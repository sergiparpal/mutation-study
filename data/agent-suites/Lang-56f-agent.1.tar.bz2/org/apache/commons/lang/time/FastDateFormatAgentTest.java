/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang.time;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.DateFormat;
import java.text.DateFormatSymbols;
import java.text.FieldPosition;
import java.text.Format;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

/**
 * Agent generated unit tests for {@link FastDateFormat}.
 *
 * <p>All assertions are made against explicitly supplied time zones and
 * locales so that the outcome does not depend on the platform defaults.</p>
 */
public class FastDateFormatAgentTest extends TestCase {

    private static final TimeZone GMT = TimeZone.getTimeZone("GMT");
    private static final TimeZone GMT_MINUS_5 = TimeZone.getTimeZone("GMT-05:00");
    private static final TimeZone GMT_PLUS_530 = TimeZone.getTimeZone("GMT+05:30");
    private static final TimeZone NEW_YORK = TimeZone.getTimeZone("America/New_York");

    /** 2003-02-05 (a Wednesday) 14:07:09.042 GMT. */
    private Calendar cal;
    /** The instant represented by {@link #cal}. */
    private Date date;

    public static void main(String[] args) {
        TestRunner.run(suite());
    }

    public static Test suite() {
        TestSuite suite = new TestSuite(FastDateFormatAgentTest.class);
        suite.setName("FastDateFormat Agent Tests");
        return suite;
    }

    public FastDateFormatAgentTest(String name) {
        super(name);
    }

    protected void setUp() throws Exception {
        super.setUp();
        cal = createCalendar(GMT, 2003, Calendar.FEBRUARY, 5, 14, 7, 9, 42);
        date = cal.getTime();
    }

    private static Calendar createCalendar(TimeZone zone, int year, int month, int day,
                                           int hour, int minute, int second, int millis) {
        Calendar c = new GregorianCalendar(zone);
        c.clear();
        c.set(year, month, day, hour, minute, second);
        c.set(Calendar.MILLISECOND, millis);
        return c;
    }

    // Factory methods and caching
    //-----------------------------------------------------------------------
    public void testGetInstanceUsesDefaultPattern() {
        FastDateFormat format = FastDateFormat.getInstance();
        assertEquals(new SimpleDateFormat().toPattern(), format.getPattern());
        assertEquals(TimeZone.getDefault(), format.getTimeZone());
        assertEquals(Locale.getDefault(), format.getLocale());
        assertEquals(false, format.getTimeZoneOverridesCalendar());
        assertSame(format, FastDateFormat.getInstance());
    }

    public void testGetInstanceIsCachedPerPattern() {
        FastDateFormat first = FastDateFormat.getInstance("yyyy-MM-dd");
        FastDateFormat second = FastDateFormat.getInstance("yyyy-MM-dd");
        assertSame(first, second);
        assertEquals("yyyy-MM-dd", first.getPattern());
        assertTrue(first != FastDateFormat.getInstance("yyyy/MM/dd"));
    }

    public void testGetInstanceIsCachedPerTimeZoneAndLocale() {
        FastDateFormat gmt = FastDateFormat.getInstance("yyyy", GMT, Locale.US);
        assertSame(gmt, FastDateFormat.getInstance("yyyy", GMT, Locale.US));

        // omitting the locale is a distinct cache key from forcing the default locale,
        // even though both formatters end up reporting the same locale
        FastDateFormat unforced = FastDateFormat.getInstance("yyyy", GMT);
        assertSame(unforced, FastDateFormat.getInstance("yyyy", GMT, (Locale) null));
        FastDateFormat forcedDefault = FastDateFormat.getInstance("yyyy", GMT, Locale.getDefault());
        assertEquals(unforced.getLocale(), forcedDefault.getLocale());
        assertTrue(unforced != forcedDefault);
        assertEquals(false, unforced.equals(forcedDefault));

        FastDateFormat other = FastDateFormat.getInstance("yyyy", GMT_MINUS_5, Locale.US);
        assertTrue(gmt != other);
        assertEquals(false, gmt.equals(other));

        FastDateFormat germany = FastDateFormat.getInstance("yyyy", GMT, Locale.GERMANY);
        assertTrue(gmt != germany);
        assertEquals(false, gmt.equals(germany));
    }

    public void testGetInstanceAccessors() {
        FastDateFormat zoned = FastDateFormat.getInstance("yyyy", GMT_MINUS_5, Locale.UK);
        assertEquals("yyyy", zoned.getPattern());
        assertEquals(GMT_MINUS_5, zoned.getTimeZone());
        assertEquals(Locale.UK, zoned.getLocale());
        assertEquals(true, zoned.getTimeZoneOverridesCalendar());

        FastDateFormat unzoned = FastDateFormat.getInstance("yyyy", (TimeZone) null, Locale.UK);
        assertEquals(TimeZone.getDefault(), unzoned.getTimeZone());
        assertEquals(false, unzoned.getTimeZoneOverridesCalendar());
        assertEquals(Locale.UK, unzoned.getLocale());
    }

    public void testGetInstanceWithLocaleOnly() {
        FastDateFormat format = FastDateFormat.getInstance("MMMM", Locale.US);
        assertEquals(Locale.US, format.getLocale());
        assertEquals(false, format.getTimeZoneOverridesCalendar());
        assertEquals("February", format.format(cal));
    }

    public void testGetInstanceNullPattern() {
        try {
            FastDateFormat.getInstance(null);
            fail("Expected IllegalArgumentException for a null pattern");
        } catch (IllegalArgumentException ex) {
            assertEquals("The pattern must not be null", ex.getMessage());
        }
    }

    public void testGetInstanceIllegalPatternComponent() {
        try {
            FastDateFormat.getInstance("yyyy-QQ", GMT, Locale.US);
            fail("Expected IllegalArgumentException for an unknown pattern letter");
        } catch (IllegalArgumentException ex) {
            assertEquals("Illegal pattern component: QQ", ex.getMessage());
        }
    }

    public void testEmptyPattern() {
        FastDateFormat format = FastDateFormat.getInstance("", GMT, Locale.US);
        assertEquals("", format.getPattern());
        assertEquals(0, format.getMaxLengthEstimate());
        assertEquals("", format.format(date));
        assertEquals("", format.format(cal));
    }

    // Style based factory methods
    //-----------------------------------------------------------------------
    public void testStyleConstants() {
        assertEquals(DateFormat.FULL, FastDateFormat.FULL);
        assertEquals(DateFormat.LONG, FastDateFormat.LONG);
        assertEquals(DateFormat.MEDIUM, FastDateFormat.MEDIUM);
        assertEquals(DateFormat.SHORT, FastDateFormat.SHORT);
    }

    public void testGetDateInstance() {
        int[] styles = new int[] {FastDateFormat.FULL, FastDateFormat.LONG,
                                  FastDateFormat.MEDIUM, FastDateFormat.SHORT};
        for (int i = 0; i < styles.length; i++) {
            int style = styles[i];
            SimpleDateFormat expected = (SimpleDateFormat) DateFormat.getDateInstance(style, Locale.US);
            FastDateFormat actual = FastDateFormat.getDateInstance(style, GMT, Locale.US);
            assertEquals(expected.toPattern(), actual.getPattern());
            assertEquals(GMT, actual.getTimeZone());
            assertEquals(Locale.US, actual.getLocale());
            assertSame(actual, FastDateFormat.getDateInstance(style, GMT, Locale.US));
            assertSame(actual, FastDateFormat.getInstance(expected.toPattern(), GMT, Locale.US));
        }
    }

    public void testGetDateInstanceOverloadsShareTheCache() {
        assertSame(FastDateFormat.getDateInstance(FastDateFormat.SHORT),
                   FastDateFormat.getDateInstance(FastDateFormat.SHORT));
        assertSame(FastDateFormat.getDateInstance(FastDateFormat.SHORT, Locale.US),
                   FastDateFormat.getDateInstance(FastDateFormat.SHORT, Locale.US));
        assertSame(FastDateFormat.getDateInstance(FastDateFormat.SHORT, GMT),
                   FastDateFormat.getDateInstance(FastDateFormat.SHORT, GMT));
        assertEquals(Locale.US, FastDateFormat.getDateInstance(FastDateFormat.SHORT, Locale.US).getLocale());
        assertEquals(GMT, FastDateFormat.getDateInstance(FastDateFormat.SHORT, GMT).getTimeZone());
    }

    public void testGetTimeInstance() {
        int[] styles = new int[] {FastDateFormat.FULL, FastDateFormat.LONG,
                                  FastDateFormat.MEDIUM, FastDateFormat.SHORT};
        for (int i = 0; i < styles.length; i++) {
            int style = styles[i];
            SimpleDateFormat expected = (SimpleDateFormat) DateFormat.getTimeInstance(style, Locale.US);
            FastDateFormat actual = FastDateFormat.getTimeInstance(style, GMT, Locale.US);
            assertEquals(expected.toPattern(), actual.getPattern());
            assertEquals(GMT, actual.getTimeZone());
            assertEquals(Locale.US, actual.getLocale());
            assertSame(actual, FastDateFormat.getTimeInstance(style, GMT, Locale.US));
        }
        assertSame(FastDateFormat.getTimeInstance(FastDateFormat.SHORT),
                   FastDateFormat.getTimeInstance(FastDateFormat.SHORT));
        assertSame(FastDateFormat.getTimeInstance(FastDateFormat.SHORT, Locale.US),
                   FastDateFormat.getTimeInstance(FastDateFormat.SHORT, Locale.US));
        assertSame(FastDateFormat.getTimeInstance(FastDateFormat.SHORT, GMT),
                   FastDateFormat.getTimeInstance(FastDateFormat.SHORT, GMT));
    }

    public void testGetDateTimeInstance() {
        SimpleDateFormat expected = (SimpleDateFormat)
            DateFormat.getDateTimeInstance(FastDateFormat.MEDIUM, FastDateFormat.SHORT, Locale.US);
        FastDateFormat actual =
            FastDateFormat.getDateTimeInstance(FastDateFormat.MEDIUM, FastDateFormat.SHORT, GMT, Locale.US);
        assertEquals(expected.toPattern(), actual.getPattern());
        assertEquals(GMT, actual.getTimeZone());
        assertEquals(Locale.US, actual.getLocale());
        assertSame(actual, FastDateFormat.getDateTimeInstance(
                FastDateFormat.MEDIUM, FastDateFormat.SHORT, GMT, Locale.US));

        // the date and the time style form a compound cache key, so swapping them
        // must not hand back the same formatter
        FastDateFormat swapped =
            FastDateFormat.getDateTimeInstance(FastDateFormat.SHORT, FastDateFormat.MEDIUM, GMT, Locale.US);
        assertTrue(actual != swapped);

        assertSame(FastDateFormat.getDateTimeInstance(FastDateFormat.SHORT, FastDateFormat.SHORT),
                   FastDateFormat.getDateTimeInstance(FastDateFormat.SHORT, FastDateFormat.SHORT));
        assertSame(FastDateFormat.getDateTimeInstance(FastDateFormat.SHORT, FastDateFormat.SHORT, Locale.US),
                   FastDateFormat.getDateTimeInstance(FastDateFormat.SHORT, FastDateFormat.SHORT, Locale.US));
        assertSame(FastDateFormat.getDateTimeInstance(FastDateFormat.SHORT, FastDateFormat.SHORT, GMT),
                   FastDateFormat.getDateTimeInstance(FastDateFormat.SHORT, FastDateFormat.SHORT, GMT));
    }

    public void testStyleInstancesRejectUnknownStyles() {
        try {
            FastDateFormat.getDateInstance(-1, GMT, Locale.US);
            fail("Expected IllegalArgumentException for a negative date style");
        } catch (IllegalArgumentException ex) {
            // expected
        }
        try {
            FastDateFormat.getTimeInstance(99, GMT, Locale.US);
            fail("Expected IllegalArgumentException for an out of range time style");
        } catch (IllegalArgumentException ex) {
            // expected
        }
        try {
            FastDateFormat.getDateTimeInstance(FastDateFormat.SHORT, 99, GMT, Locale.US);
            fail("Expected IllegalArgumentException for an out of range time style");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    // Formatting
    //-----------------------------------------------------------------------
    public void testFormatDate() {
        FastDateFormat format = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss.SSS", GMT, Locale.US);
        assertEquals("2003-02-05 14:07:09.042", format.format(date));
    }

    public void testFormatMillis() {
        FastDateFormat format = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss.SSS", GMT, Locale.US);
        assertEquals("2003-02-05 14:07:09.042", format.format(date.getTime()));
        assertEquals("1970-01-01 00:00:00.000", format.format(0L));
        assertEquals("1969-12-31 23:59:59.999", format.format(-1L));
    }

    public void testFormatCalendar() {
        FastDateFormat format = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss.SSS", GMT, Locale.US);
        assertEquals("2003-02-05 14:07:09.042", format.format(cal));
    }

    public void testFormatIntoSuppliedBuffer() {
        FastDateFormat format = FastDateFormat.getInstance("yyyy-MM-dd", GMT, Locale.US);

        StringBuffer buf = new StringBuffer("on ");
        assertSame(buf, format.format(date, buf));
        assertEquals("on 2003-02-05", buf.toString());

        StringBuffer calBuf = new StringBuffer("on ");
        assertSame(calBuf, format.format(cal, calBuf));
        assertEquals("on 2003-02-05", calBuf.toString());

        StringBuffer millisBuf = new StringBuffer("on ");
        assertSame(millisBuf, format.format(date.getTime(), millisBuf));
        assertEquals("on 2003-02-05", millisBuf.toString());
    }

    public void testFormatObject() {
        FastDateFormat format = FastDateFormat.getInstance("yyyy-MM-dd", GMT, Locale.US);
        FieldPosition pos = new FieldPosition(DateFormat.YEAR_FIELD);

        StringBuffer buf = new StringBuffer();
        assertSame(buf, format.format((Object) date, buf, pos));
        assertEquals("2003-02-05", buf.toString());

        assertEquals("2003-02-05", format.format((Object) cal, new StringBuffer(), pos).toString());
        assertEquals("2003-02-05",
                format.format(new Long(date.getTime()), new StringBuffer(), pos).toString());

        // the inherited Format.format(Object) convenience method routes through the same code
        assertEquals("2003-02-05", ((Format) format).format(date));
    }

    public void testFormatObjectRejectsUnsupportedTypes() {
        FastDateFormat format = FastDateFormat.getInstance("yyyy-MM-dd", GMT, Locale.US);
        try {
            format.format("2003-02-05", new StringBuffer(), new FieldPosition(0));
            fail("Expected IllegalArgumentException for a String argument");
        } catch (IllegalArgumentException ex) {
            assertEquals("Unknown class: java.lang.String", ex.getMessage());
        }
        try {
            format.format(new Integer(1), new StringBuffer(), new FieldPosition(0));
            fail("Expected IllegalArgumentException for an Integer argument");
        } catch (IllegalArgumentException ex) {
            assertEquals("Unknown class: java.lang.Integer", ex.getMessage());
        }
        try {
            format.format(null, new StringBuffer(), new FieldPosition(0));
            fail("Expected IllegalArgumentException for a null argument");
        } catch (IllegalArgumentException ex) {
            assertEquals("Unknown class: <null>", ex.getMessage());
        }
    }

    // Individual pattern letters
    //-----------------------------------------------------------------------
    public void testYearFields() {
        assertEquals("03", format("y"));
        assertEquals("03", format("yy"));
        assertEquals("03", format("yyy"));
        assertEquals("2003", format("yyyy"));
        assertEquals("02003", format("yyyyy"));
    }

    public void testYearPaddingBoundaries() {
        Calendar early = createCalendar(GMT, 999, Calendar.JANUARY, 1, 0, 0, 0, 0);
        FastDateFormat four = FastDateFormat.getInstance("yyyy", GMT, Locale.US);
        assertEquals("0999", four.format(early));
        assertEquals("99", FastDateFormat.getInstance("yy", GMT, Locale.US).format(early));

        Calendar y5 = createCalendar(GMT, 5, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals("0005", four.format(y5));
        assertEquals("05", FastDateFormat.getInstance("yy", GMT, Locale.US).format(y5));
    }

    public void testMonthFields() {
        assertEquals("2", format("M"));
        assertEquals("02", format("MM"));
        assertEquals("Feb", format("MMM"));
        assertEquals("February", format("MMMM"));

        Calendar december = createCalendar(GMT, 2003, Calendar.DECEMBER, 25, 0, 0, 0, 0);
        assertEquals("12", FastDateFormat.getInstance("M", GMT, Locale.US).format(december));
        assertEquals("12", FastDateFormat.getInstance("MM", GMT, Locale.US).format(december));
        assertEquals("December", FastDateFormat.getInstance("MMMM", GMT, Locale.US).format(december));
    }

    public void testDayFields() {
        assertEquals("5", format("d"));
        assertEquals("05", format("dd"));
        assertEquals("36", format("D"));
        assertEquals("036", format("DDD"));
        assertEquals("1", format("F"));
        assertEquals("Wed", format("E"));
        assertEquals("Wed", format("EEE"));
        assertEquals("Wednesday", format("EEEE"));
    }

    public void testHourFields() {
        // 14:07 -> H=14, k=14, h=2, K=2
        assertEquals("14", format("H"));
        assertEquals("14", format("k"));
        assertEquals("2", format("h"));
        assertEquals("2", format("K"));
        assertEquals("02", format("hh"));
        assertEquals("PM", format("a"));
    }

    public void testHourFieldsAtMidnight() {
        Calendar midnight = createCalendar(GMT, 2003, Calendar.FEBRUARY, 5, 0, 0, 0, 0);
        assertEquals("0", FastDateFormat.getInstance("H", GMT, Locale.US).format(midnight));
        assertEquals("00", FastDateFormat.getInstance("HH", GMT, Locale.US).format(midnight));
        // 'k' counts 1..24, so midnight is 24
        assertEquals("24", FastDateFormat.getInstance("k", GMT, Locale.US).format(midnight));
        // 'h' counts 1..12, so midnight is 12
        assertEquals("12", FastDateFormat.getInstance("h", GMT, Locale.US).format(midnight));
        // 'K' counts 0..11, so midnight is 0
        assertEquals("0", FastDateFormat.getInstance("K", GMT, Locale.US).format(midnight));
        assertEquals("AM", FastDateFormat.getInstance("a", GMT, Locale.US).format(midnight));
    }

    public void testHourFieldsAtNoon() {
        Calendar noon = createCalendar(GMT, 2003, Calendar.FEBRUARY, 5, 12, 0, 0, 0);
        assertEquals("12", FastDateFormat.getInstance("H", GMT, Locale.US).format(noon));
        assertEquals("12", FastDateFormat.getInstance("k", GMT, Locale.US).format(noon));
        assertEquals("12", FastDateFormat.getInstance("h", GMT, Locale.US).format(noon));
        assertEquals("0", FastDateFormat.getInstance("K", GMT, Locale.US).format(noon));
        assertEquals("PM", FastDateFormat.getInstance("a", GMT, Locale.US).format(noon));
    }

    public void testMinuteSecondAndMillisecondFields() {
        assertEquals("7", format("m"));
        assertEquals("07", format("mm"));
        assertEquals("9", format("s"));
        assertEquals("09", format("ss"));
        assertEquals("42", format("S"));
        assertEquals("42", format("SS"));
        assertEquals("042", format("SSS"));
        assertEquals("00042", format("SSSSS"));
    }

    public void testEraField() {
        String ad = new DateFormatSymbols(Locale.US).getEras()[GregorianCalendar.AD];
        assertEquals(ad, format("G"));
        assertEquals(ad, format("GGGG"));
    }

    // Time zones
    //-----------------------------------------------------------------------
    public void testRfc822AndIso8601TimeZoneFields() {
        assertEquals("+0000", format("Z"));
        assertEquals("+00:00", format("ZZ"));

        assertEquals("-0500", FastDateFormat.getInstance("Z", GMT_MINUS_5, Locale.US).format(date));
        assertEquals("-05:00", FastDateFormat.getInstance("ZZ", GMT_MINUS_5, Locale.US).format(date));

        assertEquals("+0530", FastDateFormat.getInstance("Z", GMT_PLUS_530, Locale.US).format(date));
        assertEquals("+05:30", FastDateFormat.getInstance("ZZ", GMT_PLUS_530, Locale.US).format(date));
    }

    public void testRfc822TimeZoneFieldIncludesDaylightSaving() {
        Calendar winter = createCalendar(NEW_YORK, 2003, Calendar.JANUARY, 15, 12, 0, 0, 0);
        Calendar summer = createCalendar(NEW_YORK, 2003, Calendar.JULY, 15, 12, 0, 0, 0);
        FastDateFormat format = FastDateFormat.getInstance("Z", NEW_YORK, Locale.US);
        assertEquals("-0500", format.format(winter));
        assertEquals("-0400", format.format(summer));
    }

    public void testTimeZoneNameFieldWithForcedZone() {
        assertEquals(GMT.getDisplayName(false, TimeZone.SHORT, Locale.US),
                FastDateFormat.getInstance("z", GMT, Locale.US).format(date));
        assertEquals(GMT.getDisplayName(false, TimeZone.SHORT, Locale.US),
                FastDateFormat.getInstance("zzz", GMT, Locale.US).format(date));
        // four or more 'z' selects the long form
        assertEquals(GMT.getDisplayName(false, TimeZone.LONG, Locale.US),
                FastDateFormat.getInstance("zzzz", GMT, Locale.US).format(date));
    }

    public void testTimeZoneNameFieldUsesDaylightName() {
        Calendar summer = createCalendar(NEW_YORK, 2003, Calendar.JULY, 15, 12, 0, 0, 0);
        Calendar winter = createCalendar(NEW_YORK, 2003, Calendar.JANUARY, 15, 12, 0, 0, 0);
        FastDateFormat format = FastDateFormat.getInstance("z", NEW_YORK, Locale.US);
        assertEquals(NEW_YORK.getDisplayName(true, TimeZone.SHORT, Locale.US), format.format(summer));
        assertEquals(NEW_YORK.getDisplayName(false, TimeZone.SHORT, Locale.US), format.format(winter));
    }

    public void testTimeZoneNameFieldFollowsCalendarWhenNotForced() {
        FastDateFormat format = FastDateFormat.getInstance("z", (TimeZone) null, Locale.US);
        Calendar gmtCal = createCalendar(GMT, 2003, Calendar.FEBRUARY, 5, 14, 7, 9, 0);
        Calendar nyCal = createCalendar(NEW_YORK, 2003, Calendar.FEBRUARY, 5, 14, 7, 9, 0);
        assertEquals(GMT.getDisplayName(false, TimeZone.SHORT, Locale.US), format.format(gmtCal));
        assertEquals(NEW_YORK.getDisplayName(false, TimeZone.SHORT, Locale.US), format.format(nyCal));
    }

    public void testForcedTimeZoneOverridesCalendarWithoutMutatingIt() {
        FastDateFormat format = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss", GMT_MINUS_5, Locale.US);
        assertEquals(true, format.getTimeZoneOverridesCalendar());
        // 14:07:09 GMT is 09:07:09 at GMT-05:00
        assertEquals("2003-02-05 09:07:09", format.format(cal));
        // the caller's calendar must be left untouched
        assertEquals(GMT, cal.getTimeZone());
        assertEquals(14, cal.get(Calendar.HOUR_OF_DAY));
    }

    public void testUnforcedTimeZoneKeepsCalendarZone() {
        FastDateFormat format = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss", (TimeZone) null, Locale.US);
        assertEquals(false, format.getTimeZoneOverridesCalendar());
        Calendar shifted = createCalendar(GMT_PLUS_530, 2003, Calendar.FEBRUARY, 5, 14, 7, 9, 0);
        assertEquals("2003-02-05 14:07:09", format.format(shifted));
        // ... while Date formatting still uses the formatter's own zone
        assertEquals(FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss", TimeZone.getDefault(), Locale.US)
                        .format(shifted.getTime()),
                     format.format(shifted.getTime()));
    }

    // Literals
    //-----------------------------------------------------------------------
    public void testLiterals() {
        assertEquals("2003-02-05", format("yyyy'-'MM'-'dd"));
        assertEquals("Today is 2003", format("'Today is 'yyyy"));
        // a doubled quote inside a literal run is an escaped quote
        assertEquals("'2003", format("''yyyy"));
        assertEquals("it's 2003", format("'it''s 'yyyy"));
        // an unterminated literal runs to the end of the pattern
        assertEquals("2003abc", format("yyyy'abc"));
        // punctuation outside quotes is copied through verbatim
        assertEquals("[2003/02]", format("'['yyyy/MM']'"));
    }

    public void testPatternOfLiteralsOnly() {
        FastDateFormat format = FastDateFormat.getInstance("'hello'", GMT, Locale.US);
        assertEquals("hello", format.format(date));
        assertEquals(5, format.getMaxLengthEstimate());
    }

    // Max length estimate
    //-----------------------------------------------------------------------
    public void testGetMaxLengthEstimate() {
        // PaddedNumberField(4) + literal + TwoDigitMonthField + literal + TwoDigitNumberField
        assertEquals(10, FastDateFormat.getInstance("yyyy-MM-dd", GMT, Locale.US).getMaxLengthEstimate());
        assertEquals(4, FastDateFormat.getInstance("yyyy", GMT, Locale.US).getMaxLengthEstimate());
        assertEquals(2, FastDateFormat.getInstance("MM", GMT, Locale.US).getMaxLengthEstimate());
        assertEquals(5, FastDateFormat.getInstance("Z", GMT, Locale.US).getMaxLengthEstimate());
    }

    public void testMaxLengthEstimateBoundsActualOutput() {
        String[] patterns = new String[] {
            "yyyy-MM-dd HH:mm:ss.SSS", "EEEE, MMMM d, yyyy", "'at' HH:mm Z", "G yyyy D F"};
        for (int i = 0; i < patterns.length; i++) {
            FastDateFormat format = FastDateFormat.getInstance(patterns[i], GMT, Locale.US);
            String result = format.format(date);
            assertTrue("Pattern " + patterns[i] + " produced " + result.length()
                    + " chars but estimated " + format.getMaxLengthEstimate(),
                    result.length() <= format.getMaxLengthEstimate());
        }
    }

    // Parsing is not supported
    //-----------------------------------------------------------------------
    public void testParseObjectIsUnsupported() {
        FastDateFormat format = FastDateFormat.getInstance("yyyy-MM-dd", GMT, Locale.US);
        ParsePosition pos = new ParsePosition(4);
        pos.setErrorIndex(9);
        assertEquals(null, format.parseObject("2003-02-05", pos));
        assertEquals(0, pos.getIndex());
        assertEquals(0, pos.getErrorIndex());
    }

    public void testParseObjectStringThrowsParseException() {
        FastDateFormat format = FastDateFormat.getInstance("yyyy-MM-dd", GMT, Locale.US);
        try {
            format.parseObject("2003-02-05");
            fail("Expected ParseException because parsing is not supported");
        } catch (ParseException ex) {
            // expected
        }
    }

    // equals, hashCode and toString
    //-----------------------------------------------------------------------
    public void testEqualsAndHashCode() throws Exception {
        FastDateFormat format = FastDateFormat.getInstance("yyyy-MM-dd", GMT, Locale.US);
        FastDateFormat copy = (FastDateFormat) roundTrip(format);

        assertTrue(format != copy);
        assertEquals(true, format.equals(copy));
        assertEquals(true, copy.equals(format));
        assertEquals(format.hashCode(), copy.hashCode());

        assertEquals(true, format.equals(format));
        assertEquals(false, format.equals(null));
        assertEquals(false, format.equals("yyyy-MM-dd"));
        assertEquals(false, format.equals(FastDateFormat.getInstance("yyyy/MM/dd", GMT, Locale.US)));
        assertEquals(false, format.equals(FastDateFormat.getInstance("yyyy-MM-dd", GMT_MINUS_5, Locale.US)));
        assertEquals(false, format.equals(FastDateFormat.getInstance("yyyy-MM-dd", GMT, Locale.GERMANY)));
        // same effective zone and locale, but not forced, so not equal
        assertEquals(false, format.equals(FastDateFormat.getInstance("yyyy-MM-dd")));
    }

    public void testToString() {
        assertEquals("FastDateFormat[yyyy-MM-dd]",
                FastDateFormat.getInstance("yyyy-MM-dd", GMT, Locale.US).toString());
        assertEquals("FastDateFormat[]", FastDateFormat.getInstance("", GMT, Locale.US).toString());
    }

    // Serialization (the parsed rules are transient and rebuilt on read)
    //-----------------------------------------------------------------------
    public void testSerializationRestoresFormattingState() throws Exception {
        FastDateFormat format = FastDateFormat.getInstance("EEEE, MMMM d, yyyy HH:mm:ss.SSS Z", GMT, Locale.US);
        String expected = format.format(date);

        FastDateFormat copy = (FastDateFormat) roundTrip(format);
        assertTrue(format != copy);
        assertEquals(format.getPattern(), copy.getPattern());
        assertEquals(format.getTimeZone(), copy.getTimeZone());
        assertEquals(format.getLocale(), copy.getLocale());
        assertEquals(format.getTimeZoneOverridesCalendar(), copy.getTimeZoneOverridesCalendar());
        assertEquals(format.getMaxLengthEstimate(), copy.getMaxLengthEstimate());
        assertEquals(expected, copy.format(date));
        assertEquals(expected, copy.format(cal));
    }

    //-----------------------------------------------------------------------
    private String format(String pattern) {
        return FastDateFormat.getInstance(pattern, GMT, Locale.US).format(date);
    }

    private static Object roundTrip(Object obj) throws Exception {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        ObjectOutputStream out = new ObjectOutputStream(bytes);
        out.writeObject(obj);
        out.close();
        ObjectInputStream in = new ObjectInputStream(new ByteArrayInputStream(bytes.toByteArray()));
        try {
            return in.readObject();
        } finally {
            in.close();
        }
    }
}
