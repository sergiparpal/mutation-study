/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang.time;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.DateFormat;
import java.text.FieldPosition;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

/**
 * Unit tests for {@link org.apache.commons.lang.time.FastDateFormat}.
 *
 * <p>These tests exercise only the public API of <code>FastDateFormat</code>.
 * Where a result depends on locale data that varies between JDKs, the expected
 * value is derived from {@link java.text.SimpleDateFormat} on the running JVM
 * rather than hard-coded, since <code>FastDateFormat</code> claims formatting
 * compatibility with <code>SimpleDateFormat</code>.</p>
 */
public class FastDateFormatAgentTest extends TestCase {

    private static final TimeZone GMT = TimeZone.getTimeZone("GMT");
    private static final TimeZone GMT_MINUS_5 = TimeZone.getTimeZone("GMT-5");

    /** 2001-09-09T01:46:40.000Z - the well known "one billion seconds" instant. */
    private static final long BILLENNIUM_MILLIS = 1000000000000L;

    public FastDateFormatAgentTest(String name) {
        super(name);
    }

    public static void main(String[] args) {
        TestRunner.run(suite());
    }

    public static Test suite() {
        return new TestSuite(FastDateFormatAgentTest.class);
    }

    /** Builds a fully determined calendar in the GMT zone. */
    private static Calendar gmtCalendar(int year, int month, int day,
                                        int hour, int min, int sec, int millis) {
        Calendar cal = new GregorianCalendar(GMT, Locale.US);
        cal.clear();
        cal.set(year, month, day, hour, min, sec);
        cal.set(Calendar.MILLISECOND, millis);
        return cal;
    }

    //-----------------------------------------------------------------------
    public void testStyleConstantsMatchDateFormat() {
        assertEquals(DateFormat.FULL, FastDateFormat.FULL);
        assertEquals(DateFormat.LONG, FastDateFormat.LONG);
        assertEquals(DateFormat.MEDIUM, FastDateFormat.MEDIUM);
        assertEquals(DateFormat.SHORT, FastDateFormat.SHORT);
        assertFalse(FastDateFormat.FULL == FastDateFormat.SHORT);
        assertFalse(FastDateFormat.LONG == FastDateFormat.MEDIUM);
    }

    //-----------------------------------------------------------------------
    public void testGetInstanceUsesDefaultPatternLocaleAndZone() {
        FastDateFormat fdf = FastDateFormat.getInstance();
        assertEquals(new SimpleDateFormat().toPattern(), fdf.getPattern());
        assertEquals(Locale.getDefault(), fdf.getLocale());
        assertEquals(TimeZone.getDefault(), fdf.getTimeZone());
        assertFalse(fdf.getTimeZoneOverridesCalendar());
    }

    public void testGetInstanceWithPatternOnly() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy/MM/dd");
        assertEquals("yyyy/MM/dd", fdf.getPattern());
        assertEquals(Locale.getDefault(), fdf.getLocale());
        assertEquals(TimeZone.getDefault(), fdf.getTimeZone());
        assertFalse(fdf.getTimeZoneOverridesCalendar());
    }

    public void testGetInstanceWithForcedTimeZone() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss", GMT_MINUS_5);
        assertEquals(GMT_MINUS_5, fdf.getTimeZone());
        assertTrue(fdf.getTimeZoneOverridesCalendar());
        assertEquals(Locale.getDefault(), fdf.getLocale());
    }

    public void testGetInstanceWithLocaleActuallyUsesLocale() {
        FastDateFormat fdf = FastDateFormat.getInstance("EEEE", Locale.GERMANY);
        assertEquals(Locale.GERMANY, fdf.getLocale());
        assertFalse(fdf.getTimeZoneOverridesCalendar());

        Calendar cal = gmtCalendar(2005, Calendar.JANUARY, 15, 0, 0, 0, 0); // a Saturday
        SimpleDateFormat reference = new SimpleDateFormat("EEEE", Locale.GERMANY);
        reference.setTimeZone(GMT);
        String german = fdf.format(cal);
        assertEquals(reference.format(cal.getTime()), german);
        // sanity: the German weekday name differs from the English one
        assertFalse("Saturday".equals(german));
    }

    public void testGetInstanceCachesEqualFormatters() {
        FastDateFormat a = FastDateFormat.getInstance("yyyy-MM-dd");
        FastDateFormat b = FastDateFormat.getInstance("yyyy-MM-dd");
        assertSame(a, b);
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
    }

    public void testGetInstanceNullPatternThrows() {
        try {
            FastDateFormat.getInstance((String) null);
            fail("Expecting IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            assertEquals("The pattern must not be null", ex.getMessage());
        }
        try {
            FastDateFormat.getInstance(null, GMT, Locale.US);
            fail("Expecting IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            assertEquals("The pattern must not be null", ex.getMessage());
        }
    }

    public void testGetInstanceInvalidPatternThrows() {
        try {
            FastDateFormat.getInstance("q");
            fail("Expecting IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            assertTrue(String.valueOf(ex.getMessage()),
                    ex.getMessage() != null
                            && ex.getMessage().indexOf("Illegal pattern component") >= 0);
        }
    }

    //-----------------------------------------------------------------------
    public void testFormatDateAndMillisUseFormatterTimeZone() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss", GMT);
        Date date = new Date(BILLENNIUM_MILLIS);

        assertEquals("2001-09-09 01:46:40", fdf.format(date));
        assertEquals("2001-09-09 01:46:40", fdf.format(BILLENNIUM_MILLIS));

        StringBuffer buf = new StringBuffer("at ");
        StringBuffer result = fdf.format(BILLENNIUM_MILLIS, buf);
        assertSame(buf, result);
        assertEquals("at 2001-09-09 01:46:40", result.toString());

        StringBuffer buf2 = new StringBuffer();
        assertSame(buf2, fdf.format(date, buf2));
        assertEquals("2001-09-09 01:46:40", buf2.toString());
    }

    public void testFormatCalendarUnforcedUsesCalendarTimeZone() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss");
        assertFalse(fdf.getTimeZoneOverridesCalendar());

        Calendar cal = Calendar.getInstance(GMT_MINUS_5);
        cal.setTime(new Date(BILLENNIUM_MILLIS));
        assertEquals("2001-09-08 20:46:40", fdf.format(cal));

        StringBuffer buf = new StringBuffer(">");
        assertSame(buf, fdf.format(cal, buf));
        assertEquals(">2001-09-08 20:46:40", buf.toString());
    }

    public void testFormatCalendarForcedTimeZoneDoesNotMutateInput() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss", GMT);
        assertTrue(fdf.getTimeZoneOverridesCalendar());

        Calendar cal = Calendar.getInstance(GMT_MINUS_5);
        cal.setTime(new Date(BILLENNIUM_MILLIS));
        int hourBefore = cal.get(Calendar.HOUR_OF_DAY);
        TimeZone zoneBefore = cal.getTimeZone();

        assertEquals("2001-09-09 01:46:40", fdf.format(cal));

        assertEquals("input calendar hour must not be mutated",
                hourBefore, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals("input calendar zone must not be mutated",
                zoneBefore, cal.getTimeZone());
    }

    //-----------------------------------------------------------------------
    public void testFormatObjectDispatchesByRuntimeType() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss", GMT);
        Date date = new Date(BILLENNIUM_MILLIS);
        Calendar cal = Calendar.getInstance(GMT);
        cal.setTime(date);
        FieldPosition pos = new FieldPosition(0);

        StringBuffer b1 = new StringBuffer();
        assertSame(b1, fdf.format((Object) date, b1, pos));
        assertEquals("2001-09-09 01:46:40", b1.toString());

        StringBuffer b2 = new StringBuffer();
        assertSame(b2, fdf.format((Object) cal, b2, pos));
        assertEquals("2001-09-09 01:46:40", b2.toString());

        StringBuffer b3 = new StringBuffer("<");
        assertSame(b3, fdf.format((Object) new Long(BILLENNIUM_MILLIS), b3, pos));
        assertEquals("<2001-09-09 01:46:40", b3.toString());

        // inherited java.text.Format.format(Object)
        assertEquals("2001-09-09 01:46:40", fdf.format((Object) date));
    }

    public void testFormatObjectRejectsUnknownType() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd", GMT);
        try {
            fdf.format("not a date", new StringBuffer(), new FieldPosition(0));
            fail("Expecting IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            assertEquals("Unknown class: java.lang.String", ex.getMessage());
        }
        try {
            fdf.format((Object) null, new StringBuffer(), new FieldPosition(0));
            fail("Expecting IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            assertTrue(String.valueOf(ex.getMessage()),
                    ex.getMessage() != null && ex.getMessage().indexOf("<null>") >= 0);
        }
    }

    //-----------------------------------------------------------------------
    public void testParseObjectIsNotSupported() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd");
        ParsePosition pos = new ParsePosition(3);
        assertNull(fdf.parseObject("2005-01-15", pos));
        assertEquals(0, pos.getIndex());
        assertEquals(0, pos.getErrorIndex());
    }

    //-----------------------------------------------------------------------
    public void testGetMaxLengthEstimate() {
        assertEquals(4, FastDateFormat.getInstance("yyyy").getMaxLengthEstimate());
        assertEquals(10, FastDateFormat.getInstance("yyyy-MM-dd").getMaxLengthEstimate());

        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss.SSS", GMT, Locale.US);
        String formatted = fdf.format(gmtCalendar(2005, Calendar.JANUARY, 15, 12, 34, 56, 789).getTime());
        assertEquals("2005-01-15 12:34:56.789", formatted);
        assertTrue("estimate " + fdf.getMaxLengthEstimate() + " should be >= " + formatted.length(),
                fdf.getMaxLengthEstimate() >= formatted.length());
    }

    public void testLiteralPatterns() {
        Calendar cal = gmtCalendar(2005, Calendar.JANUARY, 15, 0, 0, 0, 0);

        FastDateFormat literal = FastDateFormat.getInstance("'Today is 'yyyy", GMT, Locale.US);
        assertEquals("Today is 2005", literal.format(cal));
        assertEquals(13, literal.getMaxLengthEstimate());

        FastDateFormat escapedQuote = FastDateFormat.getInstance("''", GMT, Locale.US);
        assertEquals("'", escapedQuote.format(cal));
        assertEquals(1, escapedQuote.getMaxLengthEstimate());
    }

    public void testTimeZoneOffsetPatterns() {
        Date date = new Date(BILLENNIUM_MILLIS);

        assertEquals("2001-09-09 01:46:40 +0000",
                FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss Z", GMT).format(date));
        assertEquals("2001-09-09 01:46:40 +00:00",
                FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss ZZ", GMT).format(date));
        assertEquals("2001-09-08 20:46:40 -0500",
                FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss Z", GMT_MINUS_5).format(date));
        assertEquals("2001-09-08 20:46:40 -05:00",
                FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss ZZ", GMT_MINUS_5).format(date));
    }

    //-----------------------------------------------------------------------
    public void testFormatIsCompatibleWithSimpleDateFormat() {
        String[] patterns = {
                "yyyy-MM-dd HH:mm:ss.SSS",
                "yyyy-MM-dd'T'HH:mm:ss",
                "EEEE, MMMM d, yyyy G",
                "EEE, d MMM yyyy HH:mm:ss",
                "yyyy.MM.dd G 'at' HH:mm:ss",
                "h 'o''clock' a",
                "hh:mm:ss a",
                "D F k K",
                "yyyy-MM-dd HH:mm:ss z",
                "yyyy-MM-dd HH:mm:ss zzzz",
                "EEE, MMM d, ''yy",
        };
        Date date = gmtCalendar(2005, Calendar.JULY, 4, 23, 5, 9, 7).getTime();
        for (int i = 0; i < patterns.length; i++) {
            String pattern = patterns[i];
            SimpleDateFormat sdf = new SimpleDateFormat(pattern, Locale.US);
            sdf.setTimeZone(GMT);
            FastDateFormat fdf = FastDateFormat.getInstance(pattern, GMT, Locale.US);
            assertEquals("pattern <" + pattern + ">", sdf.format(date), fdf.format(date));
            assertEquals("pattern <" + pattern + ">", pattern, fdf.getPattern());
        }
    }

    //-----------------------------------------------------------------------
    public void testGetDateInstance() {
        Calendar cal = gmtCalendar(2005, Calendar.JANUARY, 15, 12, 34, 56, 0);
        Date date = cal.getTime();

        int[] styles = { FastDateFormat.FULL, FastDateFormat.LONG,
                         FastDateFormat.MEDIUM, FastDateFormat.SHORT };
        String[] expectedStart = { "Saturday, January 15, ", "January 15, ", "Jan 15, ", "1/15/05" };

        for (int i = 0; i < styles.length; i++) {
            int style = styles[i];
            String jdkPattern =
                    ((SimpleDateFormat) DateFormat.getDateInstance(style, Locale.US)).toPattern();

            FastDateFormat fdf = FastDateFormat.getDateInstance(style, GMT, Locale.US);
            assertEquals(jdkPattern, fdf.getPattern());
            assertSame(fdf, FastDateFormat.getDateInstance(style, GMT, Locale.US));

            String out = fdf.format(date);
            assertTrue("style " + style + " -> " + out, out.startsWith(expectedStart[i]));
            assertTrue("style " + style + " -> " + out, out.endsWith("05"));

            // date-only output does not depend on the zone, so the other overloads agree
            assertEquals(out, FastDateFormat.getDateInstance(style, Locale.US).format(cal));
            assertEquals(out, FastDateFormat.getDateInstance(style, GMT).format(date));
        }
    }

    public void testGetTimeInstance() {
        Calendar cal = gmtCalendar(2005, Calendar.JANUARY, 15, 12, 34, 56, 0);
        Date date = cal.getTime();

        FastDateFormat medium = FastDateFormat.getTimeInstance(FastDateFormat.MEDIUM, GMT, Locale.US);
        assertEquals(((SimpleDateFormat) DateFormat.getTimeInstance(
                        FastDateFormat.MEDIUM, Locale.US)).toPattern(),
                medium.getPattern());
        assertEquals("12:34:56 PM", medium.format(date));
        assertSame(medium, FastDateFormat.getTimeInstance(FastDateFormat.MEDIUM, GMT, Locale.US));

        FastDateFormat shortFmt = FastDateFormat.getTimeInstance(FastDateFormat.SHORT, GMT, Locale.US);
        assertEquals("12:34 PM", shortFmt.format(date));

        // unforced overloads: format the GMT calendar so the wall-clock result is deterministic
        assertEquals("12:34 PM",
                FastDateFormat.getTimeInstance(FastDateFormat.SHORT, Locale.US).format(cal));
        assertEquals("12:34 PM",
                FastDateFormat.getTimeInstance(FastDateFormat.SHORT).format(cal));
    }

    public void testGetDateTimeInstance() {
        Calendar cal = gmtCalendar(2005, Calendar.JANUARY, 15, 12, 34, 56, 0);
        Date date = cal.getTime();

        FastDateFormat fdf = FastDateFormat.getDateTimeInstance(
                FastDateFormat.SHORT, FastDateFormat.SHORT, GMT, Locale.US);
        assertEquals(((SimpleDateFormat) DateFormat.getDateTimeInstance(
                        FastDateFormat.SHORT, FastDateFormat.SHORT, Locale.US)).toPattern(),
                fdf.getPattern());
        assertEquals("1/15/05, 12:34 PM", fdf.format(date));
        assertSame(fdf, FastDateFormat.getDateTimeInstance(
                FastDateFormat.SHORT, FastDateFormat.SHORT, GMT, Locale.US));

        assertEquals("1/15/05, 12:34 PM", FastDateFormat.getDateTimeInstance(
                FastDateFormat.SHORT, FastDateFormat.SHORT, Locale.US).format(cal));
    }

    public void testGetInstanceInvalidStyleThrows() {
        try {
            FastDateFormat.getDateInstance(-1);
            fail("Expecting IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
        try {
            FastDateFormat.getTimeInstance(-1);
            fail("Expecting IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
        try {
            FastDateFormat.getDateTimeInstance(-1, -1);
            fail("Expecting IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    public void testEqualsAndHashCode() {
        FastDateFormat base = FastDateFormat.getInstance("yyyy-MM-dd", GMT, Locale.US);

        assertTrue(base.equals(base));
        assertTrue(base.equals(FastDateFormat.getInstance("yyyy-MM-dd", GMT, Locale.US)));
        assertEquals(base.hashCode(),
                FastDateFormat.getInstance("yyyy-MM-dd", GMT, Locale.US).hashCode());

        assertFalse(base.equals(FastDateFormat.getInstance("yyyy/MM/dd", GMT, Locale.US)));
        assertFalse(base.equals(FastDateFormat.getInstance("yyyy-MM-dd", GMT, Locale.GERMANY)));
        assertFalse(base.hashCode()
                == FastDateFormat.getInstance("yyyy-MM-dd", GMT, Locale.GERMANY).hashCode());

        // same zone value, but one formatter forces it and the other does not
        assertFalse(FastDateFormat.getInstance("yyyy").equals(
                FastDateFormat.getInstance("yyyy", TimeZone.getDefault())));

        assertFalse(base.equals(null));
        assertFalse(base.equals("yyyy-MM-dd"));
    }

    public void testToString() {
        assertEquals("FastDateFormat[yyyy-MM-dd]",
                FastDateFormat.getInstance("yyyy-MM-dd").toString());
        assertEquals("FastDateFormat[dd.MM.yyyy]",
                FastDateFormat.getInstance("dd.MM.yyyy", GMT, Locale.US).toString());
    }

    //-----------------------------------------------------------------------
    public void testSerializationRoundTrip() throws Exception {
        FastDateFormat original =
                FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss", GMT, Locale.US);

        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(bos);
        oos.writeObject(original);
        oos.close();

        ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(bos.toByteArray()));
        FastDateFormat copy = (FastDateFormat) ois.readObject();
        ois.close();

        assertEquals(original, copy);
        assertEquals(original.getPattern(), copy.getPattern());
        assertEquals(original.getTimeZone(), copy.getTimeZone());
        assertEquals(original.getLocale(), copy.getLocale());
        assertEquals(original.getMaxLengthEstimate(), copy.getMaxLengthEstimate());
        assertTrue(copy.getMaxLengthEstimate() > 0);

        Date date = new Date(BILLENNIUM_MILLIS);
        assertEquals("2001-09-09 01:46:40", copy.format(date));
        assertEquals(original.format(date), copy.format(date));
    }
}
