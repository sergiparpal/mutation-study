/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.cli;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.List;
import java.util.Properties;

import org.junit.Before;
import org.junit.Test;

/**
 * Tests for {@link DefaultParser}.
 */
public class DefaultParserAgentTest
{
    private DefaultParser parser;

    private Options options;

    @Before
    public void setUp()
    {
        parser = new DefaultParser();
        options = new Options()
            .addOption("a", "enable-a", false, "turn [a] on or off")
            .addOption("b", "bfile", true, "set the value of [b]")
            .addOption("c", "copt", false, "turn [c] on or off");
    }

    @Test
    public void testParseTwoArgOverloadSimpleShortOptions() throws Exception
    {
        String[] args = new String[] { "-a", "-b", "toast", "foo", "bar" };

        CommandLine cl = parser.parse(options, args);

        assertTrue(cl.hasOption("a"));
        assertTrue(cl.hasOption("b"));
        assertEquals("toast", cl.getOptionValue("b"));
        assertEquals(2, cl.getArgList().size());
        assertEquals("foo", cl.getArgList().get(0));
        assertEquals("bar", cl.getArgList().get(1));
    }

    @Test
    public void testParseLongOptions() throws Exception
    {
        String[] args = new String[] { "--enable-a", "--bfile", "toast" };

        CommandLine cl = parser.parse(options, args);

        assertTrue(cl.hasOption("a"));
        assertEquals("toast", cl.getOptionValue("bfile"));
    }

    @Test
    public void testParseNullArgumentsProducesEmptyCommandLine() throws Exception
    {
        CommandLine cl = parser.parse(options, null);

        assertNotNull(cl);
        assertFalse(cl.hasOption("a"));
        assertEquals(0, cl.getOptions().length);
        assertEquals(0, cl.getArgList().size());
    }

    @Test
    public void testParseEmptyArgumentsArray() throws Exception
    {
        CommandLine cl = parser.parse(options, new String[0]);

        assertNotNull(cl);
        assertEquals(0, cl.getArgList().size());
    }

    @Test
    public void testThreeArgOverloadStopAtNonOptionTrue() throws Exception
    {
        String[] args = new String[] { "-c", "foobar", "-b", "toast" };

        CommandLine cl = parser.parse(options, args, true);

        assertTrue(cl.hasOption("c"));
        assertFalse(cl.hasOption("b"));
        assertEquals(3, cl.getArgList().size());
        assertEquals("foobar", cl.getArgList().get(0));
        assertEquals("-b", cl.getArgList().get(1));
        assertEquals("toast", cl.getArgList().get(2));
    }

    @Test
    public void testThreeArgOverloadStopAtNonOptionFalseThrowsOnUnknown() throws Exception
    {
        String[] args = new String[] { "-a", "-z" };

        try
        {
            parser.parse(options, args, false);
            fail("expected UnrecognizedOptionException");
        }
        catch (UnrecognizedOptionException e)
        {
            assertEquals("-z", e.getOption());
        }
    }

    @Test
    public void testThreeArgOverloadWithProperties() throws Exception
    {
        Properties properties = new Properties();
        properties.setProperty("a", "true");

        CommandLine cl = parser.parse(options, new String[0], properties);

        assertTrue(cl.hasOption("a"));
    }

    @Test
    public void testFourArgOverloadCombinesPropertiesAndStopAtNonOption() throws Exception
    {
        Properties properties = new Properties();
        properties.setProperty("c", "true");

        String[] args = new String[] { "-a", "extra" };

        CommandLine cl = parser.parse(options, args, properties, true);

        assertTrue(cl.hasOption("a"));
        assertTrue(cl.hasOption("c"));
        assertEquals(1, cl.getArgList().size());
        assertEquals("extra", cl.getArgList().get(0));
    }

    @Test
    public void testDoubleDashStopsOptionParsing() throws Exception
    {
        String[] args = new String[] { "--copt", "--", "-b", "toast" };

        CommandLine cl = parser.parse(options, args);

        assertTrue(cl.hasOption("c"));
        assertFalse(cl.hasOption("b"));
        assertEquals(2, cl.getArgList().size());
        assertEquals("-b", cl.getArgList().get(0));
        assertEquals("toast", cl.getArgList().get(1));
    }

    @Test
    public void testMissingArgumentExceptionCarriesOption() throws Exception
    {
        String[] args = new String[] { "-b" };

        try
        {
            parser.parse(options, args);
            fail("expected MissingArgumentException");
        }
        catch (MissingArgumentException e)
        {
            assertEquals("b", e.getOption().getOpt());
        }
    }

    @Test
    public void testMissingArgumentDetectedBeforeDoubleDash() throws Exception
    {
        Options opts = new Options();
        opts.addOption(OptionBuilder.hasArg().create('n'));
        opts.addOption(OptionBuilder.create('m'));

        try
        {
            parser.parse(opts, new String[] { "-n", "--", "-m" });
            fail("expected MissingArgumentException");
        }
        catch (MissingArgumentException e)
        {
            assertEquals("n", e.getOption().getOpt());
        }
    }

    @Test
    public void testUnrecognizedOptionExceptionCarriesToken() throws Exception
    {
        String[] args = new String[] { "-a", "-d", "-b", "toast" };

        try
        {
            parser.parse(options, args);
            fail("expected UnrecognizedOptionException");
        }
        catch (UnrecognizedOptionException e)
        {
            assertEquals("-d", e.getOption());
        }
    }

    @Test
    public void testUnrecognizedTokenWithoutDashBecomesArgument() throws Exception
    {
        String[] args = new String[] { "foo", "-a" };

        CommandLine cl = parser.parse(options, args);

        assertTrue(cl.hasOption("a"));
        assertEquals(1, cl.getArgList().size());
        assertEquals("foo", cl.getArgList().get(0));
    }

    @Test
    public void testMissingRequiredOptionExceptionListsMissingOption()
    {
        Options opts = new Options();
        opts.addOption("a", "enable-a", false, null);
        opts.addOption(OptionBuilder.withLongOpt("bfile").hasArg().isRequired().create('b'));

        try
        {
            parser.parse(opts, new String[] { "-a" });
            fail("expected MissingOptionException");
        }
        catch (MissingOptionException e)
        {
            assertEquals("Missing required option: b", e.getMessage());
            assertTrue(e.getMissingOptions().contains("b"));
        }
        catch (ParseException e)
        {
            fail("expected MissingOptionException, got " + e);
        }
    }

    @Test
    public void testMissingRequiredOptionsExceptionListsAllMissing()
    {
        Options opts = new Options();
        opts.addOption(OptionBuilder.withLongOpt("bfile").hasArg().isRequired().create('b'));
        opts.addOption(OptionBuilder.withLongOpt("cfile").hasArg().isRequired().create('c'));

        try
        {
            parser.parse(opts, new String[0]);
            fail("expected MissingOptionException");
        }
        catch (MissingOptionException e)
        {
            assertEquals("Missing required options: b, c", e.getMessage());
            assertTrue(e.getMissingOptions().contains("b"));
            assertTrue(e.getMissingOptions().contains("c"));
        }
        catch (ParseException e)
        {
            fail("expected MissingOptionException, got " + e);
        }
    }

    @Test
    public void testRequiredOptionSatisfiedProducesNoException() throws Exception
    {
        Options opts = new Options();
        opts.addOption(OptionBuilder.withLongOpt("bfile").hasArg().isRequired().create('b'));

        CommandLine cl = parser.parse(opts, new String[] { "-b", "file" });

        assertTrue(cl.hasOption("b"));
        assertEquals("file", cl.getOptionValue("b"));
    }

    @Test
    public void testAmbiguousLongOptionExceptionListsMatches() throws Exception
    {
        Options opts = new Options();
        opts.addOption(OptionBuilder.withLongOpt("version").create());
        opts.addOption(OptionBuilder.withLongOpt("verbose").create());

        try
        {
            parser.parse(opts, new String[] { "--ver" });
            fail("expected AmbiguousOptionException");
        }
        catch (AmbiguousOptionException e)
        {
            assertEquals("--ver", e.getOption());
            assertEquals(2, e.getMatchingOptions().size());
            assertTrue(e.getMatchingOptions().contains("version"));
            assertTrue(e.getMatchingOptions().contains("verbose"));
        }
    }

    @Test
    public void testUnambiguousPartialLongOptionResolves() throws Exception
    {
        Options opts = new Options();
        opts.addOption(OptionBuilder.withLongOpt("version").create());
        opts.addOption(OptionBuilder.withLongOpt("help").create());

        CommandLine cl = parser.parse(opts, new String[] { "--ver" });

        assertTrue(cl.hasOption("version"));
        assertFalse(cl.hasOption("help"));
    }

    @Test
    public void testOptionGroupSelectionRecorded() throws Exception
    {
        OptionGroup group = new OptionGroup();
        group.addOption(OptionBuilder.create("a"));
        group.addOption(OptionBuilder.create("b"));

        Options opts = new Options();
        opts.addOptionGroup(group);

        CommandLine cl = parser.parse(opts, new String[] { "-b" });

        assertTrue(cl.hasOption("b"));
        assertEquals("b", group.getSelected());
    }

    @Test
    public void testAlreadySelectedExceptionWhenGroupOptionsConflict() throws Exception
    {
        OptionGroup group = new OptionGroup();
        group.addOption(OptionBuilder.create("a"));
        group.addOption(OptionBuilder.create("b"));

        Options opts = new Options();
        opts.addOptionGroup(group);

        try
        {
            parser.parse(opts, new String[] { "-a", "-b" });
            fail("expected AlreadySelectedException");
        }
        catch (AlreadySelectedException e)
        {
            assertEquals("a", e.getOptionGroup().getSelected());
            assertEquals("b", e.getOption().getOpt());
        }
    }

    @Test
    public void testMissingRequiredGroupThrowsWithGroupInstance() throws Exception
    {
        OptionGroup group = new OptionGroup();
        group.addOption(OptionBuilder.create("a"));
        group.addOption(OptionBuilder.create("b"));
        group.setRequired(true);

        Options opts = new Options();
        opts.addOptionGroup(group);
        opts.addOption(OptionBuilder.isRequired().create("c"));

        try
        {
            parser.parse(opts, new String[] { "-c" });
            fail("expected MissingOptionException");
        }
        catch (MissingOptionException e)
        {
            assertEquals(1, e.getMissingOptions().size());
            assertTrue(e.getMissingOptions().get(0) instanceof OptionGroup);
        }
    }

    @Test
    public void testReusingOptionsResetsGroupSelectionBetweenParses() throws Exception
    {
        OptionGroup group = new OptionGroup();
        group.addOption(OptionBuilder.create("a"));
        group.addOption(OptionBuilder.create("b"));

        Options opts = new Options();
        opts.addOptionGroup(group);

        parser.parse(opts, new String[] { "-a" });
        assertEquals("a", group.getSelected());

        // reusing the same Options instance with a different selection must not throw
        CommandLine cl = parser.parse(opts, new String[] { "-b" });

        assertTrue(cl.hasOption("b"));
        assertEquals("b", group.getSelected());
    }

    @Test
    public void testReusingRequiredOptionAcrossParsesReEvaluatesRequirement() throws Exception
    {
        Options opts = new Options();
        opts.addOption(OptionBuilder.isRequired().create('v'));

        parser.parse(opts, new String[] { "-v" });

        try
        {
            parser.parse(opts, new String[0]);
            fail("expected MissingOptionException");
        }
        catch (MissingOptionException e)
        {
            assertTrue(e.getMissingOptions().contains("v"));
        }
    }

    @Test
    public void testNegativeNumberTreatedAsArgumentValue() throws Exception
    {
        String[] args = new String[] { "-b", "-1" };

        CommandLine cl = parser.parse(options, args);

        assertEquals("-1", cl.getOptionValue("b"));
    }

    @Test
    public void testArgumentStartingWithHyphenAcceptedAsValue() throws Exception
    {
        String[] args = new String[] { "-b", "-foo" };

        CommandLine cl = parser.parse(options, args);

        assertEquals("-foo", cl.getOptionValue("b"));
    }

    @Test
    public void testLoneHyphenTreatedAsArgumentNotOption() throws Exception
    {
        String[] args = new String[] { "-a", "-" };

        CommandLine cl = parser.parse(options, args);

        assertTrue(cl.hasOption("a"));
        assertEquals(1, cl.getArgList().size());
        assertEquals("-", cl.getArgList().get(0));
    }

    @Test
    public void testShortOptionWithEqualsSign() throws Exception
    {
        Options opts = new Options();
        opts.addOption(OptionBuilder.withLongOpt("foo").hasArg().create('f'));

        CommandLine cl = parser.parse(opts, new String[] { "-f=bar" });

        assertEquals("bar", cl.getOptionValue("foo"));
    }

    @Test
    public void testShortOptionWithoutEqualsSign() throws Exception
    {
        Options opts = new Options();
        opts.addOption(OptionBuilder.withLongOpt("foo").hasArg().create('f'));

        CommandLine cl = parser.parse(opts, new String[] { "-fbar" });

        assertEquals("bar", cl.getOptionValue("foo"));
    }

    @Test
    public void testLongOptionWithEqualsDoubleDash() throws Exception
    {
        Options opts = new Options();
        opts.addOption(OptionBuilder.withLongOpt("foo").hasArg().create('f'));

        CommandLine cl = parser.parse(opts, new String[] { "--foo=bar" });

        assertEquals("bar", cl.getOptionValue("foo"));
    }

    @Test
    public void testLongOptionWithUnexpectedArgumentThrows() throws Exception
    {
        Options opts = new Options();
        opts.addOption(OptionBuilder.withLongOpt("foo").create('f'));

        try
        {
            parser.parse(opts, new String[] { "--foo=bar" });
            fail("expected UnrecognizedOptionException");
        }
        catch (UnrecognizedOptionException e)
        {
            assertEquals("--foo=bar", e.getOption());
        }
    }

    @Test
    public void testBurstingConcatenatedShortOptions() throws Exception
    {
        String[] args = new String[] { "-acbtoast", "foo" };

        CommandLine cl = parser.parse(options, args);

        assertTrue(cl.hasOption("a"));
        assertTrue(cl.hasOption("c"));
        assertTrue(cl.hasOption("b"));
        assertEquals("toast", cl.getOptionValue("b"));
        assertEquals(1, cl.getArgList().size());
        assertEquals("foo", cl.getArgList().get(0));
    }

    @Test
    public void testUnrecognizedOptionDuringBurstingCarriesFullToken() throws Exception
    {
        String[] args = new String[] { "-adbtoast" };

        try
        {
            parser.parse(options, args);
            fail("expected UnrecognizedOptionException");
        }
        catch (UnrecognizedOptionException e)
        {
            assertEquals("-adbtoast", e.getOption());
        }
    }

    @Test
    public void testStopBurstingKeepsRemainderAsSingleArgument() throws Exception
    {
        String[] args = new String[] { "-azc" };

        CommandLine cl = parser.parse(options, args, true);

        assertTrue(cl.hasOption("a"));
        assertFalse(cl.hasOption("c"));
        assertEquals(1, cl.getArgList().size());
        assertEquals("zc", cl.getArgList().get(0));
    }

    @Test
    public void testJavaPropertyStyleOptionSplitsKeyAndValue() throws Exception
    {
        Options opts = new Options();
        opts.addOption(OptionBuilder.withValueSeparator().hasArgs(2).create('D'));

        CommandLine cl = parser.parse(opts, new String[] { "-Dkey=value" });

        String[] values = cl.getOptionValues("D");
        assertArrayEquals(new String[] { "key", "value" }, values);
    }

    @Test
    public void testUnlimitedArgsCollectsAllValuesUntilNextOption() throws Exception
    {
        Options opts = new Options();
        opts.addOption(OptionBuilder.hasArgs().create("e"));
        opts.addOption(OptionBuilder.hasArgs().create("f"));

        CommandLine cl = parser.parse(opts, new String[] { "-e", "one", "two", "-f", "alpha" });

        assertArrayEquals(new String[] { "one", "two" }, cl.getOptionValues("e"));
        assertArrayEquals(new String[] { "alpha" }, cl.getOptionValues("f"));
    }

    @Test
    public void testPropertyProvidesDefaultForFlagOption() throws Exception
    {
        Options opts = new Options();
        opts.addOption("a", false, "toggle -a");

        Properties properties = new Properties();
        properties.setProperty("a", "true");

        CommandLine cl = parser.parse(opts, null, properties);

        assertTrue(cl.hasOption("a"));
    }

    @Test
    public void testPropertyIgnoredWhenNotTrueYesOrOne() throws Exception
    {
        Options opts = new Options();
        opts.addOption("a", false, "toggle -a");

        Properties properties = new Properties();
        properties.setProperty("a", "just a string");

        CommandLine cl = parser.parse(opts, null, properties);

        assertFalse(cl.hasOption("a"));
    }

    @Test
    public void testPropertyDoesNotOverrideCommandLineValue() throws Exception
    {
        Options opts = new Options();
        opts.addOption(OptionBuilder.hasOptionalArgs().create('j'));

        Properties properties = new Properties();
        properties.setProperty("j", "seek");

        CommandLine cl = parser.parse(opts, new String[] { "-j", "found" }, properties);

        assertEquals("found", cl.getOptionValue("j"));
    }

    @Test
    public void testUnrecognizedPropertyOptionThrows() throws Exception
    {
        Options opts = new Options();

        Properties properties = new Properties();
        properties.setProperty("f", "true");

        try
        {
            parser.parse(opts, null, properties);
            fail("expected UnrecognizedOptionException");
        }
        catch (UnrecognizedOptionException e)
        {
            // expected: property key "f" is not defined in Options
        }
    }

    @Test
    public void testPropertySkippedWhenGroupAlreadySelectedFromCommandLine() throws Exception
    {
        Options opts = new Options();

        OptionGroup group = new OptionGroup();
        group.addOption(new Option("a", null));
        group.addOption(new Option("b", null));
        opts.addOptionGroup(group);

        Properties properties = new Properties();
        properties.put("b", "true");

        CommandLine cl = parser.parse(opts, new String[] { "-a" }, properties);

        assertTrue(cl.hasOption("a"));
        assertFalse(cl.hasOption("b"));
    }

    @Test
    public void testGetArgsAndGetArgListReturnSameRemainingTokens() throws Exception
    {
        String[] args = new String[] { "-a", "foo", "bar" };

        CommandLine cl = parser.parse(options, args);

        String[] extra = cl.getArgs();
        List<String> extraList = cl.getArgList();

        assertArrayEquals(new String[] { "foo", "bar" }, extra);
        assertEquals(extraList, java.util.Arrays.asList(extra));
    }

    @Test
    public void testOptionValueDefaultsToNullWhenNotSet() throws Exception
    {
        CommandLine cl = parser.parse(options, new String[] { "-a" });

        assertNull(cl.getOptionValue("b"));
        assertNull(cl.getOptionValues("b"));
    }
}
