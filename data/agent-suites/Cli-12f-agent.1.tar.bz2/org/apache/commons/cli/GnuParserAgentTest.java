/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.cli;

import java.util.Properties;

import junit.framework.TestCase;

/**
 * Test case for the GnuParser.
 */
public class GnuParserAgentTest extends TestCase
{
    private Options options = null;
    private Parser parser = null;

    public void setUp()
    {
        options = new Options()
            .addOption("a", "enable-a", false, "turn [a] on or off")
            .addOption("b", "bfile", true, "set the value of [b]")
            .addOption("c", "copt", false, "turn [c] on or off");

        parser = new GnuParser();
    }

    public void testSimpleShort() throws Exception
    {
        String[] args = new String[] { "-a", "-b", "toast", "foo", "bar" };

        CommandLine cl = parser.parse(options, args);

        assertTrue("Confirm -a is set", cl.hasOption("a"));
        assertTrue("Confirm -b is set", cl.hasOption("b"));
        assertEquals("Confirm arg of -b", "toast", cl.getOptionValue("b"));
        assertEquals("Confirm size of extra args", 2, cl.getArgList().size());
        assertEquals("foo", cl.getArgList().get(0));
        assertEquals("bar", cl.getArgList().get(1));
    }

    public void testSimpleLong() throws Exception
    {
        String[] args = new String[] { "--enable-a", "--bfile", "toast", "foo", "bar" };

        CommandLine cl = parser.parse(options, args);

        assertTrue("Confirm -a is set", cl.hasOption("a"));
        assertTrue("Confirm -b is set", cl.hasOption("b"));
        assertEquals("Confirm arg of -b", "toast", cl.getOptionValue("b"));
        assertEquals("Confirm arg of --bfile", "toast", cl.getOptionValue("bfile"));
        assertEquals("Confirm size of extra args", 2, cl.getArgList().size());
    }

    public void testDoubleDash() throws Exception
    {
        String[] args = new String[] { "--copt", "--", "-b", "toast" };

        CommandLine cl = parser.parse(options, args);

        assertTrue("Confirm -c is set", cl.hasOption("c"));
        assertFalse("Confirm -b is not set", cl.hasOption("b"));
        assertEquals("Confirm 2 extra args", 2, cl.getArgList().size());
        assertEquals("-b", cl.getArgList().get(0));
        assertEquals("toast", cl.getArgList().get(1));
    }

    public void testSingleDash() throws Exception
    {
        String[] args = new String[] { "--copt", "-b", "-", "-a", "-" };

        CommandLine cl = parser.parse(options, args);

        assertTrue("Confirm -a is set", cl.hasOption("a"));
        assertTrue("Confirm -b is set", cl.hasOption("b"));
        assertEquals("Confirm arg of -b", "-", cl.getOptionValue("b"));
        assertEquals("Confirm 1 extra arg", 1, cl.getArgList().size());
        assertEquals("-", cl.getArgList().get(0));
    }

    /**
     * Unlike PosixParser, GnuParser does not bundle short options together.
     * A combined token like "-acbtoast" is only split into the first
     * recognised two-character prefix ("-a") and the remainder is treated
     * as a plain trailing argument, not further decomposed.
     */
    public void testCombinedShortOptionsNotBundled() throws Exception
    {
        String[] args = new String[] { "-acbtoast" };

        CommandLine cl = parser.parse(options, args);

        assertTrue("Confirm -a is set", cl.hasOption("a"));
        assertFalse("Confirm -b is not set", cl.hasOption("b"));
        assertFalse("Confirm -c is not set", cl.hasOption("c"));
        assertEquals("Confirm 1 extra arg", 1, cl.getArgList().size());
        assertEquals("cbtoast", cl.getArgList().get(0));
    }

    public void testLongWithEqualDoubleDash() throws Exception
    {
        String[] args = new String[] { "--bfile=toast" };

        CommandLine cl = parser.parse(options, args);

        assertTrue("Confirm -b is set", cl.hasOption("b"));
        assertEquals("Confirm arg of -b", "toast", cl.getOptionValue("b"));
        assertEquals("Confirm no extra args", 0, cl.getArgList().size());
    }

    public void testLongWithEqualSingleDash() throws Exception
    {
        String[] args = new String[] { "-bfile=toast" };

        CommandLine cl = parser.parse(options, args);

        assertTrue("Confirm -b is set", cl.hasOption("b"));
        assertEquals("Confirm arg of -b", "toast", cl.getOptionValue("b"));
        assertEquals("Confirm arg of --bfile", "toast", cl.getOptionValue("bfile"));
    }

    public void testShortWithEqual() throws Exception
    {
        String[] args = new String[] { "-b=toast" };

        CommandLine cl = parser.parse(options, args);

        assertTrue("Confirm -b is set", cl.hasOption("b"));
        assertEquals("Confirm arg of -b", "toast", cl.getOptionValue("b"));
    }

    public void testPropertyOptionFlatten() throws Exception
    {
        Options props = new Options();
        props.addOption(OptionBuilder.withValueSeparator('=')
                                      .hasArgs()
                                      .create('D'));

        String[] args = new String[] { "-Dproperty=value" };

        CommandLine cl = new GnuParser().parse(props, args);

        String[] values = cl.getOptionValues('D');
        assertEquals("property", values[0]);
        assertEquals("value", values[1]);
    }

    public void testUnrecognizedOption() throws Exception
    {
        String[] args = new String[] { "-a", "-z" };

        try
        {
            parser.parse(options, args);
            fail("UnrecognizedOptionException not caught");
        }
        catch (UnrecognizedOptionException e)
        {
            // expected
        }
    }

    public void testStopAtNonOption() throws Exception
    {
        String[] args = new String[] { "-c", "-z", "-b", "toast" };

        CommandLine cl = parser.parse(options, args, true);

        assertTrue("Confirm -c is set", cl.hasOption("c"));
        assertFalse("Confirm -b is not set", cl.hasOption("b"));
        assertEquals("Confirm 3 extra args", 3, cl.getArgList().size());
        assertEquals("-z", cl.getArgList().get(0));
        assertEquals("-b", cl.getArgList().get(1));
        assertEquals("toast", cl.getArgList().get(2));
    }

    public void testMissingArgument() throws Exception
    {
        String[] args = new String[] { "-b" };

        try
        {
            parser.parse(options, args);
            fail("MissingArgumentException not caught");
        }
        catch (MissingArgumentException e)
        {
            // expected
        }
    }

    public void testMissingRequiredOption() throws Exception
    {
        Option required = new Option("r", "required", false, "a required option");
        required.setRequired(true);

        Options requiredOptions = new Options();
        requiredOptions.addOption(required);

        try
        {
            new GnuParser().parse(requiredOptions, new String[0]);
            fail("MissingOptionException not caught");
        }
        catch (MissingOptionException e)
        {
            // expected
        }
    }

    public void testEmptyArguments() throws Exception
    {
        CommandLine cl = parser.parse(options, new String[0]);

        assertFalse(cl.hasOption("a"));
        assertFalse(cl.hasOption("b"));
        assertFalse(cl.hasOption("c"));
        assertEquals(0, cl.getArgList().size());
    }

    public void testNullArguments() throws Exception
    {
        CommandLine cl = parser.parse(options, null);

        assertFalse(cl.hasOption("a"));
        assertEquals(0, cl.getArgList().size());
    }

    public void testWithProperties() throws Exception
    {
        Properties properties = new Properties();
        properties.setProperty("b", "propvalue");

        CommandLine cl = new GnuParser().parse(options, new String[0], properties);

        assertTrue("Confirm -b is set from properties", cl.hasOption("b"));
        assertEquals("propvalue", cl.getOptionValue("b"));
    }
}
