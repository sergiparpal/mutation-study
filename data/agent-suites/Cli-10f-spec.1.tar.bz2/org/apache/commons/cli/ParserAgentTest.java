package org.apache.commons.cli;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.Properties;

import junit.framework.TestCase;

/**
 * Self-contained tests for the abstract {@link Parser} class, based solely on
 * the documented contract in the generated javadoc (api/org/apache/commons/cli/Parser.html).
 */
public class ParserAgentTest extends TestCase
{
    /**
     * Minimal concrete subclass used only to instantiate the abstract Parser.
     * flatten() is documented only as "reducing the arguments that have been
     * passed to the parse method" and returning "a String array of the
     * flattened arguments" -- an identity pass-through is a valid, minimal
     * implementation of that contract, and keeps the tests focused on the
     * behavior implemented by Parser itself rather than on flattening rules.
     */
    private static class IdentityParser extends Parser
    {
        protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption)
        {
            if (arguments == null)
            {
                return new String[0];
            }
            String[] copy = new String[arguments.length];
            System.arraycopy(arguments, 0, copy, 0, arguments.length);
            return copy;
        }
    }

    private Parser newParser()
    {
        return new IdentityParser();
    }

    private Option requiredFlag(String opt)
    {
        Option option = new Option(opt, false, "required option " + opt);
        option.setRequired(true);
        return option;
    }

    // -- parse(Options, String[]) -------------------------------------------------

    public void testParseReturnsNonNullCommandLine() throws Exception
    {
        Parser parser = newParser();
        CommandLine cl = parser.parse(new Options(), new String[0]);
        assertNotNull(cl);
    }

    public void testParseSimpleFlagOptionRecognized() throws Exception
    {
        Parser parser = newParser();
        Options options = new Options();
        options.addOption(new Option("a", false, "flag a"));

        CommandLine cl = parser.parse(options, new String[] {"-a"});

        assertTrue(cl.hasOption("a"));
    }

    public void testParseOptionWithArgumentValue() throws Exception
    {
        Parser parser = newParser();
        Options options = new Options();
        options.addOption(new Option("b", true, "value option"));

        CommandLine cl = parser.parse(options, new String[] {"-b", "hello"});

        assertTrue(cl.hasOption("b"));
        assertEquals("hello", cl.getOptionValue("b"));
    }

    public void testParseNoArgsResultsInEmptyArgsList() throws Exception
    {
        Parser parser = newParser();
        CommandLine cl = parser.parse(new Options(), new String[0]);
        assertEquals(0, cl.getArgs().length);
    }

    public void testParsePlainArgumentsCollectedInOrder() throws Exception
    {
        Parser parser = newParser();
        Options options = new Options();

        CommandLine cl = parser.parse(options, new String[] {"foo", "bar"});

        String[] remaining = cl.getArgs();
        assertEquals(2, remaining.length);
        assertEquals("foo", remaining[0]);
        assertEquals("bar", remaining[1]);
    }

    public void testParseUnrecognizedOptionThrowsParseException()
    {
        Parser parser = newParser();
        Options options = new Options();

        try
        {
            parser.parse(options, new String[] {"-x"});
            fail("Expected ParseException for an option not present in Options");
        }
        catch (ParseException expected)
        {
            // per javadoc: parse() throws ParseException if an error occurs
        }
    }

    public void testParseMissingRequiredOptionThrowsParseException()
    {
        Parser parser = newParser();
        Options options = new Options();
        options.addOption(requiredFlag("r"));

        try
        {
            parser.parse(options, new String[0]);
            fail("Expected ParseException because a required option was not supplied");
        }
        catch (ParseException expected)
        {
            // checkRequiredOptions() throws MissingOptionException, a kind of
            // ParseException, when a required option is not present
        }
    }

    public void testParseRequiredOptionPresentSucceeds() throws Exception
    {
        Parser parser = newParser();
        Options options = new Options();
        options.addOption(requiredFlag("r"));

        CommandLine cl = parser.parse(options, new String[] {"-r"});

        assertNotNull(cl);
        assertTrue(cl.hasOption("r"));
    }

    public void testParseReusableAcrossCallsWithDifferentOptions() throws Exception
    {
        Parser parser = newParser();

        Options first = new Options();
        first.addOption(requiredFlag("r"));
        parser.parse(first, new String[] {"-r"});

        // A later call with different Options (no required option at all)
        // must not be affected by state left over from the previous call.
        Options second = new Options();
        second.addOption(new Option("z", false, "flag z"));

        CommandLine cl = parser.parse(second, new String[] {"-z"});

        assertTrue(cl.hasOption("z"));
    }

    // -- parse(Options, String[], boolean stopAtNonOption) -------------------------

    public void testParseStopAtNonOptionCollectsRemainderAsArgs() throws Exception
    {
        Parser parser = newParser();
        Options options = new Options();
        options.addOption(new Option("a", false, "flag a"));

        // Per javadoc: stopAtNonOption "specifies whether to stop interpreting
        // the arguments when a non option has been encountered and to add
        // them to the CommandLines args list."
        CommandLine cl = parser.parse(options, new String[] {"positional", "-a"}, true);

        String[] remaining = cl.getArgs();
        assertEquals(2, remaining.length);
        assertEquals("positional", remaining[0]);
        assertEquals("-a", remaining[1]);
        assertFalse(cl.hasOption("a"));
    }

    public void testParseStopAtNonOptionWithAllPlainArguments() throws Exception
    {
        Parser parser = newParser();
        Options options = new Options();

        CommandLine cl = parser.parse(options, new String[] {"a", "b", "c"}, true);

        String[] remaining = cl.getArgs();
        assertEquals(3, remaining.length);
        assertEquals("a", remaining[0]);
        assertEquals("b", remaining[1]);
        assertEquals("c", remaining[2]);
    }

    public void testParseWithoutStopAtNonOptionStillParsesOptionsAfterArg() throws Exception
    {
        Parser parser = newParser();
        Options options = new Options();
        options.addOption(new Option("a", false, "flag a"));

        CommandLine cl = parser.parse(options, new String[] {"positional", "-a"}, false);

        assertTrue(cl.hasOption("a"));
        String[] remaining = cl.getArgs();
        assertEquals(1, remaining.length);
        assertEquals("positional", remaining[0]);
    }

    // -- parse(Options, String[], Properties) ---------------------------------------

    public void testParseWithPropertiesSuppliesDefaultFlagOption() throws Exception
    {
        Parser parser = newParser();
        Options options = new Options();
        options.addOption(new Option("v", false, "verbose"));

        Properties props = new Properties();
        props.setProperty("v", "true");

        CommandLine cl = parser.parse(options, new String[0], props);

        assertNotNull(cl);
        assertTrue(cl.hasOption("v"));
    }

    public void testParseWithPropertiesSuppliesDefaultOptionValue() throws Exception
    {
        Parser parser = newParser();
        Options options = new Options();
        options.addOption(new Option("f", true, "file"));

        Properties props = new Properties();
        props.setProperty("f", "out.txt");

        CommandLine cl = parser.parse(options, new String[0], props);

        assertNotNull(cl);
        assertEquals("out.txt", cl.getOptionValue("f"));
    }

    public void testParseArgumentsTakePrecedenceOverProperties() throws Exception
    {
        Parser parser = newParser();
        Options options = new Options();
        options.addOption(new Option("f", true, "file"));

        Properties props = new Properties();
        props.setProperty("f", "fromProperties.txt");

        CommandLine cl = parser.parse(options, new String[] {"-f", "fromArgs.txt"}, props);

        assertEquals("fromArgs.txt", cl.getOptionValue("f"));
    }

    // -- parse(Options, String[], Properties, boolean stopAtNonOption) --------------

    public void testParseWithPropertiesAndStopAtNonOption() throws Exception
    {
        Parser parser = newParser();
        Options options = new Options();
        options.addOption(new Option("v", false, "verbose"));

        Properties props = new Properties();
        props.setProperty("v", "true");

        CommandLine cl = parser.parse(options, new String[] {"pos"}, props, true);

        assertNotNull(cl);
        assertTrue(cl.hasOption("v"));
        String[] remaining = cl.getArgs();
        assertEquals(1, remaining.length);
        assertEquals("pos", remaining[0]);
    }

    // -- Parser instance is a CommandLineParser --------------------------------------

    public void testParserImplementsCommandLineParser()
    {
        Parser parser = newParser();
        assertTrue(parser instanceof CommandLineParser);
    }

    // -- cmd field --------------------------------------------------------------------

    public void testCmdFieldHoldsTheReturnedCommandLine() throws Exception
    {
        Parser parser = newParser();
        Options options = new Options();

        CommandLine cl = parser.parse(options, new String[0]);

        assertSame(cl, parser.cmd);
    }

    // -- setOptions / getOptions --------------------------------------------------------

    public void testSetOptionsAndGetOptionsRoundTrip()
    {
        Parser parser = newParser();
        Options options = new Options();

        parser.setOptions(options);

        assertSame(options, parser.getOptions());
    }

    // -- getRequiredOptions -------------------------------------------------------------

    public void testGetRequiredOptionsEmptyWhenNoneRequired()
    {
        Parser parser = newParser();
        Options options = new Options();
        options.addOption(new Option("a", false, "flag a"));

        parser.setOptions(options);
        List required = parser.getRequiredOptions();

        assertNotNull(required);
        assertEquals(0, required.size());
    }

    public void testGetRequiredOptionsReflectsRequiredOption()
    {
        Parser parser = newParser();
        Options options = new Options();
        options.addOption(requiredFlag("r"));

        parser.setOptions(options);
        List required = parser.getRequiredOptions();

        assertNotNull(required);
        assertEquals(1, required.size());
    }

    // -- checkRequiredOptions -----------------------------------------------------------

    public void testCheckRequiredOptionsThrowsWhenMissing()
    {
        Parser parser = newParser();
        Options options = new Options();
        options.addOption(requiredFlag("r"));
        parser.setOptions(options);

        try
        {
            parser.checkRequiredOptions();
            fail("Expected MissingOptionException because the required option was never satisfied");
        }
        catch (MissingOptionException expected)
        {
            // per javadoc: thrown "if any of the required Options are not present"
        }
    }

    public void testCheckRequiredOptionsPassesWhenNoneRequired() throws Exception
    {
        Parser parser = newParser();
        Options options = new Options();
        options.addOption(new Option("a", false, "flag a"));
        parser.setOptions(options);

        parser.checkRequiredOptions();
        // no exception expected
    }

    // -- processArgs ----------------------------------------------------------------------

    public void testProcessArgsConsumesValueFromIterator() throws Exception
    {
        Parser parser = newParser();
        Options options = new Options();
        Option opt = new Option("f", true, "file");
        options.addOption(opt);
        parser.setOptions(options);

        List values = new ArrayList();
        values.add("out.txt");
        ListIterator iter = values.listIterator();

        parser.processArgs(opt, iter);

        assertEquals("out.txt", opt.getValue());
    }

    public void testProcessArgsThrowsWhenNoValueAvailable()
    {
        Parser parser = newParser();
        Options options = new Options();
        Option opt = new Option("f", true, "file");
        options.addOption(opt);
        parser.setOptions(options);

        List values = new ArrayList();
        ListIterator iter = values.listIterator();

        try
        {
            parser.processArgs(opt, iter);
            fail("Expected ParseException: an argument value is required but none is available");
        }
        catch (ParseException expected)
        {
            // per javadoc: thrown "if an argument value is required and it is has not been found"
        }
    }

    // -- processOption --------------------------------------------------------------------

    public void testProcessOptionThrowsForUnknownOption()
    {
        Parser parser = newParser();
        Options options = new Options();
        parser.setOptions(options);

        List values = new ArrayList();
        ListIterator iter = values.listIterator();

        try
        {
            parser.processOption("-x", iter);
            fail("Expected ParseException because -x does not represent a known Option");
        }
        catch (ParseException expected)
        {
            // per javadoc: thrown "if arg does not represent an Option"
        }
    }
}
