package org.apache.commons.lang.text;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.text.ChoiceFormat;
import java.text.Format;
import java.text.MessageFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * Self-contained tests for {@link org.apache.commons.lang.text.ExtendedMessageFormat}.
 *
 * <p>Every expectation below is taken from the published Javadoc contract:</p>
 * <ul>
 *   <li>{@code ExtendedMessageFormat} <em>extends</em> {@link java.text.MessageFormat},
 *       so - when no matching {@code FormatFactory} is registered - it must behave
 *       exactly like {@code java.text.MessageFormat} (format elements of the shape
 *       <code>{argument-number(,format-name(,format-style)?)?}</code>, quoting rules,
 *       {@code choice} sub-formats, etc.).</li>
 *   <li>All four constructors are documented to throw
 *       {@link IllegalArgumentException} "in case of a bad pattern".</li>
 *   <li>{@code applyPattern(String)} "Apply the specified pattern" and
 *       {@code toPattern()} overrides {@code MessageFormat.toPattern()} - i.e. it must
 *       yield a pattern that reproduces the same formatting.</li>
 *   <li>The four sub-format mutators
 *       ({@code setFormat}, {@code setFormatByArgumentIndex}, {@code setFormats},
 *       {@code setFormatsByArgumentIndex}) are "disabled and will throw
 *       {@link UnsupportedOperationException} if called".</li>
 * </ul>
 */
public class ExtendedMessageFormatAgentTest {

    /** Default locale is pinned so locale-sensitive expectations are deterministic. */
    private Locale savedDefault;

    @Before
    public void pinDefaultLocale() {
        savedDefault = Locale.getDefault();
        Locale.setDefault(Locale.US);
    }

    @After
    public void restoreDefaultLocale() {
        Locale.setDefault(savedDefault);
    }

    private static Object[] args(Object... a) {
        return a;
    }

    /** Build with a pattern, round-trip it through toPattern(), assert identical formatting. */
    private static void assertToPatternRoundTrips(String pattern, Object[] formatArgs) {
        ExtendedMessageFormat original = new ExtendedMessageFormat(pattern, Locale.US);
        String reconstructed = original.toPattern();
        assertNotNull("toPattern() must not return null", reconstructed);
        ExtendedMessageFormat rebuilt = new ExtendedMessageFormat(reconstructed, Locale.US);
        assertEquals("pattern <" + pattern + "> must survive a toPattern() round-trip",
                original.format(formatArgs), rebuilt.format(formatArgs));
    }

    // ------------------------------------------------------------------
    // Type / inheritance
    // ------------------------------------------------------------------

    @Test
    public void isASubclassOfMessageFormat() {
        assertTrue(new ExtendedMessageFormat("plain") instanceof MessageFormat);
    }

    // ------------------------------------------------------------------
    // Constructors + basic formatting (no registry => plain MessageFormat behaviour)
    // ------------------------------------------------------------------

    @Test
    public void patternOnlyConstructorFormatsLikeMessageFormat() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello {0}!");
        assertEquals("Hello World!", emf.format(args("World")));
    }

    @Test
    public void patternAndLocaleConstructorRemembersLocale() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", Locale.GERMANY);
        assertEquals(Locale.GERMANY, emf.getLocale());
    }

    @Test
    public void patternAndLocaleConstructorUsesThatLocaleForNumbers() {
        // German groups with '.', US groups with ',': proves the locale is really used.
        ExtendedMessageFormat de = new ExtendedMessageFormat("{0,number}", Locale.GERMANY);
        ExtendedMessageFormat us = new ExtendedMessageFormat("{0,number}", Locale.US);
        assertEquals("1.234", de.format(args(Integer.valueOf(1234))));
        assertEquals("1,234", us.format(args(Integer.valueOf(1234))));
    }

    @Test
    public void patternAndRegistryConstructorFormatsAndUsesDefaultLocale() {
        Map<String, Object> registry = new HashMap<String, Object>();
        ExtendedMessageFormat emf = new ExtendedMessageFormat("<{0}>", registry);
        assertEquals("<x>", emf.format(args("x")));
        assertEquals(Locale.US, emf.getLocale());
    }

    @Test
    public void patternLocaleRegistryConstructorFormatsAndRemembersLocale() {
        Map<String, Object> registry = new HashMap<String, Object>();
        ExtendedMessageFormat emf =
                new ExtendedMessageFormat("{0,number,integer}", Locale.US, registry);
        assertEquals("42", emf.format(args(Integer.valueOf(42))));
        assertEquals(Locale.US, emf.getLocale());
    }

    @Test
    public void defaultLocaleConstructorUsesTheJvmDefaultLocale() {
        // Default locale is pinned to US in @Before.
        assertEquals(Locale.US, new ExtendedMessageFormat("{0}").getLocale());
    }

    @Test
    public void unknownFormatNameFallsBackToBuiltInMessageFormatFormats() {
        // "number"/"percent" is not in the (empty) registry, so the base
        // java.text.MessageFormat "percent" format style must still be honoured.
        ExtendedMessageFormat emf = new ExtendedMessageFormat(
                "{0,number,percent}", Locale.US, new HashMap<String, Object>());
        assertEquals("100%", emf.format(args(Integer.valueOf(1))));
    }

    // ------------------------------------------------------------------
    // Quoting / sub-format behaviour inherited from MessageFormat
    // ------------------------------------------------------------------

    @Test
    public void escapedApostropheIsEmittedAsASingleApostrophe() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("It''s {0}", Locale.US);
        assertEquals("It's here", emf.format(args("here")));
    }

    @Test
    public void quotedBracesAreTreatedAsLiteralText() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("'{'0'}'", Locale.US);
        assertEquals("{0}", emf.format(args("ignored")));
    }

    @Test
    public void choiceSubFormatSelectsByThreshold() {
        ExtendedMessageFormat emf =
                new ExtendedMessageFormat("{0,choice,0#zero|1#one|2#many}", Locale.US);
        assertEquals("zero", emf.format(args(Integer.valueOf(0))));
        assertEquals("one", emf.format(args(Integer.valueOf(1))));
        assertEquals("many", emf.format(args(Integer.valueOf(2))));
        assertEquals("many", emf.format(args(Integer.valueOf(9))));
    }

    @Test
    public void multipleArgumentsAreSubstitutedByIndex() {
        ExtendedMessageFormat emf =
                new ExtendedMessageFormat("{2}{1}{0}", Locale.US);
        assertEquals("cba", emf.format(args("a", "b", "c")));
    }

    @Test
    public void missingTrailingArgumentIsEchoedAsAPlaceholder() {
        // Documented java.text.MessageFormat behaviour: an argument that is not
        // supplied is rendered back as "{n}".
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0} {1}", Locale.US);
        assertEquals("x {1}", emf.format(args("x")));
    }

    @Test(expected = IllegalArgumentException.class)
    public void numberFormatElementRejectsNonNumericArgument() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number}", Locale.US);
        emf.format(args("not-a-number"));
    }

    // ------------------------------------------------------------------
    // toPattern()
    // ------------------------------------------------------------------

    @Test
    public void toPatternEchoesPlainText() {
        assertEquals("Hello there", new ExtendedMessageFormat("Hello there").toPattern());
    }

    @Test
    public void toPatternEchoesASimpleArgumentPattern() {
        assertEquals("{0}-{1}", new ExtendedMessageFormat("{0}-{1}").toPattern());
    }

    @Test
    public void toPatternIsStableAcrossRepeatedCalls() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number,integer}");
        String once = emf.toPattern();
        assertNotNull(once);
        assertEquals(once, emf.toPattern());
    }

    @Test
    public void toPatternRoundTripsPlainText() {
        assertToPatternRoundTrips("Hello there", args());
    }

    @Test
    public void toPatternRoundTripsSingleArgument() {
        assertToPatternRoundTrips("value = {0}", args("V"));
    }

    @Test
    public void toPatternRoundTripsTwoArguments() {
        assertToPatternRoundTrips("{0} / {1}", args("a", "b"));
    }

    @Test
    public void toPatternRoundTripsNumberFormatElement() {
        assertToPatternRoundTrips("{0,number,integer}", args(Integer.valueOf(7)));
    }

    @Test
    public void toPatternRoundTripsEscapedApostrophe() {
        assertToPatternRoundTrips("It''s {0}", args("mine"));
    }

    // ------------------------------------------------------------------
    // applyPattern()
    // ------------------------------------------------------------------

    @Test
    public void applyPatternReplacesBothPatternAndFormatting() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("old {0}", Locale.US);
        emf.applyPattern("new {0} and {1}");
        assertEquals("new {0} and {1}", emf.toPattern());
        assertEquals("new a and b", emf.format(args("a", "b")));
    }

    @Test(expected = IllegalArgumentException.class)
    public void applyPatternRejectsAnUnterminatedFormatElement() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("ok", Locale.US);
        emf.applyPattern("broken {0");
    }

    // ------------------------------------------------------------------
    // Bad patterns rejected by the constructors
    // ------------------------------------------------------------------

    @Test(expected = IllegalArgumentException.class)
    public void constructorRejectsLoneOpeningBrace() {
        new ExtendedMessageFormat("{");
    }

    @Test(expected = IllegalArgumentException.class)
    public void constructorWithLocaleRejectsUnterminatedFormatElement() {
        new ExtendedMessageFormat("value {0", Locale.US);
    }

    @Test(expected = IllegalArgumentException.class)
    public void constructorWithRegistryRejectsUnterminatedFormatElement() {
        new ExtendedMessageFormat("{0", new HashMap<String, Object>());
    }

    @Test(expected = IllegalArgumentException.class)
    public void constructorWithLocaleAndRegistryRejectsUnterminatedFormatElement() {
        new ExtendedMessageFormat(
                "{0,number,integer", Locale.US, new HashMap<String, Object>());
    }

    // ------------------------------------------------------------------
    // Disabled sub-format mutators
    // ------------------------------------------------------------------

    @Test(expected = UnsupportedOperationException.class)
    public void setFormatIsDisabled() {
        ExtendedMessageFormat emf =
                new ExtendedMessageFormat("{0,number,integer}", Locale.US);
        emf.setFormat(0, NumberFormat.getIntegerInstance(Locale.US));
    }

    @Test(expected = UnsupportedOperationException.class)
    public void setFormatByArgumentIndexIsDisabled() {
        ExtendedMessageFormat emf =
                new ExtendedMessageFormat("{0,number,integer}", Locale.US);
        emf.setFormatByArgumentIndex(0, NumberFormat.getIntegerInstance(Locale.US));
    }

    @Test(expected = UnsupportedOperationException.class)
    public void setFormatsIsDisabled() {
        ExtendedMessageFormat emf =
                new ExtendedMessageFormat("{0,number,integer}", Locale.US);
        emf.setFormats(new Format[] { NumberFormat.getIntegerInstance(Locale.US) });
    }

    @Test(expected = UnsupportedOperationException.class)
    public void setFormatsByArgumentIndexIsDisabled() {
        ExtendedMessageFormat emf =
                new ExtendedMessageFormat("{0,number,integer}", Locale.US);
        emf.setFormatsByArgumentIndex(
                new Format[] { NumberFormat.getIntegerInstance(Locale.US) });
    }

    @Test(expected = UnsupportedOperationException.class)
    public void setFormatIsDisabledEvenForAnOutOfRangeIndex() {
        // The methods are unconditionally disabled per the Javadoc.
        ExtendedMessageFormat emf = new ExtendedMessageFormat("no elements", Locale.US);
        emf.setFormat(0, NumberFormat.getIntegerInstance(Locale.US));
    }

    // ------------------------------------------------------------------
    // Inherited read accessors still work through the ExtendedMessageFormat parser
    // ------------------------------------------------------------------

    @Test
    public void getFormatsReturnsOneFormatPerElementInPatternOrder() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat(
                "{0,number,integer} : {1,choice,0#no|1#yes}", Locale.US);
        Format[] formats = emf.getFormats();
        assertEquals(2, formats.length);
        assertTrue("first element should be a NumberFormat",
                formats[0] instanceof NumberFormat);
        assertTrue("second element should be a ChoiceFormat",
                formats[1] instanceof ChoiceFormat);
    }

    @Test
    public void parseRecoversTheArgumentValues() throws ParseException {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("[{0}]", Locale.US);
        Object[] parsed = emf.parse("[hello]");
        assertEquals(1, parsed.length);
        assertEquals("hello", parsed[0]);
    }

    @Test
    public void cloneProducesAnEquivalentFormat() {
        ExtendedMessageFormat emf =
                new ExtendedMessageFormat("{0,number,integer} and {1}", Locale.US);
        ExtendedMessageFormat copy = (ExtendedMessageFormat) emf.clone();
        assertEquals(emf.toPattern(), copy.toPattern());
        Object[] a = args(Integer.valueOf(5), "tail");
        assertEquals(emf.format(a), copy.format(a));
    }

    // ------------------------------------------------------------------
    // Equality (inherited from MessageFormat)
    // ------------------------------------------------------------------

    @Test
    public void formatsBuiltFromTheSamePatternAndLocaleAreEqual() {
        ExtendedMessageFormat a = new ExtendedMessageFormat("{0} {1}", Locale.US);
        ExtendedMessageFormat b = new ExtendedMessageFormat("{0} {1}", Locale.US);
        assertEquals(a, b);
    }

    @Test
    public void formatsBuiltFromDifferentPatternsAreNotEqual() {
        ExtendedMessageFormat a = new ExtendedMessageFormat("{0} {1}", Locale.US);
        ExtendedMessageFormat c = new ExtendedMessageFormat("{0}-{1}", Locale.US);
        assertFalse(a.equals(c));
    }
}
