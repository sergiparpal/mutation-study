/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.DateFormatSymbols;
import java.text.FieldPosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.Test;

/**
 * Unit tests {@link org.apache.commons.lang3.time.FastDatePrinter}.
 *
 * @version $Id$
 */
public class FastDatePrinterAgentTest {

    private static final TimeZone GMT = TimeZone.getTimeZone("GMT");
    private static final TimeZone NEW_YORK = TimeZone.getTimeZone("America/New_York");
    private static final TimeZone INDIA = TimeZone.getTimeZone("Asia/Kolkata");

    /** 2003-01-10 (a Friday) 15:33:20.989 GMT. */
    private static final Calendar REFERENCE = calendar(GMT, 2003, Calendar.JANUARY, 10, 15, 33, 20, 989);

    private static Calendar calendar(TimeZone zone, int year, int month, int day,
                                     int hour, int minute, int second, int millisecond) {
        Calendar c = new GregorianCalendar(zone, Locale.US);
        c.clear();
        c.set(year, month, day, hour, minute, second);
        c.set(Calendar.MILLISECOND, millisecond);
        return c;
    }

    private static FastDatePrinter printer(String pattern) {
        return new FastDatePrinter(pattern, GMT, Locale.US);
    }

    private static String format(String pattern, Calendar calendar) {
        return new FastDatePrinter(pattern, calendar.getTimeZone(), Locale.US).format(calendar);
    }

    //-----------------------------------------------------------------------
    // Accessors
    //-----------------------------------------------------------------------
    @Test
    public void testAccessors() {
        FastDatePrinter p = new FastDatePrinter("yyyy-MM-dd", NEW_YORK, Locale.GERMANY);
        assertEquals("yyyy-MM-dd", p.getPattern());
        assertSame(NEW_YORK, p.getTimeZone());
        assertSame(Locale.GERMANY, p.getLocale());
    }

    @Test
    public void testGetMaxLengthEstimate() {
        assertEquals(0, printer("").getMaxLengthEstimate());
        // PaddedNumberField always estimates 4
        assertEquals(4, printer("yyyy").getMaxLengthEstimate());
        // TwoDigitYearField estimates 2
        assertEquals(2, printer("yy").getMaxLengthEstimate());
        // 4 (yyyy) + 1 ('-') + 2 (MM) + 1 ('-') + 2 (dd)
        assertEquals(10, printer("yyyy-MM-dd").getMaxLengthEstimate());
        // the whole quoted run collapses into a single string literal
        assertEquals(7, printer("'literal'").getMaxLengthEstimate());
        // TimeZoneNumberRule estimates 5
        assertEquals(5, printer("Z").getMaxLengthEstimate());
        // TextField estimates the longest value it can emit
        assertEquals("Wednesday".length(), printer("EEEE").getMaxLengthEstimate());
    }

    @Test
    public void testMaxLengthEstimateIsAnUpperBoundForTypicalPatterns() {
        String[] patterns = { "yyyy-MM-dd HH:mm:ss.SSS", "EEEE, MMMM d, yyyy h:mm a z", "dd/MM/yy", "'literal'" };
        for (String pattern : patterns) {
            FastDatePrinter p = new FastDatePrinter(pattern, NEW_YORK, Locale.US);
            String formatted = p.format(REFERENCE.getTime());
            assertTrue(pattern + " produced " + formatted.length() + " chars but estimated "
                    + p.getMaxLengthEstimate(), formatted.length() <= p.getMaxLengthEstimate());
        }
    }

    //-----------------------------------------------------------------------
    // Construction / pattern parsing errors
    //-----------------------------------------------------------------------
    @Test
    public void testNullPatternThrowsNullPointerException() {
        try {
            new FastDatePrinter(null, GMT, Locale.US);
            fail("Expected NullPointerException for a null pattern");
        } catch (NullPointerException ex) {
            // expected
        }
    }

    @Test
    public void testNullLocaleThrowsNullPointerException() {
        try {
            new FastDatePrinter("yyyy", GMT, null);
            fail("Expected NullPointerException for a null locale");
        } catch (NullPointerException ex) {
            // expected
        }
    }

    @Test
    public void testNullTimeZoneThrowsNullPointerExceptionForZonePattern() {
        try {
            new FastDatePrinter("z", null, Locale.US);
            fail("Expected NullPointerException for a null time zone");
        } catch (NullPointerException ex) {
            // expected
        }
    }

    @Test
    public void testIllegalPatternComponent() {
        for (String pattern : new String[] { "b", "Q", "yyyy-QQ", "n" }) {
            try {
                printer(pattern);
                fail("Expected IllegalArgumentException for pattern " + pattern);
            } catch (IllegalArgumentException ex) {
                assertTrue("Unexpected message: " + ex.getMessage(),
                        ex.getMessage().startsWith("Illegal pattern component: "));
            }
        }
    }

    @Test
    public void testEmptyPattern() {
        FastDatePrinter p = printer("");
        assertEquals("", p.getPattern());
        assertEquals("", p.format(REFERENCE));
        assertEquals("", p.format(REFERENCE.getTime()));
        assertEquals(0, p.getMaxLengthEstimate());
    }

    //-----------------------------------------------------------------------
    // Individual pattern letters
    //-----------------------------------------------------------------------
    @Test
    public void testYearFields() {
        assertEquals("2003", format("yyyy", REFERENCE));
        assertEquals("03", format("yy", REFERENCE));
        // Java 7 behaviour: anything but exactly two letters is a plain, 4-padded number
        assertEquals("2003", format("y", REFERENCE));
        assertEquals("2003", format("yyy", REFERENCE));
        assertEquals("02003", format("yyyyy", REFERENCE));

        Calendar early = calendar(GMT, 5, Calendar.MARCH, 2, 1, 2, 3, 4);
        assertEquals("0005", format("yyyy", early));
        assertEquals("05", format("yy", early));
        assertEquals("000005", format("yyyyyy", early));

        Calendar y2k = calendar(GMT, 2000, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals("00", format("yy", y2k));
        Calendar y1999 = calendar(GMT, 1999, Calendar.DECEMBER, 31, 23, 59, 59, 999);
        assertEquals("99", format("yy", y1999));
    }

    @Test
    public void testMonthFields() {
        assertEquals("1", format("M", REFERENCE));
        assertEquals("01", format("MM", REFERENCE));
        assertEquals("Jan", format("MMM", REFERENCE));
        assertEquals("January", format("MMMM", REFERENCE));

        Calendar december = calendar(GMT, 2003, Calendar.DECEMBER, 1, 0, 0, 0, 0);
        assertEquals("12", format("M", december));
        assertEquals("12", format("MM", december));
        assertEquals("Dec", format("MMM", december));
        assertEquals("December", format("MMMM", december));
    }

    @Test
    public void testDayAndWeekFields() {
        assertEquals("10", format("d", REFERENCE));
        assertEquals("10", format("dd", REFERENCE));
        assertEquals("010", format("ddd", REFERENCE));
        assertEquals("10", format("D", REFERENCE));
        assertEquals("010", format("DDD", REFERENCE));
        assertEquals("Fri", format("E", REFERENCE));
        assertEquals("Fri", format("EEE", REFERENCE));
        assertEquals("Friday", format("EEEE", REFERENCE));
        // the 10th of January 2003 is the second Friday of the month
        assertEquals("2", format("F", REFERENCE));
        assertEquals("2", format("w", REFERENCE));
        assertEquals("2", format("W", REFERENCE));

        Calendar firstOfMonth = calendar(GMT, 2003, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals("1", format("d", firstOfMonth));
        assertEquals("01", format("dd", firstOfMonth));
        assertEquals("Wed", format("E", firstOfMonth));
        assertEquals("1", format("D", firstOfMonth));
    }

    @Test
    public void testHourFields() {
        // 15:33 -> afternoon
        assertEquals("15", format("H", REFERENCE));
        assertEquals("15", format("HH", REFERENCE));
        assertEquals("3", format("h", REFERENCE));
        assertEquals("03", format("hh", REFERENCE));
        assertEquals("15", format("k", REFERENCE));
        assertEquals("3", format("K", REFERENCE));
        assertEquals("PM", format("a", REFERENCE));
    }

    @Test
    public void testHourFieldsAtMidnight() {
        Calendar midnight = calendar(GMT, 2003, Calendar.JANUARY, 10, 0, 0, 0, 0);
        assertEquals("0", format("H", midnight));
        assertEquals("00", format("HH", midnight));
        // 'h' is 1..12, so midnight prints as 12
        assertEquals("12", format("h", midnight));
        assertEquals("12", format("hh", midnight));
        // 'k' is 1..24, so midnight prints as 24
        assertEquals("24", format("k", midnight));
        // 'K' is 0..11, so midnight prints as 0
        assertEquals("0", format("K", midnight));
        assertEquals("AM", format("a", midnight));
    }

    @Test
    public void testHourFieldsAtNoon() {
        Calendar noon = calendar(GMT, 2003, Calendar.JANUARY, 10, 12, 0, 0, 0);
        assertEquals("12", format("H", noon));
        assertEquals("12", format("h", noon));
        assertEquals("12", format("k", noon));
        assertEquals("0", format("K", noon));
        assertEquals("PM", format("a", noon));
    }

    @Test
    public void testMinuteSecondAndMillisecondFields() {
        assertEquals("33", format("m", REFERENCE));
        assertEquals("33", format("mm", REFERENCE));
        assertEquals("20", format("s", REFERENCE));
        assertEquals("20", format("ss", REFERENCE));
        assertEquals("989", format("S", REFERENCE));
        assertEquals("989", format("SSS", REFERENCE));

        Calendar small = calendar(GMT, 2003, Calendar.JANUARY, 10, 1, 2, 3, 7);
        assertEquals("2", format("m", small));
        assertEquals("02", format("mm", small));
        assertEquals("3", format("s", small));
        assertEquals("03", format("ss", small));
        assertEquals("7", format("S", small));
        assertEquals("07", format("SS", small));
        assertEquals("007", format("SSS", small));
        assertEquals("00007", format("SSSSS", small));
    }

    @Test
    public void testEraField() {
        assertEquals("AD", format("G", REFERENCE));

        Calendar bc = calendar(GMT, 45, Calendar.MARCH, 15, 12, 0, 0, 0);
        bc.set(Calendar.ERA, GregorianCalendar.BC);
        assertEquals("BC", format("G", bc));
        assertEquals("0045", format("yyyy", bc));
    }

    //-----------------------------------------------------------------------
    // Literals
    //-----------------------------------------------------------------------
    @Test
    public void testLiterals() {
        assertEquals("2003-01-10 15:33:20.989", format("yyyy-MM-dd HH:mm:ss.SSS", REFERENCE));
        assertEquals("Today is Friday", format("'Today is 'EEEE", REFERENCE));
        // a doubled quote is an escaped single quote
        assertEquals("'2003'", format("''yyyy''", REFERENCE));
        assertEquals("MM 01", format("'MM 'MM", REFERENCE));
        // an unterminated literal simply runs to the end of the pattern
        assertEquals("unterminated", format("'unterminated", REFERENCE));
        // non-letters outside of quotes are copied verbatim
        assertEquals("[10/01/2003]", format("'['dd/MM/yyyy']'", REFERENCE));
        assertEquals("#01#", format("#MM#", REFERENCE));
    }

    //-----------------------------------------------------------------------
    // Time zones
    //-----------------------------------------------------------------------
    @Test
    public void testTimeZoneNames() {
        Date winter = REFERENCE.getTime();
        Date summer = calendar(GMT, 2003, Calendar.JULY, 10, 15, 33, 20, 0).getTime();

        FastDatePrinter shortName = new FastDatePrinter("z", NEW_YORK, Locale.US);
        FastDatePrinter longName = new FastDatePrinter("zzzz", NEW_YORK, Locale.US);

        assertEquals("EST", shortName.format(winter));
        assertEquals("EDT", shortName.format(summer));
        assertEquals("Eastern Standard Time", longName.format(winter));
        assertEquals("Eastern Daylight Time", longName.format(summer));

        assertEquals("GMT", new FastDatePrinter("z", GMT, Locale.US).format(winter));
        assertEquals("Greenwich Mean Time", new FastDatePrinter("zzzz", GMT, Locale.US).format(winter));
    }

    @Test
    public void testTimeZoneNumbers() {
        Date winter = REFERENCE.getTime();
        Date summer = calendar(GMT, 2003, Calendar.JULY, 10, 15, 33, 20, 0).getTime();

        assertEquals("+0000", new FastDatePrinter("Z", GMT, Locale.US).format(winter));
        assertEquals("+00:00", new FastDatePrinter("ZZ", GMT, Locale.US).format(winter));

        assertEquals("-0500", new FastDatePrinter("Z", NEW_YORK, Locale.US).format(winter));
        assertEquals("-05:00", new FastDatePrinter("ZZ", NEW_YORK, Locale.US).format(winter));
        // daylight saving is folded into the offset
        assertEquals("-0400", new FastDatePrinter("Z", NEW_YORK, Locale.US).format(summer));
        assertEquals("-04:00", new FastDatePrinter("ZZ", NEW_YORK, Locale.US).format(summer));

        // a zone with a non-zero minute offset
        assertEquals("+0530", new FastDatePrinter("Z", INDIA, Locale.US).format(winter));
        assertEquals("+05:30", new FastDatePrinter("ZZ", INDIA, Locale.US).format(winter));
    }

    @Test
    public void testFormatDateUsesThePrintersTimeZone() {
        Date date = REFERENCE.getTime();
        String pattern = "yyyy-MM-dd HH:mm:ss z";

        assertEquals("2003-01-10 15:33:20 GMT", new FastDatePrinter(pattern, GMT, Locale.US).format(date));
        assertEquals("2003-01-10 10:33:20 EST", new FastDatePrinter(pattern, NEW_YORK, Locale.US).format(date));
        assertEquals("2003-01-10 21:03:20 IST", new FastDatePrinter(pattern, INDIA, Locale.US).format(date));
    }

    @Test
    public void testFormatCalendarUsesTheCalendarsTimeZone() {
        // the same instant, but held in a calendar that carries its own zone
        Calendar newYork = new GregorianCalendar(NEW_YORK, Locale.US);
        newYork.setTimeInMillis(REFERENCE.getTimeInMillis());

        // the printer is on GMT, but the calendar's zone wins
        FastDatePrinter p = new FastDatePrinter("yyyy-MM-dd HH:mm:ss z", GMT, Locale.US);
        assertEquals("2003-01-10 10:33:20 EST", p.format(newYork));
        assertEquals("2003-01-10 10:33:20 EST", p.format(newYork, new StringBuffer()).toString());
        // ...while a Date is still printed in the printer's own zone
        assertEquals("2003-01-10 15:33:20 GMT", p.format(newYork.getTime()));
    }

    @Test
    public void testFormatCalendarUsesTheCalendarsDaylightSavingName() {
        Calendar summerInNewYork = new GregorianCalendar(NEW_YORK, Locale.US);
        summerInNewYork.setTimeInMillis(calendar(GMT, 2003, Calendar.JULY, 10, 15, 33, 20, 0).getTimeInMillis());

        FastDatePrinter p = new FastDatePrinter("zzzz Z", GMT, Locale.US);
        assertEquals("Eastern Daylight Time -0400", p.format(summerInNewYork));
    }

    //-----------------------------------------------------------------------
    // Locales
    //-----------------------------------------------------------------------
    @Test
    public void testLocaleSensitiveText() {
        DateFormatSymbols german = new DateFormatSymbols(Locale.GERMANY);
        FastDatePrinter p = new FastDatePrinter("MMMM EEEE", NEW_YORK, Locale.GERMANY);
        String expected = german.getMonths()[Calendar.JANUARY] + " " + german.getWeekdays()[Calendar.FRIDAY];
        assertEquals(expected, p.format(REFERENCE.getTime()));

        // and it really differs from the English rendering
        String english = new FastDatePrinter("MMMM EEEE", NEW_YORK, Locale.US).format(REFERENCE.getTime());
        assertEquals("January Friday", english);
        assertFalse(expected.equals(english));
    }

    //-----------------------------------------------------------------------
    // The format(...) overloads
    //-----------------------------------------------------------------------
    @Test
    public void testFormatOverloadsAgree() {
        FastDatePrinter p = printer("yyyy-MM-dd HH:mm:ss.SSS");
        Date date = REFERENCE.getTime();
        long millis = REFERENCE.getTimeInMillis();
        String expected = "2003-01-10 15:33:20.989";

        assertEquals(expected, p.format(date));
        assertEquals(expected, p.format(millis));
        assertEquals(expected, p.format(REFERENCE));
        assertEquals(expected, p.format(date, new StringBuffer()).toString());
        assertEquals(expected, p.format(millis, new StringBuffer()).toString());
        assertEquals(expected, p.format(REFERENCE, new StringBuffer()).toString());
        assertEquals(expected, p.format((Object) date, new StringBuffer(), new FieldPosition(0)).toString());
        assertEquals(expected, p.format((Object) Long.valueOf(millis), new StringBuffer(), new FieldPosition(0)).toString());
        assertEquals(expected, p.format((Object) REFERENCE, new StringBuffer(), new FieldPosition(0)).toString());
    }

    @Test
    public void testFormatAppendsToTheSuppliedBuffer() {
        FastDatePrinter p = printer("yyyy");
        Date date = REFERENCE.getTime();

        StringBuffer buf = new StringBuffer("year=");
        assertSame(buf, p.format(date, buf));
        assertEquals("year=2003", buf.toString());

        assertSame(buf, p.format(REFERENCE.getTimeInMillis(), buf));
        assertEquals("year=20032003", buf.toString());

        assertSame(buf, p.format(REFERENCE, buf));
        assertEquals("year=200320032003", buf.toString());

        assertSame(buf, p.format((Object) date, buf, new FieldPosition(0)));
        assertEquals("year=2003200320032003", buf.toString());
    }

    @Test
    public void testFormatObjectRejectsUnsupportedTypes() {
        FastDatePrinter p = printer("yyyy");
        StringBuffer buf = new StringBuffer();

        try {
            p.format("a string", buf, new FieldPosition(0));
            fail("Expected IllegalArgumentException for a String");
        } catch (IllegalArgumentException ex) {
            assertEquals("Unknown class: java.lang.String", ex.getMessage());
        }

        try {
            p.format(Integer.valueOf(0), buf, new FieldPosition(0));
            fail("Expected IllegalArgumentException for an Integer");
        } catch (IllegalArgumentException ex) {
            assertEquals("Unknown class: java.lang.Integer", ex.getMessage());
        }

        try {
            p.format(null, buf, new FieldPosition(0));
            fail("Expected IllegalArgumentException for null");
        } catch (IllegalArgumentException ex) {
            assertEquals("Unknown class: <null>", ex.getMessage());
        }

        assertEquals("the buffer must be left untouched", 0, buf.length());
    }

    @Test
    public void testFormatEpochAndNegativeMillis() {
        FastDatePrinter p = printer("yyyy-MM-dd HH:mm:ss.SSS");
        assertEquals("1970-01-01 00:00:00.000", p.format(0L));
        assertEquals("1969-12-31 23:59:59.999", p.format(-1L));
        assertEquals("1969-12-31 23:59:59.999", p.format(new Date(-1L)));
    }

    @Test
    public void testFormatNullDateThrowsNullPointerException() {
        FastDatePrinter p = printer("yyyy");
        try {
            p.format((Date) null);
            fail("Expected NullPointerException for a null Date");
        } catch (NullPointerException ex) {
            // expected
        }
        try {
            p.format((Calendar) null);
            fail("Expected NullPointerException for a null Calendar");
        } catch (NullPointerException ex) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // Agreement with SimpleDateFormat
    //-----------------------------------------------------------------------
    @Test
    public void testMatchesSimpleDateFormat() {
        String[] patterns = { "yyyy-MM-dd'T'HH:mm:ss.SSS", "EEEE, MMMM d, yyyy", "h:mm:ss a", "D w W F k K G", "Z" };
        long[] instants = {
                REFERENCE.getTimeInMillis(),
                0L,
                calendar(GMT, 2003, Calendar.JULY, 10, 15, 33, 20, 0).getTimeInMillis(),
                // straddles the US daylight saving change of 2003
                calendar(GMT, 2003, Calendar.APRIL, 6, 6, 59, 59, 0).getTimeInMillis(),
                calendar(GMT, 2003, Calendar.APRIL, 6, 7, 0, 0, 0).getTimeInMillis(),
        };
        for (String pattern : patterns) {
            for (TimeZone zone : new TimeZone[] { GMT, NEW_YORK, INDIA }) {
                SimpleDateFormat sdf = new SimpleDateFormat(pattern, Locale.US);
                sdf.setTimeZone(zone);
                FastDatePrinter fdp = new FastDatePrinter(pattern, zone, Locale.US);
                for (long instant : instants) {
                    Date date = new Date(instant);
                    assertEquals(pattern + " @ " + zone.getID() + " for " + instant,
                            sdf.format(date), fdp.format(date));
                }
            }
        }
    }

    //-----------------------------------------------------------------------
    // equals / hashCode / toString
    //-----------------------------------------------------------------------
    @Test
    public void testEqualsAndHashCode() {
        FastDatePrinter base = new FastDatePrinter("yyyy-MM-dd", NEW_YORK, Locale.US);
        FastDatePrinter same = new FastDatePrinter("yyyy-MM-dd", NEW_YORK, Locale.US);
        FastDatePrinter otherPattern = new FastDatePrinter("yyyy-MM-dd HH", NEW_YORK, Locale.US);
        FastDatePrinter otherZone = new FastDatePrinter("yyyy-MM-dd", GMT, Locale.US);
        FastDatePrinter otherLocale = new FastDatePrinter("yyyy-MM-dd", NEW_YORK, Locale.GERMANY);

        assertTrue(base.equals(base));
        assertTrue(base.equals(same));
        assertTrue(same.equals(base));
        assertEquals(base.hashCode(), same.hashCode());

        assertFalse(base.equals(otherPattern));
        assertFalse(base.equals(otherZone));
        assertFalse(base.equals(otherLocale));
        assertFalse(base.equals("yyyy-MM-dd"));
        assertFalse(base.equals(null));
    }

    @Test
    public void testToString() {
        assertEquals("FastDatePrinter[yyyy-MM-dd,en_US,America/New_York]",
                new FastDatePrinter("yyyy-MM-dd", NEW_YORK, Locale.US).toString());
        assertEquals("FastDatePrinter[,en_US,GMT]",
                new FastDatePrinter("", GMT, Locale.US).toString());
    }

    //-----------------------------------------------------------------------
    // Serialization and thread safety
    //-----------------------------------------------------------------------
    @Test
    public void testSerializationRestoresTheParsedRules() throws Exception {
        FastDatePrinter original = new FastDatePrinter("yyyy-MM-dd HH:mm:ss z", NEW_YORK, Locale.US);

        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        ObjectOutputStream out = new ObjectOutputStream(bytes);
        out.writeObject(original);
        out.close();

        ObjectInputStream in = new ObjectInputStream(new ByteArrayInputStream(bytes.toByteArray()));
        FastDatePrinter restored = (FastDatePrinter) in.readObject();
        in.close();

        assertEquals(original, restored);
        assertEquals(original.getPattern(), restored.getPattern());
        assertEquals(original.getTimeZone(), restored.getTimeZone());
        assertEquals(original.getLocale(), restored.getLocale());
        assertEquals(original.getMaxLengthEstimate(), restored.getMaxLengthEstimate());
        // the rules are transient, so this only works if they were rebuilt
        assertEquals("2003-01-10 10:33:20 EST", restored.format(REFERENCE.getTime()));
        assertEquals(original.format(REFERENCE.getTime()), restored.format(REFERENCE.getTime()));
    }

    @Test
    public void testConcurrentFormattingIsConsistent() throws InterruptedException {
        final FastDatePrinter p = new FastDatePrinter("yyyy-MM-dd HH:mm:ss.SSS z", NEW_YORK, Locale.US);
        final Date date = REFERENCE.getTime();
        final String expected = "2003-01-10 10:33:20.989 EST";
        assertEquals(expected, p.format(date));

        final StringBuffer failures = new StringBuffer();
        Thread[] threads = new Thread[4];
        for (int i = 0; i < threads.length; i++) {
            threads[i] = new Thread(new Runnable() {
                @Override
                public void run() {
                    for (int j = 0; j < 500; j++) {
                        String actual = p.format(date);
                        if (!expected.equals(actual)) {
                            synchronized (failures) {
                                failures.append(actual).append('\n');
                            }
                        }
                    }
                }
            });
        }
        for (Thread thread : threads) {
            thread.start();
        }
        for (Thread thread : threads) {
            thread.join();
        }
        assertEquals("unexpected renderings: " + failures, 0, failures.length());
    }
}
