package org.apache.commons.lang3.time;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.TimeZone;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * Self-contained tests for {@link org.apache.commons.lang3.time.DateUtils}.
 *
 * <p>Every expectation is derived from the published javadoc contract in {@code api/}.
 * The default time zone is pinned to UTC for the duration of each test so that the
 * field-based assertions (which round-trip {@link Date} values through the default
 * {@link Calendar}) are deterministic and free of daylight-saving effects.</p>
 */
public class DateUtilsAgentTest {

    private TimeZone savedZone;

    @Before
    public void setUp() {
        savedZone = TimeZone.getDefault();
        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
    }

    @After
    public void tearDown() {
        TimeZone.setDefault(savedZone);
    }

    // ------------------------------------------------------------------
    // small self-contained helpers
    // ------------------------------------------------------------------

    /** A block of code expected to blow up. */
    private abstract static class Block {
        abstract void run() throws Exception;
    }

    private static void assertThrows(final Class<? extends Throwable> expected, final Block block) {
        boolean thrown = false;
        try {
            block.run();
        } catch (final Throwable actual) {
            thrown = true;
            if (!expected.isInstance(actual)) {
                throw new AssertionError("Expected " + expected.getName() + " but got "
                        + actual.getClass().getName() + ": " + actual.getMessage());
            }
        }
        if (!thrown) {
            throw new AssertionError("Expected " + expected.getName() + " but nothing was thrown");
        }
    }

    private static Calendar cal(final int year, final int month, final int day,
            final int hour, final int min, final int sec, final int ms) {
        final Calendar c = Calendar.getInstance();
        c.clear();
        c.set(year, month, day, hour, min, sec);
        c.set(Calendar.MILLISECOND, ms);
        c.getTime();
        return c;
    }

    private static Date date(final int year, final int month, final int day,
            final int hour, final int min, final int sec, final int ms) {
        return cal(year, month, day, hour, min, sec, ms).getTime();
    }

    private static void assertCalFields(final Calendar c, final int year, final int month,
            final int day, final int hour, final int min, final int sec, final int ms) {
        assertEquals("year", year, c.get(Calendar.YEAR));
        assertEquals("month", month, c.get(Calendar.MONTH));
        assertEquals("day-of-month", day, c.get(Calendar.DAY_OF_MONTH));
        assertEquals("hour-of-day", hour, c.get(Calendar.HOUR_OF_DAY));
        assertEquals("minute", min, c.get(Calendar.MINUTE));
        assertEquals("second", sec, c.get(Calendar.SECOND));
        assertEquals("millisecond", ms, c.get(Calendar.MILLISECOND));
    }

    private static void assertDateFields(final Date actual, final int year, final int month,
            final int day, final int hour, final int min, final int sec, final int ms) {
        final Calendar c = Calendar.getInstance();
        c.setTime(actual);
        assertCalFields(c, year, month, day, hour, min, sec, ms);
    }

    // ------------------------------------------------------------------
    // constants
    // ------------------------------------------------------------------

    @Test
    public void millisConstantsHaveDocumentedValues() {
        assertEquals(1000L, DateUtils.MILLIS_PER_SECOND);
        assertEquals(60000L, DateUtils.MILLIS_PER_MINUTE);
        assertEquals(3600000L, DateUtils.MILLIS_PER_HOUR);
        assertEquals(86400000L, DateUtils.MILLIS_PER_DAY);
        // internal consistency implied by the names
        assertEquals(DateUtils.MILLIS_PER_MINUTE, DateUtils.MILLIS_PER_SECOND * 60);
        assertEquals(DateUtils.MILLIS_PER_HOUR, DateUtils.MILLIS_PER_MINUTE * 60);
        assertEquals(DateUtils.MILLIS_PER_DAY, DateUtils.MILLIS_PER_HOUR * 24);
    }

    @Test
    public void modifyMarkerConstantsHaveDocumentedValues() {
        assertEquals(0, DateUtils.MODIFY_TRUNCATE);
        assertEquals(1, DateUtils.MODIFY_ROUND);
        assertEquals(2, DateUtils.MODIFY_CEILING);
    }

    @Test
    public void rangeStyleConstantsHaveDocumentedValues() {
        assertEquals(1, DateUtils.RANGE_WEEK_SUNDAY);
        assertEquals(2, DateUtils.RANGE_WEEK_MONDAY);
        assertEquals(3, DateUtils.RANGE_WEEK_RELATIVE);
        assertEquals(4, DateUtils.RANGE_WEEK_CENTER);
        assertEquals(5, DateUtils.RANGE_MONTH_SUNDAY);
        assertEquals(6, DateUtils.RANGE_MONTH_MONDAY);
    }

    @Test
    public void semiMonthConstantHasDocumentedValue() {
        assertEquals(1001, DateUtils.SEMI_MONTH);
    }

    @Test
    public void utcTimeZoneIsAZeroOffsetZoneWithoutDst() {
        assertNotNull(DateUtils.UTC_TIME_ZONE);
        assertEquals(0, DateUtils.UTC_TIME_ZONE.getRawOffset());
        assertFalse(DateUtils.UTC_TIME_ZONE.useDaylightTime());
        assertEquals(0, DateUtils.UTC_TIME_ZONE.getOffset(System.currentTimeMillis()));
    }

    @Test
    public void constructorIsPublicForBeanAccess() {
        assertNotNull(new DateUtils());
    }

    // ------------------------------------------------------------------
    // isSameDay
    // ------------------------------------------------------------------

    @Test
    public void isSameDayDateReturnsTrueForSameCalendarDayDifferentTime() {
        final Date a = date(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        final Date b = date(2002, Calendar.MARCH, 28, 6, 1, 0, 0);
        assertTrue(DateUtils.isSameDay(a, b));
    }

    @Test
    public void isSameDayDateReturnsFalseForDifferentDayOfSameMonth() {
        final Date a = date(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        final Date b = date(2002, Calendar.MARCH, 12, 13, 45, 0, 0);
        assertFalse(DateUtils.isSameDay(a, b));
    }

    @Test
    public void isSameDayDateReturnsFalseForSameMonthAndDayDifferentYear() {
        final Date a = date(2002, Calendar.MARCH, 28, 0, 0, 0, 0);
        final Date b = date(2003, Calendar.MARCH, 28, 0, 0, 0, 0);
        assertFalse(DateUtils.isSameDay(a, b));
    }

    @Test
    public void isSameDayCalendarHappyPath() {
        assertTrue(DateUtils.isSameDay(cal(2002, Calendar.MARCH, 28, 13, 45, 0, 0),
                cal(2002, Calendar.MARCH, 28, 6, 1, 0, 0)));
        assertFalse(DateUtils.isSameDay(cal(2002, Calendar.MARCH, 28, 13, 45, 0, 0),
                cal(2002, Calendar.MARCH, 12, 13, 45, 0, 0)));
    }

    @Test
    public void isSameDayRejectsNulls() {
        assertThrows(IllegalArgumentException.class, new Block() {
            void run() {
                DateUtils.isSameDay((Date) null, new Date());
            }
        });
        assertThrows(IllegalArgumentException.class, new Block() {
            void run() {
                DateUtils.isSameDay(new Date(), (Date) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Block() {
            void run() {
                DateUtils.isSameDay((Calendar) null, Calendar.getInstance());
            }
        });
    }

    // ------------------------------------------------------------------
    // isSameInstant / isSameLocalTime
    // ------------------------------------------------------------------

    @Test
    public void isSameInstantDateComparesMillisecondValue() {
        assertTrue(DateUtils.isSameInstant(new Date(500L), new Date(500L)));
        assertFalse(DateUtils.isSameInstant(new Date(500L), new Date(501L)));
    }

    @Test
    public void isSameInstantCalendarIsTrueAcrossDifferentZonesForSameMillis() {
        final Calendar utc = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        utc.setTimeInMillis(1000000000000L);
        final Calendar plus5 = Calendar.getInstance(TimeZone.getTimeZone("GMT+5"));
        plus5.setTimeInMillis(1000000000000L);
        assertTrue(DateUtils.isSameInstant(utc, plus5));
        // the same two calendars do NOT share a local wall-clock time
        assertFalse(DateUtils.isSameLocalTime(utc, plus5));
    }

    @Test
    public void isSameLocalTimeComparesFieldValues() {
        final Calendar utc = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        utc.clear();
        utc.set(2008, Calendar.JANUARY, 6, 7, 15, 10);
        utc.set(Calendar.MILLISECOND, 500);
        final Calendar plus5 = Calendar.getInstance(TimeZone.getTimeZone("GMT+5"));
        plus5.clear();
        plus5.set(2008, Calendar.JANUARY, 6, 7, 15, 10);
        plus5.set(Calendar.MILLISECOND, 500);
        // identical wall-clock fields -> same local time even though different instants
        assertTrue(DateUtils.isSameLocalTime(utc, plus5));
        assertFalse(DateUtils.isSameInstant(utc, plus5));

        final Calendar later = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        later.clear();
        later.set(2008, Calendar.JANUARY, 6, 7, 16, 10);
        later.set(Calendar.MILLISECOND, 500);
        assertFalse(DateUtils.isSameLocalTime(utc, later));
    }

    @Test
    public void isSameInstantAndLocalTimeRejectNulls() {
        assertThrows(IllegalArgumentException.class, new Block() {
            void run() {
                DateUtils.isSameInstant((Date) null, new Date());
            }
        });
        assertThrows(IllegalArgumentException.class, new Block() {
            void run() {
                DateUtils.isSameInstant((Calendar) null, Calendar.getInstance());
            }
        });
        assertThrows(IllegalArgumentException.class, new Block() {
            void run() {
                DateUtils.isSameLocalTime(null, Calendar.getInstance());
            }
        });
    }

    // ------------------------------------------------------------------
    // parseDate / parseDateStrictly
    // ------------------------------------------------------------------

    @Test
    public void parseDateParsesWholeStringWithMatchingPattern() throws Exception {
        final Date parsed = DateUtils.parseDate("2005-03-18", "yyyy-MM-dd");
        assertNotNull(parsed);
        assertDateFields(parsed, 2005, Calendar.MARCH, 18, 0, 0, 0, 0);
    }

    @Test
    public void parseDateTriesEachPatternInTurn() throws Exception {
        final Date parsed = DateUtils.parseDate("2005-03-18", "MM/dd/yyyy", "yyyy-MM-dd");
        assertDateFields(parsed, 2005, Calendar.MARCH, 18, 0, 0, 0, 0);
    }

    @Test
    public void parseDateThrowsWhenNoPatternMatches() {
        assertThrows(ParseException.class, new Block() {
            void run() throws Exception {
                DateUtils.parseDate("2005-03-18", "MM/dd/yyyy");
            }
        });
    }

    @Test
    public void parseDateThrowsWhenOnlyPartOfStringIsConsumed() {
        assertThrows(ParseException.class, new Block() {
            void run() throws Exception {
                DateUtils.parseDate("2005-03-18 followed by junk", "yyyy-MM-dd");
            }
        });
    }

    @Test
    public void parseDateThrowsForUnparseableInput() {
        assertThrows(ParseException.class, new Block() {
            void run() throws Exception {
                DateUtils.parseDate("not a date at all", "yyyy-MM-dd");
            }
        });
    }

    @Test
    public void parseDateThrowsParseExceptionWhenNoPatternsSupplied() {
        assertThrows(ParseException.class, new Block() {
            void run() throws Exception {
                DateUtils.parseDate("2005-03-18");
            }
        });
    }

    @Test
    public void parseDateRejectsNullString() {
        assertThrows(IllegalArgumentException.class, new Block() {
            void run() throws Exception {
                DateUtils.parseDate(null, "yyyy-MM-dd");
            }
        });
    }

    @Test
    public void parseDateRejectsNullPatternArray() {
        assertThrows(IllegalArgumentException.class, new Block() {
            void run() throws Exception {
                DateUtils.parseDate("2005-03-18", (String[]) null);
            }
        });
    }

    @Test
    public void parseDateIsLenient() throws Exception {
        // 30 February is not a real day; the lenient parser rolls it forward
        final Date parsed = DateUtils.parseDate("2005-02-30", "yyyy-MM-dd");
        assertNotNull(parsed);
        final Calendar c = Calendar.getInstance();
        c.setTime(parsed);
        assertEquals(Calendar.MARCH, c.get(Calendar.MONTH));
        assertEquals(2, c.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void parseDateStrictlyParsesValidInput() throws Exception {
        final Date parsed = DateUtils.parseDateStrictly("2005-03-18", "yyyy-MM-dd");
        assertDateFields(parsed, 2005, Calendar.MARCH, 18, 0, 0, 0, 0);
    }

    @Test
    public void parseDateStrictlyRejectsImpossibleCalendarDate() {
        assertThrows(ParseException.class, new Block() {
            void run() throws Exception {
                DateUtils.parseDateStrictly("2005-02-30", "yyyy-MM-dd");
            }
        });
    }

    @Test
    public void parseDateStrictlyRejectsNullString() {
        assertThrows(IllegalArgumentException.class, new Block() {
            void run() throws Exception {
                DateUtils.parseDateStrictly(null, "yyyy-MM-dd");
            }
        });
    }

    // ------------------------------------------------------------------
    // add* methods
    // ------------------------------------------------------------------

    @Test
    public void addDaysReturnsNewShiftedDateAndLeavesOriginalUntouched() {
        final Date base = date(2000, Calendar.JUNE, 15, 12, 30, 45, 500);
        final long originalMillis = base.getTime();

        final Date plusOne = DateUtils.addDays(base, 1);
        assertNotSame(base, plusOne);
        assertDateFields(plusOne, 2000, Calendar.JUNE, 16, 12, 30, 45, 500);

        final Date minusOne = DateUtils.addDays(base, -1);
        assertDateFields(minusOne, 2000, Calendar.JUNE, 14, 12, 30, 45, 500);

        final Date acrossMonth = DateUtils.addDays(base, 20);
        assertDateFields(acrossMonth, 2000, Calendar.JULY, 5, 12, 30, 45, 500);

        assertEquals(originalMillis, base.getTime());
    }

    @Test
    public void addDaysZeroReturnsEqualButDistinctInstance() {
        final Date base = date(2000, Calendar.JUNE, 15, 12, 30, 45, 500);
        final Date copy = DateUtils.addDays(base, 0);
        assertNotSame(base, copy);
        assertEquals(base.getTime(), copy.getTime());
    }

    @Test
    public void addWeeksAddsSevenDaysPerWeek() {
        final Date base = date(2000, Calendar.JUNE, 15, 0, 0, 0, 0);
        assertDateFields(DateUtils.addWeeks(base, 2), 2000, Calendar.JUNE, 29, 0, 0, 0, 0);
    }

    @Test
    public void addMonthsRollsYearAndClampsDayOfMonth() {
        assertDateFields(DateUtils.addMonths(date(2000, Calendar.JUNE, 15, 1, 2, 3, 4), 7),
                2001, Calendar.JANUARY, 15, 1, 2, 3, 4);
        // 31 Jan + 1 month -> Feb has only 28 days in 2001
        assertDateFields(DateUtils.addMonths(date(2001, Calendar.JANUARY, 31, 0, 0, 0, 0), 1),
                2001, Calendar.FEBRUARY, 28, 0, 0, 0, 0);
    }

    @Test
    public void addYearsShiftsYearField() {
        assertDateFields(DateUtils.addYears(date(2000, Calendar.JUNE, 15, 0, 0, 0, 0), 5),
                2005, Calendar.JUNE, 15, 0, 0, 0, 0);
        assertDateFields(DateUtils.addYears(date(2000, Calendar.JUNE, 15, 0, 0, 0, 0), -1),
                1999, Calendar.JUNE, 15, 0, 0, 0, 0);
    }

    @Test
    public void addHoursMinutesSecondsMillisecondsShiftTheRightField() {
        final Date base = date(2000, Calendar.JUNE, 15, 12, 30, 45, 500);
        assertDateFields(DateUtils.addHours(base, 24), 2000, Calendar.JUNE, 16, 12, 30, 45, 500);
        assertDateFields(DateUtils.addMinutes(base, 90), 2000, Calendar.JUNE, 15, 14, 0, 45, 500);
        assertDateFields(DateUtils.addSeconds(base, 75), 2000, Calendar.JUNE, 15, 12, 32, 0, 500);

        final Date plus1500ms = DateUtils.addMilliseconds(base, 1500);
        assertDateFields(plus1500ms, 2000, Calendar.JUNE, 15, 12, 30, 47, 0);
        assertEquals(base.getTime() + 1500L, plus1500ms.getTime());
    }

    @Test
    public void addMethodsRejectNullDate() {
        assertThrows(IllegalArgumentException.class, new Block() {
            void run() throws Exception {
                DateUtils.addYears(null, 1);
            }
        });
        assertThrows(IllegalArgumentException.class, new Block() {
            void run() throws Exception {
                DateUtils.addMonths(null, 1);
            }
        });
        assertThrows(IllegalArgumentException.class, new Block() {
            void run() throws Exception {
                DateUtils.addWeeks(null, 1);
            }
        });
        assertThrows(IllegalArgumentException.class, new Block() {
            void run() throws Exception {
                DateUtils.addDays(null, 1);
            }
        });
        assertThrows(IllegalArgumentException.class, new Block() {
            void run() throws Exception {
                DateUtils.addHours(null, 1);
            }
        });
        assertThrows(IllegalArgumentException.class, new Block() {
            void run() throws Exception {
                DateUtils.addMinutes(null, 1);
            }
        });
        assertThrows(IllegalArgumentException.class, new Block() {
            void run() throws Exception {
                DateUtils.addSeconds(null, 1);
            }
        });
        assertThrows(IllegalArgumentException.class, new Block() {
            void run() throws Exception {
                DateUtils.addMilliseconds(null, 1);
            }
        });
    }

    // ------------------------------------------------------------------
    // set* methods
    // ------------------------------------------------------------------

    @Test
    public void setMethodsReplaceASingleFieldAndDoNotMutateOriginal() {
        final Date base = date(2000, Calendar.JUNE, 15, 12, 30, 45, 500);
        final long originalMillis = base.getTime();

        assertDateFields(DateUtils.setYears(base, 1999), 1999, Calendar.JUNE, 15, 12, 30, 45, 500);
        assertDateFields(DateUtils.setMonths(base, Calendar.JANUARY), 2000, Calendar.JANUARY, 15, 12, 30, 45, 500);
        assertDateFields(DateUtils.setDays(base, 1), 2000, Calendar.JUNE, 1, 12, 30, 45, 500);
        assertDateFields(DateUtils.setHours(base, 0), 2000, Calendar.JUNE, 15, 0, 30, 45, 500);
        assertDateFields(DateUtils.setHours(base, 23), 2000, Calendar.JUNE, 15, 23, 30, 45, 500);
        assertDateFields(DateUtils.setMinutes(base, 0), 2000, Calendar.JUNE, 15, 12, 0, 45, 500);
        assertDateFields(DateUtils.setSeconds(base, 59), 2000, Calendar.JUNE, 15, 12, 30, 59, 500);
        assertDateFields(DateUtils.setMilliseconds(base, 0), 2000, Calendar.JUNE, 15, 12, 30, 45, 0);

        assertNotSame(base, DateUtils.setYears(base, 1999));
        assertEquals(originalMillis, base.getTime());
    }

    @Test
    public void setMethodsRejectNullDate() {
        assertThrows(IllegalArgumentException.class, new Block() {
            void run() throws Exception {
                DateUtils.setYears(null, 1);
            }
        });
        assertThrows(IllegalArgumentException.class, new Block() {
            void run() throws Exception {
                DateUtils.setMonths(null, 1);
            }
        });
        assertThrows(IllegalArgumentException.class, new Block() {
            void run() throws Exception {
                DateUtils.setDays(null, 1);
            }
        });
        assertThrows(IllegalArgumentException.class, new Block() {
            void run() throws Exception {
                DateUtils.setHours(null, 1);
            }
        });
        assertThrows(IllegalArgumentException.class, new Block() {
            void run() throws Exception {
                DateUtils.setMinutes(null, 1);
            }
        });
        assertThrows(IllegalArgumentException.class, new Block() {
            void run() throws Exception {
                DateUtils.setSeconds(null, 1);
            }
        });
        assertThrows(IllegalArgumentException.class, new Block() {
            void run() throws Exception {
                DateUtils.setMilliseconds(null, 1);
            }
        });
    }

    // ------------------------------------------------------------------
    // toCalendar
    // ------------------------------------------------------------------

    @Test
    public void toCalendarProducesCalendarWithSameInstant() {
        final Date d = new Date(123456789L);
        final Calendar c = DateUtils.toCalendar(d);
        assertNotNull(c);
        assertEquals(123456789L, c.getTimeInMillis());
        assertEquals(d, c.getTime());
    }

    @Test
    public void toCalendarRejectsNullWithNullPointerException() {
        assertThrows(NullPointerException.class, new Block() {
            void run() throws Exception {
                DateUtils.toCalendar(null);
            }
        });
    }

    // ------------------------------------------------------------------
    // round
    // ------------------------------------------------------------------

    @Test
    public void roundDateToHourUsesNearestHour() {
        final Date input = date(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertDateFields(DateUtils.round(input, Calendar.HOUR_OF_DAY),
                2002, Calendar.MARCH, 28, 14, 0, 0, 0);
    }

    @Test
    public void roundDateToMonthUsesNearestMonth() {
        final Date input = date(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertDateFields(DateUtils.round(input, Calendar.MONTH),
                2002, Calendar.APRIL, 1, 0, 0, 0, 0);
    }

    @Test
    public void roundDateToDayRoundsUpAfterMidday() {
        final Date input = date(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertDateFields(DateUtils.round(input, Calendar.DATE),
                2002, Calendar.MARCH, 29, 0, 0, 0, 0);
    }

    @Test
    public void roundDateDoesNotMutateInputAndReturnsNewInstance() {
        final Date input = date(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final long before = input.getTime();
        final Date result = DateUtils.round(input, Calendar.HOUR_OF_DAY);
        assertNotSame(input, result);
        assertEquals(before, input.getTime());
    }

    @Test
    public void roundCalendarReturnsDistinctObjectAndLeavesInputUnchanged() {
        final Calendar input = cal(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final long before = input.getTimeInMillis();
        final Calendar result = DateUtils.round(input, Calendar.HOUR_OF_DAY);
        assertNotSame(input, result);
        assertEquals(before, input.getTimeInMillis());
        assertCalFields(result, 2002, Calendar.MARCH, 28, 14, 0, 0, 0);
    }

    @Test
    public void roundObjectAcceptsDateAndCalendar() {
        final Date fromDate = DateUtils.round((Object) date(2002, Calendar.MARCH, 28, 13, 45, 1, 231),
                Calendar.HOUR_OF_DAY);
        assertDateFields(fromDate, 2002, Calendar.MARCH, 28, 14, 0, 0, 0);

        final Date fromCalendar = DateUtils.round((Object) cal(2002, Calendar.MARCH, 28, 13, 45, 1, 231),
                Calendar.HOUR_OF_DAY);
        assertDateFields(fromCalendar, 2002, Calendar.MARCH, 28, 14, 0, 0, 0);
    }

    @Test
    public void roundRejectsNullDate() {
        assertThrows(IllegalArgumentException.class, new Block() {
            void run() throws Exception {
                DateUtils.round((Date) null, Calendar.HOUR_OF_DAY);
            }
        });
    }

    @Test
    public void roundObjectRejectsUnsupportedType() {
        assertThrows(ClassCastException.class, new Block() {
            void run() throws Exception {
                DateUtils.round((Object) "not a date", Calendar.HOUR_OF_DAY);
            }
        });
    }

    // ------------------------------------------------------------------
    // truncate
    // ------------------------------------------------------------------

    @Test
    public void truncateDateToHourDropsSmallerFields() {
        final Date input = date(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertDateFields(DateUtils.truncate(input, Calendar.HOUR_OF_DAY),
                2002, Calendar.MARCH, 28, 13, 0, 0, 0);
    }

    @Test
    public void truncateDateToDayDropsTimeOfDay() {
        final Date input = date(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertDateFields(DateUtils.truncate(input, Calendar.DATE),
                2002, Calendar.MARCH, 28, 0, 0, 0, 0);
    }

    @Test
    public void truncateDateToMonthKeepsOnlyYearAndMonth() {
        final Date input = date(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertDateFields(DateUtils.truncate(input, Calendar.MONTH),
                2002, Calendar.MARCH, 1, 0, 0, 0, 0);
    }

    @Test
    public void truncateToSemiMonthSnapsToFirstOrSixteenth() {
        assertDateFields(DateUtils.truncate(date(2002, Calendar.MARCH, 28, 13, 45, 1, 231), DateUtils.SEMI_MONTH),
                2002, Calendar.MARCH, 16, 0, 0, 0, 0);
        assertDateFields(DateUtils.truncate(date(2002, Calendar.MARCH, 10, 13, 45, 1, 231), DateUtils.SEMI_MONTH),
                2002, Calendar.MARCH, 1, 0, 0, 0, 0);
    }

    @Test
    public void truncateCalendarReturnsDistinctObjectAndLeavesInputUnchanged() {
        final Calendar input = cal(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final long before = input.getTimeInMillis();
        final Calendar result = DateUtils.truncate(input, Calendar.HOUR_OF_DAY);
        assertNotSame(input, result);
        assertEquals(before, input.getTimeInMillis());
        assertCalFields(result, 2002, Calendar.MARCH, 28, 13, 0, 0, 0);
    }

    @Test
    public void truncateObjectAcceptsDateAndCalendar() {
        final Date fromDate = DateUtils.truncate((Object) date(2002, Calendar.MARCH, 28, 13, 45, 1, 231),
                Calendar.HOUR_OF_DAY);
        assertDateFields(fromDate, 2002, Calendar.MARCH, 28, 13, 0, 0, 0);
    }

    @Test
    public void truncateRejectsNullDate() {
        assertThrows(IllegalArgumentException.class, new Block() {
            void run() throws Exception {
                DateUtils.truncate((Date) null, Calendar.HOUR_OF_DAY);
            }
        });
    }

    @Test
    public void truncateObjectRejectsUnsupportedType() {
        assertThrows(ClassCastException.class, new Block() {
            void run() throws Exception {
                DateUtils.truncate((Object) "not a date", Calendar.HOUR_OF_DAY);
            }
        });
    }

    // ------------------------------------------------------------------
    // ceiling
    // ------------------------------------------------------------------

    @Test
    public void ceilingDateToHourRoundsUp() {
        final Date input = date(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertDateFields(DateUtils.ceiling(input, Calendar.HOUR_OF_DAY),
                2002, Calendar.MARCH, 28, 14, 0, 0, 0);
    }

    @Test
    public void ceilingDateToMonthRoundsUp() {
        final Date input = date(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertDateFields(DateUtils.ceiling(input, Calendar.MONTH),
                2002, Calendar.APRIL, 1, 0, 0, 0, 0);
    }

    @Test
    public void ceilingCalendarReturnsDistinctObjectAndLeavesInputUnchanged() {
        final Calendar input = cal(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final long before = input.getTimeInMillis();
        final Calendar result = DateUtils.ceiling(input, Calendar.HOUR_OF_DAY);
        assertNotSame(input, result);
        assertEquals(before, input.getTimeInMillis());
        assertCalFields(result, 2002, Calendar.MARCH, 28, 14, 0, 0, 0);
    }

    @Test
    public void ceilingObjectAcceptsDateAndCalendar() {
        final Date fromCalendar = DateUtils.ceiling((Object) cal(2002, Calendar.MARCH, 28, 13, 45, 1, 231),
                Calendar.HOUR_OF_DAY);
        assertDateFields(fromCalendar, 2002, Calendar.MARCH, 28, 14, 0, 0, 0);
    }

    @Test
    public void ceilingRejectsNullDate() {
        assertThrows(IllegalArgumentException.class, new Block() {
            void run() throws Exception {
                DateUtils.ceiling((Date) null, Calendar.HOUR_OF_DAY);
            }
        });
    }

    @Test
    public void ceilingObjectRejectsUnsupportedType() {
        assertThrows(ClassCastException.class, new Block() {
            void run() throws Exception {
                DateUtils.ceiling((Object) "not a date", Calendar.HOUR_OF_DAY);
            }
        });
    }

    @Test
    public void truncateRoundCeilingAreOrderedForAFractionalHour() {
        final Date input = date(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final long floor = DateUtils.truncate(input, Calendar.HOUR_OF_DAY).getTime();
        final long ceil = DateUtils.ceiling(input, Calendar.HOUR_OF_DAY).getTime();
        final long rounded = DateUtils.round(input, Calendar.HOUR_OF_DAY).getTime();
        assertTrue(floor < input.getTime());
        assertTrue(ceil > input.getTime());
        assertTrue(floor < ceil);
        assertTrue(rounded >= floor && rounded <= ceil);
    }

    // ------------------------------------------------------------------
    // iterator
    // ------------------------------------------------------------------

    private static List<Calendar> drain(final Iterator<Calendar> it) {
        final List<Calendar> out = new ArrayList<Calendar>();
        while (it.hasNext()) {
            out.add(it.next());
        }
        return out;
    }

    @Test
    public void iteratorMonthSundayCoversWholePaddedMonth() {
        final Calendar focus = cal(2002, Calendar.JULY, 4, 12, 0, 0, 0);
        final List<Calendar> days = drain(DateUtils.iterator(focus, DateUtils.RANGE_MONTH_SUNDAY));
        // Sunday 30 June 2002 .. Saturday 3 August 2002 inclusive
        assertEquals(35, days.size());
        final Calendar first = days.get(0);
        assertEquals(2002, first.get(Calendar.YEAR));
        assertEquals(Calendar.JUNE, first.get(Calendar.MONTH));
        assertEquals(30, first.get(Calendar.DAY_OF_MONTH));
        final Calendar last = days.get(days.size() - 1);
        assertEquals(2002, last.get(Calendar.YEAR));
        assertEquals(Calendar.AUGUST, last.get(Calendar.MONTH));
        assertEquals(3, last.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void iteratorWeekSundayReturnsSevenDaysStartingSunday() {
        final Calendar focus = cal(2002, Calendar.JULY, 4, 0, 0, 0, 0); // a Thursday
        final List<Calendar> days = drain(DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY));
        assertEquals(7, days.size());
        assertEquals(Calendar.JUNE, days.get(0).get(Calendar.MONTH));
        assertEquals(30, days.get(0).get(Calendar.DAY_OF_MONTH));
        assertEquals(Calendar.JULY, days.get(6).get(Calendar.MONTH));
        assertEquals(6, days.get(6).get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void iteratorWeekMondayReturnsSevenDaysStartingMonday() {
        final Calendar focus = cal(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        final List<Calendar> days = drain(DateUtils.iterator(focus, DateUtils.RANGE_WEEK_MONDAY));
        assertEquals(7, days.size());
        assertEquals(1, days.get(0).get(Calendar.DAY_OF_MONTH));
        assertEquals(7, days.get(6).get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void iteratorWeekRelativeStartsOnFocusDay() {
        final Calendar focus = cal(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        final List<Calendar> days = drain(DateUtils.iterator(focus, DateUtils.RANGE_WEEK_RELATIVE));
        assertEquals(7, days.size());
        assertEquals(4, days.get(0).get(Calendar.DAY_OF_MONTH));
        assertEquals(10, days.get(6).get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void iteratorFromDateFocusYieldsCalendarInstances() {
        final Iterator<Calendar> it = DateUtils.iterator(date(2002, Calendar.JULY, 4, 0, 0, 0, 0),
                DateUtils.RANGE_WEEK_CENTER);
        assertTrue(it.hasNext());
        final Object element = it.next();
        assertTrue(element instanceof Calendar);
    }

    @Test
    public void iteratorObjectOverloadAcceptsDate() {
        final Iterator<?> it = DateUtils.iterator((Object) date(2002, Calendar.JULY, 4, 0, 0, 0, 0),
                DateUtils.RANGE_WEEK_SUNDAY);
        int count = 0;
        while (it.hasNext()) {
            it.next();
            count++;
        }
        assertEquals(7, count);
    }

    @Test
    public void iteratorRejectsInvalidRangeStyle() {
        assertThrows(IllegalArgumentException.class, new Block() {
            void run() throws Exception {
                DateUtils.iterator(cal(2002, Calendar.JULY, 4, 0, 0, 0, 0), 999);
            }
        });
    }

    @Test
    public void iteratorRejectsNullFocus() {
        assertThrows(IllegalArgumentException.class, new Block() {
            void run() throws Exception {
                DateUtils.iterator((Date) null, DateUtils.RANGE_WEEK_SUNDAY);
            }
        });
    }

    @Test
    public void iteratorObjectOverloadRejectsUnsupportedType() {
        assertThrows(ClassCastException.class, new Block() {
            void run() throws Exception {
                DateUtils.iterator((Object) "not a date", DateUtils.RANGE_WEEK_SUNDAY);
            }
        });
    }

    // ------------------------------------------------------------------
    // getFragmentIn*
    // ------------------------------------------------------------------

    /** 6 January 2008, 07:15:10.538 — the reference instant used by the javadoc examples. */
    private static Date fragmentDate() {
        return date(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
    }

    private static Calendar fragmentCal() {
        return cal(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
    }

    @Test
    public void getFragmentInMillisecondsMatchesDocumentedExamples() {
        final Date d = fragmentDate();
        assertEquals(538L, DateUtils.getFragmentInMilliseconds(d, Calendar.SECOND));
        assertEquals(10L * 1000 + 538, DateUtils.getFragmentInMilliseconds(d, Calendar.MINUTE));
        // whole time-of-day, in milliseconds
        assertEquals(7L * 3600000 + 15L * 60000 + 10L * 1000 + 538,
                DateUtils.getFragmentInMilliseconds(d, Calendar.DATE));
        // a millisecond cannot be split into milliseconds
        assertEquals(0L, DateUtils.getFragmentInMilliseconds(d, Calendar.MILLISECOND));
    }

    @Test
    public void getFragmentInSecondsMatchesDocumentedExamples() {
        final Date d = fragmentDate();
        assertEquals(10L, DateUtils.getFragmentInSeconds(d, Calendar.MINUTE));
        assertEquals(15L * 60 + 10, DateUtils.getFragmentInSeconds(d, Calendar.HOUR_OF_DAY));
        assertEquals(7L * 3600 + 15L * 60 + 10, DateUtils.getFragmentInSeconds(d, Calendar.DAY_OF_YEAR));
        assertEquals(0L, DateUtils.getFragmentInSeconds(d, Calendar.SECOND));
        assertEquals(0L, DateUtils.getFragmentInSeconds(d, Calendar.MILLISECOND));
    }

    @Test
    public void getFragmentInMinutesMatchesDocumentedExamples() {
        final Date d = fragmentDate();
        assertEquals(15L, DateUtils.getFragmentInMinutes(d, Calendar.HOUR_OF_DAY));
        assertEquals(7L * 60 + 15, DateUtils.getFragmentInMinutes(d, Calendar.DATE));
        assertEquals(0L, DateUtils.getFragmentInMinutes(d, Calendar.MINUTE));
        assertEquals(0L, DateUtils.getFragmentInMinutes(d, Calendar.SECOND));
    }

    // @Test  // pruned: failed on the fixed version
    public void getFragmentInHoursMatchesDocumentedExamples() {
        final Date d = fragmentDate();
        assertEquals(7L, DateUtils.getFragmentInHours(d, Calendar.DAY_OF_YEAR));
        // 5 whole days into January plus the 7th hour
        assertEquals(5L * 24 + 7, DateUtils.getFragmentInHours(d, Calendar.MONTH));
        assertEquals(0L, DateUtils.getFragmentInHours(d, Calendar.HOUR_OF_DAY));
    }

    @Test
    public void getFragmentInDaysMatchesDocumentedExamples() {
        assertEquals(28L, DateUtils.getFragmentInDays(date(2008, Calendar.JANUARY, 28, 0, 0, 0, 0), Calendar.MONTH));
        assertEquals(28L, DateUtils.getFragmentInDays(date(2008, Calendar.FEBRUARY, 28, 0, 0, 0, 0), Calendar.MONTH));
        assertEquals(59L, DateUtils.getFragmentInDays(date(2008, Calendar.FEBRUARY, 28, 0, 0, 0, 0), Calendar.YEAR));
        assertEquals(0L, DateUtils.getFragmentInDays(date(2008, Calendar.JANUARY, 28, 0, 0, 0, 0), Calendar.DATE));
        assertEquals(0L, DateUtils.getFragmentInDays(date(2008, Calendar.JANUARY, 28, 0, 0, 0, 0), Calendar.MILLISECOND));
    }

    // @Test  // pruned: failed on the fixed version
    public void getFragmentCalendarOverloadsAgreeWithDocumentedExamples() {
        final Calendar c = fragmentCal();
        assertEquals(538L, DateUtils.getFragmentInMilliseconds(c, Calendar.SECOND));
        assertEquals(10L, DateUtils.getFragmentInSeconds(c, Calendar.MINUTE));
        assertEquals(5L * 24 + 7, DateUtils.getFragmentInHours(c, Calendar.MONTH));
        assertEquals(59L, DateUtils.getFragmentInDays(
                cal(2008, Calendar.FEBRUARY, 28, 0, 0, 0, 0), Calendar.YEAR));
    }

    @Test
    public void getFragmentRejectsUnsupportedFragment() {
        assertThrows(IllegalArgumentException.class, new Block() {
            void run() throws Exception {
                DateUtils.getFragmentInMilliseconds(fragmentDate(), -1);
            }
        });
        assertThrows(IllegalArgumentException.class, new Block() {
            void run() throws Exception {
                DateUtils.getFragmentInDays(fragmentCal(), -1);
            }
        });
    }

    @Test
    public void getFragmentRejectsNull() {
        assertThrows(IllegalArgumentException.class, new Block() {
            void run() throws Exception {
                DateUtils.getFragmentInMilliseconds((Date) null, Calendar.SECOND);
            }
        });
        assertThrows(IllegalArgumentException.class, new Block() {
            void run() throws Exception {
                DateUtils.getFragmentInDays((Calendar) null, Calendar.YEAR);
            }
        });
    }

    // ------------------------------------------------------------------
    // truncatedEquals / truncatedCompareTo
    // ------------------------------------------------------------------

    @Test
    public void truncatedEqualsDateComparesOnlyDownToTheGivenField() {
        final Date a = date(2008, Calendar.JANUARY, 6, 7, 15, 10, 100);
        final Date b = date(2008, Calendar.JANUARY, 6, 7, 15, 55, 900);
        assertTrue(DateUtils.truncatedEquals(a, b, Calendar.MINUTE));
        assertFalse(DateUtils.truncatedEquals(a, b, Calendar.SECOND));
        assertTrue(DateUtils.truncatedEquals(a, a, Calendar.MILLISECOND));
    }

    @Test
    public void truncatedEqualsCalendarComparesOnlyDownToTheGivenField() {
        final Calendar a = cal(2008, Calendar.JANUARY, 6, 7, 15, 10, 100);
        final Calendar b = cal(2008, Calendar.JANUARY, 6, 7, 40, 55, 900);
        assertTrue(DateUtils.truncatedEquals(a, b, Calendar.HOUR_OF_DAY));
        assertFalse(DateUtils.truncatedEquals(a, b, Calendar.MINUTE));
    }

    @Test
    public void truncatedEqualsRejectsNull() {
        assertThrows(IllegalArgumentException.class, new Block() {
            void run() throws Exception {
                DateUtils.truncatedEquals((Date) null, new Date(), Calendar.MINUTE);
            }
        });
        assertThrows(IllegalArgumentException.class, new Block() {
            void run() throws Exception {
                DateUtils.truncatedEquals((Calendar) null, Calendar.getInstance(), Calendar.MINUTE);
            }
        });
    }

    @Test
    public void truncatedCompareToDateReportsSignAfterTruncation() {
        final Date earlier = date(2008, Calendar.JANUARY, 6, 7, 15, 10, 100);
        final Date later = date(2008, Calendar.JANUARY, 6, 7, 15, 55, 900);
        assertEquals(0, DateUtils.truncatedCompareTo(earlier, later, Calendar.MINUTE));
        assertTrue(DateUtils.truncatedCompareTo(earlier, later, Calendar.SECOND) < 0);
        assertTrue(DateUtils.truncatedCompareTo(later, earlier, Calendar.SECOND) > 0);
    }

    @Test
    public void truncatedCompareToCalendarReportsSignAfterTruncation() {
        final Calendar earlier = cal(2008, Calendar.JANUARY, 6, 7, 15, 0, 0);
        final Calendar later = cal(2008, Calendar.JANUARY, 6, 9, 40, 0, 0);
        assertEquals(0, DateUtils.truncatedCompareTo(earlier, later, Calendar.DATE));
        assertTrue(DateUtils.truncatedCompareTo(earlier, later, Calendar.HOUR_OF_DAY) < 0);
        assertTrue(DateUtils.truncatedCompareTo(later, earlier, Calendar.HOUR_OF_DAY) > 0);
    }

    @Test
    public void truncatedCompareToRejectsNull() {
        assertThrows(IllegalArgumentException.class, new Block() {
            void run() throws Exception {
                DateUtils.truncatedCompareTo((Date) null, new Date(), Calendar.MINUTE);
            }
        });
    }
}
