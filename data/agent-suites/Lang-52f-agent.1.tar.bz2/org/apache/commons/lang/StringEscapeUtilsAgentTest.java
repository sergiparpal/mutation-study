/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.lang.reflect.Constructor;
import java.lang.reflect.Modifier;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import org.apache.commons.lang.exception.NestableRuntimeException;

/**
 * Agent-authored unit tests for {@link org.apache.commons.lang.StringEscapeUtils}.
 *
 * <p>These tests exercise only the public API and assert on the concrete values
 * returned (or written to a <code>Writer</code>), including boundary and error
 * cases.  Expected values reflect the actual behaviour of the class in this
 * source tree -- for example that both <code>escapeJava</code> and
 * <code>escapeJavaScript</code> escape the forward slash.</p>
 *
 * <p>The source is deliberately ASCII-only: characters outside the ASCII range
 * are built with {@link #chr(int)} rather than written as literals, so that
 * compilation does not depend on the platform file encoding.</p>
 */
public class StringEscapeUtilsAgentTest extends TestCase {

    public StringEscapeUtilsAgentTest(String name) {
        super(name);
    }

    public static Test suite() {
        TestSuite suite = new TestSuite(StringEscapeUtilsAgentTest.class);
        suite.setName("StringEscapeUtils Agent Tests");
        return suite;
    }

    /** Builds a one-character String for the given code, keeping this file ASCII-only. */
    private static String chr(int code) {
        return String.valueOf((char) code);
    }

    // -----------------------------------------------------------------------
    // Constructor
    // -----------------------------------------------------------------------

    public void testConstructor() {
        assertNotNull(new StringEscapeUtils());
        Constructor[] cons = StringEscapeUtils.class.getDeclaredConstructors();
        assertEquals(1, cons.length);
        assertEquals(true, Modifier.isPublic(cons[0].getModifiers()));
        assertEquals(true, Modifier.isPublic(StringEscapeUtils.class.getModifiers()));
        assertEquals(false, Modifier.isFinal(StringEscapeUtils.class.getModifiers()));
    }

    // -----------------------------------------------------------------------
    // escapeJava(String)
    // -----------------------------------------------------------------------

    public void testEscapeJavaNull() {
        assertEquals(null, StringEscapeUtils.escapeJava(null));
    }

    public void testEscapeJavaEmpty() {
        assertEquals("", StringEscapeUtils.escapeJava(""));
    }

    public void testEscapeJavaNoSpecialCharacters() {
        assertEquals("abc ABC 123 -", StringEscapeUtils.escapeJava("abc ABC 123 -"));
    }

    public void testEscapeJavaControlCharacters() {
        assertEquals("\\t", StringEscapeUtils.escapeJava("\t"));
        assertEquals("\\n", StringEscapeUtils.escapeJava("\n"));
        assertEquals("\\r", StringEscapeUtils.escapeJava("\r"));
        assertEquals("\\f", StringEscapeUtils.escapeJava("\f"));
        assertEquals("\\b", StringEscapeUtils.escapeJava("\b"));
        assertEquals("a\\tb\\nc", StringEscapeUtils.escapeJava("a\tb\nc"));
    }

    public void testEscapeJavaQuotesBackslashAndSlash() {
        // double quote is escaped, single quote is NOT for plain Java
        assertEquals("\\\"", StringEscapeUtils.escapeJava("\""));
        assertEquals("'", StringEscapeUtils.escapeJava("'"));
        assertEquals("\\\\", StringEscapeUtils.escapeJava("\\"));
        // this version of the class escapes the forward slash for Java too
        assertEquals("\\/", StringEscapeUtils.escapeJava("/"));
        assertEquals("He didn't say, \\\"Stop!\\\"",
                StringEscapeUtils.escapeJava("He didn't say, \"Stop!\""));
    }

    public void testEscapeJavaUnicodeAndBoundaries() {
        assertEquals("\\u0001", StringEscapeUtils.escapeJava(chr(0x01)));
        // ch <= 0x0F is emitted as \\u000X, ch > 0x0F (still < 0x20) as \\u00XX
        assertEquals("\\u000F", StringEscapeUtils.escapeJava(chr(0x0F)));
        assertEquals("\\u0010", StringEscapeUtils.escapeJava(chr(0x10)));
        assertEquals("\\u001F", StringEscapeUtils.escapeJava(chr(0x1F)));
        // space (0x20) is the first character passed straight through
        assertEquals(" ", StringEscapeUtils.escapeJava(" "));
        // 0x7F sits on the boundary and is left untouched
        assertEquals(chr(0x7F), StringEscapeUtils.escapeJava(chr(0x7F)));
        // 0x80 and above become \\uXXXX with upper-case hex digits
        assertEquals("\\u0080", StringEscapeUtils.escapeJava(chr(0x80)));
        assertEquals("\\u00FF", StringEscapeUtils.escapeJava(chr(0xFF)));
        assertEquals("\\u0100", StringEscapeUtils.escapeJava(chr(0x100)));
        assertEquals("\\u0FFF", StringEscapeUtils.escapeJava(chr(0x0FFF)));
        assertEquals("\\u1000", StringEscapeUtils.escapeJava(chr(0x1000)));
        assertEquals("\\uCAFE", StringEscapeUtils.escapeJava(chr(0xCAFE)));
    }

    // -----------------------------------------------------------------------
    // escapeJava(Writer, String)
    // -----------------------------------------------------------------------

    public void testEscapeJavaWriterNullWriterThrows() {
        try {
            StringEscapeUtils.escapeJava((Writer) null, "data");
            fail("Expected IllegalArgumentException for a null Writer");
        } catch (IllegalArgumentException ex) {
            // expected
        } catch (IOException ex) {
            fail("Unexpected IOException: " + ex);
        }
    }

    public void testEscapeJavaWriterNullStringLeavesWriterEmpty() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.escapeJava(writer, null);
        assertEquals("", writer.toString());
    }

    public void testEscapeJavaWriterWritesEscapedValue() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.escapeJava(writer, "tab\there \"q\"");
        assertEquals("tab\\there \\\"q\\\"", writer.toString());
    }

    // -----------------------------------------------------------------------
    // escapeJavaScript(String)
    // -----------------------------------------------------------------------

    public void testEscapeJavaScriptNull() {
        assertEquals(null, StringEscapeUtils.escapeJavaScript(null));
    }

    public void testEscapeJavaScriptEmpty() {
        assertEquals("", StringEscapeUtils.escapeJavaScript(""));
    }

    public void testEscapeJavaScriptEscapesSingleQuote() {
        assertEquals("\\'", StringEscapeUtils.escapeJavaScript("'"));
        assertEquals("He didn\\'t say, \\\"Stop!\\\"",
                StringEscapeUtils.escapeJavaScript("He didn't say, \"Stop!\""));
    }

    public void testEscapeJavaScriptEscapesForwardSlash() {
        // the Lang-52 behaviour: </a> becomes <\/a>
        assertEquals("<\\/a>", StringEscapeUtils.escapeJavaScript("</a>"));
        assertEquals("\\\"quoted\\\" and \\/slash\\/",
                StringEscapeUtils.escapeJavaScript("\"quoted\" and /slash/"));
    }

    public void testEscapeJavaAndJavaScriptDifferOnlyOnSingleQuote() {
        String in = "a 'b' \"c\" \\ / \t";
        assertEquals("a 'b' \\\"c\\\" \\\\ \\/ \\t", StringEscapeUtils.escapeJava(in));
        assertEquals("a \\'b\\' \\\"c\\\" \\\\ \\/ \\t", StringEscapeUtils.escapeJavaScript(in));
    }

    public void testEscapeJavaScriptWriterNullWriterThrows() {
        try {
            StringEscapeUtils.escapeJavaScript((Writer) null, "data");
            fail("Expected IllegalArgumentException for a null Writer");
        } catch (IllegalArgumentException ex) {
            // expected
        } catch (IOException ex) {
            fail("Unexpected IOException: " + ex);
        }
    }

    public void testEscapeJavaScriptWriterWrites() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.escapeJavaScript(writer, "it's a '/'");
        assertEquals("it\\'s a \\'\\/\\'", writer.toString());
    }

    // -----------------------------------------------------------------------
    // unescapeJava(String)
    // -----------------------------------------------------------------------

    public void testUnescapeJavaNull() {
        assertEquals(null, StringEscapeUtils.unescapeJava(null));
    }

    public void testUnescapeJavaEmpty() {
        assertEquals("", StringEscapeUtils.unescapeJava(""));
    }

    public void testUnescapeJavaControlCharacters() {
        assertEquals("\t", StringEscapeUtils.unescapeJava("\\t"));
        assertEquals("\n", StringEscapeUtils.unescapeJava("\\n"));
        assertEquals("\r", StringEscapeUtils.unescapeJava("\\r"));
        assertEquals("\f", StringEscapeUtils.unescapeJava("\\f"));
        assertEquals("\b", StringEscapeUtils.unescapeJava("\\b"));
    }

    public void testUnescapeJavaQuotesBackslashAndSlash() {
        assertEquals("\"", StringEscapeUtils.unescapeJava("\\\""));
        assertEquals("'", StringEscapeUtils.unescapeJava("\\'"));
        assertEquals("\\", StringEscapeUtils.unescapeJava("\\\\"));
        assertEquals("/", StringEscapeUtils.unescapeJava("\\/"));
    }

    public void testUnescapeJavaUnicode() {
        assertEquals("A", StringEscapeUtils.unescapeJava("\\u0041"));
        assertEquals("Aa", StringEscapeUtils.unescapeJava("\\u0041\\u0061"));
        assertEquals("x A y", StringEscapeUtils.unescapeJava("x \\u0041 y"));
        assertEquals(chr(0xCAFE), StringEscapeUtils.unescapeJava("\\uCAFE"));
        // hex digits are case-insensitive
        assertEquals(chr(0xCAFE), StringEscapeUtils.unescapeJava("\\ucafe"));
        // a complete unicode escape followed by more text
        assertEquals(chr(0xABCD) + "!", StringEscapeUtils.unescapeJava("\\uABCD!"));
    }

    public void testUnescapeJavaUnrecognizedEscapeYieldsBareChar() {
        assertEquals("q", StringEscapeUtils.unescapeJava("\\q"));
        assertEquals(":", StringEscapeUtils.unescapeJava("\\:"));
        assertEquals("a1b", StringEscapeUtils.unescapeJava("a\\1b"));
    }

    public void testUnescapeJavaDanglingBackslashIsEmitted() {
        assertEquals("\\", StringEscapeUtils.unescapeJava("\\"));
        assertEquals("abc\\", StringEscapeUtils.unescapeJava("abc\\"));
    }

    public void testUnescapeJavaTruncatedUnicodeEscapeIsDropped() {
        // fewer than four hex digits before end-of-string: nothing is emitted
        assertEquals("", StringEscapeUtils.unescapeJava("\\u00"));
        assertEquals("x", StringEscapeUtils.unescapeJava("x\\u004"));
    }

    public void testUnescapeJavaInvalidUnicodeThrows() {
        try {
            StringEscapeUtils.unescapeJava("\\uXXXX");
            fail("Expected NestableRuntimeException for an invalid unicode value");
        } catch (NestableRuntimeException ex) {
            assertTrue("message was: " + ex.getMessage(),
                    ex.getMessage().indexOf("Unable to parse unicode value") >= 0);
        }

        try {
            StringEscapeUtils.unescapeJava("\\u12@4");
            fail("Expected NestableRuntimeException for an invalid unicode value");
        } catch (NestableRuntimeException ex) {
            assertTrue("message was: " + ex.getMessage(),
                    ex.getMessage().indexOf("Unable to parse unicode value") >= 0);
        }
    }

    // -----------------------------------------------------------------------
    // unescapeJava(Writer, String)
    // -----------------------------------------------------------------------

    public void testUnescapeJavaWriterNullWriterThrows() {
        try {
            StringEscapeUtils.unescapeJava((Writer) null, "data");
            fail("Expected IllegalArgumentException for a null Writer");
        } catch (IllegalArgumentException ex) {
            // expected
        } catch (IOException ex) {
            fail("Unexpected IOException: " + ex);
        }
    }

    public void testUnescapeJavaWriterNullStringLeavesWriterEmpty() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.unescapeJava(writer, null);
        assertEquals("", writer.toString());
    }

    public void testUnescapeJavaWriterWrites() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.unescapeJava(writer, "one\\ttwo\\u0021");
        assertEquals("one\ttwo!", writer.toString());
    }

    // -----------------------------------------------------------------------
    // unescapeJavaScript
    // -----------------------------------------------------------------------

    public void testUnescapeJavaScriptNull() {
        assertEquals(null, StringEscapeUtils.unescapeJavaScript(null));
    }

    public void testUnescapeJavaScriptDelegatesToUnescapeJava() {
        assertEquals("'", StringEscapeUtils.unescapeJavaScript("\\'"));
        assertEquals("He didn't say, \"Stop!\"",
                StringEscapeUtils.unescapeJavaScript("He didn\\'t say, \\\"Stop!\\\""));
    }

    public void testUnescapeJavaScriptWriterWrites() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.unescapeJavaScript(writer, "a\\nb");
        assertEquals("a\nb", writer.toString());
    }

    // -----------------------------------------------------------------------
    // round trip for the Java / JavaScript family
    // -----------------------------------------------------------------------

    public void testEscapeThenUnescapeJavaRoundTrip() {
        String original = "tab:\t nl:\n quote:\" backslash:\\ slash:/ chars:"
                + chr(0x41) + chr(0xE9) + chr(0x1234);
        String escaped = StringEscapeUtils.escapeJava(original);
        assertEquals(original, StringEscapeUtils.unescapeJava(escaped));
    }

    // -----------------------------------------------------------------------
    // escapeHtml(String)
    // -----------------------------------------------------------------------

    public void testEscapeHtmlNull() {
        assertEquals(null, StringEscapeUtils.escapeHtml(null));
    }

    public void testEscapeHtmlEmpty() {
        assertEquals("", StringEscapeUtils.escapeHtml(""));
    }

    public void testEscapeHtmlBasicMarkup() {
        assertEquals("&lt;tag&gt;", StringEscapeUtils.escapeHtml("<tag>"));
        assertEquals("a &amp; b", StringEscapeUtils.escapeHtml("a & b"));
        assertEquals("&quot;bread&quot; &amp; &quot;butter&quot;",
                StringEscapeUtils.escapeHtml("\"bread\" & \"butter\""));
        assertEquals("plain ascii 123", StringEscapeUtils.escapeHtml("plain ascii 123"));
    }

    public void testEscapeHtmlDoesNotEscapeApostrophe() {
        // &apos; is not a legal HTML 4.0 entity, so the apostrophe is left alone
        assertEquals("It's here", StringEscapeUtils.escapeHtml("It's here"));
    }

    public void testEscapeHtmlNamedHighUnicodeEntities() {
        assertEquals("&nbsp;", StringEscapeUtils.escapeHtml(chr(0xA0)));
        assertEquals("&copy;", StringEscapeUtils.escapeHtml(chr(0xA9)));
        assertEquals("&eacute;", StringEscapeUtils.escapeHtml(chr(0xE9)));
        assertEquals("&euro;", StringEscapeUtils.escapeHtml(chr(0x20AC)));
        assertEquals("&le;", StringEscapeUtils.escapeHtml(chr(0x2264)));
    }

    public void testEscapeHtmlUnnamedHighUnicodeBecomesNumericReference() {
        // U+04D2 (decimal 1234) has no HTML 4.0 name -> decimal numeric reference
        assertEquals("&#1234;", StringEscapeUtils.escapeHtml(chr(0x04D2)));
    }

    // -----------------------------------------------------------------------
    // escapeHtml(Writer, String)
    // -----------------------------------------------------------------------

    public void testEscapeHtmlWriterNullWriterThrows() {
        try {
            StringEscapeUtils.escapeHtml((Writer) null, "x");
            fail("Expected IllegalArgumentException for a null Writer");
        } catch (IllegalArgumentException ex) {
            // expected
        } catch (IOException ex) {
            fail("Unexpected IOException: " + ex);
        }
    }

    public void testEscapeHtmlWriterNullStringLeavesWriterEmpty() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.escapeHtml(writer, null);
        assertEquals("", writer.toString());
    }

    public void testEscapeHtmlWriterWrites() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.escapeHtml(writer, "<b>bold & \"quoted\"</b>");
        assertEquals("&lt;b&gt;bold &amp; &quot;quoted&quot;&lt;/b&gt;", writer.toString());
    }

    // -----------------------------------------------------------------------
    // unescapeHtml(String)
    // -----------------------------------------------------------------------

    public void testUnescapeHtmlNull() {
        assertEquals(null, StringEscapeUtils.unescapeHtml(null));
    }

    public void testUnescapeHtmlEmpty() {
        assertEquals("", StringEscapeUtils.unescapeHtml(""));
    }

    public void testUnescapeHtmlNoAmpersandUnchanged() {
        assertEquals("nothing to do here", StringEscapeUtils.unescapeHtml("nothing to do here"));
    }

    public void testUnescapeHtmlNamedEntities() {
        assertEquals("<tag>", StringEscapeUtils.unescapeHtml("&lt;tag&gt;"));
        assertEquals("a & b", StringEscapeUtils.unescapeHtml("a &amp; b"));
        assertEquals(chr(0xA9) + " 2020", StringEscapeUtils.unescapeHtml("&copy; 2020"));
        assertEquals("<Fran" + chr(0xE7) + "ais>",
                StringEscapeUtils.unescapeHtml("&lt;Fran&ccedil;ais&gt;"));
    }

    public void testUnescapeHtmlNumericEntities() {
        assertEquals("@", StringEscapeUtils.unescapeHtml("&#64;"));
        assertEquals("@", StringEscapeUtils.unescapeHtml("&#x40;"));
        assertEquals("@", StringEscapeUtils.unescapeHtml("&#X40;"));
    }

    public void testUnescapeHtmlUnknownEntityLeftVerbatim() {
        assertEquals(">&zzzz;x", StringEscapeUtils.unescapeHtml("&gt;&zzzz;x"));
        // &apos; is an XML entity, not an HTML 4.0 one
        assertEquals("&apos;", StringEscapeUtils.unescapeHtml("&apos;"));
    }

    public void testUnescapeHtmlMissingSemicolonLeftVerbatim() {
        assertEquals("bread &amp butter", StringEscapeUtils.unescapeHtml("bread &amp butter"));
    }

    public void testUnescapeHtmlNumericOverflowLeftVerbatim() {
        // values above 0xFFFF are rejected and emitted unchanged
        assertEquals("&#x10000;", StringEscapeUtils.unescapeHtml("&#x10000;"));
        assertEquals("&#65536;", StringEscapeUtils.unescapeHtml("&#65536;"));
    }

    // -----------------------------------------------------------------------
    // unescapeHtml(Writer, String)
    // -----------------------------------------------------------------------

    public void testUnescapeHtmlWriterNullWriterThrows() {
        try {
            StringEscapeUtils.unescapeHtml((Writer) null, "x");
            fail("Expected IllegalArgumentException for a null Writer");
        } catch (IllegalArgumentException ex) {
            // expected
        } catch (IOException ex) {
            fail("Unexpected IOException: " + ex);
        }
    }

    public void testUnescapeHtmlWriterNullStringLeavesWriterEmpty() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.unescapeHtml(writer, null);
        assertEquals("", writer.toString());
    }

    public void testUnescapeHtmlWriterWrites() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.unescapeHtml(writer, "&lt;x&gt; &amp; &#64;");
        assertEquals("<x> & @", writer.toString());
    }

    public void testEscapeThenUnescapeHtmlRoundTrip() {
        String original = "<html> \"tag\" & symbols "
                + chr(0xA9) + " " + chr(0xE9) + " " + chr(0x20AC);
        assertEquals(original,
                StringEscapeUtils.unescapeHtml(StringEscapeUtils.escapeHtml(original)));
    }

    // -----------------------------------------------------------------------
    // escapeXml(String)
    // -----------------------------------------------------------------------

    public void testEscapeXmlNull() {
        assertEquals(null, StringEscapeUtils.escapeXml(null));
    }

    public void testEscapeXmlEmpty() {
        assertEquals("", StringEscapeUtils.escapeXml(""));
    }

    public void testEscapeXmlFiveBasicEntities() {
        assertEquals("&lt;&gt;&amp;&quot;&apos;", StringEscapeUtils.escapeXml("<>&\"'"));
        assertEquals("plain 123 text", StringEscapeUtils.escapeXml("plain 123 text"));
    }

    public void testEscapeXmlEscapesApostropheUnlikeHtml() {
        assertEquals("It&apos;s", StringEscapeUtils.escapeXml("It's"));
    }

    public void testEscapeXmlHighUnicodeBecomesNumericReference() {
        // the XML entity set has no accented-letter names -> decimal references
        assertEquals("&#233;", StringEscapeUtils.escapeXml(chr(0xE9)));
        assertEquals("&#169;", StringEscapeUtils.escapeXml(chr(0xA9)));
    }

    // -----------------------------------------------------------------------
    // escapeXml(Writer, String)
    // -----------------------------------------------------------------------

    public void testEscapeXmlWriterNullWriterThrows() {
        try {
            StringEscapeUtils.escapeXml((Writer) null, "x");
            fail("Expected IllegalArgumentException for a null Writer");
        } catch (IllegalArgumentException ex) {
            // expected
        } catch (IOException ex) {
            fail("Unexpected IOException: " + ex);
        }
    }

    public void testEscapeXmlWriterNullStringLeavesWriterEmpty() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.escapeXml(writer, null);
        assertEquals("", writer.toString());
    }

    public void testEscapeXmlWriterWrites() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.escapeXml(writer, "<a>'x' & \"y\"</a>");
        assertEquals("&lt;a&gt;&apos;x&apos; &amp; &quot;y&quot;&lt;/a&gt;", writer.toString());
    }

    // -----------------------------------------------------------------------
    // unescapeXml(String)
    // -----------------------------------------------------------------------

    public void testUnescapeXmlNull() {
        assertEquals(null, StringEscapeUtils.unescapeXml(null));
    }

    public void testUnescapeXmlEmpty() {
        assertEquals("", StringEscapeUtils.unescapeXml(""));
    }

    public void testUnescapeXmlFiveBasicEntities() {
        assertEquals("<>&\"'", StringEscapeUtils.unescapeXml("&lt;&gt;&amp;&quot;&apos;"));
    }

    public void testUnescapeXmlNumericEntities() {
        assertEquals(chr(0xE9), StringEscapeUtils.unescapeXml("&#233;"));
        assertEquals(chr(0xE9), StringEscapeUtils.unescapeXml("&#xE9;"));
    }

    public void testUnescapeXmlUnknownEntityLeftVerbatim() {
        // &copy; is HTML-only; the XML entity set must not resolve it
        assertEquals("&copy;", StringEscapeUtils.unescapeXml("&copy;"));
        assertEquals("no entities here", StringEscapeUtils.unescapeXml("no entities here"));
    }

    // -----------------------------------------------------------------------
    // unescapeXml(Writer, String)
    // -----------------------------------------------------------------------

    public void testUnescapeXmlWriterNullWriterThrows() {
        try {
            StringEscapeUtils.unescapeXml((Writer) null, "x");
            fail("Expected IllegalArgumentException for a null Writer");
        } catch (IllegalArgumentException ex) {
            // expected
        } catch (IOException ex) {
            fail("Unexpected IOException: " + ex);
        }
    }

    public void testUnescapeXmlWriterNullStringLeavesWriterEmpty() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.unescapeXml(writer, null);
        assertEquals("", writer.toString());
    }

    public void testUnescapeXmlWriterWrites() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.unescapeXml(writer, "&lt;tag attr=&quot;v&quot;&gt;");
        assertEquals("<tag attr=\"v\">", writer.toString());
    }

    public void testEscapeThenUnescapeXmlRoundTrip() {
        String original = "<x a='1' b=\"2\"> & more " + chr(0xE9);
        assertEquals(original,
                StringEscapeUtils.unescapeXml(StringEscapeUtils.escapeXml(original)));
    }

    // -----------------------------------------------------------------------
    // escapeSql(String)
    // -----------------------------------------------------------------------

    public void testEscapeSqlNull() {
        assertEquals(null, StringEscapeUtils.escapeSql(null));
    }

    public void testEscapeSqlEmpty() {
        assertEquals("", StringEscapeUtils.escapeSql(""));
    }

    public void testEscapeSqlNoQuote() {
        assertEquals("no quotes here", StringEscapeUtils.escapeSql("no quotes here"));
    }

    public void testEscapeSqlDoublesSingleQuotes() {
        assertEquals("McHale''s Navy", StringEscapeUtils.escapeSql("McHale's Navy"));
        assertEquals("''''", StringEscapeUtils.escapeSql("''"));
        assertEquals("''a''b''", StringEscapeUtils.escapeSql("'a'b'"));
    }

    public void testEscapeSqlLeavesOtherCharactersAlone() {
        // percent, underscore and double quotes are explicitly not handled
        assertEquals("say \"hi\" 100% _x_", StringEscapeUtils.escapeSql("say \"hi\" 100% _x_"));
    }
}
