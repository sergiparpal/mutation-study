package org.apache.commons.cli;

import java.util.Properties;

import org.junit.Test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

/**
 * Tests for {@link DefaultParser}, based on the documented contract in
 * DefaultParser.html (parse(...) overloads and handleConcatenatedOptions).
 */
public class DefaultParserAgentTest {

    @Test
    public void testParseSimpleBooleanFlag() throws Exception {
        Options options = new Options();
        options.addOption("a", false, "flag a");

        DefaultParser parser = new DefaultParser();
        CommandLine cmd = parser.parse(options, new String[] { "-a" });

        assertNotNull(cmd);
        assertTrue(cmd.hasOption("a"));
        assertEquals(0, cmd.getArgs().length);
    }

    @Test
    public void testParseOptionWithArgumentValue() throws Exception {
        Options options = new Options();
        options.addOption("b", true, "flag b with value");

        DefaultParser parser = new DefaultParser();
        CommandLine cmd = parser.parse(options, new String[] { "-b", "value1" });

        assertTrue(cmd.hasOption("b"));
        assertEquals("value1", cmd.getOptionValue("b"));
    }

    @Test
    public void testParseLongOptionName() throws Exception {
        Options options = new Options();
        options.addOption(new Option("b", "bravo", true, "long option"));

        DefaultParser parser = new DefaultParser();
        CommandLine cmd = parser.parse(options, new String[] { "--bravo", "value2" });

        assertTrue(cmd.hasOption("b"));
        assertTrue(cmd.hasOption("bravo"));
        assertEquals("value2", cmd.getOptionValue("b"));
    }

    @Test
    public void testParsePositionalArgumentsPreserveOrder() throws Exception {
        Options options = new Options();
        options.addOption("a", false, "flag a");

        DefaultParser parser = new DefaultParser();
        CommandLine cmd = parser.parse(options, new String[] { "-a", "foo", "bar" });

        assertTrue(cmd.hasOption("a"));
        String[] extra = cmd.getArgs();
        assertEquals(2, extra.length);
        assertEquals("foo", extra[0]);
        assertEquals("bar", extra[1]);
    }

    @Test
    public void testParseNoArgumentsReturnsEmptyCommandLine() throws Exception {
        Options options = new Options();
        options.addOption("a", false, "flag a");

        DefaultParser parser = new DefaultParser();
        CommandLine cmd = parser.parse(options, new String[0]);

        assertFalse(cmd.hasOption("a"));
        assertEquals(0, cmd.getArgs().length);
    }

    @Test
    public void testParseUnrecognizedOptionThrowsByDefault() throws Exception {
        Options options = new Options();
        options.addOption("a", false, "flag a");

        DefaultParser parser = new DefaultParser();
        try {
            parser.parse(options, new String[] { "-x" });
            fail("Expected a ParseException for an unrecognized option");
        } catch (ParseException e) {
            assertTrue(e instanceof UnrecognizedOptionException);
        }
    }

    @Test
    public void testParseStopAtNonOptionTrueCollectsRemainderAsArgs() throws Exception {
        Options options = new Options();
        options.addOption("a", false, "flag a");

        DefaultParser parser = new DefaultParser();
        CommandLine cmd = parser.parse(options, new String[] { "-x", "-a", "foo" }, true);

        String[] extra = cmd.getArgs();
        assertEquals(3, extra.length);
        assertEquals("-x", extra[0]);
        assertEquals("-a", extra[1]);
        assertEquals("foo", extra[2]);
        assertFalse(cmd.hasOption("a"));
    }

    @Test
    public void testParseStopAtNonOptionFieldRecordsFlag() throws Exception {
        Options options = new Options();
        options.addOption("a", false, "flag a");

        DefaultParser parser = new DefaultParser();
        parser.parse(options, new String[] { "-a" }, true);

        assertTrue(parser.stopAtNonOption);
    }

    @Test
    public void testParseMissingArgumentThrowsParseException() throws Exception {
        Options options = new Options();
        options.addOption("b", true, "flag b with value");

        DefaultParser parser = new DefaultParser();
        try {
            parser.parse(options, new String[] { "-b" });
            fail("Expected a ParseException because -b requires a value");
        } catch (ParseException e) {
            assertTrue(e instanceof MissingArgumentException);
        }
    }

    @Test
    public void testParseMissingRequiredOptionThrows() throws Exception {
        Options options = new Options();
        Option required = new Option("r", false, "required flag");
        required.setRequired(true);
        options.addOption(required);

        DefaultParser parser = new DefaultParser();
        try {
            parser.parse(options, new String[0]);
            fail("Expected a ParseException because required option -r is missing");
        } catch (ParseException e) {
            assertTrue(e instanceof MissingOptionException);
        }
    }

    @Test
    public void testParseRequiredOptionSatisfied() throws Exception {
        Options options = new Options();
        Option required = new Option("r", false, "required flag");
        required.setRequired(true);
        options.addOption(required);

        DefaultParser parser = new DefaultParser();
        CommandLine cmd = parser.parse(options, new String[] { "-r" });

        assertTrue(cmd.hasOption("r"));
        assertTrue(parser.expectedOpts.isEmpty());
    }

    @Test
    public void testParseRecordsOptionsAndCommandLineFields() throws Exception {
        Options options = new Options();
        options.addOption("a", false, "flag a");

        DefaultParser parser = new DefaultParser();
        CommandLine cmd = parser.parse(options, new String[] { "-a" });

        assertSame(options, parser.options);
        assertSame(cmd, parser.cmd);
    }

    @Test
    public void testHandleConcatenatedBooleanOptionsBurst() throws Exception {
        Options options = new Options();
        options.addOption("a", false, "flag a");
        options.addOption("b", false, "flag b");
        options.addOption("c", false, "flag c");

        DefaultParser parser = new DefaultParser();
        CommandLine cmd = parser.parse(options, new String[] { "-abc" });

        assertTrue(cmd.hasOption("a"));
        assertTrue(cmd.hasOption("b"));
        assertTrue(cmd.hasOption("c"));
    }

    @Test
    public void testHandleConcatenatedOptionsConsumesTrailingValue() throws Exception {
        Options options = new Options();
        options.addOption("a", false, "flag a");
        options.addOption("b", true, "flag b with value");

        DefaultParser parser = new DefaultParser();
        CommandLine cmd = parser.parse(options, new String[] { "-abvalue" });

        assertTrue(cmd.hasOption("a"));
        assertTrue(cmd.hasOption("b"));
        assertEquals("value", cmd.getOptionValue("b"));
    }

    @Test
    public void testParsePropertiesSupplyDefaultOptionValue() throws Exception {
        Options options = new Options();
        options.addOption("D", "define", true, "definition");

        Properties properties = new Properties();
        properties.setProperty("D", "value1");

        DefaultParser parser = new DefaultParser();
        CommandLine cmd = parser.parse(options, new String[0], properties);

        assertTrue(cmd.hasOption("D"));
        assertEquals("value1", cmd.getOptionValue("D"));
    }

    @Test
    public void testParseWithPropertiesAndStopAtNonOptionOverload() throws Exception {
        Options options = new Options();
        options.addOption("D", "define", true, "definition");

        Properties properties = new Properties();
        properties.setProperty("D", "value1");

        DefaultParser parser = new DefaultParser();
        CommandLine cmd = parser.parse(options, new String[] { "-x" }, properties, true);

        assertTrue(cmd.hasOption("D"));
        assertEquals("value1", cmd.getOptionValue("D"));
        assertEquals(1, cmd.getArgs().length);
        assertEquals("-x", cmd.getArgs()[0]);
    }

    @Test
    public void testAlreadySelectedExceptionForMutuallyExclusiveOptions() throws Exception {
        Option optA = new Option("a", false, "option a");
        Option optB = new Option("b", false, "option b");
        OptionGroup group = new OptionGroup();
        group.addOption(optA);
        group.addOption(optB);

        Options options = new Options();
        options.addOptionGroup(group);

        DefaultParser parser = new DefaultParser();
        try {
            parser.parse(options, new String[] { "-a", "-b" });
            fail("Expected a ParseException because -a and -b belong to the same exclusive group");
        } catch (ParseException e) {
            assertTrue(e instanceof AlreadySelectedException);
        }
    }

    @Test
    public void testDoubleDashStopsOptionProcessing() throws Exception {
        Options options = new Options();
        options.addOption("a", false, "flag a");

        DefaultParser parser = new DefaultParser();
        CommandLine cmd = parser.parse(options, new String[] { "-a", "--", "-b", "c" });

        assertTrue(cmd.hasOption("a"));
        assertFalse(cmd.hasOption("b"));
        String[] extra = cmd.getArgs();
        assertEquals(2, extra.length);
        assertEquals("-b", extra[0]);
        assertEquals("c", extra[1]);
        assertTrue(parser.skipParsing);
    }
}
