/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.csv;

import static org.apache.commons.csv.Constants.CRLF;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import java.io.BufferedWriter;
import java.io.Closeable;
import java.io.Flushable;
import java.io.IOException;
import java.io.StringWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;

/**
 * Tests for {@link CSVPrinter}, exercising the public API only.
 *
 * @version $Id$
 */
public class CSVPrinterAgentTest {

    // ======================================================
    // constructor
    // ======================================================

    @Test(expected = IllegalArgumentException.class)
    public void testConstructorRejectsNullOut() throws IOException {
        new CSVPrinter(null, CSVFormat.DEFAULT);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testConstructorRejectsNullFormat() throws IOException {
        new CSVPrinter(new StringWriter(), null);
    }

    @Test(expected = IllegalStateException.class)
    public void testConstructorRejectsInconsistentFormat() throws IOException {
        // quoteChar and delimiter are the same: CSVFormat.validate() must reject it
        new CSVPrinter(new StringWriter(), CSVFormat.newFormat('!').withQuoteChar('!'));
    }

    @Test
    public void testConstructorWithoutHeaderWritesNothing() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        assertEquals(0, sb.length());
        printer.close();
    }

    @Test
    public void testConstructorPrintsSuppliedHeader() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT.withHeader("Col1", "Col2"));
        assertEquals("Col1,Col2" + CRLF, sb.toString());
        printer.close();
    }

    @Test
    public void testConstructorPrintsQuotedHeader() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT.withHeader("a", "b,b"));
        assertEquals("a,\"b,b\"" + CRLF, sb.toString());
        printer.close();
    }

    @Test
    public void testConstructorWithEmptyHeaderPrintsRecordSeparator() throws IOException {
        // withHeader() with no names means "read from file"; getHeader() is a non-null empty array
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT.withHeader());
        assertEquals(CRLF, sb.toString());
        printer.close();
    }

    // ======================================================
    // getOut
    // ======================================================

    @Test
    public void testGetOutReturnsSameInstance() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        assertSame(sw, printer.getOut());
        printer.close();
    }

    // ======================================================
    // print(Object)
    // ======================================================

    @Test
    public void testPrintPlainValueIsNotQuoted() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("abc");
        assertEquals("abc", sb.toString());
        printer.close();
    }

    @Test
    public void testPrintNonStringValueUsesToString() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print(Integer.valueOf(42));
        assertEquals("42", sb.toString());
        printer.close();
    }

    @Test
    public void testPrintValueContainingDelimiterIsQuoted() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("a,b");
        assertEquals("\"a,b\"", sb.toString());
        printer.close();
    }

    @Test
    public void testPrintValueContainingQuoteHasItDoubled() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("x\"y");
        assertEquals("\"x\"\"y\"", sb.toString());
        printer.close();
    }

    @Test
    public void testPrintValueContainingNewlineIsQuoted() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("a\nb");
        assertEquals("\"a\nb\"", sb.toString());
        printer.close();
    }

    @Test
    public void testPrintValueWithLeadingSpaceIsQuoted() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print(" a");
        assertEquals("\" a\"", sb.toString());
        printer.close();
    }

    @Test
    public void testPrintValueWithTrailingSpaceIsQuoted() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("a ");
        assertEquals("\"a \"", sb.toString());
        printer.close();
    }

    @Test
    public void testPrintNullWithoutNullStringWritesEmpty() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.newFormat(','));
        printer.print(null);
        printer.print("x");
        assertEquals(",x", sb.toString());
        printer.close();
    }

    @Test
    public void testPrintNullWithNullStringWritesNullString() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.newFormat(',').withNullString("N/A"));
        printer.print(null);
        assertEquals("N/A", sb.toString());
        printer.close();
    }

    @Test
    public void testSecondValueIsSeparatedByDelimiter() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("a");
        printer.print("b");
        assertEquals("a,b", sb.toString());
        printer.close();
    }

    // ======================================================
    // println
    // ======================================================

    @Test
    public void testPrintlnWritesRecordSeparator() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.println();
        assertEquals(CRLF, sb.toString());
        printer.println();
        assertEquals(CRLF + CRLF, sb.toString());
        printer.close();
    }

    @Test
    public void testPrintlnWithNullRecordSeparatorWritesNothing() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.newFormat(','));
        printer.print("a");
        printer.println();
        printer.print("b");
        // newFormat has a null record separator, so println() emits nothing but still starts a new record
        assertEquals("ab", sb.toString());
        printer.close();
    }

    @Test
    public void testPrintlnResetsNewRecordState() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.newFormat(',').withRecordSeparator('\n'));
        printer.print("a");
        printer.println();
        printer.print("b");
        assertEquals("a\nb", sb.toString());
        printer.close();
    }

    // ======================================================
    // printRecord
    // ======================================================

    @Test
    public void testPrintRecordVarargs() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord("a", "b", "c");
        assertEquals("a,b,c" + CRLF, sb.toString());
        printer.close();
    }

    @Test
    public void testPrintRecordIterable() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord(Arrays.asList("x", "y", "z"));
        assertEquals("x,y,z" + CRLF, sb.toString());
        printer.close();
    }

    @Test
    public void testPrintRecordEmptyVarargsWritesOnlyRecordSeparator() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord();
        assertEquals(CRLF, sb.toString());
        printer.close();
    }

    @Test
    public void testPrintMultipleRecords() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord("a", "b");
        printer.printRecord("c", "d");
        assertEquals("a,b" + CRLF + "c,d" + CRLF, sb.toString());
        printer.close();
    }

    @Test
    public void testPrintRecordQuotesEmptyLeadingValueButNotEmptyTrailingValue() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord("", "a");
        printer.printRecord("a", "");
        assertEquals("\"\",a" + CRLF + "a," + CRLF, sb.toString());
        printer.close();
    }

    // ======================================================
    // printRecords
    // ======================================================

    @Test
    public void testPrintRecordsWithArrayOfArrays() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        final String[][] rows = { { "a", "b" }, { "c", "d" } };
        printer.printRecords(rows);
        assertEquals("a,b" + CRLF + "c,d" + CRLF, sb.toString());
        printer.close();
    }

    @Test
    public void testPrintRecordsWithFlatArrayPrintsOneValuePerRecord() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecords(new String[] { "a", "b", "c" });
        assertEquals("a" + CRLF + "b" + CRLF + "c" + CRLF, sb.toString());
        printer.close();
    }

    @Test
    public void testPrintRecordsWithIterableOfIterables() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        final List<List<String>> rows = new ArrayList<List<String>>();
        rows.add(Arrays.asList("a", "b"));
        rows.add(Arrays.asList("c", "d"));
        printer.printRecords(rows);
        assertEquals("a,b" + CRLF + "c,d" + CRLF, sb.toString());
        printer.close();
    }

    @Test
    public void testPrintRecordsWithIterableOfPlainValues() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecords(Arrays.asList("a", "b", "c"));
        assertEquals("a" + CRLF + "b" + CRLF + "c" + CRLF, sb.toString());
        printer.close();
    }

    @Test
    public void testPrintRecordsWithMixedElements() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        final Object[] mixed = { Arrays.asList("a", "b"), new String[] { "c", "d" }, "e" };
        printer.printRecords(mixed);
        assertEquals("a,b" + CRLF + "c,d" + CRLF + "e" + CRLF, sb.toString());
        printer.close();
    }

    @Test
    public void testPrintRecordsWithResultSet() throws Exception {
        Class.forName("org.h2.Driver");
        final Connection connection =
                DriverManager.getConnection("jdbc:h2:mem:csvprinteragenttest", "sa", "");
        try {
            final Statement statement = connection.createStatement();
            statement.execute("CREATE TABLE TEST(ID INT PRIMARY KEY, NAME VARCHAR(255))");
            statement.execute("INSERT INTO TEST VALUES (1, 'r1')");
            statement.execute("INSERT INTO TEST VALUES (2, 'r2')");
            final ResultSet resultSet = statement.executeQuery("SELECT ID, NAME FROM TEST ORDER BY ID");
            final StringWriter sw = new StringWriter();
            final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
            printer.printRecords(resultSet);
            assertEquals("1,r1" + CRLF + "2,r2" + CRLF, sw.toString());
            printer.close();
            resultSet.close();
            statement.close();
        } finally {
            connection.close();
        }
    }

    // ======================================================
    // printComment
    // ======================================================

    @Test
    public void testPrintCommentIsNoopWhenCommentingDisabled() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printComment("this should not appear");
        assertEquals(0, sb.length());
        printer.close();
    }

    @Test
    public void testPrintCommentNullIsNoopWhenCommentingDisabled() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printComment(null);
        assertEquals(0, sb.length());
        printer.close();
    }

    @Test
    public void testPrintCommentSingleLine() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT.withCommentStart('#'));
        printer.printComment("Hello");
        assertEquals("# Hello" + CRLF, sb.toString());
        printer.close();
    }

    @Test
    public void testPrintCommentMultiLineWithLf() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT.withCommentStart('#'));
        printer.printComment("Line1\nLine2");
        assertEquals("# Line1" + CRLF + "# Line2" + CRLF, sb.toString());
        printer.close();
    }

    @Test
    public void testPrintCommentMultiLineWithCrLfCountsAsSingleBreak() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT.withCommentStart('#'));
        printer.printComment("Line1\r\nLine2");
        assertEquals("# Line1" + CRLF + "# Line2" + CRLF, sb.toString());
        printer.close();
    }

    @Test
    public void testPrintCommentAfterValueStartsNewLine() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT.withCommentStart('#'));
        printer.print("a");
        printer.printComment("c");
        assertEquals("a" + CRLF + "# c" + CRLF, sb.toString());
        printer.close();
    }

    @Test(expected = NullPointerException.class)
    public void testPrintCommentNullThrowsWhenCommentingEnabled() throws IOException {
        final CSVPrinter printer = new CSVPrinter(new StringBuilder(), CSVFormat.DEFAULT.withCommentStart('#'));
        printer.printComment(null);
    }

    // ======================================================
    // quote policies
    // ======================================================

    @Test
    public void testQuotePolicyAllQuotesEveryValue() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT.withQuotePolicy(Quote.ALL));
        printer.printRecord("a", "b");
        assertEquals("\"a\",\"b\"" + CRLF, sb.toString());
        printer.close();
    }

    @Test
    public void testQuotePolicyNonNumericQuotesOnlyNonNumbers() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT.withQuotePolicy(Quote.NON_NUMERIC));
        printer.printRecord("a", Integer.valueOf(123));
        assertEquals("\"a\",123" + CRLF, sb.toString());
        printer.close();
    }

    @Test
    public void testQuotePolicyNoneEscapesInsteadOfQuoting() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer =
                new CSVPrinter(sb, CSVFormat.DEFAULT.withEscape('!').withQuotePolicy(Quote.NONE));
        printer.printRecord("a,b", "c");
        assertEquals("a!,b,c" + CRLF, sb.toString());
        printer.close();
    }

    // ======================================================
    // escaping
    // ======================================================

    @Test
    public void testEscapingDelimiterAndNewline() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer =
                new CSVPrinter(sb, CSVFormat.newFormat(',').withEscape('\\').withRecordSeparator('\n'));
        printer.printRecord("a,b", "c\nd");
        assertEquals("a\\,b,c\\nd\n", sb.toString());
        printer.close();
    }

    @Test
    public void testMysqlFormatUsesTabAndEscape() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.MYSQL);
        printer.printRecord("a", "b", "c");
        assertEquals("a\tb\tc\n", sb.toString());
        printer.close();
    }

    // ======================================================
    // round trip with the parser
    // ======================================================

    @Test
    public void testRoundTripWithParser() throws IOException {
        final String input = "a,b,c" + CRLF + "1,2,3" + CRLF + "x,y,z" + CRLF;
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final CSVParser parser = CSVParser.parse(input, CSVFormat.DEFAULT);
        for (final CSVRecord record : parser) {
            printer.printRecord(record);
        }
        assertEquals(input, sw.toString());
        parser.close();
        printer.close();
    }

    // ======================================================
    // close / flush
    // ======================================================

    @Test
    public void testCloseClosesUnderlyingCloseable() throws IOException {
        final TrackingAppendable out = new TrackingAppendable();
        final CSVPrinter printer = new CSVPrinter(out, CSVFormat.DEFAULT);
        assertFalse(out.closed);
        printer.close();
        assertTrue(out.closed);
    }

    @Test
    public void testCloseIsNoopForNonCloseableAppendable() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord("a", "b");
        printer.close();
        // close() must neither throw nor alter what was already written
        assertEquals("a,b" + CRLF, sb.toString());
    }

    @Test
    public void testFlushFlushesUnderlyingFlushable() throws IOException {
        final TrackingAppendable out = new TrackingAppendable();
        final CSVPrinter printer = new CSVPrinter(out, CSVFormat.DEFAULT);
        assertFalse(out.flushed);
        printer.flush();
        assertTrue(out.flushed);
        printer.close();
    }

    @Test
    public void testFlushPushesBufferedDataToUnderlyingStream() throws IOException {
        final StringWriter sw = new StringWriter();
        final BufferedWriter bw = new BufferedWriter(sw);
        final CSVPrinter printer = new CSVPrinter(bw, CSVFormat.DEFAULT);
        printer.printRecord("a", "b", "c");
        // still buffered in the BufferedWriter, not yet visible in the StringWriter
        assertEquals("", sw.toString());
        printer.flush();
        assertEquals("a,b,c" + CRLF, sw.toString());
        printer.close();
    }

    @Test
    public void testFlushIsNoopForNonFlushableAppendable() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("a");
        printer.flush();
        assertEquals("a", sb.toString());
        printer.close();
    }

    @Test
    public void testWritesToProvidedAppendable() throws IOException {
        final TrackingAppendable out = new TrackingAppendable();
        final CSVPrinter printer = new CSVPrinter(out, CSVFormat.DEFAULT);
        printer.printRecord("a", "b");
        assertEquals("a,b" + CRLF, out.toString());
        assertSame(out, printer.getOut());
        printer.close();
    }

    /**
     * An {@link Appendable} that also records whether it has been closed / flushed, so tests can assert
     * that {@link CSVPrinter} forwards those calls.
     */
    private static final class TrackingAppendable implements Appendable, Closeable, Flushable {

        private final StringBuilder content = new StringBuilder();
        boolean closed;
        boolean flushed;

        public Appendable append(final CharSequence csq) {
            content.append(csq);
            return this;
        }

        public Appendable append(final CharSequence csq, final int start, final int end) {
            content.append(csq, start, end);
            return this;
        }

        public Appendable append(final char c) {
            content.append(c);
            return this;
        }

        public void close() {
            closed = true;
        }

        public void flush() {
            flushed = true;
        }

        @Override
        public String toString() {
            return content.toString();
        }
    }
}
