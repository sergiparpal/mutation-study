package com.google.gson.internal.bind;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.fail;

import com.google.gson.Gson;
import com.google.gson.InstanceCreator;
import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import com.google.gson.TypeAdapter;
import com.google.gson.TypeAdapterFactory;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.internal.ConstructorConstructor;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.Test;

/**
 * Tests for {@link JsonAdapterAnnotationTypeAdapterFactory}, based on the documented contract:
 * "Given a type T, looks for the annotation {@code JsonAdapter} and uses an instance of the
 * specified class as the default type adapter", and the inherited {@code create} contract that
 * it "[r]eturns a type adapter for type, or null if this factory doesn't support type."
 */
public class JsonAdapterAnnotationTypeAdapterFactoryAgentTest {

  // ---- fixtures -----------------------------------------------------------------------------

  private static ConstructorConstructor newConstructorConstructor() {
    Map<Type, InstanceCreator<?>> instanceCreators = new HashMap<Type, InstanceCreator<?>>();
    return new ConstructorConstructor(instanceCreators);
  }

  private static JsonAdapterAnnotationTypeAdapterFactory newFactory() {
    return new JsonAdapterAnnotationTypeAdapterFactory(newConstructorConstructor());
  }

  private static <T> String writeToJson(TypeAdapter<T> adapter, T value) throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter jsonWriter = new JsonWriter(stringWriter);
    adapter.write(jsonWriter, value);
    jsonWriter.flush();
    return stringWriter.toString();
  }

  private static <T> T readFromJson(TypeAdapter<T> adapter, String json) throws IOException {
    JsonReader jsonReader = new JsonReader(new StringReader(json));
    return adapter.read(jsonReader);
  }

  /** No {@code @JsonAdapter} annotation anywhere on this type. */
  static class PlainClass {
  }

  static final class FixedTypeAdapter extends TypeAdapter<AnnotatedWithTypeAdapter> {
    @Override
    public void write(JsonWriter out, AnnotatedWithTypeAdapter value) throws IOException {
      out.value("fixed-value");
    }

    @Override
    public AnnotatedWithTypeAdapter read(JsonReader in) throws IOException {
      in.nextString();
      return new AnnotatedWithTypeAdapter();
    }
  }

  @JsonAdapter(FixedTypeAdapter.class)
  static class AnnotatedWithTypeAdapter {
  }

  static final class SentinelAdapter extends TypeAdapter<AnnotatedWithFactory> {
    @Override
    public void write(JsonWriter out, AnnotatedWithFactory value) throws IOException {
      out.value("from-factory");
    }

    @Override
    public AnnotatedWithFactory read(JsonReader in) throws IOException {
      in.nextString();
      return new AnnotatedWithFactory();
    }
  }

  static final class DelegatingFactory implements TypeAdapterFactory {
    @SuppressWarnings("unchecked")
    @Override
    public <T> TypeAdapter<T> create(Gson gson, TypeToken<T> type) {
      return (TypeAdapter<T>) new SentinelAdapter();
    }
  }

  @JsonAdapter(DelegatingFactory.class)
  static class AnnotatedWithFactory {
  }

  static final class CustomSerializer implements JsonSerializer<AnnotatedWithSerializer> {
    @Override
    public JsonElement serialize(AnnotatedWithSerializer src, Type typeOfSrc,
        JsonSerializationContext context) {
      return new JsonPrimitive("serialized-value");
    }
  }

  @JsonAdapter(CustomSerializer.class)
  static class AnnotatedWithSerializer {
  }

  /** Implements none of TypeAdapter, TypeAdapterFactory, JsonSerializer or JsonDeserializer. */
  static class NotAnAdapter {
  }

  @JsonAdapter(NotAnAdapter.class)
  static class AnnotatedWithInvalidAdapter {
  }

  abstract static class AbstractAdapter extends TypeAdapter<AnnotatedWithAbstractAdapter> {
  }

  /** Annotated with an adapter class that can never be instantiated via a no-args constructor. */
  @JsonAdapter(AbstractAdapter.class)
  static class AnnotatedWithAbstractAdapter {
  }

  // ---- tests ----------------------------------------------------------------------------------

  @Test
  public void testFactoryImplementsTypeAdapterFactory() {
    JsonAdapterAnnotationTypeAdapterFactory factory = newFactory();
    assertTrueIsTypeAdapterFactory(factory);
  }

  private static void assertTrueIsTypeAdapterFactory(Object factory) {
    if (!(factory instanceof TypeAdapterFactory)) {
      fail("Expected factory to implement TypeAdapterFactory");
    }
  }

  @Test
  public void testCreateReturnsNullWhenNoAnnotationPresent() {
    JsonAdapterAnnotationTypeAdapterFactory factory = newFactory();
    Gson gson = new Gson();

    TypeAdapter<PlainClass> adapter = factory.create(gson, TypeToken.get(PlainClass.class));

    assertNull(adapter);
  }

  @Test
  public void testCreateReturnsNullForJdkTypeWithoutAnnotation() {
    JsonAdapterAnnotationTypeAdapterFactory factory = newFactory();
    Gson gson = new Gson();

    TypeAdapter<String> adapter = factory.create(gson, TypeToken.get(String.class));

    assertNull(adapter);
  }

  @Test
  public void testCreateIgnoresAnnotationOnGenericTypeArgument() {
    JsonAdapterAnnotationTypeAdapterFactory factory = newFactory();
    Gson gson = new Gson();
    TypeToken<List<AnnotatedWithTypeAdapter>> listOfAnnotatedType =
        new TypeToken<List<AnnotatedWithTypeAdapter>>() {};

    TypeAdapter<List<AnnotatedWithTypeAdapter>> adapter = factory.create(gson, listOfAnnotatedType);

    // The annotation lives on the element type, not on java.util.List itself, so the raw
    // List type remains unsupported by this factory.
    assertNull(adapter);
  }

  @Test
  public void testCreateUsesAnnotatedTypeAdapterDirectly() throws IOException {
    JsonAdapterAnnotationTypeAdapterFactory factory = newFactory();
    Gson gson = new Gson();

    TypeAdapter<AnnotatedWithTypeAdapter> adapter =
        factory.create(gson, TypeToken.get(AnnotatedWithTypeAdapter.class));

    assertNotNull(adapter);
    assertEquals("\"fixed-value\"", writeToJson(adapter, new AnnotatedWithTypeAdapter()));
  }

  @Test
  public void testCreateDelegatesToAnnotatedTypeAdapterFactory() throws IOException {
    JsonAdapterAnnotationTypeAdapterFactory factory = newFactory();
    Gson gson = new Gson();

    TypeAdapter<AnnotatedWithFactory> adapter =
        factory.create(gson, TypeToken.get(AnnotatedWithFactory.class));

    assertNotNull(adapter);
    assertEquals("\"from-factory\"", writeToJson(adapter, new AnnotatedWithFactory()));
  }

  // @Test  // pruned: failed on the fixed version
  public void testCreateWrapsAnnotatedJsonSerializer() throws IOException {
    JsonAdapterAnnotationTypeAdapterFactory factory = newFactory();
    Gson gson = new Gson();

    TypeAdapter<AnnotatedWithSerializer> adapter =
        factory.create(gson, TypeToken.get(AnnotatedWithSerializer.class));

    assertNotNull(adapter);
    assertEquals("\"serialized-value\"", writeToJson(adapter, new AnnotatedWithSerializer()));
  }

  @Test
  public void testCreateThrowsWhenAnnotationValueIsNotAnAdapterType() {
    JsonAdapterAnnotationTypeAdapterFactory factory = newFactory();
    Gson gson = new Gson();

    try {
      factory.create(gson, TypeToken.get(AnnotatedWithInvalidAdapter.class));
      fail("Expected a RuntimeException: NotAnAdapter implements none of the supported "
          + "adapter contracts (TypeAdapter, TypeAdapterFactory, JsonSerializer, "
          + "JsonDeserializer)");
    } catch (RuntimeException expected) {
      // The factory cannot silently return null here: the type IS annotated, so returning
      // null would incorrectly claim the type is unsupported rather than misconfigured.
    }
  }

  @Test
  public void testCreateThrowsWhenAnnotatedAdapterCannotBeInstantiated() {
    JsonAdapterAnnotationTypeAdapterFactory factory = newFactory();
    Gson gson = new Gson();

    try {
      factory.create(gson, TypeToken.get(AnnotatedWithAbstractAdapter.class));
      fail("Expected a RuntimeException: AbstractAdapter cannot be instantiated via a "
          + "no-args constructor because it is abstract");
    } catch (RuntimeException expected) {
      // instantiation failure must propagate rather than being swallowed into a null result
    }
  }

  @Test
  public void testGetTypeAdapterStaticMethodDelegatesLikeCreate() throws IOException {
    ConstructorConstructor constructorConstructor = newConstructorConstructor();
    Gson gson = new Gson();
    JsonAdapter annotation = AnnotatedWithTypeAdapter.class.getAnnotation(JsonAdapter.class);
    assertNotNull(annotation);

    TypeAdapter<?> adapter = JsonAdapterAnnotationTypeAdapterFactory.getTypeAdapter(
        constructorConstructor, gson, TypeToken.get(AnnotatedWithTypeAdapter.class), annotation);

    assertNotNull(adapter);
    @SuppressWarnings("unchecked")
    TypeAdapter<AnnotatedWithTypeAdapter> typedAdapter =
        (TypeAdapter<AnnotatedWithTypeAdapter>) adapter;
    assertEquals("\"fixed-value\"", writeToJson(typedAdapter, new AnnotatedWithTypeAdapter()));
  }

  @Test
  public void testCreatedTypeAdapterCanRoundTripThroughReadAndWrite() throws IOException {
    JsonAdapterAnnotationTypeAdapterFactory factory = newFactory();
    Gson gson = new Gson();

    TypeAdapter<AnnotatedWithTypeAdapter> adapter =
        factory.create(gson, TypeToken.get(AnnotatedWithTypeAdapter.class));

    assertNotNull(adapter);
    AnnotatedWithTypeAdapter value = readFromJson(adapter, "\"anything\"");
    assertNotNull(value);
  }
}
