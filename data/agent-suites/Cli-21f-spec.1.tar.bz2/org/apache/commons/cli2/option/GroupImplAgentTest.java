package org.apache.commons.cli2.option;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import junit.framework.TestCase;

import org.apache.commons.cli2.Option;
import org.apache.commons.cli2.OptionException;
import org.apache.commons.cli2.WriteableCommandLine;
import org.apache.commons.cli2.commandline.WriteableCommandLineImpl;

/**
 * Tests org.apache.commons.cli2.option.GroupImpl against its documented
 * contract.
 *
 * GroupImpl itself is used as the fixture Option for member/child options,
 * since it is the only documented, directly instantiable implementation of
 * Option available in this API: any GroupImpl is an Option (and a Group).
 */
public class GroupImplAgentTest extends TestCase {

    /** A no-op comparator, only used to satisfy signatures that require one. */
    private static final Comparator NOOP_COMPARATOR = new Comparator() {
        public int compare(Object o1, Object o2) {
            return 0;
        }
    };

    private static GroupImpl leaf(String name) {
        return new GroupImpl(Collections.EMPTY_LIST, name, name + " description", 0, 0, false);
    }

    public void testConstructorAndSimpleGetters() {
        List options = Arrays.asList(new Object[] {leaf("a"), leaf("b")});
        GroupImpl group = new GroupImpl(options, "mygroup", "my description", 1, 2, true);

        assertEquals("mygroup", group.getPreferredName());
        assertEquals("my description", group.getDescription());
        assertEquals(1, group.getMinimum());
        assertEquals(2, group.getMaximum());
        assertTrue(group.isRequired());
    }

    public void testConstructorAllowsNullName() {
        GroupImpl group = new GroupImpl(Collections.EMPTY_LIST, null, "desc", 0, 0, false);

        assertEquals("desc", group.getDescription());
        assertNotNull(group.getPrefixes());
        assertNotNull(group.getTriggers());
    }

    public void testGetOptionsReturnsProvidedNonArgumentOptions() {
        Option a = leaf("a2");
        Option b = leaf("b2");
        List options = Arrays.asList(new Object[] {a, b});
        GroupImpl group = new GroupImpl(options, "g", "d", 0, 2, false);

        List result = group.getOptions();
        assertNotNull(result);
        assertEquals(2, result.size());
        assertTrue(result.contains(a));
        assertTrue(result.contains(b));
    }

    public void testGetAnonymousEmptyWhenNoArgumentsSupplied() {
        List options = Arrays.asList(new Object[] {leaf("a3")});
        GroupImpl group = new GroupImpl(options, "g2", "d2", 0, 1, false);

        List anon = group.getAnonymous();
        assertNotNull(anon);
        assertTrue(anon.isEmpty());
    }

    public void testGetPrefixesAndTriggersAreNeverNull() {
        GroupImpl group = leaf("g3");
        assertNotNull(group.getPrefixes());
        assertNotNull(group.getTriggers());
    }

    public void testIsRequiredFalseWhenNotRequiredAndMinimumZero() {
        GroupImpl group = new GroupImpl(Collections.EMPTY_LIST, "g4", "d4", 0, 0, false);
        assertFalse(group.isRequired());
    }

    public void testIsRequiredTrueWhenMinimumPositiveEvenIfNotFlaggedRequired() {
        List options = Arrays.asList(new Object[] {leaf("a4")});
        GroupImpl group = new GroupImpl(options, "g5", "d5", 1, 1, false);

        // Documented: "we evaluate the required flag common to all options,
        // but also take the minimum constraints into account."
        assertTrue(group.isRequired());
    }

    public void pruned_testIsRequiredTrueWhenRequiredFlagTrue() {
        GroupImpl group = new GroupImpl(Collections.EMPTY_LIST, "g6", "d6", 0, 0, true);
        assertTrue(group.isRequired());
    }

    public void testFindOptionReturnsNullForUnknownTrigger() {
        List options = Arrays.asList(new Object[] {leaf("a5"), leaf("b5")});
        GroupImpl group = new GroupImpl(options, "g7", "d7", 0, 2, false);

        assertNull(group.findOption("--definitely-not-a-real-trigger-42"));
    }

    public void testValidateThrowsWhenMinimumNotMet() {
        List options = Arrays.asList(new Object[] {leaf("a6")});
        GroupImpl group = new GroupImpl(options, "g8", "d8", 1, 1, true);
        WriteableCommandLine wcli = new WriteableCommandLineImpl(group, Collections.EMPTY_LIST);

        try {
            group.validate(wcli);
            fail("Expected OptionException: minimum number of options was not met");
        } catch (OptionException expected) {
            // documented behaviour: "Throws: OptionException - if the
            // CommandLine is not valid", tied to getMinimum()'s contract.
        }
    }

    public void testValidateSucceedsWhenMinimumIsZero() {
        GroupImpl group = new GroupImpl(Collections.EMPTY_LIST, "g9", "d9", 0, 0, false);
        WriteableCommandLine wcli = new WriteableCommandLineImpl(group, Collections.EMPTY_LIST);

        try {
            group.validate(wcli);
        } catch (OptionException unexpected) {
            fail("Did not expect OptionException when minimum is zero and nothing is required");
        }
    }

    public void testDefaultsDoesNotThrowAndLeavesCommandLineUsable() {
        List options = Arrays.asList(new Object[] {leaf("a7")});
        GroupImpl group = new GroupImpl(options, "g10", "d10", 0, 1, false);
        WriteableCommandLineImpl wcli = new WriteableCommandLineImpl(group, Collections.EMPTY_LIST);

        assertTrue(wcli.getOptions().isEmpty());
        group.defaults(wcli);
        assertNotNull(wcli.getOptions());
    }

    public void testAppendUsageAppendsInformation() {
        List options = Arrays.asList(new Object[] {leaf("a8")});
        GroupImpl group = new GroupImpl(options, "grp", "d11", 1, 1, true);

        StringBuffer buffer = new StringBuffer();
        group.appendUsage(buffer, Collections.EMPTY_SET, NOOP_COMPARATOR);

        assertTrue(buffer.length() > 0);
    }

    public void testAppendUsageWithSeparatorVariantAppendsInformation() {
        List options = Arrays.asList(new Object[] {leaf("a9"), leaf("a10")});
        GroupImpl group = new GroupImpl(options, "grp2", "d12", 0, 2, false);

        StringBuffer buffer = new StringBuffer();
        group.appendUsage(buffer, Collections.EMPTY_SET, NOOP_COMPARATOR, "|");

        assertTrue(buffer.length() > 0);
    }

    public void pruned_testHelpLinesReturnsNonEmptyList() {
        List options = Arrays.asList(new Object[] {leaf("a11")});
        GroupImpl group = new GroupImpl(options, "grp3", "d13", 0, 1, false);

        List lines = group.helpLines(0, Collections.EMPTY_SET, NOOP_COMPARATOR);

        assertNotNull(lines);
        assertTrue(lines.size() >= 1);
    }

    public void testCanProcessFalseForUnrelatedArgument() {
        List options = Arrays.asList(new Object[] {leaf("a12"), leaf("b12")});
        GroupImpl group = new GroupImpl(options, "grp4", "d14", 0, 2, false);
        WriteableCommandLine wcli = new WriteableCommandLineImpl(group, Collections.EMPTY_LIST);

        assertFalse(group.canProcess(wcli, "totallyUnrelatedPlainWord"));
    }
}
