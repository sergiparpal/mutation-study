package org.apache.commons.cli2;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import junit.framework.TestCase;

import org.apache.commons.cli2.commandline.WriteableCommandLineImpl;
import org.apache.commons.cli2.option.GroupImpl;

/**
 * Tests the documented contract of the WriteableCommandLine interface
 * (org.apache.commons.cli2.WriteableCommandLine).
 *
 * Since WriteableCommandLine is an interface, and WriteableCommandLineImpl is
 * documented as its only known implementing class, instances are obtained
 * through that implementation purely as a vehicle for exercising the
 * interface's own documented methods.
 */
public class WriteableCommandLineAgentTest extends TestCase {

    private static Option leaf(String name) {
        return new GroupImpl(Collections.EMPTY_LIST, name, name + " description", 0, 0, false);
    }

    private static WriteableCommandLine newCommandLine() {
        Option root = leaf("root");
        return new WriteableCommandLineImpl(root, Collections.EMPTY_LIST);
    }

    public void testAddOptionMakesHasOptionTrue() {
        WriteableCommandLine wcli = newCommandLine();
        Option opt = leaf("opt1");

        assertFalse(wcli.hasOption(opt));
        wcli.addOption(opt);
        assertTrue(wcli.hasOption(opt));
    }

    public void testAddValueThenGetUndefaultedValuesContainsIt() {
        WriteableCommandLine wcli = newCommandLine();
        Option opt = leaf("opt2");

        assertNotNull(wcli.getUndefaultedValues(opt));
        assertTrue(wcli.getUndefaultedValues(opt).isEmpty());

        wcli.addValue(opt, "x");

        List values = wcli.getUndefaultedValues(opt);
        assertEquals(1, values.size());
        assertEquals("x", values.get(0));
    }

    public void testAddValueTwiceAccumulatesBothValues() {
        WriteableCommandLine wcli = newCommandLine();
        Option opt = leaf("opt2b");

        wcli.addValue(opt, "alpha");
        wcli.addValue(opt, "beta");

        List values = wcli.getUndefaultedValues(opt);
        assertEquals(2, values.size());
        assertTrue(values.contains("alpha"));
        assertTrue(values.contains("beta"));
    }

    public void testSetDefaultValuesAreExcludedFromUndefaultedValues() {
        WriteableCommandLine wcli = newCommandLine();
        Option opt = leaf("opt3");

        wcli.setDefaultValues(opt, Arrays.asList(new String[] {"d1", "d2"}));

        // getUndefaultedValues explicitly excludes values supplied
        // programmatically as defaults.
        List values = wcli.getUndefaultedValues(opt);
        assertNotNull(values);
        assertTrue(values.isEmpty());
    }

    public void testAddSwitchTwiceThrowsIllegalStateException() {
        WriteableCommandLine wcli = newCommandLine();
        Option opt = leaf("opt4");

        wcli.addSwitch(opt, true);
        try {
            wcli.addSwitch(opt, false);
            fail("Expected IllegalStateException when adding a switch twice for the same option");
        } catch (IllegalStateException expected) {
            // documented behaviour
        }
    }

    public void testSetCurrentOptionRoundTrip() {
        WriteableCommandLine wcli = newCommandLine();
        Option opt = leaf("opt5");

        wcli.setCurrentOption(opt);
        assertSame(opt, wcli.getCurrentOption());
    }

    public void testAddPropertyDefaultSetRoundTripAndReplace() {
        WriteableCommandLine wcli = newCommandLine();

        assertNull(wcli.getProperty("k"));

        wcli.addProperty("k", "v1");
        assertEquals("v1", wcli.getProperty("k"));

        // "Replaces any existing value for the property."
        wcli.addProperty("k", "v2");
        assertEquals("v2", wcli.getProperty("k"));
    }

    public void testAddPropertyOptionScopedRoundTrip() {
        WriteableCommandLine wcli = newCommandLine();
        Option opt = leaf("opt6");

        assertEquals("fallback", wcli.getProperty(opt, "p", "fallback"));

        wcli.addProperty(opt, "p", "v1");
        assertEquals("v1", wcli.getProperty(opt, "p", "fallback"));
    }

    public void testSetDefaultSwitchThenExplicitAddSwitchWins() {
        WriteableCommandLine wcli = newCommandLine();
        Option opt = leaf("opt7");

        wcli.setDefaultSwitch(opt, Boolean.TRUE);
        wcli.addSwitch(opt, false);

        assertEquals(Boolean.FALSE, wcli.getSwitch(opt, null));
    }

    public void testLooksLikeOptionFalseForPlainWord() {
        WriteableCommandLine wcli = newCommandLine();
        assertFalse(wcli.looksLikeOption("plainArgument"));
    }
}
