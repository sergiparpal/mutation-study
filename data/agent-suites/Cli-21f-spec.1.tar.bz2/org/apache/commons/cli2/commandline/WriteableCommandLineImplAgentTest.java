package org.apache.commons.cli2.commandline;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import junit.framework.TestCase;

import org.apache.commons.cli2.Option;
import org.apache.commons.cli2.option.GroupImpl;

/**
 * Tests org.apache.commons.cli2.commandline.WriteableCommandLineImpl against
 * its documented contract (the class javadoc, its own overridden methods, and
 * the WriteableCommandLine interface it implements).
 *
 * org.apache.commons.cli2.option.GroupImpl is used as the concrete Option
 * fixture throughout, since it is the only documented, directly instantiable
 * implementation of Option available.
 */
public class WriteableCommandLineImplAgentTest extends TestCase {

    private static Option leaf(String name) {
        return new GroupImpl(Collections.EMPTY_LIST, name, name + " description", 0, 0, false);
    }

    private static WriteableCommandLineImpl newCommandLine() {
        Option root = leaf("root");
        return new WriteableCommandLineImpl(root, Collections.EMPTY_LIST);
    }

    public void testConstructorProducesInstanceWithNoOptionsYet() {
        WriteableCommandLineImpl wcli = newCommandLine();
        assertNotNull(wcli.getOptions());
        assertTrue(wcli.getOptions().isEmpty());
    }

    public void testConstructorAcceptsNonEmptyArgumentsList() {
        Option root = leaf("root2");
        List arguments = Arrays.asList(new String[] {"--foo", "bar"});
        WriteableCommandLineImpl wcli = new WriteableCommandLineImpl(root, arguments);

        // The constructor only stores the raw arguments; it must not
        // pre-populate the option list itself.
        assertNotNull(wcli.getOptions());
        assertTrue(wcli.getOptions().isEmpty());
    }

    public void testAddOptionAndHasOptionAndGetOptions() {
        WriteableCommandLineImpl wcli = newCommandLine();
        Option opt = leaf("opt1");

        assertFalse(wcli.hasOption(opt));

        wcli.addOption(opt);

        assertTrue(wcli.hasOption(opt));
        List options = wcli.getOptions();
        assertNotNull(options);
        assertEquals(1, options.size());
        assertTrue(options.contains(opt));
    }

    public void testGetOptionUnknownTriggerReturnsNull() {
        WriteableCommandLineImpl wcli = newCommandLine();
        assertNull(wcli.getOption("--definitely-unknown-trigger-42"));
    }

    public void testAddValueAndGetUndefaultedValues() {
        WriteableCommandLineImpl wcli = newCommandLine();
        Option opt = leaf("opt2");

        assertTrue(wcli.getUndefaultedValues(opt).isEmpty());

        wcli.addValue(opt, "alpha");
        wcli.addValue(opt, "beta");

        List values = wcli.getUndefaultedValues(opt);
        assertEquals(2, values.size());
        assertTrue(values.contains("alpha"));
        assertTrue(values.contains("beta"));
    }

    public void testSetDefaultValuesExcludedFromUndefaultedValues() {
        WriteableCommandLineImpl wcli = newCommandLine();
        Option opt = leaf("opt3");

        wcli.setDefaultValues(opt, Arrays.asList(new String[] {"d1", "d2"}));

        List values = wcli.getUndefaultedValues(opt);
        assertNotNull(values);
        assertTrue(values.isEmpty());
    }

    public void testGetValuesReturnsSuppliedDefaultWhenNoneFound() {
        WriteableCommandLineImpl wcli = newCommandLine();
        Option opt = leaf("opt4");

        List defaults = Arrays.asList(new String[] {"fallback"});
        List result = wcli.getValues(opt, defaults);

        assertEquals(defaults, result);
    }

    public void testGetValuesReturnsAddedValuesRatherThanDefaultParam() {
        WriteableCommandLineImpl wcli = newCommandLine();
        Option opt = leaf("opt5");

        wcli.addValue(opt, "real");

        List result = wcli.getValues(opt, Arrays.asList(new String[] {"fallback"}));
        assertEquals(1, result.size());
        assertEquals("real", result.get(0));
    }

    public void testAddSwitchAndGetSwitch() {
        WriteableCommandLineImpl wcli = newCommandLine();
        Option opt = leaf("opt6");

        assertEquals(Boolean.FALSE, wcli.getSwitch(opt, Boolean.FALSE));

        wcli.addSwitch(opt, true);

        assertEquals(Boolean.TRUE, wcli.getSwitch(opt, Boolean.FALSE));
    }

    public void testAddSwitchTwiceThrowsIllegalStateException() {
        WriteableCommandLineImpl wcli = newCommandLine();
        Option opt = leaf("opt7");

        wcli.addSwitch(opt, true);
        try {
            wcli.addSwitch(opt, false);
            fail("Expected IllegalStateException when adding a switch twice for the same option");
        } catch (IllegalStateException expected) {
            // documented behaviour
        }
    }

    public void testGetCurrentOptionRoundTrip() {
        WriteableCommandLineImpl wcli = newCommandLine();
        Option opt = leaf("opt8");

        wcli.setCurrentOption(opt);
        assertSame(opt, wcli.getCurrentOption());
    }

    public void testDefaultPropertyRoundTripAndReplace() {
        WriteableCommandLineImpl wcli = newCommandLine();

        assertNull(wcli.getProperty("k1"));

        wcli.addProperty("k1", "v1");
        assertEquals("v1", wcli.getProperty("k1"));

        wcli.addProperty("k1", "v2");
        assertEquals("v2", wcli.getProperty("k1"));

        Set props = wcli.getProperties();
        assertNotNull(props);
        assertTrue(props.contains("k1"));
    }

    public void testOptionScopedPropertyRoundTrip() {
        WriteableCommandLineImpl wcli = newCommandLine();
        Option opt = leaf("opt9");

        assertEquals("dflt", wcli.getProperty(opt, "p1", "dflt"));

        wcli.addProperty(opt, "p1", "v1");
        assertEquals("v1", wcli.getProperty(opt, "p1", "dflt"));

        Set props = wcli.getProperties(opt);
        assertNotNull(props);
        assertTrue(props.contains("p1"));
    }

    public void testGetOptionTriggersNotNull() {
        WriteableCommandLineImpl wcli = newCommandLine();
        assertNotNull(wcli.getOptionTriggers());
    }

    public void testLooksLikeOptionFalseForPlainWord() {
        WriteableCommandLineImpl wcli = newCommandLine();
        assertFalse(wcli.looksLikeOption("plainArgument"));
    }

    public void testToStringNeverReturnsNull() {
        WriteableCommandLineImpl wcli = newCommandLine();
        assertNotNull(wcli.toString());
    }

    public void testGetNormalisedNeverReturnsNull() {
        WriteableCommandLineImpl wcli = newCommandLine();
        assertNotNull(wcli.getNormalised());
    }

    public void testSetDefaultSwitchThenExplicitAddSwitchWins() {
        WriteableCommandLineImpl wcli = newCommandLine();
        Option opt = leaf("opt10");

        wcli.setDefaultSwitch(opt, Boolean.TRUE);
        wcli.addSwitch(opt, false);

        assertEquals(Boolean.FALSE, wcli.getSwitch(opt, null));
    }
}
