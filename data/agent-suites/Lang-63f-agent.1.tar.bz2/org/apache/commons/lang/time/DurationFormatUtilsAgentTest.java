/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang.time;

import java.lang.reflect.Constructor;
import java.lang.reflect.Modifier;
import java.util.Calendar;
import java.util.TimeZone;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

/**
 * Agent-authored tests for {@link DurationFormatUtils}. These exercise the
 * public API only, asserting on the returned strings for representative
 * happy-path inputs as well as boundary (zero, negative, empty pattern) and
 * error (<code>null</code> pattern) cases.
 */
public class DurationFormatUtilsAgentTest extends TestCase {

    public static void main(String[] args) {
        TestRunner.run(suite());
    }

    public static Test suite() {
        TestSuite suite = new TestSuite(DurationFormatUtilsAgentTest.class);
        suite.setName("DurationFormatUtils Agent Tests");
        return suite;
    }

    public DurationFormatUtilsAgentTest(String name) {
        super(name);
    }

    /**
     * Builds an epoch-millis value for a wall-clock time in the GMT time zone,
     * so that periods computed from it are free of daylight-saving ambiguity.
     */
    private static long gmtMillis(int year, int month, int day, int hour, int min, int sec, int ms) {
        Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
        cal.set(year, month, day, hour, min, sec);
        cal.set(Calendar.MILLISECOND, ms);
        return cal.getTime().getTime();
    }

    // -----------------------------------------------------------------------
    public void testConstructor() {
        assertNotNull(new DurationFormatUtils());
        Constructor[] cons = DurationFormatUtils.class.getDeclaredConstructors();
        assertEquals(1, cons.length);
        assertTrue(Modifier.isPublic(cons[0].getModifiers()));
        assertTrue(Modifier.isPublic(DurationFormatUtils.class.getModifiers()));
        assertFalse(Modifier.isFinal(DurationFormatUtils.class.getModifiers()));
    }

    public void testIsoExtendedFormatPatternConstant() {
        assertEquals("'P'yyyy'Y'M'M'd'DT'H'H'm'M's.S'S'",
                DurationFormatUtils.ISO_EXTENDED_FORMAT_PATTERN);
    }

    // -----------------------------------------------------------------------
    public void testFormatDurationHMS() {
        assertEquals("0:00:00.000", DurationFormatUtils.formatDurationHMS(0L));
        assertEquals("0:00:00.001", DurationFormatUtils.formatDurationHMS(1L));
        assertEquals("0:00:00.015", DurationFormatUtils.formatDurationHMS(15L));
        assertEquals("0:00:00.165", DurationFormatUtils.formatDurationHMS(165L));
        assertEquals("0:00:01.675", DurationFormatUtils.formatDurationHMS(1675L));
        assertEquals("0:00:13.465", DurationFormatUtils.formatDurationHMS(13465L));
        assertEquals("0:01:12.789", DurationFormatUtils.formatDurationHMS(72789L));
        assertEquals("0:32:12.789", DurationFormatUtils.formatDurationHMS(12789L + 32L * 60000L));
        assertEquals("1:02:12.789", DurationFormatUtils.formatDurationHMS(12789L + 62L * 60000L));
    }

    public void testFormatDurationISO() {
        assertEquals("P0Y0M0DT0H0M0.000S", DurationFormatUtils.formatDurationISO(0L));
        assertEquals("P0Y0M0DT0H0M0.001S", DurationFormatUtils.formatDurationISO(1L));
        assertEquals("P0Y0M0DT0H0M0.010S", DurationFormatUtils.formatDurationISO(10L));
        assertEquals("P0Y0M0DT0H0M0.100S", DurationFormatUtils.formatDurationISO(100L));
        assertEquals("P0Y0M0DT0H1M15.321S", DurationFormatUtils.formatDurationISO(75321L));
    }

    // -----------------------------------------------------------------------
    public void testFormatDurationSingleFields() {
        long zero = 0L;
        assertEquals("0", DurationFormatUtils.formatDuration(zero, "y"));
        assertEquals("0", DurationFormatUtils.formatDuration(zero, "M"));
        assertEquals("0", DurationFormatUtils.formatDuration(zero, "d"));
        assertEquals("0", DurationFormatUtils.formatDuration(zero, "H"));
        assertEquals("0", DurationFormatUtils.formatDuration(zero, "m"));
        assertEquals("0", DurationFormatUtils.formatDuration(zero, "s"));
        assertEquals("0", DurationFormatUtils.formatDuration(zero, "S"));
        assertEquals("0000", DurationFormatUtils.formatDuration(zero, "SSSS"));
        assertEquals("0000", DurationFormatUtils.formatDuration(zero, "yyyy"));
        assertEquals("0000", DurationFormatUtils.formatDuration(zero, "yyMM"));

        long oneMinute = 60L * 1000L;
        assertEquals("0", DurationFormatUtils.formatDuration(oneMinute, "y"));
        assertEquals("0", DurationFormatUtils.formatDuration(oneMinute, "d"));
        assertEquals("0", DurationFormatUtils.formatDuration(oneMinute, "H"));
        assertEquals("1", DurationFormatUtils.formatDuration(oneMinute, "m"));
        assertEquals("60", DurationFormatUtils.formatDuration(oneMinute, "s"));
        assertEquals("60000", DurationFormatUtils.formatDuration(oneMinute, "S"));
        assertEquals("01:00", DurationFormatUtils.formatDuration(oneMinute, "mm:ss"));
    }

    public void testFormatDurationPadWithZerosFlag() {
        assertEquals("01:00", DurationFormatUtils.formatDuration(60L * 1000L, "mm:ss", true));
        assertEquals("1:0", DurationFormatUtils.formatDuration(60L * 1000L, "mm:ss", false));
        assertEquals("001", DurationFormatUtils.formatDuration(1L, "SSS", true));
        assertEquals("1", DurationFormatUtils.formatDuration(1L, "SSS", false));
    }

    public void testFormatDurationDayField() {
        // 2000-01-01 -> 2003-02-01 in GMT is exactly (366 + 365 + 365 + 31) days.
        long duration = gmtMillis(2003, Calendar.FEBRUARY, 1, 0, 0, 0, 0)
                - gmtMillis(2000, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals("0 0 1127", DurationFormatUtils.formatDuration(duration, "y M d"));
    }

    public void testFormatDurationNegativeDuration() {
        assertEquals("-1", DurationFormatUtils.formatDuration(-3600000L, "H"));
        assertEquals("-1", DurationFormatUtils.formatDuration(-1L, "S"));
    }

    public void testFormatDurationEmptyAndLiteralPattern() {
        assertEquals("", DurationFormatUtils.formatDuration(123456L, ""));
        assertEquals("literal", DurationFormatUtils.formatDuration(0L, "'literal'"));
        // 'H' is consumed as an hours token; the trailing letters are literal text.
        assertEquals("0ello", DurationFormatUtils.formatDuration(0L, "Hello"));
    }

    public void testFormatDurationNullPatternThrowsNPE() {
        try {
            DurationFormatUtils.formatDuration(1000L, null);
            fail("Expected NullPointerException for a null format pattern");
        } catch (NullPointerException expected) {
            // expected
        }
        try {
            DurationFormatUtils.formatDuration(1000L, null, false);
            fail("Expected NullPointerException for a null format pattern");
        } catch (NullPointerException expected) {
            // expected
        }
    }

    // -----------------------------------------------------------------------
    public void testFormatDurationWordsLeadingAndTrailingSuppression() {
        assertEquals("50 seconds",
                DurationFormatUtils.formatDurationWords(50L * 1000L, true, false));
        assertEquals("1 minute 5 seconds",
                DurationFormatUtils.formatDurationWords(65L * 1000L, true, false));
        assertEquals("2 minutes 0 seconds",
                DurationFormatUtils.formatDurationWords(120L * 1000L, true, false));
        assertEquals("2 minutes 1 second",
                DurationFormatUtils.formatDurationWords(121L * 1000L, true, false));

        assertEquals("2 minutes",
                DurationFormatUtils.formatDurationWords(120L * 1000L, true, true));
        assertEquals("1 hour 12 minutes",
                DurationFormatUtils.formatDurationWords(72L * 60L * 1000L, true, true));
        assertEquals("1 day",
                DurationFormatUtils.formatDurationWords(24L * 60L * 60L * 1000L, true, true));

        assertEquals("0 days 0 hours 0 minutes 50 seconds",
                DurationFormatUtils.formatDurationWords(50L * 1000L, false, false));
        assertEquals("0 days 1 hour 12 minutes",
                DurationFormatUtils.formatDurationWords(72L * 60L * 1000L, false, true));
        assertEquals("1 day 1 hour 12 minutes 0 seconds",
                DurationFormatUtils.formatDurationWords(24L * 60L * 60L * 1000L + 72L * 60L * 1000L, false, false));
    }

    public void testFormatDurationWordsPluralisation() {
        long oneSecond = 1000L;
        long oneMinute = oneSecond * 60L;
        long oneHour = oneMinute * 60L;
        long oneDay = oneHour * 24L;

        assertEquals("0 days 0 hours 0 minutes 1 second",
                DurationFormatUtils.formatDurationWords(oneSecond, false, false));
        assertEquals("0 days 0 hours 0 minutes 11 seconds",
                DurationFormatUtils.formatDurationWords(oneSecond * 11L, false, false));
        assertEquals("0 days 1 hour 0 minutes 0 seconds",
                DurationFormatUtils.formatDurationWords(oneHour, false, false));
        assertEquals("1 day 1 hour 1 minute 1 second",
                DurationFormatUtils.formatDurationWords(oneDay + oneHour + oneMinute + oneSecond, false, false));
    }

    public void testFormatDurationWordsNegativeDuration() {
        assertEquals("0 days 0 hours 0 minutes -1 seconds",
                DurationFormatUtils.formatDurationWords(-1000L, false, false));
    }

    // -----------------------------------------------------------------------
    public void testFormatPeriodZeroLength() {
        long t = gmtMillis(1970, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals("0", DurationFormatUtils.formatPeriod(t, t, "y"));
        assertEquals("0", DurationFormatUtils.formatPeriod(t, t, "M"));
        assertEquals("0", DurationFormatUtils.formatPeriod(t, t, "d"));
        assertEquals("0", DurationFormatUtils.formatPeriod(t, t, "H"));
        assertEquals("0", DurationFormatUtils.formatPeriod(t, t, "m"));
        assertEquals("0", DurationFormatUtils.formatPeriod(t, t, "s"));
        assertEquals("0", DurationFormatUtils.formatPeriod(t, t, "S"));
        assertEquals("0000", DurationFormatUtils.formatPeriod(t, t, "SSSS"));
    }

    public void testFormatPeriodShortDurationDelegatesToFormatDuration() {
        long start = gmtMillis(2000, Calendar.JUNE, 1, 0, 0, 0, 0);
        long end = start + 60L * 1000L;
        assertEquals("1", DurationFormatUtils.formatPeriod(start, end, "m"));
        assertEquals("60", DurationFormatUtils.formatPeriod(start, end, "s"));
        assertEquals("60000", DurationFormatUtils.formatPeriod(start, end, "S"));
        assertEquals("01:00", DurationFormatUtils.formatPeriod(start, end, "mm:ss"));
    }

    public void testFormatPeriodEndBeforeStart() {
        long start = gmtMillis(2000, Calendar.JUNE, 1, 0, 0, 0, 0);
        assertEquals("-1", DurationFormatUtils.formatPeriod(start, start - 1000L, "s"));
    }

    public void testFormatPeriodLongDurationAllFields() {
        TimeZone gmt = TimeZone.getTimeZone("GMT");
        long start = gmtMillis(2000, Calendar.JANUARY, 1, 0, 0, 0, 0);
        long end = gmtMillis(2001, Calendar.MARCH, 15, 10, 30, 45, 500);
        assertEquals("1 2 14 10 30 45 500",
                DurationFormatUtils.formatPeriod(start, end, "y M d H m s S", false, gmt));
        assertEquals("01 02 14 10 30 45 500",
                DurationFormatUtils.formatPeriod(start, end, "yy MM dd HH mm ss SSS", true, gmt));
    }

    public void testFormatPeriodExcessMonthsAndYears() {
        TimeZone gmt = TimeZone.getTimeZone("GMT");
        long start = gmtMillis(1970, Calendar.JANUARY, 1, 0, 0, 0, 0);
        long midYear = gmtMillis(1973, Calendar.JULY, 1, 0, 0, 0, 0);
        long fourYears = gmtMillis(1974, Calendar.JANUARY, 1, 0, 0, 0, 0);

        assertEquals("36", DurationFormatUtils.formatPeriod(start, midYear, "yM", false, gmt));
        assertEquals("3 years 6 months",
                DurationFormatUtils.formatPeriod(start, midYear, "y' years 'M' months'", false, gmt));
        assertEquals("03/06", DurationFormatUtils.formatPeriod(start, midYear, "yy/MM", true, gmt));

        assertEquals("40", DurationFormatUtils.formatPeriod(start, fourYears, "yM", false, gmt));
        // "M" without a "y" token accumulates the years into the month count.
        assertEquals("48", DurationFormatUtils.formatPeriod(start, fourYears, "M", false, gmt));
        assertEquals("048", DurationFormatUtils.formatPeriod(start, fourYears, "MMM", true, gmt));
    }

    public void testFormatPeriodISOWithExplicitTimeZone() {
        TimeZone tz = TimeZone.getTimeZone("GMT-3");
        Calendar base = Calendar.getInstance(tz);
        base.set(1970, Calendar.JANUARY, 1, 0, 0, 0);
        base.set(Calendar.MILLISECOND, 0);

        Calendar cal = Calendar.getInstance(tz);
        cal.set(2002, Calendar.FEBRUARY, 23, 9, 11, 12);
        cal.set(Calendar.MILLISECOND, 1);
        assertEquals("P32Y1M22DT9H11M12.001S", DurationFormatUtils.formatPeriod(
                base.getTime().getTime(), cal.getTime().getTime(),
                DurationFormatUtils.ISO_EXTENDED_FORMAT_PATTERN, false, tz));

        cal.set(1971, Calendar.FEBRUARY, 3, 10, 30, 0);
        cal.set(Calendar.MILLISECOND, 0);
        assertEquals("P1Y1M2DT10H30M0.000S", DurationFormatUtils.formatPeriod(
                base.getTime().getTime(), cal.getTime().getTime(),
                DurationFormatUtils.ISO_EXTENDED_FORMAT_PATTERN, false, tz));
    }

    public void testFormatPeriodISOConvenienceMethod() {
        // Short periods delegate to formatDuration, so they are time-zone independent.
        assertEquals("P0Y0M0DT0H0M0.000S", DurationFormatUtils.formatPeriodISO(0L, 0L));
        assertEquals("P0Y0M0DT0H1M15.321S", DurationFormatUtils.formatPeriodISO(0L, 75321L));

        // A whole calendar year: both endpoints share the platform's January
        // (standard-time) UTC offset, so the elapsed period is exactly one year.
        Calendar startCal = Calendar.getInstance();
        startCal.set(2000, Calendar.JANUARY, 1, 0, 0, 0);
        startCal.set(Calendar.MILLISECOND, 0);
        Calendar endCal = Calendar.getInstance();
        endCal.set(2001, Calendar.JANUARY, 1, 0, 0, 0);
        endCal.set(Calendar.MILLISECOND, 0);
        assertEquals("P1Y0M0DT0H0M0.000S", DurationFormatUtils.formatPeriodISO(
                startCal.getTime().getTime(), endCal.getTime().getTime()));
    }

    public void testFormatPeriodNullPatternThrowsNPE() {
        try {
            DurationFormatUtils.formatPeriod(0L, 1000L, null);
            fail("Expected NullPointerException for a null format pattern");
        } catch (NullPointerException expected) {
            // expected
        }
    }

    // -----------------------------------------------------------------------
    // Month count across a year boundary (2005-12-31 -> 2006-10-06 is 9 months).
    public void testFormatPeriodMonthsAcrossYearBoundary() {
        Calendar start = Calendar.getInstance();
        start.set(2005, Calendar.DECEMBER, 31, 0, 0, 0);
        start.set(Calendar.MILLISECOND, 0);
        Calendar end = Calendar.getInstance();
        end.set(2006, Calendar.OCTOBER, 6, 0, 0, 0);
        end.set(Calendar.MILLISECOND, 0);
        assertEquals("09", DurationFormatUtils.formatPeriod(
                start.getTime().getTime(), end.getTime().getTime(), "MM"));
    }

    // Day/hour borrow across a month boundary: 2006-01-26 18:47:34 -> 2006-02-26
    // 10:47:34 is 30 days and 16 hours (both dates are in standard time here).
    public void testFormatPeriodDayHourBorrow() {
        Calendar start = Calendar.getInstance();
        start.set(2006, Calendar.JANUARY, 26, 18, 47, 34);
        start.set(Calendar.MILLISECOND, 0);
        Calendar end = Calendar.getInstance();
        end.set(2006, Calendar.FEBRUARY, 26, 10, 47, 34);
        end.set(Calendar.MILLISECOND, 0);
        assertEquals("0000/00/30 16:00:00 000", DurationFormatUtils.formatPeriod(
                start.getTime().getTime(), end.getTime().getTime(), "yyyy/MM/dd HH:mm:ss SSS"));
    }
}
