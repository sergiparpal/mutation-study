package com.google.gson.internal;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.google.gson.InstanceCreator;
import com.google.gson.reflect.TypeToken;

import junit.framework.TestCase;

/**
 * Self-contained tests for {@link ConstructorConstructor} based solely on the
 * documented contract: it is constructed from a map of {@link Type} to
 * {@link InstanceCreator}, and its {@code get} method returns an
 * {@link ObjectConstructor} able to build instances of the requested type.
 */
public class ConstructorConstructorAgentTest extends TestCase {

    // A plain class with an accessible public no-arg constructor.
    public static class PlainPublic {
        public PlainPublic() {
        }
    }

    // A plain class whose only constructor is private; Gson's construction
    // machinery is expected to still be able to produce instances of it,
    // since the contract promises construction of "a requested type" without
    // qualifying constructor visibility.
    public static class PlainPrivate {
        private PlainPrivate() {
        }
    }

    // Simple marker type used to verify that a registered InstanceCreator is
    // actually consulted (via reference identity of the returned instance).
    public static class Marker {
        final int id;

        Marker(int id) {
            this.id = id;
        }
    }

    // Records the Type it was asked to create, and always returns a fixed
    // instance so identity can be checked by the caller.
    private static class RecordingCreator implements InstanceCreator<Marker> {
        final Marker instanceToReturn;
        Type lastRequestedType;

        RecordingCreator(Marker instanceToReturn) {
            this.instanceToReturn = instanceToReturn;
        }

        public Marker createInstance(Type type) {
            this.lastRequestedType = type;
            return instanceToReturn;
        }
    }

    private static Map<Type, InstanceCreator<?>> emptyCreators() {
        return new HashMap<Type, InstanceCreator<?>>();
    }

    public void testGetReturnsNonNullObjectConstructorForPlainClass() {
        ConstructorConstructor cc = new ConstructorConstructor(emptyCreators());
        ObjectConstructor<PlainPublic> objectConstructor = cc.get(TypeToken.get(PlainPublic.class));
        assertNotNull(objectConstructor);
    }

    public void testConstructUsingPublicNoArgConstructorProducesCorrectType() {
        ConstructorConstructor cc = new ConstructorConstructor(emptyCreators());
        ObjectConstructor<PlainPublic> objectConstructor = cc.get(TypeToken.get(PlainPublic.class));
        PlainPublic instance = objectConstructor.construct();
        assertNotNull(instance);
        assertTrue(instance instanceof PlainPublic);
    }

    public void testConstructProducesIndependentInstancesEachCall() {
        ConstructorConstructor cc = new ConstructorConstructor(emptyCreators());
        ObjectConstructor<PlainPublic> objectConstructor = cc.get(TypeToken.get(PlainPublic.class));
        PlainPublic first = objectConstructor.construct();
        PlainPublic second = objectConstructor.construct();
        assertNotNull(first);
        assertNotNull(second);
        assertTrue(first != second);
    }

    public void testExactTypeInstanceCreatorIsUsedForConstruction() {
        Marker marker = new Marker(7);
        RecordingCreator creator = new RecordingCreator(marker);
        Map<Type, InstanceCreator<?>> creators = new HashMap<Type, InstanceCreator<?>>();
        creators.put(Marker.class, creator);

        ConstructorConstructor cc = new ConstructorConstructor(creators);
        ObjectConstructor<Marker> objectConstructor = cc.get(TypeToken.get(Marker.class));
        Marker constructed = objectConstructor.construct();

        assertSame(marker, constructed);
    }

    public void testInstanceCreatorReceivesRequestedType() {
        Marker marker = new Marker(9);
        RecordingCreator creator = new RecordingCreator(marker);
        Map<Type, InstanceCreator<?>> creators = new HashMap<Type, InstanceCreator<?>>();
        creators.put(Marker.class, creator);

        ConstructorConstructor cc = new ConstructorConstructor(creators);
        ObjectConstructor<Marker> objectConstructor = cc.get(TypeToken.get(Marker.class));
        objectConstructor.construct();

        assertEquals(Marker.class, creator.lastRequestedType);
    }

    public void testUnrelatedInstanceCreatorEntryIsIgnored() {
        Marker marker = new Marker(1);
        RecordingCreator creator = new RecordingCreator(marker);
        Map<Type, InstanceCreator<?>> creators = new HashMap<Type, InstanceCreator<?>>();
        // Registered only for Marker.class, not for the type we request below.
        creators.put(Marker.class, creator);

        ConstructorConstructor cc = new ConstructorConstructor(creators);
        ObjectConstructor<PlainPublic> objectConstructor = cc.get(TypeToken.get(PlainPublic.class));
        PlainPublic instance = objectConstructor.construct();

        assertNotNull(instance);
        assertTrue(instance instanceof PlainPublic);
        assertNull(creator.lastRequestedType);
    }

    public void testPrivateNoArgConstructorIsUsableWhenNoCreatorRegistered() {
        ConstructorConstructor cc = new ConstructorConstructor(emptyCreators());
        ObjectConstructor<PlainPrivate> objectConstructor = cc.get(TypeToken.get(PlainPrivate.class));
        PlainPrivate instance = objectConstructor.construct();
        assertNotNull(instance);
        assertTrue(instance instanceof PlainPrivate);
    }

    public void testListInterfaceProducesAssignableInstance() {
        ConstructorConstructor cc = new ConstructorConstructor(emptyCreators());
        ObjectConstructor<List> objectConstructor = cc.get(TypeToken.get(List.class));
        List instance = objectConstructor.construct();
        assertNotNull(instance);
        assertTrue(instance instanceof List);
    }

    public void testMapInterfaceProducesAssignableInstance() {
        ConstructorConstructor cc = new ConstructorConstructor(emptyCreators());
        ObjectConstructor<Map> objectConstructor = cc.get(TypeToken.get(Map.class));
        Map instance = objectConstructor.construct();
        assertNotNull(instance);
        assertTrue(instance instanceof Map);
    }

    public void testSetInterfaceProducesAssignableInstance() {
        ConstructorConstructor cc = new ConstructorConstructor(emptyCreators());
        ObjectConstructor<Set> objectConstructor = cc.get(TypeToken.get(Set.class));
        Set instance = objectConstructor.construct();
        assertNotNull(instance);
        assertTrue(instance instanceof Set);
    }

    public void testGetWithNullTypeTokenFails() {
        ConstructorConstructor cc = new ConstructorConstructor(emptyCreators());
        try {
            cc.<Object>get(null);
            fail("Expected an exception when passing a null TypeToken");
        } catch (RuntimeException expected) {
            // The method's signature declares no checked exceptions, so any
            // failure here must surface as an unchecked exception; a null
            // description of "the requested type" cannot be resolved.
        }
    }

    public void testToStringReturnsNonNullAndIsStable() {
        ConstructorConstructor cc = new ConstructorConstructor(emptyCreators());
        String first = cc.toString();
        String second = cc.toString();
        assertNotNull(first);
        assertEquals(first, second);
    }
}
