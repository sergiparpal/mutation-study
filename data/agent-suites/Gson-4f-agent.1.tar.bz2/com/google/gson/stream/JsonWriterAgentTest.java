/*
 * Copyright (C) 2014 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.gson.stream;

import java.io.IOException;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.math.BigInteger;
import junit.framework.TestCase;

/**
 * Unit tests for {@link JsonWriter} covering its public API, including
 * boundary and error conditions.
 */
public final class JsonWriterAgentTest extends TestCase {

  public void testConstructorWithNullThrows() {
    try {
      new JsonWriter(null);
      fail();
    } catch (NullPointerException expected) {
    }
  }

  public void testDefaultFlags() {
    JsonWriter writer = new JsonWriter(new StringWriter());
    assertFalse(writer.isLenient());
    assertFalse(writer.isHtmlSafe());
    assertTrue(writer.getSerializeNulls());
  }

  public void testFlagSettersReturnConfiguredValues() {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.setLenient(true);
    assertTrue(writer.isLenient());
    writer.setHtmlSafe(true);
    assertTrue(writer.isHtmlSafe());
    writer.setSerializeNulls(false);
    assertFalse(writer.getSerializeNulls());
  }

  public void testWriteEmptyArray() throws IOException {
    StringWriter out = new StringWriter();
    JsonWriter writer = new JsonWriter(out);
    JsonWriter returned = writer.beginArray();
    assertSame(writer, returned);
    writer.endArray();
    writer.close();
    assertEquals("[]", out.toString());
  }

  public void testWriteEmptyObject() throws IOException {
    StringWriter out = new StringWriter();
    JsonWriter writer = new JsonWriter(out);
    writer.beginObject();
    writer.endObject();
    writer.close();
    assertEquals("{}", out.toString());
  }

  public void testWriteObjectWithNamedValues() throws IOException {
    StringWriter out = new StringWriter();
    JsonWriter writer = new JsonWriter(out);
    writer.beginObject();
    JsonWriter afterName = writer.name("a");
    assertSame(writer, afterName);
    writer.value(1);
    writer.name("b");
    writer.value("banana");
    writer.endObject();
    writer.close();
    assertEquals("{\"a\":1,\"b\":\"banana\"}", out.toString());
  }

  public void testWriteAllScalarTypes() throws IOException {
    StringWriter out = new StringWriter();
    JsonWriter writer = new JsonWriter(out);
    writer.beginArray();
    writer.value("s");
    writer.value(true);
    writer.value(1.5);
    writer.value(5L);
    writer.value(new BigDecimal("3.14"));
    writer.value((String) null);
    writer.value((Number) null);
    writer.nullValue();
    writer.endArray();
    writer.close();
    assertEquals("[\"s\",true,1.5,5,3.14,null,null,null]", out.toString());
  }

  public void testValueBigIntegerAndBigDecimal() throws IOException {
    StringWriter out = new StringWriter();
    JsonWriter writer = new JsonWriter(out);
    writer.beginArray();
    writer.value(new BigInteger("123456789012345678901234567890"));
    writer.value(new BigDecimal("1.000"));
    writer.endArray();
    writer.close();
    assertEquals("[123456789012345678901234567890,1.000]", out.toString());
  }

  public void testJsonValueWritesRawText() throws IOException {
    StringWriter out = new StringWriter();
    JsonWriter writer = new JsonWriter(out);
    writer.beginArray();
    writer.jsonValue("{\"x\":1}");
    writer.endArray();
    writer.close();
    assertEquals("[{\"x\":1}]", out.toString());
  }

  public void testJsonValueWithNullWritesNullLiteral() throws IOException {
    StringWriter out = new StringWriter();
    JsonWriter writer = new JsonWriter(out);
    writer.beginArray();
    writer.jsonValue(null);
    writer.endArray();
    writer.close();
    assertEquals("[null]", out.toString());
  }

  public void testStringEscaping() throws IOException {
    StringWriter out = new StringWriter();
    JsonWriter writer = new JsonWriter(out);
    writer.beginArray();
    writer.value("a\"b\\c\td\ne");
    writer.endArray();
    writer.close();
    assertEquals("[\"a\\\"b\\\\c\\td\\ne\"]", out.toString());
  }

  public void testControlCharacterIsEscapedAsUnicode() throws IOException {
    StringWriter out = new StringWriter();
    JsonWriter writer = new JsonWriter(out);
    writer.beginArray();
    writer.value("\u0001");
    writer.endArray();
    writer.close();
    assertEquals("[\"\\u0001\"]", out.toString());
  }

  public void testHtmlSafeEscapesSpecialCharacters() throws IOException {
    StringWriter out = new StringWriter();
    JsonWriter writer = new JsonWriter(out);
    writer.setHtmlSafe(true);
    writer.beginArray();
    writer.value("<>&='");
    writer.endArray();
    writer.close();
    assertEquals("[\"\\u003c\\u003e\\u0026\\u003d\\u0027\"]", out.toString());
  }

  public void testNotHtmlSafeLeavesSpecialCharactersUnescaped() throws IOException {
    StringWriter out = new StringWriter();
    JsonWriter writer = new JsonWriter(out);
    writer.beginArray();
    writer.value("<>&='");
    writer.endArray();
    writer.close();
    assertEquals("[\"<>&='\"]", out.toString());
  }

  public void testSetIndentPrettyPrints() throws IOException {
    StringWriter out = new StringWriter();
    JsonWriter writer = new JsonWriter(out);
    writer.setIndent("  ");
    writer.beginObject();
    writer.name("a");
    writer.value(1);
    writer.endObject();
    writer.close();
    assertEquals("{\n  \"a\": 1\n}", out.toString());
  }

  public void testSetIndentEmptyStringIsCompact() throws IOException {
    StringWriter out = new StringWriter();
    JsonWriter writer = new JsonWriter(out);
    writer.setIndent("\t");
    writer.setIndent("");
    writer.beginObject();
    writer.name("a");
    writer.value(1);
    writer.endObject();
    writer.close();
    assertEquals("{\"a\":1}", out.toString());
  }

  public void testNullValueSkipsMemberWhenSerializeNullsDisabled() throws IOException {
    StringWriter out = new StringWriter();
    JsonWriter writer = new JsonWriter(out);
    writer.setSerializeNulls(false);
    writer.beginObject();
    writer.name("a");
    writer.nullValue();
    writer.name("b");
    writer.value(1);
    writer.endObject();
    writer.close();
    assertEquals("{\"b\":1}", out.toString());
  }

  public void testNullValueInArrayIsAlwaysWritten() throws IOException {
    StringWriter out = new StringWriter();
    JsonWriter writer = new JsonWriter(out);
    writer.setSerializeNulls(false);
    writer.beginArray();
    writer.nullValue();
    writer.value(1);
    writer.endArray();
    writer.close();
    assertEquals("[null,1]", out.toString());
  }

  public void testNameWithNullThrows() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginObject();
    try {
      writer.name(null);
      fail();
    } catch (NullPointerException expected) {
    }
  }

  public void testTwoNamesInARowThrows() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginObject();
    writer.name("a");
    try {
      writer.name("b");
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testNameOutsideOfObjectThrows() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.name("a");
    try {
      writer.value(1);
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testEndObjectWithDanglingNameThrows() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginObject();
    writer.name("a");
    try {
      writer.endObject();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testEndArrayMismatchedWithBeginObjectThrows() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginObject();
    try {
      writer.endArray();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testEndObjectMismatchedWithBeginArrayThrows() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginArray();
    try {
      writer.endObject();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testDoubleNanThrowsInStrictMode() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginArray();
    try {
      writer.value(Double.NaN);
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  public void testDoubleInfiniteThrowsInStrictMode() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginArray();
    try {
      writer.value(Double.POSITIVE_INFINITY);
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  public void testDoubleNanRejectedEvenWhenLenient() throws IOException {
    // Unlike value(Number), the value(double) overload rejects non-finite
    // values regardless of the lenient setting.
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.setLenient(true);
    writer.beginArray();
    try {
      writer.value(Double.NaN);
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  public void testNumberValueOfSpecialDoubleAcceptedWhenLenient() throws IOException {
    StringWriter out = new StringWriter();
    JsonWriter writer = new JsonWriter(out);
    writer.setLenient(true);
    writer.beginArray();
    writer.value((Number) Double.valueOf(Double.NaN));
    writer.value((Number) Double.valueOf(Double.NEGATIVE_INFINITY));
    writer.value((Number) Double.valueOf(Double.POSITIVE_INFINITY));
    writer.endArray();
    assertEquals("[NaN,-Infinity,Infinity]", out.toString());
  }

  public void testNumberValueOfSpecialDoubleThrowsInStrictMode() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginArray();
    try {
      writer.value((Number) Double.valueOf(Double.NaN));
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  public void testMultipleTopLevelValuesThrowInStrictMode() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.value(1);
    try {
      writer.value(2);
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testMultipleTopLevelValuesAcceptedWhenLenient() throws IOException {
    StringWriter out = new StringWriter();
    JsonWriter writer = new JsonWriter(out);
    writer.setLenient(true);
    writer.value(1);
    writer.value(2);
    assertEquals("12", out.toString());
  }

  public void testCloseWithIncompleteDocumentThrows() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginArray();
    writer.value(1);
    try {
      writer.close();
      fail();
    } catch (IOException expected) {
    }
  }

  public void testCloseWithNothingWrittenThrows() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    try {
      writer.close();
      fail();
    } catch (IOException expected) {
    }
  }

  public void testFlushAfterCloseThrows() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginArray();
    writer.endArray();
    writer.close();
    try {
      writer.flush();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testOperationsAfterCloseThrow() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginArray();
    writer.endArray();
    writer.close();
    try {
      writer.beginArray();
      fail();
    } catch (IllegalStateException expected) {
    }
    try {
      writer.name("a");
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testFlushWhileOpenWritesBufferedData() throws IOException {
    StringWriter out = new StringWriter();
    JsonWriter writer = new JsonWriter(out);
    writer.beginArray();
    writer.value(1);
    writer.flush();
    assertEquals("[1", out.toString());
    writer.endArray();
    writer.close();
    assertEquals("[1]", out.toString());
  }

  public void testNestedArraysAndObjects() throws IOException {
    StringWriter out = new StringWriter();
    JsonWriter writer = new JsonWriter(out);
    writer.beginObject();
    writer.name("a");
    writer.beginArray();
    writer.beginObject();
    writer.name("b");
    writer.value(1);
    writer.endObject();
    writer.endArray();
    writer.endObject();
    writer.close();
    assertEquals("{\"a\":[{\"b\":1}]}", out.toString());
  }
}
