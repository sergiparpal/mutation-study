/*
 * Copyright (C) 2014 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.gson.stream;

import java.io.EOFException;
import java.io.IOException;
import java.io.StringReader;
import junit.framework.TestCase;

/**
 * Unit tests for {@link JsonReader} covering its public API, including
 * boundary and error conditions.
 */
@SuppressWarnings("resource")
public final class JsonReaderAgentTest extends TestCase {

  public void testConstructorWithNullThrows() {
    try {
      new JsonReader(null);
      fail();
    } catch (NullPointerException expected) {
    }
  }

  public void testLenientDefaultsToFalse() {
    JsonReader reader = new JsonReader(new StringReader("[]"));
    assertFalse(reader.isLenient());
    reader.setLenient(true);
    assertTrue(reader.isLenient());
    reader.setLenient(false);
    assertFalse(reader.isLenient());
  }

  public void testReadEmptyArray() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[]"));
    reader.beginArray();
    assertFalse(reader.hasNext());
    reader.endArray();
    assertEquals(JsonToken.END_DOCUMENT, reader.peek());
  }

  public void testReadArrayOfBooleans() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[true, false]"));
    reader.beginArray();
    assertTrue(reader.hasNext());
    assertEquals(JsonToken.BOOLEAN, reader.peek());
    assertTrue(reader.nextBoolean());
    assertFalse(reader.nextBoolean());
    assertFalse(reader.hasNext());
    reader.endArray();
  }

  public void testReadObject() throws IOException {
    JsonReader reader = new JsonReader(
        new StringReader("{\"a\": \"android\", \"b\": \"banana\"}"));
    reader.beginObject();
    assertEquals(JsonToken.NAME, reader.peek());
    assertEquals("a", reader.nextName());
    assertEquals("android", reader.nextString());
    assertEquals("b", reader.nextName());
    assertEquals("banana", reader.nextString());
    assertFalse(reader.hasNext());
    reader.endObject();
    assertEquals(JsonToken.END_DOCUMENT, reader.peek());
  }

  public void testReadEmptyObject() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("{}"));
    reader.beginObject();
    assertFalse(reader.hasNext());
    reader.endObject();
  }

  public void testPeekReturnsEveryTokenType() throws IOException {
    JsonReader reader = new JsonReader(
        new StringReader("{\"a\":[1,2.5,\"s\",true,null]}"));
    assertEquals(JsonToken.BEGIN_OBJECT, reader.peek());
    reader.beginObject();
    assertEquals(JsonToken.NAME, reader.peek());
    reader.nextName();
    assertEquals(JsonToken.BEGIN_ARRAY, reader.peek());
    reader.beginArray();
    assertEquals(JsonToken.NUMBER, reader.peek());
    assertEquals(1, reader.nextInt());
    assertEquals(JsonToken.NUMBER, reader.peek());
    assertEquals(2.5, reader.nextDouble());
    assertEquals(JsonToken.STRING, reader.peek());
    assertEquals("s", reader.nextString());
    assertEquals(JsonToken.BOOLEAN, reader.peek());
    assertTrue(reader.nextBoolean());
    assertEquals(JsonToken.NULL, reader.peek());
    reader.nextNull();
    assertEquals(JsonToken.END_ARRAY, reader.peek());
    reader.endArray();
    assertEquals(JsonToken.END_OBJECT, reader.peek());
    reader.endObject();
    assertEquals(JsonToken.END_DOCUMENT, reader.peek());
  }

  public void testNextStringReturnsNumberAsString() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[12345]"));
    reader.beginArray();
    assertEquals("12345", reader.nextString());
  }

  public void testNextStringOnBooleanThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[true]"));
    reader.beginArray();
    try {
      reader.nextString();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testNextNameOnNonNameThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1]"));
    reader.beginArray();
    try {
      reader.nextName();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testNextBooleanOnNonBooleanThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1]"));
    reader.beginArray();
    try {
      reader.nextBoolean();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testNextNullConsumesNull() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[null]"));
    reader.beginArray();
    reader.nextNull();
    assertFalse(reader.hasNext());
  }

  public void testNextNullOnNonNullThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1]"));
    reader.beginArray();
    try {
      reader.nextNull();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testNextDoubleFromQuotedString() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[\"1.5\"]"));
    reader.beginArray();
    assertEquals(1.5, reader.nextDouble());
  }

  public void testNextDoubleRejectsNanInStrictMode() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[\"NaN\"]"));
    reader.beginArray();
    try {
      reader.nextDouble();
      fail();
    } catch (MalformedJsonException expected) {
    }
  }

  public void testNextDoubleAcceptsNanWhenLenient() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[NaN]"));
    reader.setLenient(true);
    reader.beginArray();
    assertTrue(Double.isNaN(reader.nextDouble()));
  }

  public void testNextLongReturnsExactValue() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[123456789012]"));
    reader.beginArray();
    assertEquals(123456789012L, reader.nextLong());
  }

  public void testNextLongFromQuotedString() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[\"123\"]"));
    reader.beginArray();
    assertEquals(123L, reader.nextLong());
  }

  public void testNextLongTooPreciseForLongThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1e400]"));
    reader.beginArray();
    try {
      reader.nextLong();
      fail();
    } catch (NumberFormatException expected) {
    }
  }

  public void testNextIntReturnsExactValue() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[2147483647]"));
    reader.beginArray();
    assertEquals(2147483647, reader.nextInt());
  }

  public void testNextIntFromQuotedString() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[\"45\"]"));
    reader.beginArray();
    assertEquals(45, reader.nextInt());
  }

  public void testNextIntTooBigThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[3147483647]"));
    reader.beginArray();
    try {
      reader.nextInt();
      fail();
    } catch (NumberFormatException expected) {
    }
  }

  public void testBeginArrayOnObjectThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("{}"));
    try {
      reader.beginArray();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testBeginObjectOnArrayThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[]"));
    try {
      reader.beginObject();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testEndArrayBeforeExhaustingElementsThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1,2]"));
    reader.beginArray();
    try {
      reader.endArray();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testEndObjectBeforeExhaustingElementsThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("{\"a\":1}"));
    reader.beginObject();
    try {
      reader.endObject();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testSkipValueSkipsArrayElement() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1,2,3]"));
    reader.beginArray();
    reader.skipValue();
    assertEquals(2, reader.nextInt());
    reader.skipValue();
    reader.endArray();
  }

  public void testSkipValueSkipsNestedStructure() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[[1,2,3],4]"));
    reader.beginArray();
    reader.skipValue();
    assertEquals(4, reader.nextInt());
    reader.endArray();
  }

  public void testSkipValueOnScalarAtTopLevel() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("true"));
    reader.skipValue();
    // Once a top-level value has already been consumed, further peeks report
    // end-of-document rather than throwing.
    assertEquals(JsonToken.END_DOCUMENT, reader.peek());
  }

  public void testMalformedNumberInStrictModeThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[01]"));
    reader.beginArray();
    try {
      reader.peek();
      fail();
    } catch (MalformedJsonException expected) {
    }
  }

  public void testUnterminatedStringThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[\"abc"));
    reader.beginArray();
    try {
      reader.nextString();
      fail();
    } catch (MalformedJsonException expected) {
    }
  }

  public void testUnterminatedArrayThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1,2"));
    reader.beginArray();
    reader.nextInt();
    reader.nextInt();
    try {
      reader.peek();
      fail();
    } catch (EOFException expected) {
    }
  }

  public void testSingleQuotedStringsRejectedInStrictMode() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("['a']"));
    reader.beginArray();
    try {
      reader.nextString();
      fail();
    } catch (MalformedJsonException expected) {
    }
  }

  public void testSingleQuotedStringsAcceptedWhenLenient() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("['a']"));
    reader.setLenient(true);
    reader.beginArray();
    assertEquals("a", reader.nextString());
  }

  public void testUnquotedStringsRejectedInStrictMode() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[a]"));
    reader.beginArray();
    try {
      reader.nextString();
      fail();
    } catch (MalformedJsonException expected) {
    }
  }

  public void testUnquotedStringsAcceptedWhenLenient() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[a]"));
    reader.setLenient(true);
    reader.beginArray();
    assertEquals("a", reader.nextString());
  }

  public void testCommentsRejectedInStrictMode() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1 /* comment */, 2]"));
    reader.beginArray();
    reader.nextInt();
    try {
      reader.nextInt();
      fail();
    } catch (MalformedJsonException expected) {
    }
  }

  public void testCommentsAcceptedWhenLenient() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1 /* comment */, 2]"));
    reader.setLenient(true);
    reader.beginArray();
    assertEquals(1, reader.nextInt());
    assertEquals(2, reader.nextInt());
  }

  public void testMultipleTopLevelValuesRejectedInStrictMode() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[][]"));
    reader.beginArray();
    reader.endArray();
    try {
      reader.peek();
      fail();
    } catch (MalformedJsonException expected) {
    }
  }

  public void testMultipleTopLevelValuesAcceptedWhenLenient() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[][]"));
    reader.setLenient(true);
    reader.beginArray();
    reader.endArray();
    assertEquals(JsonToken.BEGIN_ARRAY, reader.peek());
    reader.beginArray();
    reader.endArray();
  }

  public void testNonExecutePrefixRejectedInStrictMode() throws IOException {
    JsonReader reader = new JsonReader(new StringReader(")]}'\n[]"));
    try {
      reader.peek();
      fail();
    } catch (MalformedJsonException expected) {
    }
  }

  public void testNonExecutePrefixAcceptedWhenLenient() throws IOException {
    JsonReader reader = new JsonReader(new StringReader(")]}'\n[]"));
    reader.setLenient(true);
    reader.beginArray();
    reader.endArray();
  }

  public void testEmptyDocumentThrowsEofException() {
    JsonReader reader = new JsonReader(new StringReader(""));
    try {
      reader.peek();
      fail();
    } catch (EOFException expected) {
    } catch (IOException unexpected) {
      fail("Expected EOFException but got " + unexpected);
    }
  }

  public void testCloseClosesUnderlyingReaderAndDisablesFurtherReads()
      throws IOException {
    final boolean[] closed = { false };
    StringReader delegate = new StringReader("[]") {
      @Override public void close() {
        closed[0] = true;
        super.close();
      }
    };
    JsonReader reader = new JsonReader(delegate);
    reader.close();
    assertTrue(closed[0]);
    try {
      reader.beginArray();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testGetPathAtTopLevel() {
    JsonReader reader = new JsonReader(new StringReader("[1,2]"));
    assertEquals("$", reader.getPath());
  }

  public void testGetPathAfterReadingIntoArray() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1,2]"));
    reader.beginArray();
    reader.nextInt();
    assertEquals("$[1]", reader.getPath());
  }

  public void testToStringReportsLineAndColumn() {
    JsonReader reader = new JsonReader(new StringReader("[]"));
    assertEquals("JsonReader at line 1 column 1", reader.toString());
  }

  public void testHasNextIsFalseAtEndOfDocumentForLenientReader()
      throws IOException {
    JsonReader reader = new JsonReader(new StringReader("1"));
    reader.setLenient(true);
    assertEquals(1, reader.nextInt());
  }
}
