/*
 * Copyright (C) 2016 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.gson.internal;

import java.io.Serializable;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.AbstractList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import junit.framework.TestCase;

/**
 * Exercises the public API of {@link $Gson$Types}.
 */
public final class $Gson$TypesAgentTest extends TestCase {

  // ------------------------------------------------------------------
  // newParameterizedTypeWithOwner
  // ------------------------------------------------------------------

  public void testNewParameterizedTypeWithOwner_basic() {
    ParameterizedType type =
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    assertEquals(List.class, type.getRawType());
    assertNull(type.getOwnerType());
    assertTypeArrayEquals(new Type[] { String.class }, type.getActualTypeArguments());
    assertEquals("java.util.List<java.lang.String>", type.toString());
  }

  public void testNewParameterizedTypeWithOwner_noTypeArguments() {
    ParameterizedType type = $Gson$Types.newParameterizedTypeWithOwner(null, List.class);
    assertEquals(0, type.getActualTypeArguments().length);
    assertEquals("java.util.List", type.toString());
  }

  public void testNewParameterizedTypeWithOwner_withOwnerType() {
    ParameterizedType type = $Gson$Types.newParameterizedTypeWithOwner(
        Map.class, Map.Entry.class, String.class, Integer.class);
    assertEquals(Map.class, type.getOwnerType());
    assertEquals(Map.Entry.class, type.getRawType());
    assertTypeArrayEquals(new Type[] { String.class, Integer.class }, type.getActualTypeArguments());
    assertEquals("java.util.Map$Entry<java.lang.String, java.lang.Integer>", type.toString());
  }

  public void testNewParameterizedTypeWithOwner_actualTypeArgumentsAreDefensivelyCopied() {
    ParameterizedType type =
        $Gson$Types.newParameterizedTypeWithOwner(null, Map.class, String.class, Integer.class);
    Type[] first = type.getActualTypeArguments();
    first[0] = Object.class;
    Type[] second = type.getActualTypeArguments();
    assertNotSame(first, second);
    assertEquals(String.class, second[0]);
    assertEquals(Integer.class, second[1]);
  }

  public void testNewParameterizedTypeWithOwner_canonicalizesArrayArgument() {
    ParameterizedType type =
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String[].class);
    Type argument = type.getActualTypeArguments()[0];
    assertFalse(argument instanceof Class);
    assertTrue(argument instanceof GenericArrayType);
    assertEquals(String.class, ((GenericArrayType) argument).getGenericComponentType());
  }

  public void testNewParameterizedTypeWithOwner_rejectsPrimitiveArgument() {
    try {
      $Gson$Types.newParameterizedTypeWithOwner(null, List.class, int.class);
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  public void testNewParameterizedTypeWithOwner_rejectsNullArgument() {
    try {
      $Gson$Types.newParameterizedTypeWithOwner(null, List.class, new Type[] { null });
      fail();
    } catch (NullPointerException expected) {
    }
  }

  public void testNewParameterizedTypeWithOwner_rejectsInnerClassWithoutOwner() {
    try {
      $Gson$Types.newParameterizedTypeWithOwner(null, Inner.class, String.class);
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  public void testNewParameterizedTypeWithOwner_equalsAndHashCode() {
    ParameterizedType a =
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    ParameterizedType b =
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    ParameterizedType c =
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, Integer.class);
    assertEquals(a, b);
    assertEquals(a.hashCode(), b.hashCode());
    assertFalse(a.equals(c));
    assertFalse(a.equals(String.class));
  }

  // ------------------------------------------------------------------
  // arrayOf
  // ------------------------------------------------------------------

  public void testArrayOf_classComponent() {
    GenericArrayType type = $Gson$Types.arrayOf(String.class);
    assertEquals(String.class, type.getGenericComponentType());
    assertEquals(String[].class, $Gson$Types.getRawType(type));
    assertEquals("java.lang.String[]", type.toString());
    assertEquals(type, $Gson$Types.arrayOf(String.class));
    assertEquals(type.hashCode(), $Gson$Types.arrayOf(String.class).hashCode());
    assertFalse(type.equals($Gson$Types.arrayOf(Integer.class)));
  }

  public void testArrayOf_primitiveComponent() {
    GenericArrayType type = $Gson$Types.arrayOf(int.class);
    assertEquals(int.class, type.getGenericComponentType());
    assertEquals(int[].class, $Gson$Types.getRawType(type));
    assertEquals("int[]", type.toString());
  }

  public void testArrayOf_parameterizedComponent() {
    GenericArrayType type = $Gson$Types.arrayOf(
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class));
    Type component = type.getGenericComponentType();
    assertTrue(component instanceof ParameterizedType);
    assertEquals(List.class, ((ParameterizedType) component).getRawType());
    assertEquals(List[].class, $Gson$Types.getRawType(type));
    assertEquals("java.util.List<java.lang.String>[]", type.toString());
  }

  // ------------------------------------------------------------------
  // subtypeOf / supertypeOf
  // ------------------------------------------------------------------

  public void testSubtypeOf_bounds() {
    WildcardType type = $Gson$Types.subtypeOf(CharSequence.class);
    assertTypeArrayEquals(new Type[] { CharSequence.class }, type.getUpperBounds());
    assertEquals(0, type.getLowerBounds().length);
    assertEquals("? extends java.lang.CharSequence", type.toString());
    assertEquals(CharSequence.class, $Gson$Types.getRawType(type));
  }

  public void testSubtypeOf_object() {
    WildcardType type = $Gson$Types.subtypeOf(Object.class);
    assertTypeArrayEquals(new Type[] { Object.class }, type.getUpperBounds());
    assertEquals(0, type.getLowerBounds().length);
    assertEquals("?", type.toString());
  }

  public void testSubtypeOf_unwrapsWildcardBound() {
    WildcardType inner = $Gson$Types.subtypeOf(CharSequence.class);
    WildcardType type = $Gson$Types.subtypeOf(inner);
    assertTypeArrayEquals(new Type[] { CharSequence.class }, type.getUpperBounds());
    assertEquals(0, type.getLowerBounds().length);
  }

  public void testSupertypeOf_bounds() {
    WildcardType type = $Gson$Types.supertypeOf(String.class);
    assertTypeArrayEquals(new Type[] { Object.class }, type.getUpperBounds());
    assertTypeArrayEquals(new Type[] { String.class }, type.getLowerBounds());
    assertEquals("? super java.lang.String", type.toString());
    assertEquals(Object.class, $Gson$Types.getRawType(type));
  }

  public void testSupertypeOf_unwrapsWildcardBound() {
    WildcardType inner = $Gson$Types.supertypeOf(String.class);
    WildcardType type = $Gson$Types.supertypeOf(inner);
    assertTypeArrayEquals(new Type[] { String.class }, type.getLowerBounds());
    assertTypeArrayEquals(new Type[] { Object.class }, type.getUpperBounds());
  }

  public void testSubtypeOfAndSupertypeOf_notEqual() {
    assertFalse($Gson$Types.equals(
        $Gson$Types.subtypeOf(String.class), $Gson$Types.supertypeOf(String.class)));
  }

  // ------------------------------------------------------------------
  // canonicalize
  // ------------------------------------------------------------------

  public void testCanonicalize_classReturnedUnchanged() {
    assertSame(String.class, $Gson$Types.canonicalize(String.class));
    assertSame(int.class, $Gson$Types.canonicalize(int.class));
    assertSame(Object.class, $Gson$Types.canonicalize(Object.class));
  }

  public void testCanonicalize_nullReturnsNull() {
    assertNull($Gson$Types.canonicalize(null));
  }

  public void testCanonicalize_arrayClassBecomesGenericArrayType() {
    Type canonical = $Gson$Types.canonicalize(String[].class);
    assertFalse(canonical instanceof Class);
    assertTrue(canonical instanceof GenericArrayType);
    assertEquals(String.class, ((GenericArrayType) canonical).getGenericComponentType());

    Type primitiveArray = $Gson$Types.canonicalize(int[].class);
    assertTrue(primitiveArray instanceof GenericArrayType);
    assertEquals(int.class, ((GenericArrayType) primitiveArray).getGenericComponentType());
  }

  public void testCanonicalize_multiDimensionalArrayClass() {
    Type canonical = $Gson$Types.canonicalize(String[][].class);
    assertTrue(canonical instanceof GenericArrayType);
    Type component = ((GenericArrayType) canonical).getGenericComponentType();
    assertTrue(component instanceof GenericArrayType);
    assertEquals(String.class, ((GenericArrayType) component).getGenericComponentType());
  }

  public void testCanonicalize_parameterizedTypeBecomesSerializableEqualToOriginal() throws Exception {
    Type original = Holder.class.getDeclaredField("mapField").getGenericType();
    assertTrue(original instanceof ParameterizedType);

    Type canonical = $Gson$Types.canonicalize(original);
    assertNotSame(original, canonical);
    assertTrue(canonical instanceof ParameterizedType);
    assertTrue(canonical instanceof Serializable);
    assertTrue($Gson$Types.equals(original, canonical));

    ParameterizedType parameterized = (ParameterizedType) canonical;
    assertEquals(Map.class, parameterized.getRawType());
    assertTypeArrayEquals(new Type[] { String.class, Integer.class },
        parameterized.getActualTypeArguments());

    // canonicalize is stable for an already canonical type
    assertTrue($Gson$Types.equals(canonical, $Gson$Types.canonicalize(canonical)));
  }

  // ------------------------------------------------------------------
  // getRawType
  // ------------------------------------------------------------------

  public void testGetRawType_class() {
    assertEquals(String.class, $Gson$Types.getRawType(String.class));
    assertEquals(int.class, $Gson$Types.getRawType(int.class));
  }

  public void testGetRawType_parameterizedType() throws Exception {
    assertEquals(List.class, $Gson$Types.getRawType(
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class)));

    Type jdkType = Holder.class.getDeclaredField("mapField").getGenericType();
    assertEquals(Map.class, $Gson$Types.getRawType(jdkType));
  }

  public void testGetRawType_genericArrayType() {
    assertEquals(String[].class,
        $Gson$Types.getRawType($Gson$Types.arrayOf(String.class)));
    assertEquals(List[].class, $Gson$Types.getRawType($Gson$Types.arrayOf(
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class))));
    assertEquals(Object[].class, $Gson$Types.getRawType(
        $Gson$Types.arrayOf(Collection.class.getTypeParameters()[0])));
  }

  public void testGetRawType_typeVariableIsObject() {
    assertEquals(Object.class,
        $Gson$Types.getRawType(List.class.getTypeParameters()[0]));
  }

  public void testGetRawType_wildcardUsesUpperBound() {
    assertEquals(CharSequence.class,
        $Gson$Types.getRawType($Gson$Types.subtypeOf(CharSequence.class)));
    assertEquals(Object.class,
        $Gson$Types.getRawType($Gson$Types.supertypeOf(String.class)));
  }

  public void testGetRawType_nullThrows() {
    try {
      $Gson$Types.getRawType(null);
      fail();
    } catch (IllegalArgumentException expected) {
      assertTrue(expected.getMessage().contains("null"));
    }
  }

  public void testGetRawType_unsupportedTypeThrows() {
    Type unsupported = new Type() {};
    try {
      $Gson$Types.getRawType(unsupported);
      fail();
    } catch (IllegalArgumentException expected) {
      assertTrue(expected.getMessage().contains("is of type"));
    }
  }

  // ------------------------------------------------------------------
  // equals
  // ------------------------------------------------------------------

  public void testEquals_identityAndNull() {
    assertTrue($Gson$Types.equals(null, null));
    assertTrue($Gson$Types.equals(String.class, String.class));
    assertFalse($Gson$Types.equals(null, String.class));
    assertFalse($Gson$Types.equals(String.class, null));
  }

  public void testEquals_classes() {
    assertTrue($Gson$Types.equals(String.class, String.class));
    assertFalse($Gson$Types.equals(String.class, Integer.class));
  }

  public void testEquals_parameterizedTypes() {
    Type a = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    Type b = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    Type c = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, Integer.class);
    assertTrue($Gson$Types.equals(a, b));
    assertFalse($Gson$Types.equals(a, c));
    assertFalse($Gson$Types.equals(a, String.class));
    assertFalse($Gson$Types.equals(a, $Gson$Types.arrayOf(String.class)));
  }

  public void testEquals_genericArrayTypes() {
    Type a = $Gson$Types.arrayOf(String.class);
    Type b = $Gson$Types.arrayOf(String.class);
    Type c = $Gson$Types.arrayOf(Integer.class);
    assertTrue($Gson$Types.equals(a, b));
    assertFalse($Gson$Types.equals(a, c));
    // a raw array Class is not treated as equal to a GenericArrayType
    assertFalse($Gson$Types.equals(a, String[].class));
  }

  public void testEquals_wildcardTypes() {
    Type a = $Gson$Types.subtypeOf(CharSequence.class);
    Type b = $Gson$Types.subtypeOf(CharSequence.class);
    Type c = $Gson$Types.subtypeOf(String.class);
    assertTrue($Gson$Types.equals(a, b));
    assertFalse($Gson$Types.equals(a, c));
    assertFalse($Gson$Types.equals(a, CharSequence.class));
  }

  public void testEquals_typeVariables() {
    TypeVariable<?> listE = List.class.getTypeParameters()[0];
    TypeVariable<?> listE2 = List.class.getTypeParameters()[0];
    TypeVariable<?> collectionE = Collection.class.getTypeParameters()[0];
    TypeVariable<?> mapK = Map.class.getTypeParameters()[0];
    assertTrue($Gson$Types.equals(listE, listE2));
    assertFalse($Gson$Types.equals(listE, collectionE));
    assertFalse($Gson$Types.equals(listE, mapK));
    assertFalse($Gson$Types.equals(listE, String.class));
  }

  // ------------------------------------------------------------------
  // typeToString
  // ------------------------------------------------------------------

  public void testTypeToString() {
    assertEquals("java.lang.String", $Gson$Types.typeToString(String.class));
    assertEquals("int", $Gson$Types.typeToString(int.class));
    assertEquals("java.util.List<java.lang.String>", $Gson$Types.typeToString(
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class)));
    assertEquals("java.lang.String[]",
        $Gson$Types.typeToString($Gson$Types.arrayOf(String.class)));
  }

  public void testTypeToString_nullThrows() {
    try {
      $Gson$Types.typeToString(null);
      fail();
    } catch (NullPointerException expected) {
    }
  }

  // ------------------------------------------------------------------
  // getArrayComponentType
  // ------------------------------------------------------------------

  public void testGetArrayComponentType_classArray() {
    assertEquals(String.class, $Gson$Types.getArrayComponentType(String[].class));
    assertEquals(int.class, $Gson$Types.getArrayComponentType(int[].class));
  }

  public void testGetArrayComponentType_genericArrayType() {
    Type parameterized =
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    Type component =
        $Gson$Types.getArrayComponentType($Gson$Types.arrayOf(parameterized));
    assertTrue(component instanceof ParameterizedType);
    assertTrue($Gson$Types.equals(parameterized, component));
  }

  public void testGetArrayComponentType_nonArrayClassReturnsNull() {
    assertNull($Gson$Types.getArrayComponentType(String.class));
  }

  public void testGetArrayComponentType_nonArrayTypeThrows() {
    try {
      $Gson$Types.getArrayComponentType(
          $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class));
      fail();
    } catch (ClassCastException expected) {
    }
  }

  // ------------------------------------------------------------------
  // getCollectionElementType
  // ------------------------------------------------------------------

  public void testGetCollectionElementType_parameterizedList() {
    Type listOfString =
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    assertEquals(String.class,
        $Gson$Types.getCollectionElementType(listOfString, List.class));
  }

  public void testGetCollectionElementType_concreteSubclass() {
    assertEquals(String.class,
        $Gson$Types.getCollectionElementType(StringList.class, StringList.class));
  }

  public void testGetCollectionElementType_rawCollectionIsObject() {
    assertEquals(Object.class,
        $Gson$Types.getCollectionElementType(Collection.class, Collection.class));
  }

  public void testGetCollectionElementType_nonCollectionThrows() {
    try {
      $Gson$Types.getCollectionElementType(String.class, String.class);
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  // ------------------------------------------------------------------
  // getMapKeyAndValueTypes
  // ------------------------------------------------------------------

  public void testGetMapKeyAndValueTypes_parameterizedMap() {
    Type mapType = $Gson$Types.newParameterizedTypeWithOwner(
        null, Map.class, String.class, Integer.class);
    Type[] keyAndValue = $Gson$Types.getMapKeyAndValueTypes(mapType, Map.class);
    assertTypeArrayEquals(new Type[] { String.class, Integer.class }, keyAndValue);
  }

  public void testGetMapKeyAndValueTypes_properties() {
    Type[] keyAndValue =
        $Gson$Types.getMapKeyAndValueTypes(Properties.class, Properties.class);
    assertTypeArrayEquals(new Type[] { String.class, String.class }, keyAndValue);
  }

  public void testGetMapKeyAndValueTypes_rawMapIsObject() {
    Type[] keyAndValue = $Gson$Types.getMapKeyAndValueTypes(Map.class, Map.class);
    assertTypeArrayEquals(new Type[] { Object.class, Object.class }, keyAndValue);
  }

  public void testGetMapKeyAndValueTypes_nonMapThrows() {
    try {
      $Gson$Types.getMapKeyAndValueTypes(String.class, String.class);
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  // ------------------------------------------------------------------
  // resolve
  // ------------------------------------------------------------------

  public void testResolve_returnsInputWhenNothingToResolve() throws Exception {
    assertSame(Integer.class,
        $Gson$Types.resolve(String.class, String.class, Integer.class));

    Type jdkMapType = Holder.class.getDeclaredField("mapField").getGenericType();
    assertSame(jdkMapType,
        $Gson$Types.resolve(Holder.class, Holder.class, jdkMapType));
  }

  public void testResolve_typeVariableFromSuperclassChain() {
    TypeVariable<?> collectionElement = Collection.class.getTypeParameters()[0];
    assertEquals(String.class,
        $Gson$Types.resolve(StringList.class, StringList.class, collectionElement));
  }

  public void testResolve_unresolvableTypeVariableReturnedUnchanged() {
    TypeVariable<?> listElement = List.class.getTypeParameters()[0];
    assertSame(listElement,
        $Gson$Types.resolve(String.class, String.class, listElement));
  }

  public void testResolve_genericArrayTypeComponentIsResolved() {
    TypeVariable<?> collectionElement = Collection.class.getTypeParameters()[0];
    Type resolved = $Gson$Types.resolve(
        StringList.class, StringList.class, $Gson$Types.arrayOf(collectionElement));
    assertTrue(resolved instanceof GenericArrayType);
    assertEquals(String.class, ((GenericArrayType) resolved).getGenericComponentType());
  }

  public void testResolve_wildcardUpperBoundIsResolved() {
    TypeVariable<?> collectionElement = Collection.class.getTypeParameters()[0];
    Type resolved = $Gson$Types.resolve(
        StringList.class, StringList.class, $Gson$Types.subtypeOf(collectionElement));
    assertTrue(resolved instanceof WildcardType);
    WildcardType wildcard = (WildcardType) resolved;
    assertEquals(String.class, wildcard.getUpperBounds()[0]);
    assertEquals(0, wildcard.getLowerBounds().length);
  }

  public void testResolve_parameterizedTypeArgumentIsResolved() {
    TypeVariable<?> collectionElement = Collection.class.getTypeParameters()[0];
    Type toResolve =
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, collectionElement);
    Type resolved = $Gson$Types.resolve(StringList.class, StringList.class, toResolve);
    assertTrue(resolved instanceof ParameterizedType);
    ParameterizedType parameterized = (ParameterizedType) resolved;
    assertEquals(List.class, parameterized.getRawType());
    assertEquals(String.class, parameterized.getActualTypeArguments()[0]);
    assertTrue($Gson$Types.equals(resolved,
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class)));
  }

  // ------------------------------------------------------------------
  // helpers
  // ------------------------------------------------------------------

  private static void assertTypeArrayEquals(Type[] expected, Type[] actual) {
    assertEquals("array length", expected.length, actual.length);
    for (int i = 0; i < expected.length; i++) {
      assertEquals("element " + i, expected[i], actual[i]);
    }
  }

  /** Non-static member class: parameterizing it requires an owner type. */
  class Inner {
  }

  abstract static class StringList extends AbstractList<String> {
  }

  @SuppressWarnings("unused")
  private static final class Holder {
    Map<String, Integer> mapField;
  }
}
