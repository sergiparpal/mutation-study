package org.apache.commons.lang3;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

/**
 * Self-contained tests for {@link SerializationUtils}, derived solely from the
 * published Javadoc contract:
 *
 * <ul>
 *   <li>{@code clone} performs a deep clone via serialization and returns the clone,
 *       or throws {@link SerializationException} (runtime) when serialization fails.</li>
 *   <li>{@code serialize(Serializable)} returns the produced bytes;
 *       {@code serialize(Serializable, OutputStream)} writes them, closes the stream,
 *       accepts a {@code null} object, and rejects a {@code null} stream with
 *       {@link IllegalArgumentException}.</li>
 *   <li>{@code deserialize(byte[])} / {@code deserialize(InputStream)} reconstruct the
 *       object, reject {@code null} input with {@link IllegalArgumentException}, close
 *       the stream form once the object is read, and raise {@link SerializationException}
 *       on malformed data.</li>
 * </ul>
 *
 * Every assertion below is anchored to one of those documented statements.
 */
public class SerializationUtilsAgentTest {

    // ------------------------------------------------------------------
    // Fixtures (all defined locally so the test stays self-contained)
    // ------------------------------------------------------------------

    /** A non-trivial serializable graph carrying mutable nested state. */
    public static class Person implements Serializable {
        private static final long serialVersionUID = 1L;
        private final String name;
        private final int age;
        private final List<String> nicknames;

        Person(final String name, final int age, final List<String> nicknames) {
            this.name = name;
            this.age = age;
            this.nicknames = nicknames;
        }

        List<String> nicknames() {
            return nicknames;
        }

        @Override
        public boolean equals(final Object obj) {
            if (!(obj instanceof Person)) {
                return false;
            }
            final Person other = (Person) obj;
            return age == other.age
                    && (name == null ? other.name == null : name.equals(other.name))
                    && (nicknames == null ? other.nicknames == null : nicknames.equals(other.nicknames));
        }

        @Override
        public int hashCode() {
            int result = age;
            result = 31 * result + (name == null ? 0 : name.hashCode());
            result = 31 * result + (nicknames == null ? 0 : nicknames.hashCode());
            return result;
        }

        @Override
        public String toString() {
            return "Person[name=" + name + ", age=" + age + ", nicknames=" + nicknames + "]";
        }
    }

    /** Deliberately NOT {@link Serializable}. */
    static class Unserializable {
        @SuppressWarnings("unused")
        private int payload = 7;
    }

    /** Serializable on the surface, but holds a non-serializable field. */
    public static class BrokenSerializable implements Serializable {
        private static final long serialVersionUID = 1L;
        @SuppressWarnings("unused")
        private final Unserializable trap = new Unserializable();
    }

    /** {@link ByteArrayOutputStream} that records whether {@link #close()} ran. */
    private static final class CloseAwareOutputStream extends ByteArrayOutputStream {
        private boolean closed;

        @Override
        public void close() throws IOException {
            closed = true;
            super.close();
        }

        boolean isClosed() {
            return closed;
        }
    }

    /** {@link ByteArrayInputStream} that records whether {@link #close()} ran. */
    private static final class CloseAwareInputStream extends ByteArrayInputStream {
        private boolean closed;

        CloseAwareInputStream(final byte[] buf) {
            super(buf);
        }

        @Override
        public void close() throws IOException {
            closed = true;
            super.close();
        }

        boolean isClosed() {
            return closed;
        }
    }

    private static Person samplePerson() {
        final List<String> nicknames = new ArrayList<String>();
        nicknames.add("Bob");
        nicknames.add("Bobby");
        return new Person("Robert", 42, nicknames);
    }

    // ------------------------------------------------------------------
    // Constructor
    // ------------------------------------------------------------------

    @Test
    public void publicConstructorCanBeInvoked() {
        // Documented: "This constructor is public to permit tools that require a
        // JavaBean instance to operate."
        assertNotNull(new SerializationUtils());
    }

    // ------------------------------------------------------------------
    // serialize(Serializable) -> byte[]
    // ------------------------------------------------------------------

    @Test
    public void serializeProducesNonEmptyByteArray() {
        final byte[] bytes = SerializationUtils.serialize(samplePerson());
        assertNotNull("serialize must return a byte[]", bytes);
        assertTrue("serialized form should not be empty", bytes.length > 0);
    }

    @Test
    public void serializeThenDeserializeByteArrayRoundTripsEqualValue() {
        final Person original = samplePerson();

        final byte[] bytes = SerializationUtils.serialize(original);
        final Object restored = SerializationUtils.deserialize(bytes);

        assertEquals("round-tripped value must be equal", original, restored);
        assertNotSame("round-tripped value must be a distinct instance", original, restored);
    }

    @Test
    public void serializeAcceptsNullObjectAndRoundTripsToNull() {
        // The two-arg form documents "obj ... may be null"; the array form delegates to it.
        final byte[] bytes = SerializationUtils.serialize((Serializable) null);

        assertNotNull("serializing null still yields a byte[]", bytes);
        assertNull("null must round-trip back to null", SerializationUtils.deserialize(bytes));
    }

    @Test
    public void serializeRejectsNonSerializableContentWithSerializationException() {
        try {
            SerializationUtils.serialize(new BrokenSerializable());
            fail("expected SerializationException for a non-serializable member");
        } catch (final SerializationException ex) {
            assertTrue("SerializationException must be a runtime exception", ex instanceof RuntimeException);
        }
    }

    // ------------------------------------------------------------------
    // serialize(Serializable, OutputStream)
    // ------------------------------------------------------------------

    @Test
    public void serializeToStreamWritesBytesThatDeserializeBack() {
        final Person original = samplePerson();
        final ByteArrayOutputStream out = new ByteArrayOutputStream();

        SerializationUtils.serialize(original, out);

        final byte[] written = out.toByteArray();
        assertTrue("something must have been written", written.length > 0);
        assertEquals(original, SerializationUtils.deserialize(written));
    }

    @Test
    public void serializeToStreamClosesTheStream() {
        final CloseAwareOutputStream out = new CloseAwareOutputStream();

        SerializationUtils.serialize(samplePerson(), out);

        assertTrue("the stream must be closed once the object is written", out.isClosed());
        // A closed ByteArrayOutputStream still exposes its buffer.
        assertEquals(samplePerson(), SerializationUtils.deserialize(out.toByteArray()));
    }

    @Test
    public void serializeToStreamAcceptsNullObject() {
        final ByteArrayOutputStream out = new ByteArrayOutputStream();

        SerializationUtils.serialize(null, out);

        assertNull(SerializationUtils.deserialize(out.toByteArray()));
    }

    @Test
    public void serializeToNullStreamThrowsIllegalArgumentException() {
        try {
            SerializationUtils.serialize(samplePerson(), (OutputStream) null);
            fail("expected IllegalArgumentException when outputStream is null");
        } catch (final IllegalArgumentException expected) {
            // documented contract
        }
    }

    @Test
    public void serializeToStreamRejectsNonSerializableContentWithSerializationException() {
        final ByteArrayOutputStream out = new ByteArrayOutputStream();
        try {
            SerializationUtils.serialize(new BrokenSerializable(), out);
            fail("expected SerializationException for a non-serializable member");
        } catch (final SerializationException expected) {
            // documented contract
        }
    }

    // ------------------------------------------------------------------
    // deserialize(byte[])
    // ------------------------------------------------------------------

    @Test
    public void deserializeByteArrayReturnsFreshEqualInstanceEachCall() {
        final byte[] bytes = SerializationUtils.serialize(samplePerson());

        final Object first = SerializationUtils.deserialize(bytes);
        final Object second = SerializationUtils.deserialize(bytes);

        assertEquals(samplePerson(), first);
        assertEquals(first, second);
        assertNotSame("each deserialize call must build a new graph", first, second);
    }

    @Test
    public void deserializedGraphIsIndependentOfTheOriginal() {
        final Person original = samplePerson();

        final Person restored = SerializationUtils.clone(original);
        original.nicknames().clear();

        assertEquals("clearing the source list must not affect the copy", 2, restored.nicknames().size());
    }

    @Test
    public void deserializeNullByteArrayThrowsIllegalArgumentException() {
        try {
            SerializationUtils.deserialize((byte[]) null);
            fail("expected IllegalArgumentException when objectData is null");
        } catch (final IllegalArgumentException expected) {
            // documented contract
        }
    }

    @Test
    public void deserializeEmptyByteArrayThrowsSerializationException() {
        try {
            SerializationUtils.deserialize(new byte[0]);
            fail("expected SerializationException for a truncated stream");
        } catch (final SerializationException expected) {
            // malformed data -> runtime SerializationException
        }
    }

    @Test
    public void deserializeGarbageByteArrayThrowsSerializationException() {
        try {
            SerializationUtils.deserialize(new byte[] { 1, 2, 3, 4, 5, 6, 7, 8 });
            fail("expected SerializationException for a corrupt stream");
        } catch (final SerializationException expected) {
            // malformed data -> runtime SerializationException
        }
    }

    // ------------------------------------------------------------------
    // deserialize(InputStream)
    // ------------------------------------------------------------------

    @Test
    public void deserializeFromStreamRoundTripsEqualValue() {
        final Person original = samplePerson();
        final byte[] bytes = SerializationUtils.serialize(original);

        final Object restored = SerializationUtils.deserialize(new ByteArrayInputStream(bytes));

        assertEquals(original, restored);
        assertNotSame(original, restored);
    }

    @Test
    public void deserializeFromStreamClosesTheStream() {
        final byte[] bytes = SerializationUtils.serialize(samplePerson());
        final CloseAwareInputStream in = new CloseAwareInputStream(bytes);

        final Object restored = SerializationUtils.deserialize(in);

        assertEquals(samplePerson(), restored);
        assertTrue("the stream must be closed once the object is read", in.isClosed());
    }

    @Test
    public void deserializeFromNullStreamThrowsIllegalArgumentException() {
        try {
            SerializationUtils.deserialize((InputStream) null);
            fail("expected IllegalArgumentException when inputStream is null");
        } catch (final IllegalArgumentException expected) {
            // documented contract
        }
    }

    @Test
    public void deserializeFromStreamWithGarbageThrowsSerializationException() {
        final InputStream in = new ByteArrayInputStream(new byte[] { 9, 9, 9, 9 });
        try {
            SerializationUtils.deserialize(in);
            fail("expected SerializationException for a corrupt stream");
        } catch (final SerializationException expected) {
            // malformed data -> runtime SerializationException
        }
    }

    // ------------------------------------------------------------------
    // clone(T)
    // ------------------------------------------------------------------

    @Test
    public void cloneReturnsEqualButDistinctInstance() {
        final Person original = samplePerson();

        final Person clone = SerializationUtils.clone(original);

        assertEquals("the clone must be equal to the original", original, clone);
        assertNotSame("the clone must be a different instance", original, clone);
    }

    @Test
    public void cloneIsDeepSoNestedStateIsCopiedNotShared() {
        final Person original = samplePerson();

        final Person clone = SerializationUtils.clone(original);

        assertNotSame("nested list must itself be cloned", original.nicknames(), clone.nicknames());
        assertEquals(original.nicknames(), clone.nicknames());

        original.nicknames().add("Rob");
        assertFalse("mutating the original graph must not touch the clone",
                clone.nicknames().contains("Rob"));
        assertEquals(2, clone.nicknames().size());
    }

    @Test
    public void cloneOfNullReturnsNull() {
        assertNull(SerializationUtils.clone(null));
    }

    @Test
    public void cloneRejectsNonSerializableContentWithSerializationException() {
        try {
            SerializationUtils.clone(new BrokenSerializable());
            fail("expected SerializationException for a non-serializable member");
        } catch (final SerializationException ex) {
            assertTrue("SerializationException must be a runtime exception", ex instanceof RuntimeException);
        }
    }

    @Test
    public void cloneOfCollectionsProducesEqualDetachedCopies() {
        final ArrayList<String> list = new ArrayList<String>(Arrays.asList("a", "b", "c"));
        final ArrayList<String> listClone = SerializationUtils.clone(list);
        assertEquals(list, listClone);
        assertNotSame(list, listClone);
        list.add("d");
        assertEquals("clone must not see later mutations of the source", 3, listClone.size());

        final HashMap<String, Integer> map = new HashMap<String, Integer>();
        map.put("one", Integer.valueOf(1));
        map.put("two", Integer.valueOf(2));
        final HashMap<String, Integer> mapClone = SerializationUtils.clone(map);
        assertEquals(map, mapClone);
        assertNotSame(map, mapClone);
    }

    @Test
    public void cloneOfPrimitiveArrayCopiesContents() {
        final int[] values = { 1, 2, 3, 4, 5 };

        final int[] clone = SerializationUtils.clone(values);

        assertArrayEquals(values, clone);
        assertNotSame(values, clone);
        values[0] = 99;
        assertEquals("clone must be independent of the source array", 1, clone[0]);
    }

    @Test
    public void cloneOfObjectArrayCopiesContents() {
        final String[] values = { "x", "y", "z" };

        final String[] clone = SerializationUtils.clone(values);

        assertArrayEquals(values, clone);
        assertNotSame(values, clone);
    }

    @Test
    public void clonePreservesPrimitiveTypeClasses() {
        // java.lang.Class is Serializable, so a deep clone of a primitive type token
        // must come back as the very same canonical Class object.
        final Class<?>[] primitiveTypes = {
                byte.class, short.class, int.class, long.class,
                float.class, double.class, boolean.class, char.class, void.class,
        };
        for (final Class<?> type : primitiveTypes) {
            final Serializable clone = SerializationUtils.clone((Serializable) type);
            assertEquals("clone of " + type, type, clone);
            assertSame("clone of " + type + " must be the canonical Class instance", type, clone);
        }
    }

    @Test
    public void serializeThenDeserializeRoundTripsPrimitiveTypeClass() {
        final byte[] bytes = SerializationUtils.serialize(int.class);
        assertEquals(int.class, SerializationUtils.deserialize(bytes));
    }
}
