/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.cli;

import java.util.Arrays;
import java.util.List;
import java.util.ListIterator;
import java.util.Properties;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Tests for the abstract {@link Parser} class, exercised through the
 * concrete {@link BasicParser} and {@link GnuParser} implementations.
 * Only the public API of <code>Parser</code> is exercised:
 * the four <code>parse(...)</code> overloads and <code>processArgs(...)</code>.
 */
public class ParserAgentTest extends TestCase
{
    private Parser parser = null;

    public static Test suite()
    {
        return new TestSuite(ParserAgentTest.class);
    }

    public ParserAgentTest(String name)
    {
        super(name);
    }

    public void setUp()
    {
        parser = new BasicParser();
    }

    public void tearDown()
    {
        parser = null;
    }

    // ------------------------------------------------------------------
    // happy path
    // ------------------------------------------------------------------

    public void testParseRecognizedFlagOption() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "turn a on");

        CommandLine cl = parser.parse(options, new String[] { "-a" });

        assertTrue("-a must be set", cl.hasOption("a"));
        assertNull("flag option has no value", cl.getOptionValue("a"));
        assertEquals("no left over arguments", 0, cl.getArgList().size());
        assertEquals("exactly one option processed", 1, cl.getOptions().length);
    }

    public void testParseOptionWithArgument() throws Exception
    {
        Options options = new Options();
        options.addOption("b", true, "set b");

        CommandLine cl = parser.parse(options, new String[] { "-b", "value" });

        assertTrue("-b must be set", cl.hasOption("b"));
        assertEquals("argument of -b", "value", cl.getOptionValue("b"));
        assertEquals("single value stored", 1, cl.getOptionValues("b").length);
        assertEquals("no left over arguments", 0, cl.getArgList().size());
    }

    public void testParseKeepsLeftOverArguments() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "turn a on");

        CommandLine cl = parser.parse(options,
                new String[] { "-a", "file1", "file2" });

        assertTrue("-a must be set", cl.hasOption("a"));

        String[] args = cl.getArgs();
        assertEquals("two left over arguments", 2, args.length);
        assertEquals("file1", args[0]);
        assertEquals("file2", args[1]);
    }

    public void testParseLongOptionWithGnuParser() throws Exception
    {
        Parser gnu = new GnuParser();
        Options options = new Options();
        options.addOption(OptionBuilder.withLongOpt("block-size")
                                       .hasArg()
                                       .create());

        CommandLine cl = gnu.parse(options,
                new String[] { "--block-size", "10", "extra" });

        assertTrue("--block-size must be set", cl.hasOption("block-size"));
        assertEquals("argument of --block-size", "10",
                cl.getOptionValue("block-size"));
        assertEquals("one left over argument", 1, cl.getArgList().size());
        assertEquals("extra", cl.getArgList().get(0));
    }

    // ------------------------------------------------------------------
    // null / empty arguments
    // ------------------------------------------------------------------

    public void testParseNullArguments() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "turn a on");

        CommandLine cl = parser.parse(options, (String[]) null);

        assertNotNull("a CommandLine is always returned", cl);
        assertFalse("no option set", cl.hasOption("a"));
        assertEquals("no arguments", 0, cl.getArgList().size());
        assertEquals("no options", 0, cl.getOptions().length);
    }

    public void testParseEmptyArguments() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "turn a on");

        CommandLine cl = parser.parse(options, new String[0]);

        assertFalse(cl.hasOption("a"));
        assertEquals(0, cl.getArgs().length);
    }

    // ------------------------------------------------------------------
    // error cases
    // ------------------------------------------------------------------

    public void testUnrecognizedOptionThrows() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "turn a on");

        try
        {
            parser.parse(options, new String[] { "-x" });
            fail("UnrecognizedOptionException expected");
        }
        catch (UnrecognizedOptionException e)
        {
            assertTrue("message mentions the offending option",
                    e.getMessage().indexOf("-x") != -1);
        }
    }

    public void testMissingArgumentThrowsWhenNothingFollows() throws Exception
    {
        Options options = new Options();
        options.addOption("b", true, "set b");

        try
        {
            parser.parse(options, new String[] { "-b" });
            fail("MissingArgumentException expected");
        }
        catch (MissingArgumentException e)
        {
            assertTrue("message mentions the option key",
                    e.getMessage().indexOf("b") != -1);
        }
    }

    public void testMissingArgumentThrowsWhenNextTokenIsOption() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "turn a on");
        options.addOption("b", true, "set b");

        try
        {
            parser.parse(options, new String[] { "-b", "-a" });
            fail("MissingArgumentException expected");
        }
        catch (MissingArgumentException e)
        {
            assertTrue(e.getMessage().indexOf("b") != -1);
        }
    }

    public void testMissingRequiredOptionThrows() throws Exception
    {
        Option required = new Option("r", false, "a required option");
        required.setRequired(true);

        Options options = new Options();
        options.addOption(required);
        options.addOption("a", false, "turn a on");

        try
        {
            parser.parse(options, new String[] { "-a" });
            fail("MissingOptionException expected");
        }
        catch (MissingOptionException e)
        {
            assertEquals("Missing required option: r", e.getMessage());
        }
    }

    public void testMissingMultipleRequiredOptionsReportedTogether()
            throws Exception
    {
        Option r = new Option("r", false, "required one");
        r.setRequired(true);
        Option s = new Option("s", false, "required two");
        s.setRequired(true);

        Options options = new Options();
        options.addOption(r);
        options.addOption(s);

        try
        {
            parser.parse(options, new String[0]);
            fail("MissingOptionException expected");
        }
        catch (MissingOptionException e)
        {
            String msg = e.getMessage();
            assertTrue("plural wording: " + msg,
                    msg.indexOf("Missing required options") != -1);
            assertTrue("mentions r: " + msg, msg.indexOf("r") != -1);
            assertTrue("mentions s: " + msg, msg.indexOf("s") != -1);
        }
    }

    // ------------------------------------------------------------------
    // required options - satisfied
    // ------------------------------------------------------------------

    public void testRequiredOptionSatisfied() throws Exception
    {
        Option required = new Option("r", false, "a required option");
        required.setRequired(true);

        Options options = new Options();
        options.addOption(required);

        CommandLine cl = parser.parse(options, new String[] { "-r" });

        assertTrue("-r must be set", cl.hasOption("r"));
        assertEquals(1, cl.getOptions().length);
    }

    public void testRequiredOptionStillEnforcedWhenOptionsReused()
            throws Exception
    {
        Option required = new Option("r", false, "a required option");
        required.setRequired(true);

        Options options = new Options();
        options.addOption(required);

        // first parse supplies the required option
        CommandLine first = parser.parse(options, new String[] { "-r" });
        assertTrue(first.hasOption("r"));

        // second parse with the same Options instance omits it: the parser
        // must not have permanently consumed the required-option bookkeeping
        try
        {
            parser.parse(options, new String[0]);
            fail("MissingOptionException expected on reuse");
        }
        catch (MissingOptionException e)
        {
            assertEquals("Missing required option: r", e.getMessage());
        }
    }

    // ------------------------------------------------------------------
    // stopAtNonOption
    // ------------------------------------------------------------------

    public void testStopAtNonOptionCollectsRemainder() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "turn a on");
        options.addOption("b", true, "set b");

        CommandLine cl = parser.parse(options,
                new String[] { "-a", "foo", "-b", "bar" }, true);

        assertTrue("-a parsed before the non option", cl.hasOption("a"));
        assertFalse("-b after the non option is not parsed", cl.hasOption("b"));

        List argList = cl.getArgList();
        assertEquals(3, argList.size());
        assertEquals("foo", argList.get(0));
        assertEquals("-b", argList.get(1));
        assertEquals("bar", argList.get(2));
    }

    public void testStopAtNonOptionWithUnknownOptionDoesNotThrow()
            throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "turn a on");

        CommandLine cl = parser.parse(options,
                new String[] { "-a", "-x", "-a" }, true);

        assertTrue("leading -a is parsed", cl.hasOption("a"));

        List argList = cl.getArgList();
        assertEquals(2, argList.size());
        assertEquals("-x", argList.get(0));
        assertEquals("-a", argList.get(1));
    }

    public void testUnknownOptionThrowsWhenNotStoppingAtNonOption()
            throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "turn a on");

        try
        {
            parser.parse(options, new String[] { "-x" }, false);
            fail("UnrecognizedOptionException expected");
        }
        catch (UnrecognizedOptionException e)
        {
            assertTrue(e.getMessage().indexOf("-x") != -1);
        }
    }

    // ------------------------------------------------------------------
    // "--" and "-" tokens
    // ------------------------------------------------------------------

    public void testDoubleDashStopsOptionParsing() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "turn a on");
        options.addOption("b", true, "set b");

        CommandLine cl = parser.parse(options,
                new String[] { "-a", "--", "-b", "bar" });

        assertTrue("-a before -- is parsed", cl.hasOption("a"));
        assertFalse("-b after -- is not parsed", cl.hasOption("b"));

        List argList = cl.getArgList();
        assertEquals("the -- itself is not added", 2, argList.size());
        assertEquals("-b", argList.get(0));
        assertEquals("bar", argList.get(1));
    }

    public void testSingleDashIsTreatedAsArgument() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "turn a on");

        CommandLine cl = parser.parse(options,
                new String[] { "-a", "-", "foo" });

        assertTrue(cl.hasOption("a"));

        List argList = cl.getArgList();
        assertEquals(2, argList.size());
        assertEquals("-", argList.get(0));
        assertEquals("foo", argList.get(1));
    }

    // ------------------------------------------------------------------
    // properties
    // ------------------------------------------------------------------

    public void testParseAppliesProperties() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "turn a on");
        options.addOption("b", true, "set b");

        Properties props = new Properties();
        props.setProperty("a", "true");
        props.setProperty("b", "fromProps");

        CommandLine cl = parser.parse(options, new String[0], props);

        assertTrue("flag a set from properties", cl.hasOption("a"));
        assertTrue("b set from properties", cl.hasOption("b"));
        assertEquals("fromProps", cl.getOptionValue("b"));
    }

    public void testCommandLineTakesPrecedenceOverProperties() throws Exception
    {
        Options options = new Options();
        options.addOption("b", true, "set b");

        Properties props = new Properties();
        props.setProperty("b", "fromProps");

        CommandLine cl = parser.parse(options,
                new String[] { "-b", "fromArgs" }, props);

        assertEquals("command line wins", "fromArgs", cl.getOptionValue("b"));
        assertEquals(1, cl.getOptionValues("b").length);
    }

    public void testFlagPropertyWithFalseValueIsNotSet() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "turn a on");

        Properties props = new Properties();
        props.setProperty("a", "false");

        CommandLine cl = parser.parse(options, new String[0], props);

        assertFalse("a must not be set for a non truthy property value",
                cl.hasOption("a"));
        assertEquals(0, cl.getOptions().length);
    }

    // ------------------------------------------------------------------
    // reuse of Options / option value clearing (CLI-71)
    // ------------------------------------------------------------------

    public void testReuseOptionsClearsPreviousValues() throws Exception
    {
        Options options = new Options();
        options.addOption("b", true, "set b");

        CommandLine first = parser.parse(options, new String[] { "-b", "first" });
        assertEquals("first", first.getOptionValue("b"));

        CommandLine second = parser.parse(options,
                new String[] { "-b", "second" });
        assertEquals("second", second.getOptionValue("b"));
        assertEquals("stale value from the first parse must be gone",
                1, second.getOptionValues("b").length);
    }

    // ------------------------------------------------------------------
    // public processArgs(Option, ListIterator)
    // ------------------------------------------------------------------

    public void testProcessArgsConsumesValuesUpToNextOption() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "turn a on");
        // parse once so that the parser has an Options context
        parser.parse(options, new String[0]);

        Option opt = new Option("m", true, "multi valued");
        opt.setArgs(2);

        List tokens = Arrays.asList(new String[] { "x", "y", "-a" });
        ListIterator it = tokens.listIterator();

        parser.processArgs(opt, it);

        String[] values = opt.getValues();
        assertNotNull(values);
        assertEquals(2, values.length);
        assertEquals("x", values[0]);
        assertEquals("y", values[1]);
        assertTrue("iterator stopped before the next option", it.hasNext());
        assertEquals("-a", it.next());
    }

    public void testProcessArgsStripsSurroundingQuotes() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "turn a on");
        parser.parse(options, new String[0]);

        Option opt = new Option("q", true, "quoted value");
        opt.setArgs(1);

        List tokens = Arrays.asList(new String[] { "\"hello world\"" });
        ListIterator it = tokens.listIterator();

        parser.processArgs(opt, it);

        assertEquals("hello world", opt.getValue());
        assertFalse(it.hasNext());
    }

    public void testProcessArgsThrowsMissingArgumentWhenNoValueAvailable()
            throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "turn a on");
        parser.parse(options, new String[0]);

        Option opt = new Option("z", true, "needs a value");

        List tokens = Arrays.asList(new String[] { "-a" });
        ListIterator it = tokens.listIterator();

        try
        {
            parser.processArgs(opt, it);
            fail("MissingArgumentException expected");
        }
        catch (MissingArgumentException e)
        {
            assertTrue(e.getMessage().indexOf("z") != -1);
        }

        // the option token must have been pushed back for the caller
        assertTrue(it.hasNext());
        assertEquals("-a", it.next());
    }

    public void testProcessArgsAllowsMissingValueForOptionalArg() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "turn a on");
        parser.parse(options, new String[0]);

        Option opt = new Option("o", true, "optional value");
        opt.setOptionalArg(true);

        List tokens = Arrays.asList(new String[] { "-a" });
        ListIterator it = tokens.listIterator();

        // no exception even though no value is available
        parser.processArgs(opt, it);

        assertNull("no value was consumed", opt.getValues());
    }
}
