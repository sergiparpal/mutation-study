/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.builder;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import junit.framework.TestCase;

import org.apache.commons.lang3.SystemUtils;

/**
 * Tests the public API of {@link org.apache.commons.lang3.builder.ToStringStyle}.
 *
 * <p>{@code ToStringStyle} is abstract, so it is exercised here through its
 * public singleton constants ({@code DEFAULT_STYLE}, {@code MULTI_LINE_STYLE},
 * {@code SIMPLE_STYLE}, ...) and its public {@code append*} methods.  Each test
 * asserts on the exact text written to the supplied {@code StringBuffer}.</p>
 *
 * @version $Id$
 */
public class ToStringStyleAgentTest extends TestCase {

    /** Platform line separator, as used by {@code MULTI_LINE_STYLE}. */
    private static final String LS = SystemUtils.LINE_SEPARATOR;

    public ToStringStyleAgentTest(String name) {
        super(name);
    }

    /** The identity text that {@code Object.toString()} would produce for the given object. */
    private static String id(Object o) {
        return o.getClass().getName() + "@" + Integer.toHexString(System.identityHashCode(o));
    }

    // -----------------------------------------------------------------------
    //  Singleton constants
    // -----------------------------------------------------------------------

    public void testConstantsAreNonNullDistinctAndSerializable() {
        ToStringStyle[] styles = new ToStringStyle[] {
            ToStringStyle.DEFAULT_STYLE,
            ToStringStyle.MULTI_LINE_STYLE,
            ToStringStyle.NO_FIELD_NAMES_STYLE,
            ToStringStyle.SHORT_PREFIX_STYLE,
            ToStringStyle.SIMPLE_STYLE,
        };
        for (int i = 0; i < styles.length; i++) {
            assertNotNull("style[" + i + "] must not be null", styles[i]);
            assertTrue("style[" + i + "] must be Serializable", styles[i] instanceof Serializable);
            for (int j = i + 1; j < styles.length; j++) {
                assertNotSame("styles " + i + " and " + j + " must be distinct instances",
                              styles[i], styles[j]);
            }
        }
    }

    // -----------------------------------------------------------------------
    //  append(StringBuffer, String, <primitive>) -> "name=value,"  (DEFAULT_STYLE)
    // -----------------------------------------------------------------------

    public void testAppendLong() {
        ToStringStyle style = ToStringStyle.DEFAULT_STYLE;

        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "a", 3L);
        assertEquals("a=3,", buffer.toString());

        buffer = new StringBuffer();
        style.append(buffer, "a", -7L);
        assertEquals("a=-7,", buffer.toString());

        buffer = new StringBuffer();
        style.append(buffer, "a", Long.MIN_VALUE);
        assertEquals("a=-9223372036854775808,", buffer.toString());

        // chained appends accumulate, each terminated by the field separator
        buffer = new StringBuffer();
        style.append(buffer, "a", 3L);
        style.append(buffer, "b", 4L);
        assertEquals("a=3,b=4,", buffer.toString());
    }

    public void testAppendInt() {
        ToStringStyle style = ToStringStyle.DEFAULT_STYLE;

        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "a", 0);
        assertEquals("a=0,", buffer.toString());

        buffer = new StringBuffer();
        style.append(buffer, "a", Integer.MIN_VALUE);
        assertEquals("a=-2147483648,", buffer.toString());
    }

    public void testAppendShort() {
        StringBuffer buffer = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.append(buffer, "a", (short) -12);
        assertEquals("a=-12,", buffer.toString());
    }

    public void testAppendByte() {
        StringBuffer buffer = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.append(buffer, "a", (byte) 127);
        assertEquals("a=127,", buffer.toString());
    }

    public void testAppendChar() {
        StringBuffer buffer = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.append(buffer, "a", 'Z');
        assertEquals("a=Z,", buffer.toString());
    }

    public void testAppendDouble() {
        ToStringStyle style = ToStringStyle.DEFAULT_STYLE;

        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "a", 1.5d);
        assertEquals("a=1.5,", buffer.toString());

        buffer = new StringBuffer();
        style.append(buffer, "a", Double.NaN);
        assertEquals("a=NaN,", buffer.toString());

        buffer = new StringBuffer();
        style.append(buffer, "a", Double.POSITIVE_INFINITY);
        assertEquals("a=Infinity,", buffer.toString());
    }

    public void testAppendFloat() {
        ToStringStyle style = ToStringStyle.DEFAULT_STYLE;

        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "a", 2.5f);
        assertEquals("a=2.5,", buffer.toString());

        buffer = new StringBuffer();
        style.append(buffer, "a", Float.NaN);
        assertEquals("a=NaN,", buffer.toString());
    }

    public void testAppendBoolean() {
        StringBuffer buffer = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.append(buffer, "a", true);
        assertEquals("a=true,", buffer.toString());

        buffer = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.append(buffer, "a", false);
        assertEquals("a=false,", buffer.toString());
    }

    public void testAppendPrimitiveWithNullFieldNameOmitsName() {
        StringBuffer buffer = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.append(buffer, null, 5L);
        assertEquals("5,", buffer.toString());
    }

    // -----------------------------------------------------------------------
    //  append(StringBuffer, String, Object, Boolean)
    // -----------------------------------------------------------------------

    public void testAppendObjectNull() {
        StringBuffer buffer = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.append(buffer, "a", (Object) null, null);
        assertEquals("a=<null>,", buffer.toString());
    }

    public void testAppendObjectNullWithNullFieldName() {
        StringBuffer buffer = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.append(buffer, null, (Object) null, null);
        assertEquals("<null>,", buffer.toString());
    }

    public void testAppendObjectFullDetail() {
        StringBuffer buffer = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.append(buffer, "a", "value", Boolean.TRUE);
        assertEquals("a=value,", buffer.toString());
    }

    public void testAppendObjectSummary() {
        StringBuffer buffer = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.append(buffer, "a", "value", Boolean.FALSE);
        assertEquals("a=<String>,", buffer.toString());
    }

    public void testAppendObjectNullFullDetailUsesStyleDefault() {
        // DEFAULT_STYLE's default full-detail flag is true, so a null request => full detail
        StringBuffer buffer = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.append(buffer, "a", "value", null);
        assertEquals("a=value,", buffer.toString());
    }

    public void testAppendCollection() {
        ToStringStyle style = ToStringStyle.DEFAULT_STYLE;
        List<Integer> list = new ArrayList<Integer>();
        list.add(Integer.valueOf(1));
        list.add(Integer.valueOf(2));
        list.add(Integer.valueOf(3));

        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "a", list, Boolean.FALSE);
        assertEquals("a=<size=3>,", buffer.toString());

        buffer = new StringBuffer();
        style.append(buffer, "a", list, Boolean.TRUE);
        assertEquals("a=[1, 2, 3],", buffer.toString());

        buffer = new StringBuffer();
        style.append(buffer, "a", new ArrayList<Object>(), Boolean.FALSE);
        assertEquals("a=<size=0>,", buffer.toString());
    }

    public void testAppendMap() {
        ToStringStyle style = ToStringStyle.DEFAULT_STYLE;
        Map<String, String> map = new HashMap<String, String>();
        map.put("k", "v");

        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "a", map, Boolean.FALSE);
        assertEquals("a=<size=1>,", buffer.toString());

        buffer = new StringBuffer();
        style.append(buffer, "a", map, Boolean.TRUE);
        assertEquals("a={k=v},", buffer.toString());
    }

    public void testAppendPrimitiveArrayPassedAsObject() {
        ToStringStyle style = ToStringStyle.DEFAULT_STYLE;

        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "a", (Object) new int[] {3, 6}, Boolean.TRUE);
        assertEquals("a={3,6},", buffer.toString());

        buffer = new StringBuffer();
        style.append(buffer, "a", (Object) new int[] {3, 6}, Boolean.FALSE);
        assertEquals("a=<size=2>,", buffer.toString());
    }

    // -----------------------------------------------------------------------
    //  append(StringBuffer, String, <array>, Boolean)
    // -----------------------------------------------------------------------

    public void testAppendObjectArray() {
        ToStringStyle style = ToStringStyle.DEFAULT_STYLE;

        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "a", new String[] {"x", "y"}, Boolean.TRUE);
        assertEquals("a={x,y},", buffer.toString());

        buffer = new StringBuffer();
        style.append(buffer, "a", new String[] {"x", null, "z"}, Boolean.TRUE);
        assertEquals("a={x,<null>,z},", buffer.toString());

        buffer = new StringBuffer();
        style.append(buffer, "a", new String[] {"x", "y"}, Boolean.FALSE);
        assertEquals("a=<size=2>,", buffer.toString());
    }

    public void testAppendObjectArrayEmpty() {
        ToStringStyle style = ToStringStyle.DEFAULT_STYLE;

        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "a", new String[0], Boolean.TRUE);
        assertEquals("a={},", buffer.toString());

        buffer = new StringBuffer();
        style.append(buffer, "a", new String[0], Boolean.FALSE);
        assertEquals("a=<size=0>,", buffer.toString());
    }

    public void testAppendObjectArrayNull() {
        StringBuffer buffer = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.append(buffer, "a", (Object[]) null, Boolean.TRUE);
        assertEquals("a=<null>,", buffer.toString());
    }

    public void testAppendLongArray() {
        ToStringStyle style = ToStringStyle.DEFAULT_STYLE;

        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "a", new long[] {1, 2, -3}, null);
        assertEquals("a={1,2,-3},", buffer.toString());

        buffer = new StringBuffer();
        style.append(buffer, "a", new long[] {1, 2, -3}, Boolean.FALSE);
        assertEquals("a=<size=3>,", buffer.toString());

        buffer = new StringBuffer();
        style.append(buffer, "a", (long[]) null, null);
        assertEquals("a=<null>,", buffer.toString());
    }

    public void testAppendCharArray() {
        StringBuffer buffer = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.append(buffer, "a", new char[] {'a', 'b', 'c'}, Boolean.TRUE);
        assertEquals("a={a,b,c},", buffer.toString());
    }

    public void testAppendBooleanArray() {
        StringBuffer buffer = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.append(buffer, "a", new boolean[] {true, false}, Boolean.TRUE);
        assertEquals("a={true,false},", buffer.toString());
    }

    public void testAppendDoubleArray() {
        StringBuffer buffer = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.append(buffer, "a", new double[] {1.0, 2.5}, Boolean.TRUE);
        assertEquals("a={1.0,2.5},", buffer.toString());
    }

    // -----------------------------------------------------------------------
    //  appendStart / appendEnd
    // -----------------------------------------------------------------------

    public void testAppendStartAndEndDefaultStyle() {
        ToStringStyle style = ToStringStyle.DEFAULT_STYLE;
        Integer object = new Integer(7);
        String prefix = id(object);

        StringBuffer buffer = new StringBuffer();
        style.appendStart(buffer, object);
        assertEquals(prefix + "[", buffer.toString());

        style.append(buffer, "a", 1);
        assertEquals(prefix + "[a=1,", buffer.toString());

        style.appendEnd(buffer, object);
        // appendEnd strips the trailing field separator and appends the content end
        assertEquals(prefix + "[a=1]", buffer.toString());
    }

    public void testAppendStartNullObjectWritesNothing() {
        StringBuffer buffer = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.appendStart(buffer, null);
        assertEquals("", buffer.toString());
    }

    public void testAppendEndWithoutTrailingSeparator() {
        StringBuffer buffer = new StringBuffer("x=1");
        ToStringStyle.DEFAULT_STYLE.appendEnd(buffer, null);
        assertEquals("x=1]", buffer.toString());
    }

    public void testAppendEndRemovesOnlyOneFieldSeparator() {
        StringBuffer buffer = new StringBuffer("x=1,,");
        ToStringStyle.DEFAULT_STYLE.appendEnd(buffer, null);
        assertEquals("x=1,]", buffer.toString());
    }

    public void testAppendStartAndEndShortPrefixStyle() {
        ToStringStyle style = ToStringStyle.SHORT_PREFIX_STYLE;
        Integer object = new Integer(3);

        StringBuffer buffer = new StringBuffer();
        style.appendStart(buffer, object);
        assertEquals("Integer[", buffer.toString());

        style.append(buffer, "a", 1);
        style.appendEnd(buffer, object);
        assertEquals("Integer[a=1]", buffer.toString());
    }

    public void testAppendStartAndEndMultiLineStyle() {
        ToStringStyle style = ToStringStyle.MULTI_LINE_STYLE;
        Integer object = new Integer(9);
        String prefix = id(object);

        StringBuffer empty = new StringBuffer();
        style.appendStart(empty, object);
        style.appendEnd(empty, object);
        assertEquals(prefix + "[" + LS + "]", empty.toString());

        StringBuffer withField = new StringBuffer();
        style.appendStart(withField, object);
        style.append(withField, "a", (Object) "hello", null);
        style.appendEnd(withField, object);
        assertEquals(prefix + "[" + LS + "  a=hello" + LS + "]", withField.toString());
    }

    public void testSimpleStyleAppendStartWritesNothing() {
        StringBuffer buffer = new StringBuffer();
        ToStringStyle.SIMPLE_STYLE.appendStart(buffer, new Integer(1));
        assertEquals("", buffer.toString());
    }

    public void testNoFieldNamesStyleOmitsFieldName() {
        ToStringStyle style = ToStringStyle.NO_FIELD_NAMES_STYLE;

        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "ignored", 42);
        assertEquals("42,", buffer.toString());

        buffer = new StringBuffer();
        style.append(buffer, "ignored", (Object) "v", Boolean.TRUE);
        assertEquals("v,", buffer.toString());
    }

    // -----------------------------------------------------------------------
    //  appendToString / appendSuper
    // -----------------------------------------------------------------------

    public void testAppendToStringExtractsContent() {
        StringBuffer buffer = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.appendToString(buffer, "Foo@1a2b[a=1,b=2]");
        assertEquals("a=1,b=2,", buffer.toString());
    }

    public void testAppendToStringUsesFirstStartAndLastEndMarker() {
        StringBuffer buffer = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.appendToString(buffer, "Foo@1[a=[1, 2],b=3]");
        assertEquals("a=[1, 2],b=3,", buffer.toString());
    }

    public void testAppendToStringAppendsToExistingContent() {
        StringBuffer buffer = new StringBuffer("x=0,");
        ToStringStyle.DEFAULT_STYLE.appendToString(buffer, "Foo@1[a=1]");
        assertEquals("x=0,a=1,", buffer.toString());
    }

    public void testAppendToStringNullIsIgnored() {
        StringBuffer buffer = new StringBuffer("keep");
        ToStringStyle.DEFAULT_STYLE.appendToString(buffer, null);
        assertEquals("keep", buffer.toString());
    }

    public void testAppendToStringWithoutContentMarkersIsIgnored() {
        StringBuffer buffer = new StringBuffer("keep");
        ToStringStyle.DEFAULT_STYLE.appendToString(buffer, "no markers here");
        assertEquals("keep", buffer.toString());
    }

    public void testAppendToStringEmptyContentIsIgnored() {
        StringBuffer buffer = new StringBuffer("keep");
        ToStringStyle.DEFAULT_STYLE.appendToString(buffer, "Foo@1[]");
        assertEquals("keep", buffer.toString());
    }

    public void testAppendSuperDelegatesToAppendToString() {
        StringBuffer buffer = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.appendSuper(buffer, "Foo@1[a=1]");
        assertEquals("a=1,", buffer.toString());
    }

    public void testAppendSuperNullIsIgnored() {
        StringBuffer buffer = new StringBuffer("keep");
        ToStringStyle.DEFAULT_STYLE.appendSuper(buffer, null);
        assertEquals("keep", buffer.toString());
    }

    public void testAppendSuperSimpleStyleEmptyContentMarkers() {
        // SIMPLE_STYLE uses "" as both content start and end
        StringBuffer buffer = new StringBuffer();
        ToStringStyle.SIMPLE_STYLE.appendSuper(buffer, "<null>");
        assertEquals("<null>,", buffer.toString());
    }

    // -----------------------------------------------------------------------
    //  Cyclic reference handling (append -> appendInternal -> appendCyclicObject)
    // -----------------------------------------------------------------------

    public void testAppendObjectDetectsCycleAndUsesIdentityString() {
        ToStringStyle style = ToStringStyle.DEFAULT_STYLE;
        // A non-Number/Boolean/Character value whose toString() differs from its identity string.
        StringBuilder cyclic = new StringBuilder("value");

        StringBuffer registrar = new StringBuffer();
        style.appendStart(registrar, cyclic); // registers 'cyclic' with the cycle-detection registry
        try {
            StringBuffer buffer = new StringBuffer();
            style.append(buffer, "a", cyclic, Boolean.TRUE);
            assertEquals("a=" + id(cyclic) + ",", buffer.toString());
        } finally {
            style.appendEnd(new StringBuffer(), cyclic); // unregisters 'cyclic'
        }
    }

    public void testAppendObjectWithoutCycleUsesValueToString() {
        ToStringStyle style = ToStringStyle.DEFAULT_STYLE;
        StringBuilder notCyclic = new StringBuilder("value");

        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "a", notCyclic, Boolean.TRUE);
        assertEquals("a=value,", buffer.toString());
    }

    public void testNumberValueIsNeverTreatedAsCycle() {
        ToStringStyle style = ToStringStyle.DEFAULT_STYLE;
        Integer number = new Integer(5);

        StringBuffer registrar = new StringBuffer();
        style.appendStart(registrar, number); // register the number
        try {
            StringBuffer buffer = new StringBuffer();
            style.append(buffer, "a", number, Boolean.TRUE);
            // Numbers are excluded from cycle detection, so the value is printed, not the identity string
            assertEquals("a=5,", buffer.toString());
        } finally {
            style.appendEnd(new StringBuffer(), number);
        }
    }
}
