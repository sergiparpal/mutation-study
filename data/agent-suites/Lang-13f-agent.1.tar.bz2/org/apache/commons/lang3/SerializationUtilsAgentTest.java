/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.Assert.*;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;

import org.junit.Before;
import org.junit.Test;

/**
 * Unit tests for {@link org.apache.commons.lang3.SerializationUtils} exercising the
 * public API: the JavaBean constructor, {@code serialize}, {@code deserialize} and
 * {@code clone}.
 *
 * @version $Id$
 */
public class SerializationUtilsAgentTest {

    private String iString;
    private Integer iInteger;
    private HashMap<Object, Object> iMap;

    @Before
    public void setUp() {
        iString = "foo";
        iInteger = Integer.valueOf(7);
        iMap = new HashMap<Object, Object>();
        iMap.put("FOO", iString);
        iMap.put("BAR", iInteger);
    }

    //-----------------------------------------------------------------------
    @Test
    public void testConstructor() {
        assertNotNull(new SerializationUtils());
        Constructor<?>[] cons = SerializationUtils.class.getDeclaredConstructors();
        assertEquals(1, cons.length);
        assertTrue(Modifier.isPublic(cons[0].getModifiers()));
        assertTrue(Modifier.isPublic(SerializationUtils.class.getModifiers()));
        assertFalse(Modifier.isFinal(SerializationUtils.class.getModifiers()));
    }

    //-----------------------------------------------------------------------
    //  serialize(Serializable) -> byte[]
    //-----------------------------------------------------------------------
    @Test
    public void testSerializeBytesRoundTrip() throws Exception {
        byte[] data = SerializationUtils.serialize(iMap);
        assertNotNull(data);
        assertTrue("expected a non-empty serialized form", data.length > 0);

        // Reconstitute with the plain JDK machinery and compare observable content.
        ObjectInputStream in = new ObjectInputStream(new ByteArrayInputStream(data));
        Object read = in.readObject();
        in.close();

        assertTrue(read instanceof HashMap);
        HashMap<?, ?> restored = (HashMap<?, ?>) read;
        assertEquals(2, restored.size());
        assertEquals(iString, restored.get("FOO"));
        assertEquals(iInteger, restored.get("BAR"));
        assertEquals(iMap, restored);
    }

    @Test
    public void testSerializeBytesEqualsRawObjectOutputStream() throws Exception {
        byte[] viaUtils = SerializationUtils.serialize(iMap);

        ByteArrayOutputStream raw = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(raw);
        oos.writeObject(iMap);
        oos.flush();
        oos.close();

        assertTrue("SerializationUtils.serialize must match a raw ObjectOutputStream write",
                Arrays.equals(raw.toByteArray(), viaUtils));
    }

    @Test
    public void testSerializeBytesNull() throws Exception {
        // A null object is a legal input for serialize(Serializable): a stream is still produced.
        byte[] data = SerializationUtils.serialize(null);
        assertNotNull(data);
        assertTrue(data.length > 0);

        ObjectInputStream in = new ObjectInputStream(new ByteArrayInputStream(data));
        assertNull(in.readObject());
        in.close();
    }

    @Test
    public void testSerializeBytesUnserializable() {
        iMap.put(new Object(), new Object());
        try {
            SerializationUtils.serialize(iMap);
            fail("SerializationException expected for a non-Serializable payload");
        } catch (SerializationException ex) {
            assertTrue("cause should be the underlying IOException, was " + ex.getCause(),
                    ex.getCause() instanceof IOException);
        }
    }

    //-----------------------------------------------------------------------
    //  serialize(Serializable, OutputStream)
    //-----------------------------------------------------------------------
    @Test
    public void testSerializeStreamRoundTrip() throws Exception {
        ByteArrayOutputStream streamTest = new ByteArrayOutputStream();
        SerializationUtils.serialize(iMap, streamTest);

        ByteArrayOutputStream streamReal = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(streamReal);
        oos.writeObject(iMap);
        oos.flush();
        oos.close();

        byte[] testBytes = streamTest.toByteArray();
        byte[] realBytes = streamReal.toByteArray();
        assertEquals(realBytes.length, testBytes.length);
        assertTrue(Arrays.equals(realBytes, testBytes));
    }

    @Test
    public void testSerializeStreamClosesStream() throws Exception {
        // The contract states the stream is closed once the object is written.
        final boolean[] closed = new boolean[1];
        OutputStream tracking = new ByteArrayOutputStream() {
            @Override
            public void close() throws IOException {
                closed[0] = true;
                super.close();
            }
        };
        SerializationUtils.serialize(iMap, tracking);
        assertTrue("serialize(Serializable, OutputStream) must close the stream", closed[0]);
    }

    @Test
    public void testSerializeStreamNullObj() throws Exception {
        ByteArrayOutputStream streamTest = new ByteArrayOutputStream();
        SerializationUtils.serialize(null, streamTest);
        assertTrue(streamTest.size() > 0);

        ObjectInputStream in = new ObjectInputStream(new ByteArrayInputStream(streamTest.toByteArray()));
        assertNull(in.readObject());
        in.close();
    }

    @Test
    public void testSerializeStreamNullStream() {
        try {
            SerializationUtils.serialize(iMap, null);
            fail("IllegalArgumentException expected for a null OutputStream");
        } catch (IllegalArgumentException ex) {
            assertEquals("The OutputStream must not be null", ex.getMessage());
        }
    }

    @Test
    public void testSerializeStreamUnserializable() {
        iMap.put(new Object(), new Object());
        ByteArrayOutputStream streamTest = new ByteArrayOutputStream();
        try {
            SerializationUtils.serialize(iMap, streamTest);
            fail("SerializationException expected for a non-Serializable payload");
        } catch (SerializationException ex) {
            assertTrue(ex.getCause() instanceof IOException);
        }
    }

    //-----------------------------------------------------------------------
    //  deserialize(byte[])
    //-----------------------------------------------------------------------
    @Test
    public void testDeserializeBytes() {
        Object result = SerializationUtils.deserialize(SerializationUtils.serialize(iMap));
        assertNotNull(result);
        assertTrue(result instanceof HashMap);
        assertNotSame(iMap, result);
        assertEquals(iMap, result);
    }

    @Test
    public void testDeserializeBytesPreservesType() {
        Object result = SerializationUtils.deserialize(SerializationUtils.serialize(iString));
        assertEquals("foo", result);
        assertTrue(result instanceof String);
    }

    @Test
    public void testDeserializeBytesOfNull() {
        byte[] nullEncoded = SerializationUtils.serialize(null);
        assertNull(SerializationUtils.deserialize(nullEncoded));
    }

    @Test
    public void testDeserializeBytesNull() {
        try {
            SerializationUtils.deserialize((byte[]) null);
            fail("IllegalArgumentException expected for a null byte[]");
        } catch (IllegalArgumentException ex) {
            assertEquals("The byte[] must not be null", ex.getMessage());
        }
    }

    @Test
    public void testDeserializeBytesBadData() {
        try {
            SerializationUtils.deserialize(new byte[] { 0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9 });
            fail("SerializationException expected for a corrupt stream");
        } catch (SerializationException ex) {
            assertTrue(ex.getCause() instanceof IOException);
        }
    }

    @Test
    public void testDeserializeBytesEmpty() {
        try {
            SerializationUtils.deserialize(new byte[0]);
            fail("SerializationException expected for an empty stream");
        } catch (SerializationException ex) {
            assertTrue(ex.getCause() instanceof IOException);
        }
    }

    //-----------------------------------------------------------------------
    //  deserialize(InputStream)
    //-----------------------------------------------------------------------
    @Test
    public void testDeserializeStream() {
        InputStream stream = new ByteArrayInputStream(SerializationUtils.serialize(iMap));
        Object result = SerializationUtils.deserialize(stream);
        assertNotNull(result);
        assertNotSame(iMap, result);
        assertEquals(iMap, result);
    }

    @Test
    public void testDeserializeStreamOfNull() {
        InputStream stream = new ByteArrayInputStream(SerializationUtils.serialize(null));
        assertNull(SerializationUtils.deserialize(stream));
    }

    @Test
    public void testDeserializeStreamNull() {
        try {
            SerializationUtils.deserialize((InputStream) null);
            fail("IllegalArgumentException expected for a null InputStream");
        } catch (IllegalArgumentException ex) {
            assertEquals("The InputStream must not be null", ex.getMessage());
        }
    }

    @Test
    public void testDeserializeStreamBadData() {
        try {
            SerializationUtils.deserialize(new ByteArrayInputStream(
                    new byte[] { 0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9 }));
            fail("SerializationException expected for a corrupt stream");
        } catch (SerializationException ex) {
            assertTrue(ex.getCause() instanceof IOException);
        }
    }

    //-----------------------------------------------------------------------
    //  clone(Serializable)
    //-----------------------------------------------------------------------
    @Test
    public void testClone() {
        HashMap<Object, Object> clone = SerializationUtils.clone(iMap);
        assertNotNull(clone);
        assertNotSame(iMap, clone);
        assertEquals(iMap, clone);
        assertEquals(iString, clone.get("FOO"));
        assertEquals(iInteger, clone.get("BAR"));
    }

    @Test
    public void testCloneIsIndependentDeepCopy() {
        ArrayList<Date> original = new ArrayList<Date>();
        original.add(new Date(1000L));

        ArrayList<Date> clone = SerializationUtils.clone(original);
        assertEquals(original, clone);
        assertNotSame(original, clone);
        // A deep clone: the nested mutable element is a distinct instance.
        assertNotSame(original.get(0), clone.get(0));

        // Mutating the copy must not disturb the original.
        clone.get(0).setTime(5000L);
        clone.add(new Date(2000L));
        assertEquals(1000L, original.get(0).getTime());
        assertEquals(1, original.size());
    }

    @Test
    public void testCloneNull() {
        assertNull(SerializationUtils.clone(null));
    }

    @Test
    public void testCloneUnserializable() {
        iMap.put(new Object(), new Object());
        try {
            SerializationUtils.clone(iMap);
            fail("SerializationException expected when cloning a non-Serializable payload");
        } catch (SerializationException ex) {
            assertTrue(ex.getCause() instanceof IOException);
        }
    }

    @Test
    public void testPrimitiveTypeClassSerialization() {
        Class<?>[] primitiveTypes = { byte.class, short.class, int.class, long.class,
                float.class, double.class, boolean.class, char.class, void.class };

        for (Class<?> primitiveType : primitiveTypes) {
            Class<?> clone = SerializationUtils.clone(primitiveType);
            assertEquals(primitiveType, clone);
        }
    }

    @Test
    public void testCloneSerializableSubtypeIsReturned() {
        Integer original = Integer.valueOf(42);
        Integer clone = SerializationUtils.clone(original);
        assertEquals(original, clone);
    }
}
