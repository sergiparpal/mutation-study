package org.apache.commons.csv;

import java.io.IOException;
import java.io.StringReader;

import junit.framework.TestCase;

/**
 * Self-contained JUnit 3.8 tests for {@link org.apache.commons.csv.Lexer}.
 *
 * <p>{@code Lexer} is an abstract, package-private class, so this test lives in
 * the {@code org.apache.commons.csv} package and exercises the class through a
 * tiny local concrete subclass ({@link ConcreteLexer}).  Every expectation is
 * taken from the documented contract published in {@code api/Lexer.html} and the
 * package description; where the Javadoc is silent the assertions stick to what
 * the contract clearly implies (for instance that the end-of-stream marker is
 * the usual {@code -1} returned by {@link java.io.Reader#read()}).</p>
 */
public class LexerAgentTest extends TestCase {

    /**
     * Minimal concrete {@link Lexer}. It only exists so the abstract base class
     * can be instantiated; {@link #nextToken(Token)} is never invoked by these
     * tests.
     */
    private static final class ConcreteLexer extends Lexer {

        ConcreteLexer(final CSVFormat format, final ExtendedBufferedReader in) {
            super(format, in);
        }

        @Override
        Token nextToken(final Token reusableToken) throws IOException {
            return reusableToken;
        }
    }

    private static ExtendedBufferedReader reader(final String content) {
        return new ExtendedBufferedReader(new StringReader(content));
    }

    private static Lexer defaultLexer(final String content) {
        return new ConcreteLexer(CSVFormat.DEFAULT, reader(content));
    }

    /** A copy of {@code CSVFormat.DEFAULT} with a single setting overridden. */
    private static CSVFormat customDelimiter(final char delimiter) {
        return CSVFormat.newBuilder(CSVFormat.DEFAULT).withDelimiter(delimiter).build();
    }

    private static CSVFormat withEscape() {
        return CSVFormat.newBuilder(CSVFormat.DEFAULT).withEscape('\\').build();
    }

    // ------------------------------------------------------------------
    // constructor / field wiring
    // ------------------------------------------------------------------

    public void testConstructorKeepsTheGivenFormat() throws IOException {
        final Lexer lexer = new ConcreteLexer(CSVFormat.DEFAULT, reader(""));
        assertSame(CSVFormat.DEFAULT, lexer.format);
    }

    public void testConstructorKeepsTheGivenInputStream() throws IOException {
        final ExtendedBufferedReader in = reader("");
        final Lexer lexer = new ConcreteLexer(CSVFormat.DEFAULT, in);
        assertSame(in, lexer.in);
    }

    public void testIgnoreEmptyLinesIsTakenFromFormat() throws IOException {
        final CSVFormat on = CSVFormat.newBuilder(CSVFormat.DEFAULT).withIgnoreEmptyLines(true).build();
        final CSVFormat off = CSVFormat.newBuilder(CSVFormat.DEFAULT).withIgnoreEmptyLines(false).build();
        assertTrue(new ConcreteLexer(on, reader("")).ignoreEmptyLines);
        assertFalse(new ConcreteLexer(off, reader("")).ignoreEmptyLines);
    }

    public void testIgnoreSurroundingSpacesIsTakenFromFormat() throws IOException {
        final CSVFormat on = CSVFormat.newBuilder(CSVFormat.DEFAULT).withIgnoreSurroundingSpaces(true).build();
        final CSVFormat off = CSVFormat.newBuilder(CSVFormat.DEFAULT).withIgnoreSurroundingSpaces(false).build();
        assertTrue(new ConcreteLexer(on, reader("")).ignoreSurroundingSpaces);
        assertFalse(new ConcreteLexer(off, reader("")).ignoreSurroundingSpaces);
    }

    // ------------------------------------------------------------------
    // getLineNumber()
    // ------------------------------------------------------------------

    public void testLineNumberIsZeroBeforeAnythingIsRead() throws IOException {
        final Lexer lexer = defaultLexer("a\nb\nc");
        assertEquals(0L, lexer.getLineNumber());
    }

    public void testLineNumberFollowsTheNewlinesConsumedFromInput() throws IOException {
        final ExtendedBufferedReader in = reader("a\nb\nc");
        final Lexer lexer = new ConcreteLexer(CSVFormat.DEFAULT, in);
        while (in.read() != -1) {
            // drain the reader; the content holds exactly two '\n'
        }
        assertEquals(2L, lexer.getLineNumber());
    }

    // ------------------------------------------------------------------
    // isDelimiter(int)
    // ------------------------------------------------------------------

    public void testIsDelimiterForDefaultComma() throws IOException {
        final Lexer lexer = defaultLexer("");
        assertTrue(lexer.isDelimiter(','));
        assertFalse(lexer.isDelimiter(';'));
        assertFalse(lexer.isDelimiter('a'));
    }

    public void testIsDelimiterFollowsConfiguredDelimiter() throws IOException {
        final Lexer lexer = new ConcreteLexer(customDelimiter(';'), reader(""));
        assertTrue(lexer.isDelimiter(';'));
        assertFalse(lexer.isDelimiter(','));
    }

    // ------------------------------------------------------------------
    // isQuoteChar(int)
    // ------------------------------------------------------------------

    public void testIsQuoteCharForDefaultDoubleQuote() throws IOException {
        final Lexer lexer = defaultLexer("");
        assertTrue(lexer.isQuoteChar('"'));
        assertFalse(lexer.isQuoteChar('\''));
        assertFalse(lexer.isQuoteChar('a'));
    }

    // ------------------------------------------------------------------
    // isCommentStart(int)
    // ------------------------------------------------------------------

    public void testIsCommentStartIsFalseWhenNoMarkerConfigured() throws IOException {
        // CSVFormat.DEFAULT has no comment marker ("default none" in the package doc).
        final Lexer lexer = defaultLexer("");
        assertFalse(lexer.isCommentStart('#'));
        assertFalse(lexer.isCommentStart('/'));
        assertFalse(lexer.isCommentStart('a'));
    }

    public void testIsCommentStartFollowsConfiguredMarker() throws IOException {
        final CSVFormat format = CSVFormat.newBuilder(CSVFormat.DEFAULT).withCommentStart('#').build();
        final Lexer lexer = new ConcreteLexer(format, reader(""));
        assertTrue(lexer.isCommentStart('#'));
        assertFalse(lexer.isCommentStart('a'));
    }

    // ------------------------------------------------------------------
    // isEscape(int)
    // ------------------------------------------------------------------

    public void testIsEscapeIsFalseWhenNoEscapeConfigured() throws IOException {
        final Lexer lexer = defaultLexer("");
        assertFalse(lexer.isEscape('\\'));
        assertFalse(lexer.isEscape('a'));
    }

    public void testIsEscapeFollowsConfiguredEscape() throws IOException {
        final Lexer lexer = new ConcreteLexer(withEscape(), reader(""));
        assertTrue(lexer.isEscape('\\'));
        assertFalse(lexer.isEscape('/'));
    }

    // ------------------------------------------------------------------
    // isWhitespace(int)
    // ------------------------------------------------------------------

    public void testIsWhitespaceForSpaceAndTab() throws IOException {
        final Lexer lexer = defaultLexer("");
        assertTrue(lexer.isWhitespace(' '));
        assertTrue(lexer.isWhitespace('\t'));
    }

    public void testIsWhitespaceIsFalseForPrintableCharsAndDelimiter() throws IOException {
        final Lexer lexer = defaultLexer("");
        assertFalse(lexer.isWhitespace('a'));
        assertFalse(lexer.isWhitespace('5'));
        assertFalse(lexer.isWhitespace('"'));
        // the delimiter is not classified as whitespace
        assertFalse(lexer.isWhitespace(','));
    }

    // ------------------------------------------------------------------
    // isStartOfLine(int)
    // ------------------------------------------------------------------

    public void testIsStartOfLineForCarriageReturnAndLineFeed() throws IOException {
        final Lexer lexer = defaultLexer("");
        assertTrue(lexer.isStartOfLine('\r'));
        assertTrue(lexer.isStartOfLine('\n'));
    }

    public void testIsStartOfLineIsFalseForContentCharacters() throws IOException {
        final Lexer lexer = defaultLexer("");
        assertFalse(lexer.isStartOfLine('a'));
        assertFalse(lexer.isStartOfLine(' '));
        assertFalse(lexer.isStartOfLine(','));
        assertFalse(lexer.isStartOfLine('"'));
    }

    // ------------------------------------------------------------------
    // isEndOfFile(int)
    // ------------------------------------------------------------------

    public void testIsEndOfFileForStreamEndMarker() throws IOException {
        final Lexer lexer = defaultLexer("");
        assertTrue(lexer.isEndOfFile(-1));
    }

    public void testIsEndOfFileIsFalseForRealCharacters() throws IOException {
        final Lexer lexer = defaultLexer("");
        assertFalse(lexer.isEndOfFile('a'));
        assertFalse(lexer.isEndOfFile(0));
        assertFalse(lexer.isEndOfFile(' '));
        assertFalse(lexer.isEndOfFile('\n'));
    }

    // ------------------------------------------------------------------
    // readEndOfLine(int)
    // ------------------------------------------------------------------

    public void testReadEndOfLineAcceptsBareLineFeed() throws IOException {
        final ExtendedBufferedReader in = reader("rest");
        final Lexer lexer = new ConcreteLexer(CSVFormat.DEFAULT, in);
        assertTrue(lexer.readEndOfLine('\n'));
        // '\n' was supplied directly; nothing is consumed from the stream
        assertEquals('r', in.read());
    }

    public void testReadEndOfLineAcceptsBareCarriageReturn() throws IOException {
        final ExtendedBufferedReader in = reader("x");
        final Lexer lexer = new ConcreteLexer(CSVFormat.DEFAULT, in);
        assertTrue(lexer.readEndOfLine('\r'));
        // lone '\r' (next char is not '\n'): the following char stays in the stream
        assertEquals('x', in.read());
    }

    public void testReadEndOfLineGreedilyConsumesLineFeedAfterCarriageReturn() throws IOException {
        final ExtendedBufferedReader in = reader("\nAFTER");
        final Lexer lexer = new ConcreteLexer(CSVFormat.DEFAULT, in);
        // models "\r\n": '\r' already read and supplied, '\n' still in the stream
        assertTrue(lexer.readEndOfLine('\r'));
        // the second control character of "\r\n" was silently consumed
        assertEquals('A', in.read());
    }

    public void testReadEndOfLineRejectsOrdinaryCharacters() throws IOException {
        final Lexer lexer = defaultLexer("");
        assertFalse(lexer.readEndOfLine('a'));
        assertFalse(lexer.readEndOfLine(-1));
    }

    // ------------------------------------------------------------------
    // readEscape()
    // ------------------------------------------------------------------

    public void testReadEscapeTranslatesNToLineFeed() throws IOException {
        final ExtendedBufferedReader in = reader("\\n");
        final Lexer lexer = new ConcreteLexer(withEscape(), in);
        // contract: on entry the current character must be the escape character
        assertEquals('\\', in.read());
        final int unescaped = lexer.readEscape();
        assertEquals('\n', unescaped);
        assertFalse(lexer.isEndOfFile(unescaped));
        // contract: the following character is available via getLastChar()
        assertEquals('n', in.getLastChar());
    }

    public void testReadEscapeTranslatesTToTab() throws IOException {
        final ExtendedBufferedReader in = reader("\\t");
        final Lexer lexer = new ConcreteLexer(withEscape(), in);
        assertEquals('\\', in.read());
        assertEquals('\t', lexer.readEscape());
    }

    public void testReadEscapeTranslatesRToCarriageReturn() throws IOException {
        final ExtendedBufferedReader in = reader("\\r");
        final Lexer lexer = new ConcreteLexer(withEscape(), in);
        assertEquals('\\', in.read());
        assertEquals('\r', lexer.readEscape());
    }

    public void testReadEscapeAtEndOfStreamThrows() throws IOException {
        final ExtendedBufferedReader in = reader("\\");
        final Lexer lexer = new ConcreteLexer(withEscape(), in);
        assertEquals('\\', in.read());
        try {
            lexer.readEscape();
            fail("readEscape() must throw when the escape char is the last char in the stream");
        } catch (final IOException expected) {
            // documented: "the escape character is not allowed at end of stream"
        }
    }

    public void testReadEscapeReturnsStreamEndMarkerForInvalidEscape() throws IOException {
        final ExtendedBufferedReader in = reader("\\q");
        final Lexer lexer = new ConcreteLexer(withEscape(), in);
        assertEquals('\\', in.read());
        final int result = lexer.readEscape();
        // documented: END_OF_STREAM is returned if the char following the escape is invalid
        assertTrue("invalid escape must be reported as the end-of-stream marker",
                lexer.isEndOfFile(result));
        assertEquals('q', in.getLastChar());
    }

    // ------------------------------------------------------------------
    // trimTrailingSpaces(StringBuilder)
    // ------------------------------------------------------------------

    public void testTrimTrailingSpacesDropsTrailingSpaces() throws IOException {
        final Lexer lexer = defaultLexer("");
        final StringBuilder buffer = new StringBuilder("value   ");
        lexer.trimTrailingSpaces(buffer);
        assertEquals("value", buffer.toString());
    }

    public void testTrimTrailingSpacesLeavesCleanTextUntouched() throws IOException {
        final Lexer lexer = defaultLexer("");
        final StringBuilder buffer = new StringBuilder("value");
        lexer.trimTrailingSpaces(buffer);
        assertEquals("value", buffer.toString());
    }

    public void testTrimTrailingSpacesTurnsAnAllSpacesBufferIntoEmpty() throws IOException {
        final Lexer lexer = defaultLexer("");
        final StringBuilder buffer = new StringBuilder("     ");
        lexer.trimTrailingSpaces(buffer);
        assertEquals("", buffer.toString());
        assertEquals(0, buffer.length());
    }

    public void testTrimTrailingSpacesOnEmptyBufferIsANoOp() throws IOException {
        final Lexer lexer = defaultLexer("");
        final StringBuilder buffer = new StringBuilder();
        lexer.trimTrailingSpaces(buffer);
        assertEquals("", buffer.toString());
    }

    public void testTrimTrailingSpacesKeepsLeadingAndInteriorSpaces() throws IOException {
        final Lexer lexer = defaultLexer("");
        final StringBuilder buffer = new StringBuilder("  a b  c  ");
        lexer.trimTrailingSpaces(buffer);
        assertEquals("  a b  c", buffer.toString());
    }
}
