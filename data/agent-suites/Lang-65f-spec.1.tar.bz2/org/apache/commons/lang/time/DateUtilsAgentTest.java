package org.apache.commons.lang.time;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.TimeZone;

import org.junit.Test;

/**
 * Self-contained JUnit tests for {@link org.apache.commons.lang.time.DateUtils}.
 *
 * Every expectation here is taken from the published javadoc contract in
 * <code>api/</code> (method descriptions, worked examples and
 * <code>constant-values.html</code>). Where the javadoc gives concrete worked
 * examples (rounding/truncating "28 Mar 2002 13:45:01.231", the July 4, 2002
 * iterator range, ...) those examples are asserted verbatim.
 *
 * The class deliberately defines its own small fixture helpers rather than
 * relying on any shared test base class.
 */
public class DateUtilsAgentTest {

    // ------------------------------------------------------------------
    // fixture helpers (local to this file - no external test helper used)
    // ------------------------------------------------------------------

    /** Build a Calendar with exactly the supplied civil-time fields set. */
    private static Calendar makeCal(int year, int month, int day,
                                    int hour, int min, int sec, int ms) {
        Calendar c = Calendar.getInstance();
        c.clear();
        c.set(year, month, day, hour, min, sec);
        c.set(Calendar.MILLISECOND, ms);
        c.getTimeInMillis(); // force completion so later get() calls are stable
        return c;
    }

    private static Date makeDate(int year, int month, int day,
                                 int hour, int min, int sec, int ms) {
        return makeCal(year, month, day, hour, min, sec, ms).getTime();
    }

    private static Calendar toCal(Object dateOrCal) {
        if (dateOrCal instanceof Calendar) {
            return (Calendar) dateOrCal;
        }
        Calendar c = Calendar.getInstance();
        c.setTime((Date) dateOrCal);
        return c;
    }

    private static void assertYMD(String msg, Object dateOrCal,
                                  int year, int month, int day) {
        Calendar c = toCal(dateOrCal);
        assertEquals(msg + " [year]", year, c.get(Calendar.YEAR));
        assertEquals(msg + " [month]", month, c.get(Calendar.MONTH));
        assertEquals(msg + " [day]", day, c.get(Calendar.DAY_OF_MONTH));
    }

    private static void assertFields(String msg, Object dateOrCal,
                                     int year, int month, int day,
                                     int hour, int min, int sec, int ms) {
        Calendar c = toCal(dateOrCal);
        assertEquals(msg + " [year]", year, c.get(Calendar.YEAR));
        assertEquals(msg + " [month]", month, c.get(Calendar.MONTH));
        assertEquals(msg + " [day]", day, c.get(Calendar.DAY_OF_MONTH));
        assertEquals(msg + " [hour]", hour, c.get(Calendar.HOUR_OF_DAY));
        assertEquals(msg + " [minute]", min, c.get(Calendar.MINUTE));
        assertEquals(msg + " [second]", sec, c.get(Calendar.SECOND));
        assertEquals(msg + " [milli]", ms, c.get(Calendar.MILLISECOND));
    }

    // ------------------------------------------------------------------
    // documented constants (api/constant-values.html)
    // ------------------------------------------------------------------

    @Test
    public void millisPerConstantsHaveDocumentedValues() {
        assertEquals(1000L, DateUtils.MILLIS_PER_SECOND);
        assertEquals(60000L, DateUtils.MILLIS_PER_MINUTE);
        assertEquals(3600000L, DateUtils.MILLIS_PER_HOUR);
        assertEquals(86400000L, DateUtils.MILLIS_PER_DAY);
    }

    @Test
    public void deprecatedMillisInConstantsHaveDocumentedValues() {
        assertEquals(1000, DateUtils.MILLIS_IN_SECOND);
        assertEquals(60000, DateUtils.MILLIS_IN_MINUTE);
        assertEquals(3600000, DateUtils.MILLIS_IN_HOUR);
        assertEquals(86400000, DateUtils.MILLIS_IN_DAY);
    }

    @Test
    public void rangeAndSemiMonthConstantsHaveDocumentedValues() {
        assertEquals(1, DateUtils.RANGE_WEEK_SUNDAY);
        assertEquals(2, DateUtils.RANGE_WEEK_MONDAY);
        assertEquals(3, DateUtils.RANGE_WEEK_RELATIVE);
        assertEquals(4, DateUtils.RANGE_WEEK_CENTER);
        assertEquals(5, DateUtils.RANGE_MONTH_SUNDAY);
        assertEquals(6, DateUtils.RANGE_MONTH_MONDAY);
        assertEquals(1001, DateUtils.SEMI_MONTH);
    }

    @Test
    public void utcTimeZoneIsAZeroOffsetNonDstZone() {
        assertNotNull(DateUtils.UTC_TIME_ZONE);
        assertEquals(0, DateUtils.UTC_TIME_ZONE.getRawOffset());
        assertFalse(DateUtils.UTC_TIME_ZONE.useDaylightTime());
    }

    @Test
    public void publicConstructorIsAvailableForToolingSupport() {
        assertNotNull(new DateUtils());
    }

    // ------------------------------------------------------------------
    // isSameDay
    // ------------------------------------------------------------------

    @Test
    public void isSameDayDate_trueWhenSameCalendarDayIgnoringTime() {
        // javadoc: "28 Mar 2002 13:45 and 28 Mar 2002 06:01 would return true."
        Date d1 = makeDate(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        Date d2 = makeDate(2002, Calendar.MARCH, 28, 6, 1, 0, 0);
        assertTrue(DateUtils.isSameDay(d1, d2));
    }

    @Test
    public void isSameDayDate_falseForDifferentDayOrDifferentYear() {
        // javadoc: "28 Mar 2002 13:45 and 12 Mar 2002 13:45 would return false."
        Date d1 = makeDate(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        Date d2 = makeDate(2002, Calendar.MARCH, 12, 13, 45, 0, 0);
        assertFalse(DateUtils.isSameDay(d1, d2));

        Date sameDateNextYear = makeDate(2003, Calendar.MARCH, 28, 13, 45, 0, 0);
        assertFalse(DateUtils.isSameDay(d1, sameDateNextYear));
    }

    @Test
    public void isSameDayDate_nullThrowsIllegalArgument() {
        Date d = new Date();
        try {
            DateUtils.isSameDay((Date) null, d);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
        }
        try {
            DateUtils.isSameDay(d, (Date) null);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
        }
    }

    @Test
    public void isSameDayCalendar_trueAndFalse() {
        Calendar c1 = makeCal(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        Calendar c2 = makeCal(2002, Calendar.MARCH, 28, 6, 1, 0, 0);
        Calendar c3 = makeCal(2002, Calendar.MARCH, 12, 13, 45, 0, 0);
        assertTrue(DateUtils.isSameDay(c1, c2));
        assertFalse(DateUtils.isSameDay(c1, c3));
    }

    @Test
    public void isSameDayCalendar_nullThrowsIllegalArgument() {
        Calendar c = Calendar.getInstance();
        try {
            DateUtils.isSameDay((Calendar) null, c);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
        }
        try {
            DateUtils.isSameDay(c, (Calendar) null);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
        }
    }

    // ------------------------------------------------------------------
    // isSameInstant
    // ------------------------------------------------------------------

    @Test
    public void isSameInstantDate_comparesMillisecondValue() {
        assertTrue(DateUtils.isSameInstant(new Date(1234L), new Date(1234L)));
        assertFalse(DateUtils.isSameInstant(new Date(1234L), new Date(1235L)));
    }

    @Test
    public void isSameInstantDate_nullThrowsIllegalArgument() {
        try {
            DateUtils.isSameInstant((Date) null, new Date());
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
        }
        try {
            DateUtils.isSameInstant(new Date(), (Date) null);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
        }
    }

    @Test
    public void isSameInstantCalendar_trueAcrossZonesEvenWhenLocalTimeDiffers() {
        long instant = 1119081600000L;
        Calendar gmt = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
        Calendar gmtPlus5 = Calendar.getInstance(TimeZone.getTimeZone("GMT+05:00"));
        gmt.setTimeInMillis(instant);
        gmtPlus5.setTimeInMillis(instant);

        // same millisecond instant -> isSameInstant is true ...
        assertTrue(DateUtils.isSameInstant(gmt, gmtPlus5));
        // ... but the wall-clock fields differ by five hours, so local time is not the same
        assertFalse(DateUtils.isSameLocalTime(gmt, gmtPlus5));
    }

    @Test
    public void isSameInstantCalendar_falseForDifferentInstants() {
        Calendar a = Calendar.getInstance();
        a.setTimeInMillis(1000L);
        Calendar b = Calendar.getInstance();
        b.setTimeInMillis(2000L);
        assertFalse(DateUtils.isSameInstant(a, b));
    }

    @Test
    public void isSameInstantCalendar_nullThrowsIllegalArgument() {
        Calendar c = Calendar.getInstance();
        try {
            DateUtils.isSameInstant((Calendar) null, c);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
        }
        try {
            DateUtils.isSameInstant(c, (Calendar) null);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
        }
    }

    // ------------------------------------------------------------------
    // isSameLocalTime
    // ------------------------------------------------------------------

    @Test
    public void isSameLocalTime_trueForEqualFieldsFalseAfterChange() {
        Calendar a = makeCal(2005, Calendar.JUNE, 18, 10, 30, 45, 250);
        Calendar b = (Calendar) a.clone();
        assertTrue(DateUtils.isSameLocalTime(a, b));

        b.add(Calendar.HOUR_OF_DAY, 1);
        assertFalse(DateUtils.isSameLocalTime(a, b));
    }

    @Test
    public void isSameLocalTime_nullThrowsIllegalArgument() {
        Calendar c = Calendar.getInstance();
        try {
            DateUtils.isSameLocalTime(null, c);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
        }
        try {
            DateUtils.isSameLocalTime(c, null);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
        }
    }

    // ------------------------------------------------------------------
    // parseDate
    // ------------------------------------------------------------------

    @Test
    public void parseDate_parsesWithSuppliedPattern() throws Exception {
        Date d = DateUtils.parseDate("2005-06-18", new String[] { "yyyy-MM-dd" });
        assertFields("parsed date", d, 2005, Calendar.JUNE, 18, 0, 0, 0, 0);
    }

    @Test
    public void parseDate_triesEachPatternInTurn() throws Exception {
        Date d = DateUtils.parseDate("2005-06-18",
                new String[] { "MM/dd/yyyy", "yyyy-MM-dd" });
        assertYMD("parsed via second pattern", d, 2005, Calendar.JUNE, 18);
    }

    @Test
    public void parseDate_noMatchingPatternThrowsParseException() {
        try {
            DateUtils.parseDate("not-a-date", new String[] { "yyyy-MM-dd" });
            fail("expected ParseException");
        } catch (ParseException expected) {
        }
    }

    @Test
    public void parseDate_onlySucceedsWhenWholeInputIsConsumed() {
        try {
            DateUtils.parseDate("2005-06-18 plus trailing text",
                    new String[] { "yyyy-MM-dd" });
            fail("expected ParseException because the whole string is not parsed");
        } catch (ParseException expected) {
        }
    }

    @Test
    public void parseDate_emptyPatternArrayThrowsParseException() {
        try {
            DateUtils.parseDate("2005-06-18", new String[0]);
            fail("expected ParseException");
        } catch (ParseException expected) {
        }
    }

    @Test
    public void parseDate_nullArgumentsThrowIllegalArgument() throws Exception {
        try {
            DateUtils.parseDate(null, new String[] { "yyyy-MM-dd" });
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
        }
        try {
            DateUtils.parseDate("2005-06-18", null);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
        }
    }

    // ------------------------------------------------------------------
    // addYears / addMonths / addWeeks / addDays
    // ------------------------------------------------------------------

    @Test
    public void addYears_addsAmountAndLeavesOriginalUnchanged() {
        Date base = makeDate(2005, Calendar.JUNE, 15, 10, 30, 45, 500);
        long baseMillis = base.getTime();

        Date plus = DateUtils.addYears(base, 3);
        assertFields("addYears(+3)", plus, 2008, Calendar.JUNE, 15, 10, 30, 45, 500);
        assertEquals("original date must not be mutated", baseMillis, base.getTime());

        Date minus = DateUtils.addYears(base, -3);
        assertFields("addYears(-3)", minus, 2002, Calendar.JUNE, 15, 10, 30, 45, 500);
    }

    @Test
    public void addMonths_addsAndSubtracts() {
        Date base = makeDate(2005, Calendar.JUNE, 15, 1, 2, 3, 4);
        assertFields("addMonths(+2)", DateUtils.addMonths(base, 2),
                2005, Calendar.AUGUST, 15, 1, 2, 3, 4);
        assertFields("addMonths(-1)", DateUtils.addMonths(base, -1),
                2005, Calendar.MAY, 15, 1, 2, 3, 4);
    }

    @Test
    public void addWeeks_movesBySevenDaysPerWeek() {
        Date base = makeDate(2005, Calendar.JUNE, 15, 12, 0, 0, 0);
        assertYMD("addWeeks(+2)", DateUtils.addWeeks(base, 2), 2005, Calendar.JUNE, 29);
        assertYMD("addWeeks(-1)", DateUtils.addWeeks(base, -1), 2005, Calendar.JUNE, 8);
    }

    @Test
    public void addDays_movesByDaysAcrossMonthBoundary() {
        Date base = makeDate(2005, Calendar.JUNE, 15, 12, 0, 0, 0);
        assertYMD("addDays(+10)", DateUtils.addDays(base, 10), 2005, Calendar.JUNE, 25);
        assertYMD("addDays(-20)", DateUtils.addDays(base, -20), 2005, Calendar.MAY, 26);
    }

    @Test
    public void addDays_zeroAmountReturnsEqualButDistinctObject() {
        Date base = makeDate(2005, Calendar.JUNE, 15, 12, 30, 0, 0);
        Date copy = DateUtils.addDays(base, 0);
        assertEquals("value must be identical", base, copy);
        assertNotSame("a new object must be returned", base, copy);
    }

    // ------------------------------------------------------------------
    // addHours / addMinutes / addSeconds / addMilliseconds
    // (these fields shift the instant by an exact amount of milliseconds)
    // ------------------------------------------------------------------

    @Test
    public void addHours_shiftsInstantExactly() {
        Date base = new Date(1000000L);
        assertEquals(1000000L + 3L * 3600000L, DateUtils.addHours(base, 3).getTime());
        assertEquals(1000000L - 2L * 3600000L, DateUtils.addHours(base, -2).getTime());
        assertEquals("original unchanged", 1000000L, base.getTime());
    }

    @Test
    public void addMinutes_shiftsInstantExactly() {
        Date base = new Date(1000000L);
        assertEquals(1000000L + 5L * 60000L, DateUtils.addMinutes(base, 5).getTime());
        assertEquals(1000000L - 90L * 60000L, DateUtils.addMinutes(base, -90).getTime());
    }

    @Test
    public void addSeconds_shiftsInstantExactly() {
        Date base = new Date(1000000L);
        assertEquals(1000000L + 7L * 1000L, DateUtils.addSeconds(base, 7).getTime());
    }

    @Test
    public void addMilliseconds_shiftsInstantExactly() {
        Date base = new Date(1000000L);
        assertEquals(1000000L + 250L, DateUtils.addMilliseconds(base, 250).getTime());
        assertEquals(1000000L - 400L, DateUtils.addMilliseconds(base, -400).getTime());
    }

    @Test
    public void addFamily_nullDateThrowsIllegalArgument() {
        try { DateUtils.addYears(null, 1); fail("addYears"); }
        catch (IllegalArgumentException expected) { }
        try { DateUtils.addMonths(null, 1); fail("addMonths"); }
        catch (IllegalArgumentException expected) { }
        try { DateUtils.addWeeks(null, 1); fail("addWeeks"); }
        catch (IllegalArgumentException expected) { }
        try { DateUtils.addDays(null, 1); fail("addDays"); }
        catch (IllegalArgumentException expected) { }
        try { DateUtils.addHours(null, 1); fail("addHours"); }
        catch (IllegalArgumentException expected) { }
        try { DateUtils.addMinutes(null, 1); fail("addMinutes"); }
        catch (IllegalArgumentException expected) { }
        try { DateUtils.addSeconds(null, 1); fail("addSeconds"); }
        catch (IllegalArgumentException expected) { }
        try { DateUtils.addMilliseconds(null, 1); fail("addMilliseconds"); }
        catch (IllegalArgumentException expected) { }
    }

    // ------------------------------------------------------------------
    // add(Date, int calendarField, int amount)
    // ------------------------------------------------------------------

    @Test
    public void add_appliesGivenCalendarField() {
        Date instantBase = new Date(1000000L);
        assertEquals(1000000L + 250L,
                DateUtils.add(instantBase, Calendar.MILLISECOND, 250).getTime());

        Date ymdBase = makeDate(2005, Calendar.JUNE, 15, 12, 0, 0, 0);
        assertYMD("add(YEAR,+1)", DateUtils.add(ymdBase, Calendar.YEAR, 1),
                2006, Calendar.JUNE, 15);
        assertYMD("add(MONTH,-2)", DateUtils.add(ymdBase, Calendar.MONTH, -2),
                2005, Calendar.APRIL, 15);
        assertEquals("original unchanged", makeDate(2005, Calendar.JUNE, 15, 12, 0, 0, 0),
                ymdBase);
    }

    @Test
    public void add_nullDateThrowsIllegalArgument() {
        try {
            DateUtils.add(null, Calendar.DATE, 1);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
        }
    }

    // ------------------------------------------------------------------
    // round (Date / Calendar / Object)
    // ------------------------------------------------------------------

    @Test
    public void roundDate_toHourRoundsUpOrDownAtHalfHour() {
        // javadoc worked example: 28 Mar 2002 13:45:01.231 + HOUR -> 28 Mar 2002 14:00:00.000
        Date up = DateUtils.round(makeDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231),
                Calendar.HOUR_OF_DAY);
        assertFields("round HOUR (up)", up, 2002, Calendar.MARCH, 28, 14, 0, 0, 0);

        Date down = DateUtils.round(makeDate(2002, Calendar.MARCH, 28, 13, 10, 0, 0),
                Calendar.HOUR_OF_DAY);
        assertFields("round HOUR (down)", down, 2002, Calendar.MARCH, 28, 13, 0, 0, 0);
    }

    @Test
    public void roundDate_toMonthRoundsUpOrDown() {
        // javadoc worked example: 28 Mar 2002 13:45:01.231 + MONTH -> 1 April 2002 00:00:00.000
        Date up = DateUtils.round(makeDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231),
                Calendar.MONTH);
        assertFields("round MONTH (up)", up, 2002, Calendar.APRIL, 1, 0, 0, 0, 0);

        Date down = DateUtils.round(makeDate(2002, Calendar.MARCH, 5, 9, 15, 0, 0),
                Calendar.MONTH);
        assertFields("round MONTH (down)", down, 2002, Calendar.MARCH, 1, 0, 0, 0, 0);
    }

    @Test
    public void roundDate_toDayUsesMiddayAsMidpoint() {
        Date up = DateUtils.round(makeDate(2002, Calendar.MARCH, 28, 13, 45, 0, 0),
                Calendar.DATE);
        assertFields("round DATE (up)", up, 2002, Calendar.MARCH, 29, 0, 0, 0, 0);

        Date down = DateUtils.round(makeDate(2002, Calendar.MARCH, 28, 6, 1, 0, 0),
                Calendar.DATE);
        assertFields("round DATE (down)", down, 2002, Calendar.MARCH, 28, 0, 0, 0, 0);
    }

    @Test
    public void roundDate_nullThrowsIllegalArgument() {
        try {
            DateUtils.round((Date) null, Calendar.HOUR_OF_DAY);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
        }
    }

    @Test
    public void roundCalendar_returnsADifferentObjectAndDoesNotMutateInput() {
        Calendar input = makeCal(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        long before = input.getTimeInMillis();

        Calendar rounded = DateUtils.round(input, Calendar.HOUR_OF_DAY);

        assertNotSame("javadoc: rounded date is a different object", input, rounded);
        assertEquals("input calendar must be left unaltered", before, input.getTimeInMillis());
        assertFields("rounded calendar", rounded, 2002, Calendar.MARCH, 28, 14, 0, 0, 0);
    }

    @Test
    public void roundCalendar_nullThrowsIllegalArgument() {
        try {
            DateUtils.round((Calendar) null, Calendar.HOUR_OF_DAY);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
        }
    }

    @Test
    public void roundObject_acceptsDateOrCalendarAndReturnsDate() {
        Date fromDate = DateUtils.round(
                (Object) makeDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231),
                Calendar.HOUR_OF_DAY);
        assertFields("round(Object=Date)", fromDate, 2002, Calendar.MARCH, 28, 14, 0, 0, 0);

        Date fromCal = DateUtils.round(
                (Object) makeCal(2002, Calendar.MARCH, 28, 13, 45, 1, 231),
                Calendar.HOUR_OF_DAY);
        assertFields("round(Object=Calendar)", fromCal, 2002, Calendar.MARCH, 28, 14, 0, 0, 0);
    }

    @Test
    public void roundObject_unsupportedTypeThrowsClassCastException() {
        try {
            DateUtils.round("2002-03-28", Calendar.HOUR_OF_DAY);
            fail("expected ClassCastException");
        } catch (ClassCastException expected) {
        }
    }

    @Test
    public void roundObject_nullThrowsIllegalArgument() {
        try {
            DateUtils.round((Object) null, Calendar.HOUR_OF_DAY);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
        }
    }

    @Test
    public void round_yearWellOver280MillionThrowsArithmeticException() {
        Calendar huge = Calendar.getInstance();
        huge.set(Calendar.YEAR, 285000000);
        huge.set(Calendar.MONTH, Calendar.JUNE);
        huge.set(Calendar.DAY_OF_MONTH, 15);
        try {
            DateUtils.round(huge, Calendar.HOUR_OF_DAY);
            fail("expected ArithmeticException for year over 280 million");
        } catch (ArithmeticException expected) {
        }
    }

    // ------------------------------------------------------------------
    // truncate (Date / Calendar / Object)
    // ------------------------------------------------------------------

    @Test
    public void truncateDate_toHour() {
        // javadoc worked example: 28 Mar 2002 13:45:01.231 + HOUR -> 28 Mar 2002 13:00:00.000
        Date r = DateUtils.truncate(makeDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231),
                Calendar.HOUR_OF_DAY);
        assertFields("truncate HOUR", r, 2002, Calendar.MARCH, 28, 13, 0, 0, 0);
    }

    @Test
    public void truncateDate_toMonth() {
        // javadoc worked example: 28 Mar 2002 13:45:01.231 + MONTH -> 1 Mar 2002 00:00:00.000
        Date r = DateUtils.truncate(makeDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231),
                Calendar.MONTH);
        assertFields("truncate MONTH", r, 2002, Calendar.MARCH, 1, 0, 0, 0, 0);
    }

    @Test
    public void truncateDate_toDayAndToYear() {
        Date base = makeDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertFields("truncate DATE", DateUtils.truncate(base, Calendar.DATE),
                2002, Calendar.MARCH, 28, 0, 0, 0, 0);
        assertFields("truncate YEAR", DateUtils.truncate(base, Calendar.YEAR),
                2002, Calendar.JANUARY, 1, 0, 0, 0, 0);
    }

    @Test
    public void truncateDate_toSemiMonth() {
        // SEMI_MONTH: top half of the month truncates to the 1st, bottom half to the 16th.
        Date lower = DateUtils.truncate(makeDate(2002, Calendar.MARCH, 10, 13, 45, 1, 231),
                DateUtils.SEMI_MONTH);
        assertFields("truncate SEMI_MONTH (top half)", lower,
                2002, Calendar.MARCH, 1, 0, 0, 0, 0);

        Date upper = DateUtils.truncate(makeDate(2002, Calendar.MARCH, 20, 13, 45, 1, 231),
                DateUtils.SEMI_MONTH);
        assertFields("truncate SEMI_MONTH (bottom half)", upper,
                2002, Calendar.MARCH, 16, 0, 0, 0, 0);
    }

    @Test
    public void truncateDate_nullThrowsIllegalArgument() {
        try {
            DateUtils.truncate((Date) null, Calendar.HOUR_OF_DAY);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
        }
    }

    @Test
    public void truncateCalendar_returnsADifferentObjectAndDoesNotMutateInput() {
        Calendar input = makeCal(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        long before = input.getTimeInMillis();

        Calendar result = DateUtils.truncate(input, Calendar.HOUR_OF_DAY);

        assertNotSame("javadoc: truncated date is a different object", input, result);
        assertEquals("input calendar must be left unaltered", before, input.getTimeInMillis());
        assertFields("truncated calendar", result, 2002, Calendar.MARCH, 28, 13, 0, 0, 0);
    }

    @Test
    public void truncateCalendar_nullThrowsIllegalArgument() {
        try {
            DateUtils.truncate((Calendar) null, Calendar.HOUR_OF_DAY);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
        }
    }

    @Test
    public void truncateObject_acceptsDateOrCalendarAndReturnsDate() {
        Date fromDate = DateUtils.truncate(
                (Object) makeDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231),
                Calendar.HOUR_OF_DAY);
        assertFields("truncate(Object=Date)", fromDate,
                2002, Calendar.MARCH, 28, 13, 0, 0, 0);

        Date fromCal = DateUtils.truncate(
                (Object) makeCal(2002, Calendar.MARCH, 28, 13, 45, 1, 231),
                Calendar.HOUR_OF_DAY);
        assertFields("truncate(Object=Calendar)", fromCal,
                2002, Calendar.MARCH, 28, 13, 0, 0, 0);
    }

    @Test
    public void truncateObject_unsupportedTypeThrowsClassCastException() {
        try {
            DateUtils.truncate("not a date", Calendar.HOUR_OF_DAY);
            fail("expected ClassCastException");
        } catch (ClassCastException expected) {
        }
    }

    @Test
    public void truncateObject_nullThrowsIllegalArgument() {
        try {
            DateUtils.truncate((Object) null, Calendar.HOUR_OF_DAY);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
        }
    }

    // ------------------------------------------------------------------
    // iterator (Date / Calendar / Object)
    // ------------------------------------------------------------------

    @Test
    public void iteratorDate_monthSundayRangeMatchesJavadocExample() {
        // javadoc: Thursday July 4, 2002 + RANGE_MONTH_SUNDAY
        //          -> starts Sunday June 30, 2002, ends Saturday August 3, 2002
        Date focus = makeDate(2002, Calendar.JULY, 4, 12, 0, 0, 0);
        Iterator it = DateUtils.iterator(focus, DateUtils.RANGE_MONTH_SUNDAY);

        assertTrue(it.hasNext());
        Object first = it.next();
        assertTrue("iterator must yield Calendar instances", first instanceof Calendar);
        assertYMD("first day of range", first, 2002, Calendar.JUNE, 30);

        int count = 1;
        Object last = first;
        while (it.hasNext()) {
            last = it.next();
            count++;
        }
        assertYMD("last day of range", last, 2002, Calendar.AUGUST, 3);
        assertEquals("inclusive day count from Jun 30 to Aug 3", 35, count);
        assertFalse("iterator is exhausted", it.hasNext());
    }

    @Test
    public void iteratorDate_weekSundayRangeIsSevenDaysStartingSunday() {
        Date focus = makeDate(2002, Calendar.JULY, 4, 8, 30, 0, 0);
        Iterator it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);

        Object first = it.next();
        assertYMD("week start (Sunday)", first, 2002, Calendar.JUNE, 30);

        int count = 1;
        Object last = first;
        while (it.hasNext()) {
            last = it.next();
            count++;
        }
        assertYMD("week end (Saturday)", last, 2002, Calendar.JULY, 6);
        assertEquals(7, count);
    }

    @Test
    public void iteratorDate_removeIsUnsupported() {
        Date focus = makeDate(2002, Calendar.JULY, 4, 12, 0, 0, 0);
        Iterator it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        it.next();
        try {
            it.remove();
            fail("expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
        }
    }

    @Test
    public void iteratorDate_nullThrowsIllegalArgument() {
        try {
            DateUtils.iterator((Date) null, DateUtils.RANGE_WEEK_SUNDAY);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
        }
    }

    @Test
    public void iteratorDate_invalidRangeStyleThrowsIllegalArgument() {
        Date focus = makeDate(2002, Calendar.JULY, 4, 12, 0, 0, 0);
        try {
            DateUtils.iterator(focus, -1);
            fail("expected IllegalArgumentException for negative range style");
        } catch (IllegalArgumentException expected) {
        }
        try {
            DateUtils.iterator(focus, 999);
            fail("expected IllegalArgumentException for unknown range style");
        } catch (IllegalArgumentException expected) {
        }
    }

    @Test
    public void iteratorCalendar_weekMondayRangeIsSevenDaysStartingMonday() {
        Calendar focus = makeCal(2002, Calendar.JULY, 4, 12, 0, 0, 0);
        Iterator it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_MONDAY);

        Object first = it.next();
        assertYMD("week start (Monday)", first, 2002, Calendar.JULY, 1);

        int count = 1;
        Object last = first;
        while (it.hasNext()) {
            last = it.next();
            count++;
        }
        assertYMD("week end (Sunday)", last, 2002, Calendar.JULY, 7);
        assertEquals(7, count);
    }

    @Test
    public void iteratorCalendar_nullThrowsIllegalArgument() {
        try {
            DateUtils.iterator((Calendar) null, DateUtils.RANGE_WEEK_SUNDAY);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
        }
    }

    @Test
    public void iteratorObject_acceptsDateOrCalendar() {
        Object dateFocus = makeDate(2002, Calendar.JULY, 4, 12, 0, 0, 0);
        Iterator it1 = DateUtils.iterator(dateFocus, DateUtils.RANGE_WEEK_SUNDAY);
        assertYMD("Object=Date, first element", it1.next(), 2002, Calendar.JUNE, 30);

        Object calFocus = makeCal(2002, Calendar.JULY, 4, 12, 0, 0, 0);
        Iterator it2 = DateUtils.iterator(calFocus, DateUtils.RANGE_WEEK_SUNDAY);
        assertYMD("Object=Calendar, first element", it2.next(), 2002, Calendar.JUNE, 30);
    }

    @Test
    public void iteratorObject_unsupportedTypeThrowsClassCastException() {
        try {
            DateUtils.iterator("2002-07-04", DateUtils.RANGE_WEEK_SUNDAY);
            fail("expected ClassCastException");
        } catch (ClassCastException expected) {
        }
    }

    @Test
    public void iteratorObject_nullThrowsIllegalArgument() {
        try {
            DateUtils.iterator((Object) null, DateUtils.RANGE_WEEK_SUNDAY);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
        }
    }
}
