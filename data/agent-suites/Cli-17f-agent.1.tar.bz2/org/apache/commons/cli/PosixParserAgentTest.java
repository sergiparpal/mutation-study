/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.cli;

import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import junit.framework.TestCase;

/**
 * Tests for {@link PosixParser}, exercising the public {@link CommandLineParser}
 * API (the various <code>parse</code> overloads) and the POSIX flattening /
 * token bursting rules that this parser implements.
 */
public class PosixParserAgentTest extends TestCase
{
    /** short "a", long "enable-a", no argument */
    /** short "b", long "bfile", requires an argument */
    /** short "c", long "copt", no argument */
    private Options options;
    private Parser parser;

    public void setUp()
    {
        options = new Options()
            .addOption("a", "enable-a", false, "turn [a] on or off")
            .addOption("b", "bfile", true, "set the value of [b]")
            .addOption("c", "copt", false, "turn [c] on or off");

        parser = new PosixParser();
    }

    public void testSimpleShort() throws Exception
    {
        String[] args = new String[] { "-a", "-b", "toast", "foo", "bar" };

        CommandLine cl = parser.parse(options, args);

        assertTrue("-a should be set", cl.hasOption("a"));
        assertTrue("-b should be set", cl.hasOption("b"));
        assertEquals("value of -b", "toast", cl.getOptionValue("b"));
        assertEquals("number of leftover args", 2, cl.getArgList().size());
        assertTrue(cl.getArgList().contains("foo"));
        assertTrue(cl.getArgList().contains("bar"));
    }

    public void testSimpleLong() throws Exception
    {
        String[] args = new String[] { "--enable-a", "--bfile", "toast", "foo", "bar" };

        CommandLine cl = parser.parse(options, args);

        assertTrue("-a should be set", cl.hasOption("a"));
        assertTrue("-b should be set", cl.hasOption("b"));
        assertEquals("value of -b", "toast", cl.getOptionValue("b"));
        assertEquals("number of leftover args", 2, cl.getArgList().size());
    }

    public void testLongWithEqualSign() throws Exception
    {
        CommandLine cl = parser.parse(options, new String[] { "--bfile=toast" });

        assertTrue("-b should be set", cl.hasOption("b"));
        assertEquals("toast", cl.getOptionValue("b"));
        assertEquals(0, cl.getArgList().size());
    }

    public void testBurstingOfFlags() throws Exception
    {
        // -a and -c are both flags: "-ac" must burst into both
        CommandLine cl = parser.parse(options, new String[] { "-ac" });

        assertTrue("-a should be set", cl.hasOption("a"));
        assertTrue("-c should be set", cl.hasOption("c"));
        assertTrue("-b should not be set", !cl.hasOption("b"));
        assertEquals(0, cl.getArgList().size());
    }

    public void testBurstingWithAttachedValue() throws Exception
    {
        // "-b" takes an argument, so the tail of the burst is its value
        CommandLine cl = parser.parse(options, new String[] { "-btoast" });

        assertTrue("-b should be set", cl.hasOption("b"));
        assertEquals("toast", cl.getOptionValue("b"));
        assertEquals(0, cl.getArgList().size());
    }

    public void testBurstingFlagThenValuedOption() throws Exception
    {
        // "-a" flag then "-b" with the rest of the token as its value
        CommandLine cl = parser.parse(options, new String[] { "-abtoast" });

        assertTrue("-a should be set", cl.hasOption("a"));
        assertTrue("-b should be set", cl.hasOption("b"));
        assertEquals("toast", cl.getOptionValue("b"));
        assertEquals(0, cl.getArgList().size());
    }

    public void testStopAtNonOption() throws Exception
    {
        String[] args = new String[] { "-c", "foober", "-b", "toast" };

        CommandLine cl = parser.parse(options, args, true);

        assertTrue("-c should be set", cl.hasOption("c"));
        assertTrue("-b should not be set once flattening stopped", !cl.hasOption("b"));
        List argList = cl.getArgList();
        assertEquals("everything after the first non-option is a leftover arg", 3, argList.size());
        assertEquals("foober", argList.get(0));
        assertEquals("-b", argList.get(1));
        assertEquals("toast", argList.get(2));
    }

    public void testStopBursting() throws Exception
    {
        // -a is a valid flag, "z" is not an option: with stopAtNonOption the
        // remainder of the burst ("zc") becomes a single leftover argument
        CommandLine cl = parser.parse(options, new String[] { "-azc" }, true);

        assertTrue("-a should be set", cl.hasOption("a"));
        assertTrue("-c should not be set", !cl.hasOption("c"));
        List argList = cl.getArgList();
        assertEquals(1, argList.size());
        assertEquals("zc", argList.get(0));
    }

    public void testStopBursting2() throws Exception
    {
        String[] args = new String[] { "-c", "foobar", "-btoast" };

        CommandLine cl = parser.parse(options, args, true);
        assertTrue("-c should be set", cl.hasOption("c"));
        assertEquals("two leftover args", 2, cl.getArgList().size());
        assertEquals("foobar", cl.getArgList().get(0));
        assertEquals("-btoast", cl.getArgList().get(1));

        // feed the leftovers back through the parser
        cl = parser.parse(options, (String[]) cl.getArgList().toArray(new String[0]));

        assertTrue("-c should no longer be set", !cl.hasOption("c"));
        assertTrue("-b should be set on the second pass", cl.hasOption("b"));
        assertEquals("toast", cl.getOptionValue("b"));
        assertEquals(1, cl.getArgList().size());
        assertEquals("foobar", cl.getArgList().get(0));
    }

    public void testMissingArgument() throws Exception
    {
        try
        {
            parser.parse(options, new String[] { "-b" });
            fail("MissingArgumentException expected");
        }
        catch (MissingArgumentException e)
        {
            assertNotNull("exception should carry the offending option", e.getOption());
            assertEquals("b", e.getOption().getOpt());
        }
    }

    public void testMissingArgumentAfterBursting() throws Exception
    {
        // "-ab" bursts to flag -a and valued -b, but nothing follows to be -b's value
        try
        {
            parser.parse(options, new String[] { "-ab" });
            fail("MissingArgumentException expected");
        }
        catch (MissingArgumentException e)
        {
            assertEquals("b", e.getOption().getOpt());
        }
    }

    public void testUnrecognizedLongOption() throws Exception
    {
        try
        {
            parser.parse(options, new String[] { "--xfile" });
            fail("UnrecognizedOptionException expected");
        }
        catch (UnrecognizedOptionException e)
        {
            assertEquals("--xfile", e.getOption());
        }
    }

    public void testUnrecognizedBurstThrows() throws Exception
    {
        // none of x, y, z are options and stopAtNonOption is false: the whole
        // token is passed through and rejected as unrecognized
        try
        {
            parser.parse(options, new String[] { "-xyz" });
            fail("UnrecognizedOptionException expected");
        }
        catch (UnrecognizedOptionException e)
        {
            assertEquals("-xyz", e.getOption());
        }
    }

    public void testUnrecognizedShortOptionIsIgnored() throws Exception
    {
        // a two-character unknown option is silently dropped by PosixParser
        // when stopAtNonOption is false
        CommandLine cl = parser.parse(options, new String[] { "-a", "-x" });

        assertTrue("-a should be set", cl.hasOption("a"));
        assertTrue("unknown -x should not be set", !cl.hasOption("x"));
        assertEquals("unknown short option is not a leftover arg", 0, cl.getArgList().size());
    }

    public void testDoubleDashTerminatesOptions() throws Exception
    {
        String[] args = new String[] { "-a", "--", "-b", "toast" };

        CommandLine cl = parser.parse(options, args);

        assertTrue("-a should be set", cl.hasOption("a"));
        assertTrue("-b after -- should not be set", !cl.hasOption("b"));
        List argList = cl.getArgList();
        assertEquals(2, argList.size());
        assertEquals("-b", argList.get(0));
        assertEquals("toast", argList.get(1));
    }

    public void testSingleDashIsTreatedAsArgument() throws Exception
    {
        String[] args = new String[] { "-a", "-", "foo" };

        CommandLine cl = parser.parse(options, args);

        assertTrue("-a should be set", cl.hasOption("a"));
        List argList = cl.getArgList();
        assertEquals(2, argList.size());
        assertEquals("-", argList.get(0));
        assertEquals("foo", argList.get(1));
    }

    public void testNullArguments() throws Exception
    {
        CommandLine cl = parser.parse(options, null);

        assertNotNull("parse(options, null) must not return null", cl);
        assertTrue("no options set", !cl.hasOption("a"));
        assertEquals(0, cl.getArgList().size());
        assertEquals(0, cl.getOptions().length);
    }

    public void testEmptyArguments() throws Exception
    {
        CommandLine cl = parser.parse(options, new String[0]);

        assertNotNull(cl);
        assertEquals(0, cl.getArgList().size());
        assertEquals(0, cl.getOptions().length);
    }

    public void testStopAtLeadingNonOption() throws Exception
    {
        // the first token is not an option: with stopAtNonOption everything,
        // including the option-looking "-a", is collected as leftover arguments
        String[] args = new String[] { "file1", "-a", "file2" };

        CommandLine cl = parser.parse(options, args, true);

        assertTrue("-a is never interpreted", !cl.hasOption("a"));
        List argList = cl.getArgList();
        assertEquals(3, argList.size());
        assertEquals("file1", argList.get(0));
        assertEquals("-a", argList.get(1));
        assertEquals("file2", argList.get(2));
    }

    public void testOptionalArgumentPresentAndAbsent() throws Exception
    {
        Options opts = new Options();
        opts.addOption(OptionBuilder.hasOptionalArg().create('x'));

        CommandLine withValue = new PosixParser().parse(opts, new String[] { "-x", "value" });
        assertTrue(withValue.hasOption("x"));
        assertEquals("value", withValue.getOptionValue("x"));

        CommandLine withoutValue = new PosixParser().parse(opts, new String[] { "-x" });
        assertTrue("-x is set even without a value", withoutValue.hasOption("x"));
        assertNull("no value supplied", withoutValue.getOptionValue("x"));
    }

    public void testValueSeparatorDuringBursting() throws Exception
    {
        Options opts = new Options();
        opts.addOption(OptionBuilder.withValueSeparator().hasArgs(2).create('D'));

        CommandLine cl = new PosixParser().parse(opts, new String[] { "-Dproperty=value" });

        assertTrue(cl.hasOption("D"));
        String[] values = cl.getOptionValues("D");
        assertNotNull(values);
        assertEquals(2, values.length);
        assertEquals("property", values[0]);
        assertEquals("value", values[1]);
    }

    public void testRequiredOptionMissing() throws Exception
    {
        Options opts = new Options();
        opts.addOption(OptionBuilder.isRequired().withLongOpt("mandatory").create('r'));

        try
        {
            new PosixParser().parse(opts, new String[0]);
            fail("MissingOptionException expected");
        }
        catch (MissingOptionException e)
        {
            assertTrue("missing options should report 'r'",
                       e.getMissingOptions().contains("r"));
        }
    }

    public void testRequiredOptionProvided() throws Exception
    {
        Options opts = new Options();
        opts.addOption(OptionBuilder.isRequired().create('r'));

        CommandLine cl = new PosixParser().parse(opts, new String[] { "-r" });

        assertTrue("-r should be set", cl.hasOption("r"));
    }

    public void testParseWithProperties() throws Exception
    {
        Properties props = new Properties();
        props.setProperty("b", "propvalue");

        CommandLine cl = parser.parse(options, new String[0], props);

        assertTrue("-b supplied via properties", cl.hasOption("b"));
        assertEquals("propvalue", cl.getOptionValue("b"));
    }

    public void testCommandLineArgumentBeatsProperty() throws Exception
    {
        Properties props = new Properties();
        props.setProperty("b", "fromProps");

        CommandLine cl = parser.parse(options, new String[] { "-b", "fromArgs" }, props);

        assertEquals("command line wins over properties", "fromArgs", cl.getOptionValue("b"));
    }

    public void testFlagPropertyEnablesOption() throws Exception
    {
        Options opts = new Options();
        opts.addOption("v", false, "verbose flag");

        Properties props = new Properties();
        props.setProperty("v", "true");

        CommandLine cl = new PosixParser().parse(opts, new String[0], props);

        assertTrue("flag turned on by property value 'true'", cl.hasOption("v"));
    }

    public void testFlagPropertyWithNonTrueValueIsIgnored() throws Exception
    {
        Options opts = new Options();
        opts.addOption("v", false, "verbose flag");

        Properties props = new Properties();
        props.setProperty("v", "false");

        CommandLine cl = new PosixParser().parse(opts, new String[0], props);

        assertTrue("flag stays off for property value 'false'", !cl.hasOption("v"));
    }

    public void testParserInstanceIsReusable() throws Exception
    {
        CommandLine first = parser.parse(options, new String[] { "-a", "-b", "one" });
        assertTrue(first.hasOption("a"));
        assertEquals("one", first.getOptionValue("b"));

        // reuse the same parser and Options: previous state must not leak
        CommandLine second = parser.parse(options, new String[] { "-c" });
        assertTrue("-c set on second run", second.hasOption("c"));
        assertTrue("-a must not leak from the first run", !second.hasOption("a"));
        assertTrue("-b must not leak from the first run", !second.hasOption("b"));
        assertNull(second.getOptionValue("b"));
        assertEquals(0, second.getArgList().size());
    }

    public void testGetOptionsReflectsParsedOptions() throws Exception
    {
        CommandLine cl = parser.parse(options, new String[] { "-a", "-b", "toast", "extra" });

        Option[] parsed = cl.getOptions();
        assertEquals("two options were parsed", 2, parsed.length);

        List keys = Arrays.asList(new String[] { parsed[0].getOpt(), parsed[1].getOpt() });
        assertTrue(keys.contains("a"));
        assertTrue(keys.contains("b"));
    }
}
