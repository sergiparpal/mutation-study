/*
 * Copyright (C) 2011 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.gson.internal;

import junit.framework.TestCase;

public class UnsafeAllocatorAgentTest extends TestCase {

  /** A concrete class with a constructor that throws, so we know instances only come from the allocator. */
  public static class ConcreteWithThrowingConstructor {
    public int value = 42;

    public ConcreteWithThrowingConstructor() {
      throw new AssertionError("Constructor should not be invoked by UnsafeAllocator");
    }
  }

  /** A concrete class with a private no-args constructor. */
  private static class ConcretePrivateConstructor {
    public String marker = "unset";
  }

  public abstract static class AbstractClass {
  }

  public interface SomeInterface {
  }

  public void testCreateReturnsNonNullInstance() {
    UnsafeAllocator allocator = UnsafeAllocator.create();
    assertNotNull(allocator);
  }

  public void testNewInstanceBypassesConstructor() throws Exception {
    UnsafeAllocator allocator = UnsafeAllocator.create();
    ConcreteWithThrowingConstructor instance = allocator.newInstance(ConcreteWithThrowingConstructor.class);
    assertNotNull(instance);
    // Field should have Java's default value (0), not the value set by the constructor,
    // proving the constructor was never run.
    assertEquals(0, instance.value);
  }

  public void testNewInstanceReturnsCorrectType() throws Exception {
    UnsafeAllocator allocator = UnsafeAllocator.create();
    Object instance = allocator.newInstance(String.class);
    assertNotNull(instance);
    assertEquals(String.class, instance.getClass());
  }

  public void testNewInstanceWithPrivateConstructor() throws Exception {
    UnsafeAllocator allocator = UnsafeAllocator.create();
    ConcretePrivateConstructor instance = allocator.newInstance(ConcretePrivateConstructor.class);
    assertNotNull(instance);
    assertEquals(ConcretePrivateConstructor.class, instance.getClass());
    // Field initializers are compiled into the constructor, which UnsafeAllocator bypasses,
    // so the field keeps Java's default value (null) rather than the initializer's value.
    assertNull(instance.marker);
  }

  public void testNewInstanceProducesDistinctInstances() throws Exception {
    UnsafeAllocator allocator = UnsafeAllocator.create();
    Object first = allocator.newInstance(ConcretePrivateConstructor.class);
    Object second = allocator.newInstance(ConcretePrivateConstructor.class);
    assertNotNull(first);
    assertNotNull(second);
    assertNotSame(first, second);
  }

  public void testNewInstanceWithAbstractClassThrows() throws Exception {
    UnsafeAllocator allocator = UnsafeAllocator.create();
    try {
      allocator.newInstance(AbstractClass.class);
      fail("Expected UnsupportedOperationException for abstract class");
    } catch (UnsupportedOperationException expected) {
      assertTrue(expected.getMessage().contains(AbstractClass.class.getName()));
    }
  }

  public void testNewInstanceWithInterfaceThrows() throws Exception {
    UnsafeAllocator allocator = UnsafeAllocator.create();
    try {
      allocator.newInstance(SomeInterface.class);
      fail("Expected UnsupportedOperationException for interface");
    } catch (UnsupportedOperationException expected) {
      assertTrue(expected.getMessage().contains(SomeInterface.class.getName()));
    }
  }

  public void testNewInstanceWithArrayClassThrows() throws Exception {
    UnsafeAllocator allocator = UnsafeAllocator.create();
    // Per the JVM spec, array classes report Modifier.isAbstract(...) == true even though
    // arrays are instantiable via `new`, so UnsafeAllocator's assertInstantiable guard
    // rejects them just like it rejects genuinely abstract classes.
    try {
      allocator.newInstance(int[].class);
      fail("Expected UnsupportedOperationException for array class");
    } catch (UnsupportedOperationException expected) {
      assertTrue(expected.getMessage().contains(int[].class.getName()));
    }
  }
}
