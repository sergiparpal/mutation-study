package com.google.gson.stream;

import java.io.IOException;
import java.io.StringReader;

import org.junit.Test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

/**
 * Tests for {@link JsonReader}, based solely on the documented contract in
 * the generated javadoc (api/com/google/gson/stream/JsonReader.html).
 */
public class JsonReaderAgentTest {

    /** Reader fixture that records whether close() was invoked. */
    private static class FlagCloseReader extends StringReader {
        boolean closed = false;

        FlagCloseReader(String s) {
            super(s);
        }

        public void close() {
            closed = true;
            super.close();
        }
    }

    // ---- isLenient() / setLenient(boolean) ----

    @Test
    public void testDefaultIsLenientFalse() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[]"));
        assertFalse(reader.isLenient());
    }

    @Test
    public void testSetLenientTrueMakesIsLenientTrue() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[]"));
        reader.setLenient(true);
        assertTrue(reader.isLenient());
    }

    // ---- beginArray() / endArray() / beginObject() / endObject() ----

    @Test
    public void testBeginArrayEndArrayEmptyArray() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[]"));
        reader.beginArray();
        assertFalse(reader.hasNext());
        reader.endArray();
    }

    @Test
    public void testBeginObjectEndObjectEmptyObject() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("{}"));
        reader.beginObject();
        assertFalse(reader.hasNext());
        reader.endObject();
    }

    // @Test  // pruned: failed on the fixed version
    public void testBeginArrayThrowsWhenNextTokenIsObject() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("{}"));
        try {
            reader.beginArray();
            fail("Expected IOException when asserting BEGIN_ARRAY on an object token");
        } catch (IOException expected) {
        }
    }

    // @Test  // pruned: failed on the fixed version
    public void testBeginObjectThrowsWhenNextTokenIsArray() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[]"));
        try {
            reader.beginObject();
            fail("Expected IOException when asserting BEGIN_OBJECT on an array token");
        } catch (IOException expected) {
        }
    }

    // @Test  // pruned: failed on the fixed version
    public void testEndObjectThrowsWhenMembersRemain() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("{\"a\":1}"));
        reader.beginObject();
        try {
            reader.endObject();
            fail("Expected IOException when asserting END_OBJECT with an unread member pending");
        } catch (IOException expected) {
        }
    }

    // ---- hasNext() ----

    @Test
    public void testHasNextTrueThenFalseInArray() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[1,2]"));
        reader.beginArray();
        assertTrue(reader.hasNext());
        reader.nextInt();
        assertTrue(reader.hasNext());
        reader.nextInt();
        assertFalse(reader.hasNext());
        reader.endArray();
    }

    @Test
    public void testHasNextTrueThenFalseInObject() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("{\"a\":1}"));
        reader.beginObject();
        assertTrue(reader.hasNext());
        reader.nextName();
        reader.nextInt();
        assertFalse(reader.hasNext());
        reader.endObject();
    }

    // ---- peek() ----

    @Test
    public void testPeekDoesNotConsumeToken() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("true"));
        assertEquals(JsonToken.BOOLEAN, reader.peek());
        assertEquals(JsonToken.BOOLEAN, reader.peek());
        assertTrue(reader.nextBoolean());
    }

    @Test
    public void testPeekReturnsBeginObjectAndName() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("{\"a\":1}"));
        assertEquals(JsonToken.BEGIN_OBJECT, reader.peek());
        reader.beginObject();
        assertEquals(JsonToken.NAME, reader.peek());
        assertEquals("a", reader.nextName());
        assertEquals(JsonToken.NUMBER, reader.peek());
        reader.nextInt();
        assertEquals(JsonToken.END_OBJECT, reader.peek());
        reader.endObject();
    }

    // ---- nextName() ----

    @Test
    public void testNextNameReturnsPropertyName() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("{\"key\":1}"));
        reader.beginObject();
        assertEquals("key", reader.nextName());
        reader.nextInt();
        reader.endObject();
    }

    // @Test  // pruned: failed on the fixed version
    public void testNextNameThrowsWhenNextTokenIsNotAName() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[1]"));
        reader.beginArray();
        try {
            reader.nextName();
            fail("Expected IOException when the next token is not a property name");
        } catch (IOException expected) {
        }
    }

    // ---- nextString() ----

    @Test
    public void testNextStringOnStringToken() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[\"hello\"]"));
        reader.beginArray();
        assertEquals("hello", reader.nextString());
        reader.endArray();
    }

    @Test
    public void testNextStringOnNumberTokenReturnsStringForm() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[1,\"1\"]"));
        reader.beginArray();
        assertEquals("1", reader.nextString());
        assertEquals("1", reader.nextString());
        reader.endArray();
    }

    @Test
    public void testNextStringThrowsIllegalStateOnBoolean() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[true]"));
        reader.beginArray();
        try {
            reader.nextString();
            fail("Expected IllegalStateException when the next token is not a string or number");
        } catch (IllegalStateException expected) {
        }
    }

    @Test
    public void testNextStringThrowsIllegalStateAfterClose() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("\"hello\""));
        reader.close();
        try {
            reader.nextString();
            fail("Expected IllegalStateException after the reader is closed");
        } catch (IllegalStateException expected) {
        }
    }

    // ---- nextBoolean() ----

    @Test
    public void testNextBooleanTrueAndFalse() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[true,false]"));
        reader.beginArray();
        assertTrue(reader.nextBoolean());
        assertFalse(reader.nextBoolean());
        reader.endArray();
    }

    @Test
    public void testNextBooleanThrowsIllegalStateOnNonBoolean() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[1]"));
        reader.beginArray();
        try {
            reader.nextBoolean();
            fail("Expected IllegalStateException when the next token is not a boolean");
        } catch (IllegalStateException expected) {
        }
    }

    // ---- nextNull() ----

    @Test
    public void testNextNullConsumesNullLiteral() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[null]"));
        reader.beginArray();
        reader.nextNull();
        assertFalse(reader.hasNext());
        reader.endArray();
    }

    @Test
    public void testNextNullThrowsIllegalStateOnNonNull() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[1]"));
        reader.beginArray();
        try {
            reader.nextNull();
            fail("Expected IllegalStateException when the next token is not null");
        } catch (IllegalStateException expected) {
        }
    }

    // ---- nextDouble() ----

    @Test
    public void testNextDoubleOnNumberToken() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[1.5]"));
        reader.beginArray();
        assertEquals(1.5, reader.nextDouble(), 0.0);
        reader.endArray();
    }

    @Test
    public void testNextDoubleParsesStringAsDouble() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[\"2.5\"]"));
        reader.beginArray();
        assertEquals(2.5, reader.nextDouble(), 0.0);
        reader.endArray();
    }

    // @Test  // pruned: failed on the fixed version
    public void testNextDoubleThrowsOnNonFiniteLiteral() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[NaN]"));
        reader.setLenient(true);
        reader.beginArray();
        try {
            reader.nextDouble();
            fail("Expected NumberFormatException for a non-finite literal");
        } catch (NumberFormatException expected) {
        }
    }

    @Test
    public void testNextDoubleThrowsIllegalStateOnStructuralToken() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[[]]"));
        reader.beginArray();
        try {
            reader.nextDouble();
            fail("Expected IllegalStateException when the next token is not a literal value");
        } catch (IllegalStateException expected) {
        }
    }

    // ---- nextLong() ----

    @Test
    public void testNextLongExactValue() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[9223372036854775807]"));
        reader.beginArray();
        assertEquals(Long.MAX_VALUE, reader.nextLong());
        reader.endArray();
    }

    @Test
    public void testNextLongParsesStringAsLong() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[\"123\"]"));
        reader.beginArray();
        assertEquals(123L, reader.nextLong());
        reader.endArray();
    }

    // @Test  // pruned: failed on the fixed version
    public void testNextLongThrowsNumberFormatWhenNotExactlyRepresentable() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[9223372036854775808]"));
        reader.beginArray();
        try {
            reader.nextLong();
            fail("Expected NumberFormatException for a value outside the long range");
        } catch (NumberFormatException expected) {
        }
    }

    // ---- nextInt() ----

    @Test
    public void testNextIntExactValue() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[2147483647]"));
        reader.beginArray();
        assertEquals(Integer.MAX_VALUE, reader.nextInt());
        reader.endArray();
    }

    @Test
    public void testNextIntParsesStringAsInt() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[\"456\"]"));
        reader.beginArray();
        assertEquals(456, reader.nextInt());
        reader.endArray();
    }

    @Test
    public void testNextIntThrowsNumberFormatWhenOutOfRange() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[2147483648]"));
        reader.beginArray();
        try {
            reader.nextInt();
            fail("Expected NumberFormatException for a value outside the int range");
        } catch (NumberFormatException expected) {
        }
    }

    @Test
    public void testNextIntThrowsIllegalStateOnStructuralToken() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[{}]"));
        reader.beginArray();
        try {
            reader.nextInt();
            fail("Expected IllegalStateException when the next token is not a literal value");
        } catch (IllegalStateException expected) {
        }
    }

    // ---- close() ----

    @Test
    public void testCloseClosesUnderlyingReader() throws IOException {
        FlagCloseReader underlying = new FlagCloseReader("[]");
        JsonReader reader = new JsonReader(underlying);
        reader.close();
        assertTrue(underlying.closed);
    }

    // ---- skipValue() ----

    @Test
    public void testSkipValueSkipsPrimitiveInArray() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[1,2]"));
        reader.beginArray();
        reader.skipValue();
        assertEquals(2, reader.nextInt());
        reader.endArray();
    }

    @Test
    public void testSkipValueSkipsNestedStructureRecursively() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("{\"a\":{\"nested\":[1,2,3]},\"b\":9}"));
        reader.beginObject();
        assertEquals("a", reader.nextName());
        reader.skipValue();
        assertEquals("b", reader.nextName());
        assertEquals(9, reader.nextInt());
        reader.endObject();
    }

    // ---- getPath() ----

    @Test
    public void testGetPathOfFreshReaderIsRoot() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[1,2]"));
        assertNotNull(reader.getPath());
        assertTrue(reader.getPath().startsWith("$"));
    }

    @Test
    public void testGetPathChangesAsLocationChanges() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[1,2]"));
        String rootPath = reader.getPath();
        reader.beginArray();
        reader.nextInt();
        String afterFirstElement = reader.getPath();
        assertFalse(rootPath.equals(afterFirstElement));
    }

    // ---- toString() ----

    @Test
    public void testToStringIsNotNull() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[]"));
        assertNotNull(reader.toString());
    }

    // ---- lenient mode: non-execute prefix ----

    @Test
    public void testLenientAllowsNonExecutePrefix() throws IOException {
        JsonReader reader = new JsonReader(new StringReader(")]}'\n[1]"));
        reader.setLenient(true);
        reader.beginArray();
        assertEquals(1, reader.nextInt());
        reader.endArray();
    }

    @Test
    public void testStrictRejectsNonExecutePrefix() throws IOException {
        JsonReader reader = new JsonReader(new StringReader(")]}'\n[1]"));
        try {
            reader.beginArray();
            fail("Expected IOException for the non-execute prefix under strict parsing");
        } catch (IOException expected) {
        }
    }

    // ---- lenient mode: multiple top-level values ----

    @Test
    public void testStrictRejectsMultipleTopLevelValues() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[1][2]"));
        reader.beginArray();
        assertEquals(1, reader.nextInt());
        reader.endArray();
        try {
            reader.peek();
            fail("Expected IOException for a second top-level value under strict parsing");
        } catch (IOException expected) {
        }
    }

    @Test
    public void testLenientAllowsMultipleTopLevelValues() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[1][2]"));
        reader.setLenient(true);
        reader.beginArray();
        assertEquals(1, reader.nextInt());
        reader.endArray();
        reader.beginArray();
        assertEquals(2, reader.nextInt());
        reader.endArray();
    }

    // ---- lenient mode: scalar top-level value ----

    // @Test  // pruned: failed on the fixed version
    public void testStrictRejectsScalarTopLevelValue() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("1"));
        try {
            reader.nextInt();
            fail("Expected IOException for a scalar top-level value under strict parsing");
        } catch (IOException expected) {
        }
    }

    @Test
    public void testLenientAllowsScalarTopLevelValue() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("1"));
        reader.setLenient(true);
        assertEquals(1, reader.nextInt());
    }

    // ---- lenient mode: unquoted names, alternate separators ----

    @Test
    public void testLenientAllowsUnquotedNamesAndAlternateSeparators() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("{a=1;b=2}"));
        reader.setLenient(true);
        reader.beginObject();
        assertEquals("a", reader.nextName());
        assertEquals(1, reader.nextInt());
        assertEquals("b", reader.nextName());
        assertEquals(2, reader.nextInt());
        reader.endObject();
    }

    @Test
    public void testLenientAllowsSingleQuotedStrings() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("['abc']"));
        reader.setLenient(true);
        reader.beginArray();
        assertEquals("abc", reader.nextString());
        reader.endArray();
    }

    @Test
    public void testLenientAllowsSemicolonArraySeparator() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[1;2]"));
        reader.setLenient(true);
        reader.beginArray();
        assertEquals(1, reader.nextInt());
        assertEquals(2, reader.nextInt());
        reader.endArray();
    }

    @Test
    public void testLenientTreatsOmittedArrayElementsAsNull() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[1,,3]"));
        reader.setLenient(true);
        reader.beginArray();
        assertEquals(1, reader.nextInt());
        assertEquals(JsonToken.NULL, reader.peek());
        reader.nextNull();
        assertEquals(3, reader.nextInt());
        reader.endArray();
    }

    // ---- malformed / truncated input ----

    @Test
    public void testEmptyStreamThrowsIOException() throws IOException {
        JsonReader reader = new JsonReader(new StringReader(""));
        try {
            reader.peek();
            fail("Expected IOException for a stream with no top-level value");
        } catch (IOException expected) {
        }
    }

    @Test
    public void testTruncatedObjectThrowsIOException() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("{"));
        reader.beginObject();
        try {
            reader.nextName();
            fail("Expected IOException for a truncated stream");
        } catch (IOException expected) {
        }
    }
}
