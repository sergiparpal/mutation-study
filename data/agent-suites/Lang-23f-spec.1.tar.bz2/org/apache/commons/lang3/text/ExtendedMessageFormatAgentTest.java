package org.apache.commons.lang3.text;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.text.FieldPosition;
import java.text.Format;
import java.text.MessageFormat;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.junit.Test;

/**
 * Self-contained JUnit 4 tests for {@link ExtendedMessageFormat}.
 *
 * <p>Every expectation below is taken from the published Javadoc contract of
 * {@code ExtendedMessageFormat} (which {@code extends java.text.MessageFormat}):</p>
 * <ul>
 *   <li>A "format element" is {@code {argument-number(,format-name(,format-style)?)?}}.</li>
 *   <li>{@code format-name} / {@code format-style} are trimmed of surrounding whitespace
 *       "in the manner of java.text.MessageFormat".</li>
 *   <li>If {@code format-name} is a key in the supplied registry, the matching
 *       {@link FormatFactory} is asked for a {@link Format}; on success that
 *       {@code Format} is used for the element. Otherwise the base
 *       {@code MessageFormat} handling applies (so built-ins can be overridden).</li>
 *   <li>The {@code setFormat*} mutators are disabled and throw
 *       {@link UnsupportedOperationException}.</li>
 *   <li>The constructors throw {@link IllegalArgumentException} for a bad pattern;
 *       the registry argument may be {@code null}.</li>
 * </ul>
 */
public class ExtendedMessageFormatAgentTest {

    // ------------------------------------------------------------------
    // Local fixtures - no external test helper is referenced.
    // ------------------------------------------------------------------

    /** A {@link Format} that upper-cases the string form of its argument. */
    private static final class UpperCaseFormat extends Format {
        private static final long serialVersionUID = 1L;

        @Override
        public StringBuffer format(final Object obj, final StringBuffer toAppendTo, final FieldPosition pos) {
            return toAppendTo.append(String.valueOf(obj).toUpperCase(Locale.ROOT));
        }

        @Override
        public Object parseObject(final String source, final ParsePosition pos) {
            final int start = pos.getIndex();
            pos.setIndex(source.length());
            return source.substring(start);
        }
    }

    /** A {@link Format} that always emits a fixed string, ignoring its argument. */
    private static final class ConstantFormat extends Format {
        private static final long serialVersionUID = 1L;
        private final String value;

        ConstantFormat(final String value) {
            this.value = value;
        }

        @Override
        public StringBuffer format(final Object obj, final StringBuffer toAppendTo, final FieldPosition pos) {
            return toAppendTo.append(value);
        }

        @Override
        public Object parseObject(final String source, final ParsePosition pos) {
            pos.setIndex(source.length());
            return value;
        }
    }

    /** A {@link Format} that wraps its argument in {@code <tag>...</tag>}. */
    private static final class TagFormat extends Format {
        private static final long serialVersionUID = 1L;
        private final String tag;

        TagFormat(final String tag) {
            this.tag = tag;
        }

        @Override
        public StringBuffer format(final Object obj, final StringBuffer toAppendTo, final FieldPosition pos) {
            return toAppendTo.append('<').append(tag).append('>')
                    .append(String.valueOf(obj))
                    .append('<').append('/').append(tag).append('>');
        }

        @Override
        public Object parseObject(final String source, final ParsePosition pos) {
            pos.setIndex(source.length());
            return source;
        }
    }

    /**
     * A {@link FormatFactory} that records the arguments it was handed and
     * returns a pre-built {@link Format}.
     */
    private static final class RecordingFormatFactory implements FormatFactory {
        private final Format format;
        String lastName;
        String lastArguments;
        Locale lastLocale;
        int calls;

        RecordingFormatFactory(final Format format) {
            this.format = format;
        }

        public Format getFormat(final String name, final String arguments, final Locale locale) {
            this.lastName = name;
            this.lastArguments = arguments;
            this.lastLocale = locale;
            this.calls++;
            return format;
        }
    }

    /** A {@link FormatFactory} that builds a {@link TagFormat} from the format style. */
    private static final class TagFormatFactory implements FormatFactory {
        public Format getFormat(final String name, final String arguments, final Locale locale) {
            return new TagFormat(arguments == null ? "" : arguments);
        }
    }

    private static Map<String, FormatFactory> registryWith(final String name, final FormatFactory factory) {
        final Map<String, FormatFactory> map = new HashMap<String, FormatFactory>();
        map.put(name, factory);
        return map;
    }

    // ------------------------------------------------------------------
    // Plain (non-custom) patterns must behave exactly like MessageFormat.
    // ------------------------------------------------------------------

    @Test
    public void plainPatternFormatsLikeMessageFormat() {
        final String pattern = "Hello {0}, welcome to {1}!";
        final Object[] arguments = { "Alice", "Wonderland" };

        final ExtendedMessageFormat emf = new ExtendedMessageFormat(pattern);

        assertEquals("Hello Alice, welcome to Wonderland!", emf.format(arguments));
        assertEquals(new MessageFormat(pattern).format(arguments), emf.format(arguments));
    }

    @Test
    public void extraArgumentsAreIgnored() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertEquals("first", emf.format(new Object[] { "first", "second", "third" }));
    }

    @Test
    public void toPatternRoundTripsSimplePatterns() {
        assertEquals("{0}", new ExtendedMessageFormat("{0}").toPattern());
        assertEquals("no elements here", new ExtendedMessageFormat("no elements here").toPattern());
    }

    @Test
    public void toPatternMatchesMessageFormatForPlainPattern() {
        final String pattern = "File {0} saved at {1} ({2} bytes)";
        final Object[] arguments = { "a.txt", "noon", Integer.valueOf(12) };

        final ExtendedMessageFormat emf = new ExtendedMessageFormat(pattern);

        assertEquals(new MessageFormat(pattern).toPattern(), emf.toPattern());
        assertEquals(new MessageFormat(pattern).format(arguments), emf.format(arguments));
    }

    @Test
    public void patternWithoutElementsIsVerbatim() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("just plain text");
        assertEquals("just plain text", emf.format(new Object[0]));
        assertEquals("just plain text", emf.toPattern());
    }

    @Test
    public void quotedBracesAreLiterals() {
        // '{' and '}' quoted -> literal braces; the trailing {0} is a real element.
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("'{'0'}' = {0}");
        assertEquals("{0} = five", emf.format(new Object[] { "five" }));
    }

    @Test
    public void inheritedParseWorksForPlainPattern() throws ParseException {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello {0}!");
        final Object[] parsed = emf.parse("Hello World!");
        assertNotNull(parsed);
        assertEquals(1, parsed.length);
        assertEquals("World", parsed[0]);
    }

    // ------------------------------------------------------------------
    // Custom formats supplied through the registry.
    // ------------------------------------------------------------------

    @Test
    public void customFormatFromRegistryIsApplied() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat(
                "Hello {0,upper}!",
                registryWith("upper", new RecordingFormatFactory(new UpperCaseFormat())));

        assertEquals("Hello WORLD!", emf.format(new Object[] { "world" }));
    }

    @Test
    public void mixedCustomAndPlainElements() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat(
                "{0} / {1,upper} / {0}",
                registryWith("upper", new RecordingFormatFactory(new UpperCaseFormat())));

        assertEquals("a / B / a", emf.format(new Object[] { "a", "b" }));
    }

    @Test
    public void toPatternPreservesCustomFormatName() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat(
                "Hello {0,upper}!",
                registryWith("upper", new RecordingFormatFactory(new UpperCaseFormat())));

        // The whole point of overriding toPattern(): the custom format name survives.
        assertEquals("Hello {0,upper}!", emf.toPattern());
    }

    @Test
    public void registryFactoryReceivesTrimmedNameStyleAndLocale() {
        final RecordingFormatFactory factory = new RecordingFormatFactory(new UpperCaseFormat());

        final ExtendedMessageFormat emf = new ExtendedMessageFormat(
                "x={0, dyn , some style }", Locale.GERMANY, registryWith("dyn", factory));

        assertTrue("factory must be consulted while parsing the pattern", factory.calls >= 1);
        assertEquals("dyn", factory.lastName);
        assertEquals("some style", factory.lastArguments);
        assertEquals(Locale.GERMANY, factory.lastLocale);
        // and the Format it returned is actually used
        assertEquals("x=V", emf.format(new Object[] { "v" }));
    }

    @Test
    public void factoryStyleArgumentControlsProducedFormat() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat(
                "{0,wrap,b}", registryWith("wrap", new TagFormatFactory()));

        assertEquals("<b>hi</b>", emf.format(new Object[] { "hi" }));
    }

    @Test
    public void registryOverridesBuiltInFormat() {
        // "number" is a MessageFormat built-in; the registry entry must win.
        final ExtendedMessageFormat emf = new ExtendedMessageFormat(
                "n={0,number}",
                registryWith("number", new RecordingFormatFactory(new ConstantFormat("NUM"))));

        assertEquals("n=NUM", emf.format(new Object[] { Integer.valueOf(7) }));
    }

    @Test
    public void builtInFormatUsedWhenNameNotInRegistry() {
        // Registry has "upper" only -> "number" falls through to MessageFormat.
        final ExtendedMessageFormat emf = new ExtendedMessageFormat(
                "n={0,number,integer}", Locale.US,
                registryWith("upper", new RecordingFormatFactory(new UpperCaseFormat())));

        assertEquals("n=42", emf.format(new Object[] { Integer.valueOf(42) }));
    }

    @Test
    public void nullRegistryBehavesLikePlainMessageFormat() {
        final ExtendedMessageFormat emf =
                new ExtendedMessageFormat("v={0}", (Map<String, FormatFactory>) null);

        assertEquals("v=hi", emf.format(new Object[] { "hi" }));
        assertEquals("v={0}", emf.toPattern());
    }

    @Test
    public void nullRegistryWithLocaleBehavesLikePlainMessageFormat() {
        final ExtendedMessageFormat emf =
                new ExtendedMessageFormat("v={0}", Locale.US, (Map<String, FormatFactory>) null);

        assertEquals("v=hi", emf.format(new Object[] { "hi" }));
        assertEquals(Locale.US, emf.getLocale());
    }

    // ------------------------------------------------------------------
    // applyPattern
    // ------------------------------------------------------------------

    @Test
    public void applyPatternReplacesPattern() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("old {0}");

        emf.applyPattern("fresh = {0}");

        assertEquals(new MessageFormat("fresh = {0}").toPattern(), emf.toPattern());
        assertEquals("fresh = X", emf.format(new Object[] { "X" }));
    }

    @Test
    public void applyPatternCanIntroduceCustomFormat() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat(
                "{0}", registryWith("upper", new RecordingFormatFactory(new UpperCaseFormat())));

        emf.applyPattern("{0,upper}");

        assertEquals("ABC", emf.format(new Object[] { "abc" }));
        assertEquals("{0,upper}", emf.toPattern());
    }

    // ------------------------------------------------------------------
    // Disabled mutators - must all throw UnsupportedOperationException.
    // ------------------------------------------------------------------

    @Test
    public void setFormatThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        try {
            emf.setFormat(0, new ConstantFormat("x"));
            fail("setFormat should throw UnsupportedOperationException");
        } catch (final UnsupportedOperationException expected) {
            // documented behaviour
        }
    }

    @Test
    public void setFormatByArgumentIndexThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        try {
            emf.setFormatByArgumentIndex(0, new ConstantFormat("x"));
            fail("setFormatByArgumentIndex should throw UnsupportedOperationException");
        } catch (final UnsupportedOperationException expected) {
            // documented behaviour
        }
    }

    @Test
    public void setFormatsThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        try {
            emf.setFormats(new Format[] { new ConstantFormat("x") });
            fail("setFormats should throw UnsupportedOperationException");
        } catch (final UnsupportedOperationException expected) {
            // documented behaviour
        }
    }

    @Test
    public void setFormatsByArgumentIndexThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        try {
            emf.setFormatsByArgumentIndex(new Format[] { new ConstantFormat("x") });
            fail("setFormatsByArgumentIndex should throw UnsupportedOperationException");
        } catch (final UnsupportedOperationException expected) {
            // documented behaviour
        }
    }

    // ------------------------------------------------------------------
    // Bad patterns -> IllegalArgumentException (every constructor).
    // ------------------------------------------------------------------

    @Test
    public void unmatchedBraceThrowsForPatternConstructor() {
        try {
            new ExtendedMessageFormat("Hello {0");
            fail("expected IllegalArgumentException for an unterminated format element");
        } catch (final IllegalArgumentException expected) {
            // documented behaviour
        }
    }

    @Test
    public void unmatchedBraceThrowsForPatternLocaleConstructor() {
        try {
            new ExtendedMessageFormat("Hello {0", Locale.US);
            fail("expected IllegalArgumentException for an unterminated format element");
        } catch (final IllegalArgumentException expected) {
            // documented behaviour
        }
    }

    @Test
    public void unmatchedBraceThrowsForPatternRegistryConstructor() {
        try {
            new ExtendedMessageFormat("Hello {0",
                    registryWith("upper", new RecordingFormatFactory(new UpperCaseFormat())));
            fail("expected IllegalArgumentException for an unterminated format element");
        } catch (final IllegalArgumentException expected) {
            // documented behaviour
        }
    }

    @Test
    public void unmatchedBraceThrowsForPatternLocaleRegistryConstructor() {
        try {
            new ExtendedMessageFormat("Hello {0", Locale.US,
                    registryWith("upper", new RecordingFormatFactory(new UpperCaseFormat())));
            fail("expected IllegalArgumentException for an unterminated format element");
        } catch (final IllegalArgumentException expected) {
            // documented behaviour
        }
    }

    @Test
    public void unknownFormatTypeThrowsIllegalArgumentException() {
        // "bogus" is neither a MessageFormat built-in nor a registry key.
        try {
            new ExtendedMessageFormat("value = {0,bogus}");
            fail("expected IllegalArgumentException for an unknown format type");
        } catch (final IllegalArgumentException expected) {
            // documented behaviour: bad pattern
        }
    }

    // ------------------------------------------------------------------
    // equals / hashCode
    // ------------------------------------------------------------------

    @Test
    public void equalForSamePatternAndLocale() {
        final ExtendedMessageFormat a = new ExtendedMessageFormat("Hi {0}", Locale.US);
        final ExtendedMessageFormat b = new ExtendedMessageFormat("Hi {0}", Locale.US);

        assertTrue(a.equals(b));
        assertTrue(b.equals(a));
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    public void notEqualForDifferentPatterns() {
        final ExtendedMessageFormat a = new ExtendedMessageFormat("Hi {0}", Locale.US);
        final ExtendedMessageFormat b = new ExtendedMessageFormat("Bye {0}", Locale.US);

        assertFalse(a.equals(b));
        assertFalse(b.equals(a));
    }

    @Test
    public void notEqualToNullAndUnrelatedTypes() {
        final ExtendedMessageFormat a = new ExtendedMessageFormat("Hi {0}");

        assertFalse(a.equals(null));
        assertFalse(a.equals("Hi {0}"));
        assertFalse(a.equals(Integer.valueOf(7)));
    }

    @Test
    public void equalToItselfAndHashCodeStable() {
        final ExtendedMessageFormat a = new ExtendedMessageFormat("Hi {0}");

        assertTrue(a.equals(a));
        assertEquals(a.hashCode(), a.hashCode());
    }
}
