/*
 * Copyright (C) 2014 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.gson.internal.bind;

import com.google.gson.Gson;
import com.google.gson.InstanceCreator;
import com.google.gson.TypeAdapter;
import com.google.gson.TypeAdapterFactory;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.internal.ConstructorConstructor;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.Collections;
import java.util.Locale;
import java.util.Map;
import junit.framework.TestCase;

/**
 * Unit tests for {@link JsonAdapterAnnotationTypeAdapterFactory}.
 */
public final class JsonAdapterAnnotationTypeAdapterFactoryAgentTest extends TestCase {

  private final ConstructorConstructor constructorConstructor =
      new ConstructorConstructor(Collections.<Type, InstanceCreator<?>>emptyMap());
  private final JsonAdapterAnnotationTypeAdapterFactory factory =
      new JsonAdapterAnnotationTypeAdapterFactory(constructorConstructor);
  private final Gson gson = new Gson();

  public void testCreateReturnsNullWhenTypeIsNotAnnotated() {
    TypeAdapter<NotAnnotated> adapter = factory.create(gson, TypeToken.get(NotAnnotated.class));
    assertNull(adapter);
  }

  public void testCreateReturnsAdapterFromAnnotatedTypeAdapterClass() throws IOException {
    TypeAdapter<Named> adapter = factory.create(gson, TypeToken.get(Named.class));
    assertNotNull(adapter);

    assertEquals("\"bob\"", adapter.toJson(new Named("bob")));
    assertEquals("alice", adapter.fromJson("\"alice\"").name);
  }

  public void testCreatedAdapterIsNullSafe() throws IOException {
    TypeAdapter<Named> adapter = factory.create(gson, TypeToken.get(Named.class));
    assertNotNull(adapter);

    // The declared adapter itself does not handle nulls (it would NPE), so if the
    // factory did not wrap it with nullSafe() these calls would throw instead.
    assertEquals("null", adapter.toJson(null));
    assertNull(adapter.fromJson("null"));
  }

  public void testCreateInvokesAnnotatedTypeAdapterFactory() throws IOException {
    TypeAdapter<Loud> adapter = factory.create(gson, TypeToken.get(Loud.class));
    assertNotNull(adapter);

    assertEquals("\"HELLO\"", adapter.toJson(new Loud("hello")));
    assertEquals("bye", adapter.fromJson("\"BYE\"").message);
  }

  public void testCreateReturnsNullWhenFactoryReturnsNullAdapter() {
    TypeAdapter<NullFactoryAnnotated> adapter =
        factory.create(gson, TypeToken.get(NullFactoryAnnotated.class));
    assertNull(adapter);
  }

  public void testCreateThrowsForInvalidAnnotationValue() {
    try {
      factory.create(gson, TypeToken.get(BadlyAnnotated.class));
      fail("Expected IllegalArgumentException");
    } catch (IllegalArgumentException expected) {
      assertEquals("@JsonAdapter value must be TypeAdapter or TypeAdapterFactory reference.",
          expected.getMessage());
    }
  }

  public void testCreateIsIndependentPerInvocation() throws IOException {
    TypeAdapter<Named> first = factory.create(gson, TypeToken.get(Named.class));
    TypeAdapter<Named> second = factory.create(gson, TypeToken.get(Named.class));

    assertNotNull(first);
    assertNotNull(second);
    assertNotSame(first, second);
    // Both instances are independently usable.
    assertEquals("\"first\"", first.toJson(new Named("first")));
    assertEquals("\"second\"", second.toJson(new Named("second")));
  }

  /** Plain class without a {@link JsonAdapter} annotation. */
  private static class NotAnnotated {
  }

  @JsonAdapter(NamedTypeAdapter.class)
  private static class Named {
    final String name;
    Named(String name) {
      this.name = name;
    }
  }

  private static class NamedTypeAdapter extends TypeAdapter<Named> {
    @Override public void write(JsonWriter out, Named value) throws IOException {
      out.value(value.name);
    }
    @Override public Named read(JsonReader in) throws IOException {
      return new Named(in.nextString());
    }
  }

  @JsonAdapter(UpperCaseTypeAdapterFactory.class)
  private static class Loud {
    final String message;
    Loud(String message) {
      this.message = message;
    }
  }

  private static class UpperCaseTypeAdapterFactory implements TypeAdapterFactory {
    @SuppressWarnings("unchecked")
    @Override public <T> TypeAdapter<T> create(Gson gson, TypeToken<T> type) {
      if (type.getRawType() != Loud.class) {
        return null;
      }
      return (TypeAdapter<T>) new TypeAdapter<Loud>() {
        @Override public void write(JsonWriter out, Loud value) throws IOException {
          out.value(value.message.toUpperCase(Locale.US));
        }
        @Override public Loud read(JsonReader in) throws IOException {
          return new Loud(in.nextString().toLowerCase(Locale.US));
        }
      };
    }
  }

  @JsonAdapter(NullTypeAdapterFactory.class)
  private static class NullFactoryAnnotated {
  }

  private static class NullTypeAdapterFactory implements TypeAdapterFactory {
    @Override public <T> TypeAdapter<T> create(Gson gson, TypeToken<T> type) {
      return null;
    }
  }

  // The annotation value is neither a TypeAdapter nor a TypeAdapterFactory, which
  // should cause JsonAdapterAnnotationTypeAdapterFactory#create to fail fast.
  @JsonAdapter(String.class)
  private static class BadlyAnnotated {
  }
}
