/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

/**
 * Unit tests {@link org.apache.commons.lang.Entities}.
 *
 * @version $Id$
 */
public class EntitiesAgentTest extends TestCase {

    /** Inverted exclamation mark, an ISO-8859-1 entity (iexcl). */
    private static final String IEXCL = "\u00A1";

    /** Non-breaking space, an ISO-8859-1 entity (nbsp). */
    private static final String NBSP = "\u00A0";

    /** Euro sign, an HTML 4.0 entity (euro). */
    private static final String EURO = "\u20AC";

    public EntitiesAgentTest(String name) {
        super(name);
    }

    public static void main(String[] args) {
        TestRunner.run(suite());
    }

    public static Test suite() {
        TestSuite suite = new TestSuite(EntitiesAgentTest.class);
        suite.setName("EntitiesAgent Tests");
        return suite;
    }

    /** A <code>Writer</code> that fails every write, to exercise the IOException contract. */
    private static class BrokenWriter extends Writer {
        public void write(char[] cbuf, int off, int len) throws IOException {
            throw new IOException("broken writer");
        }

        public void flush() throws IOException {
            throw new IOException("broken writer");
        }

        public void close() throws IOException {
            throw new IOException("broken writer");
        }
    }

    private Entities entities;

    protected void setUp() throws Exception {
        super.setUp();
        entities = new Entities();
    }

    protected void tearDown() throws Exception {
        entities = null;
        super.tearDown();
    }

    private String escapeToWriter(Entities e, String str) throws IOException {
        StringWriter writer = new StringWriter();
        e.escape(writer, str);
        return writer.toString();
    }

    private String unescapeToWriter(Entities e, String str) throws IOException {
        StringWriter writer = new StringWriter();
        e.unescape(writer, str);
        return writer.toString();
    }

    //-----------------------------------------------------------------------
    // addEntity / entityName / entityValue
    //-----------------------------------------------------------------------

    public void testAddEntityThenLookup() {
        entities.addEntity("foo", 0xA1);
        assertEquals(0xA1, entities.entityValue("foo"));
        assertEquals("foo", entities.entityName(0xA1));
    }

    public void testLookupOfUnknownEntity() {
        entities.addEntity("foo", 0xA1);
        assertEquals(-1, entities.entityValue("bar"));
        assertEquals(-1, entities.entityValue(""));
        assertNull(entities.entityName(0xA2));
        assertNull(entities.entityName(70000));
    }

    public void testLookupIsCaseSensitive() {
        entities.addEntity("Foo", 0x1234);
        assertEquals(0x1234, entities.entityValue("Foo"));
        assertEquals(-1, entities.entityValue("foo"));
        assertEquals(-1, entities.entityValue("FOO"));
    }

    public void testAddEntityLastNameWinsForSameValue() {
        entities.addEntity("first", 500);
        entities.addEntity("second", 500);
        assertEquals("second", entities.entityName(500));
        // both names still resolve to the value
        assertEquals(500, entities.entityValue("first"));
        assertEquals(500, entities.entityValue("second"));
    }

    public void testAddEntityLastValueWinsForSameName() {
        entities.addEntity("dup", 600);
        entities.addEntity("dup", 700);
        assertEquals(700, entities.entityValue("dup"));
        // the reverse mapping keeps both entries
        assertEquals("dup", entities.entityName(600));
        assertEquals("dup", entities.entityName(700));
    }

    public void testAddEntityWithZeroValue() {
        entities.addEntity("zero", 0);
        assertEquals(0, entities.entityValue("zero"));
        assertEquals("zero", entities.entityName(0));
    }

    //-----------------------------------------------------------------------
    // addEntities
    //-----------------------------------------------------------------------

    public void testAddEntities() {
        entities.addEntities(new String[][] { { "a", "65" }, { "b", "66" } });
        assertEquals(65, entities.entityValue("a"));
        assertEquals(66, entities.entityValue("b"));
        assertEquals("a", entities.entityName(65));
        assertEquals("b", entities.entityName(66));
    }

    public void testAddEntitiesEmptyArray() {
        entities.addEntities(new String[0][0]);
        assertEquals(-1, entities.entityValue("anything"));
    }

    public void testAddEntitiesNullArray() {
        try {
            entities.addEntities(null);
            fail("Expected NullPointerException");
        } catch (NullPointerException ex) {
            // expected
        }
    }

    public void testAddEntitiesNonNumericValue() {
        try {
            entities.addEntities(new String[][] { { "bad", "not-a-number" } });
            fail("Expected NumberFormatException");
        } catch (NumberFormatException ex) {
            // expected
        }
        assertEquals(-1, entities.entityValue("bad"));
    }

    public void testAddEntitiesShortRow() {
        try {
            entities.addEntities(new String[][] { { "onlyName" } });
            fail("Expected ArrayIndexOutOfBoundsException");
        } catch (ArrayIndexOutOfBoundsException ex) {
            // expected
        }
    }

    public void testAddEntitiesStopsAtFirstBadRow() {
        try {
            entities.addEntities(new String[][] { { "good", "65" }, { "bad", "x" }, { "never", "66" } });
            fail("Expected NumberFormatException");
        } catch (NumberFormatException ex) {
            // expected
        }
        assertEquals(65, entities.entityValue("good"));
        assertEquals(-1, entities.entityValue("never"));
    }

    //-----------------------------------------------------------------------
    // the shared, pre-populated entity sets
    //-----------------------------------------------------------------------

    public void testXmlEntitySet() {
        assertEquals(34, Entities.XML.entityValue("quot"));
        assertEquals(38, Entities.XML.entityValue("amp"));
        assertEquals(60, Entities.XML.entityValue("lt"));
        assertEquals(62, Entities.XML.entityValue("gt"));
        assertEquals(39, Entities.XML.entityValue("apos"));
        assertEquals("amp", Entities.XML.entityName(38));
        assertEquals("apos", Entities.XML.entityName(39));
        // XML has none of the ISO-8859-1 or HTML 4.0 entities
        assertEquals(-1, Entities.XML.entityValue("nbsp"));
        assertEquals(-1, Entities.XML.entityValue("euro"));
        assertNull(Entities.XML.entityName(160));
    }

    public void testHtml32EntitySet() {
        assertEquals(38, Entities.HTML32.entityValue("amp"));
        assertEquals(160, Entities.HTML32.entityValue("nbsp"));
        assertEquals(255, Entities.HTML32.entityValue("yuml"));
        assertEquals("nbsp", Entities.HTML32.entityName(160));
        assertEquals("yuml", Entities.HTML32.entityName(255));
        // apos is XML only; HTML 4.0 entities are not in the 3.2 set
        assertEquals(-1, Entities.HTML32.entityValue("apos"));
        assertEquals(-1, Entities.HTML32.entityValue("fnof"));
        assertEquals(-1, Entities.HTML32.entityValue("euro"));
    }

    public void testHtml40EntitySet() {
        assertEquals(38, Entities.HTML40.entityValue("amp"));
        assertEquals(160, Entities.HTML40.entityValue("nbsp"));
        assertEquals(402, Entities.HTML40.entityValue("fnof"));
        assertEquals(8364, Entities.HTML40.entityValue("euro"));
        assertEquals("euro", Entities.HTML40.entityName(8364));
        assertEquals("fnof", Entities.HTML40.entityName(402));
        // apos is deliberately absent from the HTML sets
        assertEquals(-1, Entities.HTML40.entityValue("apos"));
    }

    /** The lookup map is optimised for values below 256; check both sides of that edge. */
    public void testHtml40LookupTableBoundary() {
        assertEquals("yuml", Entities.HTML40.entityName(255));
        assertNull(Entities.HTML40.entityName(256));
        assertNull(Entities.HTML40.entityName(337));
        assertEquals("OElig", Entities.HTML40.entityName(338));
    }

    public void testEntitySetsAreDistinctInstances() {
        assertNotSame(Entities.XML, Entities.HTML32);
        assertNotSame(Entities.HTML32, Entities.HTML40);
        assertNotSame(Entities.XML, Entities.HTML40);
    }

    //-----------------------------------------------------------------------
    // escape(String)
    //-----------------------------------------------------------------------

    public void testEscapeKnownEntities() {
        assertEquals("&lt;foo&gt;", Entities.XML.escape("<foo>"));
        assertEquals("&amp;", Entities.XML.escape("&"));
        assertEquals("&quot;", Entities.XML.escape("\""));
        assertEquals("&apos;", Entities.XML.escape("'"));
        assertEquals("&lt;a href=&quot;x&quot;&gt;", Entities.XML.escape("<a href=\"x\">"));
    }

    public void testEscapeLeavesPlainAsciiAlone() {
        assertEquals("", Entities.XML.escape(""));
        assertEquals("plain text 123", Entities.XML.escape("plain text 123"));
        // 0x7F is the highest character that is still emitted verbatim
        assertEquals("\u007F", Entities.XML.escape("\u007F"));
        assertEquals("\0", Entities.XML.escape("\0"));
    }

    public void testEscapeUnmappedHighCharactersUseNumericReference() {
        // 0x80 is the first character above the verbatim range
        assertEquals("&#128;", Entities.XML.escape("\u0080"));
        assertEquals("&#161;", Entities.XML.escape(IEXCL));
        assertEquals("&#8364;", Entities.XML.escape(EURO));
        assertEquals("&#65535;", Entities.XML.escape("\uFFFF"));
    }

    public void testEscapePrefersEntityNameOverNumericReference() {
        assertEquals("&iexcl;", Entities.HTML32.escape(IEXCL));
        assertEquals("&nbsp;", Entities.HTML32.escape(NBSP));
        // euro has no name in HTML 3.2 but does in HTML 4.0
        assertEquals("&#8364;", Entities.HTML32.escape(EURO));
        assertEquals("&euro;", Entities.HTML40.escape(EURO));
    }

    public void testEscapeMixedContent() {
        assertEquals("a&lt;b&amp;c&#161;d", Entities.XML.escape("a<b&c" + IEXCL + "d"));
    }

    public void testEscapeUsesEntitiesAddedByTheCaller() {
        entities.addEntity("foo", 0xA1);
        assertEquals("&foo;", entities.escape(IEXCL));
        // nothing else is escaped by this set
        assertEquals("<&>", entities.escape("<&>"));
    }

    public void testEscapeNullThrows() {
        try {
            Entities.XML.escape((String) null);
            fail("Expected NullPointerException");
        } catch (NullPointerException ex) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // escape(Writer, String)
    //-----------------------------------------------------------------------

    public void testEscapeToWriterMatchesEscapeToString() throws IOException {
        String[] inputs = new String[] {
            "", "plain", "<foo>", "a<b&c" + IEXCL + "d", "\u007F", "\u0080", "\uFFFF", "'\"", NBSP };
        for (int i = 0; i < inputs.length; i++) {
            assertEquals(inputs[i], Entities.XML.escape(inputs[i]), escapeToWriter(Entities.XML, inputs[i]));
        }
        assertEquals("&euro;", escapeToWriter(Entities.HTML40, EURO));
        assertEquals("&nbsp;", escapeToWriter(Entities.HTML32, NBSP));
    }

    public void testEscapeToWriterAppendsToExistingContent() throws IOException {
        StringWriter writer = new StringWriter();
        writer.write("prefix:");
        Entities.XML.escape(writer, "<x>");
        Entities.XML.escape(writer, "&");
        assertEquals("prefix:&lt;x&gt;&amp;", writer.toString());
    }

    public void testEscapeToWriterEmptyStringWritesNothing() throws IOException {
        StringWriter writer = new StringWriter();
        Entities.XML.escape(writer, "");
        assertEquals("", writer.toString());
    }

    public void testEscapeToWriterPropagatesIOException() {
        try {
            Entities.XML.escape(new BrokenWriter(), "abc");
            fail("Expected IOException");
        } catch (IOException ex) {
            assertEquals("broken writer", ex.getMessage());
        }
    }

    public void testEscapeToWriterNullStringThrows() throws IOException {
        try {
            Entities.XML.escape(new StringWriter(), null);
            fail("Expected NullPointerException");
        } catch (NullPointerException ex) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // unescape(String)
    //-----------------------------------------------------------------------

    public void testUnescapeWithoutAmpersandReturnsSameInstance() {
        String input = "no entities here";
        assertSame(input, Entities.XML.unescape(input));
        assertSame("", Entities.XML.unescape(""));
    }

    public void testUnescapeNamedEntities() {
        assertEquals("<foo>", Entities.XML.unescape("&lt;foo&gt;"));
        assertEquals("&", Entities.XML.unescape("&amp;"));
        assertEquals("'", Entities.XML.unescape("&apos;"));
        assertEquals("abc<def", Entities.XML.unescape("abc&lt;def"));
        assertEquals(NBSP, Entities.HTML32.unescape("&nbsp;"));
        assertEquals(EURO, Entities.HTML40.unescape("&euro;"));
    }

    public void testUnescapeUnknownNamesAreLeftAlone() {
        assertEquals("&unknown;", Entities.XML.unescape("&unknown;"));
        // apos is not part of the HTML sets
        assertEquals("&apos;", Entities.HTML40.unescape("&apos;"));
        assertEquals("x&unknown;y", Entities.XML.unescape("x&unknown;y"));
    }

    public void testUnescapeDecimalReferences() {
        assertEquals("A", Entities.XML.unescape("&#65;"));
        assertEquals("\0", Entities.XML.unescape("&#0;"));
        assertEquals(IEXCL, Entities.XML.unescape("&#161;"));
        assertEquals("\uFFFF", Entities.XML.unescape("&#65535;"));
    }

    public void testUnescapeHexReferences() {
        assertEquals("A", Entities.XML.unescape("&#x41;"));
        assertEquals("A", Entities.XML.unescape("&#X41;"));
        assertEquals("\uFFFF", Entities.XML.unescape("&#xFFFF;"));
        assertEquals(IEXCL, Entities.XML.unescape("&#xa1;"));
    }

    /** Values above the 16 bit range cannot be represented by a char and are left untouched. */
    public void testUnescapeOutOfRangeReferences() {
        assertEquals("&#65536;", Entities.XML.unescape("&#65536;"));
        assertEquals("&#1114111;", Entities.XML.unescape("&#1114111;"));
        assertEquals("&#x10000;", Entities.XML.unescape("&#x10000;"));
        assertEquals("&#12345678;", Entities.XML.unescape("&#12345678;"));
        // does not fit in an int at all
        assertEquals("&#99999999999;", Entities.XML.unescape("&#99999999999;"));
        assertEquals("&#xFFFFFFFF;", Entities.XML.unescape("&#xFFFFFFFF;"));
        // a negative literal parses, but collides with the -1 "not found" sentinel
        assertEquals("&#-1;", Entities.XML.unescape("&#-1;"));
    }

    public void testUnescapeMalformedReferences() {
        assertEquals("&;", Entities.XML.unescape("&;"));
        assertEquals("&#;", Entities.XML.unescape("&#;"));
        assertEquals("&#x;", Entities.XML.unescape("&#x;"));
        assertEquals("&#abc;", Entities.XML.unescape("&#abc;"));
        assertEquals("&#xZZ;", Entities.XML.unescape("&#xZZ;"));
    }

    public void testUnescapeUnterminatedEntity() {
        assertEquals("&amp", Entities.XML.unescape("&amp"));
        assertEquals("a & b", Entities.XML.unescape("a & b"));
        assertEquals("&", Entities.XML.unescape("&"));
        assertEquals("tail&", Entities.XML.unescape("tail&"));
    }

    /** An ampersand before the semi-colon means this is not an entity. */
    public void testUnescapeNestedAmpersand() {
        assertEquals("&foo&", Entities.XML.unescape("&foo&amp;"));
        assertEquals("&&", Entities.XML.unescape("&&amp;"));
    }

    /** Unescaping is a single pass: the output is not re-scanned for entities. */
    public void testUnescapeIsNotRecursive() {
        assertEquals("&lt;", Entities.XML.unescape("&#38;lt;"));
        assertEquals("&amp;", Entities.XML.unescape("&amp;amp;"));
    }

    public void testUnescapeAdjacentEntities() {
        assertEquals("<>", Entities.XML.unescape("&lt;&gt;"));
        assertEquals("<&>", Entities.XML.unescape("&lt;&amp;&gt;"));
    }

    public void testUnescapeUsesEntitiesAddedByTheCaller() {
        entities.addEntity("foo", 0xA1);
        assertEquals(IEXCL, entities.unescape("&foo;"));
        assertEquals("&lt;", entities.unescape("&lt;"));
    }

    public void testUnescapeNullThrows() {
        try {
            Entities.XML.unescape((String) null);
            fail("Expected NullPointerException");
        } catch (NullPointerException ex) {
            // expected
        }
    }

    public void testEscapeUnescapeRoundTrip() {
        String original = "<a href=\"x\">" + IEXCL + "&" + EURO + NBSP + "</a>";
        String escaped = Entities.HTML40.escape(original);
        assertEquals("&lt;a href=&quot;x&quot;&gt;&iexcl;&amp;&euro;&nbsp;&lt;/a&gt;", escaped);
        assertEquals(original, Entities.HTML40.unescape(escaped));
    }

    //-----------------------------------------------------------------------
    // unescape(Writer, String)
    //-----------------------------------------------------------------------

    public void testUnescapeToWriterMatchesUnescapeToString() throws IOException {
        String[] inputs = new String[] {
            "", "plain", "&lt;foo&gt;", "abc&lt;def", "&unknown;", "&amp", "&;", "&#;", "&#x;",
            "&#abc;", "&#xZZ;", "&#65;", "&#x41;", "&#X41;", "&#0;", "&#65535;", "&#65536;",
            "&#x10000;", "&#1114111;", "&#xFFFFFFFF;", "&#-1;", "&foo&amp;", "&#38;lt;",
            "&lt;&gt;", "tail&" };
        for (int i = 0; i < inputs.length; i++) {
            assertEquals(inputs[i], Entities.XML.unescape(inputs[i]), unescapeToWriter(Entities.XML, inputs[i]));
        }
        assertEquals(EURO, unescapeToWriter(Entities.HTML40, "&euro;"));
        assertEquals(NBSP, unescapeToWriter(Entities.HTML32, "&nbsp;"));
    }

    public void testUnescapeToWriterAppendsToExistingContent() throws IOException {
        StringWriter writer = new StringWriter();
        writer.write("prefix:");
        Entities.XML.unescape(writer, "&lt;x&gt;");
        Entities.XML.unescape(writer, " plain");
        assertEquals("prefix:<x> plain", writer.toString());
    }

    public void testUnescapeToWriterPropagatesIOException() {
        try {
            Entities.XML.unescape(new BrokenWriter(), "no entities");
            fail("Expected IOException");
        } catch (IOException ex) {
            assertEquals("broken writer", ex.getMessage());
        }
        try {
            Entities.XML.unescape(new BrokenWriter(), "&lt;");
            fail("Expected IOException");
        } catch (IOException ex) {
            assertEquals("broken writer", ex.getMessage());
        }
    }

    public void testUnescapeToWriterNullStringThrows() throws IOException {
        try {
            Entities.XML.unescape(new StringWriter(), null);
            fail("Expected NullPointerException");
        } catch (NullPointerException ex) {
            // expected
        }
    }
}
