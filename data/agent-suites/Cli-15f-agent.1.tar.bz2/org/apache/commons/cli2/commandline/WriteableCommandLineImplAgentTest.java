/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.cli2.commandline;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import junit.framework.TestCase;

import org.apache.commons.cli2.Argument;
import org.apache.commons.cli2.Option;
import org.apache.commons.cli2.builder.ArgumentBuilder;
import org.apache.commons.cli2.builder.DefaultOptionBuilder;
import org.apache.commons.cli2.option.PropertyOption;
import org.apache.commons.cli2.resource.ResourceConstants;
import org.apache.commons.cli2.resource.ResourceHelper;

/**
 * Direct unit tests for the public API of {@link WriteableCommandLineImpl}.
 *
 * Written for JUnit 3.8 (the version shipped with this project): the class
 * extends {@link TestCase}, test methods are named <code>testXxx</code> and the
 * <code>junit.framework.Assert</code> style assertions are used.
 */
public class WriteableCommandLineImplAgentTest extends TestCase {

    private static final ResourceHelper resources = ResourceHelper.getResourceHelper();

    /** Root option used to seed the command line - carries the "-"/"--" prefixes. */
    private Option root;

    /** A plain (non Argument) option with a preferred name and an alias. */
    private Option opt;

    /** A second, unrelated plain option. */
    private Option other;

    private WriteableCommandLineImpl cl;

    public void setUp() throws Exception {
        super.setUp();
        root = new DefaultOptionBuilder().withLongName("root").create();
        opt =
            new DefaultOptionBuilder().withLongName("foo").withLongName("foo-alias").create();
        other = new DefaultOptionBuilder().withLongName("bar").create();
        cl = new WriteableCommandLineImpl(root, new ArrayList());
    }

    private static List list(final Object[] items) {
        return new ArrayList(Arrays.asList(items));
    }

    // ------------------------------------------------------------------
    // constructor / getNormalised / toString
    // ------------------------------------------------------------------

    public void testGetNormalisedReturnsArgumentsAndIsUnmodifiable() {
        final List args = list(new String[] { "--foo", "bar" });
        final WriteableCommandLineImpl local = new WriteableCommandLineImpl(root, args);

        assertEquals(list(new String[] { "--foo", "bar" }), local.getNormalised());

        try {
            local.getNormalised().add("baz");
            fail("expected UnsupportedOperationException");
        } catch (UnsupportedOperationException e) {
            // expected - the returned view is unmodifiable
        }
    }

    public void testGetNormalisedEmptyByDefault() {
        assertTrue(cl.getNormalised().isEmpty());
    }

    public void testToStringJoinsArgumentsWithSpaces() {
        final WriteableCommandLineImpl local =
            new WriteableCommandLineImpl(root, list(new String[] { "-a", "-b", "-c" }));
        assertEquals("-a -b -c", local.toString());
    }

    public void testToStringQuotesArgumentsContainingSpaces() {
        final WriteableCommandLineImpl local =
            new WriteableCommandLineImpl(root, list(new String[] { "hello world", "plain" }));
        assertEquals("\"hello world\" plain", local.toString());
    }

    public void testToStringSingleArgumentHasNoTrailingSpace() {
        final WriteableCommandLineImpl local =
            new WriteableCommandLineImpl(root, list(new String[] { "solo" }));
        assertEquals("solo", local.toString());
    }

    public void testToStringEmptyWhenNoArguments() {
        assertEquals("", cl.toString());
    }

    public void testConstructorNullRootThrowsNullPointerException() {
        try {
            new WriteableCommandLineImpl(null, new ArrayList());
            fail("expected NullPointerException");
        } catch (NullPointerException e) {
            // expected - the constructor dereferences the root option
        }
    }

    public void testConstructorAllowsNullArguments() {
        final WriteableCommandLineImpl local = new WriteableCommandLineImpl(root, null);
        local.addOption(opt);

        assertTrue(local.hasOption(opt));
        assertTrue(local.looksLikeOption("--anything"));
    }

    // ------------------------------------------------------------------
    // addOption / hasOption / getOption / getOptions / getOptionTriggers
    // ------------------------------------------------------------------

    public void testAddOptionMakesOptionPresent() {
        assertFalse(cl.hasOption(opt));
        assertFalse(cl.hasOption("--foo"));

        cl.addOption(opt);

        assertTrue(cl.hasOption(opt));
        assertTrue(cl.hasOption("--foo"));
        assertFalse(cl.hasOption(other));
        assertFalse(cl.hasOption("--bar"));
    }

    public void testGetOptionResolvesEveryTrigger() {
        cl.addOption(opt);

        assertSame(opt, cl.getOption("--foo"));
        assertSame(opt, cl.getOption("--foo-alias"));
        assertNull(cl.getOption("--missing"));
        assertNull(cl.getOption(null));
    }

    public void testGetOptionsKeepsInsertionOrderAndDuplicates() {
        cl.addOption(opt);
        cl.addOption(other);
        cl.addOption(opt);

        final List options = cl.getOptions();
        assertEquals(3, options.size());
        assertSame(opt, options.get(0));
        assertSame(other, options.get(1));
        assertSame(opt, options.get(2));
    }

    public void testGetOptionsIsUnmodifiable() {
        cl.addOption(opt);
        try {
            cl.getOptions().add(other);
            fail("expected UnsupportedOperationException");
        } catch (UnsupportedOperationException e) {
            // expected
        }
    }

    public void testGetOptionTriggersContainsAllTriggers() {
        assertTrue(cl.getOptionTriggers().isEmpty());

        cl.addOption(opt);

        final Set triggers = cl.getOptionTriggers();
        assertEquals(2, triggers.size());
        assertTrue(triggers.contains("--foo"));
        assertTrue(triggers.contains("--foo-alias"));

        try {
            triggers.add("--x");
            fail("expected UnsupportedOperationException");
        } catch (UnsupportedOperationException e) {
            // expected
        }
    }

    public void testGetOptionCountCountsRepeatedOptions() {
        assertEquals(0, cl.getOptionCount(opt));

        cl.addOption(opt);
        cl.addOption(opt);
        cl.addOption(other);

        assertEquals(2, cl.getOptionCount(opt));
        assertEquals(1, cl.getOptionCount(other));
        assertEquals(0, cl.getOptionCount((Option) null));
    }

    // ------------------------------------------------------------------
    // addValue / getValues / getUndefaultedValues
    // ------------------------------------------------------------------

    public void testAddValueAccumulatesValuesInOrderAndDoesNotRegisterPlainOption() {
        assertTrue(cl.getValues(opt, null).isEmpty());

        cl.addValue(opt, "a");
        cl.addValue(opt, "b");

        assertEquals(list(new String[] { "a", "b" }), cl.getValues(opt, null));
        // a plain option is not made "present" merely by adding values
        assertFalse(cl.hasOption(opt));
    }

    public void testAddValueRegistersArgumentOption() {
        final Argument arg = new ArgumentBuilder().withName("files").create();

        assertFalse(cl.hasOption(arg));

        cl.addValue(arg, "x");

        assertTrue(cl.hasOption(arg));
        assertEquals(Collections.singletonList("x"), cl.getValues(arg, null));
    }

    public void testGetValuesUnknownOptionReturnsEmptyList() {
        assertSame(Collections.EMPTY_LIST, cl.getValues(other, null));
    }

    public void testGetValuesReturnsMethodSuppliedDefaultsWhenNoValues() {
        final List defs = list(new String[] { "d1", "d2" });
        assertSame(defs, cl.getValues(other, defs));
    }

    public void testGetValuesFallsBackToOptionDefaults() {
        cl.setDefaultValues(opt, Collections.singletonList("od1"));

        assertEquals(Collections.singletonList("od1"), cl.getValues(opt, null));
        assertEquals(Collections.singletonList("od1"),
                     cl.getValues(opt, Collections.EMPTY_LIST));
    }

    public void testGetValuesAugmentsSuppliedValuesWithExtraOptionDefaults() {
        cl.addValue(opt, "v1");
        cl.setDefaultValues(opt, list(new String[] { "d1", "d2", "d3" }));

        // one real value plus the trailing defaults that were not overridden
        assertEquals(list(new String[] { "v1", "d2", "d3" }), cl.getValues(opt, null));
    }

    public void testGetValuesDoesNotTruncateWhenMoreValuesThanDefaults() {
        cl.addValue(opt, "a");
        cl.addValue(opt, "b");
        cl.addValue(opt, "c");
        cl.setDefaultValues(opt, Collections.singletonList("d1"));

        assertEquals(list(new String[] { "a", "b", "c" }), cl.getValues(opt, null));
    }

    public void testSetDefaultValuesNullRemovesDefaults() {
        cl.setDefaultValues(opt, Collections.singletonList("d1"));
        assertEquals(Collections.singletonList("d1"), cl.getValues(opt, null));

        cl.setDefaultValues(opt, null);
        assertSame(Collections.EMPTY_LIST, cl.getValues(opt, null));
    }

    public void testGetUndefaultedValuesIgnoresDefaults() {
        cl.setDefaultValues(opt, Collections.singletonList("d1"));
        assertSame(Collections.EMPTY_LIST, cl.getUndefaultedValues(opt));

        cl.addValue(opt, "v1");
        assertEquals(Collections.singletonList("v1"), cl.getUndefaultedValues(opt));
    }

    public void testGetValueThrowsWhenOptionHasMultipleValues() {
        cl.addValue(opt, "a");
        cl.addValue(opt, "b");

        try {
            cl.getValue(opt);
            fail("expected IllegalStateException");
        } catch (IllegalStateException e) {
            assertEquals(resources.getMessage(ResourceConstants.ARGUMENT_TOO_MANY_VALUES),
                         e.getMessage());
        }
    }

    // ------------------------------------------------------------------
    // addSwitch / getSwitch / setDefaultSwitch
    // ------------------------------------------------------------------

    public void testAddSwitchRecordsValueAndRegistersOption() {
        assertNull(cl.getSwitch(opt, null));

        cl.addSwitch(opt, true);
        assertEquals(Boolean.TRUE, cl.getSwitch(opt, null));
        assertTrue(cl.hasOption(opt));

        cl.addSwitch(other, false);
        assertEquals(Boolean.FALSE, cl.getSwitch(other, null));
        assertTrue(cl.hasOption(other));
    }

    public void testAddSwitchTwiceThrowsAndLeavesFirstValueIntact() {
        cl.addSwitch(opt, true);

        try {
            cl.addSwitch(opt, false);
            fail("expected IllegalStateException");
        } catch (IllegalStateException e) {
            assertEquals(resources.getMessage(ResourceConstants.SWITCH_ALREADY_SET),
                         e.getMessage());
        }

        // re-setting the same value is rejected too
        try {
            cl.addSwitch(opt, true);
            fail("expected IllegalStateException");
        } catch (IllegalStateException e) {
            assertEquals(resources.getMessage(ResourceConstants.SWITCH_ALREADY_SET),
                         e.getMessage());
        }

        assertEquals(Boolean.TRUE, cl.getSwitch(opt, null));
    }

    public void testGetSwitchDefaultPrecedence() {
        // nothing known -> null
        assertNull(cl.getSwitch(opt, null));
        // method supplied default is used when nothing else is known
        assertEquals(Boolean.TRUE, cl.getSwitch(opt, Boolean.TRUE));

        cl.setDefaultSwitch(opt, Boolean.FALSE);
        // option default is used when no method default is supplied
        assertEquals(Boolean.FALSE, cl.getSwitch(opt, null));
        // method supplied default beats the option default
        assertEquals(Boolean.TRUE, cl.getSwitch(opt, Boolean.TRUE));

        cl.addSwitch(opt, true);
        // an actually parsed switch beats every default
        assertEquals(Boolean.TRUE, cl.getSwitch(opt, Boolean.FALSE));
    }

    public void testSetDefaultSwitchNullRemovesDefault() {
        cl.setDefaultSwitch(opt, Boolean.TRUE);
        assertEquals(Boolean.TRUE, cl.getSwitch(opt, null));

        cl.setDefaultSwitch(opt, null);
        assertNull(cl.getSwitch(opt, null));
    }

    // ------------------------------------------------------------------
    // properties
    // ------------------------------------------------------------------

    public void testDefaultPropertyOptionRoundTrip() {
        assertNull(cl.getProperty("missing"));

        cl.addProperty("key", "val");

        assertEquals("val", cl.getProperty("key"));
        assertEquals("val", cl.getProperty(new PropertyOption(), "key", "def"));
        assertEquals("def", cl.getProperty(new PropertyOption(), "missing", "def"));

        final Set names = cl.getProperties();
        assertEquals(1, names.size());
        assertTrue(names.contains("key"));
    }

    public void testAddPropertyOverwritesExistingValue() {
        final PropertyOption po = new PropertyOption();

        cl.addProperty(po, "k", "v1");
        assertEquals("v1", cl.getProperty(po, "k", null));

        cl.addProperty(po, "k", "v2");
        assertEquals("v2", cl.getProperty(po, "k", null));
        assertEquals(1, cl.getProperties(po).size());
    }

    public void testPropertiesAreIsolatedPerOption() {
        cl.addProperty(opt, "k", "a");
        cl.addProperty(other, "k", "b");

        assertEquals("a", cl.getProperty(opt, "k", null));
        assertEquals("b", cl.getProperty(other, "k", null));
        // an option with no properties at all falls back to the supplied default
        assertEquals("z", cl.getProperty(root, "k", "z"));
    }

    public void testGetPropertiesUnknownOptionReturnsEmptySet() {
        final Set empty = cl.getProperties(other);
        assertTrue(empty.isEmpty());
        assertSame(Collections.EMPTY_SET, empty);
    }

    public void testGetPropertiesIsUnmodifiableOncePopulated() {
        cl.addProperty(other, "x", "y");

        final Set props = cl.getProperties(other);
        assertEquals(1, props.size());
        assertTrue(props.contains("x"));

        try {
            props.add("z");
            fail("expected UnsupportedOperationException");
        } catch (UnsupportedOperationException e) {
            // expected
        }
    }

    // ------------------------------------------------------------------
    // looksLikeOption
    // ------------------------------------------------------------------

    public void testLooksLikeOptionWithStandardPrefixes() {
        assertTrue(cl.looksLikeOption("--foo"));
        assertTrue(cl.looksLikeOption("-x"));
        assertFalse(cl.looksLikeOption("foo"));
        assertFalse(cl.looksLikeOption("+foo"));
        assertFalse(cl.looksLikeOption(""));
    }

    public void testLooksLikeOptionWithArgumentRootHasNoPrefixes() {
        final Argument arg = new ArgumentBuilder().withName("f").create();
        final WriteableCommandLineImpl local = new WriteableCommandLineImpl(arg, new ArrayList());

        assertFalse(local.looksLikeOption("--anything"));
        assertFalse(local.looksLikeOption("-x"));
        assertFalse(local.looksLikeOption("plain"));
    }

    public void testLooksLikeOptionWithPropertyOptionRoot() {
        final WriteableCommandLineImpl local =
            new WriteableCommandLineImpl(new PropertyOption(), new ArrayList());

        assertTrue(local.looksLikeOption("-Dfoo"));
        assertFalse(local.looksLikeOption("-x"));
        assertFalse(local.looksLikeOption("foo"));
    }
}
