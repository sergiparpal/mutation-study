/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang.text;

import java.text.FieldPosition;
import java.text.Format;
import java.text.MessageFormat;
import java.text.ParsePosition;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Tests the public API of {@link org.apache.commons.lang.text.ExtendedMessageFormat}.
 */
public class ExtendedMessageFormatAgentTest extends TestCase {

    private Map registry;

    public ExtendedMessageFormatAgentTest(String name) {
        super(name);
    }

    public static Test suite() {
        return new TestSuite(ExtendedMessageFormatAgentTest.class);
    }

    protected void setUp() throws Exception {
        super.setUp();
        registry = new HashMap();
        registry.put("upper", new UpperCaseFormatFactory());
        registry.put("lower", new LowerCaseFormatFactory());
    }

    // ------------------------------------------------------------------
    // Constructors / locale handling
    // ------------------------------------------------------------------

    public void testDefaultLocaleConstructors() {
        assertEquals(Locale.getDefault(),
                new ExtendedMessageFormat("{0}").getLocale());
        assertEquals(Locale.getDefault(),
                new ExtendedMessageFormat("{0,upper}", registry).getLocale());
    }

    public void testExplicitLocaleIsRetained() {
        ExtendedMessageFormat emf =
                new ExtendedMessageFormat("{0}", Locale.CANADA_FRENCH);
        assertEquals(Locale.CANADA_FRENCH, emf.getLocale());

        ExtendedMessageFormat emfWithRegistry =
                new ExtendedMessageFormat("{0,upper}", Locale.GERMANY, registry);
        assertEquals(Locale.GERMANY, emfWithRegistry.getLocale());
    }

    public void testNullRegistryBehavesLikeNoRegistry() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", (Map) null);
        assertEquals("{0}", emf.toPattern());
        assertEquals("v", emf.format(new Object[] { "v" }));
    }

    // ------------------------------------------------------------------
    // No registry: behaviour must mirror java.text.MessageFormat
    // ------------------------------------------------------------------

    public void testNoRegistryMatchesMessageFormat() {
        assertMatchesMessageFormat("Plain text, no elements", Locale.US, new Object[0]);
        assertMatchesMessageFormat("{0}", Locale.US, new Object[] { "x" });
        assertMatchesMessageFormat("{0} {1} {2}", Locale.US,
                new Object[] { "a", "b", "c" });
        assertMatchesMessageFormat("{0,number,integer}", Locale.US,
                new Object[] { new Integer(1234) });
        assertMatchesMessageFormat("{0,number,#,##0.00}", Locale.US,
                new Object[] { new Double(1234.5) });
        assertMatchesMessageFormat("{0,number,#,##0.00}", Locale.GERMANY,
                new Object[] { new Double(1234.5) });
        assertMatchesMessageFormat("{0,choice,0#zero|1#one|1<many}", Locale.US,
                new Object[] { new Integer(2) });
        assertMatchesMessageFormat("it''s {0}", Locale.US, new Object[] { "x" });
        assertMatchesMessageFormat("'{'0'}'", Locale.US, new Object[0]);
    }

    public void testNoRegistryConcreteValues() {
        assertEquals("1,234", new ExtendedMessageFormat("{0,number,integer}", Locale.US)
                .format(new Object[] { new Integer(1234) }));
        assertEquals("1.234,50", new ExtendedMessageFormat("{0,number,#,##0.00}", Locale.GERMANY)
                .format(new Object[] { new Double(1234.5) }));
        assertEquals("it's x", new ExtendedMessageFormat("it''s {0}", Locale.US)
                .format(new Object[] { "x" }));
        assertEquals("{0}", new ExtendedMessageFormat("'{'0'}'", Locale.US)
                .format(new Object[0]));
        assertEquals("many", new ExtendedMessageFormat("{0,choice,0#zero|1#one|1<many}", Locale.US)
                .format(new Object[] { new Integer(2) }));
    }

    public void testEmptyPattern() {
        ExtendedMessageFormat noRegistry = new ExtendedMessageFormat("");
        assertEquals("", noRegistry.toPattern());
        assertEquals("", noRegistry.format(new Object[0]));

        ExtendedMessageFormat withRegistry = new ExtendedMessageFormat("", registry);
        assertEquals("", withRegistry.toPattern());
        assertEquals("", withRegistry.format(new Object[0]));
    }

    // ------------------------------------------------------------------
    // Registry: custom formats
    // ------------------------------------------------------------------

    public void testCustomFormatIsApplied() {
        ExtendedMessageFormat upper =
                new ExtendedMessageFormat("Hello {0,upper}!", registry);
        assertEquals("Hello WORLD!", upper.format(new Object[] { "world" }));

        ExtendedMessageFormat lower =
                new ExtendedMessageFormat("Hello {0,lower}!", registry);
        assertEquals("Hello world!", lower.format(new Object[] { "WORLD" }));
    }

    public void testToPatternReinsertsCustomFormats() {
        assertEquals("Hello {0,upper}!",
                new ExtendedMessageFormat("Hello {0,upper}!", registry).toPattern());
        assertEquals("{0,upper} and {1,lower}",
                new ExtendedMessageFormat("{0,upper} and {1,lower}", registry).toPattern());
        assertEquals("{0,upper} {0}",
                new ExtendedMessageFormat("{0,upper} {0}", registry).toPattern());
        assertEquals("A {0,upper} B {1} C",
                new ExtendedMessageFormat("A {0,upper} B {1} C", registry).toPattern());
    }

    public void testMultipleAndReusedArguments() {
        assertEquals("AA and bb",
                new ExtendedMessageFormat("{0,upper} and {1,lower}", registry)
                        .format(new Object[] { "aa", "BB" }));
        assertEquals("AB aB",
                new ExtendedMessageFormat("{0,upper} {0}", registry)
                        .format(new Object[] { "aB" }));
        assertEquals("A X B y C",
                new ExtendedMessageFormat("A {0,upper} B {1} C", registry)
                        .format(new Object[] { "x", "y" }));
    }

    public void testMixedCustomAndBuiltInFormats() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat(
                "{0,upper} #{1,number,integer}", Locale.US, registry);
        assertEquals("HI #7", emf.format(new Object[] { "hi", new Integer(7) }));
        assertEquals("{0,upper} #{1,number,integer}", emf.toPattern());
    }

    public void testGetFormatsContainsCustomFormatInstance() {
        ExtendedMessageFormat emf =
                new ExtendedMessageFormat("x {0,upper} y", registry);
        Format[] formats = emf.getFormats();
        assertEquals(1, formats.length);
        assertTrue("expected an UpperCaseFormat but was " + formats[0],
                formats[0] instanceof UpperCaseFormat);
    }

    public void testUnknownFormatNameFallsThroughToBuiltIn() {
        String pattern = "{0,number,#,##0.0}";
        ExtendedMessageFormat emf =
                new ExtendedMessageFormat(pattern, Locale.US, registry);
        MessageFormat reference = new MessageFormat(pattern, Locale.US);

        assertEquals(reference.toPattern(), emf.toPattern());
        assertEquals("1,234.5", emf.format(new Object[] { new Double(1234.5) }));
        assertEquals(reference.format(new Object[] { new Double(1234.5) }),
                emf.format(new Object[] { new Double(1234.5) }));
    }

    public void testRegistryOverridesBuiltInFormat() {
        Map custom = new HashMap();
        custom.put("number", new UpperCaseFormatFactory());
        ExtendedMessageFormat emf =
                new ExtendedMessageFormat("{0,number}", Locale.US, custom);
        assertEquals("ABC", emf.format(new Object[] { "abc" }));
        assertEquals("{0,number}", emf.toPattern());
    }

    public void testFactoryReceivesFormatNameStyleAndLocale() {
        RecordingFormatFactory factory = new RecordingFormatFactory();
        Map custom = new HashMap();
        custom.put("tag", factory);

        ExtendedMessageFormat emf = new ExtendedMessageFormat(
                "<{0,tag,section header}>", Locale.US, custom);
        assertEquals("<HI>", emf.format(new Object[] { "hi" }));
        assertEquals(1, factory.calls);
        assertEquals("tag", factory.name);
        assertEquals("section header", factory.arguments);
        assertEquals(Locale.US, factory.locale);
    }

    public void testFactoryReceivesNullStyleWhenAbsent() {
        RecordingFormatFactory factory = new RecordingFormatFactory();
        Map custom = new HashMap();
        custom.put("tag", factory);

        ExtendedMessageFormat emf =
                new ExtendedMessageFormat("<{0,tag}>", Locale.GERMANY, custom);
        assertEquals("<HI>", emf.format(new Object[] { "hi" }));
        assertEquals("tag", factory.name);
        assertNull(factory.arguments);
        assertEquals(Locale.GERMANY, factory.locale);
    }

    // ------------------------------------------------------------------
    // Escaped quotes (LANG-477)
    // ------------------------------------------------------------------

    public void testEscapedQuotesAdjacentToCustomFormat() {
        ExtendedMessageFormat emf =
                new ExtendedMessageFormat("''{0,lower}''", registry);
        assertEquals("'abc'", emf.format(new Object[] { "ABC" }));
        assertEquals("''{0,lower}''", emf.toPattern());
    }

    public void testEscapedQuoteInLiteralTextWithCustomFormat_LANG477() {
        ExtendedMessageFormat emf =
                new ExtendedMessageFormat("it''s a {0,lower} 'test'!", registry);
        assertEquals("it's a dummy test!", emf.format(new Object[] { "DUMMY" }));
        assertEquals("it''s a {0,lower} test!", emf.toPattern());
    }

    // ------------------------------------------------------------------
    // applyPattern replaces previously parsed state
    // ------------------------------------------------------------------

    public void testApplyPatternReplacesCustomFormatWithPlain() {
        ExtendedMessageFormat emf =
                new ExtendedMessageFormat("{0,upper}", registry);
        assertEquals("A", emf.format(new Object[] { "a" }));

        emf.applyPattern("plain {0}");
        assertEquals("plain {0}", emf.toPattern());
        assertEquals("plain Xy", emf.format(new Object[] { "Xy" }));
    }

    public void testApplyPatternInstallsCustomFormat() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", registry);
        assertEquals("a", emf.format(new Object[] { "a" }));

        emf.applyPattern("[{0,upper}]");
        assertEquals("[{0,upper}]", emf.toPattern());
        assertEquals("[A]", emf.format(new Object[] { "a" }));
    }

    // ------------------------------------------------------------------
    // Disabled sub-format mutators
    // ------------------------------------------------------------------

    public void testSetFormatThrowsUnsupportedOperation() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        try {
            emf.setFormat(0, new UpperCaseFormat());
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
    }

    public void testSetFormatByArgumentIndexThrowsUnsupportedOperation() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        try {
            emf.setFormatByArgumentIndex(0, new UpperCaseFormat());
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
    }

    public void testSetFormatsThrowsUnsupportedOperation() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        try {
            emf.setFormats(new Format[] { new UpperCaseFormat() });
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
    }

    public void testSetFormatsByArgumentIndexThrowsUnsupportedOperation() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        try {
            emf.setFormatsByArgumentIndex(new Format[] { new UpperCaseFormat() });
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
    }

    // ------------------------------------------------------------------
    // Error / boundary cases
    // ------------------------------------------------------------------

    public void testUnterminatedElementNoRegistryThrows() {
        try {
            new ExtendedMessageFormat("Hello {0");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    public void testUnterminatedElementWithRegistryThrows() {
        try {
            new ExtendedMessageFormat("Hello {0", registry);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    public void testNonNumericArgumentIndexWithRegistryThrows() {
        try {
            new ExtendedMessageFormat("{abc}", registry);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    public void testUnterminatedFormatDescriptionWithRegistryThrows() {
        try {
            new ExtendedMessageFormat("{0,foo", registry);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    public void testUnknownBuiltInFormatTypeThrows() {
        try {
            new ExtendedMessageFormat("{0,bogus}");
            fail("Expected IllegalArgumentException without registry");
        } catch (IllegalArgumentException expected) {
            // expected
        }
        try {
            new ExtendedMessageFormat("{0,bogus}", registry);
            fail("Expected IllegalArgumentException with registry");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    public void testWhitespaceHandlingAroundFormatName() {
        // Leading whitespace inside the element (around the index and before
        // the format name) is tolerated.
        ExtendedMessageFormat ok =
                new ExtendedMessageFormat("<{ 0 ,upper}>", registry);
        assertEquals("<HI>", ok.format(new Object[] { "hi" }));
        assertEquals("<{0,upper}>", ok.toPattern());

        // A trailing space after the format name is not trimmed, so it no
        // longer matches the registry and MessageFormat rejects it.
        try {
            new ExtendedMessageFormat("<{0,upper }>", registry);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    public void testNullPatternThrowsNullPointerException() {
        try {
            new ExtendedMessageFormat((String) null);
            fail("Expected NullPointerException without registry");
        } catch (NullPointerException expected) {
            // expected
        }
        try {
            new ExtendedMessageFormat(null, registry);
            fail("Expected NullPointerException with registry");
        } catch (NullPointerException expected) {
            // expected
        }
    }

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------

    private void assertMatchesMessageFormat(String pattern, Locale locale, Object[] args) {
        MessageFormat reference = new MessageFormat(pattern, locale);
        ExtendedMessageFormat emf = new ExtendedMessageFormat(pattern, locale);
        assertEquals("toPattern() mismatch for [" + pattern + "]",
                reference.toPattern(), emf.toPattern());
        assertEquals("format() mismatch for [" + pattern + "]",
                reference.format(args), emf.format(args));
    }

    // ------------------------------------------------------------------
    // Test fixtures
    // ------------------------------------------------------------------

    private static class UpperCaseFormat extends Format {
        public StringBuffer format(Object obj, StringBuffer toAppendTo, FieldPosition pos) {
            return toAppendTo.append(String.valueOf(obj).toUpperCase(Locale.ENGLISH));
        }
        public Object parseObject(String source, ParsePosition pos) {
            throw new UnsupportedOperationException();
        }
    }

    private static class LowerCaseFormat extends Format {
        public StringBuffer format(Object obj, StringBuffer toAppendTo, FieldPosition pos) {
            return toAppendTo.append(String.valueOf(obj).toLowerCase(Locale.ENGLISH));
        }
        public Object parseObject(String source, ParsePosition pos) {
            throw new UnsupportedOperationException();
        }
    }

    private static class UpperCaseFormatFactory implements FormatFactory {
        public Format getFormat(String name, String arguments, Locale locale) {
            return new UpperCaseFormat();
        }
    }

    private static class LowerCaseFormatFactory implements FormatFactory {
        public Format getFormat(String name, String arguments, Locale locale) {
            return new LowerCaseFormat();
        }
    }

    private static class RecordingFormatFactory implements FormatFactory {
        private String name;
        private String arguments;
        private Locale locale;
        private int calls;

        public Format getFormat(String name, String arguments, Locale locale) {
            this.name = name;
            this.arguments = arguments;
            this.locale = locale;
            this.calls++;
            return new UpperCaseFormat();
        }
    }
}
