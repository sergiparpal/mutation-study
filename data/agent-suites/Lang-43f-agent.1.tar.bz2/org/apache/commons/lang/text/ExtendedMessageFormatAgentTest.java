/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang.text;

import java.text.FieldPosition;
import java.text.Format;
import java.text.MessageFormat;
import java.text.NumberFormat;
import java.text.ParsePosition;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

/**
 * Unit tests for {@link org.apache.commons.lang.text.ExtendedMessageFormat}.
 */
public class ExtendedMessageFormatAgentTest extends TestCase {

    public static void main(String[] args) {
        TestRunner.run(suite());
    }

    public static Test suite() {
        TestSuite suite = new TestSuite(ExtendedMessageFormatAgentTest.class);
        suite.setName("ExtendedMessageFormatAgentTest Tests");
        return suite;
    }

    public ExtendedMessageFormatAgentTest(String name) {
        super(name);
    }

    // -----------------------------------------------------------------------
    // Test fixtures
    // -----------------------------------------------------------------------

    /**
     * Trivial <code>Format</code> which lower-cases whatever it is handed.
     */
    private static class LowerCaseFormat extends Format {
        private static final long serialVersionUID = 1L;

        public StringBuffer format(Object obj, StringBuffer toAppendTo, FieldPosition pos) {
            return toAppendTo.append(String.valueOf(obj).toLowerCase());
        }

        public Object parseObject(String source, ParsePosition pos) {
            throw new UnsupportedOperationException();
        }
    }

    /**
     * <code>FormatFactory</code> which always hands back the <code>Format</code> it was
     * constructed with (possibly <code>null</code>) and records the arguments it was
     * called with.
     */
    private static class RecordingFactory implements FormatFactory {
        private final Format result;
        private String name;
        private String arguments;
        private Locale locale;
        private int calls;

        RecordingFactory(Format result) {
            this.result = result;
        }

        public Format getFormat(String name, String arguments, Locale locale) {
            this.name = name;
            this.arguments = arguments;
            this.locale = locale;
            this.calls++;
            return result;
        }
    }

    private LowerCaseFormat lowerCaseFormat;
    private RecordingFactory lowerCaseFactory;
    private Map registry;

    public void setUp() {
        lowerCaseFormat = new LowerCaseFormat();
        lowerCaseFactory = new RecordingFactory(lowerCaseFormat);
        registry = new HashMap();
        registry.put("lower", lowerCaseFactory);
    }

    /**
     * Assert that the given pattern is rejected by the given registry.
     */
    private void assertBadPattern(String pattern, Map reg) {
        try {
            ExtendedMessageFormat emf = new ExtendedMessageFormat(pattern, Locale.US, reg);
            fail("Expected IllegalArgumentException for pattern [" + pattern
                    + "] but got [" + emf.toPattern() + "]");
        } catch (IllegalArgumentException e) {
            assertNotNull("exception message for [" + pattern + "]", e.getMessage());
        }
    }

    // -----------------------------------------------------------------------
    // Constructors / locale
    // -----------------------------------------------------------------------

    public void testPatternOnlyConstructorUsesDefaultLocale() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Hi {0}!");
        assertEquals(Locale.getDefault(), emf.getLocale());
        assertEquals("Hi {0}!", emf.toPattern());
        assertEquals("Hi world!", emf.format(new Object[] { "world" }));
    }

    public void testPatternAndRegistryConstructorUsesDefaultLocale() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,lower}", registry);
        assertEquals(Locale.getDefault(), emf.getLocale());
        assertEquals(Locale.getDefault(), lowerCaseFactory.locale);
        assertEquals("{0,lower}", emf.toPattern());
        assertEquals("abc", emf.format(new Object[] { "ABC" }));
    }

    public void testLocaleIsHonouredByBuiltInFormats() {
        Object[] args = new Object[] { new Double(3.5) };
        ExtendedMessageFormat us = new ExtendedMessageFormat("{0,number,#.##}", Locale.US);
        ExtendedMessageFormat de = new ExtendedMessageFormat("{0,number,#.##}", Locale.GERMANY);
        assertEquals(Locale.US, us.getLocale());
        assertEquals(Locale.GERMANY, de.getLocale());
        assertEquals("3.5", us.format(args));
        assertEquals("3,5", de.format(args));
    }

    public void testNullPatternThrowsNullPointerException() {
        try {
            new ExtendedMessageFormat(null, Locale.US, registry);
            fail("Expected NullPointerException with registry");
        } catch (NullPointerException e) {
            // expected: the pattern is dereferenced while being parsed
        }
        try {
            new ExtendedMessageFormat(null, Locale.US, null);
            fail("Expected NullPointerException without registry");
        } catch (NullPointerException e) {
            // expected
        }
    }

    // -----------------------------------------------------------------------
    // Behaviour without a registry: plain MessageFormat
    // -----------------------------------------------------------------------

    public void testNoRegistryBehavesLikeMessageFormat() {
        String[] patterns = new String[] {
                "",
                "no format elements at all",
                "{0}",
                "{0}{1}{0}",
                "{0,number,#.##}",
                "{0,choice,0#zero|1#one}",
                "it''s a {0} 'test'!",
                "'{0}'" };
        Object[] args = new Object[] { new Integer(1), "two" };
        for (int i = 0; i < patterns.length; i++) {
            ExtendedMessageFormat emf = new ExtendedMessageFormat(patterns[i], Locale.US);
            MessageFormat mf = new MessageFormat(patterns[i], Locale.US);
            assertEquals("toPattern() of [" + patterns[i] + "]", mf.toPattern(), emf.toPattern());
            assertEquals("format() of [" + patterns[i] + "]", mf.format(args), emf.format(args));
            assertEquals("format count of [" + patterns[i] + "]",
                    mf.getFormats().length, emf.getFormats().length);
        }
    }

    public void testNoRegistryLeavesQuotedBracesAlone() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("'{0}'", Locale.US);
        assertEquals("'{'0}", emf.toPattern());
        assertEquals("{0}", emf.format(new Object[] { "ignored" }));
        assertEquals(0, emf.getFormats().length);
    }

    // -----------------------------------------------------------------------
    // Custom formats
    // -----------------------------------------------------------------------

    public void testCustomFormatIsInstalledAndUsed() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,lower}", Locale.US, registry);
        assertEquals("{0,lower}", emf.toPattern());
        assertEquals(1, emf.getFormats().length);
        assertSame(lowerCaseFormat, emf.getFormats()[0]);
        assertEquals("hello", emf.format(new Object[] { "HeLLo" }));
        assertEquals(1, lowerCaseFactory.calls);
    }

    public void testFactoryReceivesNameArgumentsAndLocale() {
        ExtendedMessageFormat emf =
                new ExtendedMessageFormat("{0, lower , ARG S }", Locale.GERMANY, registry);
        assertEquals(1, lowerCaseFactory.calls);
        assertEquals("lower", lowerCaseFactory.name);
        assertEquals("ARG S", lowerCaseFactory.arguments);
        assertEquals(Locale.GERMANY, lowerCaseFactory.locale);
        // the original (untrimmed) description is restored by toPattern()
        assertEquals("{0,lower , ARG S }", emf.toPattern());
        assertEquals("xyz", emf.format(new Object[] { "XYZ" }));
    }

    public void testFactoryReceivesNullArgumentsWhenNoFormatStyle() {
        new ExtendedMessageFormat("{0,lower}", Locale.US, registry);
        assertEquals(1, lowerCaseFactory.calls);
        assertEquals("lower", lowerCaseFactory.name);
        assertNull(lowerCaseFactory.arguments);
    }

    public void testCustomFormatOverridesBuiltInFormat() {
        Map reg = new HashMap();
        reg.put("number", lowerCaseFactory);
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number}", Locale.US, reg);
        assertEquals("{0,number}", emf.toPattern());
        assertSame(lowerCaseFormat, emf.getFormats()[0]);
        // a plain MessageFormat would reject a String argument here
        assertEquals("abc", emf.format(new Object[] { "ABC" }));
    }

    public void testFactoryReturningNullFallsBackToBuiltInFormat() {
        RecordingFactory nullFactory = new RecordingFactory(null);
        Map reg = new HashMap();
        reg.put("number", nullFactory);
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number,#}", Locale.US, reg);
        assertEquals(1, nullFactory.calls);
        assertEquals("number", nullFactory.name);
        assertEquals("#", nullFactory.arguments);
        assertEquals("{0,number,#}", emf.toPattern());
        assertEquals("12", emf.format(new Object[] { new Integer(12) }));
    }

    public void testUnregisteredFormatNamesAreLeftToMessageFormat() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number,#}", Locale.US, registry);
        assertEquals(0, lowerCaseFactory.calls);
        assertEquals("{0,number,#}", emf.toPattern());
        assertEquals("42", emf.format(new Object[] { new Integer(42) }));
        assertTrue("MessageFormat should own the format",
                emf.getFormats()[0] instanceof NumberFormat);
    }

    public void testUnknownFormatNameIsRejectedByMessageFormat() {
        assertBadPattern("{0,bogus}", registry);
        assertBadPattern("{0,bogus,style}", registry);
    }

    public void testMixedCustomAndBuiltInFormats() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat(
                "{0,lower} {1,number,#} {2,lower}", Locale.US, registry);
        assertEquals("{0,lower} {1,number,#} {2,lower}", emf.toPattern());
        assertEquals(2, lowerCaseFactory.calls);
        Format[] formats = emf.getFormats();
        assertEquals(3, formats.length);
        assertSame(lowerCaseFormat, formats[0]);
        assertNotNull(formats[1]);
        assertSame(lowerCaseFormat, formats[2]);
        assertEquals("aa 7 bb", emf.format(new Object[] { "AA", new Integer(7), "Bb" }));
    }

    public void testEmptyRegistryLeavesPatternUntouched() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", Locale.US, new HashMap());
        assertEquals("{0}", emf.toPattern());
        assertEquals(1, emf.getFormats().length);
        assertNull(emf.getFormats()[0]);
        assertEquals("Vv", emf.format(new Object[] { "Vv" }));
    }

    public void testRepeatedAndOutOfOrderArgumentIndexes() {
        ExtendedMessageFormat repeated =
                new ExtendedMessageFormat("{0,lower} {0}", Locale.US, registry);
        assertEquals("{0,lower} {0}", repeated.toPattern());
        assertEquals(2, repeated.getFormats().length);
        assertSame(lowerCaseFormat, repeated.getFormats()[0]);
        assertNull(repeated.getFormats()[1]);
        assertEquals("hello Hello", repeated.format(new Object[] { "Hello" }));

        ExtendedMessageFormat reversed =
                new ExtendedMessageFormat("{1,lower}{0}", Locale.US, registry);
        assertEquals("{1,lower}{0}", reversed.toPattern());
        assertEquals("bbA", reversed.format(new Object[] { "A", "Bb" }));

        ExtendedMessageFormat sparse =
                new ExtendedMessageFormat("{2,lower}", Locale.US, registry);
        assertEquals("{2,lower}", sparse.toPattern());
        assertEquals(1, sparse.getFormats().length);
        assertEquals("cde", sparse.format(new Object[] { "a", "b", "CdE" }));
    }

    public void testChoiceFormatIsHandledByMessageFormat() {
        ExtendedMessageFormat emf =
                new ExtendedMessageFormat("{0,choice,0#zero|1#one}", Locale.US, registry);
        assertEquals("{0,choice,0.0#zero|1.0#one}", emf.toPattern());
        assertEquals("zero", emf.format(new Object[] { new Integer(0) }));
        assertEquals("one", emf.format(new Object[] { new Integer(1) }));
    }

    public void testNestedBracesInCustomFormatDescription() {
        ExtendedMessageFormat emf =
                new ExtendedMessageFormat("{0,lower,{}}", Locale.US, registry);
        assertEquals("lower", lowerCaseFactory.name);
        assertEquals("{}", lowerCaseFactory.arguments);
        assertEquals("{0,lower,{}}", emf.toPattern());
        assertEquals("hi", emf.format(new Object[] { "HI" }));
    }

    // -----------------------------------------------------------------------
    // Whitespace handling
    // -----------------------------------------------------------------------

    public void testWhitespaceAroundArgumentIndexIsIgnored() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{ 0 }", Locale.US, registry);
        assertEquals("{0}", emf.toPattern());
        assertEquals("Aa", emf.format(new Object[] { "Aa" }));

        ExtendedMessageFormat custom =
                new ExtendedMessageFormat("{ 0 , lower}", Locale.US, registry);
        assertEquals("lower", lowerCaseFactory.name);
        assertEquals("{0,lower}", custom.toPattern());
        assertEquals("aa", custom.format(new Object[] { "Aa" }));
    }

    public void testFormatNameWithTrailingWhitespaceIsNotMatched() {
        // the format name is only left-trimmed when there is no format style,
        // so "lower " does not resolve and MessageFormat rejects it
        assertBadPattern("{ 0 , lower }", registry);
        assertEquals(0, lowerCaseFactory.calls);
    }

    // -----------------------------------------------------------------------
    // Quoting (LANG-477)
    // -----------------------------------------------------------------------

    public void testEscapedQuotesWithCustomFormat() {
        ExtendedMessageFormat emf =
                new ExtendedMessageFormat("it''s a {0,lower} 'test'!", Locale.US, registry);
        assertEquals("it''s a {0,lower} test!", emf.toPattern());
        assertEquals("it's a hello test!", emf.format(new Object[] { "HELLO" }));
    }

    public void testEscapedQuotesSurroundingCustomFormat() {
        ExtendedMessageFormat emf =
                new ExtendedMessageFormat("''{0,lower}''", Locale.US, registry);
        assertEquals("''{0,lower}''", emf.toPattern());
        assertEquals("'q'", emf.format(new Object[] { "Q" }));
    }

    public void testEscapedQuotesMatchMessageFormatWhenNoCustomFormat() {
        String pattern = "it''s a {0} 'test'!";
        ExtendedMessageFormat emf = new ExtendedMessageFormat(pattern, Locale.US, registry);
        MessageFormat mf = new MessageFormat(pattern, Locale.US);
        assertEquals(mf.toPattern(), emf.toPattern());
        assertEquals(mf.format(new Object[] { "X" }), emf.format(new Object[] { "X" }));
    }

    public void testToPatternRoundTrip() {
        String[] patterns = new String[] {
                "{0,lower}",
                "prefix {0,lower} suffix",
                "{0,lower,ARGS}",
                "it''s a {0,lower} test!",
                "{0,lower} {1,number,#} {2,lower}" };
        for (int i = 0; i < patterns.length; i++) {
            ExtendedMessageFormat first =
                    new ExtendedMessageFormat(patterns[i], Locale.US, registry);
            assertEquals(patterns[i], first.toPattern());
            ExtendedMessageFormat second =
                    new ExtendedMessageFormat(first.toPattern(), Locale.US, registry);
            assertEquals("round trip of [" + patterns[i] + "]",
                    first.toPattern(), second.toPattern());
        }
    }

    // -----------------------------------------------------------------------
    // Degenerate patterns
    // -----------------------------------------------------------------------

    public void testEmptyPattern() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("", Locale.US, registry);
        assertEquals("", emf.toPattern());
        assertEquals(0, emf.getFormats().length);
        assertEquals("", emf.format(new Object[] { "unused" }));
    }

    public void testPatternWithoutFormatElements() {
        ExtendedMessageFormat emf =
                new ExtendedMessageFormat("no elements here", Locale.US, registry);
        assertEquals("no elements here", emf.toPattern());
        assertEquals(0, emf.getFormats().length);
        assertEquals(0, lowerCaseFactory.calls);
        assertEquals("no elements here", emf.format(new Object[0]));
    }

    // -----------------------------------------------------------------------
    // Invalid patterns
    // -----------------------------------------------------------------------

    public void testUnterminatedFormatElement() {
        assertBadPattern("{0", registry);
        assertBadPattern("{0,lower", registry);
        assertBadPattern("{0,lower,args", registry);
        assertBadPattern("text {1", registry);
    }

    public void testInvalidArgumentIndex() {
        assertBadPattern("{a}", registry);
        assertBadPattern("{-1}", registry);
        assertBadPattern("{1a}", registry);
        assertBadPattern("{1a,lower}", registry);
        assertBadPattern("{}", registry);
    }

    public void testUnterminatedFormatElementReportsPosition() {
        try {
            new ExtendedMessageFormat("hello {0,lower", Locale.US, registry);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue("message was: " + e.getMessage(),
                    e.getMessage().indexOf("Unterminated format element") >= 0);
        }
    }

    public void testInvalidArgumentIndexReportsPosition() {
        try {
            new ExtendedMessageFormat("hello {oops}", Locale.US, registry);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue("message was: " + e.getMessage(),
                    e.getMessage().indexOf("Invalid format argument index") >= 0);
        }
    }

    // -----------------------------------------------------------------------
    // applyPattern
    // -----------------------------------------------------------------------

    public void testApplyPatternReplacesPreviousState() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,lower}", Locale.US, registry);
        assertEquals("zz", emf.format(new Object[] { "Zz" }));

        emf.applyPattern("A{0}B");
        assertEquals("A{0}B", emf.toPattern());
        assertEquals(1, emf.getFormats().length);
        assertNull("custom format should be gone", emf.getFormats()[0]);
        assertEquals("AZzB", emf.format(new Object[] { "Zz" }));

        emf.applyPattern("{0,lower}!");
        assertEquals("{0,lower}!", emf.toPattern());
        assertSame(lowerCaseFormat, emf.getFormats()[0]);
        assertEquals("zz!", emf.format(new Object[] { "Zz" }));
    }

    public void testApplyPatternLeavesInstanceUsableAfterBadPattern() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,lower}", Locale.US, registry);
        try {
            emf.applyPattern("{0,lower");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
        // the previous pattern is still reported and still usable
        assertEquals("{0,lower}", emf.toPattern());
        assertEquals("zz", emf.format(new Object[] { "Zz" }));
    }

    // -----------------------------------------------------------------------
    // Disabled mutators
    // -----------------------------------------------------------------------

    public void testSetFormatIsUnsupported() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,lower}", Locale.US, registry);
        try {
            emf.setFormat(0, new MessageFormat("{0}"));
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException e) {
            // expected
        }
        assertSame(lowerCaseFormat, emf.getFormats()[0]);
        assertEquals("kk", emf.format(new Object[] { "Kk" }));
    }

    public void testSetFormatByArgumentIndexIsUnsupported() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,lower}", Locale.US, registry);
        try {
            emf.setFormatByArgumentIndex(0, new MessageFormat("{0}"));
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException e) {
            // expected
        }
        assertSame(lowerCaseFormat, emf.getFormats()[0]);
        assertEquals("kk", emf.format(new Object[] { "Kk" }));
    }

    public void testSetFormatsIsUnsupported() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,lower}", Locale.US, registry);
        try {
            emf.setFormats(new Format[] { new MessageFormat("{0}") });
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException e) {
            // expected
        }
        assertSame(lowerCaseFormat, emf.getFormats()[0]);
        assertEquals("kk", emf.format(new Object[] { "Kk" }));
    }

    public void testSetFormatsByArgumentIndexIsUnsupported() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,lower}", Locale.US, registry);
        try {
            emf.setFormatsByArgumentIndex(new Format[] { new MessageFormat("{0}") });
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException e) {
            // expected
        }
        assertSame(lowerCaseFormat, emf.getFormats()[0]);
        assertEquals("kk", emf.format(new Object[] { "Kk" }));
    }

    public void testMutatorsRejectNullArgumentsToo() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,lower}", Locale.US, registry);
        try {
            emf.setFormat(-1, null);
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException e) {
            // expected
        }
        try {
            emf.setFormats(null);
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException e) {
            // expected
        }
    }

    // -----------------------------------------------------------------------
    // Inherited accessors
    // -----------------------------------------------------------------------

    public void testGetFormatsReturnsCopy() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,lower}", Locale.US, registry);
        Format[] formats = emf.getFormats();
        formats[0] = null;
        assertSame("internal state must not be affected", lowerCaseFormat, emf.getFormats()[0]);
        assertEquals("mm", emf.format(new Object[] { "Mm" }));
    }

    public void testEqualsAndHashCode() {
        ExtendedMessageFormat one = new ExtendedMessageFormat("{0} {1,number,#}", Locale.US);
        ExtendedMessageFormat two = new ExtendedMessageFormat("{0} {1,number,#}", Locale.US);
        ExtendedMessageFormat other = new ExtendedMessageFormat("{0}", Locale.US);

        assertEquals(one, one);
        assertEquals(one, two);
        assertEquals(two, one);
        assertEquals(one.hashCode(), two.hashCode());
        assertFalse(one.equals(other));
        assertFalse(one.equals(null));
        // a plain MessageFormat with the same pattern is a different type
        assertFalse(one.equals(new MessageFormat("{0} {1,number,#}", Locale.US)));
    }
}
