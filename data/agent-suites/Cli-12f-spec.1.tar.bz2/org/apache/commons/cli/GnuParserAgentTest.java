package org.apache.commons.cli;

import junit.framework.TestCase;

/**
 * Tests for GnuParser, based on the documented contract of:
 *  - GnuParser#flatten(Options, String[], boolean), the only member GnuParser
 *    itself declares (protected, so directly reachable from this same-package
 *    test without needing a subclass), and
 *  - the CommandLineParser contract (parse(Options, String[])) that GnuParser
 *    fulfils via its inherited Parser#parse, exercised here to observe the
 *    end-to-end effect of the documented flatten rules.
 *
 * flatten's documented rule, verbatim from the javadoc:
 *  1. If an Option exists for the first character of the arguments entry AND
 *     an Option does not exist for the whole argument, then add the first
 *     character as an option to the processed tokens list (e.g. "-D") and
 *     add the rest of the entry also (as a separate token).
 *  2. Otherwise just add the token to the processed tokens list.
 */
public class GnuParserAgentTest extends TestCase {

    private GnuParser parser;

    protected void setUp() throws Exception {
        parser = new GnuParser();
    }

    // -- helpers ---------------------------------------------------------

    private static Options optionsWith(String opt, boolean hasArg) {
        Options options = new Options();
        options.addOption(opt, hasArg, "desc for " + opt);
        return options;
    }

    private static Options emptyOptions() {
        return new Options();
    }

    // -- flatten: boundary cases ------------------------------------------

    public void testFlattenEmptyArgumentsReturnsEmptyArray() {
        String[] result = parser.flatten(emptyOptions(), new String[0], false);
        assertNotNull(result);
        assertEquals(0, result.length);
    }

    public void testFlattenEmptyArgumentsWithStopAtNonOptionTrue() {
        String[] result = parser.flatten(emptyOptions(), new String[0], true);
        assertNotNull(result);
        assertEquals(0, result.length);
    }

    // -- flatten: rule 2 (no transformation) ------------------------------

    public void testFlattenPlainNonOptionArgumentIsUnchanged() {
        Options options = emptyOptions();
        String[] result = parser.flatten(options, new String[] { "value" }, false);
        assertEquals(1, result.length);
        assertEquals("value", result[0]);
    }

    public void testFlattenWholeArgumentMatchingOptionIsUnchanged() {
        // "a" is registered exactly, so the whole-argument match takes the
        // "otherwise" branch: the token is passed through unmodified.
        Options options = optionsWith("a", false);
        String[] result = parser.flatten(options, new String[] { "-a" }, false);
        assertEquals(1, result.length);
        assertEquals("-a", result[0]);
    }

    public void testFlattenUnknownOptionLikeArgumentIsUnchanged() {
        // Neither the first character nor the whole argument correspond to
        // any registered option, so rule 1's condition is false and the
        // token is passed through as-is under rule 2.
        Options options = optionsWith("x", false);
        String[] result = parser.flatten(options, new String[] { "-z" }, false);
        assertEquals(1, result.length);
        assertEquals("-z", result[0]);
    }

    // -- flatten: rule 1 (split first character from the rest) -----------

    public void testFlattenSplitsBundledShortOption() {
        // "a" is registered but "ab" (the whole argument) is not, so the
        // first character is peeled off as its own option token and the
        // remainder is appended as a second token.
        Options options = optionsWith("a", false);
        String[] result = parser.flatten(options, new String[] { "-ab" }, false);
        assertEquals(2, result.length);
        assertEquals("-a", result[0]);
        assertEquals("b", result[1]);
    }

    public void testFlattenSplitsGnuStyleAttachedValue() {
        // Classic GNU-style example straight from the javadoc: "-Dfoo=bar"
        // is tokenised as "-D" followed by "foo=bar".
        Options options = optionsWith("D", true);
        String[] result = parser.flatten(options, new String[] { "-Dfoo=bar" }, false);
        assertEquals(2, result.length);
        assertEquals("-D", result[0]);
        assertEquals("foo=bar", result[1]);
    }

    public void testFlattenSplitDoesNotRecurseIntoRemainder() {
        // The remainder "bc" is appended as a single token, even though it
        // itself starts with a character ('b') that -- if reprocessed --
        // would not match any registered option. This confirms flatten only
        // splits once per argument, per rule 1's wording ("add the rest of
        // the entry" as a unit, not recursively re-split).
        Options options = optionsWith("a", false);
        String[] result = parser.flatten(options, new String[] { "-abc" }, false);
        assertEquals(2, result.length);
        assertEquals("-a", result[0]);
        assertEquals("bc", result[1]);
    }

    // -- flatten: multiple arguments in one call --------------------------

    public void testFlattenProcessesEachArgumentIndependently() {
        Options options = new Options();
        options.addOption("a", false, "flag a");
        options.addOption("D", true, "define");

        String[] result = parser.flatten(options,
                new String[] { "-a", "-Dfoo=bar", "plainValue" }, false);

        assertEquals(4, result.length);
        assertEquals("-a", result[0]);
        assertEquals("-D", result[1]);
        assertEquals("foo=bar", result[2]);
        assertEquals("plainValue", result[3]);
    }

    // -- flatten: stopAtNonOption --------------------------------------

    public void pruned_testFlattenStopAtNonOptionTrueHaltsFlatteningAfterNonOption() {
        Options options = new Options();
        options.addOption("a", false, "flag a");
        options.addOption("D", true, "define");

        String[] result = parser.flatten(options,
                new String[] { "-a", "plainValue", "-Dfoo=bar" }, true);

        // Once the non-option "plainValue" is encountered, flattening stops:
        // the remaining "-Dfoo=bar" must be carried through unsplit.
        assertEquals(3, result.length);
        assertEquals("-a", result[0]);
        assertEquals("plainValue", result[1]);
        assertEquals("-Dfoo=bar", result[2]);
    }

    public void testFlattenStopAtNonOptionFalseKeepsFlatteningAfterNonOption() {
        Options options = new Options();
        options.addOption("a", false, "flag a");
        options.addOption("D", true, "define");

        String[] result = parser.flatten(options,
                new String[] { "-a", "plainValue", "-Dfoo=bar" }, false);

        // Flattening is not stopped by a non-option, so "-Dfoo=bar" is still
        // split according to rule 1.
        assertEquals(4, result.length);
        assertEquals("-a", result[0]);
        assertEquals("plainValue", result[1]);
        assertEquals("-D", result[2]);
        assertEquals("foo=bar", result[3]);
    }

    // -- integration through the public CommandLineParser contract --------

    public void testParseAppliesGnuStyleAttachedValue() throws Exception {
        Options options = new Options();
        options.addOption("D", true, "define property");

        CommandLine cmd = parser.parse(options, new String[] { "-Dfoo=bar" });

        assertTrue(cmd.hasOption("D"));
        assertEquals("foo=bar", cmd.getOptionValue("D"));
    }

    public void testParseMissingRequiredOptionThrowsParseException() {
        Options options = new Options();
        Option required = new Option("r", "required option");
        required.setRequired(true);
        options.addOption(required);

        try {
            parser.parse(options, new String[0]);
            fail("Expected a ParseException because a required option was not supplied");
        } catch (ParseException expected) {
            // documented contract: parse() throws ParseException on failure
        }
    }

    public void testParseUnrecognizedOptionThrowsParseException() {
        Options options = new Options();
        options.addOption("x", false, "flag x");

        try {
            parser.parse(options, new String[] { "-z" });
            fail("Expected a ParseException for an unrecognized option");
        } catch (ParseException expected) {
            // documented contract: parse() throws ParseException on failure
        }
    }

    public void testParseWithNoArgumentsAndNoOptionsSucceeds() throws Exception {
        Options options = new Options();
        CommandLine cmd = parser.parse(options, new String[0]);
        assertNotNull(cmd);
        assertEquals(0, cmd.getArgs().length);
    }

    // -- basic instance sanity ------------------------------------------

    public void testGnuParserImplementsCommandLineParser() {
        assertTrue(parser instanceof CommandLineParser);
    }
}
