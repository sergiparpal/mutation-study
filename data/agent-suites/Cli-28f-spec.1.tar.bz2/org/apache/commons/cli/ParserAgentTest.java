package org.apache.commons.cli;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.Properties;

import junit.framework.TestCase;

/**
 * Tests for the documented contract of the deprecated abstract
 * {@link org.apache.commons.cli.Parser} class, exercised through a minimal
 * concrete subclass since Parser cannot be instantiated directly.
 */
public class ParserAgentTest extends TestCase {

    /**
     * Minimal concrete Parser: flatten() hands the raw tokens straight
     * through, unmodified, to the token processing loop in parse().
     */
    private static class StubParser extends Parser {
        protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption)
                throws ParseException {
            return arguments;
        }
    }

    private StubParser parser;
    private Options options;

    protected void setUp() throws Exception {
        super.setUp();
        parser = new StubParser();
        options = new Options();
    }

    // ---- parse(Options, String[]) ----

    public void testParseNoArgumentsReturnsEmptyCommandLine() throws Exception {
        options.addOption("a", false, "a flag");
        CommandLine cl = parser.parse(options, new String[0]);
        assertNotNull(cl);
        assertFalse(cl.hasOption("a"));
        assertEquals(0, cl.getArgs().length);
    }

    public void testParseRecognizesFlagOption() throws Exception {
        options.addOption("a", false, "a flag");
        CommandLine cl = parser.parse(options, new String[] {"-a"});
        assertTrue(cl.hasOption("a"));
    }

    public void testParseOptionWithArgumentValue() throws Exception {
        options.addOption("b", true, "b with value");
        CommandLine cl = parser.parse(options, new String[] {"-b", "value"});
        assertEquals("value", cl.getOptionValue("b"));
    }

    public void testGetOptionValueNullWhenOptionNotProvided() throws Exception {
        options.addOption("b", true, "b with value");
        CommandLine cl = parser.parse(options, new String[0]);
        assertNull(cl.getOptionValue("b"));
    }

    public void testParseUnrecognizedOptionThrowsWhenNotStoppingAtNonOption() {
        try {
            parser.parse(options, new String[] {"-z"});
            fail("Expected ParseException for an unrecognized option");
        } catch (ParseException expected) {
            // documented: an unrecognized argument triggers a ParseException
            // unless stopAtNonOption is requested
        }
    }

    public void testParseStopAtNonOptionAddsRemainingArgsWithoutThrowing() throws Exception {
        options.addOption("a", false, "a flag");
        CommandLine cl = parser.parse(options, new String[] {"-a", "-z", "leftover"}, true);
        assertTrue(cl.hasOption("a"));
        List remaining = cl.getArgList();
        assertTrue(remaining.contains("-z"));
        assertTrue(remaining.contains("leftover"));
    }

    public void testParseMissingRequiredOptionThrowsMissingOptionException() {
        Option required = new Option("r", false, "required flag");
        required.setRequired(true);
        options.addOption(required);
        try {
            parser.parse(options, new String[0]);
            fail("Expected MissingOptionException");
        } catch (MissingOptionException expected) {
            // documented contract of checkRequiredOptions()
        } catch (ParseException e) {
            fail("Expected MissingOptionException, got " + e);
        }
    }

    public void testParseRequiredOptionPresentDoesNotThrow() throws Exception {
        Option required = new Option("r", false, "required flag");
        required.setRequired(true);
        options.addOption(required);
        CommandLine cl = parser.parse(options, new String[] {"-r"});
        assertTrue(cl.hasOption("r"));
    }

    public void testCmdFieldPopulatedAfterParse() throws Exception {
        options.addOption("a", false, "a flag");
        CommandLine cl = parser.parse(options, new String[] {"-a"});
        assertSame(cl, parser.cmd);
    }

    // ---- parse(Options, String[], Properties) ----

    public void testParseWithPropertiesSuppliesDefaultForUnsetOption() throws Exception {
        options.addOption("d", true, "value option");
        Properties props = new Properties();
        props.setProperty("d", "fromProperties");
        CommandLine cl = parser.parse(options, new String[0], props);
        assertEquals("fromProperties", cl.getOptionValue("d"));
    }

    public void testParseWithPropertiesCommandLineOverridesProperty() throws Exception {
        options.addOption("d", true, "value option");
        Properties props = new Properties();
        props.setProperty("d", "fromProperties");
        CommandLine cl = parser.parse(options, new String[] {"-d", "fromCommandLine"}, props);
        assertEquals("fromCommandLine", cl.getOptionValue("d"));
    }

    // ---- parse(Options, String[], Properties, boolean) ----

    public void testParseFourArgOverloadAppliesStopAtNonOption() throws Exception {
        options.addOption("a", false, "a flag");
        Properties props = new Properties();
        CommandLine cl = parser.parse(options, new String[] {"-a", "-z"}, props, true);
        assertTrue(cl.hasOption("a"));
        assertTrue(cl.getArgList().contains("-z"));
    }

    // ---- processArgs(Option, ListIterator) ----

    public void testProcessArgsAssignsSingleValue() throws Exception {
        parser.setOptions(new Options());
        Option opt = new Option("v", true, "value option");
        List tokens = new ArrayList();
        tokens.add("theValue");
        ListIterator iter = tokens.listIterator();
        parser.processArgs(opt, iter);
        assertEquals("theValue", opt.getValue());
    }

    public void testProcessArgsThrowsWhenRequiredValueMissing() {
        parser.setOptions(new Options());
        Option opt = new Option("v", true, "value option");
        List tokens = new ArrayList();
        ListIterator iter = tokens.listIterator();
        try {
            parser.processArgs(opt, iter);
            fail("Expected a ParseException because the required argument value is missing");
        } catch (ParseException expected) {
            // documented: throws ParseException if a required argument value
            // has not been found
        }
    }

    public void testProcessArgsOptionalArgDoesNotThrowWhenMissing() throws Exception {
        parser.setOptions(new Options());
        Option opt = new Option("v", true, "value option");
        opt.setOptionalArg(true);
        List tokens = new ArrayList();
        ListIterator iter = tokens.listIterator();
        parser.processArgs(opt, iter);
        // an optional argument permits the absence of a value: no exception
    }

    // ---- getOptions()/setOptions() ----

    public void testSetOptionsThenGetOptionsReturnsSameInstance() {
        Options o = new Options();
        parser.setOptions(o);
        assertSame(o, parser.getOptions());
    }

    // ---- getRequiredOptions() ----

    public void testGetRequiredOptionsEmptyWhenNoneRequired() {
        options.addOption("a", false, "a flag");
        parser.setOptions(options);
        List requiredOptions = parser.getRequiredOptions();
        assertNotNull(requiredOptions);
        assertTrue(requiredOptions.isEmpty());
    }

    public void testGetRequiredOptionsCountsRequiredOption() {
        Option required = new Option("r", false, "required flag");
        required.setRequired(true);
        options.addOption(required);
        parser.setOptions(options);
        List requiredOptions = parser.getRequiredOptions();
        assertNotNull(requiredOptions);
        assertEquals(1, requiredOptions.size());
    }

    // ---- checkRequiredOptions() ----

    public void testCheckRequiredOptionsPassesWhenNoRequiredOptions() throws Exception {
        options.addOption("a", false, "a flag");
        parser.setOptions(options);
        parser.checkRequiredOptions();
        // no exception expected: nothing required, nothing missing
    }

    public void testCheckRequiredOptionsThrowsWhenRequiredOptionMissing() {
        Option required = new Option("r", false, "required flag");
        required.setRequired(true);
        options.addOption(required);
        parser.setOptions(options);
        try {
            parser.checkRequiredOptions();
            fail("Expected MissingOptionException");
        } catch (MissingOptionException expected) {
            // documented: thrown if any of the required Options are not present
        }
    }
}
