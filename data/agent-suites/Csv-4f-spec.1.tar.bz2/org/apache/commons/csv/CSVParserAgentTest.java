package org.apache.commons.csv;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.Writer;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import junit.framework.TestCase;

/**
 * Self-contained tests for {@link org.apache.commons.csv.CSVParser}.
 *
 * <p>Every expectation here is taken from the published javadoc contract in
 * {@code api/org/apache/commons/csv/CSVParser.html} and the package summary:
 * the default delimiter is {@code ','}, the default encapsulator (quote) is
 * {@code '"'}, an encapsulator is doubled to embed it in a quoted value, quoted
 * values may span multiple physical lines, records need not have equal numbers
 * of values, and the record separator is a line terminator.</p>
 *
 * <p>Written for the JUnit 3.8 API present in {@code lib/} (extends
 * {@link junit.framework.TestCase}; no JUnit 4 annotations).</p>
 */
public class CSVParserAgentTest extends TestCase {

    // ------------------------------------------------------------------
    // helpers (kept inside this file so the test is fully self-contained)
    // ------------------------------------------------------------------

    /** Collect the values of a record by iterating it (CSVRecord is Iterable&lt;String&gt;). */
    private static List<String> fields(final CSVRecord record) {
        final List<String> out = new ArrayList<String>();
        for (final String field : record) {
            out.add(field);
        }
        return out;
    }

    /** Write {@code content} to a fresh temp file and return it. */
    private static File writeTempCsv(final String content) throws IOException {
        final File tmp = File.createTempFile("csvparser-agent-", ".csv");
        tmp.deleteOnExit();
        final Writer w = new FileWriter(tmp);
        try {
            w.write(content);
        } finally {
            w.close();
        }
        return tmp;
    }

    // ------------------------------------------------------------------
    // constructor CSVParser(Reader, CSVFormat)
    // ------------------------------------------------------------------

    public void testConstructorRejectsNullReader() throws Exception {
        try {
            new CSVParser(null, CSVFormat.DEFAULT);
            fail("expected IllegalArgumentException for a null reader");
        } catch (final IllegalArgumentException expected) {
            // javadoc: "if either reader or format are null"
        }
    }

    public void testConstructorRejectsNullFormat() throws Exception {
        try {
            new CSVParser(new StringReader("a,b,c"), null);
            fail("expected IllegalArgumentException for a null format");
        } catch (final IllegalArgumentException expected) {
            // javadoc: "if either reader or format are null"
        }
    }

    public void testConstructorInitialState() throws Exception {
        final CSVParser parser = new CSVParser(new StringReader("a,b\nc,d\n"), CSVFormat.DEFAULT);
        try {
            assertFalse("a fresh parser must not be closed", parser.isClosed());
            assertEquals("no record consumed yet", 0L, parser.getRecordNumber());
            assertEquals("nothing read yet", 0L, parser.getCurrentLineNumber());
        } finally {
            parser.close();
        }
        assertTrue("parser is closed after close()", parser.isClosed());
    }

    // ------------------------------------------------------------------
    // static parse(String, CSVFormat)
    // ------------------------------------------------------------------

    public void testParseStringHappyPath() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b,c", CSVFormat.DEFAULT);
        try {
            assertNotNull("parse must return a parser", parser);
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals(Arrays.asList("a", "b", "c"), fields(records.get(0)));
        } finally {
            parser.close();
        }
    }

    public void testParseStringMultipleRecords() throws Exception {
        final CSVParser parser = CSVParser.parse("a,b\nc,d", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals(Arrays.asList("a", "b"), fields(records.get(0)));
            assertEquals(Arrays.asList("c", "d"), fields(records.get(1)));
        } finally {
            parser.close();
        }
    }

    public void testParseStringRejectsNullString() throws Exception {
        try {
            CSVParser.parse((String) null, CSVFormat.DEFAULT);
            fail("expected IllegalArgumentException for a null string");
        } catch (final IllegalArgumentException expected) {
            // javadoc: "if either string or format are null"
        }
    }

    public void testParseStringRejectsNullFormat() throws Exception {
        try {
            CSVParser.parse("a,b,c", (CSVFormat) null);
            fail("expected IllegalArgumentException for a null format");
        } catch (final IllegalArgumentException expected) {
            // javadoc: "if either string or format are null"
        }
    }

    // ------------------------------------------------------------------
    // static parse(File, CSVFormat)
    // ------------------------------------------------------------------

    public void testParseFileHappyPath() throws Exception {
        final File file = writeTempCsv("a,b,c\nd,e,f\n");
        final CSVParser parser = CSVParser.parse(file, CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals(Arrays.asList("a", "b", "c"), fields(records.get(0)));
            assertEquals(Arrays.asList("d", "e", "f"), fields(records.get(1)));
        } finally {
            parser.close();
        }
    }

    public void testParseFileRejectsNullFile() throws Exception {
        try {
            CSVParser.parse((File) null, CSVFormat.DEFAULT);
            fail("expected IllegalArgumentException for a null file");
        } catch (final IllegalArgumentException expected) {
            // javadoc: "if either file or format are null"
        }
    }

    public void testParseFileRejectsNullFormat() throws Exception {
        final File file = writeTempCsv("a,b\n");
        try {
            CSVParser.parse(file, (CSVFormat) null);
            fail("expected IllegalArgumentException for a null format");
        } catch (final IllegalArgumentException expected) {
            // javadoc: "if either file or format are null"
        }
    }

    public void testParseFileThrowsIOExceptionForMissingFile() throws Exception {
        final File missing = File.createTempFile("csvparser-agent-missing-", ".csv");
        assertTrue("temp file should be removable", missing.delete());
        try {
            CSVParser.parse(missing, CSVFormat.DEFAULT);
            fail("expected IOException for a non-existent file");
        } catch (final IOException expected) {
            // javadoc: "IOException - If an I/O error occurs"
        }
    }

    // ------------------------------------------------------------------
    // static parse(URL, Charset, CSVFormat)
    // ------------------------------------------------------------------

    public void testParseUrlHappyPath() throws Exception {
        final URL url = writeTempCsv("x,y\n1,2\n").toURI().toURL();
        final CSVParser parser = CSVParser.parse(url, Charset.forName("UTF-8"), CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals(Arrays.asList("x", "y"), fields(records.get(0)));
            assertEquals(Arrays.asList("1", "2"), fields(records.get(1)));
        } finally {
            parser.close();
        }
    }

    public void testParseUrlRejectsNullUrl() throws Exception {
        try {
            CSVParser.parse((URL) null, Charset.forName("UTF-8"), CSVFormat.DEFAULT);
            fail("expected IllegalArgumentException for a null url");
        } catch (final IllegalArgumentException expected) {
            // javadoc: "if either url, charset or format are null"
        }
    }

    public void testParseUrlRejectsNullCharset() throws Exception {
        final URL url = writeTempCsv("a,b\n").toURI().toURL();
        try {
            CSVParser.parse(url, (Charset) null, CSVFormat.DEFAULT);
            fail("expected IllegalArgumentException for a null charset");
        } catch (final IllegalArgumentException expected) {
            // javadoc: "if either url, charset or format are null"
        }
    }

    public void testParseUrlRejectsNullFormat() throws Exception {
        final URL url = writeTempCsv("a,b\n").toURI().toURL();
        try {
            CSVParser.parse(url, Charset.forName("UTF-8"), (CSVFormat) null);
            fail("expected IllegalArgumentException for a null format");
        } catch (final IllegalArgumentException expected) {
            // javadoc: "if either url, charset or format are null"
        }
    }

    // ------------------------------------------------------------------
    // getRecords()
    // ------------------------------------------------------------------

    public void testGetRecordsBasic() throws Exception {
        final CSVParser parser = new CSVParser(new StringReader("a,b,c\n"), CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertNotNull("getRecords never returns null", records);
            assertEquals("a single trailing line terminator must not add an empty record",
                    1, records.size());
            assertEquals(Arrays.asList("a", "b", "c"), fields(records.get(0)));
        } finally {
            parser.close();
        }
    }

    public void testGetRecordsWithoutTrailingNewline() throws Exception {
        final CSVParser parser = new CSVParser(new StringReader("x,y,z"), CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals(Arrays.asList("x", "y", "z"), fields(records.get(0)));
        } finally {
            parser.close();
        }
    }

    public void testGetRecordsEmptyInputYieldsEmptyList() throws Exception {
        CSVParser parser = new CSVParser(new StringReader(""), CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertNotNull(records);
            assertTrue("empty input -> empty list", records.isEmpty());
        } finally {
            parser.close();
        }

        parser = new CSVParser(new StringReader(""), CSVFormat.DEFAULT);
        try {
            assertNull("nextRecord() returns null at end of stream", parser.nextRecord());
        } finally {
            parser.close();
        }

        parser = new CSVParser(new StringReader(""), CSVFormat.DEFAULT);
        try {
            assertFalse("iterator over empty input has no elements", parser.iterator().hasNext());
        } finally {
            parser.close();
        }
    }

    public void testGetRecordsStartsAtCurrentParsePosition() throws Exception {
        // javadoc: "Parsing into memory starts at the current position of the parser."
        final CSVParser parser = new CSVParser(new StringReader("a\nb\nc\n"), CSVFormat.DEFAULT);
        try {
            final CSVRecord first = parser.nextRecord();
            assertNotNull(first);
            assertEquals(Arrays.asList("a"), fields(first));
            assertEquals(1L, parser.getRecordNumber());

            final List<CSVRecord> rest = parser.getRecords();
            assertEquals("already-consumed record must not reappear", 2, rest.size());
            assertEquals(Arrays.asList("b"), fields(rest.get(0)));
            assertEquals(Arrays.asList("c"), fields(rest.get(1)));
        } finally {
            parser.close();
        }
    }

    public void testGetRecordsSecondCallReturnsEmptyList() throws Exception {
        final CSVParser parser = new CSVParser(new StringReader("a\nb\n"), CSVFormat.DEFAULT);
        try {
            assertEquals(2, parser.getRecords().size());
            assertEquals("stream already exhausted -> empty list", 0, parser.getRecords().size());
        } finally {
            parser.close();
        }
    }

    public void testRecordsMayHaveDifferentFieldCounts() throws Exception {
        // package summary: "not all records must have an equal number of values"
        final CSVParser parser = new CSVParser(new StringReader("a,b,c\nd,e\n"), CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals(3, fields(records.get(0)).size());
            assertEquals(2, fields(records.get(1)).size());
            assertEquals(Arrays.asList("d", "e"), fields(records.get(1)));
        } finally {
            parser.close();
        }
    }

    // ------------------------------------------------------------------
    // nextRecord()  (package-private; reachable because this test lives in
    // the org.apache.commons.csv package, and it is part of the api/ spec)
    // ------------------------------------------------------------------

    public void testNextRecordReturnsRecordsThenNull() throws Exception {
        final CSVParser parser = new CSVParser(new StringReader("1,2\n3,4\n"), CSVFormat.DEFAULT);
        try {
            final CSVRecord r1 = parser.nextRecord();
            assertNotNull(r1);
            assertEquals(Arrays.asList("1", "2"), fields(r1));

            final CSVRecord r2 = parser.nextRecord();
            assertNotNull(r2);
            assertEquals(Arrays.asList("3", "4"), fields(r2));

            assertNull("null once the end of the stream has been reached", parser.nextRecord());
            assertNull("still null on repeated calls past the end", parser.nextRecord());
        } finally {
            parser.close();
        }
    }

    // ------------------------------------------------------------------
    // iterator() / Iterable
    // ------------------------------------------------------------------

    public void testIteratorIteratesEveryRecord() throws Exception {
        final CSVParser parser = new CSVParser(new StringReader("a,b\nc,d\n"), CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            assertTrue(it.hasNext());
            assertEquals(Arrays.asList("a", "b"), fields(it.next()));
            assertTrue(it.hasNext());
            assertEquals(Arrays.asList("c", "d"), fields(it.next()));
            assertFalse("exhausted iterator reports no more elements", it.hasNext());
            try {
                it.next();
                fail("expected NoSuchElementException past the end of iteration");
            } catch (final NoSuchElementException expected) {
                // standard Iterator contract
            }
        } finally {
            parser.close();
        }
    }

    public void testForEachLoopVisitsAllRecords() throws Exception {
        final CSVParser parser = new CSVParser(
                new StringReader("1,2,3\n4,5,6\n7,8,9\n"), CSVFormat.DEFAULT);
        try {
            final List<List<String>> all = new ArrayList<List<String>>();
            for (final CSVRecord record : parser) {
                all.add(fields(record));
            }
            assertEquals(3, all.size());
            assertEquals(Arrays.asList("1", "2", "3"), all.get(0));
            assertEquals(Arrays.asList("4", "5", "6"), all.get(1));
            assertEquals(Arrays.asList("7", "8", "9"), all.get(2));
        } finally {
            parser.close();
        }
    }

    public void testIteratorNextThrowsWhenParserClosed() throws Exception {
        // javadoc: "If the parser is closed a call to next() will throw a NoSuchElementException."
        final CSVParser parser = new CSVParser(new StringReader("a,b,c\n"), CSVFormat.DEFAULT);
        parser.close();
        assertTrue(parser.isClosed());

        final Iterator<CSVRecord> it = parser.iterator();
        assertFalse("a closed parser exposes no records", it.hasNext());
        try {
            it.next();
            fail("expected NoSuchElementException when the parser is closed");
        } catch (final NoSuchElementException expected) {
            // documented behaviour
        }
    }

    // ------------------------------------------------------------------
    // quoting / encapsulator behaviour (from the package summary)
    // ------------------------------------------------------------------

    public void testQuotedValueContainingDelimiter() throws Exception {
        final CSVParser parser = new CSVParser(new StringReader("\"a,b\",c\n"), CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals(Arrays.asList("a,b", "c"), fields(records.get(0)));
        } finally {
            parser.close();
        }
    }

    public void testQuotedValueContainingDoubledQuote() throws Exception {
        // package summary: "The encapsulator itself must be escaped or doubled ..."
        final CSVParser parser = new CSVParser(new StringReader("\"a\"\"b\",c\n"), CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals(Arrays.asList("a\"b", "c"), fields(records.get(0)));
        } finally {
            parser.close();
        }
    }

    public void testMultiLineQuotedValueKeepsOneRecordButAdvancesLineNumber() throws Exception {
        // javadoc ATTENTION notes: with multi-line values the current line number
        // does NOT correspond to the record number.
        final CSVParser parser = new CSVParser(new StringReader("\"x\ny\",z\n"), CSVFormat.DEFAULT);
        try {
            final CSVRecord record = parser.nextRecord();
            assertNotNull(record);
            assertEquals("newline inside quotes is preserved in the value",
                    Arrays.asList("x\ny", "z"), fields(record));
            assertEquals("still the first record", 1L, parser.getRecordNumber());
            assertTrue("line number advanced past the embedded newline",
                    parser.getCurrentLineNumber() >= 2L);
            assertTrue("line number is ahead of the record number",
                    parser.getCurrentLineNumber() > parser.getRecordNumber());
            assertNull(parser.nextRecord());
        } finally {
            parser.close();
        }
    }

    // ------------------------------------------------------------------
    // getCurrentLineNumber() / getRecordNumber()
    // ------------------------------------------------------------------

    public void testGetCurrentLineNumberAdvancesPerLine() throws Exception {
        final CSVParser parser = new CSVParser(
                new StringReader("a,b,c\nd,e,f\ng,h,i\n"), CSVFormat.DEFAULT);
        try {
            assertEquals(0L, parser.getCurrentLineNumber());
            assertNotNull(parser.nextRecord());
            assertEquals(1L, parser.getCurrentLineNumber());
            assertNotNull(parser.nextRecord());
            assertEquals(2L, parser.getCurrentLineNumber());
            assertNotNull(parser.nextRecord());
            assertEquals(3L, parser.getCurrentLineNumber());
            assertNull(parser.nextRecord());
        } finally {
            parser.close();
        }
    }

    public void testGetRecordNumberAdvancesPerRecord() throws Exception {
        final CSVParser parser = new CSVParser(
                new StringReader("one\ntwo\nthree\n"), CSVFormat.DEFAULT);
        try {
            assertEquals(0L, parser.getRecordNumber());
            assertNotNull(parser.nextRecord());
            assertEquals(1L, parser.getRecordNumber());
            assertNotNull(parser.nextRecord());
            assertEquals(2L, parser.getRecordNumber());
            assertNotNull(parser.nextRecord());
            assertEquals(3L, parser.getRecordNumber());
            assertNull(parser.nextRecord());
            assertEquals("record number does not move past the last record",
                    3L, parser.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    // ------------------------------------------------------------------
    // getHeaderMap()
    // ------------------------------------------------------------------

    public void testGetHeaderMapIsNullWhenNoHeaderConfigured() throws Exception {
        final CSVParser parser = new CSVParser(new StringReader("a,b,c\n"), CSVFormat.DEFAULT);
        try {
            final Map<String, Integer> headerMap = parser.getHeaderMap();
            assertNull("no header was configured, so there is no header map", headerMap);
        } finally {
            parser.close();
        }
    }

    // ------------------------------------------------------------------
    // close() / isClosed()
    // ------------------------------------------------------------------

    public void testIsClosedAndCloseIsIdempotent() throws Exception {
        final CSVParser parser = new CSVParser(new StringReader("a,b\n"), CSVFormat.DEFAULT);
        assertFalse(parser.isClosed());
        parser.close();
        assertTrue(parser.isClosed());
        parser.close(); // Closeable: closing an already-closed resource has no effect
        assertTrue(parser.isClosed());
    }

    // ------------------------------------------------------------------
    // interaction with CSVFormat factory / predefined formats referenced
    // by the CSVParser javadoc
    // ------------------------------------------------------------------

    public void testCSVFormatParseReaderShortcutProducesAWorkingParser() throws Exception {
        final Reader in = new StringReader("a,b,c\n");
        final CSVParser parser = CSVFormat.DEFAULT.parse(in);
        try {
            assertNotNull(parser);
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals(Arrays.asList("a", "b", "c"), fields(records.get(0)));
        } finally {
            parser.close();
        }
    }

    public void testExcelFormatParsesCommaSeparatedInput() throws Exception {
        final CSVParser parser = new CSVParser(
                new StringReader("a,b,c\nd,e,f\n"), CSVFormat.EXCEL);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals(Arrays.asList("a", "b", "c"), fields(records.get(0)));
            assertEquals(Arrays.asList("d", "e", "f"), fields(records.get(1)));
        } finally {
            parser.close();
        }
    }

    public void testRfc4180FormatParsesQuotedInput() throws Exception {
        final CSVParser parser = new CSVParser(
                new StringReader("\"a\",\"b,c\"\n"), CSVFormat.RFC4180);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals(Arrays.asList("a", "b,c"), fields(records.get(0)));
        } finally {
            parser.close();
        }
    }
}
