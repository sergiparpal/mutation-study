/*
 * Copyright (C) 2016 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.gson.internal;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Deque;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.NavigableSet;
import java.util.Queue;
import java.util.Set;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ConcurrentNavigableMap;
import java.util.concurrent.ConcurrentSkipListMap;

import junit.framework.TestCase;

import com.google.gson.InstanceCreator;
import com.google.gson.JsonIOException;
import com.google.gson.reflect.TypeToken;

/**
 * Tests for {@link ConstructorConstructor}. Only the public API is exercised:
 * the {@code Map}-accepting constructor, {@link ConstructorConstructor#get}, the
 * {@link ObjectConstructor} instances it returns and {@link ConstructorConstructor#toString()}.
 */
@SuppressWarnings({"rawtypes", "unchecked"})
public final class ConstructorConstructorAgentTest extends TestCase {

  private static ConstructorConstructor emptyConstructorConstructor() {
    return new ConstructorConstructor(new HashMap<Type, InstanceCreator<?>>());
  }

  private static InstanceCreator<Object> constant(final Object value) {
    return new InstanceCreator<Object>() {
      @Override public Object createInstance(Type type) {
        return value;
      }
    };
  }

  /**
   * Builds an empty {@link ConstructorConstructor}, asks it for the given type and asserts that
   * {@code construct()} yields a fresh, empty instance of exactly {@code expectedRuntimeClass}.
   */
  private static void assertConstructs(Class<?> expectedRuntimeClass, TypeToken<?> typeToken) {
    ObjectConstructor<?> constructor = emptyConstructorConstructor().get(typeToken);
    assertNotNull(constructor);

    Object first = constructor.construct();
    assertNotNull(first);
    assertEquals(expectedRuntimeClass, first.getClass());

    if (first instanceof Collection) {
      assertTrue("expected a freshly created empty collection", ((Collection<?>) first).isEmpty());
    } else if (first instanceof Map) {
      assertTrue("expected a freshly created empty map", ((Map<?, ?>) first).isEmpty());
    }

    Object second = constructor.construct();
    assertNotSame("construct() must return a new instance on every call", first, second);
  }

  // ---------------------------------------------------------------------------
  // toString / constructor
  // ---------------------------------------------------------------------------

  public void testToStringOnEmptyInstanceCreators() {
    ConstructorConstructor cc =
        new ConstructorConstructor(new HashMap<Type, InstanceCreator<?>>());
    assertEquals("{}", cc.toString());
  }

  public void testToStringReflectsTheLiveInstanceCreatorsMap() {
    Map<Type, InstanceCreator<?>> map = new HashMap<Type, InstanceCreator<?>>();
    ConstructorConstructor cc = new ConstructorConstructor(map);

    assertEquals(map.toString(), cc.toString());

    // The constructor keeps a reference to the supplied map rather than copying it, so later
    // mutations are visible through toString().
    map.put(Widget.class, constant(new Widget()));
    assertEquals(map.toString(), cc.toString());
    assertTrue(cc.toString().contains("Widget"));
  }

  // ---------------------------------------------------------------------------
  // Instance creators
  // ---------------------------------------------------------------------------

  public void testInstanceCreatorByExactTypeIsUsed() {
    final Widget provided = new Widget();
    final List<Type> seenTypes = new ArrayList<Type>();

    Map<Type, InstanceCreator<?>> map = new HashMap<Type, InstanceCreator<?>>();
    map.put(Widget.class, new InstanceCreator<Widget>() {
      @Override public Widget createInstance(Type type) {
        seenTypes.add(type);
        return provided;
      }
    });

    ConstructorConstructor cc = new ConstructorConstructor(map);
    ObjectConstructor<Widget> constructor = cc.get(TypeToken.get(Widget.class));

    // Both invocations return the very instance handed back by the creator, i.e. the default
    // (implicit) no-args constructor of Widget is never used.
    assertSame(provided, constructor.construct());
    assertSame(provided, constructor.construct());
    assertEquals(2, seenTypes.size());
    assertEquals(Widget.class, seenTypes.get(0));
  }

  public void testExactTypeInstanceCreatorPreferredOverRawTypeInstanceCreator() {
    TypeToken<Collection<String>> typeToken = new TypeToken<Collection<String>>() {};

    final Collection<Object> exactMatch = new ArrayList<Object>();
    final Collection<Object> rawMatch = new LinkedHashSet<Object>();

    Map<Type, InstanceCreator<?>> map = new HashMap<Type, InstanceCreator<?>>();
    map.put(typeToken.getType(), constant(exactMatch));
    map.put(Collection.class, constant(rawMatch));

    ConstructorConstructor cc = new ConstructorConstructor(map);
    assertSame(exactMatch, cc.get(typeToken).construct());
  }

  public void testRawTypeInstanceCreatorReceivesFullParameterizedType() {
    final List<Type> seenTypes = new ArrayList<Type>();
    final ArrayList<Object> provided = new ArrayList<Object>();

    Map<Type, InstanceCreator<?>> map = new HashMap<Type, InstanceCreator<?>>();
    map.put(Collection.class, new InstanceCreator<Object>() {
      @Override public Object createInstance(Type type) {
        seenTypes.add(type);
        return provided;
      }
    });

    ConstructorConstructor cc = new ConstructorConstructor(map);
    TypeToken<Collection<String>> typeToken = new TypeToken<Collection<String>>() {};

    assertSame(provided, cc.get(typeToken).construct());
    assertEquals(1, seenTypes.size());
    assertTrue(seenTypes.get(0) instanceof ParameterizedType);
    assertEquals(typeToken.getType(), seenTypes.get(0));
  }

  public void testInstanceCreatorTakesPrecedenceOverDefaultConstructor() {
    // ArrayList has a usable public no-args constructor, but a registered creator must win.
    final ArrayList<Object> provided = new ArrayList<Object>();
    Map<Type, InstanceCreator<?>> map = new HashMap<Type, InstanceCreator<?>>();
    map.put(ArrayList.class, constant(provided));

    ConstructorConstructor cc = new ConstructorConstructor(map);
    assertSame(provided, cc.get(TypeToken.get(ArrayList.class)).construct());
  }

  public void testInstanceCreatorTakesPrecedenceOverDefaultImplementation() {
    final LinkedList<Object> provided = new LinkedList<Object>();
    Map<Type, InstanceCreator<?>> map = new HashMap<Type, InstanceCreator<?>>();
    map.put(List.class, constant(provided));

    ConstructorConstructor cc = new ConstructorConstructor(map);
    Object constructed = cc.get(new TypeToken<List<String>>() {}).construct();
    assertSame(provided, constructed);
    assertFalse(constructed instanceof ArrayList);
  }

  public void testInstanceCreatorMapIsConsultedLazilyOnEveryGet() {
    Map<Type, InstanceCreator<?>> map = new HashMap<Type, InstanceCreator<?>>();
    ConstructorConstructor cc = new ConstructorConstructor(map);

    final ArrayList<Object> provided = new ArrayList<Object>();
    map.put(ArrayList.class, constant(provided)); // registered after construction of cc

    assertSame(provided, cc.get(TypeToken.get(ArrayList.class)).construct());
  }

  // ---------------------------------------------------------------------------
  // Default (declared) no-args constructor
  // ---------------------------------------------------------------------------

  public void testDefaultConstructorForPublicNoArgsConstructor() {
    ObjectConstructor<PublicNoArgs> constructor =
        emptyConstructorConstructor().get(TypeToken.get(PublicNoArgs.class));

    PublicNoArgs a = constructor.construct();
    PublicNoArgs b = constructor.construct();

    assertNotNull(a);
    assertEquals(42, a.marker); // constructor body actually ran
    assertNotSame(a, b);
  }

  public void testDefaultConstructorInvokesPrivateNoArgsConstructor() {
    PrivateNoArgs.instances = 0;

    ObjectConstructor<PrivateNoArgs> constructor =
        emptyConstructorConstructor().get(TypeToken.get(PrivateNoArgs.class));

    PrivateNoArgs a = constructor.construct();
    assertNotNull(a);
    assertEquals(1, PrivateNoArgs.instances);

    PrivateNoArgs b = constructor.construct();
    assertEquals(2, PrivateNoArgs.instances);
    assertNotSame(a, b);
  }

  public void testDefaultConstructorWrapsExceptionThrownByConstructorBody() {
    ObjectConstructor<ThrowingConstructor> constructor =
        emptyConstructorConstructor().get(TypeToken.get(ThrowingConstructor.class));

    try {
      constructor.construct();
      fail("Expected RuntimeException");
    } catch (RuntimeException expected) {
      assertTrue(expected.getMessage().contains("Failed to invoke"));
      assertTrue(expected.getCause() instanceof IllegalStateException);
      assertEquals("boom", expected.getCause().getMessage());
    }
  }

  public void testAbstractClassWithNoArgsConstructorFailsWithInstantiationException() {
    ObjectConstructor<AbstractWithConstructor> constructor =
        emptyConstructorConstructor().get(TypeToken.get(AbstractWithConstructor.class));
    assertNotNull(constructor);

    try {
      constructor.construct();
      fail("Expected RuntimeException");
    } catch (RuntimeException expected) {
      assertTrue(expected.getCause() instanceof InstantiationException);
    }
  }

  public void testDefaultConstructorForJdkTypeWithNoArgsConstructor() {
    ObjectConstructor<String> constructor =
        emptyConstructorConstructor().get(TypeToken.get(String.class));
    assertEquals("", constructor.construct());
  }

  public void testDefaultConstructorForPlainObject() {
    ObjectConstructor<Object> constructor =
        emptyConstructorConstructor().get(TypeToken.get(Object.class));

    Object a = constructor.construct();
    assertNotNull(a);
    assertSame(Object.class, a.getClass());
    assertNotSame(a, constructor.construct());
  }

  // ---------------------------------------------------------------------------
  // Default implementations for collection interfaces
  // ---------------------------------------------------------------------------

  public void testCollectionInterfaceProducesArrayList() {
    assertConstructs(ArrayList.class, TypeToken.get(Collection.class));
  }

  public void testListInterfaceProducesArrayList() {
    assertConstructs(ArrayList.class, new TypeToken<List<String>>() {});
  }

  public void testSetInterfaceProducesLinkedHashSet() {
    assertConstructs(LinkedHashSet.class, new TypeToken<Set<String>>() {});
  }

  public void testSortedSetInterfaceProducesTreeSet() {
    assertConstructs(TreeSet.class, new TypeToken<SortedSet<String>>() {});
  }

  public void testNavigableSetInterfaceProducesTreeSet() {
    assertConstructs(TreeSet.class, new TypeToken<NavigableSet<String>>() {});
  }

  public void testQueueInterfaceProducesLinkedList() {
    assertConstructs(LinkedList.class, new TypeToken<Queue<String>>() {});
  }

  public void testDequeInterfaceProducesLinkedList() {
    assertConstructs(LinkedList.class, new TypeToken<Deque<String>>() {});
  }

  public void testConstructedListIsMutable() {
    Object constructed =
        emptyConstructorConstructor().get(new TypeToken<List<String>>() {}).construct();
    List<String> list = (List<String>) constructed;
    list.add("a");
    list.add("b");
    assertEquals(2, list.size());
    assertEquals("a", list.get(0));
  }

  // ---------------------------------------------------------------------------
  // Default implementations for map interfaces
  // ---------------------------------------------------------------------------

  public void testRawMapProducesLinkedTreeMap() {
    assertConstructs(LinkedTreeMap.class, TypeToken.get(Map.class));
  }

  public void testStringKeyedMapProducesLinkedTreeMap() {
    assertConstructs(LinkedTreeMap.class, new TypeToken<Map<String, Integer>>() {});
  }

  public void testNonStringKeyedMapProducesLinkedHashMap() {
    assertConstructs(LinkedHashMap.class, new TypeToken<Map<Integer, Integer>>() {});
  }

  public void testConstructedMapIsMutable() {
    Object constructed = emptyConstructorConstructor()
        .get(new TypeToken<Map<Integer, String>>() {}).construct();
    assertTrue(constructed instanceof LinkedHashMap);
    Map<Integer, String> map = (Map<Integer, String>) constructed;
    map.put(1, "one");
    assertEquals(1, map.size());
    assertEquals("one", map.get(1));
  }

  public void testSortedMapInterfaceProducesTreeMap() {
    assertConstructs(TreeMap.class, new TypeToken<SortedMap<String, Integer>>() {});
  }

  public void testRawSortedMapProducesTreeMap() {
    assertConstructs(TreeMap.class, TypeToken.get(SortedMap.class));
  }

  public void testNavigableMapInterfaceProducesTreeMap() {
    assertConstructs(TreeMap.class, new TypeToken<NavigableMap<String, Integer>>() {});
  }

  public void testConcurrentMapInterfaceProducesConcurrentHashMap() {
    assertConstructs(ConcurrentHashMap.class, new TypeToken<ConcurrentMap<String, Integer>>() {});
  }

  public void testRawConcurrentMapProducesConcurrentHashMap() {
    assertConstructs(ConcurrentHashMap.class, TypeToken.get(ConcurrentMap.class));
  }

  public void testConcurrentNavigableMapProducesConcurrentSkipListMap() {
    assertConstructs(ConcurrentSkipListMap.class,
        new TypeToken<ConcurrentNavigableMap<String, Integer>>() {});
  }

  // ---------------------------------------------------------------------------
  // EnumSet
  // ---------------------------------------------------------------------------

  public void testParameterizedEnumSetProducesUsableEnumSet() {
    ObjectConstructor<EnumSet<Color>> constructor =
        emptyConstructorConstructor().get(new TypeToken<EnumSet<Color>>() {});

    EnumSet<Color> first = constructor.construct();
    assertNotNull(first);
    assertTrue(first instanceof EnumSet);
    assertTrue(first.isEmpty());

    first.add(Color.RED);
    first.add(Color.BLUE);
    assertEquals(2, first.size());
    assertTrue(first.contains(Color.RED));
    assertFalse(first.contains(Color.GREEN));

    assertNotSame(first, constructor.construct());
  }

  public void testRawEnumSetThrowsJsonIOException() {
    ObjectConstructor<?> constructor =
        emptyConstructorConstructor().get(TypeToken.get(EnumSet.class));

    try {
      constructor.construct();
      fail("Expected JsonIOException");
    } catch (JsonIOException expected) {
      assertTrue(expected.getMessage().contains("Invalid EnumSet type"));
    }
  }

  // ---------------------------------------------------------------------------
  // Unsafe allocator fallback
  // ---------------------------------------------------------------------------

  public void testClassWithoutNoArgsConstructorIsAllocatedWithoutRunningConstructor() {
    ObjectConstructor<NoNoArgsConstructor> constructor =
        emptyConstructorConstructor().get(TypeToken.get(NoNoArgsConstructor.class));

    NoNoArgsConstructor instance = constructor.construct();
    assertNotNull(instance);
    // Neither the constructor body nor the field initializers ran.
    assertNull(instance.value);
    assertEquals(0, instance.number);
    assertNotSame(instance, constructor.construct());
  }

  public void testInterfaceWithoutDefaultImplementationFailsThroughUnsafeAllocator() {
    ObjectConstructor<Runnable> constructor =
        emptyConstructorConstructor().get(TypeToken.get(Runnable.class));
    assertNotNull(constructor);

    try {
      constructor.construct();
      fail("Expected RuntimeException");
    } catch (RuntimeException expected) {
      assertTrue(expected.getMessage().contains("Unable to invoke no-args constructor for"));
    }
  }

  // ---------------------------------------------------------------------------
  // General contract / boundary cases
  // ---------------------------------------------------------------------------

  public void testGetNeverReturnsNull() {
    ConstructorConstructor cc = emptyConstructorConstructor();
    assertNotNull(cc.get(TypeToken.get(String.class)));
    assertNotNull(cc.get(TypeToken.get(Runnable.class)));
    assertNotNull(cc.get(TypeToken.get(int.class)));
    assertNotNull(cc.get(new TypeToken<Map<String, Integer>>() {}));
    assertNotNull(cc.get(new TypeToken<List<String>>() {}));
  }

  public void testNullInstanceCreatorsMapFailsWhenGetIsCalled() {
    ConstructorConstructor cc = new ConstructorConstructor(null);
    try {
      cc.get(TypeToken.get(String.class));
      fail("Expected NullPointerException");
    } catch (NullPointerException expected) {
    }
  }

  // ---------------------------------------------------------------------------
  // Fixtures
  // ---------------------------------------------------------------------------

  public static final class Widget {
  }

  public static final class PublicNoArgs {
    int marker;
    public PublicNoArgs() {
      marker = 42;
    }
  }

  public static final class PrivateNoArgs {
    static int instances;
    private PrivateNoArgs() {
      instances++;
    }
  }

  public static final class ThrowingConstructor {
    public ThrowingConstructor() {
      throw new IllegalStateException("boom");
    }
  }

  public abstract static class AbstractWithConstructor {
    public AbstractWithConstructor() {
    }
  }

  public static final class NoNoArgsConstructor {
    String value = "initialized";
    int number = 7;

    public NoNoArgsConstructor(String value) {
      this.value = value;
      this.number = 42;
    }
  }

  enum Color {
    RED, GREEN, BLUE
  }
}
