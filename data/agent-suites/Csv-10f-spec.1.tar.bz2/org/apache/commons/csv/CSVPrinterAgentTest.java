package org.apache.commons.csv;

import java.io.Writer;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import junit.framework.TestCase;

/**
 * Self-contained tests for {@link CSVPrinter}, derived exclusively from the
 * published javadoc contract in <code>api/</code>.
 *
 * <p>Every expectation is expressed against {@code CSVFormat.DEFAULT} &ndash; the
 * only {@code CSVFormat} member referenced by the package documentation (see the
 * package-summary example {@code CSVFormat.DEFAULT.parse(in)}). {@code DEFAULT}
 * is the RFC&nbsp;4180 style dialect referenced by the package description:</p>
 * <ul>
 *   <li>field delimiter {@code ','}</li>
 *   <li>quote character {@code '"'} (doubled when it occurs inside a value)</li>
 *   <li>record separator {@code "\r\n"}</li>
 *   <li>comments disabled (no comment marker configured)</li>
 * </ul>
 *
 * <p>Written for the JUnit 3.8 API present in {@code lib/} &ndash; it extends
 * {@code junit.framework.TestCase} and uses no annotations. It does not extend or
 * import any other test class; the JDBC fixture is defined inline below.</p>
 */
public class CSVPrinterAgentTest extends TestCase {

    private static final String CRLF = "\r\n";

    // ------------------------------------------------------------------
    // constructor + getOut()
    // ------------------------------------------------------------------

    public void testGetOutReturnsTheSameAppendableInstance() throws Exception {
        StringBuilder out = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(out, CSVFormat.DEFAULT);
        assertSame(out, printer.getOut());
    }

    public void testConstructorWithHeaderlessFormatWritesNothing() throws Exception {
        StringBuilder out = new StringBuilder();
        new CSVPrinter(out, CSVFormat.DEFAULT);
        assertEquals("", out.toString());
    }

    public void testConstructorRejectsNullOut() throws Exception {
        try {
            new CSVPrinter(null, CSVFormat.DEFAULT);
            fail("expected IllegalArgumentException when out is null");
        } catch (IllegalArgumentException expected) {
            // documented: "thrown if ... either out or format are null"
        }
    }

    public void testConstructorRejectsNullFormat() throws Exception {
        try {
            new CSVPrinter(new StringBuilder(), null);
            fail("expected IllegalArgumentException when format is null");
        } catch (IllegalArgumentException expected) {
            // documented: "thrown if ... either out or format are null"
        }
    }

    // ------------------------------------------------------------------
    // print(Object)
    // ------------------------------------------------------------------

    public void testPrintWritesTheValueWithNoLeadingSeparator() throws Exception {
        StringBuilder out = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(out, CSVFormat.DEFAULT);
        printer.print("abc");
        printer.flush();
        assertEquals("abc", out.toString());
    }

    public void testPrintInsertsDelimiterBeforeEveryValueExceptTheFirst() throws Exception {
        StringBuilder out = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(out, CSVFormat.DEFAULT);
        printer.print("a");
        printer.print("b");
        printer.print("c");
        printer.flush();
        assertEquals("a,b,c", out.toString());
    }

    public void testPrintDoesNotQuoteAPlainValue() throws Exception {
        StringBuilder out = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(out, CSVFormat.DEFAULT);
        printer.print("plain");
        printer.flush();
        assertEquals("plain", out.toString());
    }

    public void testPrintEncapsulatesValueContainingTheDelimiter() throws Exception {
        StringBuilder out = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(out, CSVFormat.DEFAULT);
        printer.print("a,b");
        printer.flush();
        assertEquals("\"a,b\"", out.toString());
    }

    public void testPrintEncapsulatesValueContainingTheQuoteCharAndDoublesIt() throws Exception {
        StringBuilder out = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(out, CSVFormat.DEFAULT);
        printer.print("a\"b");
        printer.flush();
        // opening quote, a, doubled quote, b, closing quote
        assertEquals("\"a\"\"b\"", out.toString());
    }

    public void testPrintEncapsulatesValueContainingLineFeed() throws Exception {
        StringBuilder out = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(out, CSVFormat.DEFAULT);
        printer.print("a\nb");
        printer.flush();
        assertEquals("\"a\nb\"", out.toString());
    }

    public void testPrintEncapsulatesValueContainingCarriageReturn() throws Exception {
        StringBuilder out = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(out, CSVFormat.DEFAULT);
        printer.print("a\rb");
        printer.flush();
        assertEquals("\"a\rb\"", out.toString());
    }

    public void testPrintRendersNonStringValueViaToString() throws Exception {
        StringBuilder out = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(out, CSVFormat.DEFAULT);
        printer.print(Integer.valueOf(42));
        printer.flush();
        assertEquals("42", out.toString());
    }

    // ------------------------------------------------------------------
    // println()
    // ------------------------------------------------------------------

    public void testPrintlnOutputsTheRecordSeparator() throws Exception {
        StringBuilder out = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(out, CSVFormat.DEFAULT);
        printer.println();
        printer.flush();
        assertEquals(CRLF, out.toString());
    }

    public void testConsecutivePrintlnCallsProduceBlankRecords() throws Exception {
        StringBuilder out = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(out, CSVFormat.DEFAULT);
        printer.println();
        printer.println();
        printer.flush();
        assertEquals("\r\n\r\n", out.toString());
    }

    public void testOnlyPrintlnTerminatesARecord() throws Exception {
        StringBuilder withoutLn = new StringBuilder();
        CSVPrinter p1 = new CSVPrinter(withoutLn, CSVFormat.DEFAULT);
        p1.print("a");
        p1.print("b");
        p1.flush();
        assertEquals("a,b", withoutLn.toString());

        StringBuilder withLn = new StringBuilder();
        CSVPrinter p2 = new CSVPrinter(withLn, CSVFormat.DEFAULT);
        p2.print("a");
        p2.print("b");
        p2.println();
        p2.flush();
        assertEquals("a,b\r\n", withLn.toString());
    }

    public void testPrintlnStartsANewRecordSoTheNextValueHasNoLeadingDelimiter() throws Exception {
        StringBuilder out = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(out, CSVFormat.DEFAULT);
        printer.print("a");
        printer.println();
        printer.print("b");
        printer.flush();
        assertEquals("a\r\nb", out.toString());
    }

    // ------------------------------------------------------------------
    // printRecord(Object...) / printRecord(Iterable)
    // ------------------------------------------------------------------

    public void testPrintRecordVarargsWritesOneTerminatedLine() throws Exception {
        StringBuilder out = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(out, CSVFormat.DEFAULT);
        printer.printRecord("a", "b", "c");
        printer.flush();
        assertEquals("a,b,c\r\n", out.toString());
    }

    public void testPrintRecordIterableWritesOneTerminatedLine() throws Exception {
        StringBuilder out = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(out, CSVFormat.DEFAULT);
        printer.printRecord(Arrays.asList("a", "b", "c"));
        printer.flush();
        assertEquals("a,b,c\r\n", out.toString());
    }

    public void testPrintRecordQuotesOnlyTheValuesThatNeedIt() throws Exception {
        StringBuilder out = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(out, CSVFormat.DEFAULT);
        printer.printRecord("a,1", "b\"2", "c");
        printer.flush();
        assertEquals("\"a,1\",\"b\"\"2\",c\r\n", out.toString());
    }

    public void testPrintRecordWithNoValuesWritesOnlyTheRecordSeparator() throws Exception {
        StringBuilder out = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(out, CSVFormat.DEFAULT);
        printer.printRecord(new Object[0]);
        printer.flush();
        assertEquals("\r\n", out.toString());
    }

    public void testPrintRecordPreservesInteriorEmptyFields() throws Exception {
        StringBuilder out = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(out, CSVFormat.DEFAULT);
        printer.printRecord("a", "", "b");
        printer.flush();
        assertEquals("a,,b\r\n", out.toString());
    }

    public void testPrintRecordEncapsulatesALoneEmptyField() throws Exception {
        // A single empty field must be encapsulated: DEFAULT skips blank input
        // lines, so an unquoted empty line could not be read back as a one-field
        // record. Quoting it ("") keeps the output round-trippable.
        StringBuilder out = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(out, CSVFormat.DEFAULT);
        printer.printRecord(new Object[] { "" });
        printer.flush();
        assertEquals("\"\"\r\n", out.toString());
    }

    public void testPrintRecordRendersNullValueAsAnEmptyField() throws Exception {
        // The javadoc is silent on null; the contract-consistent rendering of an
        // absent value is an empty field.
        StringBuilder out = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(out, CSVFormat.DEFAULT);
        printer.printRecord("x", null);
        printer.flush();
        assertEquals("x,\r\n", out.toString());
    }

    public void testPrintRecordRendersMixedObjectTypesViaToString() throws Exception {
        StringBuilder out = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(out, CSVFormat.DEFAULT);
        printer.printRecord(Integer.valueOf(1), Boolean.TRUE, "three");
        printer.flush();
        assertEquals("1,true,three\r\n", out.toString());
    }

    public void testSuccessivePrintRecordCallsAccumulate() throws Exception {
        StringBuilder out = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(out, CSVFormat.DEFAULT);
        printer.printRecord("1", "2");
        printer.printRecord("3", "4");
        printer.flush();
        assertEquals("1,2\r\n3,4\r\n", out.toString());
    }

    public void testPrintAfterPrintRecordContinuesOnTheNextLine() throws Exception {
        StringBuilder out = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(out, CSVFormat.DEFAULT);
        printer.printRecord("a", "b");
        printer.print("c");
        printer.flush();
        assertEquals("a,b\r\nc", out.toString());
    }

    // ------------------------------------------------------------------
    // printRecords(Object[]) / printRecords(Iterable) / printRecords(ResultSet)
    // ------------------------------------------------------------------

    public void testPrintRecordsArrayWritesOneRecordPerElement() throws Exception {
        StringBuilder out = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(out, CSVFormat.DEFAULT);
        printer.printRecords(new Object[] { "a", "b", "c" });
        printer.flush();
        assertEquals("a\r\nb\r\nc\r\n", out.toString());
    }

    public void testPrintRecordsIterableWritesOneRecordPerElement() throws Exception {
        StringBuilder out = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(out, CSVFormat.DEFAULT);
        List<String> values = new ArrayList<String>();
        values.add("a");
        values.add("b");
        printer.printRecords(values);
        printer.flush();
        assertEquals("a\r\nb\r\n", out.toString());
    }

    public void testPrintRecordsWithEmptyArrayWritesNothing() throws Exception {
        StringBuilder out = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(out, CSVFormat.DEFAULT);
        printer.printRecords(new Object[0]);
        printer.flush();
        assertEquals("", out.toString());
    }

    public void testPrintRecordsResultSetWritesEveryRow() throws Exception {
        StringBuilder out = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(out, CSVFormat.DEFAULT);
        ResultSet rs = newResultSet(2, new String[][] {
                { "r1c1", "r1c2" },
                { "r2c1", "r2c2" },
        });
        printer.printRecords(rs);
        printer.flush();
        assertEquals("r1c1,r1c2\r\nr2c1,r2c2\r\n", out.toString());
    }

    public void testPrintRecordsResultSetWithNoRowsWritesNothing() throws Exception {
        StringBuilder out = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(out, CSVFormat.DEFAULT);
        ResultSet rs = newResultSet(2, new String[0][]);
        printer.printRecords(rs);
        printer.flush();
        assertEquals("", out.toString());
    }

    // ------------------------------------------------------------------
    // printComment(String)
    // ------------------------------------------------------------------

    public void testPrintCommentDoesNothingWhenCommentsAreDisabled() throws Exception {
        // CSVFormat.DEFAULT configures no comment marker, so per the javadoc
        // printComment "does nothing".
        StringBuilder out = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(out, CSVFormat.DEFAULT);
        printer.printComment("a comment");
        printer.flush();
        assertEquals("", out.toString());
    }

    public void testPrintCommentDoesNotDisturbSurroundingRecords() throws Exception {
        StringBuilder out = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(out, CSVFormat.DEFAULT);
        printer.printRecord("a", "b");
        printer.printComment("ignored");
        printer.printRecord("c", "d");
        printer.flush();
        assertEquals("a,b\r\nc,d\r\n", out.toString());
    }

    // ------------------------------------------------------------------
    // flush() / close()
    // ------------------------------------------------------------------

    public void testFlushIsForwardedToTheUnderlyingStream() throws Exception {
        TrackingWriter sink = new TrackingWriter();
        CSVPrinter printer = new CSVPrinter(sink, CSVFormat.DEFAULT);
        printer.print("value");
        int flushesBefore = sink.flushCount;
        printer.flush();
        assertTrue("flush() must flush the underlying stream", sink.flushCount > flushesBefore);
        assertEquals("value", sink.written());
    }

    public void testCloseIsForwardedToTheUnderlyingCloseable() throws Exception {
        TrackingWriter sink = new TrackingWriter();
        CSVPrinter printer = new CSVPrinter(sink, CSVFormat.DEFAULT);
        printer.printRecord("a", "b");
        printer.close();
        assertTrue("close() must close the underlying Closeable", sink.closeCount > 0);
        assertEquals("a,b\r\n", sink.written());
    }

    // ==================================================================
    // Inline fixtures
    // ==================================================================

    /**
     * A {@link Writer} that records the text appended to it and counts the
     * {@code flush()} / {@code close()} calls it receives, so the tests can
     * assert that {@link CSVPrinter} forwards those calls to the wrapped stream.
     */
    private static final class TrackingWriter extends Writer {

        private final StringBuilder buffer = new StringBuilder();
        int flushCount;
        int closeCount;

        public void write(char[] cbuf, int off, int len) {
            buffer.append(cbuf, off, len);
        }

        public void write(int c) {
            buffer.append((char) c);
        }

        public void write(String str) {
            buffer.append(str);
        }

        public void write(String str, int off, int len) {
            buffer.append(str, off, off + len);
        }

        public void flush() {
            flushCount++;
        }

        public void close() {
            closeCount++;
        }

        String written() {
            return buffer.toString();
        }
    }

    /**
     * Builds a minimal {@link ResultSet} (via {@link Proxy}) that reports
     * {@code columnCount} columns and iterates over {@code rows}. Column values
     * are served for both {@code getString(int)} and {@code getObject(int)}.
     */
    private static ResultSet newResultSet(final int columnCount, final String[][] rows) {
        final int[] cursor = { -1 };

        final ResultSetMetaData meta = (ResultSetMetaData) Proxy.newProxyInstance(
                CSVPrinterAgentTest.class.getClassLoader(),
                new Class[] { ResultSetMetaData.class },
                new InvocationHandler() {
                    public Object invoke(Object proxy, Method method, Object[] args) {
                        if ("getColumnCount".equals(method.getName())) {
                            return Integer.valueOf(columnCount);
                        }
                        return objectMethodOrDefault(proxy, method, args);
                    }
                });

        return (ResultSet) Proxy.newProxyInstance(
                CSVPrinterAgentTest.class.getClassLoader(),
                new Class[] { ResultSet.class },
                new InvocationHandler() {
                    public Object invoke(Object proxy, Method method, Object[] args) {
                        String name = method.getName();
                        if ("getMetaData".equals(name)) {
                            return meta;
                        }
                        if ("next".equals(name)) {
                            cursor[0]++;
                            return Boolean.valueOf(cursor[0] < rows.length);
                        }
                        if ("getString".equals(name) || "getObject".equals(name)) {
                            int column = ((Number) args[0]).intValue();
                            return rows[cursor[0]][column - 1];
                        }
                        if ("wasNull".equals(name)) {
                            return Boolean.FALSE;
                        }
                        return objectMethodOrDefault(proxy, method, args);
                    }
                });
    }

    /** Handles Object methods on a proxy and returns type-correct defaults for anything else. */
    private static Object objectMethodOrDefault(Object proxy, Method method, Object[] args) {
        String name = method.getName();
        if ("toString".equals(name)) {
            return method.getDeclaringClass().getName() + "@proxy";
        }
        if ("hashCode".equals(name)) {
            return Integer.valueOf(System.identityHashCode(proxy));
        }
        if ("equals".equals(name)) {
            return Boolean.valueOf(proxy == (args == null ? null : args[0]));
        }
        Class<?> ret = method.getReturnType();
        if (!ret.isPrimitive() || ret == void.class) {
            return null;
        }
        if (ret == boolean.class) {
            return Boolean.FALSE;
        }
        if (ret == char.class) {
            return Character.valueOf((char) 0);
        }
        if (ret == byte.class) {
            return Byte.valueOf((byte) 0);
        }
        if (ret == short.class) {
            return Short.valueOf((short) 0);
        }
        if (ret == int.class) {
            return Integer.valueOf(0);
        }
        if (ret == long.class) {
            return Long.valueOf(0L);
        }
        if (ret == float.class) {
            return Float.valueOf(0.0f);
        }
        return Double.valueOf(0.0d);
    }
}
