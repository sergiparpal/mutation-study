package org.apache.commons.lang3.math;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.math.BigDecimal;
import java.math.BigInteger;

import org.junit.Test;

/**
 * Self-contained JUnit tests for {@link org.apache.commons.lang3.math.NumberUtils}.
 *
 * <p>Every expectation below is taken from the published Javadoc contract of the class
 * (method summaries, worked examples and the documented {@code @throws} clauses). Where
 * the Javadoc only states a general rule (for example "the default value is returned if
 * the conversion fails") the tests assert the behaviour that rule implies rather than any
 * implementation detail.</p>
 */
public class NumberUtilsAgentTest {

    /** Tolerance for "exact" floating point comparisons of representable values. */
    private static final double DELTA = 0.0000001d;
    private static final float FDELTA = 0.0000001f;

    // ------------------------------------------------------------------ constructor

    @Test
    public void constructorIsPublicAndUsable() {
        // The Javadoc states the constructor is public "to permit tools that require a
        // JavaBean instance to operate", so instantiation must succeed.
        assertNotNull(new NumberUtils());
    }

    // ------------------------------------------------------------------ reusable constants

    @Test
    public void reusableIntegralConstants() {
        assertEquals(Long.valueOf(0L), NumberUtils.LONG_ZERO);
        assertEquals(Long.valueOf(1L), NumberUtils.LONG_ONE);
        assertEquals(Long.valueOf(-1L), NumberUtils.LONG_MINUS_ONE);

        assertEquals(Integer.valueOf(0), NumberUtils.INTEGER_ZERO);
        assertEquals(Integer.valueOf(1), NumberUtils.INTEGER_ONE);
        assertEquals(Integer.valueOf(-1), NumberUtils.INTEGER_MINUS_ONE);

        assertEquals(Short.valueOf((short) 0), NumberUtils.SHORT_ZERO);
        assertEquals(Short.valueOf((short) 1), NumberUtils.SHORT_ONE);
        assertEquals(Short.valueOf((short) -1), NumberUtils.SHORT_MINUS_ONE);

        assertEquals(Byte.valueOf((byte) 0), NumberUtils.BYTE_ZERO);
        assertEquals(Byte.valueOf((byte) 1), NumberUtils.BYTE_ONE);
        assertEquals(Byte.valueOf((byte) -1), NumberUtils.BYTE_MINUS_ONE);
    }

    @Test
    public void reusableFloatingPointConstants() {
        assertEquals(Double.valueOf(0.0d), NumberUtils.DOUBLE_ZERO);
        assertEquals(Double.valueOf(1.0d), NumberUtils.DOUBLE_ONE);
        assertEquals(Double.valueOf(-1.0d), NumberUtils.DOUBLE_MINUS_ONE);

        assertEquals(Float.valueOf(0.0f), NumberUtils.FLOAT_ZERO);
        assertEquals(Float.valueOf(1.0f), NumberUtils.FLOAT_ONE);
        assertEquals(Float.valueOf(-1.0f), NumberUtils.FLOAT_MINUS_ONE);
    }

    // ------------------------------------------------------------------ toInt

    @Test
    public void toIntWithoutDefault() {
        assertEquals(0, NumberUtils.toInt(null));
        assertEquals(0, NumberUtils.toInt(""));
        assertEquals(1, NumberUtils.toInt("1"));
        assertEquals(456, NumberUtils.toInt("456"));
        assertEquals(-123, NumberUtils.toInt("-123"));
        assertEquals(Integer.MAX_VALUE, NumberUtils.toInt("2147483647"));
        assertEquals(Integer.MIN_VALUE, NumberUtils.toInt("-2147483648"));
        // conversion failures -> zero
        assertEquals(0, NumberUtils.toInt("abc"));
        assertEquals(0, NumberUtils.toInt("3.5"));
        assertEquals(0, NumberUtils.toInt("2147483648")); // overflows int
    }

    @Test
    public void toIntWithDefault() {
        assertEquals(1, NumberUtils.toInt(null, 1));
        assertEquals(1, NumberUtils.toInt("", 1));
        assertEquals(1, NumberUtils.toInt("1", 0));
        assertEquals(12, NumberUtils.toInt("12", 99));
        assertEquals(5, NumberUtils.toInt("abc", 5));
        assertEquals(-7, NumberUtils.toInt("3.5", -7));
        assertEquals(42, NumberUtils.toInt("2147483648", 42));
    }

    // ------------------------------------------------------------------ toLong

    @Test
    public void toLongWithoutDefault() {
        assertEquals(0L, NumberUtils.toLong(null));
        assertEquals(0L, NumberUtils.toLong(""));
        assertEquals(1L, NumberUtils.toLong("1"));
        assertEquals(123456789012L, NumberUtils.toLong("123456789012"));
        assertEquals(-123L, NumberUtils.toLong("-123"));
        assertEquals(Long.MAX_VALUE, NumberUtils.toLong("9223372036854775807"));
        assertEquals(0L, NumberUtils.toLong("abc"));
        assertEquals(0L, NumberUtils.toLong("1.5"));
        assertEquals(0L, NumberUtils.toLong("9223372036854775808")); // overflows long
    }

    @Test
    public void toLongWithDefault() {
        assertEquals(1L, NumberUtils.toLong(null, 1L));
        assertEquals(1L, NumberUtils.toLong("", 1L));
        assertEquals(1L, NumberUtils.toLong("1", 0L));
        assertEquals(9L, NumberUtils.toLong("1.5", 9L));
        assertEquals(123456789012L, NumberUtils.toLong("123456789012", 0L));
    }

    // ------------------------------------------------------------------ toFloat

    @Test
    public void toFloatWithoutDefault() {
        assertEquals(0.0f, NumberUtils.toFloat(null), FDELTA);
        assertEquals(0.0f, NumberUtils.toFloat(""), FDELTA);
        assertEquals(1.5f, NumberUtils.toFloat("1.5"), FDELTA);
        assertEquals(-2.25f, NumberUtils.toFloat("-2.25"), FDELTA);
        assertEquals(0.0f, NumberUtils.toFloat("abc"), FDELTA);
    }

    @Test
    public void toFloatWithDefault() {
        // The prose contract: "If the string str is null, the default value is returned."
        assertEquals(2.0f, NumberUtils.toFloat(null, 2.0f), 0.0f);
        assertEquals(1.1f, NumberUtils.toFloat("", 1.1f), FDELTA);
        assertEquals(1.5f, NumberUtils.toFloat("1.5", 0.0f), FDELTA);
        assertEquals(2.5f, NumberUtils.toFloat("xyz", 2.5f), FDELTA);
    }

    // ------------------------------------------------------------------ toDouble

    @Test
    public void toDoubleWithoutDefault() {
        assertEquals(0.0d, NumberUtils.toDouble(null), DELTA);
        assertEquals(0.0d, NumberUtils.toDouble(""), DELTA);
        assertEquals(1.5d, NumberUtils.toDouble("1.5"), DELTA);
        assertEquals(-3.75d, NumberUtils.toDouble("-3.75"), DELTA);
        assertEquals(0.0d, NumberUtils.toDouble("abc"), DELTA);
    }

    @Test
    public void toDoubleWithDefault() {
        assertEquals(1.1d, NumberUtils.toDouble(null, 1.1d), DELTA);
        assertEquals(1.1d, NumberUtils.toDouble("", 1.1d), DELTA);
        assertEquals(1.5d, NumberUtils.toDouble("1.5", 0.0d), DELTA);
        assertEquals(7.25d, NumberUtils.toDouble("bad", 7.25d), DELTA);
    }

    // ------------------------------------------------------------------ toByte

    @Test
    public void toByteWithoutDefault() {
        assertEquals(0, NumberUtils.toByte(null));
        assertEquals(0, NumberUtils.toByte(""));
        assertEquals(1, NumberUtils.toByte("1"));
        assertEquals(-12, NumberUtils.toByte("-12"));
        assertEquals(0, NumberUtils.toByte("abc"));
        assertEquals(0, NumberUtils.toByte("999")); // outside byte range
    }

    @Test
    public void toByteWithDefault() {
        assertEquals(1, NumberUtils.toByte(null, (byte) 1));
        assertEquals(1, NumberUtils.toByte("", (byte) 1));
        assertEquals(1, NumberUtils.toByte("1", (byte) 0));
        assertEquals(5, NumberUtils.toByte("abc", (byte) 5));
    }

    // ------------------------------------------------------------------ toShort

    @Test
    public void toShortWithoutDefault() {
        assertEquals(0, NumberUtils.toShort(null));
        assertEquals(0, NumberUtils.toShort(""));
        assertEquals(1, NumberUtils.toShort("1"));
        assertEquals(-1234, NumberUtils.toShort("-1234"));
        assertEquals(0, NumberUtils.toShort("abc"));
        assertEquals(0, NumberUtils.toShort("99999")); // outside short range
    }

    @Test
    public void toShortWithDefault() {
        assertEquals(1, NumberUtils.toShort(null, (short) 1));
        assertEquals(1, NumberUtils.toShort("", (short) 1));
        assertEquals(1, NumberUtils.toShort("1", (short) 0));
        assertEquals(5, NumberUtils.toShort("abc", (short) 5));
    }

    // ------------------------------------------------------------------ createNumber

    @Test
    public void createNumberNullReturnsNull() {
        assertNull(NumberUtils.createNumber(null));
    }

    @Test
    public void createNumberPlainIntegerStaysInteger() {
        final Number n = NumberUtils.createNumber("123");
        assertEquals(Integer.class, n.getClass());
        assertEquals(123, n.intValue());
    }

    @Test
    public void createNumberPromotesLargeValueToLong() {
        final Number n = NumberUtils.createNumber("12345678901");
        assertEquals(Long.class, n.getClass());
        assertEquals(12345678901L, n.longValue());
    }

    @Test
    public void createNumberHonoursTypeQualifiers() {
        assertEquals(Float.class, NumberUtils.createNumber("1.5f").getClass());
        assertEquals(1.5f, NumberUtils.createNumber("1.5f").floatValue(), FDELTA);

        assertEquals(Float.class, NumberUtils.createNumber("2.5F").getClass());

        assertEquals(Double.class, NumberUtils.createNumber("1.5d").getClass());
        assertEquals(1.5d, NumberUtils.createNumber("1.5d").doubleValue(), DELTA);

        assertEquals(Double.class, NumberUtils.createNumber("2.5D").getClass());

        assertEquals(Long.class, NumberUtils.createNumber("123L").getClass());
        assertEquals(123L, NumberUtils.createNumber("123L").longValue());
    }

    @Test
    public void createNumberHandlesHexPrefix() {
        assertEquals(26, NumberUtils.createNumber("0x1A").intValue());
        assertEquals(-26, NumberUtils.createNumber("-0x1A").intValue());
    }

    @Test
    public void createNumberHandlesDecimalWithoutQualifier() {
        // No qualifier + decimal point -> a floating point Number whose value is 1.5.
        final Number n = NumberUtils.createNumber("1.5");
        assertTrue(n instanceof Number);
        assertEquals(1.5d, n.doubleValue(), DELTA);
    }

    @Test
    public void createNumberRejectsInvalidInput() {
        assertCreateNumberThrows("blah");
        assertCreateNumberThrows("1.2.3");
        // Javadoc: the method does not trim, so leading/trailing spaces are errors.
        assertCreateNumberThrows(" 1");
        assertCreateNumberThrows("1 ");
    }

    // ------------------------------------------------------------------ createInteger

    @Test
    public void createIntegerValid() {
        assertNull(NumberUtils.createInteger(null));
        assertEquals(Integer.valueOf(123), NumberUtils.createInteger("123"));
        assertEquals(Integer.valueOf(-123), NumberUtils.createInteger("-123"));
        // "handling hex and octal notations"
        assertEquals(Integer.valueOf(255), NumberUtils.createInteger("0xFF"));
        assertEquals(Integer.valueOf(63), NumberUtils.createInteger("077"));
    }

    @Test
    public void createIntegerRejectsInvalidInput() {
        assertCreateIntegerThrows("blah");
        assertCreateIntegerThrows("1.5");
        assertCreateIntegerThrows("99999999999"); // overflows int
    }

    // ------------------------------------------------------------------ createLong

    @Test
    public void createLongValid() {
        assertNull(NumberUtils.createLong(null));
        assertEquals(Long.valueOf(123L), NumberUtils.createLong("123"));
        assertEquals(Long.valueOf(-123L), NumberUtils.createLong("-123"));
        assertEquals(Long.valueOf(12345678901L), NumberUtils.createLong("12345678901"));
    }

    @Test
    public void createLongRejectsInvalidInput() {
        assertCreateLongThrows("blah");
        assertCreateLongThrows("1.5");
        assertCreateLongThrows("12345678901234567890123"); // overflows long
    }

    // ------------------------------------------------------------------ createFloat

    @Test
    public void createFloatValid() {
        assertNull(NumberUtils.createFloat(null));
        assertEquals(Float.valueOf(1.5f), NumberUtils.createFloat("1.5"));
        assertEquals(Float.valueOf(-2.5f), NumberUtils.createFloat("-2.5"));
    }

    @Test
    public void createFloatRejectsInvalidInput() {
        assertCreateFloatThrows("blah");
        assertCreateFloatThrows("1.2.3");
    }

    // ------------------------------------------------------------------ createDouble

    @Test
    public void createDoubleValid() {
        assertNull(NumberUtils.createDouble(null));
        assertEquals(Double.valueOf(1.5d), NumberUtils.createDouble("1.5"));
        assertEquals(Double.valueOf(-2.5d), NumberUtils.createDouble("-2.5"));
    }

    @Test
    public void createDoubleRejectsInvalidInput() {
        assertCreateDoubleThrows("blah");
        assertCreateDoubleThrows("1.2.3");
    }

    // ------------------------------------------------------------------ createBigInteger

    @Test
    public void createBigIntegerValid() {
        assertNull(NumberUtils.createBigInteger(null));
        assertEquals(new BigInteger("12345678901234567890"),
                NumberUtils.createBigInteger("12345678901234567890"));
        assertEquals(BigInteger.valueOf(-42L), NumberUtils.createBigInteger("-42"));
    }

    @Test
    public void createBigIntegerRejectsInvalidInput() {
        assertCreateBigIntegerThrows("blah");
        assertCreateBigIntegerThrows("1.5");
    }

    // ------------------------------------------------------------------ createBigDecimal

    @Test
    public void createBigDecimalValid() {
        assertNull(NumberUtils.createBigDecimal(null));
        assertEquals(new BigDecimal("1.5"), NumberUtils.createBigDecimal("1.5"));
        assertEquals(new BigDecimal("-2.25"), NumberUtils.createBigDecimal("-2.25"));
        assertEquals(new BigDecimal("100"), NumberUtils.createBigDecimal("100"));
    }

    @Test
    public void createBigDecimalRejectsInvalidInput() {
        assertCreateBigDecimalThrows("blah");
        assertCreateBigDecimalThrows("1.2.3");
    }

    // ------------------------------------------------------------------ min / max over arrays

    @Test
    public void longArrayMinMax() {
        assertEquals(1L, NumberUtils.min(new long[] {1L, 2L, 3L}));
        assertEquals(1L, NumberUtils.min(new long[] {3L, 2L, 1L}));
        assertEquals(-5L, NumberUtils.min(new long[] {-5L, 0L, 5L}));
        assertEquals(7L, NumberUtils.min(new long[] {7L}));

        assertEquals(3L, NumberUtils.max(new long[] {1L, 2L, 3L}));
        assertEquals(3L, NumberUtils.max(new long[] {3L, 2L, 1L}));
        assertEquals(5L, NumberUtils.max(new long[] {-5L, 0L, 5L}));
        assertEquals(7L, NumberUtils.max(new long[] {7L}));

        assertMinMaxIae((long[]) null);
        assertMinMaxIae(new long[0]);
    }

    @Test
    public void intArrayMinMax() {
        assertEquals(1, NumberUtils.min(new int[] {1, 2, 3}));
        assertEquals(1, NumberUtils.min(new int[] {3, 2, 1}));
        assertEquals(-5, NumberUtils.min(new int[] {-5, 0, 5}));
        assertEquals(9, NumberUtils.min(new int[] {9}));

        assertEquals(3, NumberUtils.max(new int[] {1, 2, 3}));
        assertEquals(3, NumberUtils.max(new int[] {3, 2, 1}));
        assertEquals(5, NumberUtils.max(new int[] {-5, 0, 5}));
        assertEquals(9, NumberUtils.max(new int[] {9}));

        assertMinMaxIae((int[]) null);
        assertMinMaxIae(new int[0]);
    }

    @Test
    public void shortArrayMinMax() {
        assertEquals(1, NumberUtils.min(new short[] {1, 2, 3}));
        assertEquals(-5, NumberUtils.min(new short[] {-5, 0, 5}));
        assertEquals(3, NumberUtils.max(new short[] {1, 2, 3}));
        assertEquals(5, NumberUtils.max(new short[] {-5, 0, 5}));

        assertMinMaxIae((short[]) null);
        assertMinMaxIae(new short[0]);
    }

    @Test
    public void byteArrayMinMax() {
        assertEquals(1, NumberUtils.min(new byte[] {1, 2, 3}));
        assertEquals(-5, NumberUtils.min(new byte[] {-5, 0, 5}));
        assertEquals(3, NumberUtils.max(new byte[] {1, 2, 3}));
        assertEquals(5, NumberUtils.max(new byte[] {-5, 0, 5}));

        assertMinMaxIae((byte[]) null);
        assertMinMaxIae(new byte[0]);
    }

    @Test
    public void doubleArrayMinMax() {
        assertEquals(1.0d, NumberUtils.min(new double[] {1.0d, 2.0d, 3.0d}), DELTA);
        assertEquals(0.5d, NumberUtils.min(new double[] {3.5d, 2.5d, 0.5d}), DELTA);
        assertEquals(-5.0d, NumberUtils.min(new double[] {-5.0d, 0.0d, 5.0d}), DELTA);
        assertEquals(9.0d, NumberUtils.min(new double[] {9.0d}), DELTA);

        assertEquals(3.0d, NumberUtils.max(new double[] {1.0d, 2.0d, 3.0d}), DELTA);
        assertEquals(5.0d, NumberUtils.max(new double[] {-5.0d, 0.0d, 5.0d}), DELTA);
        assertEquals(9.0d, NumberUtils.max(new double[] {9.0d}), DELTA);

        assertMinMaxIae((double[]) null);
        assertMinMaxIae(new double[0]);
    }

    @Test
    public void floatArrayMinMax() {
        assertEquals(1.0f, NumberUtils.min(new float[] {1.0f, 2.0f, 3.0f}), FDELTA);
        assertEquals(0.5f, NumberUtils.min(new float[] {3.5f, 2.5f, 0.5f}), FDELTA);
        assertEquals(-5.0f, NumberUtils.min(new float[] {-5.0f, 0.0f, 5.0f}), FDELTA);

        assertEquals(3.0f, NumberUtils.max(new float[] {1.0f, 2.0f, 3.0f}), FDELTA);
        assertEquals(5.0f, NumberUtils.max(new float[] {-5.0f, 0.0f, 5.0f}), FDELTA);

        assertMinMaxIae((float[]) null);
        assertMinMaxIae(new float[0]);
    }

    // ------------------------------------------------------------------ min / max of three values

    @Test
    public void threeLongsMinMax() {
        assertEquals(1L, NumberUtils.min(1L, 2L, 3L));
        assertEquals(1L, NumberUtils.min(3L, 2L, 1L));
        assertEquals(1L, NumberUtils.min(2L, 1L, 3L));
        assertEquals(-3L, NumberUtils.min(-1L, -2L, -3L));

        assertEquals(3L, NumberUtils.max(1L, 2L, 3L));
        assertEquals(3L, NumberUtils.max(3L, 2L, 1L));
        assertEquals(3L, NumberUtils.max(1L, 3L, 2L));
        assertEquals(5L, NumberUtils.max(5L, 5L, 5L));
    }

    @Test
    public void threeIntsMinMax() {
        assertEquals(1, NumberUtils.min(1, 2, 3));
        assertEquals(1, NumberUtils.min(3, 2, 1));
        assertEquals(1, NumberUtils.min(2, 1, 3));
        assertEquals(-3, NumberUtils.min(-1, -2, -3));

        assertEquals(3, NumberUtils.max(1, 2, 3));
        assertEquals(3, NumberUtils.max(3, 2, 1));
        assertEquals(3, NumberUtils.max(2, 3, 1));
    }

    @Test
    public void threeShortsMinMax() {
        assertEquals(1, NumberUtils.min((short) 1, (short) 2, (short) 3));
        assertEquals(1, NumberUtils.min((short) 3, (short) 1, (short) 2));
        assertEquals(3, NumberUtils.max((short) 1, (short) 2, (short) 3));
        assertEquals(3, NumberUtils.max((short) 2, (short) 3, (short) 1));
    }

    @Test
    public void threeBytesMinMax() {
        assertEquals(1, NumberUtils.min((byte) 1, (byte) 2, (byte) 3));
        assertEquals(1, NumberUtils.min((byte) 3, (byte) 1, (byte) 2));
        assertEquals(3, NumberUtils.max((byte) 1, (byte) 2, (byte) 3));
        assertEquals(3, NumberUtils.max((byte) 2, (byte) 3, (byte) 1));
    }

    @Test
    public void threeDoublesMinMax() {
        assertEquals(0.5d, NumberUtils.min(1.5d, 0.5d, 2.5d), DELTA);
        assertEquals(2.5d, NumberUtils.max(1.5d, 0.5d, 2.5d), DELTA);
        assertEquals(-2.5d, NumberUtils.min(-1.5d, -2.5d, -0.5d), DELTA);
        assertEquals(-0.5d, NumberUtils.max(-1.5d, -2.5d, -0.5d), DELTA);
    }

    @Test
    public void threeDoublesNaNPropagates() {
        // Javadoc: "If any value is NaN, NaN is returned."
        assertTrue(Double.isNaN(NumberUtils.min(Double.NaN, 1.0d, 2.0d)));
        assertTrue(Double.isNaN(NumberUtils.min(1.0d, Double.NaN, 2.0d)));
        assertTrue(Double.isNaN(NumberUtils.min(1.0d, 2.0d, Double.NaN)));
        assertTrue(Double.isNaN(NumberUtils.max(Double.NaN, 1.0d, 2.0d)));
        assertTrue(Double.isNaN(NumberUtils.max(1.0d, Double.NaN, 2.0d)));
        assertTrue(Double.isNaN(NumberUtils.max(1.0d, 2.0d, Double.NaN)));
    }

    @Test
    public void threeDoublesInfinityHandled() {
        // Javadoc: "Infinity is handled."
        assertEquals(Double.NEGATIVE_INFINITY,
                NumberUtils.min(1.0d, Double.NEGATIVE_INFINITY, 2.0d), 0.0d);
        assertEquals(Double.POSITIVE_INFINITY,
                NumberUtils.max(1.0d, Double.POSITIVE_INFINITY, 2.0d), 0.0d);
    }

    @Test
    public void threeFloatsMinMax() {
        assertEquals(0.5f, NumberUtils.min(1.5f, 0.5f, 2.5f), FDELTA);
        assertEquals(2.5f, NumberUtils.max(1.5f, 0.5f, 2.5f), FDELTA);
    }

    @Test
    public void threeFloatsNaNPropagates() {
        assertTrue(Float.isNaN(NumberUtils.min(Float.NaN, 1.0f, 2.0f)));
        assertTrue(Float.isNaN(NumberUtils.min(1.0f, Float.NaN, 2.0f)));
        assertTrue(Float.isNaN(NumberUtils.min(1.0f, 2.0f, Float.NaN)));
        assertTrue(Float.isNaN(NumberUtils.max(Float.NaN, 1.0f, 2.0f)));
        assertTrue(Float.isNaN(NumberUtils.max(1.0f, Float.NaN, 2.0f)));
        assertTrue(Float.isNaN(NumberUtils.max(1.0f, 2.0f, Float.NaN)));
    }

    // ------------------------------------------------------------------ isDigits

    @Test
    public void isDigits() {
        // Javadoc: "Null and empty String will return false."
        assertFalse(NumberUtils.isDigits(null));
        assertFalse(NumberUtils.isDigits(""));

        assertTrue(NumberUtils.isDigits("0"));
        assertTrue(NumberUtils.isDigits("12345"));

        assertFalse(NumberUtils.isDigits("1234.5"));
        assertFalse(NumberUtils.isDigits("-123"));
        assertFalse(NumberUtils.isDigits("+123"));
        assertFalse(NumberUtils.isDigits("12 34"));
        assertFalse(NumberUtils.isDigits(" 12"));
        assertFalse(NumberUtils.isDigits("abc"));
        assertFalse(NumberUtils.isDigits("12a34"));
    }

    // ------------------------------------------------------------------ isNumber

    @Test
    public void isNumberAcceptsValidNumbers() {
        assertTrue(NumberUtils.isNumber("1"));
        assertTrue(NumberUtils.isNumber("123"));
        assertTrue(NumberUtils.isNumber("-123"));
        assertTrue(NumberUtils.isNumber("12.34"));
        assertTrue(NumberUtils.isNumber("-12.34"));
        // scientific notation (explicitly listed as valid)
        assertTrue(NumberUtils.isNumber("1.2e3"));
        assertTrue(NumberUtils.isNumber("1.2E3"));
        assertTrue(NumberUtils.isNumber("1.2e-3"));
        // hexadecimal marked with the 0x qualifier (explicitly listed as valid)
        assertTrue(NumberUtils.isNumber("0x1A"));
        assertTrue(NumberUtils.isNumber("0xABCDEF"));
        // type qualifier (explicitly listed as valid, e.g. 123L)
        assertTrue(NumberUtils.isNumber("123L"));
        assertTrue(NumberUtils.isNumber("12.5f"));
        assertTrue(NumberUtils.isNumber("12.5d"));
        // large integral value
        assertTrue(NumberUtils.isNumber("12345678901234567890"));
    }

    @Test
    public void isNumberRejectsInvalidNumbers() {
        // Javadoc: "Null and empty String will return false."
        assertFalse(NumberUtils.isNumber(null));
        assertFalse(NumberUtils.isNumber(""));
        assertFalse(NumberUtils.isNumber("   "));
        assertFalse(NumberUtils.isNumber("abc"));
        assertFalse(NumberUtils.isNumber("1a"));
        assertFalse(NumberUtils.isNumber("12.34.56"));
        assertFalse(NumberUtils.isNumber("1,234"));
        assertFalse(NumberUtils.isNumber("12 34"));
        assertFalse(NumberUtils.isNumber(" 123"));
        assertFalse(NumberUtils.isNumber("123 "));
        assertFalse(NumberUtils.isNumber("--1"));
    }

    // ================================================================== helpers

    private static void assertCreateNumberThrows(final String input) {
        try {
            final Number result = NumberUtils.createNumber(input);
            fail("createNumber(\"" + input + "\") should throw NumberFormatException but returned " + result);
        } catch (final NumberFormatException expected) {
            // documented behaviour
        }
    }

    private static void assertCreateIntegerThrows(final String input) {
        try {
            final Integer result = NumberUtils.createInteger(input);
            fail("createInteger(\"" + input + "\") should throw NumberFormatException but returned " + result);
        } catch (final NumberFormatException expected) {
            // documented behaviour
        }
    }

    private static void assertCreateLongThrows(final String input) {
        try {
            final Long result = NumberUtils.createLong(input);
            fail("createLong(\"" + input + "\") should throw NumberFormatException but returned " + result);
        } catch (final NumberFormatException expected) {
            // documented behaviour
        }
    }

    private static void assertCreateFloatThrows(final String input) {
        try {
            final Float result = NumberUtils.createFloat(input);
            fail("createFloat(\"" + input + "\") should throw NumberFormatException but returned " + result);
        } catch (final NumberFormatException expected) {
            // documented behaviour
        }
    }

    private static void assertCreateDoubleThrows(final String input) {
        try {
            final Double result = NumberUtils.createDouble(input);
            fail("createDouble(\"" + input + "\") should throw NumberFormatException but returned " + result);
        } catch (final NumberFormatException expected) {
            // documented behaviour
        }
    }

    private static void assertCreateBigIntegerThrows(final String input) {
        try {
            final BigInteger result = NumberUtils.createBigInteger(input);
            fail("createBigInteger(\"" + input + "\") should throw NumberFormatException but returned " + result);
        } catch (final NumberFormatException expected) {
            // documented behaviour
        }
    }

    private static void assertCreateBigDecimalThrows(final String input) {
        try {
            final BigDecimal result = NumberUtils.createBigDecimal(input);
            fail("createBigDecimal(\"" + input + "\") should throw NumberFormatException but returned " + result);
        } catch (final NumberFormatException expected) {
            // documented behaviour
        }
    }

    private static void assertMinMaxIae(final long[] array) {
        try {
            NumberUtils.min(array);
            fail("min(long[]) should throw IllegalArgumentException for null/empty input");
        } catch (final IllegalArgumentException expected) {
            // documented behaviour
        }
        try {
            NumberUtils.max(array);
            fail("max(long[]) should throw IllegalArgumentException for null/empty input");
        } catch (final IllegalArgumentException expected) {
            // documented behaviour
        }
    }

    private static void assertMinMaxIae(final int[] array) {
        try {
            NumberUtils.min(array);
            fail("min(int[]) should throw IllegalArgumentException for null/empty input");
        } catch (final IllegalArgumentException expected) {
            // documented behaviour
        }
        try {
            NumberUtils.max(array);
            fail("max(int[]) should throw IllegalArgumentException for null/empty input");
        } catch (final IllegalArgumentException expected) {
            // documented behaviour
        }
    }

    private static void assertMinMaxIae(final short[] array) {
        try {
            NumberUtils.min(array);
            fail("min(short[]) should throw IllegalArgumentException for null/empty input");
        } catch (final IllegalArgumentException expected) {
            // documented behaviour
        }
        try {
            NumberUtils.max(array);
            fail("max(short[]) should throw IllegalArgumentException for null/empty input");
        } catch (final IllegalArgumentException expected) {
            // documented behaviour
        }
    }

    private static void assertMinMaxIae(final byte[] array) {
        try {
            NumberUtils.min(array);
            fail("min(byte[]) should throw IllegalArgumentException for null/empty input");
        } catch (final IllegalArgumentException expected) {
            // documented behaviour
        }
        try {
            NumberUtils.max(array);
            fail("max(byte[]) should throw IllegalArgumentException for null/empty input");
        } catch (final IllegalArgumentException expected) {
            // documented behaviour
        }
    }

    private static void assertMinMaxIae(final double[] array) {
        try {
            NumberUtils.min(array);
            fail("min(double[]) should throw IllegalArgumentException for null/empty input");
        } catch (final IllegalArgumentException expected) {
            // documented behaviour
        }
        try {
            NumberUtils.max(array);
            fail("max(double[]) should throw IllegalArgumentException for null/empty input");
        } catch (final IllegalArgumentException expected) {
            // documented behaviour
        }
    }

    private static void assertMinMaxIae(final float[] array) {
        try {
            NumberUtils.min(array);
            fail("min(float[]) should throw IllegalArgumentException for null/empty input");
        } catch (final IllegalArgumentException expected) {
            // documented behaviour
        }
        try {
            NumberUtils.max(array);
            fail("max(float[]) should throw IllegalArgumentException for null/empty input");
        } catch (final IllegalArgumentException expected) {
            // documented behaviour
        }
    }
}
