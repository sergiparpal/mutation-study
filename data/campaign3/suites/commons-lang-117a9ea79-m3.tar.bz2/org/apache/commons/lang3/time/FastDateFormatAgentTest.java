/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.FieldPosition;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link FastDateFormat}.
 */
class FastDateFormatAgentTest {

    private static final TimeZone GMT = TimeZone.getTimeZone("GMT");

    @Test
    void testGetInstanceSamePatternSameZoneSameLocaleReturnsCachedEqualInstance() {
        final FastDateFormat f1 = FastDateFormat.getInstance("yyyy-MM-dd", GMT, Locale.US);
        final FastDateFormat f2 = FastDateFormat.getInstance("yyyy-MM-dd", GMT, Locale.US);
        assertEquals(f1, f2);
        assertEquals(f1.hashCode(), f2.hashCode());
    }

    @Test
    void testGetInstanceNullPatternThrows() {
        assertThrows(NullPointerException.class, () -> FastDateFormat.getInstance(null, GMT, Locale.US));
    }

    @Test
    void testGetInstanceInvalidPatternThrows() {
        assertThrows(IllegalArgumentException.class, () -> FastDateFormat.getInstance("XXXX"));
    }

    @Test
    void testFormatDateCalendarAndMillisAgree() {
        final GregorianCalendar cal = new GregorianCalendar(GMT);
        cal.clear();
        cal.set(2020, Calendar.MARCH, 15, 10, 30, 45);
        final Date date = cal.getTime();
        final FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss", GMT);

        final String expected = "2020-03-15 10:30:45";
        assertEquals(expected, fdf.format(date));
        assertEquals(expected, fdf.format(cal));
        assertEquals(expected, fdf.format(date.getTime()));
    }

    @Test
    void testFormatIntoStringBuffer() {
        final FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd", GMT);
        final GregorianCalendar cal = new GregorianCalendar(GMT);
        cal.clear();
        cal.set(2020, Calendar.JANUARY, 1);
        final StringBuffer sb = new StringBuffer("prefix-");
        final StringBuffer result = fdf.format(cal, sb);
        assertEquals("prefix-2020-01-01", result.toString());
        assertTrue(sb == result);
    }

    @Test
    void testFormatObjectWithFieldPosition() {
        final FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd", GMT);
        final GregorianCalendar cal = new GregorianCalendar(GMT);
        cal.clear();
        cal.set(2020, Calendar.JANUARY, 1);
        final StringBuffer sb = new StringBuffer();
        final StringBuffer result = fdf.format((Object) cal.getTime(), sb, new FieldPosition(0));
        assertEquals("2020-01-01", result.toString());
    }

    @Test
    void testParseRoundTrip() throws ParseException {
        final FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd", GMT);
        final Date parsed = fdf.parse("2020-01-01");
        assertEquals("2020-01-01", fdf.format(parsed));
    }

    @Test
    void testParseInvalidThrowsParseException() {
        final FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd", GMT);
        final ParseException ex = assertThrows(ParseException.class, () -> fdf.parse("not-a-date"));
        assertTrue(ex.getErrorOffset() >= 0);
    }

    @Test
    void testParseWithParsePositionFailureLeavesIndexUnmoved() {
        final FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd", GMT);
        final ParsePosition pos = new ParsePosition(0);
        final Date result = fdf.parse("garbage", pos);
        assertEquals(null, result);
        assertTrue(pos.getErrorIndex() >= 0);
    }

    @Test
    void testParseWithCalendarOverload() {
        final FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd", GMT);
        final Calendar cal = Calendar.getInstance(GMT);
        cal.clear();
        final ParsePosition pos = new ParsePosition(0);
        final boolean success = fdf.parse("2020-01-01", pos, cal);
        assertTrue(success);
        assertEquals(2020, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));
        assertEquals(1, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseObject() throws ParseException {
        final FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd", GMT);
        final Object parsed = fdf.parseObject("2020-01-01");
        assertTrue(parsed instanceof Date);
        assertEquals("2020-01-01", fdf.format(parsed));
    }

    @Test
    void testParseObjectWithParsePosition() {
        final FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd", GMT);
        final Object parsed = fdf.parseObject("2020-01-01", new ParsePosition(0));
        assertNotNull(parsed);
        assertTrue(parsed instanceof Date);
    }

    @Test
    void testGetPatternGetLocaleGetTimeZone() {
        final FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd", GMT, Locale.US);
        assertEquals("yyyy-MM-dd", fdf.getPattern());
        assertEquals(Locale.US, fdf.getLocale());
        assertEquals(GMT, fdf.getTimeZone());
    }

    @Test
    void testEqualsAndHashCodeDistinguishPattern() {
        final FastDateFormat f1 = FastDateFormat.getInstance("yyyy-MM-dd", GMT);
        final FastDateFormat f2 = FastDateFormat.getInstance("dd-MM-yyyy", GMT);
        assertNotEquals(f1, f2);
        assertFalse(f1.equals(new Object()));
        assertFalse(f1.equals(null));
    }

    @Test
    void testToStringContainsPatternLocaleAndTimeZone() {
        final FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd", GMT, Locale.US);
        final String str = fdf.toString();
        assertTrue(str.contains("yyyy-MM-dd"));
        assertTrue(str.contains("GMT"));
    }

    @Test
    void testGetMaxLengthEstimatePositive() {
        final FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd");
        assertTrue(fdf.getMaxLengthEstimate() > 0);
    }

    @Test
    void testGetDateInstanceStyles() {
        final FastDateFormat fdf = FastDateFormat.getDateInstance(FastDateFormat.SHORT, GMT, Locale.US);
        assertNotNull(fdf.getPattern());
        final GregorianCalendar cal = new GregorianCalendar(GMT);
        cal.clear();
        cal.set(2004, Calendar.FEBRUARY, 3);
        assertEquals("2/3/04", fdf.format(cal));
    }

    @Test
    void testGetTimeInstanceAndGetDateTimeInstance() {
        final FastDateFormat time = FastDateFormat.getTimeInstance(FastDateFormat.SHORT, GMT, Locale.US);
        assertNotNull(time.format(new Date()));
        final FastDateFormat dateTime = FastDateFormat.getDateTimeInstance(FastDateFormat.SHORT, FastDateFormat.SHORT, GMT, Locale.US);
        assertNotNull(dateTime.format(new Date()));
    }

    @Test
    void testStyleConstantsMatchDateFormatConstants() {
        assertEquals(java.text.DateFormat.FULL, FastDateFormat.FULL);
        assertEquals(java.text.DateFormat.LONG, FastDateFormat.LONG);
        assertEquals(java.text.DateFormat.MEDIUM, FastDateFormat.MEDIUM);
        assertEquals(java.text.DateFormat.SHORT, FastDateFormat.SHORT);
    }
}
