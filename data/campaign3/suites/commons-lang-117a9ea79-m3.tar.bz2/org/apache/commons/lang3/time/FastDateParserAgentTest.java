/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link FastDateParser}.
 */
class FastDateParserAgentTest {

    private static final TimeZone GMT = TimeZone.getTimeZone("GMT");

    @Test
    void testConstructorNullPatternThrows() {
        assertThrows(NullPointerException.class, () -> new FastDateParser(null, GMT, Locale.US));
    }

    @Test
    void testConstructorNullTimeZoneThrows() {
        assertThrows(NullPointerException.class, () -> new FastDateParser("yyyy-MM-dd", null, Locale.US));
    }

    @Test
    void testConstructorNullLocaleDefaultsToSystemLocale() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, null);
        assertNotNull(parser.getLocale());
    }

    @Test
    void testParseRoundTrip() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final Date date = parser.parse("2020-03-15");
        final Calendar cal = Calendar.getInstance(GMT);
        cal.setTime(date);
        assertEquals(2020, cal.get(Calendar.YEAR));
        assertEquals(Calendar.MARCH, cal.get(Calendar.MONTH));
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseInvalidStringThrowsParseException() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final ParseException ex = assertThrows(ParseException.class, () -> parser.parse("not a date"));
        assertTrue(ex.getErrorOffset() >= 0);
        assertTrue(ex.getMessage().contains("not a date"));
    }

    @Test
    void testParseEmptyStringThrowsParseException() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        assertThrows(ParseException.class, () -> parser.parse(""));
    }

    @Test
    void testParseWithParsePositionBeyondLengthFails() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final ParsePosition pos = new ParsePosition(100);
        final Date result = parser.parse("2020-03-15", pos);
        assertNull(result);
        assertEquals(100, pos.getErrorIndex());
    }

    @Test
    void testParseWithParsePositionPartialConsumption() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date result = parser.parse("2020-03-15 extra text", pos);
        assertNotNull(result);
        assertEquals(10, pos.getIndex());
    }

    @Test
    void testParseWithParsePositionFailureSetsErrorIndex() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date result = parser.parse("garbage-data", pos);
        assertNull(result);
        assertTrue(pos.getErrorIndex() >= 0);
    }

    @Test
    void testParseIntoCalendarUpdatesFields() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd HH:mm:ss", GMT, Locale.US);
        final Calendar cal = Calendar.getInstance(GMT);
        cal.clear();
        final ParsePosition pos = new ParsePosition(0);
        final boolean success = parser.parse("2020-03-15 08:09:10", pos, cal);
        assertTrue(success);
        assertEquals(2020, cal.get(Calendar.YEAR));
        assertEquals(8, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals(9, cal.get(Calendar.MINUTE));
        assertEquals(10, cal.get(Calendar.SECOND));
    }

    @Test
    void testParseIntoCalendarFailureReturnsFalse() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final Calendar cal = Calendar.getInstance(GMT);
        final ParsePosition pos = new ParsePosition(0);
        final boolean success = parser.parse("xxxx-xx-xx", pos, cal);
        assertFalse(success);
    }

    @Test
    void testParseObjectReturnsDate() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final Object obj = parser.parseObject("2020-03-15");
        assertTrue(obj instanceof Date);
    }

    @Test
    void testParseObjectWithParsePositionReturnsDate() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final Object obj = parser.parseObject("2020-03-15", new ParsePosition(0));
        assertTrue(obj instanceof Date);
    }

    @Test
    void testTwoDigitYearCenturyAdjustment() throws ParseException {
        // centuryStart defines a rolling 100-year window [1980, 2079]: two-digit years from
        // 80-99 fall in 1980-1999, and two-digit years from 00-79 fall in 2000-2079.
        final GregorianCalendar centuryStart = new GregorianCalendar(1980, Calendar.JANUARY, 1);
        final FastDateParser parser = new FastDateParser("yy-MM-dd", GMT, Locale.US, centuryStart.getTime());
        final Calendar cal = Calendar.getInstance(GMT);

        cal.setTime(parser.parse("30-01-01"));
        assertEquals(2030, cal.get(Calendar.YEAR));

        cal.setTime(parser.parse("79-01-01"));
        assertEquals(2079, cal.get(Calendar.YEAR));

        cal.setTime(parser.parse("80-01-01"));
        assertEquals(1980, cal.get(Calendar.YEAR));

        cal.setTime(parser.parse("99-01-01"));
        assertEquals(1999, cal.get(Calendar.YEAR));
    }

    @Test
    void testGetPatternGetLocaleGetTimeZone() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        assertEquals("yyyy-MM-dd", parser.getPattern());
        assertEquals(Locale.US, parser.getLocale());
        assertEquals(GMT, parser.getTimeZone());
    }

    @Test
    void testGetTimeZoneReturnsDefensiveCopy() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final TimeZone tz = parser.getTimeZone();
        tz.setID("MUTATED");
        assertEquals("GMT", parser.getTimeZone().getID());
    }

    @Test
    void testEqualsAndHashCode() {
        final FastDateParser p1 = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final FastDateParser p2 = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final FastDateParser p3 = new FastDateParser("dd-MM-yyyy", GMT, Locale.US);

        assertEquals(p1, p2);
        assertEquals(p1.hashCode(), p2.hashCode());
        assertNotEquals(p1, p3);
        assertFalse(p1.equals(new Object()));
        assertFalse(p1.equals(null));
    }

    @Test
    void testToStringContainsPatternLocaleAndTimeZone() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final String str = parser.toString();
        assertTrue(str.contains("yyyy-MM-dd"));
        assertTrue(str.contains("GMT"));
    }

    @Test
    void testToStringAllContainsFieldNames() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final String str = parser.toStringAll();
        assertTrue(str.contains("pattern="));
        assertTrue(str.contains("timeZone="));
        assertTrue(str.contains("locale="));
    }

    @Test
    void testUnsupportedPatternLetterThrows() {
        assertThrows(IllegalArgumentException.class, () -> new FastDateParser("yyyy-QQ", GMT, Locale.US));
    }

    @Test
    void testWeekYearPatternResolvesWeekBasedYear() throws ParseException {
        final FastDateParser parser = new FastDateParser("YYYY-'W'ww-u", GMT, Locale.US);
        final Date date = parser.parse("2021-W01-1");
        assertNotNull(date);
    }
}
