/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.FieldPosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link FastDatePrinter}.
 */
class FastDatePrinterAgentTest {

    private static final TimeZone GMT = TimeZone.getTimeZone("GMT");

    private static Calendar gmtCalendar(final int year, final int month, final int day, final int hour, final int minute, final int second) {
        final Calendar cal = Calendar.getInstance(GMT);
        cal.clear();
        cal.set(year, month, day, hour, minute, second);
        return cal;
    }

    @Test
    void testConstructorNullTimeZoneThrows() {
        assertThrows(NullPointerException.class, () -> new FastDatePrinter("yyyy-MM-dd", null, Locale.US));
    }

    @Test
    void testConstructorNullLocaleDefaultsToSystemLocale() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", GMT, null);
        assertEquals(Locale.getDefault(), printer.getLocale());
    }

    @Test
    void testFormatDateCalendarAndMillisAgree() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd HH:mm:ss", GMT, Locale.US);
        final Calendar cal = gmtCalendar(2020, Calendar.MARCH, 15, 10, 30, 45);
        final Date date = cal.getTime();

        final String expected = "2020-03-15 10:30:45";
        assertEquals(expected, printer.format(date));
        assertEquals(expected, printer.format(cal));
        assertEquals(expected, printer.format(date.getTime()));
    }

    @Test
    void testFormatCalendarAppendableClonesRatherThanMutatesInput() {
        final TimeZone plus5 = TimeZone.getTimeZone("GMT+5");
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd HH:mm", GMT, Locale.US);
        final Calendar cal = Calendar.getInstance(plus5);
        cal.clear();
        cal.set(2020, Calendar.JANUARY, 1, 10, 0, 0);
        // the clone's fields are reinterpreted under the printer's time zone, so the wall-clock
        // values (10:00) are preserved verbatim rather than the instant being converted.
        assertEquals("2020-01-01 10:00", printer.format(cal));
        // the original calendar instance passed in must not be mutated
        assertEquals(plus5, cal.getTimeZone());
        assertEquals(10, cal.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    void testFormatCalendarStringBufferOverloadUsesPrinterTimeZone() {
        final TimeZone plus5 = TimeZone.getTimeZone("GMT+5");
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd HH:mm", GMT, Locale.US);
        final Calendar cal = Calendar.getInstance(plus5);
        cal.clear();
        cal.set(2020, Calendar.JANUARY, 1, 10, 0, 0);
        final StringBuffer sb = new StringBuffer();
        final StringBuffer result = printer.format(cal, sb);
        assertEquals("2020-01-01 05:00", result.toString());
        assertTrue(sb == result);
    }

    @Test
    void testFormatIntoAppendableReturnsSameInstance() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", GMT, Locale.US);
        final Calendar cal = gmtCalendar(2020, Calendar.JANUARY, 1, 0, 0, 0);
        final StringBuilder sb = new StringBuilder("prefix-");
        final StringBuilder result = printer.format(cal, sb);
        assertTrue(sb == result);
        assertEquals("prefix-2020-01-01", result.toString());
    }

    @Test
    void testFormatObjectSupportsDateCalendarAndLong() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", GMT, Locale.US);
        final Calendar cal = gmtCalendar(2020, Calendar.JANUARY, 1, 0, 0, 0);
        final Date date = cal.getTime();

        assertEquals("2020-01-01", printer.format((Object) date));
        assertEquals("2020-01-01", printer.format((Object) cal));
        assertEquals("2020-01-01", printer.format((Object) Long.valueOf(date.getTime())));
    }

    @Test
    void testFormatObjectUnsupportedTypeThrows() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", GMT, Locale.US);
        assertThrows(IllegalArgumentException.class, () -> printer.format((Object) "not a date"));
    }

    @Test
    void testFormatObjectStringBufferFieldPositionUnsupportedTypeThrows() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", GMT, Locale.US);
        assertThrows(IllegalArgumentException.class, () -> printer.format((Object) 3.14, new StringBuffer(), new FieldPosition(0)));
    }

    @Test
    void testFormatObjectStringBufferFieldPositionSupportsDateCalendarLong() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", GMT, Locale.US);
        final Calendar cal = gmtCalendar(2020, Calendar.JANUARY, 1, 0, 0, 0);
        final Date date = cal.getTime();

        StringBuffer sb = new StringBuffer();
        printer.format((Object) date, sb, new FieldPosition(0));
        assertEquals("2020-01-01", sb.toString());

        sb = new StringBuffer();
        printer.format((Object) cal, sb, new FieldPosition(0));
        assertEquals("2020-01-01", sb.toString());

        sb = new StringBuffer();
        printer.format((Object) Long.valueOf(date.getTime()), sb, new FieldPosition(0));
        assertEquals("2020-01-01", sb.toString());
    }

    @Test
    void testGetPatternGetLocaleGetTimeZone() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", GMT, Locale.US);
        assertEquals("yyyy-MM-dd", printer.getPattern());
        assertEquals(Locale.US, printer.getLocale());
        assertEquals(GMT, printer.getTimeZone());
    }

    @Test
    void testGetTimeZoneReturnsDefensiveCopy() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", GMT, Locale.US);
        final TimeZone tz = printer.getTimeZone();
        tz.setID("MUTATED");
        assertEquals("GMT", printer.getTimeZone().getID());
    }

    @Test
    void testGetMaxLengthEstimateCoversActualOutput() {
        final FastDatePrinter printer = new FastDatePrinter("EEEE, MMMM dd, yyyy HH:mm:ss.SSS zzzz", GMT, Locale.US);
        final Calendar cal = gmtCalendar(2020, Calendar.JANUARY, 1, 0, 0, 0);
        final String formatted = printer.format(cal);
        assertTrue(printer.getMaxLengthEstimate() >= formatted.length());
    }

    @Test
    void testEqualsAndHashCode() {
        final FastDatePrinter p1 = new FastDatePrinter("yyyy-MM-dd", GMT, Locale.US);
        final FastDatePrinter p2 = new FastDatePrinter("yyyy-MM-dd", GMT, Locale.US);
        final FastDatePrinter p3 = new FastDatePrinter("dd-MM-yyyy", GMT, Locale.US);

        assertEquals(p1, p2);
        assertEquals(p1.hashCode(), p2.hashCode());
        assertNotEquals(p1, p3);
        assertFalse(p1.equals(new Object()));
        assertFalse(p1.equals(null));
    }

    @Test
    void testToStringContainsPatternLocaleAndTimeZone() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", GMT, Locale.US);
        final String str = printer.toString();
        assertTrue(str.contains("yyyy-MM-dd"));
        assertTrue(str.contains("GMT"));
    }

    @Test
    void testUnsupportedPatternLetterThrowsIllegalArgumentException() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> new FastDatePrinter("QQ", GMT, Locale.US));
        assertTrue(ex.getMessage().contains("QQ"));
    }

    @Test
    void testParsePatternProducesOneRulePerToken() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", GMT, Locale.US);
        final List<?> rules = printer.parsePattern();
        // tokens: yyyy, -, MM, -, dd
        assertEquals(5, rules.size());
    }

    @Test
    void testParseTokenGroupsRepeatedLetters() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", GMT, Locale.US);
        final int[] indexRef = {0};
        final String token = printer.parseToken("yyyy-MM-dd", indexRef);
        assertEquals("yyyy", token);
        assertEquals(3, indexRef[0]);
    }

    @Test
    void testParseTokenLiteralStopsBeforeNextLetter() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", GMT, Locale.US);
        final int[] indexRef = {4};
        final String token = printer.parseToken("yyyy-MM-dd", indexRef);
        assertEquals("'-", token);
        assertEquals(4, indexRef[0]);
    }

    @Test
    void testSelectNumberRuleEstimateLengthMatchesPadding() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", GMT, Locale.US);
        final Object unpadded = printer.selectNumberRule(Calendar.DAY_OF_MONTH, 1);
        final Object twoDigit = printer.selectNumberRule(Calendar.DAY_OF_MONTH, 2);
        final Object padded5 = printer.selectNumberRule(Calendar.DAY_OF_MONTH, 5);

        assertFalse(unpadded.getClass().equals(twoDigit.getClass()));
        assertFalse(twoDigit.getClass().equals(padded5.getClass()));

        final Calendar cal = gmtCalendar(2020, Calendar.JANUARY, 3, 0, 0, 0);
        assertEquals("3", new FastDatePrinter("d", GMT, Locale.US).format(cal));
        assertEquals("03", new FastDatePrinter("dd", GMT, Locale.US).format(cal));
        assertEquals("00003", new FastDatePrinter("ddddd", GMT, Locale.US).format(cal));
    }

    @Test
    void testLowYearIsPaddedToFourDigits() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", GMT, Locale.US);
        final Calendar cal = gmtCalendar(1, Calendar.JANUARY, 1, 0, 0, 0);
        assertEquals("0001-01-01", printer.format(cal));
    }

    @Test
    void testTwoDigitYearPattern() {
        final FastDatePrinter printer = new FastDatePrinter("yy-MM-dd", GMT, Locale.US);
        final Calendar cal = gmtCalendar(2004, Calendar.FEBRUARY, 3, 0, 0, 0);
        assertEquals("04-02-03", printer.format(cal));
    }

    @Test
    void testTimeZoneOffsetPatterns() {
        final Calendar cal = gmtCalendar(2020, Calendar.JUNE, 1, 0, 0, 0);
        assertEquals("+0000", new FastDatePrinter("Z", GMT, Locale.US).format(cal));
        assertEquals("Z", new FastDatePrinter("ZZ", GMT, Locale.US).format(cal));
        assertEquals("+00:00", new FastDatePrinter("ZZZ", GMT, Locale.US).format(cal));
    }
}
