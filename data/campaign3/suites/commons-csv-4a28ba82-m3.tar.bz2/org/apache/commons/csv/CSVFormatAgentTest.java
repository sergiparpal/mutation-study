/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link CSVFormat}.
 */
class CSVFormatAgentTest {

    private enum HeaderEnum {
        Name, Email, Phone
    }

    @Test
    void testNewFormatBasicDefaults() {
        final CSVFormat format = CSVFormat.newFormat(';');
        assertEquals(";", format.getDelimiterString());
        assertNull(format.getQuoteCharacter());
        assertNull(format.getCommentMarker());
        assertNull(format.getEscapeCharacter());
        assertNull(format.getRecordSeparator());
        assertFalse(format.getIgnoreEmptyLines());
        assertFalse(format.getSkipHeaderRecord());
        assertFalse(format.isQuoteCharacterSet());
        assertFalse(format.isEscapeCharacterSet());
        assertFalse(format.isCommentMarkerSet());
        assertFalse(format.isNullStringSet());
    }

    @Test
    void testDefaultFormatValues() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertTrue(format.getIgnoreEmptyLines());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
    }

    @Test
    void testBuilderCreateFromFormatCopiesFields() {
        final CSVFormat original = CSVFormat.DEFAULT.builder().setDelimiter('|').setNullString("NULL").setHeader("a", "b").get();
        final CSVFormat copy = CSVFormat.Builder.create(original).get();
        assertEquals(original, copy);
        assertEquals("|", copy.getDelimiterString());
        assertEquals("NULL", copy.getNullString());
        assertArrayEquals(new String[] {"a", "b"}, copy.getHeader());
    }

    @Test
    void testSetDelimiterStringEmptyThrows() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                builder.setDelimiter("");
            }
        });
    }

    @Test
    void testSetDelimiterLineBreakThrows() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                builder.setDelimiter('\n');
            }
        });
    }

    @Test
    void testSetCommentMarkerLineBreakThrows() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                builder.setCommentMarker('\r');
            }
        });
    }

    @Test
    void testSetEscapeLineBreakThrows() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                builder.setEscape('\n');
            }
        });
    }

    @Test
    void testSetQuoteLineBreakThrows() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                builder.setQuote('\r');
            }
        });
    }

    @Test
    void testValidateQuoteCharSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVFormat.DEFAULT.builder().setDelimiter(',').setQuote(',').get();
            }
        });
    }

    @Test
    void testValidateEscapeSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVFormat.DEFAULT.builder().setDelimiter(';').setEscape(';').get();
            }
        });
    }

    @Test
    void testValidateCommentSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVFormat.DEFAULT.builder().setDelimiter('#').setCommentMarker('#').get();
            }
        });
    }

    @Test
    void testValidateQuoteSameAsCommentThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVFormat.DEFAULT.builder().setQuote('#').setCommentMarker('#').get();
            }
        });
    }

    @Test
    void testValidateEscapeSameAsCommentThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVFormat.DEFAULT.builder().setEscape('#').setCommentMarker('#').get();
            }
        });
    }

    @Test
    void testValidateQuoteModeNoneWithoutEscapeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVFormat.DEFAULT.builder().setQuoteMode(QuoteMode.NONE).get();
            }
        });
    }

    @Test
    void testValidateQuoteModeNoneWithEscapeSucceeds() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').setQuoteMode(QuoteMode.NONE).get();
        assertEquals(QuoteMode.NONE, format.getQuoteMode());
    }

    @Test
    void testValidateDuplicateHeaderDisallowThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).setHeader("a", "b", "a").get();
            }
        });
    }

    @Test
    void testValidateDuplicateHeaderAllowEmptyAllowsBlanks() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("a", "", "", "b").get();
        assertArrayEquals(new String[] {"a", "", "", "b"}, format.getHeader());
    }

    @Test
    void testValidateDuplicateHeaderAllowEmptyRejectsNonBlankDuplicate() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("a", "a").get();
            }
        });
    }

    @Test
    void testValidateDuplicateHeaderAllowAllPermitsDuplicates() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_ALL).setHeader("a", "a").get();
        assertArrayEquals(new String[] {"a", "a"}, format.getHeader());
    }

    @Test
    void testSetDuplicateHeaderModeNullThrows() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                builder.setDuplicateHeaderMode(null);
            }
        });
    }

    @Test
    void testSetHeaderFromEnumClass() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(HeaderEnum.class).get();
        assertArrayEquals(new String[] {"Name", "Email", "Phone"}, format.getHeader());
    }

    @Test
    void testSetHeaderFromNullEnumClassDisablesHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader((Class<? extends Enum<?>>) null).get();
        assertNull(format.getHeader());
    }

    @Test
    void testGetHeaderReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "b").get();
        final String[] header1 = format.getHeader();
        header1[0] = "mutated";
        final String[] header2 = format.getHeader();
        assertEquals("a", header2[0]);
    }

    @Test
    void testGetHeaderCommentsReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeaderComments("c1", "c2").get();
        final String[] comments1 = format.getHeaderComments();
        comments1[0] = "mutated";
        final String[] comments2 = format.getHeaderComments();
        assertEquals("c1", comments2[0]);
    }

    @Test
    void testGetHeaderCommentsFromObjects() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeaderComments("comment", Integer.valueOf(42), null).get();
        assertArrayEquals(new String[] {"comment", "42", null}, format.getHeaderComments());
    }

    @Test
    void testEqualsAndHashCode() {
        final CSVFormat a = CSVFormat.DEFAULT.builder().setDelimiter(';').setHeader("x", "y").get();
        final CSVFormat b = CSVFormat.DEFAULT.builder().setDelimiter(';').setHeader("x", "y").get();
        final CSVFormat c = CSVFormat.DEFAULT.builder().setDelimiter(',').setHeader("x", "y").get();
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
        assertNotEquals(a, c);
        assertNotEquals(a, null);
        assertNotEquals(a, "not a CSVFormat");
        assertEquals(a, a);
    }

    @Test
    void testBuilderGetReturnsNewFormatInstance() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        final CSVFormat format1 = builder.get();
        final CSVFormat format2 = builder.get();
        assertNotNull(format1);
        assertEquals(format1, format2);
    }

    @Test
    void testFormatMethod() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setRecordSeparator("\r\n").get();
        final String result = format.format("a", "b", "c");
        assertEquals("a,b,c", result);
    }

    @Test
    void testFormatMethodWithQuotingNeeded() {
        final String result = CSVFormat.DEFAULT.format("a,b", "c");
        assertEquals("\"a,b\",c", result);
    }

    @Test
    void testToStringContainsDelimiter() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').setNullString("NULL").get();
        final String str = format.toString();
        assertTrue(str.contains("Delimiter=<,>"));
        assertTrue(str.contains("CommentStart=<#>"));
        assertTrue(str.contains("NullString=<NULL>"));
    }

    @Test
    void testMaxRowsDefaultIsZeroAndUseMaxRowsFalse() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertEquals(0L, format.getMaxRows());
        assertFalse(format.useMaxRows());
    }

    @Test
    void testMaxRowsSetAndUseMaxRowsTrue() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(5L).get();
        assertEquals(5L, format.getMaxRows());
        assertTrue(format.useMaxRows());
        assertTrue(format.useRow(5L));
        assertFalse(format.useRow(6L));
    }

    @Test
    void testPredefinedFormatsFields() {
        assertEquals('\t', CSVFormat.MYSQL.getDelimiter());
        assertEquals('\t', CSVFormat.MYSQL.getDelimiterString().charAt(0));
        assertNull(CSVFormat.MYSQL.getQuoteCharacter());
        assertEquals("\\N", CSVFormat.MYSQL.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, CSVFormat.MYSQL.getQuoteMode());
        assertEquals(',', CSVFormat.RFC4180.getDelimiterString().charAt(0));
        assertFalse(CSVFormat.RFC4180.getIgnoreEmptyLines());
        assertTrue(CSVFormat.EXCEL.getAllowMissingColumnNames());
        assertTrue(CSVFormat.EXCEL.getTrailingData());
        assertTrue(CSVFormat.EXCEL.getLenientEof());
    }

    @Test
    void testValueOfAndPredefinedEnum() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.valueOf("Default"));
        assertEquals(CSVFormat.EXCEL, CSVFormat.Predefined.Excel.getFormat());
    }

    @Test
    void testValueOfInvalidNameThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVFormat.valueOf("NotAPredefinedFormat");
            }
        });
    }

    @Test
    void testWithHeaderDeprecatedStillWorks() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("a", "b");
        assertArrayEquals(new String[] {"a", "b"}, format.getHeader());
    }

    @Test
    void testWithNullStringDeprecated() {
        final CSVFormat format = CSVFormat.DEFAULT.withNullString("N/A");
        assertEquals("N/A", format.getNullString());
        assertTrue(format.isNullStringSet());
    }

    @Test
    void testWithFirstRecordAsHeaderResetsHeaderAndSkips() {
        final CSVFormat base = CSVFormat.DEFAULT.builder().setHeader("x", "y").get();
        final CSVFormat format = base.withFirstRecordAsHeader();
        assertArrayEquals(new String[] {}, format.getHeader());
        assertTrue(format.getSkipHeaderRecord());
    }

    @Test
    void testWithDelimiterDeprecated() {
        final CSVFormat format = CSVFormat.DEFAULT.withDelimiter('|');
        assertEquals("|", format.getDelimiterString());
    }

    @Test
    void testWithQuoteModeDeprecated() {
        final CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL);
        assertEquals(QuoteMode.ALL, format.getQuoteMode());
    }

    @Test
    void testWithTrailingDelimiterAndTrim() {
        final CSVFormat format = CSVFormat.DEFAULT.withTrailingDelimiter().withTrim();
        assertTrue(format.getTrailingDelimiter());
        assertTrue(format.getTrim());
    }

    @Test
    void testWithAllowDuplicateHeaderNamesDeprecated() {
        final CSVFormat trueFormat = CSVFormat.DEFAULT.withAllowDuplicateHeaderNames(true);
        assertTrue(trueFormat.getAllowDuplicateHeaderNames());
        final CSVFormat falseFormat = CSVFormat.DEFAULT.withAllowDuplicateHeaderNames(false);
        assertFalse(falseFormat.getAllowDuplicateHeaderNames());
    }

    @Test
    void testBuildDeprecatedDelegatesToGet() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create().setDelimiter('~');
        final CSVFormat built = builder.build();
        assertEquals("~", built.getDelimiterString());
    }

    @Test
    void testParseProducesWorkingParser() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "b").setSkipHeaderRecord(false).get();
        final CSVParser parser = format.parse(new StringReader("1,2\r\n3,4\r\n"));
        try {
            final java.util.List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("1", records.get(0).get("a"));
            assertEquals("4", records.get(1).get("b"));
        } finally {
            parser.close();
        }
    }

    @Test
    void testPrintAndPrintRecord() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT;
        format.printRecord(writer, "a", "b,c");
        assertEquals("a,\"b,c\"\r\n", writer.toString());
    }

    @Test
    void testPrintlnOutputsTrailingDelimiterAndSeparator() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).setRecordSeparator("\n").get();
        format.println(writer);
        assertEquals(",\n", writer.toString());
    }

    @Test
    void testPrintSingleValueWithNullSubstitution() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        format.print(null, writer, true);
        assertEquals("NULL", writer.toString());
    }

    @Test
    void testPrintSingleValueWithoutNullStringIsEmpty() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT;
        format.print(null, writer, true);
        assertEquals("", writer.toString());
    }

    @Test
    void testBuilderCreateDefaultSettings() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        final CSVFormat format = builder.get();
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertTrue(format.getIgnoreEmptyLines());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
    }

    @Test
    void testSetNullStringUpdatesQuotedNullStringBeforeQuote() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuote('\'').setNullString("NULL").setQuoteMode(QuoteMode.ALL).get();
        assertEquals("'NULL'", format.format((Object) null));
    }

}
