/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3.builder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Field;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang3.tuple.Pair;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link AbstractReflection}.
 */
class AbstractReflectionAgentTest {

    private static final String FORCE_ACCESSIBLE_PROPERTY = "AbstractReflection.forceAccessible";

    /**
     * Minimal concrete builder to allow instantiating {@link AbstractReflection}.
     */
    static final class ConcreteBuilder extends AbstractReflection.AbstractBuilder<ConcreteBuilder> {
        @Override
        public ConcreteReflection get() {
            return new ConcreteReflection(this);
        }
    }

    /**
     * Minimal concrete subclass exposing package-private instance behavior for testing.
     */
    static final class ConcreteReflection extends AbstractReflection {
        ConcreteReflection(final ConcreteBuilder builder) {
            super(builder);
        }
    }

    /**
     * Fixture class carrying fields with different accessibility levels.
     */
    static class Fixture {
        public int publicField;
        private int privateField;
    }

    private String originalForceAccessibleProperty;

    @BeforeEach
    void saveSystemProperty() {
        originalForceAccessibleProperty = System.getProperty(FORCE_ACCESSIBLE_PROPERTY);
    }

    @AfterEach
    void restoreSystemProperty() {
        if (originalForceAccessibleProperty == null) {
            System.clearProperty(FORCE_ACCESSIBLE_PROPERTY);
        } else {
            System.setProperty(FORCE_ACCESSIBLE_PROPERTY, originalForceAccessibleProperty);
        }
    }

    @Test
    void testGetForceAccessibleDefaultsToTrueWhenPropertyAbsent() {
        System.clearProperty(FORCE_ACCESSIBLE_PROPERTY);
        assertTrue(AbstractReflection.getForceAccessible());
    }

    @Test
    void testGetForceAccessibleHonorsSystemPropertyFalse() {
        System.setProperty(FORCE_ACCESSIBLE_PROPERTY, "false");
        assertFalse(AbstractReflection.getForceAccessible());
    }

    @Test
    void testGetForceAccessibleHonorsSystemPropertyTrue() {
        System.setProperty(FORCE_ACCESSIBLE_PROPERTY, "true");
        assertTrue(AbstractReflection.getForceAccessible());
    }

    @Test
    void testGetForceAccessibleWithGarbageValueIsFalse() {
        // Boolean.parseBoolean() treats anything other than "true" (ignoring case) as false.
        System.setProperty(FORCE_ACCESSIBLE_PROPERTY, "not-a-boolean");
        assertFalse(AbstractReflection.getForceAccessible());
    }

    @Test
    void testSetAccessibleStaticWithNullAccessibleObjectReturnsFalse() {
        assertFalse(AbstractReflection.setAccessible(true, null));
        assertFalse(AbstractReflection.setAccessible(false, null));
    }

    @Test
    void testSetAccessibleStaticWithoutForceLeavesInaccessibleFieldUntouched() throws Exception {
        final Field field = Fixture.class.getDeclaredField("privateField");
        assertFalse(field.isAccessible());
        final boolean result = AbstractReflection.setAccessible(false, field);
        assertFalse(result);
        assertFalse(field.isAccessible());
    }

    @Test
    void testSetAccessibleStaticWithForceMakesInaccessibleFieldAccessible() throws Exception {
        final Field field = Fixture.class.getDeclaredField("privateField");
        assertFalse(field.isAccessible());
        final boolean result = AbstractReflection.setAccessible(true, field);
        assertTrue(result);
        assertTrue(field.isAccessible());
    }

    @Test
    void testSetAccessibleStaticShortCircuitsWhenAlreadyAccessible() throws Exception {
        final Field field = Fixture.class.getDeclaredField("publicField");
        field.setAccessible(true);
        assertTrue(field.isAccessible());
        // Even with forceAccessible false, an already-accessible object stays accessible.
        final boolean result = AbstractReflection.setAccessible(false, field);
        assertTrue(result);
        assertTrue(field.isAccessible());
    }

    @Test
    void testAbstractBuilderDefaultForceAccessibleMatchesGetForceAccessible() {
        System.clearProperty(FORCE_ACCESSIBLE_PROPERTY);
        final ConcreteBuilder builder = new ConcreteBuilder();
        final ConcreteReflection reflection = builder.get();
        assertTrue(reflection.isForceAccessible());
    }

    @Test
    void testAbstractBuilderSetForceAccessibleReturnsSameInstanceForChaining() {
        final ConcreteBuilder builder = new ConcreteBuilder();
        final ConcreteBuilder returned = builder.setForceAccessible(false);
        assertSame(builder, returned);
    }

    @Test
    void testAbstractBuilderSetForceAccessibleFalsePropagatesToInstance() {
        final ConcreteBuilder builder = new ConcreteBuilder();
        builder.setForceAccessible(false);
        final ConcreteReflection reflection = builder.get();
        assertFalse(reflection.isForceAccessible());
    }

    @Test
    void testAbstractBuilderSetForceAccessibleTruePropagatesToInstance() {
        final ConcreteBuilder builder = new ConcreteBuilder();
        builder.setForceAccessible(true);
        final ConcreteReflection reflection = builder.get();
        assertTrue(reflection.isForceAccessible());
    }

    @Test
    void testInstanceSetAccessibleWithoutForceLeavesFieldInaccessible() throws Exception {
        final Field field = Fixture.class.getDeclaredField("privateField");
        assertFalse(field.isAccessible());
        final ConcreteBuilder builder = new ConcreteBuilder();
        builder.setForceAccessible(false);
        final ConcreteReflection reflection = builder.get();
        final boolean result = reflection.setAccessible(field);
        assertFalse(result);
        assertFalse(field.isAccessible());
    }

    @Test
    void testInstanceSetAccessibleWithForceMakesFieldAccessible() throws Exception {
        final Field field = Fixture.class.getDeclaredField("privateField");
        assertFalse(field.isAccessible());
        final ConcreteBuilder builder = new ConcreteBuilder();
        builder.setForceAccessible(true);
        final ConcreteReflection reflection = builder.get();
        final boolean result = reflection.setAccessible(field);
        assertTrue(result);
        assertTrue(field.isAccessible());
    }

    @Test
    void testIsRegisteredFalseForEmptyOrNullRegistry() {
        final Object lhs = new Object();
        final Object rhs = new Object();
        final Set<Pair<IDKey, IDKey>> registry = new HashSet<Pair<IDKey, IDKey>>();
        assertFalse(AbstractReflection.isRegistered(lhs, rhs, registry));
        assertFalse(AbstractReflection.isRegistered(lhs, rhs, null));
    }

    @Test
    void testRegisterAndIsRegisteredDetectsBothOrientations() {
        final Object lhs = new Object();
        final Object rhs = new Object();
        final Set<Pair<IDKey, IDKey>> registry = new HashSet<Pair<IDKey, IDKey>>();
        AbstractReflection.register(lhs, rhs, registry);
        assertEquals(1, registry.size());
        assertTrue(AbstractReflection.isRegistered(lhs, rhs, registry));
        assertTrue(AbstractReflection.isRegistered(rhs, lhs, registry));
    }

    @Test
    void testIsRegisteredFalseForUnrelatedPair() {
        final Object lhs = new Object();
        final Object rhs = new Object();
        final Object other = new Object();
        final Set<Pair<IDKey, IDKey>> registry = new HashSet<Pair<IDKey, IDKey>>();
        AbstractReflection.register(lhs, rhs, registry);
        assertFalse(AbstractReflection.isRegistered(lhs, other, registry));
        assertFalse(AbstractReflection.isRegistered(other, rhs, registry));
    }

    @Test
    void testToRegisterPairWrapsValuesAsIDKeys() {
        final Object lhs = new Object();
        final Object rhs = new Object();
        final Pair<IDKey, IDKey> pair = AbstractReflection.toRegisterPair(lhs, rhs);
        assertEquals(new IDKey(lhs), pair.getLeft());
        assertEquals(new IDKey(rhs), pair.getRight());
    }

    @Test
    void testUnregisterRemovesPairAndClearsThreadLocalWhenEmpty() {
        final Object lhs = new Object();
        final Object rhs = new Object();
        final Set<Pair<IDKey, IDKey>> registry = new HashSet<Pair<IDKey, IDKey>>();
        final ThreadLocal<Set<Pair<IDKey, IDKey>>> registryTL = new ThreadLocal<Set<Pair<IDKey, IDKey>>>();
        registryTL.set(registry);
        AbstractReflection.register(lhs, rhs, registry);
        AbstractReflection.unregister(lhs, rhs, registry, registryTL);
        assertTrue(registry.isEmpty());
        assertNull(registryTL.get());
    }

    @Test
    void testUnregisterKeepsThreadLocalWhenRegistryStillNonEmpty() {
        final Object lhs1 = new Object();
        final Object rhs1 = new Object();
        final Object lhs2 = new Object();
        final Object rhs2 = new Object();
        final Set<Pair<IDKey, IDKey>> registry = new HashSet<Pair<IDKey, IDKey>>();
        final ThreadLocal<Set<Pair<IDKey, IDKey>>> registryTL = new ThreadLocal<Set<Pair<IDKey, IDKey>>>();
        registryTL.set(registry);
        AbstractReflection.register(lhs1, rhs1, registry);
        AbstractReflection.register(lhs2, rhs2, registry);
        AbstractReflection.unregister(lhs1, rhs1, registry, registryTL);
        assertEquals(1, registry.size());
        assertFalse(AbstractReflection.isRegistered(lhs1, rhs1, registry));
        assertTrue(AbstractReflection.isRegistered(lhs2, rhs2, registry));
        assertSame(registry, registryTL.get());
    }
}
