/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.annotation.Annotation;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Collection;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link AnnotationUtils}.
 */
class AnnotationUtilsAgentTest {

    public enum Color {
        RED, GREEN, BLUE
    }

    @Retention(RetentionPolicy.RUNTIME)
    @Target({ElementType.FIELD, ElementType.METHOD})
    public @interface Nested {
        String tag();
    }

    @Retention(RetentionPolicy.RUNTIME)
    @Target({ElementType.FIELD, ElementType.METHOD})
    public @interface Comprehensive {
        boolean boolVal();
        boolean[] boolArr();
        byte byteVal();
        byte[] byteArr();
        char charVal();
        char[] charArr();
        Class<?> classVal();
        Color colorVal();
        double doubleVal();
        double[] doubleArr();
        float floatVal();
        float[] floatArr();
        int intVal();
        int[] intArr();
        long longVal();
        long[] longArr();
        Nested nested();
        Nested[] nestedArr();
        short shortVal();
        short[] shortArr();
        String stringVal();
        String[] stringArr();
    }

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.FIELD)
    public @interface IntArrayHolder {
        int[] values();
    }

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.FIELD)
    public @interface NullBreaker {
        String value();
    }

    @Comprehensive(
            boolVal = true,
            boolArr = { true, false },
            byteVal = 1,
            byteArr = { 1, 2 },
            charVal = 'a',
            charArr = { 'a', 'b' },
            classVal = Object.class,
            colorVal = Color.RED,
            doubleVal = 1.5,
            doubleArr = { 1.5, 2.5 },
            floatVal = 1.5f,
            floatArr = { 1.5f, 2.5f },
            intVal = 1,
            intArr = { 1, 2, 3 },
            longVal = 1L,
            longArr = { 1L, 2L },
            nested = @Nested(tag = "n1"),
            nestedArr = { @Nested(tag = "a"), @Nested(tag = "b") },
            shortVal = 1,
            shortArr = { 1, 2 },
            stringVal = "one",
            stringArr = { "one", "two" }
    )
    private int comprehensiveA;

    @Comprehensive(
            boolVal = true,
            boolArr = { true, false },
            byteVal = 1,
            byteArr = { 1, 2 },
            charVal = 'a',
            charArr = { 'a', 'b' },
            classVal = Object.class,
            colorVal = Color.RED,
            doubleVal = 1.5,
            doubleArr = { 1.5, 2.5 },
            floatVal = 1.5f,
            floatArr = { 1.5f, 2.5f },
            intVal = 1,
            intArr = { 1, 2, 3 },
            longVal = 1L,
            longArr = { 1L, 2L },
            nested = @Nested(tag = "n1"),
            nestedArr = { @Nested(tag = "a"), @Nested(tag = "b") },
            shortVal = 1,
            shortArr = { 1, 2 },
            stringVal = "one",
            stringArr = { "one", "two" }
    )
    private int comprehensiveB;

    @Comprehensive(
            boolVal = false,
            boolArr = { true, false },
            byteVal = 1,
            byteArr = { 1, 2 },
            charVal = 'a',
            charArr = { 'a', 'b' },
            classVal = Object.class,
            colorVal = Color.BLUE,
            doubleVal = 1.5,
            doubleArr = { 1.5, 2.5 },
            floatVal = 1.5f,
            floatArr = { 1.5f, 2.5f },
            intVal = 99,
            intArr = { 1, 2, 3 },
            longVal = 1L,
            longArr = { 1L, 2L },
            nested = @Nested(tag = "different"),
            nestedArr = { @Nested(tag = "a"), @Nested(tag = "b") },
            shortVal = 1,
            shortArr = { 1, 2 },
            stringVal = "different",
            stringArr = { "one", "two" }
    )
    private int comprehensiveC;

    @IntArrayHolder(values = { 1, 2, 3 })
    private int shortArrayField;

    @IntArrayHolder(values = { 1, 2 })
    private int longerArrayField;

    @Nested(tag = "standalone")
    private int nestedOnly;

    private Comprehensive getComprehensive(final String fieldName) throws NoSuchFieldException {
        final Field field = getClass().getDeclaredField(fieldName);
        return field.getAnnotation(Comprehensive.class);
    }

    @Test
    void testEqualsSameReferenceEvenIfNull() {
        assertTrue(AnnotationUtils.equals(null, null));
    }

    @Test
    void testEqualsOneNullReturnsFalse() throws Exception {
        final Comprehensive a = getComprehensive("comprehensiveA");
        assertFalse(AnnotationUtils.equals(a, null));
        assertFalse(AnnotationUtils.equals(null, a));
    }

    @Test
    void testEqualsSameInstanceReturnsTrue() throws Exception {
        final Comprehensive a = getComprehensive("comprehensiveA");
        assertTrue(AnnotationUtils.equals(a, a));
    }

    @Test
    void testEqualsDifferentAnnotationTypesReturnsFalse() throws Exception {
        final Comprehensive comprehensive = getComprehensive("comprehensiveA");
        final Nested nested = getClass().getDeclaredField("nestedOnly").getAnnotation(Nested.class);
        assertFalse(AnnotationUtils.equals(comprehensive, nested));
        assertFalse(AnnotationUtils.equals(nested, comprehensive));
    }

    @Test
    void testEqualsEquivalentComprehensiveAnnotations() throws Exception {
        final Comprehensive a = getComprehensive("comprehensiveA");
        final Comprehensive b = getComprehensive("comprehensiveB");
        assertTrue(AnnotationUtils.equals(a, b));
        assertTrue(AnnotationUtils.equals(b, a));
    }

    @Test
    void testEqualsNonEquivalentComprehensiveAnnotations() throws Exception {
        final Comprehensive a = getComprehensive("comprehensiveA");
        final Comprehensive c = getComprehensive("comprehensiveC");
        assertFalse(AnnotationUtils.equals(a, c));
        assertFalse(AnnotationUtils.equals(c, a));
    }

    @Test
    void testEqualsPrimitiveArrayMembersWithDifferentLengthsReturnsFalse() throws Exception {
        final IntArrayHolder shortOne = getClass().getDeclaredField("shortArrayField").getAnnotation(IntArrayHolder.class);
        final IntArrayHolder longOne = getClass().getDeclaredField("longerArrayField").getAnnotation(IntArrayHolder.class);
        assertFalse(AnnotationUtils.equals(shortOne, longOne));
        assertFalse(AnnotationUtils.equals(longOne, shortOne));
    }

    @Test
    void testHashCodeMatchesRealAnnotationHashCode() throws Exception {
        final Comprehensive a = getComprehensive("comprehensiveA");
        assertEquals(a.hashCode(), AnnotationUtils.hashCode(a));
        final Comprehensive c = getComprehensive("comprehensiveC");
        assertEquals(c.hashCode(), AnnotationUtils.hashCode(c));
    }

    @Test
    void testHashCodeConsistentForEquivalentAnnotations() throws Exception {
        final Comprehensive a = getComprehensive("comprehensiveA");
        final Comprehensive b = getComprehensive("comprehensiveB");
        assertEquals(AnnotationUtils.hashCode(a), AnnotationUtils.hashCode(b));
    }

    @Test
    void testHashCodeThrowsIllegalStateExceptionOnNullMember() {
        final InvocationHandler handler = new InvocationHandler() {
            @Override
            public Object invoke(final Object proxy, final Method method, final Object[] args) {
                final String name = method.getName();
                if ("value".equals(name)) {
                    return null;
                }
                if ("annotationType".equals(name)) {
                    return NullBreaker.class;
                }
                if ("hashCode".equals(name)) {
                    return Integer.valueOf(System.identityHashCode(proxy));
                }
                if ("equals".equals(name)) {
                    return Boolean.valueOf(proxy == args[0]);
                }
                if ("toString".equals(name)) {
                    return "NullBreakerProxy";
                }
                return null;
            }
        };
        final NullBreaker brokenAnnotation = (NullBreaker) Proxy.newProxyInstance(
                Thread.currentThread().getContextClassLoader(), new Class[] { NullBreaker.class }, handler);
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                AnnotationUtils.hashCode(brokenAnnotation);
            }
        });
    }

    @Test
    void testToStringFormat() throws Exception {
        final Nested nested = getClass().getDeclaredField("nestedOnly").getAnnotation(Nested.class);
        final String result = AnnotationUtils.toString(nested);
        assertNotNull(result);
        assertTrue(result.startsWith("@" + Nested.class.getName() + "("));
        assertTrue(result.endsWith(")"));
        assertTrue(result.contains("tag=standalone"));
    }

    @Test
    void testToStringContainsSeparatorAndNestedAnnotation() throws Exception {
        final Comprehensive comprehensive = getComprehensive("comprehensiveA");
        final String result = AnnotationUtils.toString(comprehensive);
        assertTrue(result.contains(", "));
        assertTrue(result.contains("@" + Nested.class.getName() + "(tag=n1)"));
        assertTrue(result.contains("stringVal=one"));
    }

    @Test
    void testIsValidAnnotationMemberTypeNullReturnsFalse() {
        assertFalse(AnnotationUtils.isValidAnnotationMemberType(null));
    }

    @Test
    void testIsValidAnnotationMemberTypePrimitivesAndWellKnownTypes() {
        final Class<?>[] validTypes = { byte.class, short.class, int.class, char.class, long.class,
                float.class, double.class, boolean.class, String.class, Class.class, Color.class, Nested.class };
        for (final Class<?> type : validTypes) {
            assertTrue(AnnotationUtils.isValidAnnotationMemberType(type), type.getName());
        }
    }

    @Test
    void testIsValidAnnotationMemberTypeArraysOfValidTypes() {
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(int[].class));
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(String[].class));
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(Color[].class));
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(Nested[].class));
    }

    @Test
    void testIsValidAnnotationMemberTypeInvalidTypes() {
        assertFalse(AnnotationUtils.isValidAnnotationMemberType(Object.class));
        assertFalse(AnnotationUtils.isValidAnnotationMemberType(List.class));
        assertFalse(AnnotationUtils.isValidAnnotationMemberType(Collection.class));
        assertFalse(AnnotationUtils.isValidAnnotationMemberType(Object[].class));
    }

    @Test
    void testDeprecatedPublicConstructorIsUsable() {
        final AnnotationUtils instance = new AnnotationUtils();
        assertNotNull(instance);
    }

    @Test
    void testEqualsHandlesAnnotationArrayComponentType() throws Exception {
        // Exercises the Annotation[] branch of equals() via the nestedArr member.
        final Comprehensive a = getComprehensive("comprehensiveA");
        final Comprehensive b = getComprehensive("comprehensiveB");
        assertTrue(AnnotationUtils.equals(a, b));
        assertTrue(a.nestedArr().length == 2);
    }

    @Test
    void testAnnotationTypeOfProxyMustNotBeNull() {
        // Validate.notNull guards: a proxy whose annotationType() returns null must be rejected.
        final InvocationHandler handler = new InvocationHandler() {
            @Override
            public Object invoke(final Object proxy, final Method method, final Object[] args) {
                final String name = method.getName();
                if ("annotationType".equals(name)) {
                    return null;
                }
                if ("value".equals(name)) {
                    return "x";
                }
                if ("equals".equals(name)) {
                    return Boolean.valueOf(proxy == args[0]);
                }
                if ("hashCode".equals(name)) {
                    return Integer.valueOf(System.identityHashCode(proxy));
                }
                return "proxy";
            }
        };
        final NullBreaker proxyWithNullType = (NullBreaker) Proxy.newProxyInstance(
                Thread.currentThread().getContextClassLoader(), new Class[] { NullBreaker.class }, handler);
        final NullBreaker other = (NullBreaker) Proxy.newProxyInstance(
                Thread.currentThread().getContextClassLoader(), new Class[] { NullBreaker.class }, handler);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                AnnotationUtils.equals(proxyWithNullType, other);
            }
        });
    }
}
