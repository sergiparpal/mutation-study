/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.UUID;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link Conversion}.
 */
public class ConversionAgentTest {

    @Test
    public void testBinaryBeMsb0ToHexDigit() {
        assertEquals('8', Conversion.binaryBeMsb0ToHexDigit(new boolean[] { true, false, false, false }));
        assertEquals('0', Conversion.binaryBeMsb0ToHexDigit(new boolean[] { false, false, false, false }));
        assertEquals('f', Conversion.binaryBeMsb0ToHexDigit(new boolean[] { true, true, true, true }));
        // from javadoc example, srcPos = 2 selects the sub-array {1,0,1,0} resulting in '5'
        assertEquals('5', Conversion.binaryBeMsb0ToHexDigit(
                new boolean[] { false, false, false, false, false, false, false, false, false, false, false, true, false, true, false, false }, 2));
    }

    @Test
    public void testBinaryBeMsb0ToHexDigitEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Conversion.binaryBeMsb0ToHexDigit(new boolean[0]);
            }
        });
    }

    @Test
    public void testBinaryBeMsb0ToHexDigitOutOfBoundsThrows() {
        assertThrows(IndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Conversion.binaryBeMsb0ToHexDigit(new boolean[] { true, false, false, false }, 4);
            }
        });
    }

    @Test
    public void testBinaryBeMsb0ToHexDigitNullThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Conversion.binaryBeMsb0ToHexDigit(null);
            }
        });
    }

    @Test
    public void testBinaryToByte() {
        final boolean[] src = { true, false, true, true };
        final byte result = Conversion.binaryToByte(src, 0, (byte) 0, 0, 4);
        assertEquals((byte) 0b1101, result);
    }

    @Test
    public void testBinaryToByteZeroNBoolsReturnsDstInit() {
        assertEquals((byte) 42, Conversion.binaryToByte(new boolean[0], 0, (byte) 42, 0, 0));
    }

    @Test
    public void testBinaryToByteEmptySrcPosZeroReturnsDstInit() {
        assertEquals((byte) 7, Conversion.binaryToByte(new boolean[0], 0, (byte) 7, 0, 0));
    }

    @Test
    public void testBinaryToByteOutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Conversion.binaryToByte(new boolean[] { true, true, true, true, true, true, true, true, true }, 0, (byte) 0, 1, 8);
            }
        });
    }

    @Test
    public void testBinaryToByteArrayIndexOutOfBoundsThrows() {
        assertThrows(ArrayIndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Conversion.binaryToByte(new boolean[] { true, false }, 0, (byte) 0, 0, 4);
            }
        });
    }

    @Test
    public void testBinaryToHexDigit() {
        assertEquals('1', Conversion.binaryToHexDigit(new boolean[] { true, false, false, false }));
        assertEquals('f', Conversion.binaryToHexDigit(new boolean[] { true, true, true, true }));
        assertEquals('0', Conversion.binaryToHexDigit(new boolean[] { false }));
    }

    @Test
    public void testBinaryToHexDigitWithPos() {
        final boolean[] src = { false, false, true, false, false, false };
        assertEquals('1', Conversion.binaryToHexDigit(src, 2));
    }

    @Test
    public void testBinaryToHexDigitEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Conversion.binaryToHexDigit(new boolean[0]);
            }
        });
    }

    @Test
    public void testBinaryToHexDigitMsb0_4bits() {
        assertEquals('8', Conversion.binaryToHexDigitMsb0_4bits(new boolean[] { true, false, false, false }));
        assertEquals('0', Conversion.binaryToHexDigitMsb0_4bits(new boolean[] { false, false, false, false }));
        assertEquals('9', Conversion.binaryToHexDigitMsb0_4bits(new boolean[] { false, false, false, true, false, false, true, false }, 3));
    }

    @Test
    public void testBinaryToHexDigitMsb0_4bitsTooLongThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Conversion.binaryToHexDigitMsb0_4bits(new boolean[9]);
            }
        });
    }

    @Test
    public void testBinaryToHexDigitMsb0_4bitsTooShortThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Conversion.binaryToHexDigitMsb0_4bits(new boolean[] { true, false, false }, 0);
            }
        });
    }

    @Test
    public void testBinaryToInt() {
        final boolean[] src = { true, false, true, true };
        final int result = Conversion.binaryToInt(src, 0, 0, 0, 4);
        assertEquals(0b1101, result);
    }

    @Test
    public void testBinaryToIntZeroNBoolsReturnsDstInit() {
        assertEquals(99, Conversion.binaryToInt(new boolean[0], 0, 99, 0, 0));
    }

    @Test
    public void testBinaryToIntOutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Conversion.binaryToInt(new boolean[32], 0, 0, 1, 32);
            }
        });
    }

    @Test
    public void testBinaryToLong() {
        final boolean[] src = { true, false, true, true };
        final long result = Conversion.binaryToLong(src, 0, 0L, 0, 4);
        assertEquals(0b1101L, result);
    }

    @Test
    public void testBinaryToLongOutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Conversion.binaryToLong(new boolean[64], 0, 0L, 1, 64);
            }
        });
    }

    @Test
    public void testBinaryToShort() {
        final boolean[] src = { true, false, true, true };
        final short result = Conversion.binaryToShort(src, 0, (short) 0, 0, 4);
        assertEquals((short) 0b1101, result);
    }

    @Test
    public void testBinaryToShortOutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Conversion.binaryToShort(new boolean[16], 0, (short) 0, 1, 16);
            }
        });
    }

    @Test
    public void testByteArrayToInt() {
        final byte[] src = { (byte) 0xFF, 0x00 };
        final int result = Conversion.byteArrayToInt(src, 0, 0, 0, 2);
        assertEquals(0x00FF, result);
    }

    @Test
    public void testByteArrayToIntZeroNBytesReturnsDstInit() {
        assertEquals(123, Conversion.byteArrayToInt(new byte[0], 0, 123, 0, 0));
    }

    @Test
    public void testByteArrayToIntOutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Conversion.byteArrayToInt(new byte[4], 0, 0, 8, 4);
            }
        });
    }

    @Test
    public void testByteArrayToLong() {
        final byte[] src = { 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08 };
        final long result = Conversion.byteArrayToLong(src, 0, 0L, 0, 8);
        assertEquals(0x0807060504030201L, result);
    }

    @Test
    public void testByteArrayToShort() {
        final byte[] src = { 0x01, 0x02 };
        final short result = Conversion.byteArrayToShort(src, 0, (short) 0, 0, 2);
        assertEquals((short) 0x0201, result);
    }

    @Test
    public void testByteArrayToUuid() {
        final byte[] src = new byte[16];
        for (int i = 0; i < 16; i++) {
            src[i] = (byte) i;
        }
        final UUID uuid = Conversion.byteArrayToUuid(src, 0);
        assertNotNull(uuid);
        final long expectedMsb = Conversion.byteArrayToLong(src, 0, 0, 0, 8);
        final long expectedLsb = Conversion.byteArrayToLong(src, 8, 0, 0, 8);
        assertEquals(expectedMsb, uuid.getMostSignificantBits());
        assertEquals(expectedLsb, uuid.getLeastSignificantBits());
    }

    @Test
    public void testByteArrayToUuidTooShortThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Conversion.byteArrayToUuid(new byte[15], 0);
            }
        });
    }

    @Test
    public void testByteToBinary() {
        final boolean[] dst = new boolean[4];
        final boolean[] result = Conversion.byteToBinary((byte) 0b1101, 0, dst, 0, 4);
        assertSame(dst, result);
        assertArrayEquals(new boolean[] { true, false, true, true }, result);
    }

    @Test
    public void testByteToBinaryZeroNBoolsReturnsDstUnchanged() {
        final boolean[] dst = new boolean[0];
        assertSame(dst, Conversion.byteToBinary((byte) 5, 0, dst, 0, 0));
    }

    @Test
    public void testByteToBinaryOutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Conversion.byteToBinary((byte) 0, 1, new boolean[8], 0, 8);
            }
        });
    }

    @Test
    public void testByteToHex() {
        final String result = Conversion.byteToHex((byte) 0xAB, 0, "", 0, 2);
        assertEquals("ba", result);
    }

    @Test
    public void testByteToHexZeroNHexsReturnsDstInit() {
        assertEquals("x", Conversion.byteToHex((byte) 1, 0, "x", 0, 0));
    }

    @Test
    public void testByteToHexOutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Conversion.byteToHex((byte) 0, 4, "", 0, 2);
            }
        });
    }

    @Test
    public void testHexDigitMsb0ToBinary() {
        assertArrayEquals(new boolean[] { false, false, false, true }, Conversion.hexDigitMsb0ToBinary('1'));
        assertArrayEquals(new boolean[] { true, true, true, true }, Conversion.hexDigitMsb0ToBinary('f'));
        assertArrayEquals(new boolean[] { true, true, true, true }, Conversion.hexDigitMsb0ToBinary('F'));
        assertArrayEquals(new boolean[] { false, false, false, false }, Conversion.hexDigitMsb0ToBinary('0'));
    }

    @Test
    public void testHexDigitMsb0ToBinaryInvalidThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Conversion.hexDigitMsb0ToBinary('g');
            }
        });
    }

    @Test
    public void testHexDigitMsb0ToInt() {
        assertEquals(0x8, Conversion.hexDigitMsb0ToInt('1'));
        assertEquals(0x0, Conversion.hexDigitMsb0ToInt('0'));
        assertEquals(0xF, Conversion.hexDigitMsb0ToInt('f'));
        assertEquals(0x5, Conversion.hexDigitMsb0ToInt('A'));
    }

    @Test
    public void testHexDigitMsb0ToIntInvalidThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Conversion.hexDigitMsb0ToInt('z');
            }
        });
    }

    @Test
    public void testHexDigitToBinary() {
        assertArrayEquals(new boolean[] { true, false, false, false }, Conversion.hexDigitToBinary('1'));
        assertArrayEquals(new boolean[] { false, false, false, false }, Conversion.hexDigitToBinary('0'));
        assertArrayEquals(new boolean[] { true, true, true, true }, Conversion.hexDigitToBinary('F'));
    }

    @Test
    public void testHexDigitToBinaryInvalidThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Conversion.hexDigitToBinary('x');
            }
        });
    }

    @Test
    public void testHexDigitToInt() {
        assertEquals(1, Conversion.hexDigitToInt('1'));
        assertEquals(15, Conversion.hexDigitToInt('f'));
        assertEquals(15, Conversion.hexDigitToInt('F'));
        assertEquals(0, Conversion.hexDigitToInt('0'));
    }

    @Test
    public void testHexDigitToIntInvalidThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Conversion.hexDigitToInt('g');
            }
        });
    }

    @Test
    public void testHexToByte() {
        assertEquals((byte) 0xAB, Conversion.hexToByte("ba", 0, (byte) 0, 0, 2));
    }

    @Test
    public void testHexToByteZeroNHexReturnsDstInit() {
        assertEquals((byte) 9, Conversion.hexToByte("", 0, (byte) 9, 0, 0));
    }

    @Test
    public void testHexToByteOutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Conversion.hexToByte("ff", 0, (byte) 0, 4, 2);
            }
        });
    }

    @Test
    public void testHexToInt() {
        assertEquals(0x00FF, Conversion.hexToInt("ff00", 0, 0, 0, 2));
    }

    @Test
    public void testHexToLong() {
        assertEquals(0x0FL, Conversion.hexToLong("f", 0, 0L, 0, 1));
    }

    @Test
    public void testHexToShort() {
        assertEquals((short) 0xAB, Conversion.hexToShort("ba", 0, (short) 0, 0, 2));
    }

    @Test
    public void testHexToShortOutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Conversion.hexToShort("ffff", 0, (short) 0, 4, 4);
            }
        });
    }

    @Test
    public void testIntArrayToLong() {
        final int[] src = { 0x00000002, 0x00000001 };
        final long result = Conversion.intArrayToLong(src, 0, 0L, 0, 2);
        assertEquals(0x0000000100000002L, result);
    }

    @Test
    public void testIntArrayToLongZeroNIntsReturnsDstInit() {
        assertEquals(5L, Conversion.intArrayToLong(new int[0], 0, 5L, 0, 0));
    }

    @Test
    public void testIntArrayToLongOutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Conversion.intArrayToLong(new int[3], 0, 0L, 1, 3);
            }
        });
    }

    @Test
    public void testIntToBinary() {
        final boolean[] dst = new boolean[4];
        final boolean[] result = Conversion.intToBinary(0b1101, 0, dst, 0, 4);
        assertSame(dst, result);
        assertArrayEquals(new boolean[] { true, false, true, true }, result);
    }

    @Test
    public void testIntToBinaryOutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Conversion.intToBinary(0, 1, new boolean[32], 0, 32);
            }
        });
    }

    @Test
    public void testIntToByteArray() {
        final byte[] dst = new byte[4];
        final byte[] result = Conversion.intToByteArray(0x04030201, 0, dst, 0, 4);
        assertSame(dst, result);
        assertArrayEquals(new byte[] { 0x01, 0x02, 0x03, 0x04 }, result);
    }

    @Test
    public void testIntToByteArrayOutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Conversion.intToByteArray(0, 8, new byte[4], 0, 4);
            }
        });
    }

    @Test
    public void testIntToHex() {
        assertEquals("1020", Conversion.intToHex(0x00000201, 0, "", 0, 4));
    }

    @Test
    public void testIntToHexOutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Conversion.intToHex(0, 4, "", 0, 8);
            }
        });
    }

    @Test
    public void testIntToHexDigit() {
        assertEquals('0', Conversion.intToHexDigit(0));
        assertEquals('1', Conversion.intToHexDigit(1));
        assertEquals('a', Conversion.intToHexDigit(10));
        assertEquals('f', Conversion.intToHexDigit(15));
    }

    @Test
    public void testIntToHexDigitBelowRangeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Conversion.intToHexDigit(-1);
            }
        });
    }

    @Test
    public void testIntToHexDigitAboveRangeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Conversion.intToHexDigit(16);
            }
        });
    }

    @Test
    public void testIntToHexDigitMsb0() {
        assertEquals('0', Conversion.intToHexDigitMsb0(0x0));
        assertEquals('8', Conversion.intToHexDigitMsb0(0x1));
        assertEquals('5', Conversion.intToHexDigitMsb0(0xA));
        assertEquals('f', Conversion.intToHexDigitMsb0(0xF));
    }

    @Test
    public void testIntToHexDigitMsb0OutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Conversion.intToHexDigitMsb0(16);
            }
        });
    }

    @Test
    public void testIntToShortArray() {
        final short[] dst = new short[2];
        final short[] result = Conversion.intToShortArray(0x00020001, 0, dst, 0, 2);
        assertSame(dst, result);
        assertArrayEquals(new short[] { 0x0001, 0x0002 }, result);
    }

    @Test
    public void testIntToShortArrayOutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Conversion.intToShortArray(0, 16, new short[2], 0, 2);
            }
        });
    }

    @Test
    public void testLongToBinary() {
        final boolean[] dst = new boolean[4];
        final boolean[] result = Conversion.longToBinary(0b1101L, 0, dst, 0, 4);
        assertSame(dst, result);
        assertArrayEquals(new boolean[] { true, false, true, true }, result);
    }

    @Test
    public void testLongToBinaryOutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Conversion.longToBinary(0L, 1, new boolean[64], 0, 64);
            }
        });
    }

    @Test
    public void testLongToByteArray() {
        final byte[] dst = new byte[8];
        final byte[] result = Conversion.longToByteArray(0x0807060504030201L, 0, dst, 0, 8);
        assertSame(dst, result);
        assertArrayEquals(new byte[] { 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08 }, result);
    }

    @Test
    public void testLongToByteArrayOutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Conversion.longToByteArray(0L, 8, new byte[8], 0, 8);
            }
        });
    }

    @Test
    public void testLongToHex() {
        assertEquals("1020", Conversion.longToHex(0x0000000000000201L, 0, "", 0, 4));
    }

    @Test
    public void testLongToHexOutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Conversion.longToHex(0L, 4, "", 0, 16);
            }
        });
    }

    @Test
    public void testLongToIntArray() {
        final int[] dst = new int[2];
        final int[] result = Conversion.longToIntArray(0x0000000200000001L, 0, dst, 0, 2);
        assertSame(dst, result);
        assertArrayEquals(new int[] { 0x00000001, 0x00000002 }, result);
    }

    @Test
    public void testLongToIntArrayOutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Conversion.longToIntArray(0L, 32, new int[2], 0, 2);
            }
        });
    }

    @Test
    public void testLongToShortArray() {
        final short[] dst = new short[2];
        final short[] result = Conversion.longToShortArray(0x0000000200010000L, 16, dst, 0, 2);
        assertSame(dst, result);
        assertArrayEquals(new short[] { 0x0001, 0x0002 }, result);
    }

    @Test
    public void testLongToShortArrayOutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Conversion.longToShortArray(0L, 16, new short[2], 0, 4);
            }
        });
    }

    @Test
    public void testShortArrayToInt() {
        final short[] src = { 0x0002, 0x0001 };
        final int result = Conversion.shortArrayToInt(src, 0, 0, 0, 2);
        assertEquals(0x00010002, result);
    }

    @Test
    public void testShortArrayToIntOutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Conversion.shortArrayToInt(new short[2], 0, 0, 16, 2);
            }
        });
    }

    @Test
    public void testShortArrayToLong() {
        final short[] src = { 0x0001, 0x0002, 0x0003, 0x0004 };
        final long result = Conversion.shortArrayToLong(src, 0, 0L, 0, 4);
        assertEquals(0x0004000300020001L, result);
    }

    @Test
    public void testShortArrayToLongOutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Conversion.shortArrayToLong(new short[4], 0, 0L, 16, 4);
            }
        });
    }

    @Test
    public void testShortToBinary() {
        final boolean[] dst = new boolean[4];
        final boolean[] result = Conversion.shortToBinary((short) 0b1101, 0, dst, 0, 4);
        assertSame(dst, result);
        assertArrayEquals(new boolean[] { true, false, true, true }, result);
    }

    @Test
    public void testShortToBinaryOutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Conversion.shortToBinary((short) 0, 1, new boolean[16], 0, 16);
            }
        });
    }

    @Test
    public void testShortToByteArray() {
        final byte[] dst = new byte[2];
        final byte[] result = Conversion.shortToByteArray((short) 0x0201, 0, dst, 0, 2);
        assertSame(dst, result);
        assertArrayEquals(new byte[] { 0x01, 0x02 }, result);
    }

    @Test
    public void testShortToByteArrayOutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Conversion.shortToByteArray((short) 0, 8, new byte[2], 0, 2);
            }
        });
    }

    @Test
    public void testShortToHex() {
        assertEquals("ba", Conversion.shortToHex((short) 0x00AB, 0, "", 0, 2));
    }

    @Test
    public void testShortToHexOutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Conversion.shortToHex((short) 0, 0, "", 0, 5);
            }
        });
    }

    @Test
    public void testUuidToByteArray() {
        final UUID uuid = new UUID(0x0102030405060708L, 0x090A0B0C0D0E0F10L);
        final byte[] dst = new byte[16];
        final byte[] result = Conversion.uuidToByteArray(uuid, dst, 0, 16);
        assertSame(dst, result);
        final long roundTripMsb = Conversion.byteArrayToLong(result, 0, 0, 0, 8);
        final long roundTripLsb = Conversion.byteArrayToLong(result, 8, 0, 0, 8);
        assertEquals(uuid.getMostSignificantBits(), roundTripMsb);
        assertEquals(uuid.getLeastSignificantBits(), roundTripLsb);
    }

    @Test
    public void testUuidToByteArrayZeroNBytesReturnsDstUnchanged() {
        final byte[] dst = new byte[16];
        final UUID uuid = new UUID(1L, 2L);
        assertSame(dst, Conversion.uuidToByteArray(uuid, dst, 0, 0));
        assertArrayEquals(new byte[16], dst);
    }

    @Test
    public void testUuidToByteArrayTooManyBytesThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Conversion.uuidToByteArray(new UUID(1L, 2L), new byte[17], 0, 17);
            }
        });
    }

    @Test
    public void testConstructorDeprecatedButUsable() {
        assertNotNull(new Conversion());
    }
}
