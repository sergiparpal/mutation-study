package org.apache.commons.lang3.builder;

import java.lang.reflect.Field;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang3.tuple.Pair;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Self-contained tests for {@link AbstractReflection} based solely on its published javadoc.
 */
public class AbstractReflectionAgentTest {

    private static final String FORCE_ACCESSIBLE_PROPERTY = "AbstractReflection.forceAccessible";

    private String originalPropertyValue;

    @BeforeEach
    public void saveProperty() {
        originalPropertyValue = System.getProperty(FORCE_ACCESSIBLE_PROPERTY);
    }

    @AfterEach
    public void restoreProperty() {
        if (originalPropertyValue == null) {
            System.clearProperty(FORCE_ACCESSIBLE_PROPERTY);
        } else {
            System.setProperty(FORCE_ACCESSIBLE_PROPERTY, originalPropertyValue);
        }
    }

    static final class Fixture {
        private int secret = 42;
        public int open = 7;
    }

    static final class ConcreteBuilder extends AbstractReflection.AbstractBuilder<ConcreteBuilder> {
        @Override
        public ConcreteReflection get() {
            return new ConcreteReflection(this);
        }
    }

    static final class ConcreteReflection extends AbstractReflection {
        ConcreteReflection(final ConcreteBuilder builder) {
            super(builder);
        }

        boolean exposeIsForceAccessible() {
            return isForceAccessible();
        }

        boolean exposeSetAccessible(final Field field) {
            return setAccessible(field);
        }
    }

    private static Field secretField() throws NoSuchFieldException {
        return Fixture.class.getDeclaredField("secret");
    }

    @Test
    public void testGetForceAccessibleDefaultsToTrueWhenPropertyUnset() {
        System.clearProperty(FORCE_ACCESSIBLE_PROPERTY);
        assertTrue(AbstractReflection.getForceAccessible());
    }

    @Test
    public void testGetForceAccessibleHonorsTrueProperty() {
        System.setProperty(FORCE_ACCESSIBLE_PROPERTY, "true");
        assertTrue(AbstractReflection.getForceAccessible());
    }

    @Test
    public void testGetForceAccessibleHonorsFalseProperty() {
        System.setProperty(FORCE_ACCESSIBLE_PROPERTY, "false");
        assertFalse(AbstractReflection.getForceAccessible());
    }

    @Test
    public void testGetForceAccessibleTreatsUnparsablePropertyAsFalse() {
        System.setProperty(FORCE_ACCESSIBLE_PROPERTY, "not-a-boolean");
        assertFalse(AbstractReflection.getForceAccessible());
    }

    @Test
    public void testIsForceAccessibleDefaultsToGetForceAccessible() {
        System.clearProperty(FORCE_ACCESSIBLE_PROPERTY);
        final ConcreteReflection instance = new ConcreteBuilder().get();
        assertEquals(AbstractReflection.getForceAccessible(), instance.exposeIsForceAccessible());
    }

    @Test
    public void testIsForceAccessibleHonorsBuilderTrue() {
        final ConcreteReflection instance = new ConcreteBuilder().setForceAccessible(true).get();
        assertTrue(instance.exposeIsForceAccessible());
    }

    @Test
    public void testIsForceAccessibleHonorsBuilderFalse() {
        final ConcreteReflection instance = new ConcreteBuilder().setForceAccessible(false).get();
        assertFalse(instance.exposeIsForceAccessible());
    }

    @Test
    public void testSetForceAccessibleReturnsThisForChaining() {
        final ConcreteBuilder builder = new ConcreteBuilder();
        assertSame(builder, builder.setForceAccessible(true));
        assertSame(builder, builder.setForceAccessible(false));
    }

    @Test
    public void testStaticSetAccessibleNullObjectReturnsFalse() {
        assertFalse(AbstractReflection.setAccessible(true, null));
        assertFalse(AbstractReflection.setAccessible(false, null));
    }

    @Test
    public void testStaticSetAccessibleForcesInaccessibleField() throws NoSuchFieldException {
        final Field field = secretField();
        assertFalse(field.isAccessible());
        final boolean result = AbstractReflection.setAccessible(true, field);
        assertTrue(result);
        assertTrue(field.isAccessible());
    }

    @Test
    public void testStaticSetAccessibleDoesNotForceWhenFlagFalse() throws NoSuchFieldException {
        final Field field = secretField();
        final boolean result = AbstractReflection.setAccessible(false, field);
        assertFalse(result);
        assertFalse(field.isAccessible());
    }

    @Test
    public void testStaticSetAccessibleAlreadyAccessibleReturnsTrueEvenWhenFlagFalse() throws NoSuchFieldException {
        final Field field = secretField();
        field.setAccessible(true);
        final boolean result = AbstractReflection.setAccessible(false, field);
        assertTrue(result);
        assertTrue(field.isAccessible());
    }

    @Test
    public void testInstanceSetAccessibleNullFieldReturnsFalse() {
        final ConcreteReflection instance = new ConcreteBuilder().setForceAccessible(true).get();
        assertFalse(instance.exposeSetAccessible(null));
    }

    @Test
    public void testInstanceSetAccessibleForcesWhenFlagTrue() throws NoSuchFieldException {
        final ConcreteReflection instance = new ConcreteBuilder().setForceAccessible(true).get();
        final Field field = secretField();
        assertFalse(field.isAccessible());
        assertTrue(instance.exposeSetAccessible(field));
        assertTrue(field.isAccessible());
    }

    @Test
    public void testInstanceSetAccessibleDoesNotForceWhenFlagFalse() throws NoSuchFieldException {
        final ConcreteReflection instance = new ConcreteBuilder().setForceAccessible(false).get();
        final Field field = secretField();
        assertFalse(instance.exposeSetAccessible(field));
        assertFalse(field.isAccessible());
    }

    @Test
    public void testToRegisterPairReturnsNonNullKeyedPair() {
        final Object lhs = new Object();
        final Object rhs = new Object();
        final Pair<IDKey, IDKey> pair = AbstractReflection.toRegisterPair(lhs, rhs);
        assertNotNull(pair);
        assertNotNull(pair.getLeft());
        assertNotNull(pair.getRight());
    }

    @Test
    public void testIsRegisteredFalseOnEmptyRegistry() {
        final Set<Pair<IDKey, IDKey>> registry = new HashSet<Pair<IDKey, IDKey>>();
        assertFalse(AbstractReflection.isRegistered(new Object(), new Object(), registry));
    }

    @Test
    public void testRegisterThenIsRegisteredIsTrue() {
        final Object lhs = new Object();
        final Object rhs = new Object();
        final Set<Pair<IDKey, IDKey>> registry = new HashSet<Pair<IDKey, IDKey>>();
        AbstractReflection.register(lhs, rhs, registry);
        assertEquals(1, registry.size());
        assertTrue(AbstractReflection.isRegistered(lhs, rhs, registry));
    }

    @Test
    public void testUnregisterRemovesPairFromRegistry() {
        final Object lhs = new Object();
        final Object rhs = new Object();
        final Set<Pair<IDKey, IDKey>> registry = new HashSet<Pair<IDKey, IDKey>>();
        AbstractReflection.register(lhs, rhs, registry);
        assertTrue(AbstractReflection.isRegistered(lhs, rhs, registry));

        final ThreadLocal<Set<Pair<IDKey, IDKey>>> registryTL = new ThreadLocal<Set<Pair<IDKey, IDKey>>>() {
            @Override
            protected Set<Pair<IDKey, IDKey>> initialValue() {
                return registry;
            }
        };
        registryTL.get();

        AbstractReflection.unregister(lhs, rhs, registry, registryTL);
        assertFalse(AbstractReflection.isRegistered(lhs, rhs, registry));
    }
}
