package org.apache.commons.lang3;

import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Self-contained tests for {@link AnnotationUtils} based solely on its published javadoc.
 */
public class AnnotationUtilsAgentTest {

    @Retention(RetentionPolicy.RUNTIME)
    @interface SampleAnnotation {
        String value();

        int number() default 0;
    }

    @Retention(RetentionPolicy.RUNTIME)
    @interface OtherAnnotation {
        String value();
    }

    @Retention(RetentionPolicy.RUNTIME)
    @interface ThrowingAnnotation {
        String value();
    }

    enum SampleEnum {
        A, B
    }

    static final class Fixture {
        @SampleAnnotation(value = "foo", number = 5)
        void methodA() {
        }

        @SampleAnnotation(value = "foo", number = 5)
        void methodB() {
        }

        @SampleAnnotation(value = "bar", number = 5)
        void methodC() {
        }

        @SampleAnnotation(value = "foo", number = 9)
        void methodD() {
        }

        @OtherAnnotation(value = "foo")
        void methodE() {
        }
    }

    private static Annotation annotationOf(final String methodName) {
        try {
            return Fixture.class.getDeclaredMethod(methodName).getAnnotation(SampleAnnotation.class);
        } catch (final NoSuchMethodException e) {
            throw new IllegalStateException(e);
        }
    }

    private static Annotation otherAnnotationOf(final String methodName) {
        try {
            return Fixture.class.getDeclaredMethod(methodName).getAnnotation(OtherAnnotation.class);
        } catch (final NoSuchMethodException e) {
            throw new IllegalStateException(e);
        }
    }

    @Test
    @SuppressWarnings("deprecation")
    public void testDeprecatedConstructorIsUsable() {
        assertNotNull(new AnnotationUtils());
    }

    @Test
    public void testEqualsBothNullIsTrue() {
        assertTrue(AnnotationUtils.equals(null, null));
    }

    @Test
    public void testEqualsFirstNullIsFalse() {
        final Annotation a = annotationOf("methodA");
        assertFalse(AnnotationUtils.equals(null, a));
    }

    @Test
    public void testEqualsSecondNullIsFalse() {
        final Annotation a = annotationOf("methodA");
        assertFalse(AnnotationUtils.equals(a, null));
    }

    @Test
    public void testEqualsSameInstanceIsTrue() {
        final Annotation a = annotationOf("methodA");
        assertTrue(AnnotationUtils.equals(a, a));
    }

    @Test
    public void testEqualsSameMembersIsTrue() {
        final Annotation a = annotationOf("methodA");
        final Annotation b = annotationOf("methodB");
        assertTrue(AnnotationUtils.equals(a, b));
    }

    @Test
    public void testEqualsDifferentStringMemberIsFalse() {
        final Annotation a = annotationOf("methodA");
        final Annotation c = annotationOf("methodC");
        assertFalse(AnnotationUtils.equals(a, c));
    }

    @Test
    public void testEqualsDifferentIntMemberIsFalse() {
        final Annotation a = annotationOf("methodA");
        final Annotation d = annotationOf("methodD");
        assertFalse(AnnotationUtils.equals(a, d));
    }

    @Test
    public void testEqualsDifferentAnnotationTypesIsFalse() {
        final Annotation a = annotationOf("methodA");
        final Annotation other = otherAnnotationOf("methodE");
        assertFalse(AnnotationUtils.equals(a, other));
    }

    @Test
    public void testHashCodeMatchesDocumentedAlgorithm() {
        final Annotation a = annotationOf("methodA");
        final int expected = (127 * "value".hashCode()) ^ "foo".hashCode()
                + ((127 * "number".hashCode()) ^ Integer.valueOf(5).hashCode());
        assertEquals(expected, AnnotationUtils.hashCode(a));
    }

    @Test
    public void testHashCodeEqualAnnotationsHaveEqualHashCodes() {
        final Annotation a = annotationOf("methodA");
        final Annotation b = annotationOf("methodB");
        assertEquals(AnnotationUtils.hashCode(a), AnnotationUtils.hashCode(b));
    }

    @Test
    public void testHashCodeDifferentAnnotationsCanHaveDifferentHashCodes() {
        final Annotation a = annotationOf("methodA");
        final Annotation c = annotationOf("methodC");
        assertTrue(AnnotationUtils.hashCode(a) != AnnotationUtils.hashCode(c));
    }

    @Test
    public void testHashCodeThrowsRuntimeExceptionOnMemberAccessFailure() {
        final Annotation proxy = (Annotation) Proxy.newProxyInstance(
                AnnotationUtilsAgentTest.class.getClassLoader(),
                new Class<?>[] { ThrowingAnnotation.class },
                new InvocationHandler() {
                    @Override
                    public Object invoke(final Object p, final Method method, final Object[] args) {
                        final String name = method.getName();
                        if ("annotationType".equals(name)) {
                            return ThrowingAnnotation.class;
                        }
                        if ("value".equals(name)) {
                            throw new RuntimeException("member access failure");
                        }
                        if ("hashCode".equals(name)) {
                            return Integer.valueOf(0);
                        }
                        if ("toString".equals(name)) {
                            return "ThrowingAnnotationProxy";
                        }
                        return Boolean.FALSE;
                    }
                });
        assertThrows(RuntimeException.class, new Executable() {
            @Override
            public void execute() {
                AnnotationUtils.hashCode(proxy);
            }
        });
    }

    @Test
    public void testHashCodeThrowsIllegalStateExceptionOnNullMemberValue() {
        final Annotation proxy = (Annotation) Proxy.newProxyInstance(
                AnnotationUtilsAgentTest.class.getClassLoader(),
                new Class<?>[] { ThrowingAnnotation.class },
                new InvocationHandler() {
                    @Override
                    public Object invoke(final Object p, final Method method, final Object[] args) {
                        final String name = method.getName();
                        if ("annotationType".equals(name)) {
                            return ThrowingAnnotation.class;
                        }
                        if ("value".equals(name)) {
                            return null;
                        }
                        if ("hashCode".equals(name)) {
                            return Integer.valueOf(0);
                        }
                        if ("toString".equals(name)) {
                            return "NullAnnotationProxy";
                        }
                        return Boolean.FALSE;
                    }
                });
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                AnnotationUtils.hashCode(proxy);
            }
        });
    }

    @Test
    public void testIsValidAnnotationMemberTypeString() {
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(String.class));
    }

    @Test
    public void testIsValidAnnotationMemberTypeClass() {
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(Class.class));
    }

    @Test
    public void testIsValidAnnotationMemberTypePrimitive() {
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(int.class));
    }

    @Test
    public void testIsValidAnnotationMemberTypeBoxedPrimitiveIsInvalid() {
        assertFalse(AnnotationUtils.isValidAnnotationMemberType(Integer.class));
    }

    @Test
    public void testIsValidAnnotationMemberTypeAnnotation() {
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(SampleAnnotation.class));
    }

    @Test
    public void testIsValidAnnotationMemberTypeEnum() {
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(SampleEnum.class));
    }

    @Test
    public void testIsValidAnnotationMemberTypeSingleDimensionalArray() {
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(String[].class));
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(int[].class));
    }

    @Test
    public void testIsValidAnnotationMemberTypeMultiDimensionalArrayIsInvalid() {
        assertFalse(AnnotationUtils.isValidAnnotationMemberType(String[][].class));
    }

    @Test
    public void testIsValidAnnotationMemberTypeArbitraryTypeIsInvalid() {
        assertFalse(AnnotationUtils.isValidAnnotationMemberType(Object.class));
        assertFalse(AnnotationUtils.isValidAnnotationMemberType(List.class));
    }

    @Test
    public void testIsValidAnnotationMemberTypeNullIsInvalid() {
        assertFalse(AnnotationUtils.isValidAnnotationMemberType(null));
    }

    @Test
    public void testToStringIsNotNullAndContainsMembers() {
        final Annotation a = annotationOf("methodA");
        final String result = AnnotationUtils.toString(a);
        assertNotNull(result);
        assertTrue(result.startsWith("@"));
        assertTrue(result.contains("value=foo"));
        assertTrue(result.contains("number=5"));
    }

    @Test
    public void testToStringReflectsMemberValues() {
        final Annotation c = annotationOf("methodC");
        final String result = AnnotationUtils.toString(c);
        assertNotNull(result);
        assertTrue(result.contains("value=bar"));
    }
}
