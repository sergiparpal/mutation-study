package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Tests for {@link ImmutableTimeZone}, based solely on its published javadoc:
 * it is an immutable wrapper around a {@link TimeZone} (see {@link #unwrap()}),
 * mutators always throw {@link UnsupportedOperationException}, and every other
 * method overrides/implements the corresponding {@link TimeZone}/{@link Object}
 * member.
 */
class ImmutableTimeZoneAgentTest {

    private static final TimeZone UTC = TimeZone.getTimeZone("UTC");
    private static final TimeZone NEW_YORK = TimeZone.getTimeZone("America/New_York");

    private static long utcMillis(int year, int month, int day) {
        Calendar cal = new GregorianCalendar(UTC);
        cal.clear();
        cal.set(year, month, day, 12, 0, 0);
        return cal.getTimeInMillis();
    }

    @Test
    void constructorWrapsTimeZoneAndUnwrapReturnsEquivalentInstance() {
        ImmutableTimeZone immutable = new ImmutableTimeZone(NEW_YORK);
        TimeZone unwrapped = immutable.unwrap();

        assertNotNull(unwrapped);
        assertEquals(NEW_YORK.getID(), unwrapped.getID());
        assertEquals(NEW_YORK.getRawOffset(), unwrapped.getRawOffset());
    }

    @Test
    void getIdDelegatesToWrappedTimeZone() {
        ImmutableTimeZone immutable = new ImmutableTimeZone(NEW_YORK);
        assertEquals(NEW_YORK.getID(), immutable.getID());

        ImmutableTimeZone utcImmutable = new ImmutableTimeZone(UTC);
        assertEquals(UTC.getID(), utcImmutable.getID());
    }

    @Test
    void getRawOffsetDelegatesToWrappedTimeZone() {
        ImmutableTimeZone immutable = new ImmutableTimeZone(NEW_YORK);
        assertEquals(NEW_YORK.getRawOffset(), immutable.getRawOffset());

        ImmutableTimeZone utcImmutable = new ImmutableTimeZone(UTC);
        assertEquals(0, utcImmutable.getRawOffset());
    }

    @Test
    void getOffsetByDateDelegatesToWrappedTimeZoneAcrossDstBoundary() {
        ImmutableTimeZone immutable = new ImmutableTimeZone(NEW_YORK);

        long winter = utcMillis(2023, Calendar.JANUARY, 15);
        long summer = utcMillis(2023, Calendar.JULY, 15);

        assertEquals(NEW_YORK.getOffset(winter), immutable.getOffset(winter));
        assertEquals(NEW_YORK.getOffset(summer), immutable.getOffset(summer));
        assertNotEquals(immutable.getOffset(winter), immutable.getOffset(summer));
    }

    @Test
    void getOffsetByDateForFixedZoneIsAlwaysRawOffset() {
        ImmutableTimeZone immutable = new ImmutableTimeZone(UTC);

        long winter = utcMillis(2023, Calendar.JANUARY, 15);
        long summer = utcMillis(2023, Calendar.JULY, 15);

        assertEquals(0, immutable.getOffset(winter));
        assertEquals(0, immutable.getOffset(summer));
    }

    @Test
    void getOffsetByFieldsDelegatesToWrappedTimeZone() {
        ImmutableTimeZone immutable = new ImmutableTimeZone(NEW_YORK);

        int expected = NEW_YORK.getOffset(GregorianCalendar.AD, 2023, Calendar.JULY, 15,
                Calendar.SATURDAY, 0);
        int actual = immutable.getOffset(GregorianCalendar.AD, 2023, Calendar.JULY, 15,
                Calendar.SATURDAY, 0);

        assertEquals(expected, actual);
    }

    @Test
    void getDstSavingsDelegatesToWrappedTimeZone() {
        ImmutableTimeZone immutable = new ImmutableTimeZone(NEW_YORK);
        assertEquals(NEW_YORK.getDSTSavings(), immutable.getDSTSavings());

        ImmutableTimeZone utcImmutable = new ImmutableTimeZone(UTC);
        assertEquals(0, utcImmutable.getDSTSavings());
    }

    @Test
    void observesDaylightTimeDelegatesToWrappedTimeZone() {
        ImmutableTimeZone immutable = new ImmutableTimeZone(NEW_YORK);
        assertEquals(NEW_YORK.observesDaylightTime(), immutable.observesDaylightTime());
        assertTrue(immutable.observesDaylightTime());

        ImmutableTimeZone utcImmutable = new ImmutableTimeZone(UTC);
        assertFalse(utcImmutable.observesDaylightTime());
    }

    @Test
    void useDaylightTimeDelegatesToWrappedTimeZone() {
        ImmutableTimeZone immutable = new ImmutableTimeZone(NEW_YORK);
        assertEquals(NEW_YORK.useDaylightTime(), immutable.useDaylightTime());

        ImmutableTimeZone utcImmutable = new ImmutableTimeZone(UTC);
        assertFalse(utcImmutable.useDaylightTime());
    }

    @Test
    void inDaylightTimeDelegatesToWrappedTimeZoneAcrossDstBoundary() {
        ImmutableTimeZone immutable = new ImmutableTimeZone(NEW_YORK);

        Date winter = new Date(utcMillis(2023, Calendar.JANUARY, 15));
        Date summer = new Date(utcMillis(2023, Calendar.JULY, 15));

        assertEquals(NEW_YORK.inDaylightTime(winter), immutable.inDaylightTime(winter));
        assertFalse(immutable.inDaylightTime(winter));
        assertEquals(NEW_YORK.inDaylightTime(summer), immutable.inDaylightTime(summer));
        assertTrue(immutable.inDaylightTime(summer));

        ImmutableTimeZone utcImmutable = new ImmutableTimeZone(UTC);
        assertFalse(utcImmutable.inDaylightTime(summer));
    }

    @Test
    void hasSameRulesDelegatesToWrappedTimeZone() {
        ImmutableTimeZone immutable = new ImmutableTimeZone(NEW_YORK);

        assertEquals(NEW_YORK.hasSameRules(NEW_YORK), immutable.hasSameRules(NEW_YORK));
        assertTrue(immutable.hasSameRules(NEW_YORK));
        assertEquals(NEW_YORK.hasSameRules(UTC), immutable.hasSameRules(UTC));
        assertFalse(immutable.hasSameRules(UTC));
    }

    @Test
    void getDisplayNameDelegatesToWrappedTimeZone() {
        ImmutableTimeZone immutable = new ImmutableTimeZone(NEW_YORK);

        String expectedLong = NEW_YORK.getDisplayName(false, TimeZone.LONG, Locale.US);
        String expectedShort = NEW_YORK.getDisplayName(false, TimeZone.SHORT, Locale.US);

        assertEquals(expectedLong, immutable.getDisplayName(false, TimeZone.LONG, Locale.US));
        assertEquals(expectedShort, immutable.getDisplayName(false, TimeZone.SHORT, Locale.US));
    }

    @Test
    void toZoneIdDelegatesToWrappedTimeZone() {
        ImmutableTimeZone immutable = new ImmutableTimeZone(NEW_YORK);
        assertEquals(NEW_YORK.toZoneId(), immutable.toZoneId());
    }

    @Test
    void setIdAlwaysThrowsUnsupportedOperationExceptionAndLeavesStateUnchanged() {
        ImmutableTimeZone immutable = new ImmutableTimeZone(NEW_YORK);

        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                immutable.setID("Europe/Paris");
            }
        });

        assertEquals(NEW_YORK.getID(), immutable.getID());
    }

    @Test
    void setRawOffsetAlwaysThrowsUnsupportedOperationExceptionAndLeavesStateUnchanged() {
        ImmutableTimeZone immutable = new ImmutableTimeZone(NEW_YORK);

        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                immutable.setRawOffset(0);
            }
        });

        assertEquals(NEW_YORK.getRawOffset(), immutable.getRawOffset());
    }

    @Test
    void cloneReturnsDistinctEquivalentInstance() {
        ImmutableTimeZone immutable = new ImmutableTimeZone(NEW_YORK);
        Object clone = immutable.clone();

        assertNotNull(clone);
        assertNotSame(immutable, clone);
        assertTrue(clone instanceof ImmutableTimeZone);

        ImmutableTimeZone clonedImmutable = (ImmutableTimeZone) clone;
        assertEquals(immutable.getID(), clonedImmutable.getID());
        assertEquals(immutable.getRawOffset(), clonedImmutable.getRawOffset());
    }

    @Test
    void equalsIsReflexiveAndRejectsNullAndUnrelatedType() {
        ImmutableTimeZone immutable = new ImmutableTimeZone(NEW_YORK);

        assertTrue(immutable.equals(immutable));
        assertFalse(immutable.equals(null));
        assertFalse(immutable.equals("not a time zone"));
    }

    @Test
    void hashCodeIsConsistentAcrossRepeatedCalls() {
        ImmutableTimeZone immutable = new ImmutableTimeZone(NEW_YORK);

        int first = immutable.hashCode();
        int second = immutable.hashCode();

        assertEquals(first, second);
    }

    @Test
    void toStringReturnsNonNullRepresentation() {
        ImmutableTimeZone immutable = new ImmutableTimeZone(NEW_YORK);

        assertNotNull(immutable.toString());
    }

    @Test
    void unwrapReturnsWrappedZoneForMultipleDistinctZones() {
        ImmutableTimeZone utcImmutable = new ImmutableTimeZone(UTC);
        ImmutableTimeZone nyImmutable = new ImmutableTimeZone(NEW_YORK);

        assertEquals(UTC.getID(), utcImmutable.unwrap().getID());
        assertEquals(NEW_YORK.getID(), nyImmutable.unwrap().getID());
        assertNotEquals(utcImmutable.unwrap().getID(), nyImmutable.unwrap().getID());
    }
}
