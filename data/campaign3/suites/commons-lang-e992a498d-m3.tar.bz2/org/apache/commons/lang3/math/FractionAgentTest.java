/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Objects;

import org.junit.jupiter.api.Test;

public class FractionAgentTest {

    // ---- constants ----

    @Test
    public void testConstants() {
        assertEquals(0, Fraction.ZERO.getNumerator());
        assertEquals(1, Fraction.ZERO.getDenominator());
        assertEquals(1, Fraction.ONE.getNumerator());
        assertEquals(1, Fraction.ONE.getDenominator());
        assertEquals(1, Fraction.ONE_HALF.getNumerator());
        assertEquals(2, Fraction.ONE_HALF.getDenominator());
        assertEquals(2, Fraction.TWO_THIRDS.getNumerator());
        assertEquals(3, Fraction.TWO_THIRDS.getDenominator());
        assertEquals(2, Fraction.TWO_QUARTERS.getNumerator());
        assertEquals(4, Fraction.TWO_QUARTERS.getDenominator());
        // not reduced, so equals() sees them as different even though they represent the same value.
        assertNotEquals(Fraction.ONE_HALF, Fraction.TWO_QUARTERS);
        assertEquals(0, Fraction.ONE_HALF.compareTo(Fraction.TWO_QUARTERS));
    }

    // ---- getFraction(double) ----

    @Test
    public void testGetFractionDouble() {
        assertEquals(Fraction.ONE_HALF, Fraction.getFraction(0.5d));
        assertEquals(Fraction.getFraction(1, 1), Fraction.getFraction(1.0d));
        assertEquals(Fraction.getFraction(-1, 2), Fraction.getFraction(-0.5d));
        assertEquals(Fraction.getFraction(3, 4), Fraction.getFraction(0.75d));
    }

    @Test
    public void testGetFractionDoubleNaNThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(Double.NaN));
    }

    @Test
    public void testGetFractionDoubleTooLargeThrows() {
        final double tooLarge = (double) Integer.MAX_VALUE + 1.0d;
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(tooLarge));
    }

    // ---- getFraction(int, int) ----

    @Test
    public void testGetFractionIntInt() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertEquals(3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionIntIntNegativeDenominatorMovesSignToNumerator() {
        final Fraction f = Fraction.getFraction(3, -7);
        assertEquals(-3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionIntIntZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(1, 0));
    }

    @Test
    public void testGetFractionIntIntOverflowOnNegateThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(Integer.MIN_VALUE, -1));
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(1, Integer.MIN_VALUE));
    }

    // ---- getFraction(int, int, int) ----

    @Test
    public void testGetFractionWholeNumerDenom() {
        final Fraction f = Fraction.getFraction(1, 3, 7);
        assertEquals(10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionWholeNumerDenomNegativeWhole() {
        final Fraction f = Fraction.getFraction(-1, 3, 7);
        assertEquals(-10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionWholeNumerDenomZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(1, 2, 0));
    }

    @Test
    public void testGetFractionWholeNumerDenomNegativeDenominatorThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(1, 2, -3));
    }

    @Test
    public void testGetFractionWholeNumerDenomNegativeNumeratorThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(1, -2, 3));
    }

    @Test
    public void testGetFractionWholeNumerDenomOverflowThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(Integer.MAX_VALUE, Integer.MAX_VALUE, 1));
    }

    // ---- getFraction(String) ----

    @Test
    public void testGetFractionStringDoubleFormat() {
        final Fraction f = Fraction.getFraction("1.5");
        assertEquals(Fraction.getFraction(3, 2), f);
    }

    @Test
    public void testGetFractionStringMixedFormat() {
        assertEquals(Fraction.getFraction(10, 7), Fraction.getFraction("1 3/7"));
        assertEquals(Fraction.getFraction(-10, 7), Fraction.getFraction("-1 3/7"));
    }

    @Test
    public void testGetFractionStringSimpleFraction() {
        assertEquals(Fraction.getFraction(3, 7), Fraction.getFraction("3/7"));
    }

    @Test
    public void testGetFractionStringWholeNumber() {
        assertEquals(Fraction.getFraction(5, 1), Fraction.getFraction("5"));
    }

    @Test
    public void testGetFractionStringNullThrows() {
        assertThrows(NullPointerException.class, () -> Fraction.getFraction((String) null));
    }

    @Test
    public void testGetFractionStringInvalidFormatThrows() {
        assertThrows(NumberFormatException.class, () -> Fraction.getFraction("abc"));
    }

    @Test
    public void testGetFractionStringMissingSlashInMixedFormatThrows() {
        assertThrows(NumberFormatException.class, () -> Fraction.getFraction("1 3"));
    }

    @Test
    public void testGetFractionStringZeroDenominatorThrowsWithCause() {
        final NumberFormatException nfe = assertThrows(NumberFormatException.class, () -> Fraction.getFraction("1/0"));
        assertTrue(nfe.getCause() instanceof ArithmeticException);
    }

    // ---- getReducedFraction(int, int) ----

    @Test
    public void testGetReducedFraction() {
        final Fraction f = Fraction.getReducedFraction(2, 4);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
        assertEquals(Fraction.getFraction(1, 2), f);
    }

    @Test
    public void testGetReducedFractionZeroNumeratorReturnsZeroInstance() {
        assertSame(Fraction.ZERO, Fraction.getReducedFraction(0, 5));
    }

    @Test
    public void testGetReducedFractionNegativeNumerator() {
        final Fraction f = Fraction.getReducedFraction(-2, 4);
        assertEquals(-1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetReducedFractionZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getReducedFraction(1, 0));
    }

    @Test
    public void testGetReducedFractionOverflowOnNegateThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getReducedFraction(Integer.MIN_VALUE, -1));
    }

    // ---- abs() ----

    @Test
    public void testAbsPositiveReturnsSameInstance() {
        final Fraction f = Fraction.getFraction(3, 4);
        assertSame(f, f.abs());
    }

    @Test
    public void testAbsNegative() {
        final Fraction f = Fraction.getFraction(-3, 4).abs();
        assertEquals(3, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testAbsOverflowThrows() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, f::abs);
    }

    // ---- add() ----

    @Test
    public void testAdd() {
        final Fraction result = Fraction.getFraction(1, 2).add(Fraction.getFraction(1, 3));
        assertEquals(Fraction.getFraction(5, 6), result);
    }

    @Test
    public void testAddZeroIdentityReducesOther() {
        final Fraction result = Fraction.ZERO.add(Fraction.getFraction(2, 4));
        assertEquals(1, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    @Test
    public void testAddOtherZeroReducesThis() {
        final Fraction result = Fraction.getFraction(2, 4).add(Fraction.ZERO);
        assertEquals(1, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    @Test
    public void testAddNullThrows() {
        assertThrows(NullPointerException.class, () -> Fraction.ONE.add(null));
    }

    @Test
    public void testAddOverflowThrows() {
        final Fraction maxOverOne = Fraction.getFraction(Integer.MAX_VALUE, 1);
        assertThrows(ArithmeticException.class, () -> maxOverOne.add(Fraction.ONE));
    }

    // ---- subtract() ----

    @Test
    public void testSubtract() {
        final Fraction result = Fraction.getFraction(1, 2).subtract(Fraction.getFraction(1, 3));
        assertEquals(Fraction.getFraction(1, 6), result);
    }

    @Test
    public void testSubtractFromZeroNegatesReduced() {
        final Fraction result = Fraction.ZERO.subtract(Fraction.getFraction(2, 4));
        assertEquals(-1, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    @Test
    public void testSubtractNullThrows() {
        assertThrows(NullPointerException.class, () -> Fraction.ONE.subtract(null));
    }

    // ---- multiplyBy() ----

    @Test
    public void testMultiplyBy() {
        final Fraction result = Fraction.getFraction(2, 3).multiplyBy(Fraction.getFraction(3, 4));
        assertEquals(Fraction.getFraction(1, 2), result);
    }

    @Test
    public void testMultiplyByZero() {
        assertSame(Fraction.ZERO, Fraction.getFraction(5, 7).multiplyBy(Fraction.ZERO));
        assertSame(Fraction.ZERO, Fraction.ZERO.multiplyBy(Fraction.getFraction(5, 7)));
    }

    @Test
    public void testMultiplyByNullThrows() {
        assertThrows(NullPointerException.class, () -> Fraction.ONE.multiplyBy(null));
    }

    @Test
    public void testMultiplyByOverflowThrows() {
        final Fraction big = Fraction.getFraction(Integer.MAX_VALUE, 1);
        assertThrows(ArithmeticException.class, () -> big.multiplyBy(big));
    }

    // ---- divideBy() ----

    @Test
    public void testDivideBy() {
        final Fraction result = Fraction.getFraction(1, 2).divideBy(Fraction.getFraction(1, 4));
        assertEquals(Fraction.getFraction(2, 1), result);
    }

    @Test
    public void testDivideByZeroThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(1, 2).divideBy(Fraction.ZERO));
    }

    @Test
    public void testDivideByNullThrows() {
        assertThrows(NullPointerException.class, () -> Fraction.ONE.divideBy(null));
    }

    // ---- invert() ----

    @Test
    public void testInvertPositive() {
        final Fraction f = Fraction.getFraction(3, 4).invert();
        assertEquals(4, f.getNumerator());
        assertEquals(3, f.getDenominator());
    }

    @Test
    public void testInvertNegative() {
        final Fraction f = Fraction.getFraction(-3, 4).invert();
        assertEquals(-4, f.getNumerator());
        assertEquals(3, f.getDenominator());
    }

    @Test
    public void testInvertZeroThrows() {
        assertThrows(ArithmeticException.class, Fraction.ZERO::invert);
    }

    @Test
    public void testInvertMinValueNumeratorThrows() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, f::invert);
    }

    // ---- negate() ----

    @Test
    public void testNegate() {
        final Fraction f = Fraction.getFraction(3, 4).negate();
        assertEquals(-3, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testNegateOverflowThrows() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, f::negate);
    }

    // ---- pow() ----

    @Test
    public void testPowOneReturnsSameInstance() {
        final Fraction f = Fraction.getFraction(2, 3);
        assertSame(f, f.pow(1));
    }

    @Test
    public void testPowZeroReturnsOneEvenForZero() {
        assertSame(Fraction.ONE, Fraction.ZERO.pow(0));
    }

    @Test
    public void testPowPositive() {
        final Fraction result = Fraction.getFraction(2, 1).pow(3);
        assertEquals(Fraction.getFraction(8, 1), result);
    }

    @Test
    public void testPowNegative() {
        final Fraction result = Fraction.getFraction(2, 1).pow(-2);
        assertEquals(Fraction.getFraction(1, 4), result);
    }

    @Test
    public void testPowOverflowThrows() {
        final Fraction big = Fraction.getFraction(Integer.MAX_VALUE, 1);
        assertThrows(ArithmeticException.class, () -> big.pow(2));
    }

    // ---- reduce() ----

    @Test
    public void testReduce() {
        final Fraction result = Fraction.getFraction(2, 4).reduce();
        assertEquals(1, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    @Test
    public void testReduceAlreadyReducedReturnsSameInstance() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertSame(f, f.reduce());
    }

    @Test
    public void testReduceZeroNumeratorReturnsZeroEquivalent() {
        final Fraction result = Fraction.getFraction(0, 5).reduce();
        assertEquals(Fraction.ZERO, result);
    }

    // ---- compareTo() ----

    @Test
    public void testCompareTo() {
        assertTrue(Fraction.getFraction(1, 2).compareTo(Fraction.getFraction(1, 3)) > 0);
        assertTrue(Fraction.getFraction(1, 3).compareTo(Fraction.getFraction(1, 2)) < 0);
        assertEquals(0, Fraction.getFraction(1, 2).compareTo(Fraction.getFraction(2, 4)));
    }

    @Test
    public void testCompareToSameInstance() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertEquals(0, f.compareTo(f));
    }

    @Test
    public void testCompareToNullThrows() {
        assertThrows(NullPointerException.class, () -> Fraction.ONE.compareTo(null));
    }

    // ---- equals() / hashCode() ----

    @Test
    public void testEqualsReflexive() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertEquals(f, f);
    }

    @Test
    public void testEqualsDifferentButEquivalentFractionsAreNotEqual() {
        assertNotEquals(Fraction.getFraction(1, 2), Fraction.getFraction(2, 4));
    }

    @Test
    public void testEqualsSameValues() {
        assertEquals(Fraction.getFraction(3, 7), Fraction.getFraction(3, 7));
    }

    @Test
    public void testEqualsNullAndDifferentType() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertFalse(f.equals(null));
        assertFalse(f.equals("1/2"));
    }

    @Test
    public void testHashCodeMatchesContract() {
        final Fraction f = Fraction.getFraction(3, 7);
        final int expected = Objects.hash(Integer.valueOf(f.getDenominator()), Integer.valueOf(f.getNumerator()));
        assertEquals(expected, f.hashCode());
    }

    @Test
    public void testHashCodeConsistentForEqualObjects() {
        assertEquals(Fraction.getFraction(3, 7).hashCode(), Fraction.getFraction(3, 7).hashCode());
    }

    // ---- numeric conversions ----

    @Test
    public void testIntValue() {
        assertEquals(1, Fraction.getFraction(7, 4).intValue());
        assertEquals(-1, Fraction.getFraction(-7, 4).intValue());
    }

    @Test
    public void testLongValue() {
        assertEquals(1L, Fraction.getFraction(7, 4).longValue());
        assertEquals(-1L, Fraction.getFraction(-7, 4).longValue());
    }

    @Test
    public void testDoubleValue() {
        assertEquals(1.75d, Fraction.getFraction(7, 4).doubleValue(), 0.0d);
        assertEquals(-1.75d, Fraction.getFraction(-7, 4).doubleValue(), 0.0d);
    }

    @Test
    public void testFloatValue() {
        assertEquals(1.75f, Fraction.getFraction(7, 4).floatValue(), 0.0f);
    }

    // ---- getProperNumerator() / getProperWhole() ----

    @Test
    public void testGetProperNumeratorAndWhole() {
        final Fraction f = Fraction.getFraction(7, 4);
        assertEquals(3, f.getProperNumerator());
        assertEquals(1, f.getProperWhole());
    }

    @Test
    public void testGetProperNumeratorAndWholeNegative() {
        final Fraction f = Fraction.getFraction(-7, 4);
        assertEquals(3, f.getProperNumerator());
        assertEquals(-1, f.getProperWhole());
    }

    // ---- toProperString() ----

    @Test
    public void testToProperStringZero() {
        assertEquals("0", Fraction.getFraction(0, 1).toProperString());
    }

    @Test
    public void testToProperStringOne() {
        assertEquals("1", Fraction.getFraction(4, 4).toProperString());
    }

    @Test
    public void testToProperStringMinusOne() {
        assertEquals("-1", Fraction.getFraction(-4, 4).toProperString());
    }

    @Test
    public void testToProperStringImproperPositive() {
        assertEquals("1 3/4", Fraction.getFraction(7, 4).toProperString());
    }

    @Test
    public void testToProperStringImproperNegative() {
        assertEquals("-1 3/4", Fraction.getFraction(-7, 4).toProperString());
    }

    @Test
    public void testToProperStringProperFraction() {
        assertEquals("3/7", Fraction.getFraction(3, 7).toProperString());
    }

    // ---- toString() ----

    @Test
    public void testToString() {
        assertEquals("3/7", Fraction.getFraction(3, 7).toString());
    }

    @Test
    public void testToStringNotReduced() {
        assertEquals("2/4", Fraction.getFraction(2, 4).toString());
    }
}
