/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.FieldPosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link FastDatePrinter}.
 */
class FastDatePrinterAgentTest {

    private static final TimeZone UTC = TimeZone.getTimeZone("UTC");
    private static final TimeZone GMT_PLUS_1 = TimeZone.getTimeZone("GMT+01:00");
    private static final TimeZone GMT_PLUS_2 = TimeZone.getTimeZone("GMT+02:00");

    private Calendar utcCalendar(final int year, final int month, final int day,
                                  final int hour, final int minute, final int second, final int millis) {
        final Calendar cal = new GregorianCalendar(UTC, Locale.US);
        cal.clear();
        cal.set(year, month, day, hour, minute, second);
        cal.set(Calendar.MILLISECOND, millis);
        return cal;
    }

    @Test
    void testFormatDateAndLongProduceSameResult() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd HH:mm:ss", UTC, Locale.US);
        final long millis = utcCalendar(2020, Calendar.MARCH, 15, 10, 30, 0, 0).getTimeInMillis();
        final Date date = new Date(millis);

        assertEquals("2020-03-15 10:30:00", printer.format(date));
        assertEquals(printer.format(date), printer.format(millis));
    }

    @Test
    void testFormatCalendarUsesPrintersTimeZoneAndDoesNotMutateInput() {
        final long millis = utcCalendar(2020, Calendar.MARCH, 15, 10, 30, 0, 0).getTimeInMillis();
        final Calendar plus2Cal = new GregorianCalendar(GMT_PLUS_2, Locale.US);
        plus2Cal.setTimeInMillis(millis);
        assertEquals(12, plus2Cal.get(Calendar.HOUR_OF_DAY));

        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd'T'HH:mm:ss", GMT_PLUS_1, Locale.US);
        final String result = printer.format(plus2Cal);

        assertEquals("2020-03-15T11:30:00", result);
        // the original calendar must not have been mutated by format()
        assertEquals(12, plus2Cal.get(Calendar.HOUR_OF_DAY));
        assertEquals(GMT_PLUS_2, plus2Cal.getTimeZone());
    }

    @Test
    void testFormatAppendableAndStringBufferVariantsReturnSameBufferReference() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.US);
        final Date date = new Date(utcCalendar(2021, Calendar.JANUARY, 2, 0, 0, 0, 0).getTimeInMillis());
        final Calendar cal = utcCalendar(2021, Calendar.JANUARY, 2, 0, 0, 0, 0);

        final StringBuilder sb = new StringBuilder();
        final StringBuilder sbReturned = printer.format(date, sb);
        assertSame(sb, sbReturned);
        assertEquals("2021-01-02", sb.toString());

        final StringBuffer buf1 = new StringBuffer();
        final StringBuffer buf1Returned = printer.format(date, buf1);
        assertSame(buf1, buf1Returned);
        assertEquals("2021-01-02", buf1.toString());

        final StringBuffer buf2 = new StringBuffer();
        final StringBuffer buf2Returned = printer.format(cal, buf2);
        assertSame(buf2, buf2Returned);
        assertEquals("2021-01-02", buf2.toString());

        final StringBuffer buf3 = new StringBuffer();
        final StringBuffer buf3Returned = printer.format(cal.getTimeInMillis(), buf3);
        assertSame(buf3, buf3Returned);
        assertEquals("2021-01-02", buf3.toString());
    }

    @Test
    void testGetMaxLengthEstimate() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.US);
        // y(4) + -(1) + M(2) + -(1) + d(2)
        assertEquals(10, printer.getMaxLengthEstimate());
    }

    @Test
    void testGettersReturnConstructorValues() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy", GMT_PLUS_1, Locale.FRANCE);
        assertEquals("yyyy", printer.getPattern());
        assertEquals(GMT_PLUS_1, printer.getTimeZone());
        assertEquals(Locale.FRANCE, printer.getLocale());
    }

    @Test
    void testEqualsAndHashCode() {
        final FastDatePrinter p1 = new FastDatePrinter("yyyy", UTC, Locale.US);
        final FastDatePrinter p2 = new FastDatePrinter("yyyy", UTC, Locale.US);
        final FastDatePrinter differentPattern = new FastDatePrinter("MM", UTC, Locale.US);
        final FastDatePrinter differentZone = new FastDatePrinter("yyyy", GMT_PLUS_1, Locale.US);
        final FastDatePrinter differentLocale = new FastDatePrinter("yyyy", UTC, Locale.FRANCE);

        assertTrue(p1.equals(p2));
        assertEquals(p1.hashCode(), p2.hashCode());
        assertFalse(p1.equals(differentPattern));
        assertFalse(p1.equals(differentZone));
        assertFalse(p1.equals(differentLocale));
    }

    @Test
    void testEqualsWithNonFastDatePrinterOrNullReturnsFalse() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy", UTC, Locale.US);
        assertFalse(printer.equals("yyyy"));
        assertFalse(printer.equals(null));
        assertTrue(printer.equals(printer));
    }

    @Test
    void testToString() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy", UTC, Locale.US);
        assertEquals("FastDatePrinter[yyyy," + Locale.US + "," + UTC.getID() + "]", printer.toString());
    }

    @Test
    void testIllegalPatternCharacterThrowsOnConstruction() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> new FastDatePrinter("yyyy-qq", UTC, Locale.US));
        assertTrue(ex.getMessage().contains("Illegal pattern component"));
    }

    @Test
    void testIsoXPatternInvalidLengthThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> new FastDatePrinter("XXXX", UTC, Locale.US));
        assertEquals("invalid number of X", ex.getMessage());
    }

    @Test
    void testIsoXPatternValidLengths() {
        final Date date = new Date(utcCalendar(2020, Calendar.MARCH, 15, 10, 30, 0, 0).getTimeInMillis());

        assertEquals("+01", new FastDatePrinter("X", GMT_PLUS_1, Locale.US).format(date));
        assertEquals("+0100", new FastDatePrinter("XX", GMT_PLUS_1, Locale.US).format(date));
        assertEquals("+01:00", new FastDatePrinter("XXX", GMT_PLUS_1, Locale.US).format(date));
        assertEquals("Z", new FastDatePrinter("X", UTC, Locale.US).format(date));
    }

    @Test
    void testZonePatternZ() {
        final Date date = new Date(utcCalendar(2020, Calendar.MARCH, 15, 10, 30, 0, 0).getTimeInMillis());

        assertEquals("+0100", new FastDatePrinter("Z", GMT_PLUS_1, Locale.US).format(date));
        assertEquals("+01:00", new FastDatePrinter("ZZ", GMT_PLUS_1, Locale.US).format(date));
        assertEquals("+01:00", new FastDatePrinter("ZZZ", GMT_PLUS_1, Locale.US).format(date));
    }

    @Test
    void testLiteralQuotedText() {
        final FastDatePrinter printer = new FastDatePrinter("'Year:'yyyy", UTC, Locale.US);
        final Date date = new Date(utcCalendar(2020, Calendar.JANUARY, 1, 0, 0, 0, 0).getTimeInMillis());
        assertEquals("Year:2020", printer.format(date));
    }

    @Test
    void testEscapedSingleQuoteLiteral() {
        final FastDatePrinter printer = new FastDatePrinter("''", UTC, Locale.US);
        final Date date = new Date(0L);
        assertEquals("'", printer.format(date));
    }

    @Test
    void testFormatObjectDispatch() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.US);
        final Calendar cal = utcCalendar(2020, Calendar.MAY, 5, 0, 0, 0, 0);
        final Date date = cal.getTime();
        final Long millis = Long.valueOf(cal.getTimeInMillis());

        assertEquals("2020-05-05", printer.format((Object) date));
        assertEquals("2020-05-05", printer.format((Object) cal));
        assertEquals("2020-05-05", printer.format((Object) millis));
    }

    @Test
    void testFormatObjectUnsupportedTypeThrows() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.US);
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> printer.format((Object) "not a date"));
        assertTrue(ex.getMessage().startsWith("Unknown class:"));
    }

    @Test
    @SuppressWarnings("deprecation")
    void testDeprecatedFormatObjectStringBufferFieldPosition() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.US);
        final Date date = new Date(utcCalendar(2020, Calendar.MAY, 5, 0, 0, 0, 0).getTimeInMillis());

        final StringBuffer buf = new StringBuffer();
        final StringBuffer returned = printer.format((Object) date, buf, new FieldPosition(0));
        assertSame(buf, returned);
        assertEquals("2020-05-05", buf.toString());
    }

    @Test
    @SuppressWarnings("deprecation")
    void testDeprecatedFormatObjectUnsupportedThrows() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.US);
        assertThrows(IllegalArgumentException.class,
                () -> printer.format((Object) Integer.valueOf(1), new StringBuffer(), new FieldPosition(0)));
    }

    @Test
    @SuppressWarnings("deprecation")
    void testApplyRulesDeprecatedProtectedMethod() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.US);
        final Calendar cal = utcCalendar(2020, Calendar.MAY, 5, 0, 0, 0, 0);

        final StringBuffer buf = new StringBuffer();
        final StringBuffer returned = printer.applyRules(cal, buf);
        assertSame(buf, returned);
        assertEquals("2020-05-05", buf.toString());
    }

    @Test
    void testSerializationRoundTrip() throws Exception {
        final FastDatePrinter original = new FastDatePrinter("yyyy-MM-dd'T'HH:mm:ss", GMT_PLUS_1, Locale.US);

        final ByteArrayOutputStream bos = new ByteArrayOutputStream();
        final ObjectOutputStream oos = new ObjectOutputStream(bos);
        oos.writeObject(original);
        oos.close();

        final ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(bos.toByteArray()));
        final FastDatePrinter deserialized = (FastDatePrinter) ois.readObject();
        ois.close();

        assertEquals(original, deserialized);

        final Date date = new Date(utcCalendar(2020, Calendar.MARCH, 15, 10, 30, 0, 0).getTimeInMillis());
        assertEquals(original.format(date), deserialized.format(date));
        assertEquals("2020-03-15T11:30:00", deserialized.format(date));
    }

    @Test
    void testTwelveHourAndTwentyFourHourFieldMidnightBoundary() {
        final Calendar midnight = utcCalendar(2020, Calendar.JANUARY, 1, 0, 5, 0, 0);

        assertEquals("12:05", new FastDatePrinter("h:mm", UTC, Locale.US).format(midnight));
        assertEquals("24:05", new FastDatePrinter("k:mm", UTC, Locale.US).format(midnight));
        assertEquals("0:05", new FastDatePrinter("H:mm", UTC, Locale.US).format(midnight));
        assertEquals("00:05", new FastDatePrinter("HH:mm", UTC, Locale.US).format(midnight));
    }

    @Test
    void testHourInAmPmZeroBasedFieldK() {
        final Calendar midnight = utcCalendar(2020, Calendar.JANUARY, 1, 0, 0, 0, 0);
        final Calendar onePm = utcCalendar(2020, Calendar.JANUARY, 1, 13, 0, 0, 0);

        assertEquals("0", new FastDatePrinter("K", UTC, Locale.US).format(midnight));
        assertEquals("1", new FastDatePrinter("K", UTC, Locale.US).format(onePm));
    }

    @Test
    void testDayInWeekFieldMapping() {
        // 2024-01-01 is a Monday; 2023-12-31 is a Sunday.
        final Calendar monday = utcCalendar(2024, Calendar.JANUARY, 1, 0, 0, 0, 0);
        final Calendar sunday = utcCalendar(2023, Calendar.DECEMBER, 31, 0, 0, 0, 0);
        assertEquals(Calendar.MONDAY, monday.get(Calendar.DAY_OF_WEEK));
        assertEquals(Calendar.SUNDAY, sunday.get(Calendar.DAY_OF_WEEK));

        final FastDatePrinter printer = new FastDatePrinter("u", UTC, Locale.US);
        assertEquals("1", printer.format(monday));
        assertEquals("7", printer.format(sunday));
    }

    @Test
    void testWeekYearMatchesCalendarGetWeekYear() {
        final Calendar cal = utcCalendar(2024, Calendar.JUNE, 15, 0, 0, 0, 0);
        final FastDatePrinter printer = new FastDatePrinter("YYYY", UTC, Locale.US);
        assertEquals(String.valueOf(cal.getWeekYear()), printer.format(cal));
    }

    @Test
    void testTextFieldsEraMonthWeekdayAmPm() {
        final Calendar monday = utcCalendar(2024, Calendar.JANUARY, 1, 0, 0, 0, 0);

        assertEquals("AD", new FastDatePrinter("G", UTC, Locale.US).format(monday));
        assertEquals("Monday", new FastDatePrinter("EEEE", UTC, Locale.US).format(monday));
        assertEquals("Mon", new FastDatePrinter("EEE", UTC, Locale.US).format(monday));
        assertEquals("January", new FastDatePrinter("MMMM", UTC, Locale.US).format(monday));
        assertEquals("Jan", new FastDatePrinter("MMM", UTC, Locale.US).format(monday));
        assertEquals("AM", new FastDatePrinter("a", UTC, Locale.US).format(monday));

        final Calendar afternoon = utcCalendar(2024, Calendar.JANUARY, 1, 13, 0, 0, 0);
        assertEquals("PM", new FastDatePrinter("a", UTC, Locale.US).format(afternoon));
    }

    @Test
    void testUnpaddedAndTwoDigitNumberFieldLargeValue() {
        // December 31st is always day-of-year 365 or 366: exercises the
        // >= 100 branches of Unpadded/TwoDigitNumberField.
        final Calendar dec31 = utcCalendar(2024, Calendar.DECEMBER, 31, 0, 0, 0, 0);
        final String expected = String.valueOf(dec31.get(Calendar.DAY_OF_YEAR));

        assertEquals(expected, new FastDatePrinter("D", UTC, Locale.US).format(dec31));
        assertEquals(expected, new FastDatePrinter("DD", UTC, Locale.US).format(dec31));
    }

    @Test
    void testTwoDigitYearField() {
        assertEquals("24", new FastDatePrinter("yy", UTC, Locale.US).format(
                utcCalendar(2024, Calendar.JANUARY, 1, 0, 0, 0, 0)));
        assertEquals("05", new FastDatePrinter("yy", UTC, Locale.US).format(
                utcCalendar(2005, Calendar.JANUARY, 1, 0, 0, 0, 0)));
        assertEquals("99", new FastDatePrinter("yy", UTC, Locale.US).format(
                utcCalendar(1999, Calendar.JANUARY, 1, 0, 0, 0, 0)));
    }

    @Test
    void testParsePatternRuleCount() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.US);
        final List<?> rules = printer.parsePattern();
        // y, -, M, -, d => 5 rules
        assertEquals(5, rules.size());
    }

    @Test
    void testConstructorNullPatternThrowsNullPointerException() {
        assertThrows(NullPointerException.class, () -> new FastDatePrinter(null, UTC, Locale.US));
    }

    @Test
    void testClearStaticCacheDoesNotBreakSubsequentFormatting() {
        final FastDatePrinter printer = new FastDatePrinter("z", UTC, Locale.US);
        final Date date = new Date(0L);
        final String before = printer.format(date);

        FastDatePrinter.clear();

        final String after = printer.format(date);
        assertEquals(before, after);
    }
}
