package org.apache.commons.lang3.time;

import org.junit.jupiter.api.Test;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.TimeZone;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class DurationFormatUtilsAgentTest {

    private static final long DAY = 86400000L;
    private static final long HOUR = 3600000L;
    private static final long MINUTE = 60000L;
    private static final long ZERO = 0L;

    // ---- Constants ----

    @Test
    public void testConstantFieldValues() {
        assertEquals("'P'yyyy'Y'M'M'd'DT'H'H'm'M's.SSS'S'", DurationFormatUtils.ISO_EXTENDED_FORMAT_PATTERN);
        assertEquals("y", DurationFormatUtils.y);
        assertEquals("M", DurationFormatUtils.M);
        assertEquals("d", DurationFormatUtils.d);
        assertEquals("H", DurationFormatUtils.H);
        assertEquals("m", DurationFormatUtils.m);
        assertEquals("s", DurationFormatUtils.s);
        assertEquals("S", DurationFormatUtils.S);
    }

    // ---- Deprecated public constructor ----

    @Test
    @SuppressWarnings("deprecation")
    public void testConstructorIsUsable() {
        assertNotNull(new DurationFormatUtils());
    }

    // ---- formatDuration(long, String) - examples from the class-level javadoc table ----

    @Test
    public void testFormatDurationPatternAllMandatoryTokens() {
        String pattern = "d'd'H'h'm'm's's'";
        assertEquals("1d0h0m0s", DurationFormatUtils.formatDuration(DAY, pattern));
        assertEquals("0d1h0m0s", DurationFormatUtils.formatDuration(HOUR, pattern));
        assertEquals("0d0h1m0s", DurationFormatUtils.formatDuration(MINUTE, pattern));
        assertEquals("0d0h0m0s", DurationFormatUtils.formatDuration(ZERO, pattern));
    }

    @Test
    public void testFormatDurationPatternTrailingOptionalBlock() {
        String pattern = "d'd'[H'h'm'm']s's'";
        assertEquals("1d0s", DurationFormatUtils.formatDuration(DAY, pattern));
        assertEquals("0d1h0s", DurationFormatUtils.formatDuration(HOUR, pattern));
        assertEquals("0d1m0s", DurationFormatUtils.formatDuration(MINUTE, pattern));
        assertEquals("0d0s", DurationFormatUtils.formatDuration(ZERO, pattern));
    }

    @Test
    public void testFormatDurationPatternLeadingOptionalBlock() {
        String pattern = "[d'd'H'h'm'm']s's'";
        assertEquals("1d0s", DurationFormatUtils.formatDuration(DAY, pattern));
        assertEquals("1h0s", DurationFormatUtils.formatDuration(HOUR, pattern));
        assertEquals("1m0s", DurationFormatUtils.formatDuration(MINUTE, pattern));
        assertEquals("0s", DurationFormatUtils.formatDuration(ZERO, pattern));
    }

    @Test
    public void testFormatDurationPatternWhollyOptionalCanBeEmpty() {
        String pattern = "[d'd'H'h'm'm's's']";
        assertEquals("1d", DurationFormatUtils.formatDuration(DAY, pattern));
        assertEquals("1h", DurationFormatUtils.formatDuration(HOUR, pattern));
        assertEquals("1m", DurationFormatUtils.formatDuration(MINUTE, pattern));
        assertEquals("", DurationFormatUtils.formatDuration(ZERO, pattern));
    }

    @Test
    public void testFormatDurationPatternLeadingOptionalLiteral() {
        String pattern = "['{'d'}']HH':'mm";
        assertEquals("{1}00:00", DurationFormatUtils.formatDuration(DAY, pattern));
        assertEquals("01:00", DurationFormatUtils.formatDuration(HOUR, pattern));
        assertEquals("00:01", DurationFormatUtils.formatDuration(MINUTE, pattern));
        assertEquals("00:00", DurationFormatUtils.formatDuration(ZERO, pattern));
    }

    @Test
    public void testFormatDurationPatternMultipleOptionalBlocks() {
        String pattern = "['{'dd'}']['<'HH'>']['('mm')']";
        assertEquals("{01}", DurationFormatUtils.formatDuration(DAY, pattern));
        assertEquals("<01>", DurationFormatUtils.formatDuration(HOUR, pattern));
        assertEquals("(00)", DurationFormatUtils.formatDuration(MINUTE, pattern));
        assertEquals("", DurationFormatUtils.formatDuration(ZERO, pattern));
    }

    @Test
    public void testFormatDurationPatternOptionalTokensWithoutLiterals() {
        String pattern = "[dHms]";
        assertEquals("1", DurationFormatUtils.formatDuration(DAY, pattern));
        assertEquals("1", DurationFormatUtils.formatDuration(HOUR, pattern));
        assertEquals("1", DurationFormatUtils.formatDuration(MINUTE, pattern));
        assertEquals("", DurationFormatUtils.formatDuration(ZERO, pattern));
    }

    @Test
    public void testFormatDurationPadsWithZerosByDefault() {
        assertEquals("0005", DurationFormatUtils.formatDuration(5000L, "ssss"));
    }

    @Test
    public void testFormatDurationNegativeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                DurationFormatUtils.formatDuration(-1L, "ss");
            }
        });
    }

    // ---- formatDuration(long, String, boolean) ----

    @Test
    public void testFormatDurationWithPaddingFlag() {
        assertEquals("01:01", DurationFormatUtils.formatDuration(61000L, "mm:ss", true));
        assertEquals("1:1", DurationFormatUtils.formatDuration(61000L, "mm:ss", false));
    }

    @Test
    public void testFormatDurationWithPaddingFlagNegativeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                DurationFormatUtils.formatDuration(-5L, "ss", false);
            }
        });
    }

    // ---- formatDurationHMS(long) ----

    @Test
    public void testFormatDurationHMS() {
        assertEquals("00:00:00.000", DurationFormatUtils.formatDurationHMS(0L));
        assertEquals("01:01:01.001", DurationFormatUtils.formatDurationHMS(3661001L));
    }

    @Test
    public void testFormatDurationHMSNegativeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                DurationFormatUtils.formatDurationHMS(-1L);
            }
        });
    }

    // ---- formatDurationISO(long) ----

    @Test
    public void testFormatDurationISO() {
        assertEquals("P0000Y0M0DT0H0M0.000S", DurationFormatUtils.formatDurationISO(0L));
        assertEquals("P0000Y0M0DT1H1M1.001S", DurationFormatUtils.formatDurationISO(3661001L));
    }

    @Test
    public void testFormatDurationISONegativeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                DurationFormatUtils.formatDurationISO(-1L);
            }
        });
    }

    // ---- formatDurationWords(long, boolean, boolean) ----

    @Test
    public void testFormatDurationWordsNegativeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                DurationFormatUtils.formatDurationWords(-1L, false, false);
            }
        });
    }

    @Test
    public void testFormatDurationWordsReturnsNonNullContainingAllUnits() {
        String words = DurationFormatUtils.formatDurationWords(0L, false, false);
        assertNotNull(words);
        String lower = words.toLowerCase();
        assertTrue(lower.contains("day"));
        assertTrue(lower.contains("hour"));
        assertTrue(lower.contains("minute"));
        assertTrue(lower.contains("second"));
    }

    @Test
    public void testFormatDurationWordsSuppressionNeverLengthensOutput() {
        String unsuppressed = DurationFormatUtils.formatDurationWords(0L, false, false);
        String suppressed = DurationFormatUtils.formatDurationWords(0L, true, true);
        assertNotNull(suppressed);
        assertTrue(suppressed.length() <= unsuppressed.length());
    }

    @Test
    public void testFormatDurationWordsSuppressionHasNoEffectWhenNoZeroElements() {
        long durationMillis = DAY + HOUR + MINUTE + 1000L;
        String noSuppress = DurationFormatUtils.formatDurationWords(durationMillis, false, false);
        String leadingSuppressed = DurationFormatUtils.formatDurationWords(durationMillis, true, false);
        String trailingSuppressed = DurationFormatUtils.formatDurationWords(durationMillis, false, true);
        String bothSuppressed = DurationFormatUtils.formatDurationWords(durationMillis, true, true);
        assertEquals(noSuppress, leadingSuppressed);
        assertEquals(noSuppress, trailingSuppressed);
        assertEquals(noSuppress, bothSuppressed);
    }

    // ---- formatPeriod(long, long, String) ----

    @Test
    public void testFormatPeriodStartAfterEndThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                DurationFormatUtils.formatPeriod(1000L, 0L, "ss");
            }
        });
    }

    @Test
    public void testFormatPeriodDefaultsToPadding() {
        long start = utcMillis(2017, Calendar.JANUARY, 15);
        long end = utcMillis(2017, Calendar.MARCH, 10);
        assertEquals("01m26d", DurationFormatUtils.formatPeriod(start, end, "MM'm'dd'd'"));
    }

    // ---- formatPeriod(long, long, String, boolean, TimeZone) ----

    @Test
    public void testFormatPeriodMonthDayBorrowAlgorithm() {
        TimeZone utc = TimeZone.getTimeZone("UTC");
        long start = utcMillis(2017, Calendar.JANUARY, 15);
        long end = utcMillis(2017, Calendar.MARCH, 10);
        assertEquals("1m26d", DurationFormatUtils.formatPeriod(start, end, "M'm'd'd'", true, utc));
        assertEquals("01m26d", DurationFormatUtils.formatPeriod(start, end, "MM'm'dd'd'", true, utc));
        assertEquals("1m26d", DurationFormatUtils.formatPeriod(start, end, "MM'm'dd'd'", false, utc));
    }

    @Test
    public void testFormatPeriodSameInstantIsAllZero() {
        TimeZone utc = TimeZone.getTimeZone("UTC");
        long instant = utcMillis(2020, Calendar.JUNE, 1);
        assertEquals("0m0d", DurationFormatUtils.formatPeriod(instant, instant, "M'm'd'd'", true, utc));
    }

    @Test
    public void testFormatPeriodWithTimeZoneStartAfterEndThrows() {
        final TimeZone utc = TimeZone.getTimeZone("UTC");
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                DurationFormatUtils.formatPeriod(1000L, 0L, "ss", true, utc);
            }
        });
    }

    // ---- formatPeriodISO(long, long) ----

    @Test
    public void testFormatPeriodISOSameInstant() {
        long instant = utcMillis(2020, Calendar.JUNE, 1);
        assertEquals("P0000Y0M0DT0H0M0.000S", DurationFormatUtils.formatPeriodISO(instant, instant));
    }

    @Test
    public void testFormatPeriodISOMonthDayBorrowAlgorithm() {
        long start = utcMillis(2017, Calendar.JANUARY, 15);
        long end = utcMillis(2017, Calendar.MARCH, 10);
        assertEquals("P0000Y1M26DT0H0M0.000S", DurationFormatUtils.formatPeriodISO(start, end));
    }

    @Test
    public void testFormatPeriodISOStartAfterEndThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                DurationFormatUtils.formatPeriodISO(1000L, 0L);
            }
        });
    }

    // ---- lexx(String) ----

    @Test
    public void testLexxRecognizesPatternTokenCharacters() {
        DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("yyyy-MM-dd");
        assertTrue(DurationFormatUtils.Token.containsTokenWithValue(tokens, DurationFormatUtils.y));
        assertTrue(DurationFormatUtils.Token.containsTokenWithValue(tokens, DurationFormatUtils.M));
        assertTrue(DurationFormatUtils.Token.containsTokenWithValue(tokens, DurationFormatUtils.d));
        assertFalse(DurationFormatUtils.Token.containsTokenWithValue(tokens, DurationFormatUtils.H));
    }

    @Test
    public void testLexxThenFormatMatchesFormatDuration() {
        String pattern = "d'd'H'h'm'm's's'";
        long durationMillis = DAY + HOUR + MINUTE + 1000L;
        DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx(pattern);
        String viaTokens = DurationFormatUtils.format(tokens, 0L, 0L, 1L, 1L, 1L, 1L, 0L, true);
        String viaFormatDuration = DurationFormatUtils.formatDuration(durationMillis, pattern, true);
        assertEquals("1d1h1m1s", viaFormatDuration);
        assertEquals(viaFormatDuration, viaTokens);
    }

    // ---- format(Token[], ...) - the internal formatting method ----

    @Test
    public void testFormatWithMandatoryFieldToken() {
        DurationFormatUtils.Token[] tokens = new DurationFormatUtils.Token[] {
            new DurationFormatUtils.Token(DurationFormatUtils.d, false, 0)
        };
        assertEquals("5", DurationFormatUtils.format(tokens, 0L, 0L, 5L, 0L, 0L, 0L, 0L, true));
    }

    @Test
    public void testFormatWithLiteralToken() {
        DurationFormatUtils.Token[] tokens = new DurationFormatUtils.Token[] {
            new DurationFormatUtils.Token("abc", false, 0)
        };
        assertEquals("abc", DurationFormatUtils.format(tokens, 0L, 0L, 0L, 0L, 0L, 0L, 0L, true));
    }

    @Test
    public void testFormatPadsRepeatedTokenToItsCount() {
        DurationFormatUtils.Token dToken = new DurationFormatUtils.Token(DurationFormatUtils.d, false, 0);
        dToken.increment();
        dToken.increment();
        DurationFormatUtils.Token[] tokens = new DurationFormatUtils.Token[] { dToken };
        assertEquals("005", DurationFormatUtils.format(tokens, 0L, 0L, 5L, 0L, 0L, 0L, 0L, true));
        assertEquals("5", DurationFormatUtils.format(tokens, 0L, 0L, 5L, 0L, 0L, 0L, 0L, false));
    }

    @Test
    public void testFormatOptionalTokenSuppressedWhenZero() {
        DurationFormatUtils.Token[] tokens = new DurationFormatUtils.Token[] {
            new DurationFormatUtils.Token(DurationFormatUtils.d, true, 0)
        };
        assertEquals("", DurationFormatUtils.format(tokens, 0L, 0L, 0L, 0L, 0L, 0L, 0L, true));
        assertEquals("3", DurationFormatUtils.format(tokens, 0L, 0L, 3L, 0L, 0L, 0L, 0L, true));
    }

    @Test
    public void testFormatOptionalLiteralFollowsPrecedingNonLiteral() {
        DurationFormatUtils.Token[] tokens = new DurationFormatUtils.Token[] {
            new DurationFormatUtils.Token(DurationFormatUtils.d, true, 0),
            new DurationFormatUtils.Token(" days", true, 0)
        };
        assertEquals("", DurationFormatUtils.format(tokens, 0L, 0L, 0L, 0L, 0L, 0L, 0L, true));
        assertEquals("3 days", DurationFormatUtils.format(tokens, 0L, 0L, 3L, 0L, 0L, 0L, 0L, true));
    }

    // ---- Token ----

    @Test
    public void testTokenGetValueAndInitialCount() {
        DurationFormatUtils.Token token = new DurationFormatUtils.Token(DurationFormatUtils.d, false, 0);
        assertEquals(DurationFormatUtils.d, token.getValue());
        assertEquals(1, token.getCount());
    }

    @Test
    public void testTokenIncrementIncreasesCount() {
        DurationFormatUtils.Token token = new DurationFormatUtils.Token(DurationFormatUtils.d, false, 0);
        token.increment();
        assertEquals(2, token.getCount());
        token.increment();
        assertEquals(3, token.getCount());
    }

    @Test
    public void testTokenEqualsBasedOnValue() {
        DurationFormatUtils.Token a = new DurationFormatUtils.Token("d", false, 0);
        DurationFormatUtils.Token b = new DurationFormatUtils.Token("d", true, 7);
        DurationFormatUtils.Token c = new DurationFormatUtils.Token("s", false, 0);
        assertTrue(a.equals(b));
        assertFalse(a.equals(c));
        assertFalse(a.equals("d"));
    }

    @Test
    public void testTokenHashCodeMatchesValueHashCode() {
        DurationFormatUtils.Token token = new DurationFormatUtils.Token(DurationFormatUtils.d, false, 0);
        assertEquals("d".hashCode(), token.hashCode());
    }

    @Test
    public void testTokenContainsTokenWithValue() {
        DurationFormatUtils.Token[] tokens = new DurationFormatUtils.Token[] {
            new DurationFormatUtils.Token(DurationFormatUtils.d, false, 0),
            new DurationFormatUtils.Token(DurationFormatUtils.H, false, 0)
        };
        assertTrue(DurationFormatUtils.Token.containsTokenWithValue(tokens, DurationFormatUtils.d));
        assertTrue(DurationFormatUtils.Token.containsTokenWithValue(tokens, DurationFormatUtils.H));
        assertFalse(DurationFormatUtils.Token.containsTokenWithValue(tokens, DurationFormatUtils.s));
    }

    @Test
    public void testTokenToStringIsNotNull() {
        DurationFormatUtils.Token token = new DurationFormatUtils.Token(DurationFormatUtils.d, false, 0);
        assertNotNull(token.toString());
    }

    // ---- helpers ----

    private static long utcMillis(int year, int month, int dayOfMonth) {
        Calendar calendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
        calendar.clear();
        calendar.set(year, month, dayOfMonth, 0, 0, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        return calendar.getTimeInMillis();
    }
}
