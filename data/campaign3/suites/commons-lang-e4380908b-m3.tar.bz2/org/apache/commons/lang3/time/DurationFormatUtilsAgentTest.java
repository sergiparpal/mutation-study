/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.util.Calendar;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link DurationFormatUtils}.
 */
class DurationFormatUtilsAgentTest {

    @Test
    void testFormatDurationBasic() {
        assertEquals("0:0:0:0", DurationFormatUtils.formatDuration(0, "d:H:m:s"));
        assertEquals("1:1:1:1", DurationFormatUtils.formatDuration(90061000L, "d:H:m:s"));
        assertEquals("1:1:1:1", DurationFormatUtils.formatDuration(90061000L, "d:H:m:s", false));
    }

    @Test
    void testFormatDurationNegativeThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatDuration(-1, "d:H:m:s");
            }
        });
        assertTrue(ex.getMessage().contains("durationMillis"));
    }

    @Test
    void testFormatDurationZeroBoundary() {
        assertEquals("0", DurationFormatUtils.formatDuration(0, "s"));
    }

    @Test
    void testFormatDurationMillisecondWidthForcedToThreeAfterSeconds() {
        // After an 's' token, 'S' is always at least 3 digits wide, even without padding.
        assertEquals("1.005", DurationFormatUtils.formatDuration(1005, "s.S", false));
        assertEquals("1.005", DurationFormatUtils.formatDuration(1005, "s.SSS"));
    }

    @Test
    void testFormatDurationMillisecondWithoutPrecedingSeconds() {
        assertEquals("5", DurationFormatUtils.formatDuration(5, "S"));
        assertEquals("00005", DurationFormatUtils.formatDuration(5, "SSSSS"));
    }

    @Test
    void testFormatDurationLiteralText() {
        assertEquals("1 days 1 hours 1 minutes 1.023 seconds",
                DurationFormatUtils.formatDuration(90061023L, "d' days 'H' hours 'm' minutes 's.S' seconds'"));
    }

    @Test
    void testFormatDurationEscapedQuoteLiteral() {
        // d''d -> a literal day digit, a literal apostrophe, then another literal day digit.
        assertEquals("0'0", DurationFormatUtils.formatDuration(0, "d''d"));
    }

    @Test
    void testFormatDurationOptionalBlockWithTrailingLiteral() {
        assertEquals("1d0s", DurationFormatUtils.formatDuration(86400000L, "d'd'[H'h'm'm']s's'"));
        assertEquals("0d1h0s", DurationFormatUtils.formatDuration(3600000L, "d'd'[H'h'm'm']s's'"));
        assertEquals("0d0s", DurationFormatUtils.formatDuration(0L, "d'd'[H'h'm'm']s's'"));
    }

    @Test
    void testFormatDurationOptionalBlockLeading() {
        assertEquals("1d0s", DurationFormatUtils.formatDuration(86400000L, "[d'd'H'h'm'm']s's'"));
        assertEquals("1h0s", DurationFormatUtils.formatDuration(3600000L, "[d'd'H'h'm'm']s's'"));
        assertEquals("0s", DurationFormatUtils.formatDuration(0L, "[d'd'H'h'm'm']s's'"));
    }

    @Test
    void testFormatDurationOptionalBlockEverything() {
        assertEquals("1d", DurationFormatUtils.formatDuration(86400000L, "[d'd'H'h'm'm's's']"));
        assertEquals("", DurationFormatUtils.formatDuration(0L, "[d'd'H'h'm'm's's']"));
    }

    @Test
    void testFormatDurationMultipleOptionalBlocks() {
        assertEquals("{1}00:00", DurationFormatUtils.formatDuration(86400000L, "['{'d'}']HH':'mm"));
        assertEquals("01:00", DurationFormatUtils.formatDuration(3600000L, "['{'d'}']HH':'mm"));
        assertEquals("00:00", DurationFormatUtils.formatDuration(0L, "['{'d'}']HH':'mm"));
    }

    @Test
    void testFormatDurationOptionalNoLiterals() {
        final long sum = 86400000L + 3600000 + 60000 + 1000;
        assertEquals("1111", DurationFormatUtils.formatDuration(sum, "[dHms]"));
        assertEquals("", DurationFormatUtils.formatDuration(0L, "[dHms]"));
    }

    @Test
    void testFormatDurationNestedOptionalThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatDuration(0, "[d[H]]");
            }
        });
        assertTrue(ex.getMessage().contains("Nested optional"));
    }

    @Test
    void testFormatDurationUnopenedOptionalCloseThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatDuration(0, "d]");
            }
        });
        assertTrue(ex.getMessage().contains("unopened optional"));
    }

    @Test
    void testFormatDurationUnmatchedOptionalThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatDuration(0, "[d");
            }
        });
        assertTrue(ex.getMessage().contains("Unmatched optional"));
    }

    @Test
    void testFormatDurationUnmatchedQuoteThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatDuration(0, "d'abc");
            }
        });
        assertTrue(ex.getMessage().contains("Unmatched quote"));
    }

    @Test
    void testFormatDurationHMS() {
        assertEquals("00:00:00.000", DurationFormatUtils.formatDurationHMS(0));
        assertEquals("01:01:01.001", DurationFormatUtils.formatDurationHMS(3661001));
    }

    @Test
    void testFormatDurationISO() {
        assertEquals("P0Y0M0DT0H0M0.000S", DurationFormatUtils.formatDurationISO(0));
        assertEquals("P0Y0M0DT1H1M1.001S", DurationFormatUtils.formatDurationISO(3661001));
    }

    @Test
    void testFormatDurationWordsNoSuppression() {
        assertEquals("0 days 0 hours 0 minutes 0 seconds", DurationFormatUtils.formatDurationWords(0, false, false));
        assertEquals("0 days 0 hours 0 minutes 1 second", DurationFormatUtils.formatDurationWords(1000, false, false));
        final long sum = 86400000L + 3600000 + 60000 + 1000;
        assertEquals("1 day 1 hour 1 minute 1 second", DurationFormatUtils.formatDurationWords(sum, false, false));
    }

    @Test
    void testFormatDurationWordsSuppressBoth() {
        assertEquals("0 seconds", DurationFormatUtils.formatDurationWords(0, true, true));
        assertEquals("1 day", DurationFormatUtils.formatDurationWords(86400000L, true, true));
        assertEquals("1 minute", DurationFormatUtils.formatDurationWords(60000, true, true));
        assertEquals("1 hour", DurationFormatUtils.formatDurationWords(3600000, true, true));
    }

    @Test
    void testFormatPeriodBasic() {
        final TimeZone gmt = TimeZone.getTimeZone("GMT");
        assertEquals("0:0:0:0", DurationFormatUtils.formatPeriod(1000, 1000, "d:H:m:s", true, gmt));
    }

    @Test
    void testFormatPeriodStartGreaterThanEndThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatPeriod(10, 5, "d");
            }
        });
        assertTrue(ex.getMessage().contains("startMillis"));
    }

    @Test
    void testFormatPeriodMonthsAndDaysBorrowFromStartMonth() {
        final TimeZone gmt = TimeZone.getTimeZone("GMT");
        final Calendar start = Calendar.getInstance(gmt);
        start.clear();
        start.set(2000, Calendar.JANUARY, 15);
        final Calendar end = Calendar.getInstance(gmt);
        end.clear();
        end.set(2000, Calendar.MARCH, 10);
        // Expect 1 month and 26 days, per the class javadoc example (borrowing February's length).
        assertEquals("1M26D", DurationFormatUtils.formatPeriod(start.getTimeInMillis(), end.getTimeInMillis(), "M'M'd'D'", true, gmt));
    }

    @Test
    void testFormatPeriodISO() {
        final TimeZone gmt = TimeZone.getTimeZone("GMT");
        final Calendar start = Calendar.getInstance(gmt);
        start.clear();
        start.set(2000, Calendar.JANUARY, 15);
        final Calendar end = Calendar.getInstance(gmt);
        end.clear();
        end.set(2000, Calendar.MARCH, 10);
        assertEquals("P0Y1M26DT0H0M0.000S", DurationFormatUtils.formatPeriodISO(start.getTimeInMillis(), end.getTimeInMillis()));
    }

    @Test
    void testIsoExtendedFormatPatternConstant() {
        assertEquals("'P'yyyy'Y'M'M'd'DT'H'H'm'M's.SSS'S'", DurationFormatUtils.ISO_EXTENDED_FORMAT_PATTERN);
    }

    @Test
    void testDeprecatedPublicConstructor() {
        assertNotNull(new DurationFormatUtils());
    }

    @Test
    void testLexxTokenizesRepeatedAndLiteralSections() {
        final DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("d'd'H'h'm'm's's'");
        assertEquals(8, tokens.length);
        final StringBuilder rejoined = new StringBuilder();
        for (int i = 0; i < tokens.length; i++) {
            rejoined.append(tokens[i].toString());
        }
        assertEquals("ddHhmmss", rejoined.toString());
    }

    @Test
    void testLexxCollapsesRepeatedTokenChars() {
        final DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("yyyyyy");
        assertEquals(1, tokens.length);
        assertEquals(6, tokens[0].getCount());
        assertEquals("y", tokens[0].getValue());
    }

    @Test
    void testLexxUnrecognizedCharsBecomeLiteral() {
        final DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("abc");
        assertEquals(1, tokens.length);
        assertEquals("abc", tokens[0].toString());
    }

    @Test
    void testLexxSingleUnmatchedQuoteThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.lexx("'");
            }
        });
        assertTrue(ex.getMessage().contains("Unmatched quote"));
    }

    @Test
    void testTokenContainsTokenWithValue() {
        final DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("d'd'H'h'm'm's's'");
        assertTrue(DurationFormatUtils.Token.containsTokenWithValue(tokens, DurationFormatUtils.d));
        assertFalse(DurationFormatUtils.Token.containsTokenWithValue(tokens, DurationFormatUtils.y));
    }

    @Test
    void testTokenEqualsAndHashCodeAndIncrement() {
        final DurationFormatUtils.Token tokA = new DurationFormatUtils.Token(DurationFormatUtils.d, false, -1);
        final DurationFormatUtils.Token tokB = new DurationFormatUtils.Token(DurationFormatUtils.d, false, -1);
        tokB.increment();
        assertEquals(1, tokA.getCount());
        assertFalse(tokA.equals(tokB));
        tokA.increment();
        assertEquals(2, tokA.getCount());
        assertTrue(tokA.equals(tokB));
        assertFalse(tokA.equals("not a token"));
        assertEquals(DurationFormatUtils.d.hashCode(), tokA.hashCode());
    }

    @Test
    void testTokenConstructorRejectsNullValue() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new DurationFormatUtils.Token(null, false, -1);
            }
        });
    }

    @Test
    void testFormatDirectWithTokens() {
        final DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("d'd'H'h'm'm's's'");
        final String formatted = DurationFormatUtils.format(tokens, 0, 0, 1, 2, 3, 4, 0, true);
        assertEquals("1d2h3m4s", formatted);
    }

    @Test
    void testFormatDurationLargeValue() {
        // 2 days, 3 hours, 4 minutes, 5 seconds, 6 milliseconds.
        final long millis = 2L * 24 * 60 * 60 * 1000 + 3L * 60 * 60 * 1000 + 4L * 60 * 1000 + 5L * 1000 + 6L;
        assertEquals("02:03:04:05.006", DurationFormatUtils.formatDuration(millis, "dd:HH:mm:ss.SSS"));
    }

    @Test
    void testFormatDurationMaxLongDoesNotThrow() {
        final String result = DurationFormatUtils.formatDuration(Long.MAX_VALUE, "d:H:m:s");
        assertNotNull(result);
        assertTrue(result.length() > 0);
    }
}
