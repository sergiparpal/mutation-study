/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link FastDateParser}.
 */
class FastDateParserAgentTest {

    private static final TimeZone UTC = TimeZone.getTimeZone("UTC");

    private static Date buildDate(final TimeZone tz, final int year, final int month, final int day) {
        final Calendar cal = Calendar.getInstance(tz, Locale.US);
        cal.clear();
        cal.set(year, month, day);
        return cal.getTime();
    }

    @Test
    void testGetPatternLocaleTimeZone() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        assertEquals("yyyy-MM-dd", parser.getPattern());
        assertEquals(UTC, parser.getTimeZone());
        assertEquals(Locale.US, parser.getLocale());
    }

    @Test
    void testNullLocaleDefaultsToSystemDefault() {
        final FastDateParser parser = new FastDateParser("yyyy", UTC, null);
        assertEquals(Locale.getDefault(), parser.getLocale());
    }

    @Test
    void testNullPatternThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                new FastDateParser(null, UTC, Locale.US);
            }
        });
    }

    @Test
    void testNullTimeZoneThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                new FastDateParser("yyyy", null, Locale.US);
            }
        });
    }

    @Test
    void testParseBasicDate() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final Date date = parser.parse("2023-06-15");
        assertEquals(buildDate(UTC, 2023, Calendar.JUNE, 15), date);
    }

    @Test
    void testParseWithTimeFields() {
        final FastDateParser parser = new FastDateParser("HH:mm:ss", UTC, Locale.US);
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.clear();
        final ParsePosition pos = new ParsePosition(0);
        final boolean ok = parser.parse("23:59:58", pos, cal);
        assertTrue(ok);
        assertEquals(23, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals(59, cal.get(Calendar.MINUTE));
        assertEquals(58, cal.get(Calendar.SECOND));
        assertEquals(8, pos.getIndex());
    }

    @Test
    void testParseStopsAtPartialMatchAndLeavesRemainder() {
        final FastDateParser parser = new FastDateParser("yyyy/MM/dd", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("2020/01/02 extra", pos);
        assertNotNull(date);
        assertEquals(10, pos.getIndex());
        assertEquals(-1, pos.getErrorIndex());
        assertEquals(buildDate(UTC, 2020, Calendar.JANUARY, 2), date);
    }

    @Test
    void testParseWithParsePositionFailureReturnsNullAndLeavesIndexUnmoved() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("not-a-date", pos);
        assertNull(date);
        assertTrue(pos.getErrorIndex() >= 0);
        assertEquals(0, pos.getIndex());
    }

    @Test
    void testParseStringThrowsParseExceptionOnUnparseable() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final ParseException ex = assertThrows(ParseException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                parser.parse("banana");
            }
        });
        assertTrue(ex.getMessage().contains("Unparseable date"));
        assertEquals(0, ex.getErrorOffset());
    }

    @Test
    void testParseCalendarOverloadFailureSetsErrorIndex() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final boolean ok = parser.parse("xx", pos, cal);
        assertFalse(ok);
        assertTrue(pos.getErrorIndex() >= 0);
    }

    @Test
    void testParseObjectDelegatesToParse() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final Object obj = parser.parseObject("2001-02-03");
        assertTrue(obj instanceof Date);
        assertEquals(parser.parse("2001-02-03"), obj);
    }

    @Test
    void testParseObjectWithPositionReturnsNullOnFailure() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Object obj = parser.parseObject("nope", pos);
        assertNull(obj);
    }

    @Test
    void testEqualsAndHashCodeContract() {
        final FastDateParser p1 = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final FastDateParser p2 = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final FastDateParser p3 = new FastDateParser("yyyy/MM/dd", UTC, Locale.US);
        assertEquals(p1, p2);
        assertEquals(p1.hashCode(), p2.hashCode());
        assertNotEquals(p1, p3);
        assertNotEquals(p1, null);
        assertNotEquals(p1, "yyyy-MM-dd");
    }

    @Test
    void testToStringAndToStringAllContainPattern() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        assertTrue(parser.toString().contains("yyyy-MM-dd"));
        assertTrue(parser.toStringAll().contains("yyyy-MM-dd"));
    }

    @Test
    void testUnsupportedPatternLetterThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new FastDateParser("qqqq", UTC, Locale.US);
            }
        });
        assertTrue(ex.getMessage().contains("not supported"));
    }

    @Test
    void testUnterminatedQuoteThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new FastDateParser("yyyy'", UTC, Locale.US);
            }
        });
        assertEquals("Unterminated quote", ex.getMessage());
    }

    @Test
    void testInvalidIsoTimeZoneWidthThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new FastDateParser("XXXX", UTC, Locale.US);
            }
        });
    }

    @Test
    void testLiteralQuotedTextMustMatchExactly() {
        final FastDateParser parser = new FastDateParser("'Date:' yyyy-MM-dd", UTC, Locale.US);

        final ParsePosition okPos = new ParsePosition(0);
        final Date ok = parser.parse("Date: 2022-05-01", okPos);
        assertNotNull(ok);
        assertEquals(buildDate(UTC, 2022, Calendar.MAY, 1), ok);

        final ParsePosition failPos = new ParsePosition(0);
        final Date fail = parser.parse("Day: 2022-05-01", failPos);
        assertNull(fail);
        assertTrue(failPos.getErrorIndex() >= 0);
    }

    @Test
    void testTwoDigitYearAdjustmentWithExplicitCenturyStart() {
        final Calendar centuryCal = Calendar.getInstance(UTC, Locale.US);
        centuryCal.clear();
        centuryCal.set(1980, Calendar.JANUARY, 1);
        final Date centuryStart = centuryCal.getTime();

        final FastDateParser parser = new FastDateParser("yy", UTC, Locale.US, centuryStart);

        final Calendar c85 = Calendar.getInstance(UTC, Locale.US);
        c85.setTime(parser.parse("85", new ParsePosition(0)));
        assertEquals(1985, c85.get(Calendar.YEAR));

        final Calendar c30 = Calendar.getInstance(UTC, Locale.US);
        c30.setTime(parser.parse("30", new ParsePosition(0)));
        assertEquals(2030, c30.get(Calendar.YEAR));
    }

    @Test
    void testLargeNumericOverflowFailsGracefullyInsteadOfThrowing() {
        final FastDateParser parser = new FastDateParser("yyyy", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("99999999999999999999", pos);
        assertNull(date);
        assertTrue(pos.getErrorIndex() >= 0);
    }

    @Test
    void testIso8601TimeZoneOffsetIsApplied() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd'T'HH:mm:ssX", UTC, Locale.US);
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.clear();
        final ParsePosition pos = new ParsePosition(0);
        final boolean ok = parser.parse("2023-01-01T10:00:00+02", pos, cal);
        assertTrue(ok);
        assertEquals(2 * 60 * 60 * 1000, cal.getTimeZone().getRawOffset());
    }

    @Test
    void testRfc822TimeZoneOffsetIsApplied() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd'T'HH:mm:ssZ", UTC, Locale.US);
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.clear();
        final ParsePosition pos = new ParsePosition(0);
        final boolean ok = parser.parse("2023-01-01T10:00:00+0200", pos, cal);
        assertTrue(ok);
        assertEquals(2 * 60 * 60 * 1000, cal.getTimeZone().getRawOffset());
    }

    @Test
    void testMonthZeroBasedConversion() {
        final FastDateParser parser = new FastDateParser("MM", UTC, Locale.US);
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.clear();
        final boolean ok = parser.parse("01", new ParsePosition(0), cal);
        assertTrue(ok);
        assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));
    }

    @Test
    void testHour12MidnightWrapsToZero() {
        final FastDateParser parser = new FastDateParser("hh", UTC, Locale.US);
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.clear();
        final boolean ok = parser.parse("12", new ParsePosition(0), cal);
        assertTrue(ok);
        assertEquals(0, cal.get(Calendar.HOUR));
    }

    @Test
    void testHour24MidnightWrapsToZero() {
        final FastDateParser parser = new FastDateParser("kk", UTC, Locale.US);
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.clear();
        final boolean ok = parser.parse("24", new ParsePosition(0), cal);
        assertTrue(ok);
        assertEquals(0, cal.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    void testSerializationRoundTripPreservesStateAndParsing() throws Exception {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd'T'HH:mm:ss", UTC, Locale.US);

        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        final ObjectOutputStream oos = new ObjectOutputStream(baos);
        oos.writeObject(parser);
        oos.close();

        final ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(baos.toByteArray()));
        final FastDateParser copy = (FastDateParser) ois.readObject();
        ois.close();

        assertEquals(parser, copy);
        assertEquals(parser.getPattern(), copy.getPattern());

        final Date original = parser.parse("2023-06-15T10:20:30");
        final Date fromCopy = copy.parse("2023-06-15T10:20:30");
        assertEquals(original, fromCopy);
    }
}
