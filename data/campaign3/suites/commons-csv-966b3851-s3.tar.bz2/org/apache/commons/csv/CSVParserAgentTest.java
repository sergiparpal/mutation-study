package org.apache.commons.csv;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.Writer;
import java.net.URL;
import java.nio.file.Path;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Self-contained tests for {@link CSVParser} based on its documented contract.
 */
public class CSVParserAgentTest {

    /** A Reader whose every read() call fails, used to exercise error propagation. */
    private static final class ThrowingReader extends Reader {
        public int read(char[] cbuf, int off, int len) throws IOException {
            throw new IOException("simulated read failure");
        }

        public void close() {
            // no resources to release
        }
    }

    private static File createTempCsvFile(String content) throws IOException {
        File file = File.createTempFile("csv-parser-agent-test", ".csv");
        file.deleteOnExit();
        Writer writer = new FileWriter(file);
        writer.write(content);
        writer.close();
        return file;
    }

    // ---- parse(String, CSVFormat) ----

    @Test
    public void testParseStringProducesExpectedRecords() throws IOException {
        CSVParser parser = CSVParser.parse("a,b,c\n1,2,3\n", CSVFormat.DEFAULT);
        List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        CSVRecord first = records.get(0);
        assertEquals(3, first.size());
        assertEquals("a", first.get(0));
        assertEquals("b", first.get(1));
        assertEquals("c", first.get(2));
        CSVRecord second = records.get(1);
        assertEquals("1", second.get(0));
        assertEquals("2", second.get(1));
        assertEquals("3", second.get(2));
        parser.close();
    }

    @Test
    public void testParseStringNullStringThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                CSVParser.parse((String) null, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    public void testParseStringNullFormatMapsToDefault() throws IOException {
        CSVParser parser = CSVParser.parse("a,b\n", (CSVFormat) null);
        List<CSVRecord> records = parser.getRecords();
        assertEquals(1, records.size());
        assertEquals("a", records.get(0).get(0));
        assertEquals("b", records.get(0).get(1));
        parser.close();
    }

    @Test
    public void testGetRecordsOnEmptyInputIsEmptyNotNull() throws IOException {
        CSVParser parser = CSVParser.parse("", CSVFormat.DEFAULT);
        List<CSVRecord> records = parser.getRecords();
        assertNotNull(records);
        assertTrue(records.isEmpty());
        parser.close();
    }

    // ---- parse(Reader, CSVFormat) ----

    @Test
    public void testParseReaderNullReaderThrowsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                CSVParser.parse((Reader) null, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    public void testParseReaderBasic() throws IOException {
        Reader reader = new StringReader("x,y\n1,2\n");
        CSVParser parser = CSVParser.parse(reader, CSVFormat.DEFAULT);
        List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        parser.close();
    }

    // ---- parse(File, Charset, CSVFormat) ----

    @Test
    public void testParseFileNullFileThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                CSVParser.parse((File) null, java.nio.charset.Charset.defaultCharset(), CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    public void testParseFileBasic() throws IOException {
        File file = createTempCsvFile("h1,h2\nv1,v2\n");
        CSVParser parser = CSVParser.parse(file, java.nio.charset.Charset.defaultCharset(), CSVFormat.DEFAULT);
        List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        assertEquals("v1", records.get(1).get(0));
        parser.close();
    }

    // ---- parse(Path, Charset, CSVFormat) ----

    @Test
    public void testParsePathNullPathThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                CSVParser.parse((Path) null, java.nio.charset.Charset.defaultCharset(), CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    public void testParsePathBasic() throws IOException {
        File file = createTempCsvFile("p1,p2\nq1,q2\n");
        CSVParser parser = CSVParser.parse(file.toPath(), java.nio.charset.Charset.defaultCharset(), CSVFormat.DEFAULT);
        List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        parser.close();
    }

    // ---- parse(URL, Charset, CSVFormat) ----

    @Test
    public void testParseUrlNullUrlThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                CSVParser.parse((URL) null, java.nio.charset.Charset.defaultCharset(), CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    public void testParseUrlBasic() throws IOException {
        File file = createTempCsvFile("u1,u2\nz1,z2\n");
        URL url = file.toURI().toURL();
        CSVParser parser = CSVParser.parse(url, java.nio.charset.Charset.defaultCharset(), CSVFormat.DEFAULT);
        List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        parser.close();
    }

    // ---- deprecated constructors ----

    @SuppressWarnings("deprecation")
    @Test
    public void testDeprecatedConstructorNullReaderThrowsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                new CSVParser((Reader) null, CSVFormat.DEFAULT);
            }
        });
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testDeprecatedConstructorNullFormatThrowsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                new CSVParser(new StringReader("a,b\n"), (CSVFormat) null);
            }
        });
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testDeprecatedConstructorWithOffsetAndRecordNumber() throws IOException {
        CSVParser parser = new CSVParser(new StringReader("a,b\nc,d\n"), CSVFormat.DEFAULT, 0L, 7L);
        CSVRecord record = parser.nextRecord();
        assertNotNull(record);
        assertEquals(7L, parser.getRecordNumber());
        parser.close();
    }

    // ---- builder() ----

    @Test
    public void testBuilderReturnsNewInstanceEachTime() {
        assertNotSame(CSVParser.builder(), CSVParser.builder());
    }

    @Test
    public void testBuilderSettersReturnSameInstanceForFluentChaining() {
        CSVParser.Builder builder = CSVParser.builder();
        assertSame(builder, builder.setFormat(CSVFormat.DEFAULT));
        assertSame(builder, builder.setCharacterOffset(0L));
        assertSame(builder, builder.setByteOffset(-1L));
        assertSame(builder, builder.setRecordNumber(1L));
        assertSame(builder, builder.setTrackBytes(false));
    }

    @Test
    public void testBuilderGetProducesWorkingParser() throws IOException {
        CSVParser parser = CSVParser.builder()
                .setFormat(CSVFormat.DEFAULT)
                .setCharSequence("k1,k2\nm1,m2\n")
                .get();
        List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        assertEquals("k1", records.get(0).get(0));
        parser.close();
    }

    @Test
    public void testBuilderSetRecordNumberAffectsGetRecordNumber() throws IOException {
        CSVParser parser = CSVParser.builder()
                .setFormat(CSVFormat.DEFAULT)
                .setCharSequence("a,b\nc,d\n")
                .setRecordNumber(5L)
                .get();
        CSVRecord record = parser.nextRecord();
        assertNotNull(record);
        assertEquals(5L, parser.getRecordNumber());
        parser.close();
    }

    // ---- nextRecord() ----

    @Test
    public void testNextRecordReturnsRecordsThenNullAtEndOfStream() throws IOException {
        CSVParser parser = CSVParser.parse("a,b\nc,d\n", CSVFormat.DEFAULT);
        CSVRecord first = parser.nextRecord();
        assertNotNull(first);
        assertEquals("a", first.get(0));
        CSVRecord second = parser.nextRecord();
        assertNotNull(second);
        assertEquals("c", second.get(0));
        assertNull(parser.nextRecord());
        assertNull(parser.nextRecord());
        parser.close();
    }

    // ---- getCurrentLineNumber() / getRecordNumber() ----

    @Test
    public void testLineAndRecordNumbersBeforeAndAfterParsing() throws IOException {
        CSVParser parser = CSVParser.parse("a,b\nc,d\ne,f\n", CSVFormat.DEFAULT);
        assertEquals(0L, parser.getCurrentLineNumber());
        assertEquals(0L, parser.getRecordNumber());
        parser.nextRecord();
        assertEquals(1L, parser.getCurrentLineNumber());
        assertEquals(1L, parser.getRecordNumber());
        parser.nextRecord();
        assertEquals(2L, parser.getCurrentLineNumber());
        assertEquals(2L, parser.getRecordNumber());
        parser.close();
    }

    // ---- getFirstEndOfLine() ----

    @Test
    public void testGetFirstEndOfLineLf() throws IOException {
        CSVParser parser = CSVParser.parse("a,b\nc,d\n", CSVFormat.DEFAULT);
        parser.nextRecord();
        assertEquals("\n", parser.getFirstEndOfLine());
        parser.close();
    }

    @Test
    public void testGetFirstEndOfLineCrLf() throws IOException {
        CSVParser parser = CSVParser.parse("a,b\r\nc,d\r\n", CSVFormat.DEFAULT);
        parser.nextRecord();
        assertEquals("\r\n", parser.getFirstEndOfLine());
        parser.close();
    }

    // ---- getHeaderMap() / getHeaderMapRaw() / getHeaderNames() ----

    @Test
    public void testGetHeaderMapReflectsConfiguredHeader() throws IOException {
        CSVFormat format = CSVFormat.Builder.create(CSVFormat.DEFAULT)
                .setHeader("first", "second")
                .setSkipHeaderRecord(true)
                .build();
        CSVParser parser = CSVParser.parse("first,second\n1,2\n", format);
        Map<String, Integer> headerMap = parser.getHeaderMap();
        assertNotNull(headerMap);
        assertEquals(2, headerMap.size());
        assertEquals(Integer.valueOf(0), headerMap.get("first"));
        assertEquals(Integer.valueOf(1), headerMap.get("second"));
        parser.close();
    }

    @Test
    public void testGetHeaderMapIsACopyNotLinkedToSubsequentCalls() throws IOException {
        CSVFormat format = CSVFormat.Builder.create(CSVFormat.DEFAULT)
                .setHeader("only")
                .setSkipHeaderRecord(true)
                .build();
        CSVParser parser = CSVParser.parse("only\n1\n", format);
        Map<String, Integer> firstCopy = parser.getHeaderMap();
        firstCopy.put("injected", 99);
        Map<String, Integer> secondCopy = parser.getHeaderMap();
        assertFalse(secondCopy.containsKey("injected"));
        assertEquals(1, secondCopy.size());
        parser.close();
    }

    @Test
    public void testGetHeaderMapWithNoHeaderIsEmpty() throws IOException {
        CSVParser parser = CSVParser.parse("a,b\n1,2\n", CSVFormat.DEFAULT);
        Map<String, Integer> headerMap = parser.getHeaderMap();
        assertNotNull(headerMap);
        assertTrue(headerMap.isEmpty());
        parser.close();
    }

    @Test
    public void testGetHeaderMapRawReturnsUnderlyingMapInstance() throws IOException {
        CSVFormat format = CSVFormat.Builder.create(CSVFormat.DEFAULT)
                .setHeader("col")
                .setSkipHeaderRecord(true)
                .build();
        CSVParser parser = CSVParser.parse("col\nv\n", format);
        Map<String, Integer> raw1 = parser.getHeaderMapRaw();
        Map<String, Integer> raw2 = parser.getHeaderMapRaw();
        assertSame(raw1, raw2);
        parser.close();
    }

    @Test
    public void testGetHeaderNamesIteratesInColumnOrderAndIsReadOnly() throws IOException {
        CSVFormat format = CSVFormat.Builder.create(CSVFormat.DEFAULT)
                .setHeader("zeta", "alpha")
                .setSkipHeaderRecord(true)
                .build();
        CSVParser parser = CSVParser.parse("zeta,alpha\n1,2\n", format);
        final List<String> headerNames = parser.getHeaderNames();
        assertEquals(2, headerNames.size());
        assertEquals("zeta", headerNames.get(0));
        assertEquals("alpha", headerNames.get(1));
        assertThrows(UnsupportedOperationException.class, new Executable() {
            public void execute() throws Throwable {
                headerNames.add("extra");
            }
        });
        parser.close();
    }

    @Test
    public void testGetHeaderNamesWithNoHeaderIsEmpty() throws IOException {
        CSVParser parser = CSVParser.parse("a,b\n1,2\n", CSVFormat.DEFAULT);
        List<String> headerNames = parser.getHeaderNames();
        assertNotNull(headerNames);
        assertTrue(headerNames.isEmpty());
        parser.close();
    }

    // ---- header / trailer comments ----

    @Test
    public void testHeaderCommentDetectedBeforeHeaderRecord() throws IOException {
        CSVFormat format = CSVFormat.Builder.create(CSVFormat.DEFAULT)
                .setCommentMarker('#')
                .setHeader("col1", "col2")
                .setSkipHeaderRecord(true)
                .build();
        CSVParser parser = CSVParser.parse("# a header comment\ncol1,col2\n1,2\n", format);
        parser.getRecords();
        assertTrue(parser.hasHeaderComment());
        assertNotNull(parser.getHeaderComment());
        assertTrue(parser.getHeaderComment().contains("header comment"));
        parser.close();
    }

    @Test
    public void testNoHeaderCommentWhenNoneProvided() throws IOException {
        CSVParser parser = CSVParser.parse("a,b\n1,2\n", CSVFormat.DEFAULT);
        parser.getRecords();
        assertFalse(parser.hasHeaderComment());
        assertNull(parser.getHeaderComment());
        parser.close();
    }

    @Test
    public void testTrailerCommentAvailableAfterFullyProcessingStream() throws IOException {
        CSVFormat format = CSVFormat.Builder.create(CSVFormat.DEFAULT)
                .setCommentMarker('#')
                .build();
        CSVParser parser = CSVParser.parse("a,b\n1,2\n#trailing remark\n", format);
        assertFalse(parser.hasTrailerComment());
        parser.getRecords();
        assertTrue(parser.hasTrailerComment());
        assertNotNull(parser.getTrailerComment());
        assertTrue(parser.getTrailerComment().contains("trailing remark"));
        parser.close();
    }

    @Test
    public void testNoTrailerCommentWhenNoneProvided() throws IOException {
        CSVParser parser = CSVParser.parse("a,b\n1,2\n", CSVFormat.DEFAULT);
        parser.getRecords();
        assertFalse(parser.hasTrailerComment());
        assertNull(parser.getTrailerComment());
        parser.close();
    }

    // ---- isClosed() / close() ----

    @Test
    public void testIsClosedLifecycle() throws IOException {
        CSVParser parser = CSVParser.parse("a,b\n1,2\n", CSVFormat.DEFAULT);
        assertFalse(parser.isClosed());
        parser.close();
        assertTrue(parser.isClosed());
        parser.close();
        assertTrue(parser.isClosed());
    }

    @Test
    public void testIteratorYieldsNothingAfterParserIsClosed() throws IOException {
        CSVParser parser = CSVParser.parse("a,b\nc,d\n", CSVFormat.DEFAULT);
        parser.close();
        final Iterator<CSVRecord> iterator = parser.iterator();
        assertFalse(iterator.hasNext());
        assertThrows(NoSuchElementException.class, new Executable() {
            public void execute() throws Throwable {
                iterator.next();
            }
        });
    }

    // ---- iterator() ----

    @Test
    public void testIteratorProducesAllRecordsInOrder() throws IOException {
        CSVParser parser = CSVParser.parse("1,2\n3,4\n5,6\n", CSVFormat.DEFAULT);
        Iterator<CSVRecord> iterator = parser.iterator();
        int count = 0;
        String[] firstValues = null;
        while (iterator.hasNext()) {
            CSVRecord record = iterator.next();
            if (count == 0) {
                firstValues = new String[] { record.get(0), record.get(1) };
            }
            count++;
        }
        assertEquals(3, count);
        assertNotNull(firstValues);
        assertEquals("1", firstValues[0]);
        assertEquals("2", firstValues[1]);
        assertThrows(NoSuchElementException.class, new Executable() {
            public void execute() throws Throwable {
                CSVParser p = CSVParser.parse("", CSVFormat.DEFAULT);
                p.iterator().next();
            }
        });
    }

    @Test
    public void testIteratorWrapsIoExceptionAsIllegalStateException() throws IOException {
        CSVParser parser = CSVParser.parse(new ThrowingReader(), CSVFormat.DEFAULT);
        final Iterator<CSVRecord> iterator = parser.iterator();
        assertThrows(IllegalStateException.class, new Executable() {
            public void execute() throws Throwable {
                iterator.hasNext();
            }
        });
    }

    // ---- stream() ----

    @Test
    public void testStreamProducesAllRecords() throws IOException {
        CSVParser parser = CSVParser.parse("a,b\nc,d\n", CSVFormat.DEFAULT);
        Stream<CSVRecord> stream = parser.stream();
        long count = stream.count();
        assertEquals(2L, count);
        parser.close();
    }

    @Test
    public void testStreamProducesNoRecordsAfterClose() throws IOException {
        CSVParser parser = CSVParser.parse("a,b\nc,d\n", CSVFormat.DEFAULT);
        parser.close();
        long count = parser.stream().count();
        assertEquals(0L, count);
    }
}
