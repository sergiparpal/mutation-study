package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link CSVRecord} based solely on its documented contract.
 * Records are built directly via the package-private constructor since no
 * {@code CSVParser} is available; a {@code null} parser represents a record with
 * no header mapping, which the javadoc explicitly discusses (see {@link CSVRecord#getParser()}).
 */
public class CSVRecordAgentTest {

    private enum Column {
        FIRST, SECOND
    }

    // ---- values() / size() ----

    @Test
    public void testValuesReturnsSameArrayReferenceNotACopy() {
        String[] values = {"a", "b", "c"};
        CSVRecord record = new CSVRecord(null, values, null, 1L, 0L, 0L);
        assertSame(values, record.values());
        assertSame(record.values(), record.values());
    }

    @Test
    public void testValuesNeverNullForEmptyRecord() {
        CSVRecord record = new CSVRecord(null, new String[0], null, 1L, 0L, 0L);
        assertNotNull(record.values());
        assertEquals(0, record.values().length);
    }

    @Test
    public void testSizeMatchesValuesLength() {
        CSVRecord record = new CSVRecord(null, new String[] {"a", "b", "c", "d"}, null, 1L, 0L, 0L);
        assertEquals(4, record.size());
    }

    @Test
    public void testSizeOfEmptyRecordIsZero() {
        CSVRecord record = new CSVRecord(null, new String[0], null, 1L, 0L, 0L);
        assertEquals(0, record.size());
    }

    // ---- get(int) ----

    @Test
    public void testGetByIndexReturnsCorrespondingValue() {
        CSVRecord record = new CSVRecord(null, new String[] {"a", "b", "c"}, null, 1L, 0L, 0L);
        assertEquals("a", record.get(0));
        assertEquals("b", record.get(1));
        assertEquals("c", record.get(2));
    }

    @Test
    public void testGetByIndexReturnsNullElement() {
        CSVRecord record = new CSVRecord(null, new String[] {"a", null, "c"}, null, 1L, 0L, 0L);
        assertNull(record.get(1));
    }

    @Test
    public void testGetByIndexNegativeThrows() {
        final CSVRecord record = new CSVRecord(null, new String[] {"a", "b"}, null, 1L, 0L, 0L);
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                record.get(-1);
            }
        });
    }

    @Test
    public void testGetByIndexTooLargeThrows() {
        final CSVRecord record = new CSVRecord(null, new String[] {"a", "b"}, null, 1L, 0L, 0L);
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                record.get(2);
            }
        });
    }

    @Test
    public void testGetByIndexOnEmptyRecordThrows() {
        final CSVRecord record = new CSVRecord(null, new String[0], null, 1L, 0L, 0L);
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                record.get(0);
            }
        });
    }

    // ---- get(String) / get(Enum) / isMapped / isSet(String) : no header mapping ----

    @Test
    public void testGetByNameThrowsIllegalStateWhenNoHeaderMapping() {
        final CSVRecord record = new CSVRecord(null, new String[] {"a", "b"}, null, 1L, 0L, 0L);
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                record.get("FIRST");
            }
        });
    }

    @Test
    public void testGetByEnumThrowsWhenNoHeaderMapping() {
        // get(Enum) is documented as looking up "the String at the given enum String",
        // i.e. a name-based lookup like get(String); with no header mapping available
        // this implies the same failure mode as get(String).
        final CSVRecord record = new CSVRecord(null, new String[] {"a", "b"}, null, 1L, 0L, 0L);
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                record.get(Column.FIRST);
            }
        });
    }

    @Test
    public void testIsMappedFalseWhenNoHeaderMapping() {
        CSVRecord record = new CSVRecord(null, new String[] {"a", "b"}, null, 1L, 0L, 0L);
        assertFalse(record.isMapped("FIRST"));
        assertFalse(record.isMapped(""));
        assertFalse(record.isMapped("anything"));
    }

    @Test
    public void testIsSetByNameFalseWhenNoHeaderMapping() {
        CSVRecord record = new CSVRecord(null, new String[] {"a", "b"}, null, 1L, 0L, 0L);
        assertFalse(record.isSet("FIRST"));
        assertFalse(record.isSet("anything"));
    }

    // ---- isSet(int) ----

    @Test
    public void testIsSetByIndexTrueForNonNullValue() {
        CSVRecord record = new CSVRecord(null, new String[] {"a", null}, null, 1L, 0L, 0L);
        assertTrue(record.isSet(0));
    }

    @Test
    public void testIsSetByIndexFalseForNullValue() {
        CSVRecord record = new CSVRecord(null, new String[] {"a", null}, null, 1L, 0L, 0L);
        assertFalse(record.isSet(1));
    }

    @Test
    public void testIsSetByIndexNegativeThrows() {
        final CSVRecord record = new CSVRecord(null, new String[] {"a", "b"}, null, 1L, 0L, 0L);
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                record.isSet(-1);
            }
        });
    }

    @Test
    public void testIsSetByIndexTooLargeThrows() {
        final CSVRecord record = new CSVRecord(null, new String[] {"a", "b"}, null, 1L, 0L, 0L);
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                record.isSet(2);
            }
        });
    }

    // ---- positions / record number ----

    @Test
    public void testGetBytePosition() {
        CSVRecord record = new CSVRecord(null, new String[] {"a"}, null, 1L, 2L, 99L);
        assertEquals(99L, record.getBytePosition());
    }

    @Test
    public void testGetCharacterPosition() {
        CSVRecord record = new CSVRecord(null, new String[] {"a"}, null, 1L, 42L, 0L);
        assertEquals(42L, record.getCharacterPosition());
    }

    @Test
    public void testGetRecordNumber() {
        CSVRecord record = new CSVRecord(null, new String[] {"a"}, null, 7L, 0L, 0L);
        assertEquals(7L, record.getRecordNumber());
    }

    @Test
    public void testPositionBoundaryValues() {
        CSVRecord record = new CSVRecord(null, new String[] {"a"}, null, 0L, 0L, 0L);
        assertEquals(0L, record.getRecordNumber());
        assertEquals(0L, record.getCharacterPosition());
        assertEquals(0L, record.getBytePosition());

        CSVRecord maxRecord = new CSVRecord(null, new String[] {"a"}, null,
                Long.MAX_VALUE, Long.MAX_VALUE, Long.MAX_VALUE);
        assertEquals(Long.MAX_VALUE, maxRecord.getRecordNumber());
        assertEquals(Long.MAX_VALUE, maxRecord.getCharacterPosition());
        assertEquals(Long.MAX_VALUE, maxRecord.getBytePosition());
    }

    // ---- comment ----

    @Test
    public void testGetCommentPresent() {
        CSVRecord record = new CSVRecord(null, new String[] {"a"}, "a comment", 1L, 0L, 0L);
        assertEquals("a comment", record.getComment());
    }

    @Test
    public void testGetCommentAbsentIsNull() {
        CSVRecord record = new CSVRecord(null, new String[] {"a"}, null, 1L, 0L, 0L);
        assertNull(record.getComment());
    }

    @Test
    public void testHasCommentTrueWhenPresent() {
        CSVRecord record = new CSVRecord(null, new String[] {"a"}, "a comment", 1L, 0L, 0L);
        assertTrue(record.hasComment());
    }

    @Test
    public void testHasCommentFalseWhenAbsent() {
        CSVRecord record = new CSVRecord(null, new String[] {"a"}, null, 1L, 0L, 0L);
        assertFalse(record.hasComment());
    }

    // ---- parser ----

    @Test
    public void testGetParserReturnsNullWhenConstructedWithNullParser() {
        CSVRecord record = new CSVRecord(null, new String[] {"a"}, null, 1L, 0L, 0L);
        assertNull(record.getParser());
    }

    // ---- isConsistent() ----

    @Test
    public void testIsConsistentTrueWhenNoHeaderMapping() {
        // With no parser there is no header to be inconsistent with, for any record size.
        assertTrue(new CSVRecord(null, new String[0], null, 1L, 0L, 0L).isConsistent());
        assertTrue(new CSVRecord(null, new String[] {"a"}, null, 1L, 0L, 0L).isConsistent());
        assertTrue(new CSVRecord(null, new String[] {"a", "b", "c"}, null, 1L, 0L, 0L).isConsistent());
    }

    // ---- iterator() / Iterable<String> ----

    @Test
    public void testIteratorReturnsValuesInOrder() {
        String[] values = {"a", "b", "c"};
        CSVRecord record = new CSVRecord(null, values, null, 1L, 0L, 0L);
        Iterator<String> it = record.iterator();
        List<String> collected = new ArrayList<String>();
        while (it.hasNext()) {
            collected.add(it.next());
        }
        assertEquals(Arrays.asList(values), collected);
    }

    @Test
    public void testIteratorOnEmptyRecordHasNoNext() {
        CSVRecord record = new CSVRecord(null, new String[0], null, 1L, 0L, 0L);
        assertFalse(record.iterator().hasNext());
    }

    @Test
    public void testForEachLoopUsesIterableContract() {
        String[] values = {"x", "y"};
        CSVRecord record = new CSVRecord(null, values, null, 1L, 0L, 0L);
        List<String> collected = new ArrayList<String>();
        for (String value : record) {
            collected.add(value);
        }
        assertEquals(Arrays.asList(values), collected);
    }

    // ---- stream() ----

    @Test
    public void testStreamContainsValuesInOrder() {
        String[] values = {"a", "b", "c"};
        CSVRecord record = new CSVRecord(null, values, null, 1L, 0L, 0L);
        Object[] streamed = record.stream().toArray();
        assertArrayEquals(values, streamed);
    }

    @Test
    public void testStreamCountMatchesSize() {
        CSVRecord record = new CSVRecord(null, new String[] {"a", "b"}, null, 1L, 0L, 0L);
        assertEquals((long) record.size(), record.stream().count());
    }

    // ---- toList() ----

    @Test
    public void testToListContainsValuesInOrder() {
        String[] values = {"a", "b", "c"};
        CSVRecord record = new CSVRecord(null, values, null, 1L, 0L, 0L);
        assertEquals(Arrays.asList(values), record.toList());
    }

    @Test
    public void testToListEditingDoesNotAffectRecord() {
        CSVRecord record = new CSVRecord(null, new String[] {"a", "b"}, null, 1L, 0L, 0L);
        List<String> list = record.toList();
        list.add("extra");
        assertEquals(2, record.size());
        assertEquals(2, record.values().length);
    }

    // ---- toMap() ----

    @Test
    public void testToMapIsEmptyWhenRecordHasNoHeaders() {
        CSVRecord record = new CSVRecord(null, new String[] {"a", "b"}, null, 1L, 0L, 0L);
        Map<String, String> map = record.toMap();
        assertNotNull(map);
        assertTrue(map.isEmpty());
    }

    @Test
    public void testToMapEditingDoesNotAffectRecord() {
        CSVRecord record = new CSVRecord(null, new String[] {"a", "b"}, null, 1L, 0L, 0L);
        Map<String, String> firstMap = record.toMap();
        firstMap.put("injected", "value");
        Map<String, String> secondMap = record.toMap();
        assertNotSame(firstMap, secondMap);
        assertTrue(secondMap.isEmpty());
    }

    // ---- putIn(Map) ----

    @Test
    public void testPutInReturnsSameMapInstance() {
        CSVRecord record = new CSVRecord(null, new String[] {"a", "b"}, null, 1L, 0L, 0L);
        Map<String, String> map = new HashMap<String, String>();
        Map<String, String> returned = record.putIn(map);
        assertSame(map, returned);
    }

    @Test
    public void testPutInWithNoHeadersDoesNotRemoveExistingEntries() {
        CSVRecord record = new CSVRecord(null, new String[] {"a", "b"}, null, 1L, 0L, 0L);
        Map<String, String> map = new HashMap<String, String>();
        map.put("sentinel", "value");
        Map<String, String> returned = record.putIn(map);
        assertEquals("value", returned.get("sentinel"));
    }

    // ---- toString() ----

    @Test
    public void testToStringContainsValuesAndRecordNumber() {
        String[] values = {"a", "b"};
        CSVRecord record = new CSVRecord(null, values, null, 5L, 0L, 0L);
        String text = record.toString();
        assertNotNull(text);
        assertTrue(text.contains(Arrays.toString(values)));
        assertTrue(text.contains("5"));
    }

    @Test
    public void testToStringContainsCommentWhenPresent() {
        CSVRecord record = new CSVRecord(null, new String[] {"a"}, "my comment", 1L, 0L, 0L);
        String text = record.toString();
        assertTrue(text.contains("my comment"));
    }

    // ---- Serializable ----

    @Test
    public void testSerializationPreservesValuesCommentRecordNumberAndPositions() throws Exception {
        CSVRecord original = new CSVRecord(null, new String[] {"a", "b"}, "cmt", 5L, 10L, 20L);

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(baos);
        try {
            oos.writeObject(original);
        } finally {
            oos.close();
        }

        ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(baos.toByteArray()));
        CSVRecord copy;
        try {
            copy = (CSVRecord) ois.readObject();
        } finally {
            ois.close();
        }

        assertArrayEquals(original.values(), copy.values());
        assertEquals(original.getComment(), copy.getComment());
        assertEquals(original.getRecordNumber(), copy.getRecordNumber());
        assertEquals(original.getCharacterPosition(), copy.getCharacterPosition());
        assertEquals(original.getBytePosition(), copy.getBytePosition());
    }

    @Test
    public void testSerializationParserIsNullAfterDeserialization() throws Exception {
        // The parser is documented as not part of the serialized state, so after a
        // round trip getParser() must be null regardless of the original parser.
        CSVRecord original = new CSVRecord(null, new String[] {"a"}, null, 1L, 0L, 0L);

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(baos);
        try {
            oos.writeObject(original);
        } finally {
            oos.close();
        }

        ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(baos.toByteArray()));
        CSVRecord copy;
        try {
            copy = (CSVRecord) ois.readObject();
        } finally {
            ois.close();
        }

        assertNull(copy.getParser());
    }
}
