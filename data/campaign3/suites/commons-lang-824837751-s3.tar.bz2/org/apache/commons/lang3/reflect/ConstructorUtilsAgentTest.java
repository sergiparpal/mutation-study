package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests for {@link ConstructorUtils} based on the documented contract in the javadoc.
 */
public class ConstructorUtilsAgentTest {

    // ---- Fixtures -----------------------------------------------------

    public static class PublicNoArg {
        public PublicNoArg() {
        }
    }

    public static class ExactMatchTarget {
        public final String value;

        public ExactMatchTarget(String value) {
            this.value = value;
        }
    }

    public static class CompatibleMatchTarget {
        public final String value;

        public CompatibleMatchTarget(CharSequence value) {
            this.value = value.toString();
        }
    }

    public static class IntCtorTarget {
        public final int value;

        public IntCtorTarget(int value) {
            this.value = value;
        }
    }

    public abstract static class AbstractTarget {
        public AbstractTarget() {
        }
    }

    public static class ThrowingTarget {
        public ThrowingTarget() {
            throw new IllegalStateException("boom");
        }
    }

    // Deliberately package-private (non-public) top-level-like nested class: per the
    // "Known Limitations" section of the javadoc, constructors of non-public classes are
    // never considered accessible by ConstructorUtils, regardless of caller package.
    static class NonPublicTarget {
        public NonPublicTarget() {
        }
    }

    // ---- getAccessibleConstructor(Class, Class...) ---------------------

    @Test
    public void testGetAccessibleConstructorByTypesFound() throws Exception {
        Constructor<PublicNoArg> ctor = ConstructorUtils.getAccessibleConstructor(PublicNoArg.class, new Class[0]);
        assertNotNull(ctor);
        assertEquals(0, ctor.getParameterTypes().length);
        assertNotNull(ctor.newInstance());
    }

    @Test
    public void testGetAccessibleConstructorByTypesNotFound() {
        Constructor<ExactMatchTarget> ctor = ConstructorUtils.getAccessibleConstructor(ExactMatchTarget.class, Integer.class);
        assertNull(ctor);
    }

    @Test
    public void testGetAccessibleConstructorByTypesNullParameterTypesTreatedAsEmpty() {
        Constructor<PublicNoArg> ctor = ConstructorUtils.getAccessibleConstructor(PublicNoArg.class, (Class<?>[]) null);
        assertNotNull(ctor);
        assertEquals(0, ctor.getParameterTypes().length);
    }

    @Test
    public void testGetAccessibleConstructorByTypesNullClassThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                ConstructorUtils.getAccessibleConstructor(null, String.class);
            }
        });
    }

    @Test
    public void testGetAccessibleConstructorByTypesNonPublicClassReturnsNull() {
        Constructor<NonPublicTarget> ctor = ConstructorUtils.getAccessibleConstructor(NonPublicTarget.class, new Class[0]);
        assertNull(ctor);
    }

    @Test
    public void testGetAccessibleConstructorExactSignatureDoesNotFallBackToCompatible() {
        // CompatibleMatchTarget only declares a CharSequence constructor; an exact search
        // for String.class must not find it, unlike getMatchingAccessibleConstructor.
        Constructor<CompatibleMatchTarget> ctor = ConstructorUtils.getAccessibleConstructor(CompatibleMatchTarget.class, String.class);
        assertNull(ctor);
    }

    // ---- getAccessibleConstructor(Constructor) -------------------------

    @Test
    public void testGetAccessibleConstructorFromCtorReturnsEquivalentConstructor() throws Exception {
        Constructor<PublicNoArg> original = PublicNoArg.class.getConstructor();
        Constructor<PublicNoArg> accessible = ConstructorUtils.getAccessibleConstructor(original);
        assertNotNull(accessible);
        assertEquals(original.getDeclaringClass(), accessible.getDeclaringClass());
        assertEquals(0, accessible.getParameterTypes().length);
    }

    @Test
    public void testGetAccessibleConstructorFromCtorNonPublicClassReturnsNull() throws Exception {
        Constructor<NonPublicTarget> original = NonPublicTarget.class.getDeclaredConstructor();
        Constructor<NonPublicTarget> accessible = ConstructorUtils.getAccessibleConstructor(original);
        assertNull(accessible);
    }

    @Test
    public void testGetAccessibleConstructorFromCtorNullThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                ConstructorUtils.getAccessibleConstructor((Constructor<Object>) null);
            }
        });
    }

    // ---- getMatchingAccessibleConstructor(Class, Class...) -------------

    @Test
    public void testGetMatchingAccessibleConstructorExactMatch() {
        Constructor<ExactMatchTarget> ctor = ConstructorUtils.getMatchingAccessibleConstructor(ExactMatchTarget.class, String.class);
        assertNotNull(ctor);
        assertArrayEqualsLocal(new Class[] {String.class}, ctor.getParameterTypes());
    }

    @Test
    public void testGetMatchingAccessibleConstructorCompatibleFallback() {
        // No constructor declared with a String parameter, but String is assignable to
        // the declared CharSequence parameter, so the compatible search must find it.
        Constructor<CompatibleMatchTarget> ctor = ConstructorUtils.getMatchingAccessibleConstructor(CompatibleMatchTarget.class, String.class);
        assertNotNull(ctor);
        assertArrayEqualsLocal(new Class[] {CharSequence.class}, ctor.getParameterTypes());
    }

    @Test
    public void testGetMatchingAccessibleConstructorNoMatchReturnsNull() {
        Constructor<ExactMatchTarget> ctor = ConstructorUtils.getMatchingAccessibleConstructor(ExactMatchTarget.class, Integer.class);
        assertNull(ctor);
    }

    @Test
    public void testGetMatchingAccessibleConstructorNonPublicClassReturnsNull() {
        Constructor<NonPublicTarget> ctor = ConstructorUtils.getMatchingAccessibleConstructor(NonPublicTarget.class, new Class[0]);
        assertNull(ctor);
    }

    @Test
    public void testGetMatchingAccessibleConstructorNullClassThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                ConstructorUtils.getMatchingAccessibleConstructor(null, String.class);
            }
        });
    }

    // ---- invokeConstructor(Class, Object...) ---------------------------

    @Test
    public void testInvokeConstructorVarargsHappyPath() throws Exception {
        ExactMatchTarget result = ConstructorUtils.invokeConstructor(ExactMatchTarget.class, "hello");
        assertNotNull(result);
        assertEquals("hello", result.value);
    }

    @Test
    public void testInvokeConstructorVarargsNullArgsTreatedAsEmpty() throws Exception {
        PublicNoArg result = ConstructorUtils.invokeConstructor(PublicNoArg.class, (Object[]) null);
        assertNotNull(result);
    }

    @Test
    public void testInvokeConstructorVarargsPrimitiveUnwrapping() throws Exception {
        IntCtorTarget result = ConstructorUtils.invokeConstructor(IntCtorTarget.class, Integer.valueOf(42));
        assertNotNull(result);
        assertEquals(42, result.value);
    }

    @Test
    public void testInvokeConstructorVarargsCompatibleMatch() throws Exception {
        CompatibleMatchTarget result = ConstructorUtils.invokeConstructor(CompatibleMatchTarget.class, "world");
        assertNotNull(result);
        assertEquals("world", result.value);
    }

    @Test
    public void testInvokeConstructorVarargsNoMatchThrowsNoSuchMethodException() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            public void execute() throws Throwable {
                ConstructorUtils.invokeConstructor(ExactMatchTarget.class, Integer.valueOf(1));
            }
        });
    }

    @Test
    public void testInvokeConstructorVarargsNonPublicClassThrowsNoSuchMethodException() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            public void execute() throws Throwable {
                ConstructorUtils.invokeConstructor(NonPublicTarget.class);
            }
        });
    }

    @Test
    public void testInvokeConstructorVarargsNullClassThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                ConstructorUtils.invokeConstructor(null);
            }
        });
    }

    @Test
    public void testInvokeConstructorVarargsAbstractClassThrowsInstantiationException() {
        assertThrows(InstantiationException.class, new Executable() {
            public void execute() throws Throwable {
                ConstructorUtils.invokeConstructor(AbstractTarget.class);
            }
        });
    }

    @Test
    public void testInvokeConstructorVarargsWrapsConstructorExceptionInInvocationTargetException() {
        InvocationTargetException thrown = assertThrows(InvocationTargetException.class, new Executable() {
            public void execute() throws Throwable {
                ConstructorUtils.invokeConstructor(ThrowingTarget.class);
            }
        });
        assertTrue(thrown.getCause() instanceof IllegalStateException);
        assertEquals("boom", thrown.getCause().getMessage());
    }

    // ---- invokeConstructor(Class, Object[], Class[]) -------------------

    @Test
    public void testInvokeConstructorExplicitTypesHappyPath() throws Exception {
        ExactMatchTarget result = ConstructorUtils.invokeConstructor(ExactMatchTarget.class, new Object[] {"hi"}, new Class[] {String.class});
        assertNotNull(result);
        assertEquals("hi", result.value);
    }

    @Test
    public void testInvokeConstructorExplicitTypesNullArgsAndTypesTreatedAsEmpty() throws Exception {
        PublicNoArg result = ConstructorUtils.invokeConstructor(PublicNoArg.class, null, null);
        assertNotNull(result);
    }

    @Test
    public void testInvokeConstructorExplicitTypesNullClassThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                ConstructorUtils.invokeConstructor(null, new Object[] {"hi"}, new Class[] {String.class});
            }
        });
    }

    // ---- invokeExactConstructor(Class, Object...) ----------------------

    @Test
    public void testInvokeExactConstructorVarargsHappyPath() throws Exception {
        ExactMatchTarget result = ConstructorUtils.invokeExactConstructor(ExactMatchTarget.class, "hello");
        assertNotNull(result);
        assertEquals("hello", result.value);
    }

    @Test
    public void testInvokeExactConstructorVarargsNullArgsTreatedAsEmpty() throws Exception {
        PublicNoArg result = ConstructorUtils.invokeExactConstructor(PublicNoArg.class, (Object[]) null);
        assertNotNull(result);
    }

    @Test
    public void testInvokeExactConstructorVarargsDoesNotFallBackToCompatibleMatch() {
        // Unlike invokeConstructor, the exact variant requires an exact signature match;
        // a String argument must not satisfy a declared CharSequence parameter.
        assertThrows(NoSuchMethodException.class, new Executable() {
            public void execute() throws Throwable {
                ConstructorUtils.invokeExactConstructor(CompatibleMatchTarget.class, "hello");
            }
        });
    }

    @Test
    public void testInvokeExactConstructorVarargsPrimitiveTypeMismatchThrowsNoSuchMethodException() {
        // The exact variant does not perform the unwrapping conversion that the flexible
        // invokeConstructor performs, so an Integer argument cannot match an int parameter.
        assertThrows(NoSuchMethodException.class, new Executable() {
            public void execute() throws Throwable {
                ConstructorUtils.invokeExactConstructor(IntCtorTarget.class, Integer.valueOf(42));
            }
        });
    }

    @Test
    public void testInvokeExactConstructorVarargsNullClassThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                ConstructorUtils.invokeExactConstructor(null);
            }
        });
    }

    // ---- invokeExactConstructor(Class, Object[], Class[]) --------------

    @Test
    public void testInvokeExactConstructorExplicitTypesHappyPath() throws Exception {
        ExactMatchTarget result = ConstructorUtils.invokeExactConstructor(ExactMatchTarget.class, new Object[] {"hi"},
                new Class[] {String.class});
        assertNotNull(result);
        assertEquals("hi", result.value);
    }

    @Test
    public void testInvokeExactConstructorExplicitTypesNullArgsAndTypesTreatedAsEmpty() throws Exception {
        PublicNoArg result = ConstructorUtils.invokeExactConstructor(PublicNoArg.class, null, null);
        assertNotNull(result);
    }

    @Test
    public void testInvokeExactConstructorExplicitTypesNullClassThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                ConstructorUtils.invokeExactConstructor(null, new Object[] {"hi"}, new Class[] {String.class});
            }
        });
    }

    // ---- helpers ---------------------------------------------------------

    private static void assertArrayEqualsLocal(Class<?>[] expected, Class<?>[] actual) {
        assertEquals(expected.length, actual.length);
        for (int i = 0; i < expected.length; i++) {
            assertSame(expected[i], actual[i]);
        }
    }
}
