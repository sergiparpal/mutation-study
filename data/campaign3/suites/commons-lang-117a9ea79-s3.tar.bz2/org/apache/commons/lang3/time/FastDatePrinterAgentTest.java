package org.apache.commons.lang3.time;

import org.junit.jupiter.api.Test;

import java.text.FieldPosition;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

/**
 * Tests for {@link FastDatePrinter} based strictly on the documented contract in api/.
 *
 * <p>FastDatePrinter's constructor is {@code protected}, which is accessible from this
 * test because it lives in the same package.</p>
 */
public class FastDatePrinterAgentTest {

    private static final TimeZone UTC = TimeZone.getTimeZone("UTC");

    private static Calendar utcCalendar() {
        Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.clear();
        return cal;
    }

    private static FastDatePrinter printer(String pattern) {
        return new FastDatePrinter(pattern, UTC, Locale.US);
    }

    // ---- construction ----

    @Test
    public void constructor_nullPattern_throwsNullPointerException() {
        try {
            new FastDatePrinter(null, UTC, Locale.US);
            fail("Expected NullPointerException for a null pattern");
        } catch (NullPointerException expected) {
            // documented behavior
        }
    }

    @Test
    public void constructor_nullTimeZone_throwsNullPointerException() {
        try {
            new FastDatePrinter("yyyy", null, Locale.US);
            fail("Expected NullPointerException for a null time zone");
        } catch (NullPointerException expected) {
            // documented behavior
        }
    }

    @Test
    public void constructor_nullLocale_throwsNullPointerException() {
        try {
            new FastDatePrinter("yyyy", UTC, null);
            fail("Expected NullPointerException for a null locale");
        } catch (NullPointerException expected) {
            // documented behavior
        }
    }

    // ---- formatting ----

    @Test
    public void format_millis_producesExpectedString() {
        FastDatePrinter p = printer("yyyy-MM-dd");
        assertEquals("1970-01-01", p.format(0L));
    }

    @Test
    public void format_dateObject_usesPrinterTimeZone() {
        FastDatePrinter p = printer("yyyy-MM-dd HH:mm:ss");
        assertEquals("1970-01-01 00:00:00", p.format(new Date(0)));
    }

    @Test
    public void format_calendarObject_usesPrinterTimeZoneNotCalendarTimeZone() {
        FastDatePrinter p = printer("yyyy-MM-dd HH:mm:ss");
        Calendar laCalendar = Calendar.getInstance(TimeZone.getTimeZone("America/Los_Angeles"), Locale.US);
        laCalendar.setTimeInMillis(0L);
        assertEquals("1970-01-01 00:00:00", p.format(laCalendar));
    }

    @Test
    public void format_millisToAppendable_returnsSameBufferWithContent() {
        FastDatePrinter p = printer("yyyy-MM-dd");
        StringBuilder sb = new StringBuilder();
        StringBuilder result = p.format(0L, sb);
        assertSame(sb, result);
        assertEquals("1970-01-01", result.toString());
    }

    @Test
    public void format_dateToAppendable_returnsSameBufferWithContent() {
        FastDatePrinter p = printer("yyyy-MM-dd");
        StringBuilder sb = new StringBuilder();
        StringBuilder result = p.format(new Date(0), sb);
        assertSame(sb, result);
        assertEquals("1970-01-01", result.toString());
    }

    @Test
    public void format_calendarToAppendable_returnsSameBufferWithContent() {
        FastDatePrinter p = printer("yyyy-MM-dd");
        StringBuilder sb = new StringBuilder();
        Calendar cal = utcCalendar();
        cal.setTimeInMillis(0L);
        StringBuilder result = p.format(cal, sb);
        assertSame(sb, result);
        assertEquals("1970-01-01", result.toString());
    }

    @Test
    public void format_millisToStringBuffer_returnsSameBufferWithContent() {
        FastDatePrinter p = printer("yyyy-MM-dd");
        StringBuffer buf = new StringBuffer();
        StringBuffer result = p.format(0L, buf);
        assertSame(buf, result);
        assertEquals("1970-01-01", result.toString());
    }

    @Test
    public void format_dateToStringBuffer_returnsSameBufferWithContent() {
        FastDatePrinter p = printer("yyyy-MM-dd");
        StringBuffer buf = new StringBuffer();
        StringBuffer result = p.format(new Date(0), buf);
        assertSame(buf, result);
        assertEquals("1970-01-01", result.toString());
    }

    @Test
    public void format_calendarToStringBuffer_returnsSameBufferWithContent() {
        FastDatePrinter p = printer("yyyy-MM-dd");
        StringBuffer buf = new StringBuffer();
        Calendar cal = utcCalendar();
        cal.setTimeInMillis(0L);
        StringBuffer result = p.format(cal, buf);
        assertSame(buf, result);
        assertEquals("1970-01-01", result.toString());
    }

    @Test
    public void formatObject_withDateCalendarAndLong_producesExpectedString() {
        FastDatePrinter p = printer("yyyy-MM-dd");
        Calendar cal = utcCalendar();
        cal.setTimeInMillis(0L);

        assertEquals("1970-01-01", p.format((Object) new Date(0)));
        assertEquals("1970-01-01", p.format((Object) cal));
        assertEquals("1970-01-01", p.format((Object) Long.valueOf(0L)));
    }

    @SuppressWarnings("deprecation")
    @Test
    public void formatObjectFieldPosition_withDateCalendarAndLong_returnsGivenBufferWithContent() {
        FastDatePrinter p = printer("yyyy-MM-dd");
        Calendar cal = utcCalendar();
        cal.setTimeInMillis(0L);

        StringBuffer sb1 = new StringBuffer();
        StringBuffer r1 = p.format(new Date(0), sb1, new FieldPosition(0));
        assertSame(sb1, r1);
        assertEquals("1970-01-01", r1.toString());

        StringBuffer sb2 = new StringBuffer();
        StringBuffer r2 = p.format(cal, sb2, new FieldPosition(0));
        assertSame(sb2, r2);
        assertEquals("1970-01-01", r2.toString());

        StringBuffer sb3 = new StringBuffer();
        StringBuffer r3 = p.format(Long.valueOf(0L), sb3, new FieldPosition(0));
        assertSame(sb3, r3);
        assertEquals("1970-01-01", r3.toString());
    }

    @SuppressWarnings("deprecation")
    @Test
    public void formatObjectFieldPosition_withUnsupportedType_throwsIllegalArgumentException() {
        FastDatePrinter p = printer("yyyy-MM-dd");
        try {
            p.format("not a date or calendar", new StringBuffer(), new FieldPosition(0));
            fail("Expected IllegalArgumentException for an unsupported object type");
        } catch (IllegalArgumentException expected) {
            // Format can only format Date, Calendar or Long, per the documented contract.
        }
    }

    @SuppressWarnings("deprecation")
    @Test
    public void applyRules_formatsCalendarIntoSuppliedBuffer() {
        FastDatePrinter p = printer("yyyy-MM-dd");
        Calendar cal = utcCalendar();
        cal.setTimeInMillis(0L);
        StringBuffer buf = new StringBuffer();
        StringBuffer result = p.applyRules(cal, buf);
        assertSame(buf, result);
        assertEquals("1970-01-01", result.toString());
    }

    // ---- getters ----

    @Test
    public void getLocale_getPattern_getTimeZone_matchConstructionArguments() {
        FastDatePrinter p = printer("yyyy-MM-dd");
        assertEquals("yyyy-MM-dd", p.getPattern());
        assertEquals(UTC, p.getTimeZone());
        assertEquals(Locale.US, p.getLocale());
    }

    @Test
    public void getMaxLengthEstimate_isNeverSmallerThanActualFormattedLength() {
        String[] patterns = {"yyyy-MM-dd", "EEEE, MMMM d, yyyy HH:mm:ss zzzz", "yy/M/d"};
        Date now = new Date(0);
        for (int i = 0; i < patterns.length; i++) {
            FastDatePrinter p = printer(patterns[i]);
            String formatted = p.format(now);
            assertTrue(formatted.length() <= p.getMaxLengthEstimate(),
                    "pattern " + patterns[i] + " produced a string longer than the estimate");
        }
    }

    @Test
    public void getTimeZoneDisplay_returnsNonEmptyNameForKnownZone() {
        String display = FastDatePrinter.getTimeZoneDisplay(TimeZone.getTimeZone("America/New_York"), false, TimeZone.LONG, Locale.US);
        assertNotNull(display);
        assertFalse(display.isEmpty());
    }

    // ---- equals / hashCode / toString ----

    @Test
    public void equals_and_hashCode_areConsistentForEqualAndDifferentInstances() {
        FastDatePrinter p1 = printer("yyyy-MM-dd");
        FastDatePrinter p2 = printer("yyyy-MM-dd");
        FastDatePrinter p3 = printer("MM/dd/yyyy");

        assertTrue(p1.equals(p2));
        assertEquals(p1.hashCode(), p2.hashCode());
        assertFalse(p1.equals(p3));
    }

    @Test
    public void equals_withNullOrDifferentType_returnsFalse() {
        FastDatePrinter p = printer("yyyy-MM-dd");
        assertFalse(p.equals(null));
        assertFalse(p.equals("yyyy-MM-dd"));
    }

    @Test
    public void toString_returnsNonNullDebugString() {
        FastDatePrinter p = printer("yyyy-MM-dd");
        String debug = p.toString();
        assertNotNull(debug);
        assertFalse(debug.isEmpty());
    }

    // ---- package-private/protected helpers ----

    @Test
    public void clear_doesNotBreakSubsequentUsage() {
        FastDatePrinter p = printer("yyyy-MM-dd");
        String before = p.format(0L);

        FastDatePrinter.clear();

        assertEquals(before, p.format(0L));
    }

    @Test
    public void parsePattern_returnsNonEmptyListForNonTrivialPattern() {
        FastDatePrinter p = printer("yyyy-MM-dd");
        List<?> rules = p.parsePattern();
        assertNotNull(rules);
        assertFalse(rules.isEmpty());
    }

    @Test
    public void parsePattern_invalidPattern_throwsIllegalArgumentException() {
        try {
            FastDatePrinter p = printer("yyyy-MM-dd'unterminated-quote");
            p.parsePattern();
            fail("Expected IllegalArgumentException for an invalid pattern");
        } catch (IllegalArgumentException expected) {
            // documented behavior: pattern validation may happen at construction or when
            // parsePattern() is invoked directly; either way an invalid pattern must fail.
        }
    }

    @Test
    public void selectNumberRule_returnsNonNullRule() {
        FastDatePrinter p = printer("yyyy-MM-dd");
        Object rule = p.selectNumberRule(Calendar.YEAR, 4);
        assertNotNull(rule);
    }

    @Test
    public void parseToken_returnsNonNullTokenAndPreservesIndexArrayLength() {
        FastDatePrinter p = printer("yyyy-MM-dd");
        int[] indexRef = {0};
        String token = p.parseToken("yyyy-MM-dd", indexRef);
        assertNotNull(token);
        assertEquals(1, indexRef.length);
    }
}
