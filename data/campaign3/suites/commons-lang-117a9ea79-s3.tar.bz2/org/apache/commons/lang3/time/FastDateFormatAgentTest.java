package org.apache.commons.lang3.time;

import org.junit.jupiter.api.Test;

import java.text.FieldPosition;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

/**
 * Tests for {@link FastDateFormat} based strictly on the documented contract in api/.
 */
public class FastDateFormatAgentTest {

    private static final TimeZone UTC = TimeZone.getTimeZone("UTC");

    private static Calendar utcCalendar() {
        Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.clear();
        return cal;
    }

    // ---- getInstance() / factory methods ----

    @Test
    public void getInstanceDefault_returnsUsableFormatter() {
        FastDateFormat fmt = FastDateFormat.getInstance();
        assertNotNull(fmt);
        assertNotNull(fmt.getPattern());
        assertNotNull(fmt.format(new Date(0)));
    }

    @Test
    public void getInstanceWithPattern_usesGivenPatternTimeZoneLocale() {
        FastDateFormat fmt = FastDateFormat.getInstance("yyyy-MM-dd", UTC, Locale.US);
        assertEquals("yyyy-MM-dd", fmt.getPattern());
        assertEquals(UTC, fmt.getTimeZone());
        assertEquals(Locale.US, fmt.getLocale());
        assertEquals("1970-01-01", fmt.format(0L));
    }

    @Test
    public void getInstanceWithPattern_nullTimeZoneAndLocale_fallBackToDefaults() {
        FastDateFormat fmt = FastDateFormat.getInstance("yyyy-MM-dd", null, null);
        assertEquals(TimeZone.getDefault(), fmt.getTimeZone());
        assertEquals(Locale.getDefault(), fmt.getLocale());
    }

    @Test
    public void getInstance_invalidPattern_throwsIllegalArgumentException() {
        try {
            FastDateFormat.getInstance("yyyy-MM-dd'unterminated-quote");
            fail("Expected IllegalArgumentException for an invalid pattern");
        } catch (IllegalArgumentException expected) {
            // documented behavior
        }
    }

    @Test
    public void getInstance_nullPattern_throwsIllegalArgumentException() {
        try {
            FastDateFormat.getInstance(null, UTC, Locale.US);
            fail("Expected IllegalArgumentException for a null pattern");
        } catch (IllegalArgumentException expected) {
            // documented behavior: "Thrown if pattern is invalid or null"
        }
    }

    @Test
    public void getDateInstance_eachDocumentedStyle_returnsLocalizedFormatter() {
        int[] styles = {FastDateFormat.FULL, FastDateFormat.LONG, FastDateFormat.MEDIUM, FastDateFormat.SHORT};
        for (int i = 0; i < styles.length; i++) {
            FastDateFormat fmt = FastDateFormat.getDateInstance(styles[i], UTC, Locale.US);
            assertNotNull(fmt);
            assertNotNull(fmt.getPattern());
            assertNotNull(fmt.format(new Date(0)));
        }
    }

    @Test
    public void getTimeInstance_eachDocumentedStyle_returnsLocalizedFormatter() {
        int[] styles = {FastDateFormat.FULL, FastDateFormat.LONG, FastDateFormat.MEDIUM, FastDateFormat.SHORT};
        for (int i = 0; i < styles.length; i++) {
            FastDateFormat fmt = FastDateFormat.getTimeInstance(styles[i], UTC, Locale.US);
            assertNotNull(fmt);
            assertNotNull(fmt.getPattern());
            assertNotNull(fmt.format(new Date(0)));
        }
    }

    @Test
    public void getDateTimeInstance_combinesDateAndTimeStyles() {
        FastDateFormat fmt = FastDateFormat.getDateTimeInstance(FastDateFormat.SHORT, FastDateFormat.SHORT, UTC, Locale.US);
        assertNotNull(fmt);
        assertNotNull(fmt.getPattern());
        assertNotNull(fmt.format(new Date(0)));
    }

    // ---- construction via the protected constructors (same package access) ----

    @Test
    public void constructor_nullPattern_throwsNullPointerException() {
        try {
            new FastDateFormat(null, UTC, Locale.US);
            fail("Expected NullPointerException for a null pattern");
        } catch (NullPointerException expected) {
            // documented behavior
        }
    }

    @Test
    public void constructor_nullTimeZone_throwsNullPointerException() {
        try {
            new FastDateFormat("yyyy", null, Locale.US);
            fail("Expected NullPointerException for a null time zone");
        } catch (NullPointerException expected) {
            // documented behavior
        }
    }

    @Test
    public void constructor_nullLocale_throwsNullPointerException() {
        try {
            new FastDateFormat("yyyy", UTC, null);
            fail("Expected NullPointerException for a null locale");
        } catch (NullPointerException expected) {
            // documented behavior
        }
    }

    @Test
    public void fourArgConstructor_centuryStart_resolvesTwoDigitYear() {
        Calendar centuryCal = utcCalendar();
        centuryCal.set(2000, Calendar.JANUARY, 1);
        Date centuryStart = centuryCal.getTime();

        FastDateFormat fmt = new FastDateFormat("yy-MM-dd", UTC, Locale.US, centuryStart);
        Calendar result = utcCalendar();
        try {
            result.setTime(fmt.parse("05-06-15"));
        } catch (ParseException e) {
            fail("Unexpected ParseException: " + e.getMessage());
        }
        assertEquals(2005, result.get(Calendar.YEAR));
        assertEquals(Calendar.JUNE, result.get(Calendar.MONTH));
        assertEquals(15, result.get(Calendar.DAY_OF_MONTH));
    }

    // ---- formatting ----

    @Test
    public void format_millis_producesExpectedString() {
        FastDateFormat fmt = FastDateFormat.getInstance("yyyy-MM-dd", UTC, Locale.US);
        assertEquals("1970-01-01", fmt.format(0L));
    }

    @Test
    public void format_dateObject_usesFormatterTimeZone() {
        FastDateFormat fmt = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss", UTC, Locale.US);
        assertEquals("1970-01-01 00:00:00", fmt.format(new Date(0)));
    }

    @Test
    public void format_calendarObject_usesFormatterTimeZoneNotCalendarTimeZone() {
        FastDateFormat fmt = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss", UTC, Locale.US);
        Calendar laCalendar = Calendar.getInstance(TimeZone.getTimeZone("America/Los_Angeles"), Locale.US);
        laCalendar.setTimeInMillis(0L);
        assertEquals("1970-01-01 00:00:00", fmt.format(laCalendar));
    }

    @Test
    public void format_millisToAppendable_returnsSameBufferWithContent() {
        FastDateFormat fmt = FastDateFormat.getInstance("yyyy-MM-dd", UTC, Locale.US);
        StringBuilder sb = new StringBuilder();
        StringBuilder result = fmt.format(0L, sb);
        assertSame(sb, result);
        assertEquals("1970-01-01", result.toString());
    }

    @Test
    public void format_dateToAppendable_returnsSameBufferWithContent() {
        FastDateFormat fmt = FastDateFormat.getInstance("yyyy-MM-dd", UTC, Locale.US);
        StringBuilder sb = new StringBuilder();
        StringBuilder result = fmt.format(new Date(0), sb);
        assertSame(sb, result);
        assertEquals("1970-01-01", result.toString());
    }

    @Test
    public void format_calendarToAppendable_returnsSameBufferWithContent() {
        FastDateFormat fmt = FastDateFormat.getInstance("yyyy-MM-dd", UTC, Locale.US);
        StringBuilder sb = new StringBuilder();
        Calendar cal = utcCalendar();
        cal.setTimeInMillis(0L);
        StringBuilder result = fmt.format(cal, sb);
        assertSame(sb, result);
        assertEquals("1970-01-01", result.toString());
    }

    @SuppressWarnings("deprecation")
    @Test
    public void format_millisToDeprecatedStringBuffer_returnsSameBufferWithContent() {
        FastDateFormat fmt = FastDateFormat.getInstance("yyyy-MM-dd", UTC, Locale.US);
        StringBuffer buf = new StringBuffer();
        StringBuffer result = fmt.format(0L, buf);
        assertSame(buf, result);
        assertEquals("1970-01-01", result.toString());
    }

    @SuppressWarnings("deprecation")
    @Test
    public void format_dateToDeprecatedStringBuffer_returnsSameBufferWithContent() {
        FastDateFormat fmt = FastDateFormat.getInstance("yyyy-MM-dd", UTC, Locale.US);
        StringBuffer buf = new StringBuffer();
        StringBuffer result = fmt.format(new Date(0), buf);
        assertSame(buf, result);
        assertEquals("1970-01-01", result.toString());
    }

    @SuppressWarnings("deprecation")
    @Test
    public void format_calendarToDeprecatedStringBuffer_returnsSameBufferWithContent() {
        FastDateFormat fmt = FastDateFormat.getInstance("yyyy-MM-dd", UTC, Locale.US);
        StringBuffer buf = new StringBuffer();
        Calendar cal = utcCalendar();
        cal.setTimeInMillis(0L);
        StringBuffer result = fmt.format(cal, buf);
        assertSame(buf, result);
        assertEquals("1970-01-01", result.toString());
    }

    @SuppressWarnings("deprecation")
    @Test
    public void applyRules_formatsCalendarIntoSuppliedBuffer() {
        FastDateFormat fmt = FastDateFormat.getInstance("yyyy-MM-dd", UTC, Locale.US);
        Calendar cal = utcCalendar();
        cal.setTimeInMillis(0L);
        StringBuffer buf = new StringBuffer();
        StringBuffer result = fmt.applyRules(cal, buf);
        assertSame(buf, result);
        assertEquals("1970-01-01", result.toString());
    }

    @Test
    public void formatObject_withDateCalendarAndLong_producesExpectedString() {
        FastDateFormat fmt = FastDateFormat.getInstance("yyyy-MM-dd", UTC, Locale.US);
        Calendar cal = utcCalendar();
        cal.setTimeInMillis(0L);

        StringBuffer sb1 = new StringBuffer();
        StringBuffer r1 = fmt.format(new Date(0), sb1, new FieldPosition(0));
        assertSame(sb1, r1);
        assertEquals("1970-01-01", r1.toString());

        StringBuffer sb2 = new StringBuffer();
        StringBuffer r2 = fmt.format(cal, sb2, new FieldPosition(0));
        assertSame(sb2, r2);
        assertEquals("1970-01-01", r2.toString());

        StringBuffer sb3 = new StringBuffer();
        StringBuffer r3 = fmt.format(Long.valueOf(0L), sb3, new FieldPosition(0));
        assertSame(sb3, r3);
        assertEquals("1970-01-01", r3.toString());
    }

    @Test
    public void formatObject_withUnsupportedType_throwsIllegalArgumentException() {
        FastDateFormat fmt = FastDateFormat.getInstance("yyyy-MM-dd", UTC, Locale.US);
        try {
            fmt.format("not a date or calendar", new StringBuffer(), new FieldPosition(0));
            fail("Expected IllegalArgumentException for an unsupported object type");
        } catch (IllegalArgumentException expected) {
            // Format can only format Date, Calendar or Long, per the documented contract.
        }
    }

    // ---- parsing ----

    @Test
    public void parse_validString_returnsExpectedDate() throws ParseException {
        FastDateFormat fmt = FastDateFormat.getInstance("yyyy-MM-dd", UTC, Locale.US);
        Calendar expected = utcCalendar();
        expected.set(2020, Calendar.JANUARY, 15);

        Date actual = fmt.parse("2020-01-15");
        assertEquals(expected.getTime(), actual);
    }

    @Test
    public void parse_invalidString_throwsParseException() {
        FastDateFormat fmt = FastDateFormat.getInstance("yyyy-MM-dd", UTC, Locale.US);
        try {
            fmt.parse("not-a-date");
            fail("Expected ParseException for an unparsable string");
        } catch (ParseException expected) {
            // documented behavior
        }
    }

    @Test
    public void parseWithPosition_success_updatesIndexPastConsumedText() {
        FastDateFormat fmt = FastDateFormat.getInstance("yyyy-MM-dd", UTC, Locale.US);
        ParsePosition pos = new ParsePosition(0);
        Date date = fmt.parse("2020-01-15", pos);
        assertNotNull(date);
        assertEquals("2020-01-15".length(), pos.getIndex());
    }

    @Test
    public void parseWithPosition_failure_returnsNull() {
        FastDateFormat fmt = FastDateFormat.getInstance("yyyy-MM-dd", UTC, Locale.US);
        ParsePosition pos = new ParsePosition(0);
        Date date = fmt.parse("garbage-input", pos);
        assertNull(date);
    }

    @Test
    public void parseStringPositionCalendar_success_updatesCalendarAndReturnsTrue() {
        FastDateFormat fmt = FastDateFormat.getInstance("yyyy-MM-dd", UTC, Locale.US);
        Calendar cal = utcCalendar();
        ParsePosition pos = new ParsePosition(0);
        boolean success = fmt.parse("2020-01-15", pos, cal);
        assertTrue(success);
        assertEquals(2020, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void parseStringPositionCalendar_failure_returnsFalseAndSetsErrorIndex() {
        FastDateFormat fmt = FastDateFormat.getInstance("yyyy-MM-dd", UTC, Locale.US);
        Calendar cal = utcCalendar();
        ParsePosition pos = new ParsePosition(0);
        boolean success = fmt.parse("garbage-input", pos, cal);
        assertFalse(success);
        assertTrue(pos.getErrorIndex() >= 0);
    }

    @Test
    public void parseObject_withPosition_returnsDateObject() {
        FastDateFormat fmt = FastDateFormat.getInstance("yyyy-MM-dd", UTC, Locale.US);
        ParsePosition pos = new ParsePosition(0);
        Object result = fmt.parseObject("2020-01-15", pos);
        assertTrue(result instanceof Date);
    }

    // ---- misc contract: length estimate, getters, equals/hashCode, toString, clear ----

    @Test
    public void getMaxLengthEstimate_isNeverSmallerThanActualFormattedLength() {
        String[] patterns = {"yyyy-MM-dd", "EEEE, MMMM d, yyyy HH:mm:ss zzzz", "yy/M/d"};
        Date now = new Date(0);
        for (int i = 0; i < patterns.length; i++) {
            FastDateFormat fmt = FastDateFormat.getInstance(patterns[i], UTC, Locale.US);
            String formatted = fmt.format(now);
            assertTrue(formatted.length() <= fmt.getMaxLengthEstimate(),
                    "pattern " + patterns[i] + " produced a string longer than the estimate");
        }
    }

    @Test
    public void getTimeZone_returnsACopyThatCanBeMutatedWithoutAffectingTheFormatter() {
        FastDateFormat fmt = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss", UTC, Locale.US);
        String before = fmt.format(new Date(0));

        TimeZone obtained = fmt.getTimeZone();
        obtained.setRawOffset(123456);

        String after = fmt.format(new Date(0));
        assertEquals(before, after);
        assertNotEquals(123456, fmt.getTimeZone().getRawOffset());
    }

    @Test
    public void equals_and_hashCode_areConsistentForEqualAndDifferentInstances() {
        FastDateFormat fmt1 = FastDateFormat.getInstance("yyyy-MM-dd", UTC, Locale.US);
        FastDateFormat fmt2 = FastDateFormat.getInstance("yyyy-MM-dd", UTC, Locale.US);
        FastDateFormat fmt3 = FastDateFormat.getInstance("MM/dd/yyyy", UTC, Locale.US);

        assertTrue(fmt1.equals(fmt2));
        assertEquals(fmt1.hashCode(), fmt2.hashCode());
        assertFalse(fmt1.equals(fmt3));
    }

    @Test
    public void equals_withNullOrDifferentType_returnsFalse() {
        FastDateFormat fmt = FastDateFormat.getInstance("yyyy-MM-dd", UTC, Locale.US);
        assertFalse(fmt.equals(null));
        assertFalse(fmt.equals("yyyy-MM-dd"));
    }

    @Test
    public void toString_returnsNonNullDebugString() {
        FastDateFormat fmt = FastDateFormat.getInstance("yyyy-MM-dd", UTC, Locale.US);
        String debug = fmt.toString();
        assertNotNull(debug);
        assertFalse(debug.isEmpty());
    }

    @Test
    public void clear_doesNotBreakPreviouslyObtainedOrFutureInstances() {
        FastDateFormat before = FastDateFormat.getInstance("yyyy-MM-dd", UTC, Locale.US);
        String beforeResult = before.format(0L);

        FastDateFormat.clear();

        assertEquals(beforeResult, before.format(0L));

        FastDateFormat after = FastDateFormat.getInstance("yyyy-MM-dd", UTC, Locale.US);
        assertNotNull(after);
        assertEquals(beforeResult, after.format(0L));
    }

    @Test
    public void getInstance_sameKeyReturnsEqualFormatters() {
        FastDateFormat fmt1 = FastDateFormat.getInstance("yyyy-MM-dd", UTC, Locale.US);
        FastDateFormat fmt2 = FastDateFormat.getInstance("yyyy-MM-dd", UTC, Locale.US);
        assertTrue(fmt1.equals(fmt2));
    }
}
