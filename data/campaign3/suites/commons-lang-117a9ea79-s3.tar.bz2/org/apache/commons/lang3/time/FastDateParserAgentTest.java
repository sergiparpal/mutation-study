package org.apache.commons.lang3.time;

import org.junit.jupiter.api.Test;

import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

/**
 * Tests for {@link FastDateParser} based strictly on the documented contract in api/.
 *
 * <p>FastDateParser's constructors are {@code protected}, which is accessible from this
 * test because it lives in the same package.</p>
 */
public class FastDateParserAgentTest {

    private static final TimeZone UTC = TimeZone.getTimeZone("UTC");

    private static Calendar utcCalendar() {
        Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.clear();
        return cal;
    }

    private static FastDateParser parser(String pattern) {
        return new FastDateParser(pattern, UTC, Locale.US);
    }

    // ---- construction ----

    @Test
    public void threeArgConstructor_storesPatternTimeZoneLocale() {
        FastDateParser p = parser("yyyy-MM-dd");
        assertEquals("yyyy-MM-dd", p.getPattern());
        assertEquals(UTC, p.getTimeZone());
        assertEquals(Locale.US, p.getLocale());
    }

    @Test
    public void fourArgConstructor_nullLocale_defaultsToSystemLocale() {
        FastDateParser p = new FastDateParser("yyyy-MM-dd", UTC, null, null);
        assertEquals(Locale.getDefault(), p.getLocale());
    }

    @Test
    public void fourArgConstructor_centuryStart_resolvesTwoDigitYear() {
        Calendar centuryCal = utcCalendar();
        centuryCal.set(2000, Calendar.JANUARY, 1);
        Date centuryStart = centuryCal.getTime();

        FastDateParser p = new FastDateParser("yy-MM-dd", UTC, Locale.US, centuryStart);
        Calendar result = utcCalendar();
        try {
            result.setTime(p.parse("05-06-15"));
        } catch (ParseException e) {
            fail("Unexpected ParseException: " + e.getMessage());
        }
        assertEquals(2005, result.get(Calendar.YEAR));
        assertEquals(Calendar.JUNE, result.get(Calendar.MONTH));
        assertEquals(15, result.get(Calendar.DAY_OF_MONTH));
    }

    // ---- parsing ----

    @Test
    public void parse_validString_returnsExpectedDate() throws ParseException {
        FastDateParser p = parser("yyyy-MM-dd");
        Calendar expected = utcCalendar();
        expected.set(2020, Calendar.JANUARY, 15);

        assertEquals(expected.getTime(), p.parse("2020-01-15"));
    }

    @Test
    public void parse_invalidString_throwsParseException() {
        FastDateParser p = parser("yyyy-MM-dd");
        try {
            p.parse("not-a-date");
            fail("Expected ParseException for an unparsable string");
        } catch (ParseException expected) {
            // documented behavior
        }
    }

    @Test
    public void parse_lenientMode_rolloverMinutesIntoHours() throws ParseException {
        FastDateParser p = parser("HH:mm");
        Calendar cal = utcCalendar();
        cal.setTime(p.parse("01:90"));
        assertEquals(2, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals(30, cal.get(Calendar.MINUTE));
    }

    @Test
    public void parseWithPosition_success_updatesIndexPastConsumedText() {
        FastDateParser p = parser("yyyy-MM-dd");
        ParsePosition pos = new ParsePosition(0);
        Date date = p.parse("2020-01-15", pos);
        assertNotNull(date);
        assertEquals("2020-01-15".length(), pos.getIndex());
    }

    @Test
    public void parseWithPosition_failure_returnsNullAndSetsErrorIndexBeforeFailedField() {
        FastDateParser p = parser("yyyy");
        ParsePosition pos = new ParsePosition(0);
        Date date = p.parse("abcd", pos);
        assertNull(date);
        // Documented to be the position before the failed field, unlike SimpleDateFormat
        // (which points after it). Here the very first field fails, so the error index is 0.
        assertEquals(0, pos.getErrorIndex());
    }

    @Test
    public void parseStringPositionCalendar_success_updatesCalendarAndReturnsTrue() {
        FastDateParser p = parser("yyyy-MM-dd");
        Calendar cal = utcCalendar();
        ParsePosition pos = new ParsePosition(0);
        boolean success = p.parse("2020-01-15", pos, cal);
        assertTrue(success);
        assertEquals(2020, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void parseStringPositionCalendar_failure_returnsFalseAndSetsErrorIndex() {
        FastDateParser p = parser("yyyy-MM-dd");
        Calendar cal = utcCalendar();
        ParsePosition pos = new ParsePosition(0);
        boolean success = p.parse("garbage-input", pos, cal);
        assertFalse(success);
        assertTrue(pos.getErrorIndex() >= 0);
    }

    @Test
    public void parseStringPositionCalendar_nonLenientCalendarWithInvalidField_throwsIllegalArgumentException() {
        FastDateParser p = parser("MM-dd-yyyy");
        Calendar cal = utcCalendar();
        cal.setLenient(false);
        ParsePosition pos = new ParsePosition(0);
        try {
            // February 30th does not exist; a non-lenient Calendar must reject it.
            p.parse("02-30-2021", pos, cal);
            fail("Expected IllegalArgumentException for an out-of-range field on a non-lenient Calendar");
        } catch (IllegalArgumentException expected) {
            // documented behavior
        }
    }

    @Test
    public void parseObject_validString_returnsDate() throws ParseException {
        FastDateParser p = parser("yyyy-MM-dd");
        Object result = p.parseObject("2020-01-15");
        assertTrue(result instanceof Date);
    }

    @Test
    public void parseObject_invalidString_throwsParseException() {
        FastDateParser p = parser("yyyy-MM-dd");
        try {
            p.parseObject("not-a-date");
            fail("Expected ParseException for an unparsable string");
        } catch (ParseException expected) {
            // documented behavior
        }
    }

    @Test
    public void parseObjectWithPosition_success_returnsDateObject() {
        FastDateParser p = parser("yyyy-MM-dd");
        ParsePosition pos = new ParsePosition(0);
        Object result = p.parseObject("2020-01-15", pos);
        assertTrue(result instanceof Date);
    }

    // ---- equals / hashCode / toString ----

    @Test
    public void equals_and_hashCode_areConsistentForEqualAndDifferentInstances() {
        FastDateParser p1 = parser("yyyy-MM-dd");
        FastDateParser p2 = parser("yyyy-MM-dd");
        FastDateParser p3 = parser("MM/dd/yyyy");

        assertTrue(p1.equals(p2));
        assertEquals(p1.hashCode(), p2.hashCode());
        assertFalse(p1.equals(p3));
    }

    @Test
    public void equals_withNullOrDifferentType_returnsFalse() {
        FastDateParser p = parser("yyyy-MM-dd");
        assertFalse(p.equals(null));
        assertFalse(p.equals("yyyy-MM-dd"));
    }

    @Test
    public void toString_returnsNonNullDebugString() {
        FastDateParser p = parser("yyyy-MM-dd");
        String debug = p.toString();
        assertNotNull(debug);
        assertFalse(debug.isEmpty());
    }

    @Test
    public void toStringAll_returnsNonNullDebugString() {
        FastDateParser p = parser("yyyy-MM-dd");
        String debug = p.toStringAll();
        assertNotNull(debug);
        assertFalse(debug.isEmpty());
    }

    // ---- package-private helpers ----

    @Test
    public void clear_doesNotBreakSubsequentUsage() throws ParseException {
        FastDateParser p = parser("yyyy-MM-dd");
        Date before = p.parse("2020-01-15");

        FastDateParser.clear();

        assertEquals(before, p.parse("2020-01-15"));
    }

    @Test
    public void getPatterns_returnsNonNullList() {
        FastDateParser p = parser("yyyy-MM-dd");
        List<?> patterns = p.getPatterns();
        assertNotNull(patterns);
    }

    @Test
    public void japaneseImperialField_isNonNullLocale() {
        assertNotNull(FastDateParser.JAPANESE_IMPERIAL);
    }
}
