/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.GenericArrayType;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link TypeUtils}.
 */
class TypeUtilsAgentTest {

    private static class Base<T> {
        // empty
    }

    private static class Mid<T> extends Base<T> {
        // empty
    }

    private static class Leaf extends Mid<String> {
        // empty
    }

    @Test
    void testContainsTypeVariablesOnClasses() {
        assertFalse(TypeUtils.containsTypeVariables(String.class));
        assertTrue(TypeUtils.containsTypeVariables(List.class));
    }

    @Test
    void testContainsTypeVariablesOnParameterizedAndTypeVariable() {
        final ParameterizedType concrete = TypeUtils.parameterize(List.class, String.class);
        assertFalse(TypeUtils.containsTypeVariables(concrete));
        final TypeVariable<?> listVar = List.class.getTypeParameters()[0];
        final ParameterizedType withVariable = TypeUtils.parameterize(List.class, listVar);
        assertTrue(TypeUtils.containsTypeVariables(withVariable));
        assertTrue(TypeUtils.containsTypeVariables(listVar));
    }

    @Test
    void testContainsTypeVariablesOnWildcardAndGenericArray() {
        assertFalse(TypeUtils.containsTypeVariables(TypeUtils.WILDCARD_ALL));
        final TypeVariable<?> listVar = List.class.getTypeParameters()[0];
        final WildcardType wildcardWithVar = TypeUtils.wildcardType().withUpperBounds(listVar).build();
        assertTrue(TypeUtils.containsTypeVariables(wildcardWithVar));
        assertTrue(TypeUtils.containsTypeVariables(TypeUtils.genericArrayType(listVar)));
        assertFalse(TypeUtils.containsTypeVariables(TypeUtils.genericArrayType(String.class)));
    }

    @Test
    void testDetermineTypeArgumentsSameClass() {
        final ParameterizedType baseOfString = TypeUtils.parameterize(Base.class, String.class);
        final Map<TypeVariable<?>, Type> result = TypeUtils.determineTypeArguments(Base.class, baseOfString);
        assertEquals(1, result.size());
        assertEquals(String.class, result.get(Base.class.getTypeParameters()[0]));
    }

    @Test
    void testDetermineTypeArgumentsThroughHierarchy() {
        final ParameterizedType baseOfString = TypeUtils.parameterize(Base.class, String.class);
        final Map<TypeVariable<?>, Type> result = TypeUtils.determineTypeArguments(Leaf.class, baseOfString);
        assertEquals(String.class, result.get(Base.class.getTypeParameters()[0]));
        assertEquals(String.class, result.get(Mid.class.getTypeParameters()[0]));
    }

    @Test
    void testDetermineTypeArgumentsIncompatibleReturnsNull() {
        final ParameterizedType collectionOfString = TypeUtils.parameterize(Collection.class, String.class);
        assertNull(TypeUtils.determineTypeArguments(String.class, collectionOfString));
    }

    @Test
    void testDetermineTypeArgumentsNullArguments() {
        final ParameterizedType collectionOfString = TypeUtils.parameterize(Collection.class, String.class);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                TypeUtils.determineTypeArguments(null, collectionOfString);
            }
        });
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                TypeUtils.determineTypeArguments(String.class, null);
            }
        });
    }

    @Test
    void testEqualsClassesAndParameterizedTypes() {
        final ParameterizedType listOfString1 = TypeUtils.parameterize(List.class, String.class);
        final ParameterizedType listOfString2 = TypeUtils.parameterize(List.class, String.class);
        final ParameterizedType listOfInteger = TypeUtils.parameterize(List.class, Integer.class);
        assertTrue(TypeUtils.equals(String.class, String.class));
        assertFalse(TypeUtils.equals(String.class, Integer.class));
        assertTrue(TypeUtils.equals(listOfString1, listOfString2));
        assertFalse(TypeUtils.equals(listOfString1, listOfInteger));
    }

    @Test
    void testEqualsGenericArrayAndWildcardTypes() {
        final GenericArrayType arr1 = TypeUtils.genericArrayType(String.class);
        final GenericArrayType arr2 = TypeUtils.genericArrayType(String.class);
        final GenericArrayType arr3 = TypeUtils.genericArrayType(Integer.class);
        assertTrue(TypeUtils.equals(arr1, arr2));
        assertFalse(TypeUtils.equals(arr1, arr3));
        assertTrue(arr1.equals(arr2));

        final WildcardType wildcard1 = TypeUtils.WILDCARD_ALL;
        final WildcardType wildcard2 = TypeUtils.wildcardType().withUpperBounds(Object.class).build();
        assertTrue(TypeUtils.equals(wildcard1, wildcard2));
        assertTrue(wildcard1.equals(wildcard2));
    }

    @Test
    void testGenericArrayType() {
        final GenericArrayType arr = TypeUtils.genericArrayType(String.class);
        assertSame(String.class, arr.getGenericComponentType());
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                TypeUtils.genericArrayType(null);
            }
        });
    }

    @Test
    void testGetArrayComponentType() {
        assertEquals(int.class, TypeUtils.getArrayComponentType(int[].class));
        assertEquals(String.class, TypeUtils.getArrayComponentType(String[].class));
        assertNull(TypeUtils.getArrayComponentType(String.class));
        final GenericArrayType arr = TypeUtils.genericArrayType(String.class);
        assertEquals(String.class, TypeUtils.getArrayComponentType(arr));
        assertNull(TypeUtils.getArrayComponentType(TypeUtils.parameterize(List.class, String.class)));
    }

    @Test
    void testGetImplicitBounds() {
        final TypeVariable<?> listVar = List.class.getTypeParameters()[0];
        assertEquals(1, TypeUtils.getImplicitBounds(listVar).length);
        assertEquals(Object.class, TypeUtils.getImplicitBounds(listVar)[0]);
        final TypeVariable<?> baseVar = Base.class.getTypeParameters()[0];
        assertEquals(Object.class, TypeUtils.getImplicitBounds(baseVar)[0]);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                TypeUtils.getImplicitBounds(null);
            }
        });
    }

    @Test
    void testGetImplicitLowerBounds() {
        assertNull(TypeUtils.getImplicitLowerBounds(TypeUtils.WILDCARD_ALL)[0]);
        final WildcardType lower = TypeUtils.wildcardType().withLowerBounds(String.class).build();
        assertEquals(String.class, TypeUtils.getImplicitLowerBounds(lower)[0]);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                TypeUtils.getImplicitLowerBounds(null);
            }
        });
    }

    @Test
    void testGetImplicitUpperBounds() {
        assertEquals(Object.class, TypeUtils.getImplicitUpperBounds(TypeUtils.WILDCARD_ALL)[0]);
        final WildcardType upper = TypeUtils.wildcardType().withUpperBounds(Number.class).build();
        assertEquals(Number.class, TypeUtils.getImplicitUpperBounds(upper)[0]);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                TypeUtils.getImplicitUpperBounds(null);
            }
        });
    }

    @Test
    void testGetRawTypeWithClassAndParameterizedType() {
        assertEquals(String.class, TypeUtils.getRawType(String.class, null));
        final ParameterizedType listOfString = TypeUtils.parameterize(List.class, String.class);
        assertEquals(List.class, TypeUtils.getRawType(listOfString, null));
    }

    @Test
    void testGetRawTypeWithTypeVariable() {
        final TypeVariable<?> listVar = List.class.getTypeParameters()[0];
        assertNull(TypeUtils.getRawType(listVar, null));
        final ParameterizedType listOfString = TypeUtils.parameterize(List.class, String.class);
        assertEquals(String.class, TypeUtils.getRawType(listVar, listOfString));
    }

    @Test
    void testGetRawTypeWithGenericArrayAndWildcard() {
        final GenericArrayType arr = TypeUtils.genericArrayType(String.class);
        assertEquals(String[].class, TypeUtils.getRawType(arr, null));
        assertNull(TypeUtils.getRawType(TypeUtils.WILDCARD_ALL, null));
    }

    @Test
    void testGetRawTypeWithUnknownTypeThrows() {
        final Type unknown = new Type() {
            // marker-only Type implementation
        };
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                TypeUtils.getRawType(unknown, null);
            }
        });
    }

    @Test
    void testGetTypeArgumentsOfParameterizedType() {
        final ParameterizedType listOfString = TypeUtils.parameterize(List.class, String.class);
        final Map<TypeVariable<?>, Type> args = TypeUtils.getTypeArguments(listOfString);
        assertEquals(String.class, args.get(List.class.getTypeParameters()[0]));
    }

    @Test
    void testGetTypeArgumentsOfTypeAndClass() {
        final Map<TypeVariable<?>, Type> args = TypeUtils.getTypeArguments(String.class, Comparable.class);
        assertEquals(String.class, args.get(Comparable.class.getTypeParameters()[0]));
        assertNull(TypeUtils.getTypeArguments(String.class, List.class));
    }

    @Test
    void testIsArrayType() {
        assertTrue(TypeUtils.isArrayType(int[].class));
        assertTrue(TypeUtils.isArrayType(String[].class));
        assertFalse(TypeUtils.isArrayType(String.class));
        assertTrue(TypeUtils.isArrayType(TypeUtils.genericArrayType(String.class)));
        assertFalse(TypeUtils.isArrayType(null));
    }

    @Test
    void testIsAssignableClasses() {
        assertTrue(TypeUtils.isAssignable(Integer.class, Number.class));
        assertFalse(TypeUtils.isAssignable(Number.class, Integer.class));
    }

    @Test
    void testIsAssignableParameterizedTypes() {
        final ParameterizedType listOfString = TypeUtils.parameterize(List.class, String.class);
        assertTrue(TypeUtils.isAssignable(ArrayList.class, listOfString));
        assertFalse(TypeUtils.isAssignable(TypeUtils.parameterize(List.class, Integer.class), listOfString));
        final ParameterizedType listOfWildcardCharSequence = TypeUtils.parameterize(List.class, TypeUtils.wildcardType().withUpperBounds(CharSequence.class).build());
        assertTrue(TypeUtils.isAssignable(listOfString, listOfWildcardCharSequence));
    }

    @Test
    void testIsAssignableWildcardAndTypeVariableTargets() {
        final WildcardType extendsNumber = TypeUtils.wildcardType().withUpperBounds(Number.class).build();
        assertTrue(TypeUtils.isAssignable(Integer.class, extendsNumber));
        assertFalse(TypeUtils.isAssignable(String.class, extendsNumber));
        final TypeVariable<?> listVar = List.class.getTypeParameters()[0];
        assertFalse(TypeUtils.isAssignable(String.class, listVar));
        assertTrue(TypeUtils.isAssignable(listVar, listVar));
    }

    @Test
    void testIsAssignableGenericArrayTarget() {
        final GenericArrayType arrOfString = TypeUtils.genericArrayType(String.class);
        assertTrue(TypeUtils.isAssignable(String[].class, arrOfString));
        assertFalse(TypeUtils.isAssignable(Integer[].class, arrOfString));
    }

    @Test
    void testIsAssignableWithUnhandledTypeThrows() {
        final Type unknown = new Type() {
            // marker-only Type implementation
        };
        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                TypeUtils.isAssignable(String.class, unknown);
            }
        });
        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                TypeUtils.isAssignable(unknown, Number.class);
            }
        });
    }

    @Test
    void testIsInstance() {
        assertTrue(TypeUtils.isInstance("x", String.class));
        assertFalse(TypeUtils.isInstance(5, String.class));
        assertTrue(TypeUtils.isInstance(null, String.class));
        assertFalse(TypeUtils.isInstance(null, int.class));
        assertFalse(TypeUtils.isInstance("x", null));
    }

    @Test
    void testNormalizeUpperBounds() {
        final Type[] normalized = TypeUtils.normalizeUpperBounds(new Type[] { Number.class, Integer.class });
        assertEquals(1, normalized.length);
        assertEquals(Integer.class, normalized[0]);
        final Type[] single = TypeUtils.normalizeUpperBounds(new Type[] { Number.class });
        assertEquals(1, single.length);
        assertEquals(Number.class, single[0]);
        final Type[] none = TypeUtils.normalizeUpperBounds(new Type[0]);
        assertEquals(0, none.length);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                TypeUtils.normalizeUpperBounds(null);
            }
        });
    }

    @Test
    void testParameterizeBasic() {
        final ParameterizedType listOfString = TypeUtils.parameterize(List.class, String.class);
        assertEquals(List.class, listOfString.getRawType());
        assertEquals(1, listOfString.getActualTypeArguments().length);
        assertEquals(String.class, listOfString.getActualTypeArguments()[0]);
        assertNull(listOfString.getOwnerType());
    }

    @Test
    void testParameterizeWithTypeVariableMap() {
        final Map<TypeVariable<?>, Type> map = new HashMap<TypeVariable<?>, Type>();
        map.put(List.class.getTypeParameters()[0], String.class);
        final ParameterizedType listOfString = TypeUtils.parameterize(List.class, map);
        assertEquals(String.class, listOfString.getActualTypeArguments()[0]);
    }

    @Test
    void testParameterizeWrongArgumentCountThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                TypeUtils.parameterize(List.class, String.class, Integer.class);
            }
        });
    }

    @Test
    void testParameterizeNullElementThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                TypeUtils.parameterize(List.class, (Type) null);
            }
        });
    }

    @Test
    void testParameterizeWithOwnerRejectsOwnerForTopLevelClass() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                TypeUtils.parameterizeWithOwner(String.class, List.class, String.class);
            }
        });
    }

    @Test
    void testToStringForEachTypeKind() {
        assertEquals(String.class.getName(), TypeUtils.toString(String.class));
        final ParameterizedType listOfString = TypeUtils.parameterize(List.class, String.class);
        assertEquals("java.util.List<java.lang.String>", TypeUtils.toString(listOfString));
        assertEquals("?", TypeUtils.toString(TypeUtils.WILDCARD_ALL));
        final WildcardType lower = TypeUtils.wildcardType().withLowerBounds(String.class).build();
        assertEquals("? super java.lang.String", TypeUtils.toString(lower));
        final WildcardType upper = TypeUtils.wildcardType().withUpperBounds(Number.class).build();
        assertEquals("? extends java.lang.Number", TypeUtils.toString(upper));
        assertEquals("java.lang.String[]", TypeUtils.toString(TypeUtils.genericArrayType(String.class)));
    }

    @Test
    void testToStringNullAndUnknownTypeThrow() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                TypeUtils.toString(null);
            }
        });
        final Type unknown = new Type() {
            // marker-only Type implementation
        };
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                TypeUtils.toString(unknown);
            }
        });
    }

    @Test
    void testToLongString() {
        final TypeVariable<?> listVar = List.class.getTypeParameters()[0];
        assertEquals("java.util.List:E", TypeUtils.toLongString(listVar));
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                TypeUtils.toLongString(null);
            }
        });
    }

    @Test
    void testTypesSatisfyVariables() {
        final TypeVariable<?> baseVar = Base.class.getTypeParameters()[0];
        final Map<TypeVariable<?>, Type> satisfied = new HashMap<TypeVariable<?>, Type>();
        satisfied.put(baseVar, String.class);
        assertTrue(TypeUtils.typesSatisfyVariables(satisfied));

        final TypeVariable<?> numVar = NumBoxHolder.NumBox.class.getTypeParameters()[0];
        final Map<TypeVariable<?>, Type> unsatisfied = new HashMap<TypeVariable<?>, Type>();
        unsatisfied.put(numVar, String.class);
        assertFalse(TypeUtils.typesSatisfyVariables(unsatisfied));

        final Map<TypeVariable<?>, Type> satisfiedBound = new HashMap<TypeVariable<?>, Type>();
        satisfiedBound.put(numVar, Integer.class);
        assertTrue(TypeUtils.typesSatisfyVariables(satisfiedBound));

        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                TypeUtils.typesSatisfyVariables(null);
            }
        });
    }

    private static class NumBoxHolder {
        private static class NumBox<N extends Number> {
            // empty
        }
    }

    @Test
    void testUnrollVariablesResolvesTypeVariable() {
        final TypeVariable<?> listVar = List.class.getTypeParameters()[0];
        final Map<TypeVariable<?>, Type> assigns = new HashMap<TypeVariable<?>, Type>();
        assigns.put(listVar, Integer.class);
        final ParameterizedType listOfVar = TypeUtils.parameterize(List.class, listVar);
        final Type unrolled = TypeUtils.unrollVariables(assigns, listOfVar);
        assertTrue(unrolled instanceof ParameterizedType);
        assertEquals(Integer.class, ((ParameterizedType) unrolled).getActualTypeArguments()[0]);
    }

    @Test
    void testUnrollVariablesWithNullMapLeavesConcreteTypeUnchanged() {
        assertEquals(Integer.class, TypeUtils.unrollVariables(null, Integer.class));
    }

    @Test
    void testWildcardTypeBuilderDefaults() {
        final WildcardType builtDefault = TypeUtils.wildcardType().build();
        assertEquals(0, builtDefault.getUpperBounds().length);
        assertEquals(0, builtDefault.getLowerBounds().length);
        assertEquals(Object.class, TypeUtils.getImplicitUpperBounds(builtDefault)[0]);
        assertNull(TypeUtils.getImplicitLowerBounds(builtDefault)[0]);
    }

    @Test
    void testWildcardAllConstant() {
        assertEquals(1, TypeUtils.WILDCARD_ALL.getUpperBounds().length);
        assertEquals(Object.class, TypeUtils.WILDCARD_ALL.getUpperBounds()[0]);
        assertEquals(0, TypeUtils.WILDCARD_ALL.getLowerBounds().length);
    }

    @Test
    void testWrapClassAndType() {
        final Typed<String> wrappedClass = TypeUtils.wrap(String.class);
        assertEquals(String.class, wrappedClass.getType());
        final ParameterizedType listOfString = TypeUtils.parameterize(List.class, String.class);
        final Typed<List<String>> wrappedType = TypeUtils.wrap((Type) listOfString);
        assertSame(listOfString, wrappedType.getType());
    }

    @Test
    void testDeprecatedPublicConstructor() {
        assertTrue(new TypeUtils() instanceof TypeUtils);
    }
}
