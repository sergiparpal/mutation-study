/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.time.StopWatch.Split;
import org.junit.jupiter.api.Test;

/**
 * Tests {@link StopWatch}.
 */
public class StopWatchAgentTest {

    @Test
    public void testCreateUnstarted() {
        final StopWatch watch = StopWatch.create();
        assertFalse(watch.isStarted());
        assertTrue(watch.isStopped());
        assertFalse(watch.isSuspended());
        assertEquals(0, watch.getTime());
    }

    @Test
    public void testCreateStarted() {
        final StopWatch watch = StopWatch.createStarted();
        assertTrue(watch.isStarted());
        assertFalse(watch.isStopped());
        assertFalse(watch.isSuspended());
    }

    @Test
    public void testMessageConstructor() {
        final StopWatch watch = new StopWatch("myMessage");
        assertEquals("myMessage", watch.getMessage());
        assertTrue(watch.toString().startsWith("myMessage "));
    }

    @Test
    public void testNoArgConstructorHasNullMessage() {
        final StopWatch watch = new StopWatch();
        assertNotNull(watch.getMessage() == null ? "null" : watch.getMessage());
        assertEquals(null, watch.getMessage());
    }

    @Test
    public void testStartStopGetTime() throws InterruptedException {
        final StopWatch watch = new StopWatch();
        watch.start();
        Thread.sleep(20);
        watch.stop();
        assertTrue(watch.isStopped());
        assertFalse(watch.isStarted());
        assertTrue(watch.getTime() >= 0);
        assertTrue(watch.getNanoTime() >= 0);
        assertEquals(watch.getTime(), watch.getDuration().toMillis());
    }

    @Test
    public void testStartTwiceThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertThrows(IllegalStateException.class, watch::start);
    }

    @Test
    public void testStartAfterStopWithoutResetThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        assertThrows(IllegalStateException.class, watch::start);
    }

    @Test
    public void testStopBeforeStartThrows() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, watch::stop);
    }

    @Test
    public void testSuspendBeforeStartThrows() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, watch::suspend);
    }

    @Test
    public void testResumeWithoutSuspendThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertThrows(IllegalStateException.class, watch::resume);
    }

    @Test
    public void testSplitWithoutStartThrows() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, watch::split);
    }

    @Test
    public void testUnsplitWithoutSplitThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertThrows(IllegalStateException.class, watch::unsplit);
    }

    @Test
    public void testGetSplitTimeWithoutSplitThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertThrows(IllegalStateException.class, watch::getSplitNanoTime);
        assertThrows(IllegalStateException.class, watch::getSplitDuration);
    }

    @Test
    public void testSplitAndUnsplit() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        assertTrue(watch.getSplitNanoTime() >= 0);
        assertEquals(1, watch.getSplits().size());
        watch.unsplit();
        assertThrows(IllegalStateException.class, watch::getSplitNanoTime);
        assertEquals(0, watch.getSplits().size());
    }

    @Test
    public void testSplitTwiceAccumulatesSplits() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split("first");
        watch.split("second");
        final List<Split> splits = watch.getSplits();
        assertEquals(2, splits.size());
        assertEquals("first", splits.get(0).getLabel());
        assertEquals("second", splits.get(1).getLabel());
        assertNotNull(splits.get(0).getDuration());
        assertTrue(splits.get(0).toString().contains("first"));
    }

    @Test
    public void testSplitDefaultLabelsAreIndexes() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        watch.split();
        final List<Split> splits = watch.getSplits();
        assertEquals("0", splits.get(0).getLabel());
        assertEquals("1", splits.get(1).getLabel());
    }

    @Test
    public void testGetSplitsIsUnmodifiable() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        final List<Split> splits = watch.getSplits();
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                splits.add(new Split("x", Duration.ZERO));
            }
        });
    }

    @Test
    public void testSuspendResume() throws InterruptedException {
        final StopWatch watch = new StopWatch();
        watch.start();
        Thread.sleep(10);
        watch.suspend();
        assertTrue(watch.isSuspended());
        assertTrue(watch.isStarted());
        final long suspendedTime = watch.getTime();
        Thread.sleep(10);
        assertEquals(suspendedTime, watch.getTime());
        watch.resume();
        assertFalse(watch.isSuspended());
        watch.stop();
        assertTrue(watch.getTime() >= suspendedTime);
    }

    @Test
    public void testSuspendTwiceThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.suspend();
        assertThrows(IllegalStateException.class, watch::suspend);
    }

    @Test
    public void testStopWhileSuspendedDoesNotAdvanceStopInstant() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.suspend();
        final Instant stopInstantAtSuspend = watch.getStopInstant();
        watch.stop();
        assertEquals(stopInstantAtSuspend, watch.getStopInstant());
    }

    @Test
    public void testReset() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        watch.stop();
        watch.reset();
        assertFalse(watch.isStarted());
        assertTrue(watch.isStopped());
        assertEquals(0, watch.getSplits().size());
        assertThrows(IllegalStateException.class, watch::getSplitNanoTime);
        watch.start();
        assertTrue(watch.isStarted());
    }

    @Test
    public void testGetStartInstantAndStopInstantBeforeStartThrows() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, watch::getStartInstant);
        assertThrows(IllegalStateException.class, watch::getStopInstant);
    }

    @Test
    public void testGetStartTimeMatchesStartInstant() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertEquals(watch.getStartInstant().toEpochMilli(), watch.getStartTime());
    }

    @Test
    public void testGetStopTimeMatchesStopInstant() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        assertEquals(watch.getStopInstant().toEpochMilli(), watch.getStopTime());
    }

    @Test
    public void testGetTimeTimeUnit() throws InterruptedException {
        final StopWatch watch = new StopWatch();
        watch.start();
        Thread.sleep(5);
        watch.stop();
        final long nanos = watch.getNanoTime();
        assertEquals(TimeUnit.NANOSECONDS.toSeconds(nanos), watch.getTime(TimeUnit.SECONDS));
        assertEquals(TimeUnit.NANOSECONDS.toMillis(nanos), watch.getTime(TimeUnit.MILLISECONDS));
    }

    @Test
    public void testFormatTimeAndToString() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        final String formatted = watch.formatTime();
        assertNotNull(formatted);
        assertEquals(formatted, watch.toString());
    }

    @Test
    public void testFormatSplitTimeAndToSplitString() {
        final StopWatch watch = new StopWatch("msg");
        watch.start();
        watch.split();
        final String formatted = watch.formatSplitTime();
        assertNotNull(formatted);
        assertEquals("msg " + formatted, watch.toSplitString());
    }

    @Test
    public void testToSplitStringWithoutMessage() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        assertEquals(watch.formatSplitTime(), watch.toSplitString());
    }

    @Test
    public void testGetDuration() {
        final StopWatch watch = new StopWatch();
        assertEquals(Duration.ZERO, watch.getDuration());
        watch.start();
        watch.stop();
        assertEquals(watch.getNanoTime(), watch.getDuration().toNanos());
    }

    @Test
    public void testRunRunnableRecordsDuration() {
        final StopWatch watch = new StopWatch();
        final boolean[] ran = new boolean[1];
        watch.run(new Runnable() {
            @Override
            public void run() {
                ran[0] = true;
            }
        });
        assertTrue(ran[0]);
        assertTrue(watch.isSuspended());
        assertTrue(watch.getTime() >= 0);
    }

    @Test
    public void testGetSupplierReturnsValue() {
        final StopWatch watch = new StopWatch();
        final Integer result = watch.get(new java.util.function.Supplier<Integer>() {
            @Override
            public Integer get() {
                return 42;
            }
        });
        assertEquals(Integer.valueOf(42), result);
        assertTrue(watch.isSuspended());
    }

    @Test
    public void testRunTPropagatesException() {
        final StopWatch watch = new StopWatch();
        final Exception expected = new Exception("boom");
        final Throwable thrown = assertThrows(Exception.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                watch.runT(new org.apache.commons.lang3.function.FailableRunnable<Exception>() {
                    @Override
                    public void run() throws Exception {
                        throw expected;
                    }
                });
            }
        });
        assertEquals(expected, thrown);
        assertTrue(watch.isSuspended());
    }

    @Test
    public void testSplitLabelUsedInToString() {
        final Split split = new Split("label1", Duration.ofMillis(5));
        assertEquals("label1", split.getLabel());
        assertEquals(Duration.ofMillis(5), split.getDuration());
        assertTrue(split.toString().contains("label1"));
    }
}
