/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link FastDateParser}.
 */
class FastDateParserAgentTest {

    private static final TimeZone GMT = TimeZone.getTimeZone("GMT");

    @Test
    void testBasicParseReturnsExpectedFields() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final Date date = parser.parse("2020-03-15");
        final Calendar cal = Calendar.getInstance(GMT, Locale.US);
        cal.setTime(date);
        assertEquals(2020, cal.get(Calendar.YEAR));
        assertEquals(Calendar.MARCH, cal.get(Calendar.MONTH));
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testGettersReturnConstructorValues() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        assertEquals("yyyy-MM-dd", parser.getPattern());
        assertSame(GMT, parser.getTimeZone());
        assertEquals(Locale.US, parser.getLocale());
    }

    @Test
    void testToStringContainsPatternLocaleAndTimeZone() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final String s = parser.toString();
        assertTrue(s.contains("yyyy-MM-dd"));
        assertTrue(s.contains(Locale.US.toString()));
        assertTrue(s.contains(GMT.getID()));
    }

    @Test
    void testToStringAllContainsFieldLabels() {
        final FastDateParser parser = new FastDateParser("yyyy", GMT, Locale.US);
        final String s = parser.toStringAll();
        assertTrue(s.contains("pattern=yyyy"));
        assertTrue(s.contains("timeZone="));
        assertTrue(s.contains("locale="));
    }

    @Test
    void testEqualsAndHashCodeForEqualInstances() {
        final FastDateParser p1 = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final FastDateParser p2 = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        assertEquals(p1, p2);
        assertEquals(p1.hashCode(), p2.hashCode());
    }

    @Test
    void testEqualsFalseForDifferentPattern() {
        final FastDateParser p1 = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final FastDateParser p2 = new FastDateParser("dd-MM-yyyy", GMT, Locale.US);
        assertNotEquals(p1, p2);
    }

    @Test
    void testEqualsFalseForNullAndOtherType() {
        final FastDateParser p1 = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        assertNotEquals(p1, null);
        assertNotEquals(p1, "yyyy-MM-dd");
    }

    @Test
    void testParseThrowsOnUnparseableDate() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final ParseException ex = assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                parser.parse("abcd-01-01");
            }
        });
        assertTrue(ex.getMessage().contains("Unparseable date"));
        assertEquals(0, ex.getErrorOffset());
    }

    @Test
    void testParseAllowsUnconsumedTrailingText() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy", GMT, Locale.US);
        final Date date = parser.parse("2020extra");
        final Calendar cal = Calendar.getInstance(GMT, Locale.US);
        cal.setTime(date);
        assertEquals(2020, cal.get(Calendar.YEAR));
    }

    @Test
    void testParseWithPositionUpdatesIndexAndLeavesRemainder() {
        final FastDateParser parser = new FastDateParser("yyyy", GMT, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("2020extra", pos);
        assertNotNull(date);
        assertEquals(4, pos.getIndex());
    }

    @Test
    void testParseWithPositionBeyondSourceLengthReturnsNull() {
        final FastDateParser parser = new FastDateParser("yyyy", GMT, Locale.US);
        final ParsePosition pos = new ParsePosition(50);
        final Date date = parser.parse("2020", pos);
        assertNull(date);
        assertEquals(50, pos.getErrorIndex());
    }

    @Test
    void testParseIntoCalendarReturnsFalseOnMismatch() {
        final FastDateParser parser = new FastDateParser("yyyyMMdd", GMT, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Calendar cal = Calendar.getInstance(GMT, Locale.US);
        cal.clear();
        final boolean result = parser.parse("abcd0101", pos, cal);
        assertFalse(result);
        assertEquals(0, pos.getErrorIndex());
    }

    @Test
    void testParseFailsOnIntegerOverflowDigitRun() {
        final FastDateParser parser = new FastDateParser("yyyy", GMT, Locale.US);
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                parser.parse("99999999999999999999");
            }
        });
    }

    @Test
    void testParseObjectDelegatesToParse() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final Object obj = parser.parseObject("2020-03-15");
        assertTrue(obj instanceof Date);
        final ParsePosition pos = new ParsePosition(0);
        final Object obj2 = parser.parseObject("2020-03-15", pos);
        assertTrue(obj2 instanceof Date);
        assertEquals(10, pos.getIndex());
    }

    @Test
    void testTwoDigitYearAdjustmentBelowStartYearRollsToNextCentury() throws ParseException {
        final Calendar centuryBase = Calendar.getInstance(GMT, Locale.US);
        centuryBase.clear();
        centuryBase.set(1950, Calendar.JANUARY, 1);
        final FastDateParser parser = new FastDateParser("yy", GMT, Locale.US, centuryBase.getTime());
        final Date date = parser.parse("49");
        final Calendar cal = Calendar.getInstance(GMT, Locale.US);
        cal.setTime(date);
        assertEquals(2049, cal.get(Calendar.YEAR));
    }

    @Test
    void testTwoDigitYearAdjustmentAtOrAboveStartYearStaysInBaseCentury() throws ParseException {
        final Calendar centuryBase = Calendar.getInstance(GMT, Locale.US);
        centuryBase.clear();
        centuryBase.set(1950, Calendar.JANUARY, 1);
        final FastDateParser parser = new FastDateParser("yy", GMT, Locale.US, centuryBase.getTime());
        final Date date = parser.parse("60");
        final Calendar cal = Calendar.getInstance(GMT, Locale.US);
        cal.setTime(date);
        assertEquals(1960, cal.get(Calendar.YEAR));
    }

    @Test
    void testFourDigitYearIsUsedLiterally() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy", GMT, Locale.US);
        final Date date = parser.parse("0099");
        final Calendar cal = Calendar.getInstance(GMT, Locale.US);
        cal.setTime(date);
        assertEquals(99, cal.get(Calendar.YEAR));
    }

    @Test
    void testCaseInsensitiveFullMonthNameParsing() throws ParseException {
        final FastDateParser parser = new FastDateParser("MMMM yyyy", GMT, Locale.US);
        final Date date = parser.parse("JANUARY 2020");
        final Calendar cal = Calendar.getInstance(GMT, Locale.US);
        cal.setTime(date);
        assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));
        assertEquals(2020, cal.get(Calendar.YEAR));
    }

    @Test
    void testHour12MidnightStrategyMapsTwelveToZero() throws ParseException {
        final FastDateParser parser = new FastDateParser("hh:mm a", GMT, Locale.US);
        final Date date = parser.parse("12:30 AM");
        final Calendar cal = Calendar.getInstance(GMT, Locale.US);
        cal.setTime(date);
        assertEquals(0, cal.get(Calendar.HOUR));
        assertEquals(Calendar.AM, cal.get(Calendar.AM_PM));
        assertEquals(30, cal.get(Calendar.MINUTE));
    }

    @Test
    void testHour24MidnightStrategyMapsTwentyFourToZero() throws ParseException {
        final FastDateParser parser = new FastDateParser("kk:mm", GMT, Locale.US);
        final Date date = parser.parse("24:00");
        final Calendar cal = Calendar.getInstance(GMT, Locale.US);
        cal.setTime(date);
        assertEquals(0, cal.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    void testIsoOffsetTimeZoneParsing() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd'T'HH:mm:ssZZ", GMT, Locale.US);
        final Date date = parser.parse("2023-01-15T10:30:00+01:00");
        final Calendar cal = Calendar.getInstance(GMT, Locale.US);
        cal.setTime(date);
        assertEquals(9, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals(30, cal.get(Calendar.MINUTE));
    }

    @Test
    void testLiteralQuotedTextMustMatchExactly() {
        final FastDateParser parser = new FastDateParser("yyyy'Q'MM", GMT, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Calendar cal = Calendar.getInstance(GMT, Locale.US);
        cal.clear();
        final boolean result = parser.parse("2020X01", pos, cal);
        assertFalse(result);
        assertEquals(4, pos.getErrorIndex());
    }

    @Test
    void testLiteralQuotedTextMatchesAndConsumesLiteral() {
        final FastDateParser parser = new FastDateParser("yyyy'Q'MM", GMT, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Calendar cal = Calendar.getInstance(GMT, Locale.US);
        cal.clear();
        final boolean result = parser.parse("2020Q01", pos, cal);
        assertTrue(result);
        assertEquals(7, pos.getIndex());
    }

    @Test
    void testUnterminatedQuoteThrowsIllegalArgumentExceptionAtConstruction() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDateParser("yyyy'Q", GMT, Locale.US);
            }
        });
    }

    @Test
    void testUnsupportedFormatLetterThrowsIllegalArgumentExceptionAtConstruction() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDateParser("yyyy-q", GMT, Locale.US);
            }
        });
        assertTrue(ex.getMessage().contains("not supported"));
    }

    @Test
    void testInvalidIsoWidthThrowsIllegalArgumentExceptionAtConstruction() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDateParser("yyyy-MM-dd'T'HH:mm:ssXXXX", GMT, Locale.US);
            }
        });
    }

    @Test
    void testJapaneseImperialLocaleAddsExplanationToParseException() {
        final FastDateParser parser = new FastDateParser("yyyy", GMT, new Locale("ja", "JP", "JP"));
        final ParseException ex = assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                parser.parse("");
            }
        });
        assertTrue(ex.getMessage().contains("does not support dates before 1868-01-01"));
    }

    @Test
    void testConstructorRejectsNullPattern() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDateParser(null, GMT, Locale.US);
            }
        });
    }

    @Test
    void testConstructorRejectsNullTimeZone() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDateParser("yyyy", null, Locale.US);
            }
        });
    }

    @Test
    void testConstructorAllowsNullLocaleAndFallsBackToDefault() {
        final FastDateParser parser = new FastDateParser("yyyy", GMT, null);
        assertNotNull(parser.getLocale());
    }

    @Test
    void testSerializationRoundTripPreservesParsingBehavior() throws Exception {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        final ObjectOutputStream oos = new ObjectOutputStream(baos);
        oos.writeObject(parser);
        oos.close();
        final ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(baos.toByteArray()));
        final FastDateParser deserialized = (FastDateParser) ois.readObject();
        ois.close();
        assertEquals(parser, deserialized);
        final Date date = deserialized.parse("2021-07-04");
        final Calendar cal = Calendar.getInstance(GMT, Locale.US);
        cal.setTime(date);
        assertEquals(2021, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JULY, cal.get(Calendar.MONTH));
        assertEquals(4, cal.get(Calendar.DAY_OF_MONTH));
    }
}
