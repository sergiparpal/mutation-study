package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class FractionAgentTest {

    private static final double DELTA = 1.0e-9;

    // ---- constants ----

    @Test
    public void testZeroConstant() {
        assertEquals(0, Fraction.ZERO.getNumerator());
        assertEquals(1, Fraction.ZERO.getDenominator());
    }

    @Test
    public void testOneConstant() {
        assertEquals(1, Fraction.ONE.getNumerator());
        assertEquals(1, Fraction.ONE.getDenominator());
    }

    @Test
    public void testOneHalfConstant() {
        assertEquals(1, Fraction.ONE_HALF.getNumerator());
        assertEquals(2, Fraction.ONE_HALF.getDenominator());
    }

    @Test
    public void testOneThirdConstant() {
        assertEquals(1, Fraction.ONE_THIRD.getNumerator());
        assertEquals(3, Fraction.ONE_THIRD.getDenominator());
    }

    @Test
    public void testTwoThirdsConstant() {
        assertEquals(2, Fraction.TWO_THIRDS.getNumerator());
        assertEquals(3, Fraction.TWO_THIRDS.getDenominator());
    }

    @Test
    public void testOneQuarterConstant() {
        assertEquals(1, Fraction.ONE_QUARTER.getNumerator());
        assertEquals(4, Fraction.ONE_QUARTER.getDenominator());
    }

    @Test
    public void testTwoQuartersConstantIsNotReduced() {
        assertEquals(2, Fraction.TWO_QUARTERS.getNumerator());
        assertEquals(4, Fraction.TWO_QUARTERS.getDenominator());
        assertFalse(Fraction.TWO_QUARTERS.equals(Fraction.ONE_HALF));
        assertEquals(0, Fraction.TWO_QUARTERS.compareTo(Fraction.ONE_HALF));
    }

    @Test
    public void testThreeQuartersConstant() {
        assertEquals(3, Fraction.THREE_QUARTERS.getNumerator());
        assertEquals(4, Fraction.THREE_QUARTERS.getDenominator());
    }

    @Test
    public void testFifthsConstants() {
        assertEquals(1, Fraction.ONE_FIFTH.getNumerator());
        assertEquals(5, Fraction.ONE_FIFTH.getDenominator());
        assertEquals(2, Fraction.TWO_FIFTHS.getNumerator());
        assertEquals(5, Fraction.TWO_FIFTHS.getDenominator());
        assertEquals(3, Fraction.THREE_FIFTHS.getNumerator());
        assertEquals(5, Fraction.THREE_FIFTHS.getDenominator());
        assertEquals(4, Fraction.FOUR_FIFTHS.getNumerator());
        assertEquals(5, Fraction.FOUR_FIFTHS.getDenominator());
    }

    // ---- getFraction(int, int) ----

    @Test
    public void testGetFractionIntInt_basic() {
        Fraction f = Fraction.getFraction(3, 7);
        assertEquals(3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionIntInt_negativeDenominatorResolvedToNumerator() {
        Fraction f = Fraction.getFraction(3, -7);
        assertEquals(-3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionIntInt_bothNegativeCancelOut() {
        Fraction f = Fraction.getFraction(-1, -2);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetFractionIntInt_zeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                Fraction.getFraction(1, 0);
            }
        });
    }

    @Test
    public void testGetFractionIntInt_negativeDenominatorWithMinValueNumeratorThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                Fraction.getFraction(Integer.MIN_VALUE, -1);
            }
        });
    }

    // ---- getFraction(int, int, int) ----

    @Test
    public void testGetFractionWholeNumDen_basic() {
        Fraction f = Fraction.getFraction(1, 3, 7);
        assertEquals(10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionWholeNumDen_negativeWhole() {
        Fraction f = Fraction.getFraction(-1, 3, 7);
        assertEquals(-10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionWholeNumDen_zeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                Fraction.getFraction(1, 1, 0);
            }
        });
    }

    @Test
    public void testGetFractionWholeNumDen_negativeDenominatorThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                Fraction.getFraction(1, 1, -1);
            }
        });
    }

    @Test
    public void testGetFractionWholeNumDen_negativeNumeratorThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                Fraction.getFraction(1, -1, 2);
            }
        });
    }

    @Test
    public void testGetFractionWholeNumDen_overflowThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                Fraction.getFraction(Integer.MAX_VALUE, 1, 2);
            }
        });
    }

    // ---- getFraction(String) ----

    @Test
    public void testGetFractionString_doubleFormat() {
        Fraction f = Fraction.getFraction("1.5");
        assertEquals(1.5d, f.doubleValue(), DELTA);
    }

    @Test
    public void testGetFractionString_mixedFormat() {
        Fraction f = Fraction.getFraction("1 3/4");
        assertEquals(7, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionString_simpleFraction() {
        Fraction f = Fraction.getFraction("3/4");
        assertEquals(3, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionString_wholeNumber() {
        Fraction f = Fraction.getFraction("5");
        assertEquals(5, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    public void testGetFractionString_nullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                Fraction.getFraction((String) null);
            }
        });
    }

    @Test
    public void testGetFractionString_invalidFormatThrowsNumberFormatException() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                Fraction.getFraction("not-a-fraction");
            }
        });
    }

    @Test
    public void testGetFractionString_zeroDenominatorThrowsWithArithmeticCause() {
        NumberFormatException ex = assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                Fraction.getFraction("1/0");
            }
        });
        assertNotNull(ex.getCause());
        assertTrue(ex.getCause() instanceof ArithmeticException);
    }

    @Test
    public void testGetFractionString_outOfIntRangeThrowsWithArithmeticCause() {
        NumberFormatException ex = assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                Fraction.getFraction("9999999999.5");
            }
        });
        assertNotNull(ex.getCause());
        assertTrue(ex.getCause() instanceof ArithmeticException);
    }

    // ---- getReducedFraction(int, int) ----

    @Test
    public void testGetReducedFraction_basic() {
        Fraction f = Fraction.getReducedFraction(2, 4);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetReducedFraction_negativeDenominatorResolved() {
        Fraction f = Fraction.getReducedFraction(2, -4);
        assertEquals(-1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetReducedFraction_zeroNumeratorReducesToZeroOverOne() {
        Fraction f = Fraction.getReducedFraction(0, 5);
        assertEquals(0, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    public void testGetReducedFraction_zeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                Fraction.getReducedFraction(1, 0);
            }
        });
    }

    // ---- getFraction(double) ----

    @Test
    public void testGetFractionDouble_basic() {
        Fraction f = Fraction.getFraction(0.25d);
        assertEquals(0.25d, f.doubleValue(), DELTA);
        assertEquals(1, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionDouble_greaterThanOne() {
        Fraction f = Fraction.getFraction(1.5d);
        assertEquals(1.5d, f.doubleValue(), DELTA);
        assertEquals(3, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetFractionDouble_zero() {
        Fraction f = Fraction.getFraction(0.0d);
        assertEquals(0, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    public void testGetFractionDouble_nanThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                Fraction.getFraction(Double.NaN);
            }
        });
    }

    @Test
    public void testGetFractionDouble_tooLargeThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                Fraction.getFraction(1.0e10);
            }
        });
    }

    @Test
    public void testGetFractionDouble_tooNegativeThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                Fraction.getFraction(-1.0e10);
            }
        });
    }

    // ---- abs() ----

    @Test
    public void testAbs_positiveReturnsThis() {
        assertSame(Fraction.ONE_HALF, Fraction.ONE_HALF.abs());
    }

    @Test
    public void testAbs_negativeReturnsPositive() {
        Fraction f = Fraction.getFraction(-1, 2);
        Fraction result = f.abs();
        assertEquals(1, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    // ---- add(Fraction) ----

    @Test
    public void testAdd_basic() {
        Fraction result = Fraction.ONE_HALF.add(Fraction.ONE_THIRD);
        assertEquals(5, result.getNumerator());
        assertEquals(6, result.getDenominator());
    }

    @Test
    public void testAdd_resultIsReduced() {
        Fraction result = Fraction.getFraction(1, 4).add(Fraction.getFraction(1, 4));
        assertEquals(1, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    @Test
    public void testAdd_nullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                Fraction.ONE_HALF.add(null);
            }
        });
    }

    @Test
    public void testAdd_overflowThrows() {
        final Fraction big = Fraction.getFraction(Integer.MAX_VALUE, 1);
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                big.add(big);
            }
        });
    }

    // ---- compareTo(Fraction) ----

    @Test
    public void testCompareTo_lessGreaterEqual() {
        assertTrue(Fraction.ONE_THIRD.compareTo(Fraction.ONE_HALF) < 0);
        assertTrue(Fraction.ONE_HALF.compareTo(Fraction.ONE_THIRD) > 0);
        assertEquals(0, Fraction.ONE_HALF.compareTo(Fraction.TWO_QUARTERS));
    }

    @Test
    public void testCompareTo_nullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                Fraction.ONE_HALF.compareTo(null);
            }
        });
    }

    // ---- divideBy(Fraction) ----

    @Test
    public void testDivideBy_basic() {
        Fraction result = Fraction.ONE_HALF.divideBy(Fraction.ONE_THIRD);
        assertEquals(3, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    @Test
    public void testDivideBy_resultIsReduced() {
        Fraction result = Fraction.getFraction(2, 3).divideBy(Fraction.getFraction(4, 3));
        assertEquals(1, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    @Test
    public void testDivideBy_byZeroThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                Fraction.ONE_HALF.divideBy(Fraction.ZERO);
            }
        });
    }

    @Test
    public void testDivideBy_nullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                Fraction.ONE_HALF.divideBy(null);
            }
        });
    }

    // ---- doubleValue() / floatValue() ----

    @Test
    public void testDoubleValue() {
        assertEquals(0.75d, Fraction.getFraction(3, 4).doubleValue(), DELTA);
    }

    @Test
    public void testFloatValue() {
        assertEquals(0.75f, Fraction.getFraction(3, 4).floatValue(), 1.0e-6f);
    }

    // ---- getNumerator() / getDenominator() with improper fractions ----

    @Test
    public void testGetNumeratorAndDenominator_improperFraction() {
        Fraction f = Fraction.getFraction(7, 4);
        assertEquals(7, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    // ---- getProperNumerator() / getProperWhole() ----

    @Test
    public void testGetProperNumeratorAndWhole_positive() {
        Fraction f = Fraction.getFraction(7, 4);
        assertEquals(3, f.getProperNumerator());
        assertEquals(1, f.getProperWhole());
    }

    @Test
    public void testGetProperNumeratorAndWhole_negative() {
        Fraction f = Fraction.getFraction(-7, 4);
        assertEquals(3, f.getProperNumerator());
        assertEquals(-1, f.getProperWhole());
    }

    // ---- equals(Object) / hashCode() ----

    @Test
    public void testEquals_sameValueSameRepresentation() {
        assertTrue(Fraction.getFraction(1, 2).equals(Fraction.ONE_HALF));
    }

    @Test
    public void testEquals_sameValueDifferentRepresentationNotEqual() {
        assertFalse(Fraction.getFraction(2, 4).equals(Fraction.getFraction(1, 2)));
    }

    @Test
    public void testEquals_null() {
        assertFalse(Fraction.ONE_HALF.equals(null));
    }

    @Test
    public void testEquals_differentType() {
        assertFalse(Fraction.ONE_HALF.equals("1/2"));
    }

    @Test
    public void testHashCode_consistentWithEquals() {
        Fraction a = Fraction.getFraction(1, 2);
        Fraction b = Fraction.ONE_HALF;
        assertTrue(a.equals(b));
        assertEquals(a.hashCode(), b.hashCode());
    }

    // ---- intValue() / longValue() ----

    @Test
    public void testIntValue() {
        assertEquals(1, Fraction.getFraction(7, 4).intValue());
        assertEquals(-1, Fraction.getFraction(-7, 4).intValue());
    }

    @Test
    public void testLongValue() {
        assertEquals(1L, Fraction.getFraction(7, 4).longValue());
        assertEquals(-1L, Fraction.getFraction(-7, 4).longValue());
    }

    // ---- invert() ----

    @Test
    public void testInvert_basic() {
        Fraction result = Fraction.getFraction(3, 4).invert();
        assertEquals(4, result.getNumerator());
        assertEquals(3, result.getDenominator());
    }

    @Test
    public void testInvert_zeroThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                Fraction.ZERO.invert();
            }
        });
    }

    // ---- multiplyBy(Fraction) ----

    @Test
    public void testMultiplyBy_basic() {
        Fraction result = Fraction.ONE_HALF.multiplyBy(Fraction.TWO_THIRDS);
        assertEquals(1, result.getNumerator());
        assertEquals(3, result.getDenominator());
    }

    @Test
    public void testMultiplyBy_resultIsReduced() {
        Fraction result = Fraction.getFraction(2, 3).multiplyBy(Fraction.getFraction(3, 4));
        assertEquals(1, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    @Test
    public void testMultiplyBy_nullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                Fraction.ONE_HALF.multiplyBy(null);
            }
        });
    }

    @Test
    public void testMultiplyBy_overflowThrows() {
        final Fraction big = Fraction.getFraction(Integer.MAX_VALUE, 1);
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                big.multiplyBy(Fraction.getFraction(2, 1));
            }
        });
    }

    // ---- negate() ----

    @Test
    public void testNegate_basic() {
        Fraction result = Fraction.ONE_HALF.negate();
        assertEquals(-1, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    // ---- pow(int) ----

    @Test
    public void testPow_zeroReturnsOneEvenForZeroFraction() {
        assertSame(Fraction.ONE, Fraction.ONE_HALF.pow(0));
        assertSame(Fraction.ONE, Fraction.ZERO.pow(0));
    }

    @Test
    public void testPow_oneReturnsThis() {
        assertSame(Fraction.ONE_HALF, Fraction.ONE_HALF.pow(1));
    }

    @Test
    public void testPow_positivePower() {
        Fraction result = Fraction.getFraction(2, 3).pow(3);
        assertEquals(8, result.getNumerator());
        assertEquals(27, result.getDenominator());
    }

    @Test
    public void testPow_overflowThrows() {
        final Fraction big = Fraction.getFraction(Integer.MAX_VALUE, 1);
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                big.pow(2);
            }
        });
    }

    // ---- reduce() ----

    @Test
    public void testReduce_alreadyReducedReturnsThis() {
        assertSame(Fraction.ONE_HALF, Fraction.ONE_HALF.reduce());
    }

    @Test
    public void testReduce_simplifies() {
        Fraction result = Fraction.getFraction(2, 4).reduce();
        assertEquals(1, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    @Test
    public void testReduce_negativeSimplifies() {
        Fraction result = Fraction.getFraction(-4, 8).reduce();
        assertEquals(-1, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    // ---- subtract(Fraction) ----

    @Test
    public void testSubtract_basic() {
        Fraction result = Fraction.ONE_HALF.subtract(Fraction.ONE_THIRD);
        assertEquals(1, result.getNumerator());
        assertEquals(6, result.getDenominator());
    }

    @Test
    public void testSubtract_resultIsReduced() {
        Fraction result = Fraction.getFraction(3, 4).subtract(Fraction.getFraction(1, 4));
        assertEquals(1, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    @Test
    public void testSubtract_nullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                Fraction.ONE_HALF.subtract(null);
            }
        });
    }

    @Test
    public void testSubtract_overflowThrows() {
        final Fraction min = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                min.subtract(Fraction.ONE);
            }
        });
    }

    // ---- toProperString() ----

    @Test
    public void testToProperString_zero() {
        assertEquals("0", Fraction.ZERO.toProperString());
    }

    @Test
    public void testToProperString_wholeNumberOnly() {
        assertEquals("4", Fraction.getFraction(4, 1).toProperString());
    }

    @Test
    public void testToProperString_properFractionOmitsZeroWhole() {
        assertEquals("1/2", Fraction.ONE_HALF.toProperString());
    }

    @Test
    public void testToProperString_mixedNumber() {
        assertEquals("1 3/4", Fraction.getFraction(7, 4).toProperString());
    }

    // ---- toString() ----

    @Test
    public void testToString_properFraction() {
        assertEquals("3/4", Fraction.getFraction(3, 4).toString());
    }

    @Test
    public void testToString_improperFractionNotConvertedToMixed() {
        assertEquals("7/4", Fraction.getFraction(7, 4).toString());
    }

    @Test
    public void testToString_negativeFraction() {
        assertEquals("-3/4", Fraction.getFraction(-3, 4).toString());
    }
}
