package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link BitField}, based solely on the documented
 * contract in the javadoc (mask selects bits; values are shifted right on
 * get and shifted left on set; set/clear/setBoolean operate only on masked
 * bits; isSet/isAllSet test "any"/"all" of the masked bits).
 */
class BitFieldAgentTest {

    // ------------------------------------------------------------------
    // The exact example from the class-level javadoc.
    // ------------------------------------------------------------------

    @Test
    void testJavadocPaintInstructionExample() {
        BitField blue = new BitField(0xFF);
        BitField green = new BitField(0xFF00);
        BitField red = new BitField(0xFF0000);
        BitField anyColor = new BitField(0xFFFFFF);
        BitField isMetallic = new BitField(0x1000000);

        int paintInstruction = 0;
        paintInstruction = red.setValue(paintInstruction, 35);
        paintInstruction = green.setValue(paintInstruction, 100);
        paintInstruction = blue.setValue(paintInstruction, 255);

        assertEquals(0x2364FF, paintInstruction);
        assertTrue(anyColor.isSet(paintInstruction));
        assertEquals(35, red.getValue(paintInstruction));
        assertEquals(100, green.getValue(paintInstruction));
        assertEquals(255, blue.getValue(paintInstruction));
        assertFalse(isMetallic.isSet(paintInstruction));
    }

    // ------------------------------------------------------------------
    // int overloads
    // ------------------------------------------------------------------

    @Test
    void testGetRawValueAndGetValueInt() {
        BitField lowByte = new BitField(0xFF);
        BitField secondByte = new BitField(0xFF00);
        int holder = 0x12345678;

        assertEquals(0x78, lowByte.getRawValue(holder));
        assertEquals(0x78, lowByte.getValue(holder));

        assertEquals(0x5600, secondByte.getRawValue(holder));
        assertEquals(0x56, secondByte.getValue(holder));
    }

    @Test
    void testSetAndClearInt() {
        BitField field = new BitField(0xFF0000);
        int holder = 0x12345678;

        assertEquals(0x12FF5678, field.set(holder));
        assertEquals(0x12005678, field.clear(holder));
    }

    @Test
    void testIsSetAndIsAllSetInt() {
        BitField field = new BitField(0xFFFFFF);

        assertFalse(field.isSet(0x00000000));
        assertTrue(field.isSet(0x00000001));

        assertFalse(field.isAllSet(0x00345678));
        assertTrue(field.isAllSet(0x00FFFFFF));
    }

    @Test
    void testSetBooleanInt() {
        BitField field = new BitField(0xFF00);
        int holder = 0x12345678;

        assertEquals(field.set(holder), field.setBoolean(holder, true));
        assertEquals(field.clear(holder), field.setBoolean(holder, false));
    }

    @Test
    void testSetValuePreservesBitsOutsideMaskInt() {
        BitField field = new BitField(0xFF00);
        int holder = 0x12345678;

        int result = field.setValue(holder, 0xAB);

        assertEquals(0x1234AB78, result);
        assertEquals(0xAB, field.getValue(result));
        // Bits outside the mask are untouched.
        assertEquals(holder & ~0xFF00, result & ~0xFF00);
    }

    @Test
    void testSetValueTruncatesToMaskWidthInt() {
        BitField field = new BitField(0xFF);
        int holder = 0x12345600;

        // value has bits above the mask width; they must not leak into other bits.
        int result = field.setValue(holder, 0x1FF);

        assertEquals(0x123456FF, result);
        assertEquals(0xFF, field.getValue(result));
    }

    @Test
    void testSignBitMaskInt() {
        BitField field = new BitField(0x80000000);

        assertEquals(1, field.getValue(Integer.MIN_VALUE));
        assertEquals(0, field.getValue(0));
        assertTrue(field.isSet(Integer.MIN_VALUE));
        assertFalse(field.isSet(0));
        assertTrue(field.isAllSet(Integer.MIN_VALUE));
        assertEquals(Integer.MIN_VALUE, field.set(0));
        assertEquals(Integer.MAX_VALUE, field.clear(-1));
    }

    @Test
    void testZeroMaskInt() {
        BitField field = new BitField(0);

        assertFalse(field.isSet(-1));
        assertTrue(field.isAllSet(-1));
        assertTrue(field.isAllSet(0));
        assertEquals(0, field.getValue(-1));
        assertEquals(0, field.getRawValue(-1));
        assertEquals(12345, field.set(12345));
        assertEquals(12345, field.clear(12345));
    }

    // ------------------------------------------------------------------
    // long overloads
    // ------------------------------------------------------------------

    @Test
    void testGetRawValueAndGetValueLong() {
        BitField field = new BitField(0xFFL);
        long holder = 0x123456789ABCDEF0L;

        assertEquals(0xF0L, field.getRawValue(holder));
        assertEquals(0xF0L, field.getValue(holder));
    }

    @Test
    void testSetAndClearLong() {
        BitField field = new BitField(0xFFL);
        long holder = 0x123456789ABCDEF0L;

        assertEquals(0x123456789ABCDEFFL, field.set(holder));
        assertEquals(0x123456789ABCDE00L, field.clear(holder));
    }

    @Test
    void testIsSetAndIsAllSetLong() {
        BitField field = new BitField(0xFFL);
        long holder = 0x123456789ABCDEF0L;

        assertTrue(field.isSet(holder));
        assertFalse(field.isAllSet(holder));
        assertTrue(field.isAllSet(holder | 0xFFL));
        assertFalse(field.isSet(0L));
    }

    @Test
    void testSetBooleanLong() {
        BitField field = new BitField(0xFFL);
        long holder = 0x123456789ABCDEF0L;

        assertEquals(field.set(holder), field.setBoolean(holder, true));
        assertEquals(field.clear(holder), field.setBoolean(holder, false));
    }

    @Test
    void testSetValuePreservesBitsOutsideMaskLong() {
        BitField field = new BitField(0xFFL);
        long holder = 0x123456789ABCDEF0L;

        long result = field.setValue(holder, 0xABL);

        assertEquals(0x123456789ABCDEABL, result);
        assertEquals(0xABL, field.getValue(result));
        assertEquals(holder & ~0xFFL, result & ~0xFFL);
    }

    @Test
    void testSignBitMaskLong() {
        BitField field = new BitField(Long.MIN_VALUE);

        assertEquals(1L, field.getValue(Long.MIN_VALUE));
        assertEquals(0L, field.getValue(0L));
        assertTrue(field.isSet(Long.MIN_VALUE));
        assertFalse(field.isSet(0L));
        assertTrue(field.isAllSet(Long.MIN_VALUE));
        assertEquals(Long.MIN_VALUE, field.set(0L));
        assertEquals(Long.MAX_VALUE, field.clear(-1L));
    }

    @Test
    void testZeroMaskLong() {
        BitField field = new BitField(0L);

        assertFalse(field.isSet(-1L));
        assertTrue(field.isAllSet(-1L));
        assertTrue(field.isAllSet(0L));
        assertEquals(0L, field.getValue(-1L));
        assertEquals(0L, field.getRawValue(-1L));
    }

    // ------------------------------------------------------------------
    // byte overloads (clearByte / setByte / setByteBoolean only)
    // ------------------------------------------------------------------

    @Test
    void testByteOperations() {
        BitField lowNibble = new BitField(0x0F);

        byte positiveHolder = (byte) 0x3C;
        assertEquals((byte) 0x3F, lowNibble.setByte(positiveHolder));
        assertEquals((byte) 0x30, lowNibble.clearByte(positiveHolder));

        byte negativeHolder = (byte) 0xFC; // -4
        assertEquals((byte) 0xFF, lowNibble.setByte(negativeHolder));
        assertEquals((byte) 0xF0, lowNibble.clearByte(negativeHolder));

        assertEquals(lowNibble.setByte(positiveHolder), lowNibble.setByteBoolean(positiveHolder, true));
        assertEquals(lowNibble.clearByte(positiveHolder), lowNibble.setByteBoolean(positiveHolder, false));
    }

    // ------------------------------------------------------------------
    // short overloads
    // ------------------------------------------------------------------

    @Test
    void testShortSetClearBoolean() {
        BitField highByte = new BitField(0xFF00);
        short holder = (short) 0x1234;

        assertEquals((short) 0xFF34, highByte.setShort(holder));
        assertEquals((short) 0x0034, highByte.clearShort(holder));

        assertEquals(highByte.setShort(holder), highByte.setShortBoolean(holder, true));
        assertEquals(highByte.clearShort(holder), highByte.setShortBoolean(holder, false));
    }

    @Test
    void testGetShortRawValueAndGetShortValue() {
        BitField highByte = new BitField(0xFF00);
        short holder = (short) 0x1234;

        assertEquals((short) 0x1200, highByte.getShortRawValue(holder));
        assertEquals((short) 0x12, highByte.getShortValue(holder));
    }

    @Test
    void testSetShortValuePreservesBitsOutsideMask() {
        BitField highByte = new BitField(0xFF00);
        short holder = (short) 0x1234;

        short result = highByte.setShortValue(holder, (short) 0xAB);

        assertEquals((short) 0xAB34, result);
        assertEquals((short) 0xAB, highByte.getShortValue(result));
    }

    // ------------------------------------------------------------------
    // Constructors
    // ------------------------------------------------------------------

    @Test
    void testIntAndLongConstructorsProduceEquivalentBehaviorForSameMask() {
        BitField intField = new BitField(0xFF00);
        BitField longField = new BitField(0xFF00L);

        int intHolder = 0x12345678;
        long longHolder = 0x12345678L;

        assertEquals(intField.getValue(intHolder), (int) longField.getValue(longHolder));
        assertEquals(intField.set(intHolder), (int) longField.set(longHolder));
        assertEquals(intField.clear(intHolder), (int) longField.clear(longHolder));
    }
}
