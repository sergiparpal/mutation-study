package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Instant;

import org.junit.jupiter.api.Test;

public class InstantsAgentTest {

    // toEpochMillis(Instant)

    @Test
    public void testToEpochMillisNullTreatedAsEpoch() {
        assertEquals(Instant.EPOCH.toEpochMilli(), Instants.toEpochMillis(null));
        assertEquals(0L, Instants.toEpochMillis(null));
    }

    @Test
    public void testToEpochMillisEpoch() {
        assertEquals(0L, Instants.toEpochMillis(Instant.EPOCH));
    }

    @Test
    public void testToEpochMillisOrdinaryValue() {
        Instant instant = Instant.ofEpochSecond(1000000000L, 500000000L);
        assertEquals(1000000000500L, Instants.toEpochMillis(instant));
    }

    @Test
    public void testToEpochMillisNegativeValue() {
        Instant instant = Instant.ofEpochMilli(-123456789L);
        assertEquals(-123456789L, Instants.toEpochMillis(instant));
    }

    @Test
    public void testToEpochMillisClampsToMaxValueForInstantMax() {
        assertEquals(Long.MAX_VALUE, Instants.toEpochMillis(Instant.MAX));
    }

    @Test
    public void testToEpochMillisClampsToMinValueForInstantMin() {
        assertEquals(Long.MIN_VALUE, Instants.toEpochMillis(Instant.MIN));
    }

    // toInstant(Instant)

    @Test
    public void testToInstantSingleArgNullReturnsEpoch() {
        Instant result = Instants.toInstant(null);
        assertNotNull(result);
        assertEquals(Instant.EPOCH, result);
    }

    @Test
    public void testToInstantSingleArgNonNullReturnsSameInstant() {
        Instant instant = Instant.ofEpochSecond(42L);
        Instant result = Instants.toInstant(instant);
        assertSame(instant, result);
    }

    // toInstant(Instant, Instant)

    @Test
    public void testToInstantTwoArgsNullInstantReturnsDefault() {
        Instant defaultInstant = Instant.ofEpochSecond(99L);
        Instant result = Instants.toInstant(null, defaultInstant);
        assertSame(defaultInstant, result);
    }

    @Test
    public void testToInstantTwoArgsNonNullInstantIgnoresDefault() {
        Instant instant = Instant.ofEpochSecond(1L);
        Instant defaultInstant = Instant.ofEpochSecond(2L);
        Instant result = Instants.toInstant(instant, defaultInstant);
        assertSame(instant, result);
    }

    @Test
    public void testToInstantTwoArgsBothNullReturnsNull() {
        assertNull(Instants.toInstant(null, null));
    }

    @Test
    public void testToInstantTwoArgsNonNullInstantWithNullDefault() {
        Instant instant = Instant.ofEpochSecond(5L);
        assertSame(instant, Instants.toInstant(instant, null));
    }

    // toMillisSince(Instant)

    @Test
    public void testToMillisSinceNullTreatedAsEpoch() {
        long before = System.currentTimeMillis();
        long result = Instants.toMillisSince(null);
        long after = System.currentTimeMillis();
        assertTrue(result >= before && result <= after + 1000L,
                "Expected result close to current epoch millis, got " + result);
    }

    @Test
    public void testToMillisSinceRecentInstantIsCloseToZero() {
        long result = Instants.toMillisSince(Instant.now());
        assertTrue(result >= 0L && result < 5000L,
                "Expected a small non-negative duration, got " + result);
    }

    @Test
    public void testToMillisSinceClampsToMaxValueForInstantMin() {
        assertEquals(Long.MAX_VALUE, Instants.toMillisSince(Instant.MIN));
    }

    @Test
    public void testToMillisSinceClampsToMinValueForInstantMax() {
        assertEquals(Long.MIN_VALUE, Instants.toMillisSince(Instant.MAX));
    }
}
