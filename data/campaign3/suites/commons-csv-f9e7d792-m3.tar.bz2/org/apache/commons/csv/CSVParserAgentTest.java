/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;
import java.io.UncheckedIOException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link CSVParser}.
 */
class CSVParserAgentTest {

    @Test
    void testParseSimpleRecords() throws IOException {
        try (CSVParser parser = CSVParser.parse("a,b,c\nd,e,f\n", CSVFormat.DEFAULT)) {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("c", records.get(0).get(2));
            assertEquals("f", records.get(1).get(2));
        }
    }

    @Test
    void testGetRecordNumberIncrements() throws IOException {
        try (CSVParser parser = CSVParser.parse("a\nb\nc\n", CSVFormat.DEFAULT)) {
            assertEquals(0, parser.getRecordNumber());
            final Iterator<CSVRecord> it = parser.iterator();
            it.next();
            assertEquals(1, parser.getRecordNumber());
            it.next();
            assertEquals(2, parser.getRecordNumber());
        }
    }

    @Test
    void testEmptyInputProducesNoRecords() throws IOException {
        try (CSVParser parser = CSVParser.parse("", CSVFormat.DEFAULT)) {
            final List<CSVRecord> records = parser.getRecords();
            assertTrue(records.isEmpty());
        }
    }

    @Test
    void testCloseAndIsClosed() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n", CSVFormat.DEFAULT);
        assertFalse(parser.isClosed());
        parser.close();
        assertTrue(parser.isClosed());
    }

    @Test
    void testIteratorAfterCloseHasNoNext() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n", CSVFormat.DEFAULT);
        parser.close();
        final Iterator<CSVRecord> it = parser.iterator();
        assertFalse(it.hasNext());
        assertThrows(NoSuchElementException.class, it::next);
    }

    @Test
    void testIteratorNextThrowsWhenExhausted() throws IOException {
        try (CSVParser parser = CSVParser.parse("a\n", CSVFormat.DEFAULT)) {
            final Iterator<CSVRecord> it = parser.iterator();
            assertTrue(it.hasNext());
            it.next();
            assertFalse(it.hasNext());
            assertThrows(NoSuchElementException.class, it::next);
        }
    }

    @Test
    void testIteratorRemoveUnsupported() throws IOException {
        try (CSVParser parser = CSVParser.parse("a\n", CSVFormat.DEFAULT)) {
            final Iterator<CSVRecord> it = parser.iterator();
            assertThrows(UnsupportedOperationException.class, it::remove);
        }
    }

    @Test
    void testHeaderMapFromFirstLine() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().setSkipHeaderRecord(true).get();
        try (CSVParser parser = CSVParser.parse("name,age\nJohn,30\n", format)) {
            final Map<String, Integer> headerMap = parser.getHeaderMap();
            assertEquals(Integer.valueOf(0), headerMap.get("name"));
            assertEquals(Integer.valueOf(1), headerMap.get("age"));
            assertEquals(2, parser.getHeaderNames().size());
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("John", records.get(0).get("name"));
            assertEquals("30", records.get(0).get("age"));
        }
    }

    @Test
    void testExplicitHeaderWithoutSkip() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("x", "y").get();
        try (CSVParser parser = CSVParser.parse("1,2\n3,4\n", format)) {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("1", records.get(0).get("x"));
            assertEquals("2", records.get(0).get("y"));
        }
    }

    @Test
    void testNoHeaderMapWhenFormatHasNoHeader() throws IOException {
        try (CSVParser parser = CSVParser.parse("a,b\n", CSVFormat.DEFAULT)) {
            assertNull(parser.getHeaderMap());
            assertTrue(parser.getHeaderNames().isEmpty());
        }
    }

    @Test
    void testDuplicateHeaderNameThrows() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).get();
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> CSVParser.parse("a,a\n1,2\n", format));
        assertTrue(ex.getMessage().contains("duplicate"));
    }

    @Test
    void testMissingColumnNameThrowsByDefault() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "").get();
        assertThrows(IllegalArgumentException.class, () -> CSVParser.parse("1,2\n", format));
    }

    @Test
    void testMissingColumnNameAllowed() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "").setAllowMissingColumnNames(true).get();
        try (CSVParser parser = CSVParser.parse("1,2\n", format)) {
            assertEquals(2, parser.getHeaderNames().size());
            assertEquals("a", parser.getHeaderNames().get(0));
            assertEquals("", parser.getHeaderNames().get(1));
        }
    }

    @Test
    void testGetHeaderCommentAndHasHeaderComment() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().setSkipHeaderRecord(true).setCommentMarker('#').get();
        try (CSVParser parser = CSVParser.parse("# header comment\nname,age\nJohn,30\n", format)) {
            assertTrue(parser.hasHeaderComment());
            assertEquals("header comment", parser.getHeaderComment());
        }
    }

    @Test
    void testNoHeaderCommentByDefault() throws IOException {
        try (CSVParser parser = CSVParser.parse("a,b\n", CSVFormat.DEFAULT)) {
            assertFalse(parser.hasHeaderComment());
            assertNull(parser.getHeaderComment());
        }
    }

    @Test
    void testTrailerCommentAfterFullRead() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        try (CSVParser parser = CSVParser.parse("a,b\n# trailer\n", format)) {
            parser.getRecords();
            assertTrue(parser.hasTrailerComment());
            assertEquals("trailer", parser.getTrailerComment());
        }
    }

    @Test
    void testNoTrailerCommentByDefault() throws IOException {
        try (CSVParser parser = CSVParser.parse("a,b\n", CSVFormat.DEFAULT)) {
            parser.getRecords();
            assertFalse(parser.hasTrailerComment());
            assertNull(parser.getTrailerComment());
        }
    }

    @Test
    void testInvalidInputThrowsCSVException() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuote('"').setTrailingData(false).get();
        try (CSVParser parser = CSVParser.parse("\"a\"b,c\n", format)) {
            final UncheckedIOException ex = assertThrows(UncheckedIOException.class, parser::getRecords);
            assertTrue(ex.getCause() instanceof CSVException);
        }
    }

    @Test
    void testGetCurrentLineNumber() throws IOException {
        try (CSVParser parser = CSVParser.parse("a,b\nc,d\n", CSVFormat.DEFAULT)) {
            assertEquals(0, parser.getCurrentLineNumber());
            final Iterator<CSVRecord> it = parser.iterator();
            it.next();
            assertEquals(1, parser.getCurrentLineNumber());
            it.next();
            assertEquals(2, parser.getCurrentLineNumber());
        }
    }

    @Test
    void testGetFirstEndOfLine() throws IOException {
        try (CSVParser parser = CSVParser.parse("a,b\r\nc,d\n", CSVFormat.DEFAULT)) {
            parser.getRecords();
            assertEquals(Constants.CRLF, parser.getFirstEndOfLine());
        }
    }

    @Test
    void testStreamProducesSameRecordsAsIterator() throws IOException {
        try (CSVParser parser = CSVParser.parse("1,2\n3,4\n", CSVFormat.DEFAULT)) {
            final long count = parser.stream().count();
            assertEquals(2, count);
        }
    }

    @Test
    void testMaxRowsLimitsRecordCount() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(1).get();
        try (CSVParser parser = CSVParser.parse("a\nb\nc\n", format)) {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("a", records.get(0).get(0));
        }
    }

    @Test
    void testTrailingDelimiterDroppedWhenConfigured() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get();
        try (CSVParser parser = CSVParser.parse("a,b,\n", format)) {
            final CSVRecord record = parser.getRecords().get(0);
            assertEquals(2, record.size());
            assertEquals("a", record.get(0));
            assertEquals("b", record.get(1));
        }
    }

    @Test
    void testQuotedEmptyFieldKeptWithTrailingDelimiter() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get();
        try (CSVParser parser = CSVParser.parse("a,b,\"\"\n", format)) {
            final CSVRecord record = parser.getRecords().get(0);
            assertEquals(3, record.size());
            assertEquals("", record.get(2));
        }
    }

    @Test
    void testNullStringHandling() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        try (CSVParser parser = CSVParser.parse("a,NULL,b\n", format)) {
            final CSVRecord record = parser.getRecords().get(0);
            assertEquals("a", record.get(0));
            assertNull(record.get(1));
            assertEquals("b", record.get(2));
        }
    }

    @Test
    void testBuilderWithCharacterAndRecordNumberOffsets() throws IOException {
        try (CSVParser parser = CSVParser.builder().setReader(new StringReader("a,b\n")).setFormat(CSVFormat.DEFAULT)
                .setCharacterOffset(100).setRecordNumber(5).get()) {
            final CSVRecord record = parser.getRecords().get(0);
            assertEquals(5, record.getRecordNumber());
            assertEquals(100, record.getCharacterPosition());
            assertEquals(5, parser.getRecordNumber());
        }
    }

    @Test
    void testParseNullFormatDefaultsToDefaultFormat() throws IOException {
        try (CSVParser parser = CSVParser.parse("a,b\n", null)) {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("a", records.get(0).get(0));
        }
    }

    @Test
    void testParseNullStringThrowsNpe() {
        assertThrows(NullPointerException.class, () -> CSVParser.parse((String) null, CSVFormat.DEFAULT));
    }

    @Test
    void testDeprecatedConstructor() throws IOException {
        try (CSVParser parser = new CSVParser(new StringReader("a,b\n"), CSVFormat.DEFAULT)) {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("b", records.get(0).get(1));
        }
    }

    @Test
    void testNextRecordPackagePrivateMethod() throws IOException {
        try (CSVParser parser = CSVParser.parse("a,b\n", CSVFormat.DEFAULT)) {
            final CSVRecord record = parser.nextRecord();
            assertEquals("a", record.get(0));
            assertEquals("b", record.get(1));
            assertNull(parser.nextRecord());
        }
    }
}
