/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link Lexer}.
 */
class LexerAgentTest {

    @SuppressWarnings("resource")
    private static Lexer createLexer(final String input, final CSVFormat format) {
        return new Lexer(format, new ExtendedBufferedReader(new StringReader(input)));
    }

    @Test
    void testSimpleTokensAndEndOfRecord() throws IOException {
        try (Lexer lexer = createLexer("a,b,c", CSVFormat.DEFAULT)) {
            Token token = lexer.nextToken(new Token());
            assertEquals(Token.Type.TOKEN, token.type);
            assertEquals("a", token.content.toString());

            token = lexer.nextToken(new Token());
            assertEquals(Token.Type.TOKEN, token.type);
            assertEquals("b", token.content.toString());

            token = lexer.nextToken(new Token());
            assertEquals(Token.Type.EOF, token.type);
            assertEquals("c", token.content.toString());
            assertTrue(token.isReady);
        }
    }

    @Test
    void testEmptyInputYieldsEofImmediately() throws IOException {
        try (Lexer lexer = createLexer("", CSVFormat.DEFAULT)) {
            final Token token = lexer.nextToken(new Token());
            assertEquals(Token.Type.EOF, token.type);
            assertFalse(token.isReady);
            assertEquals("", token.content.toString());
        }
    }

    @Test
    void testEndOfRecordOnNewline() throws IOException {
        try (Lexer lexer = createLexer("a,b\nc", CSVFormat.DEFAULT)) {
            lexer.nextToken(new Token());
            final Token token = lexer.nextToken(new Token());
            assertEquals(Token.Type.EORECORD, token.type);
            assertEquals("b", token.content.toString());
        }
    }

    @Test
    void testQuotedToken() throws IOException {
        try (Lexer lexer = createLexer("\"quoted value\",next", CSVFormat.DEFAULT)) {
            final Token token = lexer.nextToken(new Token());
            assertEquals(Token.Type.TOKEN, token.type);
            assertEquals("quoted value", token.content.toString());
            assertTrue(token.isQuoted);
        }
    }

    @Test
    void testUnclosedQuoteThrowsCSVException() throws IOException {
        try (Lexer lexer = createLexer("\"unterminated", CSVFormat.DEFAULT)) {
            final IOException ex = assertThrows(IOException.class, () -> lexer.nextToken(new Token()));
            assertTrue(ex instanceof CSVException);
        }
    }

    @Test
    void testInvalidCharacterAfterQuoteThrowsCSVException() throws IOException {
        try (Lexer lexer = createLexer("\"a\"b,c", CSVFormat.DEFAULT)) {
            assertThrows(CSVException.class, () -> lexer.nextToken(new Token()));
        }
    }

    @Test
    void testCommentToken() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withCommentMarker('#');
        try (Lexer lexer = createLexer("# a comment\nvalue", format)) {
            final Token token = lexer.nextToken(new Token());
            assertEquals(Token.Type.COMMENT, token.type);
            assertEquals("a comment", token.content.toString());
        }
    }

    @Test
    void testIsDelimiterSingleCharacter() throws IOException {
        try (Lexer lexer = createLexer("", CSVFormat.DEFAULT)) {
            assertTrue(lexer.isDelimiter(','));
            assertFalse(lexer.isDelimiter('a'));
        }
    }

    @Test
    void testIsQuoteCharEscapeCommentStart() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withQuote('"').withEscape('\\').withCommentMarker('#');
        try (Lexer lexer = createLexer("", format)) {
            assertTrue(lexer.isQuoteChar('"'));
            assertFalse(lexer.isQuoteChar('\''));
            assertTrue(lexer.isEscape('\\'));
            assertFalse(lexer.isEscape('/'));
            assertTrue(lexer.isCommentStart('#'));
            assertFalse(lexer.isCommentStart('!'));
        }
    }

    @Test
    void testIsEndOfFile() throws IOException {
        try (Lexer lexer = createLexer("", CSVFormat.DEFAULT)) {
            assertTrue(lexer.isEndOfFile(-1));
            assertFalse(lexer.isEndOfFile('a'));
        }
    }

    @Test
    void testIsStartOfLine() throws IOException {
        try (Lexer lexer = createLexer("", CSVFormat.DEFAULT)) {
            assertTrue(lexer.isStartOfLine('\n'));
            assertTrue(lexer.isStartOfLine('\r'));
            assertTrue(lexer.isStartOfLine(Constants.UNDEFINED));
            assertFalse(lexer.isStartOfLine('a'));
        }
    }

    @Test
    void testReadEndOfLineLfAndCr() throws IOException {
        try (Lexer lexer = createLexer("", CSVFormat.DEFAULT)) {
            assertTrue(lexer.readEndOfLine(Constants.LF));
            assertTrue(lexer.readEndOfLine(Constants.CR));
            assertFalse(lexer.readEndOfLine('a'));
        }
    }

    @Test
    void testFirstEolDetectsCrlf() throws IOException {
        try (Lexer lexer = createLexer("a,b\r\nc", CSVFormat.DEFAULT)) {
            assertEquals(null, lexer.getFirstEol());
            lexer.nextToken(new Token());
            lexer.nextToken(new Token());
            assertEquals(Constants.CRLF, lexer.getFirstEol());
        }
    }

    @Test
    void testReadEscapeKnownSequences() throws IOException {
        try (Lexer lexer = createLexer("rntbf", CSVFormat.DEFAULT.withEscape('\\'))) {
            assertEquals(Constants.CR, lexer.readEscape());
            assertEquals(Constants.LF, lexer.readEscape());
            assertEquals(Constants.TAB, lexer.readEscape());
            assertEquals(Constants.BACKSPACE, lexer.readEscape());
            assertEquals(Constants.FF, lexer.readEscape());
        }
    }

    @Test
    void testReadEscapeUnknownCharacterReturnsEof() throws IOException {
        try (Lexer lexer = createLexer("z", CSVFormat.DEFAULT.withEscape('\\'))) {
            assertEquals(-1, lexer.readEscape());
        }
    }

    @Test
    void testReadEscapeAtEndOfFileThrows() throws IOException {
        try (Lexer lexer = createLexer("", CSVFormat.DEFAULT.withEscape('\\'))) {
            assertThrows(CSVException.class, lexer::readEscape);
        }
    }

    @Test
    void testTrimTrailingSpaces() throws IOException {
        try (Lexer lexer = createLexer("", CSVFormat.DEFAULT)) {
            final StringBuilder sb = new StringBuilder("value   ");
            lexer.trimTrailingSpaces(sb);
            assertEquals("value", sb.toString());

            final StringBuilder noTrailing = new StringBuilder("value");
            lexer.trimTrailingSpaces(noTrailing);
            assertEquals("value", noTrailing.toString());

            final StringBuilder allSpaces = new StringBuilder("   ");
            lexer.trimTrailingSpaces(allSpaces);
            assertEquals("", allSpaces.toString());
        }
    }

    @Test
    void testPositionAndLineNumberTracking() throws IOException {
        try (Lexer lexer = createLexer("ab\ncd", CSVFormat.DEFAULT)) {
            assertEquals(0, lexer.getCharacterPosition());
            lexer.nextToken(new Token()); // "ab" -> EORECORD after newline
            assertTrue(lexer.getCharacterPosition() > 0);
            assertEquals(1, lexer.getCurrentLineNumber());
        }
    }

    @Test
    void testGetBytesReadWithoutTrackingIsZero() throws IOException {
        try (Lexer lexer = createLexer("abc", CSVFormat.DEFAULT)) {
            lexer.nextToken(new Token());
            assertEquals(0, lexer.getBytesRead());
        }
    }

    @Test
    void testCloseAndIsClosed() throws IOException {
        final Lexer lexer = createLexer("abc", CSVFormat.DEFAULT);
        assertFalse(lexer.isClosed());
        lexer.close();
        assertTrue(lexer.isClosed());
    }

    @Test
    void testMultipleEofCallsKeepReturningEof() throws IOException {
        try (Lexer lexer = createLexer("a", CSVFormat.DEFAULT)) {
            final Token first = lexer.nextToken(new Token());
            assertEquals(Token.Type.EOF, first.type);
            final Token second = lexer.nextToken(new Token());
            assertEquals(Token.Type.EOF, second.type);
            assertFalse(second.isReady);
        }
    }

    @Test
    void testEscapedDelimiterIsConsumedAsLiteral() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withEscape('\\');
        try (Lexer lexer = createLexer("a\\,b,c", format)) {
            final Token token = lexer.nextToken(new Token());
            assertEquals(Token.Type.TOKEN, token.type);
            assertEquals("a,b", token.content.toString());
        }
    }
}
