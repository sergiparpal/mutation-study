/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link Token}.
 */
class TokenAgentTest {

    @Test
    void testInitialState() {
        final Token token = new Token();
        assertEquals(Token.Type.INVALID, token.type);
        assertEquals(0, token.content.length());
        assertEquals("", token.content.toString());
        assertFalse(token.isReady);
        assertFalse(token.isQuoted);
        assertFalse(token.isEscaped);
    }

    @Test
    void testResetClearsAllState() {
        final Token token = new Token();
        token.content.append("abc");
        token.type = Token.Type.TOKEN;
        token.isReady = true;
        token.isQuoted = true;
        token.isEscaped = true;

        token.reset();

        assertEquals(Token.Type.INVALID, token.type);
        assertEquals(0, token.content.length());
        assertFalse(token.isReady);
        assertFalse(token.isQuoted);
        assertFalse(token.isEscaped);
    }

    @Test
    void testResetIsIdempotent() {
        final Token token = new Token();
        token.reset();
        token.reset();
        assertEquals(Token.Type.INVALID, token.type);
        assertEquals(0, token.content.length());
    }

    @Test
    void testToStringContainsTypeAndContent() {
        final Token token = new Token();
        token.type = Token.Type.TOKEN;
        token.content.append("hello");
        final String str = token.toString();
        assertTrue(str.contains("TOKEN"));
        assertTrue(str.contains("hello"));
        assertEquals("TOKEN [hello]", str);
    }

    @Test
    void testToStringWithEmptyContent() {
        final Token token = new Token();
        assertEquals("INVALID []", token.toString());
    }

    @Test
    void testToStringForEveryType() {
        for (final Token.Type type : Token.Type.values()) {
            final Token token = new Token();
            token.type = type;
            final String str = token.toString();
            assertTrue(str.contains(type.name()), "toString() should contain the type name " + type);
        }
    }

    @Test
    void testTypeEnumValues() {
        final Token.Type[] values = Token.Type.values();
        assertEquals(5, values.length);
        assertEquals(Token.Type.INVALID, Token.Type.valueOf("INVALID"));
        assertEquals(Token.Type.TOKEN, Token.Type.valueOf("TOKEN"));
        assertEquals(Token.Type.EOF, Token.Type.valueOf("EOF"));
        assertEquals(Token.Type.EORECORD, Token.Type.valueOf("EORECORD"));
        assertEquals(Token.Type.COMMENT, Token.Type.valueOf("COMMENT"));
    }

    @Test
    void testContentBufferIsMutableAndIndependentPerInstance() {
        final Token token1 = new Token();
        final Token token2 = new Token();
        token1.content.append("first");
        assertEquals("first", token1.content.toString());
        assertEquals("", token2.content.toString());
    }
}
