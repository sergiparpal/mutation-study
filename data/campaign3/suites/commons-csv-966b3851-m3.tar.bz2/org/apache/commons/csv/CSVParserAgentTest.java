/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.Test;

class CSVParserAgentTest {

    @Test
    void testParseSimpleRecords() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b,c\n1,2,3\n", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("b", records.get(0).get(1));
            assertEquals("c", records.get(0).get(2));
            assertEquals("1", records.get(1).get(0));
            assertEquals("2", records.get(1).get(1));
            assertEquals("3", records.get(1).get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    void testEmptyInputProducesNoRecords() throws IOException {
        final CSVParser parser = CSVParser.parse("", CSVFormat.DEFAULT);
        try {
            assertTrue(parser.getRecords().isEmpty());
        } finally {
            parser.close();
        }
    }

    @Test
    void testHeaderMapAndNames() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().setSkipHeaderRecord(true).get();
        final CSVParser parser = CSVParser.parse("name,age\nJohn,30\n", format);
        try {
            final Map<String, Integer> headerMap = parser.getHeaderMap();
            assertEquals(Integer.valueOf(0), headerMap.get("name"));
            assertEquals(Integer.valueOf(1), headerMap.get("age"));
            assertEquals(2, parser.getHeaderNames().size());
            assertEquals("name", parser.getHeaderNames().get(0));
            assertEquals("age", parser.getHeaderNames().get(1));

            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("John", records.get(0).get("name"));
            assertEquals("30", records.get(0).get("age"));
        } finally {
            parser.close();
        }
    }

    @Test
    void testHeaderMapIsNullWithoutHeaderFormat() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n", CSVFormat.DEFAULT);
        try {
            assertNull(parser.getHeaderMap());
            assertTrue(parser.getHeaderNames().isEmpty());
        } finally {
            parser.close();
        }
    }

    @Test
    void testGetHeaderMapReturnsIndependentCopy() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().setSkipHeaderRecord(true).get();
        final CSVParser parser = CSVParser.parse("a,b\n1,2\n", format);
        try {
            final Map<String, Integer> firstCopy = parser.getHeaderMap();
            firstCopy.put("c", Integer.valueOf(99));
            final Map<String, Integer> secondCopy = parser.getHeaderMap();
            assertFalse(secondCopy.containsKey("c"));
        } finally {
            parser.close();
        }
    }

    @Test
    void testDuplicateHeaderNameThrows() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().setSkipHeaderRecord(true)
                .setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).get();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse("a,a\n1,2\n", format);
            }
        });
    }

    @Test
    void testMissingHeaderNameThrowsByDefault() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().setSkipHeaderRecord(true).get();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse("a,\n1,2\n", format);
            }
        });
    }

    @Test
    void testMissingHeaderNameAllowed() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().setSkipHeaderRecord(true)
                .setAllowMissingColumnNames(true).get();
        final CSVParser parser = CSVParser.parse("a,\n1,2\n", format);
        try {
            assertEquals(2, parser.getHeaderNames().size());
            assertEquals("a", parser.getHeaderNames().get(0));
            assertEquals("", parser.getHeaderNames().get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    void testIteratorAndRecordCount() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n2\n3\n", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            int count = 0;
            long lastRecordNumber = 0;
            while (it.hasNext()) {
                final CSVRecord record = it.next();
                count++;
                lastRecordNumber = record.getRecordNumber();
            }
            assertEquals(3, count);
            assertEquals(3, lastRecordNumber);
            assertEquals(3, parser.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    void testIteratorNextThrowsAtEnd() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            assertTrue(it.hasNext());
            it.next();
            assertFalse(it.hasNext());
            assertThrows(NoSuchElementException.class, new org.junit.jupiter.api.function.Executable() {
                @Override
                public void execute() throws Throwable {
                    it.next();
                }
            });
        } finally {
            parser.close();
        }
    }

    @Test
    void testIteratorRemoveUnsupported() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
                @Override
                public void execute() throws Throwable {
                    it.remove();
                }
            });
        } finally {
            parser.close();
        }
    }

    @Test
    void testCloseMakesParserClosedAndIteratorExhausted() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n2\n", CSVFormat.DEFAULT);
        assertFalse(parser.isClosed());
        parser.close();
        assertTrue(parser.isClosed());
        final Iterator<CSVRecord> it = parser.iterator();
        assertFalse(it.hasNext());
        assertThrows(NoSuchElementException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                it.next();
            }
        });
    }

    @Test
    void testStreamCollectsAllRecords() throws IOException {
        final CSVParser parser = CSVParser.parse("a\nb\nc\n", CSVFormat.DEFAULT);
        try {
            final long count = parser.stream().count();
            assertEquals(3, count);
        } finally {
            parser.close();
        }
    }

    @Test
    void testHeaderAndTrailerComments() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').setHeader().setSkipHeaderRecord(true).get();
        final CSVParser parser = CSVParser.parse("# header comment\na,b\n1,2\n# trailer comment\n", format);
        try {
            parser.getRecords();
            assertTrue(parser.hasHeaderComment());
            assertEquals("header comment", parser.getHeaderComment());
            assertTrue(parser.hasTrailerComment());
            assertEquals("trailer comment", parser.getTrailerComment());
        } finally {
            parser.close();
        }
    }

    @Test
    void testNoCommentsByDefault() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n1,2\n", CSVFormat.DEFAULT);
        try {
            parser.getRecords();
            assertFalse(parser.hasHeaderComment());
            assertNull(parser.getHeaderComment());
            assertFalse(parser.hasTrailerComment());
            assertNull(parser.getTrailerComment());
        } finally {
            parser.close();
        }
    }

    @Test
    void testInvalidParseSequenceThrowsCSVException() throws IOException {
        // An unescaped quote inside a quoted value is invalid for the strict RFC4180 format.
        final CSVParser parser = CSVParser.parse("\"a\"\"b\" \"c\"", CSVFormat.RFC4180);
        try {
            assertThrows(CSVException.class, new org.junit.jupiter.api.function.Executable() {
                @Override
                public void execute() throws Throwable {
                    parser.nextRecord();
                }
            });
        } finally {
            parser.close();
        }
    }

    @Test
    void testParseFromFile() throws IOException {
        final Path tempFile = Files.createTempFile("csv-parser-agent-test", ".csv");
        try {
            Files.write(tempFile, "x,y\n5,6\n".getBytes(StandardCharsets.UTF_8));
            final CSVParser parser = CSVParser.parse(tempFile.toFile(), StandardCharsets.UTF_8, CSVFormat.DEFAULT);
            try {
                final List<CSVRecord> records = parser.getRecords();
                assertEquals(2, records.size());
                assertEquals("5", records.get(1).get(0));
                assertEquals("6", records.get(1).get(1));
            } finally {
                parser.close();
            }
        } finally {
            Files.deleteIfExists(tempFile);
        }
    }

    @Test
    void testParseFromUrl() throws IOException {
        final File tempFile = Files.createTempFile("csv-parser-agent-test-url", ".csv").toFile();
        tempFile.deleteOnExit();
        try {
            Files.write(tempFile.toPath(), "p,q\n7,8\n".getBytes(StandardCharsets.UTF_8));
            final URL url = tempFile.toURI().toURL();
            final CSVParser parser = CSVParser.parse(url, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
            try {
                final List<CSVRecord> records = parser.getRecords();
                assertEquals(2, records.size());
                assertEquals("7", records.get(1).get(0));
                assertEquals("8", records.get(1).get(1));
            } finally {
                parser.close();
            }
        } finally {
            tempFile.delete();
        }
    }

    @Test
    void testParseNullFileThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse((File) null, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    void testParseNullPathThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse((Path) null, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    void testParseNullStringThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse((String) null, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    void testParseNullUrlThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse((URL) null, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    void testDeprecatedConstructorWithNullFormatThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new CSVParser(new StringReader("a,b\n"), null);
            }
        });
    }

    @Test
    void testDeprecatedConstructorWithOffsetAndRecordNumber() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("1,2\n3,4\n"), CSVFormat.DEFAULT, 10L, 5L);
        try {
            final CSVRecord record = parser.nextRecord();
            assertNotNull(record);
            assertEquals(5, record.getRecordNumber());
            assertEquals(10, record.getCharacterPosition());
        } finally {
            parser.close();
        }
    }

    @Test
    void testBuilderWithRecordNumberOffset() throws IOException {
        final CSVParser parser = CSVParser.builder()
                .setReader(new StringReader("a\nb\n"))
                .setFormat(CSVFormat.DEFAULT)
                .setRecordNumber(100L)
                .get();
        try {
            final CSVRecord first = parser.nextRecord();
            assertEquals(100, first.getRecordNumber());
            final CSVRecord second = parser.nextRecord();
            assertEquals(101, second.getRecordNumber());
            assertNull(parser.nextRecord());
        } finally {
            parser.close();
        }
    }

    @Test
    void testBuilderWithNullFormatUsesDefault() throws IOException {
        final CSVParser parser = CSVParser.builder().setReader(new StringReader("a,b\n")).setFormat(null).get();
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("b", records.get(0).get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    void testGetCurrentLineNumber() throws IOException {
        final CSVParser parser = CSVParser.parse("a\nb\nc\n", CSVFormat.DEFAULT);
        try {
            assertEquals(0, parser.getCurrentLineNumber());
            parser.nextRecord();
            assertEquals(1, parser.getCurrentLineNumber());
            parser.nextRecord();
            assertEquals(2, parser.getCurrentLineNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    void testGetFirstEndOfLine() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\r\nc,d\n", CSVFormat.DEFAULT);
        try {
            parser.getRecords();
            assertEquals("\r\n", parser.getFirstEndOfLine());
        } finally {
            parser.close();
        }
    }

    @Test
    void testTrailingDelimiterIgnoredInLastField() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get();
        final CSVParser parser = CSVParser.parse("a,b,\n", format);
        try {
            final CSVRecord record = parser.nextRecord();
            assertEquals(2, record.size());
            assertEquals("a", record.get(0));
            assertEquals("b", record.get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    void testNullStringMapsToNullValue() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        final CSVParser parser = CSVParser.parse("a,NULL,c\n", format);
        try {
            final CSVRecord record = parser.nextRecord();
            assertEquals("a", record.get(0));
            assertNull(record.get(1));
            assertEquals("c", record.get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    void testMaxRowsLimitsIterator() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(2).get();
        final CSVParser parser = CSVParser.parse("1\n2\n3\n4\n", format);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
        } finally {
            parser.close();
        }
    }
}
