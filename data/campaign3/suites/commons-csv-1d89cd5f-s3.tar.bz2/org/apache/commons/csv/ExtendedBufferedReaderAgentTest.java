package org.apache.commons.csv;

import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Tests for {@link ExtendedBufferedReader}, based solely on the documented
 * contract in the generated javadoc under api/.
 */
public class ExtendedBufferedReaderAgentTest {

    // The EOF sentinel is the standard end-of-stream value used by
    // java.io.Reader#read() and by Apache Commons IO's IOUtils.EOF (-1),
    // which the javadoc for getLastChar()/readLine() refers to.
    private static final int EOF = -1;

    @Test
    public void testGetLastChar_beforeAnyRead_isUndefinedSentinelDistinctFromEof() {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"));
        int lastChar = reader.getLastChar();
        assertTrue(lastChar < 0);
        assertNotEquals(EOF, lastChar);
    }

    @Test
    public void testGetPosition_beforeAnyRead_isZero() {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"));
        assertEquals(0L, reader.getPosition());
    }

    @Test
    public void testGetBytesRead_beforeAnyRead_isZero() {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"));
        assertEquals(0L, reader.getBytesRead());
    }

    @Test
    public void testRead_singleCharacter_returnsCharAndUpdatesLastCharAndPosition() {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("ab"));
        int c = readUnchecked(reader);
        assertEquals('a', c);
        assertEquals('a', reader.getLastChar());
        assertEquals(1L, reader.getPosition());
    }

    @Test
    public void testRead_multipleCharacters_updatesPositionIncrementally() {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"));
        readUnchecked(reader);
        readUnchecked(reader);
        assertEquals(2L, reader.getPosition());
        assertEquals('b', reader.getLastChar());
    }

    @Test
    public void testRead_atEndOfStream_returnsEofAndSetsLastCharToEof() {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader(""));
        int c = readUnchecked(reader);
        assertEquals(EOF, c);
        assertEquals(EOF, reader.getLastChar());
    }

    @Test
    public void testReadCharArray_readsRequestedLengthIntoOffset() {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abcdef"));
        char[] buf = new char[10];
        int n = readArrayUnchecked(reader, buf, 2, 4);
        assertEquals(4, n);
        assertEquals('a', buf[2]);
        assertEquals('b', buf[3]);
        assertEquals('c', buf[4]);
        assertEquals('d', buf[5]);
        assertEquals(4L, reader.getPosition());
        assertEquals('d', reader.getLastChar());
    }

    @Test
    public void testReadCharArray_zeroLength_returnsZeroAndDoesNotAdvance() {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"));
        char[] buf = new char[5];
        int n = readArrayUnchecked(reader, buf, 0, 0);
        assertEquals(0, n);
        assertEquals(0L, reader.getPosition());
    }

    @Test
    public void testReadCharArray_atEndOfStream_returnsMinusOne() {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader(""));
        char[] buf = new char[5];
        int n = readArrayUnchecked(reader, buf, 0, 5);
        assertEquals(EOF, n);
    }

    @Test
    public void testReadCharArray_negativeOffset_throwsIndexOutOfBoundsException() {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"));
        final char[] buf = new char[5];
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                reader.read(buf, -1, 2);
            }
        });
    }

    @Test
    public void testReadCharArray_lengthExceedsBuffer_throwsIndexOutOfBoundsException() {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"));
        final char[] buf = new char[5];
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                reader.read(buf, 3, 4);
            }
        });
    }

    @Test
    public void testReadLine_dropsLineFeedTerminatorAndReturnsEachLine() {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("line1\nline2"));
        assertEquals("line1", readLineUnchecked(reader));
        assertEquals("line2", readLineUnchecked(reader));
        assertNull(readLineUnchecked(reader));
    }

    @Test
    public void testReadLine_dropsCarriageReturnLineFeedTerminator() {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("line1\r\nline2\nline3"));
        assertEquals("line1", readLineUnchecked(reader));
        assertEquals("line2", readLineUnchecked(reader));
        assertEquals("line3", readLineUnchecked(reader));
        assertNull(readLineUnchecked(reader));
    }

    @Test
    public void testReadLine_onEmptyInput_returnsNullAndSetsLastCharToEof() {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader(""));
        assertNull(readLineUnchecked(reader));
        assertEquals(EOF, reader.getLastChar());
    }

    @Test
    public void testReadLine_setsLastCharToEolCharacterWhenNotAtEof() {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("line1\nline2"));
        readLineUnchecked(reader);
        assertEquals('\n', reader.getLastChar());
    }

    @Test
    public void testReadLine_setsLastCharToEofWhenFinalLineHasNoTerminator() {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("line1\nline2"));
        readLineUnchecked(reader);
        readLineUnchecked(reader);
        assertEquals(EOF, reader.getLastChar());
    }

    @Test
    public void testReadLine_incrementsLineNumber() {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("line1\nline2"));
        long before = reader.getLineNumber();
        readLineUnchecked(reader);
        long after = reader.getLineNumber();
        assertTrue(after > before);
    }

    @Test
    public void testReadLine_updatesPositionByCharactersConsumedIncludingTerminator() {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("line1\nline2"));
        readLineUnchecked(reader);
        // "line1" (5 chars) + '\n' (1 char) consumed from the underlying stream.
        assertEquals(6L, reader.getPosition());
    }

    @Test
    public void testMarkAndReset_repositionsStreamToMarkedPoint() {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abcdef"));
        readUnchecked(reader);
        markUnchecked(reader, 10);
        int afterMark = readUnchecked(reader);
        resetUnchecked(reader);
        int afterReset = readUnchecked(reader);
        assertEquals(afterMark, afterReset);
        assertEquals('b', afterMark);
    }

    @Test
    public void testClose_disallowsFurtherReads() {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"));
        closeUnchecked(reader);
        assertThrows(IOException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                reader.read();
            }
        });
    }

    @Test
    public void testDefaultBufferSizeConstructor_readsSuppliedContent() {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("xyz"));
        assertEquals('x', readUnchecked(reader));
        assertEquals('y', readUnchecked(reader));
        assertEquals('z', readUnchecked(reader));
        assertEquals(EOF, readUnchecked(reader));
    }

    @Test
    public void testDefaultBufferSizeConstructor_doesNotTrackBytes() {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"));
        readUnchecked(reader);
        readUnchecked(reader);
        readUnchecked(reader);
        assertEquals(0L, reader.getBytesRead());
    }

    @Test
    public void testThreeArgConstructor_withTrackBytesFalse_doesNotTrackBytesEvenWithCharset() {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(
                new StringReader("abc"), StandardCharsets.UTF_8, false);
        readUnchecked(reader);
        readUnchecked(reader);
        readUnchecked(reader);
        assertEquals(0L, reader.getBytesRead());
    }

    @Test
    public void testThreeArgConstructor_withTrackBytesTrueButNullCharset_doesNotTrackBytes() {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(
                new StringReader("abc"), null, true);
        readUnchecked(reader);
        readUnchecked(reader);
        readUnchecked(reader);
        assertEquals(0L, reader.getBytesRead());
    }

    @Test
    public void testThreeArgConstructor_withTrackBytesTrueAndCharset_tracksBytesAsCharsAreRead() {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(
                new StringReader("abc"), StandardCharsets.UTF_8, true);
        long before = reader.getBytesRead();
        readUnchecked(reader);
        readUnchecked(reader);
        readUnchecked(reader);
        long after = reader.getBytesRead();
        assertEquals(0L, before);
        assertTrue(after > before);
    }

    @Test
    public void testThreeArgConstructor_withEmptyReaderAndTracking_bytesReadStaysZero() {
        ExtendedBufferedReader reader = new ExtendedBufferedReader(
                new StringReader(""), StandardCharsets.UTF_8, true);
        readUnchecked(reader);
        assertEquals(0L, reader.getBytesRead());
    }

    // --- helpers that convert checked IOException into test failures ---

    private static int readUnchecked(ExtendedBufferedReader reader) {
        try {
            return reader.read();
        } catch (IOException e) {
            throw new AssertionError(e);
        }
    }

    private static int readArrayUnchecked(ExtendedBufferedReader reader, char[] buf, int offset, int length) {
        try {
            return reader.read(buf, offset, length);
        } catch (IOException e) {
            throw new AssertionError(e);
        }
    }

    private static String readLineUnchecked(ExtendedBufferedReader reader) {
        try {
            return reader.readLine();
        } catch (IOException e) {
            throw new AssertionError(e);
        }
    }

    private static void markUnchecked(ExtendedBufferedReader reader, int readAheadLimit) {
        try {
            reader.mark(readAheadLimit);
        } catch (IOException e) {
            throw new AssertionError(e);
        }
    }

    private static void resetUnchecked(ExtendedBufferedReader reader) {
        try {
            reader.reset();
        } catch (IOException e) {
            throw new AssertionError(e);
        }
    }

    private static void closeUnchecked(ExtendedBufferedReader reader) {
        try {
            reader.close();
        } catch (IOException e) {
            throw new AssertionError(e);
        }
    }
}
