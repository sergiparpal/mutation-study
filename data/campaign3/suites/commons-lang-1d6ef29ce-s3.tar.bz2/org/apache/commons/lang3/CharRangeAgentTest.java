package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Iterator;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link CharRange}, based solely on its documented
 * contract.
 */
public class CharRangeAgentTest {

    // ---------------------------------------------------------------
    // Factory methods: is / isIn / isNot / isNotIn
    // ---------------------------------------------------------------

    @Test
    public void testIsSingleChar() {
        CharRange range = CharRange.is('a');
        assertEquals('a', range.getStart());
        assertEquals('a', range.getEnd());
        assertFalse(range.isNegated());
        assertTrue(range.contains('a'));
        assertFalse(range.contains('b'));
    }

    @Test
    public void testIsNotSingleChar() {
        CharRange range = CharRange.isNot('a');
        assertEquals('a', range.getStart());
        assertEquals('a', range.getEnd());
        assertTrue(range.isNegated());
        assertFalse(range.contains('a'));
        assertTrue(range.contains('b'));
    }

    @Test
    public void testIsInNormalOrder() {
        CharRange range = CharRange.isIn('a', 'e');
        assertEquals('a', range.getStart());
        assertEquals('e', range.getEnd());
        assertFalse(range.isNegated());
    }

    @Test
    public void testIsInReversedOrder() {
        // "If start and end are in the wrong order, they are reversed."
        CharRange range = CharRange.isIn('e', 'a');
        assertEquals('a', range.getStart());
        assertEquals('e', range.getEnd());
    }

    @Test
    public void testIsInEqualChars() {
        CharRange range = CharRange.isIn('a', 'a');
        assertEquals('a', range.getStart());
        assertEquals('a', range.getEnd());
        assertTrue(range.contains('a'));
    }

    @Test
    public void testIsNotInNormalOrder() {
        CharRange range = CharRange.isNotIn('a', 'e');
        assertEquals('a', range.getStart());
        assertEquals('e', range.getEnd());
        assertTrue(range.isNegated());
        assertFalse(range.contains('a'));
        assertFalse(range.contains('c'));
        assertFalse(range.contains('e'));
        assertTrue(range.contains('f'));
        assertTrue(range.contains('`'));
    }

    @Test
    public void testIsNotInReversedOrder() {
        CharRange range = CharRange.isNotIn('e', 'a');
        assertEquals('a', range.getStart());
        assertEquals('e', range.getEnd());
        assertTrue(range.isNegated());
    }

    // ---------------------------------------------------------------
    // contains(char)
    // ---------------------------------------------------------------

    @Test
    public void testContainsCharNormalRange() {
        CharRange range = CharRange.isIn('b', 'd');
        assertTrue(range.contains('b'));
        assertTrue(range.contains('c'));
        assertTrue(range.contains('d'));
        assertFalse(range.contains('a'));
        assertFalse(range.contains('e'));
    }

    @Test
    public void testContainsCharNegatedRange() {
        CharRange range = CharRange.isNotIn('b', 'd');
        assertFalse(range.contains('b'));
        assertFalse(range.contains('c'));
        assertFalse(range.contains('d'));
        assertTrue(range.contains('a'));
        assertTrue(range.contains('e'));
    }

    @Test
    public void testContainsCharBoundaries() {
        CharRange min = CharRange.is(Character.MIN_VALUE);
        assertTrue(min.contains(Character.MIN_VALUE));
        assertFalse(min.contains((char) (Character.MIN_VALUE + 1)));

        CharRange max = CharRange.is(Character.MAX_VALUE);
        assertTrue(max.contains(Character.MAX_VALUE));
        assertFalse(max.contains((char) (Character.MAX_VALUE - 1)));
    }

    @Test
    public void testFullRangeContainsEverything() {
        CharRange full = CharRange.isIn(Character.MIN_VALUE, Character.MAX_VALUE);
        assertTrue(full.contains(Character.MIN_VALUE));
        assertTrue(full.contains(Character.MAX_VALUE));
        assertTrue(full.contains('a'));
        assertTrue(full.contains('Z'));
    }

    @Test
    public void testFullyNegatedRangeContainsNothing() {
        CharRange none = CharRange.isNotIn(Character.MIN_VALUE, Character.MAX_VALUE);
        assertFalse(none.contains(Character.MIN_VALUE));
        assertFalse(none.contains(Character.MAX_VALUE));
        assertFalse(none.contains('a'));
    }

    // ---------------------------------------------------------------
    // contains(CharRange)
    // ---------------------------------------------------------------

    @Test
    public void testContainsRangeNullThrowsNPE() {
        CharRange range = CharRange.isIn('a', 'z');
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                range.contains(null);
            }
        });
    }

    @Test
    public void testContainsRangeSelfContainment() {
        CharRange range = CharRange.isIn('a', 'z');
        assertTrue(range.contains(range));
        assertTrue(range.contains(CharRange.isIn('a', 'z')));

        CharRange negated = CharRange.isNotIn('a', 'z');
        assertTrue(negated.contains(negated));
        assertTrue(negated.contains(CharRange.isNotIn('a', 'z')));
    }

    @Test
    public void testContainsRangeSubsetAndSuperset() {
        CharRange outer = CharRange.isIn('a', 'z');
        CharRange inner = CharRange.isIn('m', 'p');
        assertTrue(outer.contains(inner));
        assertFalse(inner.contains(outer));
    }

    @Test
    public void testContainsRangeNegatedLogic() {
        // Everything except 'm' logically contains any range that excludes 'm'.
        CharRange notM = CharRange.isNot('m');
        assertTrue(notM.contains(CharRange.isIn('a', 'e')));
        // But it cannot contain a range that itself includes 'm'.
        assertFalse(notM.contains(CharRange.isIn('a', 'z')));
    }

    // ---------------------------------------------------------------
    // equals(Object)
    // ---------------------------------------------------------------

    @Test
    public void testEqualsReflexiveAndSameValues() {
        CharRange range = CharRange.isIn('a', 'e');
        assertTrue(range.equals(range));
        assertTrue(range.equals(CharRange.isIn('a', 'e')));
        // Reversed construction normalizes to the same start/end/negation.
        assertTrue(CharRange.isIn('a', 'e').equals(CharRange.isIn('e', 'a')));
    }

    @Test
    public void testEqualsDifferentRangesOrNegationOrType() {
        CharRange range = CharRange.isIn('a', 'e');
        assertFalse(range.equals(CharRange.isIn('a', 'f')));
        assertFalse(range.equals(CharRange.isNotIn('a', 'e')));
        assertFalse(range.equals("a-e"));
    }

    @Test
    public void testEqualsNull() {
        CharRange range = CharRange.isIn('a', 'e');
        assertFalse(range.equals(null));
    }

    // ---------------------------------------------------------------
    // hashCode()
    // ---------------------------------------------------------------

    @Test
    public void testHashCodeConsistentWithEquals() {
        CharRange range1 = CharRange.isIn('a', 'e');
        CharRange range2 = CharRange.isIn('e', 'a');
        assertEquals(range1, range2);
        assertEquals(range1.hashCode(), range2.hashCode());
        // hashCode must be stable across repeated invocations.
        assertEquals(range1.hashCode(), range1.hashCode());
    }

    // ---------------------------------------------------------------
    // getStart() / getEnd() / isNegated()
    // ---------------------------------------------------------------

    @Test
    public void testGetStartGetEnd() {
        CharRange range = CharRange.isIn('g', 'k');
        assertEquals('g', range.getStart());
        assertEquals('k', range.getEnd());
    }

    @Test
    public void testIsNegated() {
        assertFalse(CharRange.isIn('a', 'e').isNegated());
        assertTrue(CharRange.isNotIn('a', 'e').isNegated());
    }

    // ---------------------------------------------------------------
    // iterator()
    // ---------------------------------------------------------------

    @Test
    public void testIteratorNormalRangeOrder() {
        CharRange range = CharRange.isIn('a', 'e');
        Iterator<Character> it = range.iterator();
        char expected = 'a';
        while (it.hasNext()) {
            char actual = it.next().charValue();
            assertEquals(expected, actual);
            expected++;
        }
        assertEquals('f', expected);
    }

    @Test
    public void testIteratorSingleChar() {
        CharRange range = CharRange.is('x');
        Iterator<Character> it = range.iterator();
        assertTrue(it.hasNext());
        assertEquals(Character.valueOf('x'), it.next());
        assertFalse(it.hasNext());
    }

    @Test
    public void testIteratorExhaustionThrows() {
        final Iterator<Character> it = CharRange.is('x').iterator();
        it.next();
        assertFalse(it.hasNext());
        assertThrows(NoSuchElementException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                it.next();
            }
        });
    }

    @Test
    public void testIteratorNegatedRange() {
        CharRange range = CharRange.isNot('a');
        Iterator<Character> it = range.iterator();
        int count = 0;
        while (it.hasNext()) {
            char c = it.next().charValue();
            assertNotEquals('a', c);
            count++;
        }
        // Every char value except 'a' should have been produced exactly once.
        assertEquals(65536 - 1, count);
    }

    // ---------------------------------------------------------------
    // toString()
    // ---------------------------------------------------------------

    @Test
    public void testToStringNotNullOrEmpty() {
        String s = CharRange.isIn('a', 'e').toString();
        assertNotNull(s);
        assertFalse(s.isEmpty());

        String negatedS = CharRange.isNotIn('a', 'e').toString();
        assertNotNull(negatedS);
        assertFalse(negatedS.isEmpty());
    }

    // ---------------------------------------------------------------
    // EMPTY_ARRAY field
    // ---------------------------------------------------------------

    @Test
    public void testEmptyArrayField() {
        assertNotNull(CharRange.EMPTY_ARRAY);
        assertEquals(0, CharRange.EMPTY_ARRAY.length);
    }

    // ---------------------------------------------------------------
    // Serializable contract
    // ---------------------------------------------------------------

    @Test
    public void testSerialization() throws Exception {
        CharRange original = CharRange.isNotIn('a', 'e');

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(baos);
        oos.writeObject(original);
        oos.close();

        ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(baos.toByteArray()));
        CharRange roundTripped = (CharRange) ois.readObject();
        ois.close();

        assertEquals(original, roundTripped);
        assertEquals(original.getStart(), roundTripped.getStart());
        assertEquals(original.getEnd(), roundTripped.getEnd());
        assertEquals(original.isNegated(), roundTripped.isNegated());
    }
}
