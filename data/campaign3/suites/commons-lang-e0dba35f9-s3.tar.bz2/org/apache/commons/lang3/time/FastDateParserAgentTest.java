package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for FastDateParser, based on the documented contract
 * in the generated javadoc under api/.
 */
public class FastDateParserAgentTest {

    private static final TimeZone UTC = TimeZone.getTimeZone("UTC");

    private FastDateParser newParser(String pattern) {
        return new FastDateParser(pattern, UTC, Locale.US);
    }

    @Test
    public void testGetPatternGetTimeZoneGetLocaleFromThreeArgConstructor() {
        String pattern = "yyyy-MM-dd";
        FastDateParser parser = new FastDateParser(pattern, UTC, Locale.US);

        assertEquals(pattern, parser.getPattern());
        assertEquals(UTC, parser.getTimeZone());
        assertEquals(Locale.US, parser.getLocale());
    }

    @Test
    public void testFourArgConstructorNullLocaleMapsToDefaultLocale() {
        Locale defaultLocale = Locale.getDefault();
        FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, null, new Date(0));

        assertEquals(defaultLocale, parser.getLocale());
    }

    @Test
    public void testFourArgConstructorKeepsExplicitLocale() {
        FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US, new Date(0));

        assertEquals(Locale.US, parser.getLocale());
        assertEquals(UTC, parser.getTimeZone());
        assertEquals("yyyy-MM-dd", parser.getPattern());
    }

    @Test
    public void testParseBasicDate() throws ParseException {
        FastDateParser parser = newParser("yyyy-MM-dd");

        Date parsed = parser.parse("2023-01-15");

        Calendar cal = Calendar.getInstance(UTC);
        cal.setTime(parsed);
        assertEquals(2023, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void testParseOnlyRequiresBeginningOfStringToMatch() throws ParseException {
        FastDateParser parser = newParser("yyyy-MM-dd");

        Date parsed = parser.parse("2023-01-15 trailing text that is not part of the pattern");

        Calendar cal = Calendar.getInstance(UTC);
        cal.setTime(parsed);
        assertEquals(2023, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void testParseThrowsParseExceptionWhenBeginningCannotBeParsed() {
        FastDateParser parser = newParser("yyyy-MM-dd");

        try {
            parser.parse("not-a-date-at-all");
            fail("Expected ParseException");
        } catch (ParseException expected) {
            // documented: throws ParseException if the beginning of the string cannot be parsed
        }
    }

    @Test
    public void testParseWithLenientModeNormalizesOverflowingFields() throws ParseException {
        FastDateParser parser = newParser("yyyy-MM-dd HH:mm");

        Date parsed = parser.parse("2023-01-15 10:90");

        Calendar cal = Calendar.getInstance(UTC);
        cal.setTime(parsed);
        assertEquals(2023, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
        assertEquals(11, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals(30, cal.get(Calendar.MINUTE));
    }

    @Test
    public void testParseWithParsePositionStartingFromOffsetUpdatesIndexOnSuccess() {
        FastDateParser parser = newParser("yyyy-MM-dd");
        String source = "xxxx2023-01-15";
        ParsePosition pos = new ParsePosition(4);

        Date parsed = parser.parse(source, pos);

        assertNotNull(parsed);
        assertEquals(source.length(), pos.getIndex());

        Calendar cal = Calendar.getInstance(UTC);
        cal.setTime(parsed);
        assertEquals(2023, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void testParseWithParsePositionReturnsNullAndLeavesIndexUnchangedOnFailure() {
        FastDateParser parser = newParser("yyyy-MM-dd");
        ParsePosition pos = new ParsePosition(0);

        Date parsed = parser.parse("abcd-01-01", pos);

        assertNull(parsed);
        assertEquals(0, pos.getIndex());
        assertTrue(pos.getErrorIndex() >= 0);
    }

    @Test
    public void testParseWithCalendarReturnsTrueAndUpdatesCalendarAndPositionOnSuccess() {
        FastDateParser parser = newParser("yyyy-MM-dd");
        Calendar calendar = new GregorianCalendar(UTC);
        ParsePosition pos = new ParsePosition(0);

        boolean result = parser.parse("2023-01-15", pos, calendar);

        assertTrue(result);
        assertEquals(10, pos.getIndex());
        assertEquals(2023, calendar.get(Calendar.YEAR));
        assertEquals(Calendar.JANUARY, calendar.get(Calendar.MONTH));
        assertEquals(15, calendar.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void testParseWithCalendarReturnsFalseAndSetsErrorIndexOnFailure() {
        FastDateParser parser = newParser("yyyy-MM-dd");
        Calendar calendar = new GregorianCalendar(UTC);
        ParsePosition pos = new ParsePosition(0);

        boolean result = parser.parse("abcd-01-01", pos, calendar);

        assertFalse(result);
        assertTrue(pos.getErrorIndex() >= 0);
    }

    @Test
    public void testParseWithNonLenientCalendarThrowsOnOutOfRangeField() {
        FastDateParser parser = newParser("yyyy-MM-dd");
        GregorianCalendar calendar = new GregorianCalendar(UTC);
        calendar.setLenient(false);
        ParsePosition pos = new ParsePosition(0);

        try {
            // 2023 is not a leap year, so February 30th is out of range.
            parser.parse("2023-02-30", pos, calendar);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented: thrown when Calendar is not lenient and a parsed field is out of range
        }
    }

    @Test
    public void testParseObjectStringReturnsDateEquivalentToParse() throws ParseException {
        FastDateParser parser = newParser("yyyy-MM-dd");

        Object parsedObject = parser.parseObject("2023-01-15");
        Date parsedDate = parser.parse("2023-01-15");

        assertNotNull(parsedObject);
        assertTrue(parsedObject instanceof Date);
        assertEquals(parsedDate, parsedObject);
    }

    @Test
    public void testParseObjectStringThrowsParseExceptionOnInvalidInput() {
        FastDateParser parser = newParser("yyyy-MM-dd");

        try {
            parser.parseObject("not-a-date-at-all");
            fail("Expected ParseException");
        } catch (ParseException expected) {
            // documented: throws ParseException if beginning of string cannot be parsed
        }
    }

    @Test
    public void testParseObjectWithParsePositionUpdatesIndexOnSuccess() {
        FastDateParser parser = newParser("yyyy-MM-dd");
        ParsePosition pos = new ParsePosition(0);

        Object parsedObject = parser.parseObject("2023-01-15", pos);

        assertNotNull(parsedObject);
        assertTrue(parsedObject instanceof Date);
        assertEquals(10, pos.getIndex());
    }

    @Test
    public void testParseObjectWithParsePositionReturnsNullOnFailure() {
        FastDateParser parser = newParser("yyyy-MM-dd");
        ParsePosition pos = new ParsePosition(0);

        Object parsedObject = parser.parseObject("abcd-01-01", pos);

        assertNull(parsedObject);
    }

    @Test
    public void testEqualsIsReflexiveForEquivalentPatterns() {
        FastDateParser first = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        FastDateParser second = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);

        assertTrue(first.equals(first));
        assertTrue(first.equals(second));
        assertTrue(second.equals(first));
        assertEquals(first.hashCode(), second.hashCode());
    }

    @Test
    public void testEqualsReturnsFalseForDifferentPatternOrForeignTypesOrNull() {
        FastDateParser first = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        FastDateParser differentPattern = new FastDateParser("yyyy/MM/dd", UTC, Locale.US);

        assertFalse(first.equals(differentPattern));
        assertFalse(first.equals("yyyy-MM-dd"));
        assertFalse(first.equals(null));
    }

    @Test
    public void testToStringReturnsNonNullDebuggingString() {
        FastDateParser parser = newParser("yyyy-MM-dd");

        String result = parser.toString();

        assertNotNull(result);
    }

    @Test
    public void testToStringAllReturnsNonNullDebuggingString() {
        FastDateParser parser = newParser("yyyy-MM-dd");

        String result = parser.toStringAll();

        assertNotNull(result);
    }

    @Test
    public void testClearDoesNotPreventFurtherParsing() throws ParseException {
        FastDateParser parser = newParser("yyyy-MM-dd");

        FastDateParser.clear();
        Date parsed = parser.parse("2023-01-15");

        assertNotNull(parsed);
    }

    @Test
    public void testJapaneseImperialLocaleFieldIsNotNull() {
        assertNotNull(FastDateParser.JAPANESE_IMPERIAL);
    }

    @Test
    public void testCenturyStartBoundsTwoDigitYearInterpretation() throws ParseException {
        GregorianCalendar centuryStartCal = new GregorianCalendar(UTC);
        centuryStartCal.clear();
        centuryStartCal.set(1980, Calendar.JANUARY, 1, 0, 0, 0);
        Date centuryStart = centuryStartCal.getTime();

        GregorianCalendar centuryEndCal = (GregorianCalendar) centuryStartCal.clone();
        centuryEndCal.add(Calendar.YEAR, 100);
        Date centuryEnd = centuryEndCal.getTime();

        FastDateParser parser = new FastDateParser("yy-MM-dd", UTC, Locale.US, centuryStart);

        Date parsed = parser.parse("50-06-15");

        assertNotNull(parsed);
        assertFalse(parsed.before(centuryStart));
        assertTrue(parsed.before(centuryEnd));
    }

    @Test
    public void testMonthNameParsingWithUsLocale() throws ParseException {
        FastDateParser parser = new FastDateParser("MMM d, yyyy", UTC, Locale.US);

        Date parsed = parser.parse("Jan 15, 2023");

        Calendar cal = Calendar.getInstance(UTC);
        cal.setTime(parsed);
        assertEquals(2023, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void testParserIsSerializableAndRestoredInstanceStillParses() throws IOException, ClassNotFoundException, ParseException {
        FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(baos);
        try {
            oos.writeObject(parser);
        } finally {
            oos.close();
        }

        ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(baos.toByteArray()));
        FastDateParser restored;
        try {
            restored = (FastDateParser) ois.readObject();
        } finally {
            ois.close();
        }

        assertEquals(parser.getPattern(), restored.getPattern());
        assertEquals(parser.getTimeZone(), restored.getTimeZone());
        assertEquals(parser.getLocale(), restored.getLocale());

        Date parsed = restored.parse("2023-01-15");
        assertNotNull(parsed);
    }
}
