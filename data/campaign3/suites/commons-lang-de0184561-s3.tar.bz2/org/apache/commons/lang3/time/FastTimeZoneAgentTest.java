package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link FastTimeZone}, based solely on its documented contract.
 */
public class FastTimeZoneAgentTest {

    private static final int ONE_HOUR_MILLIS = 60 * 60 * 1000;
    private static final int ONE_MINUTE_MILLIS = 60 * 1000;

    // ---- getGmtTimeZone() ----

    @Test
    public void testGetGmtTimeZoneNotNull() {
        assertNotNull(FastTimeZone.getGmtTimeZone());
    }

    @Test
    public void testGetGmtTimeZoneHasZeroRawOffset() {
        TimeZone tz = FastTimeZone.getGmtTimeZone();
        assertEquals(0, tz.getRawOffset());
    }

    // ---- getGmtTimeZone(String) - lenient/empty-like inputs that default to GMT ----

    @Test
    public void testGetGmtTimeZonePatternZ() {
        TimeZone tz = FastTimeZone.getGmtTimeZone("Z");
        assertNotNull(tz);
        assertEquals(0, tz.getRawOffset());
    }

    @Test
    public void testGetGmtTimeZonePatternUtc() {
        TimeZone tz = FastTimeZone.getGmtTimeZone("UTC");
        assertNotNull(tz);
        assertEquals(0, tz.getRawOffset());
    }

    @Test
    public void testGetGmtTimeZonePatternEmptyString() {
        TimeZone tz = FastTimeZone.getGmtTimeZone("");
        assertNotNull(tz);
        assertEquals(0, tz.getRawOffset());
    }

    @Test
    public void testGetGmtTimeZonePatternPlusOnly() {
        TimeZone tz = FastTimeZone.getGmtTimeZone("+");
        assertNotNull(tz);
        assertEquals(0, tz.getRawOffset());
    }

    @Test
    public void testGetGmtTimeZonePatternMinusOnly() {
        TimeZone tz = FastTimeZone.getGmtTimeZone("-");
        assertNotNull(tz);
        assertEquals(0, tz.getRawOffset());
    }

    @Test
    public void testGetGmtTimeZonePatternGmtOnly() {
        TimeZone tz = FastTimeZone.getGmtTimeZone("GMT");
        assertNotNull(tz);
        assertEquals(0, tz.getRawOffset());
    }

    // ---- getGmtTimeZone(String) - well-formed offsets ----

    @Test
    public void testGetGmtTimeZonePatternPositiveSingleDigitHour() {
        TimeZone tz = FastTimeZone.getGmtTimeZone("+5");
        assertNotNull(tz);
        assertEquals(5 * ONE_HOUR_MILLIS, tz.getRawOffset());
    }

    @Test
    public void testGetGmtTimeZonePatternNegativeSingleDigitHour() {
        TimeZone tz = FastTimeZone.getGmtTimeZone("-5");
        assertNotNull(tz);
        assertEquals(-5 * ONE_HOUR_MILLIS, tz.getRawOffset());
    }

    @Test
    public void testGetGmtTimeZonePatternTwoDigitHour() {
        TimeZone tz = FastTimeZone.getGmtTimeZone("+12");
        assertNotNull(tz);
        assertEquals(12 * ONE_HOUR_MILLIS, tz.getRawOffset());
    }

    @Test
    public void testGetGmtTimeZonePatternHoursAndMinutesWithColon() {
        TimeZone tz = FastTimeZone.getGmtTimeZone("+5:30");
        assertNotNull(tz);
        assertEquals(5 * ONE_HOUR_MILLIS + 30 * ONE_MINUTE_MILLIS, tz.getRawOffset());
    }

    @Test
    public void testGetGmtTimeZonePatternNegativeHoursAndMinutesWithColon() {
        TimeZone tz = FastTimeZone.getGmtTimeZone("-5:30");
        assertNotNull(tz);
        assertEquals(-(5 * ONE_HOUR_MILLIS + 30 * ONE_MINUTE_MILLIS), tz.getRawOffset());
    }

    @Test
    public void testGetGmtTimeZonePatternGmtPrefixHoursAndMinutes() {
        TimeZone tz = FastTimeZone.getGmtTimeZone("GMT+05:30");
        assertNotNull(tz);
        assertEquals(5 * ONE_HOUR_MILLIS + 30 * ONE_MINUTE_MILLIS, tz.getRawOffset());
    }

    // ---- getGmtTimeZone(String) - out of range offsets must return null ----

    @Test
    public void testGetGmtTimeZonePatternOutOfRangeHours() {
        assertNull(FastTimeZone.getGmtTimeZone("+24"));
    }

    @Test
    public void testGetGmtTimeZonePatternOutOfRangeMinutes() {
        assertNull(FastTimeZone.getGmtTimeZone("+5:60"));
    }

    // ---- getGmtTimeZone(String) - inputs that fail the regex outright must return null ----

    @Test
    public void testGetGmtTimeZonePatternNonMatchingLetters() {
        assertNull(FastTimeZone.getGmtTimeZone("ABC"));
    }

    @Test
    public void testGetGmtTimeZonePatternTooManyColonSeparatedParts() {
        assertNull(FastTimeZone.getGmtTimeZone("+5:30:00"));
    }

    // ---- getTimeZone(String) - GMT custom ids ----

    @Test
    public void testGetTimeZoneZ() {
        TimeZone tz = FastTimeZone.getTimeZone("Z");
        assertNotNull(tz);
        assertEquals(0, tz.getRawOffset());
    }

    @Test
    public void testGetTimeZoneUtc() {
        TimeZone tz = FastTimeZone.getTimeZone("UTC");
        assertNotNull(tz);
        assertEquals(0, tz.getRawOffset());
    }

    @Test
    public void testGetTimeZoneCustomOffsetNoColon() {
        TimeZone tz = FastTimeZone.getTimeZone("+5");
        assertNotNull(tz);
        assertEquals(5 * ONE_HOUR_MILLIS, tz.getRawOffset());
    }

    @Test
    public void testGetTimeZoneCustomOffsetWithColon() {
        TimeZone tz = FastTimeZone.getTimeZone("+05:30");
        assertNotNull(tz);
        assertEquals(5 * ONE_HOUR_MILLIS + 30 * ONE_MINUTE_MILLIS, tz.getRawOffset());
    }

    @Test
    public void testGetTimeZoneNegativeCustomOffset() {
        TimeZone tz = FastTimeZone.getTimeZone("-08:00");
        assertNotNull(tz);
        assertEquals(-8 * ONE_HOUR_MILLIS, tz.getRawOffset());
    }

    @Test
    public void testGetTimeZoneGmtPrefixOffset() {
        TimeZone tz = FastTimeZone.getTimeZone("GMT+5:30");
        assertNotNull(tz);
        assertEquals(5 * ONE_HOUR_MILLIS + 30 * ONE_MINUTE_MILLIS, tz.getRawOffset());
    }

    // ---- getTimeZone(String) - falls back to Olson ids ----

    @Test
    public void testGetTimeZoneFallsBackToOlsonId() {
        TimeZone tz = FastTimeZone.getTimeZone("America/New_York");
        assertNotNull(tz);
        assertEquals("America/New_York", tz.getID());
    }

    @Test
    public void testGetTimeZoneFallsBackToOlsonIdEurope() {
        TimeZone tz = FastTimeZone.getTimeZone("Europe/Paris");
        assertNotNull(tz);
        assertEquals("Europe/Paris", tz.getID());
    }

    @Test
    public void testGetTimeZoneUnrecognizedIdNeverNull() {
        // Not a valid GMT custom id and not a known Olson id: must still return a
        // non-null TimeZone, per the "falling back to Olson ids" contract combined
        // with the fact that getTimeZone's contract never documents a null return.
        TimeZone tz = FastTimeZone.getTimeZone("Not/A/Real/Zone");
        assertNotNull(tz);
    }

    @Test
    public void testGetTimeZoneOutOfRangeOffsetNeverNull() {
        // An out-of-range GMT custom offset would make getGmtTimeZone return null,
        // but getTimeZone's own contract never documents returning null.
        TimeZone tz = FastTimeZone.getTimeZone("+24:00");
        assertNotNull(tz);
    }
}
