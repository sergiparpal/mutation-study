package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.function.Supplier;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests for {@link CSVFormat} based on the documented contract in the project's javadoc.
 */
public class CSVFormatAgentTest {

    private enum SampleHeaderEnum {
        Name, Email, Phone
    }

    private static void closeQuietly(Object printer) throws IOException {
        if (printer instanceof Closeable) {
            ((Closeable) printer).close();
        }
    }

    // ---------------------------------------------------------------
    // Predefined format field values
    // ---------------------------------------------------------------

    @Test
    public void testDefaultFormatFields() {
        final CSVFormat fmt = CSVFormat.DEFAULT;
        assertEquals(",", fmt.getDelimiterString());
        assertEquals(Character.valueOf('"'), fmt.getQuoteCharacter());
        assertEquals("\r\n", fmt.getRecordSeparator());
        assertTrue(fmt.getIgnoreEmptyLines());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, fmt.getDuplicateHeaderMode());
        assertNull(fmt.getCommentMarker());
        assertNull(fmt.getEscapeCharacter());
        assertNull(fmt.getHeader());
        assertNull(fmt.getHeaderComments());
        assertFalse(fmt.getSkipHeaderRecord());
        assertFalse(fmt.getAllowMissingColumnNames());
        assertFalse(fmt.getIgnoreHeaderCase());
        assertFalse(fmt.getIgnoreSurroundingSpaces());
        assertFalse(fmt.getTrailingDelimiter());
        assertFalse(fmt.getTrim());
        assertFalse(fmt.getAutoFlush());
        assertFalse(fmt.getLenientEof());
        assertFalse(fmt.getTrailingData());
        assertNull(fmt.getNullString());
        assertFalse(fmt.isNullStringSet());
        assertFalse(fmt.isCommentMarkerSet());
        assertFalse(fmt.isEscapeCharacterSet());
        assertTrue(fmt.isQuoteCharacterSet());
    }

    @Test
    public void testExcelFormatFields() {
        final CSVFormat fmt = CSVFormat.EXCEL;
        assertEquals(",", fmt.getDelimiterString());
        assertEquals(Character.valueOf('"'), fmt.getQuoteCharacter());
        assertEquals("\r\n", fmt.getRecordSeparator());
        assertFalse(fmt.getIgnoreEmptyLines());
        assertTrue(fmt.getAllowMissingColumnNames());
        assertTrue(fmt.getTrailingData());
        assertTrue(fmt.getLenientEof());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, fmt.getDuplicateHeaderMode());
    }

    @Test
    public void testRfc4180FormatFields() {
        final CSVFormat fmt = CSVFormat.RFC4180;
        assertEquals(",", fmt.getDelimiterString());
        assertEquals(Character.valueOf('"'), fmt.getQuoteCharacter());
        assertEquals("\r\n", fmt.getRecordSeparator());
        assertFalse(fmt.getIgnoreEmptyLines());
    }

    @Test
    public void testTdfFormatFields() {
        final CSVFormat fmt = CSVFormat.TDF;
        assertEquals("\t", fmt.getDelimiterString());
        assertTrue(fmt.getIgnoreSurroundingSpaces());
    }

    @Test
    public void testMySqlFormatFields() {
        final CSVFormat fmt = CSVFormat.MYSQL;
        assertEquals("\t", fmt.getDelimiterString());
        assertEquals(Character.valueOf('\\'), fmt.getEscapeCharacter());
        assertFalse(fmt.getIgnoreEmptyLines());
        assertFalse(fmt.isQuoteCharacterSet());
        assertEquals("\n", fmt.getRecordSeparator());
        assertEquals("\\N", fmt.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, fmt.getQuoteMode());
    }

    @Test
    public void testPostgreSqlCsvFormatFields() {
        final CSVFormat fmt = CSVFormat.POSTGRESQL_CSV;
        assertEquals(",", fmt.getDelimiterString());
        assertNull(fmt.getEscapeCharacter());
        assertFalse(fmt.getIgnoreEmptyLines());
        assertEquals(Character.valueOf('"'), fmt.getQuoteCharacter());
        assertEquals("\n", fmt.getRecordSeparator());
        assertEquals("", fmt.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, fmt.getQuoteMode());
    }

    @Test
    public void testPostgreSqlTextFormatFields() {
        final CSVFormat fmt = CSVFormat.POSTGRESQL_TEXT;
        assertEquals("\t", fmt.getDelimiterString());
        assertEquals(Character.valueOf('\\'), fmt.getEscapeCharacter());
        assertNull(fmt.getQuoteCharacter());
        assertEquals("\n", fmt.getRecordSeparator());
        assertEquals("\\N", fmt.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, fmt.getQuoteMode());
    }

    @Test
    public void testOracleFormatFields() {
        final CSVFormat fmt = CSVFormat.ORACLE;
        assertEquals(",", fmt.getDelimiterString());
        assertEquals(Character.valueOf('\\'), fmt.getEscapeCharacter());
        assertFalse(fmt.getIgnoreEmptyLines());
        assertEquals(Character.valueOf('"'), fmt.getQuoteCharacter());
        assertEquals("\\N", fmt.getNullString());
        assertTrue(fmt.getTrim());
        assertEquals(System.lineSeparator(), fmt.getRecordSeparator());
        assertEquals(QuoteMode.MINIMAL, fmt.getQuoteMode());
    }

    @Test
    public void testInformixUnloadFormatFields() {
        final CSVFormat fmt = CSVFormat.INFORMIX_UNLOAD;
        assertEquals(",", fmt.getDelimiterString());
        assertEquals(Character.valueOf('\\'), fmt.getEscapeCharacter());
        assertEquals(Character.valueOf('"'), fmt.getQuoteCharacter());
        assertEquals("\n", fmt.getRecordSeparator());
    }

    @Test
    public void testInformixUnloadCsvFormatFields() {
        final CSVFormat fmt = CSVFormat.INFORMIX_UNLOAD_CSV;
        assertEquals(",", fmt.getDelimiterString());
        assertEquals(Character.valueOf('"'), fmt.getQuoteCharacter());
        assertEquals("\n", fmt.getRecordSeparator());
    }

    @Test
    public void testMongoDbCsvFormatFields() {
        final CSVFormat fmt = CSVFormat.MONGODB_CSV;
        assertEquals(",", fmt.getDelimiterString());
        assertEquals(Character.valueOf('"'), fmt.getEscapeCharacter());
        assertEquals(Character.valueOf('"'), fmt.getQuoteCharacter());
        assertEquals(QuoteMode.MINIMAL, fmt.getQuoteMode());
    }

    @Test
    public void testMongoDbTsvFormatFields() {
        final CSVFormat fmt = CSVFormat.MONGODB_TSV;
        assertEquals("\t", fmt.getDelimiterString());
        assertEquals(Character.valueOf('"'), fmt.getEscapeCharacter());
        assertEquals(Character.valueOf('"'), fmt.getQuoteCharacter());
        assertEquals(QuoteMode.MINIMAL, fmt.getQuoteMode());
        assertFalse(fmt.getSkipHeaderRecord());
    }

    // ---------------------------------------------------------------
    // newFormat
    // ---------------------------------------------------------------

    @Test
    public void testNewFormatSetsOnlyDelimiter() {
        final CSVFormat fmt = CSVFormat.newFormat(';');
        assertEquals(";", fmt.getDelimiterString());
        assertNull(fmt.getQuoteCharacter());
        assertNull(fmt.getCommentMarker());
        assertNull(fmt.getEscapeCharacter());
        assertNull(fmt.getNullString());
        assertNull(fmt.getHeader());
        assertNull(fmt.getHeaderComments());
        assertNull(fmt.getRecordSeparator());
        assertFalse(fmt.getSkipHeaderRecord());
        assertFalse(fmt.getIgnoreEmptyLines());
        assertFalse(fmt.getIgnoreSurroundingSpaces());
        assertFalse(fmt.getTrim());
    }

    @Test
    public void testNewFormatRejectsLineBreakDelimiter() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.newFormat('\n');
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.newFormat('\r');
            }
        });
    }

    // ---------------------------------------------------------------
    // valueOf
    // ---------------------------------------------------------------

    @Test
    public void testValueOfReturnsPredefinedFormat() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.valueOf("Default"));
        assertEquals(CSVFormat.EXCEL, CSVFormat.valueOf("Excel"));
        assertEquals(CSVFormat.RFC4180, CSVFormat.valueOf("RFC4180"));
        assertEquals(CSVFormat.TDF, CSVFormat.valueOf("TDF"));
    }

    @Test
    public void testValueOfUnknownNameThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.valueOf("NotAPredefinedFormat");
            }
        });
    }

    @Test
    public void testValueOfNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.valueOf(null);
            }
        });
    }

    // ---------------------------------------------------------------
    // builder() / copy() / immutability
    // ---------------------------------------------------------------

    @Test
    public void testBuilderProducesEquivalentFormatWhenUnmodified() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder();
        assertNotNull(builder);
        assertEquals(CSVFormat.DEFAULT, builder.get());
    }

    @Test
    public void testBuilderDoesNotMutateOriginalFormat() {
        final CSVFormat original = CSVFormat.DEFAULT;
        final CSVFormat modified = original.builder().setDelimiter(';').get();
        assertEquals(",", original.getDelimiterString());
        assertEquals(";", modified.getDelimiterString());
    }

    @Test
    public void testCopyInstanceProducesEqualButDistinctInstance() {
        final CSVFormat copy = CSVFormat.DEFAULT.copy();
        assertNotSame(CSVFormat.DEFAULT, copy);
        assertEquals(CSVFormat.DEFAULT, copy);
        assertEquals(CSVFormat.DEFAULT.hashCode(), copy.hashCode());
    }

    @Test
    public void testStaticCopyOfNullIsNull() {
        assertNull(CSVFormat.copy(null));
    }

    @Test
    public void testStaticCopyOfFormatIsEqual() {
        final CSVFormat copy = CSVFormat.copy(CSVFormat.EXCEL);
        assertEquals(CSVFormat.EXCEL, copy);
    }

    @Test
    public void testBuilderCreateDefaultMatchesDefaultFormat() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.Builder.create().get());
    }

    @Test
    public void testBuilderCreateFromFormatMatchesThatFormat() {
        assertEquals(CSVFormat.EXCEL, CSVFormat.Builder.create(CSVFormat.EXCEL).get());
    }

    @Test
    public void testBuilderBuildIsEquivalentToGet() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder().setDelimiter(';');
        assertEquals(builder.get(), builder.build());
    }

    @Test
    public void testBuilderSettersReturnSameInstance() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertSame(builder, builder.setDelimiter(';'));
        assertSame(builder, builder.setQuote('\''));
        assertSame(builder, builder.setNullString("NULL"));
        assertSame(builder, builder.setTrim(true));
    }

    @Test
    public void testBuilderImplementsSupplier() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder().setDelimiter('|');
        final Supplier<CSVFormat> supplier = builder;
        assertEquals("|", supplier.get().getDelimiterString());
    }

    // ---------------------------------------------------------------
    // Delimiter
    // ---------------------------------------------------------------

    @Test
    public void testGetDelimiterDeprecatedReturnsFirstChar() {
        assertEquals(',', CSVFormat.DEFAULT.getDelimiter());
    }

    @Test
    public void testGetDelimiterCharArray() {
        assertArrayEquals(new char[] {','}, CSVFormat.DEFAULT.getDelimiterCharArray());
    }

    @Test
    public void testMultiCharacterDelimiterRoundTrips() {
        final CSVFormat fmt = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        assertEquals("::", fmt.getDelimiterString());
        assertArrayEquals(new char[] {':', ':'}, fmt.getDelimiterCharArray());
        assertEquals(':', fmt.getDelimiter());
    }

    @Test
    public void testWithDelimiterRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.withDelimiter('\n');
            }
        });
    }

    // ---------------------------------------------------------------
    // Comment marker / escape / quote validation
    // ---------------------------------------------------------------

    @Test
    public void testWithCommentMarkerRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.withCommentMarker('\r');
            }
        });
    }

    @Test
    public void testWithEscapeRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.withEscape('\n');
            }
        });
    }

    @Test
    public void testWithQuoteRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.withQuote('\n');
            }
        });
    }

    @Test
    public void testIsCommentMarkerSet() {
        assertFalse(CSVFormat.DEFAULT.isCommentMarkerSet());
        final CSVFormat fmt = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        assertTrue(fmt.isCommentMarkerSet());
        assertEquals(Character.valueOf('#'), fmt.getCommentMarker());
    }

    @Test
    public void testIsEscapeCharacterSet() {
        assertFalse(CSVFormat.DEFAULT.isEscapeCharacterSet());
        final CSVFormat fmt = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        assertTrue(fmt.isEscapeCharacterSet());
        assertEquals('\\', fmt.getEscapeChar());
    }

    @Test
    public void testGetEscapeCharDefaultsToZero() {
        assertEquals(0, CSVFormat.DEFAULT.getEscapeChar());
    }

    @Test
    public void testIsQuoteCharacterSet() {
        assertTrue(CSVFormat.DEFAULT.isQuoteCharacterSet());
        final CSVFormat fmt = CSVFormat.newFormat(',');
        assertFalse(fmt.isQuoteCharacterSet());
    }

    @Test
    public void testIsNullStringSet() {
        assertFalse(CSVFormat.DEFAULT.isNullStringSet());
        final CSVFormat fmt = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        assertTrue(fmt.isNullStringSet());
        assertEquals("NULL", fmt.getNullString());
    }

    // ---------------------------------------------------------------
    // Record separator
    // ---------------------------------------------------------------

    @Test
    public void testWithRecordSeparatorRejectsInvalidValue() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.withRecordSeparator("xyz");
            }
        });
    }

    @Test
    public void testWithRecordSeparatorAcceptsLf() {
        final CSVFormat fmt = CSVFormat.DEFAULT.withRecordSeparator("\n");
        assertEquals("\n", fmt.getRecordSeparator());
    }

    @Test
    public void testWithSystemRecordSeparator() {
        final CSVFormat fmt = CSVFormat.DEFAULT.withSystemRecordSeparator();
        assertEquals(System.lineSeparator(), fmt.getRecordSeparator());
    }

    // ---------------------------------------------------------------
    // Header / header comments
    // ---------------------------------------------------------------

    @Test
    public void testGetHeaderReturnsDefensiveCopy() {
        final String[] original = {"a", "b"};
        final CSVFormat fmt = CSVFormat.DEFAULT.builder().setHeader(original).get();
        original[0] = "changed";
        assertArrayEquals(new String[] {"a", "b"}, fmt.getHeader());

        final String[] firstCall = fmt.getHeader();
        firstCall[0] = "mutated";
        assertArrayEquals(new String[] {"a", "b"}, fmt.getHeader());
    }

    @Test
    public void testSetHeaderNoArgsProducesEmptyHeaderArray() {
        final CSVFormat fmt = CSVFormat.DEFAULT.builder().setHeader().get();
        assertNotNull(fmt.getHeader());
        assertEquals(0, fmt.getHeader().length);
    }

    @Test
    public void testSetHeaderNullDisablesHeader() {
        final CSVFormat fmt = CSVFormat.DEFAULT.builder().setHeader((String[]) null).get();
        assertNull(fmt.getHeader());
    }

    @Test
    public void testWithHeaderStringsSetsHeader() {
        final CSVFormat fmt = CSVFormat.DEFAULT.withHeader("name", "email");
        assertArrayEquals(new String[] {"name", "email"}, fmt.getHeader());
    }

    @Test
    public void testWithHeaderEnumSetsHeaderFromEnumNames() {
        final CSVFormat fmt = CSVFormat.DEFAULT.withHeader(SampleHeaderEnum.class);
        assertArrayEquals(new String[] {"Name", "Email", "Phone"}, fmt.getHeader());
    }

    @Test
    public void testWithFirstRecordAsHeaderSetsEmptyHeaderAndSkipsHeaderRecord() {
        final CSVFormat fmt = CSVFormat.DEFAULT.withFirstRecordAsHeader();
        assertNotNull(fmt.getHeader());
        assertEquals(0, fmt.getHeader().length);
        assertTrue(fmt.getSkipHeaderRecord());
    }

    @Test
    public void testGetHeaderCommentsReturnsDefensiveCopy() {
        final CSVFormat fmt = CSVFormat.DEFAULT.builder().setHeaderComments("c1", "c2").get();
        final String[] comments = fmt.getHeaderComments();
        comments[0] = "mutated";
        assertArrayEquals(new String[] {"c1", "c2"}, fmt.getHeaderComments());
    }

    @Test
    public void testWithHeaderCommentsConvertsObjectsToStrings() {
        final CSVFormat fmt = CSVFormat.DEFAULT.withHeaderComments("Generated", Integer.valueOf(123));
        assertArrayEquals(new String[] {"Generated", "123"}, fmt.getHeaderComments());
    }

    @Test
    public void testDefaultHeaderCommentsAreNull() {
        assertNull(CSVFormat.DEFAULT.getHeaderComments());
    }

    // ---------------------------------------------------------------
    // Simple boolean/long/string with*/set* round trips
    // ---------------------------------------------------------------

    @Test
    public void testWithAllowMissingColumnNames() {
        assertFalse(CSVFormat.DEFAULT.getAllowMissingColumnNames());
        assertTrue(CSVFormat.DEFAULT.withAllowMissingColumnNames().getAllowMissingColumnNames());
        assertTrue(CSVFormat.DEFAULT.withAllowMissingColumnNames(true).getAllowMissingColumnNames());
        assertFalse(CSVFormat.DEFAULT.withAllowMissingColumnNames(false).getAllowMissingColumnNames());
    }

    @Test
    public void testWithIgnoreSurroundingSpaces() {
        assertFalse(CSVFormat.DEFAULT.getIgnoreSurroundingSpaces());
        assertTrue(CSVFormat.DEFAULT.withIgnoreSurroundingSpaces().getIgnoreSurroundingSpaces());
        assertFalse(CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(false).getIgnoreSurroundingSpaces());
    }

    @Test
    public void testWithIgnoreEmptyLines() {
        assertTrue(CSVFormat.DEFAULT.withIgnoreEmptyLines().getIgnoreEmptyLines());
        assertFalse(CSVFormat.DEFAULT.withIgnoreEmptyLines(false).getIgnoreEmptyLines());
    }

    @Test
    public void testWithIgnoreHeaderCase() {
        assertFalse(CSVFormat.DEFAULT.getIgnoreHeaderCase());
        assertTrue(CSVFormat.DEFAULT.withIgnoreHeaderCase().getIgnoreHeaderCase());
        assertTrue(CSVFormat.DEFAULT.withIgnoreHeaderCase(true).getIgnoreHeaderCase());
    }

    @Test
    public void testWithTrim() {
        assertFalse(CSVFormat.DEFAULT.getTrim());
        assertTrue(CSVFormat.DEFAULT.withTrim().getTrim());
        assertTrue(CSVFormat.DEFAULT.withTrim(true).getTrim());
    }

    @Test
    public void testWithTrailingDelimiter() {
        assertFalse(CSVFormat.DEFAULT.getTrailingDelimiter());
        assertTrue(CSVFormat.DEFAULT.withTrailingDelimiter().getTrailingDelimiter());
        assertTrue(CSVFormat.DEFAULT.withTrailingDelimiter(true).getTrailingDelimiter());
    }

    @Test
    public void testWithSkipHeaderRecord() {
        assertFalse(CSVFormat.DEFAULT.getSkipHeaderRecord());
        assertTrue(CSVFormat.DEFAULT.withSkipHeaderRecord().getSkipHeaderRecord());
        assertTrue(CSVFormat.DEFAULT.withSkipHeaderRecord(true).getSkipHeaderRecord());
    }

    @Test
    public void testWithNullString() {
        assertNull(CSVFormat.DEFAULT.getNullString());
        final CSVFormat fmt = CSVFormat.DEFAULT.withNullString("NULL");
        assertEquals("NULL", fmt.getNullString());
        assertTrue(fmt.isNullStringSet());
    }

    @Test
    public void testWithQuoteMode() {
        final CSVFormat fmt = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
        assertEquals(QuoteMode.MINIMAL, fmt.getQuoteMode());
    }

    @Test
    public void testWithAutoFlush() {
        assertFalse(CSVFormat.DEFAULT.getAutoFlush());
        assertTrue(CSVFormat.DEFAULT.withAutoFlush(true).getAutoFlush());
    }

    @Test
    public void testWithAllowDuplicateHeaderNames() {
        assertTrue(CSVFormat.DEFAULT.withAllowDuplicateHeaderNames().getAllowDuplicateHeaderNames());
        assertFalse(CSVFormat.DEFAULT.withAllowDuplicateHeaderNames(false).getAllowDuplicateHeaderNames());
        assertTrue(CSVFormat.DEFAULT.withAllowDuplicateHeaderNames(true).getAllowDuplicateHeaderNames());
    }

    @Test
    public void testSetAllowMissingColumnNamesViaBuilder() {
        final CSVFormat fmt = CSVFormat.DEFAULT.builder().setAllowMissingColumnNames(true).get();
        assertTrue(fmt.getAllowMissingColumnNames());
    }

    @Test
    public void testSetMaxRowsViaBuilder() {
        assertTrue(CSVFormat.DEFAULT.getMaxRows() <= 0);
        final CSVFormat fmt = CSVFormat.DEFAULT.builder().setMaxRows(5).get();
        assertEquals(5L, fmt.getMaxRows());
    }

    @Test
    public void testSetLenientEofViaBuilder() {
        assertFalse(CSVFormat.DEFAULT.getLenientEof());
        final CSVFormat fmt = CSVFormat.DEFAULT.builder().setLenientEof(true).get();
        assertTrue(fmt.getLenientEof());
    }

    @Test
    public void testSetTrailingDataViaBuilder() {
        assertFalse(CSVFormat.DEFAULT.getTrailingData());
        final CSVFormat fmt = CSVFormat.DEFAULT.builder().setTrailingData(true).get();
        assertTrue(fmt.getTrailingData());
    }

    @Test
    public void testSetDuplicateHeaderModeViaBuilder() {
        final CSVFormat fmt = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_ALL).get();
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, fmt.getDuplicateHeaderMode());
    }

    // ---------------------------------------------------------------
    // equals / hashCode / toString
    // ---------------------------------------------------------------

    @Test
    public void testEqualsIsReflexive() {
        assertTrue(CSVFormat.DEFAULT.equals(CSVFormat.DEFAULT));
    }

    @Test
    public void testEqualsHandlesNullAndForeignTypes() {
        assertFalse(CSVFormat.DEFAULT.equals(null));
        assertFalse(CSVFormat.DEFAULT.equals("not a CSVFormat"));
    }

    @Test
    public void testEqualsAndHashCodeForEquivalentConfigurations() {
        final CSVFormat copy = CSVFormat.DEFAULT.copy();
        assertTrue(CSVFormat.DEFAULT.equals(copy));
        assertEquals(CSVFormat.DEFAULT.hashCode(), copy.hashCode());
    }

    @Test
    public void testEqualsDistinguishesDifferentConfigurations() {
        assertFalse(CSVFormat.DEFAULT.equals(CSVFormat.EXCEL));
        assertFalse(CSVFormat.DEFAULT.equals(CSVFormat.MYSQL));
    }

    @Test
    public void testToStringIsNotNullAndConsistent() {
        final String first = CSVFormat.DEFAULT.toString();
        final String second = CSVFormat.DEFAULT.toString();
        assertNotNull(first);
        assertEquals(first, second);
    }

    @Test
    public void testHashCodeIsConsistentAcrossCalls() {
        final int first = CSVFormat.DEFAULT.hashCode();
        final int second = CSVFormat.DEFAULT.hashCode();
        assertEquals(first, second);
    }

    // ---------------------------------------------------------------
    // format()
    // ---------------------------------------------------------------

    @Test
    public void testFormatJoinsValuesWithDelimiter() {
        assertEquals("a,b,c", CSVFormat.DEFAULT.format("a", "b", "c"));
    }

    @Test
    public void testFormatQuotesValueContainingDelimiter() {
        assertEquals("a,\"b,c\",d", CSVFormat.DEFAULT.format("a", "b,c", "d"));
    }

    @Test
    public void testFormatDoublesEmbeddedQuoteCharacters() {
        assertEquals("\"a \"\"quoted\"\" value\"", CSVFormat.DEFAULT.format("a \"quoted\" value"));
    }

    @Test
    public void testFormatNullValueWithoutNullStringIsEmpty() {
        assertEquals("", CSVFormat.DEFAULT.format((Object) null));
    }

    @Test
    public void testFormatNullValueWithNullStringSubstitutes() {
        final CSVFormat fmt = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        assertEquals("NULL", fmt.format((Object) null));
    }

    @Test
    public void testFormatNoValuesProducesEmptyString() {
        assertEquals("", CSVFormat.DEFAULT.format());
    }

    // ---------------------------------------------------------------
    // printRecord / println / print(value, out, newRecord)
    // ---------------------------------------------------------------

    @Test
    public void testPrintRecordWritesDelimitedValuesFollowedByRecordSeparator() throws IOException {
        final StringWriter sw = new StringWriter();
        CSVFormat.DEFAULT.printRecord(sw, "a", "b", "c");
        assertEquals("a,b,c\r\n", sw.toString());
    }

    @Test
    public void testPrintlnWithoutTrailingDelimiterWritesOnlyRecordSeparator() throws IOException {
        final StringWriter sw = new StringWriter();
        CSVFormat.DEFAULT.println(sw);
        assertEquals("\r\n", sw.toString());
    }

    @Test
    public void testPrintlnWithTrailingDelimiterWritesDelimiterThenRecordSeparator() throws IOException {
        final CSVFormat fmt = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get();
        final StringWriter sw = new StringWriter();
        fmt.println(sw);
        assertEquals(",\r\n", sw.toString());
    }

    @Test
    public void testPrintValueTrimsWhenTrimIsEnabled() throws IOException {
        final CSVFormat fmt = CSVFormat.DEFAULT.builder().setTrim(true).get();
        final StringWriter sw = new StringWriter();
        fmt.print(" value ", sw, true);
        assertEquals("value", sw.toString());
    }

    @Test
    public void testPrintValueSeparatesSubsequentValuesWithDelimiter() throws IOException {
        final StringWriter sw = new StringWriter();
        CSVFormat.DEFAULT.print("a", sw, true);
        CSVFormat.DEFAULT.print("b", sw, false);
        assertEquals("a,b", sw.toString());
    }

    // ---------------------------------------------------------------
    // parse / print(Appendable) / printer() / print(File,...) / print(Path,...)
    // ---------------------------------------------------------------

    @Test
    public void testParseReturnsNonNullParserForReader() throws IOException {
        final CSVParser parser = CSVFormat.DEFAULT.parse(new StringReader("a,b\r\n"));
        assertNotNull(parser);
    }

    @Test
    public void testParseReturnsNonNullParserForEmptyInput() throws IOException {
        final CSVParser parser = CSVFormat.DEFAULT.parse(new StringReader(""));
        assertNotNull(parser);
    }

    @Test
    public void testPrintToAppendableReturnsNonNullPrinter() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = CSVFormat.DEFAULT.print(sw);
        assertNotNull(printer);
        closeQuietly(printer);
    }

    @Test
    public void testPrinterReturnsNonNullPrinter() throws IOException {
        final CSVPrinter printer = CSVFormat.DEFAULT.printer();
        assertNotNull(printer);
        closeQuietly(printer);
    }

    @Test
    public void testPrintToFileCreatesPrinter() throws IOException {
        final File tempFile = File.createTempFile("csvformatagenttest", ".csv");
        try {
            final CSVPrinter printer = CSVFormat.DEFAULT.print(tempFile, StandardCharsets.UTF_8);
            assertNotNull(printer);
            closeQuietly(printer);
            assertTrue(tempFile.exists());
        } finally {
            tempFile.delete();
        }
    }

    @Test
    public void testPrintToPathCreatesPrinter() throws IOException {
        final Path tempPath = Files.createTempFile("csvformatagenttest", ".csv");
        try {
            final CSVPrinter printer = CSVFormat.DEFAULT.print(tempPath, StandardCharsets.UTF_8);
            assertNotNull(printer);
            closeQuietly(printer);
            assertTrue(Files.exists(tempPath));
        } finally {
            Files.deleteIfExists(tempPath);
        }
    }

    // ---------------------------------------------------------------
    // Builder validation delegated from CSVFormat
    // ---------------------------------------------------------------

    @Test
    public void testBuilderSetCommentMarkerRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.Builder.create().setCommentMarker('\n');
            }
        });
    }

    @Test
    public void testBuilderSetEscapeRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.Builder.create().setEscape('\r');
            }
        });
    }

    @Test
    public void testGetRecordSeparatorDefaultsToCrLf() {
        assertEquals("\r\n", CSVFormat.DEFAULT.getRecordSeparator());
    }

    @Test
    public void testNotEqualsBetweenDistinctPredefinedFormats() {
        assertNotEquals(CSVFormat.MYSQL, CSVFormat.POSTGRESQL_TEXT);
    }
}
