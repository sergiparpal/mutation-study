package org.apache.commons.csv;

import java.io.IOException;
import java.io.StringReader;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class LexerAgentTest {

    private static Lexer newLexer(final String input, final CSVFormat format) {
        return new Lexer(format, new ExtendedBufferedReader(new StringReader(input)));
    }

    // ---- close() / isClosed() ----

    @Test
    public void testIsClosedFalseThenTrueAfterClose() throws IOException {
        final Lexer lexer = newLexer("a,b\n", CSVFormat.DEFAULT);
        assertFalse(lexer.isClosed());
        lexer.close();
        assertTrue(lexer.isClosed());
    }

    // ---- getBytesRead() ----

    @Test
    public void testGetBytesReadStartsAtZero() {
        final Lexer lexer = newLexer("a,b\n", CSVFormat.DEFAULT);
        assertEquals(0L, lexer.getBytesRead());
    }

    // ---- getCharacterPosition() ----

    @Test
    public void testGetCharacterPositionStartsAtZeroAndAdvances() throws IOException {
        final Lexer lexer = newLexer("ab,cd\n", CSVFormat.DEFAULT);
        assertEquals(0L, lexer.getCharacterPosition());
        lexer.nextToken(new Token());
        assertTrue(lexer.getCharacterPosition() > 0L);
    }

    // ---- getCurrentLineNumber() ----

    @Test
    public void testGetCurrentLineNumberStartsAtZeroAndAdvancesPastEol() throws IOException {
        final Lexer lexer = newLexer("a\nb\n", CSVFormat.DEFAULT);
        assertEquals(0L, lexer.getCurrentLineNumber());
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals(1L, lexer.getCurrentLineNumber());
    }

    // ---- getFirstEol() ----

    @Test
    public void testGetFirstEolNullBeforeAnyLineRead() {
        final Lexer lexer = newLexer("a,b\n", CSVFormat.DEFAULT);
        assertNull(lexer.getFirstEol());
    }

    @Test
    public void testGetFirstEolReflectsFirstTerminatorSeen() throws IOException {
        final Lexer lexer = newLexer("a\r\nb\n", CSVFormat.DEFAULT);
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("\r\n", lexer.getFirstEol());
    }

    // ---- isCommentStart(int) ----

    @Test
    public void testIsCommentStartFalseWhenNoMarkerConfigured() {
        final Lexer lexer = newLexer("a,b\n", CSVFormat.DEFAULT);
        assertFalse(lexer.isCommentStart('#'));
    }

    @Test
    public void testIsCommentStartTrueOnlyForConfiguredMarker() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').build();
        final Lexer lexer = newLexer("a,b\n", format);
        assertTrue(lexer.isCommentStart('#'));
        assertFalse(lexer.isCommentStart('a'));
    }

    // ---- isDelimiter(int) ----

    @Test
    public void testIsDelimiterTrueForConfiguredDelimiter() throws IOException {
        final Lexer lexer = newLexer("a,b\n", CSVFormat.DEFAULT);
        assertTrue(lexer.isDelimiter(','));
        assertFalse(lexer.isDelimiter('a'));
    }

    // ---- isEndOfFile(int) ----

    @Test
    public void testIsEndOfFileRecognizesEofSentinelOnly() {
        final Lexer lexer = newLexer("a,b\n", CSVFormat.DEFAULT);
        assertTrue(lexer.isEndOfFile(-1));
        assertFalse(lexer.isEndOfFile('a'));
    }

    // ---- isEscape(int) ----

    @Test
    public void testIsEscapeFalseWhenNoEscapeConfigured() {
        final Lexer lexer = newLexer("a,b\n", CSVFormat.DEFAULT);
        assertFalse(lexer.isEscape('\\'));
    }

    @Test
    public void testIsEscapeTrueOnlyForConfiguredEscapeCharacter() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').build();
        final Lexer lexer = newLexer("a,b\n", format);
        assertTrue(lexer.isEscape('\\'));
        assertFalse(lexer.isEscape('a'));
    }

    // ---- isEscapeDelimiter() ----

    @Test
    public void testIsEscapeDelimiterFalseWhenNoEscapeConfigured() throws IOException {
        final Lexer lexer = newLexer("a,b\n", CSVFormat.DEFAULT);
        assertFalse(lexer.isEscapeDelimiter());
    }

    // ---- isQuoteChar(int) ----

    @Test
    public void testIsQuoteCharMatchesConfiguredQuote() {
        final Lexer lexer = newLexer("\"a\",b\n", CSVFormat.DEFAULT);
        assertTrue(lexer.isQuoteChar('"'));
        assertFalse(lexer.isQuoteChar('\''));
    }

    // ---- isStartOfLine(int) ----

    @Test
    public void testIsStartOfLineTrueForCrAndLf() {
        final Lexer lexer = newLexer("a,b\n", CSVFormat.DEFAULT);
        assertTrue(lexer.isStartOfLine('\n'));
        assertTrue(lexer.isStartOfLine('\r'));
        assertFalse(lexer.isStartOfLine('a'));
    }

    // ---- nextToken(Token) ----

    @Test
    public void testNextTokenReturnsSameTokenInstancePassedIn() throws IOException {
        final Lexer lexer = newLexer("a,b\n", CSVFormat.DEFAULT);
        final Token token = new Token();
        final Token result = lexer.nextToken(token);
        assertSame(token, result);
    }

    @Test
    public void testNextTokenTokenizesSimpleTwoFieldRecord() throws IOException {
        final Lexer lexer = newLexer("a,b\n", CSVFormat.DEFAULT);

        final Token first = new Token();
        lexer.nextToken(first);
        assertEquals(Token.Type.TOKEN, first.type);
        assertEquals("a", first.content.toString());

        final Token second = new Token();
        lexer.nextToken(second);
        assertEquals(Token.Type.EORECORD, second.type);
        assertEquals("b", second.content.toString());

        final Token third = new Token();
        lexer.nextToken(third);
        assertEquals(Token.Type.EOF, third.type);
    }

    @Test
    public void testNextTokenTokenizesMultipleRecords() throws IOException {
        final Lexer lexer = newLexer("a,b\nc,d\n", CSVFormat.DEFAULT);
        final String[] expectedContents = {"a", "b", "c", "d"};
        final Token.Type[] expectedTypes = {Token.Type.TOKEN, Token.Type.EORECORD, Token.Type.TOKEN, Token.Type.EORECORD};

        for (int i = 0; i < expectedContents.length; i++) {
            final Token token = new Token();
            lexer.nextToken(token);
            assertEquals(expectedTypes[i], token.type, "type at index " + i);
            assertEquals(expectedContents[i], token.content.toString(), "content at index " + i);
        }

        final Token eof = new Token();
        lexer.nextToken(eof);
        assertEquals(Token.Type.EOF, eof.type);
    }

    @Test
    public void testNextTokenOnEmptyInputYieldsEofImmediately() throws IOException {
        final Lexer lexer = newLexer("", CSVFormat.DEFAULT);
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.EOF, token.type);
    }

    // ---- readEndOfLine(int) ----

    @Test
    public void testReadEndOfLineTrueForLineFeed() throws IOException {
        final Lexer lexer = newLexer("\n", CSVFormat.DEFAULT);
        assertTrue(lexer.readEndOfLine('\n'));
    }

    @Test
    public void testReadEndOfLineFalseForNonTerminator() throws IOException {
        final Lexer lexer = newLexer("a", CSVFormat.DEFAULT);
        assertFalse(lexer.readEndOfLine('a'));
    }

    // ---- readEscape() ----

    @Test
    public void testReadEscapeReturnsCharacterFollowingEscape() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').build();
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("\\,rest"));
        final Lexer lexer = new Lexer(format, reader);
        reader.read(); // consume the escape character itself, per the method's precondition
        final int unescaped = lexer.readEscape();
        assertEquals((int) ',', unescaped);
    }

    @Test
    public void testReadEscapeAtEndOfStreamThrowsIOException() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').build();
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("\\"));
        final Lexer lexer = new Lexer(format, reader);
        reader.read(); // consume the escape character itself
        assertThrows(IOException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                lexer.readEscape();
            }
        });
    }

    // ---- trimTrailingSpaces(StringBuilder) ----

    @Test
    public void testTrimTrailingSpacesRemovesOnlyTrailingWhitespace() {
        final Lexer lexer = newLexer("a,b\n", CSVFormat.DEFAULT);
        final StringBuilder buffer = new StringBuilder("abc   ");
        lexer.trimTrailingSpaces(buffer);
        assertEquals("abc", buffer.toString());
    }

    @Test
    public void testTrimTrailingSpacesNoOpWhenNoTrailingWhitespace() {
        final Lexer lexer = newLexer("a,b\n", CSVFormat.DEFAULT);
        final StringBuilder buffer = new StringBuilder("abc");
        lexer.trimTrailingSpaces(buffer);
        assertEquals("abc", buffer.toString());
    }

    @Test
    public void testTrimTrailingSpacesAllWhitespaceBecomesEmpty() {
        final Lexer lexer = newLexer("a,b\n", CSVFormat.DEFAULT);
        final StringBuilder buffer = new StringBuilder("   ");
        lexer.trimTrailingSpaces(buffer);
        assertEquals(0, buffer.length());
    }
}
