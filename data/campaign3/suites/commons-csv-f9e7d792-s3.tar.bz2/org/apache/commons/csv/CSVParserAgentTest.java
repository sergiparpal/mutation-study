package org.apache.commons.csv;

import java.io.File;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class CSVParserAgentTest {

    private static List<String> values(final CSVRecord record) {
        final List<String> result = new ArrayList<String>();
        for (final String field : record) {
            result.add(field);
        }
        return result;
    }

    // ---- static parse(String, CSVFormat) ----

    @Test
    public void testParseStringProducesExpectedRecords() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b,c\nd,e,f\n", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals(java.util.Arrays.asList("a", "b", "c"), values(records.get(0)));
            assertEquals(java.util.Arrays.asList("d", "e", "f"), values(records.get(1)));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testParseNullStringThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse((String) null, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    public void testParseStringNullFormatMapsToDefault() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n", (CSVFormat) null);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals(java.util.Arrays.asList("a", "b"), values(records.get(0)));
        } finally {
            parser.close();
        }
    }

    // ---- static parse(Reader, CSVFormat) ----

    @Test
    public void testParseReaderNullThrowsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse((Reader) null, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    public void testParseReaderValid() throws IOException {
        final CSVParser parser = CSVParser.parse(new StringReader("x,y\n"), CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
        } finally {
            parser.close();
        }
    }

    // ---- static parse(File, Charset, CSVFormat) ----

    @Test
    public void testParseFileNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse((File) null, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
            }
        });
    }

    // ---- static parse(Path, Charset, CSVFormat) ----

    @Test
    public void testParsePathNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse((Path) null, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
            }
        });
    }

    // ---- static parse(URL, Charset, CSVFormat) ----

    @Test
    public void testParseUrlNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse((URL) null, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
            }
        });
    }

    // ---- deprecated constructors ----

    @Test
    public void testConstructorNullReaderThrowsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new CSVParser((Reader) null, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    public void testConstructorNullFormatThrowsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new CSVParser(new StringReader("a,b\n"), (CSVFormat) null);
            }
        });
    }

    @Test
    public void testConstructorWithOffsetsSetsInitialRecordNumber() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a,b\nc,d\n"), CSVFormat.DEFAULT, 0L, 42L);
        try {
            final CSVRecord record = parser.nextRecord();
            assertNotNull(record);
            assertEquals(42L, parser.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    // ---- builder() ----

    @Test
    public void testBuilderReturnsNewInstanceEachCall() {
        assertNotNull(CSVParser.builder());
        assertNotSame(CSVParser.builder(), CSVParser.builder());
    }

    @Test
    public void testBuilderSetFormatIsFluent() {
        final CSVParser.Builder builder = CSVParser.builder();
        assertSame(builder, builder.setFormat(CSVFormat.DEFAULT));
    }

    @Test
    public void testBuilderSetRecordNumberIsFluent() {
        final CSVParser.Builder builder = CSVParser.builder();
        assertSame(builder, builder.setRecordNumber(5L));
    }

    @Test
    public void testBuilderSetCharacterOffsetIsFluent() {
        final CSVParser.Builder builder = CSVParser.builder();
        assertSame(builder, builder.setCharacterOffset(0L));
    }

    @Test
    public void testBuilderSetByteOffsetIsFluent() {
        final CSVParser.Builder builder = CSVParser.builder();
        assertSame(builder, builder.setByteOffset(0L));
    }

    @Test
    public void testBuilderSetTrackBytesIsFluent() {
        final CSVParser.Builder builder = CSVParser.builder();
        assertSame(builder, builder.setTrackBytes(true));
    }

    @Test
    public void testBuilderGetProducesWorkingParser() throws IOException {
        final CSVParser parser = CSVParser.builder()
                .setReader(new StringReader("1,2,3\n"))
                .setFormat(CSVFormat.DEFAULT)
                .get();
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals(java.util.Arrays.asList("1", "2", "3"), values(records.get(0)));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testBuilderDefaultRecordNumberIsOne() throws IOException {
        final CSVParser parser = CSVParser.builder()
                .setReader(new StringReader("a\n"))
                .setFormat(CSVFormat.DEFAULT)
                .get();
        try {
            final CSVRecord record = parser.nextRecord();
            assertNotNull(record);
            assertEquals(1L, parser.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testBuilderSetRecordNumberAffectsFirstRecordNumber() throws IOException {
        final CSVParser parser = CSVParser.builder()
                .setReader(new StringReader("a\n"))
                .setFormat(CSVFormat.DEFAULT)
                .setRecordNumber(100L)
                .get();
        try {
            final CSVRecord record = parser.nextRecord();
            assertNotNull(record);
            assertEquals(100L, parser.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    // ---- close() / isClosed() ----

    @Test
    public void testIsClosedFalseAfterConstructionAndTrueAfterClose() throws IOException {
        final CSVParser parser = CSVParser.parse("a\n", CSVFormat.DEFAULT);
        assertFalse(parser.isClosed());
        parser.close();
        assertTrue(parser.isClosed());
    }

    @Test
    public void testIteratorYieldsNothingAfterClose() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\nc,d\n", CSVFormat.DEFAULT);
        parser.close();
        final Iterator<CSVRecord> iterator = parser.iterator();
        assertFalse(iterator.hasNext());
        assertThrows(NoSuchElementException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                iterator.next();
            }
        });
    }

    @Test
    public void testStreamYieldsNothingAfterClose() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\nc,d\n", CSVFormat.DEFAULT);
        parser.close();
        assertEquals(0L, parser.stream().count());
    }

    // ---- iterator() / stream() on an open parser ----

    @Test
    public void testIteratorYieldsAllRecordsInOrder() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n2\n3\n", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> iterator = parser.iterator();
            final List<String> firstValues = new ArrayList<String>();
            while (iterator.hasNext()) {
                firstValues.add(iterator.next().get(0));
            }
            assertEquals(java.util.Arrays.asList("1", "2", "3"), firstValues);
            assertFalse(iterator.hasNext());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testStreamCountMatchesRecordCount() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n2\n3\n4\n", CSVFormat.DEFAULT);
        try {
            assertEquals(4L, parser.stream().count());
        } finally {
            parser.close();
        }
    }

    // ---- nextRecord() ----

    @Test
    public void testNextRecordReturnsNullAtEndOfFile() throws IOException {
        final CSVParser parser = CSVParser.parse("", CSVFormat.DEFAULT);
        try {
            assertNull(parser.nextRecord());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testNextRecordExhaustionThenGetRecordsIsEmpty() throws IOException {
        final CSVParser parser = CSVParser.parse("a\nb\n", CSVFormat.DEFAULT);
        try {
            while (parser.nextRecord() != null) {
                // drain
            }
            final List<CSVRecord> remaining = parser.getRecords();
            assertNotNull(remaining);
            assertTrue(remaining.isEmpty());
        } finally {
            parser.close();
        }
    }

    // ---- line / record numbers ----

    @Test
    public void testGetCurrentLineNumberAdvancesWithLines() throws IOException {
        final CSVParser parser = CSVParser.parse("a\nb\nc\n", CSVFormat.DEFAULT);
        try {
            assertEquals(0L, parser.getCurrentLineNumber());
            parser.nextRecord();
            assertEquals(1L, parser.getCurrentLineNumber());
            parser.nextRecord();
            assertEquals(2L, parser.getCurrentLineNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetRecordNumberAdvancesPerRecord() throws IOException {
        final CSVParser parser = CSVParser.parse("a\nb\n", CSVFormat.DEFAULT);
        try {
            assertEquals(0L, parser.getRecordNumber());
            parser.nextRecord();
            assertEquals(1L, parser.getRecordNumber());
            parser.nextRecord();
            assertEquals(2L, parser.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    // ---- getFirstEndOfLine() ----

    @Test
    public void testGetFirstEndOfLineDetectsLineFeed() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\nc,d\n", CSVFormat.DEFAULT);
        try {
            parser.getRecords();
            assertEquals("\n", parser.getFirstEndOfLine());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetFirstEndOfLineDetectsCarriageReturnLineFeed() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\r\nc,d\r\n", CSVFormat.DEFAULT);
        try {
            parser.getRecords();
            assertEquals("\r\n", parser.getFirstEndOfLine());
        } finally {
            parser.close();
        }
    }

    // ---- header map / header names ----

    @Test
    public void testGetHeaderMapEmptyWhenNoHeaderConfigured() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n", CSVFormat.DEFAULT);
        try {
            final Map<String, Integer> headerMap = parser.getHeaderMap();
            assertNotNull(headerMap);
            assertTrue(headerMap.isEmpty());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetHeaderMapReflectsConfiguredHeader() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("A", "B").setSkipHeaderRecord(true).build();
        final CSVParser parser = CSVParser.parse("A,B\n1,2\n", format);
        try {
            final Map<String, Integer> headerMap = parser.getHeaderMap();
            assertEquals(Integer.valueOf(0), headerMap.get("A"));
            assertEquals(Integer.valueOf(1), headerMap.get("B"));
            assertEquals(java.util.Arrays.asList("A", "B"), parser.getHeaderNames());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetHeaderMapReturnsFreshCopyEachCall() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("A").setSkipHeaderRecord(true).build();
        final CSVParser parser = CSVParser.parse("A\n1\n", format);
        try {
            final Map<String, Integer> first = parser.getHeaderMap();
            final Map<String, Integer> second = parser.getHeaderMap();
            assertEquals(first, second);
            assertNotSame(first, second);
            first.put("MUTATED", 99);
            assertFalse(parser.getHeaderMap().containsKey("MUTATED"));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetHeaderMapRawIsStableAcrossCalls() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("A").setSkipHeaderRecord(true).build();
        final CSVParser parser = CSVParser.parse("A\n1\n", format);
        try {
            final Map<String, Integer> raw1 = parser.getHeaderMapRaw();
            final Map<String, Integer> raw2 = parser.getHeaderMapRaw();
            assertSame(raw1, raw2);
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetHeaderNamesIsReadOnly() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("A", "B").setSkipHeaderRecord(true).build();
        final CSVParser parser = CSVParser.parse("A,B\n1,2\n", format);
        try {
            final List<String> headerNames = parser.getHeaderNames();
            assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
                @Override
                public void execute() {
                    headerNames.add("C");
                }
            });
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetHeaderNamesEmptyWhenNoHeaderConfigured() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n", CSVFormat.DEFAULT);
        try {
            assertTrue(parser.getHeaderNames().isEmpty());
        } finally {
            parser.close();
        }
    }

    // ---- header / trailer comments ----

    @Test
    public void testHasHeaderCommentFalseAndCommentNullWhenAbsent() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n", CSVFormat.DEFAULT);
        try {
            parser.getRecords();
            assertFalse(parser.hasHeaderComment());
            assertNull(parser.getHeaderComment());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testHasTrailerCommentFalseAndCommentNullWhenAbsent() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n", CSVFormat.DEFAULT);
        try {
            parser.getRecords();
            assertFalse(parser.hasTrailerComment());
            assertNull(parser.getTrailerComment());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testHeaderCommentDetectedWhenPresent() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').build();
        final CSVParser parser = CSVParser.parse("# header comment\na,b\n", format);
        try {
            parser.getRecords();
            assertTrue(parser.hasHeaderComment());
            assertEquals("header comment", parser.getHeaderComment());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testTrailerCommentDetectedWhenPresent() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').build();
        final CSVParser parser = CSVParser.parse("a,b\n# trailer comment\n", format);
        try {
            parser.getRecords();
            assertTrue(parser.hasTrailerComment());
            assertEquals("trailer comment", parser.getTrailerComment());
        } finally {
            parser.close();
        }
    }

    // ---- getRecords() ----

    @Test
    public void testGetRecordsOnEmptyInputReturnsEmptyList() throws IOException {
        final CSVParser parser = CSVParser.parse("", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertNotNull(records);
            assertTrue(records.isEmpty());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetRecordsStartsAtCurrentPosition() throws IOException {
        final CSVParser parser = CSVParser.parse("a\nb\nc\n", CSVFormat.DEFAULT);
        try {
            final CSVRecord first = parser.nextRecord();
            assertEquals("a", first.get(0));
            final List<CSVRecord> rest = parser.getRecords();
            assertEquals(2, rest.size());
            assertEquals("b", rest.get(0).get(0));
            assertEquals("c", rest.get(1).get(0));
        } finally {
            parser.close();
        }
    }
}
