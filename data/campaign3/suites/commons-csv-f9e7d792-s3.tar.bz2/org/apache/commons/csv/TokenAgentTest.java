package org.apache.commons.csv;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class TokenAgentTest {

    @Test
    public void testNewTokenHasNonNullEmptyContent() {
        final Token token = new Token();
        assertNotNull(token.content);
        assertEquals(0, token.content.length());
    }

    @Test
    public void testNewTokenIsInInitializedState() {
        // Per Token.Type.INVALID javadoc: "Token has no valid content, that is, is in its
        // initialized state", so a freshly constructed Token should carry type INVALID.
        final Token token = new Token();
        assertEquals(Token.Type.INVALID, token.type);
    }

    @Test
    public void testNewTokenDefaultFlagsAreFalse() {
        final Token token = new Token();
        assertFalse(token.isReady);
        assertFalse(token.isQuoted);
        assertFalse(token.isEscaped);
    }

    @Test
    public void testContentBufferIsMutableAndRetainsAppendedData() {
        final Token token = new Token();
        token.content.append("abc");
        assertEquals("abc", token.content.toString());
        assertEquals(3, token.content.length());
    }

    @Test
    public void testContentFieldReferenceIsStable() {
        // The content field is documented as final, so the same StringBuilder instance
        // must be returned on every access.
        final Token token = new Token();
        final StringBuilder first = token.content;
        token.content.append("x");
        final StringBuilder second = token.content;
        assertSame(first, second);
    }

    @Test
    public void testResetRestoresInitializedState() {
        final Token token = new Token();
        token.type = Token.Type.TOKEN;
        token.content.append("some data");
        token.isReady = true;
        token.isQuoted = true;
        token.isEscaped = true;

        token.reset();

        assertEquals(Token.Type.INVALID, token.type);
        assertEquals(0, token.content.length());
        assertFalse(token.isReady);
        assertFalse(token.isQuoted);
        assertFalse(token.isEscaped);
    }

    @Test
    public void testResetOnAlreadyFreshTokenIsIdempotent() {
        final Token token = new Token();
        token.reset();
        assertEquals(Token.Type.INVALID, token.type);
        assertEquals(0, token.content.length());
        assertFalse(token.isReady);
        assertFalse(token.isQuoted);
        assertFalse(token.isEscaped);
    }

    @Test
    public void testToStringIsNotNull() {
        final Token token = new Token();
        assertNotNull(token.toString());
    }

    @Test
    public void testToStringReflectsTokenState() {
        // toString() is documented to convert "the token state" to a string, implying the
        // result changes when the state (e.g. content) changes.
        final Token fresh = new Token();
        final String freshRepresentation = fresh.toString();

        final Token populated = new Token();
        populated.type = Token.Type.EORECORD;
        populated.content.append("some distinguishable payload");
        final String populatedRepresentation = populated.toString();

        assertNotSame(freshRepresentation, populatedRepresentation);
        assertFalse(freshRepresentation.equals(populatedRepresentation));
    }

    @Test
    public void testTypeFieldAssignableToEachEnumConstant() {
        final Token token = new Token();
        for (final Token.Type type : Token.Type.values()) {
            token.type = type;
            assertEquals(type, token.type);
        }
    }

    @Test
    public void testTokenTypeValuesOrderAndCount() {
        final Token.Type[] values = Token.Type.values();
        assertEquals(5, values.length);
        assertEquals(Token.Type.INVALID, values[0]);
        assertEquals(Token.Type.TOKEN, values[1]);
        assertEquals(Token.Type.EOF, values[2]);
        assertEquals(Token.Type.EORECORD, values[3]);
        assertEquals(Token.Type.COMMENT, values[4]);
    }

    @Test
    public void testTokenTypeValuesReturnsIndependentArray() {
        final Token.Type[] first = Token.Type.values();
        first[0] = Token.Type.COMMENT;
        final Token.Type[] second = Token.Type.values();
        assertEquals(Token.Type.INVALID, second[0]);
    }

    @Test
    public void testTokenTypeOrdinalsMatchDeclarationOrder() {
        assertEquals(0, Token.Type.INVALID.ordinal());
        assertEquals(1, Token.Type.TOKEN.ordinal());
        assertEquals(2, Token.Type.EOF.ordinal());
        assertEquals(3, Token.Type.EORECORD.ordinal());
        assertEquals(4, Token.Type.COMMENT.ordinal());
    }

    @Test
    public void testTokenTypeValueOfReturnsMatchingConstant() {
        assertSame(Token.Type.TOKEN, Token.Type.valueOf("TOKEN"));
        assertSame(Token.Type.EOF, Token.Type.valueOf("EOF"));
        assertSame(Token.Type.EORECORD, Token.Type.valueOf("EORECORD"));
        assertSame(Token.Type.COMMENT, Token.Type.valueOf("COMMENT"));
        assertSame(Token.Type.INVALID, Token.Type.valueOf("INVALID"));
    }

    @Test
    public void testTokenTypeValueOfRejectsUnknownName() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Token.Type.valueOf("NOT_A_REAL_TYPE");
            }
        });
    }

    @Test
    public void testTokenTypeValueOfRejectsNull() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Token.Type.valueOf(null);
            }
        });
    }

    @Test
    public void testTokenTypeValueOfRejectsWrongCase() {
        // The javadoc states the name must match exactly; lower-case must not resolve.
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Token.Type.valueOf("token");
            }
        });
    }

    @Test
    public void testTokenTypeToStringMatchesName() {
        assertEquals("TOKEN", Token.Type.TOKEN.toString());
        assertEquals("INVALID", Token.Type.INVALID.name());
    }
}
