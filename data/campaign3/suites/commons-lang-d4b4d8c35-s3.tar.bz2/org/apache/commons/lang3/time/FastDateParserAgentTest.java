package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link FastDateParser}, driven by the documented
 * contract in the javadoc (api/org/apache/commons/lang3/time/FastDateParser.html).
 */
public class FastDateParserAgentTest {

    private static final TimeZone UTC = TimeZone.getTimeZone("UTC");

    private static Date utcDate(int year, int month, int day, int hour, int minute, int second) {
        Calendar cal = new GregorianCalendar(UTC, Locale.US);
        cal.clear();
        cal.set(year, month, day, hour, minute, second);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTime();
    }

    // ---- constructor / accessor contract ----

    @Test
    public void testGetPatternReturnsConstructorPattern() {
        FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        assertEquals("yyyy-MM-dd", parser.getPattern());
    }

    @Test
    public void testGetTimeZoneReturnsConstructorTimeZone() {
        TimeZone tz = TimeZone.getTimeZone("GMT+02:00");
        FastDateParser parser = new FastDateParser("yyyy-MM-dd", tz, Locale.US);
        assertEquals(tz, parser.getTimeZone());
    }

    @Test
    public void testGetLocaleReturnsConstructorLocale() {
        FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.GERMANY);
        assertEquals(Locale.GERMANY, parser.getLocale());
    }

    @Test
    public void testFourArgConstructorNullLocaleMapsToDefault() {
        Locale defaultLocale = Locale.getDefault();
        FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, null, new Date());
        assertEquals(defaultLocale, parser.getLocale());
    }

    @Test
    public void testConstructorNullPatternThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new FastDateParser(null, UTC, Locale.US);
            }
        });
    }

    @Test
    public void testConstructorNullTimeZoneThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new FastDateParser("yyyy-MM-dd", null, Locale.US);
            }
        });
    }

    @Test
    public void testImplementsDateParserAndSerializable() {
        FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        assertTrue(parser instanceof DateParser);
        assertTrue(parser instanceof java.io.Serializable);
    }

    // ---- basic parse(String) ----

    @Test
    public void testParseSimpleDate() throws ParseException {
        FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        Date result = parser.parse("2017-06-21");
        assertEquals(utcDate(2017, Calendar.JUNE, 21, 0, 0, 0), result);
    }

    @Test
    public void testParseDateTimeWithExplicitZoneOverridesDefaultZone() throws ParseException {
        FastDateParser parser = new FastDateParser("yyyy-MM-dd'T'HH:mm:ssZ", TimeZone.getTimeZone("GMT"), Locale.US);
        Date result = parser.parse("2020-06-01T12:00:00+0200");
        Calendar expectedCal = new GregorianCalendar(TimeZone.getTimeZone("GMT+02:00"), Locale.US);
        expectedCal.clear();
        expectedCal.set(2020, Calendar.JUNE, 1, 12, 0, 0);
        assertEquals(expectedCal.getTime(), result);
    }

    @Test
    public void testParseUsesConfiguredTimeZoneWhenPatternHasNoZone() throws ParseException {
        TimeZone plusFive = TimeZone.getTimeZone("GMT+05:00");
        FastDateParser parser = new FastDateParser("yyyy-MM-dd'T'HH:mm:ss", plusFive, Locale.US);
        Date result = parser.parse("2020-01-01T10:00:00");
        Calendar expectedCal = new GregorianCalendar(plusFive, Locale.US);
        expectedCal.clear();
        expectedCal.set(2020, Calendar.JANUARY, 1, 10, 0, 0);
        assertEquals(expectedCal.getTime(), result);
    }

    @Test
    public void testLenientModeNormalizesOutOfRangeMinutes() throws ParseException {
        // Class-level javadoc: "a time of 90 minutes is treated as 1 hour 30 minutes."
        FastDateParser parser = new FastDateParser("yyyy-MM-dd HH:mm", UTC, Locale.US);
        Date result = parser.parse("2020-01-01 10:90");
        assertEquals(utcDate(2020, Calendar.JANUARY, 1, 11, 30, 0), result);
    }

    @Test
    public void testParseThrowsParseExceptionOnUnparsableString() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                parser.parse("not-a-date");
            }
        });
    }

    @Test
    public void testParseThrowsParseExceptionOnEmptyString() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                parser.parse("");
            }
        });
    }

    // ---- parse(String, ParsePosition) ----

    @Test
    public void testParseWithParsePositionUpdatesIndexOnSuccessAndStopsAtPatternEnd() {
        FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        ParsePosition pos = new ParsePosition(0);
        Date result = parser.parse("2020-01-01 extra text", pos);
        assertNotNull(result);
        assertEquals(utcDate(2020, Calendar.JANUARY, 1, 0, 0, 0), result);
        assertEquals(10, pos.getIndex());
    }

    @Test
    public void testParseWithParsePositionReturnsNullAndDoesNotAdvanceIndexOnFailure() {
        FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        ParsePosition pos = new ParsePosition(0);
        Date result = parser.parse("not-a-date", pos);
        assertNull(result);
        assertEquals(0, pos.getIndex());
        assertTrue(pos.getErrorIndex() >= 0);
    }

    // ---- parse(String, ParsePosition, Calendar) ----

    @Test
    public void testParseWithCalendarReturnsTrueAndPopulatesFieldsOnSuccess() {
        FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        Calendar calendar = new GregorianCalendar(UTC, Locale.US);
        calendar.clear();
        ParsePosition pos = new ParsePosition(0);
        boolean result = parser.parse("2020-03-15", pos, calendar);
        assertTrue(result);
        assertEquals(10, pos.getIndex());
        assertEquals(2020, calendar.get(Calendar.YEAR));
        assertEquals(Calendar.MARCH, calendar.get(Calendar.MONTH));
        assertEquals(15, calendar.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void testParseWithCalendarReturnsFalseAndSetsErrorIndexOnFailure() {
        FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        Calendar calendar = new GregorianCalendar(UTC, Locale.US);
        ParsePosition pos = new ParsePosition(0);
        boolean result = parser.parse("abcd", pos, calendar);
        assertFalse(result);
        assertEquals(0, pos.getIndex());
        assertTrue(pos.getErrorIndex() >= 0);
    }

    @Test
    public void testParseWithNonLenientCalendarThrowsIllegalArgumentExceptionOnOutOfRangeField() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final Calendar calendar = new GregorianCalendar(UTC, Locale.US);
        calendar.clear();
        calendar.setLenient(false);
        final ParsePosition pos = new ParsePosition(0);
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                // February 30th does not exist.
                parser.parse("2020-02-30", pos, calendar);
            }
        });
    }

    @Test
    public void testParseWithLenientCalendarNormalizesOutOfRangeDayOfMonth() {
        FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        Calendar calendar = new GregorianCalendar(UTC, Locale.US);
        calendar.clear();
        ParsePosition pos = new ParsePosition(0);
        boolean result = parser.parse("2020-02-30", pos, calendar);
        assertTrue(result);

        Calendar expectedCal = new GregorianCalendar(UTC, Locale.US);
        expectedCal.clear();
        expectedCal.set(Calendar.YEAR, 2020);
        expectedCal.set(Calendar.MONTH, Calendar.FEBRUARY);
        expectedCal.set(Calendar.DAY_OF_MONTH, 30);

        assertEquals(expectedCal.getTime(), calendar.getTime());
    }

    // ---- parseObject ----

    @Test
    public void testParseObjectStringReturnsDate() throws ParseException {
        FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        Object result = parser.parseObject("2017-06-21");
        assertTrue(result instanceof Date);
        assertEquals(utcDate(2017, Calendar.JUNE, 21, 0, 0, 0), result);
    }

    @Test
    public void testParseObjectStringThrowsParseExceptionOnInvalidInput() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                parser.parseObject("garbage");
            }
        });
    }

    @Test
    public void testParseObjectWithParsePositionReturnsDate() {
        FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        ParsePosition pos = new ParsePosition(0);
        Object result = parser.parseObject("2017-06-21", pos);
        assertTrue(result instanceof Date);
        assertEquals(utcDate(2017, Calendar.JUNE, 21, 0, 0, 0), result);
        assertEquals(10, pos.getIndex());
    }

    // ---- two digit year / centuryStart ----

    @Test
    public void testTwoDigitYearIsResolvedWithinCenturyStartWindow() throws ParseException {
        Date centuryStart = utcDate(1950, Calendar.JANUARY, 1, 0, 0, 0);
        FastDateParser parser = new FastDateParser("yy-MM-dd", UTC, Locale.US, centuryStart);

        int[] twoDigitYears = {0, 49, 50, 99};
        for (int i = 0; i < twoDigitYears.length; i++) {
            int twoDigitYear = twoDigitYears[i];
            String source = String.format("%02d-01-01", twoDigitYear);
            Date parsed = parser.parse(source);
            Calendar cal = new GregorianCalendar(UTC, Locale.US);
            cal.setTime(parsed);
            int fullYear = cal.get(Calendar.YEAR);
            assertTrue(fullYear >= 1950 && fullYear <= 2049,
                    "year " + fullYear + " for input " + twoDigitYear + " out of expected century window");
            assertEquals(twoDigitYear, fullYear % 100);
        }
    }

    // ---- equals / hashCode ----

    @Test
    public void testEqualsIsReflexive() {
        FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        assertTrue(parser.equals(parser));
    }

    @Test
    public void testEqualsNullIsFalse() {
        FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        assertFalse(parser.equals(null));
    }

    @Test
    public void testEqualsDifferentTypeIsFalse() {
        FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        assertFalse(parser.equals("yyyy-MM-dd"));
    }

    @Test
    public void testEqualsAndHashCodeForEquivalentConfiguration() {
        FastDateParser parser1 = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        FastDateParser parser2 = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        assertTrue(parser1.equals(parser2));
        assertTrue(parser2.equals(parser1));
        assertEquals(parser1.hashCode(), parser2.hashCode());
    }

    @Test
    public void testEqualsDistinguishesDifferentPattern() {
        FastDateParser parser1 = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        FastDateParser parser2 = new FastDateParser("dd/MM/yyyy", UTC, Locale.US);
        assertFalse(parser1.equals(parser2));
    }

    @Test
    public void testEqualsDistinguishesDifferentLocale() {
        FastDateParser parser1 = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        FastDateParser parser2 = new FastDateParser("yyyy-MM-dd", UTC, Locale.GERMANY);
        assertFalse(parser1.equals(parser2));
    }

    @Test
    public void testHashCodeIsConsistent() {
        FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        int first = parser.hashCode();
        int second = parser.hashCode();
        assertEquals(first, second);
    }

    // ---- toString / toStringAll ----

    @Test
    public void testToStringIsNonNullAndDeterministic() {
        FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        String s1 = parser.toString();
        String s2 = parser.toString();
        assertNotNull(s1);
        assertFalse(s1.isEmpty());
        assertEquals(s1, s2);
    }

    @Test
    public void testToStringAllIsNonNullAndContainsPattern() {
        FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        String all = parser.toStringAll();
        assertNotNull(all);
        assertFalse(all.isEmpty());
        assertTrue(all.contains("yyyy-MM-dd"));
    }

    // ---- clear() cache ----

    @Test
    public void testClearDoesNotBreakSubsequentParsing() throws ParseException {
        FastDateParser.clear();
        FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        Date before = parser.parse("2021-05-05");
        FastDateParser.clear();
        Date after = parser.parse("2021-05-05");
        assertEquals(utcDate(2021, Calendar.MAY, 5, 0, 0, 0), before);
        assertEquals(before, after);
    }

    // ---- Serializable contract ----

    @Test
    public void testSerializationRoundTripPreservesState() throws IOException, ClassNotFoundException, ParseException {
        FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(baos);
        oos.writeObject(parser);
        oos.close();

        ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(baos.toByteArray()));
        FastDateParser deserialized = (FastDateParser) ois.readObject();
        ois.close();

        assertEquals(parser.getPattern(), deserialized.getPattern());
        assertEquals(parser.getTimeZone(), deserialized.getTimeZone());
        assertEquals(parser.getLocale(), deserialized.getLocale());
        assertEquals(parser.parse("2021-05-05"), deserialized.parse("2021-05-05"));
    }
}
