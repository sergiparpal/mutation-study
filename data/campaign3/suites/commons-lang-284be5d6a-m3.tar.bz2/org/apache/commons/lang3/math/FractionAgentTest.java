/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class FractionAgentTest {

    @Test
    public void testGetFractionIntIntBasic() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertEquals(3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionIntIntNotReduced() {
        final Fraction f = Fraction.getFraction(2, 4);
        assertEquals(2, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionNegativeDenominatorMovesSignToNumerator() {
        final Fraction f = Fraction.getFraction(3, -7);
        assertEquals(-3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(1, 0);
            }
        });
    }

    @Test
    public void testGetFractionOverflowOnNegateThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(Integer.MIN_VALUE, -1);
            }
        });
    }

    @Test
    public void testGetFractionWholeNumeratorDenominatorPositiveWhole() {
        final Fraction f = Fraction.getFraction(1, 3, 7);
        assertEquals(10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionWholeNumeratorDenominatorNegativeWhole() {
        final Fraction f = Fraction.getFraction(-1, 3, 7);
        assertEquals(-10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionWholeNegativeDenominatorThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(1, 1, -2);
            }
        });
    }

    @Test
    public void testGetFractionWholeNegativeNumeratorThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(1, -1, 2);
            }
        });
    }

    @Test
    public void testGetFractionWholeOverflowThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(Integer.MAX_VALUE, 1, 1);
            }
        });
    }

    @Test
    public void testGetReducedFractionReducesToLowestTerms() {
        final Fraction f = Fraction.getReducedFraction(2, 4);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetReducedFractionZeroNumeratorIsZeroConstant() {
        final Fraction f = Fraction.getReducedFraction(0, 5);
        assertSame(Fraction.ZERO, f);
    }

    @Test
    public void testGetReducedFractionZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getReducedFraction(1, 0);
            }
        });
    }

    @Test
    public void testGetFractionDoubleHalf() {
        final Fraction f = Fraction.getFraction(0.5d);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetFractionDoubleNegative() {
        final Fraction f = Fraction.getFraction(-0.25d);
        assertEquals(-1, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionDoubleNaNThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(Double.NaN);
            }
        });
    }

    @Test
    public void testGetFractionDoubleTooLargeThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction((double) Integer.MAX_VALUE + 10.0d);
            }
        });
    }

    @Test
    public void testGetFractionStringSimpleWholeNumber() {
        final Fraction f = Fraction.getFraction("5");
        assertEquals(5, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    public void testGetFractionStringFraction() {
        final Fraction f = Fraction.getFraction("3/7");
        assertEquals(3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionStringMixed() {
        final Fraction f = Fraction.getFraction("1 3/7");
        assertEquals(10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionStringDouble() {
        final Fraction f = Fraction.getFraction("0.25");
        assertEquals(1, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionStringNullThrowsNPE() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction((String) null);
            }
        });
    }

    @Test
    public void testGetFractionStringInvalidMixedFormatThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction("1 3-7");
            }
        });
    }

    @Test
    public void testGetFractionStringZeroDenominatorThrowsNFEWithCause() {
        final NumberFormatException nfe = assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction("1/0");
            }
        });
        assertTrue(nfe.getCause() instanceof ArithmeticException);
    }

    @Test
    public void testAddSameDenominator() {
        final Fraction a = Fraction.getFraction(1, 4);
        final Fraction b = Fraction.getFraction(2, 4);
        final Fraction result = a.add(b);
        assertEquals(3, result.getNumerator());
        assertEquals(4, result.getDenominator());
    }

    @Test
    public void testAddDifferentDenominator() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(1, 3);
        final Fraction result = a.add(b);
        assertEquals(5, result.getNumerator());
        assertEquals(6, result.getDenominator());
    }

    @Test
    public void testAddWithZero() {
        final Fraction a = Fraction.getFraction(3, 5);
        final Fraction result = a.add(Fraction.ZERO);
        assertEquals(3, result.getNumerator());
        assertEquals(5, result.getDenominator());
    }

    @Test
    public void testAddNullThrowsNPE() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                a.add(null);
            }
        });
    }

    @Test
    public void testAddOverflowThrows() {
        final Fraction a = Fraction.getFraction(Integer.MAX_VALUE, 1);
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                a.add(Fraction.ONE);
            }
        });
    }

    @Test
    public void testSubtract() {
        final Fraction a = Fraction.getFraction(3, 4);
        final Fraction b = Fraction.getFraction(1, 4);
        final Fraction result = a.subtract(b);
        assertEquals(1, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    @Test
    public void testSubtractNullThrowsNPE() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                a.subtract(null);
            }
        });
    }

    @Test
    public void testMultiplyBy() {
        final Fraction a = Fraction.getFraction(2, 3);
        final Fraction b = Fraction.getFraction(3, 4);
        final Fraction result = a.multiplyBy(b);
        assertEquals(1, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    @Test
    public void testMultiplyByZeroIsZero() {
        final Fraction a = Fraction.getFraction(2, 3);
        final Fraction result = a.multiplyBy(Fraction.ZERO);
        assertSame(Fraction.ZERO, result);
    }

    @Test
    public void testMultiplyByNullThrowsNPE() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                a.multiplyBy(null);
            }
        });
    }

    @Test
    public void testDivideBy() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(1, 4);
        final Fraction result = a.divideBy(b);
        assertEquals(2, result.getNumerator());
        assertEquals(1, result.getDenominator());
    }

    @Test
    public void testDivideByZeroThrows() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                a.divideBy(Fraction.ZERO);
            }
        });
    }

    @Test
    public void testDivideByNullThrowsNPE() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                a.divideBy(null);
            }
        });
    }

    @Test
    public void testInvertPositive() {
        final Fraction a = Fraction.getFraction(2, 5);
        final Fraction inv = a.invert();
        assertEquals(5, inv.getNumerator());
        assertEquals(2, inv.getDenominator());
    }

    @Test
    public void testInvertNegativeKeepsSignOnNumerator() {
        final Fraction a = Fraction.getFraction(-2, 5);
        final Fraction inv = a.invert();
        assertEquals(-5, inv.getNumerator());
        assertEquals(2, inv.getDenominator());
    }

    @Test
    public void testInvertZeroThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.ZERO.invert();
            }
        });
    }

    @Test
    public void testInvertMinValueNumeratorThrows() {
        final Fraction a = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                a.invert();
            }
        });
    }

    @Test
    public void testNegate() {
        final Fraction a = Fraction.getFraction(3, 5);
        final Fraction result = a.negate();
        assertEquals(-3, result.getNumerator());
        assertEquals(5, result.getDenominator());
    }

    @Test
    public void testNegateMinValueThrows() {
        final Fraction a = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                a.negate();
            }
        });
    }

    @Test
    public void testAbsOnPositiveReturnsSameInstance() {
        final Fraction a = Fraction.getFraction(3, 5);
        assertSame(a, a.abs());
    }

    @Test
    public void testAbsOnNegative() {
        final Fraction a = Fraction.getFraction(-3, 5);
        final Fraction result = a.abs();
        assertEquals(3, result.getNumerator());
        assertEquals(5, result.getDenominator());
    }

    @Test
    public void testPowZeroIsOne() {
        final Fraction a = Fraction.getFraction(3, 5);
        assertSame(Fraction.ONE, a.pow(0));
    }

    @Test
    public void testPowOneReturnsSameInstance() {
        final Fraction a = Fraction.getFraction(3, 5);
        assertSame(a, a.pow(1));
    }

    @Test
    public void testPowPositive() {
        final Fraction a = Fraction.getFraction(2, 3);
        final Fraction result = a.pow(3);
        assertEquals(8, result.getNumerator());
        assertEquals(27, result.getDenominator());
    }

    @Test
    public void testPowNegative() {
        final Fraction a = Fraction.getFraction(2, 3);
        final Fraction result = a.pow(-1);
        assertEquals(3, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    @Test
    public void testPowMinValue() {
        final Fraction result = Fraction.ONE.pow(Integer.MIN_VALUE);
        assertEquals(1, result.getNumerator());
        assertEquals(1, result.getDenominator());
    }

    @Test
    public void testReduceAlreadyReducedReturnsSameInstance() {
        final Fraction a = Fraction.getFraction(3, 5);
        assertSame(a, a.reduce());
    }

    @Test
    public void testReduceReducesFraction() {
        final Fraction a = Fraction.getFraction(4, 8);
        final Fraction result = a.reduce();
        assertEquals(1, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    @Test
    public void testReduceZeroNumeratorReturnsZeroConstant() {
        final Fraction a = Fraction.getFraction(0, 5);
        assertSame(Fraction.ZERO, a.reduce());
    }

    @Test
    public void testCompareToEqualValuesDifferentRepresentation() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(2, 4);
        assertEquals(0, a.compareTo(b));
    }

    @Test
    public void testCompareToLessThan() {
        final Fraction a = Fraction.getFraction(1, 3);
        final Fraction b = Fraction.getFraction(1, 2);
        assertTrue(a.compareTo(b) < 0);
    }

    @Test
    public void testCompareToGreaterThan() {
        final Fraction a = Fraction.getFraction(2, 3);
        final Fraction b = Fraction.getFraction(1, 2);
        assertTrue(a.compareTo(b) > 0);
    }

    @Test
    public void testCompareToSameInstance() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertEquals(0, a.compareTo(a));
    }

    @Test
    public void testCompareToNullThrowsNPE() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                a.compareTo(null);
            }
        });
    }

    @Test
    public void testEqualsSameValueDifferentRepresentationNotEqual() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(2, 4);
        assertNotEquals(a, b);
    }

    @Test
    public void testEqualsSameRepresentation() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(1, 2);
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    public void testEqualsNullIsFalse() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertFalse(a.equals(null));
    }

    @Test
    public void testEqualsDifferentTypeIsFalse() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertFalse(a.equals("1/2"));
    }

    @Test
    public void testEqualsSelf() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertTrue(a.equals(a));
    }

    @Test
    public void testToString() {
        final Fraction a = Fraction.getFraction(-3, 7);
        assertEquals("-3/7", a.toString());
    }

    @Test
    public void testToProperStringZero() {
        assertEquals("0", Fraction.getFraction(0, 5).toProperString());
    }

    @Test
    public void testToProperStringWholeOne() {
        final Fraction a = Fraction.getFraction(4, 4);
        assertEquals("1", a.toProperString());
    }

    @Test
    public void testToProperStringNegativeOne() {
        final Fraction a = Fraction.getFraction(-4, 4);
        assertEquals("-1", a.toProperString());
    }

    @Test
    public void testToProperStringImproperPositive() {
        final Fraction a = Fraction.getFraction(7, 4);
        assertEquals("1 3/4", a.toProperString());
    }

    @Test
    public void testToProperStringImproperNegative() {
        final Fraction a = Fraction.getFraction(-7, 4);
        assertEquals("-1 3/4", a.toProperString());
    }

    @Test
    public void testToProperStringProperFraction() {
        final Fraction a = Fraction.getFraction(3, 4);
        assertEquals("3/4", a.toProperString());
    }

    @Test
    public void testIntValueTruncatesTowardZero() {
        final Fraction a = Fraction.getFraction(7, 4);
        assertEquals(1, a.intValue());
        final Fraction b = Fraction.getFraction(-7, 4);
        assertEquals(-1, b.intValue());
    }

    @Test
    public void testLongValue() {
        final Fraction a = Fraction.getFraction(10, 4);
        assertEquals(2L, a.longValue());
    }

    @Test
    public void testFloatValue() {
        final Fraction a = Fraction.getFraction(1, 4);
        assertEquals(0.25f, a.floatValue(), 0.0f);
    }

    @Test
    public void testDoubleValue() {
        final Fraction a = Fraction.getFraction(1, 4);
        assertEquals(0.25d, a.doubleValue(), 0.0d);
    }

    @Test
    public void testGetProperNumeratorPositive() {
        final Fraction a = Fraction.getFraction(7, 4);
        assertEquals(3, a.getProperNumerator());
    }

    @Test
    public void testGetProperNumeratorNegative() {
        final Fraction a = Fraction.getFraction(-7, 4);
        assertEquals(3, a.getProperNumerator());
    }

    @Test
    public void testGetProperWholePositive() {
        final Fraction a = Fraction.getFraction(7, 4);
        assertEquals(1, a.getProperWhole());
    }

    @Test
    public void testGetProperWholeNegative() {
        final Fraction a = Fraction.getFraction(-7, 4);
        assertEquals(-1, a.getProperWhole());
    }

    @Test
    public void testConstantsHaveExpectedValues() {
        assertEquals(0, Fraction.ZERO.getNumerator());
        assertEquals(1, Fraction.ZERO.getDenominator());
        assertEquals(1, Fraction.ONE.getNumerator());
        assertEquals(1, Fraction.ONE.getDenominator());
        assertEquals(1, Fraction.ONE_HALF.getNumerator());
        assertEquals(2, Fraction.ONE_HALF.getDenominator());
        assertEquals(4, Fraction.FOUR_FIFTHS.getNumerator());
        assertEquals(5, Fraction.FOUR_FIFTHS.getDenominator());
    }
}
