package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link CSVFormat} based solely on the generated javadoc contract.
 */
public class CSVFormatAgentTest {

    private enum SampleHeader {
        Name, Email, Phone
    }

    // ---------------------------------------------------------------
    // Predefined formats
    // ---------------------------------------------------------------

    @Test
    public void testDefaultFormat() {
        CSVFormat format = CSVFormat.DEFAULT;
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertTrue(format.getIgnoreEmptyLines());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
        assertNull(format.getEscapeCharacter());
        assertFalse(format.isEscapeCharacterSet());
        assertNull(format.getNullString());
        assertFalse(format.isNullStringSet());
        assertNull(format.getCommentMarker());
        assertFalse(format.isCommentMarkerSet());
        assertFalse(format.getAllowMissingColumnNames());
        assertFalse(format.getTrailingData());
        assertFalse(format.getLenientEof());
        assertFalse(format.getTrailingDelimiter());
        assertFalse(format.getTrim());
        assertFalse(format.getAutoFlush());
        assertFalse(format.getSkipHeaderRecord());
        assertEquals(0L, format.getMaxRows());
        assertNull(format.getHeader());
    }

    @Test
    public void testExcelFormat() {
        CSVFormat format = CSVFormat.EXCEL;
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
        assertFalse(format.getIgnoreEmptyLines());
        assertTrue(format.getAllowMissingColumnNames());
        assertTrue(format.getTrailingData());
        assertTrue(format.getLenientEof());
    }

    @Test
    public void testRfc4180Format() {
        CSVFormat format = CSVFormat.RFC4180;
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertFalse(format.getIgnoreEmptyLines());
    }

    @Test
    public void testTdfFormat() {
        CSVFormat format = CSVFormat.TDF;
        assertEquals("\t", format.getDelimiterString());
        assertTrue(format.getIgnoreSurroundingSpaces());
    }

    @Test
    public void testMySqlFormat() {
        CSVFormat format = CSVFormat.MYSQL;
        assertEquals("\t", format.getDelimiterString());
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
        assertFalse(format.getIgnoreEmptyLines());
        assertNull(format.getQuoteCharacter());
        assertFalse(format.isQuoteCharacterSet());
        assertEquals("\n", format.getRecordSeparator());
        assertEquals("\\N", format.getNullString());
        assertTrue(format.isNullStringSet());
        assertEquals(QuoteMode.ALL_NON_NULL, format.getQuoteMode());
    }

    @Test
    public void testOracleFormat() {
        CSVFormat format = CSVFormat.ORACLE;
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
        assertFalse(format.getIgnoreEmptyLines());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\\N", format.getNullString());
        assertTrue(format.getTrim());
        assertEquals(System.lineSeparator(), format.getRecordSeparator());
        assertEquals(QuoteMode.MINIMAL, format.getQuoteMode());
    }

    @Test
    public void testPostgresCsvFormat() {
        CSVFormat format = CSVFormat.POSTGRESQL_CSV;
        assertEquals(",", format.getDelimiterString());
        assertNull(format.getEscapeCharacter());
        assertFalse(format.getIgnoreEmptyLines());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\n", format.getRecordSeparator());
        assertEquals("", format.getNullString());
        assertTrue(format.isNullStringSet());
        assertEquals(QuoteMode.ALL_NON_NULL, format.getQuoteMode());
    }

    @Test
    public void testPostgresTextFormat() {
        CSVFormat format = CSVFormat.POSTGRESQL_TEXT;
        assertEquals("\t", format.getDelimiterString());
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
        assertFalse(format.getIgnoreEmptyLines());
        assertNull(format.getQuoteCharacter());
        assertEquals("\n", format.getRecordSeparator());
        assertEquals("\\N", format.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, format.getQuoteMode());
    }

    @Test
    public void testMongoDbCsvFormat() {
        CSVFormat format = CSVFormat.MONGODB_CSV;
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getEscapeCharacter());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals(QuoteMode.MINIMAL, format.getQuoteMode());
    }

    @Test
    public void testMongoDbTsvFormat() {
        CSVFormat format = CSVFormat.MONGODB_TSV;
        assertEquals("\t", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getEscapeCharacter());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals(QuoteMode.MINIMAL, format.getQuoteMode());
        assertFalse(format.getSkipHeaderRecord());
    }

    @Test
    public void testInformixUnloadFormat() {
        CSVFormat format = CSVFormat.INFORMIX_UNLOAD;
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\n", format.getRecordSeparator());
    }

    @Test
    public void testInformixUnloadCsvFormat() {
        CSVFormat format = CSVFormat.INFORMIX_UNLOAD_CSV;
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\n", format.getRecordSeparator());
    }

    // ---------------------------------------------------------------
    // Predefined enum
    // ---------------------------------------------------------------

    @Test
    public void testPredefinedEnumValuesCount() {
        assertEquals(12, CSVFormat.Predefined.values().length);
    }

    @Test
    public void testPredefinedEnumGetFormat() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.Predefined.valueOf("Default").getFormat());
        assertEquals(CSVFormat.EXCEL, CSVFormat.Predefined.valueOf("Excel").getFormat());
        assertEquals(CSVFormat.TDF, CSVFormat.Predefined.valueOf("TDF").getFormat());
    }

    @Test
    public void testPredefinedEnumValueOfRejectsUnknownName() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.Predefined.valueOf("NoSuchFormat");
            }
        });
    }

    @Test
    public void testPredefinedEnumValueOfRejectsNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.Predefined.valueOf(null);
            }
        });
    }

    // ---------------------------------------------------------------
    // newFormat / valueOf
    // ---------------------------------------------------------------

    @Test
    public void testNewFormatInitializesOnlyDelimiter() {
        CSVFormat format = CSVFormat.newFormat(';');
        assertEquals(";", format.getDelimiterString());
        assertNull(format.getQuoteCharacter());
        assertFalse(format.isQuoteCharacterSet());
        assertNull(format.getEscapeCharacter());
        assertNull(format.getCommentMarker());
        assertNull(format.getNullString());
        assertNull(format.getRecordSeparator());
        assertNull(format.getHeader());
        assertNull(format.getHeaderComments());
        assertNull(format.getQuoteMode());
        assertFalse(format.getIgnoreEmptyLines());
        assertFalse(format.getIgnoreHeaderCase());
        assertFalse(format.getIgnoreSurroundingSpaces());
        assertFalse(format.getAllowMissingColumnNames());
        assertFalse(format.getSkipHeaderRecord());
        assertFalse(format.getTrailingDelimiter());
        assertFalse(format.getTrailingData());
        assertFalse(format.getTrim());
        assertFalse(format.getAutoFlush());
        assertFalse(format.getLenientEof());
        assertEquals(0L, format.getMaxRows());
    }

    @Test
    public void testNewFormatRejectsLineBreakDelimiter() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.newFormat('\n');
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.newFormat('\r');
            }
        });
    }

    @Test
    public void testValueOfReturnsPredefinedFormat() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.valueOf("Default"));
        assertEquals(CSVFormat.EXCEL, CSVFormat.valueOf("Excel"));
    }

    @Test
    public void testValueOfRejectsUnknownName() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.valueOf("NotAFormat");
            }
        });
    }

    // ---------------------------------------------------------------
    // builder() / copy()
    // ---------------------------------------------------------------

    @Test
    public void testInstanceBuilderRoundTrip() {
        CSVFormat rebuilt = CSVFormat.DEFAULT.builder().get();
        assertEquals(CSVFormat.DEFAULT, rebuilt);
    }

    @Test
    public void testCopyInstanceMethod() {
        CSVFormat copy = CSVFormat.DEFAULT.copy();
        assertEquals(CSVFormat.DEFAULT, copy);
        assertNotSame(CSVFormat.DEFAULT, copy);
    }

    @Test
    public void testCopyStaticIsNullSafe() {
        assertNull(CSVFormat.copy(null));
        CSVFormat copy = CSVFormat.copy(CSVFormat.EXCEL);
        assertEquals(CSVFormat.EXCEL, copy);
        assertNotSame(CSVFormat.EXCEL, copy);
    }

    // ---------------------------------------------------------------
    // equals / hashCode / toString
    // ---------------------------------------------------------------

    @Test
    public void testEqualsAndHashCodeContract() {
        CSVFormat a = CSVFormat.newFormat(',').builder().setQuote('"').get();
        CSVFormat b = CSVFormat.newFormat(',').builder().setQuote('"').get();
        assertTrue(a.equals(a));
        assertTrue(a.equals(b));
        assertTrue(b.equals(a));
        assertEquals(a.hashCode(), b.hashCode());
        assertNotEquals(a, CSVFormat.newFormat(';'));
    }

    @Test
    public void testEqualsRejectsNullAndOtherTypes() {
        assertFalse(CSVFormat.DEFAULT.equals(null));
        assertFalse(CSVFormat.DEFAULT.equals("not a CSVFormat"));
    }

    @Test
    public void testToStringIsNotBlank() {
        String text = CSVFormat.DEFAULT.toString();
        assertNotNull(text);
        assertTrue(text.length() > 0);
    }

    // ---------------------------------------------------------------
    // format(Object...)
    // ---------------------------------------------------------------

    @Test
    public void testFormatSimpleValues() {
        assertEquals("a,b,c", CSVFormat.DEFAULT.format("a", "b", "c"));
    }

    @Test
    public void testFormatNoValues() {
        assertEquals("", CSVFormat.DEFAULT.format());
    }

    @Test
    public void testFormatQuotesValueContainingDelimiter() {
        assertEquals("\"a,b\"", CSVFormat.DEFAULT.format("a,b"));
    }

    @Test
    public void testFormatEscapesEmbeddedQuoteByDoubling() {
        assertEquals("\"a\"\"b\"", CSVFormat.DEFAULT.format("a\"b"));
    }

    @Test
    public void testFormatWritesConfiguredNullString() {
        assertEquals("\\N", CSVFormat.MYSQL.format((Object) null));
    }

    // ---------------------------------------------------------------
    // Defensive copies: getHeader / getHeaderComments
    // ---------------------------------------------------------------

    @Test
    public void testGetHeaderReturnsDefensiveCopy() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "b").get();
        String[] first = format.getHeader();
        assertArrayEquals(new String[] { "a", "b" }, first);
        first[0] = "mutated";
        String[] second = format.getHeader();
        assertArrayEquals(new String[] { "a", "b" }, second);
    }

    @Test
    public void testGetHeaderCommentsReturnsDefensiveCopy() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setHeaderComments("c1", "c2").get();
        String[] first = format.getHeaderComments();
        assertArrayEquals(new String[] { "c1", "c2" }, first);
        first[0] = "mutated";
        String[] second = format.getHeaderComments();
        assertArrayEquals(new String[] { "c1", "c2" }, second);
    }

    @Test
    public void testSetHeaderKeepsCopyOfInputArray() {
        String[] header = { "x", "y" };
        CSVFormat.Builder builder = CSVFormat.Builder.create().setHeader(header);
        header[0] = "z";
        CSVFormat format = builder.get();
        assertArrayEquals(new String[] { "x", "y" }, format.getHeader());
    }

    @Test
    public void testSetHeaderCommentsKeepsCopyOfInputArray() {
        Object[] comments = { "c1" };
        CSVFormat.Builder builder = CSVFormat.Builder.create().setHeaderComments(comments);
        comments[0] = "mutated";
        CSVFormat format = builder.get();
        assertArrayEquals(new String[] { "c1" }, format.getHeaderComments());
    }

    // ---------------------------------------------------------------
    // Package-private helper methods (same package access)
    // ---------------------------------------------------------------

    @Test
    public void testGetEscapeCharPrimitive() {
        assertEquals(0, CSVFormat.DEFAULT.getEscapeChar());
        assertEquals('\\', CSVFormat.MYSQL.getEscapeChar());
    }

    @Test
    public void testGetDelimiterCharArray() {
        assertArrayEquals(new char[] { ',' }, CSVFormat.DEFAULT.getDelimiterCharArray());
        assertArrayEquals(new char[] { '\t' }, CSVFormat.TDF.getDelimiterCharArray());
    }

    @Test
    public void testCloneIsNullSafeAndCopiesContent() {
        String[] original = { "x", "y" };
        String[] cloned = CSVFormat.clone(original);
        assertArrayEquals(original, cloned);
        assertNotSame(original, cloned);
        String[] nullClone = CSVFormat.clone((String[]) null);
        assertNull(nullClone);
    }

    // ---------------------------------------------------------------
    // Deprecated with* mutators still carry a documented contract
    // ---------------------------------------------------------------

    @Test
    public void testWithDelimiterDeprecated() {
        CSVFormat format = CSVFormat.DEFAULT.withDelimiter(';');
        assertEquals(';', format.getDelimiter());
        assertNotEquals(CSVFormat.DEFAULT, format);
    }

    @Test
    public void testWithDelimiterRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.withDelimiter('\n');
            }
        });
    }

    @Test
    public void testWithEscapeCharAndCharacter() {
        CSVFormat withChar = CSVFormat.DEFAULT.withEscape('\\');
        assertEquals(Character.valueOf('\\'), withChar.getEscapeCharacter());
        CSVFormat withBoxed = CSVFormat.DEFAULT.withEscape(Character.valueOf('!'));
        assertEquals(Character.valueOf('!'), withBoxed.getEscapeCharacter());
        CSVFormat disabled = withBoxed.withEscape((Character) null);
        assertNull(disabled.getEscapeCharacter());
    }

    @Test
    public void testWithEscapeRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.withEscape('\r');
            }
        });
    }

    @Test
    public void testWithQuoteCharAndCharacter() {
        CSVFormat withChar = CSVFormat.DEFAULT.withQuote('\'');
        assertEquals(Character.valueOf('\''), withChar.getQuoteCharacter());
        CSVFormat disabled = withChar.withQuote((Character) null);
        assertNull(disabled.getQuoteCharacter());
        assertFalse(disabled.isQuoteCharacterSet());
    }

    @Test
    public void testWithQuoteRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.withQuote('\n');
            }
        });
    }

    @Test
    public void testWithQuoteModeDeprecated() {
        CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);
        assertEquals(QuoteMode.MINIMAL, format.getQuoteMode());
    }

    @Test
    public void testWithCommentMarkerCharAndCharacter() {
        CSVFormat format = CSVFormat.DEFAULT.withCommentMarker('#');
        assertEquals(Character.valueOf('#'), format.getCommentMarker());
        assertTrue(format.isCommentMarkerSet());
        CSVFormat disabled = format.withCommentMarker((Character) null);
        assertNull(disabled.getCommentMarker());
        assertFalse(disabled.isCommentMarkerSet());
    }

    @Test
    public void testWithCommentMarkerRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.withCommentMarker('\n');
            }
        });
    }

    @Test
    public void testWithNullStringDeprecated() {
        CSVFormat format = CSVFormat.DEFAULT.withNullString("NULL");
        assertEquals("NULL", format.getNullString());
        assertTrue(format.isNullStringSet());
    }

    @Test
    public void testWithIgnoreEmptyLinesVariants() {
        assertTrue(CSVFormat.EXCEL.withIgnoreEmptyLines().getIgnoreEmptyLines());
        assertFalse(CSVFormat.DEFAULT.withIgnoreEmptyLines(false).getIgnoreEmptyLines());
    }

    @Test
    public void testWithIgnoreHeaderCaseVariants() {
        assertTrue(CSVFormat.DEFAULT.withIgnoreHeaderCase().getIgnoreHeaderCase());
        assertTrue(CSVFormat.DEFAULT.withIgnoreHeaderCase(true).getIgnoreHeaderCase());
        assertFalse(CSVFormat.DEFAULT.withIgnoreHeaderCase(false).getIgnoreHeaderCase());
    }

    @Test
    public void testWithIgnoreSurroundingSpacesVariants() {
        assertTrue(CSVFormat.DEFAULT.withIgnoreSurroundingSpaces().getIgnoreSurroundingSpaces());
        assertFalse(CSVFormat.TDF.withIgnoreSurroundingSpaces(false).getIgnoreSurroundingSpaces());
    }

    @Test
    public void testWithAllowMissingColumnNamesVariants() {
        assertTrue(CSVFormat.DEFAULT.withAllowMissingColumnNames().getAllowMissingColumnNames());
        assertFalse(CSVFormat.EXCEL.withAllowMissingColumnNames(false).getAllowMissingColumnNames());
    }

    @Test
    public void testWithAllowDuplicateHeaderNamesVariants() {
        assertTrue(CSVFormat.DEFAULT.withAllowDuplicateHeaderNames().getAllowDuplicateHeaderNames());
        assertFalse(CSVFormat.DEFAULT.withAllowDuplicateHeaderNames(false).getAllowDuplicateHeaderNames());
    }

    @Test
    public void testWithAutoFlushDeprecated() {
        assertTrue(CSVFormat.DEFAULT.withAutoFlush(true).getAutoFlush());
    }

    @Test
    public void testWithRecordSeparatorCharAndString() {
        assertEquals("\n", CSVFormat.DEFAULT.withRecordSeparator('\n').getRecordSeparator());
        assertEquals("\r\n", CSVFormat.DEFAULT.withRecordSeparator("\r\n").getRecordSeparator());
    }

    @Test
    public void testWithRecordSeparatorRejectsInvalidString() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.withRecordSeparator("not-a-valid-separator");
            }
        });
    }

    @Test
    public void testWithSkipHeaderRecordVariants() {
        assertTrue(CSVFormat.DEFAULT.withSkipHeaderRecord().getSkipHeaderRecord());
        assertFalse(CSVFormat.DEFAULT.withSkipHeaderRecord(false).getSkipHeaderRecord());
    }

    @Test
    public void testWithTrailingDelimiterVariants() {
        assertTrue(CSVFormat.DEFAULT.withTrailingDelimiter().getTrailingDelimiter());
        assertFalse(CSVFormat.DEFAULT.withTrailingDelimiter(false).getTrailingDelimiter());
    }

    @Test
    public void testWithTrimVariants() {
        assertTrue(CSVFormat.DEFAULT.withTrim().getTrim());
        assertFalse(CSVFormat.ORACLE.withTrim(false).getTrim());
    }

    @Test
    public void testWithHeaderStrings() {
        CSVFormat format = CSVFormat.DEFAULT.withHeader("name", "email");
        assertArrayEquals(new String[] { "name", "email" }, format.getHeader());
    }

    @Test
    public void testWithHeaderEnumClass() {
        CSVFormat format = CSVFormat.DEFAULT.withHeader(SampleHeader.class);
        assertArrayEquals(new String[] { "Name", "Email", "Phone" }, format.getHeader());
    }

    @Test
    public void testWithSystemRecordSeparator() {
        assertEquals(System.lineSeparator(), CSVFormat.DEFAULT.withSystemRecordSeparator().getRecordSeparator());
    }

    @Test
    public void testWithFirstRecordAsHeader() {
        CSVFormat format = CSVFormat.DEFAULT.withFirstRecordAsHeader();
        assertArrayEquals(new String[0], format.getHeader());
        assertTrue(format.getSkipHeaderRecord());
    }

    @Test
    public void testWithHeaderComments() {
        CSVFormat format = CSVFormat.DEFAULT.withHeaderComments("Generated", "by tests");
        assertArrayEquals(new String[] { "Generated", "by tests" }, format.getHeaderComments());
    }

    // ---------------------------------------------------------------
    // printing helpers on CSVFormat itself
    // ---------------------------------------------------------------

    @Test
    public void testPrintSingleValueAsNewRecordNoQuotingNeeded() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.print("simple", sb, true);
        assertEquals("simple", sb.toString());
    }

    @Test
    public void testPrintQuotesValueContainingDelimiter() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.print("a,b", sb, true);
        assertEquals("\"a,b\"", sb.toString());
    }

    @Test
    public void testPrintTrimsValueWhenConfigured() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat.ORACLE.print(" x ", sb, true);
        assertEquals("x", sb.toString());
    }

    @Test
    public void testPrintlnOutputsTrailingDelimiterThenRecordSeparator() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.println(sb);
        assertEquals("\r\n", sb.toString());
    }

    @Test
    public void testPrintlnOutputsNothingWhenNeitherSet() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat.newFormat(',').println(sb);
        assertEquals("", sb.toString());
    }

    @Test
    public void testPrintlnOutputsTrailingDelimiterWithoutRecordSeparator() throws IOException {
        CSVFormat format = CSVFormat.newFormat(',').builder().setTrailingDelimiter(true).get();
        StringBuilder sb = new StringBuilder();
        format.println(sb);
        assertEquals(",", sb.toString());
    }

    @Test
    public void testPrintRecordWritesValuesAndRecordSeparator() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.printRecord(sb, "a", "b", "c");
        assertEquals("a,b,c\r\n", sb.toString());
    }

    @Test
    public void testPrintRecordQuotesValuesAsNeeded() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.printRecord(sb, "a,b", "c");
        assertEquals("\"a,b\",c\r\n", sb.toString());
    }

    @Test
    public void testParseReturnsNonNullParser() throws IOException {
        Reader reader = new StringReader("a,b,c\r\n");
        CSVParser parser = CSVFormat.DEFAULT.parse(reader);
        assertNotNull(parser);
        parser.close();
    }

    @Test
    public void testPrintToFileWithCharsetReturnsNonNullPrinter() throws IOException {
        File file = File.createTempFile("csv-format-agent-test", ".csv");
        file.deleteOnExit();
        CSVPrinter printer = CSVFormat.DEFAULT.print(file, StandardCharsets.UTF_8);
        assertNotNull(printer);
        printer.close();
    }

    @Test
    public void testPrintToPathWithCharsetReturnsNonNullPrinter() throws IOException {
        Path path = Files.createTempFile("csv-format-agent-test", ".csv");
        path.toFile().deleteOnExit();
        CSVPrinter printer = CSVFormat.DEFAULT.print(path, StandardCharsets.UTF_8);
        assertNotNull(printer);
        printer.close();
    }

    // ---------------------------------------------------------------
    // CSVFormat.Builder
    // ---------------------------------------------------------------

    @Test
    public void testBuilderCreateMatchesDefault() {
        CSVFormat created = CSVFormat.Builder.create().get();
        assertEquals(CSVFormat.DEFAULT, created);
    }

    @Test
    public void testBuilderCreateFromFormatRoundTrips() {
        CSVFormat.Builder builder = CSVFormat.Builder.create(CSVFormat.EXCEL);
        assertEquals(CSVFormat.EXCEL, builder.get());
    }

    @Test
    public void testBuilderGetAndDeprecatedBuildAreEquivalent() {
        CSVFormat.Builder builder = CSVFormat.Builder.create().setDelimiter(';');
        CSVFormat viaGet = builder.get();
        CSVFormat viaBuild = builder.build();
        assertEquals(viaGet, viaBuild);
    }

    @Test
    public void testBuilderSettersAreReflectedByGetters() {
        CSVFormat format = CSVFormat.Builder.create()
                .setDelimiter(';')
                .setQuote('\'')
                .setEscape('\\')
                .setCommentMarker('#')
                .setHeader("a", "b")
                .setHeaderComments("c1", "c2")
                .setIgnoreEmptyLines(false)
                .setIgnoreHeaderCase(true)
                .setIgnoreSurroundingSpaces(true)
                .setLenientEof(true)
                .setMaxRows(5L)
                .setNullString("NULL")
                .setQuoteMode(QuoteMode.MINIMAL)
                .setRecordSeparator("\n")
                .setSkipHeaderRecord(true)
                .setTrailingData(true)
                .setTrailingDelimiter(true)
                .setTrim(true)
                .setAutoFlush(true)
                .setAllowMissingColumnNames(true)
                .setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_ALL)
                .get();

        assertEquals(";", format.getDelimiterString());
        assertEquals(Character.valueOf('\''), format.getQuoteCharacter());
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
        assertEquals(Character.valueOf('#'), format.getCommentMarker());
        assertTrue(format.isCommentMarkerSet());
        assertArrayEquals(new String[] { "a", "b" }, format.getHeader());
        assertArrayEquals(new String[] { "c1", "c2" }, format.getHeaderComments());
        assertFalse(format.getIgnoreEmptyLines());
        assertTrue(format.getIgnoreHeaderCase());
        assertTrue(format.getIgnoreSurroundingSpaces());
        assertTrue(format.getLenientEof());
        assertEquals(5L, format.getMaxRows());
        assertEquals("NULL", format.getNullString());
        assertTrue(format.isNullStringSet());
        assertEquals(QuoteMode.MINIMAL, format.getQuoteMode());
        assertEquals("\n", format.getRecordSeparator());
        assertTrue(format.getSkipHeaderRecord());
        assertTrue(format.getTrailingData());
        assertTrue(format.getTrailingDelimiter());
        assertTrue(format.getTrim());
        assertTrue(format.getAutoFlush());
        assertTrue(format.getAllowMissingColumnNames());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
    }

    @Test
    public void testBuilderSetHeaderEnumClass() {
        CSVFormat format = CSVFormat.Builder.create().setHeader(SampleHeader.class).get();
        assertArrayEquals(new String[] { "Name", "Email", "Phone" }, format.getHeader());
    }

    @Test
    public void testBuilderSetDelimiterStringVariant() {
        CSVFormat format = CSVFormat.Builder.create().setDelimiter("::").get();
        assertEquals("::", format.getDelimiterString());
    }

    @Test
    public void testBuilderSetCommentMarkerRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.Builder.create().setCommentMarker('\n');
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.Builder.create().setCommentMarker(Character.valueOf('\r'));
            }
        });
    }

    @Test
    public void testBuilderSetEscapeRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.Builder.create().setEscape('\n');
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.Builder.create().setEscape(Character.valueOf('\r'));
            }
        });
    }

    @Test
    public void testBuilderSettersReturnSameBuilderInstance() {
        CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertSame(builder, builder.setDelimiter(';'));
        assertSame(builder, builder.setTrim(true));
        assertSame(builder, builder.setMaxRows(10L));
    }
}
