/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.apache.commons.csv.Constants.UNDEFINED;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.StandardCharsets;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link ExtendedBufferedReader}.
 */
class ExtendedBufferedReaderAgentTest {

    private static final int EOF = -1;

    private ExtendedBufferedReader create(final String content) {
        return new ExtendedBufferedReader(new StringReader(content));
    }

    @Test
    void testInitialState() {
        final ExtendedBufferedReader reader = create("abc");
        assertEquals(UNDEFINED, reader.getLastChar());
        assertEquals(0, reader.getPosition());
        assertEquals(0, reader.getLineNumber());
        assertEquals(0, reader.getBytesRead());
    }

    @Test
    void testReadSingleCharUpdatesState() throws IOException {
        final ExtendedBufferedReader reader = create("ab");
        assertEquals('a', reader.read());
        assertEquals('a', reader.getLastChar());
        assertEquals(1, reader.getPosition());
        assertEquals('b', reader.read());
        assertEquals('b', reader.getLastChar());
        assertEquals(2, reader.getPosition());
        assertEquals(EOF, reader.read());
        assertEquals(EOF, reader.getLastChar());
        assertEquals(3, reader.getPosition());
        // Reading past EOF again does not advance position further in an unexpected way.
        assertEquals(EOF, reader.read());
        assertEquals(EOF, reader.getLastChar());
    }

    @Test
    void testReadEmptyStream() throws IOException {
        final ExtendedBufferedReader reader = create("");
        assertEquals(EOF, reader.read());
        assertEquals(EOF, reader.getLastChar());
        // Reaching EOF on the very first read counts as having completed a (empty) line.
        assertEquals(1, reader.getLineNumber());
    }

    @Test
    void testPeekDoesNotConsume() throws IOException {
        final ExtendedBufferedReader reader = create("xy");
        assertEquals('x', reader.peek());
        // peek() must not change observable read state.
        assertEquals(UNDEFINED, reader.getLastChar());
        assertEquals(0, reader.getPosition());
        assertEquals('x', reader.peek());
        assertEquals('x', reader.read());
        assertEquals('x', reader.getLastChar());
        assertEquals(1, reader.getPosition());
    }

    @Test
    void testPeekAtEof() throws IOException {
        final ExtendedBufferedReader reader = create("");
        assertEquals(EOF, reader.peek());
        assertEquals(UNDEFINED, reader.getLastChar());
    }

    @Test
    void testReadCharArrayZeroLength() throws IOException {
        final ExtendedBufferedReader reader = create("abc");
        final char[] buf = new char[4];
        assertEquals(0, reader.read(buf, 0, 0));
        assertEquals(0, reader.getPosition());
        assertEquals(UNDEFINED, reader.getLastChar());
    }

    @Test
    void testReadCharArrayPartialAndEof() throws IOException {
        final ExtendedBufferedReader reader = create("abc");
        final char[] buf = new char[10];
        final int len = reader.read(buf, 2, 8);
        assertEquals(3, len);
        assertEquals('a', buf[2]);
        assertEquals('b', buf[3]);
        assertEquals('c', buf[4]);
        assertEquals('c', reader.getLastChar());
        assertEquals(3, reader.getPosition());
        assertEquals(EOF, reader.read(buf, 0, 1));
        assertEquals(EOF, reader.getLastChar());
    }

    @Test
    void testLineNumberWithLf() throws IOException {
        final ExtendedBufferedReader reader = create("ab\ncd");
        assertEquals(0, reader.getLineNumber());
        reader.read(); // a
        assertEquals(1, reader.getLineNumber());
        reader.read(); // b
        assertEquals(1, reader.getLineNumber());
        reader.read(); // \n
        assertEquals(1, reader.getLineNumber());
        reader.read(); // c
        assertEquals(2, reader.getLineNumber());
        reader.read(); // d
        assertEquals(2, reader.getLineNumber());
        reader.read(); // EOF
        assertEquals(2, reader.getLineNumber());
    }

    @Test
    void testLineNumberWithCrLf() throws IOException {
        final ExtendedBufferedReader reader = create("a\r\nb");
        reader.read(); // a
        reader.read(); // \r
        assertEquals(1, reader.getLineNumber());
        reader.read(); // \n, must not double count
        assertEquals(1, reader.getLineNumber());
        reader.read(); // b
        assertEquals(2, reader.getLineNumber());
        reader.read(); // EOF
        assertEquals(2, reader.getLineNumber());
    }

    @Test
    void testLineNumberWithCrOnly() throws IOException {
        final ExtendedBufferedReader reader = create("a\rb\rc");
        reader.read(); // a
        reader.read(); // \r
        assertEquals(1, reader.getLineNumber());
        reader.read(); // b
        assertEquals(2, reader.getLineNumber());
        reader.read(); // \r
        assertEquals(2, reader.getLineNumber());
        reader.read(); // c
        assertEquals(3, reader.getLineNumber());
        reader.read(); // EOF
        assertEquals(3, reader.getLineNumber());
    }

    @Test
    void testLineNumberWithBulkRead() throws IOException {
        final ExtendedBufferedReader reader = create("ab\ncd\r\nef");
        final char[] buf = new char[20];
        final int len = reader.read(buf, 0, buf.length);
        assertEquals(9, len);
        assertEquals(3, reader.getLineNumber());
        assertEquals('f', reader.getLastChar());
    }

    @Test
    void testReadLineBasic() throws IOException {
        final ExtendedBufferedReader reader = create("one\ntwo\r\nthree\rfour");
        assertEquals("one", reader.readLine());
        assertEquals("two", reader.readLine());
        assertEquals("three", reader.readLine());
        assertEquals("four", reader.readLine());
        assertNull(reader.readLine());
    }

    @Test
    void testReadLineEmptyLines() throws IOException {
        final ExtendedBufferedReader reader = create("\n\nabc\n");
        assertEquals("", reader.readLine());
        assertEquals("", reader.readLine());
        assertEquals("abc", reader.readLine());
        assertNull(reader.readLine());
    }

    @Test
    void testReadLineOnEmptyStream() throws IOException {
        final ExtendedBufferedReader reader = create("");
        assertNull(reader.readLine());
    }

    @Test
    void testReadLineNoTrailingTerminator() throws IOException {
        final ExtendedBufferedReader reader = create("lastline");
        assertEquals("lastline", reader.readLine());
        assertNull(reader.readLine());
    }

    @Test
    void testMarkAndReset() throws IOException {
        final ExtendedBufferedReader reader = create("abcdef");
        reader.read(); // a
        reader.read(); // b
        reader.mark(10);
        final long markedPosition = reader.getPosition();
        final int markedLastChar = reader.getLastChar();
        final long markedLineNumber = reader.getLineNumber();
        reader.read(); // c
        reader.read(); // d
        assertEquals('d', reader.getLastChar());
        reader.reset();
        assertEquals(markedPosition, reader.getPosition());
        assertEquals(markedLastChar, reader.getLastChar());
        assertEquals(markedLineNumber, reader.getLineNumber());
        // Reading again after reset must replay the same characters.
        assertEquals('c', reader.read());
        assertEquals('d', reader.read());
    }

    @Test
    void testCloseSetsLastCharToEofAndBlocksFurtherReads() throws IOException {
        final ExtendedBufferedReader reader = create("abc");
        reader.read();
        reader.close();
        assertEquals(EOF, reader.getLastChar());
        assertThrows(IOException.class, reader::read);
    }

    @Test
    void testGetBytesReadWithoutTrackingIsAlwaysZero() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("hello"), StandardCharsets.UTF_8, false);
        final char[] buf = new char[10];
        reader.read(buf, 0, buf.length);
        assertEquals(0, reader.getBytesRead());
    }

    @Test
    void testGetBytesReadWithoutCharsetIsAlwaysZero() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("hello"), null, true);
        reader.read();
        assertEquals(0, reader.getBytesRead());
    }

    @Test
    void testGetBytesReadAsciiOneBytePerChar() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"), StandardCharsets.UTF_8, true);
        reader.read();
        assertEquals(1, reader.getBytesRead());
        reader.read();
        assertEquals(2, reader.getBytesRead());
        reader.read();
        assertEquals(3, reader.getBytesRead());
    }

    @Test
    void testGetBytesReadMultiByteCharacter() throws IOException {
        // U+00E9 (e acute) encodes as 2 bytes in UTF-8.
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("éx"), StandardCharsets.UTF_8, true);
        reader.read();
        assertEquals(2, reader.getBytesRead());
        reader.read();
        assertEquals(3, reader.getBytesRead());
    }

    @Test
    void testGetBytesReadSurrogatePairFourBytes() throws IOException {
        // U+1F600 (grinning face emoji) encodes as 4 bytes in UTF-8, and is represented
        // as a high/low surrogate pair in UTF-16.
        final String emoji = new String(Character.toChars(0x1F600));
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader(emoji), StandardCharsets.UTF_8, true);
        reader.read(); // high surrogate: contributes 0 bytes by itself
        assertEquals(0, reader.getBytesRead());
        reader.read(); // low surrogate completes the pair: 4 bytes total
        assertEquals(4, reader.getBytesRead());
    }

    @Test
    void testGetBytesReadBulkRead() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"), StandardCharsets.UTF_8, true);
        final char[] buf = new char[10];
        final int len = reader.read(buf, 0, buf.length);
        assertEquals(3, len);
        assertEquals(3, reader.getBytesRead());
    }

    @Test
    void testUnpairedLowSurrogateThrowsCharacterCodingException() {
        final String badContent = String.valueOf('\udc00');
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader(badContent), StandardCharsets.UTF_8, true);
        assertThrows(CharacterCodingException.class, reader::read);
    }

    @Test
    void testGetLineNumberAtVeryStartIsZero() {
        final ExtendedBufferedReader reader = create("abc");
        assertEquals(0, reader.getLineNumber());
    }

    @Test
    void testPositionAdvancesExactlyByCharsReadNotRequestedLength() throws IOException {
        final ExtendedBufferedReader reader = create("ab");
        final char[] buf = new char[100];
        final int len = reader.read(buf, 0, 100);
        assertEquals(2, len);
        assertEquals(2, reader.getPosition());
        assertTrue(reader.getPosition() < 100);
    }
}
