/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Base64;
import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link CSVFormat}.
 */
class CSVFormatAgentTest {

    private enum SampleHeaderEnum {
        Name, Email, Phone
    }

    // ---------------------------------------------------------------
    // Builder basics
    // ---------------------------------------------------------------

    @Test
    void testBuilderCreateDefaults() {
        final CSVFormat format = CSVFormat.Builder.create().get();
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertTrue(format.getIgnoreEmptyLines());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
    }

    @Test
    void testBuilderCreateFromFormatCopiesFields() {
        final CSVFormat source = CSVFormat.DEFAULT.builder().setDelimiter(';').setNullString("NULL").setTrim(true).get();
        final CSVFormat copy = CSVFormat.Builder.create(source).get();
        assertEquals(source, copy);
        assertNotSame(source, copy);
        assertEquals(";", copy.getDelimiterString());
        assertEquals("NULL", copy.getNullString());
        assertTrue(copy.getTrim());
    }

    @Test
    void testBuildDeprecatedEqualsGet() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertEquals(builder.get(), builder.build());
    }

    @Test
    void testNewFormat() {
        final CSVFormat format = CSVFormat.newFormat('|');
        assertEquals("|", format.getDelimiterString());
        assertNull(format.getQuoteCharacter());
        assertNull(format.getEscapeCharacter());
        assertNull(format.getRecordSeparator());
        assertFalse(format.getIgnoreEmptyLines());
        assertFalse(format.getTrim());
    }

    // ---------------------------------------------------------------
    // Builder setter validation (boundary / error cases)
    // ---------------------------------------------------------------

    @Test
    void testSetCommentMarkerRejectsLineBreaks() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, () -> builder.setCommentMarker('\n'));
        assertThrows(IllegalArgumentException.class, () -> builder.setCommentMarker('\r'));
        assertThrows(IllegalArgumentException.class, () -> builder.setCommentMarker(Character.valueOf('\n')));
    }

    @Test
    void testSetCommentMarkerAllowsNullCharacter() {
        final CSVFormat format = CSVFormat.Builder.create().setCommentMarker((Character) null).get();
        assertFalse(format.isCommentMarkerSet());
        assertNull(format.getCommentMarker());
    }

    @Test
    void testSetDelimiterRejectsLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, () -> builder.setDelimiter("a\nb"));
        assertThrows(IllegalArgumentException.class, () -> builder.setDelimiter("a\rb"));
    }

    @Test
    void testSetDelimiterRejectsEmptyString() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, () -> builder.setDelimiter(""));
    }

    @Test
    void testSetDelimiterMultiChar() {
        final CSVFormat format = CSVFormat.Builder.create().setDelimiter("::").get();
        assertEquals("::", format.getDelimiterString());
        assertArrayEquals(new char[] {':', ':'}, format.getDelimiterCharArray());
    }

    @Test
    void testSetDuplicateHeaderModeRejectsNull() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(NullPointerException.class, () -> builder.setDuplicateHeaderMode(null));
    }

    @Test
    void testSetEscapeRejectsLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, () -> builder.setEscape('\n'));
        assertThrows(IllegalArgumentException.class, () -> builder.setEscape(Character.valueOf('\r')));
    }

    @Test
    void testSetQuoteRejectsLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, () -> builder.setQuote('\n'));
        assertThrows(IllegalArgumentException.class, () -> builder.setQuote(Character.valueOf('\r')));
    }

    @Test
    void testSetQuoteNullDisablesQuoting() {
        final CSVFormat format = CSVFormat.Builder.create().setQuote((Character) null).get();
        assertFalse(format.isQuoteCharacterSet());
        assertNull(format.getQuoteCharacter());
    }

    @Test
    void testSetMaxRows() {
        final CSVFormat format = CSVFormat.Builder.create().setMaxRows(5L).get();
        assertEquals(5L, format.getMaxRows());
        assertTrue(format.useMaxRows());
        assertTrue(format.useRow(5L));
        assertFalse(format.useRow(6L));
    }

    @Test
    void testUseMaxRowsDisabledByDefault() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertEquals(0L, format.getMaxRows());
        assertFalse(format.useMaxRows());
        assertTrue(format.useRow(1000L));
    }

    @Test
    void testSetAllowDuplicateHeaderNamesDeprecated() {
        final CSVFormat allow = CSVFormat.Builder.create().setAllowDuplicateHeaderNames(true).get();
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, allow.getDuplicateHeaderMode());
        final CSVFormat disallow = CSVFormat.Builder.create().setAllowDuplicateHeaderNames(false).get();
        assertEquals(DuplicateHeaderMode.ALLOW_EMPTY, disallow.getDuplicateHeaderMode());
    }

    @Test
    void testBooleanSetters() {
        final CSVFormat format = CSVFormat.Builder.create()
                .setAllowMissingColumnNames(true)
                .setAutoFlush(true)
                .setIgnoreHeaderCase(true)
                .setIgnoreSurroundingSpaces(true)
                .setLenientEof(true)
                .setSkipHeaderRecord(true)
                .setTrailingData(true)
                .setTrailingDelimiter(true)
                .setTrim(true)
                .get();
        assertTrue(format.getAllowMissingColumnNames());
        assertTrue(format.getAutoFlush());
        assertTrue(format.getIgnoreHeaderCase());
        assertTrue(format.getIgnoreSurroundingSpaces());
        assertTrue(format.getLenientEof());
        assertTrue(format.getSkipHeaderRecord());
        assertTrue(format.getTrailingData());
        assertTrue(format.getTrailingDelimiter());
        assertTrue(format.getTrim());
    }

    @Test
    void testSetRecordSeparatorCharAndString() {
        final CSVFormat fromChar = CSVFormat.Builder.create().setRecordSeparator('\n').get();
        assertEquals("\n", fromChar.getRecordSeparator());
        final CSVFormat fromString = CSVFormat.Builder.create().setRecordSeparator("\r\n").get();
        assertEquals("\r\n", fromString.getRecordSeparator());
    }

    @Test
    void testSetQuoteMode() {
        final CSVFormat format = CSVFormat.Builder.create().setQuoteMode(QuoteMode.ALL).get();
        assertEquals(QuoteMode.ALL, format.getQuoteMode());
    }

    @Test
    void testSetNullString() {
        final CSVFormat format = CSVFormat.Builder.create().setNullString("N/A").get();
        assertTrue(format.isNullStringSet());
        assertEquals("N/A", format.getNullString());
    }

    // ---------------------------------------------------------------
    // Header handling
    // ---------------------------------------------------------------

    @Test
    void testSetHeaderStringArrayCopiesInput() {
        final String[] original = {"a", "b"};
        final CSVFormat format = CSVFormat.Builder.create().setHeader(original).get();
        original[0] = "mutated";
        assertArrayEquals(new String[] {"a", "b"}, format.getHeader());
    }

    @Test
    void testGetHeaderReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.Builder.create().setHeader("a", "b").get();
        final String[] header = format.getHeader();
        header[0] = "mutated";
        assertArrayEquals(new String[] {"a", "b"}, format.getHeader());
    }

    @Test
    void testGetHeaderNullWhenDisabled() {
        assertNull(CSVFormat.DEFAULT.getHeader());
    }

    @Test
    void testSetHeaderFromEnumClass() {
        final CSVFormat format = CSVFormat.Builder.create().setHeader(SampleHeaderEnum.class).get();
        assertArrayEquals(new String[] {"Name", "Email", "Phone"}, format.getHeader());
    }

    @Test
    void testSetHeaderFromNullEnumClassDisablesHeader() {
        final CSVFormat format = CSVFormat.Builder.create().setHeader((Class<? extends Enum<?>>) null).get();
        assertNull(format.getHeader());
    }

    @Test
    void testSetHeaderFromResultSet() throws SQLException {
        final ResultSetMetaData metaData = mock(ResultSetMetaData.class);
        when(metaData.getColumnCount()).thenReturn(2);
        when(metaData.getColumnLabel(1)).thenReturn("ID");
        when(metaData.getColumnLabel(2)).thenReturn("NAME");
        final ResultSet resultSet = mock(ResultSet.class);
        when(resultSet.getMetaData()).thenReturn(metaData);
        final CSVFormat format = CSVFormat.Builder.create().setHeader(resultSet).get();
        assertArrayEquals(new String[] {"ID", "NAME"}, format.getHeader());
    }

    @Test
    void testSetHeaderFromNullResultSet() throws SQLException {
        final CSVFormat format = CSVFormat.Builder.create().setHeader((ResultSet) null).get();
        assertNull(format.getHeader());
    }

    @Test
    void testSetHeaderFromResultSetMetaData() throws SQLException {
        final ResultSetMetaData metaData = mock(ResultSetMetaData.class);
        when(metaData.getColumnCount()).thenReturn(1);
        when(metaData.getColumnLabel(1)).thenReturn("ONLY");
        final CSVFormat format = CSVFormat.Builder.create().setHeader(metaData).get();
        assertArrayEquals(new String[] {"ONLY"}, format.getHeader());
    }

    @Test
    void testSetHeaderComments() {
        final CSVFormat fromObjects = CSVFormat.Builder.create().setHeaderComments("line1", Integer.valueOf(2)).get();
        assertArrayEquals(new String[] {"line1", "2"}, fromObjects.getHeaderComments());
        final CSVFormat fromStrings = CSVFormat.Builder.create().setHeaderComments("a", "b").get();
        assertArrayEquals(new String[] {"a", "b"}, fromStrings.getHeaderComments());
    }

    @Test
    void testGetHeaderCommentsNullWhenUnset() {
        assertNull(CSVFormat.DEFAULT.getHeaderComments());
    }

    @Test
    void testDuplicateHeaderDisallowThrows() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create().setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).setHeader("a", "a");
        assertThrows(IllegalArgumentException.class, builder::get);
    }

    @Test
    void testDuplicateHeaderAllowEmptyPermitsBlankDuplicates() {
        final CSVFormat format = CSVFormat.Builder.create().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("", "", "a").get();
        assertArrayEquals(new String[] {"", "", "a"}, format.getHeader());
    }

    @Test
    void testDuplicateHeaderAllowEmptyRejectsNonBlankDuplicates() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("a", "a");
        assertThrows(IllegalArgumentException.class, builder::get);
    }

    @Test
    void testDuplicateHeaderAllowAllPermitsDuplicates() {
        final CSVFormat format = CSVFormat.Builder.create().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_ALL).setHeader("a", "a").get();
        assertArrayEquals(new String[] {"a", "a"}, format.getHeader());
    }

    // ---------------------------------------------------------------
    // validate() via construction
    // ---------------------------------------------------------------

    @Test
    void testValidateQuoteEqualsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.Builder.create().setDelimiter(',').setQuote(',').get());
    }

    @Test
    void testValidateEscapeEqualsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.Builder.create().setDelimiter(',').setEscape(',').get());
    }

    @Test
    void testValidateCommentEqualsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.Builder.create().setDelimiter(',').setCommentMarker(',').get());
    }

    @Test
    void testValidateQuoteEqualsCommentThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.Builder.create().setQuote('#').setCommentMarker('#').get());
    }

    @Test
    void testValidateEscapeEqualsCommentThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.Builder.create().setEscape('#').setCommentMarker('#').get());
    }

    @Test
    void testValidateQuoteModeNoneWithoutEscapeThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.Builder.create().setQuoteMode(QuoteMode.NONE).get());
    }

    @Test
    void testValidateQuoteModeNoneWithEscapeSucceeds() {
        final CSVFormat format = CSVFormat.Builder.create().setQuoteMode(QuoteMode.NONE).setEscape('\\').get();
        assertEquals(QuoteMode.NONE, format.getQuoteMode());
    }

    // ---------------------------------------------------------------
    // Predefined formats
    // ---------------------------------------------------------------

    @Test
    void testDefaultFormatFields() {
        assertEquals(",", CSVFormat.DEFAULT.getDelimiterString());
        assertEquals(Character.valueOf('"'), CSVFormat.DEFAULT.getQuoteCharacter());
        assertEquals("\r\n", CSVFormat.DEFAULT.getRecordSeparator());
        assertTrue(CSVFormat.DEFAULT.getIgnoreEmptyLines());
    }

    @Test
    void testExcelFormatFields() {
        assertFalse(CSVFormat.EXCEL.getIgnoreEmptyLines());
        assertTrue(CSVFormat.EXCEL.getAllowMissingColumnNames());
        assertTrue(CSVFormat.EXCEL.getTrailingData());
        assertTrue(CSVFormat.EXCEL.getLenientEof());
    }

    @Test
    void testMySqlFormatFields() {
        assertEquals("\t", CSVFormat.MYSQL.getDelimiterString());
        assertEquals(Character.valueOf('\\'), CSVFormat.MYSQL.getEscapeCharacter());
        assertNull(CSVFormat.MYSQL.getQuoteCharacter());
        assertEquals("\n", CSVFormat.MYSQL.getRecordSeparator());
        assertEquals("\\N", CSVFormat.MYSQL.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, CSVFormat.MYSQL.getQuoteMode());
    }

    @Test
    void testOracleFormatFields() {
        assertEquals(",", CSVFormat.ORACLE.getDelimiterString());
        assertEquals(Character.valueOf('\\'), CSVFormat.ORACLE.getEscapeCharacter());
        assertEquals(Character.valueOf('"'), CSVFormat.ORACLE.getQuoteCharacter());
        assertTrue(CSVFormat.ORACLE.getTrim());
        assertEquals(System.lineSeparator(), CSVFormat.ORACLE.getRecordSeparator());
    }

    @Test
    void testPostgreSqlCsvFormatFields() {
        assertEquals(",", CSVFormat.POSTGRESQL_CSV.getDelimiterString());
        assertNull(CSVFormat.POSTGRESQL_CSV.getEscapeCharacter());
        assertEquals("", CSVFormat.POSTGRESQL_CSV.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, CSVFormat.POSTGRESQL_CSV.getQuoteMode());
    }

    @Test
    void testPostgreSqlTextFormatFields() {
        assertEquals("\t", CSVFormat.POSTGRESQL_TEXT.getDelimiterString());
        assertNull(CSVFormat.POSTGRESQL_TEXT.getQuoteCharacter());
        assertEquals("\\N", CSVFormat.POSTGRESQL_TEXT.getNullString());
    }

    @Test
    void testRfc4180FormatFields() {
        assertFalse(CSVFormat.RFC4180.getIgnoreEmptyLines());
        assertEquals(",", CSVFormat.RFC4180.getDelimiterString());
    }

    @Test
    void testTdfFormatFields() {
        assertEquals("\t", CSVFormat.TDF.getDelimiterString());
        assertTrue(CSVFormat.TDF.getIgnoreSurroundingSpaces());
    }

    @Test
    void testMongoDbCsvFormatFields() {
        assertEquals(",", CSVFormat.MONGODB_CSV.getDelimiterString());
        assertEquals(Character.valueOf('"'), CSVFormat.MONGODB_CSV.getEscapeCharacter());
        assertEquals(QuoteMode.MINIMAL, CSVFormat.MONGODB_CSV.getQuoteMode());
    }

    @Test
    void testMongoDbTsvFormatFields() {
        assertEquals("\t", CSVFormat.MONGODB_TSV.getDelimiterString());
        assertFalse(CSVFormat.MONGODB_TSV.getSkipHeaderRecord());
    }

    @Test
    void testInformixUnloadFormatFields() {
        assertEquals("|", CSVFormat.INFORMIX_UNLOAD.getDelimiterString());
        assertEquals(Character.valueOf('\\'), CSVFormat.INFORMIX_UNLOAD.getEscapeCharacter());
        assertEquals("\n", CSVFormat.INFORMIX_UNLOAD.getRecordSeparator());
    }

    @Test
    void testInformixUnloadCsvFormatFields() {
        assertEquals(",", CSVFormat.INFORMIX_UNLOAD_CSV.getDelimiterString());
        assertEquals("\n", CSVFormat.INFORMIX_UNLOAD_CSV.getRecordSeparator());
    }

    @Test
    void testPredefinedEnumMatchesConstants() {
        for (final CSVFormat.Predefined predefined : CSVFormat.Predefined.values()) {
            assertNotNull(predefined.getFormat());
        }
        assertEquals(CSVFormat.DEFAULT, CSVFormat.Predefined.Default.getFormat());
        assertEquals(CSVFormat.TDF, CSVFormat.Predefined.TDF.getFormat());
    }

    @Test
    void testValueOfKnownName() {
        assertEquals(CSVFormat.EXCEL, CSVFormat.valueOf("Excel"));
    }

    @Test
    void testValueOfUnknownNameThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.valueOf("NotAFormat"));
    }

    // ---------------------------------------------------------------
    // builder()/copy()/equals()/hashCode()
    // ---------------------------------------------------------------

    @Test
    void testBuilderInstanceMethodProducesEqualFormat() {
        final CSVFormat rebuilt = CSVFormat.EXCEL.builder().get();
        assertEquals(CSVFormat.EXCEL, rebuilt);
    }

    @Test
    void testCopyStaticNullSafe() {
        assertNull(CSVFormat.copy(null));
        final CSVFormat copy = CSVFormat.copy(CSVFormat.DEFAULT);
        assertEquals(CSVFormat.DEFAULT, copy);
        assertNotSame(CSVFormat.DEFAULT, copy);
    }

    @Test
    void testEqualsContract() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.DEFAULT);
        assertNotEquals(CSVFormat.DEFAULT, null);
        assertNotEquals(CSVFormat.DEFAULT, "not a format");
        assertNotEquals(CSVFormat.DEFAULT, CSVFormat.EXCEL);
        final CSVFormat a = CSVFormat.Builder.create().setDelimiter(';').get();
        final CSVFormat b = CSVFormat.Builder.create().setDelimiter(';').get();
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
    }

    // ---------------------------------------------------------------
    // Simple getters on DEFAULT
    // ---------------------------------------------------------------

    @Test
    void testDeprecatedGetDelimiterChar() {
        assertEquals(',', CSVFormat.DEFAULT.getDelimiter());
    }

    @Test
    void testGetEscapeCharDefaultsToZero() {
        assertEquals(0, CSVFormat.DEFAULT.getEscapeChar());
        final CSVFormat withEscape = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        assertEquals('\\', withEscape.getEscapeChar());
    }

    @Test
    void testIsSetFlagsOnDefault() {
        assertFalse(CSVFormat.DEFAULT.isCommentMarkerSet());
        assertFalse(CSVFormat.DEFAULT.isEscapeCharacterSet());
        assertFalse(CSVFormat.DEFAULT.isNullStringSet());
        assertTrue(CSVFormat.DEFAULT.isQuoteCharacterSet());
    }

    // ---------------------------------------------------------------
    // format(Object...)
    // ---------------------------------------------------------------

    @Test
    void testFormatSimpleValues() {
        assertEquals("a,b", CSVFormat.DEFAULT.format("a", "b"));
    }

    @Test
    void testFormatQuotesValueContainingDelimiter() {
        assertEquals("a,\"b,c\"", CSVFormat.DEFAULT.format("a", "b,c"));
    }

    // ---------------------------------------------------------------
    // parse(Reader)
    // ---------------------------------------------------------------

    @Test
    void testParseReader() throws IOException {
        final CSVParser parser = CSVFormat.DEFAULT.parse(new StringReader("a,b\r\nc,d\r\n"));
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("b", records.get(0).get(1));
            assertEquals("c", records.get(1).get(0));
            assertEquals("d", records.get(1).get(1));
        } finally {
            parser.close();
        }
    }

    // ---------------------------------------------------------------
    // print(Appendable) / printer() / println() / printRecord()
    // ---------------------------------------------------------------

    @Test
    void testPrintToAppendable() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = CSVFormat.DEFAULT.print(sw);
        try {
            printer.printRecord("x", "y");
        } finally {
            printer.close();
        }
        assertEquals("x,y\r\n", sw.toString());
    }

    @Test
    void testPrinterCreatesNonNullPrinter() throws IOException {
        assertNotNull(CSVFormat.DEFAULT.printer());
    }

    @Test
    void testPrintlnWithTrailingDelimiter() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get();
        final StringWriter sw = new StringWriter();
        format.println(sw);
        assertEquals(",\r\n", sw.toString());
    }

    @Test
    void testPrintlnWithoutTrailingDelimiter() throws IOException {
        final StringWriter sw = new StringWriter();
        CSVFormat.DEFAULT.println(sw);
        assertEquals("\r\n", sw.toString());
    }

    @Test
    void testPrintRecordToAppendable() throws IOException {
        final StringWriter sw = new StringWriter();
        CSVFormat.DEFAULT.printRecord(sw, "a", "b");
        assertEquals("a,b\r\n", sw.toString());
    }

    @Test
    void testPrintFileAndPathWithCharset() throws IOException {
        final File temp = File.createTempFile("csvformatagenttest", ".csv");
        try {
            final CSVPrinter filePrinter = CSVFormat.DEFAULT.print(temp, StandardCharsets.UTF_8);
            try {
                filePrinter.printRecord("1", "2");
            } finally {
                filePrinter.close();
            }
            assertEquals("1,2\r\n", new String(Files.readAllBytes(temp.toPath()), StandardCharsets.UTF_8));

            final CSVPrinter pathPrinter = CSVFormat.DEFAULT.print(temp.toPath(), StandardCharsets.UTF_8);
            try {
                pathPrinter.printRecord("3", "4");
            } finally {
                pathPrinter.close();
            }
            assertEquals("3,4\r\n", new String(Files.readAllBytes(temp.toPath()), StandardCharsets.UTF_8));
        } finally {
            temp.delete();
        }
    }

    // ---------------------------------------------------------------
    // print(Object, Appendable, boolean)
    // ---------------------------------------------------------------

    @Test
    void testPrintNullValueUsesEmptyStringWhenNullStringUnset() throws IOException {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.print(null, sb, true);
        assertEquals("", sb.toString());
    }

    @Test
    void testPrintNullValuePrependsDelimiterWhenNotNewRecord() throws IOException {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.print(null, sb, false);
        assertEquals(",", sb.toString());
    }

    @Test
    void testPrintNumberWithNonNumericQuoteModeIsUnquoted() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuoteMode(QuoteMode.NON_NUMERIC).get();
        final StringBuilder sb = new StringBuilder();
        format.print(Integer.valueOf(5), sb, true);
        assertEquals("5", sb.toString());
    }

    @Test
    void testPrintStringWithNonNumericQuoteModeIsQuoted() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuoteMode(QuoteMode.NON_NUMERIC).get();
        final StringBuilder sb = new StringBuilder();
        format.print("hello", sb, true);
        assertEquals("\"hello\"", sb.toString());
    }

    @Test
    void testPrintReaderValueIsQuoted() throws IOException {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.print(new StringReader("ab"), sb, true);
        assertEquals("\"ab\"", sb.toString());
    }

    @Test
    void testPrintInputStreamValueIsBase64EncodedAndQuoted() throws IOException {
        final byte[] bytes = "ab".getBytes(StandardCharsets.UTF_8);
        final StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.print(new ByteArrayInputStream(bytes), sb, true);
        final String result = sb.toString();
        assertTrue(result.startsWith("\""));
        assertTrue(result.endsWith("\""));
        final String base64 = result.substring(1, result.length() - 1);
        assertArrayEquals(bytes, Base64.getDecoder().decode(base64));
    }

    @Test
    void testPrintTrimsValueWhenTrimEnabled() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrim(true).setQuote((Character) null).get();
        final StringBuilder sb = new StringBuilder();
        format.print("  hi  ", sb, true);
        assertEquals("hi", sb.toString());
    }

    // ---------------------------------------------------------------
    // toString() / trim(String) / useMaxRows()/useRow()
    // ---------------------------------------------------------------

    @Test
    void testToStringContainsConfiguredSettings() {
        final String s = CSVFormat.DEFAULT.toString();
        assertTrue(s.contains("Delimiter=<,>"));
        assertTrue(s.contains("QuoteChar=<\">"));
    }

    @Test
    void testPackagePrivateTrimHonorsSetting() {
        final CSVFormat trimming = CSVFormat.DEFAULT.builder().setTrim(true).get();
        assertEquals("hi", trimming.trim(" hi "));
        assertEquals(" hi ", CSVFormat.DEFAULT.trim(" hi "));
    }

    // ---------------------------------------------------------------
    // Deprecated with* methods delegate correctly
    // ---------------------------------------------------------------

    @Test
    void testWithDelimiter() {
        assertEquals(";", CSVFormat.DEFAULT.withDelimiter(';').getDelimiterString());
    }

    @Test
    void testWithQuoteCharAndCharacter() {
        assertEquals(Character.valueOf('\''), CSVFormat.DEFAULT.withQuote('\'').getQuoteCharacter());
        assertNull(CSVFormat.DEFAULT.withQuote((Character) null).getQuoteCharacter());
    }

    @Test
    void testWithHeaderStrings() {
        assertArrayEquals(new String[] {"x", "y"}, CSVFormat.DEFAULT.withHeader("x", "y").getHeader());
    }

    @Test
    void testWithAllowDuplicateHeaderNames() {
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, CSVFormat.DEFAULT.withAllowDuplicateHeaderNames().getDuplicateHeaderMode());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, CSVFormat.DEFAULT.withAllowDuplicateHeaderNames(true).getDuplicateHeaderMode());
        assertEquals(DuplicateHeaderMode.ALLOW_EMPTY, CSVFormat.DEFAULT.withAllowDuplicateHeaderNames(false).getDuplicateHeaderMode());
    }

    @Test
    void testWithTrim() {
        assertTrue(CSVFormat.DEFAULT.withTrim().getTrim());
        assertTrue(CSVFormat.DEFAULT.withTrim(true).getTrim());
        assertFalse(CSVFormat.DEFAULT.withTrim(false).getTrim());
    }

    @Test
    void testWithRecordSeparatorCharAndString() {
        assertEquals("\n", CSVFormat.DEFAULT.withRecordSeparator('\n').getRecordSeparator());
        assertEquals("\r\n", CSVFormat.DEFAULT.withRecordSeparator("\r\n").getRecordSeparator());
    }

    @Test
    void testWithNullString() {
        assertEquals("NULL", CSVFormat.DEFAULT.withNullString("NULL").getNullString());
    }

    @Test
    void testWithQuoteMode() {
        assertEquals(QuoteMode.ALL, CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL).getQuoteMode());
    }

    @Test
    void testWithIgnoreEmptyLines() {
        assertTrue(CSVFormat.RFC4180.withIgnoreEmptyLines().getIgnoreEmptyLines());
        assertFalse(CSVFormat.DEFAULT.withIgnoreEmptyLines(false).getIgnoreEmptyLines());
    }

    @Test
    void testWithIgnoreHeaderCase() {
        assertTrue(CSVFormat.DEFAULT.withIgnoreHeaderCase().getIgnoreHeaderCase());
        assertTrue(CSVFormat.DEFAULT.withIgnoreHeaderCase(true).getIgnoreHeaderCase());
    }

    @Test
    void testWithIgnoreSurroundingSpaces() {
        assertTrue(CSVFormat.DEFAULT.withIgnoreSurroundingSpaces().getIgnoreSurroundingSpaces());
        assertTrue(CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(true).getIgnoreSurroundingSpaces());
    }

    @Test
    void testWithCommentMarkerCharAndCharacter() {
        assertEquals(Character.valueOf('#'), CSVFormat.DEFAULT.withCommentMarker('#').getCommentMarker());
        assertEquals(Character.valueOf('#'), CSVFormat.DEFAULT.withCommentMarker(Character.valueOf('#')).getCommentMarker());
    }

    @Test
    void testWithEscapeCharAndCharacter() {
        assertEquals(Character.valueOf('\\'), CSVFormat.DEFAULT.withEscape('\\').getEscapeCharacter());
        assertEquals(Character.valueOf('\\'), CSVFormat.DEFAULT.withEscape(Character.valueOf('\\')).getEscapeCharacter());
    }

    @Test
    void testWithSkipHeaderRecord() {
        assertTrue(CSVFormat.DEFAULT.withSkipHeaderRecord().getSkipHeaderRecord());
        assertTrue(CSVFormat.DEFAULT.withSkipHeaderRecord(true).getSkipHeaderRecord());
    }

    @Test
    void testWithTrailingDelimiter() {
        assertTrue(CSVFormat.DEFAULT.withTrailingDelimiter().getTrailingDelimiter());
        assertTrue(CSVFormat.DEFAULT.withTrailingDelimiter(true).getTrailingDelimiter());
    }

    @Test
    void testWithAutoFlush() {
        assertTrue(CSVFormat.DEFAULT.withAutoFlush(true).getAutoFlush());
    }

    @Test
    void testWithSystemRecordSeparator() {
        assertEquals(System.lineSeparator(), CSVFormat.DEFAULT.withSystemRecordSeparator().getRecordSeparator());
    }

    @Test
    void testWithAllowMissingColumnNames() {
        assertTrue(CSVFormat.DEFAULT.withAllowMissingColumnNames().getAllowMissingColumnNames());
        assertTrue(CSVFormat.DEFAULT.withAllowMissingColumnNames(true).getAllowMissingColumnNames());
    }

    @Test
    void testWithHeaderComments() {
        assertArrayEquals(new String[] {"c1", "c2"}, CSVFormat.DEFAULT.withHeaderComments("c1", "c2").getHeaderComments());
    }

    @Test
    void testWithFirstRecordAsHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.withFirstRecordAsHeader();
        assertArrayEquals(new String[0], format.getHeader());
        assertTrue(format.getSkipHeaderRecord());
    }

    @Test
    void testWithHeaderEnumClass() {
        assertArrayEquals(new String[] {"Name", "Email", "Phone"}, CSVFormat.DEFAULT.withHeader(SampleHeaderEnum.class).getHeader());
    }

    @Test
    void testWithHeaderResultSetAndMetaData() throws SQLException {
        final ResultSetMetaData metaData = mock(ResultSetMetaData.class);
        when(metaData.getColumnCount()).thenReturn(1);
        when(metaData.getColumnLabel(1)).thenReturn("COL");
        assertArrayEquals(new String[] {"COL"}, CSVFormat.DEFAULT.withHeader(metaData).getHeader());

        final ResultSet resultSet = mock(ResultSet.class);
        when(resultSet.getMetaData()).thenReturn(metaData);
        assertArrayEquals(new String[] {"COL"}, CSVFormat.DEFAULT.withHeader(resultSet).getHeader());
    }
}
