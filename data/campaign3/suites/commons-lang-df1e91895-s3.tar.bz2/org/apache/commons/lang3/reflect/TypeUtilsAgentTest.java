package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.GenericArrayType;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.TreeSet;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

class TypeUtilsAgentTest {

    static class PlainBox<T> {
    }

    static class NumberBox<T extends Number> {
    }

    static class Outer<T> {
        class Inner<S> {
        }
    }

    @SuppressWarnings("deprecation")
    @Test
    void testDeprecatedPublicConstructor() {
        TypeUtils instance = new TypeUtils();
        assertNotNull(instance);
    }

    @Test
    void testWildcardAllField() {
        assertArrayEquals(new Type[] { Object.class }, TypeUtils.WILDCARD_ALL.getUpperBounds());
        assertArrayEquals(new Type[0], TypeUtils.WILDCARD_ALL.getLowerBounds());
    }

    @Test
    void testContainsTypeVariables() {
        assertFalse(TypeUtils.containsTypeVariables(String.class));

        TypeVariable<?> plainVar = PlainBox.class.getTypeParameters()[0];
        assertTrue(TypeUtils.containsTypeVariables(plainVar));

        Type arrayOfVar = TypeUtils.genericArrayType(plainVar);
        assertTrue(TypeUtils.containsTypeVariables(arrayOfVar));

        Type listOfVar = TypeUtils.parameterize(List.class, plainVar);
        assertTrue(TypeUtils.containsTypeVariables(listOfVar));

        Type listOfString = TypeUtils.parameterize(List.class, String.class);
        assertFalse(TypeUtils.containsTypeVariables(listOfString));
    }

    @Test
    void testDetermineTypeArguments() {
        // Mirrors the TreeSet/Iterable example documented on determineTypeArguments.
        Type collectionOfWildcard = TypeUtils.parameterize(Collection.class, TypeUtils.WILDCARD_ALL);
        WildcardType extendsCollectionOfWildcard = TypeUtils.wildcardType().withUpperBounds(collectionOfWildcard).build();
        Type mapType = TypeUtils.parameterize(Map.class, Integer.class, extendsCollectionOfWildcard);
        WildcardType extendsMapType = TypeUtils.wildcardType().withUpperBounds(mapType).build();
        ParameterizedType iterableType = TypeUtils.parameterize(Iterable.class, extendsMapType);

        Map<TypeVariable<?>, Type> result = TypeUtils.determineTypeArguments(TreeSet.class, iterableType);
        TypeVariable<?> treeSetVar = TreeSet.class.getTypeParameters()[0];

        assertNotNull(result);
        assertTrue(result.containsKey(treeSetVar));
        assertTrue(TypeUtils.equals(extendsMapType, result.get(treeSetVar)));
    }

    @Test
    void testDetermineTypeArgumentsNullArguments() {
        final ParameterizedType iterableType = TypeUtils.parameterize(Iterable.class, String.class);
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                TypeUtils.determineTypeArguments(null, iterableType);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                TypeUtils.determineTypeArguments(TreeSet.class, null);
            }
        });
    }

    @Test
    void testEquals() {
        Type list1 = TypeUtils.parameterize(List.class, String.class);
        Type list2 = TypeUtils.parameterize(List.class, String.class);
        Type list3 = TypeUtils.parameterize(List.class, Integer.class);

        assertTrue(TypeUtils.equals(list1, list2));
        assertFalse(TypeUtils.equals(list1, list3));
        assertTrue(TypeUtils.equals(String.class, String.class));
        assertFalse(TypeUtils.equals(String.class, Integer.class));
    }

    @Test
    void testGenericArrayType() {
        GenericArrayType gat = TypeUtils.genericArrayType(String.class);
        assertEquals(String.class, gat.getGenericComponentType());
        assertTrue(TypeUtils.isArrayType(gat));
    }

    @Test
    void testGetArrayComponentType() {
        assertEquals(int.class, TypeUtils.getArrayComponentType(int[].class));
        assertEquals(String.class, TypeUtils.getArrayComponentType(String[].class));
        assertNull(TypeUtils.getArrayComponentType(String.class));

        GenericArrayType gat = TypeUtils.genericArrayType(String.class);
        assertEquals(String.class, TypeUtils.getArrayComponentType(gat));
    }

    @Test
    void testGetImplicitBounds() {
        TypeVariable<?> plainVar = PlainBox.class.getTypeParameters()[0];
        assertArrayEquals(new Type[] { Object.class }, TypeUtils.getImplicitBounds(plainVar));

        TypeVariable<?> numberVar = NumberBox.class.getTypeParameters()[0];
        assertArrayEquals(new Type[] { Number.class }, TypeUtils.getImplicitBounds(numberVar));
    }

    @Test
    void testGetImplicitBoundsNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                TypeUtils.getImplicitBounds(null);
            }
        });
    }

    @Test
    void testGetImplicitLowerBounds() {
        assertArrayEquals(new Type[] { null }, TypeUtils.getImplicitLowerBounds(TypeUtils.WILDCARD_ALL));

        WildcardType lowerString = TypeUtils.wildcardType().withLowerBounds(String.class).build();
        assertArrayEquals(new Type[] { String.class }, TypeUtils.getImplicitLowerBounds(lowerString));
    }

    @Test
    void testGetImplicitLowerBoundsNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                TypeUtils.getImplicitLowerBounds(null);
            }
        });
    }

    @Test
    void testGetImplicitUpperBounds() {
        assertArrayEquals(new Type[] { Object.class }, TypeUtils.getImplicitUpperBounds(TypeUtils.WILDCARD_ALL));

        WildcardType upperNumber = TypeUtils.wildcardType().withUpperBounds(Number.class).build();
        assertArrayEquals(new Type[] { Number.class }, TypeUtils.getImplicitUpperBounds(upperNumber));
    }

    @Test
    void testGetImplicitUpperBoundsNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                TypeUtils.getImplicitUpperBounds(null);
            }
        });
    }

    @Test
    void testGetRawType() {
        assertEquals(String.class, TypeUtils.getRawType(String.class, null));

        Type listOfString = TypeUtils.parameterize(List.class, String.class);
        assertEquals(List.class, TypeUtils.getRawType(listOfString, null));

        GenericArrayType gat = TypeUtils.genericArrayType(String.class);
        assertEquals(String[].class, TypeUtils.getRawType(gat, null));
    }

    @Test
    void testGetTypeArgumentsParameterizedType() {
        ParameterizedType pt = TypeUtils.parameterize(Map.class, String.class, Integer.class);
        Map<TypeVariable<?>, Type> args = TypeUtils.getTypeArguments(pt);

        TypeVariable<?> keyVar = Map.class.getTypeParameters()[0];
        TypeVariable<?> valueVar = Map.class.getTypeParameters()[1];

        assertEquals(String.class, args.get(keyVar));
        assertEquals(Integer.class, args.get(valueVar));
    }

    @Test
    void testGetTypeArgumentsSubtype() {
        Map<TypeVariable<?>, Type> result = TypeUtils.getTypeArguments(Properties.class, Map.class);

        TypeVariable<?> keyVar = Map.class.getTypeParameters()[0];
        TypeVariable<?> valueVar = Map.class.getTypeParameters()[1];

        assertEquals(Object.class, result.get(keyVar));
        assertEquals(Object.class, result.get(valueVar));

        assertNull(TypeUtils.getTypeArguments(String.class, List.class));

        Map<TypeVariable<?>, Type> emptyResult = TypeUtils.getTypeArguments(Object.class, Object.class);
        assertNotNull(emptyResult);
        assertTrue(emptyResult.isEmpty());
    }

    @Test
    void testIsArrayType() {
        assertTrue(TypeUtils.isArrayType(int[].class));
        assertTrue(TypeUtils.isArrayType(String[].class));
        assertTrue(TypeUtils.isArrayType(TypeUtils.genericArrayType(String.class)));
        assertFalse(TypeUtils.isArrayType(String.class));
        assertFalse(TypeUtils.isArrayType(TypeUtils.parameterize(List.class, String.class)));
    }

    @Test
    void testIsAssignable() {
        assertTrue(TypeUtils.isAssignable(String.class, Object.class));
        assertFalse(TypeUtils.isAssignable(Object.class, String.class));
        assertTrue(TypeUtils.isAssignable(Integer.class, Number.class));
        assertFalse(TypeUtils.isAssignable(String.class, Integer.class));
        assertTrue(TypeUtils.isAssignable(String.class, String.class));
    }

    @Test
    void testIsInstance() {
        assertTrue(TypeUtils.isInstance("hello", String.class));
        assertTrue(TypeUtils.isInstance(Integer.valueOf(5), Number.class));
        assertFalse(TypeUtils.isInstance("hello", Integer.class));
        assertFalse(TypeUtils.isInstance(Integer.valueOf(5), String.class));
    }

    @Test
    void testNormalizeUpperBounds() {
        Type[] bounds = new Type[] { Collection.class, List.class };
        assertArrayEquals(new Type[] { List.class }, TypeUtils.normalizeUpperBounds(bounds));

        Type[] singleBound = new Type[] { Number.class };
        assertArrayEquals(new Type[] { Number.class }, TypeUtils.normalizeUpperBounds(singleBound));
    }

    @Test
    void testNormalizeUpperBoundsNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                TypeUtils.normalizeUpperBounds(null);
            }
        });
    }

    @Test
    void testParameterizeVarargs() {
        ParameterizedType pt = TypeUtils.parameterize(List.class, String.class);
        assertEquals(List.class, pt.getRawType());
        assertArrayEquals(new Type[] { String.class }, pt.getActualTypeArguments());
        assertNull(pt.getOwnerType());
    }

    @Test
    void testParameterizeVarargsNullRawClass() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                TypeUtils.parameterize(null, String.class);
            }
        });
    }

    @Test
    void testParameterizeMap() {
        Map<TypeVariable<?>, Type> varMap = new HashMap<TypeVariable<?>, Type>();
        varMap.put(List.class.getTypeParameters()[0], String.class);
        ParameterizedType pt = TypeUtils.parameterize(List.class, varMap);

        assertTrue(TypeUtils.equals(TypeUtils.parameterize(List.class, String.class), pt));
    }

    @Test
    void testParameterizeMapNullArguments() {
        final Map<TypeVariable<?>, Type> varMap = new HashMap<TypeVariable<?>, Type>();
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                TypeUtils.parameterize(null, varMap);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                TypeUtils.parameterize(List.class, (Map<TypeVariable<?>, Type>) null);
            }
        });
    }

    @Test
    void testParameterizeWithOwnerVarargs() {
        Type ownerType = TypeUtils.parameterize(Outer.class, String.class);
        ParameterizedType innerPt = TypeUtils.parameterizeWithOwner(ownerType, Outer.Inner.class, Integer.class);

        assertEquals(Outer.Inner.class, innerPt.getRawType());
        assertArrayEquals(new Type[] { Integer.class }, innerPt.getActualTypeArguments());
        assertTrue(TypeUtils.equals(ownerType, innerPt.getOwnerType()));

        ParameterizedType topPt = TypeUtils.parameterizeWithOwner(null, List.class, String.class);
        assertNull(topPt.getOwnerType());
        assertTrue(TypeUtils.equals(TypeUtils.parameterize(List.class, String.class), topPt));
    }

    @Test
    void testParameterizeWithOwnerVarargsNullRawClass() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                TypeUtils.parameterizeWithOwner(null, null, String.class);
            }
        });
    }

    @Test
    void testParameterizeWithOwnerMap() {
        Map<TypeVariable<?>, Type> varMap = new HashMap<TypeVariable<?>, Type>();
        varMap.put(Outer.Inner.class.getTypeParameters()[0], Integer.class);
        Type ownerType = TypeUtils.parameterize(Outer.class, String.class);

        ParameterizedType innerPt = TypeUtils.parameterizeWithOwner(ownerType, Outer.Inner.class, varMap);

        assertEquals(Outer.Inner.class, innerPt.getRawType());
        assertArrayEquals(new Type[] { Integer.class }, innerPt.getActualTypeArguments());
        assertTrue(TypeUtils.equals(ownerType, innerPt.getOwnerType()));
    }

    @Test
    void testParameterizeWithOwnerMapNullArguments() {
        final Map<TypeVariable<?>, Type> varMap = new HashMap<TypeVariable<?>, Type>();
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                TypeUtils.parameterizeWithOwner(null, null, varMap);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                TypeUtils.parameterizeWithOwner(null, List.class, (Map<TypeVariable<?>, Type>) null);
            }
        });
    }

    @Test
    void testToLongStringAndToString() {
        TypeVariable<?> listVar = List.class.getTypeParameters()[0];

        String shortForm = TypeUtils.toString(listVar);
        String longForm = TypeUtils.toLongString(listVar);

        assertEquals(listVar.getName(), shortForm);
        assertNotNull(longForm);
        assertTrue(longForm.length() > shortForm.length());
        assertTrue(longForm.contains(listVar.getName()));
        assertTrue(longForm.contains("List"));
    }

    @Test
    void testToString() {
        assertEquals("java.lang.String", TypeUtils.toString(String.class));
        assertEquals("java.lang.String[]", TypeUtils.toString(String[].class));

        ParameterizedType listOfString = TypeUtils.parameterize(List.class, String.class);
        assertEquals("java.util.List<java.lang.String>", TypeUtils.toString(listOfString));
    }

    @Test
    void testToStringNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                TypeUtils.toString(null);
            }
        });
    }

    @Test
    void testToLongStringNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                TypeUtils.toLongString(null);
            }
        });
    }

    @Test
    void testTypesSatisfyVariables() {
        TypeVariable<?> numberVar = NumberBox.class.getTypeParameters()[0];

        Map<TypeVariable<?>, Type> satisfy = new HashMap<TypeVariable<?>, Type>();
        satisfy.put(numberVar, Integer.class);
        assertTrue(TypeUtils.typesSatisfyVariables(satisfy));

        Map<TypeVariable<?>, Type> violate = new HashMap<TypeVariable<?>, Type>();
        violate.put(numberVar, String.class);
        assertFalse(TypeUtils.typesSatisfyVariables(violate));
    }

    @Test
    void testTypesSatisfyVariablesNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                TypeUtils.typesSatisfyVariables(null);
            }
        });
    }

    @Test
    void testUnrollVariables() {
        ParameterizedType listOfString = TypeUtils.parameterize(List.class, String.class);
        Map<TypeVariable<?>, Type> argMap = TypeUtils.getTypeArguments(listOfString);
        TypeVariable<?> listVar = List.class.getTypeParameters()[0];

        assertEquals(String.class, TypeUtils.unrollVariables(argMap, listVar));
        assertEquals(String.class, TypeUtils.unrollVariables(new HashMap<TypeVariable<?>, Type>(), String.class));
    }

    @Test
    void testWildcardTypeBuilder() {
        TypeUtils.WildcardTypeBuilder builder = TypeUtils.wildcardType();
        TypeUtils.WildcardTypeBuilder afterUpper = builder.withUpperBounds(Number.class);
        assertSame(builder, afterUpper);
        TypeUtils.WildcardTypeBuilder afterLower = afterUpper.withLowerBounds(String.class);
        assertSame(builder, afterLower);

        WildcardType built = afterLower.build();
        assertArrayEquals(new Type[] { Number.class }, built.getUpperBounds());
        assertArrayEquals(new Type[] { String.class }, built.getLowerBounds());
    }

    @Test
    void testWildcardTypeBuilderDefaults() {
        WildcardType upperOnly = TypeUtils.wildcardType().withUpperBounds(Number.class).build();
        assertArrayEquals(new Type[] { Number.class }, upperOnly.getUpperBounds());
        assertArrayEquals(new Type[0], upperOnly.getLowerBounds());
    }

    @Test
    void testWrapClass() {
        Typed<String> wrapped = TypeUtils.wrap(String.class);
        assertNotNull(wrapped);
    }

    @Test
    void testWrapType() {
        Type type = String.class;
        Typed<?> wrapped = TypeUtils.wrap(type);
        assertNotNull(wrapped);
    }
}
