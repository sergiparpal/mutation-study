/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Map;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link ArrayUtils}.
 */
class ArrayUtilsAgentTest {

    @Test
    void testAddObject() {
        final String[] array = { "a", "b" };
        final String[] added = ArrayUtils.add(array, "c");
        assertArrayEquals(new String[] { "a", "b", "c" }, added);
        assertNotSame(array, added);

        final Integer[] fromNull = ArrayUtils.add((Integer[]) null, 1);
        assertArrayEquals(new Integer[] { 1 }, fromNull);
    }

    @Test
    void testAddIntPrimitiveAtIndex() {
        final int[] array = { 1, 2, 3 };
        assertArrayEquals(new int[] { 0, 1, 2, 3 }, ArrayUtils.add(array, 0, 0));
        assertArrayEquals(new int[] { 1, 2, 3, 4 }, ArrayUtils.add(array, 3, 4));
        assertArrayEquals(new int[] { 1, 9, 2, 3 }, ArrayUtils.add(array, 1, 9));
    }

    @Test
    void testAddIndexOutOfBounds() {
        final int[] array = { 1, 2, 3 };
        assertThrows(IndexOutOfBoundsException.class, () -> ArrayUtils.add(array, -1, 9));
        assertThrows(IndexOutOfBoundsException.class, () -> ArrayUtils.add(array, 4, 9));
    }

    @Test
    void testAddAllObjectArrays() {
        final String[] array1 = { "a", "b" };
        final String[] array2 = { "c", "d" };
        assertArrayEquals(new String[] { "a", "b", "c", "d" }, ArrayUtils.addAll(array1, array2));
        assertArrayEquals(array1, ArrayUtils.addAll(array1, (String[]) null));
        assertArrayEquals(array2, ArrayUtils.addAll(null, array2));
        assertNull(ArrayUtils.addAll((String[]) null, (String[]) null));
    }

    @Test
    void testAddAllIntArrays() {
        final int[] array1 = { 1, 2 };
        final int[] array2 = { 3, 4 };
        assertArrayEquals(new int[] { 1, 2, 3, 4 }, ArrayUtils.addAll(array1, array2));
        assertArrayEquals(new int[] { 1, 2 }, ArrayUtils.addAll(array1, new int[0]));
    }

    @Test
    void testAddFirst() {
        final int[] array = { 1, 2, 3 };
        assertArrayEquals(new int[] { 0, 1, 2, 3 }, ArrayUtils.addFirst(array, 0));
        assertArrayEquals(new int[] { 9 }, ArrayUtils.addFirst((int[]) null, 9));
    }

    @Test
    void testClonePrimitiveAndObjectArrays() {
        final int[] array = { 1, 2, 3 };
        final int[] cloned = ArrayUtils.clone(array);
        assertArrayEquals(array, cloned);
        assertNotSame(array, cloned);
        assertNull(ArrayUtils.clone((int[]) null));

        final Object[] objArray = { "a", "b" };
        final Object[] clonedObj = ArrayUtils.clone(objArray);
        assertArrayEquals(objArray, clonedObj);
        assertNotSame(objArray, clonedObj);
        assertNull(ArrayUtils.clone((Object[]) null));
    }

    @Test
    void testContains() {
        final int[] array = { 1, 2, 3 };
        assertTrue(ArrayUtils.contains(array, 2));
        assertFalse(ArrayUtils.contains(array, 4));
        assertFalse(ArrayUtils.contains((int[]) null, 1));

        final Object[] objArray = { "a", null, "c" };
        assertTrue(ArrayUtils.contains(objArray, "c"));
        assertTrue(ArrayUtils.contains(objArray, null));
        assertFalse(ArrayUtils.contains(objArray, "z"));
        assertFalse(ArrayUtils.contains((Object[]) null, "a"));
    }

    @Test
    void testContainsAny() {
        final int[] array = { 1, 2, 3 };
        assertTrue(ArrayUtils.containsAny(array, 5, 2));
        assertFalse(ArrayUtils.containsAny(array, 5, 6));
        assertFalse(ArrayUtils.containsAny((int[]) null, 1));

        final String[] strArray = { "a", "b" };
        assertTrue(ArrayUtils.containsAny(strArray, "z", "b"));
        assertFalse(ArrayUtils.containsAny(strArray, "y", "z"));
    }

    @Test
    void testGet() {
        final String[] array = { "a", "b", "c" };
        assertEquals("b", ArrayUtils.get(array, 1));
        assertNull(ArrayUtils.get(array, 5));
        assertNull(ArrayUtils.get(array, -1));
        assertEquals("default", ArrayUtils.get(array, 10, "default"));
        assertNull(ArrayUtils.get((String[]) null, 0));
    }

    @Test
    void testGetLength() {
        assertEquals(0, ArrayUtils.getLength(null));
        assertEquals(0, ArrayUtils.getLength(new int[0]));
        assertEquals(1, ArrayUtils.getLength(new Object[] { null }));
        assertEquals(3, ArrayUtils.getLength(new int[] { 1, 2, 3 }));
        assertThrows(IllegalArgumentException.class, () -> ArrayUtils.getLength("not an array"));
    }

    @Test
    void testHashCode() {
        assertEquals(ArrayUtils.hashCode(null), ArrayUtils.hashCode(null));
        final int[] array1 = { 1, 2, 3 };
        final int[] array2 = { 1, 2, 3 };
        final int[] array3 = { 3, 2, 1 };
        assertEquals(ArrayUtils.hashCode(array1), ArrayUtils.hashCode(array2));
        assertFalse(ArrayUtils.hashCode(array1) == ArrayUtils.hashCode(array3));
    }

    @Test
    void testIndexOf() {
        final int[] array = { 1, 2, 3, 2 };
        assertEquals(1, ArrayUtils.indexOf(array, 2));
        assertEquals(3, ArrayUtils.indexOf(array, 2, 2));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf(array, 9));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf((int[]) null, 1));
        assertEquals(1, ArrayUtils.indexOf(array, 2, -10));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf(array, 2, 10));
    }

    @Test
    void testLastIndexOf() {
        final int[] array = { 1, 2, 3, 2 };
        assertEquals(3, ArrayUtils.lastIndexOf(array, 2));
        assertEquals(1, ArrayUtils.lastIndexOf(array, 2, 2));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.lastIndexOf(array, 9));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.lastIndexOf((int[]) null, 1));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.lastIndexOf(array, 2, -1));
        assertEquals(3, ArrayUtils.lastIndexOf(array, 2, 100));
    }

    @Test
    void testIndexesOf() {
        final int[] array = { 1, 2, 3, 2 };
        final java.util.BitSet found = ArrayUtils.indexesOf(array, 2);
        assertTrue(found.get(1));
        assertTrue(found.get(3));
        assertEquals(2, found.cardinality());

        final java.util.BitSet notFound = ArrayUtils.indexesOf(array, 9);
        assertTrue(notFound.isEmpty());

        final java.util.BitSet fromStart = ArrayUtils.indexesOf(array, 2, 2);
        assertEquals(1, fromStart.cardinality());
        assertTrue(fromStart.get(3));

        assertTrue(ArrayUtils.indexesOf((int[]) null, 2).isEmpty());
    }

    @Test
    void testInsert() {
        final int[] array = { 1, 2, 3 };
        assertArrayEquals(new int[] { 9, 1, 2, 3 }, ArrayUtils.insert(0, array, 9));
        assertArrayEquals(new int[] { 1, 2, 3, 9 }, ArrayUtils.insert(3, array, 9));
        assertNull(ArrayUtils.insert(0, (int[]) null, 9));
        assertThrows(IndexOutOfBoundsException.class, () -> ArrayUtils.insert(-1, array, 9));
        assertThrows(IndexOutOfBoundsException.class, () -> ArrayUtils.insert(4, array, 9));
    }

    @Test
    void testIsArrayIndexValid() {
        final String[] array = { "a", "b" };
        assertTrue(ArrayUtils.isArrayIndexValid(array, 0));
        assertTrue(ArrayUtils.isArrayIndexValid(array, 1));
        assertFalse(ArrayUtils.isArrayIndexValid(array, 2));
        assertFalse(ArrayUtils.isArrayIndexValid(array, -1));
        assertFalse(ArrayUtils.isArrayIndexValid((String[]) null, 0));
    }

    @Test
    void testIsEmptyIsNotEmpty() {
        assertTrue(ArrayUtils.isEmpty((int[]) null));
        assertTrue(ArrayUtils.isEmpty(new int[0]));
        assertFalse(ArrayUtils.isEmpty(new int[] { 1 }));

        assertFalse(ArrayUtils.isNotEmpty((Object[]) null));
        assertFalse(ArrayUtils.isNotEmpty(new Object[0]));
        assertTrue(ArrayUtils.isNotEmpty(new Object[] { "a" }));
    }

    @Test
    void testIsSameLength() {
        assertTrue(ArrayUtils.isSameLength(new int[] { 1, 2 }, new int[] { 3, 4 }));
        assertFalse(ArrayUtils.isSameLength(new int[] { 1, 2 }, new int[] { 3 }));
        assertTrue(ArrayUtils.isSameLength((int[]) null, (int[]) null));
        assertFalse(ArrayUtils.isSameLength(null, new int[] { 1 }));
    }

    @Test
    void testIsSameType() {
        assertTrue(ArrayUtils.isSameType(new int[0], new int[0]));
        assertFalse(ArrayUtils.isSameType(new int[0], new long[0]));
        assertThrows(IllegalArgumentException.class, () -> ArrayUtils.isSameType(null, new int[0]));
        assertThrows(IllegalArgumentException.class, () -> ArrayUtils.isSameType(new int[0], null));
    }

    @Test
    void testIsSorted() {
        assertTrue(ArrayUtils.isSorted(new int[] { 1, 2, 3 }));
        assertFalse(ArrayUtils.isSorted(new int[] { 3, 2, 1 }));
        assertTrue(ArrayUtils.isSorted(new int[0]));
        assertTrue(ArrayUtils.isSorted((int[]) null));
        assertTrue(ArrayUtils.isSorted(new int[] { 5 }));
    }

    @Test
    void testNullToEmpty() {
        assertArrayEquals(new int[0], ArrayUtils.nullToEmpty((int[]) null));
        final int[] array = { 1, 2 };
        assertSame(array, ArrayUtils.nullToEmpty(array));

        assertArrayEquals(new String[0], ArrayUtils.nullToEmpty((String[]) null));
        final String[] strArray = { "a" };
        assertSame(strArray, ArrayUtils.nullToEmpty(strArray));
    }

    @Test
    void testRemoveIndex() {
        final int[] array = { 1, 2, 3 };
        assertArrayEquals(new int[] { 1, 3 }, ArrayUtils.remove(array, 1));
        assertArrayEquals(new int[] { 2, 3 }, ArrayUtils.remove(array, 0));
        assertThrows(IndexOutOfBoundsException.class, () -> ArrayUtils.remove(array, -1));
        assertThrows(IndexOutOfBoundsException.class, () -> ArrayUtils.remove(array, 3));
        assertThrows(IndexOutOfBoundsException.class, () -> ArrayUtils.remove((int[]) null, 0));
    }

    @Test
    void testRemoveAllIndices() {
        final String[] array = { "a", "b", "c", "d" };
        assertArrayEquals(new String[] { "a", "c" }, ArrayUtils.removeAll(array, 1, 3));
        assertArrayEquals(array, ArrayUtils.removeAll(array));
    }

    @Test
    void testRemoveAllOccurrences() {
        final int[] array = { 1, 2, 1, 3, 1 };
        assertArrayEquals(new int[] { 2, 3 }, ArrayUtils.removeAllOccurrences(array, 1));
        assertArrayEquals(array, ArrayUtils.removeAllOccurrences(array, 9));
    }

    @Test
    void testRemoveElement() {
        final int[] array = { 1, 2, 3, 2 };
        assertArrayEquals(new int[] { 1, 3, 2 }, ArrayUtils.removeElement(array, 2));
        assertArrayEquals(array, ArrayUtils.removeElement(array, 9));
    }

    @Test
    void testReverse() {
        final int[] array = { 1, 2, 3 };
        ArrayUtils.reverse(array);
        assertArrayEquals(new int[] { 3, 2, 1 }, array);

        final int[] rangeArray = { 1, 2, 3, 4, 5 };
        ArrayUtils.reverse(rangeArray, 1, 4);
        assertArrayEquals(new int[] { 1, 4, 3, 2, 5 }, rangeArray);

        ArrayUtils.reverse((int[]) null);
    }

    @Test
    void testShift() {
        final int[] array = { 1, 2, 3, 4, 5 };
        ArrayUtils.shift(array, 1);
        assertArrayEquals(new int[] { 5, 1, 2, 3, 4 }, array);

        final int[] array2 = { 1, 2, 3, 4, 5 };
        ArrayUtils.shift(array2, 0);
        assertArrayEquals(new int[] { 1, 2, 3, 4, 5 }, array2);

        ArrayUtils.shift((int[]) null, 1);
    }

    @Test
    void testShuffleKeepsAllElements() {
        final int[] array = { 1, 2, 3, 4, 5 };
        final int[] original = ArrayUtils.clone(array);
        ArrayUtils.shuffle(array, new java.util.Random(42));
        assertEquals(original.length, array.length);
        final int[] sortedOriginal = ArrayUtils.clone(original);
        final int[] sortedShuffled = ArrayUtils.clone(array);
        java.util.Arrays.sort(sortedOriginal);
        java.util.Arrays.sort(sortedShuffled);
        assertArrayEquals(sortedOriginal, sortedShuffled);
    }

    @Test
    void testStartsWith() {
        assertTrue(ArrayUtils.startsWith(new byte[] { 1, 2, 3 }, new byte[] { 1, 2 }));
        assertFalse(ArrayUtils.startsWith(new byte[] { 1, 2, 3 }, new byte[] { 2, 3 }));
        assertFalse(ArrayUtils.startsWith(new byte[] { 1, 2, 3 }, new byte[] { 1, 2, 3, 4 }));
        assertTrue(ArrayUtils.startsWith((byte[]) null, (byte[]) null));
        assertFalse(ArrayUtils.startsWith(new byte[] { 1 }, null));
        assertFalse(ArrayUtils.startsWith(null, new byte[] { 1 }));
    }

    @Test
    void testSubarray() {
        final int[] array = { 1, 2, 3, 4, 5 };
        assertArrayEquals(new int[] { 2, 3 }, ArrayUtils.subarray(array, 1, 3));
        assertArrayEquals(new int[] { 1, 2, 3, 4, 5 }, ArrayUtils.subarray(array, -2, 10));
        assertArrayEquals(new int[0], ArrayUtils.subarray(array, 3, 1));
        assertNull(ArrayUtils.subarray((int[]) null, 0, 1));
    }

    @Test
    void testSwap() {
        final int[] array = { 1, 2, 3 };
        ArrayUtils.swap(array, 0, 2);
        assertArrayEquals(new int[] { 3, 2, 1 }, array);

        final int[] array2 = { 1, 2, 3 };
        ArrayUtils.swap(array2, 0, 5);
        assertArrayEquals(new int[] { 1, 2, 3 }, array2);

        final int[] array3 = { 1, 2, 3 };
        ArrayUtils.swap(array3, -1, 1);
        assertArrayEquals(new int[] { 2, 1, 3 }, array3);

        ArrayUtils.swap((int[]) null, 0, 1);
    }

    @Test
    void testToArray() {
        final String[] array = ArrayUtils.toArray("a", "b", "c");
        assertArrayEquals(new String[] { "a", "b", "c" }, array);
    }

    @Test
    void testToMap() {
        final Map<Object, Object> map = ArrayUtils.toMap(new String[][] { { "RED", "#FF0000" }, { "GREEN", "#00FF00" } });
        assertEquals(2, map.size());
        assertEquals("#FF0000", map.get("RED"));
        assertNull(ArrayUtils.toMap(null));
        assertThrows(IllegalArgumentException.class, () -> ArrayUtils.toMap(new Object[] { "not a pair" }));
        assertThrows(IllegalArgumentException.class, () -> ArrayUtils.toMap(new Object[] { new String[] { "onlyone" } }));
    }

    @Test
    void testToObjectAndToPrimitiveInt() {
        final int[] primitive = { 1, 2, 3 };
        final Integer[] boxed = ArrayUtils.toObject(primitive);
        assertArrayEquals(new Integer[] { 1, 2, 3 }, boxed);
        assertNull(ArrayUtils.toObject((int[]) null));

        final int[] backToPrimitive = ArrayUtils.toPrimitive(boxed);
        assertArrayEquals(primitive, backToPrimitive);
        assertNull(ArrayUtils.toPrimitive((Integer[]) null));
        assertThrows(NullPointerException.class, () -> ArrayUtils.toPrimitive(new Integer[] { 1, null }));
    }

    @Test
    void testToPrimitiveWithDefault() {
        final Integer[] boxed = { 1, null, 3 };
        final int[] primitive = ArrayUtils.toPrimitive(boxed, -1);
        assertArrayEquals(new int[] { 1, -1, 3 }, primitive);
    }

    @Test
    void testToStringArray() {
        final Object[] array = { "a", 1, true };
        assertArrayEquals(new String[] { "a", "1", "true" }, ArrayUtils.toStringArray(array));
        assertNull(ArrayUtils.toStringArray(null));
        assertArrayEquals(new String[] { "N/A" }, ArrayUtils.toStringArray(new Object[] { null }, "N/A"));
    }

    @Test
    void testToStringMethod() {
        assertEquals("{}", ArrayUtils.toString(null));
        assertEquals("{}", ArrayUtils.toString(new Object[0]));
        assertNotNull(ArrayUtils.toString(new int[] { 1, 2, 3 }));
        assertEquals("EMPTY", ArrayUtils.toString(null, "EMPTY"));
    }
}
