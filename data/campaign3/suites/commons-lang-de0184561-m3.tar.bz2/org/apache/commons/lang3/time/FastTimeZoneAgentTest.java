/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Tests for {@link FastTimeZone}.
 */
class FastTimeZoneAgentTest {

    @Test
    void testGetGmtTimeZoneNoArg() {
        final TimeZone tz = FastTimeZone.getGmtTimeZone();
        assertNotNull(tz);
        assertEquals(0, tz.getRawOffset());
        assertEquals("GMT+00:00", tz.getID());
        assertSame(FastTimeZone.getGmtTimeZone(), tz);
    }

    @Test
    void testGetGmtTimeZoneZAndUtc() {
        assertSame(FastTimeZone.getGmtTimeZone(), FastTimeZone.getGmtTimeZone("Z"));
        assertSame(FastTimeZone.getGmtTimeZone(), FastTimeZone.getGmtTimeZone("UTC"));
    }

    @Test
    void testGetGmtTimeZoneEmptyAndBareSigns() {
        assertSame(FastTimeZone.getGmtTimeZone(), FastTimeZone.getGmtTimeZone(""));
        assertSame(FastTimeZone.getGmtTimeZone(), FastTimeZone.getGmtTimeZone("+"));
        assertSame(FastTimeZone.getGmtTimeZone(), FastTimeZone.getGmtTimeZone("-"));
        assertSame(FastTimeZone.getGmtTimeZone(), FastTimeZone.getGmtTimeZone("GMT"));
    }

    @Test
    void testGetGmtTimeZoneGmtCaseInsensitivePrefix() {
        final TimeZone tz = FastTimeZone.getGmtTimeZone("gmt+5");
        assertNotNull(tz);
        assertEquals(5 * 60 * 60 * 1000, tz.getRawOffset());
    }

    @Test
    void testGetGmtTimeZonePositiveHoursAndMinutes() {
        final TimeZone tz = FastTimeZone.getGmtTimeZone("GMT+01:02");
        assertNotNull(tz);
        assertEquals("GMT+01:02", tz.getID());
        assertEquals((1 * 60 + 2) * 60 * 1000, tz.getRawOffset());
    }

    @Test
    void testGetGmtTimeZoneNegativeHoursAndMinutes() {
        final TimeZone tz = FastTimeZone.getGmtTimeZone("-11:22");
        assertNotNull(tz);
        assertEquals("GMT-11:22", tz.getID());
        assertEquals(-(11 * 60 + 22) * 60 * 1000, tz.getRawOffset());
    }

    @Test
    void testGetGmtTimeZoneHoursOnlyNoColon() {
        final TimeZone tz = FastTimeZone.getGmtTimeZone("+0930");
        assertNotNull(tz);
        assertEquals((9 * 60 + 30) * 60 * 1000, tz.getRawOffset());
    }

    @Test
    void testGetGmtTimeZoneSingleDigitHour() {
        final TimeZone tz = FastTimeZone.getGmtTimeZone("+5");
        assertNotNull(tz);
        assertEquals(5 * 60 * 60 * 1000, tz.getRawOffset());
    }

    @Test
    void testGetGmtTimeZoneMinutesOnly() {
        // sign+hours absent, minutes-only group still matches the lenient pattern.
        final TimeZone tz = FastTimeZone.getGmtTimeZone(":30");
        assertNotNull(tz);
        assertEquals(30 * 60 * 1000, tz.getRawOffset());
    }

    @Test
    void testGetGmtTimeZoneHoursBoundaryInRange() {
        final TimeZone tz = FastTimeZone.getGmtTimeZone("+23:59");
        assertNotNull(tz);
        assertEquals((23 * 60 + 59) * 60 * 1000, tz.getRawOffset());
    }

    @Test
    void testGetGmtTimeZoneHoursOutOfRange() {
        assertNull(FastTimeZone.getGmtTimeZone("+24:00"));
    }

    @Test
    void testGetGmtTimeZoneMinutesOutOfRange() {
        assertNull(FastTimeZone.getGmtTimeZone("+00:60"));
    }

    @Test
    void testGetGmtTimeZoneInvalidPattern() {
        assertNull(FastTimeZone.getGmtTimeZone("bogus"));
        assertNull(FastTimeZone.getGmtTimeZone("GMT+1:2:3"));
        assertNull(FastTimeZone.getGmtTimeZone("++5"));
    }

    @Test
    void testGetTimeZoneDelegatesToGmtFirst() {
        final TimeZone tz = FastTimeZone.getTimeZone("+02:00");
        assertNotNull(tz);
        assertEquals(2 * 60 * 60 * 1000, tz.getRawOffset());
    }

    @Test
    void testGetTimeZoneFallsBackToOlsonId() {
        final TimeZone tz = FastTimeZone.getTimeZone("America/Chicago");
        assertNotNull(tz);
        assertEquals("America/Chicago", tz.getID());
    }

    @Test
    void testGetTimeZoneUnknownOlsonIdFallsBackToGmt() {
        final TimeZone tz = FastTimeZone.getTimeZone("Not/A_Real_Zone");
        assertNotNull(tz);
        // java.util.TimeZone.getTimeZone falls back to "GMT" for unrecognized ids.
        assertEquals("GMT", tz.getID());
        assertTrue(tz.getID() != null);
    }
}
