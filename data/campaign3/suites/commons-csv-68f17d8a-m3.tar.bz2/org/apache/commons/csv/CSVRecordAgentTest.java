/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

class CSVRecordAgentTest {

    private enum Header {
        NAME, AGE
    }

    private static CSVRecord recordWithHeader() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("NAME", "AGE").get();
        try (CSVParser parser = CSVParser.parse("John,32\n", format)) {
            final Iterator<CSVRecord> it = parser.iterator();
            final CSVRecord record = it.next();
            assertFalse(it.hasNext());
            return record;
        }
    }

    private static CSVRecord recordWithoutHeader() throws IOException {
        try (CSVParser parser = CSVParser.parse("John,32\n", CSVFormat.DEFAULT)) {
            return parser.iterator().next();
        }
    }

    @Test
    void testGetByIndex() throws IOException {
        final CSVRecord record = recordWithoutHeader();
        assertEquals("John", record.get(0));
        assertEquals("32", record.get(1));
    }

    @Test
    void testGetByIndexOutOfBoundsThrows() throws IOException {
        final CSVRecord record = recordWithoutHeader();
        assertThrows(ArrayIndexOutOfBoundsException.class, () -> record.get(2));
        assertThrows(ArrayIndexOutOfBoundsException.class, () -> record.get(-1));
    }

    @Test
    void testGetByNameWithHeader() throws IOException {
        final CSVRecord record = recordWithHeader();
        assertEquals("John", record.get("NAME"));
        assertEquals("32", record.get("AGE"));
    }

    @Test
    void testGetByNameUnmappedThrowsIllegalArgument() throws IOException {
        final CSVRecord record = recordWithHeader();
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> record.get("MISSING"));
        assertTrue(ex.getMessage().contains("MISSING"));
    }

    @Test
    void testGetByNameNullNameThrowsIllegalArgument() throws IOException {
        final CSVRecord record = recordWithHeader();
        assertThrows(IllegalArgumentException.class, () -> record.get((String) null));
    }

    @Test
    void testGetByNameWithoutHeaderThrowsIllegalState() throws IOException {
        final CSVRecord record = recordWithoutHeader();
        assertThrows(IllegalStateException.class, () -> record.get("NAME"));
    }

    @Test
    void testGetByNameInconsistentRecordThrowsIllegalArgument() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("NAME", "AGE", "EXTRA").get();
        try (CSVParser parser = CSVParser.parse("John,32\n", format)) {
            final CSVRecord record = parser.iterator().next();
            final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> record.get("EXTRA"));
            assertTrue(ex.getMessage().contains("EXTRA"));
        }
    }

    @Test
    void testGetByEnum() throws IOException {
        final CSVRecord record = recordWithHeader();
        assertEquals("John", record.get(Header.NAME));
        assertEquals("32", record.get(Header.AGE));
    }

    @Test
    void testGetByEnumNullThrowsIllegalState() throws IOException {
        final CSVRecord record = recordWithoutHeader();
        assertThrows(IllegalStateException.class, () -> record.get((Enum<?>) null));
    }

    @Test
    void testSize() throws IOException {
        final CSVRecord record = recordWithoutHeader();
        assertEquals(2, record.size());
    }

    @Test
    void testValuesNotACopy() throws IOException {
        final CSVRecord record = recordWithoutHeader();
        final String[] values = record.values();
        assertEquals(2, values.length);
        assertEquals("John", values[0]);
        assertEquals("32", values[1]);
    }

    @Test
    void testGetRecordNumber() throws IOException {
        try (CSVParser parser = CSVParser.parse("a\nb\nc\n", CSVFormat.DEFAULT)) {
            final Iterator<CSVRecord> it = parser.iterator();
            assertEquals(1, it.next().getRecordNumber());
            assertEquals(2, it.next().getRecordNumber());
            assertEquals(3, it.next().getRecordNumber());
        }
    }

    @Test
    void testGetCharacterPosition() throws IOException {
        try (CSVParser parser = CSVParser.parse("ab\ncd\n", CSVFormat.DEFAULT)) {
            final Iterator<CSVRecord> it = parser.iterator();
            final CSVRecord first = it.next();
            final CSVRecord second = it.next();
            assertEquals(0, first.getCharacterPosition());
            assertTrue(second.getCharacterPosition() > first.getCharacterPosition());
        }
    }

    @Test
    void testCommentAbsent() throws IOException {
        final CSVRecord record = recordWithoutHeader();
        assertFalse(record.hasComment());
        assertNull(record.getComment());
    }

    @Test
    void testCommentPresent() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        try (CSVParser parser = CSVParser.parse("# a comment\nJohn,32\n", format)) {
            final CSVRecord record = parser.iterator().next();
            assertTrue(record.hasComment());
            assertEquals("a comment", record.getComment());
        }
    }

    @Test
    void testGetParser() throws IOException {
        try (CSVParser parser = CSVParser.parse("John,32\n", CSVFormat.DEFAULT)) {
            final CSVRecord record = parser.iterator().next();
            assertEquals(parser, record.getParser());
        }
    }

    @Test
    void testIsConsistentTrueWhenSizesMatch() throws IOException {
        final CSVRecord record = recordWithHeader();
        assertTrue(record.isConsistent());
    }

    @Test
    void testIsConsistentFalseWhenSizesMismatch() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("NAME", "AGE", "EXTRA").get();
        try (CSVParser parser = CSVParser.parse("John,32\n", format)) {
            final CSVRecord record = parser.iterator().next();
            assertFalse(record.isConsistent());
        }
    }

    @Test
    void testIsConsistentTrueWithoutHeader() throws IOException {
        final CSVRecord record = recordWithoutHeader();
        assertTrue(record.isConsistent());
    }

    @Test
    void testIsMapped() throws IOException {
        final CSVRecord record = recordWithHeader();
        assertTrue(record.isMapped("NAME"));
        assertFalse(record.isMapped("MISSING"));
        assertFalse(record.isMapped(null));
    }

    @Test
    void testIsMappedWithoutHeader() throws IOException {
        final CSVRecord record = recordWithoutHeader();
        assertFalse(record.isMapped("NAME"));
    }

    @Test
    void testIsSetByIndex() throws IOException {
        final CSVRecord record = recordWithoutHeader();
        assertTrue(record.isSet(0));
        assertTrue(record.isSet(1));
        assertFalse(record.isSet(2));
        assertFalse(record.isSet(-1));
    }

    @Test
    void testIsSetByName() throws IOException {
        final CSVRecord record = recordWithHeader();
        assertTrue(record.isSet("NAME"));
        assertFalse(record.isSet("MISSING"));
    }

    @Test
    void testIsSetByNameBeyondValuesLength() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("NAME", "AGE", "EXTRA").get();
        try (CSVParser parser = CSVParser.parse("John,32\n", format)) {
            final CSVRecord record = parser.iterator().next();
            assertFalse(record.isSet("EXTRA"));
        }
    }

    @Test
    void testIterator() throws IOException {
        final CSVRecord record = recordWithoutHeader();
        final Iterator<String> it = record.iterator();
        assertTrue(it.hasNext());
        assertEquals("John", it.next());
        assertEquals("32", it.next());
        assertFalse(it.hasNext());
    }

    @Test
    void testToList() throws IOException {
        final CSVRecord record = recordWithoutHeader();
        final List<String> list = record.toList();
        assertEquals(2, list.size());
        assertEquals("John", list.get(0));
        assertEquals("32", list.get(1));
    }

    @Test
    void testStream() throws IOException {
        final CSVRecord record = recordWithoutHeader();
        final List<String> list = record.stream().collect(java.util.stream.Collectors.toList());
        assertEquals(2, list.size());
        assertEquals("32", list.get(1));
    }

    @Test
    void testToMapWithHeader() throws IOException {
        final CSVRecord record = recordWithHeader();
        final Map<String, String> map = record.toMap();
        assertEquals(2, map.size());
        assertEquals("John", map.get("NAME"));
        assertEquals("32", map.get("AGE"));
    }

    @Test
    void testToMapWithoutHeaderIsEmpty() throws IOException {
        final CSVRecord record = recordWithoutHeader();
        final Map<String, String> map = record.toMap();
        assertTrue(map.isEmpty());
    }

    @Test
    void testPutInExistingMap() throws IOException {
        final CSVRecord record = recordWithHeader();
        final Map<String, String> map = new HashMap<>();
        map.put("PRE_EXISTING", "value");
        final Map<String, String> result = record.putIn(map);
        assertEquals(map, result);
        assertEquals(3, map.size());
        assertEquals("John", map.get("NAME"));
        assertEquals("value", map.get("PRE_EXISTING"));
    }

    @Test
    void testPutInSkipsValuesBeyondHeaderMapping() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("NAME").get();
        try (CSVParser parser = CSVParser.parse("John,32\n", format)) {
            final CSVRecord record = parser.iterator().next();
            final Map<String, String> map = record.putIn(new HashMap<String, String>());
            assertEquals(1, map.size());
            assertEquals("John", map.get("NAME"));
        }
    }

    @Test
    void testToStringContainsValues() throws IOException {
        final CSVRecord record = recordWithoutHeader();
        final String str = record.toString();
        assertTrue(str.contains("John"));
        assertTrue(str.contains("32"));
        assertTrue(str.contains("recordNumber=1"));
    }

    @Test
    void testTrailingEmptyFieldYieldsEmptyValue() throws IOException {
        try (CSVParser parser = CSVParser.parse("a,\n", CSVFormat.DEFAULT)) {
            final CSVRecord record = parser.iterator().next();
            assertEquals(2, record.size());
            assertEquals("a", record.get(0));
            assertEquals("", record.get(1));
        }
    }
}
