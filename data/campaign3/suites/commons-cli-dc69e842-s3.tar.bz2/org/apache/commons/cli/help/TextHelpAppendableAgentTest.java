package org.apache.commons.cli.help;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link TextHelpAppendable} based solely on the documented contract
 * found in the generated javadoc (api/org/apache/commons/cli/help/TextHelpAppendable.html).
 */
public class TextHelpAppendableAgentTest {

    /** An Appendable that always fails, used to verify that IOException is propagated. */
    private static final class ThrowingAppendable implements Appendable {
        @Override
        public Appendable append(final CharSequence csq) throws IOException {
            throw new IOException("boom");
        }

        @Override
        public Appendable append(final CharSequence csq, final int start, final int end) throws IOException {
            throw new IOException("boom");
        }

        @Override
        public Appendable append(final char c) throws IOException {
            throw new IOException("boom");
        }
    }

    // ----- constants -----

    @Test
    public void testDefaultWidthConstant() {
        assertEquals(74, TextHelpAppendable.DEFAULT_WIDTH);
    }

    @Test
    public void testDefaultLeftPadConstant() {
        assertEquals(1, TextHelpAppendable.DEFAULT_LEFT_PAD);
    }

    @Test
    public void testDefaultIndentConstant() {
        assertEquals(3, TextHelpAppendable.DEFAULT_INDENT);
    }

    @Test
    public void testDefaultListIndentConstant() {
        assertEquals(7, TextHelpAppendable.DEFAULT_LIST_INDENT);
    }

    // ----- constructor & defaults -----

    @Test
    public void testConstructorWithAppendableUsesDefaults() {
        final TextHelpAppendable help = new TextHelpAppendable(new StringBuilder());
        assertEquals(TextHelpAppendable.DEFAULT_WIDTH, help.getMaxWidth());
        assertEquals(TextHelpAppendable.DEFAULT_LEFT_PAD, help.getLeftPad());
        assertEquals(TextHelpAppendable.DEFAULT_INDENT, help.getIndent());
    }

    @Test
    public void testConstructorWithNullOutputDoesNotThrow() {
        final TextHelpAppendable help = new TextHelpAppendable(null);
        assertEquals(TextHelpAppendable.DEFAULT_WIDTH, help.getMaxWidth());
        assertEquals(TextHelpAppendable.DEFAULT_LEFT_PAD, help.getLeftPad());
        assertEquals(TextHelpAppendable.DEFAULT_INDENT, help.getIndent());
    }

    // ----- getIndent / setIndent -----

    @Test
    public void testSetAndGetIndent() {
        final TextHelpAppendable help = new TextHelpAppendable(new StringBuilder());
        help.setIndent(10);
        assertEquals(10, help.getIndent());
        help.setIndent(0);
        assertEquals(0, help.getIndent());
    }

    // ----- getLeftPad / setLeftPad -----

    @Test
    public void testSetAndGetLeftPad() {
        final TextHelpAppendable help = new TextHelpAppendable(new StringBuilder());
        help.setLeftPad(5);
        assertEquals(5, help.getLeftPad());
        help.setLeftPad(0);
        assertEquals(0, help.getLeftPad());
    }

    // ----- getMaxWidth / setMaxWidth -----

    @Test
    public void testSetAndGetMaxWidth() {
        final TextHelpAppendable help = new TextHelpAppendable(new StringBuilder());
        help.setMaxWidth(100);
        assertEquals(100, help.getMaxWidth());
        help.setMaxWidth(1);
        assertEquals(1, help.getMaxWidth());
    }

    // ----- getTextStyleBuilder -----

    @Test
    public void testGetTextStyleBuilderNotNull() {
        final TextHelpAppendable help = new TextHelpAppendable(new StringBuilder());
        assertNotNull(help.getTextStyleBuilder());
    }

    // ----- systemOut (protected static, accessible from same package) -----

    @Test
    public void testSystemOutReturnsNewNonNullInstanceWithDefaults() {
        final TextHelpAppendable first = TextHelpAppendable.systemOut();
        final TextHelpAppendable second = TextHelpAppendable.systemOut();
        assertNotNull(first);
        assertNotNull(second);
        assertNotSame(first, second);
        assertEquals(TextHelpAppendable.DEFAULT_WIDTH, first.getMaxWidth());
        assertEquals(TextHelpAppendable.DEFAULT_LEFT_PAD, first.getLeftPad());
        assertEquals(TextHelpAppendable.DEFAULT_INDENT, first.getIndent());
    }

    // ----- resize (protected, accessible from same package) -----

    @Test
    public void testResizeReturnsSameBuilderInstance() {
        final TextHelpAppendable help = new TextHelpAppendable(new StringBuilder());
        final TextStyle.Builder builder = help.getTextStyleBuilder();
        final TextStyle.Builder result = help.resize(builder, 0.5);
        assertNotNull(result);
        assertSame(builder, result);
    }

    // ----- indexOfWrap (static) -----

    @Test
    public void testIndexOfWrapPicksLastWhitespaceBeforeLimit() {
        // "aaa bbb ccc" indices: 3 and 7 are spaces; width 9 from pos 0 -> limit 9, last space before it is 7.
        assertEquals(7, TextHelpAppendable.indexOfWrap("aaa bbb ccc", 9, 0));
    }

    @Test
    public void testIndexOfWrapWithStartPosOffset() {
        // Starting the search at position 4, the last whitespace before position 9 is still at index 7.
        assertEquals(7, TextHelpAppendable.indexOfWrap("aaa bbb ccc", 5, 4));
    }

    @Test
    public void testIndexOfWrapNoWhitespaceReturnsStartPosPlusWidth() {
        assertEquals(5, TextHelpAppendable.indexOfWrap("abcdefghij", 5, 0));
    }

    @Test
    public void testIndexOfWrapNoWhitespaceWithinShortTextReturnsTextLength() {
        // startPos+width (10) exceeds the text length (3); wrap position is at the end of the text.
        assertEquals(3, TextHelpAppendable.indexOfWrap("abc", 10, 0));
    }

    @Test
    public void testIndexOfWrapFindsWhitespaceBeyondWidthWhenTextIsShort() {
        // startPos+width (10) exceeds the text length (7) but a whitespace exists at index 3.
        assertEquals(3, TextHelpAppendable.indexOfWrap("abc def", 10, 0));
    }

    @Test
    public void testIndexOfWrapRecognizesCarriageReturnAsWhitespace() {
        assertEquals(2, TextHelpAppendable.indexOfWrap("ab\rcd", 3, 0));
    }

    @Test
    public void testIndexOfWrapRecognizesNewlineAsWhitespace() {
        assertEquals(2, TextHelpAppendable.indexOfWrap("ab\ncd", 3, 0));
    }

    @Test
    public void testIndexOfWrapDoesNotTreatTabAsWhitespace() {
        // Tab is not one of the documented whitespace characters (space, \n, \r), so no break is found
        // before the limit and startPos+width is returned.
        assertEquals(3, TextHelpAppendable.indexOfWrap("ab\tcd", 3, 0));
    }

    @Test
    public void testIndexOfWrapWhitespaceExactlyAtTextLength() {
        // "a bb": whitespace at index 1, startPos+width == text.length() (4).
        assertEquals(1, TextHelpAppendable.indexOfWrap("a bb", 4, 0));
    }

    // ----- appendHeader -----

    @Test
    public void testAppendHeaderWithNullTextIsNoop() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final TextHelpAppendable help = new TextHelpAppendable(sb);
        help.appendHeader(1, null);
        assertEquals(0, sb.length());
    }

    @Test
    public void testAppendHeaderWritesText() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final TextHelpAppendable help = new TextHelpAppendable(sb);
        help.appendHeader(1, "MyHeader");
        assertTrue(sb.toString().contains("MyHeader"));
    }

    @Test
    public void testAppendHeaderPropagatesIOException() {
        final TextHelpAppendable help = new TextHelpAppendable(new ThrowingAppendable());
        assertThrows(IOException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                help.appendHeader(1, "MyHeader");
            }
        });
    }

    // ----- appendList -----

    @Test
    public void testAppendListWithNullIsNoop() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final TextHelpAppendable help = new TextHelpAppendable(sb);
        help.appendList(true, null);
        assertEquals(0, sb.length());
    }

    @Test
    public void testAppendListWritesItems() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final TextHelpAppendable help = new TextHelpAppendable(sb);
        final Collection<CharSequence> list = new ArrayList<CharSequence>();
        list.add("firstItem");
        list.add("secondItem");
        help.appendList(false, list);
        final String out = sb.toString();
        assertTrue(out.contains("firstItem"));
        assertTrue(out.contains("secondItem"));
    }

    @Test
    public void testAppendListPropagatesIOException() {
        final TextHelpAppendable help = new TextHelpAppendable(new ThrowingAppendable());
        final Collection<CharSequence> list = new ArrayList<CharSequence>();
        list.add("item");
        assertThrows(IOException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                help.appendList(true, list);
            }
        });
    }

    // ----- appendParagraph -----

    @Test
    public void testAppendParagraphWithNullIsNoop() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final TextHelpAppendable help = new TextHelpAppendable(sb);
        help.appendParagraph(null);
        assertEquals(0, sb.length());
    }

    @Test
    public void testAppendParagraphWritesText() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final TextHelpAppendable help = new TextHelpAppendable(sb);
        help.appendParagraph("SomeParagraphText");
        assertTrue(sb.toString().contains("SomeParagraphText"));
    }

    @Test
    public void testAppendParagraphPropagatesIOException() {
        final TextHelpAppendable help = new TextHelpAppendable(new ThrowingAppendable());
        assertThrows(IOException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                help.appendParagraph("SomeParagraphText");
            }
        });
    }

    // ----- appendTitle -----

    @Test
    public void testAppendTitleWithNullIsNoop() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final TextHelpAppendable help = new TextHelpAppendable(sb);
        help.appendTitle(null);
        assertEquals(0, sb.length());
    }

    @Test
    public void testAppendTitleWritesText() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final TextHelpAppendable help = new TextHelpAppendable(sb);
        help.appendTitle("MyTitle");
        assertTrue(sb.toString().contains("MyTitle"));
    }

    @Test
    public void testAppendTitlePropagatesIOException() {
        final TextHelpAppendable help = new TextHelpAppendable(new ThrowingAppendable());
        assertThrows(IOException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                help.appendTitle("MyTitle");
            }
        });
    }

    // ----- appendTable -----

    @Test
    public void testAppendTableWithNullIsNoop() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final TextHelpAppendable help = new TextHelpAppendable(sb);
        help.appendTable(null);
        assertEquals(0, sb.length());
    }

    @Test
    public void testAppendTableWithNullIsNoopEvenWhenOutputWouldFail() throws IOException {
        // Confirms the null case never reaches the underlying Appendable at all.
        final TextHelpAppendable help = new TextHelpAppendable(new ThrowingAppendable());
        help.appendTable(null);
    }

    // ----- printWrapped(String) -----

    @Test
    public void testPrintWrappedWritesContent() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final TextHelpAppendable help = new TextHelpAppendable(sb);
        help.printWrapped("Hello");
        assertTrue(sb.length() > 0);
        assertTrue(sb.toString().contains("Hello"));
    }

    @Test
    public void testPrintWrappedProducesMultipleLinesWhenTextExceedsMaxWidth() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final TextHelpAppendable help = new TextHelpAppendable(sb);
        help.setMaxWidth(10);
        help.printWrapped("Hello wonderful world");
        final String out = sb.toString();
        assertTrue(out.contains("Hello"));
        assertTrue(out.contains("wonderful"));
        assertTrue(out.contains("world"));
        final String[] lines = out.split("\\r\\n|\\r|\\n");
        assertTrue(lines.length > 1);
    }

    @Test
    public void testPrintWrappedPropagatesIOException() {
        final TextHelpAppendable help = new TextHelpAppendable(new ThrowingAppendable());
        assertThrows(IOException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                help.printWrapped("Hello");
            }
        });
    }

    @Test
    public void testPrintWrappedWithEmptyStringDoesNotThrow() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final TextHelpAppendable help = new TextHelpAppendable(sb);
        help.printWrapped("");
        assertFalse(sb.toString().contains("Hello"));
    }
}
