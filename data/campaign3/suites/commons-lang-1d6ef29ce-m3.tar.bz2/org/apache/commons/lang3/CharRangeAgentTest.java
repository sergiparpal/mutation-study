/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Iterator;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link CharRange}.
 */
class CharRangeAgentTest {

    @Test
    void testIsFactory() {
        final CharRange range = CharRange.is('a');
        assertEquals('a', range.getStart());
        assertEquals('a', range.getEnd());
        assertFalse(range.isNegated());
        assertTrue(range.contains('a'));
        assertFalse(range.contains('b'));
    }

    @Test
    void testIsNotFactory() {
        final CharRange range = CharRange.isNot('a');
        assertEquals('a', range.getStart());
        assertEquals('a', range.getEnd());
        assertTrue(range.isNegated());
        assertFalse(range.contains('a'));
        assertTrue(range.contains('b'));
    }

    @Test
    void testIsInFactory() {
        final CharRange range = CharRange.isIn('a', 'e');
        assertEquals('a', range.getStart());
        assertEquals('e', range.getEnd());
        assertFalse(range.isNegated());
        assertTrue(range.contains('a'));
        assertTrue(range.contains('c'));
        assertTrue(range.contains('e'));
        assertFalse(range.contains('f'));
        assertFalse(range.contains('`'));
    }

    @Test
    void testIsInFactoryReversedArguments() {
        // Start and end reversed should be normalized.
        final CharRange range = CharRange.isIn('e', 'a');
        assertEquals('a', range.getStart());
        assertEquals('e', range.getEnd());
        assertFalse(range.isNegated());
    }

    @Test
    void testIsNotInFactory() {
        final CharRange range = CharRange.isNotIn('a', 'e');
        assertEquals('a', range.getStart());
        assertEquals('e', range.getEnd());
        assertTrue(range.isNegated());
        assertFalse(range.contains('a'));
        assertFalse(range.contains('c'));
        assertFalse(range.contains('e'));
        assertTrue(range.contains('f'));
        assertTrue(range.contains('`'));
    }

    @Test
    void testIsNotInFactoryReversedArguments() {
        final CharRange range = CharRange.isNotIn('e', 'a');
        assertEquals('a', range.getStart());
        assertEquals('e', range.getEnd());
        assertTrue(range.isNegated());
    }

    @Test
    void testContainsCharBoundaries() {
        final CharRange range = CharRange.isIn('b', 'd');
        assertFalse(range.contains('a'));
        assertTrue(range.contains('b'));
        assertTrue(range.contains('c'));
        assertTrue(range.contains('d'));
        assertFalse(range.contains('e'));
    }

    @Test
    void testContainsCharRangeNullThrowsNpe() {
        final CharRange range = CharRange.isIn('a', 'z');
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                range.contains((CharRange) null);
            }
        });
    }

    @Test
    void testContainsCharRangeNonNegatedInNonNegated() {
        final CharRange outer = CharRange.isIn('a', 'z');
        final CharRange inner = CharRange.isIn('c', 'd');
        assertTrue(outer.contains(inner));
        assertFalse(inner.contains(outer));
        // Equal ranges contain each other.
        assertTrue(outer.contains(CharRange.isIn('a', 'z')));
    }

    @Test
    void testContainsCharRangeNonNegatedOutsideFails() {
        final CharRange range = CharRange.isIn('c', 'd');
        final CharRange outsider = CharRange.isIn('a', 'z');
        assertFalse(range.contains(outsider));
    }

    @Test
    void testContainsCharRangeNegatedInNegated() {
        // negated containing negated: start >= range.start && end <= range.end
        final CharRange outer = CharRange.isNotIn('a', 'z');
        final CharRange inner = CharRange.isNotIn('c', 'd');
        assertTrue(inner.contains(outer));
        assertFalse(outer.contains(inner));
    }

    @Test
    void testContainsCharRangeNegatedContainsNonNegated() {
        // negated range contains non-negated range when they don't overlap.
        final CharRange negated = CharRange.isNotIn('m', 'p');
        final CharRange nonOverlapping = CharRange.isIn('a', 'c');
        assertTrue(negated.contains(nonOverlapping));

        final CharRange overlapping = CharRange.isIn('a', 'n');
        assertFalse(negated.contains(overlapping));
    }

    @Test
    void testContainsCharRangeNonNegatedContainsNegatedFullRange() {
        // non-negated contains negated only if non-negated spans the whole char space.
        final CharRange full = CharRange.isIn((char) 0, Character.MAX_VALUE);
        final CharRange negated = CharRange.isNotIn('a', 'z');
        assertTrue(full.contains(negated));

        final CharRange partial = CharRange.isIn('a', 'z');
        assertFalse(partial.contains(negated));
    }

    @Test
    void testContainsCharRangeNonNegatedContainsEmptyNegatedSet() {
        // A negated range over the entire char space denotes the empty set,
        // which is contained by anything.
        final CharRange emptySet = CharRange.isNotIn((char) 0, Character.MAX_VALUE);
        final CharRange small = CharRange.isIn('a', 'b');
        assertTrue(small.contains(emptySet));
    }

    @Test
    void testContainsCharRangeLowEmptyBoundary() {
        // range.start == 0 (lowEmpty) in a non-negated-contains-negated scenario.
        final CharRange negated = CharRange.isNotIn((char) 0, 'm');
        final CharRange containing = CharRange.isIn('n', Character.MAX_VALUE);
        assertTrue(containing.contains(negated));

        final CharRange notContaining = CharRange.isIn('a', 'z');
        assertFalse(notContaining.contains(negated));
    }

    @Test
    void testContainsCharRangeHighEmptyBoundary() {
        // range.end == Character.MAX_VALUE (highEmpty) scenario.
        final CharRange negated = CharRange.isNotIn('m', Character.MAX_VALUE);
        final CharRange containing = CharRange.isIn((char) 0, 'l');
        assertTrue(containing.contains(negated));

        final CharRange notContaining = CharRange.isIn('b', 'n');
        assertFalse(notContaining.contains(negated));
    }

    @Test
    void testEqualsAndHashCode() {
        final CharRange a = CharRange.isIn('a', 'z');
        final CharRange b = CharRange.isIn('a', 'z');
        final CharRange negatedSame = CharRange.isNotIn('a', 'z');
        final CharRange different = CharRange.isIn('a', 'y');

        assertEquals(a, a);
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
        assertNotEquals(a, negatedSame);
        assertNotEquals(a, different);
        assertNotEquals(a, null);
        assertNotEquals(a, "not a range");
    }

    @Test
    void testGetStartGetEndSingleChar() {
        final CharRange range = CharRange.is('x');
        assertEquals('x', range.getStart());
        assertEquals('x', range.getEnd());
    }

    @Test
    void testToStringSingleChar() {
        final CharRange range = CharRange.is('a');
        assertEquals("a", range.toString());
    }

    @Test
    void testToStringRange() {
        final CharRange range = CharRange.isIn('a', 'e');
        assertEquals("a-e", range.toString());
    }

    @Test
    void testToStringNegatedSingleChar() {
        final CharRange range = CharRange.isNot('a');
        assertEquals("^a", range.toString());
    }

    @Test
    void testToStringNegatedRange() {
        final CharRange range = CharRange.isNotIn('a', 'e');
        assertEquals("^a-e", range.toString());
    }

    @Test
    void testToStringCached() {
        final CharRange range = CharRange.isIn('a', 'e');
        final String first = range.toString();
        final String second = range.toString();
        assertEquals(first, second);
    }

    @Test
    void testIteratorNonNegatedRange() {
        final CharRange range = CharRange.isIn('a', 'd');
        final Iterator<Character> it = range.iterator();
        final StringBuilder sb = new StringBuilder();
        while (it.hasNext()) {
            sb.append(it.next().charValue());
        }
        assertEquals("abcd", sb.toString());
    }

    @Test
    void testIteratorSingleCharRange() {
        final CharRange range = CharRange.is('x');
        final Iterator<Character> it = range.iterator();
        assertTrue(it.hasNext());
        assertEquals(Character.valueOf('x'), it.next());
        assertFalse(it.hasNext());
    }

    @Test
    void testIteratorExhaustedThrowsNoSuchElementException() {
        final CharRange range = CharRange.is('x');
        final Iterator<Character> it = range.iterator();
        it.next();
        assertThrows(NoSuchElementException.class, new Executable() {
            @Override
            public void execute() {
                it.next();
            }
        });
    }

    @Test
    void testIteratorRemoveUnsupported() {
        final CharRange range = CharRange.is('x');
        final Iterator<Character> it = range.iterator();
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                it.remove();
            }
        });
    }

    @Test
    void testIteratorNegatedRangeStartsAtZero() {
        // negated range with start == 0: iteration should begin right after end.
        final CharRange range = CharRange.isNotIn((char) 0, (char) 2);
        final Iterator<Character> it = range.iterator();
        assertTrue(it.hasNext());
        assertEquals(Character.valueOf((char) 3), it.next());
    }

    @Test
    void testIteratorNegatedRangeCoversWholeSpaceIsEmpty() {
        // negated range spanning the whole char space denotes the empty set.
        final CharRange range = CharRange.isNotIn((char) 0, Character.MAX_VALUE);
        final Iterator<Character> it = range.iterator();
        assertFalse(it.hasNext());
        assertThrows(NoSuchElementException.class, new Executable() {
            @Override
            public void execute() {
                it.next();
            }
        });
    }

    @Test
    void testIteratorNegatedRangeEndsAtMaxValue() {
        // negated range with end == Character.MAX_VALUE: iteration stops once reaching start - 1.
        final char excludedStart = (char) (Character.MAX_VALUE - 2);
        final CharRange range = CharRange.isNotIn(excludedStart, Character.MAX_VALUE);
        final Iterator<Character> it = range.iterator();
        int count = 0;
        char last = 0;
        while (it.hasNext()) {
            last = it.next().charValue();
            count++;
        }
        assertEquals(excludedStart, count);
        assertEquals((char) (excludedStart - 1), last);
    }

    @Test
    void testIteratorNegatedRangeMiddleWrapsAround() {
        // negated range in the middle of the space iterates both below and above the hole.
        final CharRange range = CharRange.isNotIn('m', 'o');
        final Iterator<Character> it = range.iterator();
        assertTrue(it.hasNext());
        assertEquals(Character.valueOf((char) 0), it.next());
        // Skip ahead to confirm it eventually reaches past the excluded range.
        char lastBelow = 0;
        while (it.hasNext()) {
            final char next = it.next().charValue();
            if (next == 'p') {
                break;
            }
            lastBelow = next;
        }
        assertEquals('l', lastBelow);
    }
}
