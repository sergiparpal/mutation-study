package org.apache.commons.csv;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Self-contained tests for {@link CSVFormat} based on the published javadoc contract.
 */
public class CSVFormatAgentTest {

    private enum HeaderEnum {
        Name, Email, Phone
    }

    // ----- Predefined constants -----

    @Test
    public void testDefaultFormat() {
        CSVFormat format = CSVFormat.DEFAULT;
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertTrue(format.getIgnoreEmptyLines());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
        assertFalse(format.isCommentMarkerSet());
        assertFalse(format.isEscapeCharacterSet());
        assertFalse(format.isNullStringSet());
        assertTrue(format.isQuoteCharacterSet());
        assertNull(format.getHeader());
        assertNull(format.getHeaderComments());
        assertFalse(format.getSkipHeaderRecord());
        assertFalse(format.getTrailingDelimiter());
        assertFalse(format.getTrim());
        assertFalse(format.getAutoFlush());
        assertFalse(format.getAllowMissingColumnNames());
        assertFalse(format.getIgnoreHeaderCase());
        assertFalse(format.getIgnoreSurroundingSpaces());
        assertFalse(format.getLenientEof());
        assertFalse(format.getTrailingData());
        assertTrue(format.getMaxRows() <= 0);
    }

    @Test
    public void testExcelFormat() {
        CSVFormat format = CSVFormat.EXCEL;
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
        assertFalse(format.getIgnoreEmptyLines());
        assertTrue(format.getAllowMissingColumnNames());
        assertTrue(format.getTrailingData());
        assertTrue(format.getLenientEof());
    }

    @Test
    public void testRfc4180Format() {
        CSVFormat format = CSVFormat.RFC4180;
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertFalse(format.getIgnoreEmptyLines());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
    }

    @Test
    public void testTdfFormat() {
        CSVFormat format = CSVFormat.TDF;
        assertEquals("\t", format.getDelimiterString());
        assertTrue(format.getIgnoreSurroundingSpaces());
        assertTrue(format.getIgnoreEmptyLines());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
    }

    @Test
    public void testMySqlFormat() {
        CSVFormat format = CSVFormat.MYSQL;
        assertEquals("\t", format.getDelimiterString());
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
        assertFalse(format.getIgnoreEmptyLines());
        assertNull(format.getQuoteCharacter());
        assertEquals("\n", format.getRecordSeparator());
        assertEquals("\\N", format.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, format.getQuoteMode());
    }

    @Test
    public void testOracleFormat() {
        CSVFormat format = CSVFormat.ORACLE;
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
        assertFalse(format.getIgnoreEmptyLines());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertTrue(format.getTrim());
        assertEquals(System.lineSeparator(), format.getRecordSeparator());
        assertEquals(QuoteMode.MINIMAL, format.getQuoteMode());
    }

    @Test
    public void testPostgreSqlCsvFormat() {
        CSVFormat format = CSVFormat.POSTGRESQL_CSV;
        assertEquals(",", format.getDelimiterString());
        assertFalse(format.isEscapeCharacterSet());
        assertFalse(format.getIgnoreEmptyLines());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\n", format.getRecordSeparator());
        assertEquals("", format.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, format.getQuoteMode());
    }

    @Test
    public void testPostgreSqlTextFormat() {
        CSVFormat format = CSVFormat.POSTGRESQL_TEXT;
        assertEquals("\t", format.getDelimiterString());
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
        assertFalse(format.getIgnoreEmptyLines());
        assertNull(format.getQuoteCharacter());
        assertEquals("\n", format.getRecordSeparator());
        assertEquals("\\N", format.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, format.getQuoteMode());
    }

    @Test
    public void testMongoDbCsvFormat() {
        CSVFormat format = CSVFormat.MONGODB_CSV;
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getEscapeCharacter());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals(QuoteMode.MINIMAL, format.getQuoteMode());
        assertTrue(format.getIgnoreEmptyLines());
    }

    @Test
    public void testMongoDbTsvFormat() {
        CSVFormat format = CSVFormat.MONGODB_TSV;
        assertEquals("\t", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getEscapeCharacter());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals(QuoteMode.MINIMAL, format.getQuoteMode());
        assertFalse(format.getSkipHeaderRecord());
    }

    @Test
    public void testInformixUnloadFormat() {
        CSVFormat format = CSVFormat.INFORMIX_UNLOAD;
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\n", format.getRecordSeparator());
    }

    @Test
    public void testInformixUnloadCsvFormat() {
        CSVFormat format = CSVFormat.INFORMIX_UNLOAD_CSV;
        assertEquals(",", format.getDelimiterString());
        assertFalse(format.isEscapeCharacterSet());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\n", format.getRecordSeparator());
    }

    // ----- newFormat / valueOf -----

    @Test
    public void testNewFormatDefaults() {
        CSVFormat format = CSVFormat.newFormat(';');
        assertEquals(";", format.getDelimiterString());
        assertArrayEquals(new char[] {';'}, format.getDelimiterCharArray());
        assertNull(format.getQuoteCharacter());
        assertNull(format.getEscapeCharacter());
        assertNull(format.getCommentMarker());
        assertNull(format.getRecordSeparator());
        assertNull(format.getNullString());
        assertNull(format.getHeader());
        assertNull(format.getHeaderComments());
        assertNull(format.getQuoteMode());
        assertFalse(format.getIgnoreEmptyLines());
        assertFalse(format.getIgnoreHeaderCase());
        assertFalse(format.getIgnoreSurroundingSpaces());
        assertFalse(format.getSkipHeaderRecord());
        assertFalse(format.getTrailingDelimiter());
        assertFalse(format.getTrim());
        assertFalse(format.getAutoFlush());
        assertFalse(format.getAllowMissingColumnNames());
        assertFalse(format.getLenientEof());
        assertFalse(format.getTrailingData());
    }

    @Test
    public void testNewFormatRejectsLineBreakDelimiter() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.newFormat('\n');
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.newFormat('\r');
            }
        });
    }

    @Test
    public void testValueOfKnownNames() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.valueOf("Default"));
        assertEquals(CSVFormat.EXCEL, CSVFormat.valueOf("Excel"));
        assertEquals(CSVFormat.RFC4180, CSVFormat.valueOf("RFC4180"));
        assertEquals(CSVFormat.TDF, CSVFormat.valueOf("TDF"));
        assertEquals(CSVFormat.MYSQL, CSVFormat.valueOf("MySQL"));
    }

    @Test
    public void testValueOfUnknownNameThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.valueOf("NotAKnownFormat");
            }
        });
    }

    // ----- CSVFormat.Predefined -----

    @Test
    public void testPredefinedGetFormat() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.Predefined.Default.getFormat());
        assertEquals(CSVFormat.EXCEL, CSVFormat.Predefined.Excel.getFormat());
        assertEquals(CSVFormat.MYSQL, CSVFormat.Predefined.MySQL.getFormat());
        assertEquals(CSVFormat.TDF, CSVFormat.Predefined.TDF.getFormat());
    }

    @Test
    public void testPredefinedValueOfAndValues() {
        assertEquals(CSVFormat.Predefined.Default, CSVFormat.Predefined.valueOf("Default"));
        assertEquals(12, CSVFormat.Predefined.values().length);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.Predefined.valueOf("DoesNotExist");
            }
        });
    }

    // ----- equals / hashCode / toString / copy -----

    @Test
    public void testEqualsAndHashCode() {
        CSVFormat a = CSVFormat.DEFAULT;
        CSVFormat b = CSVFormat.newFormat(',').builder().setQuote('"').setRecordSeparator("\r\n")
                .setIgnoreEmptyLines(true).setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_ALL).get();
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
        assertNotEquals(CSVFormat.DEFAULT, CSVFormat.EXCEL);
        assertFalse(CSVFormat.DEFAULT.equals(null));
        assertFalse(CSVFormat.DEFAULT.equals("not a format"));
        assertTrue(CSVFormat.DEFAULT.equals(CSVFormat.DEFAULT));
    }

    @Test
    public void testToStringNotNull() {
        assertNotNull(CSVFormat.DEFAULT.toString());
        assertNotNull(CSVFormat.newFormat(',').toString());
    }

    @Test
    public void testCopyInstanceMethod() {
        CSVFormat copy = CSVFormat.DEFAULT.copy();
        assertEquals(CSVFormat.DEFAULT, copy);
    }

    @Test
    public void testStaticCopyNullSafe() {
        assertNull(CSVFormat.copy(null));
        CSVFormat copy = CSVFormat.copy(CSVFormat.EXCEL);
        assertEquals(CSVFormat.EXCEL, copy);
    }

    // ----- clone (package-private helper) -----

    @Test
    public void testCloneNullSafe() {
        assertNull(CSVFormat.<String>clone((String[]) null));
    }

    @Test
    public void testCloneCopiesArray() {
        String[] src = {"a", "b", "c"};
        String[] cloned = CSVFormat.clone(src);
        assertArrayEquals(src, cloned);
        assertNotSame(src, cloned);
    }

    // ----- getDelimiterCharArray / getEscapeChar (package-private helpers) -----

    @Test
    public void testGetDelimiterCharArray() {
        assertArrayEquals(new char[] {','}, CSVFormat.DEFAULT.getDelimiterCharArray());
        assertArrayEquals(new char[] {'\t'}, CSVFormat.MYSQL.getDelimiterCharArray());
    }

    @Test
    public void testGetEscapeChar() {
        assertEquals('\0', CSVFormat.DEFAULT.getEscapeChar());
        assertEquals('\\', CSVFormat.MYSQL.getEscapeChar());
    }

    // ----- builder() / Builder.create / Builder.get / Builder.build -----

    @Test
    public void testBuilderRoundTripEqualsOriginal() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.DEFAULT.builder().get());
        assertEquals(CSVFormat.EXCEL, CSVFormat.EXCEL.builder().get());
        assertEquals(CSVFormat.MYSQL, CSVFormat.MYSQL.builder().get());
    }

    @Test
    public void testBuilderIndependentInstances() {
        CSVFormat.Builder b1 = CSVFormat.DEFAULT.builder();
        CSVFormat.Builder b2 = CSVFormat.DEFAULT.builder();
        b1.setDelimiter(';');
        assertEquals(";", b1.get().getDelimiterString());
        assertEquals(",", b2.get().getDelimiterString());
    }

    @Test
    public void testBuilderCreateDefaults() {
        CSVFormat format = CSVFormat.Builder.create().get();
        assertEquals(CSVFormat.DEFAULT, format);
    }

    @Test
    public void testBuilderCreateFromFormat() {
        CSVFormat format = CSVFormat.Builder.create(CSVFormat.EXCEL).get();
        assertEquals(CSVFormat.EXCEL, format);
    }

    @Test
    public void testBuilderGetAndDeprecatedBuildAgree() {
        CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertEquals(builder.get(), builder.build());
    }

    @Test
    public void testOriginalFormatIsImmutableAfterBuilderMutation() {
        CSVFormat original = CSVFormat.DEFAULT;
        CSVFormat.Builder builder = original.builder();
        builder.setTrim(true).setDelimiter('|');
        CSVFormat mutated = builder.get();
        assertFalse(original.getTrim());
        assertEquals(",", original.getDelimiterString());
        assertTrue(mutated.getTrim());
        assertEquals("|", mutated.getDelimiterString());
    }

    // ----- Builder setters: comprehensive round trip -----

    @Test
    public void testBuilderSettersRoundTrip() {
        CSVFormat format = CSVFormat.Builder.create()
                .setDelimiter(';')
                .setQuote('\'')
                .setRecordSeparator("\n")
                .setCommentMarker('#')
                .setEscape('\\')
                .setHeader("H1", "H2")
                .setHeaderComments("c1", "c2")
                .setIgnoreEmptyLines(false)
                .setIgnoreHeaderCase(true)
                .setIgnoreSurroundingSpaces(true)
                .setLenientEof(true)
                .setMaxRows(10)
                .setNullString("NULL")
                .setQuoteMode(QuoteMode.ALL_NON_NULL)
                .setSkipHeaderRecord(true)
                .setTrailingData(true)
                .setTrailingDelimiter(true)
                .setTrim(true)
                .setAutoFlush(true)
                .setAllowMissingColumnNames(true)
                .setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_ALL)
                .get();

        assertEquals(";", format.getDelimiterString());
        assertEquals(Character.valueOf('\''), format.getQuoteCharacter());
        assertEquals("\n", format.getRecordSeparator());
        assertEquals(Character.valueOf('#'), format.getCommentMarker());
        assertTrue(format.isCommentMarkerSet());
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
        assertTrue(format.isEscapeCharacterSet());
        assertArrayEquals(new String[] {"H1", "H2"}, format.getHeader());
        assertArrayEquals(new String[] {"c1", "c2"}, format.getHeaderComments());
        assertFalse(format.getIgnoreEmptyLines());
        assertTrue(format.getIgnoreHeaderCase());
        assertTrue(format.getIgnoreSurroundingSpaces());
        assertTrue(format.getLenientEof());
        assertEquals(10L, format.getMaxRows());
        assertEquals("NULL", format.getNullString());
        assertTrue(format.isNullStringSet());
        assertEquals(QuoteMode.ALL_NON_NULL, format.getQuoteMode());
        assertTrue(format.getSkipHeaderRecord());
        assertTrue(format.getTrailingData());
        assertTrue(format.getTrailingDelimiter());
        assertTrue(format.getTrim());
        assertTrue(format.getAutoFlush());
        assertTrue(format.getAllowMissingColumnNames());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
    }

    @Test
    public void testSetMaxRowsAcceptsNonPositiveValues() {
        assertEquals(0L, CSVFormat.Builder.create().setMaxRows(0).get().getMaxRows());
        assertEquals(-5L, CSVFormat.Builder.create().setMaxRows(-5).get().getMaxRows());
    }

    @Test
    public void testSetHeaderEmptyMeansAutoDetect() {
        CSVFormat format = CSVFormat.Builder.create().setHeader().get();
        assertNotNull(format.getHeader());
        assertEquals(0, format.getHeader().length);
    }

    @Test
    public void testSetHeaderNullDisables() {
        CSVFormat format = CSVFormat.Builder.create().setHeader((String[]) null).get();
        assertNull(format.getHeader());
    }

    @Test
    public void testSetHeaderFromEnumClass() {
        CSVFormat format = CSVFormat.Builder.create().setHeader(HeaderEnum.class).get();
        assertArrayEquals(new String[] {"Name", "Email", "Phone"}, format.getHeader());
    }

    @Test
    public void testSetDelimiterString() {
        CSVFormat format = CSVFormat.Builder.create().setDelimiter(";;").get();
        assertEquals(";;", format.getDelimiterString());
    }

    @Test
    public void testSetQuoteCharacterNullDisables() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setQuote((Character) null).get();
        assertNull(format.getQuoteCharacter());
        assertFalse(format.isQuoteCharacterSet());
    }

    @Test
    public void testSetEscapeCharacterNullDisables() {
        CSVFormat format = CSVFormat.MYSQL.builder().setEscape((Character) null).get();
        assertNull(format.getEscapeCharacter());
        assertFalse(format.isEscapeCharacterSet());
    }

    @Test
    public void testSetCommentMarkerCharacterNullDisables() {
        CSVFormat withComment = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        assertTrue(withComment.isCommentMarkerSet());
        CSVFormat withoutComment = withComment.builder().setCommentMarker((Character) null).get();
        assertFalse(withoutComment.isCommentMarkerSet());
        assertNull(withoutComment.getCommentMarker());
    }

    @Test
    public void testDeprecatedSetAllowDuplicateHeaderNames() {
        CSVFormat format = CSVFormat.DEFAULT.builder().setAllowDuplicateHeaderNames(false).get();
        assertFalse(format.getAllowDuplicateHeaderNames());
    }

    // ----- Builder validation errors -----

    @Test
    public void testSetCommentMarkerCharRejectsLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                builder.setCommentMarker('\n');
            }
        });
    }

    @Test
    public void testSetCommentMarkerCharacterRejectsLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                builder.setCommentMarker(Character.valueOf('\r'));
            }
        });
    }

    @Test
    public void testSetEscapeCharRejectsLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                builder.setEscape('\n');
            }
        });
    }

    @Test
    public void testSetEscapeCharacterRejectsLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                builder.setEscape(Character.valueOf('\n'));
            }
        });
    }

    // ----- Deprecated CSVFormat-level with* methods -----

    @Test
    public void testWithQuote() {
        CSVFormat format = CSVFormat.DEFAULT.withQuote('\'');
        assertEquals(Character.valueOf('\''), format.getQuoteCharacter());
        assertEquals(Character.valueOf('"'), CSVFormat.DEFAULT.getQuoteCharacter());
    }

    @Test
    public void testWithQuoteRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.withQuote('\r');
            }
        });
    }

    @Test
    public void testWithDelimiter() {
        CSVFormat format = CSVFormat.DEFAULT.withDelimiter(';');
        assertEquals(";", format.getDelimiterString());
        assertEquals(",", CSVFormat.DEFAULT.getDelimiterString());
    }

    @Test
    public void testWithDelimiterRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.withDelimiter('\n');
            }
        });
    }

    @Test
    public void testWithEscape() {
        CSVFormat format = CSVFormat.DEFAULT.withEscape('\\');
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
    }

    @Test
    public void testWithEscapeRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.withEscape('\n');
            }
        });
    }

    @Test
    public void testWithCommentMarker() {
        CSVFormat format = CSVFormat.DEFAULT.withCommentMarker('#');
        assertEquals(Character.valueOf('#'), format.getCommentMarker());
        assertTrue(format.isCommentMarkerSet());
    }

    @Test
    public void testWithCommentMarkerRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.withCommentMarker('\n');
            }
        });
    }

    @Test
    public void testWithHeaderStrings() {
        CSVFormat format = CSVFormat.DEFAULT.withHeader("a", "b");
        assertArrayEquals(new String[] {"a", "b"}, format.getHeader());
        assertNull(CSVFormat.DEFAULT.getHeader());
    }

    @Test
    public void testWithNullString() {
        CSVFormat format = CSVFormat.DEFAULT.withNullString("N/A");
        assertEquals("N/A", format.getNullString());
        assertTrue(format.isNullStringSet());
    }

    @Test
    public void testWithRecordSeparatorChar() {
        CSVFormat format = CSVFormat.newFormat(',').withRecordSeparator('\n');
        assertEquals("\n", format.getRecordSeparator());
    }

    @Test
    public void testWithRecordSeparatorStringRejectsInvalidValue() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.withRecordSeparator(";");
            }
        });
    }

    @Test
    public void testWithRecordSeparatorStringAcceptsCrLf() {
        CSVFormat format = CSVFormat.newFormat(',').withRecordSeparator("\r\n");
        assertEquals("\r\n", format.getRecordSeparator());
    }

    @Test
    public void testWithTrim() {
        CSVFormat format = CSVFormat.DEFAULT.withTrim();
        assertTrue(format.getTrim());
        assertFalse(CSVFormat.DEFAULT.getTrim());
    }

    @Test
    public void testWithTrimBoolean() {
        assertTrue(CSVFormat.DEFAULT.withTrim(true).getTrim());
        assertFalse(CSVFormat.DEFAULT.withTrim(false).getTrim());
    }

    @Test
    public void testWithIgnoreSurroundingSpaces() {
        assertTrue(CSVFormat.DEFAULT.withIgnoreSurroundingSpaces().getIgnoreSurroundingSpaces());
    }

    @Test
    public void testWithIgnoreHeaderCase() {
        assertTrue(CSVFormat.DEFAULT.withIgnoreHeaderCase().getIgnoreHeaderCase());
    }

    @Test
    public void testWithSkipHeaderRecord() {
        assertTrue(CSVFormat.DEFAULT.withSkipHeaderRecord().getSkipHeaderRecord());
        assertFalse(CSVFormat.DEFAULT.withSkipHeaderRecord(false).getSkipHeaderRecord());
    }

    @Test
    public void testWithAllowMissingColumnNames() {
        assertTrue(CSVFormat.DEFAULT.withAllowMissingColumnNames().getAllowMissingColumnNames());
    }

    @Test
    public void testWithAllowDuplicateHeaderNames() {
        assertTrue(CSVFormat.DEFAULT.withAllowDuplicateHeaderNames().getAllowDuplicateHeaderNames());
        assertFalse(CSVFormat.DEFAULT.withAllowDuplicateHeaderNames(false).getAllowDuplicateHeaderNames());
    }

    @Test
    public void testWithTrailingDelimiter() {
        assertTrue(CSVFormat.DEFAULT.withTrailingDelimiter().getTrailingDelimiter());
        assertFalse(CSVFormat.DEFAULT.withTrailingDelimiter(false).getTrailingDelimiter());
    }

    @Test
    public void testWithSystemRecordSeparator() {
        assertEquals(System.lineSeparator(), CSVFormat.DEFAULT.withSystemRecordSeparator().getRecordSeparator());
    }

    @Test
    public void testWithFirstRecordAsHeader() {
        CSVFormat format = CSVFormat.DEFAULT.withFirstRecordAsHeader();
        assertNotNull(format.getHeader());
        assertEquals(0, format.getHeader().length);
        assertTrue(format.getSkipHeaderRecord());
    }

    @Test
    public void testWithHeaderComments() {
        CSVFormat format = CSVFormat.DEFAULT.withHeaderComments("line1", "line2");
        assertArrayEquals(new String[] {"line1", "line2"}, format.getHeaderComments());
    }

    @Test
    public void testWithHeaderEnumClass() {
        CSVFormat format = CSVFormat.DEFAULT.withHeader(HeaderEnum.class);
        assertArrayEquals(new String[] {"Name", "Email", "Phone"}, format.getHeader());
    }

    // ----- format(Object...) -----

    @Test
    public void testFormatNoValues() {
        assertEquals("", CSVFormat.DEFAULT.format());
    }

    @Test
    public void testFormatSimpleValues() {
        assertEquals("a,b,c", CSVFormat.DEFAULT.format("a", "b", "c"));
    }

    @Test
    public void testFormatQuotesValueContainingDelimiter() {
        assertEquals("\"a,b\",c", CSVFormat.DEFAULT.format("a,b", "c"));
    }

    @Test
    public void testFormatDoesNotAppendRecordSeparator() {
        String formatted = CSVFormat.DEFAULT.format("x", "y");
        assertFalse(formatted.endsWith("\r\n"));
    }

    // ----- print(Object, Appendable, boolean) -----

    @Test
    public void testPrintSingleValue() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.print("abc", sb, true);
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testPrintQuotesValueContainingDelimiter() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.print("a,b", sb, true);
        assertEquals("\"a,b\"", sb.toString());
    }

    @Test
    public void testPrintTrimsWhenTrimEnabled() throws IOException {
        CSVFormat format = CSVFormat.DEFAULT.builder().setTrim(true).get();
        StringBuilder sb = new StringBuilder();
        format.print(" a ", sb, true);
        assertEquals("a", sb.toString());
    }

    @Test
    public void testPrintDoesNotTrimByDefault() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.print(" a ", sb, true);
        assertEquals(" a ", sb.toString());
    }

    // ----- println(Appendable) -----

    @Test
    public void testPrintlnWritesOnlyRecordSeparatorByDefault() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.println(sb);
        assertEquals("\r\n", sb.toString());
    }

    @Test
    public void testPrintlnWritesTrailingDelimiterThenSeparator() throws IOException {
        CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get();
        StringBuilder sb = new StringBuilder();
        format.println(sb);
        assertEquals(",\r\n", sb.toString());
    }

    @Test
    public void testPrintlnWritesNothingWhenNeitherSet() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat.newFormat(',').println(sb);
        assertEquals("", sb.toString());
    }

    @Test
    public void testPrintlnWritesOnlyTrailingDelimiterWhenNoSeparator() throws IOException {
        CSVFormat format = CSVFormat.newFormat(',').builder().setTrailingDelimiter(true).get();
        StringBuilder sb = new StringBuilder();
        format.println(sb);
        assertEquals(",", sb.toString());
    }

    // ----- printRecord(Appendable, Object...) -----

    @Test
    public void testPrintRecordAppendsRecordSeparator() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.printRecord(sb, "a", "b", "c");
        assertEquals("a,b,c\r\n", sb.toString());
    }

    @Test
    public void testPrintRecordQuotesValueContainingDelimiter() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.printRecord(sb, "a,b", "c");
        assertEquals("\"a,b\",c\r\n", sb.toString());
    }

    @Test
    public void testPrintRecordWithNoValuesStillAppendsSeparator() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.printRecord(sb);
        assertEquals("\r\n", sb.toString());
    }

    // ----- print(Appendable) / printer() -----

    @Test
    public void testPrintToAppendableReturnsNonNullPrinter() throws IOException {
        StringWriter writer = new StringWriter();
        CSVPrinter printer = CSVFormat.DEFAULT.print(writer);
        assertNotNull(printer);
        printer.close();
    }

    @Test
    public void testPrinterReturnsNonNull() throws IOException {
        java.io.PrintStream original = System.out;
        try {
            System.setOut(new java.io.PrintStream(new java.io.ByteArrayOutputStream()));
            CSVPrinter printer = CSVFormat.DEFAULT.printer();
            assertNotNull(printer);
        } finally {
            System.setOut(original);
        }
    }

    // ----- print(File, Charset) / print(Path, Charset) -----

    @Test
    public void testPrintToFileWritesHeader() throws IOException {
        File file = File.createTempFile("csvformat-agent-test", ".csv");
        file.deleteOnExit();
        CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("A", "B").get();
        CSVPrinter printer = format.print(file, StandardCharsets.UTF_8);
        assertNotNull(printer);
        printer.close();
        byte[] content = Files.readAllBytes(file.toPath());
        assertTrue(content.length > 0);
        String text = new String(content, StandardCharsets.UTF_8);
        assertTrue(text.contains("A") && text.contains("B"));
    }

    @Test
    public void testPrintToPathMustBeClosedByCaller() throws IOException {
        Path path = Files.createTempFile("csvformat-agent-test", ".csv");
        path.toFile().deleteOnExit();
        CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("X", "Y").get();
        CSVPrinter printer = format.print(path, StandardCharsets.UTF_8);
        assertNotNull(printer);
        printer.close();
        byte[] content = Files.readAllBytes(path);
        assertTrue(content.length > 0);
    }

    // ----- parse(Reader) -----

    @Test
    public void testParseReturnsNonNullParser() throws IOException {
        StringReader reader = new StringReader("a,b\r\nc,d\r\n");
        CSVParser parser = CSVFormat.DEFAULT.parse(reader);
        assertNotNull(parser);
    }
}
