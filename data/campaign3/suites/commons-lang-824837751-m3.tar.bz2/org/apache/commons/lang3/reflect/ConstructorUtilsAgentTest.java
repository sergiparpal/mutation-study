/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link ConstructorUtils}.
 */
public class ConstructorUtilsAgentTest {

    public static class NoArgOnly {
        public NoArgOnly() {
            // empty
        }
    }

    public static class WithArgs {
        public final String stringValue;
        public final int intValue;

        public WithArgs(final String s) {
            this.stringValue = s;
            this.intValue = -1;
        }

        public WithArgs(final Integer i) {
            this.stringValue = null;
            this.intValue = i.intValue();
        }
    }

    public static class NumberHolder {
        public final Number value;

        public NumberHolder(final Number n) {
            this.value = n;
        }
    }

    public static class HierarchyHolder {
        public final String which;

        public HierarchyHolder(final Object o) {
            this.which = "Object";
        }

        public HierarchyHolder(final CharSequence cs) {
            this.which = "CharSequence";
        }
    }

    public static class ThrowingCtor {
        public ThrowingCtor() {
            throw new IllegalStateException("boom");
        }
    }

    public abstract static class AbstractFixture {
        public AbstractFixture() {
            // empty
        }
    }

    private static class PrivateFixture {
        public PrivateFixture() {
            // empty
        }
    }

    // ---- getAccessibleConstructor(Class, Class...) ----

    @Test
    public void testGetAccessibleConstructor_classAndParams_nullClassThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                ConstructorUtils.getAccessibleConstructor((Class<?>) null);
            }
        });
    }

    @Test
    public void testGetAccessibleConstructor_classAndParams_publicNoArg() throws Exception {
        final Constructor<String> ctor = ConstructorUtils.getAccessibleConstructor(String.class);
        assertNotNull(ctor);
        assertEquals(0, ctor.getParameterTypes().length);
        assertEquals(String.class, ctor.getDeclaringClass());
    }

    @Test
    public void testGetAccessibleConstructor_classAndParams_noMatchReturnsNull() {
        final Constructor<String> ctor = ConstructorUtils.getAccessibleConstructor(String.class, Boolean.class);
        assertNull(ctor);
    }

    @Test
    public void testGetAccessibleConstructor_classAndParams_nonPublicClassReturnsNull() {
        final Constructor<PrivateFixture> ctor = ConstructorUtils.getAccessibleConstructor(PrivateFixture.class);
        assertNull(ctor);
    }

    // ---- getAccessibleConstructor(Constructor) ----

    @Test
    public void testGetAccessibleConstructor_ctor_nullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                ConstructorUtils.getAccessibleConstructor((Constructor<?>) null);
            }
        });
    }

    @Test
    public void testGetAccessibleConstructor_ctor_accessibleReturnsSameSignature() throws Exception {
        final Constructor<NoArgOnly> raw = NoArgOnly.class.getConstructor();
        final Constructor<NoArgOnly> result = ConstructorUtils.getAccessibleConstructor(raw);
        assertNotNull(result);
        assertEquals(NoArgOnly.class, result.getDeclaringClass());
    }

    @Test
    public void testGetAccessibleConstructor_ctor_nonPublicDeclaringClassReturnsNull() throws Exception {
        final Constructor<PrivateFixture> raw = PrivateFixture.class.getDeclaredConstructor();
        final Constructor<PrivateFixture> result = ConstructorUtils.getAccessibleConstructor(raw);
        assertNull(result);
    }

    // ---- getMatchingAccessibleConstructor(Class, Class...) ----

    @Test
    public void testGetMatchingAccessibleConstructor_nullClassThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                ConstructorUtils.getMatchingAccessibleConstructor((Class<?>) null);
            }
        });
    }

    @Test
    public void testGetMatchingAccessibleConstructor_exactMatch() {
        final Constructor<WithArgs> ctor = ConstructorUtils.getMatchingAccessibleConstructor(WithArgs.class, String.class);
        assertNotNull(ctor);
        assertEquals(String.class, ctor.getParameterTypes()[0]);
    }

    @Test
    public void testGetMatchingAccessibleConstructor_compatibleMatch() {
        final Constructor<NumberHolder> ctor = ConstructorUtils.getMatchingAccessibleConstructor(NumberHolder.class, Integer.class);
        assertNotNull(ctor);
        assertEquals(Number.class, ctor.getParameterTypes()[0]);
    }

    @Test
    public void testGetMatchingAccessibleConstructor_picksMostSpecificFit() {
        final Constructor<HierarchyHolder> ctor = ConstructorUtils.getMatchingAccessibleConstructor(HierarchyHolder.class, String.class);
        assertNotNull(ctor);
        assertEquals(CharSequence.class, ctor.getParameterTypes()[0]);
    }

    @Test
    public void testGetMatchingAccessibleConstructor_noMatchReturnsNull() {
        final Constructor<WithArgs> ctor = ConstructorUtils.getMatchingAccessibleConstructor(WithArgs.class, Boolean.class);
        assertNull(ctor);
    }

    @Test
    public void testGetMatchingAccessibleConstructor_nonPublicClassReturnsNull() {
        final Constructor<PrivateFixture> ctor = ConstructorUtils.getMatchingAccessibleConstructor(PrivateFixture.class);
        assertNull(ctor);
    }

    // ---- invokeConstructor(Class, Object...) ----

    @Test
    public void testInvokeConstructor_varargs_noArgs() throws Exception {
        final NoArgOnly result = ConstructorUtils.invokeConstructor(NoArgOnly.class);
        assertNotNull(result);
    }

    @Test
    public void testInvokeConstructor_varargs_stringArg() throws Exception {
        final WithArgs result = ConstructorUtils.invokeConstructor(WithArgs.class, "hello");
        assertEquals("hello", result.stringValue);
        assertEquals(-1, result.intValue);
    }

    @Test
    public void testInvokeConstructor_varargs_integerArg() throws Exception {
        final WithArgs result = ConstructorUtils.invokeConstructor(WithArgs.class, Integer.valueOf(5));
        assertNull(result.stringValue);
        assertEquals(5, result.intValue);
    }

    @Test
    public void testInvokeConstructor_varargs_noSuchMethod() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            public void execute() throws Throwable {
                ConstructorUtils.invokeConstructor(WithArgs.class, Boolean.TRUE);
            }
        });
    }

    @Test
    public void testInvokeConstructor_varargs_nullClassThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                ConstructorUtils.invokeConstructor(null, "ignored");
            }
        });
    }

    @Test
    public void testInvokeConstructor_varargs_constructorThrowsWrapped() {
        final InvocationTargetException thrown = assertThrows(InvocationTargetException.class, new Executable() {
            public void execute() throws Throwable {
                ConstructorUtils.invokeConstructor(ThrowingCtor.class);
            }
        });
        assertTrue(thrown.getCause() instanceof IllegalStateException);
        assertEquals("boom", thrown.getCause().getMessage());
    }

    @Test
    public void testInvokeConstructor_varargs_abstractClassThrowsInstantiationException() {
        assertThrows(InstantiationException.class, new Executable() {
            public void execute() throws Throwable {
                ConstructorUtils.invokeConstructor(AbstractFixture.class);
            }
        });
    }

    @Test
    public void testInvokeConstructor_varargs_nonPublicClassThrowsNoSuchMethod() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            public void execute() throws Throwable {
                ConstructorUtils.invokeConstructor(PrivateFixture.class);
            }
        });
    }

    // ---- invokeConstructor(Class, Object[], Class[]) ----

    @Test
    public void testInvokeConstructor_explicitTypes_matchesByDeclaredParamType() throws Exception {
        final NumberHolder result = ConstructorUtils.invokeConstructor(NumberHolder.class, new Object[] {Integer.valueOf(42)},
                new Class<?>[] {Number.class});
        assertEquals(42, result.value.intValue());
    }

    @Test
    public void testInvokeConstructor_explicitTypes_nullArraysTreatedAsEmpty() throws Exception {
        final NoArgOnly result = ConstructorUtils.invokeConstructor(NoArgOnly.class, null, null);
        assertNotNull(result);
    }

    // ---- invokeExactConstructor(Class, Object...) ----

    @Test
    public void testInvokeExactConstructor_varargs_exactMatch() throws Exception {
        final WithArgs result = ConstructorUtils.invokeExactConstructor(WithArgs.class, "exact");
        assertEquals("exact", result.stringValue);
    }

    @Test
    public void testInvokeExactConstructor_varargs_noSubtypeMatch() {
        // NumberHolder only declares a Number constructor; an Integer argument does not
        // match exactly even though it is assignable, unlike invokeConstructor.
        assertThrows(NoSuchMethodException.class, new Executable() {
            public void execute() throws Throwable {
                ConstructorUtils.invokeExactConstructor(NumberHolder.class, Integer.valueOf(3));
            }
        });
    }

    @Test
    public void testInvokeExactConstructor_varargs_nullClassThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                ConstructorUtils.invokeExactConstructor(null, "ignored");
            }
        });
    }

    // ---- invokeExactConstructor(Class, Object[], Class[]) ----

    @Test
    public void testInvokeExactConstructor_explicitTypes_exactDeclaredTypeWorks() throws Exception {
        final NumberHolder result = ConstructorUtils.invokeExactConstructor(NumberHolder.class, new Object[] {Integer.valueOf(7)},
                new Class<?>[] {Number.class});
        assertEquals(7, result.value.intValue());
    }

    @Test
    public void testInvokeExactConstructor_explicitTypes_noMatchThrowsNoSuchMethod() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            public void execute() throws Throwable {
                ConstructorUtils.invokeExactConstructor(WithArgs.class, new Object[] {Boolean.TRUE}, new Class<?>[] {Boolean.class});
            }
        });
    }

    @Test
    public void testInvokeExactConstructor_explicitTypes_nullArraysTreatedAsEmpty() throws Exception {
        final NoArgOnly result = ConstructorUtils.invokeExactConstructor(NoArgOnly.class, null, null);
        assertNotNull(result);
    }

    // ---- public deprecated no-arg constructor ----

    @Test
    public void testPublicConstructor() {
        final ConstructorUtils instance = new ConstructorUtils();
        assertNotNull(instance);
    }
}
