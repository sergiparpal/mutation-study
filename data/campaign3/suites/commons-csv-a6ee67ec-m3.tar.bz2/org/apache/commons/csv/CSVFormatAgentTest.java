/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringWriter;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link CSVFormat}.
 */
class CSVFormatAgentTest {

    private enum HeaderEnum {
        Name, Email, Phone
    }

    @Test
    void testNewFormat() {
        final CSVFormat format = CSVFormat.newFormat(';');
        assertEquals(";", format.getDelimiterString());
        assertNull(format.getQuoteCharacter());
        assertNull(format.getCommentMarker());
        assertNull(format.getRecordSeparator());
        assertFalse(format.getSkipHeaderRecord());
        assertNull(format.getHeader());
    }

    @Test
    void testDefaultFormatDefaults() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertTrue(format.getIgnoreEmptyLines());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
        assertFalse(format.isCommentMarkerSet());
        assertFalse(format.isEscapeCharacterSet());
        assertFalse(format.isNullStringSet());
        assertEquals(0L, format.getMaxRows());
        assertFalse(format.useMaxRows());
    }

    @Test
    void testPredefinedFormatsHaveExpectedSettings() {
        assertEquals("\t", CSVFormat.TDF.getDelimiterString());
        assertTrue(CSVFormat.TDF.getIgnoreSurroundingSpaces());

        assertFalse(CSVFormat.RFC4180.getIgnoreEmptyLines());

        assertTrue(CSVFormat.EXCEL.getAllowMissingColumnNames());
        assertTrue(CSVFormat.EXCEL.getTrailingData());
        assertTrue(CSVFormat.EXCEL.getLenientEof());
        assertFalse(CSVFormat.EXCEL.getIgnoreEmptyLines());

        assertEquals(Character.valueOf('\\'), CSVFormat.MYSQL.getEscapeCharacter());
        assertNull(CSVFormat.MYSQL.getQuoteCharacter());
        assertEquals("\\N", CSVFormat.MYSQL.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, CSVFormat.MYSQL.getQuoteMode());

        assertEquals(Character.valueOf('|'), CSVFormat.INFORMIX_UNLOAD.getDelimiterString().charAt(0));
    }

    @Test
    void testValueOfReturnsPredefinedFormat() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.valueOf("Default"));
        assertEquals(CSVFormat.EXCEL, CSVFormat.valueOf("Excel"));
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.valueOf("NoSuchFormat"));
    }

    @Test
    void testBuilderRoundTrip() {
        final CSVFormat original = CSVFormat.DEFAULT;
        final CSVFormat copy = original.builder().get();
        assertEquals(original, copy);
        assertNotEquals((Object) null, copy);
    }

    @Test
    void testSetDelimiterRejectsEmptyString() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, () -> builder.setDelimiter(""));
    }

    @Test
    void testSetDelimiterRejectsLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, () -> builder.setDelimiter('\n'));
        assertThrows(IllegalArgumentException.class, () -> builder.setDelimiter("a\rb"));
    }

    @Test
    void testSetCommentMarkerRejectsLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, () -> builder.setCommentMarker('\n'));
        assertThrows(IllegalArgumentException.class, () -> builder.setCommentMarker('\r'));
    }

    @Test
    void testSetEscapeRejectsLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, () -> builder.setEscape('\n'));
    }

    @Test
    void testSetQuoteRejectsLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertThrows(IllegalArgumentException.class, () -> builder.setQuote('\r'));
    }

    @Test
    void testValidateQuoteCharacterSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setDelimiter(',').setQuote(',').get());
    }

    @Test
    void testValidateEscapeCharacterSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setDelimiter(',').setEscape(',').get());
    }

    @Test
    void testValidateCommentMarkerSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setDelimiter(',').setCommentMarker(',').get());
    }

    @Test
    void testValidateQuoteCharacterSameAsCommentMarkerThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setCommentMarker('#').setQuote('#').get());
    }

    @Test
    void testValidateEscapeCharacterSameAsCommentMarkerThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setCommentMarker('#').setEscape('#').get());
    }

    @Test
    void testValidateQuoteModeNoneWithoutEscapeThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setEscape(null).setQuoteMode(QuoteMode.NONE).get());
    }

    @Test
    void testValidateQuoteModeNoneWithEscapeOk() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').setQuoteMode(QuoteMode.NONE).get();
        assertEquals(QuoteMode.NONE, format.getQuoteMode());
    }

    @Test
    void testDuplicateHeaderNamesDisallowedByDefaultMode() {
        assertThrows(IllegalArgumentException.class,
                () -> CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).setHeader("A", "B", "A").get());
    }

    @Test
    void testDuplicateHeaderNamesAllowedWithAllowAllMode() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("A", "B", "A").get();
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
        assertEquals(3, format.getHeader().length);
    }

    @Test
    void testDuplicateEmptyHeaderNamesAllowedWithAllowEmptyMode() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("", "B", "").get();
        assertEquals(3, format.getHeader().length);
    }

    @Test
    void testDuplicateEmptyHeaderNamesDisallowedWithDisallowMode() {
        assertThrows(IllegalArgumentException.class,
                () -> CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).setHeader("", "B", "").get());
    }

    @Test
    void testGetHeaderReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("A", "B").get();
        final String[] header1 = format.getHeader();
        header1[0] = "MUTATED";
        final String[] header2 = format.getHeader();
        assertEquals("A", header2[0]);
    }

    @Test
    void testGetHeaderNullWhenNotSet() {
        assertNull(CSVFormat.DEFAULT.getHeader());
    }

    @Test
    void testSetHeaderFromEnum() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(HeaderEnum.class).get();
        assertEquals(3, format.getHeader().length);
        assertEquals("Name", format.getHeader()[0]);
        assertEquals("Email", format.getHeader()[1]);
        assertEquals("Phone", format.getHeader()[2]);
    }

    @Test
    void testSetHeaderFromNullEnum() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader((Class<? extends Enum<?>>) null).get();
        assertNull(format.getHeader());
    }

    @Test
    void testSetHeaderFromResultSetMetaData() throws SQLException {
        final ResultSetMetaData metaData = new StubResultSetMetaData(new String[] {"Col1", "Col2"});
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(metaData).get();
        assertEquals(2, format.getHeader().length);
        assertEquals("Col1", format.getHeader()[0]);
        assertEquals("Col2", format.getHeader()[1]);
    }

    @Test
    void testSetHeaderFromNullResultSet() throws SQLException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader((ResultSet) null).get();
        assertNull(format.getHeader());
    }

    @Test
    void testGetHeaderCommentsReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeaderComments("line1", "line2").get();
        final String[] comments1 = format.getHeaderComments();
        comments1[0] = "MUTATED";
        final String[] comments2 = format.getHeaderComments();
        assertEquals("line1", comments2[0]);
    }

    @Test
    void testSetHeaderCommentsFromObjects() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeaderComments("text", Integer.valueOf(42), null).get();
        final String[] comments = format.getHeaderComments();
        assertEquals("text", comments[0]);
        assertEquals("42", comments[1]);
        assertNull(comments[2]);
    }

    @Test
    void testSetNullStringAlsoBuildsQuotedNullString() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuote('"').setNullString("NULL").get();
        assertEquals("NULL", format.getNullString());
        assertTrue(format.isNullStringSet());
    }

    @Test
    void testIsNullStringSetFalseByDefault() {
        assertFalse(CSVFormat.DEFAULT.isNullStringSet());
        assertNull(CSVFormat.DEFAULT.getNullString());
    }

    @Test
    void testSetQuoteNullDisablesQuoting() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuote((Character) null).get();
        assertFalse(format.isQuoteCharacterSet());
        assertNull(format.getQuoteCharacter());
    }

    @Test
    void testSetMaxRows() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(5L).get();
        assertEquals(5L, format.getMaxRows());
        assertTrue(format.useMaxRows());
        assertTrue(format.useRow(5L));
        assertFalse(format.useRow(6L));
    }

    @Test
    void testMaxRowsZeroMeansNoLimit() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(0L).get();
        assertFalse(format.useMaxRows());
        assertTrue(format.useRow(Long.MAX_VALUE));
    }

    @Test
    void testFormatValues() {
        final CSVFormat format = CSVFormat.DEFAULT;
        final String result = format.format("a", "b,c", "d");
        assertEquals("a,\"b,c\",d", result);
    }

    @Test
    void testFormatEmptyValues() {
        final String result = CSVFormat.DEFAULT.format();
        assertEquals("", result);
    }

    @Test
    void testPrintRecordAppendsRecordSeparator() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.printRecord(writer, "x", "y");
        assertEquals("x,y\r\n", writer.toString());
    }

    @Test
    void testPrintlnWithTrailingDelimiter() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).setRecordSeparator("\n").get().println(writer);
        assertEquals(",\n", writer.toString());
    }

    @Test
    void testPrintlnWithoutRecordSeparator() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.builder().setRecordSeparator(null).get().println(writer);
        assertEquals("", writer.toString());
    }

    @Test
    void testPrintSingleValueWithQuoting() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.print("a\"b", writer, true);
        assertEquals("\"a\"\"b\"", writer.toString());
    }

    @Test
    void testPrintNullValueWithoutNullString() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.print(null, writer, true);
        assertEquals("", writer.toString());
    }

    @Test
    void testPrintNullValueWithNullString() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.builder().setNullString("NULL").get().print(null, writer, true);
        assertEquals("NULL", writer.toString());
    }

    @Test
    void testPrintTrimsValueWhenTrimSet() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.builder().setTrim(true).setQuote(null).get().print("  spaced  ", writer, true);
        assertEquals("spaced", writer.toString());
    }

    @Test
    void testEqualsAndHashCode() {
        final CSVFormat a = CSVFormat.DEFAULT.builder().setHeader("A", "B").get();
        final CSVFormat b = CSVFormat.DEFAULT.builder().setHeader("A", "B").get();
        final CSVFormat c = CSVFormat.DEFAULT.builder().setHeader("A", "C").get();
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
        assertNotEquals(a, c);
        assertNotEquals(a, "not a CSVFormat");
        assertNotEquals(null, a);
        assertEquals(a, a);
    }

    @Test
    void testToStringContainsConfiguredAttributes() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').setNullString("NULL").setHeader("A", "B").get();
        final String str = format.toString();
        assertTrue(str.contains("Delimiter=<,>"));
        assertTrue(str.contains("QuoteChar=<\">"));
        assertTrue(str.contains("CommentStart=<#>"));
        assertTrue(str.contains("NullString=<NULL>"));
        assertTrue(str.contains("Header:"));
    }

    @Test
    void testIsEscapeCharacterSet() {
        assertFalse(CSVFormat.DEFAULT.isEscapeCharacterSet());
        assertTrue(CSVFormat.DEFAULT.builder().setEscape('\\').get().isEscapeCharacterSet());
    }

    @Test
    void testIsCommentMarkerSet() {
        assertFalse(CSVFormat.DEFAULT.isCommentMarkerSet());
        assertTrue(CSVFormat.DEFAULT.builder().setCommentMarker('#').get().isCommentMarkerSet());
    }

    @Test
    void testDeprecatedGetDelimiterReturnsFirstChar() {
        assertEquals(',', CSVFormat.DEFAULT.getDelimiter());
    }

    @Test
    void testDeprecatedWithDelimiter() {
        final CSVFormat format = CSVFormat.DEFAULT.withDelimiter(';');
        assertEquals(";", format.getDelimiterString());
    }

    @Test
    void testDeprecatedWithAllowDuplicateHeaderNames() {
        final CSVFormat format = CSVFormat.DEFAULT.withAllowDuplicateHeaderNames(false);
        assertEquals(DuplicateHeaderMode.ALLOW_EMPTY, format.getDuplicateHeaderMode());
        assertFalse(format.getAllowDuplicateHeaderNames());
    }

    @Test
    void testBuilderGetReturnsNewInstanceEachTime() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        final CSVFormat first = builder.get();
        final CSVFormat second = builder.get();
        assertNotNull(first);
        assertNotNull(second);
        assertEquals(first, second);
    }

    @Test
    void testParseReturnsParserOverContent() throws IOException {
        final java.io.StringReader reader = new java.io.StringReader("a,b\nc,d\n");
        final CSVParser parser = CSVFormat.DEFAULT.parse(reader);
        assertNotNull(parser);
        final java.util.List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        assertEquals("a", records.get(0).get(0));
        parser.close();
    }

    /** Minimal stand-in for a JDBC ResultSetMetaData, used only to exercise {@code Builder#setHeader(ResultSetMetaData)}. */
    private static final class StubResultSetMetaData implements ResultSetMetaData {
        private final String[] labels;

        StubResultSetMetaData(final String[] labels) {
            this.labels = labels;
        }

        @Override
        public int getColumnCount() {
            return labels.length;
        }

        @Override
        public String getColumnLabel(final int column) {
            return labels[column - 1];
        }

        @Override
        public <T> T unwrap(final Class<T> iface) {
            return null;
        }

        @Override
        public boolean isWrapperFor(final Class<?> iface) {
            return false;
        }

        @Override
        public boolean isAutoIncrement(final int column) {
            return false;
        }

        @Override
        public boolean isCaseSensitive(final int column) {
            return false;
        }

        @Override
        public boolean isSearchable(final int column) {
            return false;
        }

        @Override
        public boolean isCurrency(final int column) {
            return false;
        }

        @Override
        public int isNullable(final int column) {
            return 0;
        }

        @Override
        public boolean isSigned(final int column) {
            return false;
        }

        @Override
        public int getColumnDisplaySize(final int column) {
            return 0;
        }

        @Override
        public String getColumnName(final int column) {
            return labels[column - 1];
        }

        @Override
        public String getSchemaName(final int column) {
            return null;
        }

        @Override
        public int getPrecision(final int column) {
            return 0;
        }

        @Override
        public int getScale(final int column) {
            return 0;
        }

        @Override
        public String getTableName(final int column) {
            return null;
        }

        @Override
        public String getCatalogName(final int column) {
            return null;
        }

        @Override
        public int getColumnType(final int column) {
            return 0;
        }

        @Override
        public String getColumnTypeName(final int column) {
            return null;
        }

        @Override
        public boolean isReadOnly(final int column) {
            return false;
        }

        @Override
        public boolean isWritable(final int column) {
            return false;
        }

        @Override
        public boolean isDefinitelyWritable(final int column) {
            return false;
        }

        @Override
        public String getColumnClassName(final int column) {
            return null;
        }
    }
}
