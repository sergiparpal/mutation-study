package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;

import org.junit.jupiter.api.Test;

public class NumberUtilsAgentTest {

    // ------------------------------------------------------------------
    // Reusable constant fields
    // ------------------------------------------------------------------

    @Test
    public void testByteConstants() {
        assertEquals((byte) 0, NumberUtils.BYTE_ZERO.byteValue());
        assertEquals((byte) 1, NumberUtils.BYTE_ONE.byteValue());
        assertEquals((byte) -1, NumberUtils.BYTE_MINUS_ONE.byteValue());
    }

    @Test
    public void testShortConstants() {
        assertEquals((short) 0, NumberUtils.SHORT_ZERO.shortValue());
        assertEquals((short) 1, NumberUtils.SHORT_ONE.shortValue());
        assertEquals((short) -1, NumberUtils.SHORT_MINUS_ONE.shortValue());
    }

    @Test
    public void testIntegerConstants() {
        assertEquals(0, NumberUtils.INTEGER_ZERO.intValue());
        assertEquals(1, NumberUtils.INTEGER_ONE.intValue());
        assertEquals(2, NumberUtils.INTEGER_TWO.intValue());
        assertEquals(-1, NumberUtils.INTEGER_MINUS_ONE.intValue());
    }

    @Test
    public void testLongConstants() {
        assertEquals(0L, NumberUtils.LONG_ZERO.longValue());
        assertEquals(1L, NumberUtils.LONG_ONE.longValue());
        assertEquals(-1L, NumberUtils.LONG_MINUS_ONE.longValue());
        assertEquals((long) Integer.MAX_VALUE, NumberUtils.LONG_INT_MAX_VALUE.longValue());
        assertEquals((long) Integer.MIN_VALUE, NumberUtils.LONG_INT_MIN_VALUE.longValue());
    }

    @Test
    public void testFloatConstants() {
        assertEquals(0.0f, NumberUtils.FLOAT_ZERO.floatValue(), 0.0f);
        assertEquals(1.0f, NumberUtils.FLOAT_ONE.floatValue(), 0.0f);
        assertEquals(-1.0f, NumberUtils.FLOAT_MINUS_ONE.floatValue(), 0.0f);
    }

    @Test
    public void testDoubleConstants() {
        assertEquals(0.0d, NumberUtils.DOUBLE_ZERO.doubleValue(), 0.0d);
        assertEquals(1.0d, NumberUtils.DOUBLE_ONE.doubleValue(), 0.0d);
        assertEquals(-1.0d, NumberUtils.DOUBLE_MINUS_ONE.doubleValue(), 0.0d);
    }

    // ------------------------------------------------------------------
    // compare(...)
    // ------------------------------------------------------------------

    @Test
    public void testCompareByte() {
        assertEquals(0, NumberUtils.compare((byte) 5, (byte) 5));
        assertTrue(NumberUtils.compare((byte) 1, (byte) 2) < 0);
        assertTrue(NumberUtils.compare((byte) 2, (byte) 1) > 0);
    }

    @Test
    public void testCompareInt() {
        assertEquals(0, NumberUtils.compare(5, 5));
        assertTrue(NumberUtils.compare(1, 2) < 0);
        assertTrue(NumberUtils.compare(2, 1) > 0);
    }

    @Test
    public void testCompareLong() {
        assertEquals(0, NumberUtils.compare(5L, 5L));
        assertTrue(NumberUtils.compare(1L, 2L) < 0);
        assertTrue(NumberUtils.compare(2L, 1L) > 0);
    }

    @Test
    public void testCompareShort() {
        assertEquals(0, NumberUtils.compare((short) 5, (short) 5));
        assertTrue(NumberUtils.compare((short) 1, (short) 2) < 0);
        assertTrue(NumberUtils.compare((short) 2, (short) 1) > 0);
    }

    // ------------------------------------------------------------------
    // createBigDecimal
    // ------------------------------------------------------------------

    @Test
    public void testCreateBigDecimalNull() {
        assertNull(NumberUtils.createBigDecimal(null));
    }

    @Test
    public void testCreateBigDecimalValid() {
        assertEquals(new BigDecimal("1.5"), NumberUtils.createBigDecimal("1.5"));
    }

    @Test
    public void testCreateBigDecimalInvalid() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                NumberUtils.createBigDecimal("abc");
            }
        });
    }

    // ------------------------------------------------------------------
    // createBigInteger
    // ------------------------------------------------------------------

    @Test
    public void testCreateBigIntegerNull() {
        assertNull(NumberUtils.createBigInteger(null));
    }

    @Test
    public void testCreateBigIntegerDecimal() {
        assertEquals(BigInteger.valueOf(123), NumberUtils.createBigInteger("123"));
    }

    @Test
    public void testCreateBigIntegerHex() {
        assertEquals(BigInteger.valueOf(26), NumberUtils.createBigInteger("0x1A"));
        assertEquals(BigInteger.valueOf(26), NumberUtils.createBigInteger("#1A"));
    }

    @Test
    public void testCreateBigIntegerInvalid() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                NumberUtils.createBigInteger("abc");
            }
        });
    }

    // ------------------------------------------------------------------
    // createDouble
    // ------------------------------------------------------------------

    @Test
    public void testCreateDoubleNull() {
        assertNull(NumberUtils.createDouble(null));
    }

    @Test
    public void testCreateDoubleValid() {
        assertEquals(1.5d, NumberUtils.createDouble("1.5").doubleValue(), 0.0d);
    }

    @Test
    public void testCreateDoubleInvalid() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                NumberUtils.createDouble("abc");
            }
        });
    }

    // ------------------------------------------------------------------
    // createFloat
    // ------------------------------------------------------------------

    @Test
    public void testCreateFloatNull() {
        assertNull(NumberUtils.createFloat(null));
    }

    @Test
    public void testCreateFloatValid() {
        assertEquals(1.5f, NumberUtils.createFloat("1.5").floatValue(), 0.0f);
    }

    @Test
    public void testCreateFloatInvalid() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                NumberUtils.createFloat("abc");
            }
        });
    }

    // ------------------------------------------------------------------
    // createInteger
    // ------------------------------------------------------------------

    @Test
    public void testCreateIntegerNull() {
        assertNull(NumberUtils.createInteger(null));
    }

    @Test
    public void testCreateIntegerDecimal() {
        assertEquals(123, NumberUtils.createInteger("123").intValue());
        assertEquals(-123, NumberUtils.createInteger("-123").intValue());
    }

    @Test
    public void testCreateIntegerHex() {
        assertEquals(26, NumberUtils.createInteger("0x1A").intValue());
    }

    @Test
    public void testCreateIntegerOctal() {
        assertEquals(8, NumberUtils.createInteger("010").intValue());
    }

    @Test
    public void testCreateIntegerInvalid() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                NumberUtils.createInteger("abc");
            }
        });
    }

    // ------------------------------------------------------------------
    // createLong
    // ------------------------------------------------------------------

    @Test
    public void testCreateLongNull() {
        assertNull(NumberUtils.createLong(null));
    }

    @Test
    public void testCreateLongDecimal() {
        assertEquals(123L, NumberUtils.createLong("123").longValue());
    }

    @Test
    public void testCreateLongHex() {
        assertEquals(26L, NumberUtils.createLong("0x1A").longValue());
    }

    @Test
    public void testCreateLongOctal() {
        assertEquals(8L, NumberUtils.createLong("010").longValue());
    }

    @Test
    public void testCreateLongInvalid() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                NumberUtils.createLong("abc");
            }
        });
    }

    // ------------------------------------------------------------------
    // createNumber
    // ------------------------------------------------------------------

    @Test
    public void testCreateNumberNull() {
        assertNull(NumberUtils.createNumber(null));
    }

    @Test
    public void testCreateNumberPlainInteger() {
        Number n = NumberUtils.createNumber("123");
        assertTrue(n instanceof Integer);
        assertEquals(123, n.intValue());
    }

    @Test
    public void testCreateNumberLongSuffix() {
        Number n = NumberUtils.createNumber("123L");
        assertTrue(n instanceof Long);
        assertEquals(123L, n.longValue());
    }

    @Test
    public void testCreateNumberFloatSuffix() {
        Number n = NumberUtils.createNumber("123F");
        assertTrue(n instanceof Float);
        assertEquals(123.0f, n.floatValue(), 0.0f);
    }

    @Test
    public void testCreateNumberDoubleSuffix() {
        Number n = NumberUtils.createNumber("123D");
        assertTrue(n instanceof Double);
        assertEquals(123.0d, n.doubleValue(), 0.0d);
    }

    @Test
    public void testCreateNumberHexWithinIntRange() {
        Number n = NumberUtils.createNumber("0x7FFFFFFF");
        assertTrue(n instanceof Integer);
        assertEquals(Integer.MAX_VALUE, n.intValue());
    }

    @Test
    public void testCreateNumberHexBeyondIntRange() {
        // 9 hex digits after the prefix -> more than 8, so Long is used.
        Number n = NumberUtils.createNumber("0x100000000");
        assertTrue(n instanceof Long);
        assertEquals(4294967296L, n.longValue());
    }

    @Test
    public void testCreateNumberHexBeyondLongRange() {
        // 17 hex digits after the prefix -> more than 16, so BigInteger is used.
        Number n = NumberUtils.createNumber("0x11111111111111111");
        assertTrue(n instanceof BigInteger);
    }

    @Test
    public void testCreateNumberOctal() {
        Number n = NumberUtils.createNumber("010");
        assertTrue(n instanceof Integer);
        assertEquals(8, n.intValue());
    }

    @Test
    public void testCreateNumberInvalid() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                NumberUtils.createNumber("abc");
            }
        });
    }

    @Test
    public void testCreateNumberDoesNotTrim() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                NumberUtils.createNumber(" 123 ");
            }
        });
    }

    // ------------------------------------------------------------------
    // isCreatable / isNumber (deprecated alias with the same contract)
    // ------------------------------------------------------------------

    @Test
    public void testIsCreatableNullAndBlank() {
        assertFalse(NumberUtils.isCreatable(null));
        assertFalse(NumberUtils.isCreatable(""));
        assertFalse(NumberUtils.isCreatable("   "));
    }

    @Test
    public void testIsCreatableValidForms() {
        assertTrue(NumberUtils.isCreatable("123"));
        assertTrue(NumberUtils.isCreatable("0x1A"));
        assertTrue(NumberUtils.isCreatable("123L"));
        assertTrue(NumberUtils.isCreatable("1e10"));
        assertTrue(NumberUtils.isCreatable("0.09"));
    }

    @Test
    public void testIsCreatableInvalidOctal() {
        assertFalse(NumberUtils.isCreatable("09"));
    }

    @Test
    public void testIsCreatableGarbage() {
        assertFalse(NumberUtils.isCreatable("abc"));
    }

    @Test
    public void testIsNumberDeprecatedMatchesIsCreatable() {
        assertFalse(NumberUtils.isNumber(null));
        assertFalse(NumberUtils.isNumber(""));
        assertFalse(NumberUtils.isNumber("09"));
        assertTrue(NumberUtils.isNumber("123"));
        assertTrue(NumberUtils.isNumber("0x1A"));
    }

    // ------------------------------------------------------------------
    // isDigits
    // ------------------------------------------------------------------

    @Test
    public void testIsDigits() {
        assertFalse(NumberUtils.isDigits(null));
        assertFalse(NumberUtils.isDigits(""));
        assertTrue(NumberUtils.isDigits("123"));
        assertFalse(NumberUtils.isDigits("12.3"));
        assertFalse(NumberUtils.isDigits("-123"));
        assertFalse(NumberUtils.isDigits("12 3"));
    }

    // ------------------------------------------------------------------
    // isParsable
    // ------------------------------------------------------------------

    @Test
    public void testIsParsableNullAndEmpty() {
        assertFalse(NumberUtils.isParsable(null));
        assertFalse(NumberUtils.isParsable(""));
    }

    @Test
    public void testIsParsableValidForms() {
        assertTrue(NumberUtils.isParsable("123"));
        assertTrue(NumberUtils.isParsable("1.2e-5"));
        assertTrue(NumberUtils.isParsable("2.0f"));
        assertTrue(NumberUtils.isParsable("2.0d"));
        assertTrue(NumberUtils.isParsable("NaN"));
        assertTrue(NumberUtils.isParsable("Infinity"));
        assertTrue(NumberUtils.isParsable("+Infinity"));
        assertTrue(NumberUtils.isParsable("-Infinity"));
    }

    @Test
    public void testIsParsableInvalid() {
        assertFalse(NumberUtils.isParsable("abc"));
        assertFalse(NumberUtils.isParsable("0x1A"));
        assertFalse(NumberUtils.isParsable(" 123"));
    }

    // ------------------------------------------------------------------
    // max / min - varargs
    // ------------------------------------------------------------------

    @Test
    public void testMaxByteArray() {
        assertEquals((byte) 5, NumberUtils.max((byte) 1, (byte) 5, (byte) 3));
        assertEquals((byte) 7, NumberUtils.max(new byte[] {(byte) 7}));
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                NumberUtils.max((byte[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                NumberUtils.max(new byte[0]);
            }
        });
    }

    @Test
    public void testMinByteArray() {
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 5, (byte) 3));
        assertEquals((byte) 7, NumberUtils.min(new byte[] {(byte) 7}));
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                NumberUtils.min((byte[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                NumberUtils.min(new byte[0]);
            }
        });
    }

    @Test
    public void testMaxShortArray() {
        assertEquals((short) 5, NumberUtils.max((short) 1, (short) 5, (short) 3));
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                NumberUtils.max((short[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                NumberUtils.max(new short[0]);
            }
        });
    }

    @Test
    public void testMinShortArray() {
        assertEquals((short) 1, NumberUtils.min((short) 1, (short) 5, (short) 3));
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                NumberUtils.min((short[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                NumberUtils.min(new short[0]);
            }
        });
    }

    @Test
    public void testMaxIntArray() {
        assertEquals(5, NumberUtils.max(1, 5, 3));
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                NumberUtils.max((int[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                NumberUtils.max(new int[0]);
            }
        });
    }

    @Test
    public void testMinIntArray() {
        assertEquals(1, NumberUtils.min(1, 5, 3));
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                NumberUtils.min((int[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                NumberUtils.min(new int[0]);
            }
        });
    }

    @Test
    public void testMaxLongArray() {
        assertEquals(5L, NumberUtils.max(1L, 5L, 3L));
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                NumberUtils.max((long[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                NumberUtils.max(new long[0]);
            }
        });
    }

    @Test
    public void testMinLongArray() {
        assertEquals(1L, NumberUtils.min(1L, 5L, 3L));
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                NumberUtils.min((long[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                NumberUtils.min(new long[0]);
            }
        });
    }

    @Test
    public void testMaxFloatArray() {
        assertEquals(5.0f, NumberUtils.max(1.0f, 5.0f, 3.0f), 0.0f);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                NumberUtils.max((float[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                NumberUtils.max(new float[0]);
            }
        });
    }

    @Test
    public void testMinFloatArray() {
        assertEquals(1.0f, NumberUtils.min(1.0f, 5.0f, 3.0f), 0.0f);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                NumberUtils.min((float[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                NumberUtils.min(new float[0]);
            }
        });
    }

    @Test
    public void testMaxDoubleArray() {
        assertEquals(5.0d, NumberUtils.max(1.0d, 5.0d, 3.0d), 0.0d);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                NumberUtils.max((double[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                NumberUtils.max(new double[0]);
            }
        });
    }

    @Test
    public void testMinDoubleArray() {
        assertEquals(1.0d, NumberUtils.min(1.0d, 5.0d, 3.0d), 0.0d);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                NumberUtils.min((double[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            public void execute() {
                NumberUtils.min(new double[0]);
            }
        });
    }

    // ------------------------------------------------------------------
    // max / min - three-value overloads
    // ------------------------------------------------------------------

    @Test
    public void testMaxMinThreeByte() {
        assertEquals((byte) 9, NumberUtils.max((byte) 1, (byte) 9, (byte) 5));
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 9, (byte) 5));
    }

    @Test
    public void testMaxMinThreeShort() {
        assertEquals((short) 9, NumberUtils.max((short) 1, (short) 9, (short) 5));
        assertEquals((short) 1, NumberUtils.min((short) 1, (short) 9, (short) 5));
    }

    @Test
    public void testMaxMinThreeInt() {
        assertEquals(9, NumberUtils.max(1, 9, 5));
        assertEquals(1, NumberUtils.min(1, 9, 5));
    }

    @Test
    public void testMaxMinThreeLong() {
        assertEquals(9L, NumberUtils.max(1L, 9L, 5L));
        assertEquals(1L, NumberUtils.min(1L, 9L, 5L));
    }

    @Test
    public void testMaxMinThreeFloat() {
        assertEquals(9.0f, NumberUtils.max(1.0f, 9.0f, 5.0f), 0.0f);
        assertEquals(1.0f, NumberUtils.min(1.0f, 9.0f, 5.0f), 0.0f);
    }

    @Test
    public void testMaxMinThreeFloatNaN() {
        assertTrue(Float.isNaN(NumberUtils.max(1.0f, Float.NaN, 5.0f)));
        assertTrue(Float.isNaN(NumberUtils.min(1.0f, Float.NaN, 5.0f)));
    }

    @Test
    public void testMaxMinThreeDouble() {
        assertEquals(9.0d, NumberUtils.max(1.0d, 9.0d, 5.0d), 0.0d);
        assertEquals(1.0d, NumberUtils.min(1.0d, 9.0d, 5.0d), 0.0d);
    }

    @Test
    public void testMaxMinThreeDoubleNaN() {
        assertTrue(Double.isNaN(NumberUtils.max(1.0d, Double.NaN, 5.0d)));
        assertTrue(Double.isNaN(NumberUtils.min(1.0d, Double.NaN, 5.0d)));
    }

    // ------------------------------------------------------------------
    // toByte
    // ------------------------------------------------------------------

    @Test
    public void testToByte() {
        assertEquals((byte) 0, NumberUtils.toByte(null));
        assertEquals((byte) 0, NumberUtils.toByte(""));
        assertEquals((byte) 1, NumberUtils.toByte("1"));
    }

    @Test
    public void testToByteWithDefault() {
        assertEquals((byte) 1, NumberUtils.toByte(null, (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("", (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("1", (byte) 0));
        assertEquals((byte) 9, NumberUtils.toByte("not a byte", (byte) 9));
    }

    // ------------------------------------------------------------------
    // toDouble
    // ------------------------------------------------------------------

    @Test
    public void testToDoubleString() {
        assertEquals(0.0d, NumberUtils.toDouble((String) null), 0.0d);
        assertEquals(0.0d, NumberUtils.toDouble(""), 0.0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5"), 0.0d);
    }

    @Test
    public void testToDoubleStringWithDefault() {
        assertEquals(1.1d, NumberUtils.toDouble((String) null, 1.1d), 0.0d);
        assertEquals(1.1d, NumberUtils.toDouble("", 1.1d), 0.0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5", 0.0d), 0.0d);
    }

    @Test
    public void testToDoubleBigDecimal() {
        assertEquals(0.0d, NumberUtils.toDouble((BigDecimal) null), 0.0d);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d)), 0.0d);
    }

    @Test
    public void testToDoubleBigDecimalWithDefault() {
        assertEquals(1.1d, NumberUtils.toDouble((BigDecimal) null, 1.1d), 0.0d);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d), 1.1d), 0.0d);
    }

    // ------------------------------------------------------------------
    // toFloat
    // ------------------------------------------------------------------

    @Test
    public void testToFloat() {
        assertEquals(0.0f, NumberUtils.toFloat(null), 0.0f);
        assertEquals(0.0f, NumberUtils.toFloat(""), 0.0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5"), 0.0f);
    }

    @Test
    public void testToFloatWithDefault() {
        assertEquals(1.1f, NumberUtils.toFloat(null, 1.1f), 0.0f);
        assertEquals(1.1f, NumberUtils.toFloat("", 1.1f), 0.0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5", 0.0f), 0.0f);
    }

    // ------------------------------------------------------------------
    // toInt
    // ------------------------------------------------------------------

    @Test
    public void testToInt() {
        assertEquals(0, NumberUtils.toInt(null));
        assertEquals(0, NumberUtils.toInt(""));
        assertEquals(1, NumberUtils.toInt("1"));
    }

    @Test
    public void testToIntWithDefault() {
        assertEquals(1, NumberUtils.toInt(null, 1));
        assertEquals(1, NumberUtils.toInt("", 1));
        assertEquals(1, NumberUtils.toInt("1", 0));
    }

    // ------------------------------------------------------------------
    // toLong
    // ------------------------------------------------------------------

    @Test
    public void testToLong() {
        assertEquals(0L, NumberUtils.toLong(null));
        assertEquals(0L, NumberUtils.toLong(""));
        assertEquals(1L, NumberUtils.toLong("1"));
    }

    @Test
    public void testToLongWithDefault() {
        assertEquals(1L, NumberUtils.toLong(null, 1L));
        assertEquals(1L, NumberUtils.toLong("", 1L));
        assertEquals(1L, NumberUtils.toLong("1", 0L));
    }

    // ------------------------------------------------------------------
    // toShort
    // ------------------------------------------------------------------

    @Test
    public void testToShort() {
        assertEquals((short) 0, NumberUtils.toShort(null));
        assertEquals((short) 0, NumberUtils.toShort(""));
        assertEquals((short) 1, NumberUtils.toShort("1"));
    }

    @Test
    public void testToShortWithDefault() {
        assertEquals((short) 1, NumberUtils.toShort(null, (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("", (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("1", (short) 0));
    }

    // ------------------------------------------------------------------
    // toScaledBigDecimal
    // ------------------------------------------------------------------

    @Test
    public void testToScaledBigDecimalBigDecimalDefaultScale() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null));
        BigDecimal roundedDown = NumberUtils.toScaledBigDecimal(new BigDecimal("2.344"));
        assertEquals(2, roundedDown.scale());
        assertEquals(0, roundedDown.compareTo(new BigDecimal("2.34")));
        BigDecimal roundedUp = NumberUtils.toScaledBigDecimal(new BigDecimal("2.346"));
        assertEquals(0, roundedUp.compareTo(new BigDecimal("2.35")));
    }

    @Test
    public void testToScaledBigDecimalBigDecimalCustomScale() {
        BigDecimal result = NumberUtils.toScaledBigDecimal(new BigDecimal("1.23456"), 3, RoundingMode.DOWN);
        assertEquals(3, result.scale());
        assertEquals(0, result.compareTo(new BigDecimal("1.234")));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null, 3, RoundingMode.DOWN));
    }

    @Test
    public void testToScaledBigDecimalDoubleDefaultScale() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null));
        BigDecimal result = NumberUtils.toScaledBigDecimal(Double.valueOf(2.344d));
        assertEquals(2, result.scale());
        assertEquals(0, result.compareTo(new BigDecimal("2.34")));
    }

    @Test
    public void testToScaledBigDecimalDoubleCustomScale() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null, 3, RoundingMode.DOWN));
        BigDecimal result = NumberUtils.toScaledBigDecimal(Double.valueOf(1.23456d), 3, RoundingMode.DOWN);
        assertEquals(0, result.compareTo(new BigDecimal("1.234")));
    }

    @Test
    public void testToScaledBigDecimalFloatDefaultScale() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null));
        BigDecimal result = NumberUtils.toScaledBigDecimal(Float.valueOf(2.34f));
        assertEquals(2, result.scale());
        assertEquals(0, result.compareTo(new BigDecimal("2.34")));
    }

    @Test
    public void testToScaledBigDecimalFloatCustomScale() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null, 1, RoundingMode.DOWN));
        BigDecimal result = NumberUtils.toScaledBigDecimal(Float.valueOf(1.26f), 1, RoundingMode.DOWN);
        assertEquals(0, result.compareTo(new BigDecimal("1.2")));
    }

    @Test
    public void testToScaledBigDecimalStringDefaultScale() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null));
        BigDecimal result = NumberUtils.toScaledBigDecimal("2.344");
        assertEquals(2, result.scale());
        assertEquals(0, result.compareTo(new BigDecimal("2.34")));
    }

    @Test
    public void testToScaledBigDecimalStringCustomScale() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null, 3, RoundingMode.DOWN));
        BigDecimal result = NumberUtils.toScaledBigDecimal("1.23456", 3, RoundingMode.DOWN);
        assertEquals(0, result.compareTo(new BigDecimal("1.234")));
    }
}
