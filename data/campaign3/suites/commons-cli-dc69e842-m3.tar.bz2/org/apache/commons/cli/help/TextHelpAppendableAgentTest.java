/*
  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      https://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
 */
package org.apache.commons.cli.help;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link TextHelpAppendable}.
 */
class TextHelpAppendableAgentTest {

    private static final String NL = System.lineSeparator();

    private static TextHelpAppendable newAppendable(final StringBuilder sb) {
        return new TextHelpAppendable(sb);
    }

    // -- indexOfWrap -------------------------------------------------------

    @Test
    void testIndexOfWrapInvalidWidthThrows() {
        assertThrows(IllegalArgumentException.class, () -> TextHelpAppendable.indexOfWrap("abc", 0, 0));
        assertThrows(IllegalArgumentException.class, () -> TextHelpAppendable.indexOfWrap("abc", -1, 0));
    }

    @Test
    void testIndexOfWrapFindsLastWhitespaceBeforeLimit() {
        assertEquals(5, TextHelpAppendable.indexOfWrap("hello world", 5, 0));
    }

    @Test
    void testIndexOfWrapNoWhitespaceChopsAtLimit() {
        assertEquals(4, TextHelpAppendable.indexOfWrap("helloworld", 5, 0));
    }

    @Test
    void testIndexOfWrapReturnsTextLengthWhenWidthCoversRemainder() {
        assertEquals(2, TextHelpAppendable.indexOfWrap("hi", 10, 0));
    }

    @Test
    void testIndexOfWrapStopsAtBreakChar() {
        assertEquals(2, TextHelpAppendable.indexOfWrap("hi\tworld", 10, 0));
    }

    @Test
    void testIndexOfWrapHandlesMaxWidthWithoutOverflow() {
        assertEquals(3, TextHelpAppendable.indexOfWrap("abc", Integer.MAX_VALUE, 0));
    }

    @Test
    void testIndexOfWrapExactLengthTextReturnsLength() {
        assertEquals(1, TextHelpAppendable.indexOfWrap("a", 1, 0));
    }

    // -- construction and simple getters/setters ---------------------------

    @Test
    void testConstructorDefaults() {
        final TextHelpAppendable help = newAppendable(new StringBuilder());
        assertEquals(TextHelpAppendable.DEFAULT_WIDTH, help.getMaxWidth());
        assertEquals(TextHelpAppendable.DEFAULT_LEFT_PAD, help.getLeftPad());
        assertEquals(TextHelpAppendable.DEFAULT_INDENT, help.getIndent());
        assertNotNull(help.getTextStyleBuilder());
    }

    @Test
    void testSystemOutDefaults() {
        final TextHelpAppendable help = TextHelpAppendable.systemOut();
        assertNotNull(help);
        assertEquals(TextHelpAppendable.DEFAULT_WIDTH, help.getMaxWidth());
    }

    @Test
    void testSettersUpdateGettersAndBuilder() {
        final TextHelpAppendable help = newAppendable(new StringBuilder());
        help.setIndent(5);
        help.setLeftPad(2);
        help.setMaxWidth(40);
        assertEquals(5, help.getIndent());
        assertEquals(2, help.getLeftPad());
        assertEquals(40, help.getMaxWidth());
        assertEquals(40, help.getTextStyleBuilder().getMaxWidth());
    }

    @Test
    void testGetTextStyleBuilderIsLiveView() {
        final TextHelpAppendable help = newAppendable(new StringBuilder());
        help.getTextStyleBuilder().setMaxWidth(99);
        assertEquals(99, help.getMaxWidth());
    }

    // -- appendHeader --------------------------------------------------------

    @Test
    void testAppendHeaderNullOrEmptyIsNoop() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final TextHelpAppendable help = newAppendable(sb);
        help.appendHeader(1, null);
        help.appendHeader(1, "");
        assertEquals(0, sb.length());
    }

    @Test
    void testAppendHeaderInvalidLevelThrows() {
        final TextHelpAppendable help = newAppendable(new StringBuilder());
        assertThrows(IllegalArgumentException.class, () -> help.appendHeader(0, "text"));
        assertThrows(IllegalArgumentException.class, () -> help.appendHeader(-1, "text"));
    }

    @Test
    void testAppendHeaderLevel1ProducesEqualsUnderline() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final TextHelpAppendable help = newAppendable(sb);
        help.setMaxWidth(10);
        help.setLeftPad(0);
        help.setIndent(0);
        help.appendHeader(1, "AB");
        assertEquals("AB" + NL + "==" + NL + NL, sb.toString());
    }

    @Test
    void testAppendHeaderLevelBeyondFillCharsClampsToLast() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final TextHelpAppendable help = newAppendable(sb);
        help.setMaxWidth(10);
        help.setLeftPad(0);
        help.setIndent(0);
        help.appendHeader(10, "AB");
        assertEquals("AB" + NL + "__" + NL + NL, sb.toString());
    }

    // -- appendTitle -----------------------------------------------------------

    @Test
    void testAppendTitleNullOrEmptyIsNoop() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final TextHelpAppendable help = newAppendable(sb);
        help.appendTitle(null);
        help.appendTitle("");
        assertEquals(0, sb.length());
    }

    @Test
    void testAppendTitleProducesHashUnderline() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final TextHelpAppendable help = newAppendable(sb);
        help.setMaxWidth(10);
        help.setLeftPad(0);
        help.setIndent(0);
        help.appendTitle("XY");
        assertEquals("XY" + NL + "##" + NL + NL, sb.toString());
    }

    // -- appendParagraph ---------------------------------------------------

    @Test
    void testAppendParagraphNullOrEmptyIsNoop() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final TextHelpAppendable help = newAppendable(sb);
        help.appendParagraph(null);
        help.appendParagraph("");
        assertEquals(0, sb.length());
    }

    @Test
    void testAppendParagraphWrapsAtWidth() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final TextHelpAppendable help = newAppendable(sb);
        help.setMaxWidth(5);
        help.setLeftPad(0);
        help.setIndent(0);
        help.appendParagraph("Hello World");
        assertEquals("Hello" + NL + "World" + NL + NL, sb.toString());
    }

    // -- printWrapped --------------------------------------------------------

    @Test
    void testPrintWrappedUsesInstanceStyle() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final TextHelpAppendable help = newAppendable(sb);
        help.setMaxWidth(5);
        help.setLeftPad(0);
        help.setIndent(0);
        help.printWrapped("Hello World");
        assertEquals("Hello" + NL + "World" + NL, sb.toString());
    }

    @Test
    void testPrintWrappedWithExplicitStyle() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final TextHelpAppendable help = newAppendable(sb);
        final TextStyle style = TextStyle.builder().setMaxWidth(5).setLeftPad(0).setIndent(0).get();
        help.printWrapped("Hello World", style);
        assertEquals("Hello" + NL + "World" + NL, sb.toString());
    }

    // -- appendList -----------------------------------------------------------

    @Test
    void testAppendListNullOrEmptyIsNoop() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final TextHelpAppendable help = newAppendable(sb);
        help.appendList(true, null);
        help.appendList(false, Collections.<CharSequence>emptyList());
        assertEquals(0, sb.length());
    }

    @Test
    void testAppendListOrdered() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final TextHelpAppendable help = newAppendable(sb);
        final List<CharSequence> list = new ArrayList<>();
        list.add("a");
        list.add("b");
        help.appendList(true, list);
        assertEquals("  1. a" + NL + "  2. b" + NL + NL, sb.toString());
    }

    @Test
    void testAppendListUnordered() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final TextHelpAppendable help = newAppendable(sb);
        final List<CharSequence> list = new ArrayList<>();
        list.add("x");
        help.appendList(false, list);
        assertEquals("  * x" + NL + NL, sb.toString());
    }

    // -- makeColumnQueue / makeColumnQueues ------------------------------------

    @Test
    void testMakeColumnQueueBreaksOnBreakChar() {
        final TextHelpAppendable help = newAppendable(new StringBuilder());
        final TextStyle style = TextStyle.builder().setMaxWidth(100).setLeftPad(0).setIndent(0).get();
        final Queue<String> queue = help.makeColumnQueue("Hi\nThere", style);
        assertEquals(2, queue.size());
        final String first = queue.poll();
        final String second = queue.poll();
        assertTrue(first.startsWith("Hi"));
        assertTrue(second.startsWith("There"));
        assertEquals(100, first.length());
    }

    @Test
    void testMakeColumnQueuesProducesOneQueuePerColumn() {
        final TextHelpAppendable help = newAppendable(new StringBuilder());
        final TextStyle style1 = TextStyle.builder().setMaxWidth(5).setLeftPad(0).setIndent(0).get();
        final TextStyle style2 = TextStyle.builder().setMaxWidth(5).setLeftPad(0).setIndent(0).get();
        final List<String> columnData = Arrays.asList("Hello", "Hi");
        final List<TextStyle> styles = Arrays.asList(style1, style2);
        final List<Queue<String>> queues = help.makeColumnQueues(columnData, styles);
        assertEquals(2, queues.size());
        assertEquals("Hello", queues.get(0).poll());
        assertEquals("Hi   ", queues.get(1).poll());
    }

    // -- writeColumnQueues ----------------------------------------------------

    @Test
    void testWriteColumnQueuesPadsExhaustedColumns() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final TextHelpAppendable help = newAppendable(sb);
        help.setLeftPad(0);

        final Queue<String> col1 = new LinkedList<>();
        col1.add("A");
        col1.add("B");
        final Queue<String> col2 = new LinkedList<>();
        col2.add("C");

        final List<Queue<String>> queues = new ArrayList<>();
        queues.add(col1);
        queues.add(col2);

        final TextStyle style = TextStyle.builder().setMaxWidth(1).setLeftPad(0).get();
        final List<TextStyle> styles = Arrays.asList(style, style);

        help.writeColumnQueues(queues, styles);

        assertEquals("AC" + NL + "B " + NL, sb.toString());
    }

    // -- adjustTableFormat / appendTable ---------------------------------------

    @Test
    void testAdjustTableFormatExpandsUnsetColumnToHeaderLength() {
        final TextHelpAppendable help = newAppendable(new StringBuilder());
        final List<TextStyle> columnStyles = Collections.singletonList(TextStyle.DEFAULT);
        final List<String> headers = Collections.singletonList("H");
        final List<List<String>> rows = Collections.singletonList(Collections.singletonList("V"));
        final TableDefinition table = TableDefinition.from(null, columnStyles, headers, rows);

        final TableDefinition adjusted = help.adjustTableFormat(table);

        assertEquals(1, adjusted.columnTextStyles().size());
        assertEquals(1, adjusted.columnTextStyles().get(0).getMaxWidth());
        assertEquals(1, adjusted.columnTextStyles().get(0).getMinWidth());
    }

    @Test
    void testAdjustTableFormatGrowsColumnToLongestCell() {
        final TextHelpAppendable help = newAppendable(new StringBuilder());
        final List<TextStyle> columnStyles = Collections.singletonList(TextStyle.DEFAULT);
        final List<String> headers = Collections.singletonList("H");
        final List<List<String>> rows = Collections.singletonList(Collections.singletonList("LongValue"));
        final TableDefinition table = TableDefinition.from(null, columnStyles, headers, rows);

        final TableDefinition adjusted = help.adjustTableFormat(table);

        assertEquals("LongValue".length(), adjusted.columnTextStyles().get(0).getMaxWidth());
    }

    @Test
    void testAppendTableSingleColumn() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final TextHelpAppendable help = newAppendable(sb);
        final List<TextStyle> columnStyles = Collections.singletonList(TextStyle.DEFAULT);
        final List<String> headers = Collections.singletonList("H");
        final List<List<String>> rows = Collections.singletonList(Collections.singletonList("V"));
        final TableDefinition table = TableDefinition.from(null, columnStyles, headers, rows);

        help.appendTable(table);

        assertEquals(" H" + NL + " V" + NL + NL, sb.toString());
    }

    @Test
    void testAppendTableWithCaptionWritesCaptionParagraph() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final TextHelpAppendable help = newAppendable(sb);
        help.setLeftPad(0);
        final List<TextStyle> columnStyles = Collections.singletonList(TextStyle.DEFAULT);
        final List<String> headers = Collections.singletonList("H");
        final List<List<String>> rows = Collections.singletonList(Collections.singletonList("V"));
        final TableDefinition table = TableDefinition.from("Caption", columnStyles, headers, rows);

        help.appendTable(table);

        assertEquals("Caption" + NL + NL + "H" + NL + "V" + NL + NL, sb.toString());
    }

    // -- resize ---------------------------------------------------------------

    @Test
    void testResizeScalesMaxWidthAndIndent() {
        final TextHelpAppendable help = newAppendable(new StringBuilder());
        final TextStyle.Builder builder = TextStyle.builder().setMaxWidth(90).setIndent(30).setMinWidth(0);

        final TextStyle.Builder resized = help.resize(builder, 0.5);

        assertEquals(45, resized.getMaxWidth());
        assertEquals(10, resized.getIndent());
    }

    @Test
    void testResizeClampsToMinWidthAndZeroesIndentWhenWidthIsOne() {
        final TextHelpAppendable help = newAppendable(new StringBuilder());
        final TextStyle.Builder builder = TextStyle.builder().setMaxWidth(2).setIndent(5).setMinWidth(1);

        final TextStyle.Builder resized = help.resize(builder, 0.3);

        assertEquals(1, resized.getMaxWidth());
        assertEquals(0, resized.getIndent());
    }

    @Test
    void testResizeRespectsMinWidthFloor() {
        final TextHelpAppendable help = newAppendable(new StringBuilder());
        final TextStyle.Builder builder = TextStyle.builder().setMaxWidth(100).setIndent(10).setMinWidth(80);

        final TextStyle.Builder resized = help.resize(builder, 0.1);

        assertEquals(80, resized.getMaxWidth());
    }

    // -- appendFormat / append passthrough (inherited from FilterHelpAppendable) --

    @Test
    void testAppendPassesThroughToUnderlyingOutput() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final TextHelpAppendable help = newAppendable(sb);
        help.append('x');
        help.append("yz");
        assertEquals("xyz", sb.toString());
        assertFalse(sb.length() == 0);
    }
}
