package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Supplier;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link StopWatch} and {@link StopWatch.Split}, based solely on the
 * documented contract in the generated javadoc.
 */
public class StopWatchAgentTest {

    private static void sleepBriefly() {
        try {
            Thread.sleep(5);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    // ---- construction / initial state ----

    @Test
    public void testDefaultConstructorInitialState() {
        StopWatch sw = new StopWatch();
        assertNull(sw.getMessage());
        assertFalse(sw.isStarted());
        assertFalse(sw.isSuspended());
        assertTrue(sw.isStopped());
    }

    @Test
    public void testMessageConstructorStoresMessage() {
        StopWatch sw = new StopWatch("myMessage");
        assertEquals("myMessage", sw.getMessage());
        assertTrue(sw.isStopped());
    }

    @Test
    public void testCreateReturnsUnstartedWatch() {
        StopWatch sw = StopWatch.create();
        assertNotNull(sw);
        assertFalse(sw.isStarted());
        assertTrue(sw.isStopped());
        assertFalse(sw.isSuspended());
    }

    @Test
    public void testCreateStartedReturnsStartedWatch() {
        StopWatch sw = StopWatch.createStarted();
        assertNotNull(sw);
        assertTrue(sw.isStarted());
        assertFalse(sw.isStopped());
        assertFalse(sw.isSuspended());
    }

    // ---- start / stop ----

    @Test
    public void testStartThenStopTransitionsState() {
        final StopWatch sw = new StopWatch();
        sw.start();
        assertTrue(sw.isStarted());
        assertFalse(sw.isStopped());
        sleepBriefly();
        sw.stop();
        assertTrue(sw.isStopped());
    }

    @Test
    public void testStartTwiceWithoutResetThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.start();
            }
        });
    }

    @Test
    public void testStopWithoutStartThrows() {
        final StopWatch sw = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.stop();
            }
        });
    }

    @Test
    public void testStopTwiceThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.stop();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.stop();
            }
        });
    }

    @Test
    public void testStartAfterStopWithoutResetThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.stop();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.start();
            }
        });
    }

    // ---- suspend / resume ----

    @Test
    public void testSuspendWithoutStartThrows() {
        final StopWatch sw = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.suspend();
            }
        });
    }

    @Test
    public void testSuspendAndResume() {
        StopWatch sw = new StopWatch();
        sw.start();
        sw.suspend();
        assertTrue(sw.isSuspended());
        assertTrue(sw.isStarted());
        assertFalse(sw.isStopped());
        sw.resume();
        assertFalse(sw.isSuspended());
        assertTrue(sw.isStarted());
        assertFalse(sw.isStopped());
        sw.stop();
        assertTrue(sw.isStopped());
    }

    @Test
    public void testSuspendTwiceThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.suspend();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.suspend();
            }
        });
    }

    @Test
    public void testResumeWithoutSuspendThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.resume();
            }
        });
    }

    // ---- split / unsplit ----

    @Test
    public void testSplitWithoutStartThrows() {
        final StopWatch sw = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.split();
            }
        });
    }

    @Test
    public void testSplitTwiceThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.split();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.split();
            }
        });
    }

    @Test
    public void testUnsplitWithoutSplitThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.unsplit();
            }
        });
    }

    @Test
    public void testUnsplitAllowsSplitSuspendStopAgain() {
        StopWatch sw = new StopWatch();
        sw.start();
        sw.split();
        sw.unsplit();
        // After unsplit, split/suspend/stop are available again.
        sw.split();
        sw.unsplit();
        sw.suspend();
        sw.resume();
        sw.stop();
        assertTrue(sw.isStopped());
    }

    // ---- illegal state on accessors before start / split ----

    @Test
    public void testGetSplitDurationWithoutSplitThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.getSplitDuration();
            }
        });
    }

    @Test
    public void testGetSplitNanoTimeWithoutSplitThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.getSplitNanoTime();
            }
        });
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testGetSplitTimeDeprecatedWithoutSplitThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.getSplitTime();
            }
        });
    }

    @Test
    public void testGetStartInstantWithoutStartThrows() {
        final StopWatch sw = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.getStartInstant();
            }
        });
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testGetStartTimeDeprecatedWithoutStartThrows() {
        final StopWatch sw = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.getStartTime();
            }
        });
    }

    @Test
    public void testGetStopInstantWithoutStartThrows() {
        final StopWatch sw = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.getStopInstant();
            }
        });
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testGetStopTimeDeprecatedWithoutStartThrows() {
        final StopWatch sw = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.getStopTime();
            }
        });
    }

    // ---- reset ----

    @Test
    public void testResetClearsStateAfterStop() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sleepBriefly();
        sw.stop();
        sw.reset();
        assertFalse(sw.isStarted());
        assertTrue(sw.isStopped());
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.getStartInstant();
            }
        });
    }

    @Test
    public void testResetThenStartSucceeds() {
        StopWatch sw = new StopWatch();
        sw.start();
        sw.stop();
        sw.reset();
        sw.start();
        assertTrue(sw.isStarted());
        assertFalse(sw.isStopped());
    }

    // ---- timing values ----

    @Test
    public void testGetTimeAndNanoTimeConsistencyAfterStop() {
        StopWatch sw = new StopWatch();
        sw.start();
        sleepBriefly();
        sw.stop();
        long millis = sw.getTime();
        long nanos = sw.getNanoTime();
        assertTrue(millis >= 0);
        assertTrue(nanos >= 0);
        assertEquals(TimeUnit.NANOSECONDS.toMillis(nanos), millis);
    }

    @Test
    public void testGetTimeWithTimeUnit() {
        StopWatch sw = new StopWatch();
        sw.start();
        sleepBriefly();
        sw.stop();
        long millis = sw.getTime();
        assertEquals(millis, sw.getTime(TimeUnit.MILLISECONDS));
        // A short-lived StopWatch is well under an hour.
        assertEquals(0L, sw.getTime(TimeUnit.HOURS));
    }

    @Test
    public void testGetDurationMatchesNanoTime() {
        StopWatch sw = new StopWatch();
        sw.start();
        sleepBriefly();
        sw.stop();
        Duration duration = sw.getDuration();
        assertFalse(duration.isNegative());
        assertEquals(sw.getNanoTime(), duration.toNanos());
    }

    @Test
    public void testGetSplitDurationAndNanoTimeConsistency() {
        StopWatch sw = new StopWatch();
        sw.start();
        sleepBriefly();
        sw.split();
        Duration splitDuration = sw.getSplitDuration();
        long splitNanoTime = sw.getSplitNanoTime();
        assertFalse(splitDuration.isNegative());
        assertTrue(splitNanoTime >= 0);
        assertEquals(splitNanoTime, splitDuration.toNanos());
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testGetSplitTimeDeprecatedMatchesSplitNanoTime() {
        StopWatch sw = new StopWatch();
        sw.start();
        sleepBriefly();
        sw.split();
        long splitNanoTime = sw.getSplitNanoTime();
        assertEquals(TimeUnit.NANOSECONDS.toMillis(splitNanoTime), sw.getSplitTime());
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testGetStartAndStopTimeDeprecatedMatchInstants() {
        StopWatch sw = new StopWatch();
        sw.start();
        sleepBriefly();
        sw.stop();
        assertEquals(sw.getStartInstant().toEpochMilli(), sw.getStartTime());
        assertEquals(sw.getStopInstant().toEpochMilli(), sw.getStopTime());
    }

    // ---- formatting ----

    private static final String TIME_PATTERN = "\\d+:\\d{2}:\\d{2}\\.\\d{3}";

    @Test
    public void testFormatTimeFormat() {
        StopWatch sw = new StopWatch();
        sw.start();
        sleepBriefly();
        sw.stop();
        String formatted = sw.formatTime();
        assertNotNull(formatted);
        assertTrue(formatted.matches(TIME_PATTERN), "Unexpected format: " + formatted);
    }

    @Test
    public void testFormatSplitTimeFormat() {
        StopWatch sw = new StopWatch();
        sw.start();
        sleepBriefly();
        sw.split();
        String formatted = sw.formatSplitTime();
        assertNotNull(formatted);
        assertTrue(formatted.matches(TIME_PATTERN), "Unexpected format: " + formatted);
    }

    @Test
    public void testToStringFormatWithoutMessage() {
        StopWatch sw = new StopWatch();
        sw.start();
        sleepBriefly();
        sw.stop();
        String result = sw.toString();
        assertNotNull(result);
        assertTrue(result.matches(TIME_PATTERN), "Unexpected format: " + result);
    }

    @Test
    public void testToStringFormatWithMessage() {
        StopWatch sw = new StopWatch("myMessage");
        sw.start();
        sleepBriefly();
        sw.stop();
        String result = sw.toString();
        assertNotNull(result);
        assertTrue(result.startsWith("myMessage "), "Expected message prefix: " + result);
        assertTrue(result.matches("myMessage " + TIME_PATTERN), "Unexpected format: " + result);
    }

    @Test
    public void testToSplitStringFormatWithMessage() {
        StopWatch sw = new StopWatch("myMessage");
        sw.start();
        sleepBriefly();
        sw.split();
        String result = sw.toSplitString();
        assertNotNull(result);
        assertTrue(result.startsWith("myMessage "), "Expected message prefix: " + result);
        assertTrue(result.matches("myMessage " + TIME_PATTERN), "Unexpected format: " + result);
    }

    // ---- splits list ----

    @Test
    public void testGetSplitsEmptyInitially() {
        StopWatch sw = new StopWatch();
        List<StopWatch.Split> splits = sw.getSplits();
        assertNotNull(splits);
        assertTrue(splits.isEmpty());
    }

    @Test
    public void testGetSplitsRecordsLabeledSplits() {
        StopWatch sw = new StopWatch();
        sw.start();
        sw.split("first");
        sw.unsplit();
        sw.split("second");
        sw.unsplit();
        sw.stop();

        List<StopWatch.Split> splits = sw.getSplits();
        assertEquals(2, splits.size());
        assertEquals("first", splits.get(0).getLabel());
        assertEquals("second", splits.get(1).getLabel());
        assertFalse(splits.get(0).getDuration().isNegative());
        assertFalse(splits.get(1).getDuration().isNegative());
    }

    @Test
    public void testSplitWithLabelWithoutStartThrows() {
        final StopWatch sw = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.split("label");
            }
        });
    }

    // ---- StopWatch.Split nested class ----

    @Test
    public void testSplitClassConstructorAndAccessors() {
        Duration duration = Duration.ofMillis(250);
        StopWatch.Split split = new StopWatch.Split("abc", duration);
        assertEquals("abc", split.getLabel());
        assertEquals(duration, split.getDuration());
        String str = split.toString();
        assertNotNull(str);
        assertFalse(str.isEmpty());
    }

    @Test
    public void testSplitClassEqualsAndHashCode() {
        StopWatch.Split a = new StopWatch.Split("x", Duration.ofSeconds(1));
        StopWatch.Split b = new StopWatch.Split("x", Duration.ofSeconds(1));
        StopWatch.Split c = new StopWatch.Split("y", Duration.ofSeconds(1));

        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
        assertNotEquals(a, c);
    }

    // ---- functional delegation ----

    @Test
    public void testGetSupplierDelegatesAndRecordsTime() {
        StopWatch sw = new StopWatch();
        final AtomicBoolean called = new AtomicBoolean(false);
        String result = sw.get(new Supplier<String>() {
            @Override
            public String get() {
                called.set(true);
                sleepBriefly();
                return "value";
            }
        });
        assertEquals("value", result);
        assertTrue(called.get());
        assertTrue(sw.isStopped());
        assertTrue(sw.getTime() >= 0);
    }

    @Test
    public void testRunRunnableDelegatesAndRecordsTime() {
        StopWatch sw = new StopWatch();
        final AtomicBoolean called = new AtomicBoolean(false);
        sw.run(new Runnable() {
            @Override
            public void run() {
                called.set(true);
                sleepBriefly();
            }
        });
        assertTrue(called.get());
        assertTrue(sw.isStopped());
        assertTrue(sw.getTime() >= 0);
    }
}
