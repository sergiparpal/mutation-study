/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link CSVFormat}.
 */
class CSVFormatAgentTest {

    private enum Header {
        Name, Email
    }

    @Test
    void testBuilderCreateCopiesSettings() {
        final CSVFormat source = CSVFormat.DEFAULT.builder().setDelimiter(';').setQuote('\'').setNullString("NULL").get();
        final CSVFormat copy = CSVFormat.Builder.create(source).get();
        assertEquals(source, copy);
        assertNotSame(source, copy);
    }

    @Test
    void testBuilderGetAliasForBuild() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder().setDelimiter('|');
        assertEquals(builder.get(), builder.build());
    }

    @Test
    void testCommentMarkerCannotBeLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder();
        assertThrows(IllegalArgumentException.class, () -> builder.setCommentMarker('\n'));
        assertThrows(IllegalArgumentException.class, () -> builder.setCommentMarker('\r'));
        assertThrows(IllegalArgumentException.class, () -> builder.setCommentMarker(Character.valueOf('\n')));
    }

    @Test
    void testCopyIsEqualButNotSame() {
        final CSVFormat copy = CSVFormat.copy(CSVFormat.DEFAULT);
        assertEquals(CSVFormat.DEFAULT, copy);
        assertNotSame(CSVFormat.DEFAULT, copy);
        assertNull(CSVFormat.copy(null));
    }

    @Test
    void testDelimiterCannotBeEmpty() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder();
        assertThrows(IllegalArgumentException.class, () -> builder.setDelimiter(""));
    }

    @Test
    void testDelimiterCannotBeLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder();
        assertThrows(IllegalArgumentException.class, () -> builder.setDelimiter('\n'));
        assertThrows(IllegalArgumentException.class, () -> builder.setDelimiter("a\r\nb"));
    }

    @Test
    void testDuplicateHeaderModeAllowAllPermitsDuplicates() {
        final CSVFormat format = CSVFormat.DEFAULT.builder()
                .setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_ALL)
                .setHeader("A", "A")
                .get();
        assertArrayEquals(new String[] { "A", "A" }, format.getHeader());
    }

    @Test
    void testDuplicateHeaderModeAllowEmptyAllowsBlanksButNotDuplicateNames() {
        final CSVFormat format = CSVFormat.DEFAULT.builder()
                .setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY)
                .setHeader("A", "", "")
                .get();
        assertArrayEquals(new String[] { "A", "", "" }, format.getHeader());
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder()
                .setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY)
                .setHeader("A", "A");
        assertThrows(IllegalArgumentException.class, builder::get);
    }

    @Test
    void testDuplicateHeaderModeDisallowRejectsAnyDuplicate() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder()
                .setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW)
                .setHeader("A", "A");
        assertThrows(IllegalArgumentException.class, builder::get);
        final CSVFormat.Builder blankBuilder = CSVFormat.DEFAULT.builder()
                .setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW)
                .setHeader("A", "", "");
        assertThrows(IllegalArgumentException.class, blankBuilder::get);
    }

    @Test
    void testDuplicateHeaderModeNullThrows() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder();
        assertThrows(NullPointerException.class, () -> builder.setDuplicateHeaderMode(null));
    }

    @Test
    void testEqualsAndHashCode() {
        final CSVFormat a = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        final CSVFormat b = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        final CSVFormat c = CSVFormat.DEFAULT.builder().setDelimiter(',').get();
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
        assertNotEquals(a, c);
        assertNotEquals(a, null);
        assertNotEquals(a, "not a format");
        assertEquals(a, a);
    }

    @Test
    void testEscapeCannotBeLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder();
        assertThrows(IllegalArgumentException.class, () -> builder.setEscape('\n'));
        assertThrows(IllegalArgumentException.class, () -> builder.setEscape(Character.valueOf('\r')));
    }

    @Test
    void testFormatMethodProducesExpectedStringWithoutRecordSeparator() {
        final String formatted = CSVFormat.DEFAULT.format("a", "b", "c");
        assertEquals("a,b,c", formatted);
    }

    @Test
    void testFormatMethodQuotesValueContainingDelimiter() {
        final String formatted = CSVFormat.DEFAULT.format("a,b", "c");
        assertEquals("\"a,b\",c", formatted);
    }

    @Test
    void testGetDelimiterCharArray() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        assertArrayEquals(new char[] { ':', ':' }, format.getDelimiterCharArray());
    }

    @Test
    void testGetDelimiterDeprecatedReturnsFirstChar() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        assertEquals(';', format.getDelimiter());
        assertEquals(";", format.getDelimiterString());
    }

    @Test
    void testGetEscapeCharDefaultsToZero() {
        assertEquals(0, CSVFormat.DEFAULT.getEscapeChar());
        assertFalse(CSVFormat.DEFAULT.isEscapeCharacterSet());
        final CSVFormat withEscape = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        assertEquals('\\', withEscape.getEscapeChar());
        assertTrue(withEscape.isEscapeCharacterSet());
    }

    @Test
    void testGetHeaderReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "b").get();
        final String[] header1 = format.getHeader();
        header1[0] = "mutated";
        final String[] header2 = format.getHeader();
        assertEquals("a", header2[0]);
        assertNotSame(header1, header2);
    }

    @Test
    void testGetHeaderCommentsReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeaderComments("c1", "c2").get();
        final String[] comments1 = format.getHeaderComments();
        comments1[0] = "mutated";
        final String[] comments2 = format.getHeaderComments();
        assertEquals("c1", comments2[0]);
        assertNull(CSVFormat.DEFAULT.getHeaderComments());
    }

    @Test
    void testIsCommentMarkerSet() {
        assertFalse(CSVFormat.DEFAULT.isCommentMarkerSet());
        assertTrue(CSVFormat.DEFAULT.builder().setCommentMarker('#').get().isCommentMarkerSet());
    }

    @Test
    void testIsNullStringSet() {
        assertFalse(CSVFormat.DEFAULT.isNullStringSet());
        assertTrue(CSVFormat.DEFAULT.builder().setNullString("NULL").get().isNullStringSet());
    }

    @Test
    void testIsQuoteCharacterSet() {
        assertTrue(CSVFormat.DEFAULT.isQuoteCharacterSet());
        assertFalse(CSVFormat.DEFAULT.builder().setQuote(null).get().isQuoteCharacterSet());
    }

    @Test
    void testMaxRowsBoundaries() {
        assertEquals(0, CSVFormat.DEFAULT.getMaxRows());
        assertFalse(CSVFormat.DEFAULT.useMaxRows());
        final CSVFormat negative = CSVFormat.DEFAULT.builder().setMaxRows(-5).get();
        assertFalse(negative.useMaxRows());
        assertTrue(negative.useRow(100));
        final CSVFormat limited = CSVFormat.DEFAULT.builder().setMaxRows(3).get();
        assertTrue(limited.useMaxRows());
        assertTrue(limited.useRow(3));
        assertFalse(limited.useRow(4));
    }

    @Test
    void testNewFormatOnlySetsDelimiter() {
        final CSVFormat format = CSVFormat.newFormat(';');
        assertEquals(";", format.getDelimiterString());
        assertNull(format.getQuoteCharacter());
        assertNull(format.getCommentMarker());
        assertNull(format.getEscapeCharacter());
        assertFalse(format.getIgnoreEmptyLines());
        assertFalse(format.getSkipHeaderRecord());
        assertNull(format.getRecordSeparator());
    }

    @Test
    void testParseReadsRecords() throws IOException {
        final Reader reader = new StringReader("a,b,c\r\n1,2,3\r\n");
        try (CSVParser parser = CSVFormat.DEFAULT.parse(reader)) {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("3", records.get(1).get(2));
        }
    }

    @Test
    void testPredefinedFormatProperties() {
        assertEquals('\t', CSVFormat.TDF.getDelimiter());
        assertTrue(CSVFormat.TDF.getIgnoreSurroundingSpaces());
        assertNull(CSVFormat.MYSQL.getQuoteCharacter());
        assertEquals(QuoteMode.ALL_NON_NULL, CSVFormat.MYSQL.getQuoteMode());
        assertNull(CSVFormat.POSTGRESQL_CSV.getEscapeCharacter());
        assertTrue(CSVFormat.EXCEL.getAllowMissingColumnNames());
        assertTrue(CSVFormat.EXCEL.getTrailingData());
        assertTrue(CSVFormat.EXCEL.getLenientEof());
        assertFalse(CSVFormat.RFC4180.getIgnoreEmptyLines());
    }

    @Test
    void testPredefinedEnumRoundTrip() {
        assertSame(CSVFormat.DEFAULT, CSVFormat.Predefined.Default.getFormat());
        assertEquals(CSVFormat.EXCEL, CSVFormat.valueOf("Excel"));
    }

    @Test
    void testPredefinedEnumRejectsUnknownName() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.valueOf("NotAFormat"));
    }

    @Test
    void testPrintAndPrintRecord() throws IOException {
        final StringWriter writer = new StringWriter();
        try (CSVPrinter printer = CSVFormat.DEFAULT.print(writer)) {
            printer.printRecord("x", "y");
        }
        assertEquals("x,y\r\n", writer.toString());
    }

    @Test
    void testPrintRecordDirectlyOnAppendable() throws IOException {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.printRecord(sb, "1", "2", "3");
        assertEquals("1,2,3\r\n", sb.toString());
    }

    @Test
    void testPrintlnWritesTrailingDelimiterAndSeparator() throws IOException {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get().println(sb);
        assertEquals(",\r\n", sb.toString());
    }

    @Test
    void testPrintNullValueUsesNullString() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("N/A").get();
        final StringBuilder sb = new StringBuilder();
        format.print(null, sb, true);
        assertEquals("N/A", sb.toString());
    }

    @Test
    void testPrintTrimsValueWhenTrimEnabled() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrim(true).get();
        final StringBuilder sb = new StringBuilder();
        format.print("  spaced  ", sb, true);
        assertEquals("spaced", sb.toString());
    }

    @Test
    void testQuoteCannotBeLineBreak() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder();
        assertThrows(IllegalArgumentException.class, () -> builder.setQuote('\n'));
    }

    @Test
    void testSetHeaderFromEnumClass() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(Header.class).get();
        assertArrayEquals(new String[] { "Name", "Email" }, format.getHeader());
        final CSVFormat disabled = CSVFormat.DEFAULT.builder().setHeader((Class<? extends Enum<?>>) null).get();
        assertNull(disabled.getHeader());
    }

    @Test
    void testSetNullStringAlsoUpdatesQuotedNullString() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        assertEquals("NULL", format.getNullString());
    }

    @Test
    void testToStringContainsConfiguredAttributes() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').setNullString("NULL").get();
        final String s = format.toString();
        assertTrue(s.contains("Delimiter=<,>"));
        assertTrue(s.contains("CommentStart=<#>"));
        assertTrue(s.contains("NullString=<NULL>"));
    }

    @Test
    void testValidateCommentMarkerCannotEqualDelimiter() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder().setCommentMarker(',');
        assertThrows(IllegalArgumentException.class, builder::get);
    }

    @Test
    void testValidateEscapeCannotEqualCommentMarker() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder().setCommentMarker('#').setEscape('#');
        assertThrows(IllegalArgumentException.class, builder::get);
    }

    @Test
    void testValidateEscapeCannotEqualDelimiter() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder().setEscape(',');
        assertThrows(IllegalArgumentException.class, builder::get);
    }

    @Test
    void testValidateQuoteCannotEqualCommentMarker() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder().setCommentMarker('#').setQuote('#');
        assertThrows(IllegalArgumentException.class, builder::get);
    }

    @Test
    void testValidateQuoteCannotEqualDelimiter() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder().setQuote(',');
        assertThrows(IllegalArgumentException.class, builder::get);
    }

    @Test
    void testValidateQuoteModeNoneRequiresEscape() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder().setQuoteMode(QuoteMode.NONE);
        assertThrows(IllegalArgumentException.class, builder::get);
        final CSVFormat ok = CSVFormat.DEFAULT.builder().setQuoteMode(QuoteMode.NONE).setEscape('\\').get();
        assertEquals(QuoteMode.NONE, ok.getQuoteMode());
    }

    @Test
    void testWithDelimiterDeprecatedWrapper() {
        final CSVFormat format = CSVFormat.DEFAULT.withDelimiter(';');
        assertEquals(";", format.getDelimiterString());
    }

    @Test
    void testWithHeaderDeprecatedWrapper() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("x", "y");
        assertArrayEquals(new String[] { "x", "y" }, format.getHeader());
    }

    @Test
    void testWithQuoteDeprecatedWrapperAcceptsNullToDisable() {
        final CSVFormat format = CSVFormat.DEFAULT.withQuote((Character) null);
        assertFalse(format.isQuoteCharacterSet());
    }
}
