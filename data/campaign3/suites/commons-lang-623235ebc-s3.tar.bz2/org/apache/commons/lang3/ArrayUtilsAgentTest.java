package org.apache.commons.lang3;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import java.util.AbstractMap;
import java.util.Arrays;
import java.util.BitSet;
import java.util.Comparator;
import java.util.Map;
import java.util.Random;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class ArrayUtilsAgentTest {

    // ---------------------------------------------------------------
    // Constants
    // ---------------------------------------------------------------

    @Test
    public void testEmptyArrayConstants() {
        assertEquals(0, ArrayUtils.EMPTY_BOOLEAN_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_BOOLEAN_OBJECT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_BYTE_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_BYTE_OBJECT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_CHAR_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_CHARACTER_OBJECT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_CLASS_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_DOUBLE_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_DOUBLE_OBJECT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_FLOAT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_FLOAT_OBJECT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_INT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_INTEGER_OBJECT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_LONG_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_LONG_OBJECT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_OBJECT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_SHORT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_SHORT_OBJECT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_STRING_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_THROWABLE_ARRAY.length);
    }

    @Test
    public void testIndexNotFoundConstant() {
        assertEquals(-1, ArrayUtils.INDEX_NOT_FOUND);
    }

    // ---------------------------------------------------------------
    // add
    // ---------------------------------------------------------------

    @Test
    public void testAddPrimitiveToNullArray() {
        assertArrayEquals(new int[] {5}, ArrayUtils.add((int[]) null, 5));
        assertArrayEquals(new boolean[] {true}, ArrayUtils.add((boolean[]) null, true));
    }

    @Test
    public void testAddPrimitiveAppendsAtEnd() {
        assertArrayEquals(new int[] {1, 0, 1}, ArrayUtils.add(new int[] {1, 0}, 1));
        assertArrayEquals(new boolean[] {true, false, true}, ArrayUtils.add(new boolean[] {true, false}, true));
    }

    @Test
    public void testAddObjectToNullArray() {
        String[] result = ArrayUtils.add((String[]) null, "a");
        assertArrayEquals(new String[] {"a"}, result);
    }

    @Test
    public void testAddObjectAppendsAtEndAndCopies() {
        String[] input = {"a", "b"};
        String[] result = ArrayUtils.add(input, "c");
        assertArrayEquals(new String[] {"a", "b", "c"}, result);
        assertEquals(2, input.length);
    }

    // ---------------------------------------------------------------
    // addAll
    // ---------------------------------------------------------------

    @Test
    public void testAddAllBothNullReturnsNull() {
        assertNull(ArrayUtils.addAll((int[]) null, (int[]) null));
        assertNull(ArrayUtils.addAll((Object[]) null, (Object[]) null));
    }

    @Test
    public void testAddAllFirstNullReturnsClonedCopyOfSecond() {
        int[] second = {1, 2};
        int[] result = ArrayUtils.addAll(null, second);
        assertArrayEquals(second, result);
        assertNotSame(second, result);
    }

    @Test
    public void testAddAllSecondNullReturnsClonedCopyOfFirst() {
        int[] first = {1, 2};
        int[] result = ArrayUtils.addAll(first, (int[]) null);
        assertArrayEquals(first, result);
        assertNotSame(first, result);
    }

    @Test
    public void testAddAllConcatenatesBothArrays() {
        assertArrayEquals(new int[] {1, 2, 3, 4}, ArrayUtils.addAll(new int[] {1, 2}, new int[] {3, 4}));
        assertArrayEquals(new String[0], ArrayUtils.addAll(new String[0], new String[0]));
        assertArrayEquals(new String[] {"a", "b", "c", "1", "2", "3"},
                ArrayUtils.addAll(new String[] {"a", "b", "c"}, new String[] {"1", "2", "3"}));
    }

    @Test
    public void testAddAllIncompatibleTypesThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                ArrayUtils.addAll(new String[] {"a"}, new Object[] {Integer.valueOf(1)});
            }
        });
    }

    // ---------------------------------------------------------------
    // addFirst
    // ---------------------------------------------------------------

    @Test
    public void testAddFirstOnNullArray() {
        assertArrayEquals(new int[] {1}, ArrayUtils.addFirst((int[]) null, 1));
    }

    @Test
    public void testAddFirstPrependsElement() {
        assertArrayEquals(new int[] {0, 1}, ArrayUtils.addFirst(new int[] {1}, 0));
        assertArrayEquals(new boolean[] {true, true, false}, ArrayUtils.addFirst(new boolean[] {true, false}, true));
    }

    // ---------------------------------------------------------------
    // clone
    // ---------------------------------------------------------------

    @Test
    public void testCloneNullReturnsNull() {
        assertNull(ArrayUtils.clone((int[]) null));
        assertNull(ArrayUtils.clone((Object[]) null));
    }

    @Test
    public void testCloneReturnsEqualButDistinctArray() {
        int[] original = {1, 2, 3};
        int[] cloned = ArrayUtils.clone(original);
        assertArrayEquals(original, cloned);
        assertNotSame(original, cloned);

        String[] originalObjects = {"a", "b"};
        String[] clonedObjects = ArrayUtils.clone(originalObjects);
        assertArrayEquals(originalObjects, clonedObjects);
        assertNotSame(originalObjects, clonedObjects);
    }

    // ---------------------------------------------------------------
    // contains / containsAny
    // ---------------------------------------------------------------

    @Test
    public void testContainsNullArrayReturnsFalse() {
        assertFalse(ArrayUtils.contains((int[]) null, 1));
        assertFalse(ArrayUtils.contains((Object[]) null, "a"));
    }

    @Test
    public void testContainsFindsValue() {
        assertTrue(ArrayUtils.contains(new int[] {1, 2, 3}, 2));
        assertFalse(ArrayUtils.contains(new int[] {1, 2, 3}, 4));
        assertTrue(ArrayUtils.contains(new Object[] {"a", null, "b"}, null));
        assertTrue(ArrayUtils.contains(new Object[] {"a", "b"}, "b"));
    }

    @Test
    public void testContainsWithTolerance() {
        double[] array = {1.0, 5.0, 9.0};
        assertTrue(ArrayUtils.contains(array, 5.2, 0.5));
        assertFalse(ArrayUtils.contains(array, 5.2, 0.1));
    }

    @Test
    public void testContainsAny() {
        assertTrue(ArrayUtils.containsAny(new int[] {1, 2, 3}, 9, 2));
        assertFalse(ArrayUtils.containsAny(new int[] {1, 2, 3}, 9, 8));
        assertFalse(ArrayUtils.containsAny((int[]) null, 1));
        assertTrue(ArrayUtils.containsAny(new Object[] {"a", "b"}, "x", "b"));
    }

    // ---------------------------------------------------------------
    // get / getLength / getComponentType
    // ---------------------------------------------------------------

    @Test
    public void testGetReturnsNullWhenOutOfBoundsOrNullArray() {
        assertNull(ArrayUtils.get((String[]) null, 0));
        assertNull(ArrayUtils.get(new String[] {"a"}, 5));
        assertNull(ArrayUtils.get(new String[] {"a"}, -1));
        assertEquals("a", ArrayUtils.get(new String[] {"a"}, 0));
    }

    @Test
    public void testGetWithDefaultValue() {
        assertEquals("default", ArrayUtils.get(new String[] {"a"}, 5, "default"));
        assertEquals("a", ArrayUtils.get(new String[] {"a"}, 0, "default"));
        assertEquals("default", ArrayUtils.get((String[]) null, 0, "default"));
    }

    @Test
    public void testGetComponentType() {
        assertEquals(String.class, ArrayUtils.getComponentType(new String[0]));
        assertEquals(Integer.class, ArrayUtils.getComponentType(new Integer[0]));
    }

    @Test
    public void testGetLengthContract() {
        assertEquals(0, ArrayUtils.getLength(null));
        assertEquals(0, ArrayUtils.getLength(new Object[0]));
        assertEquals(1, ArrayUtils.getLength(new Object[] {null}));
        assertEquals(2, ArrayUtils.getLength(new boolean[] {true, false}));
        assertEquals(3, ArrayUtils.getLength(new int[] {1, 2, 3}));
        assertEquals(3, ArrayUtils.getLength(new String[] {"a", "b", "c"}));
    }

    @Test
    public void testGetLengthNonArrayThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                ArrayUtils.getLength("not an array");
            }
        });
    }

    // ---------------------------------------------------------------
    // hashCode
    // ---------------------------------------------------------------

    @Test
    public void testHashCodeNullIsZero() {
        assertEquals(0, ArrayUtils.hashCode(null));
    }

    @Test
    public void testHashCodeConsistentForEqualContent() {
        int[] a = {1, 2, 3};
        int[] b = {1, 2, 3};
        assertEquals(ArrayUtils.hashCode(a), ArrayUtils.hashCode(b));
    }

    // ---------------------------------------------------------------
    // indexOf / lastIndexOf / indexesOf
    // ---------------------------------------------------------------

    @Test
    public void testIndexOfNullArray() {
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf((int[]) null, 1));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf((Object[]) null, "a"));
    }

    @Test
    public void testIndexOfFindsFirstOccurrence() {
        int[] array = {1, 2, 3, 2};
        assertEquals(1, ArrayUtils.indexOf(array, 2));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf(array, 9));
    }

    @Test
    public void testIndexOfWithStartIndex() {
        int[] array = {1, 2, 3, 2};
        assertEquals(3, ArrayUtils.indexOf(array, 2, 2));
        assertEquals(1, ArrayUtils.indexOf(array, 2, -5));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf(array, 2, 10));
    }

    @Test
    public void testLastIndexOfNullArray() {
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.lastIndexOf((int[]) null, 1));
    }

    @Test
    public void testLastIndexOfFindsLastOccurrence() {
        int[] array = {1, 2, 3, 2};
        assertEquals(3, ArrayUtils.lastIndexOf(array, 2));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.lastIndexOf(array, 2, -1));
        assertEquals(3, ArrayUtils.lastIndexOf(array, 2, 100));
    }

    @Test
    public void testIndexesOfReturnsAllMatchingPositions() {
        int[] array = {1, 2, 1, 3, 1};
        BitSet bits = ArrayUtils.indexesOf(array, 1);
        assertTrue(bits.get(0));
        assertTrue(bits.get(2));
        assertTrue(bits.get(4));
        assertFalse(bits.get(1));
        assertFalse(bits.get(3));
        assertEquals(3, bits.cardinality());
    }

    @Test
    public void testIndexesOfNullArrayReturnsEmptyBitSet() {
        BitSet bits = ArrayUtils.indexesOf((int[]) null, 1);
        assertEquals(0, bits.cardinality());
    }

    // ---------------------------------------------------------------
    // insert
    // ---------------------------------------------------------------

    @Test
    public void testInsertNullArrayReturnsNull() {
        assertNull(ArrayUtils.insert(0, (int[]) null, 1, 2));
    }

    @Test
    public void testInsertNullValuesReturnsClonedCopy() {
        int[] array = {1, 2, 3};
        int[] result = ArrayUtils.insert(1, array, (int[]) null);
        assertArrayEquals(array, result);
        assertNotSame(array, result);
    }

    @Test
    public void testInsertAtGivenIndex() {
        int[] array = {1, 2, 3};
        int[] result = ArrayUtils.insert(1, array, 9, 8);
        assertArrayEquals(new int[] {1, 9, 8, 2, 3}, result);
    }

    @Test
    public void testInsertIndexOutOfBoundsThrows() {
        final int[] array = {1, 2, 3};
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            public void execute() throws Throwable {
                ArrayUtils.insert(-1, array, 9);
            }
        });
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            public void execute() throws Throwable {
                ArrayUtils.insert(4, array, 9);
            }
        });
    }

    // ---------------------------------------------------------------
    // isArrayIndexValid
    // ---------------------------------------------------------------

    @Test
    public void testIsArrayIndexValid() {
        assertFalse(ArrayUtils.isArrayIndexValid((String[]) null, 0));
        assertFalse(ArrayUtils.isArrayIndexValid(new String[0], 0));
        assertTrue(ArrayUtils.isArrayIndexValid(new String[] {"a"}, 0));
        assertFalse(ArrayUtils.isArrayIndexValid(new String[] {"a"}, 1));
        assertFalse(ArrayUtils.isArrayIndexValid(new String[] {"a"}, -1));
    }

    // ---------------------------------------------------------------
    // isEmpty / isNotEmpty
    // ---------------------------------------------------------------

    @Test
    public void testIsEmptyForPrimitiveAndObjectArrays() {
        assertTrue(ArrayUtils.isEmpty((int[]) null));
        assertTrue(ArrayUtils.isEmpty(new int[0]));
        assertFalse(ArrayUtils.isEmpty(new int[] {1}));

        assertTrue(ArrayUtils.isEmpty((Object[]) null));
        assertTrue(ArrayUtils.isEmpty(new Object[0]));
        assertFalse(ArrayUtils.isEmpty(new Object[] {"a"}));
    }

    @Test
    public void testIsNotEmptyForPrimitiveAndObjectArrays() {
        assertFalse(ArrayUtils.isNotEmpty((int[]) null));
        assertFalse(ArrayUtils.isNotEmpty(new int[0]));
        assertTrue(ArrayUtils.isNotEmpty(new int[] {1}));

        assertFalse(ArrayUtils.isNotEmpty((String[]) null));
        assertTrue(ArrayUtils.isNotEmpty(new String[] {"a"}));
    }

    // ---------------------------------------------------------------
    // isSameLength / isSameType
    // ---------------------------------------------------------------

    @Test
    public void testIsSameLengthTreatsNullAsEmpty() {
        assertTrue(ArrayUtils.isSameLength((int[]) null, (int[]) null));
        assertTrue(ArrayUtils.isSameLength((int[]) null, new int[0]));
        assertFalse(ArrayUtils.isSameLength(new int[] {1}, (int[]) null));
        assertTrue(ArrayUtils.isSameLength(new int[] {1, 2}, new int[] {3, 4}));
        assertFalse(ArrayUtils.isSameLength(new int[] {1, 2}, new int[] {3}));

        assertTrue(ArrayUtils.isSameLength((Object[]) null, (Object[]) null));
        assertTrue(ArrayUtils.isSameLength(new String[] {"a"}, new Object[] {Integer.valueOf(1)}));
    }

    @Test
    public void testIsSameTypeMatchesComponentType() {
        assertTrue(ArrayUtils.isSameType(new int[0], new int[] {1, 2}));
        assertFalse(ArrayUtils.isSameType(new int[0], new long[0]));
        assertTrue(ArrayUtils.isSameType(new int[0][0], new int[1][1]));
        assertFalse(ArrayUtils.isSameType(new int[0][0], new int[0]));
    }

    @Test
    public void testIsSameTypeNullThrows() {
        final int[] array = {1};
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                ArrayUtils.isSameType(null, array);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                ArrayUtils.isSameType(array, null);
            }
        });
    }

    // ---------------------------------------------------------------
    // isSorted
    // ---------------------------------------------------------------

    @Test
    public void testIsSortedPrimitiveArrays() {
        assertTrue(ArrayUtils.isSorted(new int[] {1, 2, 2, 3}));
        assertFalse(ArrayUtils.isSorted(new int[] {3, 2, 1}));
        assertTrue(ArrayUtils.isSorted(new int[0]));
        assertTrue(ArrayUtils.isSorted(new int[] {1}));
    }

    @Test
    public void testIsSortedBooleanArrayOrdersFalseBeforeTrue() {
        assertTrue(ArrayUtils.isSorted(new boolean[] {false, false, true, true}));
        assertFalse(ArrayUtils.isSorted(new boolean[] {true, false}));
    }

    @Test
    public void testIsSortedComparableArray() {
        assertTrue(ArrayUtils.isSorted(new String[] {"a", "b", "c"}));
        assertFalse(ArrayUtils.isSorted(new String[] {"c", "b", "a"}));
    }

    @Test
    public void testIsSortedWithComparator() {
        Comparator<String> reverseOrder = new Comparator<String>() {
            public int compare(String o1, String o2) {
                return o2.compareTo(o1);
            }
        };
        assertTrue(ArrayUtils.isSorted(new String[] {"c", "b", "a"}, reverseOrder));
        assertFalse(ArrayUtils.isSorted(new String[] {"a", "b", "c"}, reverseOrder));
    }

    @Test
    public void testIsSortedNullComparatorThrows() {
        final String[] array = {"a", "b"};
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                ArrayUtils.isSorted(array, null);
            }
        });
    }

    // ---------------------------------------------------------------
    // newInstance
    // ---------------------------------------------------------------

    @Test
    public void testNewInstanceCreatesArrayOfGivenLengthAndType() {
        String[] result = ArrayUtils.newInstance(String.class, 3);
        assertEquals(3, result.length);
        assertEquals(String.class, result.getClass().getComponentType());
    }

    @Test
    public void testNewInstanceNullComponentTypeThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                ArrayUtils.newInstance(null, 1);
            }
        });
    }

    // ---------------------------------------------------------------
    // nullTo / nullToEmpty
    // ---------------------------------------------------------------

    @Test
    public void testNullToReturnsDefaultForNullOrEmpty() {
        String[] defaultArray = {"default"};
        assertSame(defaultArray, ArrayUtils.nullTo((String[]) null, defaultArray));
        assertSame(defaultArray, ArrayUtils.nullTo(new String[0], defaultArray));
        String[] nonEmpty = {"a"};
        assertSame(nonEmpty, ArrayUtils.nullTo(nonEmpty, defaultArray));
    }

    @Test
    public void testNullToEmptyIntArray() {
        assertArrayEquals(ArrayUtils.EMPTY_INT_ARRAY, ArrayUtils.nullToEmpty((int[]) null));
        assertSame(ArrayUtils.EMPTY_INT_ARRAY, ArrayUtils.nullToEmpty((int[]) null));
        assertSame(ArrayUtils.EMPTY_INT_ARRAY, ArrayUtils.nullToEmpty(new int[0]));
        int[] nonEmpty = {1, 2};
        assertSame(nonEmpty, ArrayUtils.nullToEmpty(nonEmpty));
    }

    @Test
    public void testNullToEmptyObjectArrayWithType() {
        String[] result = ArrayUtils.nullToEmpty((String[]) null, String[].class);
        assertNotNull(result);
        assertEquals(0, result.length);
    }

    @Test
    public void testNullToEmptyWithNullTypeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                ArrayUtils.nullToEmpty((String[]) null, null);
            }
        });
    }

    // ---------------------------------------------------------------
    // remove / removeAll
    // ---------------------------------------------------------------

    @Test
    public void testRemoveShiftsSubsequentElementsLeft() {
        assertArrayEquals(new int[] {6, 3}, ArrayUtils.remove(new int[] {2, 6, 3}, 0));
        assertArrayEquals(new int[] {2, 3}, ArrayUtils.remove(new int[] {2, 6, 3}, 1));
        assertArrayEquals(new String[] {"a", "c"}, ArrayUtils.remove(new String[] {"a", "b", "c"}, 1));
    }

    @Test
    public void testRemoveNullArrayThrows() {
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            public void execute() throws Throwable {
                ArrayUtils.remove((int[]) null, 0);
            }
        });
    }

    @Test
    public void testRemoveOutOfBoundsThrows() {
        final int[] array = {1, 2};
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            public void execute() throws Throwable {
                ArrayUtils.remove(array, -1);
            }
        });
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            public void execute() throws Throwable {
                ArrayUtils.remove(array, 2);
            }
        });
    }

    @Test
    public void testRemoveAllRemovesMultiplePositions() {
        boolean[] array = {true, false, true};
        assertArrayEquals(new boolean[] {false}, ArrayUtils.removeAll(array, 0, 2));
        int[] intArray = {2, 6, 3, 9};
        assertArrayEquals(new int[] {6, 9}, ArrayUtils.removeAll(intArray, 0, 2));
    }

    // ---------------------------------------------------------------
    // removeAllOccurrences / removeElement / removeElements
    // ---------------------------------------------------------------

    @Test
    public void testRemoveAllOccurrencesRemovesEveryMatch() {
        assertArrayEquals(new int[] {2, 3}, ArrayUtils.removeAllOccurrences(new int[] {1, 2, 1, 3, 1}, 1));
        assertArrayEquals(new String[] {"b"}, ArrayUtils.removeAllOccurrences(new String[] {"a", "b", "a"}, "a"));
    }

    @Test
    public void testRemoveElementRemovesOnlyFirstOccurrence() {
        assertArrayEquals(new int[] {2, 1, 3}, ArrayUtils.removeElement(new int[] {1, 2, 1, 3}, 1));
    }

    @Test
    public void testRemoveElementNoMatchReturnsCopy() {
        int[] array = {1, 2, 3};
        int[] result = ArrayUtils.removeElement(array, 9);
        assertArrayEquals(array, result);
        assertNotSame(array, result);
    }

    @Test
    public void testRemoveElementsRemovesGivenQuantities() {
        int[] array = {1, 2, 1, 1, 3};
        assertArrayEquals(new int[] {2, 1, 3}, ArrayUtils.removeElements(array, 1, 1));
    }

    // ---------------------------------------------------------------
    // reverse
    // ---------------------------------------------------------------

    @Test
    public void testReverseFullArray() {
        int[] array = {1, 2, 3};
        ArrayUtils.reverse(array);
        assertArrayEquals(new int[] {3, 2, 1}, array);
    }

    @Test
    public void testReverseNullArrayDoesNothing() {
        ArrayUtils.reverse((int[]) null);
    }

    @Test
    public void testReverseRange() {
        int[] array = {1, 2, 3, 4, 5};
        ArrayUtils.reverse(array, 1, 4);
        assertArrayEquals(new int[] {1, 4, 3, 2, 5}, array);
    }

    @Test
    public void testReverseRangeClampsOutOfBoundIndices() {
        int[] array = {1, 2, 3};
        ArrayUtils.reverse(array, -5, 100);
        assertArrayEquals(new int[] {3, 2, 1}, array);
    }

    // ---------------------------------------------------------------
    // shift
    // ---------------------------------------------------------------

    @Test
    public void testShiftByZeroDoesNotChangeArray() {
        int[] array = {1, 2, 3, 4};
        ArrayUtils.shift(array, 0);
        assertArrayEquals(new int[] {1, 2, 3, 4}, array);
    }

    @Test
    public void testShiftOnNullOrEmptyDoesNothing() {
        ArrayUtils.shift((int[]) null, 3);
        int[] empty = new int[0];
        ArrayUtils.shift(empty, 3);
        assertEquals(0, empty.length);
    }

    @Test
    public void testShiftByLengthIsModuloEquivalentToNoShift() {
        int[] array = {1, 2, 3, 4, 5};
        int[] expected = array.clone();
        ArrayUtils.shift(array, array.length);
        assertArrayEquals(expected, array);
    }

    @Test
    public void testShiftTwiceByComplementaryOffsetsRestoresOriginal() {
        int[] array = {1, 2, 3, 4, 5};
        int[] original = array.clone();
        ArrayUtils.shift(array, 2);
        ArrayUtils.shift(array, array.length - 2);
        assertArrayEquals(original, array);
    }

    // ---------------------------------------------------------------
    // shuffle
    // ---------------------------------------------------------------

    @Test
    public void testShuffleOnSingleElementArrayIsUnchanged() {
        int[] array = {42};
        ArrayUtils.shuffle(array, new Random(0));
        assertArrayEquals(new int[] {42}, array);
    }

    @Test
    public void testShufflePreservesMultisetOfElements() {
        int[] array = {1, 2, 3, 4, 5};
        int[] expectedSorted = array.clone();
        Arrays.sort(expectedSorted);
        ArrayUtils.shuffle(array, new Random(123));
        int[] actualSorted = array.clone();
        Arrays.sort(actualSorted);
        assertArrayEquals(expectedSorted, actualSorted);
    }

    // ---------------------------------------------------------------
    // startsWith
    // ---------------------------------------------------------------

    @Test
    public void testStartsWithBothNullIsTrue() {
        assertTrue(ArrayUtils.startsWith(null, null));
    }

    @Test
    public void testStartsWithOneNullIsFalse() {
        assertFalse(ArrayUtils.startsWith(new byte[] {1, 2}, null));
        assertFalse(ArrayUtils.startsWith(null, new byte[] {1, 2}));
    }

    @Test
    public void testStartsWithMatchingPrefix() {
        assertTrue(ArrayUtils.startsWith(new byte[] {1, 2, 3}, new byte[] {1, 2}));
        assertFalse(ArrayUtils.startsWith(new byte[] {1, 2, 3}, new byte[] {2, 3}));
    }

    // ---------------------------------------------------------------
    // subarray
    // ---------------------------------------------------------------

    @Test
    public void testSubarrayNullReturnsNull() {
        assertNull(ArrayUtils.subarray((int[]) null, 0, 1));
    }

    @Test
    public void testSubarrayBasicRange() {
        int[] array = {1, 2, 3, 4, 5};
        assertArrayEquals(new int[] {2, 3}, ArrayUtils.subarray(array, 1, 3));
    }

    @Test
    public void testSubarrayNegativeStartIsPromotedToZero() {
        int[] array = {1, 2, 3};
        assertArrayEquals(new int[] {1, 2}, ArrayUtils.subarray(array, -5, 2));
    }

    @Test
    public void testSubarrayStartOverLengthProducesEmptyArray() {
        int[] array = {1, 2, 3};
        assertArrayEquals(new int[0], ArrayUtils.subarray(array, 10, 20));
    }

    @Test
    public void testSubarrayEndBeforeStartProducesEmptyArray() {
        int[] array = {1, 2, 3};
        assertArrayEquals(new int[0], ArrayUtils.subarray(array, 2, 1));
    }

    @Test
    public void testSubarrayEndOverLengthIsDemotedToLength() {
        int[] array = {1, 2, 3};
        assertArrayEquals(new int[] {2, 3}, ArrayUtils.subarray(array, 1, 100));
    }

    // ---------------------------------------------------------------
    // swap
    // ---------------------------------------------------------------

    @Test
    public void testSwapTwoElements() {
        int[] array = {1, 2, 3};
        ArrayUtils.swap(array, 0, 2);
        assertArrayEquals(new int[] {3, 2, 1}, array);
    }

    @Test
    public void testSwapSameIndexIsNoop() {
        int[] array = {1, 2, 3};
        ArrayUtils.swap(array, 0, 0);
        assertArrayEquals(new int[] {1, 2, 3}, array);
    }

    @Test
    public void testSwapOverflowIndexIsNoop() {
        int[] array = {1, 2, 3};
        ArrayUtils.swap(array, 0, 5);
        assertArrayEquals(new int[] {1, 2, 3}, array);
    }

    @Test
    public void testSwapNegativeIndexIsPromotedToZero() {
        int[] array = {1, 2, 3};
        ArrayUtils.swap(array, -1, 1);
        assertArrayEquals(new int[] {2, 1, 3}, array);
    }

    @Test
    public void testSwapNullOrEmptyArrayDoesNothing() {
        ArrayUtils.swap((int[]) null, 0, 1);
        int[] empty = new int[0];
        ArrayUtils.swap(empty, 0, 1);
        assertEquals(0, empty.length);
    }

    @Test
    public void testSwapRangeOfElements() {
        int[] array = {1, 2, 3, 4};
        ArrayUtils.swap(array, 0, 2, 2);
        assertArrayEquals(new int[] {3, 4, 1, 2}, array);
    }

    @Test
    public void testSwapRangeStoppedAtArrayEnd() {
        int[] array = {1, 2, 3, 4};
        ArrayUtils.swap(array, 0, 3, 3);
        assertArrayEquals(new int[] {4, 2, 3, 1}, array);
    }

    // ---------------------------------------------------------------
    // toArray / toMap
    // ---------------------------------------------------------------

    @Test
    public void testToArrayCreatesArrayFromVarargs() {
        String[] result = ArrayUtils.toArray("a", "b", "c");
        assertArrayEquals(new String[] {"a", "b", "c"}, result);
    }

    @Test
    public void testToMapNullReturnsNull() {
        assertNull(ArrayUtils.toMap(null));
    }

    @Test
    public void testToMapFromTwoElementArrays() {
        Object[] input = {new String[] {"RED", "#FF0000"}, new String[] {"GREEN", "#00FF00"}};
        Map<Object, Object> map = ArrayUtils.toMap(input);
        assertEquals("#FF0000", map.get("RED"));
        assertEquals("#00FF00", map.get("GREEN"));
        assertEquals(2, map.size());
    }

    @Test
    public void testToMapFromMapEntries() {
        Map.Entry<String, String> entry = new AbstractMap.SimpleEntry<String, String>("key", "value");
        Object[] input = {entry};
        Map<Object, Object> map = ArrayUtils.toMap(input);
        assertEquals("value", map.get("key"));
    }

    @Test
    public void testToMapElementArrayTooShortThrows() {
        final Object[] input = {new String[] {"onlyOne"}};
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                ArrayUtils.toMap(input);
            }
        });
    }

    @Test
    public void testToMapInvalidElementTypeThrows() {
        final Object[] input = {"not an entry or array"};
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                ArrayUtils.toMap(input);
            }
        });
    }

    // ---------------------------------------------------------------
    // toObject / toPrimitive
    // ---------------------------------------------------------------

    @Test
    public void testToObjectNullReturnsNull() {
        assertNull(ArrayUtils.toObject((int[]) null));
    }

    @Test
    public void testToObjectConvertsPrimitivesToWrappers() {
        Integer[] result = ArrayUtils.toObject(new int[] {1, 2, 3});
        assertArrayEquals(new Integer[] {1, 2, 3}, result);
    }

    @Test
    public void testToPrimitiveNullReturnsNull() {
        assertNull(ArrayUtils.toPrimitive((Integer[]) null));
    }

    @Test
    public void testToPrimitiveConvertsWrappersToPrimitives() {
        int[] result = ArrayUtils.toPrimitive(new Integer[] {1, 2, 3});
        assertArrayEquals(new int[] {1, 2, 3}, result);
    }

    @Test
    public void testToPrimitiveNullElementThrowsWithoutDefault() {
        final Integer[] array = {1, null};
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                ArrayUtils.toPrimitive(array);
            }
        });
    }

    @Test
    public void testToPrimitiveWithValueForNull() {
        Integer[] array = {1, null, 3};
        int[] result = ArrayUtils.toPrimitive(array, -1);
        assertArrayEquals(new int[] {1, -1, 3}, result);
    }

    @Test
    public void testToPrimitiveBooleanNullMapsToFalseByDefault() {
        Boolean[] array = {Boolean.TRUE, null};
        boolean[] result = ArrayUtils.toPrimitive(array);
        assertArrayEquals(new boolean[] {true, false}, result);
    }

    @Test
    public void testToPrimitiveGenericObjectDelegatesByType() {
        assertNull(ArrayUtils.toPrimitive((Object) null));
        Object result = ArrayUtils.toPrimitive((Object) new Integer[] {1, 2});
        assertArrayEquals(new int[] {1, 2}, (int[]) result);
    }

    // ---------------------------------------------------------------
    // toString / toStringArray
    // ---------------------------------------------------------------

    @Test
    public void testToStringNullArrayYieldsEmptyBraces() {
        assertEquals("{}", ArrayUtils.toString(null));
    }

    @Test
    public void testToStringWithStringIfNull() {
        assertEquals("null-array", ArrayUtils.toString(null, "null-array"));
    }

    @Test
    public void testToStringFormatsArrayContent() {
        assertEquals("{1,2,3}", ArrayUtils.toString(new int[] {1, 2, 3}));
    }

    @Test
    public void testToStringArrayNullReturnsNull() {
        assertNull(ArrayUtils.toStringArray(null));
    }

    @Test
    public void testToStringArrayConvertsElementsToStrings() {
        Object[] input = {Integer.valueOf(1), "b", Boolean.TRUE};
        String[] result = ArrayUtils.toStringArray(input);
        assertArrayEquals(new String[] {"1", "b", "true"}, result);
    }

    @Test
    public void testToStringArrayWithNullElementThrowsWithoutDefault() {
        final Object[] input = {"a", null};
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                ArrayUtils.toStringArray(input);
            }
        });
    }

    @Test
    public void testToStringArrayWithValueForNullElements() {
        Object[] input = {"a", null};
        String[] result = ArrayUtils.toStringArray(input, "N/A");
        assertArrayEquals(new String[] {"a", "N/A"}, result);
    }
}
