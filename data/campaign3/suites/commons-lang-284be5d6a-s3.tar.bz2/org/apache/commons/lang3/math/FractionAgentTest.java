package org.apache.commons.lang3.math;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class FractionAgentTest {

    // ---- static constants ----

    @Test
    public void testConstantZero() {
        assertEquals(0, Fraction.ZERO.getNumerator());
        assertEquals(1, Fraction.ZERO.getDenominator());
    }

    @Test
    public void testConstantOne() {
        assertEquals(1, Fraction.ONE.getNumerator());
        assertEquals(1, Fraction.ONE.getDenominator());
    }

    @Test
    public void testConstantOneHalf() {
        assertEquals(1, Fraction.ONE_HALF.getNumerator());
        assertEquals(2, Fraction.ONE_HALF.getDenominator());
    }

    @Test
    public void testConstantOneThird() {
        assertEquals(1, Fraction.ONE_THIRD.getNumerator());
        assertEquals(3, Fraction.ONE_THIRD.getDenominator());
    }

    @Test
    public void testConstantTwoThirds() {
        assertEquals(2, Fraction.TWO_THIRDS.getNumerator());
        assertEquals(3, Fraction.TWO_THIRDS.getDenominator());
    }

    @Test
    public void testConstantOneQuarter() {
        assertEquals(1, Fraction.ONE_QUARTER.getNumerator());
        assertEquals(4, Fraction.ONE_QUARTER.getDenominator());
    }

    @Test
    public void testConstantTwoQuarters() {
        assertEquals(2, Fraction.TWO_QUARTERS.getNumerator());
        assertEquals(4, Fraction.TWO_QUARTERS.getDenominator());
    }

    @Test
    public void testConstantThreeQuarters() {
        assertEquals(3, Fraction.THREE_QUARTERS.getNumerator());
        assertEquals(4, Fraction.THREE_QUARTERS.getDenominator());
    }

    @Test
    public void testConstantOneFifth() {
        assertEquals(1, Fraction.ONE_FIFTH.getNumerator());
        assertEquals(5, Fraction.ONE_FIFTH.getDenominator());
    }

    @Test
    public void testConstantTwoFifths() {
        assertEquals(2, Fraction.TWO_FIFTHS.getNumerator());
        assertEquals(5, Fraction.TWO_FIFTHS.getDenominator());
    }

    @Test
    public void testConstantThreeFifths() {
        assertEquals(3, Fraction.THREE_FIFTHS.getNumerator());
        assertEquals(5, Fraction.THREE_FIFTHS.getDenominator());
    }

    @Test
    public void testConstantFourFifths() {
        assertEquals(4, Fraction.FOUR_FIFTHS.getNumerator());
        assertEquals(5, Fraction.FOUR_FIFTHS.getDenominator());
    }

    // ---- getFraction(int, int) ----

    @Test
    public void testGetFractionIntIntBasic() {
        Fraction f = Fraction.getFraction(3, 7);
        assertEquals(3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionIntIntResolvesNegativeDenominatorToNumerator() {
        Fraction f = Fraction.getFraction(3, -7);
        assertEquals(-3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionIntIntZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new ThrowingCall() {
            public void execute() {
                Fraction.getFraction(1, 0);
            }
        });
    }

    @Test
    public void testGetFractionIntIntNegativeDenominatorWithMinValueNumeratorThrows() {
        assertThrows(ArithmeticException.class, new ThrowingCall() {
            public void execute() {
                Fraction.getFraction(Integer.MIN_VALUE, -1);
            }
        });
    }

    // ---- getFraction(int, int, int) ----

    @Test
    public void testGetFractionWholeNumDenomBasic() {
        Fraction f = Fraction.getFraction(1, 3, 7);
        assertEquals(10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionWholeNumDenomNegativeWhole() {
        Fraction f = Fraction.getFraction(-1, 3, 7);
        assertEquals(-10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionWholeNumDenomZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new ThrowingCall() {
            public void execute() {
                Fraction.getFraction(1, 1, 0);
            }
        });
    }

    @Test
    public void testGetFractionWholeNumDenomNegativeDenominatorThrows() {
        assertThrows(ArithmeticException.class, new ThrowingCall() {
            public void execute() {
                Fraction.getFraction(1, 1, -1);
            }
        });
    }

    @Test
    public void testGetFractionWholeNumDenomNegativeNumeratorThrows() {
        assertThrows(ArithmeticException.class, new ThrowingCall() {
            public void execute() {
                Fraction.getFraction(1, -1, 2);
            }
        });
    }

    @Test
    public void testGetFractionWholeNumDenomOverflowThrows() {
        assertThrows(ArithmeticException.class, new ThrowingCall() {
            public void execute() {
                Fraction.getFraction(Integer.MAX_VALUE, 1, 1);
            }
        });
    }

    // ---- getFraction(String) ----

    @Test
    public void testGetFractionStringSimple() {
        Fraction f = Fraction.getFraction("3/7");
        assertEquals(3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionStringMixed() {
        Fraction f = Fraction.getFraction("1 3/7");
        assertEquals(10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionStringWholeNumber() {
        Fraction f = Fraction.getFraction("7");
        assertEquals(7, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    public void testGetFractionStringDecimal() {
        Fraction f = Fraction.getFraction("1.5");
        assertEquals(0, f.compareTo(Fraction.getFraction(3, 2)));
    }

    @Test
    public void testGetFractionStringNullThrows() {
        assertThrows(NullPointerException.class, new ThrowingCall() {
            public void execute() {
                Fraction.getFraction((String) null);
            }
        });
    }

    @Test
    public void testGetFractionStringZeroDenominatorThrowsWithCause() {
        NumberFormatException ex = assertThrows(NumberFormatException.class, new ThrowingCall() {
            public void execute() {
                Fraction.getFraction("1/0");
            }
        });
        assertTrue(ex.getCause() instanceof ArithmeticException);
    }

    @Test
    public void testGetFractionStringMalformedThrows() {
        assertThrows(NumberFormatException.class, new ThrowingCall() {
            public void execute() {
                Fraction.getFraction("not-a-fraction");
            }
        });
    }

    // ---- getFraction(double) ----

    @Test
    public void testGetFractionDoubleBasic() {
        Fraction half = Fraction.getFraction(0.5d);
        assertEquals(0, half.compareTo(Fraction.getFraction(1, 2)));
        assertEquals(0.5d, half.doubleValue(), 0.0000001d);

        Fraction negHalf = Fraction.getFraction(-0.5d);
        assertEquals(0, negHalf.compareTo(Fraction.getFraction(-1, 2)));

        Fraction zero = Fraction.getFraction(0.0d);
        assertEquals(0, zero.compareTo(Fraction.ZERO));

        Fraction one = Fraction.getFraction(1.0d);
        assertEquals(0, one.compareTo(Fraction.ONE));
    }

    @Test
    public void testGetFractionDoubleNaNThrows() {
        assertThrows(ArithmeticException.class, new ThrowingCall() {
            public void execute() {
                Fraction.getFraction(Double.NaN);
            }
        });
    }

    @Test
    public void testGetFractionDoubleTooLargeThrows() {
        assertThrows(ArithmeticException.class, new ThrowingCall() {
            public void execute() {
                Fraction.getFraction(1.0e20d);
            }
        });
    }

    // ---- getReducedFraction(int, int) ----

    @Test
    public void testGetReducedFractionBasic() {
        Fraction f = Fraction.getReducedFraction(2, 4);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetReducedFractionResolvesNegativeSignToNumerator() {
        Fraction f = Fraction.getReducedFraction(-2, 4);
        assertEquals(-1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetReducedFractionZero() {
        Fraction f = Fraction.getReducedFraction(0, 5);
        assertEquals(0, f.getNumerator());
        assertEquals(0, f.compareTo(Fraction.ZERO));
    }

    @Test
    public void testGetReducedFractionZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new ThrowingCall() {
            public void execute() {
                Fraction.getReducedFraction(1, 0);
            }
        });
    }

    // ---- abs ----

    @Test
    public void testAbsOnPositiveReturnsSameInstance() {
        Fraction f = Fraction.getFraction(3, 7);
        assertSame(f, f.abs());
    }

    @Test
    public void testAbsOnNegative() {
        Fraction f = Fraction.getFraction(-3, 7);
        Fraction abs = f.abs();
        assertEquals(3, abs.getNumerator());
        assertEquals(7, abs.getDenominator());
    }

    // ---- add ----

    @Test
    public void testAddReducesResult() {
        Fraction result = Fraction.ONE_THIRD.add(Fraction.ONE_THIRD);
        assertTrue(result.equals(Fraction.TWO_THIRDS));

        Fraction resultOne = Fraction.ONE_HALF.add(Fraction.ONE_HALF);
        assertTrue(resultOne.equals(Fraction.ONE));
    }

    @Test
    public void testAddNullThrows() {
        assertThrows(NullPointerException.class, new ThrowingCall() {
            public void execute() {
                Fraction.ONE.add(null);
            }
        });
    }

    @Test
    public void testAddOverflowThrows() {
        final Fraction big = Fraction.getFraction(Integer.MAX_VALUE, 1);
        assertThrows(ArithmeticException.class, new ThrowingCall() {
            public void execute() {
                big.add(big);
            }
        });
    }

    // ---- subtract ----

    @Test
    public void testSubtract() {
        Fraction result = Fraction.ONE.subtract(Fraction.ONE_THIRD);
        assertTrue(result.equals(Fraction.TWO_THIRDS));
    }

    @Test
    public void testSubtractNullThrows() {
        assertThrows(NullPointerException.class, new ThrowingCall() {
            public void execute() {
                Fraction.ONE.subtract(null);
            }
        });
    }

    // ---- multiplyBy ----

    @Test
    public void testMultiplyByReducesResult() {
        Fraction result = Fraction.ONE_HALF.multiplyBy(Fraction.ONE_HALF);
        assertTrue(result.equals(Fraction.ONE_QUARTER));
    }

    @Test
    public void testMultiplyByNullThrows() {
        assertThrows(NullPointerException.class, new ThrowingCall() {
            public void execute() {
                Fraction.ONE.multiplyBy(null);
            }
        });
    }

    // ---- divideBy ----

    @Test
    public void testDivideBy() {
        Fraction result = Fraction.ONE_HALF.divideBy(Fraction.ONE_HALF);
        assertTrue(result.equals(Fraction.ONE));
    }

    @Test
    public void testDivideByZeroThrows() {
        assertThrows(ArithmeticException.class, new ThrowingCall() {
            public void execute() {
                Fraction.ONE.divideBy(Fraction.ZERO);
            }
        });
    }

    @Test
    public void testDivideByNullThrows() {
        assertThrows(NullPointerException.class, new ThrowingCall() {
            public void execute() {
                Fraction.ONE.divideBy(null);
            }
        });
    }

    // ---- compareTo ----

    @Test
    public void testCompareTo() {
        assertTrue(Fraction.ONE_HALF.compareTo(Fraction.ONE_THIRD) > 0);
        assertTrue(Fraction.ONE_THIRD.compareTo(Fraction.ONE_HALF) < 0);
        assertEquals(0, Fraction.ONE_HALF.compareTo(Fraction.ONE_HALF));
        // equal in value but different representation: compareTo treats them equal
        assertEquals(0, Fraction.ONE_HALF.compareTo(Fraction.TWO_QUARTERS));
    }

    @Test
    public void testCompareToNullThrows() {
        assertThrows(NullPointerException.class, new ThrowingCall() {
            public void execute() {
                Fraction.ONE.compareTo(null);
            }
        });
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Test
    public void testCompareToNonFractionThrowsClassCastException() {
        final Comparable raw = Fraction.ONE;
        assertThrows(ClassCastException.class, new ThrowingCall() {
            public void execute() {
                raw.compareTo("not a fraction");
            }
        });
    }

    // ---- equals / hashCode ----

    @Test
    public void testEqualsDistinguishesUnreducedValues() {
        assertFalse(Fraction.ONE_HALF.equals(Fraction.TWO_QUARTERS));
    }

    @Test
    public void testEqualsSameValue() {
        Fraction a = Fraction.getFraction(3, 7);
        Fraction b = Fraction.getFraction(3, 7);
        assertTrue(a.equals(b));
        assertTrue(b.equals(a));
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    public void testEqualsAgainstNullAndOtherType() {
        assertFalse(Fraction.ONE.equals(null));
        assertFalse(Fraction.ONE.equals("1/1"));
    }

    // ---- getters ----

    @Test
    public void testGetNumeratorReturnsRawUnreducedValue() {
        Fraction f = Fraction.getFraction(6, 3);
        assertEquals(6, f.getNumerator());
        assertEquals(3, f.getDenominator());
    }

    @Test
    public void testGetProperNumeratorAndWholePositive() {
        Fraction f = Fraction.getFraction(7, 4);
        assertEquals(1, f.getProperWhole());
        assertEquals(3, f.getProperNumerator());
    }

    @Test
    public void testGetProperNumeratorAndWholeNegative() {
        Fraction f = Fraction.getFraction(-7, 4);
        assertEquals(-1, f.getProperWhole());
        assertEquals(3, f.getProperNumerator());
    }

    @Test
    public void testGetProperNumeratorAndWholeExactWhole() {
        Fraction f = Fraction.getFraction(6, 3);
        assertEquals(2, f.getProperWhole());
        assertEquals(0, f.getProperNumerator());
    }

    @Test
    public void testGetProperNumeratorAndWholeZero() {
        assertEquals(0, Fraction.ZERO.getProperWhole());
        assertEquals(0, Fraction.ZERO.getProperNumerator());
    }

    // ---- invert ----

    @Test
    public void testInvert() {
        Fraction f = Fraction.getFraction(3, 7);
        Fraction inverted = f.invert();
        assertEquals(7, inverted.getNumerator());
        assertEquals(3, inverted.getDenominator());
    }

    @Test
    public void testInvertZeroThrows() {
        assertThrows(ArithmeticException.class, new ThrowingCall() {
            public void execute() {
                Fraction.ZERO.invert();
            }
        });
    }

    // ---- negate ----

    @Test
    public void testNegate() {
        Fraction negated = Fraction.ONE_HALF.negate();
        assertEquals(-1, negated.getNumerator());
        assertEquals(2, negated.getDenominator());
    }

    // ---- pow ----

    @Test
    public void testPowPositive() {
        Fraction result = Fraction.ONE_HALF.pow(2);
        assertTrue(result.equals(Fraction.ONE_QUARTER));
    }

    @Test
    public void testPowOneReturnsSameInstance() {
        assertSame(Fraction.ONE_HALF, Fraction.ONE_HALF.pow(1));
    }

    @Test
    public void testPowZeroReturnsOneEvenForZeroFraction() {
        assertTrue(Fraction.ONE_HALF.pow(0).equals(Fraction.ONE));
        assertTrue(Fraction.ZERO.pow(0).equals(Fraction.ONE));
    }

    @Test
    public void testPowNegative() {
        Fraction result = Fraction.ONE_HALF.pow(-1);
        assertEquals(0, result.compareTo(Fraction.ONE_HALF.invert()));
    }

    @Test
    public void testPowOverflowThrows() {
        final Fraction big = Fraction.getFraction(Integer.MAX_VALUE, 1);
        assertThrows(ArithmeticException.class, new ThrowingCall() {
            public void execute() {
                big.pow(2);
            }
        });
    }

    // ---- reduce ----

    @Test
    public void testReduce() {
        Fraction reduced = Fraction.getFraction(2, 4).reduce();
        assertTrue(reduced.equals(Fraction.ONE_HALF));
    }

    @Test
    public void testReduceAlreadyReducedReturnsSameInstance() {
        Fraction f = Fraction.getFraction(3, 5);
        assertSame(f, f.reduce());
    }

    // ---- numeric conversions ----

    @Test
    public void testDoubleValue() {
        assertEquals(0.5d, Fraction.ONE_HALF.doubleValue(), 0.0000001d);
    }

    @Test
    public void testFloatValue() {
        assertEquals(0.5f, Fraction.ONE_HALF.floatValue(), 0.0000001f);
    }

    @Test
    public void testIntValue() {
        assertEquals(1, Fraction.getFraction(7, 4).intValue());
        assertEquals(-1, Fraction.getFraction(-7, 4).intValue());
    }

    @Test
    public void testLongValue() {
        assertEquals(1L, Fraction.getFraction(7, 4).longValue());
        assertEquals(-1L, Fraction.getFraction(-7, 4).longValue());
    }

    // ---- toString / toProperString ----

    @Test
    public void testToString() {
        assertEquals("3/7", Fraction.getFraction(3, 7).toString());
        assertEquals("-3/7", Fraction.getFraction(-3, 7).toString());
    }

    @Test
    public void testToProperStringOmitsZeroWhole() {
        assertEquals("3/7", Fraction.getFraction(3, 7).toProperString());
    }

    @Test
    public void testToProperStringOmitsZeroNumerator() {
        assertEquals("7", Fraction.getFraction(7, 1).toProperString());
    }

    @Test
    public void testToProperStringWithWholeAndFraction() {
        assertEquals("1 3/7", Fraction.getFraction(1, 3, 7).toProperString());
    }

    @Test
    public void testGetDenominatorAndNumeratorGetters() {
        assertNotNull(Fraction.ONE);
        assertEquals(1, Fraction.ONE.getNumerator());
        assertEquals(1, Fraction.ONE.getDenominator());
    }

    /**
     * Functional-interface-free executable used with assertThrows, kept
     * self-contained since lambdas are not available at --release 8 here.
     */
    private interface ThrowingCall extends org.junit.jupiter.api.function.Executable {
    }
}
