/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.SimpleTimeZone;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests for {@link ImmutableTimeZone}.
 */
class ImmutableTimeZoneAgentTest {

    private static ImmutableTimeZone wrap(final TimeZone timeZone) {
        return new ImmutableTimeZone(timeZone);
    }

    @Test
    void testClone() {
        final ImmutableTimeZone itz = wrap(new SimpleTimeZone(3600000, "Test/Clone"));
        assertSame(itz, itz.clone());
    }

    @Test
    void testConstructorRejectsNull() {
        final NullPointerException ex = assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                new ImmutableTimeZone(null);
            }
        });
        assertEquals("timeZone", ex.getMessage());
    }

    @Test
    void testEquals() {
        final SimpleTimeZone stz1 = new SimpleTimeZone(3600000, "Test/Equal");
        final SimpleTimeZone stz2 = new SimpleTimeZone(3600000, "Test/Equal");
        final SimpleTimeZone stz3 = new SimpleTimeZone(7200000, "Test/Different");
        final ImmutableTimeZone itz1 = wrap(stz1);
        final ImmutableTimeZone itz2 = wrap(stz2);
        final ImmutableTimeZone itz3 = wrap(stz3);

        // Reflexive.
        assertEquals(itz1, itz1);
        // Equal delegates, different ImmutableTimeZone instances.
        assertEquals(itz1, itz2);
        // Different delegates.
        assertNotEquals(itz1, itz3);
        // Compared against a plain TimeZone that is equal to the delegate.
        assertEquals(itz1, stz1);
        assertEquals(stz1, stz1);
        // Not a TimeZone at all.
        assertNotEquals(itz1, "not a time zone");
        // Null.
        assertNotEquals(null, itz1);
    }

    @Test
    void testGetDisplayName() {
        final SimpleTimeZone stz = new SimpleTimeZone(3600000, "Test/DisplayName");
        final ImmutableTimeZone itz = wrap(stz);
        assertEquals(stz.getDisplayName(false, TimeZone.SHORT, Locale.US), itz.getDisplayName(false, TimeZone.SHORT, Locale.US));
        assertEquals(stz.getDisplayName(true, TimeZone.LONG, Locale.US), itz.getDisplayName(true, TimeZone.LONG, Locale.US));
    }

    @Test
    void testGetDSTSavings() {
        final SimpleTimeZone stz = new SimpleTimeZone(3600000, "Test/DSTSavings");
        final ImmutableTimeZone itz = wrap(stz);
        assertEquals(stz.getDSTSavings(), itz.getDSTSavings());
    }

    @Test
    void testGetID() {
        final ImmutableTimeZone itz = wrap(new SimpleTimeZone(3600000, "Test/ID"));
        assertEquals("Test/ID", itz.getID());
    }

    @Test
    void testGetOffsetByComponents() {
        final SimpleTimeZone stz = new SimpleTimeZone(3600000, "Test/OffsetComponents");
        final ImmutableTimeZone itz = wrap(stz);
        final int expected = stz.getOffset(GregorianCalendar.AD, 2024, Calendar.JANUARY, 1, Calendar.MONDAY, 0);
        final int actual = itz.getOffset(GregorianCalendar.AD, 2024, Calendar.JANUARY, 1, Calendar.MONDAY, 0);
        assertEquals(3600000, expected);
        assertEquals(expected, actual);
    }

    @Test
    void testGetOffsetByDate() {
        final SimpleTimeZone stz = new SimpleTimeZone(3600000, "Test/OffsetDate");
        final ImmutableTimeZone itz = wrap(stz);
        final long now = System.currentTimeMillis();
        assertEquals(3600000, itz.getOffset(now));
        assertEquals(stz.getOffset(now), itz.getOffset(now));
    }

    @Test
    void testGetRawOffset() {
        final ImmutableTimeZone itz = wrap(new SimpleTimeZone(1800000, "Test/RawOffset"));
        assertEquals(1800000, itz.getRawOffset());
    }

    @Test
    void testHashCode() {
        final SimpleTimeZone stz1 = new SimpleTimeZone(3600000, "Test/HashCode");
        final SimpleTimeZone stz2 = new SimpleTimeZone(3600000, "Test/HashCode");
        assertEquals(wrap(stz1).hashCode(), wrap(stz2).hashCode());
        assertEquals(stz1.hashCode(), wrap(stz1).hashCode());
    }

    @Test
    void testHasSameRules() {
        final SimpleTimeZone stz1 = new SimpleTimeZone(3600000, "Test/SameRules1");
        final SimpleTimeZone stz2 = new SimpleTimeZone(3600000, "Test/SameRules2");
        final SimpleTimeZone stz3 = new SimpleTimeZone(7200000, "Test/DifferentRules");
        final ImmutableTimeZone itz1 = wrap(stz1);
        assertTrue(itz1.hasSameRules(stz2));
        assertFalse(itz1.hasSameRules(stz3));
    }

    @Test
    void testInDaylightTime() {
        final SimpleTimeZone stz = new SimpleTimeZone(3600000, "Test/InDaylight");
        final ImmutableTimeZone itz = wrap(stz);
        final Date date = new Date();
        assertFalse(itz.inDaylightTime(date));
        assertEquals(stz.inDaylightTime(date), itz.inDaylightTime(date));
    }

    @Test
    void testObservesDaylightTime() {
        final ImmutableTimeZone itz = wrap(new SimpleTimeZone(3600000, "Test/Observes"));
        assertFalse(itz.observesDaylightTime());
    }

    @Test
    void testSerialization() throws IOException, ClassNotFoundException {
        final ImmutableTimeZone itz = wrap(new SimpleTimeZone(3600000, "Test/Serialization"));
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        final ObjectOutputStream oos = new ObjectOutputStream(baos);
        oos.writeObject(itz);
        oos.close();

        final ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(baos.toByteArray()));
        final Object restored = ois.readObject();
        ois.close();

        assertTrue(restored instanceof ImmutableTimeZone);
        final ImmutableTimeZone restoredItz = (ImmutableTimeZone) restored;
        assertEquals("Test/Serialization", restoredItz.getID());
        assertEquals(3600000, restoredItz.getRawOffset());
        assertNotNull(restoredItz.unwrap());
    }

    @Test
    void testSetIDThrows() {
        final SimpleTimeZone stz = new SimpleTimeZone(3600000, "Test/SetID");
        final ImmutableTimeZone itz = wrap(stz);
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                itz.setID("Other/ID");
            }
        });
        // State must remain unchanged after the failed mutation.
        assertEquals("Test/SetID", itz.getID());
    }

    @Test
    void testSetRawOffsetThrows() {
        final SimpleTimeZone stz = new SimpleTimeZone(3600000, "Test/SetRawOffset");
        final ImmutableTimeZone itz = wrap(stz);
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                itz.setRawOffset(0);
            }
        });
        // State must remain unchanged after the failed mutation.
        assertEquals(3600000, itz.getRawOffset());
    }

    @Test
    void testToString() {
        final SimpleTimeZone stz = new SimpleTimeZone(3600000, "Test/ToString");
        final ImmutableTimeZone itz = wrap(stz);
        assertEquals(stz.toString(), itz.toString());
    }

    @Test
    void testToZoneId() {
        final TimeZone tz = TimeZone.getTimeZone("UTC");
        final ImmutableTimeZone itz = wrap(tz);
        final ZoneId zoneId = itz.toZoneId();
        assertNotNull(zoneId);
        assertEquals(tz.toZoneId(), zoneId);
    }

    @Test
    void testUnwrap() {
        final SimpleTimeZone stz = new SimpleTimeZone(3600000, "Test/Unwrap");
        final ImmutableTimeZone itz = wrap(stz);
        assertSame(stz, itz.unwrap());
    }

    @Test
    void testUseDaylightTime() {
        final ImmutableTimeZone itz = wrap(new SimpleTimeZone(3600000, "Test/UseDaylight"));
        assertFalse(itz.useDaylightTime());
    }
}
