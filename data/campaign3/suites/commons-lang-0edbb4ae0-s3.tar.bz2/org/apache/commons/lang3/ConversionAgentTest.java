package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

public class ConversionAgentTest {

    // ---------------------------------------------------------------
    // deprecated constructor
    // ---------------------------------------------------------------

    @Test
    @SuppressWarnings("deprecation")
    public void testConstructor() {
        assertNotNull(new Conversion());
    }

    // ---------------------------------------------------------------
    // binaryBeMsb0ToHexDigit(boolean[])
    // ---------------------------------------------------------------

    @Test
    public void testBinaryBeMsb0ToHexDigit() {
        assertEquals('8', Conversion.binaryBeMsb0ToHexDigit(new boolean[] {true, false, false, false}));
        assertEquals('4', Conversion.binaryBeMsb0ToHexDigit(new boolean[] {
            true, false, false, false, false, false, false, false,
            false, false, false, false, false, true, false, false}));
    }

    @Test
    public void testBinaryBeMsb0ToHexDigitEmpty() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.binaryBeMsb0ToHexDigit(new boolean[0]);
            }
        });
    }

    @Test
    public void testBinaryBeMsb0ToHexDigitNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.binaryBeMsb0ToHexDigit((boolean[]) null);
            }
        });
    }

    // ---------------------------------------------------------------
    // binaryBeMsb0ToHexDigit(boolean[], int)
    // ---------------------------------------------------------------

    @Test
    public void testBinaryBeMsb0ToHexDigitWithPos() {
        assertEquals('8', Conversion.binaryBeMsb0ToHexDigit(new boolean[] {true, false, false, false}, 0));
        assertEquals('5', Conversion.binaryBeMsb0ToHexDigit(new boolean[] {
            true, false, false, false, false, false, false, false,
            false, false, false, true, false, true, false, false}, 2));
    }

    @Test
    public void testBinaryBeMsb0ToHexDigitWithPosEmpty() {
        final boolean[] empty = new boolean[0];
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.binaryBeMsb0ToHexDigit(empty, 0);
            }
        });
    }

    @Test
    public void testBinaryBeMsb0ToHexDigitWithPosNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.binaryBeMsb0ToHexDigit((boolean[]) null, 0);
            }
        });
    }

    @Test
    public void testBinaryBeMsb0ToHexDigitWithPosOutOfBounds() {
        final boolean[] src = new boolean[] {true, false, false, false};
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.binaryBeMsb0ToHexDigit(src, 4);
            }
        });
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.binaryBeMsb0ToHexDigit(src, -1);
            }
        });
    }

    // ---------------------------------------------------------------
    // binaryToByte / binaryToInt / binaryToLong / binaryToShort
    // ---------------------------------------------------------------

    @Test
    public void testBinaryToByte() {
        final boolean[] src = {true, false, true, false};
        assertEquals((byte) 5, Conversion.binaryToByte(src, 0, (byte) 0, 0, 4));
        // preserve bits outside the written range coming from dstInit
        assertEquals((byte) 0xF5, Conversion.binaryToByte(src, 0, (byte) 0xF0, 0, 4));
    }

    @Test
    public void testBinaryToByteNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.binaryToByte(null, 0, (byte) 0, 0, 4);
            }
        });
    }

    @Test
    public void testBinaryToByteBoundary() {
        final boolean[] src = {true};
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.binaryToByte(src, 0, (byte) 0, 8, 1);
            }
        });
    }

    @Test
    public void testBinaryToByteArrayIndexOutOfBounds() {
        final boolean[] src = {true, false};
        assertThrows(ArrayIndexOutOfBoundsException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.binaryToByte(src, 1, (byte) 0, 0, 4);
            }
        });
    }

    @Test
    public void testBinaryToInt() {
        final boolean[] src = {true, false, true, false};
        assertEquals(5, Conversion.binaryToInt(src, 0, 0, 0, 4));
    }

    @Test
    public void testBinaryToIntNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.binaryToInt(null, 0, 0, 0, 4);
            }
        });
    }

    @Test
    public void testBinaryToIntBoundary() {
        final boolean[] src = {true};
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.binaryToInt(src, 0, 0, 32, 1);
            }
        });
    }

    @Test
    public void testBinaryToLong() {
        final boolean[] src = {true, false, true, false};
        assertEquals(5L, Conversion.binaryToLong(src, 0, 0L, 0, 4));
    }

    @Test
    public void testBinaryToLongNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.binaryToLong(null, 0, 0L, 0, 4);
            }
        });
    }

    @Test
    public void testBinaryToLongBoundary() {
        final boolean[] src = {true};
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.binaryToLong(src, 0, 0L, 64, 1);
            }
        });
    }

    @Test
    public void testBinaryToShort() {
        final boolean[] src = {true, false, true, false};
        assertEquals((short) 5, Conversion.binaryToShort(src, 0, (short) 0, 0, 4));
    }

    @Test
    public void testBinaryToShortNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.binaryToShort(null, 0, (short) 0, 0, 4);
            }
        });
    }

    @Test
    public void testBinaryToShortBoundary() {
        final boolean[] src = {true};
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.binaryToShort(src, 0, (short) 0, 16, 1);
            }
        });
    }

    // ---------------------------------------------------------------
    // binaryToHexDigit(boolean[]) / binaryToHexDigit(boolean[], int)
    // ---------------------------------------------------------------

    @Test
    public void testBinaryToHexDigit() {
        assertEquals('1', Conversion.binaryToHexDigit(new boolean[] {true, false, false, false}));
    }

    @Test
    public void testBinaryToHexDigitEmpty() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.binaryToHexDigit(new boolean[0]);
            }
        });
    }

    @Test
    public void testBinaryToHexDigitNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.binaryToHexDigit((boolean[]) null);
            }
        });
    }

    @Test
    public void testBinaryToHexDigitWithPos() {
        assertEquals('1', Conversion.binaryToHexDigit(new boolean[] {true, false, false, false}, 0));
    }

    @Test
    public void testBinaryToHexDigitWithPosEmpty() {
        final boolean[] empty = new boolean[0];
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.binaryToHexDigit(empty, 0);
            }
        });
    }

    @Test
    public void testBinaryToHexDigitWithPosNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.binaryToHexDigit((boolean[]) null, 0);
            }
        });
    }

    // ---------------------------------------------------------------
    // binaryToHexDigitMsb0_4bits(boolean[]) / with pos
    // ---------------------------------------------------------------

    @Test
    public void testBinaryToHexDigitMsb0_4bits() {
        assertEquals('8', Conversion.binaryToHexDigitMsb0_4bits(new boolean[] {true, false, false, false}));
    }

    @Test
    public void testBinaryToHexDigitMsb0_4bitsTooShort() {
        final boolean[] tooShort = {true, false, false};
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.binaryToHexDigitMsb0_4bits(tooShort);
            }
        });
    }

    @Test
    public void testBinaryToHexDigitMsb0_4bitsTooLong() {
        final boolean[] tooLong = new boolean[9];
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.binaryToHexDigitMsb0_4bits(tooLong);
            }
        });
    }

    @Test
    public void testBinaryToHexDigitMsb0_4bitsNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.binaryToHexDigitMsb0_4bits((boolean[]) null);
            }
        });
    }

    @Test
    public void testBinaryToHexDigitMsb0_4bitsWithPos() {
        assertEquals('D', Conversion.binaryToHexDigitMsb0_4bits(
            new boolean[] {true, false, false, true, true, false, true, false}, 3));
    }

    @Test
    public void testBinaryToHexDigitMsb0_4bitsWithPosNotEnoughBits() {
        final boolean[] src = {true, false, false, true, true};
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.binaryToHexDigitMsb0_4bits(src, 3);
            }
        });
    }

    @Test
    public void testBinaryToHexDigitMsb0_4bitsWithPosNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.binaryToHexDigitMsb0_4bits((boolean[]) null, 0);
            }
        });
    }

    // ---------------------------------------------------------------
    // byteArrayToInt / byteArrayToLong / byteArrayToShort
    // ---------------------------------------------------------------

    @Test
    public void testByteArrayToInt() {
        final byte[] src = {1, 2, 3, 4};
        assertEquals(0x04030201, Conversion.byteArrayToInt(src, 0, 0, 0, 4));
    }

    @Test
    public void testByteArrayToIntNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.byteArrayToInt(null, 0, 0, 0, 4);
            }
        });
    }

    @Test
    public void testByteArrayToIntBoundary() {
        final byte[] src = {1};
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.byteArrayToInt(src, 0, 0, 32, 1);
            }
        });
    }

    @Test
    public void testByteArrayToIntArrayIndexOutOfBounds() {
        final byte[] src = {1, 2};
        assertThrows(ArrayIndexOutOfBoundsException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.byteArrayToInt(src, 0, 0, 0, 4);
            }
        });
    }

    @Test
    public void testByteArrayToLong() {
        final byte[] src = {1, 2, 3, 4, 5, 6, 7, 8};
        assertEquals(0x0807060504030201L, Conversion.byteArrayToLong(src, 0, 0L, 0, 8));
    }

    @Test
    public void testByteArrayToLongNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.byteArrayToLong(null, 0, 0L, 0, 8);
            }
        });
    }

    @Test
    public void testByteArrayToLongBoundary() {
        final byte[] src = {1};
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.byteArrayToLong(src, 0, 0L, 64, 1);
            }
        });
    }

    @Test
    public void testByteArrayToShort() {
        final byte[] src = {1, 2};
        assertEquals((short) 0x0201, Conversion.byteArrayToShort(src, 0, (short) 0, 0, 2));
    }

    @Test
    public void testByteArrayToShortNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.byteArrayToShort(null, 0, (short) 0, 0, 2);
            }
        });
    }

    @Test
    public void testByteArrayToShortBoundary() {
        final byte[] src = {1};
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.byteArrayToShort(src, 0, (short) 0, 16, 1);
            }
        });
    }

    // ---------------------------------------------------------------
    // byteArrayToUuid / uuidToByteArray
    // ---------------------------------------------------------------

    @Test
    public void testUuidRoundTrip() {
        final UUID original = UUID.fromString("01020304-0506-0708-090a-0b0c0d0e0f10");
        final byte[] dst = new byte[16];
        final byte[] result = Conversion.uuidToByteArray(original, dst, 0, 16);
        assertSame(dst, result);
        final UUID roundTripped = Conversion.byteArrayToUuid(dst, 0);
        assertEquals(original, roundTripped);
    }

    @Test
    public void testUuidRoundTripWithOffset() {
        final UUID original = UUID.fromString("11223344-5566-7788-99aa-bbccddeeff00");
        final byte[] dst = new byte[20];
        final byte[] result = Conversion.uuidToByteArray(original, dst, 3, 16);
        assertSame(dst, result);
        final UUID roundTripped = Conversion.byteArrayToUuid(dst, 3);
        assertEquals(original, roundTripped);
    }

    @Test
    public void testUuidToByteArrayNull() {
        final UUID uuid = UUID.randomUUID();
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.uuidToByteArray(uuid, null, 0, 16);
            }
        });
    }

    @Test
    public void testUuidToByteArrayTooManyBytes() {
        final UUID uuid = UUID.randomUUID();
        final byte[] dst = new byte[20];
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.uuidToByteArray(uuid, dst, 0, 17);
            }
        });
    }

    @Test
    public void testUuidToByteArrayIndexOutOfBounds() {
        final UUID uuid = UUID.randomUUID();
        final byte[] dst = new byte[16];
        assertThrows(ArrayIndexOutOfBoundsException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.uuidToByteArray(uuid, dst, 1, 16);
            }
        });
    }

    @Test
    public void testByteArrayToUuidNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.byteArrayToUuid(null, 0);
            }
        });
    }

    @Test
    public void testByteArrayToUuidTooShort() {
        final byte[] src = new byte[10];
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.byteArrayToUuid(src, 0);
            }
        });
    }

    // ---------------------------------------------------------------
    // byteToBinary
    // ---------------------------------------------------------------

    @Test
    public void testByteToBinary() {
        final boolean[] dst = new boolean[4];
        final boolean[] result = Conversion.byteToBinary((byte) 5, 0, dst, 0, 4);
        assertSame(dst, result);
        assertArrayEquals(new boolean[] {true, false, true, false}, dst);
    }

    @Test
    public void testByteToBinaryNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.byteToBinary((byte) 5, 0, null, 0, 4);
            }
        });
    }

    @Test
    public void testByteToBinaryBoundary() {
        final boolean[] dst = new boolean[1];
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.byteToBinary((byte) 1, 8, dst, 0, 1);
            }
        });
    }

    @Test
    public void testByteToBinaryArrayIndexOutOfBounds() {
        final boolean[] dst = new boolean[2];
        assertThrows(ArrayIndexOutOfBoundsException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.byteToBinary((byte) 1, 0, dst, 1, 4);
            }
        });
    }

    // ---------------------------------------------------------------
    // byteToHex / hexToByte
    // ---------------------------------------------------------------

    @Test
    public void testByteToHex() {
        assertEquals("12", Conversion.byteToHex((byte) 0x21, 0, "00", 0, 2));
    }

    @Test
    public void testByteToHexBoundary() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.byteToHex((byte) 1, 8, "0", 0, 1);
            }
        });
    }

    @Test
    public void testHexToByte() {
        assertEquals((byte) 0x21, Conversion.hexToByte("12", 0, (byte) 0, 0, 2));
    }

    @Test
    public void testHexToByteBoundary() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.hexToByte("1", 0, (byte) 0, 8, 1);
            }
        });
    }

    // ---------------------------------------------------------------
    // hexDigitToInt / hexDigitToBinary / hexDigitMsb0ToInt / hexDigitMsb0ToBinary
    // ---------------------------------------------------------------

    @Test
    public void testHexDigitToInt() {
        assertEquals(1, Conversion.hexDigitToInt('1'));
        assertEquals(0, Conversion.hexDigitToInt('0'));
        assertEquals(9, Conversion.hexDigitToInt('9'));
    }

    @Test
    public void testHexDigitToIntInvalid() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.hexDigitToInt('g');
            }
        });
    }

    @Test
    public void testHexDigitToBinary() {
        assertArrayEquals(new boolean[] {true, false, false, false}, Conversion.hexDigitToBinary('1'));
    }

    @Test
    public void testHexDigitToBinaryInvalid() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.hexDigitToBinary('g');
            }
        });
    }

    @Test
    public void testHexDigitMsb0ToInt() {
        assertEquals(8, Conversion.hexDigitMsb0ToInt('1'));
    }

    @Test
    public void testHexDigitMsb0ToIntInvalid() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.hexDigitMsb0ToInt('g');
            }
        });
    }

    @Test
    public void testHexDigitMsb0ToBinary() {
        assertArrayEquals(new boolean[] {false, false, false, true}, Conversion.hexDigitMsb0ToBinary('1'));
    }

    @Test
    public void testHexDigitMsb0ToBinaryInvalid() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.hexDigitMsb0ToBinary('g');
            }
        });
    }

    // ---------------------------------------------------------------
    // hexToInt / hexToLong / hexToShort and their inverses
    // ---------------------------------------------------------------

    @Test
    public void testHexToIntAndIntToHex() {
        assertEquals(0x4321, Conversion.hexToInt("1234", 0, 0, 0, 4));
        assertEquals("1234", Conversion.intToHex(0x4321, 0, "0000", 0, 4));
    }

    @Test
    public void testHexToIntBoundary() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.hexToInt("1", 0, 0, 32, 1);
            }
        });
    }

    @Test
    public void testIntToHexBoundary() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.intToHex(1, 32, "0", 0, 1);
            }
        });
    }

    @Test
    public void testHexToLongAndLongToHex() {
        assertEquals(0x87654321L, Conversion.hexToLong("12345678", 0, 0L, 0, 8));
        assertEquals("12345678", Conversion.longToHex(0x87654321L, 0, "00000000", 0, 8));
    }

    @Test
    public void testHexToLongBoundary() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.hexToLong("1", 0, 0L, 64, 1);
            }
        });
    }

    @Test
    public void testLongToHexBoundary() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.longToHex(1L, 64, "0", 0, 1);
            }
        });
    }

    @Test
    public void testHexToShortAndShortToHex() {
        final short expected = 0x4321;
        assertEquals(expected, Conversion.hexToShort("1234", 0, (short) 0, 0, 4));
        assertEquals("1234", Conversion.shortToHex(expected, 0, "0000", 0, 4));
    }

    @Test
    public void testHexToShortBoundary() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.hexToShort("1", 0, (short) 0, 16, 1);
            }
        });
    }

    @Test
    public void testShortToHexBoundary() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.shortToHex((short) 1, 16, "0", 0, 1);
            }
        });
    }

    // ---------------------------------------------------------------
    // intArrayToLong
    // ---------------------------------------------------------------

    @Test
    public void testIntArrayToLong() {
        final int[] src = {1, 2};
        assertEquals(0x0000000200000001L, Conversion.intArrayToLong(src, 0, 0L, 0, 2));
    }

    @Test
    public void testIntArrayToLongNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.intArrayToLong(null, 0, 0L, 0, 2);
            }
        });
    }

    @Test
    public void testIntArrayToLongBoundary() {
        final int[] src = {1};
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.intArrayToLong(src, 0, 0L, 64, 1);
            }
        });
    }

    @Test
    public void testIntArrayToLongArrayIndexOutOfBounds() {
        final int[] src = {1};
        assertThrows(ArrayIndexOutOfBoundsException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.intArrayToLong(src, 0, 0L, 0, 2);
            }
        });
    }

    // ---------------------------------------------------------------
    // intToBinary / intToByteArray / intToShortArray
    // ---------------------------------------------------------------

    @Test
    public void testIntToBinary() {
        final boolean[] dst = new boolean[4];
        final boolean[] result = Conversion.intToBinary(5, 0, dst, 0, 4);
        assertSame(dst, result);
        assertArrayEquals(new boolean[] {true, false, true, false}, dst);
    }

    @Test
    public void testIntToBinaryNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.intToBinary(5, 0, null, 0, 4);
            }
        });
    }

    @Test
    public void testIntToBinaryBoundary() {
        final boolean[] dst = new boolean[1];
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.intToBinary(1, 32, dst, 0, 1);
            }
        });
    }

    @Test
    public void testIntToByteArray() {
        final byte[] dst = new byte[4];
        final byte[] result = Conversion.intToByteArray(0x04030201, 0, dst, 0, 4);
        assertSame(dst, result);
        assertArrayEquals(new byte[] {1, 2, 3, 4}, dst);
    }

    @Test
    public void testIntToByteArrayNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.intToByteArray(1, 0, null, 0, 1);
            }
        });
    }

    @Test
    public void testIntToByteArrayBoundary() {
        final byte[] dst = new byte[1];
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.intToByteArray(1, 32, dst, 0, 1);
            }
        });
    }

    @Test
    public void testIntToShortArray() {
        final short[] dst = new short[2];
        final short[] result = Conversion.intToShortArray(0x00020001, 0, dst, 0, 2);
        assertSame(dst, result);
        assertArrayEquals(new short[] {1, 2}, dst);
    }

    @Test
    public void testIntToShortArrayNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.intToShortArray(1, 0, null, 0, 1);
            }
        });
    }

    @Test
    public void testIntToShortArrayBoundary() {
        final short[] dst = new short[1];
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.intToShortArray(1, 32, dst, 0, 1);
            }
        });
    }

    // ---------------------------------------------------------------
    // intToHexDigit / intToHexDigitMsb0
    // ---------------------------------------------------------------

    @Test
    public void testIntToHexDigit() {
        assertEquals('0', Conversion.intToHexDigit(0));
        assertEquals('1', Conversion.intToHexDigit(1));
        assertEquals('9', Conversion.intToHexDigit(9));
        assertEquals('A', Conversion.intToHexDigit(10));
    }

    @Test
    public void testIntToHexDigitInvalid() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.intToHexDigit(-1);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.intToHexDigit(16);
            }
        });
    }

    @Test
    public void testIntToHexDigitMsb0() {
        assertEquals('0', Conversion.intToHexDigitMsb0(0));
        assertEquals('8', Conversion.intToHexDigitMsb0(1));
        assertEquals('5', Conversion.intToHexDigitMsb0(10));
    }

    @Test
    public void testIntToHexDigitMsb0Invalid() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.intToHexDigitMsb0(-1);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.intToHexDigitMsb0(16);
            }
        });
    }

    // ---------------------------------------------------------------
    // longToBinary / longToByteArray / longToIntArray / longToShortArray
    // ---------------------------------------------------------------

    @Test
    public void testLongToBinary() {
        final boolean[] dst = new boolean[4];
        final boolean[] result = Conversion.longToBinary(5L, 0, dst, 0, 4);
        assertSame(dst, result);
        assertArrayEquals(new boolean[] {true, false, true, false}, dst);
    }

    @Test
    public void testLongToBinaryNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.longToBinary(5L, 0, null, 0, 4);
            }
        });
    }

    @Test
    public void testLongToBinaryBoundary() {
        final boolean[] dst = new boolean[1];
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.longToBinary(1L, 64, dst, 0, 1);
            }
        });
    }

    @Test
    public void testLongToByteArray() {
        final byte[] dst = new byte[8];
        final byte[] result = Conversion.longToByteArray(0x0807060504030201L, 0, dst, 0, 8);
        assertSame(dst, result);
        assertArrayEquals(new byte[] {1, 2, 3, 4, 5, 6, 7, 8}, dst);
    }

    @Test
    public void testLongToByteArrayNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.longToByteArray(1L, 0, null, 0, 1);
            }
        });
    }

    @Test
    public void testLongToByteArrayBoundary() {
        final byte[] dst = new byte[1];
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.longToByteArray(1L, 64, dst, 0, 1);
            }
        });
    }

    @Test
    public void testLongToIntArray() {
        final int[] dst = new int[2];
        final int[] result = Conversion.longToIntArray(0x0000000200000001L, 0, dst, 0, 2);
        assertSame(dst, result);
        assertArrayEquals(new int[] {1, 2}, dst);
    }

    @Test
    public void testLongToIntArrayBoundary() {
        final int[] dst = new int[1];
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.longToIntArray(1L, 64, dst, 0, 1);
            }
        });
    }

    @Test
    public void testLongToShortArray() {
        final short[] dst = new short[4];
        final short[] result = Conversion.longToShortArray(0x0004000300020001L, 0, dst, 0, 4);
        assertSame(dst, result);
        assertArrayEquals(new short[] {1, 2, 3, 4}, dst);
    }

    @Test
    public void testLongToShortArrayNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.longToShortArray(1L, 0, null, 0, 1);
            }
        });
    }

    @Test
    public void testLongToShortArrayBoundary() {
        final short[] dst = new short[1];
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.longToShortArray(1L, 64, dst, 0, 1);
            }
        });
    }

    // ---------------------------------------------------------------
    // shortArrayToInt / shortArrayToLong
    // ---------------------------------------------------------------

    @Test
    public void testShortArrayToInt() {
        final short[] src = {1, 2};
        assertEquals(0x00020001, Conversion.shortArrayToInt(src, 0, 0, 0, 2));
    }

    @Test
    public void testShortArrayToIntNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.shortArrayToInt(null, 0, 0, 0, 1);
            }
        });
    }

    @Test
    public void testShortArrayToIntBoundary() {
        final short[] src = {1};
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.shortArrayToInt(src, 0, 0, 32, 1);
            }
        });
    }

    @Test
    public void testShortArrayToIntArrayIndexOutOfBounds() {
        final short[] src = {1};
        assertThrows(ArrayIndexOutOfBoundsException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.shortArrayToInt(src, 0, 0, 0, 2);
            }
        });
    }

    @Test
    public void testShortArrayToLong() {
        final short[] src = {1, 2, 3, 4};
        assertEquals(0x0004000300020001L, Conversion.shortArrayToLong(src, 0, 0L, 0, 4));
    }

    @Test
    public void testShortArrayToLongNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.shortArrayToLong(null, 0, 0L, 0, 1);
            }
        });
    }

    @Test
    public void testShortArrayToLongBoundary() {
        final short[] src = {1};
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.shortArrayToLong(src, 0, 0L, 64, 1);
            }
        });
    }

    // ---------------------------------------------------------------
    // shortToBinary / shortToByteArray
    // ---------------------------------------------------------------

    @Test
    public void testShortToBinary() {
        final boolean[] dst = new boolean[4];
        final boolean[] result = Conversion.shortToBinary((short) 5, 0, dst, 0, 4);
        assertSame(dst, result);
        assertArrayEquals(new boolean[] {true, false, true, false}, dst);
    }

    @Test
    public void testShortToBinaryNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.shortToBinary((short) 5, 0, null, 0, 4);
            }
        });
    }

    @Test
    public void testShortToBinaryBoundary() {
        final boolean[] dst = new boolean[1];
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.shortToBinary((short) 1, 16, dst, 0, 1);
            }
        });
    }

    @Test
    public void testShortToByteArray() {
        final byte[] dst = new byte[2];
        final byte[] result = Conversion.shortToByteArray((short) 0x0201, 0, dst, 0, 2);
        assertSame(dst, result);
        assertArrayEquals(new byte[] {1, 2}, dst);
    }

    @Test
    public void testShortToByteArrayNull() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.shortToByteArray((short) 1, 0, null, 0, 1);
            }
        });
    }

    @Test
    public void testShortToByteArrayBoundary() {
        final byte[] dst = new byte[1];
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() throws Throwable {
                Conversion.shortToByteArray((short) 1, 16, dst, 0, 1);
            }
        });
    }
}
