/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Instant;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link Instants}.
 */
class InstantsAgentTest {

    @Test
    void testToEpochMillisNull() {
        assertEquals(Instant.EPOCH.toEpochMilli(), Instants.toEpochMillis(null));
        assertEquals(0, Instants.toEpochMillis(null));
    }

    @Test
    void testToEpochMillisEpoch() {
        assertEquals(0, Instants.toEpochMillis(Instant.EPOCH));
    }

    @Test
    void testToEpochMillisOrdinary() {
        final Instant instant = Instant.ofEpochMilli(123456789L);
        assertEquals(123456789L, Instants.toEpochMillis(instant));
    }

    @Test
    void testToEpochMillisNegativeOrdinary() {
        final Instant instant = Instant.ofEpochMilli(-123456789L);
        assertEquals(-123456789L, Instants.toEpochMillis(instant));
    }

    @Test
    void testToEpochMillisMaxOverflowsToLongMax() {
        // Instant.MAX overflows long multiplication by 1000, epoch second >= 0.
        assertEquals(Long.MAX_VALUE, Instants.toEpochMillis(Instant.MAX));
    }

    @Test
    void testToEpochMillisMinOverflowsToLongMin() {
        // Instant.MIN overflows long multiplication by 1000, epoch second < 0.
        assertEquals(Long.MIN_VALUE, Instants.toEpochMillis(Instant.MIN));
    }

    @Test
    void testToInstantNull() {
        assertSame(Instant.EPOCH, Instants.toInstant(null));
    }

    @Test
    void testToInstantNonNull() {
        final Instant instant = Instant.ofEpochSecond(42);
        assertSame(instant, Instants.toInstant(instant));
    }

    @Test
    void testToInstantWithDefaultNullInstant() {
        final Instant defaultInstant = Instant.ofEpochSecond(99);
        assertSame(defaultInstant, Instants.toInstant(null, defaultInstant));
    }

    @Test
    void testToInstantWithDefaultNonNullInstant() {
        final Instant instant = Instant.ofEpochSecond(1);
        final Instant defaultInstant = Instant.ofEpochSecond(99);
        assertSame(instant, Instants.toInstant(instant, defaultInstant));
    }

    @Test
    void testToInstantWithDefaultBothNull() {
        assertEquals(null, Instants.toInstant(null, null));
    }

    @Test
    void testToMillisSinceNullTreatedAsEpoch() {
        final long millis = Instants.toMillisSince(null);
        final long now = System.currentTimeMillis();
        // Millis since the epoch should be close to the current wall clock time in millis.
        assertTrue(millis > 0);
        assertTrue(Math.abs(now - millis) < 60000L, "millis=" + millis + " now=" + now);
    }

    @Test
    void testToMillisSinceEpoch() {
        final long millis = Instants.toMillisSince(Instant.EPOCH);
        assertTrue(millis > 0);
        assertTrue(millis < Long.MAX_VALUE);
    }

    @Test
    void testToMillisSinceInstantMinOverflowsToLongMax() {
        // now - Instant.MIN is an enormous positive duration: not negative, so it binds to Long.MAX_VALUE.
        assertEquals(Long.MAX_VALUE, Instants.toMillisSince(Instant.MIN));
    }

    @Test
    void testToMillisSinceInstantMaxOverflowsToLongMin() {
        // now - Instant.MAX is an enormous negative duration: it binds to Long.MIN_VALUE.
        assertEquals(Long.MIN_VALUE, Instants.toMillisSince(Instant.MAX));
    }

    @Test
    void testToMillisSinceFutureInstantIsNegative() {
        final Instant future = Instant.now().plusSeconds(3600);
        final long millis = Instants.toMillisSince(future);
        assertTrue(millis < 0);
    }
}
