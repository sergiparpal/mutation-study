package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.text.FieldPosition;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link FastDatePrinter}, based solely on the
 * documented contract in the generated javadoc.
 */
public class FastDatePrinterAgentTest {

    private static final TimeZone UTC = TimeZone.getTimeZone("UTC");
    private static final Locale US = Locale.US;

    private static long utcMillis(int year, int month, int day, int hour, int minute, int second, int millis) {
        Calendar cal = Calendar.getInstance(UTC, US);
        cal.clear();
        cal.set(year, month - 1, day, hour, minute, second);
        cal.set(Calendar.MILLISECOND, millis);
        return cal.getTimeInMillis();
    }

    private static long utcMillis(int year, int month, int day, int hour, int minute, int second) {
        return utcMillis(year, month, day, hour, minute, second, 0);
    }

    // ------------------------------------------------------------------
    // Constructor
    // ------------------------------------------------------------------

    @Test
    public void testConstructorRejectsNullPattern() {
        try {
            new FastDatePrinter(null, UTC, US);
            fail("Expected NullPointerException for null pattern");
        } catch (NullPointerException expected) {
            // documented
        }
    }

    @Test
    public void testConstructorRejectsNullTimeZone() {
        try {
            new FastDatePrinter("yyyy", null, US);
            fail("Expected NullPointerException for null timeZone");
        } catch (NullPointerException expected) {
            // documented
        }
    }

    @Test
    public void testConstructorRejectsNullLocale() {
        try {
            new FastDatePrinter("yyyy", UTC, null);
            fail("Expected NullPointerException for null locale");
        } catch (NullPointerException expected) {
            // documented
        }
    }

    // ------------------------------------------------------------------
    // getPattern / getTimeZone / getLocale
    // ------------------------------------------------------------------

    @Test
    public void testGettersReturnConstructorArguments() {
        FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", UTC, US);
        assertEquals("yyyy-MM-dd", printer.getPattern());
        assertEquals(UTC, printer.getTimeZone());
        assertEquals(US, printer.getLocale());
    }

    // ------------------------------------------------------------------
    // format(long) / format(Date) / format(Calendar)
    // ------------------------------------------------------------------

    @Test
    public void testFormatLongBasicDatePattern() {
        FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", UTC, US);
        long millis = utcMillis(2023, 3, 15, 10, 30, 45);
        assertEquals("2023-03-15", printer.format(millis));
    }

    @Test
    public void testFormatDateUsesGregorianCalendarFields() {
        FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", UTC, US);
        long millis = utcMillis(2023, 3, 15, 10, 30, 45);
        assertEquals("2023-03-15", printer.format(new Date(millis)));
    }

    @Test
    public void testFormatCalendarSameTimeZoneAsPrinter() {
        FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd HH:mm:ss", UTC, US);
        Calendar cal = Calendar.getInstance(UTC, US);
        cal.setTimeInMillis(utcMillis(2023, 3, 15, 10, 30, 45));
        assertEquals("2023-03-15 10:30:45", printer.format(cal));
    }

    @Test
    public void testFormatCalendarUsesPrinterTimeZoneNotCalendarTimeZone() {
        TimeZone ny = TimeZone.getTimeZone("America/New_York");
        FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd HH:mm:ss", ny, US);
        Calendar cal = Calendar.getInstance(UTC, US);
        cal.setTimeInMillis(utcMillis(2023, 7, 1, 12, 0, 0));
        // 2023-07-01T12:00:00Z is 08:00:00 in America/New_York (EDT, UTC-4).
        assertEquals("2023-07-01 08:00:00", printer.format(cal));
    }

    @Test
    public void testFormatSingleLetterPatternHasNoLeadingZeroPadding() {
        FastDatePrinter printer = new FastDatePrinter("H:m:s", UTC, US);
        long millis = utcMillis(2023, 3, 15, 5, 3, 9);
        assertEquals("5:3:9", printer.format(millis));
    }

    @Test
    public void testFormatDoubleLetterPatternPadsToTwoDigits() {
        FastDatePrinter printer = new FastDatePrinter("HH:mm:ss", UTC, US);
        long millis = utcMillis(2023, 3, 15, 5, 3, 9);
        assertEquals("05:03:09", printer.format(millis));
    }

    @Test
    public void testFormatMillisecondPatternPadsToThreeDigits() {
        FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd HH:mm:ss.SSS", UTC, US);
        long millis = utcMillis(2023, 1, 1, 0, 0, 0, 7);
        assertEquals("2023-01-01 00:00:00.007", printer.format(millis));
    }

    @Test
    public void testFormatLiteralQuotedText() {
        FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd'T'HH:mm:ss'Z'", UTC, US);
        long millis = utcMillis(2023, 3, 15, 10, 30, 45);
        assertEquals("2023-03-15T10:30:45Z", printer.format(millis));
    }

    @Test
    public void testFormatAbbreviatedAndFullWeekdayNames() {
        // 2023-03-15 is a Wednesday.
        long millis = utcMillis(2023, 3, 15, 0, 0, 0);
        FastDatePrinter shortPrinter = new FastDatePrinter("EEE", UTC, US);
        FastDatePrinter longPrinter = new FastDatePrinter("EEEE", UTC, US);
        assertEquals("Wed", shortPrinter.format(millis));
        assertEquals("Wednesday", longPrinter.format(millis));
    }

    @Test
    public void testFormatAbbreviatedAndFullMonthNames() {
        long millis = utcMillis(2023, 3, 15, 0, 0, 0);
        FastDatePrinter shortPrinter = new FastDatePrinter("MMM", UTC, US);
        FastDatePrinter longPrinter = new FastDatePrinter("MMMM", UTC, US);
        assertEquals("Mar", shortPrinter.format(millis));
        assertEquals("March", longPrinter.format(millis));
    }

    @Test
    public void testFormatRfc822TimeZoneAtZeroOffset() {
        FastDatePrinter printer = new FastDatePrinter("Z", UTC, US);
        long millis = utcMillis(2023, 3, 15, 10, 30, 45);
        assertEquals("+0000", printer.format(millis));
    }

    @Test
    public void testFormatIso8601ExtendedTimeZoneAtZeroOffset() {
        FastDatePrinter printer = new FastDatePrinter("ZZ", UTC, US);
        long millis = utcMillis(2023, 3, 15, 10, 30, 45);
        assertEquals("+00:00", printer.format(millis));
    }

    @Test
    public void testFormatRfc822AndIso8601TimeZoneAtNegativeOffset() {
        TimeZone ny = TimeZone.getTimeZone("America/New_York");
        FastDatePrinter rfc822 = new FastDatePrinter("Z", ny, US);
        FastDatePrinter iso8601 = new FastDatePrinter("ZZ", ny, US);
        long millis = utcMillis(2023, 7, 1, 12, 0, 0);
        assertEquals("-0400", rfc822.format(millis));
        assertEquals("-04:00", iso8601.format(millis));
    }

    // ------------------------------------------------------------------
    // format(..., StringBuffer) / format(..., Appendable)
    // ------------------------------------------------------------------

    @Test
    public void testFormatLongIntoStringBufferAppendsAndReturnsSameBuffer() {
        FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", UTC, US);
        long millis = utcMillis(2023, 3, 15, 10, 30, 45);
        StringBuffer buf = new StringBuffer("prefix-");
        StringBuffer result = printer.format(millis, buf);
        assertSame(buf, result);
        assertEquals("prefix-2023-03-15", buf.toString());
    }

    @Test
    public void testFormatDateIntoStringBufferAppendsAndReturnsSameBuffer() {
        FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", UTC, US);
        long millis = utcMillis(2023, 3, 15, 10, 30, 45);
        StringBuffer buf = new StringBuffer("prefix-");
        StringBuffer result = printer.format(new Date(millis), buf);
        assertSame(buf, result);
        assertEquals("prefix-2023-03-15", buf.toString());
    }

    @Test
    public void testFormatCalendarIntoStringBufferAppendsAndReturnsSameBuffer() {
        FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", UTC, US);
        Calendar cal = Calendar.getInstance(UTC, US);
        cal.setTimeInMillis(utcMillis(2023, 3, 15, 10, 30, 45));
        StringBuffer buf = new StringBuffer("prefix-");
        StringBuffer result = printer.format(cal, buf);
        assertSame(buf, result);
        assertEquals("prefix-2023-03-15", buf.toString());
    }

    @Test
    public void testFormatLongIntoAppendableReturnsSameInstance() {
        FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", UTC, US);
        long millis = utcMillis(2023, 3, 15, 10, 30, 45);
        StringBuilder buf = new StringBuilder("prefix-");
        StringBuilder result = printer.format(millis, buf);
        assertSame(buf, result);
        assertEquals("prefix-2023-03-15", buf.toString());
    }

    @Test
    public void testFormatDateIntoAppendableReturnsSameInstance() {
        FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", UTC, US);
        long millis = utcMillis(2023, 3, 15, 10, 30, 45);
        StringBuilder buf = new StringBuilder("prefix-");
        StringBuilder result = printer.format(new Date(millis), buf);
        assertSame(buf, result);
        assertEquals("prefix-2023-03-15", buf.toString());
    }

    @Test
    public void testFormatCalendarIntoAppendableReturnsSameInstance() {
        FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", UTC, US);
        Calendar cal = Calendar.getInstance(UTC, US);
        cal.setTimeInMillis(utcMillis(2023, 3, 15, 10, 30, 45));
        StringBuilder buf = new StringBuilder("prefix-");
        StringBuilder result = printer.format(cal, buf);
        assertSame(buf, result);
        assertEquals("prefix-2023-03-15", buf.toString());
    }

    // ------------------------------------------------------------------
    // format(Object) - package-private, documented to accept Date, Calendar or Long
    // ------------------------------------------------------------------

    @Test
    public void testFormatObjectAcceptsDateCalendarAndLongConsistently() {
        FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd HH:mm:ss", UTC, US);
        long millis = utcMillis(2023, 3, 15, 10, 30, 45);
        Date date = new Date(millis);
        Calendar cal = Calendar.getInstance(UTC, US);
        cal.setTimeInMillis(millis);
        Long boxedMillis = Long.valueOf(millis);

        String expected = "2023-03-15 10:30:45";
        assertEquals(expected, printer.format((Object) date));
        assertEquals(expected, printer.format((Object) cal));
        assertEquals(expected, printer.format((Object) boxedMillis));
    }

    // ------------------------------------------------------------------
    // Deprecated format(Object, StringBuffer, FieldPosition)
    // ------------------------------------------------------------------

    @Test
    public void testDeprecatedFormatObjectReturnsSuppliedBuffer() {
        FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", UTC, US);
        long millis = utcMillis(2023, 3, 15, 10, 30, 45);
        Date date = new Date(millis);
        StringBuffer buf = new StringBuffer("prefix-");
        StringBuffer result = printer.format((Object) date, buf, new FieldPosition(0));
        assertSame(buf, result);
        assertEquals("prefix-2023-03-15", buf.toString());
    }

    // ------------------------------------------------------------------
    // Deprecated applyRules(Calendar, StringBuffer)
    // ------------------------------------------------------------------

    @Test
    public void testApplyRulesFormatsIntoAndReturnsSuppliedBuffer() {
        FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", UTC, US);
        Calendar cal = Calendar.getInstance(UTC, US);
        cal.setTimeInMillis(utcMillis(2023, 3, 15, 10, 30, 45));
        StringBuffer buf = new StringBuffer("prefix-");
        StringBuffer result = printer.applyRules(cal, buf);
        assertSame(buf, result);
        assertEquals("prefix-2023-03-15", buf.toString());
    }

    // ------------------------------------------------------------------
    // getMaxLengthEstimate
    // ------------------------------------------------------------------

    @Test
    public void testGetMaxLengthEstimateIsPositiveAndDeterministic() {
        FastDatePrinter printer = new FastDatePrinter("EEEE, dd MMMM yyyy HH:mm:ss.SSS Z", UTC, US);
        int estimate1 = printer.getMaxLengthEstimate();
        int estimate2 = printer.getMaxLengthEstimate();
        assertTrue(estimate1 > 0);
        assertEquals(estimate1, estimate2);
    }

    @Test
    public void testGetMaxLengthEstimateBoundsActualFormattedLength() {
        FastDatePrinter printer = new FastDatePrinter("EEEE, dd MMMM yyyy HH:mm:ss.SSS Z", UTC, US);
        int estimate = printer.getMaxLengthEstimate();

        long[] samples = {
            utcMillis(2023, 3, 15, 10, 30, 45, 7),
            utcMillis(9999, 12, 31, 23, 59, 59, 999),
            utcMillis(1970, 1, 1, 0, 0, 0, 0),
            utcMillis(2000, 2, 29, 0, 0, 0, 100),
        };
        for (int i = 0; i < samples.length; i++) {
            String formatted = printer.format(samples[i]);
            assertTrue(formatted.length() <= estimate,
                "formatted length " + formatted.length() + " exceeded estimate " + estimate
                    + " for value: " + formatted);
        }
    }

    // ------------------------------------------------------------------
    // equals / hashCode
    // ------------------------------------------------------------------

    @Test
    public void testEqualsIsReflexive() {
        FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", UTC, US);
        assertTrue(printer.equals(printer));
    }

    @Test
    public void testEqualsNullAndForeignTypeReturnFalse() {
        FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", UTC, US);
        assertFalse(printer.equals(null));
        assertFalse(printer.equals("yyyy-MM-dd"));
    }

    @Test
    public void testEqualsAndHashCodeForEquivalentConstructorArguments() {
        FastDatePrinter printer1 = new FastDatePrinter("yyyy-MM-dd", UTC, US);
        FastDatePrinter printer2 = new FastDatePrinter("yyyy-MM-dd", UTC, US);
        assertNotSame(printer1, printer2);
        assertTrue(printer1.equals(printer2));
        assertTrue(printer2.equals(printer1));
        assertEquals(printer1.hashCode(), printer2.hashCode());
    }

    @Test
    public void testEqualsReturnsFalseForDifferentPattern() {
        FastDatePrinter printer1 = new FastDatePrinter("yyyy-MM-dd", UTC, US);
        FastDatePrinter printer2 = new FastDatePrinter("yyyy/MM/dd", UTC, US);
        assertFalse(printer1.equals(printer2));
    }

    @Test
    public void testEqualsReturnsFalseForDifferentTimeZone() {
        FastDatePrinter printer1 = new FastDatePrinter("yyyy-MM-dd", UTC, US);
        FastDatePrinter printer2 = new FastDatePrinter("yyyy-MM-dd", TimeZone.getTimeZone("America/New_York"), US);
        assertFalse(printer1.equals(printer2));
    }

    @Test
    public void testEqualsReturnsFalseForDifferentLocale() {
        FastDatePrinter printer1 = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.US);
        FastDatePrinter printer2 = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.GERMANY);
        assertFalse(printer1.equals(printer2));
    }

    // ------------------------------------------------------------------
    // toString
    // ------------------------------------------------------------------

    @Test
    public void testToStringIsNotNullOrEmpty() {
        FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", UTC, US);
        String str = printer.toString();
        assertNotNull(str);
        assertFalse(str.isEmpty());
    }

    // ------------------------------------------------------------------
    // Fields FULL / LONG / MEDIUM / SHORT
    // ------------------------------------------------------------------

    @Test
    public void testLocaleStyleConstantsAreDistinct() {
        assertNotEquals(FastDatePrinter.FULL, FastDatePrinter.LONG);
        assertNotEquals(FastDatePrinter.FULL, FastDatePrinter.MEDIUM);
        assertNotEquals(FastDatePrinter.FULL, FastDatePrinter.SHORT);
        assertNotEquals(FastDatePrinter.LONG, FastDatePrinter.MEDIUM);
        assertNotEquals(FastDatePrinter.LONG, FastDatePrinter.SHORT);
        assertNotEquals(FastDatePrinter.MEDIUM, FastDatePrinter.SHORT);
    }

    // ------------------------------------------------------------------
    // parsePattern
    // ------------------------------------------------------------------

    @Test
    public void testParsePatternReturnsNonEmptyListForValidPattern() {
        FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", UTC, US);
        List<?> rules = printer.parsePattern();
        assertNotNull(rules);
        assertFalse(rules.isEmpty());
    }

    @Test
    public void testParsePatternReturnsEmptyListForEmptyPattern() {
        FastDatePrinter printer = new FastDatePrinter("", UTC, US);
        List<?> rules = printer.parsePattern();
        assertNotNull(rules);
        assertTrue(rules.isEmpty());
    }

    @Test
    public void testParsePatternRejectsUnterminatedQuote() {
        try {
            FastDatePrinter printer = new FastDatePrinter("'unterminated", UTC, US);
            printer.parsePattern();
            fail("Expected IllegalArgumentException for an invalid (unterminated quote) pattern");
        } catch (IllegalArgumentException expected) {
            // documented: parsePattern() throws IllegalArgumentException if pattern is invalid
        }
    }

    // ------------------------------------------------------------------
    // selectNumberRule
    // ------------------------------------------------------------------

    @Test
    public void testSelectNumberRuleReturnsNonNullRuleForVariousPadding() {
        FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", UTC, US);
        assertNotNull(printer.selectNumberRule(Calendar.YEAR, 0));
        assertNotNull(printer.selectNumberRule(Calendar.YEAR, 1));
        assertNotNull(printer.selectNumberRule(Calendar.DAY_OF_MONTH, 4));
    }

    // ------------------------------------------------------------------
    // Static helpers: getTimeZoneDisplay / clear
    // ------------------------------------------------------------------

    @Test
    public void testGetTimeZoneDisplayMatchesTimeZoneApi() {
        TimeZone ny = TimeZone.getTimeZone("America/New_York");
        String expectedLong = ny.getDisplayName(false, TimeZone.LONG, US);
        String expectedShort = ny.getDisplayName(false, TimeZone.SHORT, US);
        String expectedLongDst = ny.getDisplayName(true, TimeZone.LONG, US);

        assertEquals(expectedLong, FastDatePrinter.getTimeZoneDisplay(ny, false, TimeZone.LONG, US));
        assertEquals(expectedShort, FastDatePrinter.getTimeZoneDisplay(ny, false, TimeZone.SHORT, US));
        assertEquals(expectedLongDst, FastDatePrinter.getTimeZoneDisplay(ny, true, TimeZone.LONG, US));
    }

    @Test
    public void testClearDoesNotBreakSubsequentTimeZoneDisplayLookups() {
        TimeZone ny = TimeZone.getTimeZone("America/New_York");
        String expected = ny.getDisplayName(false, TimeZone.LONG, US);

        // Populate the cache, then clear it, and confirm lookups still work correctly.
        assertEquals(expected, FastDatePrinter.getTimeZoneDisplay(ny, false, TimeZone.LONG, US));
        FastDatePrinter.clear();
        assertEquals(expected, FastDatePrinter.getTimeZoneDisplay(ny, false, TimeZone.LONG, US));
    }
}
