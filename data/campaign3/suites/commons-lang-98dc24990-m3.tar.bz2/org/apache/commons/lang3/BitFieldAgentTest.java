/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class BitFieldAgentTest {

    private static final BitField BIT_FIELD_LOW_BYTE = new BitField(0xFF);
    private static final BitField BIT_FIELD_MID_BYTE = new BitField(0xFF00);
    private static final BitField BIT_FIELD_SINGLE_BIT = new BitField(0x8000);

    @Test
    public void testGetValueInt() {
        assertEquals(0xFF, BIT_FIELD_LOW_BYTE.getValue(0xFFFFFFFF));
        assertEquals(0, BIT_FIELD_LOW_BYTE.getValue(0xFFFFFF00));
        assertEquals(0x23, BIT_FIELD_LOW_BYTE.getValue(0x3723));
        assertEquals(0x37, BIT_FIELD_MID_BYTE.getValue(0x3723));
    }

    @Test
    public void testGetRawValueInt() {
        assertEquals(0xFF, BIT_FIELD_LOW_BYTE.getRawValue(0xFFFFFFFF));
        assertEquals(0x23, BIT_FIELD_LOW_BYTE.getRawValue(0x3723));
        assertEquals(0x3700, BIT_FIELD_MID_BYTE.getRawValue(0x3723));
    }

    @Test
    public void testGetShortValue() {
        final short holder = (short) 0x3723;
        assertEquals((short) 0x23, BIT_FIELD_LOW_BYTE.getShortValue(holder));
        assertEquals((short) 0x37, BIT_FIELD_MID_BYTE.getShortValue(holder));
    }

    @Test
    public void testGetShortRawValue() {
        final short holder = (short) 0x3723;
        assertEquals((short) 0x23, BIT_FIELD_LOW_BYTE.getShortRawValue(holder));
        assertEquals((short) 0x3700, BIT_FIELD_MID_BYTE.getShortRawValue(holder));
    }

    @Test
    public void testIsSetInt() {
        assertTrue(BIT_FIELD_LOW_BYTE.isSet(0x01));
        assertFalse(BIT_FIELD_LOW_BYTE.isSet(0x100));
        assertFalse(BIT_FIELD_LOW_BYTE.isSet(0));
        assertTrue(BIT_FIELD_SINGLE_BIT.isSet(0x8000));
    }

    @Test
    public void testIsAllSetInt() {
        assertTrue(BIT_FIELD_LOW_BYTE.isAllSet(0xFF));
        assertTrue(BIT_FIELD_LOW_BYTE.isAllSet(0xFFFF));
        assertFalse(BIT_FIELD_LOW_BYTE.isAllSet(0xFE));
        assertFalse(BIT_FIELD_LOW_BYTE.isAllSet(0));
    }

    @Test
    public void testClearInt() {
        assertEquals(0xFFFFFF00, BIT_FIELD_LOW_BYTE.clear(0xFFFFFFFF));
        assertEquals(0, BIT_FIELD_LOW_BYTE.clear(0xFF));
        assertEquals(0x0023, BIT_FIELD_MID_BYTE.clear(0x3723));
    }

    @Test
    public void testClearShort() {
        final short holder = (short) 0xFFFF;
        assertEquals((short) 0xFF00, BIT_FIELD_LOW_BYTE.clearShort(holder));
    }

    @Test
    public void testSetInt() {
        assertEquals(0xFF, BIT_FIELD_LOW_BYTE.set(0));
        assertEquals(0xFFFF, BIT_FIELD_LOW_BYTE.set(0xFF00));
    }

    @Test
    public void testSetShort() {
        final short holder = 0;
        assertEquals((short) 0xFF, BIT_FIELD_LOW_BYTE.setShort(holder));
    }

    @Test
    public void testSetByteAndClearByte() {
        final byte holder = 0;
        assertEquals((byte) 0xFF, BIT_FIELD_LOW_BYTE.setByte(holder));
        final byte setHolder = (byte) 0xFF;
        assertEquals((byte) 0x00, BIT_FIELD_LOW_BYTE.clearByte(setHolder));
    }

    @Test
    public void testSetBooleanInt() {
        assertEquals(0xFF, BIT_FIELD_LOW_BYTE.setBoolean(0, true));
        assertEquals(0, BIT_FIELD_LOW_BYTE.setBoolean(0xFF, false));
    }

    @Test
    public void testSetByteBoolean() {
        final byte zero = 0;
        final byte allSet = (byte) 0xFF;
        assertEquals((byte) 0xFF, BIT_FIELD_LOW_BYTE.setByteBoolean(zero, true));
        assertEquals((byte) 0x00, BIT_FIELD_LOW_BYTE.setByteBoolean(allSet, false));
    }

    @Test
    public void testSetShortBoolean() {
        final short zero = 0;
        final short allSet = (short) 0xFF;
        assertEquals((short) 0xFF, BIT_FIELD_LOW_BYTE.setShortBoolean(zero, true));
        assertEquals((short) 0x00, BIT_FIELD_LOW_BYTE.setShortBoolean(allSet, false));
    }

    @Test
    public void testSetValueInt() {
        assertEquals(0x3745, BIT_FIELD_LOW_BYTE.setValue(0x3723, 0x45));
        assertEquals(0x4523, BIT_FIELD_MID_BYTE.setValue(0x3723, 0x45));
        // value is masked, overflow bits above the field are dropped
        assertEquals(0x3700, BIT_FIELD_LOW_BYTE.setValue(0x3723, 0x100));
    }

    @Test
    public void testSetShortValue() {
        final short holder = (short) 0x3723;
        assertEquals((short) 0x3745, BIT_FIELD_LOW_BYTE.setShortValue(holder, (short) 0x45));
        assertEquals((short) 0x4523, BIT_FIELD_MID_BYTE.setShortValue(holder, (short) 0x45));
    }

    @Test
    public void testZeroMask() {
        final BitField zeroMask = new BitField(0);
        assertEquals(0, zeroMask.getValue(0xFFFFFFFF));
        assertEquals(0, zeroMask.getRawValue(0xFFFFFFFF));
        assertFalse(zeroMask.isSet(0xFFFFFFFF));
        // with an empty mask, "all bits set" is vacuously true
        assertTrue(zeroMask.isAllSet(0xFFFFFFFF));
        assertEquals(0xFFFFFFFF, zeroMask.clear(0xFFFFFFFF));
        assertEquals(0xFFFFFFFF, zeroMask.set(0xFFFFFFFF));
    }

    @Test
    public void testFullIntMask() {
        final BitField fullMask = new BitField(0xFFFFFFFF);
        assertEquals(0xFFFFFFFF, fullMask.getValue(0xFFFFFFFF));
        assertEquals(0x12345678, fullMask.getValue(0x12345678));
        assertTrue(fullMask.isAllSet(0xFFFFFFFF));
        assertEquals(0, fullMask.clear(0xFFFFFFFF));
        assertEquals(0xFFFFFFFF, fullMask.set(0));
    }

    @Test
    public void testHighBitMaskShiftCount() {
        // mask with only the sign bit set: shift count should be 31, so
        // setValue with value=1 sets the high bit.
        final BitField highBit = new BitField(0x80000000);
        assertEquals(0x80000000, highBit.setValue(0, 1));
        assertEquals(1, highBit.getValue(0x80000000));
        assertTrue(highBit.isSet(0x80000000));
        assertFalse(highBit.isSet(0x7FFFFFFF));
    }

    @Test
    public void testLongMaskConstructor() {
        final BitField lowBits = new BitField(0xFFL);
        assertEquals(0xFF, lowBits.getValue(0xFFFFL));
        assertEquals(0xFFL, lowBits.getRawValue(0xFFFFL));
        assertTrue(lowBits.isSet(0x01L));
        assertTrue(lowBits.isAllSet(0xFFL));
        assertFalse(lowBits.isAllSet(0xFEL));
    }

    @Test
    public void testLongHolderOperations() {
        final BitField field = new BitField(0xFF00L);
        assertEquals(0x37L, field.getValue(0x3723L));
        assertEquals(0x4500L, field.setValue(0x3700L, 0x45L));
        assertEquals(0L, field.clear(0xFF00L));
        assertEquals(0xFF00L, field.set(0L));
        assertTrue(field.isSet(0xFF00L));
        assertFalse(field.isSet(0x00FFL));
        assertEquals(0xFF00L, field.setBoolean(0L, true));
        assertEquals(0L, field.setBoolean(0xFF00L, false));
    }

    @Test
    public void testNegativeMaskConstructorEquivalence() {
        // int constructor treats the mask as unsigned 32 bits
        final BitField fromInt = new BitField(0xFF000000);
        final BitField fromLong = new BitField(0xFF000000L);
        assertEquals(fromLong.getValue(0xFF000000L), fromInt.getValue(0xFF000000));
        assertEquals(fromLong.clear(0xFFFFFFFFL), fromInt.clear(0xFFFFFFFF) & 0xFFFFFFFFL);
    }
}
