package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.File;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link CSVFormat} based solely on its documented contract.
 */
public class CSVFormatAgentTest {

    private enum SampleHeader {
        NAME, EMAIL, PHONE
    }

    // ----- Predefined formats -----

    @Test
    public void defaultFormatHasDocumentedSettings() {
        assertEquals(",", CSVFormat.DEFAULT.getDelimiterString());
        assertEquals(Character.valueOf('"'), CSVFormat.DEFAULT.getQuoteCharacter());
        assertEquals("\r\n", CSVFormat.DEFAULT.getRecordSeparator());
        assertTrue(CSVFormat.DEFAULT.getIgnoreEmptyLines());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, CSVFormat.DEFAULT.getDuplicateHeaderMode());
    }

    @Test
    public void excelFormatHasDocumentedSettings() {
        assertEquals(",", CSVFormat.EXCEL.getDelimiterString());
        assertEquals(Character.valueOf('"'), CSVFormat.EXCEL.getQuoteCharacter());
        assertEquals("\r\n", CSVFormat.EXCEL.getRecordSeparator());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, CSVFormat.EXCEL.getDuplicateHeaderMode());
        assertFalse(CSVFormat.EXCEL.getIgnoreEmptyLines());
        assertTrue(CSVFormat.EXCEL.getAllowMissingColumnNames());
        assertTrue(CSVFormat.EXCEL.getTrailingData());
        assertTrue(CSVFormat.EXCEL.getLenientEof());
    }

    @Test
    public void rfc4180FormatHasDocumentedSettings() {
        assertEquals(",", CSVFormat.RFC4180.getDelimiterString());
        assertEquals(Character.valueOf('"'), CSVFormat.RFC4180.getQuoteCharacter());
        assertEquals("\r\n", CSVFormat.RFC4180.getRecordSeparator());
        assertFalse(CSVFormat.RFC4180.getIgnoreEmptyLines());
    }

    @Test
    public void tdfFormatHasDocumentedSettings() {
        assertEquals("\t", CSVFormat.TDF.getDelimiterString());
        assertTrue(CSVFormat.TDF.getIgnoreSurroundingSpaces());
        assertEquals(Character.valueOf('"'), CSVFormat.TDF.getQuoteCharacter());
        assertTrue(CSVFormat.TDF.getIgnoreEmptyLines());
    }

    @Test
    public void mySqlFormatHasDocumentedSettings() {
        assertEquals("\t", CSVFormat.MYSQL.getDelimiterString());
        assertEquals(Character.valueOf('\\'), CSVFormat.MYSQL.getEscapeCharacter());
        assertFalse(CSVFormat.MYSQL.getIgnoreEmptyLines());
        assertNull(CSVFormat.MYSQL.getQuoteCharacter());
        assertFalse(CSVFormat.MYSQL.isQuoteCharacterSet());
        assertEquals("\n", CSVFormat.MYSQL.getRecordSeparator());
        assertEquals("\\N", CSVFormat.MYSQL.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, CSVFormat.MYSQL.getQuoteMode());
    }

    @Test
    public void oracleFormatHasDocumentedSettings() {
        assertEquals(",", CSVFormat.ORACLE.getDelimiterString());
        assertEquals(Character.valueOf('\\'), CSVFormat.ORACLE.getEscapeCharacter());
        assertFalse(CSVFormat.ORACLE.getIgnoreEmptyLines());
        assertEquals(Character.valueOf('"'), CSVFormat.ORACLE.getQuoteCharacter());
        assertEquals("\\N", CSVFormat.ORACLE.getNullString());
        assertTrue(CSVFormat.ORACLE.getTrim());
        assertEquals(System.lineSeparator(), CSVFormat.ORACLE.getRecordSeparator());
        assertEquals(QuoteMode.MINIMAL, CSVFormat.ORACLE.getQuoteMode());
    }

    @Test
    public void postgresqlCsvFormatHasDocumentedSettings() {
        assertEquals(",", CSVFormat.POSTGRESQL_CSV.getDelimiterString());
        assertNull(CSVFormat.POSTGRESQL_CSV.getEscapeCharacter());
        assertFalse(CSVFormat.POSTGRESQL_CSV.isEscapeCharacterSet());
        assertFalse(CSVFormat.POSTGRESQL_CSV.getIgnoreEmptyLines());
        assertEquals(Character.valueOf('"'), CSVFormat.POSTGRESQL_CSV.getQuoteCharacter());
        assertEquals("\n", CSVFormat.POSTGRESQL_CSV.getRecordSeparator());
        assertEquals("", CSVFormat.POSTGRESQL_CSV.getNullString());
        assertTrue(CSVFormat.POSTGRESQL_CSV.isNullStringSet());
        assertEquals(QuoteMode.ALL_NON_NULL, CSVFormat.POSTGRESQL_CSV.getQuoteMode());
    }

    @Test
    public void postgresqlTextFormatHasDocumentedSettings() {
        assertEquals("\t", CSVFormat.POSTGRESQL_TEXT.getDelimiterString());
        assertEquals(Character.valueOf('\\'), CSVFormat.POSTGRESQL_TEXT.getEscapeCharacter());
        assertFalse(CSVFormat.POSTGRESQL_TEXT.getIgnoreEmptyLines());
        assertNull(CSVFormat.POSTGRESQL_TEXT.getQuoteCharacter());
        assertEquals("\n", CSVFormat.POSTGRESQL_TEXT.getRecordSeparator());
        assertEquals("\\N", CSVFormat.POSTGRESQL_TEXT.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, CSVFormat.POSTGRESQL_TEXT.getQuoteMode());
    }

    @Test
    public void mongoDbCsvFormatHasDocumentedSettings() {
        assertEquals(",", CSVFormat.MONGODB_CSV.getDelimiterString());
        assertEquals(Character.valueOf('"'), CSVFormat.MONGODB_CSV.getEscapeCharacter());
        assertEquals(Character.valueOf('"'), CSVFormat.MONGODB_CSV.getQuoteCharacter());
        assertEquals(QuoteMode.MINIMAL, CSVFormat.MONGODB_CSV.getQuoteMode());
    }

    @Test
    public void mongoDbTsvFormatHasDocumentedSettings() {
        assertEquals("\t", CSVFormat.MONGODB_TSV.getDelimiterString());
        assertEquals(Character.valueOf('"'), CSVFormat.MONGODB_TSV.getEscapeCharacter());
        assertEquals(Character.valueOf('"'), CSVFormat.MONGODB_TSV.getQuoteCharacter());
        assertEquals(QuoteMode.MINIMAL, CSVFormat.MONGODB_TSV.getQuoteMode());
        assertFalse(CSVFormat.MONGODB_TSV.getSkipHeaderRecord());
    }

    @Test
    public void informixUnloadFormatHasDocumentedSettings() {
        assertEquals(",", CSVFormat.INFORMIX_UNLOAD.getDelimiterString());
        assertEquals(Character.valueOf('\\'), CSVFormat.INFORMIX_UNLOAD.getEscapeCharacter());
        assertEquals(Character.valueOf('"'), CSVFormat.INFORMIX_UNLOAD.getQuoteCharacter());
        assertEquals("\n", CSVFormat.INFORMIX_UNLOAD.getRecordSeparator());
    }

    @Test
    public void informixUnloadCsvFormatHasDocumentedSettings() {
        assertEquals(",", CSVFormat.INFORMIX_UNLOAD_CSV.getDelimiterString());
        assertEquals(Character.valueOf('"'), CSVFormat.INFORMIX_UNLOAD_CSV.getQuoteCharacter());
        assertEquals("\n", CSVFormat.INFORMIX_UNLOAD_CSV.getRecordSeparator());
        assertFalse(CSVFormat.INFORMIX_UNLOAD_CSV.isEscapeCharacterSet());
    }

    // ----- CSVFormat.Predefined -----

    @Test
    public void predefinedEnumGetFormatMatchesStaticFields() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.Predefined.Default.getFormat());
        assertEquals(CSVFormat.EXCEL, CSVFormat.Predefined.Excel.getFormat());
        assertEquals(CSVFormat.INFORMIX_UNLOAD, CSVFormat.Predefined.InformixUnload.getFormat());
        assertEquals(CSVFormat.INFORMIX_UNLOAD_CSV, CSVFormat.Predefined.InformixUnloadCsv.getFormat());
        assertEquals(CSVFormat.MONGODB_CSV, CSVFormat.Predefined.MongoDBCsv.getFormat());
        assertEquals(CSVFormat.MONGODB_TSV, CSVFormat.Predefined.MongoDBTsv.getFormat());
        assertEquals(CSVFormat.MYSQL, CSVFormat.Predefined.MySQL.getFormat());
        assertEquals(CSVFormat.ORACLE, CSVFormat.Predefined.Oracle.getFormat());
        assertEquals(CSVFormat.POSTGRESQL_CSV, CSVFormat.Predefined.PostgreSQLCsv.getFormat());
        assertEquals(CSVFormat.POSTGRESQL_TEXT, CSVFormat.Predefined.PostgreSQLText.getFormat());
        assertEquals(CSVFormat.RFC4180, CSVFormat.Predefined.RFC4180.getFormat());
        assertEquals(CSVFormat.TDF, CSVFormat.Predefined.TDF.getFormat());
    }

    @Test
    public void predefinedEnumValuesAndValueOf() {
        assertEquals(12, CSVFormat.Predefined.values().length);
        assertSame(CSVFormat.Predefined.Default, CSVFormat.Predefined.valueOf("Default"));
        assertSame(CSVFormat.Predefined.Excel, CSVFormat.Predefined.valueOf("Excel"));
    }

    @Test
    public void predefinedEnumValueOfRejectsUnknownName() {
        try {
            CSVFormat.Predefined.valueOf("NotARealPredefinedFormat");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented contract
        }
    }

    @Test
    public void predefinedEnumValueOfRejectsNull() {
        try {
            CSVFormat.Predefined.valueOf(null);
            fail("Expected NullPointerException");
        } catch (NullPointerException expected) {
            // documented contract
        }
    }

    @Test
    public void staticValueOfReturnsPredefinedFormat() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.valueOf("Default"));
        assertEquals(CSVFormat.EXCEL, CSVFormat.valueOf("Excel"));
        assertEquals(CSVFormat.TDF, CSVFormat.valueOf("TDF"));
    }

    // ----- newFormat(char) -----

    @Test
    public void newFormatInitializesOnlyDelimiter() {
        CSVFormat format = CSVFormat.newFormat(';');
        assertEquals(";", format.getDelimiterString());
        assertNull(format.getQuoteCharacter());
        assertFalse(format.isQuoteCharacterSet());
        assertNull(format.getCommentMarker());
        assertFalse(format.isCommentMarkerSet());
        assertNull(format.getEscapeCharacter());
        assertFalse(format.isEscapeCharacterSet());
        assertNull(format.getRecordSeparator());
        assertFalse(format.getIgnoreEmptyLines());
        assertFalse(format.getSkipHeaderRecord());
        assertNull(format.getHeader());
        assertNull(format.getNullString());
        assertFalse(format.isNullStringSet());
        assertNull(format.getQuoteMode());
        assertFalse(format.getTrim());
        assertFalse(format.getAllowMissingColumnNames());
        assertFalse(format.getIgnoreHeaderCase());
        assertFalse(format.getIgnoreSurroundingSpaces());
        assertFalse(format.getTrailingDelimiter());
        assertFalse(format.getTrailingData());
        assertFalse(format.getAutoFlush());
        assertFalse(format.getLenientEof());
        assertEquals(0L, format.getMaxRows());
    }

    @Test
    public void newFormatRejectsLineBreakDelimiter() {
        try {
            CSVFormat.newFormat('\n');
            fail("Expected IllegalArgumentException for '\\n' delimiter");
        } catch (IllegalArgumentException expected) {
            // documented contract
        }
        try {
            CSVFormat.newFormat('\r');
            fail("Expected IllegalArgumentException for '\\r' delimiter");
        } catch (IllegalArgumentException expected) {
            // documented contract
        }
    }

    // ----- builder() / copy() -----

    @Test
    public void instanceBuilderInheritsCurrentSettings() {
        CSVFormat custom = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        CSVFormat recreated = custom.builder().get();
        assertEquals(custom, recreated);
        assertEquals(";", recreated.getDelimiterString());
        assertEquals("\r\n", recreated.getRecordSeparator());
    }

    @Test
    public void copyInstanceProducesEqualFormat() {
        CSVFormat copy = CSVFormat.DEFAULT.copy();
        assertEquals(CSVFormat.DEFAULT, copy);
    }

    @Test
    public void copyStaticIsNullSafe() {
        assertNull(CSVFormat.copy(null));
        assertEquals(CSVFormat.EXCEL, CSVFormat.copy(CSVFormat.EXCEL));
    }

    @Test
    public void cloneStaticIsNullSafe() {
        assertNull(CSVFormat.<String>clone((String[]) null));
        String[] src = {"x", "y"};
        String[] cloned = CSVFormat.<String>clone(src);
        assertArrayEquals(src, cloned);
        assertNotSame(src, cloned);
    }

    // ----- equals/hashCode/toString -----

    @Test
    public void equalsAndHashCodeContract() {
        CSVFormat a = CSVFormat.DEFAULT;
        CSVFormat b = CSVFormat.copy(CSVFormat.DEFAULT);
        assertTrue(a.equals(a));
        assertTrue(a.equals(b));
        assertEquals(a.hashCode(), b.hashCode());
        assertFalse(a.equals(CSVFormat.EXCEL));
        assertFalse(a.equals(null));
        assertFalse(a.equals("not a CSVFormat"));
    }

    @Test
    public void toStringIsNotBlank() {
        String s = CSVFormat.DEFAULT.toString();
        assertNotNull(s);
        assertFalse(s.isEmpty());
    }

    // ----- package-private accessors with documented contracts -----

    @Test
    public void packagePrivateDelimiterAndEscapeAccessorsReflectState() {
        assertArrayEquals(new char[] {','}, CSVFormat.DEFAULT.getDelimiterCharArray());
        assertEquals(0, CSVFormat.DEFAULT.getEscapeChar());
        assertEquals('\\', CSVFormat.MYSQL.getEscapeChar());
    }

    // ----- format(Object...) -----

    @Test
    public void formatProducesQuotedCsvRecord() {
        String formatted = CSVFormat.DEFAULT.format("a", "b,c", "d\"e");
        assertEquals("a,\"b,c\",\"d\"\"e\"", formatted);
        assertEquals("", CSVFormat.DEFAULT.format());
    }

    // ----- print(Object, Appendable, boolean) -----

    @Test
    public void printObjectAppendableQuotesAndTrimsAsConfigured() throws IOException {
        StringWriter plain = new StringWriter();
        CSVFormat.DEFAULT.print("needs,quote", plain, true);
        assertEquals("\"needs,quote\"", plain.toString());

        CSVFormat trimming = CSVFormat.DEFAULT.builder().setTrim(true).get();
        StringWriter trimmed = new StringWriter();
        trimming.print("  padded  ", trimmed, true);
        assertEquals("padded", trimmed.toString());
    }

    // ----- println(Appendable) -----

    @Test
    public void printlnOutputsTrailingDelimiterAndRecordSeparator() throws IOException {
        CSVFormat withTrailing = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).setRecordSeparator("\n").get();
        StringWriter w1 = new StringWriter();
        withTrailing.println(w1);
        assertEquals(",\n", w1.toString());

        CSVFormat withoutTrailing = CSVFormat.DEFAULT.builder().setTrailingDelimiter(false).setRecordSeparator("\n").get();
        StringWriter w2 = new StringWriter();
        withoutTrailing.println(w2);
        assertEquals("\n", w2.toString());
    }

    // ----- printRecord(Appendable, Object...) -----

    @Test
    public void printRecordWritesDelimitedValuesAndSeparator() throws IOException {
        CSVFormat format = CSVFormat.DEFAULT.builder().setRecordSeparator("\n").get();
        StringWriter writer = new StringWriter();
        format.printRecord(writer, "a", "b", "c");
        assertEquals("a,b,c\n", writer.toString());
    }

    // ----- print(Appendable) / print(File, Charset) / print(Path, Charset) / printer() -----

    @Test
    public void printAppendableReturnsFunctioningPrinter() throws IOException {
        CSVFormat format = CSVFormat.DEFAULT.builder().setRecordSeparator("\n").get();
        StringWriter writer = new StringWriter();
        CSVPrinter printer = format.print(writer);
        assertNotNull(printer);
        printer.printRecord("x", "y");
        printer.close();
        assertEquals("x,y\n", writer.toString());
    }

    @Test
    public void printFileWritesCsvContent() throws IOException {
        File file = File.createTempFile("csvformat-agent-test", ".csv");
        file.deleteOnExit();
        CSVFormat format = CSVFormat.DEFAULT.builder().setRecordSeparator("\n").get();
        CSVPrinter printer = format.print(file, StandardCharsets.UTF_8);
        printer.printRecord("1", "2");
        printer.close();
        String content = new String(Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8);
        assertEquals("1,2\n", content);
    }

    @Test
    public void printPathWritesCsvContent() throws IOException {
        Path path = Files.createTempFile("csvformat-agent-test", ".csv");
        path.toFile().deleteOnExit();
        CSVFormat format = CSVFormat.DEFAULT.builder().setRecordSeparator("\n").get();
        CSVPrinter printer = format.print(path, StandardCharsets.UTF_8);
        printer.printRecord("3", "4");
        printer.close();
        String content = new String(Files.readAllBytes(path), StandardCharsets.UTF_8);
        assertEquals("3,4\n", content);
    }

    @Test
    public void printerReturnsNonNullPrinterToSystemOut() throws IOException {
        CSVPrinter printer = CSVFormat.DEFAULT.printer();
        assertNotNull(printer);
    }

    // ----- parse(Reader) -----

    @Test
    public void parseReaderProducesRecordsUsingHeader() throws IOException {
        CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "b").setSkipHeaderRecord(true).get();
        Reader reader = new StringReader("a,b\r\n1,2\r\n3,4\r\n");
        CSVParser parser = format.parse(reader);
        assertNotNull(parser);
        List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        assertEquals("1", records.get(0).get("a"));
        assertEquals("2", records.get(0).get("b"));
        assertEquals("3", records.get(1).get(0));
        assertEquals("4", records.get(1).get(1));
        parser.close();
    }

    @Test
    public void parseReaderThrowsOnMalformedInput() {
        Reader reader = new StringReader("\"unterminated");
        try {
            CSVFormat.DEFAULT.parse(reader);
            fail("Expected an IOException for malformed quoted CSV input");
        } catch (IOException expected) {
            // documented: "Thrown on invalid input"
        }
    }

    // ----- CSVFormat.Builder -----

    @Test
    public void builderCreateDefaultsMatchDocumentedSettings() {
        CSVFormat format = CSVFormat.Builder.create().get();
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertTrue(format.getIgnoreEmptyLines());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
        assertNull(format.getCommentMarker());
        assertNull(format.getEscapeCharacter());
        assertNull(format.getHeader());
        assertFalse(format.getTrim());
        assertFalse(format.getSkipHeaderRecord());
    }

    @Test
    public void builderCreateFromFormatIsIndependentCopy() {
        CSVFormat.Builder builder = CSVFormat.Builder.create(CSVFormat.DEFAULT);
        CSVFormat copyFormat = builder.get();
        assertEquals(CSVFormat.DEFAULT, copyFormat);

        builder.setDelimiter(';');
        CSVFormat changed = builder.get();
        assertEquals(";", changed.getDelimiterString());
        assertEquals(",", CSVFormat.DEFAULT.getDelimiterString());
    }

    @Test
    public void builderBuildIsAliasForGet() {
        CSVFormat.Builder builder = CSVFormat.Builder.create();
        assertEquals(builder.get(), builder.build());
    }

    @Test
    public void builderFluentSettersApplyAndReturnSameInstance() {
        CSVFormat.Builder builder = CSVFormat.Builder.create();

        CSVFormat.Builder afterDelimiter = builder.setDelimiter('|');
        assertSame(builder, afterDelimiter);

        builder.setQuote(Character.valueOf('\''));
        builder.setCommentMarker('#');
        builder.setEscape('\\');
        builder.setRecordSeparator("\n");
        builder.setNullString("NULL");
        builder.setIgnoreEmptyLines(false);
        builder.setIgnoreHeaderCase(true);
        builder.setIgnoreSurroundingSpaces(true);
        builder.setSkipHeaderRecord(true);
        builder.setTrailingDelimiter(true);
        builder.setTrailingData(true);
        builder.setTrim(true);
        builder.setAutoFlush(true);
        builder.setAllowMissingColumnNames(true);
        builder.setLenientEof(true);
        builder.setMaxRows(5L);
        builder.setQuoteMode(QuoteMode.ALL_NON_NULL);
        builder.setHeader("a", "b");
        builder.setHeaderComments("c1", "c2");
        builder.setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_ALL);

        CSVFormat format = builder.get();

        assertEquals("|", format.getDelimiterString());
        assertEquals(Character.valueOf('\''), format.getQuoteCharacter());
        assertEquals(Character.valueOf('#'), format.getCommentMarker());
        assertTrue(format.isCommentMarkerSet());
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
        assertTrue(format.isEscapeCharacterSet());
        assertEquals("\n", format.getRecordSeparator());
        assertEquals("NULL", format.getNullString());
        assertTrue(format.isNullStringSet());
        assertFalse(format.getIgnoreEmptyLines());
        assertTrue(format.getIgnoreHeaderCase());
        assertTrue(format.getIgnoreSurroundingSpaces());
        assertTrue(format.getSkipHeaderRecord());
        assertTrue(format.getTrailingDelimiter());
        assertTrue(format.getTrailingData());
        assertTrue(format.getTrim());
        assertTrue(format.getAutoFlush());
        assertTrue(format.getAllowMissingColumnNames());
        assertTrue(format.getLenientEof());
        assertEquals(5L, format.getMaxRows());
        assertEquals(QuoteMode.ALL_NON_NULL, format.getQuoteMode());
        assertArrayEquals(new String[] {"a", "b"}, format.getHeader());
        assertArrayEquals(new String[] {"c1", "c2"}, format.getHeaderComments());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
    }

    @Test
    public void builderSetDelimiterStringVariantMatchesCharVariant() {
        CSVFormat format = CSVFormat.Builder.create().setDelimiter(";").get();
        assertEquals(";", format.getDelimiterString());
    }

    @Test
    public void builderSetHeaderNullDisablesHeader() {
        CSVFormat format = CSVFormat.Builder.create().setHeader((String[]) null).get();
        assertNull(format.getHeader());
    }

    @Test
    public void builderSetHeaderNoArgsMeansAutoDetect() {
        CSVFormat format = CSVFormat.Builder.create().setHeader().get();
        String[] header = format.getHeader();
        assertNotNull(header);
        assertEquals(0, header.length);
    }

    @Test
    public void builderSetHeaderCopiesInputArrayAndReturnsDefensiveCopy() {
        String[] input = {"a", "b"};
        CSVFormat format = CSVFormat.Builder.create().setHeader(input).get();

        input[0] = "mutated-input";
        assertArrayEquals(new String[] {"a", "b"}, format.getHeader());

        String[] output = format.getHeader();
        output[0] = "mutated-output";
        assertArrayEquals(new String[] {"a", "b"}, format.getHeader());
    }

    @Test
    public void builderSetHeaderFromEnumClass() {
        CSVFormat format = CSVFormat.Builder.create().setHeader(SampleHeader.class).get();
        assertArrayEquals(new String[] {"NAME", "EMAIL", "PHONE"}, format.getHeader());
    }

    @Test
    public void builderSetCommentMarkerRejectsLineBreakAndAcceptsNullToDisable() {
        try {
            CSVFormat.Builder.create().setCommentMarker('\n');
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented contract
        }

        CSVFormat format = CSVFormat.Builder.create().setCommentMarker('#').setCommentMarker((Character) null).get();
        assertNull(format.getCommentMarker());
        assertFalse(format.isCommentMarkerSet());
    }

    @Test
    public void builderSetEscapeRejectsLineBreakAndAcceptsNullToDisable() {
        try {
            CSVFormat.Builder.create().setEscape('\r');
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented contract
        }

        CSVFormat format = CSVFormat.Builder.create().setEscape('\\').setEscape((Character) null).get();
        assertNull(format.getEscapeCharacter());
        assertFalse(format.isEscapeCharacterSet());
    }

    @Test
    public void builderSetQuoteRejectsLineBreakAndAcceptsNullToDisable() {
        try {
            CSVFormat.Builder.create().setQuote('\n');
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented contract
        }

        CSVFormat format = CSVFormat.Builder.create().setQuote('"').setQuote((Character) null).get();
        assertNull(format.getQuoteCharacter());
        assertFalse(format.isQuoteCharacterSet());
    }

    @Test
    public void builderSetMaxRowsNonPositiveMeansNoLimit() {
        CSVFormat format = CSVFormat.Builder.create().setMaxRows(0L).get();
        assertEquals(0L, format.getMaxRows());
    }

    // ----- deprecated instance getters -----

    @Test
    public void deprecatedGetDelimiterReturnsFirstDelimiterChar() {
        assertEquals(',', CSVFormat.DEFAULT.getDelimiter());
    }

    // ----- deprecated with* methods -----

    @Test
    public void deprecatedWithAllowFlagsTogglesState() {
        assertTrue(CSVFormat.DEFAULT.withAllowDuplicateHeaderNames().getAllowDuplicateHeaderNames());
        assertTrue(CSVFormat.DEFAULT.withAllowDuplicateHeaderNames(true).getAllowDuplicateHeaderNames());
        assertFalse(CSVFormat.DEFAULT.withAllowDuplicateHeaderNames(false).getAllowDuplicateHeaderNames());

        assertTrue(CSVFormat.DEFAULT.withAllowMissingColumnNames().getAllowMissingColumnNames());
        assertTrue(CSVFormat.DEFAULT.withAllowMissingColumnNames(true).getAllowMissingColumnNames());
        assertFalse(CSVFormat.DEFAULT.withAllowMissingColumnNames(false).getAllowMissingColumnNames());
    }

    @Test
    public void deprecatedWithBooleanFlagsToggleStateWithoutMutatingOriginal() {
        CSVFormat base = CSVFormat.DEFAULT;

        assertTrue(base.withAutoFlush(true).getAutoFlush());
        assertFalse(base.withAutoFlush(false).getAutoFlush());

        assertTrue(base.withIgnoreEmptyLines().getIgnoreEmptyLines());
        assertFalse(base.withIgnoreEmptyLines(false).getIgnoreEmptyLines());

        assertTrue(base.withIgnoreHeaderCase().getIgnoreHeaderCase());
        assertFalse(base.withIgnoreHeaderCase(false).getIgnoreHeaderCase());

        assertTrue(base.withIgnoreSurroundingSpaces().getIgnoreSurroundingSpaces());
        assertFalse(base.withIgnoreSurroundingSpaces(false).getIgnoreSurroundingSpaces());

        assertTrue(base.withSkipHeaderRecord().getSkipHeaderRecord());
        assertTrue(base.withSkipHeaderRecord(true).getSkipHeaderRecord());
        assertFalse(base.withSkipHeaderRecord(false).getSkipHeaderRecord());

        assertTrue(base.withTrailingDelimiter().getTrailingDelimiter());
        assertFalse(base.withTrailingDelimiter(false).getTrailingDelimiter());

        assertTrue(base.withTrim().getTrim());
        assertFalse(base.withTrim(false).getTrim());

        assertFalse(base.getAutoFlush());
        assertTrue(base.getIgnoreEmptyLines());
    }

    @Test
    public void deprecatedWithCommentMarkerSetsOrDisablesMarker() {
        CSVFormat withMarker = CSVFormat.DEFAULT.withCommentMarker('#');
        assertEquals(Character.valueOf('#'), withMarker.getCommentMarker());
        assertTrue(withMarker.isCommentMarkerSet());

        CSVFormat disabled = withMarker.withCommentMarker((Character) null);
        assertNull(disabled.getCommentMarker());
        assertFalse(disabled.isCommentMarkerSet());

        try {
            CSVFormat.DEFAULT.withCommentMarker('\n');
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented contract
        }
    }

    @Test
    public void deprecatedWithEscapeSetsOrDisablesEscape() {
        CSVFormat withEscape = CSVFormat.DEFAULT.withEscape('\\');
        assertEquals(Character.valueOf('\\'), withEscape.getEscapeCharacter());
        assertTrue(withEscape.isEscapeCharacterSet());

        CSVFormat disabled = withEscape.withEscape((Character) null);
        assertNull(disabled.getEscapeCharacter());
        assertFalse(disabled.isEscapeCharacterSet());

        try {
            CSVFormat.DEFAULT.withEscape('\r');
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented contract
        }
    }

    @Test
    public void deprecatedWithQuoteSetsOrDisablesQuote() {
        CSVFormat withQuote = CSVFormat.DEFAULT.withQuote('\'');
        assertEquals(Character.valueOf('\''), withQuote.getQuoteCharacter());
        assertTrue(withQuote.isQuoteCharacterSet());

        CSVFormat disabled = withQuote.withQuote((Character) null);
        assertNull(disabled.getQuoteCharacter());
        assertFalse(disabled.isQuoteCharacterSet());

        try {
            CSVFormat.DEFAULT.withQuote('\n');
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented contract
        }
    }

    @Test
    public void deprecatedWithDelimiterSetsDelimiterAndRejectsLineBreak() {
        CSVFormat withSemicolon = CSVFormat.DEFAULT.withDelimiter(';');
        assertEquals(";", withSemicolon.getDelimiterString());

        try {
            CSVFormat.DEFAULT.withDelimiter('\r');
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented contract
        }
    }

    @Test
    public void deprecatedWithHeaderVarargsVariants() {
        CSVFormat withHeader = CSVFormat.DEFAULT.withHeader("a", "b");
        assertArrayEquals(new String[] {"a", "b"}, withHeader.getHeader());

        CSVFormat noHeader = CSVFormat.DEFAULT.withHeader((String[]) null);
        assertNull(noHeader.getHeader());

        CSVFormat autoHeader = CSVFormat.DEFAULT.withHeader();
        assertNotNull(autoHeader.getHeader());
        assertEquals(0, autoHeader.getHeader().length);
    }

    @Test
    public void deprecatedWithHeaderClassEnumSetsHeaderNames() {
        CSVFormat format = CSVFormat.DEFAULT.withHeader(SampleHeader.class);
        assertArrayEquals(new String[] {"NAME", "EMAIL", "PHONE"}, format.getHeader());
    }

    @Test
    public void deprecatedWithHeaderCommentsConvertsValuesToStrings() {
        CSVFormat format = CSVFormat.DEFAULT.withHeaderComments("Generated", Integer.valueOf(7));
        assertArrayEquals(new String[] {"Generated", "7"}, format.getHeaderComments());
    }

    @Test
    public void deprecatedWithFirstRecordAsHeaderResetsHeaderAndSkipsIt() {
        CSVFormat original = CSVFormat.DEFAULT.builder().setHeader("x", "y").setSkipHeaderRecord(false).get();
        CSVFormat updated = original.withFirstRecordAsHeader();

        assertArrayEquals(new String[0], updated.getHeader());
        assertTrue(updated.getSkipHeaderRecord());

        assertArrayEquals(new String[] {"x", "y"}, original.getHeader());
        assertFalse(original.getSkipHeaderRecord());
    }

    @Test
    public void deprecatedWithNullStringSetsOrClearsNullString() {
        CSVFormat withNull = CSVFormat.DEFAULT.withNullString("NULL");
        assertEquals("NULL", withNull.getNullString());
        assertTrue(withNull.isNullStringSet());

        CSVFormat withoutNull = withNull.withNullString(null);
        assertNull(withoutNull.getNullString());
        assertFalse(withoutNull.isNullStringSet());
    }

    @Test
    public void deprecatedWithQuoteModeRoundTrips() {
        CSVFormat withMode = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL_NON_NULL);
        assertEquals(QuoteMode.ALL_NON_NULL, withMode.getQuoteMode());
    }

    @Test
    public void deprecatedWithRecordSeparatorVariants() {
        CSVFormat withCharSep = CSVFormat.DEFAULT.withRecordSeparator('\n');
        assertEquals("\n", withCharSep.getRecordSeparator());

        CSVFormat withStringSep = CSVFormat.DEFAULT.withRecordSeparator("\r\n");
        assertEquals("\r\n", withStringSep.getRecordSeparator());

        try {
            CSVFormat.DEFAULT.withRecordSeparator("not-a-valid-separator");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented contract: "if recordSeparator is none of CR, LF or CRLF"
        }

        CSVFormat withSystemSep = CSVFormat.DEFAULT.withSystemRecordSeparator();
        assertEquals(System.lineSeparator(), withSystemSep.getRecordSeparator());
    }
}
