/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link WordUtils}, self-contained (no shared test base class).
 */
@Deprecated
class WordUtilsAgentTest {

    @Test
    void testConstructor() {
        assertEquals(WordUtils.class, new WordUtils().getClass());
    }

    // capitalize(String)

    @Test
    void testCapitalize_nullAndEmpty() {
        assertNull(WordUtils.capitalize(null));
        assertEquals("", WordUtils.capitalize(""));
        assertEquals(" ", WordUtils.capitalize(" "));
    }

    @Test
    void testCapitalize_basic() {
        assertEquals("I Am FINE", WordUtils.capitalize("i am FINE"));
        assertEquals("I", WordUtils.capitalize("i"));
        assertEquals("I", WordUtils.capitalize("I"));
    }

    // capitalize(String, char...)

    @Test
    void testCapitalizeWithDelimiters_nullDelimitersMeansWhitespace() {
        assertEquals("I Am Fine", WordUtils.capitalize("i am fine", (char[]) null));
    }

    @Test
    void testCapitalizeWithDelimiters_emptyArrayReturnsUnchanged() {
        final String str = "i am fine";
        assertSame(str, WordUtils.capitalize(str, new char[0]));
    }

    @Test
    void testCapitalizeWithDelimiters_customDelimiter() {
        assertEquals("I aM.Fine", WordUtils.capitalize("i aM.fine", '.'));
    }

    @Test
    void testCapitalizeWithDelimiters_nullAndEmptyInput() {
        assertNull(WordUtils.capitalize(null, '.'));
        assertEquals("", WordUtils.capitalize("", '.'));
    }

    // capitalizeFully(String)

    @Test
    void testCapitalizeFully_nullAndEmpty() {
        assertNull(WordUtils.capitalizeFully(null));
        assertEquals("", WordUtils.capitalizeFully(""));
    }

    @Test
    void testCapitalizeFully_basic() {
        assertEquals("I Am Fine", WordUtils.capitalizeFully("i am FINE"));
    }

    // capitalizeFully(String, char...)

    @Test
    void testCapitalizeFullyWithDelimiters_nullDelimitersMeansWhitespace() {
        assertEquals("I Am.fine", WordUtils.capitalizeFully("i aM.fine", (char[]) null));
    }

    @Test
    void testCapitalizeFullyWithDelimiters_emptyArrayReturnsUnchanged() {
        final String str = "i aM.fine";
        assertSame(str, WordUtils.capitalizeFully(str, new char[0]));
    }

    @Test
    void testCapitalizeFullyWithDelimiters_customDelimiter() {
        assertEquals("I am.Fine", WordUtils.capitalizeFully("i aM.fine", '.'));
    }

    @Test
    void testCapitalizeFullyWithDelimiters_nullAndEmptyInput() {
        assertNull(WordUtils.capitalizeFully(null, '.'));
        assertEquals("", WordUtils.capitalizeFully("", '.'));
    }

    // containsAllWords(CharSequence, CharSequence...)

    @Test
    void testContainsAllWords_nullOrEmptyWord() {
        assertEquals(false, WordUtils.containsAllWords(null, "ab"));
        assertEquals(false, WordUtils.containsAllWords("", "ab"));
    }

    @Test
    void testContainsAllWords_nullOrEmptyWordsArray() {
        assertEquals(false, WordUtils.containsAllWords("abc def"));
        assertEquals(false, WordUtils.containsAllWords("abc def", (CharSequence[]) null));
    }

    @Test
    void testContainsAllWords_partialMatchOnSubstringFails() {
        assertEquals(false, WordUtils.containsAllWords("abcd", "ab", "cd"));
    }

    @Test
    void testContainsAllWords_allWordsPresent() {
        assertEquals(true, WordUtils.containsAllWords("abc def", "def", "abc"));
    }

    @Test
    void testContainsAllWords_blankWordInArrayReturnsFalse() {
        assertEquals(false, WordUtils.containsAllWords("abc def", "abc", " "));
        assertEquals(false, WordUtils.containsAllWords("abc def", "abc", ""));
    }

    @Test
    void testContainsAllWords_missingWordReturnsFalse() {
        assertEquals(false, WordUtils.containsAllWords("abc def", "abc", "ghi"));
    }

    // initials(String)

    @Test
    void testInitials_nullAndEmpty() {
        assertNull(WordUtils.initials(null));
        assertEquals("", WordUtils.initials(""));
    }

    @Test
    void testInitials_basic() {
        assertEquals("BJL", WordUtils.initials("Ben John Lee"));
        assertEquals("BJ", WordUtils.initials("Ben J.Lee"));
    }

    // initials(String, char...)

    @Test
    void testInitialsWithDelimiters_nullDelimitersMeansWhitespace() {
        assertEquals("BJL", WordUtils.initials("Ben John Lee", (char[]) null));
        assertEquals("BJ", WordUtils.initials("Ben J.Lee", (char[]) null));
    }

    @Test
    void testInitialsWithDelimiters_customDelimiters() {
        assertEquals("BJL", WordUtils.initials("Ben J.Lee", new char[] {' ', '.'}));
    }

    @Test
    void testInitialsWithDelimiters_emptyArrayReturnsEmptyString() {
        assertEquals("", WordUtils.initials("Ben John Lee", new char[0]));
    }

    @Test
    void testInitialsWithDelimiters_nullAndEmptyInput() {
        assertNull(WordUtils.initials(null, '.'));
        assertEquals("", WordUtils.initials("", '.'));
    }

    @Test
    void testInitials_supplementaryCodePointKeptWithHighSurrogate() {
        // U+1D400 MATHEMATICAL BOLD CAPITAL A, represented as a surrogate pair
        final String supplementary = new String(Character.toChars(0x1D400));
        final String str = supplementary + "bc def";
        final String result = WordUtils.initials(str);
        assertEquals(supplementary + "d", result);
    }

    // swapCase(String)

    @Test
    void testSwapCase_nullAndEmpty() {
        assertNull(WordUtils.swapCase(null));
        assertEquals("", WordUtils.swapCase(""));
    }

    @Test
    void testSwapCase_basic() {
        assertEquals("tHE DOG HAS A bone", WordUtils.swapCase("The dog has a BONE"));
    }

    @Test
    void testSwapCase_nonLetterCharactersResetWhitespaceFlag() {
        assertEquals("1A", WordUtils.swapCase("1a"));
    }

    // uncapitalize(String)

    @Test
    void testUncapitalize_nullAndEmpty() {
        assertNull(WordUtils.uncapitalize(null));
        assertEquals("", WordUtils.uncapitalize(""));
    }

    @Test
    void testUncapitalize_basic() {
        assertEquals("i am fINE", WordUtils.uncapitalize("I Am FINE"));
    }

    // uncapitalize(String, char...)

    @Test
    void testUncapitalizeWithDelimiters_nullArrayMeansWhitespace() {
        assertEquals("i aM.FINE", WordUtils.uncapitalize("I AM.FINE", (char[]) null));
    }

    @Test
    void testUncapitalizeWithDelimiters_emptyArrayReturnsUnchanged() {
        final String str = "I AM.FINE";
        assertSame(str, WordUtils.uncapitalize(str, new char[0]));
    }

    @Test
    void testUncapitalizeWithDelimiters_customDelimiter() {
        assertEquals("i AM.fINE", WordUtils.uncapitalize("I AM.FINE", '.'));
    }

    @Test
    void testUncapitalizeWithDelimiters_nullAndEmptyInput() {
        assertNull(WordUtils.uncapitalize(null, '.'));
        assertEquals("", WordUtils.uncapitalize("", '.'));
    }

    // wrap(String, int)

    @Test
    void testWrap_nullAndEmpty() {
        assertNull(WordUtils.wrap(null, 20));
        assertEquals("", WordUtils.wrap("", 20));
    }

    @Test
    void testWrap_basic() {
        final String input = "Here is one line of text that is going to be wrapped after 20 columns.";
        final String expected = "Here is one line of" + System.lineSeparator()
                + "text that is going" + System.lineSeparator()
                + "to be wrapped after" + System.lineSeparator()
                + "20 columns.";
        assertEquals(expected, WordUtils.wrap(input, 20));
    }

    @Test
    void testWrap_doesNotWrapLongUrlByDefault() {
        final String input = "Click here to jump to the commons website - https://commons.apache.org";
        final String expected = "Click here to jump\nto the commons\nwebsite -\nhttps://commons.apache.org";
        assertEquals(expected, WordUtils.wrap(input, 20, "\n", false));
    }

    // wrap(String, int, String, boolean)

    @Test
    void testWrapWithNewLineAndLongWords_customNewLineString() {
        final String input = "Here is one line of text that is going to be wrapped after 20 columns.";
        final String expected = "Here is one line of<br />text that is going<br />to be wrapped after<br />20 columns.";
        assertEquals(expected, WordUtils.wrap(input, 20, "<br />", false));
    }

    @Test
    void testWrapWithNewLineAndLongWords_wrapLongWordsTrue() {
        final String input = "Click here to jump to the commons website - https://commons.apache.org";
        final String expected = "Click here to jump\nto the commons\nwebsite -\nhttps://commons.apac\nhe.org";
        assertEquals(expected, WordUtils.wrap(input, 20, "\n", true));
    }

    @Test
    void testWrapWithNewLineAndLongWords_nullNewLineUsesSystemLineSeparator() {
        final String input = "Here is one line of text that is going to be wrapped after 20 columns.";
        final String expected = "Here is one line of" + System.lineSeparator()
                + "text that is going" + System.lineSeparator()
                + "to be wrapped after" + System.lineSeparator()
                + "20 columns.";
        assertEquals(expected, WordUtils.wrap(input, 20, null, false));
    }

    // wrap(String, int, String, boolean, String)

    @Test
    void testWrapFull_wrapOnSlash() {
        assertEquals("flammable\ninflammable", WordUtils.wrap("flammable/inflammable", 20, "\n", true, "/"));
    }

    @Test
    void testWrapFull_blankWrapOnDefaultsToSpace() {
        final String input = "Here is one line of text that is going to be wrapped after 20 columns.";
        final String expected = "Here is one line of\ntext that is going\nto be wrapped after\n20 columns.";
        assertEquals(expected, WordUtils.wrap(input, 20, "\n", false, "   "));
    }

    @Test
    void testWrapFull_wrapLengthLessThanOneTreatedAsOne() {
        final String result = WordUtils.wrap("abc def", 0, "\n", false, " ");
        assertEquals("abc\ndef", result);
    }

    @Test
    void testWrapFull_negativeWrapLengthTreatedAsOne() {
        final String result = WordUtils.wrap("abc def", -5, "\n", false, " ");
        assertEquals("abc\ndef", result);
    }

    @Test
    void testWrapFull_nullInput() {
        assertNull(WordUtils.wrap(null, 20, "\n", false, " "));
    }

    @Test
    void testWrapFull_singleWordShorterThanWrapLengthUnwrapped() {
        assertEquals("abc", WordUtils.wrap("abc", 20, "\n", false, " "));
    }
}
