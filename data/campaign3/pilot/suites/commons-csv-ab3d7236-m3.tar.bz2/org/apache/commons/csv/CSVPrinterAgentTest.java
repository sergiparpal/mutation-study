/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.Closeable;
import java.io.Flushable;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link CSVPrinter}.
 */
public class CSVPrinterAgentTest {

    /**
     * An Appendable that is also Flushable and Closeable so flush/close delegation can be observed.
     */
    private static final class TrackingAppendable implements Appendable, Flushable, Closeable {
        private final StringBuilder sb = new StringBuilder();
        private boolean flushed;
        private boolean closed;

        @Override
        public Appendable append(final char c) throws IOException {
            sb.append(c);
            return this;
        }

        @Override
        public Appendable append(final CharSequence csq) throws IOException {
            sb.append(csq);
            return this;
        }

        @Override
        public Appendable append(final CharSequence csq, final int start, final int end) throws IOException {
            sb.append(csq, start, end);
            return this;
        }

        @Override
        public void close() throws IOException {
            closed = true;
        }

        @Override
        public void flush() throws IOException {
            flushed = true;
        }

        @Override
        public String toString() {
            return sb.toString();
        }
    }

    /**
     * A minimal ResultSet stand-in that supports the two rows/columns this test needs.
     */
    private static final class FakeResultSet implements java.lang.reflect.InvocationHandler {
        private int row = 0;
        private final Object[][] data;
        private final String[] labels;

        FakeResultSet(final String[] labels, final Object[][] data) {
            this.labels = labels;
            this.data = data;
        }

        @Override
        public Object invoke(final Object proxy, final java.lang.reflect.Method method, final Object[] args) throws Throwable {
            final String name = method.getName();
            if ("next".equals(name)) {
                if (row < data.length) {
                    row++;
                    return Boolean.TRUE;
                }
                return Boolean.FALSE;
            }
            if ("getRow".equals(name)) {
                return Integer.valueOf(row);
            }
            if ("getObject".equals(name)) {
                final int col = ((Integer) args[0]).intValue();
                return data[row - 1][col - 1];
            }
            if ("getMetaData".equals(name)) {
                return newMetaDataProxy();
            }
            if ("equals".equals(name)) {
                return Boolean.valueOf(proxy == args[0]);
            }
            if ("hashCode".equals(name)) {
                return Integer.valueOf(System.identityHashCode(proxy));
            }
            if ("toString".equals(name)) {
                return "FakeResultSet";
            }
            throw new UnsupportedOperationException(name);
        }

        private ResultSetMetaData newMetaDataProxy() {
            return (ResultSetMetaData) java.lang.reflect.Proxy.newProxyInstance(
                    getClass().getClassLoader(), new Class[] { ResultSetMetaData.class },
                    new java.lang.reflect.InvocationHandler() {
                        @Override
                        public Object invoke(final Object proxy, final java.lang.reflect.Method method, final Object[] args) throws Throwable {
                            final String name = method.getName();
                            if ("getColumnCount".equals(name)) {
                                return Integer.valueOf(labels.length);
                            }
                            if ("getColumnLabel".equals(name)) {
                                final int col = ((Integer) args[0]).intValue();
                                return labels[col - 1];
                            }
                            throw new UnsupportedOperationException(name);
                        }
                    });
        }

        ResultSet asResultSet() {
            return (ResultSet) java.lang.reflect.Proxy.newProxyInstance(
                    getClass().getClassLoader(), new Class[] { ResultSet.class }, this);
        }
    }

    @Test
    public void testConstructorNullAppendableThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new CSVPrinter(null, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    public void testConstructorNullFormatThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new CSVPrinter(new StringBuilder(), null);
            }
        });
    }

    @Test
    public void testPrintSimpleValues() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("a");
        printer.print("b");
        assertEquals("a,b", sb.toString());
    }

    @Test
    public void testPrintNullValueUsesEmptyString() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("a");
        printer.print(null);
        assertEquals("a,", sb.toString());
    }

    @Test
    public void testPrintQuotesValueContainingDelimiter() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("a,b");
        assertEquals("\"a,b\"", sb.toString());
    }

    @Test
    public void testPrintRecordVarargs() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord("a", "b", "c");
        assertEquals("a,b,c\r\n", sb.toString());
        assertEquals(1, printer.getRecordCount());
    }

    @Test
    public void testPrintRecordEmptyVarargsStillEndsRecord() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord();
        assertEquals("\r\n", sb.toString());
        assertEquals(1, printer.getRecordCount());
    }

    @Test
    public void testPrintRecordIterable() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        final List<String> values = new ArrayList<String>();
        values.add("x");
        values.add("y");
        printer.printRecord(values);
        assertEquals("x,y\r\n", sb.toString());
        assertEquals(1, printer.getRecordCount());
    }

    @Test
    public void testPrintRecordStream() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord(Arrays.asList("p", "q").stream());
        assertEquals("p,q\r\n", sb.toString());
        assertEquals(1, printer.getRecordCount());
    }

    @Test
    public void testPrintRecordsObjectArrayNested() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecords(new Object[] { new String[] { "A", "B" }, new String[] { "1", "2" } });
        assertEquals("A,B\r\n1,2\r\n", sb.toString());
        assertEquals(2, printer.getRecordCount());
    }

    @Test
    public void testPrintRecordsIterableNested() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        final List<String[]> data = new ArrayList<String[]>();
        data.add(new String[] { "A", "B", "C" });
        data.add(new String[] { "1", "2", "3" });
        printer.printRecords(data);
        assertEquals("A,B,C\r\n1,2,3\r\n", sb.toString());
        assertEquals(2, printer.getRecordCount());
    }

    @Test
    public void testPrintRecordsOfSimpleObjectsPrintsOneRecordPerValue() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecords("a", "b", "c");
        assertEquals("a\r\nb\r\nc\r\n", sb.toString());
        assertEquals(3, printer.getRecordCount());
    }

    @Test
    public void testPrintRecordsEmptyArrayPrintsNothing() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecords(new Object[0]);
        assertEquals("", sb.toString());
        assertEquals(0, printer.getRecordCount());
    }

    @Test
    public void testPrintRecordsStream() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        final List<String[]> data = new ArrayList<String[]>();
        data.add(new String[] { "A", "B" });
        data.add(new String[] { "1", "2" });
        printer.printRecords(data.stream());
        assertEquals("A,B\r\n1,2\r\n", sb.toString());
        assertEquals(2, printer.getRecordCount());
    }

    @Test
    public void testPrintlnDoesNotIncrementRecordCount() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("a");
        printer.println();
        assertEquals("a\r\n", sb.toString());
        assertEquals(0, printer.getRecordCount());
    }

    @Test
    public void testPrintCommentWithoutMarkerDoesNothing() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printComment("a comment");
        assertEquals("", sb.toString());
    }

    @Test
    public void testPrintCommentNullDoesNothing() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVPrinter printer = new CSVPrinter(sb, format);
        printer.printComment(null);
        assertEquals("", sb.toString());
    }

    @Test
    public void testPrintCommentWithMarker() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVPrinter printer = new CSVPrinter(sb, format);
        printer.printComment("hello");
        assertEquals("# hello\r\n", sb.toString());
        assertEquals(0, printer.getRecordCount());
    }

    @Test
    public void testPrintCommentMultiline() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVPrinter printer = new CSVPrinter(sb, format);
        printer.printComment("line1\nline2");
        assertEquals("# line1\r\n# line2\r\n", sb.toString());
    }

    @Test
    public void testHeaderPrintedOnConstructionByDefault() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("col1", "col2").get();
        final CSVPrinter printer = new CSVPrinter(sb, format);
        assertEquals("col1,col2\r\n", sb.toString());
        printer.printRecord("a", "b");
        assertEquals("col1,col2\r\na,b\r\n", sb.toString());
    }

    @Test
    public void testHeaderSkippedWhenConfigured() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("col1", "col2").setSkipHeaderRecord(true).get();
        new CSVPrinter(sb, format);
        assertEquals("", sb.toString());
    }

    @Test
    public void testHeaderCommentsPrintedOnConstruction() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').setHeaderComments("top of file").get();
        new CSVPrinter(sb, format);
        assertEquals("# top of file\r\n", sb.toString());
    }

    @Test
    public void testGetOutReturnsSameAppendable() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        assertSame(sb, printer.getOut());
    }

    @Test
    public void testGetRecordCountInitiallyZero() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        assertEquals(0, printer.getRecordCount());
    }

    @Test
    public void testFlushDelegatesToFlushableAppendable() throws IOException {
        final TrackingAppendable appendable = new TrackingAppendable();
        final CSVPrinter printer = new CSVPrinter(appendable, CSVFormat.DEFAULT);
        assertFalse(appendable.flushed);
        printer.flush();
        assertTrue(appendable.flushed);
    }

    @Test
    public void testFlushOnNonFlushableAppendableIsNoOp() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.flush();
    }

    @Test
    public void testCloseWithoutFlushDoesNotFlushByDefault() throws IOException {
        final TrackingAppendable appendable = new TrackingAppendable();
        final CSVPrinter printer = new CSVPrinter(appendable, CSVFormat.DEFAULT);
        printer.close();
        assertFalse(appendable.flushed);
        assertTrue(appendable.closed);
    }

    @Test
    public void testCloseWithExplicitFlushTrueFlushesFirst() throws IOException {
        final TrackingAppendable appendable = new TrackingAppendable();
        final CSVPrinter printer = new CSVPrinter(appendable, CSVFormat.DEFAULT);
        printer.close(true);
        assertTrue(appendable.flushed);
        assertTrue(appendable.closed);
    }

    @Test
    public void testCloseWithAutoFlushFormatFlushesOnClose() throws IOException {
        final TrackingAppendable appendable = new TrackingAppendable();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setAutoFlush(true).get();
        final CSVPrinter printer = new CSVPrinter(appendable, format);
        printer.close(false);
        assertTrue(appendable.flushed);
    }

    @Test
    public void testCloseOnNonCloseableAppendableDoesNotThrow() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.close();
    }

    @Test
    public void testPrintRecordsFromResultSet() throws IOException, SQLException {
        final FakeResultSet fake = new FakeResultSet(
                new String[] { "A", "B" },
                new Object[][] { { "a1", "b1" }, { "a2", "b2" } });
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecords(fake.asResultSet());
        assertEquals("a1,b1\r\na2,b2\r\n", sb.toString());
        assertEquals(2, printer.getRecordCount());
    }

    @Test
    public void testPrintRecordsFromResultSetWithHeader() throws IOException, SQLException {
        final FakeResultSet fake = new FakeResultSet(
                new String[] { "A", "B" },
                new Object[][] { { "a1", "b1" } });
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecords(fake.asResultSet(), true);
        assertEquals("A,B\r\na1,b1\r\n", sb.toString());
        assertEquals(1, printer.getRecordCount());
    }

    @Test
    public void testPrintHeadersFromResultSet() throws IOException, SQLException {
        final FakeResultSet fake = new FakeResultSet(
                new String[] { "X", "Y", "Z" },
                new Object[][] {});
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printHeaders(fake.asResultSet());
        assertEquals("X,Y,Z\r\n", sb.toString());
        assertEquals(0, printer.getRecordCount());
    }

    @Test
    public void testPrintRecordsEmptyResultSetPrintsNothing() throws IOException, SQLException {
        final FakeResultSet fake = new FakeResultSet(new String[] { "A" }, new Object[][] {});
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecords(fake.asResultSet());
        assertEquals("", sb.toString());
        assertEquals(0, printer.getRecordCount());
    }
}
