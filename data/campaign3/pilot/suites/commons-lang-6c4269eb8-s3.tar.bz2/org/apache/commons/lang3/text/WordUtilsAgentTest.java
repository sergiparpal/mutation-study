package org.apache.commons.lang3.text;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SuppressWarnings("deprecation")
public class WordUtilsAgentTest {

    private static final String NL = System.lineSeparator();

    // ---- constructor ----

    @Test
    public void testConstructorIsPublic() {
        WordUtils instance = new WordUtils();
        assertNotNull(instance);
    }

    // ---- capitalize(String) ----

    @Test
    public void testCapitalizeNull() {
        assertNull(WordUtils.capitalize(null));
    }

    @Test
    public void testCapitalizeEmpty() {
        assertEquals("", WordUtils.capitalize(""));
    }

    @Test
    public void testCapitalizeWhitespaceSeparatedWords() {
        assertEquals("I Am FINE", WordUtils.capitalize("i am FINE"));
    }

    @Test
    public void testCapitalizeSingleWord() {
        assertEquals("Hello", WordUtils.capitalize("hello"));
    }

    @Test
    public void testCapitalizeAlreadyCapitalized() {
        assertEquals("Hello", WordUtils.capitalize("Hello"));
    }

    @Test
    public void testCapitalizeNonLetterFirstChar() {
        assertEquals("3abc", WordUtils.capitalize("3abc"));
    }

    // ---- capitalize(String, char...) ----

    @Test
    public void testCapitalizeDelimNullString() {
        assertNull(WordUtils.capitalize(null, '*'));
    }

    @Test
    public void testCapitalizeDelimEmptyString() {
        assertEquals("", WordUtils.capitalize("", '*'));
    }

    @Test
    public void testCapitalizeDelimEmptyArrayLeavesUnchanged() {
        assertEquals("i am fine", WordUtils.capitalize("i am fine", new char[0]));
    }

    @Test
    public void testCapitalizeDelimNullArrayMeansWhitespace() {
        assertEquals("I Am Fine", WordUtils.capitalize("i am fine", (char[]) null));
    }

    @Test
    public void testCapitalizeDelimCustomDelimiter() {
        assertEquals("I aM.Fine", WordUtils.capitalize("i aM.fine", '.'));
    }

    // ---- capitalizeFully(String) ----

    @Test
    public void testCapitalizeFullyNull() {
        assertNull(WordUtils.capitalizeFully(null));
    }

    @Test
    public void testCapitalizeFullyEmpty() {
        assertEquals("", WordUtils.capitalizeFully(""));
    }

    @Test
    public void testCapitalizeFullyWhitespaceSeparatedWords() {
        assertEquals("I Am Fine", WordUtils.capitalizeFully("i am FINE"));
    }

    // ---- capitalizeFully(String, char...) ----

    @Test
    public void testCapitalizeFullyDelimNullString() {
        assertNull(WordUtils.capitalizeFully(null, '*'));
    }

    @Test
    public void testCapitalizeFullyDelimEmptyString() {
        assertEquals("", WordUtils.capitalizeFully("", '*'));
    }

    @Test
    public void testCapitalizeFullyDelimNullArrayLeavesUnchanged() {
        assertEquals("i aM.fine", WordUtils.capitalizeFully("i aM.fine", (char[]) null));
    }

    @Test
    public void testCapitalizeFullyDelimEmptyArrayLeavesUnchanged() {
        assertEquals("i aM.fine", WordUtils.capitalizeFully("i aM.fine", new char[0]));
    }

    @Test
    public void testCapitalizeFullyDelimCustomDelimiter() {
        assertEquals("I am.Fine", WordUtils.capitalizeFully("i aM.fine", '.'));
    }

    // ---- containsAllWords(CharSequence, CharSequence...) ----

    @Test
    public void testContainsAllWordsNullWord() {
        assertFalse(WordUtils.containsAllWords(null, "abc"));
    }

    @Test
    public void testContainsAllWordsEmptyWord() {
        assertFalse(WordUtils.containsAllWords("", "abc"));
    }

    @Test
    public void testContainsAllWordsNullWordsArray() {
        assertFalse(WordUtils.containsAllWords("abc def", (CharSequence[]) null));
    }

    @Test
    public void testContainsAllWordsEmptyWordsArray() {
        assertFalse(WordUtils.containsAllWords("abc def", new CharSequence[0]));
    }

    @Test
    public void testContainsAllWordsPartialMatchIsNotWholeWord() {
        assertFalse(WordUtils.containsAllWords("abcd", "ab", "cd"));
    }

    @Test
    public void testContainsAllWordsAllFoundInAnyOrder() {
        assertTrue(WordUtils.containsAllWords("abc def", "def", "abc"));
    }

    @Test
    public void testContainsAllWordsNotSubstringMatch() {
        assertFalse(WordUtils.containsAllWords("abcx", "abc"));
    }

    @Test
    public void testContainsAllWordsCaseSensitive() {
        assertFalse(WordUtils.containsAllWords("abc def", "ABC"));
    }

    // ---- initials(String) ----

    @Test
    public void testInitialsNull() {
        assertNull(WordUtils.initials(null));
    }

    @Test
    public void testInitialsEmpty() {
        assertEquals("", WordUtils.initials(""));
    }

    @Test
    public void testInitialsThreeWords() {
        assertEquals("BJL", WordUtils.initials("Ben John Lee"));
    }

    @Test
    public void testInitialsDotIsNotWhitespace() {
        assertEquals("BJ", WordUtils.initials("Ben J.Lee"));
    }

    @Test
    public void testInitialsSingleWord() {
        assertEquals("B", WordUtils.initials("Ben"));
    }

    // ---- initials(String, char...) ----

    @Test
    public void testInitialsDelimNullString() {
        assertNull(WordUtils.initials(null, '*'));
    }

    @Test
    public void testInitialsDelimEmptyString() {
        assertEquals("", WordUtils.initials("", '*'));
    }

    @Test
    public void testInitialsDelimNullArrayMeansWhitespace() {
        assertEquals("BJL", WordUtils.initials("Ben John Lee", (char[]) null));
    }

    @Test
    public void testInitialsDelimNullArrayDotNotWhitespace() {
        assertEquals("BJ", WordUtils.initials("Ben J.Lee", (char[]) null));
    }

    @Test
    public void testInitialsDelimCustomDelimiters() {
        assertEquals("BJL", WordUtils.initials("Ben J.Lee", new char[] {' ', '.'}));
    }

    @Test
    public void testInitialsDelimEmptyArrayReturnsEmpty() {
        assertEquals("", WordUtils.initials("Ben John Lee", new char[0]));
    }

    // ---- swapCase(String) ----

    @Test
    public void testSwapCaseNull() {
        assertNull(WordUtils.swapCase(null));
    }

    @Test
    public void testSwapCaseEmpty() {
        assertEquals("", WordUtils.swapCase(""));
    }

    @Test
    public void testSwapCaseMixed() {
        assertEquals("tHE DOG HAS A bone", WordUtils.swapCase("The dog has a BONE"));
    }

    // ---- uncapitalize(String) ----

    @Test
    public void testUncapitalizeNull() {
        assertNull(WordUtils.uncapitalize(null));
    }

    @Test
    public void testUncapitalizeEmpty() {
        assertEquals("", WordUtils.uncapitalize(""));
    }

    @Test
    public void testUncapitalizeWhitespaceSeparatedWords() {
        assertEquals("i am fINE", WordUtils.uncapitalize("I Am FINE"));
    }

    // ---- uncapitalize(String, char...) ----

    @Test
    public void testUncapitalizeDelimNullString() {
        assertNull(WordUtils.uncapitalize(null, '*'));
    }

    @Test
    public void testUncapitalizeDelimEmptyString() {
        assertEquals("", WordUtils.uncapitalize("", '*'));
    }

    @Test
    public void testUncapitalizeDelimNullArrayLeavesUnchanged() {
        assertEquals("I AM.FINE", WordUtils.uncapitalize("I AM.FINE", (char[]) null));
    }

    @Test
    public void testUncapitalizeDelimEmptyArrayLeavesUnchanged() {
        assertEquals("I AM.FINE", WordUtils.uncapitalize("I AM.FINE", new char[0]));
    }

    @Test
    public void testUncapitalizeDelimCustomDelimiter() {
        assertEquals("i AM.fINE", WordUtils.uncapitalize("I AM.FINE", '.'));
    }

    // ---- wrap(String, int) ----

    @Test
    public void testWrapTwoArgNull() {
        assertNull(WordUtils.wrap(null, 20));
    }

    @Test
    public void testWrapTwoArgEmpty() {
        assertEquals("", WordUtils.wrap("", 20));
    }

    @Test
    public void testWrapTwoArgSentence() {
        String expected = "Here is one line of" + NL + "text that is going" + NL
                + "to be wrapped after" + NL + "20 columns.";
        assertEquals(expected,
                WordUtils.wrap("Here is one line of text that is going to be wrapped after 20 columns.", 20));
    }

    @Test
    public void testWrapTwoArgDoesNotBreakLongWord() {
        String expected = "Click here to jump" + NL + "to the commons" + NL + "website -" + NL
                + "https://commons.apache.org";
        assertEquals(expected,
                WordUtils.wrap("Click here to jump to the commons website - https://commons.apache.org", 20));
    }

    @Test
    public void testWrapTwoArgLengthLessThanOneTreatedAsOne() {
        assertEquals("ab" + NL + "cd", WordUtils.wrap("ab cd", 0));
    }

    @Test
    public void testWrapTwoArgNegativeLengthTreatedAsOne() {
        assertEquals("ab" + NL + "cd", WordUtils.wrap("ab cd", -5));
    }

    // ---- wrap(String, int, String, boolean) ----

    @Test
    public void testWrapFourArgNull() {
        assertNull(WordUtils.wrap(null, 20, "\n", true));
    }

    @Test
    public void testWrapFourArgEmpty() {
        assertEquals("", WordUtils.wrap("", 20, "\n", true));
    }

    @Test
    public void testWrapFourArgCustomNewLineString() {
        String expected = "Here is one line of<br />text that is going<br />to be wrapped after<br />20 columns.";
        assertEquals(expected,
                WordUtils.wrap("Here is one line of text that is going to be wrapped after 20 columns.",
                        20, "<br />", true));
    }

    @Test
    public void testWrapFourArgNullNewLineUsesSystemLineSeparator() {
        String expected = "Here is one line of" + NL + "text that is going" + NL
                + "to be wrapped after" + NL + "20 columns.";
        assertEquals(expected,
                WordUtils.wrap("Here is one line of text that is going to be wrapped after 20 columns.",
                        20, null, true));
    }

    @Test
    public void testWrapFourArgLongWordNotWrappedWhenFlagFalse() {
        String expected = "Click here to jump\nto the commons\nwebsite -\nhttps://commons.apache.org";
        assertEquals(expected,
                WordUtils.wrap("Click here to jump to the commons website - https://commons.apache.org",
                        20, "\n", false));
    }

    @Test
    public void testWrapFourArgLongWordWrappedWhenFlagTrue() {
        String expected = "Click here to jump\nto the commons\nwebsite -\nhttps://commons.apach\ne.org";
        assertEquals(expected,
                WordUtils.wrap("Click here to jump to the commons website - https://commons.apache.org",
                        20, "\n", true));
    }

    // ---- wrap(String, int, String, boolean, String) ----

    @Test
    public void testWrapFiveArgNull() {
        assertNull(WordUtils.wrap(null, 20, "\n", true, " "));
    }

    @Test
    public void testWrapFiveArgEmpty() {
        assertEquals("", WordUtils.wrap("", 20, "\n", true, " "));
    }

    @Test
    public void testWrapFiveArgDefaultSpaceDelimiterMatchesFourArgBehavior() {
        String expected = "Click here to jump\nto the commons\nwebsite -\nhttps://commons.apach\ne.org";
        assertEquals(expected,
                WordUtils.wrap("Click here to jump to the commons website - https://commons.apache.org",
                        20, "\n", true, " "));
    }

    @Test
    public void testWrapFiveArgCustomWrapOnCharacter() {
        assertEquals("flammable\ninflammable",
                WordUtils.wrap("flammable/inflammable", 20, "\n", true, "/"));
    }
}
