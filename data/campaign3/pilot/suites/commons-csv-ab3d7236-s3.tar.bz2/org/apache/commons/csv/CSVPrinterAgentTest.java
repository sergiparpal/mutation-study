package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringWriter;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link CSVPrinter} based on its documented contract.
 */
public class CSVPrinterAgentTest {

    // ---------------------------------------------------------------
    // Fixtures
    // ---------------------------------------------------------------

    private static CSVFormat.Builder newFormatBuilder() {
        return CSVFormat.Builder.create(CSVFormat.DEFAULT).setDelimiter(',').setQuote(Character.valueOf('"'))
                .setRecordSeparator("\n");
    }

    private static CSVFormat plainFormat() {
        return newFormatBuilder().build();
    }

    /** A Writer that counts flush() and close() invocations without discarding buffered text. */
    private static final class CountingWriter extends StringWriter {
        private int flushCount;
        private int closeCount;

        @Override
        public void flush() {
            flushCount++;
            super.flush();
        }

        @Override
        public void close() throws IOException {
            closeCount++;
            super.close();
        }
    }

    /** An Appendable whose every append() call fails, to verify IOException propagation. */
    private static final class ThrowingAppendable implements Appendable {
        @Override
        public Appendable append(final CharSequence csq) throws IOException {
            throw new IOException("boom");
        }

        @Override
        public Appendable append(final CharSequence csq, final int start, final int end) throws IOException {
            throw new IOException("boom");
        }

        @Override
        public Appendable append(final char c) throws IOException {
            throw new IOException("boom");
        }
    }

    private static Object defaultReturnFor(final Class<?> type) {
        if (type == boolean.class) {
            return Boolean.FALSE;
        }
        if (type == long.class) {
            return Long.valueOf(0L);
        }
        if (type == double.class) {
            return Double.valueOf(0d);
        }
        if (type == float.class) {
            return Float.valueOf(0f);
        }
        if (type == short.class) {
            return Short.valueOf((short) 0);
        }
        if (type == byte.class) {
            return Byte.valueOf((byte) 0);
        }
        if (type == int.class) {
            return Integer.valueOf(0);
        }
        return null;
    }

    /** A minimal java.sql.ResultSet backed by an in-memory table, built via a dynamic proxy. */
    private static final class FakeResultSetHandler implements InvocationHandler {
        private final String[] columnLabels;
        private final Object[][] rows;
        private int cursor = -1;
        private Object metaDataProxy;

        FakeResultSetHandler(final String[] columnLabels, final Object[][] rows) {
            this.columnLabels = columnLabels;
            this.rows = rows;
        }

        void setMetaDataProxy(final Object metaDataProxy) {
            this.metaDataProxy = metaDataProxy;
        }

        @Override
        public Object invoke(final Object proxy, final Method method, final Object[] args) throws Throwable {
            final String name = method.getName();
            if ("next".equals(name)) {
                cursor++;
                return Boolean.valueOf(cursor < rows.length);
            }
            if ("getMetaData".equals(name)) {
                return metaDataProxy;
            }
            if ("getObject".equals(name) && args != null && args.length == 1 && args[0] instanceof Integer) {
                final int idx = ((Integer) args[0]).intValue();
                return rows[cursor][idx - 1];
            }
            if ("isClosed".equals(name)) {
                return Boolean.FALSE;
            }
            if ("close".equals(name)) {
                return null;
            }
            if ("equals".equals(name)) {
                return Boolean.valueOf(proxy == args[0]);
            }
            if ("hashCode".equals(name)) {
                return Integer.valueOf(System.identityHashCode(proxy));
            }
            if ("toString".equals(name)) {
                return "FakeResultSet";
            }
            return defaultReturnFor(method.getReturnType());
        }
    }

    private static final class FakeMetaDataHandler implements InvocationHandler {
        private final String[] columnLabels;

        FakeMetaDataHandler(final String[] columnLabels) {
            this.columnLabels = columnLabels;
        }

        @Override
        public Object invoke(final Object proxy, final Method method, final Object[] args) throws Throwable {
            final String name = method.getName();
            if ("getColumnCount".equals(name)) {
                return Integer.valueOf(columnLabels.length);
            }
            if (("getColumnLabel".equals(name) || "getColumnName".equals(name)) && args != null && args.length == 1) {
                final int idx = ((Integer) args[0]).intValue();
                return columnLabels[idx - 1];
            }
            if ("equals".equals(name)) {
                return Boolean.valueOf(proxy == args[0]);
            }
            if ("hashCode".equals(name)) {
                return Integer.valueOf(System.identityHashCode(proxy));
            }
            if ("toString".equals(name)) {
                return "FakeResultSetMetaData";
            }
            return defaultReturnFor(method.getReturnType());
        }
    }

    private static ResultSet newFakeResultSet(final String[] columnLabels, final Object[][] rows) {
        final FakeResultSetHandler rsHandler = new FakeResultSetHandler(columnLabels, rows);
        final ResultSetMetaData metaData = (ResultSetMetaData) Proxy.newProxyInstance(
                CSVPrinterAgentTest.class.getClassLoader(), new Class[] { ResultSetMetaData.class },
                new FakeMetaDataHandler(columnLabels));
        rsHandler.setMetaDataProxy(metaData);
        return (ResultSet) Proxy.newProxyInstance(CSVPrinterAgentTest.class.getClassLoader(),
                new Class[] { ResultSet.class }, rsHandler);
    }

    // ---------------------------------------------------------------
    // Constructor
    // ---------------------------------------------------------------

    @Test
    public void constructorRejectsNullAppendable() {
        final CSVFormat format = plainFormat();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                new CSVPrinter(null, format);
            }
        });
    }

    @Test
    public void constructorRejectsNullFormat() {
        final StringWriter sw = new StringWriter();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                new CSVPrinter(sw, null);
            }
        });
    }

    @Test
    public void constructorRejectsHybridEncapsulationAndEscaping() {
        final CSVFormat hybrid = newFormatBuilder().setEscape(Character.valueOf('\\')).build();
        final StringWriter sw = new StringWriter();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                new CSVPrinter(sw, hybrid);
            }
        });
    }

    @Test
    public void constructorPropagatesIOExceptionFromHeaderWrite() {
        final CSVFormat withHeader = newFormatBuilder().setHeader(new String[] { "a", "b" }).build();
        final ThrowingAppendable throwing = new ThrowingAppendable();
        assertThrows(IOException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                new CSVPrinter(throwing, withHeader);
            }
        });
    }

    @Test
    public void constructorWritesHeaderImmediately() throws IOException {
        final CSVFormat withHeader = newFormatBuilder().setHeader(new String[] { "a", "b" }).build();
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, withHeader);
        assertEquals("a,b\n", sw.toString());
        assertEquals(0L, printer.getRecordCount());
        printer.close();
    }

    @Test
    public void getOutReturnsSameAppendable() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, plainFormat());
        assertSame(sw, printer.getOut());
        printer.close();
    }

    @Test
    public void recordCountStartsAtZero() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, plainFormat());
        assertEquals(0L, printer.getRecordCount());
        printer.close();
    }

    // ---------------------------------------------------------------
    // print / println
    // ---------------------------------------------------------------

    @Test
    public void printDoesNotAddRecordSeparatorOrIncrementRecordCount() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, plainFormat());
        printer.print("value");
        assertEquals("value", sw.toString());
        assertEquals(0L, printer.getRecordCount());
        printer.close();
    }

    @Test
    public void printlnWritesOnlyRecordSeparator() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, plainFormat());
        printer.print("value");
        printer.println();
        assertEquals("value\n", sw.toString());
        assertEquals(0L, printer.getRecordCount());
        printer.close();
    }

    @Test
    public void printThrowsIOExceptionFromUnderlyingStream() throws IOException {
        final ThrowingAppendable throwing = new ThrowingAppendable();
        final CSVPrinter printer = new CSVPrinter(throwing, plainFormat());
        assertThrows(IOException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                printer.print("value");
            }
        });
    }

    // ---------------------------------------------------------------
    // printRecord
    // ---------------------------------------------------------------

    @Test
    public void printRecordObjectArrayQuotesValueContainingDelimiter() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, plainFormat());
        printer.printRecord(new Object[] { "a,b", "c" });
        assertEquals("\"a,b\",c\n", sw.toString());
        assertEquals(1L, printer.getRecordCount());
        printer.close();
    }

    @Test
    public void printRecordDoublesEmbeddedQuoteCharacters() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, plainFormat());
        printer.printRecord(new Object[] { "he said \"hi\"" });
        assertEquals("\"he said \"\"hi\"\"\"\n", sw.toString());
        assertEquals(1L, printer.getRecordCount());
        printer.close();
    }

    @Test
    public void printRecordWithNoValuesStillWritesSeparatorAndCountsRecord() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, plainFormat());
        printer.printRecord(new Object[0]);
        assertEquals("\n", sw.toString());
        assertEquals(1L, printer.getRecordCount());
        printer.close();
    }

    @Test
    public void printRecordIterableIncrementsRecordCount() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, plainFormat());
        final List<String> values = new ArrayList<String>();
        values.add("x");
        values.add("y");
        printer.printRecord(values);
        assertEquals("x,y\n", sw.toString());
        assertEquals(1L, printer.getRecordCount());
        printer.close();
    }

    @Test
    public void printRecordStreamIncrementsRecordCount() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, plainFormat());
        final List<String> values = new ArrayList<String>();
        values.add("x");
        values.add("y");
        printer.printRecord(values.stream());
        assertEquals("x,y\n", sw.toString());
        assertEquals(1L, printer.getRecordCount());
        printer.close();
    }

    @Test
    public void printRecordThrowsIOExceptionFromUnderlyingStream() {
        final ThrowingAppendable throwing = new ThrowingAppendable();
        assertThrows(IOException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                final CSVPrinter printer = new CSVPrinter(throwing, plainFormat());
                printer.printRecord(new Object[] { "value" });
            }
        });
    }

    // ---------------------------------------------------------------
    // printRecords
    // ---------------------------------------------------------------

    @Test
    public void printRecordsObjectArrayOfSimpleValuesIsSingleRecord() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, plainFormat());
        printer.printRecords(new Object[] { "A", "B", "C" });
        assertEquals("A,B,C\n", sw.toString());
        assertEquals(1L, printer.getRecordCount());
        printer.close();
    }

    @Test
    public void printRecordsObjectArrayOfNestedArraysIsMultipleRecords() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, plainFormat());
        printer.printRecords(new Object[] { new String[] { "A", "B" }, new String[] { "1", "2" } });
        assertEquals("A,B\n1,2\n", sw.toString());
        assertEquals(2L, printer.getRecordCount());
        printer.close();
    }

    @Test
    public void printRecordsIterableOfNestedCollectionsIsMultipleRecords() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, plainFormat());
        final List<String[]> data = new ArrayList<String[]>();
        data.add(new String[] { "A", "B", "C" });
        data.add(new String[] { "1", "2", "3" });
        printer.printRecords(data);
        assertEquals("A,B,C\n1,2,3\n", sw.toString());
        assertEquals(2L, printer.getRecordCount());
        printer.close();
    }

    @Test
    public void printRecordsStreamOfNestedArraysIsMultipleRecords() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, plainFormat());
        final List<String[]> data = new ArrayList<String[]>();
        data.add(new String[] { "A", "B" });
        data.add(new String[] { "1", "2" });
        printer.printRecords(data.stream());
        assertEquals("A,B\n1,2\n", sw.toString());
        assertEquals(2L, printer.getRecordCount());
        printer.close();
    }

    // ---------------------------------------------------------------
    // printComment
    // ---------------------------------------------------------------

    @Test
    public void printCommentDoesNothingWhenCommentsDisabled() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, plainFormat());
        printer.printComment("a comment");
        assertEquals("", sw.toString());
        assertEquals(0L, printer.getRecordCount());
        printer.close();
    }

    @Test
    public void printCommentWritesMarkerAndSpaceWhenEnabled() throws IOException {
        final CSVFormat commented = newFormatBuilder().setCommentMarker(Character.valueOf('#')).build();
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, commented);
        printer.printComment("hello");
        assertEquals("# hello\n", sw.toString());
        assertEquals(0L, printer.getRecordCount());
        printer.close();
    }

    @Test
    public void printCommentSplitsOnEmbeddedLineBreaks() throws IOException {
        final CSVFormat commented = newFormatBuilder().setCommentMarker(Character.valueOf('#')).build();
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, commented);
        printer.printComment("line1\nline2");
        assertEquals("# line1\n# line2\n", sw.toString());
        printer.close();
    }

    @Test
    public void printCommentStartsOnNewLineAfterPendingValue() throws IOException {
        final CSVFormat commented = newFormatBuilder().setCommentMarker(Character.valueOf('#')).build();
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, commented);
        printer.print("value");
        printer.printComment("c");
        assertEquals("value\n# c\n", sw.toString());
        printer.close();
    }

    // ---------------------------------------------------------------
    // flush / close
    // ---------------------------------------------------------------

    @Test
    public void flushFlushesUnderlyingStream() throws IOException {
        final CountingWriter writer = new CountingWriter();
        final CSVPrinter printer = new CSVPrinter(writer, plainFormat());
        printer.flush();
        assertTrue(writer.flushCount > 0);
        printer.close();
    }

    @Test
    public void closeClosesUnderlyingStream() throws IOException {
        final CountingWriter writer = new CountingWriter();
        final CSVPrinter printer = new CSVPrinter(writer, plainFormat());
        printer.close();
        assertEquals(1, writer.closeCount);
    }

    @Test
    public void closeWithFlushTrueFlushesBeforeClosing() throws IOException {
        final CountingWriter writer = new CountingWriter();
        final CSVPrinter printer = new CSVPrinter(writer, plainFormat());
        printer.close(true);
        assertTrue(writer.flushCount > 0);
        assertEquals(1, writer.closeCount);
    }

    @Test
    public void closeWithFlushFalseDoesNotFlush() throws IOException {
        final CountingWriter writer = new CountingWriter();
        final CSVPrinter printer = new CSVPrinter(writer, plainFormat());
        printer.close(false);
        assertEquals(0, writer.flushCount);
        assertEquals(1, writer.closeCount);
    }

    // ---------------------------------------------------------------
    // JDBC ResultSet based methods
    // ---------------------------------------------------------------

    @Test
    public void printHeadersWritesColumnLabelsAndDoesNotCountAsRecord() throws Exception {
        final ResultSet rs = newFakeResultSet(new String[] { "id", "name" }, new Object[0][0]);
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, plainFormat());
        printer.printHeaders(rs);
        assertEquals("id,name\n", sw.toString());
        assertEquals(0L, printer.getRecordCount());
        printer.close();
    }

    @Test
    public void printRecordsResultSetWritesEachRowAsRecordWithoutHeader() throws Exception {
        final ResultSet rs = newFakeResultSet(new String[] { "id", "name" },
                new Object[][] { { "1", "john" }, { "2", "mary" } });
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, plainFormat());
        printer.printRecords(rs);
        assertEquals("1,john\n2,mary\n", sw.toString());
        assertEquals(2L, printer.getRecordCount());
        printer.close();
    }

    @Test
    public void printRecordsResultSetWithHeaderTrueWritesHeaderThenRows() throws Exception {
        final ResultSet rs = newFakeResultSet(new String[] { "id", "name" },
                new Object[][] { { "1", "john" } });
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, plainFormat());
        printer.printRecords(rs, true);
        assertEquals("id,name\n1,john\n", sw.toString());
        assertEquals(1L, printer.getRecordCount());
        printer.close();
    }

    @Test
    public void printRecordsResultSetWithHeaderFalseOmitsHeader() throws Exception {
        final ResultSet rs = newFakeResultSet(new String[] { "id", "name" },
                new Object[][] { { "1", "john" } });
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, plainFormat());
        printer.printRecords(rs, false);
        assertEquals("1,john\n", sw.toString());
        assertEquals(1L, printer.getRecordCount());
        printer.close();
    }

    @Test
    public void printRecordsResultSetWithNoRowsWritesNothingAndCountsZero() throws Exception {
        final ResultSet rs = newFakeResultSet(new String[] { "id", "name" }, new Object[0][0]);
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, plainFormat());
        printer.printRecords(rs);
        assertEquals("", sw.toString());
        assertEquals(0L, printer.getRecordCount());
        assertFalse(sw.toString().length() > 0);
        printer.close();
    }
}
