/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link WordUtils}.
 */
class WordUtilsAgentTest {

    @Test
    void testCapitalizeNullAndEmpty() {
        assertNull(WordUtils.capitalize(null));
        assertEquals("", WordUtils.capitalize(""));
    }

    @Test
    void testCapitalizeDefault() {
        assertEquals("I Am FINE", WordUtils.capitalize("i am FINE"));
        assertEquals("Single", WordUtils.capitalize("single"));
        assertEquals(" Leading Space", WordUtils.capitalize(" leading space"));
    }

    @Test
    void testCapitalizeWithDelimiters() {
        assertEquals("I Am Fine", WordUtils.capitalize("i am fine", (char[]) null));
        assertEquals("I aM.Fine", WordUtils.capitalize("i aM.fine", '.'));
        // empty delimiter array means no delimiters at all -> only first char capitalized
        final String original = "i am fine";
        assertSame(original, WordUtils.capitalize(original, new char[0]));
    }

    @Test
    void testCapitalizeFullyNullAndEmpty() {
        assertNull(WordUtils.capitalizeFully(null));
        assertEquals("", WordUtils.capitalizeFully(""));
    }

    @Test
    void testCapitalizeFullyDefault() {
        assertEquals("I Am Fine", WordUtils.capitalizeFully("i am FINE"));
    }

    @Test
    void testCapitalizeFullyWithDelimiters() {
        assertEquals("I Am.fine", WordUtils.capitalizeFully("i aM.fine", ' '));
        assertEquals("I am.Fine", WordUtils.capitalizeFully("i aM.fine", '.'));
        final String original = "i aM.fine";
        assertSame(original, WordUtils.capitalizeFully(original, new char[0]));
    }

    @Test
    void testContainsAllWords() {
        assertTrue(!WordUtils.containsAllWords(null, "ab"));
        assertTrue(!WordUtils.containsAllWords("", "ab"));
        assertTrue(!WordUtils.containsAllWords("abcd", (CharSequence[]) null));
        assertTrue(!WordUtils.containsAllWords("abcd", new CharSequence[0]));
        assertTrue(!WordUtils.containsAllWords("abcd", "ab", "cd"));
        assertTrue(WordUtils.containsAllWords("abc def", "def", "abc"));
        // a blank search word means the overall result is false
        assertTrue(!WordUtils.containsAllWords("abc def", "abc", " "));
    }

    @Test
    void testInitialsNullAndEmpty() {
        assertNull(WordUtils.initials(null));
        assertEquals("", WordUtils.initials(""));
    }

    @Test
    void testInitialsDefault() {
        assertEquals("BJL", WordUtils.initials("Ben John Lee"));
        assertEquals("BJ", WordUtils.initials("Ben J.Lee"));
    }

    @Test
    void testInitialsWithDelimiters() {
        assertEquals("BJL", WordUtils.initials("Ben John Lee", (char[]) null));
        assertEquals("BJL", WordUtils.initials("Ben J.Lee", new char[] {' ', '.'}));
        assertEquals("", WordUtils.initials("Ben John Lee", new char[0]));
    }

    @Test
    void testInitialsSupplementaryCharacters() {
        // high/low surrogate pair at the start of a word must be kept together
        final String highLow = "𐌀 abc";
        assertEquals("𐌀a", WordUtils.initials(highLow));
    }

    @Test
    void testSwapCaseNullAndEmpty() {
        assertNull(WordUtils.swapCase(null));
        assertEquals("", WordUtils.swapCase(""));
    }

    @Test
    void testSwapCaseDefault() {
        assertEquals("tHE DOG HAS A bone", WordUtils.swapCase("The dog has a BONE"));
    }

    @Test
    void testUncapitalizeNullAndEmpty() {
        assertNull(WordUtils.uncapitalize(null));
        assertEquals("", WordUtils.uncapitalize(""));
    }

    @Test
    void testUncapitalizeDefault() {
        assertEquals("i am fINE", WordUtils.uncapitalize("I Am FINE"));
    }

    @Test
    void testUncapitalizeWithDelimiters() {
        assertEquals("i AM.fINE", WordUtils.uncapitalize("I AM.FINE", '.'));
        final String original = "I AM.FINE";
        assertSame(original, WordUtils.uncapitalize(original, new char[0]));
        assertEquals("i aM.FINE", WordUtils.uncapitalize(original, (char[]) null));
    }

    @Test
    void testWrapNull() {
        assertNull(WordUtils.wrap(null, 20));
    }

    @Test
    void testWrapEmpty() {
        assertEquals("", WordUtils.wrap("", 20));
    }

    @Test
    void testWrapBasic() {
        final String input = "Here is one line of text that is going to be wrapped after 20 columns.";
        final String expected = "Here is one line of" + System.lineSeparator()
                + "text that is going" + System.lineSeparator()
                + "to be wrapped after" + System.lineSeparator()
                + "20 columns.";
        assertEquals(expected, WordUtils.wrap(input, 20));
    }

    @Test
    void testWrapLengthLessThanOneTreatedAsOne() {
        final String result = WordUtils.wrap("abc", 0);
        assertEquals("abc", result);
    }

    @Test
    void testWrapWithNewLineStringAndLongWordNotWrapped() {
        final String input = "Click here to jump to the commons website - https://commons.apache.org";
        final String expected = "Click here to jump\nto the commons\nwebsite -\nhttps://commons.apache.org";
        assertEquals(expected, WordUtils.wrap(input, 20, "\n", false));
    }

    @Test
    void testWrapWithLongWordsWrapped() {
        final String input = "Click here to jump to the commons website - https://commons.apache.org";
        final String expected = "Click here to jump\nto the commons\nwebsite -\nhttps://commons.apac\nhe.org";
        assertEquals(expected, WordUtils.wrap(input, 20, "\n", true));
    }

    @Test
    void testWrapOnCustomRegex() {
        final String input = "flammable/inflammable";
        assertEquals("flammable\ninflammable", WordUtils.wrap(input, 20, "\n", true, "/"));
    }

    @Test
    void testWrapOnBlankUsesSpace() {
        final String input = "abcd efgh ijkl";
        assertEquals(WordUtils.wrap(input, 5, "\n", false), WordUtils.wrap(input, 5, "\n", false, ""));
    }

    @Test
    void testConstructorIsPublic() {
        assertTrue(new WordUtils() != null);
    }
}
