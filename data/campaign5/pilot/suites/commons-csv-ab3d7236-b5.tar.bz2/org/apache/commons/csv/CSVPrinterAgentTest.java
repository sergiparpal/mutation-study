/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.Closeable;
import java.io.Flushable;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link CSVPrinter}.
 */
class CSVPrinterAgentTest {

    /** An Appendable that is both Closeable and Flushable, tracking calls to each. */
    private static final class TrackingAppendable implements Appendable, Closeable, Flushable {
        private final StringBuilder sb = new StringBuilder();
        private boolean flushed;
        private boolean closed;

        @Override
        public Appendable append(final CharSequence csq) throws IOException {
            sb.append(csq);
            return this;
        }

        @Override
        public Appendable append(final CharSequence csq, final int start, final int end) throws IOException {
            sb.append(csq, start, end);
            return this;
        }

        @Override
        public Appendable append(final char c) throws IOException {
            sb.append(c);
            return this;
        }

        @Override
        public void flush() throws IOException {
            flushed = true;
        }

        @Override
        public void close() throws IOException {
            closed = true;
        }

        @Override
        public String toString() {
            return sb.toString();
        }
    }

    /** A plain Appendable that is neither Closeable nor Flushable. */
    private static final class PlainAppendable implements Appendable {
        private final StringBuilder sb = new StringBuilder();

        @Override
        public Appendable append(final CharSequence csq) throws IOException {
            sb.append(csq);
            return this;
        }

        @Override
        public Appendable append(final CharSequence csq, final int start, final int end) throws IOException {
            sb.append(csq, start, end);
            return this;
        }

        @Override
        public Appendable append(final char c) throws IOException {
            sb.append(c);
            return this;
        }

        @Override
        public String toString() {
            return sb.toString();
        }
    }

    // --- Constructor ---

    @Test
    void constructorThrowsOnNullAppendable() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new CSVPrinter(null, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    void constructorThrowsOnNullFormat() {
        final StringBuilder sb = new StringBuilder();
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new CSVPrinter(sb, null);
            }
        });
    }

    @Test
    void constructorWithHeaderPrintsHeaderImmediately() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "b").get();
        final CSVPrinter printer = new CSVPrinter(sb, format);
        assertEquals("a,b\r\n", sb.toString());
        // The header is printed via printRecord internally, so it counts.
        assertEquals(1, printer.getRecordCount());
    }

    @Test
    void constructorWithHeaderAndSkipHeaderRecordDoesNotPrintHeader() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "b").setSkipHeaderRecord(true).get();
        new CSVPrinter(sb, format);
        assertEquals("", sb.toString());
    }

    @Test
    void constructorWithHeaderCommentsPrintsComments() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').setHeaderComments("comment1", "comment2").get();
        new CSVPrinter(sb, format);
        assertEquals("# comment1\r\n# comment2\r\n", sb.toString());
    }

    // --- print ---

    @Test
    void printSimpleValue() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("value");
        assertEquals("value", sb.toString());
    }

    @Test
    void printValueContainingDelimiterGetsQuoted() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("a,b");
        assertEquals("\"a,b\"", sb.toString());
    }

    @Test
    void printNullValueUsesConfiguredNullString() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        final CSVPrinter printer = new CSVPrinter(sb, format);
        printer.print(null);
        assertEquals("NULL", sb.toString());
    }

    @Test
    void printNullValueWithoutNullStringPrintsEmpty() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print(null);
        assertEquals("", sb.toString());
    }

    // --- printComment ---

    @Test
    void printCommentWithoutCommentMarkerIsNoOp() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printComment("this is a comment");
        assertEquals("", sb.toString());
    }

    @Test
    void printCommentWithNullCommentIsNoOp() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVPrinter printer = new CSVPrinter(sb, format);
        printer.printComment(null);
        assertEquals("", sb.toString());
    }

    @Test
    void printCommentWritesMarkerAndText() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVPrinter printer = new CSVPrinter(sb, format);
        printer.printComment("hello");
        assertEquals("# hello\r\n", sb.toString());
    }

    @Test
    void printCommentWithEmbeddedNewlineSplitsIntoMultipleLines() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVPrinter printer = new CSVPrinter(sb, format);
        printer.printComment("line1\nline2");
        assertEquals("# line1\r\n# line2\r\n", sb.toString());
    }

    @Test
    void printCommentWithEmbeddedCRLFDoesNotProduceBlankLine() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVPrinter printer = new CSVPrinter(sb, format);
        printer.printComment("line1\r\nline2");
        assertEquals("# line1\r\n# line2\r\n", sb.toString());
    }

    @Test
    void printCommentAfterPartialRecordStartsOnNewLine() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVPrinter printer = new CSVPrinter(sb, format);
        printer.print("value");
        printer.printComment("hello");
        assertEquals("value\r\n# hello\r\n", sb.toString());
    }

    // --- println / getRecordCount ---

    @Test
    void getRecordCountInitiallyZero() throws IOException {
        final CSVPrinter printer = new CSVPrinter(new StringBuilder(), CSVFormat.DEFAULT);
        assertEquals(0, printer.getRecordCount());
    }

    @Test
    void printlnDoesNotIncrementRecordCount() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.println();
        assertEquals("\r\n", sb.toString());
        assertEquals(0, printer.getRecordCount());
    }

    // --- printRecord ---

    @Test
    void printRecordVarargsIncrementsRecordCount() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord("a", "b", "c");
        assertEquals("a,b,c\r\n", sb.toString());
        assertEquals(1, printer.getRecordCount());
        printer.printRecord("d", "e");
        assertEquals("a,b,c\r\nd,e\r\n", sb.toString());
        assertEquals(2, printer.getRecordCount());
    }

    @Test
    void printRecordWithEmptyVarargsStillWritesRecordSeparator() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord();
        assertEquals("\r\n", sb.toString());
        assertEquals(1, printer.getRecordCount());
    }

    @Test
    void printRecordIterable() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        final List<String> values = new ArrayList<String>();
        values.add("x");
        values.add("y");
        printer.printRecord(values);
        assertEquals("x,y\r\n", sb.toString());
        assertEquals(1, printer.getRecordCount());
    }

    @Test
    void printRecordStream() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord(Arrays.asList("p", "q").stream());
        assertEquals("p,q\r\n", sb.toString());
        assertEquals(1, printer.getRecordCount());
    }

    // --- printRecords ---

    @Test
    void printRecordsIterableWithNestedArraysPrintsMultipleRecords() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        final List<String[]> data = new ArrayList<String[]>();
        data.add(new String[] { "A", "B" });
        data.add(new String[] { "1", "2" });
        printer.printRecords(data);
        assertEquals("A,B\r\n1,2\r\n", sb.toString());
        assertEquals(2, printer.getRecordCount());
    }

    @Test
    void printRecordsObjectVarargsWithSimpleValuesPrintsOneRecordPerValue() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        // Simple (non-array, non-Iterable) elements are each printed as their own single-value record.
        printer.printRecords("A", "B", "C");
        assertEquals("A\r\nB\r\nC\r\n", sb.toString());
        assertEquals(3, printer.getRecordCount());
    }

    @Test
    void printRecordsObjectVarargsWithNestedArraysPrintsMultipleRecords() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecords((Object) new String[] { "A", "B" }, new String[] { "1", "2" });
        assertEquals("A,B\r\n1,2\r\n", sb.toString());
        assertEquals(2, printer.getRecordCount());
    }

    @Test
    void printRecordsStream() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        final List<String[]> data = new ArrayList<String[]>();
        data.add(new String[] { "A", "B" });
        data.add(new String[] { "1", "2" });
        printer.printRecords(data.stream());
        assertEquals("A,B\r\n1,2\r\n", sb.toString());
        assertEquals(2, printer.getRecordCount());
    }

    // --- printHeaders / printRecords(ResultSet) ---

    @Test
    void printHeadersWritesColumnLabels() throws IOException, SQLException {
        final ResultSet resultSet = mock(ResultSet.class);
        final ResultSetMetaData metaData = mock(ResultSetMetaData.class);
        when(resultSet.getMetaData()).thenReturn(metaData);
        when(metaData.getColumnCount()).thenReturn(2);
        when(metaData.getColumnLabel(1)).thenReturn("col1");
        when(metaData.getColumnLabel(2)).thenReturn("col2");

        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printHeaders(resultSet);
        assertEquals("col1,col2\r\n", sb.toString());
        assertEquals(0, printer.getRecordCount());
    }

    @Test
    void printRecordsResultSetWritesEachRowAsRecord() throws IOException, SQLException {
        final ResultSet resultSet = mock(ResultSet.class);
        final ResultSetMetaData metaData = mock(ResultSetMetaData.class);
        when(resultSet.getMetaData()).thenReturn(metaData);
        when(metaData.getColumnCount()).thenReturn(2);
        when(resultSet.next()).thenReturn(true, true, false);
        when(resultSet.getRow()).thenReturn(1, 2);
        when(resultSet.getObject(1)).thenReturn("r1c1", "r2c1");
        when(resultSet.getObject(2)).thenReturn("r1c2", "r2c2");

        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecords(resultSet);
        assertEquals("r1c1,r1c2\r\nr2c1,r2c2\r\n", sb.toString());
        assertEquals(2, printer.getRecordCount());
    }

    @Test
    void printRecordsResultSetWithPrintHeaderTruePrintsHeadersFirst() throws IOException, SQLException {
        final ResultSet resultSet = mock(ResultSet.class);
        final ResultSetMetaData metaData = mock(ResultSetMetaData.class);
        when(resultSet.getMetaData()).thenReturn(metaData);
        when(metaData.getColumnCount()).thenReturn(1);
        when(metaData.getColumnLabel(1)).thenReturn("name");
        when(resultSet.next()).thenReturn(true, false);
        when(resultSet.getRow()).thenReturn(1);
        when(resultSet.getObject(1)).thenReturn("value1");

        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecords(resultSet, true);
        assertEquals("name\r\nvalue1\r\n", sb.toString());
        assertEquals(1, printer.getRecordCount());
    }

    @Test
    void printRecordsResultSetWithPrintHeaderFalseSkipsHeaders() throws IOException, SQLException {
        final ResultSet resultSet = mock(ResultSet.class);
        final ResultSetMetaData metaData = mock(ResultSetMetaData.class);
        when(resultSet.getMetaData()).thenReturn(metaData);
        when(metaData.getColumnCount()).thenReturn(1);
        when(resultSet.next()).thenReturn(true, false);
        when(resultSet.getRow()).thenReturn(1);
        when(resultSet.getObject(1)).thenReturn("value1");

        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecords(resultSet, false);
        assertEquals("value1\r\n", sb.toString());
        assertEquals(1, printer.getRecordCount());
    }

    // --- getOut ---

    @Test
    void getOutReturnsTheOriginalAppendable() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        assertSame(sb, printer.getOut());
    }

    // --- flush ---

    @Test
    void flushDelegatesToFlushableAppendable() throws IOException {
        final TrackingAppendable appendable = new TrackingAppendable();
        final CSVPrinter printer = new CSVPrinter(appendable, CSVFormat.DEFAULT);
        assertFalse(appendable.flushed);
        printer.flush();
        assertTrue(appendable.flushed);
    }

    @Test
    void flushOnNonFlushableAppendableDoesNotThrow() throws IOException {
        final PlainAppendable appendable = new PlainAppendable();
        final CSVPrinter printer = new CSVPrinter(appendable, CSVFormat.DEFAULT);
        printer.flush();
    }

    // --- close ---

    @Test
    void closeClosesUnderlyingCloseableAppendable() throws IOException {
        final TrackingAppendable appendable = new TrackingAppendable();
        final CSVPrinter printer = new CSVPrinter(appendable, CSVFormat.DEFAULT);
        printer.close();
        assertTrue(appendable.closed);
    }

    @Test
    void closeWithoutAutoFlushDoesNotFlush() throws IOException {
        final TrackingAppendable appendable = new TrackingAppendable();
        final CSVPrinter printer = new CSVPrinter(appendable, CSVFormat.DEFAULT);
        printer.close();
        assertFalse(appendable.flushed);
        assertTrue(appendable.closed);
    }

    @Test
    void closeWithExplicitFlushTrueFlushesRegardlessOfAutoFlush() throws IOException {
        final TrackingAppendable appendable = new TrackingAppendable();
        final CSVPrinter printer = new CSVPrinter(appendable, CSVFormat.DEFAULT);
        printer.close(true);
        assertTrue(appendable.flushed);
        assertTrue(appendable.closed);
    }

    @Test
    void closeWithAutoFlushFormatFlushesEvenWithoutExplicitFlush() throws IOException {
        final TrackingAppendable appendable = new TrackingAppendable();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setAutoFlush(true).get();
        final CSVPrinter printer = new CSVPrinter(appendable, format);
        printer.close(false);
        assertTrue(appendable.flushed);
    }

    @Test
    void closeOnNonCloseableAppendableDoesNotThrow() throws IOException {
        final PlainAppendable appendable = new PlainAppendable();
        final CSVPrinter printer = new CSVPrinter(appendable, CSVFormat.DEFAULT);
        printer.close();
    }
}
