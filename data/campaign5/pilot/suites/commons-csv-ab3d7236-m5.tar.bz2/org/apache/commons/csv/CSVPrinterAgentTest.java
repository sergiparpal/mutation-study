/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link CSVPrinter}.
 */
class CSVPrinterAgentTest {

    /**
     * Minimal stub ResultSet implementation used instead of a mocking library so the test stays self-contained.
     */
    private static final class StubResultSet implements java.lang.reflect.InvocationHandler {
        private final List<Object[]> rows;
        private final String[] columnLabels;
        private int rowIndex = -1;

        StubResultSet(final String[] columnLabels, final List<Object[]> rows) {
            this.columnLabels = columnLabels;
            this.rows = rows;
        }

        @Override
        public Object invoke(final Object proxy, final java.lang.reflect.Method method, final Object[] args) throws Throwable {
            final String name = method.getName();
            if ("getMetaData".equals(name)) {
                return newMetaDataProxy();
            }
            if ("next".equals(name)) {
                rowIndex++;
                return rowIndex < rows.size();
            }
            if ("getRow".equals(name)) {
                return rowIndex + 1;
            }
            if ("getObject".equals(name)) {
                final int col = ((Integer) args[0]).intValue();
                return rows.get(rowIndex)[col - 1];
            }
            if ("getColumnCount".equals(name)) {
                return columnLabels.length;
            }
            if ("getColumnLabel".equals(name)) {
                final int col = ((Integer) args[0]).intValue();
                return columnLabels[col - 1];
            }
            if ("hashCode".equals(name)) {
                return Integer.valueOf(System.identityHashCode(proxy));
            }
            if ("equals".equals(name)) {
                return Boolean.valueOf(proxy == args[0]);
            }
            if ("toString".equals(name)) {
                return "StubResultSet";
            }
            throw new UnsupportedOperationException(name);
        }

        private Object newMetaDataProxy() {
            return java.lang.reflect.Proxy.newProxyInstance(getClass().getClassLoader(), new Class[] { ResultSetMetaData.class }, this);
        }

        ResultSet newProxy() {
            return (ResultSet) java.lang.reflect.Proxy.newProxyInstance(getClass().getClassLoader(), new Class[] { ResultSet.class }, this);
        }
    }

    @Test
    void constructorNullAppendableThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new CSVPrinter(null, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    void constructorNullFormatThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new CSVPrinter(new StringWriter(), null);
            }
        });
    }

    @Test
    void constructorPrintsHeaderWhenNotSkipped() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("A", "B").get();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        assertEquals("A,B\r\n", sw.toString());
        assertEquals(1, printer.getRecordCount());
        printer.close();
    }

    @Test
    void constructorSkipsHeaderWhenRequested() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("A", "B").setSkipHeaderRecord(true).get();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        assertEquals("", sw.toString());
        printer.close();
    }

    @Test
    void constructorPrintsHeaderComments() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').setHeaderComments("line one", "line two").get();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        assertEquals("# line one\r\n# line two\r\n", sw.toString());
        printer.close();
    }

    @Test
    void getOutReturnsSameAppendable() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        assertSame(sw, printer.getOut());
        printer.close();
    }

    @Test
    void printSimpleValue() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("a");
        printer.print("b");
        assertEquals("a,b", sw.toString());
        printer.close();
    }

    @Test
    void printValueNeedingQuoting() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("a,b");
        assertEquals("\"a,b\"", sw.toString());
        printer.close();
    }

    @Test
    void printNullValue() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print(null);
        assertEquals("", sw.toString());
        printer.close();
    }

    @Test
    void printlnWritesSeparatorOnly() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.println();
        assertEquals("\r\n", sw.toString());
        assertEquals(0, printer.getRecordCount());
        printer.close();
    }

    @Test
    void printCommentNullIsNoOp() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printComment(null);
        assertEquals("", sw.toString());
        printer.close();
    }

    @Test
    void printCommentWithoutMarkerIsNoOp() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printComment("hello");
        assertEquals("", sw.toString());
        printer.close();
    }

    @Test
    void printCommentWithMultipleLines() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printComment("line1\nline2\r\nline3");
        assertEquals("# line1\r\n# line2\r\n# line3\r\n", sw.toString());
        printer.close();
    }

    @Test
    void printRecordVarargs() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecord("a", "b", "c");
        assertEquals("a,b,c\r\n", sw.toString());
        assertEquals(1, printer.getRecordCount());
        printer.close();
    }

    @Test
    void printRecordEmptyVarargsStillTerminatesRecord() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecord();
        assertEquals("\r\n", sw.toString());
        assertEquals(1, printer.getRecordCount());
        printer.close();
    }

    @Test
    void printRecordIterable() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecord(Arrays.asList("x", "y"));
        assertEquals("x,y\r\n", sw.toString());
        assertEquals(1, printer.getRecordCount());
        printer.close();
    }

    @Test
    void printRecordStream() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecord(Arrays.asList("p", "q").stream());
        assertEquals("p,q\r\n", sw.toString());
        assertEquals(1, printer.getRecordCount());
        printer.close();
    }

    @Test
    void printRecordsObjectArrayFlatElementsEachBecomeOwnRecord() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecords(new Object[] { "a", "b" });
        assertEquals("a\r\nb\r\n", sw.toString());
        assertEquals(2, printer.getRecordCount());
        printer.close();
    }

    @Test
    void printRecordsNestedArraysProduceMultipleRecords() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final String[][] data = new String[3][];
        data[0] = new String[] { "A", "B", "C" };
        data[1] = new String[] { "1", "2", "3" };
        data[2] = new String[] { "A1", "B2", "C3" };
        printer.printRecords((Object[]) data);
        assertEquals("A,B,C\r\n1,2,3\r\nA1,B2,C3\r\n", sw.toString());
        assertEquals(3, printer.getRecordCount());
        printer.close();
    }

    @Test
    void printRecordsIterableOfIterables() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final List<List<String>> data = new ArrayList<List<String>>();
        data.add(Arrays.asList("A", "B"));
        data.add(Arrays.asList("1", "2"));
        printer.printRecords(data);
        assertEquals("A,B\r\n1,2\r\n", sw.toString());
        assertEquals(2, printer.getRecordCount());
        printer.close();
    }

    @Test
    void printRecordsStream() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final List<String[]> data = new ArrayList<String[]>();
        data.add(new String[] { "A", "B" });
        data.add(new String[] { "1", "2" });
        printer.printRecords(data.stream());
        assertEquals("A,B\r\n1,2\r\n", sw.toString());
        assertEquals(2, printer.getRecordCount());
        printer.close();
    }

    @Test
    void closeWithoutFlushDoesNotFlushByDefault() throws IOException {
        final NoAutoFlushTrackingWriter writer = new NoAutoFlushTrackingWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        printer.print("a");
        printer.close();
        assertTrue(writer.closed);
        assertFalse(writer.flushed);
    }

    @Test
    void closeWithExplicitFlushTrueFlushesFirst() throws IOException {
        final NoAutoFlushTrackingWriter writer = new NoAutoFlushTrackingWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        printer.print("a");
        printer.close(true);
        assertTrue(writer.flushed);
        assertTrue(writer.closed);
    }

    @Test
    void closeHonorsFormatAutoFlush() throws IOException {
        final NoAutoFlushTrackingWriter writer = new NoAutoFlushTrackingWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setAutoFlush(true).get();
        final CSVPrinter printer = new CSVPrinter(writer, format);
        printer.print("a");
        printer.close();
        assertTrue(writer.flushed);
    }

    @Test
    void flushDelegatesToFlushableAppendable() throws IOException {
        final NoAutoFlushTrackingWriter writer = new NoAutoFlushTrackingWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        assertFalse(writer.flushed);
        printer.flush();
        assertTrue(writer.flushed);
        writer.close();
    }

    @Test
    void printHeadersFromResultSetMetaData() throws IOException, SQLException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final StubResultSet stub = new StubResultSet(new String[] { "ID", "NAME" }, new ArrayList<Object[]>());
        printer.printHeaders(stub.newProxy());
        assertEquals("ID,NAME\r\n", sw.toString());
        assertEquals(0, printer.getRecordCount());
        printer.close();
    }

    @Test
    void printRecordsFromResultSet() throws IOException, SQLException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final List<Object[]> rows = new ArrayList<Object[]>();
        rows.add(new Object[] { Integer.valueOf(1), "john" });
        rows.add(new Object[] { Integer.valueOf(2), "mary" });
        final StubResultSet stub = new StubResultSet(new String[] { "ID", "NAME" }, rows);
        printer.printRecords(stub.newProxy());
        assertEquals("1,john\r\n2,mary\r\n", sw.toString());
        assertEquals(2, printer.getRecordCount());
        printer.close();
    }

    @Test
    void printRecordsFromResultSetWithHeaderTrue() throws IOException, SQLException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final List<Object[]> rows = new ArrayList<Object[]>();
        rows.add(new Object[] { Integer.valueOf(1), "john" });
        final StubResultSet stub = new StubResultSet(new String[] { "ID", "NAME" }, rows);
        printer.printRecords(stub.newProxy(), true);
        assertEquals("ID,NAME\r\n1,john\r\n", sw.toString());
        assertEquals(1, printer.getRecordCount());
        printer.close();
    }

    @Test
    void printRecordsFromResultSetWithHeaderFalseSkipsHeader() throws IOException, SQLException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final List<Object[]> rows = new ArrayList<Object[]>();
        rows.add(new Object[] { Integer.valueOf(1), "john" });
        final StubResultSet stub = new StubResultSet(new String[] { "ID", "NAME" }, rows);
        printer.printRecords(stub.newProxy(), false);
        assertEquals("1,john\r\n", sw.toString());
        printer.close();
    }

    @Test
    void printRecordsFromResultSetHonorsMaxRows() throws IOException, SQLException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(1).get();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        final List<Object[]> rows = new ArrayList<Object[]>();
        rows.add(new Object[] { Integer.valueOf(1), "john" });
        rows.add(new Object[] { Integer.valueOf(2), "mary" });
        final StubResultSet stub = new StubResultSet(new String[] { "ID", "NAME" }, rows);
        printer.printRecords(stub.newProxy());
        assertEquals("1,john\r\n", sw.toString());
        assertEquals(1, printer.getRecordCount());
        printer.close();
    }

    /**
     * Writer that is both Closeable and Flushable so close()/flush() state can be observed.
     */
    private static final class NoAutoFlushTrackingWriter extends Writer {
        private final StringWriter delegate = new StringWriter();
        private boolean flushed;
        private boolean closed;

        @Override
        public void write(final char[] cbuf, final int off, final int len) throws IOException {
            delegate.write(cbuf, off, len);
        }

        @Override
        public void flush() throws IOException {
            flushed = true;
        }

        @Override
        public void close() throws IOException {
            closed = true;
        }
    }
}
