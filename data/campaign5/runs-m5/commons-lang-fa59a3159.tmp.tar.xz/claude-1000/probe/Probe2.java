import org.apache.commons.lang3.math.NumberUtils;
import java.math.BigDecimal;
import java.math.RoundingMode;

public class Probe2 {
    public static void main(String[] args) throws Exception {
        System.out.println(NumberUtils.toScaledBigDecimal("1.015"));
        System.out.println(NumberUtils.toScaledBigDecimal("1.025"));
        System.out.println(NumberUtils.toScaledBigDecimal((BigDecimal) null));
        System.out.println(NumberUtils.toScaledBigDecimal((BigDecimal) null).scale());
        System.out.println(NumberUtils.toScaledBigDecimal(new BigDecimal("2.355")));
        System.out.println(NumberUtils.toScaledBigDecimal(new BigDecimal("100"), 2, RoundingMode.UP));
        System.out.println(NumberUtils.isDigits(null));
        System.out.println(NumberUtils.isDigits(""));
        System.out.println(NumberUtils.isDigits("12.3"));
        System.out.println(NumberUtils.isDigits("-123"));
        System.out.println(NumberUtils.isParsable(null));
        System.out.println(NumberUtils.isParsable(""));
        System.out.println(NumberUtils.isParsable("NaN"));
        System.out.println(NumberUtils.isParsable("Infinity"));
        System.out.println(NumberUtils.isCreatable(" "));
        System.out.println(NumberUtils.isCreatable(""));
        System.out.println(NumberUtils.isCreatable(null));
        System.out.println(NumberUtils.createNumber("  "));
    }
}
