import org.apache.commons.lang3.math.NumberUtils;

public class Probe4 {
    public static void main(String[] args) throws Exception {
        System.out.println(NumberUtils.isCreatable("1.2.3"));
        System.out.println(NumberUtils.isCreatable("12x34"));
        System.out.println(NumberUtils.isCreatable("--123"));
        System.out.println(NumberUtils.createNumber("--123"));
    }
}
