import org.apache.commons.lang3.math.NumberUtils;

public class Probe3 {
    public static void main(String[] args) throws Exception {
        System.out.println(NumberUtils.createNumber("0123"));
        System.out.println(NumberUtils.createNumber("-0123"));
        System.out.println(NumberUtils.toDouble((String) null, 9.9d));
        System.out.println(NumberUtils.toInt((String) null, 9));
        System.out.println(NumberUtils.toByte((String) null, (byte) 9));
        System.out.println(NumberUtils.toShort((String) null, (short) 9));
        System.out.println(NumberUtils.toLong((String) null, 9L));
        System.out.println(NumberUtils.toFloat((String) null, 9.9f));
        System.out.println(NumberUtils.min(3.0, Double.NaN, 1.0));
        System.out.println(NumberUtils.min(new double[] {3.0, Double.NaN, 1.0}));
        System.out.println(NumberUtils.max(new float[] {3.0f, Float.NaN, 1.0f}));
    }
}
