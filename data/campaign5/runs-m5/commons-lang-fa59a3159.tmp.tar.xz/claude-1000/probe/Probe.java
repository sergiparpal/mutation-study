import org.apache.commons.lang3.math.NumberUtils;

public class Probe {
    public static void main(String[] args) throws Exception {
        String[] tests = new String[] {"123", "123L", "123.45", "1.2e3", "1.2e3f", "1.2e3d", "0xFF", "0xFFL",
            "077", "-123", "+123", "2147483648", "9223372036854775808", "3.14f", "3.14d",
            "100000000000000000000000000000L", "1.7976931348623157E308", "NaN", "Infinity",
            "0x7fffffff", "0x80000000", "0x7fffffffffffffff", "0x8000000000000000",
            "0x7fffffffffffffffL", "123.0", "0.0", "-0.0", ".5", "5.", "5e10", "5E-10"};
        for (String t : tests) {
            try {
                Number n = NumberUtils.createNumber(t);
                System.out.println(t + " -> " + (n == null ? "null" : n.getClass().getSimpleName() + ":" + n));
            } catch (Exception e) {
                System.out.println(t + " -> EXCEPTION " + e.getClass().getSimpleName() + ": " + e.getMessage());
            }
        }
    }
}
