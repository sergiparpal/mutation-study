/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Random;

import org.junit.jupiter.api.Test;

public class RandomStringUtilsAgentTest {

    private static boolean isAlpha(final String s) {
        for (int i = 0; i < s.length(); i++) {
            if (!Character.isLetter(s.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    private static boolean isAlphanumeric(final String s) {
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            if (!Character.isLetter(c) && !Character.isDigit(c)) {
                return false;
            }
        }
        return true;
    }

    private static boolean isNumeric(final String s) {
        for (int i = 0; i < s.length(); i++) {
            if (!Character.isDigit(s.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    private static boolean isAsciiPrintable(final String s) {
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            if (c < 32 || c > 126) {
                return false;
            }
        }
        return true;
    }

    // --- singleton accessors ---

    @Test
    public void testSingletonsNotNullAndStable() {
        assertNotNull(RandomStringUtils.secure());
        assertNotNull(RandomStringUtils.insecure());
        assertNotNull(RandomStringUtils.secureStrong());
        assertSame(RandomStringUtils.secure(), RandomStringUtils.secure());
        assertSame(RandomStringUtils.insecure(), RandomStringUtils.insecure());
        assertSame(RandomStringUtils.secureStrong(), RandomStringUtils.secureStrong());
        assertNotSame(RandomStringUtils.secure(), RandomStringUtils.insecure());
    }

    @Test
    public void testDeprecatedConstructor() {
        final RandomStringUtils instance = new RandomStringUtils();
        assertNotNull(instance);
        assertNotNull(instance.next(5));
    }

    // --- zero / boundary length ---

    @Test
    public void testZeroCountYieldsEmptyString() {
        assertEquals("", RandomStringUtils.insecure().next(0));
        assertEquals("", RandomStringUtils.secure().nextAlphabetic(0));
        assertEquals("", RandomStringUtils.insecure().nextAlphanumeric(0));
        assertEquals("", RandomStringUtils.insecure().nextNumeric(0));
        assertEquals("", RandomStringUtils.insecure().nextAscii(0));
        assertEquals("", RandomStringUtils.insecure().nextGraph(0));
        assertEquals("", RandomStringUtils.insecure().nextPrint(0));
    }

    @Test
    public void testNegativeCountThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.insecure().next(-1);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.insecure().nextAlphabetic(-5);
            }
        });
    }

    // --- length and content checks ---

    @Test
    public void testNextCountLength() {
        final String s = RandomStringUtils.insecure().next(100);
        assertEquals(100, s.length());
    }

    @Test
    public void testNextAlphabetic() {
        final String s = RandomStringUtils.insecure().nextAlphabetic(200);
        assertEquals(200, s.length());
        assertTrue(isAlpha(s));
    }

    @Test
    public void testNextAlphanumeric() {
        final String s = RandomStringUtils.insecure().nextAlphanumeric(200);
        assertEquals(200, s.length());
        assertTrue(isAlphanumeric(s));
    }

    @Test
    public void testNextNumeric() {
        final String s = RandomStringUtils.insecure().nextNumeric(200);
        assertEquals(200, s.length());
        assertTrue(isNumeric(s));
    }

    @Test
    public void testNextAscii() {
        final String s = RandomStringUtils.insecure().nextAscii(200);
        assertEquals(200, s.length());
        assertTrue(isAsciiPrintable(s));
    }

    @Test
    public void testNextGraph() {
        final String s = RandomStringUtils.insecure().nextGraph(200);
        assertEquals(200, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 33 && c <= 126);
        }
    }

    @Test
    public void testNextPrint() {
        final String s = RandomStringUtils.insecure().nextPrint(200);
        assertEquals(200, s.length());
        assertTrue(isAsciiPrintable(s));
    }

    // --- min/max length range overloads ---

    @Test
    public void testNextAlphabeticRange() {
        for (int i = 0; i < 20; i++) {
            final String s = RandomStringUtils.insecure().nextAlphabetic(3, 8);
            assertTrue(s.length() >= 3 && s.length() < 8, "length=" + s.length());
            assertTrue(isAlpha(s));
        }
    }

    @Test
    public void testNextAlphanumericRange() {
        for (int i = 0; i < 20; i++) {
            final String s = RandomStringUtils.insecure().nextAlphanumeric(3, 8);
            assertTrue(s.length() >= 3 && s.length() < 8);
            assertTrue(isAlphanumeric(s));
        }
    }

    @Test
    public void testNextNumericRange() {
        for (int i = 0; i < 20; i++) {
            final String s = RandomStringUtils.insecure().nextNumeric(3, 8);
            assertTrue(s.length() >= 3 && s.length() < 8);
            assertTrue(isNumeric(s));
        }
    }

    @Test
    public void testNextAsciiRange() {
        for (int i = 0; i < 20; i++) {
            final String s = RandomStringUtils.insecure().nextAscii(3, 8);
            assertTrue(s.length() >= 3 && s.length() < 8);
            assertTrue(isAsciiPrintable(s));
        }
    }

    @Test
    public void testNextGraphRange() {
        for (int i = 0; i < 20; i++) {
            final String s = RandomStringUtils.insecure().nextGraph(3, 8);
            assertTrue(s.length() >= 3 && s.length() < 8);
        }
    }

    @Test
    public void testNextPrintRange() {
        for (int i = 0; i < 20; i++) {
            final String s = RandomStringUtils.insecure().nextPrint(3, 8);
            assertTrue(s.length() >= 3 && s.length() < 8);
        }
    }

    // --- custom char set ---

    @Test
    public void testNextWithCharArray() {
        final char[] chars = { 'x', 'y', 'z' };
        final String s = RandomStringUtils.insecure().next(50, chars);
        assertEquals(50, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c == 'x' || c == 'y' || c == 'z');
        }
    }

    @Test
    public void testNextWithSingleCharArray() {
        final char[] chars = { 'q' };
        final String s = RandomStringUtils.insecure().next(10, chars);
        assertEquals("qqqqqqqqqq", s);
    }

    @Test
    public void testNextWithNullCharArrayUsesAllChars() {
        final char[] nullChars = null;
        final String s = RandomStringUtils.insecure().next(20, nullChars);
        assertEquals(20, s.length());
    }

    @Test
    public void testNextWithEmptyCharArrayThrows() {
        final char[] empty = {};
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.insecure().next(5, empty);
            }
        });
    }

    @Test
    public void testNextWithString() {
        final String s = RandomStringUtils.insecure().next(30, "ab");
        assertEquals(30, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c == 'a' || c == 'b');
        }
    }

    @Test
    public void testNextWithNullStringUsesAllChars() {
        final String nullStr = null;
        final String s = RandomStringUtils.insecure().next(15, nullStr);
        assertEquals(15, s.length());
    }

    @Test
    public void testNextWithEmptyStringThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.insecure().next(5, "");
            }
        });
    }

    // --- start/end/letters/numbers/chars/random overload (static random method) ---

    @Test
    public void testStaticRandomWithFixedSeedIsDeterministic() {
        final Random r1 = new Random(42L);
        final Random r2 = new Random(42L);
        final String s1 = RandomStringUtils.random(10, 0, 0, true, true, null, r1);
        final String s2 = RandomStringUtils.random(10, 0, 0, true, true, null, r2);
        assertEquals(s1, s2);
        assertEquals(10, s1.length());
    }

    @Test
    public void testStaticRandomZeroCount() {
        assertEquals("", RandomStringUtils.random(0, 0, 0, true, true, null, new Random(1L)));
    }

    @Test
    public void testStaticRandomNegativeCountThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(-3, 0, 0, true, true, null, new Random(1L));
            }
        });
    }

    @Test
    public void testStaticRandomEndLessThanStartThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 10, 5, false, false, null, new Random(1L));
            }
        });
    }

    @Test
    public void testStaticRandomNegativeStartThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, -1, 10, false, false, null, new Random(1L));
            }
        });
    }

    @Test
    public void testStaticRandomStartBeyondCharsLengthThrows() {
        final char[] chars = { 'a', 'b', 'c' };
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 5, 6, false, false, chars, new Random(1L));
            }
        });
    }

    @Test
    public void testStaticRandomEndBeyondCharsLengthThrows() {
        final char[] chars = { 'a', 'b', 'c' };
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 0, 4, false, false, chars, new Random(1L));
            }
        });
    }

    @Test
    public void testStaticRandomNoLettersOrDigitsInRangeThrows() {
        // Range [0,'0') contains neither letters nor digits.
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 1, (int) '0', true, true, null, new Random(1L));
            }
        });
    }

    @Test
    public void testStaticRandomNoLettersInCharsThrows() {
        final char[] digitsOnly = { '0', '1', '2' };
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 0, digitsOnly.length, true, false, digitsOnly, new Random(1L));
            }
        });
    }

    @Test
    public void testStaticRandomNeitherLettersNorDigitsUsesFullRange() {
        final String s = RandomStringUtils.random(10, 0, 0, false, false, null, new Random(1L));
        assertEquals(10, s.length());
    }

    // --- deprecated static convenience methods still function ---

    @Test
    public void testDeprecatedRandomMethods() {
        assertEquals(0, RandomStringUtils.random(0).length());
        assertEquals(15, RandomStringUtils.random(15).length());
        assertEquals(15, RandomStringUtils.random(15, true, true).length());
        assertEquals(15, RandomStringUtils.random(15, "xy").length());
        assertEquals(15, RandomStringUtils.random(15, new char[] { 'x', 'y' }).length());
        assertEquals(15, RandomStringUtils.random(15, 0, 0, true, true).length());
        assertEquals(15, RandomStringUtils.random(15, 0, 0, true, true, new char[] { 'x', 'y' }).length());

        assertTrue(isAlpha(RandomStringUtils.randomAlphabetic(20)));
        assertEquals(20, RandomStringUtils.randomAlphabetic(20).length());

        assertTrue(isAlphanumeric(RandomStringUtils.randomAlphanumeric(20)));

        assertTrue(isNumeric(RandomStringUtils.randomNumeric(20)));

        assertTrue(isAsciiPrintable(RandomStringUtils.randomAscii(20)));

        assertTrue(isAsciiPrintable(RandomStringUtils.randomPrint(20)));

        final String graph = RandomStringUtils.randomGraph(20);
        assertEquals(20, graph.length());

        for (int i = 0; i < 10; i++) {
            final int len = RandomStringUtils.randomAlphabetic(3, 8).length();
            assertTrue(len >= 3 && len < 8);
        }
        for (int i = 0; i < 10; i++) {
            final int len = RandomStringUtils.randomAlphanumeric(3, 8).length();
            assertTrue(len >= 3 && len < 8);
        }
        for (int i = 0; i < 10; i++) {
            final int len = RandomStringUtils.randomNumeric(3, 8).length();
            assertTrue(len >= 3 && len < 8);
        }
        for (int i = 0; i < 10; i++) {
            final int len = RandomStringUtils.randomAscii(3, 8).length();
            assertTrue(len >= 3 && len < 8);
        }
        for (int i = 0; i < 10; i++) {
            final int len = RandomStringUtils.randomGraph(3, 8).length();
            assertTrue(len >= 3 && len < 8);
        }
        for (int i = 0; i < 10; i++) {
            final int len = RandomStringUtils.randomPrint(3, 8).length();
            assertTrue(len >= 3 && len < 8);
        }
    }

    // --- toString and instance plumbing ---

    @Test
    public void testToStringContainsRandom() {
        final String s = RandomStringUtils.secure().toString();
        assertNotNull(s);
        assertTrue(s.startsWith("RandomStringUtils ["));
    }

    @Test
    public void testSecureAndInsecureProduceDifferentlyFlavoredInstances() {
        final String secureResult = RandomStringUtils.secure().next(5);
        final String insecureResult = RandomStringUtils.insecure().next(5);
        assertEquals(5, secureResult.length());
        assertEquals(5, insecureResult.length());
    }

    @Test
    public void testSecureStrongProducesValidOutput() {
        final String s = RandomStringUtils.secureStrong().nextAlphanumeric(10);
        assertEquals(10, s.length());
        assertTrue(isAlphanumeric(s));
    }

    @Test
    public void testHighRejectionRangeEventuallyThrowsOrSucceeds() {
        // Only digit '5' is reachable as a digit within [0x30, 0x3A), everything else in a tiny
        // window is rejected if letters requested but not present; verify no infinite loop and a
        // sensible result (IllegalArgumentException) when the category cannot be satisfied at all.
        final char[] onlyDigit = { '5' };
        final String s = RandomStringUtils.insecure().next(5, onlyDigit);
        assertEquals("55555", s);
    }
}
