/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.Format;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link ExtendedMessageFormat}.
 */
@Deprecated
class ExtendedMessageFormatAgentTest {

    /**
     * Simple upper-casing format used as a fixture for a custom format factory.
     */
    private static final class UpperFormat extends Format {
        private static final long serialVersionUID = 1L;

        @Override
        public StringBuffer format(final Object obj, final StringBuffer toAppendTo, final java.text.FieldPosition pos) {
            return toAppendTo.append(String.valueOf(obj).toUpperCase(Locale.ROOT));
        }

        @Override
        public Object parseObject(final String source, final java.text.ParsePosition pos) {
            pos.setIndex(source.length());
            return source;
        }

        @Override
        public boolean equals(final Object obj) {
            return obj instanceof UpperFormat;
        }

        @Override
        public int hashCode() {
            return UpperFormat.class.hashCode();
        }
    }

    private static final class UpperFormatFactory implements FormatFactory {
        @Override
        public Format getFormat(final String name, final String arguments, final Locale locale) {
            return "upper".equals(name) ? new UpperFormat() : null;
        }
    }

    private static Map<String, FormatFactory> upperRegistry() {
        final Map<String, FormatFactory> registry = new HashMap<>();
        registry.put("upper", new UpperFormatFactory());
        return registry;
    }

    @Test
    void testSimplePatternNoRegistry() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello, {0}!");
        assertEquals("Hello, {0}!", emf.toPattern());
        assertEquals("Hello, World!", emf.format(new Object[] {"World"}));
    }

    @Test
    void testCustomFormatIsApplied() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("Value: {0,upper}", upperRegistry());
        assertEquals("Value: ABC", emf.format(new Object[] {"abc"}));
        assertEquals("Value: {0,upper}", emf.toPattern());
    }

    @Test
    void testUnknownFormatNameFallsThroughToMessageFormat() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number,integer}", upperRegistry());
        assertEquals("42", emf.format(new Object[] {Integer.valueOf(42)}));
        assertEquals("{0,number,integer}", emf.toPattern());
    }

    @Test
    void testMixedCustomAndBuiltinFormats() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper} and {1,number,integer}", upperRegistry());
        assertEquals("ABC and 7", emf.format(new Object[] {"abc", Integer.valueOf(7)}));
    }

    @Test
    void testNullRegistryUsesSuperApplyPattern() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number,integer}", (Map<String, FormatFactory>) null);
        assertEquals("{0,number,integer}", emf.toPattern());
        assertEquals("5", emf.format(new Object[] {Integer.valueOf(5)}));
    }

    @Test
    void testLocaleConstructorUsesSpecifiedLocale() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", Locale.GERMANY);
        assertEquals(Locale.GERMANY, emf.getLocale());
    }

    @Test
    void testQuotedStringIsPreservedInPattern() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("it''s {0}");
        assertEquals("it's World", emf.format(new Object[] {"World"}));
    }

    @Test
    void testMultipleArgumentIndicesOutOfOrder() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{1} {0}");
        assertEquals("b a", emf.format(new Object[] {"a", "b"}));
    }

    @Test
    void testUnterminatedFormatElementThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{0", upperRegistry());
            }
        });
    }

    @Test
    void testUnterminatedQuotedStringThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("it's {0}", upperRegistry());
            }
        });
    }

    @Test
    void testInvalidArgumentIndexThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{abc}", upperRegistry());
            }
        });
    }

    @Test
    void testSetFormatThrowsUnsupported() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormat(0, new SimpleDateFormat());
            }
        });
    }

    @Test
    void testSetFormatByArgumentIndexThrowsUnsupported() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormatByArgumentIndex(0, new SimpleDateFormat());
            }
        });
    }

    @Test
    void testSetFormatsThrowsUnsupported() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormats(new Format[] {new SimpleDateFormat()});
            }
        });
    }

    @Test
    void testSetFormatsByArgumentIndexThrowsUnsupported() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormatsByArgumentIndex(new Format[] {new SimpleDateFormat()});
            }
        });
    }

    @Test
    void testEqualsAndHashCodeSamePatternAndRegistry() {
        final Map<String, FormatFactory> registry = upperRegistry();
        final ExtendedMessageFormat emf1 = new ExtendedMessageFormat("{0,upper}", Locale.US, registry);
        final ExtendedMessageFormat emf2 = new ExtendedMessageFormat("{0,upper}", Locale.US, registry);
        assertEquals(emf1, emf2);
        assertEquals(emf1.hashCode(), emf2.hashCode());
    }

    @Test
    void testEqualsDifferentPattern() {
        final ExtendedMessageFormat emf1 = new ExtendedMessageFormat("{0}");
        final ExtendedMessageFormat emf2 = new ExtendedMessageFormat("{0} {1}");
        assertNotEquals(emf1, emf2);
    }

    @Test
    void testEqualsAgainstPlainMessageFormatIsFalse() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        final java.text.MessageFormat mf = new java.text.MessageFormat("{0}");
        assertFalse(emf.equals(mf));
    }

    @Test
    void testEqualsAgainstNullIsFalse() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertFalse(emf.equals(null));
    }

    @Test
    void testEqualsReflexive() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertTrue(emf.equals(emf));
    }

    @Test
    void testChoiceFormatPattern() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat(
                "{0,choice,0#no files|1#one file|1<{0,number} files}");
        assertEquals("no files", emf.format(new Object[] {Integer.valueOf(0)}));
        assertEquals("one file", emf.format(new Object[] {Integer.valueOf(1)}));
        assertEquals("3 files", emf.format(new Object[] {Integer.valueOf(3)}));
    }

    @Test
    void testEmptyPattern() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("");
        assertEquals("", emf.toPattern());
        assertEquals("", emf.format(new Object[0]));
    }

    @Test
    void testDateFormatWithStyleArgument() throws ParseException {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,date,yyyy-MM-dd}", Locale.US);
        final Calendar cal = new GregorianCalendar(2020, Calendar.JANUARY, 15);
        assertEquals("2020-01-15", emf.format(new Object[] {cal.getTime()}));
    }
}
