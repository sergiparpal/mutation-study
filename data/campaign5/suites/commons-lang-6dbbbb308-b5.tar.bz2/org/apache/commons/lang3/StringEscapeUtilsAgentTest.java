/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link StringEscapeUtils}.
 */
class StringEscapeUtilsAgentTest {

    @Test
    void testConstructorIsPublic() {
        assertNotNull(new StringEscapeUtils());
    }

    // ---- escapeJava / unescapeJava ----

    @Test
    void testEscapeJavaNull() {
        assertNull(StringEscapeUtils.escapeJava(null));
    }

    @Test
    void testEscapeJavaEmpty() {
        assertEquals("", StringEscapeUtils.escapeJava(""));
    }

    @Test
    void testEscapeJavaBasic() {
        assertEquals("He didn't say, \\\"Stop!\\\"", StringEscapeUtils.escapeJava("He didn't say, \"Stop!\""));
    }

    @Test
    void testEscapeJavaControlChars() {
        assertEquals("\\t\\n\\r\\f\\b", StringEscapeUtils.escapeJava("\t\n\r\f\b"));
    }

    @Test
    void testEscapeJavaBackslash() {
        assertEquals("\\\\", StringEscapeUtils.escapeJava("\\"));
    }

    @Test
    void testEscapeJavaDoesNotEscapeForwardSlash() {
        // unlike EcmaScript/Json, Java escaping does not escape '/'
        assertEquals("/", StringEscapeUtils.escapeJava("/"));
    }

    @Test
    void testEscapeJavaUnicodeOutsideAscii() {
        assertEquals("\\u00E9", StringEscapeUtils.escapeJava("é"));
    }

    @Test
    void testUnescapeJavaNull() {
        assertNull(StringEscapeUtils.unescapeJava(null));
    }

    @Test
    void testUnescapeJavaBasic() {
        assertEquals("He didn't say, \"Stop!\"", StringEscapeUtils.unescapeJava("He didn't say, \\\"Stop!\\\""));
    }

    @Test
    void testUnescapeJavaOctal() {
        assertEquals("A", StringEscapeUtils.unescapeJava("\\101"));
    }

    @Test
    void testUnescapeJavaUnicode() {
        assertEquals("é", StringEscapeUtils.unescapeJava("\\u00e9"));
    }

    @Test
    void testUnescapeJavaInvalidUnicodeThrows() {
        try {
            StringEscapeUtils.unescapeJava("\\uZZZZ");
            throw new AssertionError("expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected: invalid Unicode escape
        }
    }

    @Test
    void testUnescapeJavaLoneBackslashAtEnd() {
        // trailing lone backslash is swallowed (see UNESCAPE_JAVA lookup table)
        assertEquals("ab", StringEscapeUtils.unescapeJava("ab\\"));
    }

    // ---- escapeEcmaScript / unescapeEcmaScript ----

    @Test
    void testEscapeEcmaScriptNull() {
        assertNull(StringEscapeUtils.escapeEcmaScript(null));
    }

    @Test
    void testEscapeEcmaScriptQuotesAndSlash() {
        assertEquals("He didn\\'t say, \\\"Stop!\\\"", StringEscapeUtils.escapeEcmaScript("He didn't say, \"Stop!\""));
        assertEquals("\\/", StringEscapeUtils.escapeEcmaScript("/"));
    }

    @Test
    void testUnescapeEcmaScriptSameAsJava() {
        assertSame(StringEscapeUtils.UNESCAPE_JAVA, StringEscapeUtils.UNESCAPE_ECMASCRIPT);
        assertEquals("a'b", StringEscapeUtils.unescapeEcmaScript("a\\'b"));
    }

    // ---- escapeJson / unescapeJson ----

    @Test
    void testEscapeJsonNull() {
        assertNull(StringEscapeUtils.escapeJson(null));
    }

    @Test
    void testEscapeJsonForwardSlashAndQuote() {
        assertEquals("He didn't say, \\\"Stop!\\\"", StringEscapeUtils.escapeJson("He didn't say, \"Stop!\""));
        assertEquals("\\/", StringEscapeUtils.escapeJson("/"));
    }

    @Test
    void testEscapeJsonDoesNotEscapeSingleQuote() {
        // unlike EcmaScript, Json does not escape apostrophes
        assertEquals("'", StringEscapeUtils.escapeJson("'"));
    }

    @Test
    void testUnescapeJsonSameAsJava() {
        assertSame(StringEscapeUtils.UNESCAPE_JAVA, StringEscapeUtils.UNESCAPE_JSON);
        assertEquals("\n", StringEscapeUtils.unescapeJson("\\n"));
    }

    // ---- escapeHtml3 / unescapeHtml3 ----

    @Test
    void testEscapeHtml3Null() {
        assertNull(StringEscapeUtils.escapeHtml3(null));
    }

    @Test
    void testEscapeHtml3Basic() {
        assertEquals("&quot;bread&quot; &amp; &quot;butter&quot;",
                StringEscapeUtils.escapeHtml3("\"bread\" & \"butter\""));
    }

    @Test
    void testEscapeHtml3DoesNotHaveAposEntity() {
        // HTML3 escaping does not translate the apostrophe to &apos;
        assertEquals("'", StringEscapeUtils.escapeHtml3("'"));
    }

    @Test
    void testUnescapeHtml3Null() {
        assertNull(StringEscapeUtils.unescapeHtml3(null));
    }

    @Test
    void testUnescapeHtml3Basic() {
        assertEquals("\"bread\" & \"butter\"", StringEscapeUtils.unescapeHtml3("&quot;bread&quot; &amp; &quot;butter&quot;"));
    }

    @Test
    void testUnescapeHtml3NumericEntity() {
        assertEquals("<", StringEscapeUtils.unescapeHtml3("&#60;"));
    }

    @Test
    void testUnescapeHtml3UnknownEntityLeftAlone() {
        assertEquals(">&zzzz;x", StringEscapeUtils.unescapeHtml3("&gt;&zzzz;x"));
    }

    // ---- escapeHtml4 / unescapeHtml4 ----

    @Test
    void testEscapeHtml4Null() {
        assertNull(StringEscapeUtils.escapeHtml4(null));
    }

    @Test
    void testEscapeHtml4Basic() {
        assertEquals("&quot;bread&quot; &amp; &quot;butter&quot;",
                StringEscapeUtils.escapeHtml4("\"bread\" & \"butter\""));
    }

    @Test
    void testEscapeHtml4ExtendedEntity() {
        assertEquals("&euro;", StringEscapeUtils.escapeHtml4("€"));
    }

    @Test
    void testUnescapeHtml4Null() {
        assertNull(StringEscapeUtils.unescapeHtml4(null));
    }

    @Test
    void testUnescapeHtml4FrenchExample() {
        assertEquals("<Français>", StringEscapeUtils.unescapeHtml4("&lt;Fran&ccedil;ais&gt;"));
    }

    @Test
    void testUnescapeHtml4UnknownEntityLeftAlone() {
        assertEquals(">&zzzz;x", StringEscapeUtils.unescapeHtml4("&gt;&zzzz;x"));
    }

    // ---- escapeXml (deprecated) ----

    @Test
    void testEscapeXmlNull() {
        assertNull(StringEscapeUtils.escapeXml(null));
    }

    @Test
    void testEscapeXmlBasic() {
        assertEquals("&quot;bread&quot; &amp; &quot;butter&quot;", StringEscapeUtils.escapeXml("\"bread\" & \"butter\""));
    }

    @Test
    void testEscapeXmlApostrophe() {
        assertEquals("&apos;", StringEscapeUtils.escapeXml("'"));
    }

    @Test
    void testEscapeXmlDoesNotEscapeHighUnicode() {
        // as of 3.0, characters above 0x7f are no longer escaped by plain escapeXml
        assertEquals("é", StringEscapeUtils.escapeXml("é"));
    }

    // ---- escapeXml10 ----

    @Test
    void testEscapeXml10Null() {
        assertNull(StringEscapeUtils.escapeXml10(null));
    }

    @Test
    void testEscapeXml10RemovesControlChars() {
        // \u0000 and \u0001 are not representable in XML 1.0 and are stripped
        assertEquals("ab", StringEscapeUtils.escapeXml10("a\u0000\u0001b"));
    }

    @Test
    void testEscapeXml10KeepsTabNewlineCr() {
        assertEquals("a\tb\nc\rd", StringEscapeUtils.escapeXml10("a\tb\nc\rd"));
    }

    @Test
    void testEscapeXml10EscapesNearControlRange() {
        assertEquals("&#127;", StringEscapeUtils.escapeXml10("\u007f"));
    }

    @Test
    void testEscapeXml10RemovesFormFeed() {
        // \u000c (form feed) is removed under XML 1.0, unlike XML 1.1 which escapes it
        assertEquals("ab", StringEscapeUtils.escapeXml10("a\u000cb"));
    }

    // ---- escapeXml11 ----

    @Test
    void testEscapeXml11Null() {
        assertNull(StringEscapeUtils.escapeXml11(null));
    }

    @Test
    void testEscapeXml11RemovesNullByte() {
        assertEquals("ab", StringEscapeUtils.escapeXml11("a\u0000b"));
    }

    @Test
    void testEscapeXml11EscapesControlChar() {
        assertEquals("a&#1;b", StringEscapeUtils.escapeXml11("a\u0001b"));
    }

    @Test
    void testEscapeXml11KeepsFormFeedEscapedDifferentlyThanXml10() {
        assertEquals("a&#12;b", StringEscapeUtils.escapeXml11("a\u000cb"));
    }

    // ---- unescapeXml ----

    @Test
    void testUnescapeXmlNull() {
        assertNull(StringEscapeUtils.unescapeXml(null));
    }

    @Test
    void testUnescapeXmlBasic() {
        assertEquals("\"bread\" & \"butter\"", StringEscapeUtils.unescapeXml("&quot;bread&quot; &amp; &quot;butter&quot;"));
    }

    @Test
    void testUnescapeXmlApostropheAndNumeric() {
        assertEquals("'<", StringEscapeUtils.unescapeXml("&apos;&#60;"));
    }

    // ---- escapeCsv / unescapeCsv ----

    @Test
    void testEscapeCsvNull() {
        assertNull(StringEscapeUtils.escapeCsv(null));
    }

    @Test
    void testEscapeCsvNoSpecialChars() {
        assertEquals("abc", StringEscapeUtils.escapeCsv("abc"));
    }

    @Test
    void testEscapeCsvWithComma() {
        assertEquals("\"a,b\"", StringEscapeUtils.escapeCsv("a,b"));
    }

    @Test
    void testEscapeCsvWithQuote() {
        assertEquals("\"a\"\"b\"", StringEscapeUtils.escapeCsv("a\"b"));
    }

    @Test
    void testEscapeCsvWithCrLf() {
        assertEquals("\"a\r\nb\"", StringEscapeUtils.escapeCsv("a\r\nb"));
    }

    @Test
    void testEscapeCsvEmptyString() {
        assertEquals("", StringEscapeUtils.escapeCsv(""));
    }

    @Test
    void testUnescapeCsvNull() {
        assertNull(StringEscapeUtils.unescapeCsv(null));
    }

    @Test
    void testUnescapeCsvNoQuotes() {
        assertEquals("abc", StringEscapeUtils.unescapeCsv("abc"));
    }

    @Test
    void testUnescapeCsvQuoted() {
        assertEquals("a,b", StringEscapeUtils.unescapeCsv("\"a,b\""));
    }

    @Test
    void testUnescapeCsvQuotedWithEscapedQuotes() {
        assertEquals("a\"b", StringEscapeUtils.unescapeCsv("\"a\"\"b\""));
    }

    @Test
    void testUnescapeCsvSingleQuoteCharacterThrows() {
        // a lone quote character: start == end index, implementation indexes out of bounds
        try {
            StringEscapeUtils.unescapeCsv("\"");
            throw new AssertionError("expected StringIndexOutOfBoundsException");
        } catch (final StringIndexOutOfBoundsException expected) {
            // expected: known edge-case bug in the deprecated CsvUnescaper
        }
    }

    @Test
    void testUnescapeCsvQuotedWithoutSpecialCharsKeepsQuotes() {
        // quotes are only stripped when the quoted content contains a special char
        assertEquals("\"abc\"", StringEscapeUtils.unescapeCsv("\"abc\""));
    }

    @Test
    void testUnescapeCsvEmptyString() {
        assertEquals("", StringEscapeUtils.unescapeCsv(""));
    }

    // ---- round trips ----

    @Test
    void testJavaRoundTrip() {
        final String original = "Tab:\t Quote:\" Backslash:\\ Unicode:é";
        final String escaped = StringEscapeUtils.escapeJava(original);
        assertEquals(original, StringEscapeUtils.unescapeJava(escaped));
    }

    @Test
    void testHtml4RoundTrip() {
        final String original = "<a href=\"test\">Français & Co</a>";
        final String escaped = StringEscapeUtils.escapeHtml4(original);
        assertEquals(original, StringEscapeUtils.unescapeHtml4(escaped));
    }

    @Test
    void testXmlRoundTrip() {
        final String original = "<tag attr='value'>a & b</tag>";
        final String escaped = StringEscapeUtils.escapeXml10(original);
        assertEquals(original, StringEscapeUtils.unescapeXml(escaped));
    }

    @Test
    void testCsvRoundTrip() {
        final String original = "a,\"quoted\"\nb";
        final String escaped = StringEscapeUtils.escapeCsv(original);
        assertEquals(original, StringEscapeUtils.unescapeCsv(escaped));
    }
}
