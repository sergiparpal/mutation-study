/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3.builder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link HashCodeBuilder}.
 */
class HashCodeBuilderAgentTest {

    /**
     * A plain fixture with fields of various types, used for reflection based tests.
     */
    static class SimpleFixture {
        int intField = 7;
        String stringField = "abc";
        transient int transientField = 42;
        static int staticField = 99;

        @HashCodeExclude
        int excludedField = 11;
    }

    /**
     * A fixture referencing another fixture, to exercise reflection over object graphs that
     * cycle back to themselves.
     */
    static class CyclicFixture {
        CyclicFixture other;
    }

    @Test
    void testDefaultConstructorProducesInitialValueWhenNothingAppended() {
        final HashCodeBuilder builder = new HashCodeBuilder();
        assertEquals(17, builder.toHashCode());
    }

    @Test
    void testTwoArgConstructorUsesGivenInitialValue() {
        final HashCodeBuilder builder = new HashCodeBuilder(3, 5);
        assertEquals(3, builder.toHashCode());
    }

    @Test
    void testConstructorRejectsEvenInitialValue() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new HashCodeBuilder(4, 7);
            }
        });
    }

    @Test
    void testConstructorRejectsEvenMultiplier() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new HashCodeBuilder(7, 4);
            }
        });
    }

    @Test
    void testConstructorRejectsZeroInitialValue() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new HashCodeBuilder(0, 7);
            }
        });
    }

    @Test
    void testConstructorRejectsZeroMultiplier() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new HashCodeBuilder(7, 0);
            }
        });
    }

    @Test
    void testAppendBooleanTrueAddsZero() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        builder.append(true);
        assertEquals(17 * 37, builder.toHashCode());
    }

    @Test
    void testAppendBooleanFalseAddsOne() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        builder.append(false);
        assertEquals(17 * 37 + 1, builder.toHashCode());
    }

    @Test
    void testAppendBooleanArrayNull() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        builder.append((boolean[]) null);
        assertEquals(17 * 37, builder.toHashCode());
    }

    @Test
    void testAppendBooleanArrayMatchesElementwiseAppend() {
        final boolean[] array = {true, false, true};
        final HashCodeBuilder arrayBuilder = new HashCodeBuilder(17, 37);
        arrayBuilder.append(array);

        final HashCodeBuilder elementBuilder = new HashCodeBuilder(17, 37);
        elementBuilder.append(true).append(false).append(true);

        assertEquals(elementBuilder.toHashCode(), arrayBuilder.toHashCode());
    }

    @Test
    void testAppendByte() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        builder.append((byte) 5);
        assertEquals(17 * 37 + 5, builder.toHashCode());
    }

    @Test
    void testAppendByteArrayNull() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        builder.append((byte[]) null);
        assertEquals(17 * 37, builder.toHashCode());
    }

    @Test
    void testAppendByteArrayEmpty() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        builder.append(new byte[0]);
        assertEquals(17, builder.toHashCode());
    }

    @Test
    void testAppendChar() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        builder.append('A');
        assertEquals(17 * 37 + 'A', builder.toHashCode());
    }

    @Test
    void testAppendCharArrayNull() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        builder.append((char[]) null);
        assertEquals(17 * 37, builder.toHashCode());
    }

    @Test
    void testAppendDoubleMatchesDoubleToLongBits() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        builder.append(1.5d);
        final long bits = Double.doubleToLongBits(1.5d);
        final int expected = 17 * 37 + (int) (bits ^ bits >> 32);
        assertEquals(expected, builder.toHashCode());
    }

    @Test
    void testAppendDoubleArrayNull() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        builder.append((double[]) null);
        assertEquals(17 * 37, builder.toHashCode());
    }

    @Test
    void testAppendFloat() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        builder.append(2.5f);
        assertEquals(17 * 37 + Float.floatToIntBits(2.5f), builder.toHashCode());
    }

    @Test
    void testAppendFloatArrayNull() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        builder.append((float[]) null);
        assertEquals(17 * 37, builder.toHashCode());
    }

    @Test
    void testAppendInt() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        builder.append(123);
        assertEquals(17 * 37 + 123, builder.toHashCode());
    }

    @Test
    void testAppendIntArrayNull() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        builder.append((int[]) null);
        assertEquals(17 * 37, builder.toHashCode());
    }

    @Test
    void testAppendLong() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        builder.append(123456789012L);
        final long value = 123456789012L;
        final int expected = 17 * 37 + (int) (value ^ value >> 32);
        assertEquals(expected, builder.toHashCode());
    }

    @Test
    void testAppendLongArrayNull() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        builder.append((long[]) null);
        assertEquals(17 * 37, builder.toHashCode());
    }

    @Test
    void testAppendShort() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        builder.append((short) 9);
        assertEquals(17 * 37 + 9, builder.toHashCode());
    }

    @Test
    void testAppendShortArrayNull() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        builder.append((short[]) null);
        assertEquals(17 * 37, builder.toHashCode());
    }

    @Test
    void testAppendObjectNull() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        builder.append((Object) null);
        assertEquals(17 * 37, builder.toHashCode());
    }

    @Test
    void testAppendObjectUsesItsHashCode() {
        final String value = "hello";
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        builder.append((Object) value);
        assertEquals(17 * 37 + value.hashCode(), builder.toHashCode());
    }

    @Test
    void testAppendObjectArrayNull() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        builder.append((Object[]) null);
        assertEquals(17 * 37, builder.toHashCode());
    }

    @Test
    void testAppendObjectArrayDelegatesToObjectAppend() {
        final Object[] array = {"x", "y"};
        final HashCodeBuilder arrayBuilder = new HashCodeBuilder(17, 37);
        arrayBuilder.append(array);

        final HashCodeBuilder elementBuilder = new HashCodeBuilder(17, 37);
        elementBuilder.append((Object) "x").append((Object) "y");

        assertEquals(elementBuilder.toHashCode(), arrayBuilder.toHashCode());
    }

    @Test
    void testAppendObjectThatIsAnArrayDispatchesToArrayHandling() {
        final int[] primitiveArray = {1, 2, 3};
        final HashCodeBuilder viaObjectOverload = new HashCodeBuilder(17, 37);
        viaObjectOverload.append((Object) primitiveArray);

        final HashCodeBuilder viaIntArrayOverload = new HashCodeBuilder(17, 37);
        viaIntArrayOverload.append(primitiveArray);

        assertEquals(viaIntArrayOverload.toHashCode(), viaObjectOverload.toHashCode());
    }

    @Test
    void testAppendMultiDimensionalArray() {
        final int[][] array = {{1, 2}, {3, 4}};
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        builder.append((Object) array);

        final HashCodeBuilder expectedBuilder = new HashCodeBuilder(17, 37);
        expectedBuilder.append(array[0]).append(array[1]);

        assertEquals(expectedBuilder.toHashCode(), builder.toHashCode());
    }

    @Test
    void testAppendSuperCombinesWithTotal() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        builder.append(5);
        builder.appendSuper(99);
        final int expected = (17 * 37 + 5) * 37 + 99;
        assertEquals(expected, builder.toHashCode());
    }

    @Test
    void testChainingReturnsSameInstance() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        final HashCodeBuilder result = builder.append(1).append("x").appendSuper(2);
        assertSame(builder, result);
    }

    @Test
    void testBuildReturnsBoxedToHashCode() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        builder.append(42);
        assertEquals(Integer.valueOf(builder.toHashCode()), builder.build());
    }

    @Test
    void testHashCodeMethodReturnsToHashCode() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        builder.append(42);
        assertEquals(builder.toHashCode(), builder.hashCode());
    }

    @Test
    void testEqualsTrueForSameTotal() {
        final HashCodeBuilder builderA = new HashCodeBuilder(17, 37);
        builderA.append(5);
        final HashCodeBuilder builderB = new HashCodeBuilder(17, 37);
        builderB.append(5);
        assertTrue(builderA.equals(builderB));
        assertTrue(builderB.equals(builderA));
    }

    @Test
    void testEqualsFalseForDifferentTotal() {
        final HashCodeBuilder builderA = new HashCodeBuilder(17, 37);
        builderA.append(5);
        final HashCodeBuilder builderB = new HashCodeBuilder(17, 37);
        builderB.append(6);
        assertFalse(builderA.equals(builderB));
    }

    @Test
    void testEqualsFalseForNullAndOtherType() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        assertFalse(builder.equals(null));
        assertFalse(builder.equals("not a builder"));
    }

    @Test
    void testEqualsReflexive() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        assertTrue(builder.equals(builder));
    }

    @Test
    void testTwoBuildersWithSameSequenceProduceSameHashCode() {
        final HashCodeBuilder builderA = new HashCodeBuilder(17, 37).append(1).append("x").append(2.5d);
        final HashCodeBuilder builderB = new HashCodeBuilder(17, 37).append(1).append("x").append(2.5d);
        assertEquals(builderA.toHashCode(), builderB.toHashCode());
    }

    @Test
    void testDifferentSequencesTendToProduceDifferentHashCode() {
        final HashCodeBuilder builderA = new HashCodeBuilder(17, 37).append(1).append(2);
        final HashCodeBuilder builderB = new HashCodeBuilder(17, 37).append(2).append(1);
        assertNotEquals(builderA.toHashCode(), builderB.toHashCode());
    }

    @Test
    void testStaticBuilderProducesWorkingInstance() {
        final HashCodeBuilder builder = HashCodeBuilder.builder()
                .setInitialOddNumber(9)
                .setMultiplierOddNumber(11)
                .get();
        assertEquals(9, builder.toHashCode());
        builder.append(4);
        assertEquals(9 * 11 + 4, builder.toHashCode());
    }

    @Test
    void testReflectionHashCodeRejectsNullObject() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                HashCodeBuilder.reflectionHashCode(17, 37, null);
            }
        });
    }

    @Test
    void testReflectionHashCodeRejectsEvenInitialValue() {
        final SimpleFixture fixture = new SimpleFixture();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                HashCodeBuilder.reflectionHashCode(18, 37, fixture);
            }
        });
    }

    @Test
    void testReflectionHashCodeIsConsistentAcrossCalls() {
        final SimpleFixture fixture = new SimpleFixture();
        final int first = HashCodeBuilder.reflectionHashCode(fixture);
        final int second = HashCodeBuilder.reflectionHashCode(fixture);
        assertEquals(first, second);
    }

    @Test
    void testReflectionHashCodeExcludesStaticAndAnnotatedFields() {
        final SimpleFixture fixture = new SimpleFixture();
        final int withoutExclusion = HashCodeBuilder.reflectionHashCode(17, 37, fixture, false, null);

        final HashCodeBuilder manual = new HashCodeBuilder(17, 37);
        manual.append(fixture.intField);
        manual.append(fixture.stringField);
        assertEquals(manual.toHashCode(), withoutExclusion);
    }

    @Test
    void testReflectionHashCodeIncludesTransientFieldsWhenRequested() {
        final SimpleFixture withTransients = new SimpleFixture();
        final SimpleFixture withoutChangeToTransient = new SimpleFixture();
        withoutChangeToTransient.transientField = 1000;

        final int hashIgnoringTransient = HashCodeBuilder.reflectionHashCode(17, 37, withTransients, false, null);
        final int otherHashIgnoringTransient = HashCodeBuilder.reflectionHashCode(17, 37, withoutChangeToTransient, false, null);
        assertEquals(hashIgnoringTransient, otherHashIgnoringTransient);

        final int hashUsingTransient = HashCodeBuilder.reflectionHashCode(17, 37, withTransients, true, null);
        final int otherHashUsingTransient = HashCodeBuilder.reflectionHashCode(17, 37, withoutChangeToTransient, true, null);
        assertNotEquals(hashUsingTransient, otherHashUsingTransient);
    }

    @Test
    void testReflectionHashCodeWithExcludeFieldsArray() {
        final SimpleFixture fixture = new SimpleFixture();
        final int excludingIntField = HashCodeBuilder.reflectionHashCode(fixture, "intField");

        final HashCodeBuilder manual = new HashCodeBuilder(17, 37);
        manual.append(fixture.stringField);
        assertEquals(manual.toHashCode(), excludingIntField);
    }

    @Test
    void testReflectionHashCodeWithExcludeFieldsCollection() {
        final SimpleFixture fixture = new SimpleFixture();
        final List<String> excluded = new ArrayList<String>();
        excluded.add("intField");
        excluded.add("stringField");
        final int excludingBoth = HashCodeBuilder.reflectionHashCode(fixture, excluded);
        assertEquals(17, excludingBoth);
    }

    @Test
    void testReflectionHashCodeWithEmptyExcludeCollectionMatchesPlainReflection() {
        final SimpleFixture fixture = new SimpleFixture();
        final int plain = HashCodeBuilder.reflectionHashCode(fixture, (String[]) null);
        final int withEmptyExclusions = HashCodeBuilder.reflectionHashCode(fixture, Collections.<String>emptyList());
        assertEquals(plain, withEmptyExclusions);
    }

    @Test
    void testReflectionHashCodeHandlesSelfReferencingCycleWithoutInfiniteLoop() {
        final CyclicFixture cyclic = new CyclicFixture();
        cyclic.other = cyclic;
        final int first = HashCodeBuilder.reflectionHashCode(cyclic);
        final int second = HashCodeBuilder.reflectionHashCode(cyclic);
        assertEquals(first, second);
    }

    @Test
    void testReflectionHashCodeWithReflectUpToClassLimitsSuperclassFields() {
        final SimpleFixture fixture = new SimpleFixture();
        final int hashUpToObject = HashCodeBuilder.<SimpleFixture>reflectionHashCode(17, 37, fixture, false, Object.class);
        final int hashUpToSimpleFixture = HashCodeBuilder.<SimpleFixture>reflectionHashCode(17, 37, fixture, false, SimpleFixture.class);
        assertEquals(hashUpToObject, hashUpToSimpleFixture);
    }
}
