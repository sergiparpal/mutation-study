/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link StopWatch}.
 */
public class StopWatchAgentTest {

    @Test
    public void testCreateUnstarted() {
        final StopWatch watch = StopWatch.create();
        assertFalse(watch.isStarted());
        assertTrue(watch.isStopped());
        assertFalse(watch.isSuspended());
        assertEquals(0, watch.getTime());
        assertNull(watch.getMessage());
    }

    @Test
    public void testCreateStarted() {
        final StopWatch watch = StopWatch.createStarted();
        assertTrue(watch.isStarted());
        assertFalse(watch.isStopped());
        assertFalse(watch.isSuspended());
    }

    @Test
    public void testDefaultConstructorMessageIsNull() {
        final StopWatch watch = new StopWatch();
        assertNull(watch.getMessage());
    }

    @Test
    public void testMessageConstructor() {
        final StopWatch watch = new StopWatch("myMessage");
        assertEquals("myMessage", watch.getMessage());
        watch.start();
        watch.stop();
        assertTrue(watch.toString().startsWith("myMessage "));
    }

    @Test
    public void testStartStopBasic() throws InterruptedException {
        final StopWatch watch = new StopWatch();
        watch.start();
        Thread.sleep(20);
        watch.stop();
        assertTrue(watch.isStopped());
        assertFalse(watch.isStarted());
        assertTrue(watch.getTime() >= 0);
        assertTrue(watch.getNanoTime() >= 0);
        assertNotNull(watch.getStartInstant());
        assertNotNull(watch.getStopInstant());
        assertTrue(!watch.getStopInstant().isBefore(watch.getStartInstant()));
    }

    @Test
    public void testStartTwiceThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        final IllegalStateException e = assertThrows(IllegalStateException.class, watch::start);
        assertEquals("Stopwatch already started.", e.getMessage());
    }

    @Test
    public void testStartAfterStopWithoutResetThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        final IllegalStateException e = assertThrows(IllegalStateException.class, watch::start);
        assertEquals("Stopwatch must be reset before being restarted.", e.getMessage());
    }

    @Test
    public void testStartAfterResetWorks() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        watch.reset();
        assertFalse(watch.isStarted());
        watch.start();
        assertTrue(watch.isStarted());
    }

    @Test
    public void testStopBeforeStartThrows() {
        final StopWatch watch = new StopWatch();
        final IllegalStateException e = assertThrows(IllegalStateException.class, watch::stop);
        assertEquals("Stopwatch is not running.", e.getMessage());
    }

    @Test
    public void testStopTwiceThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        final IllegalStateException e = assertThrows(IllegalStateException.class, watch::stop);
        assertEquals("Stopwatch is not running.", e.getMessage());
    }

    @Test
    public void testSuspendResume() throws InterruptedException {
        final StopWatch watch = new StopWatch();
        watch.start();
        Thread.sleep(10);
        watch.suspend();
        assertTrue(watch.isSuspended());
        assertTrue(watch.isStarted());
        final long suspendedTime = watch.getTime();
        Thread.sleep(20);
        assertEquals(suspendedTime, watch.getTime());
        watch.resume();
        assertFalse(watch.isSuspended());
        assertTrue(watch.isStarted());
        watch.stop();
        assertTrue(watch.getTime() >= suspendedTime);
    }

    @Test
    public void testSuspendBeforeStartThrows() {
        final StopWatch watch = new StopWatch();
        final IllegalStateException e = assertThrows(IllegalStateException.class, watch::suspend);
        assertEquals("Stopwatch must be running to suspend.", e.getMessage());
    }

    @Test
    public void testSuspendTwiceThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.suspend();
        final IllegalStateException e = assertThrows(IllegalStateException.class, watch::suspend);
        assertEquals("Stopwatch must be running to suspend.", e.getMessage());
    }

    @Test
    public void testResumeWithoutSuspendThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        final IllegalStateException e = assertThrows(IllegalStateException.class, watch::resume);
        assertEquals("Stopwatch must be suspended to resume.", e.getMessage());
    }

    @Test
    public void testResumeBeforeStartThrows() {
        final StopWatch watch = new StopWatch();
        final IllegalStateException e = assertThrows(IllegalStateException.class, watch::resume);
        assertEquals("Stopwatch must be suspended to resume.", e.getMessage());
    }

    @Test
    public void testSplitUnsplit() throws InterruptedException {
        final StopWatch watch = new StopWatch();
        watch.start();
        Thread.sleep(10);
        watch.split();
        final long splitTime = watch.getSplitTime();
        assertTrue(splitTime >= 0);
        final Duration splitDuration = watch.getSplitDuration();
        assertEquals(splitTime, splitDuration.toMillis());
        assertEquals(1, watch.getSplits().size());
        watch.unsplit();
        assertTrue(watch.getSplits().isEmpty());
        watch.stop();
    }

    @Test
    public void testSplitWithLabel() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split("first");
        watch.split("second");
        final List<StopWatch.Split> splits = watch.getSplits();
        assertEquals(2, splits.size());
        assertEquals("first", splits.get(0).getLabel());
        assertEquals("second", splits.get(1).getLabel());
        assertNotNull(splits.get(0).getDuration());
        watch.stop();
    }

    @Test
    public void testSplitsListIsUnmodifiable() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        final List<StopWatch.Split> splits = watch.getSplits();
        assertThrows(UnsupportedOperationException.class, () -> splits.add(new StopWatch.Split("x", Duration.ZERO)));
    }

    @Test
    public void testGetSplitTimeBeforeSplitThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        final IllegalStateException e = assertThrows(IllegalStateException.class, watch::getSplitTime);
        assertEquals("Stopwatch must be split to get the split time.", e.getMessage());
    }

    @Test
    public void testUnsplitWithoutSplitThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        final IllegalStateException e = assertThrows(IllegalStateException.class, watch::unsplit);
        assertEquals("Stopwatch has not been split.", e.getMessage());
    }

    @Test
    public void testSplitBeforeStartThrows() {
        final StopWatch watch = new StopWatch();
        final IllegalStateException e = assertThrows(IllegalStateException.class, watch::split);
        assertEquals("Stopwatch is not running.", e.getMessage());
    }

    @Test
    public void testSplitAfterStopThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        final IllegalStateException e = assertThrows(IllegalStateException.class, watch::split);
        assertEquals("Stopwatch is not running.", e.getMessage());
    }

    @Test
    public void testResetClearsSplitsAndState() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        watch.reset();
        assertTrue(watch.isStopped());
        assertFalse(watch.isStarted());
        assertTrue(watch.getSplits().isEmpty());
        assertThrows(IllegalStateException.class, watch::getSplitTime);
    }

    @Test
    public void testGetStartInstantBeforeStartThrows() {
        final StopWatch watch = new StopWatch();
        final IllegalStateException e = assertThrows(IllegalStateException.class, watch::getStartInstant);
        assertEquals("Stopwatch has not been started", e.getMessage());
    }

    @Test
    public void testGetStopInstantBeforeStartThrows() {
        final StopWatch watch = new StopWatch();
        final IllegalStateException e = assertThrows(IllegalStateException.class, watch::getStopInstant);
        assertEquals("Stopwatch has not been started", e.getMessage());
    }

    @Test
    public void testGetStartInstantAfterStartButBeforeStop() {
        final StopWatch watch = new StopWatch();
        final Instant before = Instant.now();
        watch.start();
        final Instant startInstant = watch.getStartInstant();
        assertNotNull(startInstant);
        assertFalse(startInstant.isBefore(before.minusSeconds(1)));
    }

    @Test
    public void testGetTimeUnstartedIsZero() {
        final StopWatch watch = new StopWatch();
        assertEquals(0, watch.getTime());
        assertEquals(0, watch.getNanoTime());
        assertEquals(Duration.ZERO, watch.getDuration());
    }

    @Test
    public void testGetTimeWithTimeUnit() throws InterruptedException {
        final StopWatch watch = new StopWatch();
        watch.start();
        Thread.sleep(5);
        watch.stop();
        final long nanos = watch.getNanoTime();
        assertEquals(TimeUnit.NANOSECONDS.toSeconds(nanos), watch.getTime(TimeUnit.SECONDS));
        assertEquals(TimeUnit.NANOSECONDS.toMillis(nanos), watch.getTime(TimeUnit.MILLISECONDS));
    }

    @Test
    public void testGetTimeWhileRunningReflectsElapsed() throws InterruptedException {
        final StopWatch watch = StopWatch.createStarted();
        Thread.sleep(10);
        final long t1 = watch.getTime();
        assertTrue(t1 >= 0);
        Thread.sleep(10);
        final long t2 = watch.getTime();
        assertTrue(t2 >= t1);
    }

    @Test
    public void testFormatSplitTime() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        final String formatted = watch.formatSplitTime();
        assertNotNull(formatted);
        assertTrue(formatted.matches("\\d+:\\d{2}:\\d{2}\\.\\d{3}"));
    }

    @Test
    public void testFormatTime() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        final String formatted = watch.formatTime();
        assertNotNull(formatted);
        assertTrue(formatted.matches("\\d+:\\d{2}:\\d{2}\\.\\d{3}"));
    }

    @Test
    public void testToStringWithoutMessage() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        final String str = watch.toString();
        assertEquals(watch.formatTime(), str);
    }

    @Test
    public void testToSplitStringWithoutMessage() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        final String str = watch.toSplitString();
        assertEquals(watch.formatSplitTime(), str);
    }

    @Test
    public void testToSplitStringWithMessage() {
        final StopWatch watch = new StopWatch("myLabel");
        watch.start();
        watch.split();
        final String str = watch.toSplitString();
        assertTrue(str.startsWith("myLabel "));
    }

    @Test
    public void testGetDeprecatedStartTimeMatchesInstant() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        assertEquals(watch.getStartInstant().toEpochMilli(), watch.getStartTime());
        assertEquals(watch.getStopInstant().toEpochMilli(), watch.getStopTime());
    }

    @Test
    public void testRunRunnableRecordsDurationAndSuspends() {
        final StopWatch watch = new StopWatch();
        final boolean[] ran = {false};
        watch.run(() -> ran[0] = true);
        assertTrue(ran[0]);
        assertTrue(watch.isSuspended());
        assertTrue(watch.getTime() >= 0);
    }

    @Test
    public void testGetSupplierReturnsValueAndSuspends() {
        final StopWatch watch = new StopWatch();
        final Integer result = watch.get(() -> 42);
        assertEquals(42, result.intValue());
        assertTrue(watch.isSuspended());
    }

    @Test
    public void testGetSupplierResumesAlreadyStartedWatch() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.suspend();
        final String result = watch.get(() -> "value");
        assertEquals("value", result);
        assertTrue(watch.isSuspended());
    }

    @Test
    public void testRunTPropagatesException() {
        final StopWatch watch = new StopWatch();
        final RuntimeException thrown = new RuntimeException("boom");
        final RuntimeException caught = assertThrows(RuntimeException.class, () -> watch.runT(() -> {
            throw thrown;
        }));
        assertSame(thrown, caught);
        assertTrue(watch.isSuspended());
    }

    @Test
    public void testGetTPropagatesExceptionAndSuspends() {
        final StopWatch watch = new StopWatch();
        final Exception thrown = new Exception("fail");
        final Exception caught = assertThrows(Exception.class, () -> watch.getT(() -> {
            throw thrown;
        }));
        assertSame(thrown, caught);
        assertTrue(watch.isSuspended());
    }

    @Test
    public void testSplitClassLabelAndDuration() {
        final Duration duration = Duration.ofMillis(100);
        final StopWatch.Split split = new StopWatch.Split("label", duration);
        assertEquals("label", split.getLabel());
        assertEquals(duration, split.getDuration());
        assertEquals("label", split.getLeft());
        assertEquals(duration, split.getRight());
        assertTrue(split.toString().contains("label"));
    }

    @Test
    public void testResetAfterSuspendedAllowsRestart() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.suspend();
        watch.reset();
        assertFalse(watch.isStarted());
        watch.start();
        assertTrue(watch.isStarted());
    }

    @Test
    public void testMultipleSplitsAccumulate() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        watch.unsplit();
        watch.split();
        watch.unsplit();
        watch.split();
        assertEquals(1, watch.getSplits().size());
    }
}
