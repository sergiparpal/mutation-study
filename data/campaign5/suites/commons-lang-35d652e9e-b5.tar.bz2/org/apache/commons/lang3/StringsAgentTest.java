/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link Strings}.
 */
class StringsAgentTest {

    @Test
    void testCsAppendIfMissing() {
        assertNull(Strings.CS.appendIfMissing(null, null));
        assertEquals("abc", Strings.CS.appendIfMissing("abc", null));
        assertEquals("xyz", Strings.CS.appendIfMissing("", "xyz"));
        assertEquals("abcxyz", Strings.CS.appendIfMissing("abc", "xyz"));
        assertEquals("abcxyz", Strings.CS.appendIfMissing("abcxyz", "xyz"));
        assertEquals("abcXYZxyz", Strings.CS.appendIfMissing("abcXYZ", "xyz"));
        assertEquals("abc", Strings.CS.appendIfMissing("abc", "xyz", ""));
        assertEquals("abcmno", Strings.CS.appendIfMissing("abcmno", "xyz", "mno"));
    }

    @Test
    void testCiAppendIfMissing() {
        assertEquals("abcXYZ", Strings.CI.appendIfMissing("abcXYZ", "xyz"));
        assertEquals("abcMNO", Strings.CI.appendIfMissing("abcMNO", "xyz", "mno"));
        assertEquals("xyz", Strings.CI.appendIfMissing("", "xyz"));
    }

    @Test
    void testCsCompare() {
        assertEquals(0, Strings.CS.compare(null, null));
        assertTrue(Strings.CS.compare(null, "a") < 0);
        assertTrue(Strings.CS.compare("a", null) > 0);
        assertEquals(0, Strings.CS.compare("abc", "abc"));
        assertTrue(Strings.CS.compare("a", "b") < 0);
        assertTrue(Strings.CS.compare("b", "a") > 0);
        assertTrue(Strings.CS.compare("a", "B") > 0);
        assertTrue(Strings.CS.compare("ab", "abc") < 0);
    }

    @Test
    void testCiCompare() {
        assertEquals(0, Strings.CI.compare(null, null));
        assertTrue(Strings.CI.compare(null, "a") < 0);
        assertTrue(Strings.CI.compare("a", null) > 0);
        assertEquals(0, Strings.CI.compare("abc", "ABC"));
        assertTrue(Strings.CI.compare("a", "B") < 0);
        assertTrue(Strings.CI.compare("A", "b") < 0);
    }

    @Test
    void testCsContains() {
        assertFalse(Strings.CS.contains(null, "a"));
        assertFalse(Strings.CS.contains("a", null));
        assertTrue(Strings.CS.contains("", ""));
        assertTrue(Strings.CS.contains("abc", ""));
        assertTrue(Strings.CS.contains("abc", "a"));
        assertFalse(Strings.CS.contains("abc", "z"));
        assertFalse(Strings.CS.contains("abc", "A"));
    }

    @Test
    void testCiContains() {
        assertFalse(Strings.CI.contains(null, "a"));
        assertFalse(Strings.CI.contains("a", null));
        assertTrue(Strings.CI.contains("", ""));
        assertTrue(Strings.CI.contains("abc", "A"));
        assertFalse(Strings.CI.contains("abc", "Z"));
    }

    @Test
    void testContainsAny() {
        assertFalse(Strings.CS.containsAny(null, "a"));
        assertFalse(Strings.CS.containsAny("", "a"));
        assertFalse(Strings.CS.containsAny("abc", (CharSequence[]) null));
        assertFalse(Strings.CS.containsAny("abc"));
        assertTrue(Strings.CS.containsAny("abcd", "ab", (CharSequence) null));
        assertTrue(Strings.CS.containsAny("abc", "d", "abc"));
        assertFalse(Strings.CS.containsAny("ABC", "d", "abc"));
        assertTrue(Strings.CI.containsAny("ABC", "d", "abc"));
    }

    @Test
    void testCsEndsWith() {
        assertTrue(Strings.CS.endsWith(null, null));
        assertFalse(Strings.CS.endsWith(null, "def"));
        assertFalse(Strings.CS.endsWith("abcdef", null));
        assertTrue(Strings.CS.endsWith("abcdef", "def"));
        assertFalse(Strings.CS.endsWith("ABCDEF", "def"));
        assertTrue(Strings.CS.endsWith("ABCDEF", ""));
    }

    @Test
    void testCiEndsWith() {
        assertTrue(Strings.CI.endsWith(null, null));
        assertTrue(Strings.CI.endsWith("abcdef", "def"));
        assertTrue(Strings.CI.endsWith("ABCDEF", "def"));
        assertFalse(Strings.CI.endsWith("ABCDEF", "cde"));
    }

    @Test
    void testEndsWithAny() {
        assertFalse(Strings.CS.endsWithAny(null, (CharSequence[]) null));
        assertFalse(Strings.CS.endsWithAny(null, "abc"));
        assertFalse(Strings.CS.endsWithAny("abcxyz", (CharSequence[]) null));
        assertTrue(Strings.CS.endsWithAny("abcxyz", ""));
        assertTrue(Strings.CS.endsWithAny("abcxyz", "xyz"));
        assertTrue(Strings.CS.endsWithAny("abcxyz", (CharSequence) null, "xyz", "abc"));
        assertTrue(Strings.CS.endsWithAny("abcXYZ", "def", "XYZ"));
        assertFalse(Strings.CS.endsWithAny("abcXYZ", "def", "xyz"));
    }

    @Test
    void testCsEqualsCharSequence() {
        assertTrue(Strings.CS.equals((CharSequence) null, (CharSequence) null));
        assertFalse(Strings.CS.equals((CharSequence) null, "abc"));
        assertFalse(Strings.CS.equals("abc", (CharSequence) null));
        assertTrue(Strings.CS.equals((CharSequence) "abc", (CharSequence) "abc"));
        assertFalse(Strings.CS.equals((CharSequence) "abc", (CharSequence) "ABC"));
        final StringBuilder sb = new StringBuilder("abc");
        assertTrue(Strings.CS.equals((CharSequence) "abc", sb));
    }

    @Test
    void testCiEqualsCharSequence() {
        assertTrue(Strings.CI.equals((CharSequence) null, (CharSequence) null));
        assertFalse(Strings.CI.equals((CharSequence) null, "abc"));
        assertTrue(Strings.CI.equals((CharSequence) "abc", (CharSequence) "ABC"));
        final StringBuilder sb = new StringBuilder("ABC");
        assertTrue(Strings.CI.equals((CharSequence) "abc", sb));
        assertFalse(Strings.CI.equals((CharSequence) "abc", (CharSequence) "abcd"));
    }

    @Test
    void testCsEqualsString() {
        assertTrue(Strings.CS.equals((String) null, (String) null));
        assertFalse(Strings.CS.equals((String) null, "abc"));
        assertFalse(Strings.CS.equals("abc", (String) null));
        assertTrue(Strings.CS.equals("abc", "abc"));
        assertFalse(Strings.CS.equals("abc", "ABC"));
    }

    @Test
    void testCiEqualsString() {
        assertTrue(Strings.CI.equals((String) null, (String) null));
        assertFalse(Strings.CI.equals((String) null, "abc"));
        assertTrue(Strings.CI.equals("abc", "ABC"));
    }

    @Test
    void testEqualsAny() {
        assertFalse(Strings.CS.equalsAny(null, (CharSequence[]) null));
        assertTrue(Strings.CS.equalsAny(null, (CharSequence) null, (CharSequence) null));
        assertFalse(Strings.CS.equalsAny(null, "abc", "def"));
        assertFalse(Strings.CS.equalsAny("abc", (CharSequence) null, "def"));
        assertTrue(Strings.CS.equalsAny("abc", "abc", "def"));
        assertFalse(Strings.CS.equalsAny("abc", "ABC", "DEF"));
        assertTrue(Strings.CI.equalsAny("abc", "ABC", "DEF"));
    }

    @Test
    void testCsIndexOfTwoArg() {
        assertEquals(-1, Strings.CS.indexOf(null, "a"));
        assertEquals(-1, Strings.CS.indexOf("a", null));
        assertEquals(0, Strings.CS.indexOf("", ""));
        assertEquals(-1, Strings.CS.indexOf("", "a"));
        assertEquals(0, Strings.CS.indexOf("aabaabaa", "a"));
        assertEquals(2, Strings.CS.indexOf("aabaabaa", "b"));
        assertEquals(1, Strings.CS.indexOf("aabaabaa", "ab"));
        assertEquals(0, Strings.CS.indexOf("aabaabaa", ""));
    }

    @Test
    void testCsIndexOfThreeArg() {
        assertEquals(-1, Strings.CS.indexOf(null, "a", 0));
        assertEquals(-1, Strings.CS.indexOf("a", null, 0));
        assertEquals(0, Strings.CS.indexOf("", "", 0));
        assertEquals(-1, Strings.CS.indexOf("", "a", 0));
        assertEquals(5, Strings.CS.indexOf("aabaabaa", "b", 3));
        assertEquals(-1, Strings.CS.indexOf("aabaabaa", "b", 9));
        assertEquals(2, Strings.CS.indexOf("aabaabaa", "b", -1));
        assertEquals(2, Strings.CS.indexOf("aabaabaa", "", 2));
        assertEquals(3, Strings.CS.indexOf("abc", "", 9));
    }

    @Test
    void testCiIndexOfThreeArg() {
        assertEquals(-1, Strings.CI.indexOf(null, "a", 0));
        assertEquals(-1, Strings.CI.indexOf("a", null, 0));
        assertEquals(0, Strings.CI.indexOf("", "", 0));
        assertEquals(0, Strings.CI.indexOf("aabaabaa", "A", 0));
        assertEquals(2, Strings.CI.indexOf("aabaabaa", "B", 0));
        assertEquals(1, Strings.CI.indexOf("aabaabaa", "AB", 0));
        assertEquals(5, Strings.CI.indexOf("aabaabaa", "B", 3));
        assertEquals(-1, Strings.CI.indexOf("aabaabaa", "B", 9));
        assertEquals(2, Strings.CI.indexOf("aabaabaa", "B", -1));
        assertEquals(2, Strings.CI.indexOf("aabaabaa", "", 2));
        assertEquals(-1, Strings.CI.indexOf("abc", "", 9));
    }

    @Test
    void testIsCaseSensitive() {
        assertTrue(Strings.CS.isCaseSensitive());
        assertFalse(Strings.CI.isCaseSensitive());
    }

    @Test
    void testCsLastIndexOfTwoArg() {
        assertEquals(-1, Strings.CS.lastIndexOf(null, "a"));
        assertEquals(-1, Strings.CS.lastIndexOf("a", null));
        assertEquals(0, Strings.CS.lastIndexOf("", ""));
        assertEquals(7, Strings.CS.lastIndexOf("aabaabaa", "a"));
        assertEquals(5, Strings.CS.lastIndexOf("aabaabaa", "b"));
        assertEquals(4, Strings.CS.lastIndexOf("aabaabaa", "ab"));
        assertEquals(8, Strings.CS.lastIndexOf("aabaabaa", ""));
    }

    @Test
    void testCiLastIndexOfTwoArg() {
        assertEquals(-1, Strings.CI.lastIndexOf(null, "a"));
        assertEquals(7, Strings.CI.lastIndexOf("aabaabaa", "A"));
        assertEquals(5, Strings.CI.lastIndexOf("aabaabaa", "B"));
        assertEquals(4, Strings.CI.lastIndexOf("aabaabaa", "AB"));
    }

    @Test
    void testCsLastIndexOfThreeArg() {
        assertEquals(-1, Strings.CS.lastIndexOf(null, "a", 8));
        assertEquals(-1, Strings.CS.lastIndexOf("a", null, 8));
        assertEquals(7, Strings.CS.lastIndexOf("aabaabaa", "a", 8));
        assertEquals(5, Strings.CS.lastIndexOf("aabaabaa", "b", 8));
        assertEquals(4, Strings.CS.lastIndexOf("aabaabaa", "ab", 8));
        assertEquals(5, Strings.CS.lastIndexOf("aabaabaa", "b", 9));
        assertEquals(-1, Strings.CS.lastIndexOf("aabaabaa", "b", -1));
        assertEquals(0, Strings.CS.lastIndexOf("aabaabaa", "a", 0));
        assertEquals(-1, Strings.CS.lastIndexOf("aabaabaa", "b", 0));
        assertEquals(-1, Strings.CS.lastIndexOf("aabaabaa", "b", 1));
        assertEquals(2, Strings.CS.lastIndexOf("aabaabaa", "b", 2));
        assertEquals(2, Strings.CS.lastIndexOf("aabaabaa", "ba", 2));
    }

    @Test
    void testCiLastIndexOfThreeArg() {
        assertEquals(-1, Strings.CI.lastIndexOf(null, "a", 8));
        assertEquals(7, Strings.CI.lastIndexOf("aabaabaa", "A", 8));
        assertEquals(5, Strings.CI.lastIndexOf("aabaabaa", "B", 8));
        assertEquals(4, Strings.CI.lastIndexOf("aabaabaa", "AB", 8));
        assertEquals(5, Strings.CI.lastIndexOf("aabaabaa", "B", 9));
        assertEquals(-1, Strings.CI.lastIndexOf("aabaabaa", "B", -1));
        assertEquals(0, Strings.CI.lastIndexOf("aabaabaa", "A", 0));
        assertEquals(-1, Strings.CI.lastIndexOf("aabaabaa", "B", 0));
    }

    @Test
    void testCsPrependIfMissing() {
        assertNull(Strings.CS.prependIfMissing(null, null));
        assertEquals("abc", Strings.CS.prependIfMissing("abc", null));
        assertEquals("xyz", Strings.CS.prependIfMissing("", "xyz"));
        assertEquals("xyzabc", Strings.CS.prependIfMissing("abc", "xyz"));
        assertEquals("xyzabc", Strings.CS.prependIfMissing("xyzabc", "xyz"));
        assertEquals("xyzXYZabc", Strings.CS.prependIfMissing("XYZabc", "xyz"));
        assertEquals("mnoabc", Strings.CS.prependIfMissing("mnoabc", "xyz", "mno"));
    }

    @Test
    void testCiPrependIfMissing() {
        assertEquals("XYZabc", Strings.CI.prependIfMissing("XYZabc", "xyz"));
        assertEquals("MNOabc", Strings.CI.prependIfMissing("MNOabc", "xyz", "mno"));
    }

    @Test
    void testCsRemove() {
        assertNull(Strings.CS.remove(null, "a"));
        assertEquals("", Strings.CS.remove("", "a"));
        assertEquals("abc", Strings.CS.remove("abc", null));
        assertEquals("abc", Strings.CS.remove("abc", ""));
        assertEquals("qd", Strings.CS.remove("queued", "ue"));
        assertEquals("queued", Strings.CS.remove("queued", "zz"));
    }

    @Test
    void testCiRemove() {
        assertEquals("qd", Strings.CI.remove("quEUed", "UE"));
        assertEquals("queued", Strings.CI.remove("queued", "zZ"));
    }

    @Test
    void testCsRemoveEnd() {
        assertNull(Strings.CS.removeEnd(null, "x"));
        assertEquals("", Strings.CS.removeEnd("", "x"));
        assertEquals("abc", Strings.CS.removeEnd("abc", null));
        assertEquals("www.domain.com", Strings.CS.removeEnd("www.domain.com", ".com."));
        assertEquals("www.domain", Strings.CS.removeEnd("www.domain.com", ".com"));
        assertEquals("www.domain.com", Strings.CS.removeEnd("www.domain.com", "domain"));
        assertEquals("abc", Strings.CS.removeEnd("abc", ""));
    }

    @Test
    void testCiRemoveEnd() {
        assertEquals("www.domain", Strings.CI.removeEnd("www.domain.com", ".COM"));
        assertEquals("www.domain", Strings.CI.removeEnd("www.domain.COM", ".com"));
    }

    @Test
    void testCsRemoveStart() {
        assertNull(Strings.CS.removeStart(null, "x"));
        assertEquals("", Strings.CS.removeStart("", "x"));
        assertEquals("abc", Strings.CS.removeStart("abc", null));
        assertEquals("domain.com", Strings.CS.removeStart("www.domain.com", "www."));
        assertEquals("domain.com", Strings.CS.removeStart("domain.com", "www."));
        assertEquals("www.domain.com", Strings.CS.removeStart("www.domain.com", "domain"));
        assertEquals("abc", Strings.CS.removeStart("abc", ""));
    }

    @Test
    void testCiRemoveStart() {
        assertEquals("domain.com", Strings.CI.removeStart("www.domain.com", "WWW."));
    }

    @Test
    void testCsReplaceThreeArg() {
        assertNull(Strings.CS.replace(null, "a", "b"));
        assertEquals("", Strings.CS.replace("", "a", "b"));
        assertEquals("any", Strings.CS.replace("any", null, "b"));
        assertEquals("any", Strings.CS.replace("any", "a", null));
        assertEquals("any", Strings.CS.replace("any", "", "b"));
        assertEquals("aba", Strings.CS.replace("aba", "a", null));
        assertEquals("b", Strings.CS.replace("aba", "a", ""));
        assertEquals("zbz", Strings.CS.replace("aba", "a", "z"));
    }

    @Test
    void testCiReplaceThreeArg() {
        assertEquals("b", Strings.CI.replace("abA", "A", ""));
        assertEquals("zbz", Strings.CI.replace("aba", "A", "z"));
    }

    @Test
    void testCsReplaceFourArg() {
        assertNull(Strings.CS.replace(null, "a", "b", 1));
        assertEquals("any", Strings.CS.replace("any", "a", "z", 0));
        assertEquals("abaa", Strings.CS.replace("abaa", "a", null, -1));
        assertEquals("b", Strings.CS.replace("abaa", "a", "", -1));
        assertEquals("abaa", Strings.CS.replace("abaa", "a", "z", 0));
        assertEquals("zbaa", Strings.CS.replace("abaa", "a", "z", 1));
        assertEquals("zbza", Strings.CS.replace("abaa", "a", "z", 2));
        assertEquals("zbzz", Strings.CS.replace("abaa", "a", "z", -1));
    }

    @Test
    void testCiReplaceFourArg() {
        assertEquals("zbaa", Strings.CI.replace("abaa", "A", "z", 1));
        assertEquals("zbza", Strings.CI.replace("abAa", "a", "z", 2));
        assertEquals("zbzz", Strings.CI.replace("abAa", "a", "z", -1));
    }

    @Test
    void testCsReplaceOnce() {
        assertNull(Strings.CS.replaceOnce(null, "a", "b"));
        assertEquals("ba", Strings.CS.replaceOnce("aba", "a", ""));
        assertEquals("zba", Strings.CS.replaceOnce("aba", "a", "z"));
    }

    @Test
    void testCiReplaceOnce() {
        assertEquals("Foofoo", Strings.CI.replaceOnce("FoOFoofoo", "foo", ""));
    }

    @Test
    void testCsStartsWith() {
        assertTrue(Strings.CS.startsWith(null, null));
        assertFalse(Strings.CS.startsWith(null, "abc"));
        assertFalse(Strings.CS.startsWith("abcdef", null));
        assertTrue(Strings.CS.startsWith("abcdef", "abc"));
        assertFalse(Strings.CS.startsWith("ABCDEF", "abc"));
    }

    @Test
    void testCiStartsWith() {
        assertTrue(Strings.CI.startsWith(null, null));
        assertTrue(Strings.CI.startsWith("abcdef", "abc"));
        assertTrue(Strings.CI.startsWith("ABCDEF", "abc"));
    }

    @Test
    void testStartsWithAny() {
        assertFalse(Strings.CS.startsWithAny(null, (CharSequence[]) null));
        assertFalse(Strings.CS.startsWithAny(null, "abc"));
        assertFalse(Strings.CS.startsWithAny("abcxyz", (CharSequence[]) null));
        assertTrue(Strings.CS.startsWithAny("abcxyz", ""));
        assertTrue(Strings.CS.startsWithAny("abcxyz", "abc"));
        assertTrue(Strings.CS.startsWithAny("abcxyz", (CharSequence) null, "xyz", "abc"));
        assertFalse(Strings.CS.startsWithAny("abcxyz", (CharSequence) null, "xyz", "ABCX"));
        assertTrue(Strings.CI.startsWithAny("abcxyz", (CharSequence) null, "xyz", "ABCX"));
    }

    @Test
    void testBuilderDefaults() {
        final Strings ci = Strings.builder().setIgnoreCase(true).get();
        final Strings cs = Strings.builder().setIgnoreCase(false).get();
        assertFalse(ci.isCaseSensitive());
        assertTrue(cs.isCaseSensitive());
        assertTrue(ci.equals("abc", "ABC"));
        assertFalse(cs.equals("abc", "ABC"));
    }

    @Test
    void testBuilderNullIsLessFalse() {
        final Strings cs = Strings.builder().setIgnoreCase(false).setNullIsLess(false).get();
        assertTrue(cs.compare(null, "a") > 0);
        assertTrue(cs.compare("a", null) < 0);
        assertEquals(0, cs.compare(null, null));
    }

    @Test
    void testSingletonIdentitySameObjectCompareZero() {
        final String s = "same";
        assertEquals(0, Strings.CS.compare(s, s));
        assertEquals(0, Strings.CI.compare(s, s));
        assertSame(Strings.CS, Strings.CS);
    }

    @Test
    void testIndexOfEmptyStartPosBeyondLength() {
        assertEquals(3, Strings.CS.indexOf("abc", "", 3));
        assertEquals(3, Strings.CS.indexOf("abc", "", 100));
    }

    @Test
    void testLastIndexOfNegativeStartPos() {
        assertEquals(-1, Strings.CS.lastIndexOf("abc", "a", -1));
        assertEquals(-1, Strings.CI.lastIndexOf("abc", "a", -1));
    }
}
