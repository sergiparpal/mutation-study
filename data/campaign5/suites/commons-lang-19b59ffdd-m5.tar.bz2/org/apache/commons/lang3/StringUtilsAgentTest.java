/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Locale;
import java.util.function.Supplier;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link StringUtils}.
 */
public class StringUtilsAgentTest {

    @Test
    public void testAbbreviate() {
        assertNull(StringUtils.abbreviate(null, 10));
        assertEquals("", StringUtils.abbreviate("", 10));
        assertEquals("abcdefg...", StringUtils.abbreviate("abcdefghijklmno", 10));
        assertEquals("abcdefghij", StringUtils.abbreviate("abcdefghij", 10));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.abbreviate("abcdefghij", 3);
            }
        });
    }

    @Test
    public void testAbbreviateMiddle() {
        assertNull(StringUtils.abbreviateMiddle(null, ".", 10));
        assertEquals("abc", StringUtils.abbreviateMiddle("abc", ".", 10));
        assertEquals("ab.g", StringUtils.abbreviateMiddle("abcdefg", ".", 4));
    }

    @Test
    public void testCapitalizeAndUncapitalize() {
        assertNull(StringUtils.capitalize(null));
        assertEquals("", StringUtils.capitalize(""));
        assertEquals("Cat", StringUtils.capitalize("cat"));
        assertEquals("CAt", StringUtils.capitalize("CAt"));

        assertNull(StringUtils.uncapitalize(null));
        assertEquals("", StringUtils.uncapitalize(""));
        assertEquals("cat", StringUtils.uncapitalize("Cat"));
        assertEquals("cAT", StringUtils.uncapitalize("CAT"));
    }

    @Test
    public void testCenter() {
        assertNull(StringUtils.center(null, 4));
        assertEquals("    ", StringUtils.center("", 4));
        assertEquals("ab", StringUtils.center("ab", 0));
        assertEquals(" ab ", StringUtils.center("ab", 4));
        assertEquals("abcd", StringUtils.center("abcd", 2));
        assertEquals("yayxay", StringUtils.center("a", 6, "yz"));
        assertEquals("xxaxxx", StringUtils.center("a", 6, 'x'));
    }

    @Test
    public void testChompAndChop() {
        assertNull(StringUtils.chomp(null));
        assertEquals("", StringUtils.chomp(""));
        assertEquals("abc", StringUtils.chomp("abc\r\n"));
        assertEquals("abc\r\n", StringUtils.chomp("abc\r\n", "x"));

        assertNull(StringUtils.chop(null));
        assertEquals("", StringUtils.chop(""));
        assertEquals("abc", StringUtils.chop("abcx"));
        assertEquals("", StringUtils.chop("x"));
    }

    @Test
    public void testCompare() {
        assertEquals(0, StringUtils.compare(null, null));
        assertTrue(StringUtils.compare(null, "a") < 0);
        assertTrue(StringUtils.compare("a", null) > 0);
        assertTrue(StringUtils.compare("a", "b") < 0);

        assertTrue(StringUtils.compare(null, "a", true) < 0);
        assertTrue(StringUtils.compare(null, "a", false) > 0);
        assertTrue(StringUtils.compare("a", null, true) > 0);
        assertTrue(StringUtils.compare("a", null, false) < 0);
    }

    @Test
    public void testCompareIgnoreCase() {
        assertEquals(0, StringUtils.compareIgnoreCase("ABC", "abc"));
        assertTrue(StringUtils.compareIgnoreCase("a", "B") < 0);
        assertTrue(StringUtils.compareIgnoreCase(null, "a", false) > 0);
    }

    @Test
    public void testContains() {
        assertFalse(StringUtils.contains(null, "a"));
        assertFalse(StringUtils.contains("abc", null));
        assertTrue(StringUtils.contains("abc", ""));
        assertTrue(StringUtils.contains("abc", "b"));
        assertFalse(StringUtils.contains("abc", "z"));

        assertFalse(StringUtils.contains((CharSequence) null, 'a'));
        assertTrue(StringUtils.contains("abc", 'b'));
    }

    @Test
    public void testContainsAnyAndNoneAndOnly() {
        assertFalse(StringUtils.containsAny(null, 'a'));
        assertFalse(StringUtils.containsAny("", 'a'));
        assertTrue(StringUtils.containsAny("zzabyy", 'a', 'b'));
        assertFalse(StringUtils.containsAny("zzxxyy", 'a', 'b'));

        assertTrue(StringUtils.containsAny("zzabyy", "a", "x"));
        assertTrue(StringUtils.containsAnyIgnoreCase("zzABYY", "a", "x"));

        assertTrue(StringUtils.containsNone("abc", 'x', 'y'));
        assertFalse(StringUtils.containsNone("abc", 'x', 'a'));

        assertTrue(StringUtils.containsOnly("abab", 'a', 'b'));
        assertFalse(StringUtils.containsOnly("abcd", 'a', 'b'));
        assertFalse(StringUtils.containsOnly(null, 'a'));
        assertFalse(StringUtils.containsOnly("ab", (char[]) null));
    }

    @Test
    public void testContainsIgnoreCaseAndWhitespace() {
        assertTrue(StringUtils.containsIgnoreCase("ABC", "b"));
        assertFalse(StringUtils.containsIgnoreCase(null, "b"));

        assertFalse(StringUtils.containsWhitespace(null));
        assertFalse(StringUtils.containsWhitespace(""));
        assertTrue(StringUtils.containsWhitespace("ab c"));
    }

    @Test
    public void testCountMatches() {
        assertEquals(0, StringUtils.countMatches(null, 'a'));
        assertEquals(0, StringUtils.countMatches("", 'a'));
        assertEquals(3, StringUtils.countMatches("abcabcabc", 'a'));

        assertEquals(0, StringUtils.countMatches(null, "ab"));
        assertEquals(0, StringUtils.countMatches("abcabc", ""));
        assertEquals(2, StringUtils.countMatches("abcabc", "abc"));
    }

    @Test
    public void testDefaultValues() {
        assertEquals("", StringUtils.defaultIfBlank("", "default"));
        assertEquals("default", StringUtils.defaultIfBlank(" ", "default"));
        assertEquals("abc", StringUtils.defaultIfBlank("abc", "default"));

        assertEquals("default", StringUtils.defaultIfEmpty("", "default"));
        assertEquals("abc", StringUtils.defaultIfEmpty("abc", "default"));

        assertEquals("", StringUtils.defaultString(null));
        assertEquals("abc", StringUtils.defaultString("abc"));
        assertEquals("NULL", StringUtils.defaultString(null, "NULL"));
    }

    @Test
    public void testDeleteWhitespace() {
        assertNull(StringUtils.deleteWhitespace(null));
        assertEquals("", StringUtils.deleteWhitespace(""));
        assertEquals("abc", StringUtils.deleteWhitespace("  a b  c  "));
    }

    @Test
    public void testDifference() {
        assertEquals("abc", StringUtils.difference(null, "abc"));
        assertNull(StringUtils.difference(null, null));
        assertEquals("", StringUtils.difference("abc", "abc"));
        assertEquals("xyz", StringUtils.difference("", "xyz"));
        assertEquals("ty", StringUtils.difference("abc", "abty"));
    }

    @Test
    public void testEndsWithFamily() {
        assertTrue(StringUtils.endsWith(null, null));
        assertFalse(StringUtils.endsWith(null, "abc"));
        assertTrue(StringUtils.endsWith("abcdef", "def"));
        assertFalse(StringUtils.endsWith("ABCDEF", "def"));

        assertTrue(StringUtils.endsWithAny("abcxyz", "xyz", "123"));
        assertFalse(StringUtils.endsWithAny("abcxyz", "foo", "123"));

        assertTrue(StringUtils.endsWithIgnoreCase("ABCDEF", "def"));
    }

    @Test
    public void testEqualsFamily() {
        assertTrue(StringUtils.equals(null, null));
        assertFalse(StringUtils.equals(null, "abc"));
        assertTrue(StringUtils.equals("abc", "abc"));
        assertFalse(StringUtils.equals("abc", "ABC"));

        assertTrue(StringUtils.equalsAny("abc", "xyz", "abc"));
        assertFalse(StringUtils.equalsAny("abc", "xyz", "def"));

        assertTrue(StringUtils.equalsAnyIgnoreCase("ABC", "xyz", "abc"));

        assertTrue(StringUtils.equalsIgnoreCase("abc", "ABC"));
        assertTrue(StringUtils.equalsIgnoreCase(null, null));
        assertFalse(StringUtils.equalsIgnoreCase(null, "abc"));
    }

    @Test
    public void testGetBytes() throws UnsupportedEncodingException {
        assertArrayEquals(new byte[0], StringUtils.getBytes(null, StandardCharsets.UTF_8));
        assertArrayEquals("abc".getBytes(StandardCharsets.UTF_8), StringUtils.getBytes("abc", StandardCharsets.UTF_8));

        assertArrayEquals(new byte[0], StringUtils.getBytes(null, "UTF-8"));
        assertArrayEquals("abc".getBytes("UTF-8"), StringUtils.getBytes("abc", "UTF-8"));
    }

    @Test
    public void testGetCommonPrefix() {
        assertEquals("", StringUtils.getCommonPrefix((String[]) null));
        assertEquals("", StringUtils.getCommonPrefix());
        assertEquals("abc", StringUtils.getCommonPrefix("abc"));
        assertEquals("", StringUtils.getCommonPrefix((String) null, (String) null));
        assertEquals("ab", StringUtils.getCommonPrefix("abcde", "abxyz"));
        assertEquals("", StringUtils.getCommonPrefix("abcde", "xyz"));
    }

    @Test
    public void testGetDigits() {
        assertNull(StringUtils.getDigits(null));
        assertEquals("", StringUtils.getDigits(""));
        assertEquals("", StringUtils.getDigits("abc"));
        assertEquals("1000", StringUtils.getDigits("1000$"));
        assertEquals("5417543010", StringUtils.getDigits("(541) 754-3010"));
    }

    @Test
    public void testGetLevenshteinDistance() {
        assertEquals(0, StringUtils.getLevenshteinDistance("", ""));
        assertEquals(7, StringUtils.getLevenshteinDistance("elephant", "hippo"));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.getLevenshteinDistance(null, "a");
            }
        });

        assertEquals(7, StringUtils.getLevenshteinDistance("elephant", "hippo", 7));
        assertEquals(-1, StringUtils.getLevenshteinDistance("elephant", "hippo", 6));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.getLevenshteinDistance("a", "b", -1);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.getLevenshteinDistance(null, null, 1);
            }
        });
    }

    @Test
    public void testIndexOfFamily() {
        assertEquals(-1, StringUtils.indexOf(null, "a"));
        assertEquals(-1, StringUtils.indexOf("abc", null));
        assertEquals(0, StringUtils.indexOf("", ""));
        assertEquals(2, StringUtils.indexOf("abcabc", "c"));
        assertEquals(5, StringUtils.indexOf("abcabc", "c", 3));

        assertEquals(-1, StringUtils.indexOf((CharSequence) null, 'a'));
        assertEquals(2, StringUtils.indexOf("abc", 'c'));
        assertEquals(5, StringUtils.indexOf("abcabc", 'c', 3));

        assertEquals(0, StringUtils.indexOfAny("zzabyycdxx", 'z', 'a'));
        assertEquals(-1, StringUtils.indexOfAny((CharSequence) null, 'a'));
        assertEquals(2, StringUtils.indexOfAny("zzabyycdxx", "ab", "cd"));

        assertEquals(2, StringUtils.indexOfAnyBut("zzabyycdxx", 'z'));
        assertEquals(-1, StringUtils.indexOfAnyBut("zzzz", 'z'));

        assertEquals(0, StringUtils.indexOfIgnoreCase("aabaabaa", "A"));
        assertEquals(2, StringUtils.indexOfIgnoreCase("aabaabaa", "B"));
    }

    @Test
    public void testIndexOfDifference() {
        assertEquals(-1, StringUtils.indexOfDifference("abc", "abc"));
        assertEquals(1, StringUtils.indexOfDifference("abc", "a"));
        assertEquals(2, StringUtils.indexOfDifference("abc", "abd"));
        assertEquals(-1, StringUtils.indexOfDifference((CharSequence[]) null));
    }

    @Test
    public void testIsCheckFamily() {
        assertTrue(StringUtils.isAllBlank(null, " "));
        assertFalse(StringUtils.isAllBlank(null, "a"));
        assertTrue(StringUtils.isAllEmpty(null, ""));
        assertFalse(StringUtils.isAllEmpty(null, "a"));

        assertTrue(StringUtils.isAllLowerCase("abc"));
        assertFalse(StringUtils.isAllLowerCase("abC"));
        assertFalse(StringUtils.isAllLowerCase(null));

        assertTrue(StringUtils.isAllUpperCase("ABC"));
        assertFalse(StringUtils.isAllUpperCase("ABc"));

        assertTrue(StringUtils.isAlpha("abc"));
        assertFalse(StringUtils.isAlpha("ab2c"));
        assertFalse(StringUtils.isAlpha(""));
        assertFalse(StringUtils.isAlpha(null));

        assertTrue(StringUtils.isAlphanumeric("ab2c"));
        assertFalse(StringUtils.isAlphanumeric("ab-c"));

        assertTrue(StringUtils.isAlphanumericSpace("ab2 c"));
        assertFalse(StringUtils.isAlphanumericSpace("ab2!c"));

        assertTrue(StringUtils.isAlphaSpace("ab c"));
        assertFalse(StringUtils.isAlphaSpace("ab2c"));

        assertTrue(StringUtils.isAnyBlank((String) null));
        assertFalse(StringUtils.isAnyBlank("abc"));

        assertTrue(StringUtils.isAnyEmpty((String) null));
        assertFalse(StringUtils.isAnyEmpty("abc"));

        assertTrue(StringUtils.isAsciiPrintable("abc!"));
        assertFalse(StringUtils.isAsciiPrintable("ab\tc"));
        assertFalse(StringUtils.isAsciiPrintable(null));

        assertTrue(StringUtils.isBlank(null));
        assertTrue(StringUtils.isBlank(""));
        assertTrue(StringUtils.isBlank("   "));
        assertFalse(StringUtils.isBlank("abc"));

        assertTrue(StringUtils.isEmpty(null));
        assertTrue(StringUtils.isEmpty(""));
        assertFalse(StringUtils.isEmpty(" "));

        assertTrue(StringUtils.isMixedCase("aBc"));
        assertFalse(StringUtils.isMixedCase("abc"));
        assertFalse(StringUtils.isMixedCase(null));

        assertTrue(StringUtils.isNoneBlank("abc", "xyz"));
        assertFalse(StringUtils.isNoneBlank("abc", ""));

        assertTrue(StringUtils.isNoneEmpty("abc", "xyz"));
        assertFalse(StringUtils.isNoneEmpty("abc", ""));

        assertTrue(StringUtils.isNotBlank("abc"));
        assertFalse(StringUtils.isNotBlank(" "));

        assertTrue(StringUtils.isNotEmpty("abc"));
        assertFalse(StringUtils.isNotEmpty(""));

        assertTrue(StringUtils.isNumeric("123"));
        assertFalse(StringUtils.isNumeric("12 3"));
        assertFalse(StringUtils.isNumeric("-123"));
        assertFalse(StringUtils.isNumeric(null));

        assertTrue(StringUtils.isNumericSpace("12 3"));
        assertFalse(StringUtils.isNumericSpace("12a3"));

        assertTrue(StringUtils.isWhitespace("   "));
        assertTrue(StringUtils.isWhitespace(""));
        assertFalse(StringUtils.isWhitespace("ab"));
        assertFalse(StringUtils.isWhitespace(null));
    }

    @Test
    public void testJoinArrays() {
        assertNull(StringUtils.join((Object[]) null, ','));
        assertEquals("", StringUtils.join(new Object[0], ','));
        assertEquals("a,b,c", StringUtils.join(new Object[] {"a", "b", "c"}, ','));
        assertEquals("a,,c", StringUtils.join(new Object[] {"a", null, "c"}, ','));

        assertEquals("a-b-c", StringUtils.join(new Object[] {"a", "b", "c"}, "-"));
        assertEquals("a", StringUtils.join(new Object[] {"a", "b", "c"}, "-", 0, 1));

        assertEquals("1,2,3", StringUtils.join(new int[] {1, 2, 3}, ','));
        assertEquals("true,false", StringUtils.join(new boolean[] {true, false}, ','));
        assertEquals("a,b,c", StringUtils.join(new char[] {'a', 'b', 'c'}, ','));

        assertEquals("a,b", StringUtils.join(Arrays.asList("a", "b").iterator(), ','));
        assertEquals("", StringUtils.join((Iterator<?>) Arrays.asList().iterator(), ','));
    }

    @Test
    public void testJoinWith() {
        assertEquals("a-b-3", StringUtils.joinWith("-", "a", "b", 3));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.joinWith(null, "a", "b");
            }
        });
    }

    @Test
    public void testLastIndexOfFamily() {
        assertEquals(-1, StringUtils.lastIndexOf(null, "a"));
        assertEquals(2, StringUtils.lastIndexOf("aabaabaa", "b"));
        assertEquals(2, StringUtils.lastIndexOf("aabaabaa", "b", 4));

        assertEquals(-1, StringUtils.lastIndexOf((CharSequence) null, 'a'));
        assertEquals(7, StringUtils.lastIndexOf("aabaabaa", 'a'));

        assertEquals(6, StringUtils.lastIndexOfAny("zzabyycdxx", "ab", "cd"));
        assertEquals(-1, StringUtils.lastIndexOfAny("zzabyycdxx", "mn", "op"));

        assertEquals(5, StringUtils.lastIndexOfIgnoreCase("aabaabaa", "B"));
        assertEquals(2, StringUtils.lastIndexOfIgnoreCase("aabaabaa", "B", 4));
    }

    @Test
    public void testLeftRightMid() {
        assertNull(StringUtils.left(null, 3));
        assertEquals("", StringUtils.left("abc", -1));
        assertEquals("ab", StringUtils.left("abc", 2));
        assertEquals("abc", StringUtils.left("abc", 10));

        assertNull(StringUtils.right(null, 3));
        assertEquals("", StringUtils.right("abc", -1));
        assertEquals("bc", StringUtils.right("abc", 2));
        assertEquals("abc", StringUtils.right("abc", 10));

        assertNull(StringUtils.mid(null, 0, 2));
        assertEquals("", StringUtils.mid("abc", 0, -1));
        assertEquals("ab", StringUtils.mid("abc", 0, 2));
        assertEquals("c", StringUtils.mid("abc", 4, 2));
    }

    @Test
    public void testPadFamily() {
        assertNull(StringUtils.leftPad(null, 3));
        assertEquals("  ab", StringUtils.leftPad("ab", 4));
        assertEquals("ab", StringUtils.leftPad("ab", 1));
        assertEquals("xxab", StringUtils.leftPad("ab", 4, 'x'));
        assertEquals("xyxyab", StringUtils.leftPad("ab", 6, "xy"));

        assertNull(StringUtils.rightPad(null, 3));
        assertEquals("ab  ", StringUtils.rightPad("ab", 4));
        assertEquals("ab", StringUtils.rightPad("ab", 1));
        assertEquals("abxx", StringUtils.rightPad("ab", 4, 'x'));
        assertEquals("abxyxy", StringUtils.rightPad("ab", 6, "xy"));
    }

    @Test
    public void testLength() {
        assertEquals(0, StringUtils.length(null));
        assertEquals(0, StringUtils.length(""));
        assertEquals(3, StringUtils.length("abc"));
    }

    @Test
    public void testCaseConversions() {
        assertNull(StringUtils.lowerCase(null));
        assertEquals("abc", StringUtils.lowerCase("ABC"));
        assertEquals("abc", StringUtils.lowerCase("ABC", Locale.ROOT));

        assertNull(StringUtils.upperCase(null));
        assertEquals("ABC", StringUtils.upperCase("abc"));
        assertEquals("ABC", StringUtils.upperCase("abc", Locale.ROOT));

        assertNull(StringUtils.toRootLowerCase(null));
        assertEquals("abc", StringUtils.toRootLowerCase("ABC"));

        assertNull(StringUtils.toRootUpperCase(null));
        assertEquals("ABC", StringUtils.toRootUpperCase("abc"));

        assertNull(StringUtils.swapCase(null));
        assertEquals("", StringUtils.swapCase(""));
        assertEquals("The DOG has a BONE", StringUtils.swapCase("tHE dog HAS A bone"));
    }

    @Test
    public void testNormalizeSpace() {
        assertNull(StringUtils.normalizeSpace(null));
        assertEquals("", StringUtils.normalizeSpace(""));
        assertEquals("a b c", StringUtils.normalizeSpace("  a   b   c  "));
    }

    @Test
    public void testOverlay() {
        assertEquals("abef", StringUtils.overlay("abcdef", "", 2, 4));
        assertEquals("abzzzzef", StringUtils.overlay("abcdef", "zzzz", 2, 4));
        assertNull(StringUtils.overlay(null, "x", 0, 0));
    }

    @Test
    public void testPrependIfMissing() {
        assertNull(StringUtils.prependIfMissing(null, "xyz"));
        assertEquals("xyzabc", StringUtils.prependIfMissing("abc", "xyz"));
        assertEquals("abc", StringUtils.prependIfMissing("abc", "a"));
        assertEquals("Xyzabc", StringUtils.prependIfMissingIgnoreCase("abc", "Xyz"));
        assertEquals("abc", StringUtils.prependIfMissingIgnoreCase("abc", "A"));
    }

    @Test
    public void testRemoveFamily() {
        assertNull(StringUtils.remove(null, 'a'));
        assertEquals("qeout", StringUtils.remove("queued", 'u'));

        assertNull(StringUtils.remove(null, "ue"));
        assertEquals("qd", StringUtils.remove("queued", "ue"));
        assertEquals("abc", StringUtils.remove("abc", (String) null));
        assertEquals("abc", StringUtils.remove("abc", ""));

        assertNull(StringUtils.removeAll(null, "a"));
        assertEquals("", StringUtils.removeAll("foobar", "o"));

        assertNull(StringUtils.removeEnd(null, "a"));
        assertEquals("www.domain.com", StringUtils.removeEnd("www.domain.com", "x"));
        assertEquals("www.domain", StringUtils.removeEnd("www.domain.com", ".com"));

        assertEquals("www.domain", StringUtils.removeEndIgnoreCase("www.domain.COM", ".com"));

        assertNull(StringUtils.removeFirst(null, "a"));
        assertEquals("foobar", StringUtils.removeFirst("foobar", "x"));

        assertEquals("qd", StringUtils.removeIgnoreCase("queued", "UE"));

        assertNull(StringUtils.removePattern(null, "a"));
        assertEquals("AB", StringUtils.removePattern("A\nB", ".*\\n"));

        assertNull(StringUtils.removeStart(null, 'a'));
        assertEquals("omain.com", StringUtils.removeStart("domain.com", 'd'));

        assertNull(StringUtils.removeStart(null, "www."));
        assertEquals("domain.com", StringUtils.removeStart("www.domain.com", "www."));

        assertEquals("domain.com", StringUtils.removeStartIgnoreCase("WWW.domain.com", "www."));
    }

    @Test
    public void testRepeat() {
        assertEquals("", StringUtils.repeat('x', -2));
        assertEquals("xxx", StringUtils.repeat('x', 3));

        assertNull(StringUtils.repeat((String) null, 2));
        assertEquals("", StringUtils.repeat("", 0));
        assertEquals("", StringUtils.repeat("a", -2));
        assertEquals("abab", StringUtils.repeat("ab", 2));

        assertEquals("a-a-a", StringUtils.repeat("a", "-", 3));
        assertEquals("", StringUtils.repeat("a", "-", 0));
    }

    @Test
    public void testReplaceFamily() {
        assertNull(StringUtils.replace(null, "a", "b"));
        assertEquals("zzz", StringUtils.replace("aaa", "a", "z"));
        assertEquals("zaa", StringUtils.replace("aaa", "a", "z", 1));

        assertNull(StringUtils.replaceAll(null, "a", "z"));
        assertEquals("zzz", StringUtils.replaceAll("aaa", "a", "z"));

        assertNull(StringUtils.replaceChars(null, 'a', 'z'));
        assertEquals("zbcz", StringUtils.replaceChars("abca", 'a', 'z'));

        assertEquals("jelly", StringUtils.replaceChars("hello", "ho", "jy"));

        assertNull(StringUtils.replaceIgnoreCase(null, "a", "z"));
        assertEquals("zzz", StringUtils.replaceIgnoreCase("AaA", "a", "z"));

        assertNull(StringUtils.replaceOnce(null, "a", "z"));
        assertEquals("zaa", StringUtils.replaceOnce("aaa", "a", "z"));

        assertEquals("zaa", StringUtils.replaceOnceIgnoreCase("Aaa", "a", "z"));

        assertNull(StringUtils.replacePattern(null, "a", "z"));
        assertEquals("z", StringUtils.replacePattern("abc", "[a-c]+", "z"));

        assertNull(StringUtils.replaceFirst(null, "a", "z"));
        assertEquals("zbc", StringUtils.replaceFirst("abc", "a", "z"));
    }

    @Test
    public void testReplaceEachFamily() {
        assertNull(StringUtils.replaceEach(null, new String[] {"a"}, new String[] {"b"}));
        assertEquals("wcte", StringUtils.replaceEach("abcde", new String[] {"ab", "d"}, new String[] {"w", "t"}));
        assertEquals("dcte", StringUtils.replaceEach("abcde", new String[] {"ab", "d"}, new String[] {"d", "t"}));

        assertEquals("tcte", StringUtils.replaceEachRepeatedly("abcde", new String[] {"ab", "d"}, new String[] {"d", "t"}));
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.replaceEachRepeatedly("abcde", new String[] {"ab", "d"}, new String[] {"d", "ab"});
            }
        });
    }

    @Test
    public void testReverseFamily() {
        assertNull(StringUtils.reverse(null));
        assertEquals("", StringUtils.reverse(""));
        assertEquals("cba", StringUtils.reverse("abc"));

        assertNull(StringUtils.reverseDelimited(null, '.'));
        assertEquals("c.b.a", StringUtils.reverseDelimited("a.b.c", '.'));
    }

    @Test
    public void testRotate() {
        assertNull(StringUtils.rotate(null, 1));
        assertEquals("", StringUtils.rotate("", 1));
        assertEquals("abcdefg", StringUtils.rotate("abcdefg", 0));
        assertEquals("fgabcde", StringUtils.rotate("abcdefg", 2));
        assertEquals("cdefgab", StringUtils.rotate("abcdefg", -2));
    }

    @Test
    public void testSplitFamily() {
        assertNull(StringUtils.split(null));
        assertArrayEquals(new String[0], StringUtils.split(""));
        assertArrayEquals(new String[] {"ab", "cd", "ef"}, StringUtils.split("ab cd ef"));

        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.split("a.b.c", '.'));
        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.split("a..b.c", '.'));

        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.split("a:b:c", ":"));
        assertArrayEquals(new String[] {"a", "b,c"}, StringUtils.split("a,b,c", ",", 2));

        assertArrayEquals(new String[] {"a", "", "b", "c"}, StringUtils.splitPreserveAllTokens("a..b.c", '.'));

        assertArrayEquals(new String[] {"ab", "cd", "ef"}, StringUtils.splitByWholeSeparator("ab-!-cd-!-ef", "-!-"));

        assertArrayEquals(new String[] {"ab", "", "cd"}, StringUtils.splitByWholeSeparatorPreserveAllTokens("ab--cd", "-"));

        assertArrayEquals(new String[] {"ab", "DE"}, StringUtils.splitByCharacterType("abDE"));
        assertArrayEquals(new String[] {"ab", "De"}, StringUtils.splitByCharacterTypeCamelCase("abDe"));
    }

    @Test
    public void testSplitByWholeSeparatorExact() {
        assertArrayEquals(new String[] {"ab", "cd", "ef"}, StringUtils.splitByWholeSeparator("ab:cd:ef", ":"));
        assertArrayEquals(new String[] {"ab", "cd:ef"}, StringUtils.splitByWholeSeparator("ab:cd:ef", ":", 2));
    }

    @Test
    public void testStartsWithFamily() {
        assertTrue(StringUtils.startsWith(null, null));
        assertFalse(StringUtils.startsWith(null, "abc"));
        assertTrue(StringUtils.startsWith("abcdef", "abc"));
        assertFalse(StringUtils.startsWith("ABCDEF", "abc"));

        assertTrue(StringUtils.startsWithAny("abcxyz", "xyz", "abc"));
        assertFalse(StringUtils.startsWithAny("abcxyz", "xyz", "123"));

        assertTrue(StringUtils.startsWithIgnoreCase("ABCDEF", "abc"));
    }

    @Test
    public void testStripFamily() {
        assertNull(StringUtils.strip(null));
        assertEquals("", StringUtils.strip("   "));
        assertEquals("abc", StringUtils.strip("  abc  "));
        assertEquals("abc  ", StringUtils.strip("  abc  ", " \t"));

        assertNull(StringUtils.stripAccents(null));
        assertEquals("eclair", StringUtils.stripAccents("éclair"));

        assertArrayEquals(new String[] {"abc", "ABC"}, StringUtils.stripAll("  abc  ", "  ABC  "));
        assertArrayEquals(new String[] {"abc"}, StringUtils.stripAll(new String[] {" abc "}, " "));

        assertNull(StringUtils.stripEnd(null, null));
        assertEquals("abc", StringUtils.stripEnd("abc  ", null));

        assertNull(StringUtils.stripStart(null, null));
        assertEquals("abc  ", StringUtils.stripStart("  abc  ", null));

        assertEquals("", StringUtils.stripToEmpty(null));
        assertEquals("abc", StringUtils.stripToEmpty("  abc  "));

        assertNull(StringUtils.stripToNull("   "));
        assertEquals("abc", StringUtils.stripToNull("  abc  "));
    }

    @Test
    public void testSubstringFamily() {
        assertNull(StringUtils.substring(null, 0));
        assertEquals("cde", StringUtils.substring("abcde", 2));
        assertEquals("cde", StringUtils.substring("abcde", -3));
        assertEquals("", StringUtils.substring("abcde", 10));

        assertNull(StringUtils.substring(null, 0, 2));
        assertEquals("ab", StringUtils.substring("abcde", 0, 2));
        assertEquals("cde", StringUtils.substring("abcde", 2, 10));
        assertEquals("", StringUtils.substring("abcde", 4, 2));

        assertNull(StringUtils.substringAfter(null, 'c'));
        assertEquals("de", StringUtils.substringAfter("abcde", 'c'));
        assertEquals("", StringUtils.substringAfter("abcde", 'z'));

        assertNull(StringUtils.substringAfter(null, "c"));
        assertEquals("", StringUtils.substringAfter("abc", null));
        assertEquals("cba", StringUtils.substringAfter("abcba", "b"));

        assertEquals("ba", StringUtils.substringAfterLast("abcba", "c"));
        assertEquals("", StringUtils.substringAfterLast("abc", null));

        assertEquals("ab", StringUtils.substringBefore("abcba", "c"));
        assertEquals("abc", StringUtils.substringBefore("abc", null));
        assertEquals("abc", StringUtils.substringBefore("abc", "x"));

        assertEquals("ab", StringUtils.substringBeforeLast("abcbc", "bc"));

        assertNull(StringUtils.substringBetween(null, "tag"));
        assertEquals("bar", StringUtils.substringBetween("tagbartag", "tag"));

        assertEquals("bar", StringUtils.substringBetween("<a>bar</a>", "<a>", "</a>"));

        assertArrayEquals(new String[] {"a", "b"}, StringUtils.substringsBetween("[a][b]", "[", "]"));
        assertNull(StringUtils.substringsBetween(null, "[", "]"));
    }

    @Test
    public void testSubstringNegativeAndOutOfRange() {
        assertEquals("", StringUtils.substring("abc", 100));
        assertEquals("abc", StringUtils.substring("abc", -100));
        assertEquals("abc", StringUtils.substring("abc", 0, 100));
        assertEquals("", StringUtils.substring("abc", -100, -50));
    }

    @Test
    public void testToCodePointsAndEncoding() {
        assertArrayEquals(new int[] {'a', 'b', 'c'}, StringUtils.toCodePoints("abc"));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.toCodePoints("");
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.toCodePoints(null);
            }
        });

        assertEquals("abc", StringUtils.toEncodedString("abc".getBytes(StandardCharsets.UTF_8), StandardCharsets.UTF_8));
    }

    @Test
    public void testToStringBytes() throws UnsupportedEncodingException {
        assertNull(StringUtils.toString(null, "UTF-8"));
        assertEquals("abc", StringUtils.toString("abc".getBytes("UTF-8"), "UTF-8"));
        assertEquals("abc", StringUtils.toString("abc".getBytes("UTF-8"), null));
    }

    @Test
    public void testTrimFamily() {
        assertNull(StringUtils.trim(null));
        assertEquals("", StringUtils.trim("   "));
        assertEquals("abc", StringUtils.trim("  abc  "));

        assertEquals("", StringUtils.trimToEmpty(null));
        assertEquals("abc", StringUtils.trimToEmpty("  abc  "));

        assertNull(StringUtils.trimToNull("   "));
        assertEquals("abc", StringUtils.trimToNull("  abc  "));
    }

    @Test
    public void testTruncate() {
        assertNull(StringUtils.truncate(null, 10));
        assertEquals("", StringUtils.truncate("", 10));
        assertEquals("abcde", StringUtils.truncate("abcdefghij", 5));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.truncate("abc", -1);
            }
        });

        assertEquals("cde", StringUtils.truncate("abcdefghij", 2, 3));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.truncate("abc", -1, 2);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.truncate("abc", 0, -1);
            }
        });
    }

    @Test
    public void testUnwrapAndWrap() {
        assertNull(StringUtils.unwrap(null, 'x'));
        assertEquals("abc", StringUtils.unwrap("xabcx", 'x'));
        assertEquals("abc", StringUtils.unwrap("abc", 'x'));

        assertNull(StringUtils.unwrap(null, "tag"));
        assertEquals("abc", StringUtils.unwrap("tagabctag", "tag"));

        assertNull(StringUtils.wrap(null, 'x'));
        assertEquals("xabcx", StringUtils.wrap("abc", 'x'));

        assertNull(StringUtils.wrap(null, "tag"));
        assertEquals("tagabctag", StringUtils.wrap("abc", "tag"));

        assertNull(StringUtils.wrapIfMissing(null, 'x'));
        assertEquals("xabcx", StringUtils.wrapIfMissing("abc", 'x'));
        assertEquals("xabcx", StringUtils.wrapIfMissing("xabcx", 'x'));

        assertEquals("tagabctag", StringUtils.wrapIfMissing("abc", "tag"));
        assertEquals("tagabctag", StringUtils.wrapIfMissing("tagabctag", "tag"));
    }

    @Test
    public void testValueOf() {
        assertEquals("abc", StringUtils.valueOf(new char[] {'a', 'b', 'c'}));
        assertNull(StringUtils.valueOf(null));
    }

    @Test
    public void testAppendIfMissing() {
        assertNull(StringUtils.appendIfMissing(null, "xyz"));
        assertEquals("abcxyz", StringUtils.appendIfMissing("abc", "xyz"));
        assertEquals("abcxyz", StringUtils.appendIfMissing("abcxyz", "xyz"));
        assertEquals("abcXYZ", StringUtils.appendIfMissingIgnoreCase("abcXYZ", "xyz"));
    }

    @Test
    public void testFirstNonBlankAndEmpty() {
        assertNull(StringUtils.firstNonBlank((String[]) null));
        assertNull(StringUtils.firstNonBlank(null, "", " "));
        assertEquals("abc", StringUtils.firstNonBlank(null, "", " ", "abc"));

        assertNull(StringUtils.firstNonEmpty((String[]) null));
        assertNull(StringUtils.firstNonEmpty(null, ""));
        assertEquals("abc", StringUtils.firstNonEmpty(null, "", "abc"));
    }

    @Test
    public void testGetIfBlankAndEmpty() {
        final Supplier<String> defaultSupplier = new Supplier<String>() {
            @Override
            public String get() {
                return "default";
            }
        };
        assertEquals("default", StringUtils.getIfBlank(" ", defaultSupplier));
        assertEquals("abc", StringUtils.getIfBlank("abc", defaultSupplier));
        assertNull(StringUtils.getIfBlank(" ", null));

        assertEquals("default", StringUtils.getIfEmpty("", defaultSupplier));
        assertEquals("abc", StringUtils.getIfEmpty("abc", defaultSupplier));
    }

    @Test
    public void testFuzzyAndJaroWinklerDistance() {
        assertEquals(3, StringUtils.getFuzzyDistance("Workshop", "b", Locale.ENGLISH));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.getFuzzyDistance(null, "b", Locale.ENGLISH);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.getFuzzyDistance("a", "b", null);
            }
        });

        assertEquals(1.0d, StringUtils.getJaroWinklerDistance("foo", "foo"), 0.0001d);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.getJaroWinklerDistance(null, "foo");
            }
        });
    }

    @Test
    public void testOrdinalIndexOfAndLastOrdinalIndexOf() {
        assertEquals(-1, StringUtils.ordinalIndexOf(null, "a", 1));
        assertEquals(0, StringUtils.ordinalIndexOf("aabaabaa", "a", 1));
        assertEquals(1, StringUtils.ordinalIndexOf("aabaabaa", "a", 2));
        assertEquals(5, StringUtils.ordinalIndexOf("aabaabaa", "a", 4));

        assertEquals(7, StringUtils.lastOrdinalIndexOf("aabaabaa", "a", 1));
        assertEquals(6, StringUtils.lastOrdinalIndexOf("aabaabaa", "a", 2));
    }
}
