/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Field;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

public class TypeUtilsAgentTest {

    private interface Foo<F> {
        // marker generic interface used for type-argument resolution tests
    }

    private static class FooBar implements Foo<String> {
        // concrete subtype binding Foo's type variable to String
    }

    private static class Unbounded<T> {
        // class with a plain, unbounded type variable
    }

    private static class Bounded<T extends Number> {
        // class with a bounded type variable
    }

    private static class ArrayHolder<T> {
        public T[] arr;
    }

    private static class StringArrayHolder {
        public String[] arr;
    }

    // ------------------------------------------------------------------
    // containsTypeVariables
    // ------------------------------------------------------------------

    @Test
    public void testContainsTypeVariablesFalseForPlainClass() {
        assertFalse(TypeUtils.containsTypeVariables(String.class));
    }

    @Test
    public void testContainsTypeVariablesTrueForGenericClassItself() {
        assertTrue(TypeUtils.containsTypeVariables(List.class));
    }

    @Test
    public void testContainsTypeVariablesTrueForTypeVariable() {
        final TypeVariable<?> tv = Unbounded.class.getTypeParameters()[0];
        assertTrue(TypeUtils.containsTypeVariables(tv));
    }

    @Test
    public void testContainsTypeVariablesFalseForFullyResolvedParameterizedType() {
        final ParameterizedType pt = TypeUtils.parameterize(List.class, String.class);
        assertFalse(TypeUtils.containsTypeVariables(pt));
    }

    @Test
    public void testContainsTypeVariablesTrueForUnresolvedParameterizedType() {
        final TypeVariable<?> tv = Unbounded.class.getTypeParameters()[0];
        final ParameterizedType pt = TypeUtils.parameterize(List.class, tv);
        assertTrue(TypeUtils.containsTypeVariables(pt));
    }

    @Test
    public void testContainsTypeVariablesTrueForGenericArrayOfVariable() throws Exception {
        final Field field = ArrayHolder.class.getField("arr");
        assertTrue(TypeUtils.containsTypeVariables(field.getGenericType()));
    }

    // ------------------------------------------------------------------
    // determineTypeArguments
    // ------------------------------------------------------------------

    @Test
    public void testDetermineTypeArgumentsResolvesSuperTypeArgument() {
        final ParameterizedType fooOfString = TypeUtils.parameterize(Foo.class, String.class);
        final Map<TypeVariable<?>, Type> result = TypeUtils.determineTypeArguments(FooBar.class, fooOfString);
        assertEquals(String.class, result.get(Foo.class.getTypeParameters()[0]));
    }

    @Test
    public void testDetermineTypeArgumentsReturnsNullForIncompatibleTypes() {
        final ParameterizedType fooOfString = TypeUtils.parameterize(Foo.class, String.class);
        assertNull(TypeUtils.determineTypeArguments(String.class, fooOfString));
    }

    @Test
    public void testDetermineTypeArgumentsNullArgumentsThrowNpe() {
        final ParameterizedType fooOfString = TypeUtils.parameterize(Foo.class, String.class);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                TypeUtils.determineTypeArguments(null, fooOfString);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                TypeUtils.determineTypeArguments(FooBar.class, null);
            }
        });
    }

    // ------------------------------------------------------------------
    // equals
    // ------------------------------------------------------------------

    @Test
    public void testEqualsTrueForSeparatelyBuiltParameterizedTypes() {
        final ParameterizedType a = TypeUtils.parameterize(List.class, String.class);
        final ParameterizedType b = TypeUtils.parameterize(List.class, String.class);
        assertTrue(TypeUtils.equals(a, b));
    }

    @Test
    public void testEqualsFalseForDifferentTypeArguments() {
        final ParameterizedType a = TypeUtils.parameterize(List.class, String.class);
        final ParameterizedType b = TypeUtils.parameterize(List.class, Integer.class);
        assertFalse(TypeUtils.equals(a, b));
    }

    @Test
    public void testEqualsTrueForEqualGenericArrayTypes() {
        final GenericArrayType a = TypeUtils.genericArrayType(String.class);
        final GenericArrayType b = TypeUtils.genericArrayType(String.class);
        assertTrue(TypeUtils.equals(a, b));
    }

    @Test
    public void testEqualsTrueForPlainEqualClasses() {
        assertTrue(TypeUtils.equals(String.class, String.class));
        assertFalse(TypeUtils.equals(String.class, Integer.class));
    }

    // ------------------------------------------------------------------
    // genericArrayType
    // ------------------------------------------------------------------

    @Test
    public void testGenericArrayTypeReturnsComponentType() {
        final GenericArrayType gat = TypeUtils.genericArrayType(String.class);
        assertEquals(String.class, gat.getGenericComponentType());
    }

    @Test
    public void testGenericArrayTypeNullComponentThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                TypeUtils.genericArrayType(null);
            }
        });
    }

    // ------------------------------------------------------------------
    // getArrayComponentType
    // ------------------------------------------------------------------

    @Test
    public void testGetArrayComponentTypeForArrayClass() {
        assertEquals(int.class, TypeUtils.getArrayComponentType(int[].class));
        assertEquals(String.class, TypeUtils.getArrayComponentType(String[].class));
    }

    @Test
    public void testGetArrayComponentTypeNullForNonArrayClass() {
        assertNull(TypeUtils.getArrayComponentType(String.class));
    }

    @Test
    public void testGetArrayComponentTypeForGenericArrayType() throws Exception {
        final Field field = ArrayHolder.class.getField("arr");
        final Type component = TypeUtils.getArrayComponentType(field.getGenericType());
        assertEquals(ArrayHolder.class.getTypeParameters()[0], component);
    }

    @Test
    public void testGetArrayComponentTypeNullForOtherTypes() {
        final ParameterizedType pt = TypeUtils.parameterize(List.class, String.class);
        assertNull(TypeUtils.getArrayComponentType(pt));
    }

    // ------------------------------------------------------------------
    // getImplicitBounds / getImplicitLowerBounds / getImplicitUpperBounds
    // ------------------------------------------------------------------

    @Test
    public void testGetImplicitBoundsDefaultsToObject() {
        final TypeVariable<?> tv = Unbounded.class.getTypeParameters()[0];
        final Type[] bounds = TypeUtils.getImplicitBounds(tv);
        assertEquals(1, bounds.length);
        assertEquals(Object.class, bounds[0]);
    }

    @Test
    public void testGetImplicitBoundsReturnsDeclaredBound() {
        final TypeVariable<?> tv = Bounded.class.getTypeParameters()[0];
        final Type[] bounds = TypeUtils.getImplicitBounds(tv);
        assertEquals(1, bounds.length);
        assertEquals(Number.class, bounds[0]);
    }

    @Test
    public void testGetImplicitBoundsNullThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                TypeUtils.getImplicitBounds(null);
            }
        });
    }

    @Test
    public void testGetImplicitLowerBoundsDefaultsToNullElement() {
        final WildcardType wc = TypeUtils.wildcardType().withUpperBounds(String.class).build();
        final Type[] lower = TypeUtils.getImplicitLowerBounds(wc);
        assertEquals(1, lower.length);
        assertNull(lower[0]);
    }

    @Test
    public void testGetImplicitLowerBoundsReturnsDeclaredLowerBound() {
        final WildcardType wc = TypeUtils.wildcardType().withLowerBounds(String.class).build();
        final Type[] lower = TypeUtils.getImplicitLowerBounds(wc);
        assertEquals(1, lower.length);
        assertEquals(String.class, lower[0]);
    }

    @Test
    public void testGetImplicitUpperBoundsDefaultsToObject() {
        final WildcardType wc = TypeUtils.wildcardType().build();
        final Type[] upper = TypeUtils.getImplicitUpperBounds(wc);
        assertEquals(1, upper.length);
        assertEquals(Object.class, upper[0]);
    }

    @Test
    public void testGetImplicitUpperBoundsNullThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                TypeUtils.getImplicitUpperBounds(null);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                TypeUtils.getImplicitLowerBounds(null);
            }
        });
    }

    // ------------------------------------------------------------------
    // getRawType
    // ------------------------------------------------------------------

    @Test
    public void testGetRawTypeForClass() {
        assertEquals(String.class, TypeUtils.getRawType(String.class, null));
    }

    @Test
    public void testGetRawTypeForParameterizedType() {
        final ParameterizedType pt = TypeUtils.parameterize(List.class, String.class);
        assertEquals(List.class, TypeUtils.getRawType(pt, null));
    }

    @Test
    public void testGetRawTypeForTypeVariableWithNullAssigningTypeIsNull() {
        final TypeVariable<?> tv = Bounded.class.getTypeParameters()[0];
        assertNull(TypeUtils.getRawType(tv, null));
    }

    @Test
    public void testGetRawTypeForTypeVariableResolvedViaAssigningType() {
        final TypeVariable<?> f = Foo.class.getTypeParameters()[0];
        assertEquals(String.class, TypeUtils.getRawType(f, FooBar.class));
    }

    @Test
    public void testGetRawTypeForGenericArrayType() throws Exception {
        final Field field = ArrayHolder.class.getField("arr");
        final Type assigningType = TypeUtils.parameterize(ArrayHolder.class, String.class);
        final Class<?> raw = TypeUtils.getRawType(field.getGenericType(), assigningType);
        assertEquals(String[].class, raw);
    }

    @Test
    public void testGetRawTypeForWildcardTypeIsNull() {
        final WildcardType wc = TypeUtils.wildcardType().withUpperBounds(String.class).build();
        assertNull(TypeUtils.getRawType(wc, null));
    }

    @Test
    public void testGetRawTypeForUnknownTypeThrows() {
        final Type weird = new Type() {
            @Override
            public String toString() {
                return "weird";
            }
        };
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                TypeUtils.getRawType(weird, null);
            }
        });
    }

    // ------------------------------------------------------------------
    // getTypeArguments
    // ------------------------------------------------------------------

    @Test
    public void testGetTypeArgumentsForParameterizedType() {
        final ParameterizedType pt = TypeUtils.parameterize(List.class, String.class);
        final Map<TypeVariable<?>, Type> args = TypeUtils.getTypeArguments(pt);
        assertEquals(String.class, args.get(List.class.getTypeParameters()[0]));
    }

    @Test
    public void testGetTypeArgumentsForSubtype() {
        final Map<TypeVariable<?>, Type> args = TypeUtils.getTypeArguments(FooBar.class, Foo.class);
        assertEquals(String.class, args.get(Foo.class.getTypeParameters()[0]));
    }

    @Test
    public void testGetTypeArgumentsReturnsNullForIncompatibleSubtype() {
        assertNull(TypeUtils.getTypeArguments(String.class, Foo.class));
    }

    @Test
    public void testGetTypeArgumentsEmptyForClassWithoutGenerics() {
        final Map<TypeVariable<?>, Type> args = TypeUtils.getTypeArguments(Integer.class, Number.class);
        assertNotNull(args);
        assertTrue(args.isEmpty());
    }

    // ------------------------------------------------------------------
    // isArrayType
    // ------------------------------------------------------------------

    @Test
    public void testIsArrayType() {
        assertTrue(TypeUtils.isArrayType(int[].class));
        assertTrue(TypeUtils.isArrayType(TypeUtils.genericArrayType(String.class)));
        assertFalse(TypeUtils.isArrayType(String.class));
        assertFalse(TypeUtils.isArrayType(TypeUtils.parameterize(List.class, String.class)));
    }

    // ------------------------------------------------------------------
    // isAssignable
    // ------------------------------------------------------------------

    @Test
    public void testIsAssignableClassToClass() {
        assertTrue(TypeUtils.isAssignable(Integer.class, Number.class));
        assertFalse(TypeUtils.isAssignable(Number.class, Integer.class));
        assertTrue(TypeUtils.isAssignable(String.class, String.class));
    }

    @Test
    public void testIsAssignableNullType() {
        assertTrue(TypeUtils.isAssignable(null, Object.class));
        assertFalse(TypeUtils.isAssignable(null, int.class));
    }

    @Test
    public void testIsAssignableParameterizedTypes() {
        final ParameterizedType listOfString = TypeUtils.parameterize(List.class, String.class);
        final ParameterizedType listOfInteger = TypeUtils.parameterize(List.class, Integer.class);
        assertTrue(TypeUtils.isAssignable(listOfString, listOfString));
        assertFalse(TypeUtils.isAssignable(listOfString, listOfInteger));
    }

    @Test
    public void testIsAssignableRawListToParameterizedList() {
        final ParameterizedType listOfString = TypeUtils.parameterize(List.class, String.class);
        assertTrue(TypeUtils.isAssignable(List.class, listOfString));
    }

    @Test
    public void testIsAssignableToWildcard() {
        final WildcardType extendsNumber = TypeUtils.wildcardType().withUpperBounds(Number.class).build();
        assertTrue(TypeUtils.isAssignable(Integer.class, extendsNumber));
        assertFalse(TypeUtils.isAssignable(String.class, extendsNumber));
    }

    @Test
    public void testIsAssignableGenericArrayToObject() {
        final GenericArrayType gat = TypeUtils.genericArrayType(String.class);
        assertTrue(TypeUtils.isAssignable(gat, Object.class));
        assertTrue(TypeUtils.isAssignable(gat, Object[].class));
        assertFalse(TypeUtils.isAssignable(gat, String.class));
    }

    @Test
    public void testIsAssignableUnknownTypeThrows() {
        final Type weird = new Type() {
            @Override
            public String toString() {
                return "weird";
            }
        };
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                TypeUtils.isAssignable(weird, Object.class);
            }
        });
    }

    // ------------------------------------------------------------------
    // isInstance
    // ------------------------------------------------------------------

    @Test
    public void testIsInstance() {
        assertTrue(TypeUtils.isInstance("hello", String.class));
        assertFalse(TypeUtils.isInstance(Integer.valueOf(5), String.class));
        assertTrue(TypeUtils.isInstance(null, String.class));
        assertFalse(TypeUtils.isInstance(null, int.class));
        assertFalse(TypeUtils.isInstance("hello", null));
    }

    // ------------------------------------------------------------------
    // normalizeUpperBounds
    // ------------------------------------------------------------------

    @Test
    public void testNormalizeUpperBoundsRemovesRedundantSupertype() {
        final Type[] bounds = { Collection.class, List.class };
        final Type[] normalized = TypeUtils.normalizeUpperBounds(bounds);
        assertEquals(1, normalized.length);
        assertEquals(List.class, normalized[0]);
    }

    @Test
    public void testNormalizeUpperBoundsSingleElementUnchanged() {
        final Type[] bounds = { Number.class };
        assertSame(bounds, TypeUtils.normalizeUpperBounds(bounds));
    }

    @Test
    public void testNormalizeUpperBoundsNullThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                TypeUtils.normalizeUpperBounds(null);
            }
        });
    }

    // ------------------------------------------------------------------
    // parameterize / parameterizeWithOwner
    // ------------------------------------------------------------------

    @Test
    public void testParameterizeWithTypeArguments() {
        final ParameterizedType pt = TypeUtils.parameterize(List.class, String.class);
        assertEquals(List.class, pt.getRawType());
        assertEquals(1, pt.getActualTypeArguments().length);
        assertEquals(String.class, pt.getActualTypeArguments()[0]);
        assertNull(pt.getOwnerType());
    }

    @Test
    public void testParameterizeWithMap() {
        final Map<TypeVariable<?>, Type> map = new HashMap<>();
        map.put(List.class.getTypeParameters()[0], String.class);
        final ParameterizedType pt = TypeUtils.parameterize(List.class, map);
        assertEquals(String.class, pt.getActualTypeArguments()[0]);
    }

    @Test
    public void testParameterizeRawClassNullThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                TypeUtils.parameterize(null, String.class);
            }
        });
    }

    @Test
    public void testParameterizeWrongArgumentCountThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                TypeUtils.parameterize(List.class, String.class, Integer.class);
            }
        });
    }

    @Test
    public void testParameterizeNullArgumentThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                TypeUtils.parameterize(List.class, (Type) null);
            }
        });
    }

    @Test
    public void testParameterizeWithOwnerRejectsOwnerForTopLevelClass() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                TypeUtils.parameterizeWithOwner(String.class, List.class, String.class);
            }
        });
    }

    // ------------------------------------------------------------------
    // toLongString
    // ------------------------------------------------------------------

    @Test
    public void testToLongString() {
        final TypeVariable<?> tv = List.class.getTypeParameters()[0];
        assertEquals("java.util.List:" + tv.getName(), TypeUtils.toLongString(tv));
    }

    @Test
    public void testToLongStringNullThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                TypeUtils.toLongString(null);
            }
        });
    }

    // ------------------------------------------------------------------
    // toString
    // ------------------------------------------------------------------

    @Test
    public void testToStringForClass() {
        assertEquals("java.lang.String", TypeUtils.toString(String.class));
    }

    @Test
    public void testToStringForArrayClass() {
        assertEquals("int[]", TypeUtils.toString(int[].class));
    }

    @Test
    public void testToStringForParameterizedType() {
        final ParameterizedType pt = TypeUtils.parameterize(List.class, String.class);
        assertEquals("java.util.List<java.lang.String>", TypeUtils.toString(pt));
    }

    @Test
    public void testToStringForWildcardAll() {
        assertEquals("?", TypeUtils.toString(TypeUtils.WILDCARD_ALL));
    }

    @Test
    public void testToStringForBoundedWildcard() {
        final WildcardType wc = TypeUtils.wildcardType().withUpperBounds(Number.class).build();
        assertEquals("? extends java.lang.Number", TypeUtils.toString(wc));
    }

    @Test
    public void testToStringNullThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                TypeUtils.toString(null);
            }
        });
    }

    @Test
    public void testToStringUnknownTypeThrows() {
        final Type weird = new Type() {
            @Override
            public String toString() {
                return "weird";
            }
        };
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                TypeUtils.toString(weird);
            }
        });
    }

    // ------------------------------------------------------------------
    // typesSatisfyVariables
    // ------------------------------------------------------------------

    @Test
    public void testTypesSatisfyVariablesTrue() {
        final Map<TypeVariable<?>, Type> map = new HashMap<>();
        map.put(Bounded.class.getTypeParameters()[0], Integer.class);
        assertTrue(TypeUtils.typesSatisfyVariables(map));
    }

    @Test
    public void testTypesSatisfyVariablesFalse() {
        final Map<TypeVariable<?>, Type> map = new HashMap<>();
        map.put(Bounded.class.getTypeParameters()[0], String.class);
        assertFalse(TypeUtils.typesSatisfyVariables(map));
    }

    @Test
    public void testTypesSatisfyVariablesNullThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                TypeUtils.typesSatisfyVariables(null);
            }
        });
    }

    // ------------------------------------------------------------------
    // unrollVariables
    // ------------------------------------------------------------------

    @Test
    public void testUnrollVariablesResolvesTypeVariable() {
        final TypeVariable<?> tv = Foo.class.getTypeParameters()[0];
        final Map<TypeVariable<?>, Type> args = TypeUtils.getTypeArguments(FooBar.class, Foo.class);
        assertEquals(String.class, TypeUtils.unrollVariables(args, tv));
    }

    @Test
    public void testUnrollVariablesWithNullMapLeavesPlainTypeUnchanged() {
        assertEquals(String.class, TypeUtils.unrollVariables(null, String.class));
    }

    // ------------------------------------------------------------------
    // wildcardType / WILDCARD_ALL
    // ------------------------------------------------------------------

    @Test
    public void testWildcardTypeBuilderDefaults() {
        final WildcardType wc = TypeUtils.wildcardType().build();
        assertEquals(1, wc.getUpperBounds().length);
        assertEquals(Object.class, wc.getUpperBounds()[0]);
        assertEquals(0, wc.getLowerBounds().length);
    }

    @Test
    public void testWildcardTypeBuilderWithBounds() {
        final WildcardType wc = TypeUtils.wildcardType().withUpperBounds(Number.class).withLowerBounds(Integer.class).build();
        assertEquals(1, wc.getUpperBounds().length);
        assertEquals(Number.class, wc.getUpperBounds()[0]);
        assertEquals(1, wc.getLowerBounds().length);
        assertEquals(Integer.class, wc.getLowerBounds()[0]);
    }

    @Test
    public void testWildcardAllConstant() {
        assertEquals(1, TypeUtils.WILDCARD_ALL.getUpperBounds().length);
        assertEquals(Object.class, TypeUtils.WILDCARD_ALL.getUpperBounds()[0]);
        assertEquals(0, TypeUtils.WILDCARD_ALL.getLowerBounds().length);
    }

    // ------------------------------------------------------------------
    // wrap
    // ------------------------------------------------------------------

    @Test
    public void testWrapClass() {
        final Typed<String> typed = TypeUtils.wrap(String.class);
        assertEquals(String.class, typed.getType());
    }

    @Test
    public void testWrapType() {
        final ParameterizedType pt = TypeUtils.parameterize(List.class, String.class);
        final Typed<List<String>> typed = TypeUtils.wrap((Type) pt);
        assertSame(pt, typed.getType());
    }
}
