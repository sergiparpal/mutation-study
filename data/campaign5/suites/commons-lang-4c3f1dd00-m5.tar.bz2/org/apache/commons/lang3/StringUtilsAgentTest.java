/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link StringUtils}.
 */
class StringUtilsAgentTest {

    @Test
    void testIsEmptyIsBlank() {
        assertTrue(StringUtils.isEmpty(null));
        assertTrue(StringUtils.isEmpty(""));
        assertFalse(StringUtils.isEmpty(" "));
        assertFalse(StringUtils.isEmpty("abc"));

        assertTrue(StringUtils.isBlank(null));
        assertTrue(StringUtils.isBlank(""));
        assertTrue(StringUtils.isBlank("   "));
        assertFalse(StringUtils.isBlank("abc"));
        assertFalse(StringUtils.isBlank("  a  "));

        assertFalse(StringUtils.isNotEmpty(null));
        assertTrue(StringUtils.isNotEmpty("x"));
        assertFalse(StringUtils.isNotBlank(" "));
        assertTrue(StringUtils.isNotBlank(" x "));
    }

    @Test
    void testIsAnyIsNoneIsAllBlankEmpty() {
        assertTrue(StringUtils.isAnyEmpty("a", ""));
        assertFalse(StringUtils.isAnyEmpty("a", "b"));
        assertFalse(StringUtils.isAnyEmpty());

        assertTrue(StringUtils.isAnyBlank("a", " "));
        assertFalse(StringUtils.isAnyBlank("a", "b"));

        assertTrue(StringUtils.isNoneEmpty("a", "b"));
        assertFalse(StringUtils.isNoneEmpty("a", ""));

        assertTrue(StringUtils.isNoneBlank("a", "b"));
        assertFalse(StringUtils.isNoneBlank("a", " "));

        assertTrue(StringUtils.isAllBlank((CharSequence[]) null));
        assertTrue(StringUtils.isAllBlank("", " ", null));
        assertFalse(StringUtils.isAllBlank("", "x"));
    }

    @Test
    void testTrimAndStrip() {
        assertNull(StringUtils.trim(null));
        assertEquals("", StringUtils.trim("   "));
        assertEquals("abc", StringUtils.trim("  abc  "));

        assertNull(StringUtils.trimToNull("   "));
        assertEquals("abc", StringUtils.trimToNull("  abc  "));

        assertEquals("", StringUtils.trimToEmpty(null));
        assertEquals("abc", StringUtils.trimToEmpty(" abc "));

        assertNull(StringUtils.strip(null));
        assertEquals("abc", StringUtils.strip("  abc  "));
        assertEquals("abc", StringUtils.strip("xxabcxx", "x"));

        assertNull(StringUtils.stripToNull("   "));
        assertEquals("", StringUtils.stripToEmpty(null));

        assertEquals("abc  ", StringUtils.stripStart("  abc  ", null));
        assertEquals("  abc", StringUtils.stripEnd("  abc  ", null));
        assertNull(StringUtils.stripStart(null, "x"));
        assertNull(StringUtils.stripEnd(null, "x"));
    }

    @Test
    void testEqualsAndIgnoreCase() {
        assertTrue(StringUtils.equals(null, null));
        assertFalse(StringUtils.equals(null, "abc"));
        assertFalse(StringUtils.equals("abc", null));
        assertTrue(StringUtils.equals("abc", "abc"));
        assertFalse(StringUtils.equals("abc", "abd"));

        assertTrue(StringUtils.equalsIgnoreCase(null, null));
        assertTrue(StringUtils.equalsIgnoreCase("abc", "ABC"));
        assertFalse(StringUtils.equalsIgnoreCase("abc", null));

        assertTrue(StringUtils.equalsAny("abc", "xyz", "abc"));
        assertFalse(StringUtils.equalsAny("abc", "xyz", "def"));
        assertTrue(StringUtils.equalsAnyIgnoreCase("abc", "ABC"));
    }

    @Test
    void testIndexOfVariants() {
        assertEquals(-1, StringUtils.indexOf(null, "a"));
        assertEquals(1, StringUtils.indexOf("babc", "a"));
        assertEquals(0, StringUtils.indexOf("aabaabaa", "a", -1));

        assertEquals(-1, StringUtils.lastIndexOf(null, "a"));
        assertEquals(5, StringUtils.lastIndexOf("aabaabaa", "b"));

        assertEquals(0, StringUtils.indexOfIgnoreCase("aabaabaa", "A"));
        assertEquals(-1, StringUtils.indexOfIgnoreCase(null, "A"));
        assertEquals(7, StringUtils.lastIndexOfIgnoreCase("aabaabaa", "A"));

        assertEquals(-1, StringUtils.ordinalIndexOf(null, "a", 2));
        assertEquals(2, StringUtils.ordinalIndexOf("aabaabaa", "b", 1));
        assertEquals(5, StringUtils.ordinalIndexOf("aabaabaa", "b", 2));
        assertEquals(-1, StringUtils.ordinalIndexOf("aabaabaa", "b", 3));

        assertEquals(2, StringUtils.lastOrdinalIndexOf("aabaabaa", "b", 2));
    }

    @Test
    void testContainsVariants() {
        assertFalse(StringUtils.contains(null, "a"));
        assertTrue(StringUtils.contains("abc", "b"));
        assertFalse(StringUtils.contains("abc", "z"));

        assertTrue(StringUtils.containsIgnoreCase("abc", "B"));
        assertFalse(StringUtils.containsIgnoreCase(null, "B"));

        assertTrue(StringUtils.containsAny("abc", 'z', 'b'));
        assertFalse(StringUtils.containsAny("abc", 'z', 'y'));
        assertFalse(StringUtils.containsAny((CharSequence) null, 'a'));

        assertTrue(StringUtils.containsAny("abc", "xyz", "bc"));
        assertFalse(StringUtils.containsAny("abc", "xyz", "qq"));

        assertTrue(StringUtils.containsNone("abc", 'x', 'y'));
        assertFalse(StringUtils.containsNone("abc", 'x', 'a'));

        assertTrue(StringUtils.containsOnly("aabbcc", 'a', 'b', 'c'));
        assertFalse(StringUtils.containsOnly("aabbccd", 'a', 'b', 'c'));
        assertFalse(StringUtils.containsOnly(null, 'a'));

        assertTrue(StringUtils.startsWithAny("abcdef", "xyz", "abc"));
        assertFalse(StringUtils.startsWithAny("abcdef", "xyz", "qqq"));
        assertTrue(StringUtils.endsWithAny("abcdef", "xyz", "def"));
    }

    @Test
    void testSubstring() {
        assertNull(StringUtils.substring(null, 0));
        assertEquals("", StringUtils.substring("", 2));
        assertEquals("cde", StringUtils.substring("abcde", 2));
        assertEquals("cde", StringUtils.substring("abcde", -3));
        assertEquals("", StringUtils.substring("abcde", 10));

        assertEquals("bc", StringUtils.substring("abcde", 1, 3));
        assertEquals("", StringUtils.substring("abcde", 3, 1));

        assertEquals("a", StringUtils.substringBefore("abcba", "b"));
        assertEquals("abcba", StringUtils.substringBefore("abcba", "x"));
        assertNull(StringUtils.substringBefore(null, "b"));

        assertEquals("cba", StringUtils.substringAfter("abcba", "b"));
        assertEquals("", StringUtils.substringAfter("abcba", "x"));
        assertNull(StringUtils.substringAfter(null, "b"));

        assertEquals("abc", StringUtils.substringBetween("tagabctag", "tag"));
        assertEquals("bar", StringUtils.substringBetween("[bar]", "[", "]"));
        assertNull(StringUtils.substringBetween(null, "[", "]"));
        assertNull(StringUtils.substringBetween("foo", "[", "]"));
    }

    @Test
    void testSplitAndJoin() {
        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.split("a b c"));
        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.split("a,b,c", ','));
        assertNull(StringUtils.split((String) null));
        assertArrayEquals(new String[0], StringUtils.split(""));

        assertArrayEquals(new String[] {"ab", "cd", "ef"}, StringUtils.splitByWholeSeparator("ab::cd::ef", "::"));
        assertArrayEquals(new String[] {"ab", "cd:ef"}, StringUtils.splitByWholeSeparator("ab::cd:ef", "::", 2));

        assertEquals("a,b,c", StringUtils.join(new String[] {"a", "b", "c"}, ','));
        assertEquals("", StringUtils.join((Object[]) new String[0], ','));
        assertNull(StringUtils.join((Object[]) null, ','));
        assertEquals("a-b-c", StringUtils.join(new Object[] {"a", "b", "c"}, "-"));
    }

    @Test
    void testDeleteWhitespaceAndCountMatches() {
        assertNull(StringUtils.deleteWhitespace(null));
        assertEquals("", StringUtils.deleteWhitespace(""));
        assertEquals("abc", StringUtils.deleteWhitespace(" a\tb\nc  "));

        assertEquals(0, StringUtils.countMatches(null, "a"));
        assertEquals(0, StringUtils.countMatches("abc", ""));
        assertEquals(2, StringUtils.countMatches("abcabc", "a"));
        assertEquals(1, StringUtils.countMatches("abcabc", "cab"));
    }

    @Test
    void testReplaceAndRemove() {
        assertNull(StringUtils.replace(null, "a", "b"));
        assertEquals("foo", StringUtils.replace("foo", "x", "y"));
        assertEquals("bbbb", StringUtils.replace("aaaa", "a", "b"));
        assertEquals("zbcabc", StringUtils.replace("abcabc", "a", "z", 1));

        assertEquals("foozoo", StringUtils.replaceOnce("foobaroo", "bar", "z"));

        assertEquals("abcabc", StringUtils.removeStart("xabcabc", "x"));
        assertEquals("abcabc", StringUtils.removeStart("abcabc", "x"));
        assertNull(StringUtils.removeStart(null, "x"));

        assertEquals("abcabc", StringUtils.removeEnd("abcabcy", "y"));
        assertEquals("qbc", StringUtils.removeStart("qbc", ""));

        assertEquals("", StringUtils.removeIgnoreCase("ABC", "abc"));

        assertEquals("qd", StringUtils.remove("queued", "ue"));
    }

    @Test
    void testPrependAppendIfMissing() {
        assertEquals("/path", StringUtils.prependIfMissing("path", "/"));
        assertEquals("/path", StringUtils.prependIfMissing("/path", "/"));

        assertEquals("abc/", StringUtils.appendIfMissing("abc", "/"));
        assertEquals("abc/", StringUtils.appendIfMissing("abc/", "/"));
    }

    @Test
    void testPaddingAndCenter() {
        assertEquals("  abc", StringUtils.leftPad("abc", 5));
        assertEquals("abc", StringUtils.leftPad("abc", 2));
        assertEquals("xxabc", StringUtils.leftPad("abc", 5, 'x'));
        assertNull(StringUtils.leftPad(null, 5));

        assertEquals("abc  ", StringUtils.rightPad("abc", 5));
        assertEquals("abcxx", StringUtils.rightPad("abc", 5, 'x'));

        assertEquals("  ab  ", StringUtils.center("ab", 6));
        assertEquals("ab", StringUtils.center("ab", 1));
        assertNull(StringUtils.center(null, 4));
    }

    @Test
    void testLeftRightMid() {
        assertNull(StringUtils.left(null, 3));
        assertEquals("", StringUtils.left("abc", -1));
        assertEquals("ab", StringUtils.left("abc", 2));
        assertEquals("abc", StringUtils.left("abc", 10));

        assertEquals("bc", StringUtils.right("abc", 2));
        assertEquals("", StringUtils.right("abc", 0));

        assertNull(StringUtils.mid(null, 0, 2));
        assertEquals("", StringUtils.mid("abc", 0, -1));
        assertEquals("ab", StringUtils.mid("abc", 0, 2));
        assertEquals("ab", StringUtils.mid("abc", -1, 2));
        assertEquals("c", StringUtils.mid("abc", 2, 10));
        assertEquals("", StringUtils.mid("abc", 4, 2));
    }

    @Test
    void testCapitalizeAndSwapCase() {
        assertNull(StringUtils.capitalize(null));
        assertEquals("", StringUtils.capitalize(""));
        assertEquals("Cat", StringUtils.capitalize("cat"));
        assertEquals("CAT", StringUtils.capitalize("CAT"));

        assertNull(StringUtils.uncapitalize(null));
        assertEquals("cAT", StringUtils.uncapitalize("CAT"));

        assertNull(StringUtils.swapCase(null));
        assertEquals("", StringUtils.swapCase(""));
        assertEquals("tHE DOG HAS A bone", StringUtils.swapCase("The dog has a BONE"));
    }

    @Test
    void testReverse() {
        assertNull(StringUtils.reverse(null));
        assertEquals("", StringUtils.reverse(""));
        assertEquals("cba", StringUtils.reverse("abc"));

        assertEquals("c.b.a", StringUtils.reverseDelimited("a.b.c", '.'));
    }

    @Test
    void testAbbreviateAndTruncate() {
        assertNull(StringUtils.abbreviate(null, 4));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", 7));
        assertEquals("abc...", StringUtils.abbreviate("abcdefg", 6));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.abbreviate("abcdefg", 3);
            }
        });

        assertNull(StringUtils.truncate(null, 4));
        assertEquals("abc", StringUtils.truncate("abcdefg", 3));
        assertEquals("", StringUtils.truncate("abcdefg", 0));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.truncate("abcdefg", -1);
            }
        });
    }

    @Test
    void testGetLevenshteinDistanceAndCommon() {
        assertEquals(0, StringUtils.getLevenshteinDistance("", ""));
        assertEquals(3, StringUtils.getLevenshteinDistance("", "abc"));
        assertEquals(1, StringUtils.getLevenshteinDistance("frog", "fog"));
        assertEquals(7, StringUtils.getLevenshteinDistance("elephant", "hippo"));

        assertEquals(1, StringUtils.getLevenshteinDistance("frog", "fog", 5));
        assertEquals(-1, StringUtils.getLevenshteinDistance("frog", "elephant", 2));

        assertEquals("robot", StringUtils.difference("i am a machine", "i am a robot"));
        assertEquals("", StringUtils.difference("abc", "abc"));
        assertEquals("xyz", StringUtils.difference("abcde", "abxyz"));

        assertEquals("", StringUtils.getCommonPrefix("", "abc"));
        assertEquals("abc", StringUtils.getCommonPrefix("abcde", "abc"));
        assertEquals("", StringUtils.getCommonPrefix((String[]) null));
    }

    @Test
    void testIsAlphaNumericWhitespace() {
        assertFalse(StringUtils.isAlpha(null));
        assertFalse(StringUtils.isAlpha(""));
        assertTrue(StringUtils.isAlpha("abc"));
        assertFalse(StringUtils.isAlpha("ab2c"));

        assertTrue(StringUtils.isAlphanumeric("ab2c"));
        assertFalse(StringUtils.isAlphanumeric("ab2 c"));

        assertTrue(StringUtils.isNumeric("12345"));
        assertFalse(StringUtils.isNumeric("12.3"));
        assertFalse(StringUtils.isNumeric(null));

        assertTrue(StringUtils.isWhitespace("   "));
        assertTrue(StringUtils.isWhitespace(""));
        assertFalse(StringUtils.isWhitespace(" a "));

        assertTrue(StringUtils.isAsciiPrintable("abc123 !"));
        assertFalse(StringUtils.isAsciiPrintable("abc\u0001"));
    }

    @Test
    void testRepeatAndNormalizeSpace() {
        assertNull(StringUtils.repeat(null, 2));
        assertEquals("", StringUtils.repeat("ab", 0));
        assertEquals("ababab", StringUtils.repeat("ab", 3));
        assertEquals("", StringUtils.repeat('x', 0));
        assertEquals("xxx", StringUtils.repeat('x', 3));
        assertEquals("a-a-a", StringUtils.repeat("a", "-", 3));

        assertNull(StringUtils.normalizeSpace(null));
        assertEquals("", StringUtils.normalizeSpace("   "));
        assertEquals("a b c", StringUtils.normalizeSpace("  a   b  c "));
    }

    @Test
    void testWrapAndUnwrap() {
        assertNull(StringUtils.wrap(null, '"'));
        assertEquals("'abc'", StringUtils.wrap("abc", '\''));
        assertEquals("\"abc\"", StringUtils.wrap("abc", "\""));
        assertEquals("abc", StringUtils.wrap("abc", (String) null));

        assertEquals("abc", StringUtils.unwrap("'abc'", '\''));
        assertEquals("abc", StringUtils.unwrap("\"abc\"", "\""));
        assertEquals("'abc", StringUtils.unwrap("'abc", '\''));
    }

    @Test
    void testRotate() {
        assertNull(StringUtils.rotate(null, 1));
        assertEquals("", StringUtils.rotate("", 5));
        assertEquals("abcdefg", StringUtils.rotate("abcdefg", 0));
        assertEquals("fgabcde", StringUtils.rotate("abcdefg", 2));
        assertEquals("cdefgab", StringUtils.rotate("abcdefg", -2));
    }

    @Test
    void testChompAndChop() {
        assertNull(StringUtils.chomp(null));
        assertEquals("abc", StringUtils.chomp("abc\n"));
        assertEquals("abc", StringUtils.chomp("abc\r\n"));
        assertEquals("", StringUtils.chomp(""));

        assertNull(StringUtils.chop(null));
        assertEquals("abc", StringUtils.chop("abcx"));
        assertEquals("", StringUtils.chop("x"));
        assertEquals("", StringUtils.chop(""));
    }

    @Test
    void testDefaultMethods() {
        assertEquals("", StringUtils.defaultString(null));
        assertEquals("abc", StringUtils.defaultString("abc"));
        assertEquals("NULL", StringUtils.defaultString(null, "NULL"));

        assertEquals("NULL", StringUtils.defaultIfEmpty("", "NULL"));
        assertEquals("abc", StringUtils.defaultIfEmpty("abc", "NULL"));

        assertEquals("NULL", StringUtils.defaultIfBlank("  ", "NULL"));
        assertEquals("abc", StringUtils.defaultIfBlank("abc", "NULL"));
    }

    @Test
    void testEmptyConstant() {
        assertEquals("", StringUtils.EMPTY);
        assertSame(StringUtils.EMPTY, StringUtils.EMPTY);
    }
}
