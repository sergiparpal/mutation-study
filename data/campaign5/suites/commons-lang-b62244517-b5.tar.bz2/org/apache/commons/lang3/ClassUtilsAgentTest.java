/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link ClassUtils}.
 */
public class ClassUtilsAgentTest {

    private interface AgentInterfaceA {
        // marker
    }

    private interface AgentInterfaceB extends AgentInterfaceA {
        // marker
    }

    private static class AgentSuper implements AgentInterfaceB {
        // empty
    }

    private static class AgentChild extends AgentSuper {
        // empty
    }

    public static class AgentInner {
        public static class AgentNested {
            // empty
        }
    }

    // -------------------- constructor --------------------

    @Test
    public void testConstructorIsPublic() {
        assertNotNull(new ClassUtils());
    }

    // -------------------- comparator --------------------

    @Test
    public void testComparator() {
        final List<Class<?>> list = new ArrayList<Class<?>>(Arrays.asList(String.class, Integer.class, Boolean.class));
        list.sort(ClassUtils.comparator());
        assertEquals(Arrays.asList(Boolean.class, Integer.class, String.class), list);
    }

    // -------------------- convertClassesToClassNames --------------------

    @Test
    public void testConvertClassesToClassNamesNull() {
        assertNull(ClassUtils.convertClassesToClassNames(null));
    }

    @Test
    public void testConvertClassesToClassNames() {
        final List<Class<?>> classes = new ArrayList<Class<?>>();
        classes.add(String.class);
        classes.add(null);
        final List<String> names = ClassUtils.convertClassesToClassNames(classes);
        assertEquals(2, names.size());
        assertEquals("java.lang.String", names.get(0));
        assertNull(names.get(1));
    }

    // -------------------- convertClassNamesToClasses --------------------

    @Test
    public void testConvertClassNamesToClassesNull() {
        assertNull(ClassUtils.convertClassNamesToClasses(null));
    }

    @Test
    public void testConvertClassNamesToClasses() {
        final List<String> names = new ArrayList<String>();
        names.add("java.lang.String");
        names.add("not.a.real.ClassName");
        names.add(null);
        final List<Class<?>> classes = ClassUtils.convertClassNamesToClasses(names);
        assertEquals(3, classes.size());
        assertEquals(String.class, classes.get(0));
        assertNull(classes.get(1));
        assertNull(classes.get(2));
    }

    // -------------------- getAbbreviatedName --------------------

    @Test
    public void testGetAbbreviatedNameClassNull() {
        assertEquals("", ClassUtils.getAbbreviatedName((Class<?>) null, 1));
    }

    @Test
    public void testGetAbbreviatedNameStringNull() {
        assertEquals("", ClassUtils.getAbbreviatedName((String) null, 1));
    }

    @Test
    public void testGetAbbreviatedNameInvalidLengthHint() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ClassUtils.getAbbreviatedName("java.lang.String", 0);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ClassUtils.getAbbreviatedName("java.lang.String", -1);
            }
        });
    }

    @Test
    public void testGetAbbreviatedNameExamples() {
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName("java.lang.String", 5));
        assertEquals("j.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 13));
        assertEquals("java.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 30));
        assertEquals("o.a.c.l.ClassUtils", ClassUtils.getAbbreviatedName("org.apache.commons.lang3.ClassUtils", 18));
    }

    @Test
    public void testGetAbbreviatedNameFromClass() {
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName(String.class, 5));
    }

    // -------------------- getAllInterfaces --------------------

    @Test
    public void testGetAllInterfacesNull() {
        assertNull(ClassUtils.getAllInterfaces(null));
    }

    @Test
    public void testGetAllInterfaces() {
        final List<Class<?>> interfaces = ClassUtils.getAllInterfaces(AgentChild.class);
        assertTrue(interfaces.contains(AgentInterfaceA.class));
        assertTrue(interfaces.contains(AgentInterfaceB.class));
        assertEquals(2, interfaces.size());
    }

    @Test
    public void testGetAllInterfacesNoInterfaces() {
        assertTrue(ClassUtils.getAllInterfaces(Object.class).isEmpty());
    }

    // -------------------- getAllSuperclasses --------------------

    @Test
    public void testGetAllSuperclassesNull() {
        assertNull(ClassUtils.getAllSuperclasses(null));
    }

    @Test
    public void testGetAllSuperclasses() {
        final List<Class<?>> supers = ClassUtils.getAllSuperclasses(AgentChild.class);
        assertEquals(Arrays.asList(AgentSuper.class, Object.class), supers);
    }

    @Test
    public void testGetAllSuperclassesOfObject() {
        assertTrue(ClassUtils.getAllSuperclasses(Object.class).isEmpty());
    }

    // -------------------- getCanonicalName --------------------

    @Test
    public void testGetCanonicalNameClassNull() {
        assertEquals("", ClassUtils.getCanonicalName((Class<?>) null));
        assertEquals("X", ClassUtils.getCanonicalName((Class<?>) null, "X"));
    }

    @Test
    public void testGetCanonicalNameClass() {
        assertEquals("java.lang.String", ClassUtils.getCanonicalName(String.class));
    }

    @Test
    public void testGetCanonicalNameObjectNull() {
        assertEquals("", ClassUtils.getCanonicalName((Object) null));
        assertEquals("X", ClassUtils.getCanonicalName((Object) null, "X"));
    }

    @Test
    public void testGetCanonicalNameObject() {
        assertEquals("java.lang.String", ClassUtils.getCanonicalName("hello"));
    }

    // -------------------- getClass --------------------

    @Test
    public void testGetClassSimpleName() throws ClassNotFoundException {
        assertEquals(String.class, ClassUtils.getClass("java.lang.String"));
    }

    @Test
    public void testGetClassPrimitive() throws ClassNotFoundException {
        assertEquals(int.class, ClassUtils.getClass("int"));
    }

    @Test
    public void testGetClassArray() throws ClassNotFoundException {
        assertEquals(int[].class, ClassUtils.getClass("int[]"));
        assertEquals(String[].class, ClassUtils.getClass("java.lang.String[]"));
        assertEquals(String[].class, ClassUtils.getClass("[Ljava.lang.String;"));
    }

    @Test
    public void testGetClassInnerWithDot() throws ClassNotFoundException {
        assertEquals(AgentInner.AgentNested.class,
                ClassUtils.getClass(AgentInner.class.getName() + ".AgentNested"));
    }

    @Test
    public void testGetClassNotFound() {
        assertThrows(ClassNotFoundException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass("not.a.real.ClassName");
            }
        });
    }

    @Test
    public void testGetClassNullThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass((String) null);
            }
        });
    }

    @Test
    public void testGetClassEmptyThrowsIllegalArgument() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass("");
            }
        });
    }

    @Test
    public void testGetClassWithWhitespace() throws ClassNotFoundException {
        assertEquals(String.class, ClassUtils.getClass(" java . lang . String "));
    }

    // -------------------- getComponentType --------------------

    @Test
    public void testGetComponentTypeNull() {
        assertNull(ClassUtils.getComponentType(null));
    }

    @Test
    public void testGetComponentType() {
        assertEquals(String.class, ClassUtils.getComponentType(String[].class));
    }

    // -------------------- getName --------------------

    @Test
    public void testGetNameClassNull() {
        assertEquals("", ClassUtils.getName((Class<?>) null));
        assertEquals("X", ClassUtils.getName((Class<?>) null, "X"));
    }

    @Test
    public void testGetNameClass() {
        assertEquals("java.lang.String", ClassUtils.getName(String.class));
    }

    @Test
    public void testGetNameObjectNull() {
        assertEquals("", ClassUtils.getName((Object) null));
        assertEquals("X", ClassUtils.getName((Object) null, "X"));
    }

    @Test
    public void testGetNameObject() {
        assertEquals("java.lang.String", ClassUtils.getName("hello"));
    }

    // -------------------- getPackageCanonicalName / getPackageName --------------------

    @Test
    public void testGetPackageCanonicalNameClassNull() {
        assertEquals("", ClassUtils.getPackageCanonicalName((Class<?>) null));
    }

    @Test
    public void testGetPackageCanonicalNameClass() {
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName(String[].class));
    }

    @Test
    public void testGetPackageCanonicalNameObjectNull() {
        assertEquals("X", ClassUtils.getPackageCanonicalName((Object) null, "X"));
    }

    @Test
    public void testGetPackageNameClassNull() {
        assertEquals("", ClassUtils.getPackageName((Class<?>) null));
    }

    @Test
    public void testGetPackageNameClass() {
        assertEquals("java.lang", ClassUtils.getPackageName(String.class));
    }

    @Test
    public void testGetPackageNameObjectNull() {
        assertEquals("X", ClassUtils.getPackageName((Object) null, "X"));
    }

    @Test
    public void testGetPackageNameStringEmpty() {
        assertEquals("", ClassUtils.getPackageName(""));
        assertEquals("", ClassUtils.getPackageName((String) null));
    }

    @Test
    public void testGetPackageNameDefaultPackage() {
        assertEquals("", ClassUtils.getPackageName("NoPackage"));
    }

    @Test
    public void testGetPackageNameArrayEncoding() {
        assertEquals("java.lang", ClassUtils.getPackageName("[Ljava.lang.String;"));
    }

    // -------------------- getPublicMethod --------------------

    @Test
    public void testGetPublicMethod() throws Exception {
        final Map<String, String> unmodifiable = java.util.Collections.unmodifiableMap(new java.util.HashMap<String, String>());
        final java.lang.reflect.Method method = ClassUtils.getPublicMethod(unmodifiable.getClass(), "isEmpty");
        assertNotNull(method);
        assertTrue(ClassUtils.isPublic(method.getDeclaringClass()));
        assertEquals(Boolean.TRUE, method.invoke(unmodifiable));
    }

    @Test
    public void testGetPublicMethodNotFound() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getPublicMethod(String.class, "noSuchMethodAtAll");
            }
        });
    }

    @Test
    public void testGetPublicMethodNullClassThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getPublicMethod(null, "isEmpty");
            }
        });
    }

    // -------------------- getShortCanonicalName --------------------

    @Test
    public void testGetShortCanonicalNameClassNull() {
        assertEquals("", ClassUtils.getShortCanonicalName((Class<?>) null));
    }

    @Test
    public void testGetShortCanonicalNameClass() {
        assertEquals("String", ClassUtils.getShortCanonicalName(String.class));
        assertEquals("String[]", ClassUtils.getShortCanonicalName(String[].class));
        assertEquals("int[]", ClassUtils.getShortCanonicalName(int[].class));
    }

    @Test
    public void testGetShortCanonicalNameObjectNull() {
        assertEquals("X", ClassUtils.getShortCanonicalName((Object) null, "X"));
    }

    @Test
    public void testGetShortCanonicalNameString() {
        assertEquals("ClassUtils", ClassUtils.getShortCanonicalName("org.apache.commons.lang3.ClassUtils"));
        assertEquals("int[]", ClassUtils.getShortCanonicalName("[I"));
    }

    // -------------------- getShortClassName --------------------

    @Test
    public void testGetShortClassNameClassNull() {
        assertEquals("", ClassUtils.getShortClassName((Class<?>) null));
    }

    @Test
    public void testGetShortClassNameClass() {
        assertEquals("String", ClassUtils.getShortClassName(String.class));
    }

    @Test
    public void testGetShortClassNameObjectNull() {
        assertEquals("X", ClassUtils.getShortClassName((Object) null, "X"));
    }

    @Test
    public void testGetShortClassNameStringEmpty() {
        assertEquals("", ClassUtils.getShortClassName(""));
        assertEquals("", ClassUtils.getShortClassName((String) null));
    }

    @Test
    public void testGetShortClassNameInnerClass() {
        assertEquals("Map.Entry", ClassUtils.getShortClassName(Map.Entry.class.getName()));
    }

    @Test
    public void testGetShortClassNameArray() {
        assertEquals("String[]", ClassUtils.getShortClassName("[Ljava.lang.String;"));
        assertEquals("String[][]", ClassUtils.getShortClassName("[[Ljava.lang.String;"));
        assertEquals("int[]", ClassUtils.getShortClassName("[I"));
    }

    // -------------------- getSimpleName --------------------

    @Test
    public void testGetSimpleNameClassNull() {
        assertEquals("", ClassUtils.getSimpleName((Class<?>) null));
        assertEquals("X", ClassUtils.getSimpleName((Class<?>) null, "X"));
    }

    @Test
    public void testGetSimpleNameClass() {
        assertEquals("String", ClassUtils.getSimpleName(String.class));
    }

    @Test
    public void testGetSimpleNameObjectNull() {
        assertEquals("", ClassUtils.getSimpleName((Object) null));
        assertEquals("X", ClassUtils.getSimpleName((Object) null, "X"));
    }

    @Test
    public void testGetSimpleNameObject() {
        assertEquals("String", ClassUtils.getSimpleName("hello"));
    }

    // -------------------- hierarchy --------------------

    @Test
    public void testHierarchyExcludeInterfaces() {
        final List<Class<?>> hierarchy = new ArrayList<Class<?>>();
        for (final Class<?> c : ClassUtils.hierarchy(AgentChild.class)) {
            hierarchy.add(c);
        }
        assertEquals(Arrays.asList(AgentChild.class, AgentSuper.class, Object.class), hierarchy);
    }

    @Test
    public void testHierarchyIncludeInterfaces() {
        final List<Class<?>> hierarchy = new ArrayList<Class<?>>();
        for (final Class<?> c : ClassUtils.hierarchy(AgentChild.class, ClassUtils.Interfaces.INCLUDE)) {
            hierarchy.add(c);
        }
        assertTrue(hierarchy.contains(AgentChild.class));
        assertTrue(hierarchy.contains(AgentSuper.class));
        assertTrue(hierarchy.contains(AgentInterfaceA.class));
        assertTrue(hierarchy.contains(AgentInterfaceB.class));
        assertTrue(hierarchy.contains(Object.class));
    }

    @Test
    public void testHierarchyIteratorRemoveUnsupported() {
        final Iterator<Class<?>> it = ClassUtils.hierarchy(AgentChild.class).iterator();
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                it.remove();
            }
        });
    }

    // -------------------- isAssignable --------------------

    @Test
    public void testIsAssignableNullToClass() {
        assertFalse(ClassUtils.isAssignable(String.class, null));
    }

    @Test
    public void testIsAssignableNullClassToReference() {
        assertTrue(ClassUtils.isAssignable((Class<?>) null, Object.class));
    }

    @Test
    public void testIsAssignableNullClassToPrimitive() {
        assertFalse(ClassUtils.isAssignable((Class<?>) null, int.class));
    }

    @Test
    public void testIsAssignableAutoboxing() {
        assertTrue(ClassUtils.isAssignable(Integer.class, int.class));
        assertTrue(ClassUtils.isAssignable(int.class, Integer.class));
        assertTrue(ClassUtils.isAssignable(int.class, long.class));
        assertFalse(ClassUtils.isAssignable(long.class, int.class));
    }

    @Test
    public void testIsAssignableNoAutoboxing() {
        assertFalse(ClassUtils.isAssignable(Integer.class, int.class, false));
    }

    @Test
    public void testIsAssignableReferenceTypes() {
        assertTrue(ClassUtils.isAssignable(AgentChild.class, AgentInterfaceA.class));
        assertFalse(ClassUtils.isAssignable(AgentSuper.class, AgentChild.class));
    }

    @Test
    public void testIsAssignableArraysDifferentLength() {
        assertFalse(ClassUtils.isAssignable(new Class<?>[] {String.class}, new Class<?>[] {String.class, Integer.class}));
    }

    @Test
    public void testIsAssignableArraysNull() {
        assertTrue(ClassUtils.isAssignable((Class<?>[]) null, (Class<?>[]) null));
    }

    @Test
    public void testIsAssignableArrays() {
        assertTrue(ClassUtils.isAssignable(new Class<?>[] {String.class, int.class}, new Class<?>[] {Object.class, long.class}));
        assertFalse(ClassUtils.isAssignable(new Class<?>[] {String.class, long.class}, new Class<?>[] {Object.class, int.class}));
    }

    // -------------------- isInnerClass --------------------

    @Test
    public void testIsInnerClassNull() {
        assertFalse(ClassUtils.isInnerClass(null));
    }

    @Test
    public void testIsInnerClassTrue() {
        assertTrue(ClassUtils.isInnerClass(AgentInner.AgentNested.class));
    }

    @Test
    public void testIsInnerClassFalse() {
        assertFalse(ClassUtils.isInnerClass(String.class));
    }

    // -------------------- isPrimitiveOrWrapper / isPrimitiveWrapper --------------------

    @Test
    public void testIsPrimitiveOrWrapperNull() {
        assertFalse(ClassUtils.isPrimitiveOrWrapper(null));
    }

    @Test
    public void testIsPrimitiveOrWrapper() {
        assertTrue(ClassUtils.isPrimitiveOrWrapper(int.class));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(Integer.class));
        assertFalse(ClassUtils.isPrimitiveOrWrapper(String.class));
    }

    @Test
    public void testIsPrimitiveWrapperNull() {
        assertFalse(ClassUtils.isPrimitiveWrapper(null));
    }

    @Test
    public void testIsPrimitiveWrapper() {
        assertTrue(ClassUtils.isPrimitiveWrapper(Boolean.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(boolean.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(String.class));
    }

    // -------------------- isPublic --------------------

    @Test
    public void testIsPublic() {
        assertTrue(ClassUtils.isPublic(String.class));
        assertFalse(ClassUtils.isPublic(AgentSuper.class));
    }

    @Test
    public void testIsPublicNullThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ClassUtils.isPublic(null);
            }
        });
    }

    // -------------------- primitivesToWrappers / primitiveToWrapper --------------------

    @Test
    public void testPrimitivesToWrappersNull() {
        assertNull(ClassUtils.primitivesToWrappers((Class<?>[]) null));
    }

    @Test
    public void testPrimitivesToWrappersEmpty() {
        final Class<?>[] empty = new Class<?>[0];
        assertEquals(0, ClassUtils.primitivesToWrappers(empty).length);
    }

    @Test
    public void testPrimitivesToWrappers() {
        final Class<?>[] result = ClassUtils.primitivesToWrappers(int.class, String.class, null);
        assertEquals(Integer.class, result[0]);
        assertEquals(String.class, result[1]);
        assertNull(result[2]);
    }

    @Test
    public void testPrimitiveToWrapperNull() {
        assertNull(ClassUtils.primitiveToWrapper(null));
    }

    @Test
    public void testPrimitiveToWrapper() {
        assertEquals(Integer.class, ClassUtils.primitiveToWrapper(int.class));
        assertEquals(String.class, ClassUtils.primitiveToWrapper(String.class));
        assertEquals(Void.TYPE, ClassUtils.primitiveToWrapper(Void.TYPE));
    }

    // -------------------- toClass --------------------

    @Test
    public void testToClassNull() {
        assertNull(ClassUtils.toClass((Object[]) null));
    }

    @Test
    public void testToClassEmpty() {
        assertEquals(0, ClassUtils.toClass().length);
    }

    @Test
    public void testToClass() {
        final Class<?>[] result = ClassUtils.toClass("a", 1, null);
        assertEquals(String.class, result[0]);
        assertEquals(Integer.class, result[1]);
        assertNull(result[2]);
    }

    // -------------------- wrappersToPrimitives / wrapperToPrimitive --------------------

    @Test
    public void testWrappersToPrimitivesNull() {
        assertNull(ClassUtils.wrappersToPrimitives((Class<?>[]) null));
    }

    @Test
    public void testWrappersToPrimitivesEmpty() {
        final Class<?>[] empty = new Class<?>[0];
        assertEquals(0, ClassUtils.wrappersToPrimitives(empty).length);
    }

    @Test
    public void testWrappersToPrimitives() {
        final Class<?>[] result = ClassUtils.wrappersToPrimitives(Integer.class, String.class, null);
        assertEquals(int.class, result[0]);
        assertNull(result[1]);
        assertNull(result[2]);
    }

    @Test
    public void testWrapperToPrimitiveNull() {
        assertNull(ClassUtils.wrapperToPrimitive(null));
    }

    @Test
    public void testWrapperToPrimitive() {
        assertEquals(int.class, ClassUtils.wrapperToPrimitive(Integer.class));
        assertNull(ClassUtils.wrapperToPrimitive(String.class));
    }

    // -------------------- Interfaces enum --------------------

    @Test
    public void testInterfacesEnumValues() {
        assertEquals(2, ClassUtils.Interfaces.values().length);
        assertEquals(ClassUtils.Interfaces.INCLUDE, ClassUtils.Interfaces.valueOf("INCLUDE"));
        assertEquals(ClassUtils.Interfaces.EXCLUDE, ClassUtils.Interfaces.valueOf("EXCLUDE"));
    }

    // -------------------- Serializable marker check --------------------

    @Test
    public void testClassUtilsIsNotSerializableInstance() {
        assertFalse(new ClassUtils() instanceof Serializable);
    }
}
