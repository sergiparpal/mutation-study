/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.function.FailableConsumer;
import org.apache.commons.lang3.function.FailableRunnable;
import org.junit.jupiter.api.Test;

/**
 * Tests {@link DurationUtils}.
 */
class DurationUtilsAgentTest {

    private static final class CustomException extends Exception {
        private static final long serialVersionUID = 1L;

        CustomException(final String message) {
            super(message);
        }
    }

    @Test
    void testAcceptNullConsumerIsNoOp() throws Throwable {
        // Should not throw even though the consumer is null.
        DurationUtils.accept(null, Duration.ofMillis(1234));
    }

    @Test
    void testAcceptNullDurationIsNoOp() throws Throwable {
        final boolean[] called = { false };
        DurationUtils.accept(new org.apache.commons.lang3.function.FailableBiConsumer<Long, Integer, RuntimeException>() {
            @Override
            public void accept(final Long millis, final Integer nanos) {
                called[0] = true;
            }
        }, null);
        assertFalse(called[0]);
    }

    @Test
    void testAcceptPassesMillisAndNanos() throws Throwable {
        final Duration duration = Duration.ofSeconds(1, 123456789L);
        final long[] millisHolder = { -1 };
        final int[] nanosHolder = { -1 };
        DurationUtils.accept(new org.apache.commons.lang3.function.FailableBiConsumer<Long, Integer, RuntimeException>() {
            @Override
            public void accept(final Long millis, final Integer nanos) {
                millisHolder[0] = millis;
                nanosHolder[0] = nanos;
            }
        }, duration);
        assertEquals(duration.toMillis(), millisHolder[0]);
        assertEquals(123456789 % 1000000, nanosHolder[0]);
    }

    @Test
    void testAcceptPropagatesException() {
        final Duration duration = Duration.ofMillis(5);
        assertThrows(CustomException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                DurationUtils.accept(new org.apache.commons.lang3.function.FailableBiConsumer<Long, Integer, CustomException>() {
                    @Override
                    public void accept(final Long millis, final Integer nanos) throws CustomException {
                        throw new CustomException("boom");
                    }
                }, duration);
            }
        });
    }

    @Test
    void testGetDefault() {
        final Duration duration = DurationUtils.get("this.property.does.not.exist.agent.test", ChronoUnit.SECONDS, 42);
        assertEquals(Duration.ofSeconds(42), duration);
    }

    @Test
    void testGetEmptyKeyUsesDefault() {
        final Duration duration = DurationUtils.get("", ChronoUnit.MINUTES, 7);
        assertEquals(Duration.ofMinutes(7), duration);
    }

    @Test
    void testGetMillisDefault() {
        final Duration duration = DurationUtils.getMillis("this.property.does.not.exist.agent.test", 500);
        assertEquals(Duration.ofMillis(500), duration);
    }

    @Test
    void testGetSecondsDefault() {
        final Duration duration = DurationUtils.getSeconds("this.property.does.not.exist.agent.test", 9);
        assertEquals(Duration.ofSeconds(9), duration);
    }

    @Test
    void testGetNanosOfMilli() {
        assertEquals(0, DurationUtils.getNanosOfMilli(Duration.ofSeconds(1)));
        assertEquals(500000, DurationUtils.getNanosOfMilli(Duration.ofNanos(500000)));
        assertEquals(999999, DurationUtils.getNanosOfMilli(Duration.ofNanos(1999999)));
    }

    @Test
    void testGetNanosOfMiiliDeprecatedMatchesReplacement() {
        final Duration duration = Duration.ofNanos(123456789L);
        assertEquals(DurationUtils.getNanosOfMilli(duration), DurationUtils.getNanosOfMiili(duration));
    }

    @Test
    void testGetNanosOfMilliNullDuration() {
        assertEquals(0, DurationUtils.getNanosOfMilli(null));
    }

    @Test
    void testIsPositive() {
        assertTrue(DurationUtils.isPositive(Duration.ofMillis(1)));
        assertFalse(DurationUtils.isPositive(Duration.ZERO));
        assertFalse(DurationUtils.isPositive(Duration.ofMillis(-1)));
    }

    @Test
    void testOfRunnableReturnsNonNegativeDuration() throws Throwable {
        final Duration duration = DurationUtils.of(new FailableRunnable<RuntimeException>() {
            @Override
            public void run() {
                // no-op, just measure overhead
            }
        });
        assertNotNull(duration);
        assertFalse(duration.isNegative());
    }

    @Test
    void testOfConsumerReceivesStartInstant() throws Throwable {
        final Instant[] startHolder = new Instant[1];
        final Duration duration = DurationUtils.of(new FailableConsumer<Instant, RuntimeException>() {
            @Override
            public void accept(final Instant start) {
                startHolder[0] = start;
            }
        });
        assertNotNull(startHolder[0]);
        assertNotNull(duration);
        assertFalse(duration.isNegative());
    }

    @Test
    void testOfRunnablePropagatesException() {
        assertThrows(CustomException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                DurationUtils.of(new FailableRunnable<CustomException>() {
                    @Override
                    public void run() throws CustomException {
                        throw new CustomException("boom");
                    }
                });
            }
        });
    }

    @Test
    void testSince() {
        final Instant start = Instant.now().minusSeconds(1);
        final Duration duration = DurationUtils.since(start);
        assertFalse(duration.isNegative());
        assertTrue(duration.toMillis() >= 900);
    }

    @Test
    void testToChronoUnitAllValues() {
        assertEquals(ChronoUnit.NANOS, DurationUtils.toChronoUnit(TimeUnit.NANOSECONDS));
        assertEquals(ChronoUnit.MICROS, DurationUtils.toChronoUnit(TimeUnit.MICROSECONDS));
        assertEquals(ChronoUnit.MILLIS, DurationUtils.toChronoUnit(TimeUnit.MILLISECONDS));
        assertEquals(ChronoUnit.SECONDS, DurationUtils.toChronoUnit(TimeUnit.SECONDS));
        assertEquals(ChronoUnit.MINUTES, DurationUtils.toChronoUnit(TimeUnit.MINUTES));
        assertEquals(ChronoUnit.HOURS, DurationUtils.toChronoUnit(TimeUnit.HOURS));
        assertEquals(ChronoUnit.DAYS, DurationUtils.toChronoUnit(TimeUnit.DAYS));
    }

    @Test
    void testToChronoUnitNullThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationUtils.toChronoUnit(null);
            }
        });
    }

    @Test
    void testToDuration() {
        assertEquals(Duration.ofSeconds(5), DurationUtils.toDuration(5, TimeUnit.SECONDS));
        assertEquals(Duration.ofMillis(-10), DurationUtils.toDuration(-10, TimeUnit.MILLISECONDS));
        assertEquals(Duration.ZERO, DurationUtils.toDuration(0, TimeUnit.DAYS));
    }

    @Test
    void testToMillisInt() {
        assertEquals(1000, DurationUtils.toMillisInt(Duration.ofSeconds(1)));
        assertEquals(0, DurationUtils.toMillisInt(Duration.ZERO));
        assertEquals(-1000, DurationUtils.toMillisInt(Duration.ofSeconds(-1)));
    }

    @Test
    void testToMillisIntClampsToIntegerMax() {
        final Duration huge = Duration.ofMillis(Long.MAX_VALUE);
        assertEquals(Integer.MAX_VALUE, DurationUtils.toMillisInt(huge));
    }

    @Test
    void testToMillisIntClampsToIntegerMin() {
        final Duration huge = Duration.ofMillis(Long.MIN_VALUE);
        assertEquals(Integer.MIN_VALUE, DurationUtils.toMillisInt(huge));
    }

    @Test
    void testToMillisIntNullThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationUtils.toMillisInt(null);
            }
        });
    }

    @Test
    void testZeroIfNull() {
        assertSame(Duration.ZERO, DurationUtils.zeroIfNull(null));
        final Duration d = Duration.ofSeconds(3);
        assertSame(d, DurationUtils.zeroIfNull(d));
    }

    @Test
    void testConstructorIsAccessible() {
        // The deprecated public constructor should still be usable for backward compatibility.
        assertNotNull(new DurationUtils());
    }
}
