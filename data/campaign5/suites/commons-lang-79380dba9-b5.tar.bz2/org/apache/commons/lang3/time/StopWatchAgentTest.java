/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;

import org.apache.commons.lang3.function.FailableRunnable;
import org.apache.commons.lang3.function.FailableSupplier;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests {@link StopWatch}.
 */
class StopWatchAgentTest {

    private static final class CustomException extends Exception {
        private static final long serialVersionUID = 1L;

        CustomException(final String message) {
            super(message);
        }
    }

    private void sleepQuietly(final long millis) {
        try {
            Thread.sleep(millis);
        } catch (final InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    @Test
    void testCreateReturnsUnstartedWatch() {
        final StopWatch watch = StopWatch.create();
        assertFalse(watch.isStarted());
        assertTrue(watch.isStopped());
        assertFalse(watch.isSuspended());
        assertEquals(0, watch.getTime());
    }

    @Test
    void testCreateStartedReturnsStartedWatch() {
        final StopWatch watch = StopWatch.createStarted();
        assertTrue(watch.isStarted());
        assertFalse(watch.isStopped());
        assertFalse(watch.isSuspended());
    }

    @Test
    void testDefaultConstructorHasNullMessage() {
        final StopWatch watch = new StopWatch();
        assertNull(watch.getMessage());
    }

    @Test
    void testMessageConstructor() {
        final StopWatch watch = new StopWatch("my message");
        assertEquals("my message", watch.getMessage());
        assertTrue(watch.toString().startsWith("my message "));
    }

    @Test
    void testStartTwiceThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.start();
            }
        });
    }

    @Test
    void testStartAfterStopWithoutResetThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.start();
            }
        });
    }

    @Test
    void testStartAfterResetSucceeds() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        watch.reset();
        watch.start();
        assertTrue(watch.isStarted());
    }

    @Test
    void testStopWithoutStartThrows() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.stop();
            }
        });
    }

    @Test
    void testStopAfterStopThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.stop();
            }
        });
    }

    @Test
    void testStopFromSuspendedIsAllowed() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.suspend();
        watch.stop();
        assertTrue(watch.isStopped());
    }

    @Test
    void testSuspendWithoutStartThrows() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.suspend();
            }
        });
    }

    @Test
    void testSuspendTwiceThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.suspend();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.suspend();
            }
        });
    }

    @Test
    void testResumeWithoutSuspendThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.resume();
            }
        });
    }

    @Test
    void testResumeWithoutStartThrows() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.resume();
            }
        });
    }

    @Test
    void testSuspendResumeExcludesPausedTime() {
        final StopWatch watch = new StopWatch();
        watch.start();
        sleepQuietly(20);
        watch.suspend();
        assertTrue(watch.isSuspended());
        final long suspendedTime = watch.getTime();
        sleepQuietly(50);
        assertEquals(suspendedTime, watch.getTime());
        watch.resume();
        assertFalse(watch.isSuspended());
        watch.stop();
        assertTrue(watch.getTime() >= suspendedTime);
    }

    @Test
    void testSplitWithoutStartThrows() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.split();
            }
        });
    }

    @Test
    void testSplitTwiceWhileRunningAccumulatesSplits() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        watch.split();
        assertEquals(2, watch.getSplits().size());
        assertEquals("0", watch.getSplits().get(0).getLabel());
        assertEquals("1", watch.getSplits().get(1).getLabel());
    }

    @Test
    void testSplitAfterStopThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.split();
            }
        });
    }

    @Test
    void testUnsplitWithoutSplitThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.unsplit();
            }
        });
    }

    @Test
    void testGetSplitNanoTimeWithoutSplitThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.getSplitNanoTime();
            }
        });
    }

    @Test
    void testSplitAndUnsplit() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        assertEquals(1, watch.getSplits().size());
        assertEquals("0", watch.getSplits().get(0).getLabel());
        final Duration splitDuration = watch.getSplitDuration();
        assertNotNull(splitDuration);
        assertFalse(splitDuration.isNegative());
        assertEquals(watch.getSplitNanoTime(), splitDuration.toNanos());
        watch.unsplit();
        assertEquals(0, watch.getSplits().size());
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.getSplitNanoTime();
            }
        });
    }

    @Test
    void testSplitWithLabel() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split("first");
        assertEquals("first", watch.getSplits().get(0).getLabel());
        assertEquals(1, watch.getSplits().size());
    }

    @Test
    void testSplitAccumulatesMultipleSplits() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split("one");
        watch.unsplit();
        watch.split("two");
        assertEquals(1, watch.getSplits().size());
        assertEquals("two", watch.getSplits().get(0).getLabel());
    }

    @Test
    void testGetSplitsIsUnmodifiable() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        final List<StopWatch.Split> splits = watch.getSplits();
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                splits.add(new StopWatch.Split("x", Duration.ZERO));
            }
        });
    }

    @Test
    void testSplitObjectAccessors() {
        final StopWatch.Split split = new StopWatch.Split("label", Duration.ofSeconds(2));
        assertEquals("label", split.getLabel());
        assertEquals(Duration.ofSeconds(2), split.getDuration());
        assertTrue(split.toString().contains("label"));
    }

    @Test
    void testResetClearsSplitsAndState() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        watch.reset();
        assertTrue(watch.isStopped());
        assertFalse(watch.isStarted());
        assertEquals(0, watch.getSplits().size());
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.getSplitNanoTime();
            }
        });
    }

    @Test
    void testGetStartInstantWithoutStartThrows() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.getStartInstant();
            }
        });
    }

    @Test
    void testGetStopInstantWithoutStartThrows() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.getStopInstant();
            }
        });
    }

    @Test
    void testGetStopInstantBeforeStopIsNull() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertNull(watch.getStopInstant());
        assertEquals(0L, watch.getStopTime());
    }

    @Test
    void testGetStartAndStopInstantsAfterStop() {
        final StopWatch watch = new StopWatch();
        watch.start();
        sleepQuietly(5);
        watch.stop();
        assertNotNull(watch.getStartInstant());
        assertNotNull(watch.getStopInstant());
        assertTrue(watch.getStopInstant().isAfter(watch.getStartInstant()) || watch.getStopInstant().equals(watch.getStartInstant()));
        assertEquals(watch.getStartInstant().toEpochMilli(), watch.getStartTime());
        assertEquals(watch.getStopInstant().toEpochMilli(), watch.getStopTime());
    }

    @Test
    void testGetTimeUnstartedIsZero() {
        final StopWatch watch = new StopWatch();
        assertEquals(0, watch.getTime());
        assertEquals(0, watch.getNanoTime());
        assertEquals(Duration.ZERO, watch.getDuration());
    }

    @Test
    void testGetTimeInSpecifiedUnit() {
        final StopWatch watch = new StopWatch();
        watch.start();
        sleepQuietly(30);
        watch.stop();
        final long millis = watch.getTime(TimeUnit.MILLISECONDS);
        final long nanos = watch.getTime(TimeUnit.NANOSECONDS);
        assertTrue(millis >= 30);
        assertTrue(nanos >= millis * 1000000L);
        final long hours = watch.getTime(TimeUnit.HOURS);
        assertEquals(0, hours);
    }

    @Test
    void testGetSplitTimeDeprecatedMatchesSplitDuration() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        assertEquals(watch.getSplitDuration().toMillis(), watch.getSplitTime());
    }

    @Test
    void testFormatTimeAndSplitTime() {
        final StopWatch watch = new StopWatch();
        assertEquals("00:00:00.000", watch.formatTime());
        watch.start();
        watch.split();
        final String formattedSplit = watch.formatSplitTime();
        assertEquals(12, formattedSplit.length());
        assertTrue(formattedSplit.startsWith("00:"));
    }

    @Test
    void testToStringWithoutMessage() {
        final StopWatch watch = new StopWatch();
        assertEquals("00:00:00.000", watch.toString());
    }

    @Test
    void testToSplitStringWithoutMessage() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        final String splitString = watch.toSplitString();
        assertEquals(12, splitString.length());
    }

    @Test
    void testToSplitStringWithMessage() {
        final StopWatch watch = new StopWatch("prefix");
        watch.start();
        watch.split();
        assertTrue(watch.toSplitString().startsWith("prefix "));
    }

    @Test
    void testRunExecutesRunnableAndSuspendsAfterwards() {
        final boolean[] ran = { false };
        final StopWatch watch = new StopWatch();
        watch.run(new Runnable() {
            @Override
            public void run() {
                ran[0] = true;
                assertTrue(watch.isStarted());
            }
        });
        assertTrue(ran[0]);
        assertTrue(watch.isSuspended());
    }

    @Test
    void testGetDelegatesToSupplierAndSuspends() {
        final StopWatch watch = new StopWatch();
        final String result = watch.get(new Supplier<String>() {
            @Override
            public String get() {
                assertTrue(watch.isStarted());
                return "value";
            }
        });
        assertEquals("value", result);
        assertTrue(watch.isSuspended());
    }

    @Test
    void testRunTPropagatesCheckedException() {
        final StopWatch watch = new StopWatch();
        assertThrows(CustomException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                watch.runT(new FailableRunnable<CustomException>() {
                    @Override
                    public void run() throws CustomException {
                        throw new CustomException("boom");
                    }
                });
            }
        });
        assertTrue(watch.isSuspended());
    }

    @Test
    void testGetTPropagatesCheckedExceptionAndReturnsValueOtherwise() throws Throwable {
        final StopWatch watch = new StopWatch();
        final Integer value = watch.getT(new FailableSupplier<Integer, CustomException>() {
            @Override
            public Integer get() {
                return 42;
            }
        });
        assertEquals(Integer.valueOf(42), value);
        assertTrue(watch.isSuspended());

        final StopWatch watch2 = new StopWatch();
        assertThrows(CustomException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                watch2.getT(new FailableSupplier<Integer, CustomException>() {
                    @Override
                    public Integer get() throws CustomException {
                        throw new CustomException("boom");
                    }
                });
            }
        });
    }

    @Test
    void testGetResumesSuspendedWatch() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.suspend();
        final String result = watch.get(new Supplier<String>() {
            @Override
            public String get() {
                assertTrue(watch.isStarted());
                assertFalse(watch.isSuspended());
                return "resumed";
            }
        });
        assertEquals("resumed", result);
        assertTrue(watch.isSuspended());
    }

    @Test
    void testIsStartedIsStoppedIsSuspendedTransitions() {
        final StopWatch watch = new StopWatch();
        assertFalse(watch.isStarted());
        assertTrue(watch.isStopped());
        assertFalse(watch.isSuspended());

        watch.start();
        assertTrue(watch.isStarted());
        assertFalse(watch.isStopped());
        assertFalse(watch.isSuspended());

        watch.suspend();
        assertTrue(watch.isStarted());
        assertFalse(watch.isStopped());
        assertTrue(watch.isSuspended());

        watch.resume();
        assertTrue(watch.isStarted());
        assertFalse(watch.isStopped());
        assertFalse(watch.isSuspended());

        watch.stop();
        assertFalse(watch.isStarted());
        assertTrue(watch.isStopped());
        assertFalse(watch.isSuspended());
    }

    @Test
    void testGetDurationMatchesGetTimeInMillis() {
        final StopWatch watch = new StopWatch();
        watch.start();
        sleepQuietly(10);
        watch.stop();
        assertEquals(watch.getTime(), watch.getDuration().toMillis());
        assertSame(watch.getDuration().getClass(), Duration.class);
    }
}
