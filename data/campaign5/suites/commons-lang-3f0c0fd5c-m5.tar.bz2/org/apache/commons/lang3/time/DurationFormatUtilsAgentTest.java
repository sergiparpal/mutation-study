/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Tests for {@link DurationFormatUtils}.
 */
public class DurationFormatUtilsAgentTest {

    private static final TimeZone GMT = TimeZone.getTimeZone("GMT");

    // formatDuration -----------------------------------------------------

    @Test
    public void testFormatDuration_zero() {
        assertEquals("0", DurationFormatUtils.formatDuration(0, "d"));
    }

    @Test
    public void testFormatDuration_daysHoursMinutesSecondsMillis() {
        final long millis = (((1L * 24 + 2) * 60 + 3) * 60 + 4) * 1000 + 5;
        // 'S' immediately following 's' is always padded to at least 3 digits.
        assertEquals("1 2 3 4 005", DurationFormatUtils.formatDuration(millis, "d H m s S"));
    }

    @Test
    public void testFormatDuration_padWithZerosFalse() {
        final long millis = (((1L * 24 + 2) * 60 + 3) * 60 + 4) * 1000 + 5;
        // 'S' immediately following 's' is always padded to at least 3 digits, even with padWithZeros=false.
        assertEquals("1:2:3:4:005", DurationFormatUtils.formatDuration(millis, "d:H:m:s:S", false));
    }

    @Test
    public void testFormatDuration_padding() {
        assertEquals("001", DurationFormatUtils.formatDuration(1, "SSS"));
        assertEquals("1", DurationFormatUtils.formatDuration(1, "SSS", false));
    }

    @Test
    public void testFormatDuration_negativeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatDuration(-1, "d");
            }
        });
    }

    @Test
    public void testFormatDuration_literalText() {
        assertEquals("1 days", DurationFormatUtils.formatDuration(DateUtils.MILLIS_PER_DAY, "d' days'"));
    }

    @Test
    public void testFormatDuration_optionalBlockSuppressed() {
        // zero days -> optional block omitted entirely
        assertEquals("0s", DurationFormatUtils.formatDuration(0, "[d'd'H'h'm'm']s's'"));
        // one hour -> optional block kept (because hour token non-zero)
        assertEquals("1h0s", DurationFormatUtils.formatDuration(DateUtils.MILLIS_PER_HOUR, "[d'd'H'h'm'm']s's'"));
    }

    @Test
    public void testFormatDuration_milliSecondsWithSecondsPadsToThree() {
        // 'S' after 's' is padded to at least 3 digits regardless of padWithZeros when lastOutputSeconds
        assertEquals("0.001", DurationFormatUtils.formatDuration(1, "s.S", false));
    }

    // formatDurationHMS ----------------------------------------------------

    @Test
    public void testFormatDurationHMS_zero() {
        assertEquals("00:00:00.000", DurationFormatUtils.formatDurationHMS(0));
    }

    @Test
    public void testFormatDurationHMS_value() {
        final long millis = ((2L * 60 + 3) * 60 + 4) * 1000 + 5;
        assertEquals("02:03:04.005", DurationFormatUtils.formatDurationHMS(millis));
    }

    // formatDurationISO ----------------------------------------------------

    @Test
    public void testFormatDurationISO_zero() {
        assertEquals("P0Y0M0DT0H0M0.000S", DurationFormatUtils.formatDurationISO(0));
    }

    @Test
    public void testFormatDurationISO_oneDay() {
        assertEquals("P0Y0M1DT0H0M0.000S", DurationFormatUtils.formatDurationISO(DateUtils.MILLIS_PER_DAY));
    }

    // formatDurationWords --------------------------------------------------

    @Test
    public void testFormatDurationWords_zero_noSuppression() {
        assertEquals("0 days 0 hours 0 minutes 0 seconds", DurationFormatUtils.formatDurationWords(0, false, false));
    }

    @Test
    public void testFormatDurationWords_zero_suppressLeading() {
        // leading suppression only removes " 0 days"/" 0 hours"/" 0 minutes", the trailing seconds remain.
        assertEquals("0 seconds", DurationFormatUtils.formatDurationWords(0, true, false));
    }

    @Test
    public void testFormatDurationWords_zero_suppressBoth() {
        // trailing suppression looks for a leading space before "0 seconds" which was already stripped, so it has no effect here.
        assertEquals("0 seconds", DurationFormatUtils.formatDurationWords(0, true, true));
    }

    @Test
    public void testFormatDurationWords_oneDay_singularAndSuppression() {
        final String result = DurationFormatUtils.formatDurationWords(DateUtils.MILLIS_PER_DAY, true, true);
        assertEquals("1 day", result);
    }

    @Test
    public void testFormatDurationWords_oneOfEach_singular() {
        final long millis = (((1L * 24 + 1) * 60 + 1) * 60 + 1) * 1000;
        final String result = DurationFormatUtils.formatDurationWords(millis, false, false);
        assertEquals("1 day 1 hour 1 minute 1 second", result);
    }

    @Test
    public void testFormatDurationWords_suppressTrailingOnly() {
        // 1 day, 0 hours, 0 minutes, 0 seconds, suppress trailing zero elements
        final String result = DurationFormatUtils.formatDurationWords(DateUtils.MILLIS_PER_DAY, false, true);
        assertEquals("1 day", result);
    }

    // formatPeriod -----------------------------------------------------

    @Test
    public void testFormatPeriod_zero() {
        assertEquals("0", DurationFormatUtils.formatPeriod(0, 0, "d"));
    }

    @Test
    public void testFormatPeriod_startGreaterThanEndThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatPeriod(1, 0, "d");
            }
        });
    }

    @Test
    public void testFormatPeriod_daysOnly() {
        final Calendar start = new GregorianCalendar(2000, Calendar.JANUARY, 1, 0, 0, 0);
        start.setTimeZone(GMT);
        start.set(Calendar.MILLISECOND, 0);
        final Calendar end = new GregorianCalendar(2000, Calendar.JANUARY, 5, 0, 0, 0);
        end.setTimeZone(GMT);
        end.set(Calendar.MILLISECOND, 0);
        final String result = DurationFormatUtils.formatPeriod(start.getTimeInMillis(), end.getTimeInMillis(), "d", true, GMT);
        assertEquals("4", result);
    }

    @Test
    public void testFormatPeriod_monthsAndDays() {
        final Calendar start = new GregorianCalendar(2000, Calendar.JANUARY, 15, 0, 0, 0);
        start.setTimeZone(GMT);
        start.set(Calendar.MILLISECOND, 0);
        final Calendar end = new GregorianCalendar(2000, Calendar.MARCH, 10, 0, 0, 0);
        end.setTimeZone(GMT);
        end.set(Calendar.MILLISECOND, 0);
        final String result = DurationFormatUtils.formatPeriod(start.getTimeInMillis(), end.getTimeInMillis(), "M'm'd'd'", true, GMT);
        assertEquals("1m26d", result);
    }

    @Test
    public void testFormatPeriod_withoutDaysToken_rollsIntoHours() {
        // 2 days should be converted into 48 hours when 'd' is absent from the pattern.
        final long start = 0L;
        final long end = 2 * DateUtils.MILLIS_PER_DAY;
        final String result = DurationFormatUtils.formatPeriod(start, end, "H", true, GMT);
        assertEquals("48", result);
    }

    // formatPeriodISO --------------------------------------------------

    @Test
    public void testFormatPeriodISO_zero() {
        assertEquals("P0Y0M0DT0H0M0.000S", DurationFormatUtils.formatPeriodISO(0, 0));
    }

    @Test
    public void testFormatPeriodISO_oneDay() {
        assertEquals("P0Y0M1DT0H0M0.000S", DurationFormatUtils.formatPeriodISO(0, DateUtils.MILLIS_PER_DAY));
    }

    // lexx (package-private) --------------------------------------------

    @Test
    public void testLexx_simpleTokens() {
        final DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("yMdHms");
        assertEquals(6, tokens.length);
        assertEquals("y", tokens[0].toString());
        assertEquals("M", tokens[1].toString());
        assertEquals("d", tokens[2].toString());
        assertEquals("H", tokens[3].toString());
        assertEquals("m", tokens[4].toString());
        assertEquals("s", tokens[5].toString());
    }

    @Test
    public void testLexx_repeatedTokenIncrementsCount() {
        final DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("yyyy");
        assertEquals(1, tokens.length);
        assertEquals(4, tokens[0].getCount());
        assertEquals("yyyy", tokens[0].toString());
    }

    @Test
    public void testLexx_literalText() {
        final DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("d'd'");
        assertEquals(2, tokens.length);
        assertEquals("d", tokens[0].toString());
        assertEquals("d", tokens[1].toString());
    }

    @Test
    public void testLexx_escapedQuote() {
        final DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("''");
        assertEquals(1, tokens.length);
        assertEquals("'", tokens[0].toString());
    }

    @Test
    public void testLexx_unmatchedQuoteThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.lexx("d'd");
            }
        });
    }

    @Test
    public void testLexx_unmatchedOptionalThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.lexx("[d");
            }
        });
    }

    @Test
    public void testLexx_unopenedOptionalCloseThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.lexx("d]");
            }
        });
    }

    @Test
    public void testLexx_nestedOptionalThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.lexx("[d[H]]");
            }
        });
    }

    // Token internal class -------------------------------------------------

    @Test
    public void testToken_equalsAndHashCode() {
        final DurationFormatUtils.Token[] a = DurationFormatUtils.lexx("yy");
        final DurationFormatUtils.Token[] b = DurationFormatUtils.lexx("yy");
        assertEquals(a[0], b[0]);
        assertEquals(a[0].hashCode(), b[0].hashCode());
        assertFalse(a[0].equals("not a token"));
    }

    @Test
    public void testToken_notEqualDifferentCount() {
        final DurationFormatUtils.Token[] a = DurationFormatUtils.lexx("y");
        final DurationFormatUtils.Token[] b = DurationFormatUtils.lexx("yy");
        assertFalse(a[0].equals(b[0]));
    }

    @Test
    public void testToken_containsTokenWithValue() {
        final DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("yMd");
        assertTrue(DurationFormatUtils.Token.containsTokenWithValue(tokens, DurationFormatUtils.y));
        assertFalse(DurationFormatUtils.Token.containsTokenWithValue(tokens, DurationFormatUtils.H));
    }

    // constructor / constants -------------------------------------------

    @Test
    public void testConstructorIsPublic() {
        assertNotNull(new DurationFormatUtils());
    }

    @Test
    public void testIsoExtendedFormatPatternConstant() {
        assertEquals("'P'yyyy'Y'M'M'd'DT'H'H'm'M's.SSS'S'", DurationFormatUtils.ISO_EXTENDED_FORMAT_PATTERN);
    }
}
