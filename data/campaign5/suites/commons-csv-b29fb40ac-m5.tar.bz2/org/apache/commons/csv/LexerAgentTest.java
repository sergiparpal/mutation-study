/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link Lexer}.
 */
class LexerAgentTest {

    private static Lexer createLexer(final CSVFormat format, final String input) {
        return new Lexer(format, new ExtendedBufferedReader(new StringReader(input)));
    }

    @Test
    void testSimpleTokensAndEof() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a,b,c\n");
        Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a", token.content.toString());
        assertFalse(token.isQuoted);

        token.reset();
        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("b", token.content.toString());

        token.reset();
        lexer.nextToken(token);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("c", token.content.toString());

        token.reset();
        lexer.nextToken(token);
        assertEquals(Token.Type.EOF, token.type);
        assertFalse(token.isReady);
        assertEquals("", token.content.toString());
    }

    @Test
    void testEofWithoutTrailingNewlineKeepsLastTokenReady() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a,b");
        Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a", token.content.toString());

        token.reset();
        lexer.nextToken(token);
        assertEquals(Token.Type.EOF, token.type);
        assertTrue(token.isReady);
        assertEquals("b", token.content.toString());
    }

    @Test
    void testQuotedToken() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "\"hello, world\",b\n");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("hello, world", token.content.toString());
        assertTrue(token.isQuoted);
    }

    @Test
    void testQuotedTokenWithDoubledQuote() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "\"a\"\"b\"\n");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("a\"b", token.content.toString());
    }

    @Test
    void testEscapedDelimiterInSimpleToken() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer(format, "a\\,b,c\n");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a,b", token.content.toString());

        token.reset();
        lexer.nextToken(token);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("c", token.content.toString());
    }

    @Test
    void testEscapedMultiCharDelimiterInSimpleToken() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").setEscape('\\').get();
        final Lexer lexer = createLexer(format, "a\\:\\:b::c\n");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a::b", token.content.toString());

        token.reset();
        lexer.nextToken(token);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("c", token.content.toString());
    }

    @Test
    void testReadEscapeControlCharacters() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();

        assertEquals(Constants.CR, createLexer(format, "r").readEscape());
        assertEquals(Constants.LF, createLexer(format, "n").readEscape());
        assertEquals(Constants.TAB, createLexer(format, "t").readEscape());
        assertEquals(Constants.BACKSPACE, createLexer(format, "b").readEscape());
        assertEquals(Constants.FF, createLexer(format, "f").readEscape());
        assertEquals(Constants.CR, createLexer(format, "\r").readEscape());
        assertEquals(Constants.LF, createLexer(format, "\n").readEscape());
    }

    @Test
    void testReadEscapeMetaCharacterReturnsCharacter() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        // '"' is the quote character and thus a recognized meta character.
        assertEquals('"', createLexer(format, "\"").readEscape());
    }

    @Test
    void testReadEscapeUnexpectedCharacterReturnsEof() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer(format, "q");
        assertEquals(-1, lexer.readEscape());
    }

    @Test
    void testReadEscapeAtEofThrows() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer(format, "");
        final CSVException e = assertThrows(CSVException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                lexer.readEscape();
            }
        });
        assertTrue(e.getMessage().contains("EOF"));
    }

    @Test
    void testUnterminatedQuoteThrowsByDefault() {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "\"abc");
        final Token token = new Token();
        final CSVException e = assertThrows(CSVException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                lexer.nextToken(token);
            }
        });
        assertTrue(e.getMessage().contains("EOF reached before encapsulated token finished"));
    }

    @Test
    void testUnterminatedQuoteWithLenientEofReturnsEofToken() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setLenientEof(true).get();
        final Lexer lexer = createLexer(format, "\"abc");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.EOF, token.type);
        assertTrue(token.isReady);
        assertEquals("abc", token.content.toString());
    }

    @Test
    void testInvalidCharAfterEncapsulatedTokenThrowsByDefault() {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "\"abc\"xyz,d\n");
        final Token token = new Token();
        final CSVException e = assertThrows(CSVException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                lexer.nextToken(token);
            }
        });
        assertTrue(e.getMessage().contains("Invalid character between encapsulated token and delimiter"));
    }

    @Test
    void testTrailingDataAllowsCharsAfterEncapsulatedToken() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingData(true).get();
        final Lexer lexer = createLexer(format, "\"abc\"xyz,d\n");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("abcxyz", token.content.toString());
    }

    @Test
    void testWhitespaceAfterEncapsulatedTokenIsIgnored() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "\"abc\"   ,d\n");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("abc", token.content.toString());
    }

    @Test
    void testCommentLine() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final Lexer lexer = createLexer(format, "a,b\n#a comment\nc,d\n");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a", token.content.toString());

        token.reset();
        lexer.nextToken(token);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("b", token.content.toString());

        token.reset();
        lexer.nextToken(token);
        assertEquals(Token.Type.COMMENT, token.type);
        assertEquals("a comment", token.content.toString());

        token.reset();
        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("c", token.content.toString());
    }

    @Test
    void testCommentLineAtEofReturnsEof() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final Lexer lexer = createLexer(format, "a\n#");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.EORECORD, token.type);

        token.reset();
        lexer.nextToken(token);
        assertEquals(Token.Type.EOF, token.type);
    }

    @Test
    void testIgnoreEmptyLinesSkipsBlankLines() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "\n\na,b\n");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a", token.content.toString());
    }

    @Test
    void testIgnoreEmptyLinesAtEndOfFileReturnsEof() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a,b\n\n");
        final Token token = new Token();
        lexer.nextToken(token);
        token.reset();
        lexer.nextToken(token);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("b", token.content.toString());

        token.reset();
        lexer.nextToken(token);
        assertEquals(Token.Type.EOF, token.type);
        assertFalse(token.isReady);
    }

    @Test
    void testDoNotIgnoreEmptyLinesPreservesBlankRecord() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreEmptyLines(false).get();
        final Lexer lexer = createLexer(format, "\na,b\n");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("", token.content.toString());
    }

    @Test
    void testIgnoreSurroundingSpaces() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreSurroundingSpaces(true).get();
        final Lexer lexer = createLexer(format, "  a  ,  b  \n");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a", token.content.toString());

        token.reset();
        lexer.nextToken(token);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("b", token.content.toString());
    }

    @Test
    void testIsDelimiterSingleChar() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, ",x");
        assertTrue(lexer.isDelimiter(','));
        assertFalse(lexer.isDelimiter('x'));
    }

    @Test
    void testIsDelimiterMultiCharMatchAndMismatch() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        final Lexer matching = createLexer(format, "::rest");
        assertTrue(matching.isDelimiter(':'));

        // The first delimiter char is passed in directly; only the remainder is read from the stream.
        final Lexer mismatching = createLexer(format, "x");
        assertFalse(mismatching.isDelimiter(':'));
    }

    @Test
    void testIsEscapeDelimiterMultiChar() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").setEscape('\\').get();
        // After the leading escape char is consumed by the caller, the remainder is ":\\:" .
        final Lexer lexer = createLexer(format, ":\\:rest");
        assertTrue(lexer.isEscapeDelimiter());

        final Lexer mismatching = createLexer(format, ":xrest");
        assertFalse(mismatching.isEscapeDelimiter());
    }

    @Test
    void testIsEndOfFile() {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a");
        assertTrue(lexer.isEndOfFile(-1));
        assertFalse(lexer.isEndOfFile('a'));
        assertFalse(lexer.isEndOfFile(0));
    }

    @Test
    void testIsStartOfLine() {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a");
        assertTrue(lexer.isStartOfLine(Constants.LF));
        assertTrue(lexer.isStartOfLine(Constants.CR));
        assertTrue(lexer.isStartOfLine(Constants.UNDEFINED));
        assertFalse(lexer.isStartOfLine('a'));
    }

    @Test
    void testIsQuoteCharAndIsCommentStartDisabledByDefault() {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a");
        assertTrue(lexer.isQuoteChar('"'));
        assertFalse(lexer.isQuoteChar('\''));
        // No comment marker configured for CSVFormat.DEFAULT.
        assertFalse(lexer.isCommentStart('#'));
    }

    @Test
    void testIsCommentStartWhenConfigured() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final Lexer lexer = createLexer(format, "a");
        assertTrue(lexer.isCommentStart('#'));
        assertFalse(lexer.isCommentStart('!'));
    }

    @Test
    void testIsEscapeDisabledByDefault() {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a");
        assertFalse(lexer.isEscape('\\'));
    }

    @Test
    void testReadEndOfLineLfAndCrAndCrLf() throws IOException {
        final Lexer lfLexer = createLexer(CSVFormat.DEFAULT, "a");
        assertTrue(lfLexer.readEndOfLine(Constants.LF));
        assertEquals("\n", lfLexer.getFirstEol());

        final Lexer crLexer = createLexer(CSVFormat.DEFAULT, "a");
        assertTrue(crLexer.readEndOfLine(Constants.CR));
        assertEquals("\r", crLexer.getFirstEol());

        // A CR followed by LF in the stream is swallowed as a single CRLF EOL.
        final Lexer crlfLexer = createLexer(CSVFormat.DEFAULT, "\nrest");
        assertTrue(crlfLexer.readEndOfLine(Constants.CR));
        assertEquals("\r\n", crlfLexer.getFirstEol());

        final Lexer notEol = createLexer(CSVFormat.DEFAULT, "a");
        assertFalse(notEol.readEndOfLine('x'));
    }

    @Test
    void testGetFirstEolIsNullBeforeAnyEol() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a,b");
        assertNull(lexer.getFirstEol());
        final Token token = new Token();
        lexer.nextToken(token);
        assertNull(lexer.getFirstEol());
    }

    @Test
    void testPositionsAndLineNumberAdvance() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a,b\nc,d\n");
        assertEquals(0, lexer.getCharacterPosition());
        assertEquals(0, lexer.getCurrentLineNumber());

        final Token token = new Token();
        lexer.nextToken(token); // "a"
        token.reset();
        lexer.nextToken(token); // EORECORD "b"
        assertTrue(lexer.getCharacterPosition() > 0);
        assertEquals(1, lexer.getCurrentLineNumber());

        token.reset();
        lexer.nextToken(token); // "c" on line 2
        assertEquals(2, lexer.getCurrentLineNumber());
    }

    @Test
    void testGetBytesReadWithoutByteTrackingIsZero() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a,b\n");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(0, lexer.getBytesRead());
    }

    @Test
    void testCloseAndIsClosed() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a,b\n");
        assertFalse(lexer.isClosed());
        lexer.close();
        assertTrue(lexer.isClosed());
    }

    @Test
    void testTrimTrailingSpaces() {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a");

        final StringBuilder withTrailingSpaces = new StringBuilder("abc   ");
        lexer.trimTrailingSpaces(withTrailingSpaces);
        assertEquals("abc", withTrailingSpaces.toString());

        final StringBuilder allSpaces = new StringBuilder("   ");
        lexer.trimTrailingSpaces(allSpaces);
        assertEquals("", allSpaces.toString());

        final StringBuilder noTrailingSpaces = new StringBuilder("abc");
        lexer.trimTrailingSpaces(noTrailingSpaces);
        assertEquals("abc", noTrailingSpaces.toString());

        final StringBuilder empty = new StringBuilder("");
        lexer.trimTrailingSpaces(empty);
        assertEquals("", empty.toString());
    }
}
