/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.CharBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link StrBuilder}.
 */
public class StrBuilderAgentTest {

    @Test
    public void testDefaultConstructor() {
        final StrBuilder sb = new StrBuilder();
        assertEquals(0, sb.length());
        assertEquals(32, sb.capacity());
        assertEquals("", sb.toString());
    }

    @Test
    public void testCapacityConstructor() {
        final StrBuilder sb = new StrBuilder(10);
        assertEquals(10, sb.capacity());
        assertEquals(0, sb.length());
    }

    @Test
    public void testCapacityConstructorNonPositiveDefaultsTo32() {
        assertEquals(32, new StrBuilder(0).capacity());
        assertEquals(32, new StrBuilder(-5).capacity());
    }

    @Test
    public void testStringConstructor() {
        final StrBuilder sb = new StrBuilder("abc");
        assertEquals("abc", sb.toString());
        assertEquals(3, sb.length());
        assertTrue(sb.capacity() >= 3);
    }

    @Test
    public void testStringConstructorNull() {
        final StrBuilder sb = new StrBuilder((String) null);
        assertEquals("", sb.toString());
        assertEquals(0, sb.length());
    }

    @Test
    public void testAppendBoolean() {
        final StrBuilder sb = new StrBuilder();
        sb.append(true);
        assertEquals("true", sb.toString());
        sb.clear();
        sb.append(false);
        assertEquals("false", sb.toString());
    }

    @Test
    public void testAppendChar() {
        final StrBuilder sb = new StrBuilder();
        final StrBuilder result = sb.append('x');
        assertSame(sb, result);
        assertEquals("x", sb.toString());
    }

    @Test
    public void testAppendCharArray() {
        final StrBuilder sb = new StrBuilder();
        sb.append(new char[] {'a', 'b', 'c'});
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendCharArrayNull() {
        final StrBuilder sb = new StrBuilder();
        sb.append((char[]) null);
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendCharArrayNullUsesNullText() {
        final StrBuilder sb = new StrBuilder();
        sb.setNullText("NULL");
        sb.append((char[]) null);
        assertEquals("NULL", sb.toString());
    }

    @Test
    public void testAppendCharArrayEmpty() {
        final StrBuilder sb = new StrBuilder();
        sb.append(new char[0]);
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendCharArrayRange() {
        final StrBuilder sb = new StrBuilder();
        sb.append(new char[] {'a', 'b', 'c', 'd', 'e'}, 1, 3);
        assertEquals("bcd", sb.toString());
    }

    @Test
    public void testAppendCharArrayRangeInvalidStartIndex() {
        final StrBuilder sb = new StrBuilder();
        final char[] chars = {'a', 'b', 'c'};
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append(chars, -1, 1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append(chars, 4, 1));
    }

    @Test
    public void testAppendCharArrayRangeInvalidLength() {
        final StrBuilder sb = new StrBuilder();
        final char[] chars = {'a', 'b', 'c'};
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append(chars, 0, -1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append(chars, 1, 5));
    }

    @Test
    public void testAppendCharBuffer() {
        final StrBuilder sb = new StrBuilder();
        sb.append(CharBuffer.wrap("hello".toCharArray()));
        assertEquals("hello", sb.toString());
    }

    @Test
    public void testAppendCharBufferNull() {
        final StrBuilder sb = new StrBuilder();
        sb.append((CharBuffer) null);
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendCharBufferRange() {
        final StrBuilder sb = new StrBuilder();
        sb.append(CharBuffer.wrap("hello".toCharArray()), 1, 3);
        assertEquals("ell", sb.toString());
    }

    @Test
    public void testAppendCharBufferRangeInvalid() {
        final StrBuilder sb = new StrBuilder();
        final CharBuffer buf = CharBuffer.wrap("hello".toCharArray());
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append(buf, -1, 1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append(buf, 0, 100));
    }

    @Test
    public void testAppendCharSequence() {
        final StrBuilder sb = new StrBuilder();
        sb.append((CharSequence) "abc");
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendCharSequenceNull() {
        final StrBuilder sb = new StrBuilder();
        sb.append((CharSequence) null);
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendCharSequenceOtherStrBuilder() {
        final StrBuilder sb = new StrBuilder();
        final StrBuilder other = new StrBuilder("xyz");
        sb.append((CharSequence) other);
        assertEquals("xyz", sb.toString());
    }

    @Test
    public void testAppendCharSequenceStringBuilder() {
        final StrBuilder sb = new StrBuilder();
        sb.append((CharSequence) new StringBuilder("abc"));
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendCharSequenceStringBuffer() {
        final StrBuilder sb = new StrBuilder();
        sb.append((CharSequence) new StringBuffer("abc"));
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendCharSequenceRange() {
        final StrBuilder sb = new StrBuilder();
        sb.append((CharSequence) "abcdef", 1, 3);
        assertEquals("bcd", sb.toString());
    }

    @Test
    public void testAppendCharSequenceRangeNull() {
        final StrBuilder sb = new StrBuilder();
        sb.append((CharSequence) null, 0, 0);
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendDoubleFloatIntLong() {
        final StrBuilder sb = new StrBuilder();
        sb.append(1.5d).append(' ').append(2.5f).append(' ').append(3).append(' ').append(4L);
        assertEquals("1.5 2.5 3 4", sb.toString());
    }

    @Test
    public void testAppendObject() {
        final StrBuilder sb = new StrBuilder();
        sb.append((Object) Integer.valueOf(42));
        assertEquals("42", sb.toString());
    }

    @Test
    public void testAppendObjectNull() {
        final StrBuilder sb = new StrBuilder();
        sb.append((Object) null);
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendObjectCharSequence() {
        final StrBuilder sb = new StrBuilder();
        sb.append((Object) "hi");
        assertEquals("hi", sb.toString());
    }

    @Test
    public void testAppendStrBuilder() {
        final StrBuilder sb = new StrBuilder("a");
        final StrBuilder other = new StrBuilder("bc");
        sb.append(other);
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendStrBuilderNull() {
        final StrBuilder sb = new StrBuilder("a");
        sb.append((StrBuilder) null);
        assertEquals("a", sb.toString());
    }

    @Test
    public void testAppendStrBuilderRange() {
        final StrBuilder sb = new StrBuilder();
        final StrBuilder other = new StrBuilder("abcdef");
        sb.append(other, 1, 3);
        assertEquals("bcd", sb.toString());
    }

    @Test
    public void testAppendStrBuilderRangeInvalid() {
        final StrBuilder sb = new StrBuilder();
        final StrBuilder other = new StrBuilder("abc");
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append(other, -1, 1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append(other, 0, 10));
    }

    @Test
    public void testAppendString() {
        final StrBuilder sb = new StrBuilder();
        sb.append("hello");
        assertEquals("hello", sb.toString());
    }

    @Test
    public void testAppendStringNull() {
        final StrBuilder sb = new StrBuilder();
        sb.append((String) null);
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendStringRange() {
        final StrBuilder sb = new StrBuilder();
        sb.append("abcdef", 1, 3);
        assertEquals("bcd", sb.toString());
    }

    @Test
    public void testAppendStringRangeInvalid() {
        final StrBuilder sb = new StrBuilder();
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append("abc", -1, 1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append("abc", 0, 10));
    }

    @Test
    public void testAppendFormatted() {
        final StrBuilder sb = new StrBuilder();
        sb.append("%s-%d", "a", 1);
        assertEquals("a-1", sb.toString());
    }

    @Test
    public void testAppendStringBuffer() {
        final StrBuilder sb = new StrBuilder();
        sb.append(new StringBuffer("abc"));
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendStringBufferNull() {
        final StrBuilder sb = new StrBuilder();
        sb.append((StringBuffer) null);
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendStringBufferRange() {
        final StrBuilder sb = new StrBuilder();
        sb.append(new StringBuffer("abcdef"), 1, 3);
        assertEquals("bcd", sb.toString());
    }

    @Test
    public void testAppendStringBuilderArg() {
        final StrBuilder sb = new StrBuilder();
        sb.append(new StringBuilder("abc"));
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendStringBuilderArgNull() {
        final StrBuilder sb = new StrBuilder();
        sb.append((StringBuilder) null);
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendStringBuilderArgRange() {
        final StrBuilder sb = new StrBuilder();
        sb.append(new StringBuilder("abcdef"), 1, 3);
        assertEquals("bcd", sb.toString());
    }

    @Test
    public void testAppendAllIterable() {
        final StrBuilder sb = new StrBuilder();
        final List<String> list = Arrays.asList("a", "b", "c");
        sb.appendAll((Iterable<?>) list);
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendAllIterableNull() {
        final StrBuilder sb = new StrBuilder();
        sb.appendAll((Iterable<?>) null);
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendAllIterator() {
        final StrBuilder sb = new StrBuilder();
        final List<String> list = Arrays.asList("a", "b", "c");
        sb.appendAll(list.iterator());
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendAllIteratorNull() {
        final StrBuilder sb = new StrBuilder();
        sb.appendAll((java.util.Iterator<?>) null);
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendAllArray() {
        final StrBuilder sb = new StrBuilder();
        sb.appendAll("a", "b", "c");
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadLeftInt() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft(1, 5, '0');
        assertEquals("00001", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadLeftObjectTruncates() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft("abcdef", 3, ' ');
        assertEquals("def", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadLeftZeroWidthNoOp() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft("abc", 0, ' ');
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadLeftNullObjectUsesNullText() {
        final StrBuilder sb = new StrBuilder();
        sb.setNullText("NULL");
        sb.appendFixedWidthPadLeft(null, 6, ' ');
        assertEquals("  NULL", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadRightInt() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadRight(1, 5, '0');
        assertEquals("10000", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadRightObjectTruncates() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadRight("abcdef", 3, ' ');
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadRightZeroWidthNoOp() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadRight("abc", -1, ' ');
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendlnVariants() {
        final StrBuilder sb = new StrBuilder();
        sb.setNewLineText("\n");
        sb.appendln(1);
        assertEquals("1\n", sb.toString());
        sb.clear();
        sb.appendln(true);
        assertEquals("true\n", sb.toString());
        sb.clear();
        sb.appendln('x');
        assertEquals("x\n", sb.toString());
        sb.clear();
        sb.appendln(1.5d);
        assertEquals("1.5\n", sb.toString());
        sb.clear();
        sb.appendln(1.5f);
        assertEquals("1.5\n", sb.toString());
        sb.clear();
        sb.appendln(1L);
        assertEquals("1\n", sb.toString());
        sb.clear();
        sb.appendln("hi");
        assertEquals("hi\n", sb.toString());
        sb.clear();
        sb.appendln((Object) "obj");
        assertEquals("obj\n", sb.toString());
    }

    @Test
    public void testAppendNewLineDefaultsToSystemLineSeparator() {
        final StrBuilder sb = new StrBuilder();
        sb.appendNewLine();
        assertEquals(System.lineSeparator(), sb.toString());
    }

    @Test
    public void testAppendNewLineCustom() {
        final StrBuilder sb = new StrBuilder();
        sb.setNewLineText("<br>");
        sb.appendNewLine();
        assertEquals("<br>", sb.toString());
        assertEquals("<br>", sb.getNewLineText());
    }

    @Test
    public void testAppendNullDefaultNoOp() {
        final StrBuilder sb = new StrBuilder();
        sb.appendNull();
        assertEquals("", sb.toString());
        assertNull(sb.getNullText());
    }

    @Test
    public void testAppendNullCustomText() {
        final StrBuilder sb = new StrBuilder();
        sb.setNullText("NULL");
        sb.appendNull();
        assertEquals("NULL", sb.toString());
    }

    @Test
    public void testAppendPadding() {
        final StrBuilder sb = new StrBuilder();
        sb.appendPadding(3, '*');
        assertEquals("***", sb.toString());
    }

    @Test
    public void testAppendPaddingNegativeNoOp() {
        final StrBuilder sb = new StrBuilder();
        sb.appendPadding(-1, '*');
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendSeparatorChar() {
        final StrBuilder sb = new StrBuilder();
        sb.appendSeparator(',');
        assertEquals("", sb.toString());
        sb.append('a');
        sb.appendSeparator(',');
        sb.append('b');
        assertEquals("a,b", sb.toString());
    }

    @Test
    public void testAppendSeparatorCharStandardOrDefault() {
        final StrBuilder sb = new StrBuilder();
        sb.appendSeparator(',', ';');
        assertEquals(";", sb.toString());
        sb.append('a');
        sb.appendSeparator(',', ';');
        assertEquals(";a,", sb.toString());
    }

    @Test
    public void testAppendSeparatorCharLoopIndex() {
        final StrBuilder sb = new StrBuilder();
        for (int i = 0; i < 3; i++) {
            sb.appendSeparator(',', i);
            sb.append(i);
        }
        assertEquals("0,1,2", sb.toString());
    }

    @Test
    public void testAppendSeparatorStringNull() {
        final StrBuilder sb = new StrBuilder();
        sb.append('a');
        sb.appendSeparator((String) null);
        sb.append('b');
        assertEquals("ab", sb.toString());
    }

    @Test
    public void testAppendSeparatorStringLoopIndex() {
        final StrBuilder sb = new StrBuilder();
        for (int i = 0; i < 3; i++) {
            sb.appendSeparator("-", i);
            sb.append(i);
        }
        assertEquals("0-1-2", sb.toString());
    }

    @Test
    public void testAppendSeparatorStringStandardOrDefault() {
        final StrBuilder sb = new StrBuilder();
        sb.appendSeparator(" and", " where");
        assertEquals(" where", sb.toString());
        sb.append("x=1");
        sb.appendSeparator(" and", " where");
        assertEquals(" wherex=1 and", sb.toString());
    }

    @Test
    public void testAppendSeparatorStringStandardOrDefaultBothNull() {
        final StrBuilder sb = new StrBuilder();
        sb.appendSeparator(null, null);
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendToWriter() throws IOException {
        final StrBuilder sb = new StrBuilder("hello");
        final StringWriter writer = new StringWriter();
        sb.appendTo(writer);
        assertEquals("hello", writer.getContents());
    }

    @Test
    public void testAppendToStringBuilder() throws IOException {
        final StrBuilder sb = new StrBuilder("hello");
        final StringBuilder dest = new StringBuilder();
        sb.appendTo(dest);
        assertEquals("hello", dest.toString());
    }

    @Test
    public void testAppendToStringBuffer() throws IOException {
        final StrBuilder sb = new StrBuilder("hello");
        final StringBuffer dest = new StringBuffer();
        sb.appendTo(dest);
        assertEquals("hello", dest.toString());
    }

    @Test
    public void testAppendToCharBuffer() throws IOException {
        final StrBuilder sb = new StrBuilder("hello");
        final CharBuffer dest = CharBuffer.allocate(10);
        sb.appendTo(dest);
        dest.flip();
        assertEquals("hello", dest.toString());
    }

    @Test
    public void testAppendWithSeparatorsIterable() {
        final StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators(Arrays.asList("a", "b", "c"), ",");
        assertEquals("a,b,c", sb.toString());
    }

    @Test
    public void testAppendWithSeparatorsIterableNullSeparator() {
        final StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators(Arrays.asList("a", "b"), null);
        assertEquals("ab", sb.toString());
    }

    @Test
    public void testAppendWithSeparatorsIterableNull() {
        final StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators((Iterable<?>) null, ",");
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendWithSeparatorsIterator() {
        final StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators(Arrays.asList("a", "b", "c").iterator(), ",");
        assertEquals("a,b,c", sb.toString());
    }

    @Test
    public void testAppendWithSeparatorsArray() {
        final StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators(new Object[] {"a", "b", "c"}, ",");
        assertEquals("a,b,c", sb.toString());
    }

    @Test
    public void testAppendWithSeparatorsArrayNull() {
        final StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators((Object[]) null, ",");
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendWithSeparatorsArrayEmpty() {
        final StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators(new Object[0], ",");
        assertEquals("", sb.toString());
    }

    @Test
    public void testAsReader() throws IOException {
        final StrBuilder sb = new StrBuilder("hello");
        final Reader reader = sb.asReader();
        assertNotNull(reader);
        final char[] buf = new char[5];
        final int n = reader.read(buf, 0, 5);
        assertEquals(5, n);
        assertEquals("hello", new String(buf));
        assertEquals(-1, reader.read());
    }

    @Test
    public void testAsReaderMarkReset() throws IOException {
        final StrBuilder sb = new StrBuilder("abc");
        final Reader reader = sb.asReader();
        assertTrue(reader.markSupported());
        assertEquals('a', (char) reader.read());
        reader.mark(0);
        assertEquals('b', (char) reader.read());
        reader.reset();
        assertEquals('b', (char) reader.read());
        reader.close();
    }

    @Test
    public void testAsReaderSkip() throws IOException {
        final StrBuilder sb = new StrBuilder("abcdef");
        final Reader reader = sb.asReader();
        final long skipped = reader.skip(3);
        assertEquals(3, skipped);
        assertEquals('d', (char) reader.read());
    }

    @Test
    public void testAsTokenizer() {
        final StrBuilder sb = new StrBuilder("a b c");
        final StrTokenizer tokenizer = sb.asTokenizer();
        assertNotNull(tokenizer);
        final String[] tokens = tokenizer.getTokenArray();
        assertArrayEquals(new String[] {"a", "b", "c"}, tokens);
    }

    @Test
    public void testAsWriter() throws IOException {
        final StrBuilder sb = new StrBuilder();
        final Writer writer = sb.asWriter();
        writer.write("hello");
        writer.write(' ');
        writer.write(new char[] {'w', 'o', 'r', 'l', 'd'});
        assertEquals("hello world", sb.toString());
    }

    @Test
    public void testBuild() {
        final StrBuilder sb = new StrBuilder("abc");
        assertEquals("abc", sb.build());
    }

    @Test
    public void testCapacity() {
        final StrBuilder sb = new StrBuilder(5);
        assertEquals(5, sb.capacity());
        sb.append("123456");
        assertTrue(sb.capacity() >= 6);
    }

    @Test
    public void testCharAt() {
        final StrBuilder sb = new StrBuilder("abc");
        assertEquals('a', sb.charAt(0));
        assertEquals('c', sb.charAt(2));
    }

    @Test
    public void testCharAtInvalid() {
        final StrBuilder sb = new StrBuilder("abc");
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.charAt(-1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.charAt(3));
    }

    @Test
    public void testClear() {
        final StrBuilder sb = new StrBuilder("abc");
        final StrBuilder result = sb.clear();
        assertSame(sb, result);
        assertEquals(0, sb.length());
        assertEquals("", sb.toString());
    }

    @Test
    public void testContainsChar() {
        final StrBuilder sb = new StrBuilder("abc");
        assertTrue(sb.contains('b'));
        assertFalse(sb.contains('z'));
    }

    @Test
    public void testContainsString() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertTrue(sb.contains("cde"));
        assertFalse(sb.contains("xyz"));
    }

    @Test
    public void testContainsMatcher() {
        final StrBuilder sb = new StrBuilder("abc123");
        assertTrue(sb.contains(StrMatcher.charSetMatcher("0123456789")));
        assertFalse(sb.contains((StrMatcher) null));
    }

    @Test
    public void testDelete() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.delete(1, 3);
        assertEquals("adef", sb.toString());
    }

    @Test
    public void testDeleteEndIndexBeyondSizeTreatedAsEnd() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.delete(2, 100);
        assertEquals("ab", sb.toString());
    }

    @Test
    public void testDeleteInvalidStartIndex() {
        final StrBuilder sb = new StrBuilder("abc");
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.delete(-1, 2));
    }

    @Test
    public void testDeleteInvalidRange() {
        final StrBuilder sb = new StrBuilder("abc");
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.delete(2, 1));
    }

    @Test
    public void testDeleteAllChar() {
        final StrBuilder sb = new StrBuilder("abcabc");
        sb.deleteAll('a');
        assertEquals("bcbc", sb.toString());
    }

    @Test
    public void testDeleteAllString() {
        final StrBuilder sb = new StrBuilder("abcabcabc");
        sb.deleteAll("bc");
        assertEquals("aaa", sb.toString());
    }

    @Test
    public void testDeleteAllStringNull() {
        final StrBuilder sb = new StrBuilder("abc");
        sb.deleteAll((String) null);
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testDeleteAllMatcher() {
        final StrBuilder sb = new StrBuilder("a1b2c3");
        sb.deleteAll(StrMatcher.charSetMatcher("0123456789"));
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testDeleteCharAt() {
        final StrBuilder sb = new StrBuilder("abc");
        sb.deleteCharAt(1);
        assertEquals("ac", sb.toString());
    }

    @Test
    public void testDeleteCharAtInvalid() {
        final StrBuilder sb = new StrBuilder("abc");
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.deleteCharAt(-1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.deleteCharAt(3));
    }

    @Test
    public void testDeleteFirstChar() {
        final StrBuilder sb = new StrBuilder("abcabc");
        sb.deleteFirst('a');
        assertEquals("bcabc", sb.toString());
    }

    @Test
    public void testDeleteFirstString() {
        final StrBuilder sb = new StrBuilder("abcabc");
        sb.deleteFirst("bc");
        assertEquals("aabc", sb.toString());
    }

    @Test
    public void testDeleteFirstMatcher() {
        final StrBuilder sb = new StrBuilder("a1b2");
        sb.deleteFirst(StrMatcher.charSetMatcher("0123456789"));
        assertEquals("ab2", sb.toString());
    }

    @Test
    public void testEndsWith() {
        final StrBuilder sb = new StrBuilder("hello world");
        assertTrue(sb.endsWith("world"));
        assertFalse(sb.endsWith("hello"));
        assertFalse(sb.endsWith(null));
        assertTrue(sb.endsWith(""));
        assertFalse(sb.endsWith("this is way too long"));
    }

    @Test
    public void testEnsureCapacity() {
        final StrBuilder sb = new StrBuilder(5);
        sb.ensureCapacity(100);
        assertTrue(sb.capacity() >= 100);
    }

    @Test
    public void testEnsureCapacityNoShrink() {
        final StrBuilder sb = new StrBuilder(100);
        sb.ensureCapacity(5);
        assertEquals(100, sb.capacity());
    }

    @Test
    public void testEqualsObject() {
        final StrBuilder sb1 = new StrBuilder("abc");
        final StrBuilder sb2 = new StrBuilder("abc");
        final StrBuilder sb3 = new StrBuilder("abd");
        assertTrue(sb1.equals((Object) sb2));
        assertFalse(sb1.equals((Object) sb3));
        assertFalse(sb1.equals("abc"));
        assertFalse(sb1.equals(null));
    }

    @Test
    public void testEqualsStrBuilder() {
        final StrBuilder sb1 = new StrBuilder("abc");
        final StrBuilder sb2 = new StrBuilder("abc");
        assertTrue(sb1.equals(sb1));
        assertTrue(sb1.equals(sb2));
        assertFalse(sb1.equals((StrBuilder) null));
        final StrBuilder sb3 = new StrBuilder("ab");
        assertFalse(sb1.equals(sb3));
    }

    @Test
    public void testEqualsIgnoreCase() {
        final StrBuilder sb1 = new StrBuilder("ABC");
        final StrBuilder sb2 = new StrBuilder("abc");
        assertTrue(sb1.equalsIgnoreCase(sb2));
        assertTrue(sb1.equalsIgnoreCase(sb1));
        final StrBuilder sb3 = new StrBuilder("abcd");
        assertFalse(sb1.equalsIgnoreCase(sb3));
    }

    @Test
    public void testHashCodeConsistentWithEquals() {
        final StrBuilder sb1 = new StrBuilder("abc");
        final StrBuilder sb2 = new StrBuilder("abc");
        assertEquals(sb1.hashCode(), sb2.hashCode());
    }

    @Test
    public void testGetCharsNoArgs() {
        final StrBuilder sb = new StrBuilder("abc");
        final char[] result = sb.getChars((char[]) null);
        assertArrayEquals(new char[] {'a', 'b', 'c'}, result);
    }

    @Test
    public void testGetCharsDestinationTooSmallAllocatesNew() {
        final StrBuilder sb = new StrBuilder("abc");
        final char[] small = new char[1];
        final char[] result = sb.getChars(small);
        assertEquals(3, result.length);
        assertArrayEquals(new char[] {'a', 'b', 'c'}, result);
    }

    @Test
    public void testGetCharsRange() {
        final StrBuilder sb = new StrBuilder("abcdef");
        final char[] dest = new char[6];
        sb.getChars(1, 4, dest, 0);
        assertEquals('b', dest[0]);
        assertEquals('c', dest[1]);
        assertEquals('d', dest[2]);
    }

    @Test
    public void testGetCharsRangeInvalid() {
        final StrBuilder sb = new StrBuilder("abc");
        final char[] dest = new char[3];
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.getChars(-1, 2, dest, 0));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.getChars(0, 10, dest, 0));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.getChars(2, 1, dest, 0));
    }

    @Test
    public void testGetSetNewLineText() {
        final StrBuilder sb = new StrBuilder();
        assertNull(sb.getNewLineText());
        sb.setNewLineText("X");
        assertEquals("X", sb.getNewLineText());
        sb.setNewLineText(null);
        assertNull(sb.getNewLineText());
    }

    @Test
    public void testGetSetNullText() {
        final StrBuilder sb = new StrBuilder();
        assertNull(sb.getNullText());
        sb.setNullText("NULL");
        assertEquals("NULL", sb.getNullText());
        sb.setNullText("");
        assertNull(sb.getNullText());
        sb.setNullText(null);
        assertNull(sb.getNullText());
    }

    @Test
    public void testIndexOfChar() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(0, sb.indexOf('a'));
        assertEquals(-1, sb.indexOf('z'));
    }

    @Test
    public void testIndexOfCharWithStart() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(3, sb.indexOf('a', 1));
        assertEquals(-1, sb.indexOf('a', 100));
        assertEquals(0, sb.indexOf('a', -5));
    }

    @Test
    public void testIndexOfString() {
        final StrBuilder sb = new StrBuilder("abcdefabc");
        assertEquals(1, sb.indexOf("bcd"));
        assertEquals(-1, sb.indexOf((String) null));
        assertEquals(-1, sb.indexOf("zzz"));
    }

    @Test
    public void testIndexOfStringWithStart() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(3, sb.indexOf("abc", 1));
    }

    @Test
    public void testIndexOfMatcher() {
        final StrBuilder sb = new StrBuilder("ab1cd2");
        assertEquals(2, sb.indexOf(StrMatcher.charSetMatcher("0123456789")));
        assertEquals(-1, sb.indexOf((StrMatcher) null));
    }

    @Test
    public void testIndexOfMatcherWithStart() {
        final StrBuilder sb = new StrBuilder("ab1cd2");
        assertEquals(5, sb.indexOf(StrMatcher.charSetMatcher("0123456789"), 3));
        assertEquals(-1, sb.indexOf(StrMatcher.charSetMatcher("0123456789"), 100));
    }

    @Test
    public void testInsertBoolean() {
        final StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, true);
        assertEquals("atruec", sb.toString());
        sb.clear();
        sb.append("ac");
        sb.insert(1, false);
        assertEquals("afalsec", sb.toString());
    }

    @Test
    public void testInsertChar() {
        final StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, 'b');
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testInsertInvalidIndex() {
        final StrBuilder sb = new StrBuilder("abc");
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.insert(-1, 'x'));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.insert(4, 'x'));
    }

    @Test
    public void testInsertCharArray() {
        final StrBuilder sb = new StrBuilder("ad");
        sb.insert(1, new char[] {'b', 'c'});
        assertEquals("abcd", sb.toString());
    }

    @Test
    public void testInsertCharArrayNullUsesNullText() {
        final StrBuilder sb = new StrBuilder("ab");
        sb.setNullText("X");
        sb.insert(1, (char[]) null);
        assertEquals("aXb", sb.toString());
    }

    @Test
    public void testInsertCharArrayRange() {
        final StrBuilder sb = new StrBuilder("af");
        sb.insert(1, new char[] {'b', 'c', 'd', 'e'}, 1, 2);
        assertEquals("acdf", sb.toString());
    }

    @Test
    public void testInsertCharArrayRangeInvalid() {
        final StrBuilder sb = new StrBuilder("abc");
        final char[] chars = {'x', 'y'};
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.insert(0, chars, -1, 1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.insert(0, chars, 0, 10));
    }

    @Test
    public void testInsertDoubleFloatIntLong() {
        final StrBuilder sb = new StrBuilder();
        sb.insert(0, 1L);
        assertEquals("1", sb.toString());
        sb.clear();
        sb.insert(0, 1);
        assertEquals("1", sb.toString());
        sb.clear();
        sb.insert(0, 1.5f);
        assertEquals("1.5", sb.toString());
        sb.clear();
        sb.insert(0, 1.5d);
        assertEquals("1.5", sb.toString());
    }

    @Test
    public void testInsertObject() {
        final StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, Integer.valueOf(9));
        assertEquals("a9c", sb.toString());
    }

    @Test
    public void testInsertObjectNullUsesNullText() {
        final StrBuilder sb = new StrBuilder("ab");
        sb.setNullText("X");
        sb.insert(1, (Object) null);
        assertEquals("aXb", sb.toString());
    }

    @Test
    public void testInsertString() {
        final StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, "b");
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testInsertStringNullNoNullTextIsNoOp() {
        final StrBuilder sb = new StrBuilder("ab");
        sb.insert(1, (String) null);
        assertEquals("ab", sb.toString());
    }

    @Test
    public void testIsEmptyIsNotEmpty() {
        final StrBuilder sb = new StrBuilder();
        assertTrue(sb.isEmpty());
        assertFalse(sb.isNotEmpty());
        sb.append('a');
        assertFalse(sb.isEmpty());
        assertTrue(sb.isNotEmpty());
    }

    @Test
    public void testLastIndexOfChar() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(3, sb.lastIndexOf('a'));
        assertEquals(-1, sb.lastIndexOf('z'));
    }

    @Test
    public void testLastIndexOfCharWithStart() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(0, sb.lastIndexOf('a', 2));
        assertEquals(-1, sb.lastIndexOf('a', -1));
    }

    @Test
    public void testLastIndexOfString() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(3, sb.lastIndexOf("abc"));
        assertEquals(-1, sb.lastIndexOf((String) null));
    }

    @Test
    public void testLastIndexOfStringWithStart() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(0, sb.lastIndexOf("abc", 2));
    }

    @Test
    public void testLastIndexOfMatcher() {
        final StrBuilder sb = new StrBuilder("a1b2c3");
        assertEquals(5, sb.lastIndexOf(StrMatcher.charSetMatcher("0123456789")));
        assertEquals(-1, sb.lastIndexOf((StrMatcher) null));
    }

    @Test
    public void testLastIndexOfMatcherWithStart() {
        final StrBuilder sb = new StrBuilder("a1b2c3");
        assertEquals(3, sb.lastIndexOf(StrMatcher.charSetMatcher("0123456789"), 4));
    }

    @Test
    public void testLeftString() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("abc", sb.leftString(3));
        assertEquals("", sb.leftString(0));
        assertEquals("", sb.leftString(-1));
        assertEquals("abcdef", sb.leftString(100));
    }

    @Test
    public void testLength() {
        final StrBuilder sb = new StrBuilder("abcde");
        assertEquals(5, sb.length());
    }

    @Test
    public void testMidString() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("cde", sb.midString(2, 3));
        assertEquals("", sb.midString(2, -1));
        assertEquals("", sb.midString(100, 3));
        assertEquals("abc", sb.midString(-5, 3));
        assertEquals("def", sb.midString(3, 100));
    }

    @Test
    public void testMinimizeCapacity() {
        final StrBuilder sb = new StrBuilder(100);
        sb.append("abc");
        sb.minimizeCapacity();
        assertEquals(3, sb.capacity());
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testReadFromReader() throws IOException {
        final StrBuilder sb = new StrBuilder();
        final int read = sb.readFrom(new java.io.StringReader("hello"));
        assertEquals(5, read);
        assertEquals("hello", sb.toString());
    }

    @Test
    public void testReadFromCharBuffer() throws IOException {
        final StrBuilder sb = new StrBuilder();
        final CharBuffer buf = CharBuffer.wrap("hello");
        final int read = sb.readFrom(buf);
        assertEquals(5, read);
        assertEquals("hello", sb.toString());
    }

    @Test
    public void testReadFromGenericReadable() throws IOException {
        final StrBuilder sb = new StrBuilder();
        final Readable readable = new SimpleReadable("hello");
        final int read = sb.readFrom(readable);
        assertEquals(5, read);
        assertEquals("hello", sb.toString());
    }

    @Test
    public void testReplaceRange() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.replace(1, 3, "XYZ");
        assertEquals("aXYZdef", sb.toString());
    }

    @Test
    public void testReplaceRangeWithNullDeletes() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.replace(1, 3, null);
        assertEquals("adef", sb.toString());
    }

    @Test
    public void testReplaceRangeEndBeyondSize() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.replace(3, 100, "X");
        assertEquals("abcX", sb.toString());
    }

    @Test
    public void testReplaceWithMatcher() {
        final StrBuilder sb = new StrBuilder("a1b2c3");
        sb.replace(StrMatcher.charSetMatcher("0123456789"), "#", 0, 6, -1);
        assertEquals("a#b#c#", sb.toString());
    }

    @Test
    public void testReplaceWithMatcherInvalidStart() {
        final StrBuilder sb = new StrBuilder("abc");
        assertThrows(StringIndexOutOfBoundsException.class,
                () -> sb.replace(StrMatcher.charSetMatcher("0123456789"), "#", -1, 3, -1));
    }

    @Test
    public void testReplaceAllChar() {
        final StrBuilder sb = new StrBuilder("ababab");
        sb.replaceAll('a', 'x');
        assertEquals("xbxbxb", sb.toString());
    }

    @Test
    public void testReplaceAllCharSameNoOp() {
        final StrBuilder sb = new StrBuilder("aaa");
        sb.replaceAll('a', 'a');
        assertEquals("aaa", sb.toString());
    }

    @Test
    public void testReplaceAllString() {
        final StrBuilder sb = new StrBuilder("foobarfoobar");
        sb.replaceAll("foo", "X");
        assertEquals("XbarXbar", sb.toString());
    }

    @Test
    public void testReplaceAllStringNullReplaceDeletes() {
        final StrBuilder sb = new StrBuilder("foobarfoo");
        sb.replaceAll("foo", null);
        assertEquals("bar", sb.toString());
    }

    @Test
    public void testReplaceAllMatcher() {
        final StrBuilder sb = new StrBuilder("a1b2c3");
        sb.replaceAll(StrMatcher.charSetMatcher("0123456789"), "#");
        assertEquals("a#b#c#", sb.toString());
    }

    @Test
    public void testReplaceFirstChar() {
        final StrBuilder sb = new StrBuilder("ababab");
        sb.replaceFirst('a', 'x');
        assertEquals("xbabab", sb.toString());
    }

    @Test
    public void testReplaceFirstString() {
        final StrBuilder sb = new StrBuilder("foobarfoobar");
        sb.replaceFirst("foo", "X");
        assertEquals("Xbarfoobar", sb.toString());
    }

    @Test
    public void testReplaceFirstMatcher() {
        final StrBuilder sb = new StrBuilder("a1b2c3");
        sb.replaceFirst(StrMatcher.charSetMatcher("0123456789"), "#");
        assertEquals("a#b2c3", sb.toString());
    }

    @Test
    public void testReverse() {
        final StrBuilder sb = new StrBuilder("abcde");
        sb.reverse();
        assertEquals("edcba", sb.toString());
    }

    @Test
    public void testReverseEmpty() {
        final StrBuilder sb = new StrBuilder();
        sb.reverse();
        assertEquals("", sb.toString());
    }

    @Test
    public void testReverseSurrogatePair() {
        final String supplementary = new String(Character.toChars(0x1F600));
        final StrBuilder sb = new StrBuilder("a" + supplementary + "b");
        sb.reverse();
        assertEquals("b" + supplementary + "a", sb.toString());
    }

    @Test
    public void testRightString() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("def", sb.rightString(3));
        assertEquals("", sb.rightString(0));
        assertEquals("", sb.rightString(-1));
        assertEquals("abcdef", sb.rightString(100));
    }

    @Test
    public void testSetCharAt() {
        final StrBuilder sb = new StrBuilder("abc");
        sb.setCharAt(1, 'X');
        assertEquals("aXc", sb.toString());
    }

    @Test
    public void testSetCharAtInvalid() {
        final StrBuilder sb = new StrBuilder("abc");
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.setCharAt(-1, 'x'));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.setCharAt(3, 'x'));
    }

    @Test
    public void testSetLengthShrink() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.setLength(3);
        assertEquals("abc", sb.toString());
        assertEquals(3, sb.length());
    }

    @Test
    public void testSetLengthGrowFillsZeroChars() {
        final StrBuilder sb = new StrBuilder("ab");
        sb.setLength(4);
        assertEquals(4, sb.length());
        assertEquals('a', sb.charAt(0));
        assertEquals('b', sb.charAt(1));
        assertEquals('\0', sb.charAt(2));
        assertEquals('\0', sb.charAt(3));
    }

    @Test
    public void testSetLengthNegativeThrows() {
        final StrBuilder sb = new StrBuilder("abc");
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.setLength(-1));
    }

    @Test
    public void testSize() {
        final StrBuilder sb = new StrBuilder("abcde");
        assertEquals(5, sb.size());
        assertEquals(sb.length(), sb.size());
    }

    @Test
    public void testStartsWith() {
        final StrBuilder sb = new StrBuilder("hello world");
        assertTrue(sb.startsWith("hello"));
        assertFalse(sb.startsWith("world"));
        assertFalse(sb.startsWith(null));
        assertTrue(sb.startsWith(""));
        assertFalse(sb.startsWith("this is way too long"));
    }

    @Test
    public void testSubSequence() {
        final StrBuilder sb = new StrBuilder("abcdef");
        final CharSequence sub = sb.subSequence(1, 4);
        assertEquals("bcd", sub.toString());
    }

    @Test
    public void testSubSequenceInvalid() {
        final StrBuilder sb = new StrBuilder("abc");
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.subSequence(-1, 2));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.subSequence(0, 100));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.subSequence(2, 1));
    }

    @Test
    public void testSubstringFromStart() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("cdef", sb.substring(2));
    }

    @Test
    public void testSubstringRange() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("bcd", sb.substring(1, 4));
    }

    @Test
    public void testSubstringRangeEndBeyondSizeTreatedAsEnd() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("cdef", sb.substring(2, 100));
    }

    @Test
    public void testSubstringInvalidStart() {
        final StrBuilder sb = new StrBuilder("abc");
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.substring(-1, 2));
    }

    @Test
    public void testToCharArray() {
        final StrBuilder sb = new StrBuilder("abc");
        assertArrayEquals(new char[] {'a', 'b', 'c'}, sb.toCharArray());
    }

    @Test
    public void testToCharArrayEmpty() {
        final StrBuilder sb = new StrBuilder();
        assertEquals(0, sb.toCharArray().length);
    }

    @Test
    public void testToCharArrayRange() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertArrayEquals(new char[] {'b', 'c', 'd'}, sb.toCharArray(1, 4));
    }

    @Test
    public void testToCharArrayRangeEmpty() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertEquals(0, sb.toCharArray(2, 2).length);
    }

    @Test
    public void testToString() {
        final StrBuilder sb = new StrBuilder("abc");
        assertEquals("abc", sb.toString());
        sb.append("def");
        assertEquals("abcdef", sb.toString());
    }

    @Test
    public void testToStringBuffer() {
        final StrBuilder sb = new StrBuilder("abc");
        final StringBuffer buf = sb.toStringBuffer();
        assertEquals("abc", buf.toString());
    }

    @Test
    public void testToStringBuilder() {
        final StrBuilder sb = new StrBuilder("abc");
        final StringBuilder builder = sb.toStringBuilder();
        assertEquals("abc", builder.toString());
    }

    @Test
    public void testTrim() {
        final StrBuilder sb = new StrBuilder("  abc  ");
        sb.trim();
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testTrimEmpty() {
        final StrBuilder sb = new StrBuilder();
        sb.trim();
        assertEquals("", sb.toString());
    }

    @Test
    public void testTrimAllWhitespace() {
        final StrBuilder sb = new StrBuilder("    ");
        sb.trim();
        assertEquals("", sb.toString());
    }

    @Test
    public void testCharSequenceInterfaceLength() {
        final CharSequence cs = new StrBuilder("abc");
        assertEquals(3, cs.length());
    }

    @Test
    public void testAppendableInterfaceAppendCharSequence() throws IOException {
        final Appendable appendable = new StrBuilder();
        appendable.append("abc");
        assertEquals("abc", appendable.toString());
    }

    @Test
    public void testChainedCalls() {
        final StrBuilder sb = new StrBuilder();
        sb.append("a").append('b').append(1).append(true);
        assertEquals("ab1true", sb.toString());
    }

    /**
     * Minimal Writer that is not a StringWriter, used only to exercise the generic
     * {@link StrBuilder#appendTo(Appendable)} Writer branch independent of java.io.StringWriter internals.
     */
    private static final class StringWriter extends Writer {
        private final StringBuilder contents = new StringBuilder();

        @Override
        public void write(final char[] cbuf, final int off, final int len) {
            contents.append(cbuf, off, len);
        }

        @Override
        public void flush() {
            // do nothing
        }

        @Override
        public void close() {
            // do nothing
        }

        String getContents() {
            return contents.toString();
        }
    }

    /**
     * Readable implementation that is neither a Reader nor a CharBuffer, to exercise
     * the generic branch of {@link StrBuilder#readFrom(Readable)}.
     */
    private static final class SimpleReadable implements Readable {
        private final char[] data;
        private int pos;

        SimpleReadable(final String s) {
            this.data = s.toCharArray();
        }

        @Override
        public int read(final CharBuffer cb) {
            if (pos >= data.length) {
                return -1;
            }
            int n = 0;
            while (pos < data.length && cb.hasRemaining()) {
                cb.put(data[pos++]);
                n++;
            }
            return n;
        }
    }
}
