/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link FastDateParser}.
 *
 * <p>
 * This test class lives in the same package as {@link FastDateParser} so that it can call the {@code protected} constructors directly, without going
 * through the {@link FastDateFormat} cache.
 * </p>
 */
class FastDateParserAgentTest {

    private static final TimeZone GMT = TimeZone.getTimeZone("GMT");

    private static Calendar calendarFor(final TimeZone tz, final Date date) {
        final Calendar cal = Calendar.getInstance(tz, Locale.US);
        cal.setTime(date);
        return cal;
    }

    @Test
    void testParseBasicDate() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final Date date = parser.parse("2023-06-15");
        assertNotNull(date);
        final Calendar cal = calendarFor(GMT, date);
        assertEquals(2023, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JUNE, cal.get(Calendar.MONTH));
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseAdjacentNumericFieldsRespectWidth() throws ParseException {
        // Adjacent numeric fields without a separator must not let the first field swallow digits
        // that belong to the next one.
        final FastDateParser parser = new FastDateParser("yyyyMMdd", GMT, Locale.US);
        final Date date = parser.parse("20230615");
        final Calendar cal = calendarFor(GMT, date);
        assertEquals(2023, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JUNE, cal.get(Calendar.MONTH));
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseThrowsParseExceptionOnMismatch() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final ParseException e = assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                parser.parse("not-a-date");
            }
        });
        assertEquals(0, e.getErrorOffset());
        assertTrue(e.getMessage().contains("Unparseable date"));
    }

    @Test
    void testParseIgnoresTrailingUnmatchedText() throws ParseException {
        // parse(String) does not require the whole input to be consumed, only a matching prefix.
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final Date date = parser.parse("2023-06-15 extra garbage that is not part of the pattern");
        assertEquals(2023, calendarFor(GMT, date).get(Calendar.YEAR));
    }

    @Test
    void testParseWithPositionAllowsPartialConsumption() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("2023-06-15 and then some", pos);
        assertNotNull(date);
        assertEquals(10, pos.getIndex());
    }

    @Test
    void testParseWithPositionStartingMidString() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final ParsePosition pos = new ParsePosition(7);
        final Date date = parser.parse("prefix-2023-06-15", pos);
        assertNotNull(date);
        assertEquals(17, pos.getIndex());
    }

    @Test
    void testParseWithPositionReturnsNullOnMismatch() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("garbage", pos);
        assertNull(date);
        assertEquals(0, pos.getIndex());
        assertTrue(pos.getErrorIndex() >= 0);
    }

    @Test
    void testParseWithPositionIndexBeyondSourceLengthReturnsNull() {
        // checkLength: an index already past the end of the source is a failure, not an exception.
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final ParsePosition pos = new ParsePosition(20);
        final Date date = parser.parse("2023-06-15", pos);
        assertNull(date);
        assertEquals(20, pos.getErrorIndex());
    }

    @Test
    void testParseWithCalendarReturnsFalseOnFailureWithoutAdvancing() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Calendar cal = Calendar.getInstance(GMT, Locale.US);
        final boolean result = parser.parse("garbage", pos, cal);
        assertFalse(result);
        assertEquals(0, pos.getIndex());
    }

    @Test
    void testParseWithCalendarReturnsTrueAndSetsFields() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Calendar cal = Calendar.getInstance(GMT, Locale.US);
        cal.clear();
        final boolean result = parser.parse("2023-06-15", pos, cal);
        assertTrue(result);
        assertEquals(10, pos.getIndex());
        assertEquals(2023, cal.get(Calendar.YEAR));
    }

    @Test
    void testHourInDay24RolledOverToZero() throws ParseException {
        // 'kk' (hour in day, 1-24): midnight is encoded as 24, not 0.
        final FastDateParser parser = new FastDateParser("kk", GMT, Locale.US);
        final Date date = parser.parse("24");
        assertEquals(0, calendarFor(GMT, date).get(Calendar.HOUR_OF_DAY));
    }

    @Test
    void testHourInAmPm12RolledOverToZero() throws ParseException {
        // 'hh' (hour in am/pm, 1-12): midday/midnight is encoded as 12, not 0.
        final FastDateParser parser = new FastDateParser("hh", GMT, Locale.US);
        final Date date = parser.parse("12");
        assertEquals(0, calendarFor(GMT, date).get(Calendar.HOUR));
    }

    @Test
    void testTwoDigitYearBelowStartYearRollsToNextCentury() throws ParseException {
        final Calendar centuryStart = Calendar.getInstance(GMT, Locale.US);
        centuryStart.clear();
        centuryStart.set(1950, Calendar.JANUARY, 1);
        final FastDateParser parser = new FastDateParser("yy", GMT, Locale.US, centuryStart.getTime());
        final Date below = parser.parse("49");
        assertEquals(2049, calendarFor(GMT, below).get(Calendar.YEAR));
    }

    @Test
    void testTwoDigitYearAtStartYearStaysInCentury() throws ParseException {
        final Calendar centuryStart = Calendar.getInstance(GMT, Locale.US);
        centuryStart.clear();
        centuryStart.set(1950, Calendar.JANUARY, 1);
        final FastDateParser parser = new FastDateParser("yy", GMT, Locale.US, centuryStart.getTime());
        final Date at = parser.parse("50");
        assertEquals(1950, calendarFor(GMT, at).get(Calendar.YEAR));
    }

    @Test
    void testFourDigitYearOverflowIsParseFailureNotCrash() {
        // A run of digits that overflows int must become a parse failure (ParseException), not an
        // undeclared NumberFormatException.
        final FastDateParser parser = new FastDateParser("yyyy", GMT, Locale.US);
        final ParseException e = assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                parser.parse("99999999999999999999");
            }
        });
        assertEquals(0, e.getErrorOffset());
    }

    @Test
    void testUnsupportedPatternLetterRejectedAtConstruction() {
        final IllegalArgumentException e = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDateParser("n", GMT, Locale.US);
            }
        });
        assertTrue(e.getMessage().contains("n"));
    }

    @Test
    void testUnterminatedQuoteRejectedAtConstruction() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDateParser("yyyy'bad", GMT, Locale.US);
            }
        });
    }

    @Test
    void testNullPatternRejected() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDateParser(null, GMT, Locale.US);
            }
        });
    }

    @Test
    void testNullTimeZoneRejected() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDateParser("yyyy", null, Locale.US);
            }
        });
    }

    @Test
    void testNullLocaleDefaultsToSystemLocale() {
        final FastDateParser parser = new FastDateParser("yyyy", GMT, null);
        assertEquals(Locale.getDefault(), parser.getLocale());
    }

    @Test
    void testGettersReturnConstructorValues() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        assertEquals("yyyy-MM-dd", parser.getPattern());
        assertEquals(Locale.US, parser.getLocale());
        assertEquals(GMT, parser.getTimeZone());
    }

    @Test
    void testGetTimeZoneReturnsIndependentClone() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final TimeZone first = parser.getTimeZone();
        first.setRawOffset(123456);
        final TimeZone second = parser.getTimeZone();
        assertNotEquals(123456, second.getRawOffset());
    }

    @Test
    void testEqualsAndHashCode() {
        final FastDateParser a = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final FastDateParser b = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final FastDateParser differentPattern = new FastDateParser("yyyy/MM/dd", GMT, Locale.US);
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
        assertNotEquals(a, differentPattern);
        assertNotEquals(a, null);
        assertNotEquals(a, "yyyy-MM-dd");
    }

    @Test
    void testToStringContainsPatternLocaleAndZone() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final String s = parser.toString();
        assertTrue(s.contains("yyyy-MM-dd"));
        assertTrue(s.contains("GMT"));
    }

    @Test
    void testToStringAllContainsPattern() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        assertTrue(parser.toStringAll().contains("yyyy-MM-dd"));
    }

    @Test
    void testGetPatternsCountsLiteralsAndFields() {
        // "yyyy", "-", "MM", "-", "dd" -> five strategy entries.
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final List<?> patterns = parser.getPatterns();
        assertEquals(5, patterns.size());
    }

    @Test
    void testIsoOffsetPatternParsesNonZeroOffset() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd'T'HH:mm:ssXXX", GMT, Locale.US);
        final Date date = parser.parse("2023-06-15T10:20:30+02:00");
        final Calendar cal = calendarFor(GMT, date);
        assertEquals(8, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals(20, cal.get(Calendar.MINUTE));
    }

    @Test
    void testWeekYearPatternResolvesThroughSetWeekDate() throws ParseException {
        final FastDateParser parser = new FastDateParser("YYYY-'W'ww-u", GMT, Locale.US);
        final Date date = parser.parse("2023-W24-4");
        final Calendar cal = calendarFor(GMT, date);
        assertEquals(Calendar.THURSDAY, cal.get(Calendar.DAY_OF_WEEK));
    }

    @Test
    void testJapaneseImperialLocaleUnparseableMessageMentionsEraLimit() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, FastDateParser.JAPANESE_IMPERIAL);
        final ParseException e = assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                parser.parse("not-a-date");
            }
        });
        assertTrue(e.getMessage().contains("1868-01-01"));
    }

    @Test
    void testSerializationRoundTrip() throws Exception {
        final FastDateParser original = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        final ObjectOutputStream oos = new ObjectOutputStream(baos);
        oos.writeObject(original);
        oos.close();
        final ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(baos.toByteArray()));
        final FastDateParser deserialized = (FastDateParser) ois.readObject();
        ois.close();
        assertEquals(original, deserialized);
        final Date date = deserialized.parse("2024-01-02");
        assertEquals(2024, calendarFor(GMT, date).get(Calendar.YEAR));
    }

    @Test
    void testParseObjectDelegatesToParse() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final Object result = parser.parseObject("2023-06-15");
        assertTrue(result instanceof Date);
        assertEquals(2023, calendarFor(GMT, (Date) result).get(Calendar.YEAR));
    }

    @Test
    void testParseObjectWithPositionDelegatesToParse() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Object result = parser.parseObject("2023-06-15", pos);
        assertTrue(result instanceof Date);
        assertEquals(10, pos.getIndex());
    }
}
