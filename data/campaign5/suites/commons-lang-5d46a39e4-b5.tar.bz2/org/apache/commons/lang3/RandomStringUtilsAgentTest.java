/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Random;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link RandomStringUtils}.
 */
@SuppressWarnings("deprecation")
class RandomStringUtilsAgentTest {

    private static void assertAllCharsMatch(final String s, final String description, final CharPredicate predicate) {
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(predicate.test(c), description + ": unexpected char '" + c + "' (" + (int) c + ") in \"" + s + "\"");
        }
    }

    private interface CharPredicate {
        boolean test(char c);
    }

    // --- Singletons -----------------------------------------------------

    @Test
    void testSecureSingleton() {
        final RandomStringUtils a = RandomStringUtils.secure();
        final RandomStringUtils b = RandomStringUtils.secure();
        assertSame(a, b);
        assertNotNull(a);
    }

    @Test
    void testSecureStrongSingleton() {
        final RandomStringUtils a = RandomStringUtils.secureStrong();
        final RandomStringUtils b = RandomStringUtils.secureStrong();
        assertSame(a, b);
        assertNotNull(a);
    }

    @Test
    void testInsecureSingleton() {
        final RandomStringUtils a = RandomStringUtils.insecure();
        final RandomStringUtils b = RandomStringUtils.insecure();
        assertSame(a, b);
        assertNotNull(a);
    }

    @Test
    void testSingletonsAreDistinct() {
        assertTrue(RandomStringUtils.secure() != RandomStringUtils.insecure());
        assertTrue(RandomStringUtils.secure() != RandomStringUtils.secureStrong());
    }

    @Test
    void testDeprecatedPublicConstructor() {
        final RandomStringUtils instance = new RandomStringUtils();
        final String s = instance.next(5);
        assertEquals(5, s.length());
    }

    // --- Static deprecated random(...) methods ---------------------------

    @Test
    void testRandomCountZero() {
        assertEquals("", RandomStringUtils.random(0));
    }

    @Test
    void testRandomNegativeCountThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(-1);
            }
        });
    }

    @Test
    void testRandomCountOnlyLength() {
        final String s = RandomStringUtils.random(100);
        assertEquals(100, s.length());
    }

    @Test
    void testRandomLettersOnly() {
        final String s = RandomStringUtils.random(50, true, false);
        assertEquals(50, s.length());
        assertAllCharsMatch(s, "letters only", new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return Character.isLetter(c);
            }
        });
    }

    @Test
    void testRandomNumbersOnly() {
        final String s = RandomStringUtils.random(50, false, true);
        assertEquals(50, s.length());
        assertAllCharsMatch(s, "numbers only", new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return Character.isDigit(c);
            }
        });
    }

    @Test
    void testRandomCharsArrayNegativeCountThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(-5, 'a', 'b', 'c');
            }
        });
    }

    @Test
    void testRandomCharsArrayEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, new char[0]);
            }
        });
    }

    @Test
    void testRandomCharsArrayZeroCountBypassesEmptyCharsCheck() {
        // count == 0 is handled before the empty-chars validation, so no exception is thrown.
        assertEquals("", RandomStringUtils.random(0, new char[0]));
    }

    @Test
    void testRandomCharsArrayRestrictsCharacterSet() {
        final char[] allowed = { 'x', 'y', 'z' };
        final String s = RandomStringUtils.random(200, allowed);
        assertEquals(200, s.length());
        assertAllCharsMatch(s, "restricted set", new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return c == 'x' || c == 'y' || c == 'z';
            }
        });
    }

    @Test
    void testRandomStartEndLettersNumbers() {
        final String s = RandomStringUtils.random(50, 0, 0, true, true);
        assertEquals(50, s.length());
        assertAllCharsMatch(s, "letters+numbers", new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return Character.isLetterOrDigit(c);
            }
        });
    }

    @Test
    void testRandomStartEndMustBeGreaterThanStart() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 10, 10, false, false);
            }
        });
    }

    @Test
    void testRandomStartEndMustBeGreaterThanStartWhenEndSmaller() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 10, 5, false, false);
            }
        });
    }

    @Test
    void testRandomNegativeStartOrEndThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, -1, 20, false, false);
            }
        });
    }

    @Test
    void testRandomNumbersEndTooSmallThrows() {
        // chars == null, end <= 0x7f, numbers=true and end <= '0' (48) must fail.
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 1, '0', true, false);
            }
        });
    }

    @Test
    void testRandomLettersEndTooSmallThrows() {
        // chars == null, end <= 0x7f, letters=true and end <= 'A' (65) must fail.
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 1, 'A', true, false);
            }
        });
    }

    @Test
    void testRandomStartEndLettersNumbersChars() {
        final char[] chars = { 'a', 'b', 'c', 'd', 'e' };
        final String s = RandomStringUtils.random(30, 0, chars.length, false, false, chars);
        assertEquals(30, s.length());
        assertAllCharsMatch(s, "explicit chars subset", new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return c >= 'a' && c <= 'e';
            }
        });
    }

    @Test
    void testRandomFullSignatureDeterministicWithSeededRandom() {
        final char[] chars = "abcdefghij".toCharArray();
        final String first = RandomStringUtils.random(40, 0, chars.length, false, false, chars, new Random(42L));
        final String second = RandomStringUtils.random(40, 0, chars.length, false, false, chars, new Random(42L));
        assertEquals(first, second);
        assertEquals(40, first.length());
    }

    @Test
    void testRandomFullSignatureCountZeroReturnsEmpty() {
        assertEquals("", RandomStringUtils.random(0, 0, 0, false, false, null, new Random(1L)));
    }

    @Test
    void testRandomFullSignatureNegativeCountThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(-3, 0, 0, false, false, null, new Random(1L));
            }
        });
    }

    @Test
    void testRandomFullSignatureEmptyCharsThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(3, 0, 0, false, false, new char[0], new Random(1L));
            }
        });
    }

    @Test
    void testRandomStringCharsParam() {
        final String s = RandomStringUtils.random(25, "ab");
        assertEquals(25, s.length());
        assertAllCharsMatch(s, "string chars", new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return c == 'a' || c == 'b';
            }
        });
    }

    @Test
    void testRandomStringCharsNull() {
        final String s = RandomStringUtils.random(10, (String) null);
        assertEquals(10, s.length());
    }

    @Test
    void testRandomStringCharsEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, "");
            }
        });
    }

    // --- Static deprecated convenience methods ----------------------------

    @Test
    void testRandomAlphabetic() {
        final String s = RandomStringUtils.randomAlphabetic(40);
        assertEquals(40, s.length());
        assertAllCharsMatch(s, "alphabetic", new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
            }
        });
    }

    @Test
    void testRandomAlphabeticRange() {
        final String s = RandomStringUtils.randomAlphabetic(5, 6);
        assertEquals(5, s.length());
    }

    @Test
    void testRandomAlphabeticRangeMinEqualsMax() {
        final String s = RandomStringUtils.randomAlphabetic(7, 7);
        assertEquals(7, s.length());
    }

    @Test
    void testRandomAlphabeticRangeMinGreaterThanMaxThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.randomAlphabetic(10, 5);
            }
        });
    }

    @Test
    void testRandomAlphanumeric() {
        final String s = RandomStringUtils.randomAlphanumeric(40);
        assertEquals(40, s.length());
        assertAllCharsMatch(s, "alphanumeric", new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9');
            }
        });
    }

    @Test
    void testRandomAlphanumericRange() {
        final String s = RandomStringUtils.randomAlphanumeric(3, 4);
        assertEquals(3, s.length());
    }

    @Test
    void testRandomAscii() {
        final String s = RandomStringUtils.randomAscii(40);
        assertEquals(40, s.length());
        assertAllCharsMatch(s, "ascii", new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return c >= 32 && c <= 126;
            }
        });
    }

    @Test
    void testRandomAsciiRange() {
        final String s = RandomStringUtils.randomAscii(2, 3);
        assertEquals(2, s.length());
    }

    @Test
    void testRandomGraph() {
        final String s = RandomStringUtils.randomGraph(40);
        assertEquals(40, s.length());
        assertAllCharsMatch(s, "graph", new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return c >= 33 && c <= 125;
            }
        });
    }

    @Test
    void testRandomGraphRange() {
        final String s = RandomStringUtils.randomGraph(2, 3);
        assertEquals(2, s.length());
    }

    @Test
    void testRandomNumeric() {
        final String s = RandomStringUtils.randomNumeric(40);
        assertEquals(40, s.length());
        assertAllCharsMatch(s, "numeric", new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return c >= '0' && c <= '9';
            }
        });
    }

    @Test
    void testRandomNumericRange() {
        final String s = RandomStringUtils.randomNumeric(2, 3);
        assertEquals(2, s.length());
    }

    @Test
    void testRandomPrint() {
        final String s = RandomStringUtils.randomPrint(40);
        assertEquals(40, s.length());
        assertAllCharsMatch(s, "print", new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return c >= 32 && c <= 125;
            }
        });
    }

    @Test
    void testRandomPrintRange() {
        final String s = RandomStringUtils.randomPrint(2, 3);
        assertEquals(2, s.length());
    }

    // --- Instance methods: next(...) --------------------------------------

    @Test
    void testNextCountZero() {
        assertEquals("", RandomStringUtils.secure().next(0));
    }

    @Test
    void testNextNegativeCountThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.secure().next(-1);
            }
        });
    }

    @Test
    void testNextCountOnly() {
        final String s = RandomStringUtils.insecure().next(64);
        assertEquals(64, s.length());
    }

    @Test
    void testNextLettersNumbers() {
        final String s = RandomStringUtils.insecure().next(30, true, true);
        assertEquals(30, s.length());
        assertAllCharsMatch(s, "next letters+numbers", new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return Character.isLetterOrDigit(c);
            }
        });
    }

    @Test
    void testNextCharsVarargsNullMeansAnyChar() {
        final String s = RandomStringUtils.insecure().next(20, (char[]) null);
        assertEquals(20, s.length());
    }

    @Test
    void testNextCharsVarargsRestrictsCharacterSet() {
        final String s = RandomStringUtils.insecure().next(20, '1', '2', '3');
        assertEquals(20, s.length());
        assertAllCharsMatch(s, "next chars varargs", new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return c == '1' || c == '2' || c == '3';
            }
        });
    }

    @Test
    void testNextStartEndLettersNumbers() {
        final String s = RandomStringUtils.insecure().next(30, 0, 0, false, true);
        assertEquals(30, s.length());
        assertAllCharsMatch(s, "next start/end numbers", new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return Character.isDigit(c);
            }
        });
    }

    @Test
    void testNextStartEndLettersNumbersCharsVarargs() {
        final char[] chars = { 'q', 'r', 's' };
        final String s = RandomStringUtils.insecure().next(15, 0, chars.length, false, false, chars);
        assertEquals(15, s.length());
        assertAllCharsMatch(s, "next start/end chars", new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return c == 'q' || c == 'r' || c == 's';
            }
        });
    }

    @Test
    void testNextStringCharsParam() {
        final String s = RandomStringUtils.insecure().next(15, "mn");
        assertEquals(15, s.length());
        assertAllCharsMatch(s, "next string chars", new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return c == 'm' || c == 'n';
            }
        });
    }

    @Test
    void testNextStringCharsParamNull() {
        final String s = RandomStringUtils.insecure().next(10, (String) null);
        assertEquals(10, s.length());
    }

    @Test
    void testNextAlphabetic() {
        final String s = RandomStringUtils.insecure().nextAlphabetic(25);
        assertEquals(25, s.length());
        assertAllCharsMatch(s, "nextAlphabetic", new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
            }
        });
    }

    @Test
    void testNextAlphabeticZeroCount() {
        assertEquals("", RandomStringUtils.insecure().nextAlphabetic(0));
    }

    @Test
    void testNextAlphabeticRange() {
        final String s = RandomStringUtils.insecure().nextAlphabetic(4, 5);
        assertEquals(4, s.length());
    }

    @Test
    void testNextAlphanumeric() {
        final String s = RandomStringUtils.insecure().nextAlphanumeric(25);
        assertEquals(25, s.length());
        assertAllCharsMatch(s, "nextAlphanumeric", new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9');
            }
        });
    }

    @Test
    void testNextAlphanumericRange() {
        final String s = RandomStringUtils.insecure().nextAlphanumeric(4, 5);
        assertEquals(4, s.length());
    }

    @Test
    void testNextAscii() {
        final String s = RandomStringUtils.insecure().nextAscii(25);
        assertEquals(25, s.length());
        assertAllCharsMatch(s, "nextAscii", new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return c >= 32 && c <= 126;
            }
        });
    }

    @Test
    void testNextAsciiRange() {
        final String s = RandomStringUtils.insecure().nextAscii(4, 5);
        assertEquals(4, s.length());
    }

    @Test
    void testNextGraph() {
        final String s = RandomStringUtils.insecure().nextGraph(25);
        assertEquals(25, s.length());
        assertAllCharsMatch(s, "nextGraph", new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return c >= 33 && c <= 125;
            }
        });
    }

    @Test
    void testNextGraphRange() {
        final String s = RandomStringUtils.insecure().nextGraph(4, 5);
        assertEquals(4, s.length());
    }

    @Test
    void testNextNumeric() {
        final String s = RandomStringUtils.insecure().nextNumeric(25);
        assertEquals(25, s.length());
        assertAllCharsMatch(s, "nextNumeric", new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return c >= '0' && c <= '9';
            }
        });
    }

    @Test
    void testNextNumericRange() {
        final String s = RandomStringUtils.insecure().nextNumeric(4, 5);
        assertEquals(4, s.length());
    }

    @Test
    void testNextPrint() {
        final String s = RandomStringUtils.insecure().nextPrint(25);
        assertEquals(25, s.length());
        assertAllCharsMatch(s, "nextPrint", new CharPredicate() {
            @Override
            public boolean test(final char c) {
                return c >= 32 && c <= 125;
            }
        });
    }

    @Test
    void testNextPrintRange() {
        final String s = RandomStringUtils.insecure().nextPrint(4, 5);
        assertEquals(4, s.length());
    }

    @Test
    void testNextPrintRangeMinGreaterThanMaxThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.insecure().nextPrint(10, 2);
            }
        });
    }

    // --- toString -----------------------------------------------------------

    @Test
    void testToStringContainsClassNameAndRandom() {
        final String s = RandomStringUtils.secure().toString();
        assertTrue(s.contains("RandomStringUtils"));
        assertTrue(s.contains("random="));
    }

    @Test
    void testRandomCharsArrayOfLengthOne() {
        final String s = RandomStringUtils.random(10, 'z');
        assertEquals(10, s.length());
        final char[] expected = new char[10];
        for (int i = 0; i < expected.length; i++) {
            expected[i] = 'z';
        }
        assertArrayEquals(expected, s.toCharArray());
    }
}
