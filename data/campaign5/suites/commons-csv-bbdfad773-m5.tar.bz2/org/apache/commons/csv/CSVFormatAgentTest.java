/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import org.apache.commons.csv.CSVFormat.Builder;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link CSVFormat}.
 */
class CSVFormatAgentTest {

    enum HeaderEnum {
        NAME, EMAIL, PHONE
    }

    enum EmptyHeaderEnum {
        // intentionally empty
    }

    private static File newTempFile(final String suffix) throws IOException {
        String tmpDir = System.getenv("TMPDIR");
        if (tmpDir == null) {
            tmpDir = System.getProperty("java.io.tmpdir");
        }
        final File dir = new File(tmpDir);
        final File file = File.createTempFile("CSVFormatAgentTest", suffix, dir);
        file.deleteOnExit();
        return file;
    }

    // --- Predefined formats -------------------------------------------------

    @Test
    void testPredefinedDefault() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertTrue(format.getIgnoreEmptyLines());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
    }

    @Test
    void testPredefinedExcel() {
        final CSVFormat format = CSVFormat.EXCEL;
        assertFalse(format.getIgnoreEmptyLines());
        assertTrue(format.getAllowMissingColumnNames());
        assertTrue(format.getTrailingData());
        assertTrue(format.getLenientEof());
    }

    @Test
    void testPredefinedMySql() {
        final CSVFormat format = CSVFormat.MYSQL;
        assertEquals("\t", format.getDelimiterString());
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
        assertFalse(format.isQuoteCharacterSet());
        assertEquals("\\N", format.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, format.getQuoteMode());
        assertEquals("\n", format.getRecordSeparator());
    }

    @Test
    void testPredefinedRfc4180() {
        final CSVFormat format = CSVFormat.RFC4180;
        assertFalse(format.getIgnoreEmptyLines());
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
    }

    @Test
    void testPredefinedTdf() {
        final CSVFormat format = CSVFormat.TDF;
        assertEquals("\t", format.getDelimiterString());
        assertTrue(format.getIgnoreSurroundingSpaces());
    }

    @Test
    void testPredefinedOracle() {
        final CSVFormat format = CSVFormat.ORACLE;
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertTrue(format.getTrim());
        assertEquals(QuoteMode.MINIMAL, format.getQuoteMode());
    }

    @Test
    void testPredefinedPostgresqlCsv() {
        final CSVFormat format = CSVFormat.POSTGRESQL_CSV;
        assertFalse(format.isEscapeCharacterSet());
        assertEquals("", format.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, format.getQuoteMode());
    }

    @Test
    void testPredefinedMongoDbCsv() {
        final CSVFormat format = CSVFormat.MONGODB_CSV;
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getEscapeCharacter());
        assertEquals(QuoteMode.MINIMAL, format.getQuoteMode());
    }

    @Test
    void testValueOfPredefinedReturnsSameInstance() {
        assertSame(CSVFormat.DEFAULT, CSVFormat.valueOf("Default"));
        assertSame(CSVFormat.TDF, CSVFormat.valueOf("TDF"));
    }

    @Test
    void testValueOfUnknownThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.valueOf("NotAFormat");
            }
        });
    }

    // --- newFormat / basic construction -------------------------------------

    @Test
    void testNewFormatMinimalState() {
        final CSVFormat format = CSVFormat.newFormat('|');
        assertEquals("|", format.getDelimiterString());
        assertFalse(format.isQuoteCharacterSet());
        assertFalse(format.isEscapeCharacterSet());
        assertFalse(format.isCommentMarkerSet());
        assertFalse(format.isNullStringSet());
        assertNull(format.getHeader());
        assertEquals(0L, format.getMaxRows());
    }

    @Test
    void testNewFormatDelimiterIsCrThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.newFormat(Constants.CR);
            }
        });
    }

    @Test
    void testNewFormatDelimiterIsLfThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.newFormat(Constants.LF);
            }
        });
    }

    // --- Builder validation on delimiter/comment/escape/quote --------------

    @Test
    void testSetDelimiterEmptyStringThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDelimiter("").get();
            }
        });
    }

    @Test
    void testSetDelimiterCharLineBreakThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDelimiter(Constants.CR).get();
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDelimiter(Constants.LF).get();
            }
        });
    }

    @Test
    void testSetDelimiterStringLineBreakThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDelimiter(String.valueOf(Constants.CR)).get();
            }
        });
    }

    @Test
    void testSetCommentMarkerLineBreakThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setCommentMarker(Constants.LF).get();
            }
        });
    }

    @Test
    void testSetEscapeLineBreakThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setEscape(Constants.CR).get();
            }
        });
    }

    @Test
    void testSetQuoteLineBreakThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setQuote(Constants.LF).get();
            }
        });
    }

    // --- validate(): cross-field conflicts ----------------------------------

    @Test
    void testValidateQuoteSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDelimiter('!').setQuote('!').get();
            }
        });
    }

    @Test
    void testValidateEscapeSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDelimiter('!').setEscape('!').get();
            }
        });
    }

    @Test
    void testValidateCommentSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDelimiter('!').setCommentMarker('!').get();
            }
        });
    }

    @Test
    void testValidateQuoteSameAsCommentThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setQuote('#').setCommentMarker('#').get();
            }
        });
    }

    @Test
    void testValidateEscapeSameAsCommentThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setEscape('#').setCommentMarker('#').get();
            }
        });
    }

    @Test
    void testValidateQuoteModeNoneWithoutEscapeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setQuoteMode(QuoteMode.NONE).get();
            }
        });
    }

    @Test
    void testValidateQuoteModeNoneWithEscapeIsOk() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').setQuoteMode(QuoteMode.NONE).get();
        assertEquals(QuoteMode.NONE, format.getQuoteMode());
    }

    // --- Duplicate header handling -------------------------------------------

    @Test
    void testDuplicateHeaderDisallowThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).setHeader("A", "A").get();
            }
        });
    }

    @Test
    void testDuplicateHeaderDisallowDistinctIsOk() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).setHeader("A", "B").get();
        assertArrayEquals(new String[] { "A", "B" }, format.getHeader());
    }

    @Test
    void testDuplicateHeaderAllowEmptyAllowsBlankDuplicates() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("", "").get();
        assertEquals(2, format.getHeader().length);
    }

    @Test
    void testDuplicateHeaderAllowEmptyDisallowsNonBlankDuplicates() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("A", "A").get();
            }
        });
    }

    @Test
    void testDuplicateHeaderAllowAllAllowsDuplicatesByDefault() {
        final String[] header = { "A", "A" };
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(header).get();
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
        assertArrayEquals(header, format.getHeader());
    }

    @Test
    void testSetAllowDuplicateHeaderNamesDeprecated() {
        final CSVFormat allow = CSVFormat.DEFAULT.builder().setAllowDuplicateHeaderNames(true).get();
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, allow.getDuplicateHeaderMode());
        assertTrue(allow.getAllowDuplicateHeaderNames());

        final CSVFormat disallow = CSVFormat.DEFAULT.builder().setAllowDuplicateHeaderNames(false).get();
        assertEquals(DuplicateHeaderMode.ALLOW_EMPTY, disallow.getDuplicateHeaderMode());
        assertFalse(disallow.getAllowDuplicateHeaderNames());
    }

    // --- Header / header comments ---------------------------------------------

    @Test
    void testSetHeaderFromEnum() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(HeaderEnum.class).get();
        assertArrayEquals(new String[] { "NAME", "EMAIL", "PHONE" }, format.getHeader());
    }

    @Test
    void testSetHeaderFromEmptyEnumYieldsEmptyArray() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(EmptyHeaderEnum.class).get();
        assertNotNull(format.getHeader());
        assertEquals(0, format.getHeader().length);
    }

    @Test
    void testSetHeaderFromNullEnumYieldsNullHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader((Class<? extends Enum<?>>) null).get();
        assertNull(format.getHeader());
    }

    @Test
    void testGetHeaderReturnsDefensiveCopy() {
        final String[] header = { "A", "B" };
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(header).get();
        // Mutating the caller's array after the fact must not affect the format.
        header[0] = "MUTATED";
        final String[] got = format.getHeader();
        assertEquals("A", got[0]);
        // Mutating the returned array must not affect the format either.
        got[0] = "ALSO MUTATED";
        assertEquals("A", format.getHeader()[0]);
    }

    @Test
    void testGetHeaderCommentsReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeaderComments("one", "two").get();
        final String[] comments = format.getHeaderComments();
        comments[0] = "MUTATED";
        assertEquals("one", format.getHeaderComments()[0]);
    }

    @Test
    void testHeaderCommentsNullByDefault() {
        assertNull(CSVFormat.DEFAULT.getHeaderComments());
    }

    // --- equals / hashCode / toString -----------------------------------------

    @Test
    void testEqualsReflexive() {
        assertTrue(CSVFormat.DEFAULT.equals(CSVFormat.DEFAULT));
    }

    @Test
    void testEqualsNull() {
        assertFalse(CSVFormat.DEFAULT.equals(null));
    }

    @Test
    void testEqualsDifferentType() {
        assertFalse(CSVFormat.DEFAULT.equals("not a CSVFormat"));
    }

    @Test
    void testEqualsAndHashCodeForEquivalentFormats() {
        final CSVFormat a = CSVFormat.DEFAULT;
        final CSVFormat b = CSVFormat.DEFAULT.builder().get();
        assertNotSame(a, b);
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    void testNotEqualsForDifferentFormats() {
        assertNotEquals(CSVFormat.DEFAULT, CSVFormat.EXCEL);
        assertNotEquals(CSVFormat.DEFAULT, CSVFormat.RFC4180);
    }

    @Test
    void testToStringContainsConfiguredSettings() {
        final String str = CSVFormat.DEFAULT.toString();
        assertTrue(str.contains("Delimiter=<,>"));
        assertTrue(str.contains("QuoteChar=<\">"));
        assertTrue(str.contains("SkipHeaderRecord:false"));
    }

    @Test
    void testToStringIncludesHeaderAndComments() {
        final String str = CSVFormat.DEFAULT.builder().setHeader("A", "B").setCommentMarker('#').setHeaderComments("c1").get().toString();
        assertTrue(str.contains("Header:[A, B]"));
        assertTrue(str.contains("HeaderComments:[c1]"));
        assertTrue(str.contains("CommentStart=<#>"));
    }

    // --- builder()/build()/get() ----------------------------------------------

    @Test
    void testBuilderProducesEqualButDistinctInstance() {
        final CSVFormat copy = CSVFormat.DEFAULT.builder().get();
        assertNotSame(CSVFormat.DEFAULT, copy);
        assertEquals(CSVFormat.DEFAULT, copy);
    }

    @SuppressWarnings("deprecation")
    @Test
    void testBuildAndGetReturnDistinctEqualInstances() {
        final Builder builder = CSVFormat.DEFAULT.builder();
        final CSVFormat viaGet = builder.get();
        final CSVFormat viaBuild = builder.build();
        assertNotSame(viaGet, viaBuild);
        assertEquals(viaGet, viaBuild);
    }

    // --- Delimiter accessors ----------------------------------------------------

    @Test
    void testGetDelimiterDeprecatedReturnsFirstChar() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("||").get();
        assertEquals('|', format.getDelimiter());
        assertEquals("||", format.getDelimiterString());
    }

    // --- is*Set() flags ----------------------------------------------------------

    @Test
    void testIsQuoteCharacterSet() {
        assertTrue(CSVFormat.DEFAULT.isQuoteCharacterSet());
        assertFalse(CSVFormat.DEFAULT.builder().setQuote(null).get().isQuoteCharacterSet());
    }

    @Test
    void testIsEscapeCharacterSet() {
        assertFalse(CSVFormat.DEFAULT.isEscapeCharacterSet());
        assertTrue(CSVFormat.INFORMIX_UNLOAD.isEscapeCharacterSet());
    }

    @Test
    void testIsCommentMarkerSet() {
        assertFalse(CSVFormat.DEFAULT.isCommentMarkerSet());
        assertTrue(CSVFormat.DEFAULT.builder().setCommentMarker('#').get().isCommentMarkerSet());
    }

    @Test
    void testIsNullStringSet() {
        assertFalse(CSVFormat.DEFAULT.isNullStringSet());
        assertTrue(CSVFormat.DEFAULT.builder().setNullString("NULL").get().isNullStringSet());
    }

    // --- maxRows / useMaxRows / useRow (package-private boundary logic) ---------

    @Test
    void testMaxRowsDefaultIsUnlimited() {
        assertEquals(0L, CSVFormat.DEFAULT.getMaxRows());
        assertFalse(CSVFormat.DEFAULT.useMaxRows());
        assertTrue(CSVFormat.DEFAULT.useRow(1000000L));
    }

    @Test
    void testMaxRowsLimitsRows() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(3).get();
        assertEquals(3L, format.getMaxRows());
        assertTrue(format.useMaxRows());
        assertTrue(format.useRow(3));
        assertFalse(format.useRow(4));
    }

    @Test
    void testMaxRowsNegativeMeansUnlimited() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(-1).get();
        assertFalse(format.useMaxRows());
    }

    // --- format(Object...) -------------------------------------------------------

    @Test
    void testFormatSimpleValuesNeedNoQuoting() {
        assertEquals("a,b,c", CSVFormat.DEFAULT.format("a", "b", "c"));
    }

    @Test
    void testFormatQuotesValueContainingDelimiter() {
        assertEquals("a,\"b,c\"", CSVFormat.DEFAULT.format("a", "b,c"));
    }

    @Test
    void testFormatQuotesLeadingEmptyValue() {
        assertEquals("\"\",b", CSVFormat.DEFAULT.format("", "b"));
    }

    @Test
    void testFormatDoesNotQuoteTrailingEmptyValue() {
        assertEquals("a,", CSVFormat.DEFAULT.format("a", ""));
    }

    @Test
    void testFormatQuotesLowControlLeadingChar() {
        assertEquals("\"#value\"", CSVFormat.DEFAULT.format("#value"));
    }

    @Test
    void testFormatMultiCharDelimiterNoQuotingNeeded() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("||").get();
        assertEquals("a||b", format.format("a", "b"));
    }

    @Test
    void testFormatMultiCharDelimiterTrailingPartialMatchIsQuoted() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("||").get();
        assertEquals("\"a|\"||b", format.format("a|", "b"));
    }

    @Test
    void testFormatEscapesInsteadOfQuotingWhenConfigured() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuote(null).setEscape('\\').get();
        final String expected = "a" + '\\' + ",b";
        assertEquals(expected, format.format("a,b"));
    }

    @Test
    void testFormatQuoteModeNoneUsesEscaping() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').setQuoteMode(QuoteMode.NONE).get();
        final String expected = "a" + '\\' + ",b";
        assertEquals(expected, format.format("a,b"));
    }

    // --- print(Object, Appendable, boolean) / println / printRecord -------------

    @Test
    void testPrintSimpleValueNewRecord() throws IOException {
        final StringWriter sw = new StringWriter();
        CSVFormat.DEFAULT.print("hello", sw, true);
        assertEquals("hello", sw.toString());
    }

    @Test
    void testPrintPrependsDelimiterWhenNotNewRecord() throws IOException {
        final StringWriter sw = new StringWriter();
        CSVFormat.DEFAULT.print("hello", sw, false);
        assertEquals(",hello", sw.toString());
    }

    @Test
    void testPrintNullUsesNullStringWithoutQuoting() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        format.print(null, sw, true);
        assertEquals("NULL", sw.toString());
    }

    @Test
    void testPrintNullWithQuoteModeAllUsesQuotedNullString() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").setQuoteMode(QuoteMode.ALL).get();
        format.print(null, sw, true);
        assertEquals("\"NULL\"", sw.toString());
    }

    @Test
    void testPrintlnWritesTrailingDelimiterAndRecordSeparator() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).setRecordSeparator('\n').get();
        format.println(sw);
        assertEquals(",\n", sw.toString());
    }

    @Test
    void testPrintlnWithoutRecordSeparatorWritesNothing() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.newFormat(',');
        format.println(sw);
        assertEquals("", sw.toString());
    }

    @Test
    void testPrintRecordAppendsRecordSeparator() throws IOException {
        final StringWriter sw = new StringWriter();
        CSVFormat.DEFAULT.printRecord(sw, "a", "b");
        assertEquals("a,b\r\n", sw.toString());
    }

    // --- parse(Reader) ------------------------------------------------------------

    @Test
    void testParseReadsRecordsAndFields() throws IOException {
        final CSVParser parser = CSVFormat.DEFAULT.parse(new StringReader("a,b,c\r\n1,2,3\r\n"));
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("b", records.get(0).get(1));
            assertEquals("c", records.get(0).get(2));
            assertEquals(3, records.get(1).size());
            assertEquals("3", records.get(1).get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    void testParseEmptyInputYieldsNoRecords() throws IOException {
        final CSVParser parser = CSVFormat.DEFAULT.parse(new StringReader(""));
        try {
            assertTrue(parser.getRecords().isEmpty());
        } finally {
            parser.close();
        }
    }

    // --- print(Appendable) / print(File,Charset) / print(Path,Charset) -----------

    @Test
    void testPrintToAppendableReturnsWorkingPrinter() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = CSVFormat.DEFAULT.print(sw);
        try {
            printer.printRecord("x", "y");
        } finally {
            printer.close();
        }
        assertEquals("x,y\r\n", sw.toString());
    }

    @Test
    void testPrintToFileWritesCsv() throws IOException {
        final File file = newTempFile(".csv");
        final CSVPrinter printer = CSVFormat.DEFAULT.print(file, StandardCharsets.UTF_8);
        try {
            printer.printRecord("a", "b");
        } finally {
            printer.close();
        }
        final String content = new String(Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8);
        assertEquals("a,b\r\n", content);
    }

    @Test
    void testPrintToPathWritesCsv() throws IOException {
        final Path path = newTempFile(".csv").toPath();
        final CSVPrinter printer = CSVFormat.DEFAULT.print(path, StandardCharsets.UTF_8);
        try {
            printer.printRecord("x", "y", "z");
        } finally {
            printer.close();
        }
        final String content = new String(Files.readAllBytes(path), StandardCharsets.UTF_8);
        assertEquals("x,y,z\r\n", content);
    }

    // --- deprecated with*() factory methods ---------------------------------------

    @SuppressWarnings("deprecation")
    @Test
    void testWithDelimiter() {
        final CSVFormat format = CSVFormat.DEFAULT.withDelimiter(';');
        assertEquals(";", format.getDelimiterString());
    }

    @SuppressWarnings("deprecation")
    @Test
    void testWithQuote() {
        final CSVFormat format = CSVFormat.DEFAULT.withQuote('\'');
        assertEquals(Character.valueOf('\''), format.getQuoteCharacter());
    }

    @SuppressWarnings("deprecation")
    @Test
    void testWithQuoteNullDisablesQuoting() {
        final CSVFormat format = CSVFormat.DEFAULT.withQuote((Character) null);
        assertFalse(format.isQuoteCharacterSet());
    }

    @SuppressWarnings("deprecation")
    @Test
    void testWithHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("A", "B");
        assertArrayEquals(new String[] { "A", "B" }, format.getHeader());
    }

    @SuppressWarnings("deprecation")
    @Test
    void testWithFirstRecordAsHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.withFirstRecordAsHeader();
        assertNotNull(format.getHeader());
        assertEquals(0, format.getHeader().length);
        assertTrue(format.getSkipHeaderRecord());
    }

    @SuppressWarnings("deprecation")
    @Test
    void testWithRecordSeparatorChar() {
        final CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator('\n');
        assertEquals("\n", format.getRecordSeparator());
    }

    @SuppressWarnings("deprecation")
    @Test
    void testWithSystemRecordSeparator() {
        final CSVFormat format = CSVFormat.DEFAULT.withSystemRecordSeparator();
        assertEquals(System.lineSeparator(), format.getRecordSeparator());
    }

    @SuppressWarnings("deprecation")
    @Test
    void testWithNullString() {
        final CSVFormat format = CSVFormat.DEFAULT.withNullString("N/A");
        assertEquals("N/A", format.getNullString());
    }

    @SuppressWarnings("deprecation")
    @Test
    void testWithTrim() {
        assertTrue(CSVFormat.DEFAULT.withTrim().getTrim());
        assertFalse(CSVFormat.DEFAULT.withTrim(false).getTrim());
    }

    @SuppressWarnings("deprecation")
    @Test
    void testWithIgnoreHeaderCase() {
        assertTrue(CSVFormat.DEFAULT.withIgnoreHeaderCase().getIgnoreHeaderCase());
        assertFalse(CSVFormat.DEFAULT.withIgnoreHeaderCase(false).getIgnoreHeaderCase());
    }

    @SuppressWarnings("deprecation")
    @Test
    void testWithIgnoreSurroundingSpaces() {
        assertTrue(CSVFormat.DEFAULT.withIgnoreSurroundingSpaces().getIgnoreSurroundingSpaces());
        assertFalse(CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(false).getIgnoreSurroundingSpaces());
    }

    @SuppressWarnings("deprecation")
    @Test
    void testWithTrailingDelimiter() {
        assertTrue(CSVFormat.DEFAULT.withTrailingDelimiter().getTrailingDelimiter());
        assertFalse(CSVFormat.DEFAULT.withTrailingDelimiter(false).getTrailingDelimiter());
    }

    @SuppressWarnings("deprecation")
    @Test
    void testWithAllowMissingColumnNames() {
        assertTrue(CSVFormat.DEFAULT.withAllowMissingColumnNames().getAllowMissingColumnNames());
        assertFalse(CSVFormat.DEFAULT.withAllowMissingColumnNames(false).getAllowMissingColumnNames());
    }

    @SuppressWarnings("deprecation")
    @Test
    void testWithAutoFlush() {
        assertTrue(CSVFormat.DEFAULT.withAutoFlush(true).getAutoFlush());
        assertFalse(CSVFormat.DEFAULT.withAutoFlush(false).getAutoFlush());
    }

    @SuppressWarnings("deprecation")
    @Test
    void testWithEscape() {
        final CSVFormat format = CSVFormat.DEFAULT.withEscape('\\');
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
    }

    @SuppressWarnings("deprecation")
    @Test
    void testWithCommentMarker() {
        final CSVFormat format = CSVFormat.DEFAULT.withCommentMarker('#');
        assertEquals(Character.valueOf('#'), format.getCommentMarker());
    }

    @SuppressWarnings("deprecation")
    @Test
    void testWithQuoteMode() {
        final CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL);
        assertEquals(QuoteMode.ALL, format.getQuoteMode());
    }

    @SuppressWarnings("deprecation")
    @Test
    void testWithIgnoreEmptyLines() {
        assertFalse(CSVFormat.DEFAULT.withIgnoreEmptyLines(false).getIgnoreEmptyLines());
        assertTrue(CSVFormat.DEFAULT.withIgnoreEmptyLines(true).getIgnoreEmptyLines());
    }

    @SuppressWarnings("deprecation")
    @Test
    void testWithAllowDuplicateHeaderNamesNoArg() {
        final CSVFormat format = CSVFormat.DEFAULT.withAllowDuplicateHeaderNames();
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
    }

    @SuppressWarnings("deprecation")
    @Test
    void testWithAllowDuplicateHeaderNamesBoolean() {
        final CSVFormat format = CSVFormat.DEFAULT.withAllowDuplicateHeaderNames(false);
        assertEquals(DuplicateHeaderMode.ALLOW_EMPTY, format.getDuplicateHeaderMode());
    }
}
