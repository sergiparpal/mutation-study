/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.Format;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link ExtendedMessageFormat}.
 */
@SuppressWarnings("deprecation")
class ExtendedMessageFormatAgentTest {

    /**
     * Simple format that upper-cases its argument, regardless of style.
     */
    private static final class UpperCaseFormat extends Format {
        private static final long serialVersionUID = 1L;

        @Override
        public StringBuffer format(final Object obj, final StringBuffer toAppendTo, final java.text.FieldPosition pos) {
            return toAppendTo.append(String.valueOf(obj).toUpperCase());
        }

        @Override
        public Object parseObject(final String source, final java.text.ParsePosition pos) {
            pos.setIndex(source.length());
            return source;
        }
    }

    private static final class UpperFormatFactory implements FormatFactory {
        @Override
        public Format getFormat(final String name, final String arguments, final Locale locale) {
            if ("upper".equals(name)) {
                return new UpperCaseFormat();
            }
            return null;
        }
    }

    private static Map<String, FormatFactory> upperRegistry() {
        final Map<String, FormatFactory> registry = new HashMap<String, FormatFactory>();
        registry.put("upper", new UpperFormatFactory());
        return registry;
    }

    @Test
    void testSimplePatternWithoutRegistry() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello, {0}!");
        assertEquals("Hello, World!", emf.format(new Object[] {"World"}));
        assertEquals("Hello, {0}!", emf.toPattern());
    }

    @Test
    void testCustomFormatIsApplied() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("Name: {0,upper}", upperRegistry());
        assertEquals("Name: JOHN", emf.format(new Object[] {"john"}));
    }

    @Test
    void testCustomFormatPreservedInToPattern() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("Name: {0,upper}", upperRegistry());
        assertEquals("Name: {0,upper}", emf.toPattern());
    }

    @Test
    void testUnknownFormatNameFallsBackToStandardMessageFormat() {
        // "number" is a standard MessageFormat type, not in our custom registry, so it
        // should be handled by the superclass rather than failing.
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number}", upperRegistry());
        assertEquals("42", emf.format(new Object[] {Integer.valueOf(42)}));
    }

    @Test
    void testNullRegistryUsesPlainMessageFormatBehavior() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", Locale.US, null);
        assertEquals("abc", emf.format(new Object[] {"abc"}));
        assertEquals("{0}", emf.toPattern());
    }

    @Test
    void testLocaleConstructorUsesGivenLocale() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number}", Locale.GERMANY);
        // In German locale the decimal separator is a comma.
        assertEquals("1,5", emf.format(new Object[] {Double.valueOf(1.5d)}));
    }

    @Test
    void testUnterminatedFormatElementThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{0", upperRegistry());
            }
        });
        assertTrue(ex.getMessage().contains("Unterminated"));
    }

    @Test
    void testUnterminatedQuotedStringThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("it's a {0,upper", upperRegistry());
            }
        });
        assertTrue(ex.getMessage().contains("Unterminated"));
    }

    @Test
    void testInvalidArgumentIndexThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{x,upper}", upperRegistry());
            }
        });
    }

    @Test
    void testSetFormatThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", upperRegistry());
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                emf.setFormat(0, new UpperCaseFormat());
            }
        });
    }

    @Test
    void testSetFormatByArgumentIndexThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", upperRegistry());
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                emf.setFormatByArgumentIndex(0, new UpperCaseFormat());
            }
        });
    }

    @Test
    void testSetFormatsThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", upperRegistry());
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                emf.setFormats(new Format[] {new UpperCaseFormat()});
            }
        });
    }

    @Test
    void testSetFormatsByArgumentIndexThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", upperRegistry());
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                emf.setFormatsByArgumentIndex(new Format[] {new UpperCaseFormat()});
            }
        });
    }

    @Test
    void testEqualsAndHashCodeForEquivalentInstances() {
        final Map<String, FormatFactory> registry = upperRegistry();
        final ExtendedMessageFormat emf1 = new ExtendedMessageFormat("Hi {0}", Locale.US, registry);
        final ExtendedMessageFormat emf2 = new ExtendedMessageFormat("Hi {0}", Locale.US, registry);
        assertTrue(emf1.equals(emf2));
        assertEquals(emf1.hashCode(), emf2.hashCode());
    }

    @Test
    void testEqualsReturnsFalseForDifferentPattern() {
        final Map<String, FormatFactory> registry = upperRegistry();
        final ExtendedMessageFormat emf1 = new ExtendedMessageFormat("Hi {0}", Locale.US, registry);
        final ExtendedMessageFormat emf2 = new ExtendedMessageFormat("Bye {0}", Locale.US, registry);
        assertFalse(emf1.equals(emf2));
    }

    @Test
    void testEqualsReturnsFalseForNonExtendedMessageFormat() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("Hi {0}");
        assertNotEquals(emf, "Hi {0}");
    }

    @Test
    void testQuotedTextIsNotTreatedAsFormatElement() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("it''s a {0,upper}", upperRegistry());
        assertEquals("it's a TEST", emf.format(new Object[] {"test"}));
    }

    @Test
    void testEmptyPattern() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("", upperRegistry());
        assertEquals("", emf.format(new Object[] {}));
        assertEquals("", emf.toPattern());
    }

    @Test
    void testMultipleArgumentsWithMixedFormats() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper} is {1,number}", upperRegistry());
        assertEquals("BOB is 7", emf.format(new Object[] {"bob", Integer.valueOf(7)}));
    }
}
