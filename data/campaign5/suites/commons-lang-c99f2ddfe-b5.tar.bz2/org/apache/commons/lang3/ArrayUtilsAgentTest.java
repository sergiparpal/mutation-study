/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.BitSet;
import java.util.Map;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link ArrayUtils}.
 */
class ArrayUtilsAgentTest {

    @Test
    void testAddIntElement() {
        final int[] newArray = ArrayUtils.add(new int[] { 1, 2, 3 }, 4);
        assertArrayEquals(new int[] { 1, 2, 3, 4 }, newArray);
        assertArrayEquals(new int[] { 1 }, ArrayUtils.add((int[]) null, 1));
    }

    @Test
    void testAddIntIndex() {
        final int[] array = { 1, 2, 3 };
        assertArrayEquals(new int[] { 0, 1, 2, 3 }, ArrayUtils.add(array, 0, 0));
        assertArrayEquals(new int[] { 1, 2, 3, 4 }, ArrayUtils.add(array, 3, 4));
        assertThrows(IndexOutOfBoundsException.class, () -> ArrayUtils.add(array, -1, 9));
        assertThrows(IndexOutOfBoundsException.class, () -> ArrayUtils.add(array, 4, 9));
    }

    @Test
    void testAddGenericElement() {
        final String[] array = { "a", "b" };
        final String[] result = ArrayUtils.add(array, "c");
        assertArrayEquals(new String[] { "a", "b", "c" }, result);
        final String[] fromNull = ArrayUtils.add((String[]) null, "a");
        assertArrayEquals(new String[] { "a" }, fromNull);
    }

    @Test
    void testAddAllObjectArray() {
        final String[] array1 = { "a", "b" };
        final String[] array2 = { "c", "d" };
        assertArrayEquals(new String[] { "a", "b", "c", "d" }, ArrayUtils.addAll(array1, array2));
        assertArrayEquals(array1, ArrayUtils.addAll(array1, (String[]) null));
    }

    @Test
    void testAddAllPrimitiveInt() {
        assertArrayEquals(new int[] { 1, 2, 3, 4 }, ArrayUtils.addAll(new int[] { 1, 2 }, 3, 4));
        assertArrayEquals(new int[] { 1, 2 }, ArrayUtils.addAll(new int[] { 1, 2 }));
    }

    @Test
    void testAddFirst() {
        assertArrayEquals(new int[] { 0, 1, 2 }, ArrayUtils.addFirst(new int[] { 1, 2 }, 0));
        assertArrayEquals(new int[] { 9 }, ArrayUtils.addFirst((int[]) null, 9));
    }

    @Test
    void testCloneArray() {
        final int[] array = { 1, 2, 3 };
        final int[] cloned = ArrayUtils.clone(array);
        assertArrayEquals(array, cloned);
        assertTrue(array != cloned);
        assertNull(ArrayUtils.clone((int[]) null));
        assertNull(ArrayUtils.clone((Object[]) null));
    }

    @Test
    void testConcatInt() {
        assertArrayEquals(new int[] { 1, 2, 3, 4 }, ArrayUtils.concat(new int[] { 1, 2 }, new int[] { 3, 4 }));
        assertArrayEquals(new int[0], ArrayUtils.concat(new int[0][]));
    }

    @Test
    void testContains() {
        final int[] array = { 1, 2, 3 };
        assertTrue(ArrayUtils.contains(array, 2));
        assertFalse(ArrayUtils.contains(array, 9));
        assertFalse(ArrayUtils.contains((int[]) null, 2));
        assertTrue(ArrayUtils.contains(new Object[] { "a", "b" }, "a"));
        assertFalse(ArrayUtils.contains((Object[]) null, "a"));
    }

    @Test
    void testContainsWithTolerance() {
        final double[] array = { 1.0, 2.0, 3.0 };
        assertTrue(ArrayUtils.contains(array, 2.05, 0.1));
        assertFalse(ArrayUtils.contains(array, 2.5, 0.1));
    }

    @Test
    void testContainsAny() {
        final Object[] array = { "a", "b", "c" };
        assertTrue(ArrayUtils.containsAny(array, "x", "b"));
        assertFalse(ArrayUtils.containsAny(array, "x", "y"));
        assertFalse(ArrayUtils.containsAny((Object[]) null, "a"));
    }

    @Test
    void testGet() {
        final String[] array = { "a", "b", "c" };
        assertEquals("b", ArrayUtils.get(array, 1));
        assertNull(ArrayUtils.get(array, 5));
        assertNull(ArrayUtils.get((String[]) null, 0));
        assertEquals("default", ArrayUtils.get(array, 10, "default"));
        assertEquals("default", ArrayUtils.get((String[]) null, 0, "default"));
    }

    @Test
    void testGetComponentType() {
        final String[] array = { "a" };
        assertEquals(String.class, ArrayUtils.getComponentType(array));
        assertNull(ArrayUtils.getComponentType((String[]) null));
    }

    @Test
    void testGetDimensions() {
        assertEquals(0, ArrayUtils.getDimensions(null));
        assertEquals(0, ArrayUtils.getDimensions("not an array"));
        assertEquals(1, ArrayUtils.getDimensions(new int[] { 1, 2 }));
        assertEquals(2, ArrayUtils.getDimensions(new int[][] { { 1 }, { 2 } }));
    }

    @Test
    void testGetLength() {
        assertEquals(0, ArrayUtils.getLength(null));
        assertEquals(0, ArrayUtils.getLength(new int[0]));
        assertEquals(3, ArrayUtils.getLength(new int[] { 1, 2, 3 }));
        assertThrows(IllegalArgumentException.class, () -> ArrayUtils.getLength("not an array"));
    }

    @Test
    void testHashCode() {
        assertEquals(ArrayUtils.hashCode(null), ArrayUtils.hashCode(null));
        final int[] array1 = { 1, 2, 3 };
        final int[] array2 = { 1, 2, 3 };
        final int[] array3 = { 3, 2, 1 };
        assertEquals(ArrayUtils.hashCode(array1), ArrayUtils.hashCode(array2));
        assertTrue(ArrayUtils.hashCode(array1) != ArrayUtils.hashCode(array3));
    }

    @Test
    void testIndexesOf() {
        final int[] array = { 1, 2, 1, 3, 1 };
        final BitSet expected = new BitSet();
        expected.set(0);
        expected.set(2);
        expected.set(4);
        assertEquals(expected, ArrayUtils.indexesOf(array, 1));
        assertTrue(ArrayUtils.indexesOf(array, 9).isEmpty());
    }

    @Test
    void testIndexOf() {
        final int[] array = { 1, 2, 3, 2 };
        assertEquals(1, ArrayUtils.indexOf(array, 2));
        assertEquals(3, ArrayUtils.indexOf(array, 2, 2));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf(array, 9));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf((int[]) null, 1));
        assertEquals(1, ArrayUtils.indexOf(new Object[] { "a", "b" }, "b"));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf(new Object[] { "a", "b" }, null));
    }

    @Test
    void testLastIndexOf() {
        final int[] array = { 1, 2, 3, 2 };
        assertEquals(3, ArrayUtils.lastIndexOf(array, 2));
        assertEquals(1, ArrayUtils.lastIndexOf(array, 2, 2));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.lastIndexOf(array, 9));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.lastIndexOf((int[]) null, 1));
    }

    @Test
    void testInsert() {
        final int[] array = { 1, 2, 3 };
        assertArrayEquals(new int[] { 1, 9, 2, 3 }, ArrayUtils.insert(1, array, 9));
        assertNull(ArrayUtils.insert(0, (int[]) null, 1));
        assertThrows(IndexOutOfBoundsException.class, () -> ArrayUtils.insert(-1, array, 9));
        assertThrows(IndexOutOfBoundsException.class, () -> ArrayUtils.insert(4, array, 9));
    }

    @Test
    void testInsertGeneric() {
        final String[] array = { "a", "b" };
        final String[] result = ArrayUtils.insert(1, array, "x", "y");
        assertArrayEquals(new String[] { "a", "x", "y", "b" }, result);
        assertNull(ArrayUtils.insert(0, (String[]) null, "a"));
    }

    @Test
    void testIsArrayIndexValid() {
        assertFalse(ArrayUtils.isArrayIndexValid(null, 0));
        assertFalse(ArrayUtils.isArrayIndexValid(new String[0], 0));
        assertTrue(ArrayUtils.isArrayIndexValid(new String[] { "a" }, 0));
        assertFalse(ArrayUtils.isArrayIndexValid(new String[] { "a" }, 1));
        assertFalse(ArrayUtils.isArrayIndexValid(new String[] { "a" }, -1));
    }

    @Test
    void testIsEmptyAndIsNotEmpty() {
        assertTrue(ArrayUtils.isEmpty((int[]) null));
        assertTrue(ArrayUtils.isEmpty(new int[0]));
        assertFalse(ArrayUtils.isEmpty(new int[] { 1 }));
        assertFalse(ArrayUtils.isNotEmpty((Object[]) null));
        assertTrue(ArrayUtils.isNotEmpty(new Object[] { "a" }));
    }

    @Test
    void testIsEquals() {
        assertTrue(ArrayUtils.isEquals(new int[] { 1, 2 }, new int[] { 1, 2 }));
        assertFalse(ArrayUtils.isEquals(new int[] { 1, 2 }, new int[] { 1, 3 }));
        assertTrue(ArrayUtils.isEquals(null, null));
    }

    @Test
    void testIsSameLength() {
        assertTrue(ArrayUtils.isSameLength(new int[] { 1, 2 }, new int[] { 3, 4 }));
        assertFalse(ArrayUtils.isSameLength(new int[] { 1 }, new int[] { 3, 4 }));
        assertTrue(ArrayUtils.isSameLength((Object[]) null, (Object[]) null));
    }

    @Test
    void testIsSameType() {
        assertTrue(ArrayUtils.isSameType(new int[0], new int[0]));
        assertFalse(ArrayUtils.isSameType(new int[0], new long[0]));
        assertThrows(IllegalArgumentException.class, () -> ArrayUtils.isSameType(null, new int[0]));
    }

    @Test
    void testIsSorted() {
        assertTrue(ArrayUtils.isSorted(new int[] { 1, 2, 3 }));
        assertFalse(ArrayUtils.isSorted(new int[] { 3, 2, 1 }));
        assertTrue(ArrayUtils.isSorted(new int[0]));
        assertTrue(ArrayUtils.isSorted((int[]) null));
    }

    @Test
    void testNewInstance() {
        final String[] array = ArrayUtils.newInstance(String.class, 3);
        assertEquals(3, array.length);
        assertEquals(String.class, array.getClass().getComponentType());
    }

    @Test
    void testNullTo() {
        final String[] defaultArray = { "d" };
        assertSame(defaultArray, ArrayUtils.nullTo(null, defaultArray));
        final String[] array = { "a" };
        assertSame(array, ArrayUtils.nullTo(array, defaultArray));
    }

    @Test
    void testNullToEmpty() {
        assertArrayEquals(ArrayUtils.EMPTY_INT_ARRAY, ArrayUtils.nullToEmpty((int[]) null));
        final int[] array = { 1, 2 };
        assertSame(array, ArrayUtils.nullToEmpty(array));
        assertArrayEquals(ArrayUtils.EMPTY_STRING_ARRAY, ArrayUtils.nullToEmpty((String[]) null));
    }

    @Test
    void testRemoveIndex() {
        final int[] array = { 1, 2, 3 };
        assertArrayEquals(new int[] { 1, 3 }, ArrayUtils.remove(array, 1));
        assertThrows(IndexOutOfBoundsException.class, () -> ArrayUtils.remove(array, -1));
        assertThrows(IndexOutOfBoundsException.class, () -> ArrayUtils.remove(array, 3));
        assertThrows(IndexOutOfBoundsException.class, () -> ArrayUtils.remove((int[]) null, 0));
    }

    @Test
    void testRemoveAllIndices() {
        final int[] array = { 1, 2, 3, 4, 5 };
        assertArrayEquals(new int[] { 1, 3, 5 }, ArrayUtils.removeAll(array, 1, 3));
        assertArrayEquals(array, ArrayUtils.removeAll(array));
    }

    @Test
    void testRemoveAllOccurrences() {
        final int[] array = { 1, 2, 1, 3, 1 };
        assertArrayEquals(new int[] { 2, 3 }, ArrayUtils.removeAllOccurrences(array, 1));
        final String[] strArray = { "a", "b", "a" };
        assertArrayEquals(new String[] { "b" }, ArrayUtils.removeAllOccurrences(strArray, "a"));
    }

    @Test
    void testRemoveElement() {
        final int[] array = { 1, 2, 3, 2 };
        assertArrayEquals(new int[] { 1, 3, 2 }, ArrayUtils.removeElement(array, 2));
        assertArrayEquals(array, ArrayUtils.removeElement(array, 9));
        assertNull(ArrayUtils.removeElement((int[]) null, 1));
    }

    @Test
    void testRemoveElements() {
        final int[] array = { 1, 2, 1, 3 };
        assertArrayEquals(new int[] { 2, 3 }, ArrayUtils.removeElements(array, 1, 1));
        assertArrayEquals(array, ArrayUtils.removeElements(array));
    }

    @Test
    void testReverse() {
        final int[] array = { 1, 2, 3 };
        ArrayUtils.reverse(array);
        assertArrayEquals(new int[] { 3, 2, 1 }, array);
        ArrayUtils.reverse((int[]) null);
        final int[] array2 = { 1, 2, 3, 4, 5 };
        ArrayUtils.reverse(array2, 1, 4);
        assertArrayEquals(new int[] { 1, 4, 3, 2, 5 }, array2);
    }

    @Test
    void testSetAll() {
        final Integer[] array = new Integer[5];
        ArrayUtils.setAll(array, i -> i * i);
        assertArrayEquals(new Integer[] { 0, 1, 4, 9, 16 }, array);
    }

    @Test
    void testShift() {
        final int[] array = { 1, 2, 3, 4, 5 };
        ArrayUtils.shift(array, 2);
        assertArrayEquals(new int[] { 4, 5, 1, 2, 3 }, array);
        ArrayUtils.shift((int[]) null, 1);
        final int[] empty = {};
        ArrayUtils.shift(empty, 1);
        assertEquals(0, empty.length);
    }

    @Test
    void testShuffleDoesNotChangeLengthOrElements() {
        final int[] array = { 1, 2, 3, 4, 5 };
        ArrayUtils.shuffle(array, new java.util.Random(42));
        final int[] sorted = ArrayUtils.clone(array);
        java.util.Arrays.sort(sorted);
        assertArrayEquals(new int[] { 1, 2, 3, 4, 5 }, sorted);
    }

    @Test
    void testStartsWith() {
        assertTrue(ArrayUtils.startsWith(new byte[] { 1, 2, 3 }, new byte[] { 1, 2 }));
        assertFalse(ArrayUtils.startsWith(new byte[] { 1, 2, 3 }, new byte[] { 2, 3 }));
        assertFalse(ArrayUtils.startsWith(new byte[] { 1, 2, 3 }, new byte[] { 1, 2, 3, 4 }));
        assertFalse(ArrayUtils.startsWith(null, new byte[] { 1 }));
        assertTrue(ArrayUtils.startsWith(new byte[] { 1, 2, 3 }, new byte[] { 1, 2, 3 }));
    }

    @Test
    void testSubarray() {
        final int[] array = { 1, 2, 3, 4, 5 };
        assertArrayEquals(new int[] { 2, 3 }, ArrayUtils.subarray(array, 1, 3));
        assertArrayEquals(new int[] { 1, 2, 3, 4, 5 }, ArrayUtils.subarray(array, -2, 10));
        assertArrayEquals(new int[0], ArrayUtils.subarray(array, 3, 1));
        assertNull(ArrayUtils.subarray((int[]) null, 0, 1));
        final String[] strArray = { "a", "b", "c" };
        assertArrayEquals(new String[] { "a", "b" }, ArrayUtils.subarray(strArray, 0, 2));
    }

    @Test
    void testSwap() {
        final int[] array = { 1, 2, 3 };
        ArrayUtils.swap(array, 0, 2);
        assertArrayEquals(new int[] { 3, 2, 1 }, array);
        final int[] array2 = { 1, 2, 3 };
        ArrayUtils.swap(array2, 0, 5);
        assertArrayEquals(new int[] { 1, 2, 3 }, array2);
        ArrayUtils.swap((int[]) null, 0, 1);
    }

    @Test
    void testToArray() {
        final String[] array = ArrayUtils.toArray("a", "b", "c");
        assertArrayEquals(new String[] { "a", "b", "c" }, array);
    }

    @Test
    void testToMap() {
        final Map<Object, Object> map = ArrayUtils.toMap(new String[][] { { "k1", "v1" }, { "k2", "v2" } });
        assertEquals(2, map.size());
        assertEquals("v1", map.get("k1"));
        assertNull(ArrayUtils.toMap(null));
        assertThrows(IllegalArgumentException.class, () -> ArrayUtils.toMap(new Object[] { "not an entry" }));
        assertThrows(IllegalArgumentException.class, () -> ArrayUtils.toMap(new Object[] { new String[] { "onlyone" } }));
    }

    @Test
    void testToObject() {
        assertArrayEquals(new Integer[] { 1, 2, 3 }, ArrayUtils.toObject(new int[] { 1, 2, 3 }));
        assertArrayEquals(new Boolean[] { Boolean.TRUE, Boolean.FALSE }, ArrayUtils.toObject(new boolean[] { true, false }));
    }

    @Test
    void testToPrimitiveInt() {
        assertArrayEquals(new int[] { 1, 2, 3 }, ArrayUtils.toPrimitive(new Integer[] { 1, 2, 3 }));
        assertNull(ArrayUtils.toPrimitive((Integer[]) null));
        assertThrows(NullPointerException.class, () -> ArrayUtils.toPrimitive(new Integer[] { 1, null }));
        assertArrayEquals(new int[] { 1, 0 }, ArrayUtils.toPrimitive(new Integer[] { 1, null }, 0));
    }

    @Test
    void testToPrimitiveBoolean() {
        assertArrayEquals(new boolean[] { true, false }, ArrayUtils.toPrimitive(new Boolean[] { true, false }, false));
        assertArrayEquals(new boolean[] { true, true }, ArrayUtils.toPrimitive(new Boolean[] { true, null }, true));
    }

    @Test
    void testToStringMethods() {
        assertEquals("{}", ArrayUtils.toString(null));
        assertEquals("fallback", ArrayUtils.toString(null, "fallback"));
        assertEquals("{1,2,3}", ArrayUtils.toString(new int[] { 1, 2, 3 }));
    }

    @Test
    void testToStringArray() {
        final String[] result = ArrayUtils.toStringArray(new Object[] { 1, "b", null });
        assertArrayEquals(new String[] { "1", "b", "null" }, result);
        assertArrayEquals(new String[] { "1", "b", "N/A" }, ArrayUtils.toStringArray(new Object[] { 1, "b", null }, "N/A"));
        assertNull(ArrayUtils.toStringArray(null));
        assertNull(ArrayUtils.toStringArray(null, "N/A"));
    }
}
