/*
  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      https://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
 */
package org.apache.commons.cli;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.util.Date;

import org.junit.jupiter.api.Test;

/**
 * Tests for {@link Converter}.
 */
class ConverterAgentTest {

    /** Class without a no-arg constructor, used to force a ReflectiveOperationException from Converter.OBJECT. */
    public static final class NoDefaultConstructor {
        public NoDefaultConstructor(final String ignored) {
        }
    }

    @Test
    void testClassConverterSuccess() throws Exception {
        final Class<?> cls = Converter.CLASS.apply(String.class.getName());
        assertEquals(String.class, cls);
    }

    @Test
    void testClassConverterFailure() {
        assertThrows(ClassNotFoundException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.CLASS.apply("no.such.ClassName");
            }
        });
    }

    @Test
    void testDateConverterSuccess() throws Exception {
        final Date date = Converter.DATE.apply("Thu Jun 06 17:48:57 EDT 2002");
        assertNotNull(date);
    }

    @Test
    void testDateConverterUnparseable() {
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.DATE.apply("not a date");
            }
        });
    }

    @Test
    void testDateConverterTrailingGarbageRejected() {
        // Valid prefix followed by extra text must be rejected, not silently truncated.
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.DATE.apply("Thu Jun 06 17:48:57 EDT 2002 extra-garbage");
            }
        });
    }

    @Test
    void testDateConverterOutOfRangeFieldRejected() {
        // Lenient parsing would normally roll "Feb 30" over into March; strict parsing must reject it.
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.DATE.apply("Thu Feb 30 17:48:57 EDT 2002");
            }
        });
    }

    @Test
    void testDefaultConverterIsIdentity() throws Exception {
        final Object value = Converter.DEFAULT.apply("hello");
        assertEquals("hello", value);
    }

    @Test
    void testDefaultConverterEmptyString() throws Exception {
        final Object value = Converter.DEFAULT.apply("");
        assertEquals("", value);
    }

    @Test
    void testFileConverterSuccess() throws Exception {
        final File file = Converter.FILE.apply("some-file.txt");
        assertEquals(new File("some-file.txt"), file);
    }

    @Test
    void testFileConverterNullThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.FILE.apply(null);
            }
        });
    }

    @Test
    void testNumberConverterInteger() throws Exception {
        final Number n = Converter.NUMBER.apply("42");
        assertTrue(n instanceof Long);
        assertEquals(42L, n.longValue());
    }

    @Test
    void testNumberConverterDecimal() throws Exception {
        final Number n = Converter.NUMBER.apply("42.5");
        assertTrue(n instanceof Double);
        assertEquals(42.5d, n.doubleValue(), 0.0d);
    }

    @Test
    void testNumberConverterInvalidThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.NUMBER.apply("not-a-number");
            }
        });
    }

    @Test
    void testNumberConverterInvalidDecimalThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.NUMBER.apply("1.2.3");
            }
        });
    }

    @Test
    void testObjectConverterSuccess() throws Exception {
        final Object obj = Converter.OBJECT.apply(Object.class.getName());
        assertNotNull(obj);
        assertEquals(Object.class, obj.getClass());
    }

    @Test
    void testObjectConverterUnknownClassThrows() {
        assertThrows(ClassNotFoundException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.OBJECT.apply("no.such.ClassName");
            }
        });
    }

    @Test
    void testObjectConverterNoDefaultConstructorThrows() {
        assertThrows(ReflectiveOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.OBJECT.apply(NoDefaultConstructor.class.getName());
            }
        });
    }

    @Test
    void testPathConverterSuccess() throws Exception {
        final Path path = Converter.PATH.apply("some-path.txt");
        assertEquals(Paths.get("some-path.txt"), path);
    }

    @Test
    void testPathConverterInvalidThrows() {
        assertThrows(InvalidPathException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.PATH.apply("some\u0000path.txt");
            }
        });
    }

    @Test
    void testUrlConverterSuccess() throws Exception {
        final URL url = Converter.URL.apply("https://commons.apache.org");
        assertEquals(new URL("https://commons.apache.org"), url);
    }

    @Test
    void testUrlConverterMalformedThrows() {
        assertThrows(MalformedURLException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.URL.apply("not a url");
            }
        });
    }

    /**
     * Exercises the functional interface contract directly with a custom implementation, rather than only the
     * predefined constants.
     */
    @Test
    void testCustomConverterImplementationPropagatesCheckedException() {
        final Converter<Integer, ParseException> doubler = new Converter<Integer, ParseException>() {
            @Override
            public Integer apply(final String string) throws ParseException {
                if (string == null || string.isEmpty()) {
                    throw new ParseException("empty input", 0);
                }
                return Integer.parseInt(string) * 2;
            }
        };

        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                doubler.apply("");
            }
        });

        try {
            final Integer result = doubler.apply("21");
            assertEquals(Integer.valueOf(42), result);
        } catch (final ParseException e) {
            throw new AssertionError("unexpected ParseException", e);
        }
    }

    @Test
    void testDefaultConverterDistinctFromClassConverter() {
        final Object defaultConverter = Converter.DEFAULT;
        final Object classConverter = Converter.CLASS;
        assertFalse(defaultConverter == classConverter);
    }
}
