/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZonedDateTime;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link DateUtils}.
 */
public class DateUtilsAgentTest {

    private Calendar newCalendar(final int year, final int month, final int day, final int hour, final int minute,
        final int second, final int millis) {
        final Calendar c = new GregorianCalendar(year, month, day, hour, minute, second);
        c.set(Calendar.MILLISECOND, millis);
        return c;
    }

    @Test
    public void testConstants() {
        assertEquals(1000L, DateUtils.MILLIS_PER_SECOND);
        assertEquals(60 * 1000L, DateUtils.MILLIS_PER_MINUTE);
        assertEquals(60 * 60 * 1000L, DateUtils.MILLIS_PER_HOUR);
        assertEquals(24 * 60 * 60 * 1000L, DateUtils.MILLIS_PER_DAY);
        assertEquals(1001, DateUtils.SEMI_MONTH);
        assertEquals(1, DateUtils.RANGE_WEEK_SUNDAY);
        assertEquals(2, DateUtils.RANGE_WEEK_MONDAY);
        assertEquals(3, DateUtils.RANGE_WEEK_RELATIVE);
        assertEquals(4, DateUtils.RANGE_WEEK_CENTER);
        assertEquals(5, DateUtils.RANGE_MONTH_SUNDAY);
        assertEquals(6, DateUtils.RANGE_MONTH_MONDAY);
    }

    @Test
    public void testDeprecatedConstructorDoesNotThrow() {
        assertNotNull(new DateUtils());
    }

    @Test
    public void testAddDays() {
        final Date date = newCalendar(2008, Calendar.JUNE, 15, 10, 20, 30, 0).getTime();
        final Date result = DateUtils.addDays(date, 5);
        final Calendar expected = (Calendar) newCalendar(2008, Calendar.JUNE, 15, 10, 20, 30, 0);
        expected.add(Calendar.DATE, 5);
        assertEquals(expected.getTime(), result);
        // original unchanged
        assertEquals(newCalendar(2008, Calendar.JUNE, 15, 10, 20, 30, 0).getTime(), date);
        assertThrows(NullPointerException.class, () -> DateUtils.addDays(null, 1));
    }

    @Test
    public void testAddHoursMinutesSecondsMillisecondsWeeksMonthsYears() {
        final Date date = newCalendar(2008, Calendar.JUNE, 15, 10, 20, 30, 0).getTime();

        final Calendar expectedHours = newCalendar(2008, Calendar.JUNE, 15, 10, 20, 30, 0);
        expectedHours.add(Calendar.HOUR_OF_DAY, 3);
        assertEquals(expectedHours.getTime(), DateUtils.addHours(date, 3));

        final Calendar expectedMinutes = newCalendar(2008, Calendar.JUNE, 15, 10, 20, 30, 0);
        expectedMinutes.add(Calendar.MINUTE, -15);
        assertEquals(expectedMinutes.getTime(), DateUtils.addMinutes(date, -15));

        final Calendar expectedSeconds = newCalendar(2008, Calendar.JUNE, 15, 10, 20, 30, 0);
        expectedSeconds.add(Calendar.SECOND, 45);
        assertEquals(expectedSeconds.getTime(), DateUtils.addSeconds(date, 45));

        final Calendar expectedMillis = newCalendar(2008, Calendar.JUNE, 15, 10, 20, 30, 0);
        expectedMillis.add(Calendar.MILLISECOND, 250);
        assertEquals(expectedMillis.getTime(), DateUtils.addMilliseconds(date, 250));

        final Calendar expectedWeeks = newCalendar(2008, Calendar.JUNE, 15, 10, 20, 30, 0);
        expectedWeeks.add(Calendar.WEEK_OF_YEAR, 2);
        assertEquals(expectedWeeks.getTime(), DateUtils.addWeeks(date, 2));

        final Calendar expectedMonths = newCalendar(2008, Calendar.JUNE, 15, 10, 20, 30, 0);
        expectedMonths.add(Calendar.MONTH, 7);
        assertEquals(expectedMonths.getTime(), DateUtils.addMonths(date, 7));

        final Calendar expectedYears = newCalendar(2008, Calendar.JUNE, 15, 10, 20, 30, 0);
        expectedYears.add(Calendar.YEAR, -1);
        assertEquals(expectedYears.getTime(), DateUtils.addYears(date, -1));

        assertThrows(NullPointerException.class, () -> DateUtils.addHours(null, 1));
        assertThrows(NullPointerException.class, () -> DateUtils.addMinutes(null, 1));
        assertThrows(NullPointerException.class, () -> DateUtils.addSeconds(null, 1));
        assertThrows(NullPointerException.class, () -> DateUtils.addMilliseconds(null, 1));
        assertThrows(NullPointerException.class, () -> DateUtils.addWeeks(null, 1));
        assertThrows(NullPointerException.class, () -> DateUtils.addMonths(null, 1));
        assertThrows(NullPointerException.class, () -> DateUtils.addYears(null, 1));
    }

    @Test
    public void testTruncateCalendar() {
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);

        final Calendar truncatedHour = DateUtils.truncate(cal, Calendar.HOUR_OF_DAY);
        assertEquals(newCalendar(2002, Calendar.MARCH, 28, 13, 0, 0, 0).getTimeInMillis(), truncatedHour.getTimeInMillis());

        final Calendar truncatedMonth = DateUtils.truncate(cal, Calendar.MONTH);
        assertEquals(newCalendar(2002, Calendar.MARCH, 1, 0, 0, 0, 0).getTimeInMillis(), truncatedMonth.getTimeInMillis());

        // original calendar is not mutated
        assertEquals(231, cal.get(Calendar.MILLISECOND));

        // truncating at MILLISECOND is a no-op
        final Calendar truncatedMillis = DateUtils.truncate(cal, Calendar.MILLISECOND);
        assertEquals(cal.getTimeInMillis(), truncatedMillis.getTimeInMillis());

        assertThrows(NullPointerException.class, () -> DateUtils.truncate((Calendar) null, Calendar.YEAR));

        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
            () -> DateUtils.truncate(cal, Calendar.DAY_OF_WEEK));
        assertTrue(ex.getMessage().contains("not supported"));

        final Calendar huge = new GregorianCalendar(280000001, Calendar.JANUARY, 1);
        assertThrows(ArithmeticException.class, () -> DateUtils.truncate(huge, Calendar.YEAR));
    }

    @Test
    public void testTruncateDateAndObjectDispatch() {
        final Date date = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231).getTime();
        final Date truncated = DateUtils.truncate(date, Calendar.MONTH);
        assertEquals(newCalendar(2002, Calendar.MARCH, 1, 0, 0, 0, 0).getTime(), truncated);

        assertThrows(NullPointerException.class, () -> DateUtils.truncate((Date) null, Calendar.YEAR));
        assertThrows(NullPointerException.class, () -> DateUtils.truncate((Object) null, Calendar.YEAR));

        assertEquals(truncated, DateUtils.truncate((Object) date, Calendar.MONTH));
        assertEquals(truncated, DateUtils.truncate((Object) DateUtils.toCalendar(date), Calendar.MONTH));

        final ClassCastException ex = assertThrows(ClassCastException.class, () -> DateUtils.truncate("not a date", Calendar.MONTH));
        assertNotNull(ex.getMessage());
    }

    @Test
    public void testCeilingCalendarAndDate() {
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);

        final Calendar ceilHour = DateUtils.ceiling(cal, Calendar.HOUR_OF_DAY);
        assertEquals(newCalendar(2002, Calendar.MARCH, 28, 14, 0, 0, 0).getTimeInMillis(), ceilHour.getTimeInMillis());

        final Calendar ceilMonth = DateUtils.ceiling(cal, Calendar.MONTH);
        assertEquals(newCalendar(2002, Calendar.APRIL, 1, 0, 0, 0, 0).getTimeInMillis(), ceilMonth.getTimeInMillis());

        final Date date = cal.getTime();
        assertEquals(ceilMonth.getTime(), DateUtils.ceiling(date, Calendar.MONTH));

        assertThrows(NullPointerException.class, () -> DateUtils.ceiling((Calendar) null, Calendar.YEAR));
        assertThrows(NullPointerException.class, () -> DateUtils.ceiling((Date) null, Calendar.YEAR));
        assertThrows(NullPointerException.class, () -> DateUtils.ceiling((Object) null, Calendar.YEAR));
        assertThrows(ClassCastException.class, () -> DateUtils.ceiling(new Object(), Calendar.YEAR));

        final Calendar huge = new GregorianCalendar(280000001, Calendar.JANUARY, 1);
        assertThrows(ArithmeticException.class, () -> DateUtils.ceiling(huge, Calendar.YEAR));
    }

    @Test
    public void testRoundMinuteBoundary() {
        final Calendar roundsUp = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 45, 0);
        final Calendar resultUp = DateUtils.round(roundsUp, Calendar.MINUTE);
        assertEquals(newCalendar(2002, Calendar.MARCH, 28, 13, 46, 0, 0).getTimeInMillis(), resultUp.getTimeInMillis());

        final Calendar roundsDown = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 10, 0);
        final Calendar resultDown = DateUtils.round(roundsDown, Calendar.MINUTE);
        assertEquals(newCalendar(2002, Calendar.MARCH, 28, 13, 45, 0, 0).getTimeInMillis(), resultDown.getTimeInMillis());

        final Date dateUp = roundsUp.getTime();
        assertEquals(resultUp.getTime(), DateUtils.round(dateUp, Calendar.MINUTE));

        assertThrows(NullPointerException.class, () -> DateUtils.round((Calendar) null, Calendar.MINUTE));
        assertThrows(NullPointerException.class, () -> DateUtils.round((Date) null, Calendar.MINUTE));
        assertThrows(NullPointerException.class, () -> DateUtils.round((Object) null, Calendar.MINUTE));
        assertThrows(ClassCastException.class, () -> DateUtils.round(Boolean.TRUE, Calendar.MINUTE));
    }

    @Test
    public void testRoundAndTruncateSemiMonth() {
        final Calendar day1 = newCalendar(2008, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals(newCalendar(2008, Calendar.JANUARY, 1, 0, 0, 0, 0).getTimeInMillis(),
            DateUtils.truncate(day1, DateUtils.SEMI_MONTH).getTimeInMillis());

        final Calendar day20 = newCalendar(2008, Calendar.JANUARY, 20, 0, 0, 0, 0);
        assertEquals(newCalendar(2008, Calendar.JANUARY, 16, 0, 0, 0, 0).getTimeInMillis(),
            DateUtils.truncate(day20, DateUtils.SEMI_MONTH).getTimeInMillis());
        assertEquals(newCalendar(2008, Calendar.FEBRUARY, 1, 0, 0, 0, 0).getTimeInMillis(),
            DateUtils.ceiling(day20, DateUtils.SEMI_MONTH).getTimeInMillis());
    }

    @Test
    public void testGetFragmentInDays() {
        final Calendar jan1 = newCalendar(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        assertEquals(1L, DateUtils.getFragmentInDays(jan1, Calendar.MONTH));

        final Calendar jan6 = newCalendar(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(6L, DateUtils.getFragmentInDays(jan6, Calendar.YEAR));

        final Calendar feb28 = newCalendar(2008, Calendar.FEBRUARY, 28, 0, 0, 0, 0);
        assertEquals(59L, DateUtils.getFragmentInDays(feb28, Calendar.YEAR));
        assertEquals(28L, DateUtils.getFragmentInDays(feb28, Calendar.MONTH));

        // a fragment less than or equal to a DAY field returns 0
        assertEquals(0L, DateUtils.getFragmentInDays(jan1, Calendar.MILLISECOND));

        assertEquals(DateUtils.getFragmentInDays(feb28, Calendar.YEAR), DateUtils.getFragmentInDays(feb28.getTime(), Calendar.YEAR));

        assertThrows(NullPointerException.class, () -> DateUtils.getFragmentInDays((Calendar) null, Calendar.YEAR));
        assertThrows(NullPointerException.class, () -> DateUtils.getFragmentInDays((Date) null, Calendar.YEAR));

        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
            () -> DateUtils.getFragmentInDays(jan1, Calendar.DAY_OF_WEEK));
        assertTrue(ex.getMessage().contains("not supported"));
    }

    @Test
    public void testGetFragmentInHoursMinutesSecondsMilliseconds() {
        final Calendar jan6 = newCalendar(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(127L, DateUtils.getFragmentInHours(jan6, Calendar.MONTH));

        final Calendar jan1 = newCalendar(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        assertEquals(435L, DateUtils.getFragmentInMinutes(jan1, Calendar.MONTH));
        assertEquals(15L, DateUtils.getFragmentInMinutes(jan1, Calendar.HOUR_OF_DAY));
        assertEquals(7635L, DateUtils.getFragmentInMinutes(jan6, Calendar.MONTH));

        final Calendar minute = newCalendar(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        assertEquals(10L, DateUtils.getFragmentInSeconds(minute, Calendar.MINUTE));
        assertEquals(538L, DateUtils.getFragmentInMilliseconds(minute, Calendar.SECOND));

        // Date overloads delegate to the Calendar overloads
        assertEquals(DateUtils.getFragmentInHours(jan6, Calendar.MONTH), DateUtils.getFragmentInHours(jan6.getTime(), Calendar.MONTH));
        assertEquals(DateUtils.getFragmentInMinutes(jan1, Calendar.MONTH), DateUtils.getFragmentInMinutes(jan1.getTime(), Calendar.MONTH));
        assertEquals(DateUtils.getFragmentInSeconds(minute, Calendar.MINUTE), DateUtils.getFragmentInSeconds(minute.getTime(), Calendar.MINUTE));
        assertEquals(DateUtils.getFragmentInMilliseconds(minute, Calendar.SECOND),
            DateUtils.getFragmentInMilliseconds(minute.getTime(), Calendar.SECOND));

        assertThrows(NullPointerException.class, () -> DateUtils.getFragmentInHours((Calendar) null, Calendar.MONTH));
        assertThrows(NullPointerException.class, () -> DateUtils.getFragmentInMinutes((Date) null, Calendar.MONTH));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.getFragmentInSeconds(minute, Calendar.DAY_OF_WEEK));
    }

    @Test
    public void testIsSameDay() {
        final Calendar cal1 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        final Calendar cal2 = newCalendar(2002, Calendar.MARCH, 28, 6, 1, 0, 0);
        assertTrue(DateUtils.isSameDay(cal1, cal2));
        assertTrue(DateUtils.isSameDay(cal1.getTime(), cal2.getTime()));

        final Calendar cal3 = newCalendar(2002, Calendar.MARCH, 12, 13, 45, 0, 0);
        assertFalse(DateUtils.isSameDay(cal1, cal3));

        assertThrows(NullPointerException.class, () -> DateUtils.isSameDay((Calendar) null, cal2));
        assertThrows(NullPointerException.class, () -> DateUtils.isSameDay(cal1, (Calendar) null));
        assertThrows(NullPointerException.class, () -> DateUtils.isSameDay((Date) null, new Date()));
    }

    @Test
    public void testIsSameInstant() {
        final Calendar cal1 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        final Calendar cal2 = (Calendar) cal1.clone();
        assertTrue(DateUtils.isSameInstant(cal1, cal2));
        assertTrue(DateUtils.isSameInstant(cal1.getTime(), cal2.getTime()));

        final Calendar cal3 = newCalendar(2002, Calendar.MARCH, 28, 6, 1, 0, 0);
        assertFalse(DateUtils.isSameInstant(cal1, cal3));

        assertThrows(NullPointerException.class, () -> DateUtils.isSameInstant((Calendar) null, cal2));
        assertThrows(NullPointerException.class, () -> DateUtils.isSameInstant((Date) null, new Date()));
    }

    @Test
    public void testIsSameLocalTime() {
        final Calendar cal1 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 0);
        final Calendar cal2 = (Calendar) cal1.clone();
        assertTrue(DateUtils.isSameLocalTime(cal1, cal2));

        final Calendar cal3 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 2, 0);
        assertFalse(DateUtils.isSameLocalTime(cal1, cal3));

        assertThrows(NullPointerException.class, () -> DateUtils.isSameLocalTime((Calendar) null, cal2));
        assertThrows(NullPointerException.class, () -> DateUtils.isSameLocalTime(cal1, (Calendar) null));
    }

    @Test
    public void testIteratorRangeMonthSunday() {
        final Calendar focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0); // Thursday
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_MONTH_SUNDAY);

        Calendar first = null;
        Calendar last = null;
        int count = 0;
        while (it.hasNext()) {
            last = it.next();
            if (first == null) {
                first = last;
            }
            count++;
        }
        assertEquals(35, count);
        assertEquals(Calendar.SUNDAY, first.get(Calendar.DAY_OF_WEEK));
        assertEquals(Calendar.SATURDAY, last.get(Calendar.DAY_OF_WEEK));
        assertEquals(newCalendar(2002, Calendar.JUNE, 30, 0, 0, 0, 0).getTimeInMillis(), first.getTimeInMillis());
        assertEquals(newCalendar(2002, Calendar.AUGUST, 3, 0, 0, 0, 0).getTimeInMillis(), last.getTimeInMillis());

        assertThrows(NoSuchElementException.class, it::next);
        assertThrows(UnsupportedOperationException.class, it::remove);
    }

    @Test
    public void testIteratorExhaustionAndInvalidStyle() {
        final Calendar focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        int count = 0;
        while (it.hasNext()) {
            it.next();
            count++;
        }
        assertEquals(7, count);
        assertThrows(NoSuchElementException.class, it::next);

        assertThrows(NullPointerException.class, () -> DateUtils.iterator((Calendar) null, DateUtils.RANGE_WEEK_SUNDAY));
        assertThrows(NullPointerException.class, () -> DateUtils.iterator((Date) null, DateUtils.RANGE_WEEK_SUNDAY));
        assertThrows(NullPointerException.class, () -> DateUtils.iterator((Object) null, DateUtils.RANGE_WEEK_SUNDAY));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.iterator(focus, 999));
        assertThrows(ClassCastException.class, () -> DateUtils.iterator("not a date", DateUtils.RANGE_WEEK_SUNDAY));

        final Iterator<?> fromDate = DateUtils.iterator((Object) focus.getTime(), DateUtils.RANGE_WEEK_SUNDAY);
        assertNotNull(fromDate);
    }

    @Test
    public void testParseDate() throws ParseException {
        final Date parsed = DateUtils.parseDate("2008-10-01", "yyyy-MM-dd");
        assertEquals(newCalendar(2008, Calendar.OCTOBER, 1, 0, 0, 0, 0).getTime(), parsed);

        // second pattern in the list matches
        final Date parsedSecondPattern = DateUtils.parseDate("01/10/2008", "yyyy-MM-dd", "dd/MM/yyyy");
        assertEquals(newCalendar(2008, Calendar.OCTOBER, 1, 0, 0, 0, 0).getTime(), parsedSecondPattern);

        assertThrows(ParseException.class, () -> DateUtils.parseDate("not a date", "yyyy-MM-dd"));
        assertThrows(ParseException.class, () -> DateUtils.parseDate("2008-10-01", new String[0]));
        assertThrows(NullPointerException.class, () -> DateUtils.parseDate(null, "yyyy-MM-dd"));
        assertThrows(NullPointerException.class, () -> DateUtils.parseDate("2008-10-01", (String[]) null));
    }

    @Test
    public void testParseDateStrictly() throws ParseException {
        final Date parsed = DateUtils.parseDateStrictly("2008-10-01", "yyyy-MM-dd");
        assertEquals(newCalendar(2008, Calendar.OCTOBER, 1, 0, 0, 0, 0).getTime(), parsed);

        // lenient parsing would accept day 942 by rolling over, strict must reject it
        assertThrows(ParseException.class, () -> DateUtils.parseDateStrictly("2008-02-942", "yyyy-MM-dd"));
        assertDoesNotThrowButRolls("2008-02-942");

        assertThrows(NullPointerException.class, () -> DateUtils.parseDateStrictly(null, "yyyy-MM-dd"));
    }

    private void assertDoesNotThrowButRolls(final String invalidDayStr) {
        try {
            final Date lenientParsed = DateUtils.parseDate(invalidDayStr, "yyyy-MM-dd");
            assertNotNull(lenientParsed);
        } catch (final ParseException e) {
            fail("lenient parseDate should not throw for " + invalidDayStr);
        }
    }

    @Test
    public void testSetDays() {
        final Date date = newCalendar(2008, Calendar.JUNE, 15, 10, 20, 30, 0).getTime();
        assertEquals(newCalendar(2008, Calendar.JUNE, 1, 10, 20, 30, 0).getTime(), DateUtils.setDays(date, 1));
        assertEquals(newCalendar(2008, Calendar.JUNE, 30, 10, 20, 30, 0).getTime(), DateUtils.setDays(date, 30));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setDays(date, 0));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setDays(date, 32));
        assertThrows(NullPointerException.class, () -> DateUtils.setDays(null, 1));
    }

    @Test
    public void testSetHours() {
        final Date date = newCalendar(2008, Calendar.JUNE, 15, 10, 20, 30, 0).getTime();
        assertEquals(newCalendar(2008, Calendar.JUNE, 15, 0, 20, 30, 0).getTime(), DateUtils.setHours(date, 0));
        assertEquals(newCalendar(2008, Calendar.JUNE, 15, 23, 20, 30, 0).getTime(), DateUtils.setHours(date, 23));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setHours(date, -1));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setHours(date, 24));
        assertThrows(NullPointerException.class, () -> DateUtils.setHours(null, 0));
    }

    @Test
    public void testSetMillisecondsAndMinutesAndSeconds() {
        final Date date = newCalendar(2008, Calendar.JUNE, 15, 10, 20, 30, 0).getTime();

        assertEquals(newCalendar(2008, Calendar.JUNE, 15, 10, 20, 30, 0).getTime(), DateUtils.setMilliseconds(date, 0));
        assertEquals(newCalendar(2008, Calendar.JUNE, 15, 10, 20, 30, 999).getTime(), DateUtils.setMilliseconds(date, 999));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setMilliseconds(date, 1000));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setMilliseconds(date, -1));

        assertEquals(newCalendar(2008, Calendar.JUNE, 15, 10, 0, 30, 0).getTime(), DateUtils.setMinutes(date, 0));
        assertEquals(newCalendar(2008, Calendar.JUNE, 15, 10, 59, 30, 0).getTime(), DateUtils.setMinutes(date, 59));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setMinutes(date, 60));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setMinutes(date, -1));

        assertEquals(newCalendar(2008, Calendar.JUNE, 15, 10, 20, 0, 0).getTime(), DateUtils.setSeconds(date, 0));
        assertEquals(newCalendar(2008, Calendar.JUNE, 15, 10, 20, 59, 0).getTime(), DateUtils.setSeconds(date, 59));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setSeconds(date, 60));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setSeconds(date, -1));

        assertThrows(NullPointerException.class, () -> DateUtils.setMilliseconds(null, 0));
        assertThrows(NullPointerException.class, () -> DateUtils.setMinutes(null, 0));
        assertThrows(NullPointerException.class, () -> DateUtils.setSeconds(null, 0));
    }

    @Test
    public void testSetMonthsAndYears() {
        final Date date = newCalendar(2008, Calendar.JUNE, 15, 10, 20, 30, 0).getTime();

        assertEquals(newCalendar(2008, Calendar.JANUARY, 15, 10, 20, 30, 0).getTime(), DateUtils.setMonths(date, 0));
        assertEquals(newCalendar(2008, Calendar.DECEMBER, 15, 10, 20, 30, 0).getTime(), DateUtils.setMonths(date, 11));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setMonths(date, 12));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setMonths(date, -1));

        assertEquals(newCalendar(1999, Calendar.JUNE, 15, 10, 20, 30, 0).getTime(), DateUtils.setYears(date, 1999));

        assertThrows(NullPointerException.class, () -> DateUtils.setMonths(null, 0));
        assertThrows(NullPointerException.class, () -> DateUtils.setYears(null, 2000));
    }

    @Test
    public void testToCalendar() {
        final Date date = newCalendar(2008, Calendar.JUNE, 15, 10, 20, 30, 0).getTime();
        final Calendar cal = DateUtils.toCalendar(date);
        assertEquals(date, cal.getTime());

        final TimeZone tz = TimeZone.getTimeZone("America/Los_Angeles");
        final Calendar calTz = DateUtils.toCalendar(date, tz);
        assertEquals(date, calTz.getTime());
        assertEquals(tz, calTz.getTimeZone());

        assertThrows(NullPointerException.class, () -> DateUtils.toCalendar(null));
        assertThrows(NullPointerException.class, () -> DateUtils.toCalendar(null, tz));
        assertThrows(NullPointerException.class, () -> DateUtils.toCalendar(date, null));
    }

    @Test
    public void testToLocalDateTimeOffsetDateTimeZonedDateTime() {
        final TimeZone tz = TimeZone.getTimeZone("America/Los_Angeles");
        final Date date = newCalendar(2008, Calendar.JUNE, 15, 10, 20, 30, 0).getTime();

        final LocalDateTime ldt = DateUtils.toLocalDateTime(date, tz);
        assertEquals(LocalDateTime.of(2008, 6, 15, 10, 20, 30), ldt);

        final OffsetDateTime odt = DateUtils.toOffsetDateTime(date, tz);
        assertEquals(date.toInstant(), odt.toInstant());

        final ZonedDateTime zdt = DateUtils.toZonedDateTime(date, tz);
        assertEquals(date.toInstant(), zdt.toInstant());
        assertEquals(tz.toZoneId(), zdt.getZone());

        // default time zone overloads should be consistent with the default zone
        assertEquals(DateUtils.toLocalDateTime(date, TimeZone.getDefault()), DateUtils.toLocalDateTime(date));
        assertEquals(DateUtils.toOffsetDateTime(date, TimeZone.getDefault()), DateUtils.toOffsetDateTime(date));
        assertEquals(DateUtils.toZonedDateTime(date, TimeZone.getDefault()), DateUtils.toZonedDateTime(date));
    }

    @Test
    public void testTruncatedCompareToAndEquals() {
        final Date d1 = newCalendar(2008, Calendar.JUNE, 15, 10, 20, 30, 0).getTime();
        final Date d2 = newCalendar(2008, Calendar.JUNE, 15, 23, 59, 59, 0).getTime();

        assertTrue(DateUtils.truncatedEquals(d1, d2, Calendar.DATE));
        assertFalse(DateUtils.truncatedEquals(d1, d2, Calendar.HOUR_OF_DAY));
        assertTrue(DateUtils.truncatedCompareTo(d1, d2, Calendar.HOUR_OF_DAY) < 0);
        assertEquals(0, DateUtils.truncatedCompareTo(d1, d1, Calendar.MILLISECOND));

        final Calendar c1 = DateUtils.toCalendar(d1);
        final Calendar c2 = DateUtils.toCalendar(d2);
        assertTrue(DateUtils.truncatedEquals(c1, c2, Calendar.DATE));
        assertFalse(DateUtils.truncatedEquals(c1, c2, Calendar.HOUR_OF_DAY));
        assertTrue(DateUtils.truncatedCompareTo(c1, c2, Calendar.HOUR_OF_DAY) < 0);
    }
}
