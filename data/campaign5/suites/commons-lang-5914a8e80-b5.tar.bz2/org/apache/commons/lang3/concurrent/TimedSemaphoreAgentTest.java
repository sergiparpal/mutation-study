/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.concurrent;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained test class for {@link TimedSemaphore}.
 */
class TimedSemaphoreAgentTest {

    private boolean waitUntilAcquireCountIsZero(final TimedSemaphore sem, final long timeoutMillis) throws InterruptedException {
        final long deadline = System.currentTimeMillis() + timeoutMillis;
        while (System.currentTimeMillis() < deadline) {
            if (sem.getAcquireCount() == 0 && sem.getLastAcquiresPerPeriod() > 0) {
                return true;
            }
            Thread.sleep(10);
        }
        return sem.getAcquireCount() == 0 && sem.getLastAcquiresPerPeriod() > 0;
    }

    @Test
    void testBuilderCreatesInstanceWithGivenValues() {
        final TimedSemaphore sem = TimedSemaphore.builder().setPeriod(1).setTimeUnit(TimeUnit.SECONDS).setLimit(5).get();
        try {
            assertEquals(1, sem.getPeriod());
            assertEquals(TimeUnit.SECONDS, sem.getUnit());
            assertEquals(5, sem.getLimit());
            assertEquals(0, sem.getAcquireCount());
            assertEquals(5, sem.getAvailablePermits());
            assertEquals(0, sem.getLastAcquiresPerPeriod());
            assertEquals(0.0d, sem.getAverageCallsPerPeriod(), 0.0d);
            assertFalse(sem.isShutdown());
        } finally {
            sem.shutdown();
        }
    }

    @Test
    void testBuilderRejectsZeroPeriod() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                TimedSemaphore.builder().setPeriod(0).setTimeUnit(TimeUnit.SECONDS).setLimit(1).get();
            }
        });
    }

    @Test
    void testBuilderRejectsNegativePeriod() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                TimedSemaphore.builder().setPeriod(-1).setTimeUnit(TimeUnit.SECONDS).setLimit(1).get();
            }
        });
    }

    @Test
    void testBuilderAcceptsMaximumPeriod() {
        final TimedSemaphore sem = TimedSemaphore.builder().setPeriod(Long.MAX_VALUE).setTimeUnit(TimeUnit.SECONDS).setLimit(1).get();
        try {
            assertEquals(Long.MAX_VALUE, sem.getPeriod());
        } finally {
            sem.shutdown();
        }
    }

    @SuppressWarnings("deprecation")
    @Test
    void testDeprecatedConstructor() {
        final TimedSemaphore sem = new TimedSemaphore(1, TimeUnit.SECONDS, 10);
        try {
            assertEquals(1, sem.getPeriod());
            assertEquals(TimeUnit.SECONDS, sem.getUnit());
            assertEquals(10, sem.getLimit());
        } finally {
            sem.shutdown();
        }
    }

    @SuppressWarnings("deprecation")
    @Test
    void testDeprecatedConstructorWithExternalServiceIsNotShutdownByInstance() {
        final ScheduledExecutorService externalService = new ScheduledThreadPoolExecutor(1);
        final TimedSemaphore sem = new TimedSemaphore(externalService, 1, TimeUnit.SECONDS, 3);
        try {
            assertSame(externalService, sem.getExecutorService());
            sem.shutdown();
            assertTrue(sem.isShutdown());
            assertFalse(externalService.isShutdown(), "external executor must not be shut down by the semaphore");
        } finally {
            externalService.shutdownNow();
        }
    }

    @Test
    void testOwnExecutorIsShutdownOnShutdown() {
        final TimedSemaphore sem = TimedSemaphore.builder().setPeriod(1).setTimeUnit(TimeUnit.SECONDS).setLimit(1).get();
        final ScheduledExecutorService service = sem.getExecutorService();
        sem.shutdown();
        assertTrue(service.isShutdown(), "own executor should be shut down");
    }

    @Test
    void testTryAcquireWithinLimit() {
        final TimedSemaphore sem = TimedSemaphore.builder().setPeriod(10).setTimeUnit(TimeUnit.SECONDS).setLimit(3).get();
        try {
            assertTrue(sem.tryAcquire());
            assertEquals(1, sem.getAcquireCount());
            assertTrue(sem.tryAcquire());
            assertEquals(2, sem.getAcquireCount());
            assertTrue(sem.tryAcquire());
            assertEquals(3, sem.getAcquireCount());
            assertEquals(0, sem.getAvailablePermits());
            assertFalse(sem.tryAcquire(), "limit should have been reached");
            assertEquals(3, sem.getAcquireCount(), "failed tryAcquire must not increase the counter");
        } finally {
            sem.shutdown();
        }
    }

    @Test
    void testTryAcquireWithNoLimitAlwaysSucceedsButStillCounts() {
        final TimedSemaphore sem = TimedSemaphore.builder().setPeriod(10).setTimeUnit(TimeUnit.SECONDS).setLimit(TimedSemaphore.NO_LIMIT).get();
        try {
            for (int i = 0; i < 50; i++) {
                assertTrue(sem.tryAcquire(), "call " + i + " should not be blocked when there is no limit");
            }
            assertEquals(50, sem.getAcquireCount());
            assertEquals(TimedSemaphore.NO_LIMIT - 50, sem.getAvailablePermits());
        } finally {
            sem.shutdown();
        }
    }

    @Test
    void testTryAcquireWithNegativeLimitBehavesAsNoLimit() {
        final TimedSemaphore sem = TimedSemaphore.builder().setPeriod(10).setTimeUnit(TimeUnit.SECONDS).setLimit(-5).get();
        try {
            assertTrue(sem.tryAcquire());
            assertTrue(sem.tryAcquire());
            assertEquals(2, sem.getAcquireCount());
            assertEquals(-5 - 2, sem.getAvailablePermits());
        } finally {
            sem.shutdown();
        }
    }

    @Test
    void testSetLimitTakesEffectImmediatelyForBlockedCallers() {
        final TimedSemaphore sem = TimedSemaphore.builder().setPeriod(10).setTimeUnit(TimeUnit.SECONDS).setLimit(2).get();
        try {
            assertTrue(sem.tryAcquire());
            assertTrue(sem.tryAcquire());
            assertFalse(sem.tryAcquire(), "limit of 2 should already be exhausted");
            sem.setLimit(5);
            assertEquals(5, sem.getLimit());
            assertTrue(sem.tryAcquire(), "raising the limit should allow more acquisitions in the same period");
            assertEquals(3, sem.getAcquireCount());
        } finally {
            sem.shutdown();
        }
    }

    @Test
    void testSetLimitToZeroDisablesSemaphore() {
        final TimedSemaphore sem = TimedSemaphore.builder().setPeriod(10).setTimeUnit(TimeUnit.SECONDS).setLimit(1).get();
        try {
            assertTrue(sem.tryAcquire());
            assertFalse(sem.tryAcquire(), "limit of 1 should be exhausted");
            sem.setLimit(TimedSemaphore.NO_LIMIT);
            assertTrue(sem.tryAcquire(), "setting the limit to NO_LIMIT should disable blocking");
        } finally {
            sem.shutdown();
        }
    }

    @Test
    void testEndOfPeriodResetsAcquireCountAndUpdatesStatistics() {
        final TimedSemaphore sem = TimedSemaphore.builder().setPeriod(10).setTimeUnit(TimeUnit.SECONDS).setLimit(5).get();
        try {
            assertTrue(sem.tryAcquire());
            assertTrue(sem.tryAcquire());
            sem.endOfPeriod();
            assertEquals(0, sem.getAcquireCount(), "acquire count must reset at the end of a period");
            assertEquals(2, sem.getLastAcquiresPerPeriod());
            assertEquals(2.0d, sem.getAverageCallsPerPeriod(), 0.0d);

            assertTrue(sem.tryAcquire());
            assertTrue(sem.tryAcquire());
            assertTrue(sem.tryAcquire());
            sem.endOfPeriod();
            assertEquals(0, sem.getAcquireCount());
            assertEquals(3, sem.getLastAcquiresPerPeriod());
            assertEquals(2.5d, sem.getAverageCallsPerPeriod(), 0.0001d, "average should be (2+3)/2 over two periods");
        } finally {
            sem.shutdown();
        }
    }

    @Test
    void testAverageCallsPerPeriodIsZeroWhenNoPeriodHasEndedYet() {
        final TimedSemaphore sem = TimedSemaphore.builder().setPeriod(10).setTimeUnit(TimeUnit.SECONDS).setLimit(5).get();
        try {
            assertEquals(0.0d, sem.getAverageCallsPerPeriod(), 0.0d);
            sem.tryAcquire();
            assertEquals(0.0d, sem.getAverageCallsPerPeriod(), 0.0d, "no period has elapsed yet");
        } finally {
            sem.shutdown();
        }
    }

    @Test
    void testIsShutdownInitiallyFalse() {
        final TimedSemaphore sem = TimedSemaphore.builder().setPeriod(10).setTimeUnit(TimeUnit.SECONDS).setLimit(1).get();
        try {
            assertFalse(sem.isShutdown());
        } finally {
            sem.shutdown();
        }
    }

    @Test
    void testShutdownIsIdempotentAndSafeWithoutAcquire() {
        final TimedSemaphore sem = TimedSemaphore.builder().setPeriod(10).setTimeUnit(TimeUnit.SECONDS).setLimit(1).get();
        sem.shutdown();
        assertTrue(sem.isShutdown());
        sem.shutdown();
        assertTrue(sem.isShutdown(), "calling shutdown twice must not throw and must remain shut down");
    }

    @Test
    void testTryAcquireAfterShutdownThrows() {
        final TimedSemaphore sem = TimedSemaphore.builder().setPeriod(10).setTimeUnit(TimeUnit.SECONDS).setLimit(1).get();
        sem.shutdown();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                sem.tryAcquire();
            }
        });
    }

    @Test
    void testAcquireAfterShutdownThrows() {
        final TimedSemaphore sem = TimedSemaphore.builder().setPeriod(10).setTimeUnit(TimeUnit.SECONDS).setLimit(1).get();
        sem.shutdown();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                sem.acquire();
            }
        });
    }

    @Test
    void testAcquireBlocksSecondCallerUntilPeriodEnds() throws InterruptedException {
        final long periodMillis = 300;
        final TimedSemaphore sem = TimedSemaphore.builder().setPeriod(periodMillis).setTimeUnit(TimeUnit.MILLISECONDS).setLimit(1).get();
        try {
            sem.acquire();
            assertEquals(1, sem.getAcquireCount());

            final CountDownLatch latch = new CountDownLatch(1);
            final Throwable[] error = new Throwable[1];
            final Thread blockedCaller = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        sem.acquire();
                        latch.countDown();
                    } catch (final Throwable t) {
                        error[0] = t;
                    }
                }
            });
            blockedCaller.start();

            assertFalse(latch.await(periodMillis / 3, TimeUnit.MILLISECONDS), "second caller should still be blocked");
            assertTrue(latch.await(periodMillis * 10, TimeUnit.MILLISECONDS), "second caller should unblock once the period ends");
            blockedCaller.join(periodMillis * 10);
            assertNull(error[0], "blocked caller must not have thrown");
        } finally {
            sem.shutdown();
        }
    }

    @Test
    void testTimerFiresAndResetsCountAutomatically() throws InterruptedException {
        final long periodMillis = 150;
        final TimedSemaphore sem = TimedSemaphore.builder().setPeriod(periodMillis).setTimeUnit(TimeUnit.MILLISECONDS).setLimit(2).get();
        try {
            assertTrue(sem.tryAcquire());
            assertTrue(sem.tryAcquire());
            assertEquals(2, sem.getAcquireCount());

            final boolean reset = waitUntilAcquireCountIsZero(sem, periodMillis * 20);
            assertTrue(reset, "acquire count should have been reset automatically by the internal timer");
            assertEquals(2, sem.getLastAcquiresPerPeriod());
            assertEquals(2.0d, sem.getAverageCallsPerPeriod(), 0.0001d);
        } finally {
            sem.shutdown();
        }
    }

    @Test
    void testGetAvailablePermitsReflectsCurrentUsage() {
        final TimedSemaphore sem = TimedSemaphore.builder().setPeriod(10).setTimeUnit(TimeUnit.SECONDS).setLimit(4).get();
        try {
            assertEquals(4, sem.getAvailablePermits());
            sem.tryAcquire();
            assertEquals(3, sem.getAvailablePermits());
            sem.tryAcquire();
            sem.tryAcquire();
            sem.tryAcquire();
            assertEquals(0, sem.getAvailablePermits());
            assertFalse(sem.tryAcquire());
            assertEquals(0, sem.getAvailablePermits());
        } finally {
            sem.shutdown();
        }
    }
}
