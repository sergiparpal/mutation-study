/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.BitSet;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link ArrayUtils}.
 */
class ArrayUtilsAgentTest {

    // -------------------- isEmpty / isNotEmpty --------------------

    @Test
    void testIsEmptyNull() {
        assertTrue(ArrayUtils.isEmpty((Object[]) null));
        assertTrue(ArrayUtils.isEmpty((int[]) null));
        assertTrue(ArrayUtils.isEmpty((boolean[]) null));
        assertTrue(ArrayUtils.isEmpty((byte[]) null));
        assertTrue(ArrayUtils.isEmpty((char[]) null));
        assertTrue(ArrayUtils.isEmpty((double[]) null));
        assertTrue(ArrayUtils.isEmpty((float[]) null));
        assertTrue(ArrayUtils.isEmpty((long[]) null));
        assertTrue(ArrayUtils.isEmpty((short[]) null));
    }

    @Test
    void testIsEmptyEmptyAndNonEmpty() {
        assertTrue(ArrayUtils.isEmpty(new Object[0]));
        assertFalse(ArrayUtils.isEmpty(new Object[] { "a" }));
        assertTrue(ArrayUtils.isEmpty(new int[0]));
        assertFalse(ArrayUtils.isEmpty(new int[] { 1 }));
    }

    @Test
    void testIsNotEmpty() {
        assertFalse(ArrayUtils.isNotEmpty((Object[]) null));
        assertFalse(ArrayUtils.isNotEmpty(new String[0]));
        assertTrue(ArrayUtils.isNotEmpty(new String[] { "x" }));
        assertFalse(ArrayUtils.isNotEmpty((int[]) null));
        assertTrue(ArrayUtils.isNotEmpty(new int[] { 1 }));
    }

    // -------------------- getLength / getComponentType --------------------

    @Test
    void testGetLength() {
        assertEquals(0, ArrayUtils.getLength(null));
        assertEquals(0, ArrayUtils.getLength(new Object[0]));
        assertEquals(3, ArrayUtils.getLength(new int[] { 1, 2, 3 }));
        assertEquals(2, ArrayUtils.getLength(new int[][] { { 1 }, { 2 } }));
    }

    @Test
    void testGetComponentType() {
        assertEquals(String.class, ArrayUtils.getComponentType(new String[0]));
        assertNull(ArrayUtils.getComponentType(null));
    }

    // -------------------- add --------------------

    @Test
    void testAddObjectToNullArray() {
        final Object[] result = ArrayUtils.add((Object[]) null, "a");
        assertArrayEquals(new Object[] { "a" }, result);
    }

    @Test
    void testAddIntArray() {
        final int[] result = ArrayUtils.add(new int[] { 1, 2 }, 3);
        assertArrayEquals(new int[] { 1, 2, 3 }, result);
    }

    @Test
    void testAddAtIndex() {
        final int[] result = ArrayUtils.add(new int[] { 1, 2, 3 }, 1, 99);
        assertArrayEquals(new int[] { 1, 99, 2, 3 }, result);
    }

    @Test
    void testAddAtIndexOutOfBounds() {
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.add(new int[] { 1, 2 }, 5, 99);
            }
        });
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.add(new int[] { 1, 2 }, -1, 99);
            }
        });
    }

    @Test
    void testAddNullValueToTypedArray() {
        final String[] base = { "a", "b" };
        final String[] result = ArrayUtils.add(base, (String) null);
        assertArrayEquals(new String[] { "a", "b", null }, result);
    }

    // -------------------- addAll --------------------

    @Test
    void testAddAllBothNull() {
        assertNull(ArrayUtils.addAll((Object[]) null, (Object[]) null));
    }

    @Test
    void testAddAllFirstNull() {
        final String[] array2 = { "a", "b" };
        final String[] result = ArrayUtils.addAll((String[]) null, array2);
        assertArrayEquals(new String[] { "a", "b" }, result);
        assertNotSame(array2, result);
    }

    @Test
    void testAddAllIntArrays() {
        final int[] result = ArrayUtils.addAll(new int[] { 1, 2 }, 3, 4);
        assertArrayEquals(new int[] { 1, 2, 3, 4 }, result);
    }

    // -------------------- clone --------------------

    @Test
    void testCloneNull() {
        assertNull(ArrayUtils.clone((Object[]) null));
        assertNull(ArrayUtils.clone((int[]) null));
    }

    @Test
    void testCloneProducesIndependentCopy() {
        final int[] original = { 1, 2, 3 };
        final int[] cloned = ArrayUtils.clone(original);
        assertArrayEquals(original, cloned);
        assertNotSame(original, cloned);
        cloned[0] = 99;
        assertEquals(1, original[0]);
    }

    // -------------------- contains --------------------

    @Test
    void testContainsNullArray() {
        assertFalse(ArrayUtils.contains((Object[]) null, "a"));
        assertFalse(ArrayUtils.contains((int[]) null, 1));
    }

    @Test
    void testContainsFoundAndNotFound() {
        final Object[] array = { "a", "b", null };
        assertTrue(ArrayUtils.contains(array, "a"));
        assertTrue(ArrayUtils.contains(array, null));
        assertFalse(ArrayUtils.contains(array, "z"));
    }

    @Test
    void testContainsDoubleWithTolerance() {
        final double[] array = { 1.0, 2.0, 3.0 };
        assertTrue(ArrayUtils.contains(array, 2.05, 0.1));
        assertFalse(ArrayUtils.contains(array, 2.5, 0.1));
    }

    // -------------------- indexOf / lastIndexOf / indexesOf --------------------

    @Test
    void testIndexOfNullArray() {
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf((Object[]) null, "x"));
    }

    @Test
    void testIndexOfIntArray() {
        final int[] array = { 1, 2, 3, 2 };
        assertEquals(1, ArrayUtils.indexOf(array, 2));
        assertEquals(3, ArrayUtils.indexOf(array, 2, 2));
        assertEquals(-1, ArrayUtils.indexOf(array, 2, 10));
        assertEquals(1, ArrayUtils.indexOf(array, 2, -5));
    }

    @Test
    void testLastIndexOfIntArray() {
        final int[] array = { 1, 2, 3, 2 };
        assertEquals(3, ArrayUtils.lastIndexOf(array, 2));
        assertEquals(1, ArrayUtils.lastIndexOf(array, 2, 2));
        assertEquals(-1, ArrayUtils.lastIndexOf(array, 2, -1));
        assertEquals(-1, ArrayUtils.lastIndexOf((int[]) null, 2));
    }

    @Test
    void testIndexesOfIntArray() {
        final int[] array = { 1, 2, 1, 2, 1 };
        final BitSet expected = new BitSet();
        expected.set(0);
        expected.set(2);
        expected.set(4);
        assertEquals(expected, ArrayUtils.indexesOf(array, 1));
    }

    @Test
    void testIndexesOfEmptyWhenNotFound() {
        final int[] array = { 1, 2, 3 };
        assertTrue(ArrayUtils.indexesOf(array, 99).isEmpty());
    }

    // -------------------- isSameLength / isSameType --------------------

    @Test
    void testIsSameLength() {
        assertTrue(ArrayUtils.isSameLength((Object[]) null, (Object[]) null));
        assertFalse(ArrayUtils.isSameLength(new Object[1], null));
        assertTrue(ArrayUtils.isSameLength(new Object[] { "a" }, new Object[] { "b" }));
        assertFalse(ArrayUtils.isSameLength(new Object[] { "a" }, new Object[] { "a", "b" }));
    }

    @Test
    void testIsSameTypeThrowsOnNull() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.isSameType(null, new Object[0]);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.isSameType(new Object[0], null);
            }
        });
    }

    @Test
    void testIsSameTypeComparesClasses() {
        assertTrue(ArrayUtils.isSameType(new String[0], new String[0]));
        assertFalse(ArrayUtils.isSameType(new String[0], new Object[0]));
    }

    // -------------------- isSorted --------------------

    @Test
    void testIsSortedIntArray() {
        assertTrue(ArrayUtils.isSorted(new int[] { 1, 2, 3 }));
        assertFalse(ArrayUtils.isSorted(new int[] { 3, 2, 1 }));
        assertTrue(ArrayUtils.isSorted((int[]) null));
        assertTrue(ArrayUtils.isSorted(new int[0]));
        assertTrue(ArrayUtils.isSorted(new int[] { 1 }));
    }

    // -------------------- remove / removeAll / removeElement --------------------

    @Test
    void testRemoveIndex() {
        final int[] result = ArrayUtils.remove(new int[] { 1, 2, 3 }, 1);
        assertArrayEquals(new int[] { 1, 3 }, result);
    }

    @Test
    void testRemoveIndexOutOfBounds() {
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.remove(new int[] { 1, 2, 3 }, 3);
            }
        });
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.remove(new int[] { 1, 2, 3 }, -1);
            }
        });
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.remove(new int[0], 0);
            }
        });
    }

    @Test
    void testRemoveAllIndices() {
        final int[] result = ArrayUtils.removeAll(new int[] { 1, 2, 3, 4, 5 }, 1, 3);
        assertArrayEquals(new int[] { 1, 3, 5 }, result);
    }

    @Test
    void testRemoveElementNotFoundReturnsCopy() {
        final int[] original = { 1, 2, 3 };
        final int[] result = ArrayUtils.removeElement(original, 99);
        assertArrayEquals(original, result);
        assertNotSame(original, result);
    }

    @Test
    void testRemoveElementFound() {
        final int[] result = ArrayUtils.removeElement(new int[] { 1, 2, 3, 2 }, 2);
        assertArrayEquals(new int[] { 1, 3, 2 }, result);
    }

    @Test
    void testRemoveAllOccurrences() {
        final int[] result = ArrayUtils.removeAllOccurrences(new int[] { 1, 2, 1, 3, 1 }, 1);
        assertArrayEquals(new int[] { 2, 3 }, result);
    }

    // -------------------- reverse --------------------

    @Test
    void testReverseFullArray() {
        final int[] array = { 1, 2, 3 };
        ArrayUtils.reverse(array);
        assertArrayEquals(new int[] { 3, 2, 1 }, array);
    }

    @Test
    void testReverseNullIsNoOp() {
        ArrayUtils.reverse((int[]) null);
        // no exception; nothing to assert on a null reference beyond lack of failure
        final Object[] arr = null;
        ArrayUtils.reverse(arr);
    }

    @Test
    void testReverseRange() {
        final int[] array = { 1, 2, 3, 4, 5 };
        ArrayUtils.reverse(array, 1, 4);
        assertArrayEquals(new int[] { 1, 4, 3, 2, 5 }, array);
    }

    // -------------------- swap --------------------

    @Test
    void testSwap() {
        final int[] array = { 1, 2, 3 };
        ArrayUtils.swap(array, 0, 2);
        assertArrayEquals(new int[] { 3, 2, 1 }, array);
    }

    @Test
    void testSwapOutOfBoundsIsSafeNoOp() {
        final int[] array = { 1, 2, 3 };
        ArrayUtils.swap(array, 0, 10);
        assertArrayEquals(new int[] { 1, 2, 3 }, array);
    }

    @Test
    void testSwapNullArrayIsNoOp() {
        ArrayUtils.swap((int[]) null, 0, 1);
    }

    // -------------------- shift --------------------

    @Test
    void testShiftPositiveOffset() {
        final int[] array = { 1, 2, 3, 4, 5 };
        ArrayUtils.shift(array, 2);
        assertArrayEquals(new int[] { 4, 5, 1, 2, 3 }, array);
    }

    @Test
    void testShiftNegativeOffset() {
        final int[] array = { 1, 2, 3, 4, 5 };
        ArrayUtils.shift(array, -1);
        assertArrayEquals(new int[] { 2, 3, 4, 5, 1 }, array);
    }

    @Test
    void testShiftNullOrEmptyIsNoOp() {
        ArrayUtils.shift((int[]) null, 1);
        final int[] empty = {};
        ArrayUtils.shift(empty, 1);
        assertEquals(0, empty.length);
    }

    // -------------------- subarray --------------------

    @Test
    void testSubarrayBasic() {
        final int[] array = { 1, 2, 3, 4, 5 };
        assertArrayEquals(new int[] { 2, 3, 4 }, ArrayUtils.subarray(array, 1, 4));
    }

    @Test
    void testSubarrayClampsOutOfRangeIndices() {
        final int[] array = { 1, 2, 3 };
        assertArrayEquals(new int[] { 1, 2, 3 }, ArrayUtils.subarray(array, -5, 10));
        assertArrayEquals(new int[0], ArrayUtils.subarray(array, 5, 1));
    }

    @Test
    void testSubarrayNullReturnsNull() {
        assertNull(ArrayUtils.subarray((int[]) null, 0, 1));
    }

    // -------------------- startsWith --------------------

    @Test
    void testStartsWith() {
        assertTrue(ArrayUtils.startsWith(new byte[] { 1, 2, 3 }, new byte[] { 1, 2 }));
        assertFalse(ArrayUtils.startsWith(new byte[] { 1, 2, 3 }, new byte[] { 2, 3 }));
        assertFalse(ArrayUtils.startsWith(new byte[] { 1 }, new byte[] { 1, 2 }));
        assertTrue(ArrayUtils.startsWith(new byte[] { 1 }, new byte[0]));
        assertFalse(ArrayUtils.startsWith(null, new byte[] { 1 }));
        assertFalse(ArrayUtils.startsWith(new byte[] { 1 }, null));
    }

    // -------------------- toObject / toPrimitive --------------------

    @Test
    void testToObjectIntArray() {
        final Integer[] result = ArrayUtils.toObject(new int[] { 1, 2, 3 });
        assertArrayEquals(new Integer[] { 1, 2, 3 }, result);
        assertNull(ArrayUtils.toObject((int[]) null));
        assertEquals(0, ArrayUtils.toObject(new int[0]).length);
    }

    @Test
    void testToPrimitiveIntegerArray() {
        final int[] result = ArrayUtils.toPrimitive(new Integer[] { 1, 2, 3 });
        assertArrayEquals(new int[] { 1, 2, 3 }, result);
        assertNull(ArrayUtils.toPrimitive((Integer[]) null));
    }

    @Test
    void testToPrimitiveNullElementThrowsWithoutDefault() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.toPrimitive(new Integer[] { 1, null });
            }
        });
    }

    @Test
    void testToPrimitiveWithDefaultForNull() {
        final int[] result = ArrayUtils.toPrimitive(new Integer[] { 1, null, 3 }, -1);
        assertArrayEquals(new int[] { 1, -1, 3 }, result);
    }

    // -------------------- toMap --------------------

    @Test
    void testToMapNull() {
        assertNull(ArrayUtils.toMap(null));
    }

    @Test
    void testToMapFromPairsArray() {
        final Map<Object, Object> map = ArrayUtils.toMap(new String[][] { { "RED", "#FF0000" }, { "GREEN", "#00FF00" } });
        assertEquals(2, map.size());
        assertEquals("#FF0000", map.get("RED"));
        assertEquals("#00FF00", map.get("GREEN"));
    }

    @Test
    void testToMapInvalidEntryLengthThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.toMap(new String[][] { { "ONLYONE" } });
            }
        });
    }

    @Test
    void testToMapInvalidElementTypeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.toMap(new Object[] { Integer.valueOf(1) });
            }
        });
    }

    // -------------------- toString --------------------

    @Test
    void testToStringNullArray() {
        assertEquals("{}", ArrayUtils.toString(null));
        assertEquals("null-array", ArrayUtils.toString(null, "null-array"));
    }

    @Test
    void testToStringNonNullArray() {
        assertEquals("{1,2,3}", ArrayUtils.toString(new int[] { 1, 2, 3 }));
    }

    // -------------------- toStringArray --------------------

    @Test
    void testToStringArrayNull() {
        assertNull(ArrayUtils.toStringArray(null));
    }

    @Test
    void testToStringArrayDefaultsNullElementToNullString() {
        final String[] result = ArrayUtils.toStringArray(new Object[] { "a", null });
        assertArrayEquals(new String[] { "a", "null" }, result);
    }

    @Test
    void testToStringArrayWithDefaultForNullElement() {
        final String[] result = ArrayUtils.toStringArray(new Object[] { "a", null }, "<null>");
        assertArrayEquals(new String[] { "a", "<null>" }, result);
    }

    // -------------------- isArrayIndexValid --------------------

    @Test
    void testIsArrayIndexValid() {
        final String[] array = { "a", "b" };
        assertTrue(ArrayUtils.isArrayIndexValid(array, 0));
        assertTrue(ArrayUtils.isArrayIndexValid(array, 1));
        assertFalse(ArrayUtils.isArrayIndexValid(array, 2));
        assertFalse(ArrayUtils.isArrayIndexValid(array, -1));
        assertFalse(ArrayUtils.isArrayIndexValid((String[]) null, 0));
    }

    // -------------------- insert --------------------

    @Test
    void testInsertAtIndex() {
        final int[] result = ArrayUtils.insert(1, new int[] { 1, 2, 3 }, 99, 98);
        assertArrayEquals(new int[] { 1, 99, 98, 2, 3 }, result);
    }

    @Test
    void testInsertOutOfBoundsThrows() {
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.insert(5, new int[] { 1, 2 }, 9);
            }
        });
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                ArrayUtils.insert(-1, new int[] { 1, 2 }, 9);
            }
        });
    }

    @Test
    void testInsertNoValuesReturnsClone() {
        final int[] original = { 1, 2, 3 };
        final int[] result = ArrayUtils.insert(1, original);
        assertArrayEquals(original, result);
        assertNotSame(original, result);
    }

    // -------------------- concat --------------------

    @Test
    void testConcatIntArrays() {
        final int[] result = ArrayUtils.concat(new int[] { 1, 2 }, new int[] { 3, 4 }, new int[] { 5 });
        assertArrayEquals(new int[] { 1, 2, 3, 4, 5 }, result);
    }

    @Test
    void testConcatNoArgsReturnsEmpty() {
        assertArrayEquals(new int[0], ArrayUtils.concat(new int[][] {}));
    }

    @Test
    void testConcatWithNullSubArray() {
        final int[] result = ArrayUtils.concat(new int[] { 1 }, null, new int[] { 2 });
        assertArrayEquals(new int[] { 1, 2 }, result);
    }

    // -------------------- hashCode / isEquals --------------------

    @Test
    void testHashCodeNullIsConsistent() {
        final int first = ArrayUtils.hashCode(null);
        final int second = ArrayUtils.hashCode(null);
        assertEquals(first, second);
    }

    @Test
    void testHashCodeEqualArraysMatch() {
        assertEquals(ArrayUtils.hashCode(new int[] { 1, 2, 3 }), ArrayUtils.hashCode(new int[] { 1, 2, 3 }));
    }

    @Test
    void testIsEqualsTwoArrays() {
        assertTrue(ArrayUtils.isEquals(new int[] { 1, 2 }, new int[] { 1, 2 }));
        assertFalse(ArrayUtils.isEquals(new int[] { 1, 2 }, new int[] { 1, 3 }));
        assertTrue(ArrayUtils.isEquals(null, null));
    }

    // -------------------- get --------------------

    @Test
    void testGetWithinAndOutOfBounds() {
        final String[] array = { "a", "b" };
        assertEquals("a", ArrayUtils.get(array, 0));
        assertNull(ArrayUtils.get(array, 5));
        assertNull(ArrayUtils.get(null, 0));
    }

    @Test
    void testGetWithDefault() {
        final String[] array = { "a", "b" };
        assertEquals("b", ArrayUtils.get(array, 1, "default"));
        assertEquals("default", ArrayUtils.get(array, 10, "default"));
        assertEquals("default", ArrayUtils.get(null, 0, "default"));
    }

    // -------------------- nullToEmpty --------------------

    @Test
    void testNullToEmptyIntArray() {
        final int[] result = ArrayUtils.nullToEmpty((int[]) null);
        assertNotNull(result);
        assertEquals(0, result.length);
        final int[] nonEmpty = { 1, 2 };
        assertSame(nonEmpty, ArrayUtils.nullToEmpty(nonEmpty));
    }

    @Test
    void testNullToEmptyObjectArrayWithType() {
        final String[] result = ArrayUtils.nullToEmpty((String[]) null, String[].class);
        assertNotNull(result);
        assertEquals(0, result.length);
    }

    // -------------------- toArray --------------------

    @Test
    void testToArrayVarargs() {
        final String[] result = ArrayUtils.toArray("a", "b", "c");
        assertArrayEquals(new String[] { "a", "b", "c" }, result);
    }

    // -------------------- containsAny --------------------

    @Test
    void testContainsAny() {
        final int[] array = { 1, 2, 3 };
        assertTrue(ArrayUtils.containsAny(array, 5, 2));
        assertFalse(ArrayUtils.containsAny(array, 5, 6));
        assertFalse(ArrayUtils.containsAny((int[]) null, 1));
    }
}
