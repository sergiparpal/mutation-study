/*
  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      https://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
 */
package org.apache.commons.cli;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.text.ParseException;
import java.util.Date;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link Converter}.
 */
class ConverterAgentTest {

    @Test
    void testDefaultReturnsSameString() {
        final Converter<?, RuntimeException> converter = Converter.DEFAULT;
        final Object result = converter.apply("hello");
        assertEquals("hello", result);
        assertNotNull(result);
    }

    @Test
    void testDefaultWithEmptyString() {
        assertEquals("", Converter.DEFAULT.apply(""));
    }

    @Test
    void testClassConverterHappyPath() throws ClassNotFoundException {
        final Class<?> cls = Converter.CLASS.apply(String.class.getName());
        assertEquals(String.class, cls);
    }

    @Test
    void testClassConverterUnknownClassThrows() {
        assertThrows(ClassNotFoundException.class, () -> Converter.CLASS.apply("no.such.Class"));
    }

    @Test
    void testFileConverterHappyPath() {
        final File file = Converter.FILE.apply("some-file.txt");
        assertEquals(new File("some-file.txt"), file);
    }

    @Test
    void testFileConverterNullThrowsNpe() {
        assertThrows(NullPointerException.class, () -> Converter.FILE.apply(null));
    }

    @Test
    void testPathConverterHappyPath() {
        final Path path = Converter.PATH.apply("some-path.txt");
        assertEquals(new File("some-path.txt").toPath(), path);
    }

    @Test
    void testPathConverterInvalidPathThrows() {
        // NUL character is illegal in a path on both POSIX and Windows file systems.
        assertThrows(InvalidPathException.class, () -> Converter.PATH.apply("inva\u0000lid"));
    }

    @Test
    void testNumberConverterInteger() throws NumberFormatException {
        final Number n = Converter.NUMBER.apply("15");
        assertEquals(Long.valueOf(15L), n);
        assertTrue(n instanceof Long);
    }

    @Test
    void testNumberConverterDecimal() throws NumberFormatException {
        final Number n = Converter.NUMBER.apply("1.5");
        assertEquals(Double.valueOf(1.5), n);
        assertTrue(n instanceof Double);
    }

    @Test
    void testNumberConverterInvalidThrows() {
        assertThrows(NumberFormatException.class, () -> Converter.NUMBER.apply("not-a-number"));
    }

    @Test
    void testObjectConverterHappyPath() throws ReflectiveOperationException {
        final Object obj = Converter.OBJECT.apply(Date.class.getName());
        assertTrue(obj instanceof Date);
    }

    @Test
    void testObjectConverterUnknownClassThrows() {
        assertThrows(ReflectiveOperationException.class, () -> Converter.OBJECT.apply("no.such.Class"));
    }

    /** Has only a private constructor, so it cannot be instantiated via the default constructor. */
    public static final class NotInstantiable {
        private NotInstantiable() {
        }
    }

    @Test
    void testObjectConverterNotInstantiableThrows() {
        assertThrows(ReflectiveOperationException.class, () -> Converter.OBJECT.apply(NotInstantiable.class.getName()));
    }

    @Test
    void testUrlConverterHappyPath() throws MalformedURLException {
        final String urlString = "https://commons.apache.org";
        final URL url = Converter.URL.apply(urlString);
        assertEquals(new URL(urlString), url);
    }

    @Test
    void testUrlConverterMalformedThrows() {
        assertThrows(MalformedURLException.class, () -> Converter.URL.apply("malformed-url"));
    }

    @Test
    void testDateConverterHappyPath() throws ParseException {
        final Date date = new Date(1023400137000L);
        final String formatted = new java.text.SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy", java.util.Locale.ENGLISH).format(date);
        final Date parsed = Converter.DATE.apply(formatted);
        assertEquals(date, parsed);
    }

    @Test
    void testDateConverterInvalidThrows() {
        assertThrows(ParseException.class, () -> Converter.DATE.apply("not a date"));
    }

    @Test
    void testFunctionalInterfaceCustomImplementation() throws Exception {
        final Converter<Integer, Exception> doubler = s -> Integer.valueOf(s) * 2;
        assertEquals(Integer.valueOf(10), doubler.apply("5"));
    }

    @Test
    void testCustomImplementationPropagatesCheckedException() {
        final Converter<Integer, ParseException> failing = s -> {
            throw new ParseException("boom", 0);
        };
        final ParseException thrown = assertThrows(ParseException.class, () -> failing.apply("anything"));
        assertEquals("boom", thrown.getMessage());
    }

    @Test
    void testDistinctConstantsAreNotSame() {
        assertNotSame(Converter.FILE, Converter.PATH);
        assertNotSame(Converter.CLASS, Converter.OBJECT);
    }
}
