/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

class DateUtilsAgentTest {

    private static Calendar newCalendar(final int year, final int month, final int day,
            final int hour, final int minute, final int second, final int millis) {
        final Calendar c = Calendar.getInstance();
        c.clear();
        c.set(year, month, day, hour, minute, second);
        c.set(Calendar.MILLISECOND, millis);
        return c;
    }

    private static Date newDate(final int year, final int month, final int day,
            final int hour, final int minute, final int second, final int millis) {
        return newCalendar(year, month, day, hour, minute, second, millis).getTime();
    }

    // ---- constants ----

    @Test
    void testConstants() {
        assertEquals(1000L, DateUtils.MILLIS_PER_SECOND);
        assertEquals(60 * 1000L, DateUtils.MILLIS_PER_MINUTE);
        assertEquals(60 * 60 * 1000L, DateUtils.MILLIS_PER_HOUR);
        assertEquals(24 * 60 * 60 * 1000L, DateUtils.MILLIS_PER_DAY);
        assertEquals(1001, DateUtils.SEMI_MONTH);
        assertEquals(1, DateUtils.RANGE_WEEK_SUNDAY);
        assertEquals(2, DateUtils.RANGE_WEEK_MONDAY);
        assertEquals(3, DateUtils.RANGE_WEEK_RELATIVE);
        assertEquals(4, DateUtils.RANGE_WEEK_CENTER);
        assertEquals(5, DateUtils.RANGE_MONTH_SUNDAY);
        assertEquals(6, DateUtils.RANGE_MONTH_MONDAY);
    }

    @Test
    void testDeprecatedPublicConstructor() {
        assertNotNull(new DateUtils());
    }

    // ---- add* ----

    @Test
    void testAddDays() {
        final Date date = newDate(2020, Calendar.JANUARY, 31, 10, 0, 0, 0);
        final Date result = DateUtils.addDays(date, 1);
        final Calendar c = DateUtils.toCalendar(result);
        assertEquals(Calendar.FEBRUARY, c.get(Calendar.MONTH));
        assertEquals(1, c.get(Calendar.DAY_OF_MONTH));
        // original unchanged
        assertEquals(31, DateUtils.toCalendar(date).get(Calendar.DAY_OF_MONTH));
        final Date negative = DateUtils.addDays(date, -31);
        assertEquals(Calendar.DECEMBER, DateUtils.toCalendar(negative).get(Calendar.MONTH));
    }

    @Test
    void testAddHoursMinutesSecondsMilliseconds() {
        final Date date = newDate(2020, Calendar.JANUARY, 1, 23, 59, 59, 999);
        final Calendar afterHour = DateUtils.toCalendar(DateUtils.addHours(date, 1));
        assertEquals(2, afterHour.get(Calendar.DAY_OF_MONTH));
        assertEquals(0, afterHour.get(Calendar.HOUR_OF_DAY));

        final Calendar afterMinute = DateUtils.toCalendar(DateUtils.addMinutes(date, 1));
        assertEquals(0, afterMinute.get(Calendar.MINUTE));
        assertEquals(0, afterMinute.get(Calendar.HOUR_OF_DAY));

        final Calendar afterSecond = DateUtils.toCalendar(DateUtils.addSeconds(date, 1));
        assertEquals(0, afterSecond.get(Calendar.SECOND));

        final Calendar afterMillis = DateUtils.toCalendar(DateUtils.addMilliseconds(date, 1));
        assertEquals(0, afterMillis.get(Calendar.MILLISECOND));
        assertEquals(2, afterMillis.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testAddMonthsWeeksYears() {
        final Date date = newDate(2020, Calendar.JANUARY, 31, 0, 0, 0, 0);
        final Calendar afterMonth = DateUtils.toCalendar(DateUtils.addMonths(date, 1));
        // Jan 31 + 1 month: Calendar.add() clamps to the last day of February instead of overflowing into March
        assertEquals(Calendar.FEBRUARY, afterMonth.get(Calendar.MONTH));
        assertEquals(29, afterMonth.get(Calendar.DAY_OF_MONTH)); // 2020 is a leap year

        final Date weekBase = newDate(2020, Calendar.JANUARY, 1, 0, 0, 0, 0);
        final Calendar afterWeek = DateUtils.toCalendar(DateUtils.addWeeks(weekBase, 1));
        assertEquals(8, afterWeek.get(Calendar.DAY_OF_MONTH));

        final Calendar afterYear = DateUtils.toCalendar(DateUtils.addYears(weekBase, 1));
        assertEquals(2021, afterYear.get(Calendar.YEAR));

        final Calendar afterNegativeYear = DateUtils.toCalendar(DateUtils.addYears(weekBase, -1));
        assertEquals(2019, afterNegativeYear.get(Calendar.YEAR));
    }

    @Test
    void testAddMethodsNullThrowsNpe() {
        assertThrows(NullPointerException.class, () -> DateUtils.addDays(null, 1));
        assertThrows(NullPointerException.class, () -> DateUtils.addHours(null, 1));
        assertThrows(NullPointerException.class, () -> DateUtils.addMinutes(null, 1));
        assertThrows(NullPointerException.class, () -> DateUtils.addSeconds(null, 1));
        assertThrows(NullPointerException.class, () -> DateUtils.addMilliseconds(null, 1));
        assertThrows(NullPointerException.class, () -> DateUtils.addMonths(null, 1));
        assertThrows(NullPointerException.class, () -> DateUtils.addWeeks(null, 1));
        assertThrows(NullPointerException.class, () -> DateUtils.addYears(null, 1));
    }

    // ---- ceiling / truncate / round (Date, Calendar, Object) ----

    @Test
    void testCeilingDate() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Date hourCeil = DateUtils.ceiling(date, Calendar.HOUR_OF_DAY);
        final Calendar hc = DateUtils.toCalendar(hourCeil);
        assertEquals(14, hc.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, hc.get(Calendar.MINUTE));
        assertEquals(0, hc.get(Calendar.MILLISECOND));

        final Date monthCeil = DateUtils.ceiling(date, Calendar.MONTH);
        final Calendar mc = DateUtils.toCalendar(monthCeil);
        assertEquals(Calendar.APRIL, mc.get(Calendar.MONTH));
        assertEquals(1, mc.get(Calendar.DAY_OF_MONTH));
        assertEquals(0, mc.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    void testCeilingCalendarAndObject() {
        final Calendar calendar = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Calendar result = DateUtils.ceiling(calendar, Calendar.HOUR_OF_DAY);
        assertEquals(14, result.get(Calendar.HOUR_OF_DAY));
        // original calendar must be unchanged (ceiling clones)
        assertEquals(13, calendar.get(Calendar.HOUR_OF_DAY));

        final Date asDate = DateUtils.ceiling((Object) newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231), Calendar.HOUR_OF_DAY);
        assertEquals(14, DateUtils.toCalendar(asDate).get(Calendar.HOUR_OF_DAY));

        final Date asCalendarObject = DateUtils.ceiling((Object) newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231), Calendar.HOUR_OF_DAY);
        assertEquals(14, DateUtils.toCalendar(asCalendarObject).get(Calendar.HOUR_OF_DAY));
    }

    @Test
    void testCeilingErrorCases() {
        assertThrows(NullPointerException.class, () -> DateUtils.ceiling((Date) null, Calendar.HOUR_OF_DAY));
        assertThrows(NullPointerException.class, () -> DateUtils.ceiling((Calendar) null, Calendar.HOUR_OF_DAY));
        assertThrows(NullPointerException.class, () -> DateUtils.ceiling((Object) null, Calendar.HOUR_OF_DAY));
        assertThrows(ClassCastException.class, () -> DateUtils.ceiling("not a date", Calendar.HOUR_OF_DAY));
        assertThrows(IllegalArgumentException.class,
                () -> DateUtils.ceiling(newDate(2020, Calendar.JANUARY, 1, 0, 0, 0, 0), Calendar.ZONE_OFFSET));

        final Calendar hugeYear = newCalendar(1970, Calendar.JANUARY, 1, 0, 0, 0, 0);
        hugeYear.set(Calendar.YEAR, 300000000);
        assertThrows(ArithmeticException.class, () -> DateUtils.ceiling(hugeYear, Calendar.YEAR));
    }

    @Test
    void testTruncateDate() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Date hourTrunc = DateUtils.truncate(date, Calendar.HOUR_OF_DAY);
        final Calendar hc = DateUtils.toCalendar(hourTrunc);
        assertEquals(13, hc.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, hc.get(Calendar.MINUTE));
        assertEquals(0, hc.get(Calendar.MILLISECOND));

        final Date monthTrunc = DateUtils.truncate(date, Calendar.MONTH);
        final Calendar mc = DateUtils.toCalendar(monthTrunc);
        assertEquals(Calendar.MARCH, mc.get(Calendar.MONTH));
        assertEquals(1, mc.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testTruncateCalendarAndObjectAndErrors() {
        final Calendar calendar = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Calendar result = DateUtils.truncate(calendar, Calendar.HOUR_OF_DAY);
        assertEquals(13, result.get(Calendar.HOUR_OF_DAY));
        assertEquals(13, calendar.get(Calendar.HOUR_OF_DAY)); // unchanged original

        final Date asDate = DateUtils.truncate((Object) newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231), Calendar.HOUR_OF_DAY);
        assertEquals(13, DateUtils.toCalendar(asDate).get(Calendar.HOUR_OF_DAY));

        assertThrows(NullPointerException.class, () -> DateUtils.truncate((Date) null, Calendar.HOUR_OF_DAY));
        assertThrows(NullPointerException.class, () -> DateUtils.truncate((Calendar) null, Calendar.HOUR_OF_DAY));
        assertThrows(ClassCastException.class, () -> DateUtils.truncate(Integer.valueOf(1), Calendar.HOUR_OF_DAY));
        assertThrows(IllegalArgumentException.class,
                () -> DateUtils.truncate(newDate(2020, Calendar.JANUARY, 1, 0, 0, 0, 0), Calendar.ZONE_OFFSET));
    }

    @Test
    void testRoundDate() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Date hourRound = DateUtils.round(date, Calendar.HOUR_OF_DAY);
        final Calendar hc = DateUtils.toCalendar(hourRound);
        assertEquals(14, hc.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, hc.get(Calendar.MINUTE));

        final Date earlyHour = newDate(2002, Calendar.MARCH, 28, 13, 10, 0, 0);
        final Calendar earlyRound = DateUtils.toCalendar(DateUtils.round(earlyHour, Calendar.HOUR_OF_DAY));
        assertEquals(13, earlyRound.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    void testRoundCalendarAndObjectAndErrors() {
        final Calendar calendar = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Calendar result = DateUtils.round(calendar, Calendar.HOUR_OF_DAY);
        assertEquals(14, result.get(Calendar.HOUR_OF_DAY));

        final Date asCalendarObject = DateUtils.round((Object) newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231), Calendar.HOUR_OF_DAY);
        assertEquals(14, DateUtils.toCalendar(asCalendarObject).get(Calendar.HOUR_OF_DAY));

        assertThrows(NullPointerException.class, () -> DateUtils.round((Object) null, Calendar.HOUR_OF_DAY));
        assertThrows(ClassCastException.class, () -> DateUtils.round(new Object(), Calendar.HOUR_OF_DAY));
    }

    @Test
    void testRoundSemiMonth() {
        // day 10 -> rounds up to 16th; day 20 -> rounds down to 16th (same month)
        final Date day10 = newDate(2020, Calendar.JUNE, 10, 0, 0, 0, 0);
        final Calendar r10 = DateUtils.toCalendar(DateUtils.round(day10, DateUtils.SEMI_MONTH));
        assertEquals(16, r10.get(Calendar.DAY_OF_MONTH));
        assertEquals(Calendar.JUNE, r10.get(Calendar.MONTH));

        final Date day28 = newDate(2020, Calendar.JUNE, 28, 0, 0, 0, 0);
        final Calendar r28 = DateUtils.toCalendar(DateUtils.round(day28, DateUtils.SEMI_MONTH));
        assertEquals(1, r28.get(Calendar.DAY_OF_MONTH));
        assertEquals(Calendar.JULY, r28.get(Calendar.MONTH));
    }

    // ---- getFragmentIn* ----

    @Test
    void testGetFragmentInDays() {
        final Calendar jan28 = newCalendar(2008, Calendar.JANUARY, 28, 0, 0, 0, 0);
        assertEquals(28, DateUtils.getFragmentInDays(jan28, Calendar.MONTH));
        assertEquals(28, DateUtils.getFragmentInDays(jan28, Calendar.YEAR));

        final Calendar feb28 = newCalendar(2008, Calendar.FEBRUARY, 28, 0, 0, 0, 0);
        assertEquals(59, DateUtils.getFragmentInDays(feb28, Calendar.YEAR));
        assertEquals(0, DateUtils.getFragmentInDays(feb28, Calendar.MILLISECOND));

        assertEquals(28, DateUtils.getFragmentInDays(jan28.getTime(), Calendar.MONTH));
    }

    @Test
    void testGetFragmentInHoursMinutesSecondsMillis() {
        final Calendar cal = newCalendar(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        assertEquals(7, DateUtils.getFragmentInHours(cal, Calendar.DAY_OF_YEAR));
        assertEquals(15, DateUtils.getFragmentInMinutes(cal, Calendar.HOUR_OF_DAY));
        assertEquals(10, DateUtils.getFragmentInSeconds(cal, Calendar.MINUTE));
        assertEquals(538, DateUtils.getFragmentInMilliseconds(cal, Calendar.SECOND));
        assertEquals(10538, DateUtils.getFragmentInMilliseconds(cal, Calendar.MINUTE));

        assertEquals(7, DateUtils.getFragmentInHours(cal.getTime(), Calendar.DAY_OF_YEAR));
        assertEquals(15, DateUtils.getFragmentInMinutes(cal.getTime(), Calendar.HOUR_OF_DAY));
        assertEquals(10, DateUtils.getFragmentInSeconds(cal.getTime(), Calendar.MINUTE));
        assertEquals(538, DateUtils.getFragmentInMilliseconds(cal.getTime(), Calendar.SECOND));
    }

    @Test
    void testGetFragmentUnsupportedAndNull() {
        final Calendar cal = newCalendar(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        assertThrows(IllegalArgumentException.class, () -> DateUtils.getFragmentInDays(cal, Calendar.AM_PM));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.getFragmentInHours(cal.getTime(), Calendar.AM_PM));
        assertThrows(NullPointerException.class, () -> DateUtils.getFragmentInDays((Calendar) null, Calendar.YEAR));
        assertThrows(NullPointerException.class, () -> DateUtils.getFragmentInDays((Date) null, Calendar.YEAR));
    }

    // ---- isSameDay / isSameInstant / isSameLocalTime ----

    @Test
    void testIsSameDay() {
        final Date d1 = newDate(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        final Date d2 = newDate(2002, Calendar.MARCH, 28, 6, 1, 0, 0);
        final Date d3 = newDate(2002, Calendar.MARCH, 12, 13, 45, 0, 0);
        assertTrue(DateUtils.isSameDay(d1, d2));
        assertFalse(DateUtils.isSameDay(d1, d3));
        assertTrue(DateUtils.isSameDay(DateUtils.toCalendar(d1), DateUtils.toCalendar(d2)));
        assertFalse(DateUtils.isSameDay(DateUtils.toCalendar(d1), DateUtils.toCalendar(d3)));

        assertThrows(NullPointerException.class, () -> DateUtils.isSameDay((Date) null, d2));
        assertThrows(NullPointerException.class, () -> DateUtils.isSameDay(d1, (Date) null));
        assertThrows(NullPointerException.class, () -> DateUtils.isSameDay((Calendar) null, DateUtils.toCalendar(d2)));
    }

    @Test
    void testIsSameInstant() {
        final Date d1 = newDate(2002, Calendar.MARCH, 28, 13, 45, 0, 123);
        final Date d2 = newDate(2002, Calendar.MARCH, 28, 13, 45, 0, 123);
        final Date d3 = newDate(2002, Calendar.MARCH, 28, 13, 45, 0, 124);
        assertTrue(DateUtils.isSameInstant(d1, d2));
        assertFalse(DateUtils.isSameInstant(d1, d3));
        assertTrue(DateUtils.isSameInstant(DateUtils.toCalendar(d1), DateUtils.toCalendar(d2)));

        assertThrows(NullPointerException.class, () -> DateUtils.isSameInstant((Date) null, d2));
        assertThrows(NullPointerException.class, () -> DateUtils.isSameInstant((Calendar) null, DateUtils.toCalendar(d2)));
    }

    @Test
    void testIsSameLocalTime() {
        final Calendar cal1 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Calendar cal2 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertTrue(DateUtils.isSameLocalTime(cal1, cal2));

        final Calendar cal3 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 232);
        assertFalse(DateUtils.isSameLocalTime(cal1, cal3));

        assertThrows(NullPointerException.class, () -> DateUtils.isSameLocalTime(null, cal2));
        assertThrows(NullPointerException.class, () -> DateUtils.isSameLocalTime(cal1, null));
    }

    // ---- iterator ----

    @Test
    void testIteratorMonthSundayMatchesJavadocExample() {
        // Thursday, July 4, 2002
        final Calendar focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_MONTH_SUNDAY);
        final List<Calendar> days = new ArrayList<>();
        while (it.hasNext()) {
            days.add(it.next());
        }
        assertEquals(35, days.size()); // 5 full weeks
        final Calendar first = days.get(0);
        assertEquals(2002, first.get(Calendar.YEAR));
        assertEquals(Calendar.JUNE, first.get(Calendar.MONTH));
        assertEquals(30, first.get(Calendar.DAY_OF_MONTH));
        final Calendar last = days.get(days.size() - 1);
        assertEquals(Calendar.AUGUST, last.get(Calendar.MONTH));
        assertEquals(3, last.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testIteratorWeekRangesHaveSevenDays() {
        final Date focus = newDate(2002, Calendar.MARCH, 28, 0, 0, 0, 0);
        assertEquals(7, countIteratorDays(DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY)));
        assertEquals(7, countIteratorDays(DateUtils.iterator(focus, DateUtils.RANGE_WEEK_MONDAY)));
        assertEquals(7, countIteratorDays(DateUtils.iterator(focus, DateUtils.RANGE_WEEK_RELATIVE)));
        assertEquals(7, countIteratorDays(DateUtils.iterator(focus, DateUtils.RANGE_WEEK_CENTER)));
    }

    private static int countIteratorDays(final Iterator<Calendar> it) {
        int count = 0;
        while (it.hasNext()) {
            it.next();
            count++;
        }
        return count;
    }

    @Test
    void testIteratorObjectOverload() {
        final Date focus = newDate(2002, Calendar.MARCH, 28, 0, 0, 0, 0);
        final Iterator<?> fromDate = DateUtils.iterator((Object) focus, DateUtils.RANGE_WEEK_SUNDAY);
        assertTrue(fromDate.hasNext());
        final Iterator<?> fromCalendar = DateUtils.iterator((Object) DateUtils.toCalendar(focus), DateUtils.RANGE_WEEK_SUNDAY);
        assertTrue(fromCalendar.hasNext());
        assertThrows(ClassCastException.class, () -> DateUtils.iterator("not a date", DateUtils.RANGE_WEEK_SUNDAY));
        assertThrows(NullPointerException.class, () -> DateUtils.iterator((Object) null, DateUtils.RANGE_WEEK_SUNDAY));
    }

    @Test
    void testIteratorInvalidRangeStyleAndNull() {
        final Calendar focus = newCalendar(2002, Calendar.MARCH, 28, 0, 0, 0, 0);
        assertThrows(IllegalArgumentException.class, () -> DateUtils.iterator(focus, -1));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.iterator(focus, 999));
        assertThrows(NullPointerException.class, () -> DateUtils.iterator((Calendar) null, DateUtils.RANGE_WEEK_SUNDAY));
    }

    @Test
    void testIteratorExhaustionAndRemove() {
        final Calendar focus = newCalendar(2002, Calendar.MARCH, 28, 0, 0, 0, 0);
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        assertThrows(UnsupportedOperationException.class, it::remove);
        while (it.hasNext()) {
            it.next();
        }
        assertFalse(it.hasNext());
        assertThrows(NoSuchElementException.class, it::next);
    }

    // ---- parseDate / parseDateStrictly ----

    @Test
    void testParseDateSuccessTriesEachPatternInTurn() throws ParseException {
        final Date parsed = DateUtils.parseDate("2009-10-16", "yyyy/MM/dd", "yyyy-MM-dd");
        final Calendar c = DateUtils.toCalendar(parsed);
        assertEquals(2009, c.get(Calendar.YEAR));
        assertEquals(Calendar.OCTOBER, c.get(Calendar.MONTH));
        assertEquals(16, c.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseDateNoMatchingPatternThrows() {
        assertThrows(ParseException.class, () -> DateUtils.parseDate("2009-10-16", "yyyy/MM/dd"));
        assertThrows(ParseException.class, () -> DateUtils.parseDate("2009-10-16"));
        // a prefix match of the pattern isn't enough: the whole string must be consumed
        assertThrows(ParseException.class, () -> DateUtils.parseDate("2009-10-16extra", "yyyy-MM-dd"));
    }

    @Test
    void testParseDateLeniencyRollsOverInvalidDay() throws ParseException {
        final Date parsed = DateUtils.parseDate("2006-02-30", "yyyy-MM-dd");
        final Calendar expected = Calendar.getInstance();
        expected.clear();
        expected.setLenient(true);
        expected.set(2006, Calendar.FEBRUARY, 30, 0, 0, 0);
        assertEquals(expected.getTime(), parsed);
    }

    @Test
    void testParseDateStrictlyRejectsInvalidDay() {
        assertThrows(ParseException.class, () -> DateUtils.parseDateStrictly("2006-02-30", "yyyy-MM-dd"));
    }

    @Test
    void testParseDateStrictlySuccess() throws ParseException {
        final Date parsed = DateUtils.parseDateStrictly("2006-02-20", "yyyy-MM-dd");
        assertEquals(20, DateUtils.toCalendar(parsed).get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseDateNullChecks() {
        assertThrows(NullPointerException.class, () -> DateUtils.parseDate(null, "yyyy-MM-dd"));
        assertThrows(NullPointerException.class, () -> DateUtils.parseDate("2009-10-16", (String[]) null));
        assertThrows(NullPointerException.class, () -> DateUtils.parseDateStrictly(null, "yyyy-MM-dd"));
    }

    // ---- set* ----

    @Test
    void testSetDaysBoundaries() {
        final Date date = newDate(2020, Calendar.JANUARY, 15, 10, 0, 0, 0);
        assertEquals(1, DateUtils.toCalendar(DateUtils.setDays(date, 1)).get(Calendar.DAY_OF_MONTH));
        assertEquals(31, DateUtils.toCalendar(DateUtils.setDays(date, 31)).get(Calendar.DAY_OF_MONTH));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setDays(date, 0));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setDays(date, 32));
        assertThrows(NullPointerException.class, () -> DateUtils.setDays(null, 1));
    }

    @Test
    void testSetHoursBoundaries() {
        final Date date = newDate(2020, Calendar.JANUARY, 15, 10, 0, 0, 0);
        assertEquals(0, DateUtils.toCalendar(DateUtils.setHours(date, 0)).get(Calendar.HOUR_OF_DAY));
        assertEquals(23, DateUtils.toCalendar(DateUtils.setHours(date, 23)).get(Calendar.HOUR_OF_DAY));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setHours(date, -1));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setHours(date, 24));
    }

    @Test
    void testSetMinutesSecondsMillisecondsBoundaries() {
        final Date date = newDate(2020, Calendar.JANUARY, 15, 10, 0, 0, 0);
        assertEquals(59, DateUtils.toCalendar(DateUtils.setMinutes(date, 59)).get(Calendar.MINUTE));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setMinutes(date, 60));

        assertEquals(59, DateUtils.toCalendar(DateUtils.setSeconds(date, 59)).get(Calendar.SECOND));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setSeconds(date, 60));

        assertEquals(999, DateUtils.toCalendar(DateUtils.setMilliseconds(date, 999)).get(Calendar.MILLISECOND));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setMilliseconds(date, 1000));
    }

    @Test
    void testSetMonthsAndYears() {
        final Date date = newDate(2020, Calendar.JANUARY, 15, 10, 0, 0, 0);
        assertEquals(Calendar.DECEMBER, DateUtils.toCalendar(DateUtils.setMonths(date, 11)).get(Calendar.MONTH));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setMonths(date, 12));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setMonths(date, -1));

        assertEquals(1999, DateUtils.toCalendar(DateUtils.setYears(date, 1999)).get(Calendar.YEAR));
    }

    // ---- toCalendar ----

    @Test
    void testToCalendar() {
        final Date date = newDate(2020, Calendar.JANUARY, 15, 10, 0, 0, 0);
        final Calendar c = DateUtils.toCalendar(date);
        assertEquals(date.getTime(), c.getTimeInMillis());

        final TimeZone utc = TimeZone.getTimeZone("UTC");
        final Calendar withTz = DateUtils.toCalendar(date, utc);
        assertEquals(date.getTime(), withTz.getTimeInMillis());
        assertEquals(utc, withTz.getTimeZone());

        assertThrows(NullPointerException.class, () -> DateUtils.toCalendar(null));
        assertThrows(NullPointerException.class, () -> DateUtils.toCalendar(null, utc));
        assertThrows(NullPointerException.class, () -> DateUtils.toCalendar(date, null));
    }

    // ---- toLocalDateTime / toOffsetDateTime / toZonedDateTime ----

    @Test
    void testToLocalDateTimeOffsetDateTimeZonedDateTime() {
        final Date date = newDate(2020, Calendar.JANUARY, 15, 10, 30, 0, 0);
        final TimeZone utc = TimeZone.getTimeZone("UTC");

        final LocalDateTime ldt = DateUtils.toLocalDateTime(date, utc);
        assertEquals(LocalDateTime.ofInstant(date.toInstant(), ZoneId.of("UTC")), ldt);
        assertEquals(DateUtils.toLocalDateTime(date, TimeZone.getDefault()), DateUtils.toLocalDateTime(date));

        final OffsetDateTime odt = DateUtils.toOffsetDateTime(date, utc);
        assertEquals(OffsetDateTime.ofInstant(date.toInstant(), ZoneId.of("UTC")), odt);
        assertEquals(DateUtils.toOffsetDateTime(date, TimeZone.getDefault()), DateUtils.toOffsetDateTime(date));

        final ZonedDateTime zdt = DateUtils.toZonedDateTime(date, utc);
        assertEquals(ZonedDateTime.ofInstant(date.toInstant(), ZoneId.of("UTC")), zdt);
        assertEquals(DateUtils.toZonedDateTime(date, TimeZone.getDefault()), DateUtils.toZonedDateTime(date));
    }

    // ---- truncatedCompareTo / truncatedEquals ----

    @Test
    void testTruncatedCompareToAndEquals() {
        final Date d1 = newDate(2020, Calendar.JANUARY, 1, 10, 15, 0, 0);
        final Date d2 = newDate(2020, Calendar.JANUARY, 1, 20, 45, 0, 0);

        assertEquals(0, DateUtils.truncatedCompareTo(d1, d2, Calendar.DATE));
        assertTrue(DateUtils.truncatedEquals(d1, d2, Calendar.DATE));

        assertTrue(DateUtils.truncatedCompareTo(d1, d2, Calendar.HOUR_OF_DAY) < 0);
        assertFalse(DateUtils.truncatedEquals(d1, d2, Calendar.HOUR_OF_DAY));

        final Calendar c1 = DateUtils.toCalendar(d1);
        final Calendar c2 = DateUtils.toCalendar(d2);
        assertEquals(0, DateUtils.truncatedCompareTo(c1, c2, Calendar.DATE));
        assertTrue(DateUtils.truncatedEquals(c1, c2, Calendar.DATE));
        assertTrue(DateUtils.truncatedCompareTo(c2, c1, Calendar.HOUR_OF_DAY) > 0);
    }
}
