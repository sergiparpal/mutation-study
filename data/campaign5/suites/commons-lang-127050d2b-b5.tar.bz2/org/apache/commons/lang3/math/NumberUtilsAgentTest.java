/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link NumberUtils}.
 */
class NumberUtilsAgentTest {

    @Test
    void testConstructor() {
        assertNotNull(new NumberUtils());
    }

    @Test
    void testConstants() {
        assertEquals(0L, NumberUtils.LONG_ZERO.longValue());
        assertEquals(1L, NumberUtils.LONG_ONE.longValue());
        assertEquals(-1L, NumberUtils.LONG_MINUS_ONE.longValue());
        assertEquals(0, NumberUtils.INTEGER_ZERO.intValue());
        assertEquals(1, NumberUtils.INTEGER_ONE.intValue());
        assertEquals(2, NumberUtils.INTEGER_TWO.intValue());
        assertEquals(-1, NumberUtils.INTEGER_MINUS_ONE.intValue());
        assertEquals((short) 0, NumberUtils.SHORT_ZERO.shortValue());
        assertEquals((short) 1, NumberUtils.SHORT_ONE.shortValue());
        assertEquals((short) -1, NumberUtils.SHORT_MINUS_ONE.shortValue());
        assertEquals((byte) 0, NumberUtils.BYTE_ZERO.byteValue());
        assertEquals((byte) 1, NumberUtils.BYTE_ONE.byteValue());
        assertEquals((byte) -1, NumberUtils.BYTE_MINUS_ONE.byteValue());
        assertEquals(0.0d, NumberUtils.DOUBLE_ZERO.doubleValue(), 0.0d);
        assertEquals(1.0d, NumberUtils.DOUBLE_ONE.doubleValue(), 0.0d);
        assertEquals(-1.0d, NumberUtils.DOUBLE_MINUS_ONE.doubleValue(), 0.0d);
        assertEquals(0.0f, NumberUtils.FLOAT_ZERO.floatValue(), 0.0f);
        assertEquals(1.0f, NumberUtils.FLOAT_ONE.floatValue(), 0.0f);
        assertEquals(-1.0f, NumberUtils.FLOAT_MINUS_ONE.floatValue(), 0.0f);
        assertEquals((long) Integer.MAX_VALUE, NumberUtils.LONG_INT_MAX_VALUE.longValue());
        assertEquals((long) Integer.MIN_VALUE, NumberUtils.LONG_INT_MIN_VALUE.longValue());
    }

    @Test
    void testCompareByte() {
        assertEquals(0, NumberUtils.compare((byte) 1, (byte) 1));
        assertTrue(NumberUtils.compare((byte) 1, (byte) 2) < 0);
        assertTrue(NumberUtils.compare((byte) 2, (byte) 1) > 0);
    }

    @Test
    void testCompareInt() {
        assertEquals(0, NumberUtils.compare(1, 1));
        assertTrue(NumberUtils.compare(1, 2) < 0);
        assertTrue(NumberUtils.compare(2, 1) > 0);
    }

    @Test
    void testCompareLong() {
        assertEquals(0, NumberUtils.compare(1L, 1L));
        assertTrue(NumberUtils.compare(1L, 2L) < 0);
        assertTrue(NumberUtils.compare(2L, 1L) > 0);
    }

    @Test
    void testCompareShort() {
        assertEquals(0, NumberUtils.compare((short) 1, (short) 1));
        assertTrue(NumberUtils.compare((short) 1, (short) 2) < 0);
        assertTrue(NumberUtils.compare((short) 2, (short) 1) > 0);
    }

    @Test
    void testCreateBigDecimal() {
        assertNull(NumberUtils.createBigDecimal(null));
        assertEquals(new BigDecimal("1.23"), NumberUtils.createBigDecimal("1.23"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigDecimal("");
            }
        });
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigDecimal("   ");
            }
        });
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigDecimal("not a number");
            }
        });
    }

    @Test
    void testCreateBigInteger() {
        assertNull(NumberUtils.createBigInteger(null));
        assertEquals(new BigInteger("255"), NumberUtils.createBigInteger("255"));
        assertEquals(new BigInteger("255"), NumberUtils.createBigInteger("0xFF"));
        assertEquals(new BigInteger("255"), NumberUtils.createBigInteger("#FF"));
        assertEquals(new BigInteger("8"), NumberUtils.createBigInteger("010"));
        assertEquals(new BigInteger("-255"), NumberUtils.createBigInteger("-0xFF"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigInteger("");
            }
        });
    }

    @Test
    void testCreateDouble() {
        assertNull(NumberUtils.createDouble(null));
        assertEquals(Double.valueOf(1.23d), NumberUtils.createDouble("1.23"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createDouble("not a number");
            }
        });
    }

    @Test
    void testCreateFloat() {
        assertNull(NumberUtils.createFloat(null));
        assertEquals(Float.valueOf(1.23f), NumberUtils.createFloat("1.23"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createFloat("not a number");
            }
        });
    }

    @Test
    void testCreateInteger() {
        assertNull(NumberUtils.createInteger(null));
        assertEquals(Integer.valueOf(12), NumberUtils.createInteger("12"));
        assertEquals(Integer.valueOf(255), NumberUtils.createInteger("0xFF"));
        assertEquals(Integer.valueOf(8), NumberUtils.createInteger("010"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createInteger("not a number");
            }
        });
    }

    @Test
    void testCreateLong() {
        assertNull(NumberUtils.createLong(null));
        assertEquals(Long.valueOf(12L), NumberUtils.createLong("12"));
        assertEquals(Long.valueOf(255L), NumberUtils.createLong("0xFF"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createLong("not a number");
            }
        });
    }

    @Test
    void testCreateNumberNullAndBlank() {
        assertNull(NumberUtils.createNumber(null));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("");
            }
        });
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("   ");
            }
        });
    }

    @Test
    void testCreateNumberIntegral() {
        assertEquals(Integer.valueOf(12345), NumberUtils.createNumber("12345"));
        assertTrue(NumberUtils.createNumber("12345") instanceof Integer);
        assertTrue(NumberUtils.createNumber("" + ((long) Integer.MAX_VALUE + 1L)) instanceof Long);
        final String bigIntStr = "123456789012345678901234567890";
        assertEquals(new BigInteger(bigIntStr), NumberUtils.createNumber(bigIntStr));
        assertTrue(NumberUtils.createNumber(bigIntStr) instanceof BigInteger);
    }

    @Test
    void testCreateNumberHex() {
        assertEquals(Integer.valueOf(255), NumberUtils.createNumber("0xFF"));
        assertTrue(NumberUtils.createNumber("0xFF") instanceof Integer);
        assertTrue(NumberUtils.createNumber("0x" + Long.toHexString(0x100000001L)) instanceof Long);
    }

    @Test
    void testCreateNumberFloatingPoint() {
        assertTrue(NumberUtils.createNumber("1.23") instanceof Float);
        assertEquals(1.23f, NumberUtils.createNumber("1.23").floatValue(), 0.0001f);
        assertTrue(NumberUtils.createNumber("1.23D") instanceof Double);
        assertTrue(NumberUtils.createNumber("1.23F") instanceof Float);
        assertTrue(NumberUtils.createNumber("3L") instanceof Long);
        assertEquals(3L, NumberUtils.createNumber("3L").longValue());
    }

    @Test
    void testCreateNumberInvalid() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("not a number");
            }
        });
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("1.23X");
            }
        });
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("1.2.3");
            }
        });
    }

    @Test
    void testIsCreatable() {
        assertFalse(NumberUtils.isCreatable(null));
        assertFalse(NumberUtils.isCreatable(""));
        assertTrue(NumberUtils.isCreatable("12345"));
        assertTrue(NumberUtils.isCreatable("-12345"));
        assertTrue(NumberUtils.isCreatable("+12345"));
        assertTrue(NumberUtils.isCreatable("0xFF"));
        assertFalse(NumberUtils.isCreatable("0x"));
        assertTrue(NumberUtils.isCreatable("010"));
        assertFalse(NumberUtils.isCreatable("09"));
        assertTrue(NumberUtils.isCreatable("0.1"));
        assertTrue(NumberUtils.isCreatable("1.2e3"));
        assertTrue(NumberUtils.isCreatable("1.2e-3"));
        assertFalse(NumberUtils.isCreatable("1.2e"));
        assertFalse(NumberUtils.isCreatable("--1"));
        assertTrue(NumberUtils.isCreatable("1L"));
        assertFalse(NumberUtils.isCreatable("1.2L"));
        assertFalse(NumberUtils.isCreatable("abc"));
    }

    @Test
    void testIsDigits() {
        assertFalse(NumberUtils.isDigits(null));
        assertFalse(NumberUtils.isDigits(""));
        assertTrue(NumberUtils.isDigits("12345"));
        assertFalse(NumberUtils.isDigits("12.345"));
        assertFalse(NumberUtils.isDigits("-12345"));
        assertFalse(NumberUtils.isDigits("abc"));
    }

    @Test
    void testIsNumberDeprecated() {
        assertTrue(NumberUtils.isNumber("12345"));
        assertFalse(NumberUtils.isNumber("abc"));
    }

    @Test
    void testIsParsable() {
        assertFalse(NumberUtils.isParsable(null));
        assertFalse(NumberUtils.isParsable(""));
        assertTrue(NumberUtils.isParsable("123"));
        assertTrue(NumberUtils.isParsable("1.23"));
        assertTrue(NumberUtils.isParsable("1.2e-5"));
        assertFalse(NumberUtils.isParsable("1.23L"));
        assertFalse(NumberUtils.isParsable("0xFF"));
    }

    @Test
    void testMaxByteArray() {
        assertEquals((byte) 3, NumberUtils.max((byte) 1, (byte) 3, (byte) 2));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max((byte[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max();
            }
        });
    }

    @Test
    void testMaxByteThreeParam() {
        assertEquals((byte) 3, NumberUtils.max((byte) 1, (byte) 3, (byte) 2));
        assertEquals((byte) 3, NumberUtils.max((byte) 3, (byte) 1, (byte) 2));
        assertEquals((byte) 3, NumberUtils.max((byte) 1, (byte) 2, (byte) 3));
    }

    @Test
    void testMaxDoubleArray() {
        assertEquals(3.0d, NumberUtils.max(1.0d, 3.0d, 2.0d), 0.0d);
        assertTrue(Double.isNaN(NumberUtils.max(1.0d, Double.NaN, 2.0d)));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max((double[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new double[0]);
            }
        });
    }

    @Test
    void testMaxDoubleThreeParam() {
        assertEquals(3.0d, NumberUtils.max(1.0d, 2.0d, 3.0d), 0.0d);
    }

    @Test
    void testMaxFloatArray() {
        assertEquals(3.0f, NumberUtils.max(1.0f, 3.0f, 2.0f), 0.0f);
        assertTrue(Float.isNaN(NumberUtils.max(1.0f, Float.NaN, 2.0f)));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max((float[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new float[0]);
            }
        });
    }

    @Test
    void testMaxFloatThreeParam() {
        assertEquals(3.0f, NumberUtils.max(1.0f, 2.0f, 3.0f), 0.0f);
    }

    @Test
    void testMaxIntArray() {
        assertEquals(3, NumberUtils.max(1, 3, 2));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max((int[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new int[0]);
            }
        });
    }

    @Test
    void testMaxIntThreeParam() {
        assertEquals(3, NumberUtils.max(1, 2, 3));
    }

    @Test
    void testMaxLongArray() {
        assertEquals(3L, NumberUtils.max(1L, 3L, 2L));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max((long[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new long[0]);
            }
        });
    }

    @Test
    void testMaxLongThreeParam() {
        assertEquals(3L, NumberUtils.max(1L, 2L, 3L));
    }

    @Test
    void testMaxShortArray() {
        assertEquals((short) 3, NumberUtils.max((short) 1, (short) 3, (short) 2));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max((short[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new short[0]);
            }
        });
    }

    @Test
    void testMaxShortThreeParam() {
        assertEquals((short) 3, NumberUtils.max((short) 1, (short) 2, (short) 3));
    }

    @Test
    void testMinByteArray() {
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 3, (byte) 2));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min((byte[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min();
            }
        });
    }

    @Test
    void testMinByteThreeParam() {
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 3, (byte) 2));
        assertEquals((byte) 1, NumberUtils.min((byte) 3, (byte) 1, (byte) 2));
        assertEquals((byte) 1, NumberUtils.min((byte) 2, (byte) 3, (byte) 1));
    }

    @Test
    void testMinDoubleArray() {
        assertEquals(1.0d, NumberUtils.min(1.0d, 3.0d, 2.0d), 0.0d);
        assertTrue(Double.isNaN(NumberUtils.min(1.0d, Double.NaN, 2.0d)));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min((double[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new double[0]);
            }
        });
    }

    @Test
    void testMinDoubleThreeParam() {
        assertEquals(1.0d, NumberUtils.min(1.0d, 2.0d, 3.0d), 0.0d);
    }

    @Test
    void testMinFloatArray() {
        assertEquals(1.0f, NumberUtils.min(1.0f, 3.0f, 2.0f), 0.0f);
        assertTrue(Float.isNaN(NumberUtils.min(1.0f, Float.NaN, 2.0f)));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min((float[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new float[0]);
            }
        });
    }

    @Test
    void testMinFloatThreeParam() {
        assertEquals(1.0f, NumberUtils.min(1.0f, 2.0f, 3.0f), 0.0f);
    }

    @Test
    void testMinIntArray() {
        assertEquals(1, NumberUtils.min(1, 3, 2));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min((int[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new int[0]);
            }
        });
    }

    @Test
    void testMinIntThreeParam() {
        assertEquals(1, NumberUtils.min(1, 2, 3));
    }

    @Test
    void testMinLongArray() {
        assertEquals(1L, NumberUtils.min(1L, 3L, 2L));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min((long[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new long[0]);
            }
        });
    }

    @Test
    void testMinLongThreeParam() {
        assertEquals(1L, NumberUtils.min(1L, 2L, 3L));
    }

    @Test
    void testMinShortArray() {
        assertEquals((short) 1, NumberUtils.min((short) 1, (short) 3, (short) 2));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min((short[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new short[0]);
            }
        });
    }

    @Test
    void testMinShortThreeParam() {
        assertEquals((short) 1, NumberUtils.min((short) 1, (short) 2, (short) 3));
    }

    @Test
    void testToByte() {
        assertEquals((byte) 0, NumberUtils.toByte(null));
        assertEquals((byte) 0, NumberUtils.toByte(""));
        assertEquals((byte) 1, NumberUtils.toByte("1"));
        assertEquals((byte) 1, NumberUtils.toByte(null, (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("", (byte) 1));
        assertEquals((byte) 2, NumberUtils.toByte("2", (byte) 1));
        assertEquals((byte) 9, NumberUtils.toByte("not a number", (byte) 9));
    }

    @Test
    void testToDoubleBigDecimal() {
        assertEquals(0.0d, NumberUtils.toDouble((BigDecimal) null), 0.0d);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d)), 0.0d);
        assertEquals(1.1d, NumberUtils.toDouble((BigDecimal) null, 1.1d), 0.0d);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d), 1.1d), 0.0d);
    }

    @Test
    void testToDoubleString() {
        assertEquals(0.0d, NumberUtils.toDouble((String) null), 0.0d);
        assertEquals(0.0d, NumberUtils.toDouble(""), 0.0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5"), 0.0d);
        assertEquals(1.1d, NumberUtils.toDouble((String) null, 1.1d), 0.0d);
        assertEquals(1.1d, NumberUtils.toDouble("", 1.1d), 0.0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5", 0.0d), 0.0d);
        assertEquals(9.9d, NumberUtils.toDouble("not a number", 9.9d), 0.0d);
    }

    @Test
    void testToFloat() {
        assertEquals(0.0f, NumberUtils.toFloat(null), 0.0f);
        assertEquals(0.0f, NumberUtils.toFloat(""), 0.0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5"), 0.0f);
        assertEquals(1.1f, NumberUtils.toFloat(null, 1.1f), 0.0f);
        assertEquals(1.1f, NumberUtils.toFloat("", 1.1f), 0.0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5", 0.0f), 0.0f);
        assertEquals(9.9f, NumberUtils.toFloat("not a number", 9.9f), 0.0f);
    }

    @Test
    void testToInt() {
        assertEquals(0, NumberUtils.toInt(null));
        assertEquals(0, NumberUtils.toInt(""));
        assertEquals(1, NumberUtils.toInt("1"));
        assertEquals(1, NumberUtils.toInt(null, 1));
        assertEquals(1, NumberUtils.toInt("", 1));
        assertEquals(2, NumberUtils.toInt("2", 1));
        assertEquals(9, NumberUtils.toInt("not a number", 9));
    }

    @Test
    void testToLong() {
        assertEquals(0L, NumberUtils.toLong(null));
        assertEquals(0L, NumberUtils.toLong(""));
        assertEquals(1L, NumberUtils.toLong("1"));
        assertEquals(1L, NumberUtils.toLong(null, 1L));
        assertEquals(1L, NumberUtils.toLong("", 1L));
        assertEquals(2L, NumberUtils.toLong("2", 1L));
        assertEquals(9L, NumberUtils.toLong("not a number", 9L));
    }

    @Test
    void testToShort() {
        assertEquals((short) 0, NumberUtils.toShort(null));
        assertEquals((short) 0, NumberUtils.toShort(""));
        assertEquals((short) 1, NumberUtils.toShort("1"));
        assertEquals((short) 1, NumberUtils.toShort(null, (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("", (short) 1));
        assertEquals((short) 2, NumberUtils.toShort("2", (short) 1));
        assertEquals((short) 9, NumberUtils.toShort("not a number", (short) 9));
    }

    @Test
    void testToScaledBigDecimalBigDecimal() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.235")));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null, 3, RoundingMode.HALF_UP));
        assertEquals(new BigDecimal("1.235"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.2345"), 3, RoundingMode.HALF_UP));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.235"), 2, null));
    }

    @Test
    void testToScaledBigDecimalDouble() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal(Double.valueOf(1.235d)));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null, 3, RoundingMode.HALF_UP));
        assertEquals(new BigDecimal("1.235"), NumberUtils.toScaledBigDecimal(Double.valueOf(1.2345d), 3, RoundingMode.HALF_UP));
    }

    @Test
    void testToScaledBigDecimalFloat() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal(Float.valueOf(1.235f)));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null, 3, RoundingMode.HALF_UP));
    }

    @Test
    void testToScaledBigDecimalString() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal("1.235"));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null, 3, RoundingMode.HALF_UP));
        assertEquals(new BigDecimal("1.235"), NumberUtils.toScaledBigDecimal("1.2345", 3, RoundingMode.HALF_UP));
    }
}
