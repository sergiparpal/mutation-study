/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link DateUtils}.
 */
class DateUtilsAgentTest {

    private static Calendar newCalendar(final int year, final int month, final int day,
            final int hour, final int minute, final int second, final int millis) {
        final Calendar c = Calendar.getInstance();
        c.clear();
        c.set(year, month, day, hour, minute, second);
        c.set(Calendar.MILLISECOND, millis);
        return c;
    }

    private static Date newDate(final int year, final int month, final int day,
            final int hour, final int minute, final int second, final int millis) {
        return newCalendar(year, month, day, hour, minute, second, millis).getTime();
    }

    // ---- add* ----

    @Test
    void testAddDays() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 0, 0, 0, 0);
        final Date result = DateUtils.addDays(date, 2);
        assertEquals(newDate(2002, Calendar.MARCH, 30, 0, 0, 0, 0), result);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 0, 0, 0, 0), date, "original date unchanged");
    }

    @Test
    void testAddHoursNegativeAmount() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 1, 0, 0, 0);
        final Date result = DateUtils.addHours(date, -2);
        assertEquals(newDate(2002, Calendar.MARCH, 27, 23, 0, 0, 0), result);
    }

    @Test
    void testAddMinutesSecondsMillisecondsWeeksYearsMonths() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 0, 0, 0, 0);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 0, 30, 0, 0), DateUtils.addMinutes(date, 30));
        assertEquals(newDate(2002, Calendar.MARCH, 28, 0, 0, 15, 0), DateUtils.addSeconds(date, 15));
        assertEquals(newDate(2002, Calendar.MARCH, 28, 0, 0, 0, 500), DateUtils.addMilliseconds(date, 500));
        assertEquals(newDate(2002, Calendar.APRIL, 4, 0, 0, 0, 0), DateUtils.addWeeks(date, 1));
        assertEquals(newDate(2003, Calendar.MARCH, 28, 0, 0, 0, 0), DateUtils.addYears(date, 1));
        assertEquals(newDate(2002, Calendar.APRIL, 28, 0, 0, 0, 0), DateUtils.addMonths(date, 1));
    }

    @Test
    void testAddNullThrowsNullPointerException() {
        try {
            DateUtils.addDays(null, 1);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            DateUtils.addHours(null, 1);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            DateUtils.addMinutes(null, 1);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            DateUtils.addSeconds(null, 1);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            DateUtils.addMilliseconds(null, 1);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            DateUtils.addWeeks(null, 1);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            DateUtils.addMonths(null, 1);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            DateUtils.addYears(null, 1);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    // ---- ceiling / round / truncate ----

    @Test
    void testCeilingHourOfDay() {
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Calendar result = DateUtils.ceiling(cal, Calendar.HOUR_OF_DAY);
        assertEquals(newCalendar(2002, Calendar.MARCH, 28, 14, 0, 0, 0), result);
        // original not mutated
        assertEquals(13, cal.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    void testCeilingMonth() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Date result = DateUtils.ceiling(date, Calendar.MONTH);
        assertEquals(newDate(2002, Calendar.APRIL, 1, 0, 0, 0, 0), result);
    }

    @Test
    void testCeilingObjectDispatch() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertEquals(DateUtils.ceiling(date, Calendar.MONTH), DateUtils.ceiling((Object) date, Calendar.MONTH));
        assertEquals(DateUtils.ceiling(cal, Calendar.MONTH).getTime(), DateUtils.ceiling((Object) cal, Calendar.MONTH));
        try {
            DateUtils.ceiling((Object) "not a date", Calendar.MONTH);
            fail("expected ClassCastException");
        } catch (final ClassCastException expected) {
            // expected
        }
        try {
            DateUtils.ceiling((Object) null, Calendar.MONTH);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    void testCeilingAmPmSpecialCase() {
        // hour 5 (not midnight) rounds up to noon
        assertEquals(newCalendar(2002, Calendar.MARCH, 28, 12, 0, 0, 0),
                DateUtils.ceiling(newCalendar(2002, Calendar.MARCH, 28, 5, 10, 0, 0), Calendar.AM_PM));
        // exact midnight stays at midnight (no fractional part to round up)
        assertEquals(newCalendar(2002, Calendar.MARCH, 28, 0, 0, 0, 0),
                DateUtils.ceiling(newCalendar(2002, Calendar.MARCH, 28, 0, 0, 0, 0), Calendar.AM_PM));
    }

    @Test
    void testRoundAndTruncateSemiMonth() {
        final Calendar firstHalf = newCalendar(2002, Calendar.MARCH, 10, 13, 45, 1, 231);
        assertEquals(newCalendar(2002, Calendar.MARCH, 1, 0, 0, 0, 0), DateUtils.truncate(firstHalf, DateUtils.SEMI_MONTH));

        final Calendar secondHalf = newCalendar(2002, Calendar.MARCH, 20, 13, 45, 1, 231);
        assertEquals(newCalendar(2002, Calendar.MARCH, 16, 0, 0, 0, 0), DateUtils.truncate(secondHalf, DateUtils.SEMI_MONTH));

        // day 10 is more than 7 days into the first half, so rounds up to day 16
        final Calendar roundUp = newCalendar(2002, Calendar.MARCH, 10, 13, 45, 1, 231);
        assertEquals(newCalendar(2002, Calendar.MARCH, 16, 0, 0, 0, 0), DateUtils.round(roundUp, DateUtils.SEMI_MONTH));

        // day 1 is the very start, no rounding needed
        final Calendar roundStart = newCalendar(2002, Calendar.MARCH, 1, 13, 45, 1, 0);
        assertEquals(newCalendar(2002, Calendar.MARCH, 1, 0, 0, 0, 0), DateUtils.round(roundStart, DateUtils.SEMI_MONTH));
    }

    @Test
    void testTruncateObjectDispatchAndErrors() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertEquals(DateUtils.truncate(date, Calendar.MONTH), DateUtils.truncate((Object) date, Calendar.MONTH));
        try {
            DateUtils.truncate((Object) Integer.valueOf(1), Calendar.MONTH);
            fail("expected ClassCastException");
        } catch (final ClassCastException expected) {
            // expected
        }
        try {
            DateUtils.truncate((Date) null, Calendar.MONTH);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            DateUtils.truncate((Calendar) null, Calendar.MONTH);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    void testModifyUnsupportedFieldThrowsIllegalArgumentException() {
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        try {
            DateUtils.truncate(cal, Calendar.DAY_OF_WEEK);
            fail("expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
        try {
            DateUtils.round(cal, Calendar.DAY_OF_WEEK);
            fail("expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
        try {
            DateUtils.ceiling(cal, Calendar.DAY_OF_WEEK);
            fail("expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testModifyYearTooLargeThrowsArithmeticException() {
        final Calendar big = Calendar.getInstance();
        big.clear();
        big.set(Calendar.YEAR, 280000001);
        try {
            DateUtils.truncate(big, Calendar.MONTH);
            fail("expected ArithmeticException");
        } catch (final ArithmeticException expected) {
            // expected
        }
        try {
            DateUtils.round(big, Calendar.MONTH);
            fail("expected ArithmeticException");
        } catch (final ArithmeticException expected) {
            // expected
        }
        try {
            DateUtils.ceiling(big, Calendar.MONTH);
            fail("expected ArithmeticException");
        } catch (final ArithmeticException expected) {
            // expected
        }
    }

    // ---- getFragmentIn* ----

    @Test
    void testGetFragmentInHours() {
        final Calendar cal = newCalendar(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(127L, DateUtils.getFragmentInHours(cal, Calendar.MONTH));
        assertEquals(7L, DateUtils.getFragmentInHours(cal, Calendar.DAY_OF_YEAR));
    }

    @Test
    void testGetFragmentInSeconds() {
        final Calendar cal = newCalendar(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(26110L, DateUtils.getFragmentInSeconds(cal, Calendar.DAY_OF_YEAR));
        assertEquals(10L, DateUtils.getFragmentInSeconds(cal, Calendar.MINUTE));
    }

    @Test
    void testGetFragmentInMinutesAndMillisecondsAndDays() {
        final Calendar cal = newCalendar(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(7635L, DateUtils.getFragmentInMinutes(cal, Calendar.MONTH));
        assertEquals(10538L, DateUtils.getFragmentInMilliseconds(cal, Calendar.MINUTE));
        // MILLISECOND fragment can never be split further, always 0
        assertEquals(0L, DateUtils.getFragmentInDays(cal, Calendar.MILLISECOND));
        assertEquals(0L, DateUtils.getFragmentInHours(cal, Calendar.MILLISECOND));
        assertEquals(0L, DateUtils.getFragmentInMinutes(cal, Calendar.MILLISECOND));
        assertEquals(0L, DateUtils.getFragmentInSeconds(cal, Calendar.MILLISECOND));
        assertEquals(0L, DateUtils.getFragmentInMilliseconds(cal, Calendar.MILLISECOND));
    }

    @Test
    void testGetFragmentOnDateOverloads() {
        final Date date = newDate(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(127L, DateUtils.getFragmentInHours(date, Calendar.MONTH));
        assertEquals(26110L, DateUtils.getFragmentInSeconds(date, Calendar.DAY_OF_YEAR));
        assertEquals(7635L, DateUtils.getFragmentInMinutes(date, Calendar.MONTH));
        assertEquals(10538L, DateUtils.getFragmentInMilliseconds(date, Calendar.MINUTE));
        assertEquals(6L, DateUtils.getFragmentInDays(date, Calendar.MONTH));
    }

    @Test
    void testGetFragmentUnsupportedThrowsIllegalArgumentException() {
        final Calendar cal = newCalendar(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        try {
            DateUtils.getFragmentInDays(cal, Calendar.ZONE_OFFSET);
            fail("expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
        try {
            DateUtils.getFragmentInHours(cal, Calendar.ZONE_OFFSET);
            fail("expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testGetFragmentNullThrowsNullPointerException() {
        try {
            DateUtils.getFragmentInDays((Calendar) null, Calendar.MONTH);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            DateUtils.getFragmentInDays((Date) null, Calendar.MONTH);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    // ---- isSameDay / isSameInstant / isSameLocalTime ----

    @Test
    void testIsSameDay() {
        final Calendar cal1 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        final Calendar cal2 = newCalendar(2002, Calendar.MARCH, 28, 6, 1, 0, 0);
        assertTrue(DateUtils.isSameDay(cal1, cal2));
        assertTrue(DateUtils.isSameDay(cal1.getTime(), cal2.getTime()));

        final Calendar cal3 = newCalendar(2002, Calendar.MARCH, 12, 13, 45, 0, 0);
        assertFalse(DateUtils.isSameDay(cal1, cal3));
        assertFalse(DateUtils.isSameDay(cal1.getTime(), cal3.getTime()));
    }

    @Test
    void testIsSameDayNullThrowsNullPointerException() {
        final Calendar cal = Calendar.getInstance();
        try {
            DateUtils.isSameDay((Calendar) null, cal);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            DateUtils.isSameDay(cal, (Calendar) null);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            DateUtils.isSameDay((Date) null, cal.getTime());
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    void testIsSameInstant() {
        final Date date1 = newDate(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        final Date date2 = newDate(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        final Date date3 = newDate(2002, Calendar.MARCH, 28, 13, 45, 0, 1);
        assertTrue(DateUtils.isSameInstant(date1, date2));
        assertFalse(DateUtils.isSameInstant(date1, date3));

        final Calendar cal1 = Calendar.getInstance();
        cal1.setTime(date1);
        final Calendar cal2 = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
        cal2.setTime(date1);
        // same instant even though the Calendar implementations carry different time zones
        assertTrue(DateUtils.isSameInstant(cal1, cal2));
    }

    @Test
    void testIsSameInstantNullThrowsNullPointerException() {
        final Date date = new Date();
        try {
            DateUtils.isSameInstant((Date) null, date);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            DateUtils.isSameInstant(date, (Date) null);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    void testIsSameLocalTime() {
        final Calendar cal1 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        final Calendar cal2 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        assertTrue(DateUtils.isSameLocalTime(cal1, cal2));

        final Calendar cal3 = newCalendar(2002, Calendar.MARCH, 28, 13, 46, 0, 0);
        assertFalse(DateUtils.isSameLocalTime(cal1, cal3));

        // same field values, but a different concrete Calendar class disqualifies the match
        final Calendar differentClass = new GregorianCalendar() {
            // anonymous subclass so getClass() differs from GregorianCalendar
        };
        differentClass.clear();
        differentClass.set(2002, Calendar.MARCH, 28, 13, 45, 0);
        assertFalse(DateUtils.isSameLocalTime(cal1, differentClass));
    }

    // ---- iterator ----

    @Test
    void testIteratorRangeWeekSunday() {
        // Thursday, July 4, 2002
        final Calendar focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        int count = 0;
        Calendar first = null;
        Calendar last = null;
        while (it.hasNext()) {
            final Calendar day = it.next();
            if (first == null) {
                first = day;
            }
            last = day;
            count++;
        }
        assertEquals(7, count);
        assertEquals(Calendar.SUNDAY, first.get(Calendar.DAY_OF_WEEK));
        assertEquals(Calendar.SATURDAY, last.get(Calendar.DAY_OF_WEEK));
        try {
            it.next();
            fail("expected NoSuchElementException");
        } catch (final NoSuchElementException expected) {
            // expected
        }
    }

    @Test
    void testIteratorRangeMonthSunday() {
        final Calendar focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_MONTH_SUNDAY);
        int count = 0;
        while (it.hasNext()) {
            it.next();
            count++;
        }
        // whole weeks covering July 2002 starting/ending on Sunday
        assertEquals(0, count % 7);
        assertTrue(count >= 31);
    }

    @Test
    void testIteratorRemoveUnsupported() {
        final Iterator<Calendar> it = DateUtils.iterator(newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0), DateUtils.RANGE_WEEK_SUNDAY);
        try {
            it.remove();
            fail("expected UnsupportedOperationException");
        } catch (final UnsupportedOperationException expected) {
            // expected
        }
    }

    @Test
    void testIteratorInvalidRangeStyleThrowsIllegalArgumentException() {
        final Calendar focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        try {
            DateUtils.iterator(focus, 999);
            fail("expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testIteratorNullThrowsNullPointerException() {
        try {
            DateUtils.iterator((Calendar) null, DateUtils.RANGE_WEEK_SUNDAY);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            DateUtils.iterator((Date) null, DateUtils.RANGE_WEEK_SUNDAY);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            DateUtils.iterator((Object) null, DateUtils.RANGE_WEEK_SUNDAY);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    void testIteratorObjectDispatchInvalidTypeThrowsClassCastException() {
        try {
            DateUtils.iterator("not a date", DateUtils.RANGE_WEEK_SUNDAY);
            fail("expected ClassCastException");
        } catch (final ClassCastException expected) {
            // expected
        }
    }

    // ---- parseDate / parseDateStrictly ----

    @Test
    void testParseDateTriesEachPatternInTurn() throws ParseException {
        final Date parsed = DateUtils.parseDate("2002-03-28", "MM/dd/yyyy", "yyyy-MM-dd");
        final Calendar expected = newCalendar(2002, Calendar.MARCH, 28, 0, 0, 0, 0);
        assertEquals(expected.getTime(), parsed);
    }

    @Test
    void testParseDateLenientAllowsOverflow() throws ParseException {
        // day-of-month 942 overflows but lenient parsing rolls it forward
        final Date parsed = DateUtils.parseDate("February 942, 1996", "MMMM dd, yyyy");
        assertNotNull(parsed);
    }

    @Test
    void testParseDateStrictlyRejectsOverflow() {
        try {
            DateUtils.parseDateStrictly("February 942, 1996", "MMMM dd, yyyy");
            fail("expected ParseException");
        } catch (final ParseException expected) {
            // expected
        }
    }

    @Test
    void testParseDateNoMatchingPatternThrowsParseException() {
        try {
            DateUtils.parseDate("not-a-date", "yyyy-MM-dd");
            fail("expected ParseException");
        } catch (final ParseException expected) {
            // expected
        }
    }

    @Test
    void testParseDateNullThrowsNullPointerException() {
        try {
            DateUtils.parseDate(null, "yyyy-MM-dd");
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        } catch (final ParseException e) {
            fail("expected NullPointerException, got ParseException");
        }
        try {
            DateUtils.parseDate("2002-03-28", (String[]) null);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        } catch (final ParseException e) {
            fail("expected NullPointerException, got ParseException");
        }
        try {
            DateUtils.parseDateStrictly(null, "yyyy-MM-dd");
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        } catch (final ParseException e) {
            fail("expected NullPointerException, got ParseException");
        }
    }

    // ---- set* ----

    @Test
    void testSetDaysHoursMinutesMonthsSecondsYearsMilliseconds() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertEquals(newDate(2002, Calendar.MARCH, 15, 13, 45, 1, 231), DateUtils.setDays(date, 15));
        assertEquals(newDate(2002, Calendar.MARCH, 28, 5, 45, 1, 231), DateUtils.setHours(date, 5));
        assertEquals(newDate(2002, Calendar.MARCH, 28, 13, 10, 1, 231), DateUtils.setMinutes(date, 10));
        assertEquals(newDate(2002, Calendar.JANUARY, 28, 13, 45, 1, 231), DateUtils.setMonths(date, Calendar.JANUARY));
        assertEquals(newDate(2002, Calendar.MARCH, 28, 13, 45, 20, 231), DateUtils.setSeconds(date, 20));
        assertEquals(newDate(1999, Calendar.MARCH, 28, 13, 45, 1, 231), DateUtils.setYears(date, 1999));
        assertEquals(newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 500), DateUtils.setMilliseconds(date, 500));
    }

    @Test
    void testSetOutOfRangeThrowsIllegalArgumentException() {
        final Date date = new Date();
        try {
            DateUtils.setHours(date, 24);
            fail("expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
        try {
            DateUtils.setHours(date, -1);
            fail("expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
        try {
            DateUtils.setMinutes(date, 60);
            fail("expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
        try {
            DateUtils.setSeconds(date, 60);
            fail("expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
        try {
            DateUtils.setMilliseconds(date, 1000);
            fail("expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
        try {
            DateUtils.setDays(date, 0);
            fail("expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
        try {
            DateUtils.setDays(date, 32);
            fail("expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testSetNullThrowsNullPointerException() {
        try {
            DateUtils.setDays(null, 1);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            DateUtils.setHours(null, 1);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            DateUtils.setMinutes(null, 1);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            DateUtils.setSeconds(null, 1);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            DateUtils.setMilliseconds(null, 1);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            DateUtils.setMonths(null, 1);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            DateUtils.setYears(null, 1);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    // ---- toCalendar ----

    @Test
    void testToCalendar() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Calendar cal = DateUtils.toCalendar(date);
        assertEquals(date, cal.getTime());
    }

    @Test
    void testToCalendarWithTimeZone() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final TimeZone utc = TimeZone.getTimeZone("UTC");
        final Calendar cal = DateUtils.toCalendar(date, utc);
        assertEquals(utc, cal.getTimeZone());
        assertEquals(date, cal.getTime());
    }

    @Test
    void testToCalendarNullThrowsNullPointerException() {
        try {
            DateUtils.toCalendar(null);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            DateUtils.toCalendar(null, TimeZone.getTimeZone("UTC"));
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            DateUtils.toCalendar(new Date(), null);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    // ---- toLocalDateTime / toOffsetDateTime / toZonedDateTime ----

    @Test
    void testToLocalDateTimeDefaultAndExplicitZone() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final ZoneId zone = TimeZone.getDefault().toZoneId();
        assertEquals(LocalDateTime.ofInstant(date.toInstant(), zone), DateUtils.toLocalDateTime(date));

        final TimeZone utc = TimeZone.getTimeZone("UTC");
        assertEquals(LocalDateTime.ofInstant(date.toInstant(), utc.toZoneId()), DateUtils.toLocalDateTime(date, utc));
    }

    @Test
    void testToOffsetDateTime() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final TimeZone utc = TimeZone.getTimeZone("UTC");
        final OffsetDateTime expected = OffsetDateTime.ofInstant(date.toInstant(), utc.toZoneId());
        assertEquals(expected, DateUtils.toOffsetDateTime(date, utc));
    }

    @Test
    void testToZonedDateTime() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final TimeZone utc = TimeZone.getTimeZone("UTC");
        final ZonedDateTime expected = ZonedDateTime.ofInstant(date.toInstant(), utc.toZoneId());
        assertEquals(expected, DateUtils.toZonedDateTime(date, utc));
        assertNotNull(DateUtils.toZonedDateTime(date));
    }

    // ---- truncatedCompareTo / truncatedEquals ----

    @Test
    void testTruncatedCompareToAndEquals() {
        final Date date1 = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 0);
        final Date date2 = newDate(2002, Calendar.MARCH, 28, 6, 1, 1, 0);
        assertEquals(0, DateUtils.truncatedCompareTo(date1, date2, Calendar.DAY_OF_MONTH));
        assertTrue(DateUtils.truncatedEquals(date1, date2, Calendar.DAY_OF_MONTH));
        assertFalse(DateUtils.truncatedEquals(date1, date2, Calendar.HOUR_OF_DAY));
        assertTrue(DateUtils.truncatedCompareTo(date1, date2, Calendar.HOUR_OF_DAY) > 0);

        final Calendar cal1 = DateUtils.toCalendar(date1);
        final Calendar cal2 = DateUtils.toCalendar(date2);
        assertTrue(DateUtils.truncatedEquals(cal1, cal2, Calendar.DAY_OF_MONTH));
        assertFalse(DateUtils.truncatedEquals(cal1, cal2, Calendar.HOUR_OF_DAY));
    }

    // ---- constants ----

    @Test
    void testMillisConstants() {
        assertEquals(1000L, DateUtils.MILLIS_PER_SECOND);
        assertEquals(60L * 1000L, DateUtils.MILLIS_PER_MINUTE);
        assertEquals(60L * 60L * 1000L, DateUtils.MILLIS_PER_HOUR);
        assertEquals(24L * 60L * 60L * 1000L, DateUtils.MILLIS_PER_DAY);
    }

    // ---- deprecated public constructor ----

    @Test
    void testPublicConstructorIsUsable() {
        assertNotNull(new DateUtils());
    }
}
