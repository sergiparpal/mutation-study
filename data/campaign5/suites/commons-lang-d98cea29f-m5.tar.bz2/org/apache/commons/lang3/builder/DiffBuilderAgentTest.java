/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.builder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link DiffBuilder}.
 */
class DiffBuilderAgentTest {

    private static final class Address {
        final String city;

        Address(final String city) {
            this.city = city;
        }
    }

    private static final class Person {
        final String name;
        final int age;

        Person(final String name, final int age) {
            this.name = name;
            this.age = age;
        }
    }

    // --- Builder ---

    @Test
    void testBuilderMissingLeftAndRightThrowsOnBuild() {
        final DiffBuilder.Builder<String> builder = DiffBuilder.<String>builder();
        assertThrows(NullPointerException.class, builder::build);
    }

    @Test
    void testBuilderSetLeftRightAndGetters() {
        final DiffBuilder<String> diffBuilder = DiffBuilder.<String>builder().setLeft("L").setRight("R").build();
        assertEquals("L", diffBuilder.getLeft());
        assertEquals("R", diffBuilder.getRight());
    }

    @Test
    void testBuilderDefaultStyleIsUsedWhenNotSet() {
        final DiffResult<String> result = DiffBuilder.<String>builder().setLeft("L").setRight("R").build()
                .append("field", "a", "b").build();
        assertSame(ToStringStyle.DEFAULT_STYLE, result.getToStringStyle());
    }

    @Test
    void testBuilderSetStyleNullFallsBackToDefault() {
        final DiffResult<String> result = DiffBuilder.<String>builder().setLeft("L").setRight("R")
                .setStyle(null).build().append("field", "a", "b").build();
        assertSame(ToStringStyle.DEFAULT_STYLE, result.getToStringStyle());
    }

    @Test
    void testBuilderSetStyleExplicit() {
        final DiffResult<String> result = DiffBuilder.<String>builder().setLeft("L").setRight("R")
                .setStyle(ToStringStyle.SHORT_PREFIX_STYLE).build().append("field", "a", "b").build();
        assertSame(ToStringStyle.SHORT_PREFIX_STYLE, result.getToStringStyle());
    }

    @Test
    void testBuilderToStringFormatDefault() {
        final DiffResult<String> result = DiffBuilder.<String>builder().setLeft("L").setRight("R").build()
                .append("field", "a", "b").build();
        assertTrue(result.toString().contains("differs from"));
    }

    @Test
    void testBuilderToStringFormatNullFallsBackToDefault() {
        final DiffResult<String> result = DiffBuilder.<String>builder().setLeft("L").setRight("R")
                .setToStringFormat(null).build().append("field", "a", "b").build();
        assertTrue(result.toString().contains("differs from"));
    }

    @Test
    void testBuilderToStringFormatCustom() {
        final DiffResult<String> result = DiffBuilder.<String>builder().setLeft("L").setRight("R")
                .setToStringFormat("%s vs %s").build().append("field", "a", "b").build();
        assertTrue(result.toString().contains(" vs "));
        assertFalse(result.toString().contains("differs from"));
    }

    @Test
    void testBuilderTestObjectsEqualsTrueShortCircuitsEqualObjects() {
        final String left = "abc";
        final String right = new String("abc");
        assertNotSame(left, right);
        final DiffResult<String> result = DiffBuilder.<String>builder().setLeft(left).setRight(right).build()
                .append("len", 3, 4)
                .build();
        assertEquals(0, result.getNumberOfDiffs());
    }

    @Test
    void testBuilderTestObjectsEqualsFalseForcesPerFieldEvaluation() {
        final String left = "abc";
        final String right = new String("abc");
        final DiffResult<String> result = DiffBuilder.<String>builder().setLeft(left).setRight(right)
                .setTestObjectsEquals(false).build()
                .append("len", 3, 4)
                .build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    // --- Deprecated constructors ---

    @Test
    void testDeprecatedConstructorNullLeftThrowsNpe() {
        assertThrows(NullPointerException.class, () -> new DiffBuilder<String>(null, "r", ToStringStyle.DEFAULT_STYLE));
    }

    @Test
    void testDeprecatedConstructorNullRightThrowsNpe() {
        assertThrows(NullPointerException.class, () -> new DiffBuilder<String>("l", null, ToStringStyle.DEFAULT_STYLE));
    }

    @Test
    void testDeprecatedConstructorNullStyleUsesDefault() {
        final DiffBuilder<String> diffBuilder = new DiffBuilder<>("L", "R", null);
        final DiffResult<String> result = diffBuilder.append("field", "a", "b").build();
        assertSame(ToStringStyle.DEFAULT_STYLE, result.getToStringStyle());
    }

    @Test
    void testDeprecatedConstructorTestObjectsEqualsFalse() {
        final String left = "abc";
        final String right = new String("abc");
        final DiffBuilder<String> diffBuilder = new DiffBuilder<>(left, right, ToStringStyle.DEFAULT_STYLE, false);
        final DiffResult<String> result = diffBuilder.append("len", 3, 4).build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    // --- append(String, boolean/boolean) ---

    @Test
    void testAppendBooleanEqualProducesNoDiff() {
        final DiffResult<String> result = newBuilder().append("b", true, true).build();
        assertEquals(0, result.getNumberOfDiffs());
    }

    @Test
    void testAppendBooleanDifferentProducesDiff() {
        final DiffResult<String> result = newBuilder().append("b", true, false).build();
        assertEquals(1, result.getNumberOfDiffs());
        final Diff<?> diff = result.getDiffs().get(0);
        assertEquals("b", diff.getFieldName());
        assertEquals(Boolean.TRUE, diff.getLeft());
        assertEquals(Boolean.FALSE, diff.getRight());
    }

    // --- append(String, boolean[]/boolean[]) ---

    @Test
    void testAppendBooleanArrayEqualProducesNoDiff() {
        final DiffResult<String> result = newBuilder().append("b", new boolean[] {true, false}, new boolean[] {true, false}).build();
        assertEquals(0, result.getNumberOfDiffs());
    }

    @Test
    void testAppendBooleanArrayDifferentProducesDiff() {
        final DiffResult<String> result = newBuilder().append("b", new boolean[] {true}, new boolean[] {false}).build();
        assertEquals(1, result.getNumberOfDiffs());
        final Diff<?> diff = result.getDiffs().get(0);
        assertTrue(diff.getLeft() instanceof Boolean[]);
    }

    // --- append(String, byte/byte) ---

    @Test
    void testAppendByteEqualProducesNoDiff() {
        assertEquals(0, newBuilder().append("b", (byte) 1, (byte) 1).build().getNumberOfDiffs());
    }

    @Test
    void testAppendByteDifferentProducesDiff() {
        final DiffResult<String> result = newBuilder().append("b", (byte) 1, (byte) 2).build();
        assertEquals(1, result.getNumberOfDiffs());
        assertEquals(Byte.valueOf((byte) 1), result.getDiffs().get(0).getLeft());
        assertEquals(Byte.valueOf((byte) 2), result.getDiffs().get(0).getRight());
    }

    // --- append(String, byte[]/byte[]) ---

    @Test
    void testAppendByteArrayDifferentProducesDiff() {
        final DiffResult<String> result = newBuilder().append("b", new byte[] {1, 2}, new byte[] {1, 3}).build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    void testAppendByteArrayEqualProducesNoDiff() {
        assertEquals(0, newBuilder().append("b", new byte[] {1, 2}, new byte[] {1, 2}).build().getNumberOfDiffs());
    }

    // --- append(String, char/char) ---

    @Test
    void testAppendCharDifferentProducesDiff() {
        final DiffResult<String> result = newBuilder().append("c", 'a', 'b').build();
        assertEquals(1, result.getNumberOfDiffs());
        assertEquals(Character.valueOf('a'), result.getDiffs().get(0).getLeft());
    }

    @Test
    void testAppendCharEqualProducesNoDiff() {
        assertEquals(0, newBuilder().append("c", 'a', 'a').build().getNumberOfDiffs());
    }

    // --- append(String, char[]/char[]) ---

    @Test
    void testAppendCharArrayDifferentProducesDiff() {
        assertEquals(1, newBuilder().append("c", "ab".toCharArray(), "ac".toCharArray()).build().getNumberOfDiffs());
    }

    @Test
    void testAppendCharArrayEqualProducesNoDiff() {
        assertEquals(0, newBuilder().append("c", "ab".toCharArray(), "ab".toCharArray()).build().getNumberOfDiffs());
    }

    // --- append(String, double/double) ---

    @Test
    void testAppendDoubleDifferentProducesDiff() {
        final DiffResult<String> result = newBuilder().append("d", 1.0d, 2.0d).build();
        assertEquals(1, result.getNumberOfDiffs());
        assertEquals(Double.valueOf(1.0d), result.getDiffs().get(0).getLeft());
    }

    @Test
    void testAppendDoubleEqualProducesNoDiff() {
        assertEquals(0, newBuilder().append("d", 1.0d, 1.0d).build().getNumberOfDiffs());
    }

    @Test
    void testAppendDoubleNanEqualsNanProducesNoDiff() {
        // Double.doubleToLongBits makes NaN == NaN for this comparison, unlike primitive ==.
        assertEquals(0, newBuilder().append("d", Double.NaN, Double.NaN).build().getNumberOfDiffs());
    }

    // --- append(String, double[]/double[]) ---

    @Test
    void testAppendDoubleArrayDifferentProducesDiff() {
        assertEquals(1, newBuilder().append("d", new double[] {1.0}, new double[] {2.0}).build().getNumberOfDiffs());
    }

    @Test
    void testAppendDoubleArrayEqualProducesNoDiff() {
        assertEquals(0, newBuilder().append("d", new double[] {1.0}, new double[] {1.0}).build().getNumberOfDiffs());
    }

    // --- append(String, float/float) ---

    @Test
    void testAppendFloatDifferentProducesDiff() {
        final DiffResult<String> result = newBuilder().append("f", 1.0f, 2.0f).build();
        assertEquals(1, result.getNumberOfDiffs());
        assertEquals(Float.valueOf(1.0f), result.getDiffs().get(0).getLeft());
    }

    @Test
    void testAppendFloatEqualProducesNoDiff() {
        assertEquals(0, newBuilder().append("f", 1.0f, 1.0f).build().getNumberOfDiffs());
    }

    // --- append(String, float[]/float[]) ---

    @Test
    void testAppendFloatArrayDifferentProducesDiff() {
        assertEquals(1, newBuilder().append("f", new float[] {1.0f}, new float[] {2.0f}).build().getNumberOfDiffs());
    }

    @Test
    void testAppendFloatArrayEqualProducesNoDiff() {
        assertEquals(0, newBuilder().append("f", new float[] {1.0f}, new float[] {1.0f}).build().getNumberOfDiffs());
    }

    // --- append(String, int/int) ---

    @Test
    void testAppendIntDifferentProducesDiff() {
        final DiffResult<String> result = newBuilder().append("i", 1, 2).build();
        assertEquals(1, result.getNumberOfDiffs());
        assertEquals(Integer.valueOf(1), result.getDiffs().get(0).getLeft());
        assertEquals(Integer.valueOf(2), result.getDiffs().get(0).getRight());
    }

    @Test
    void testAppendIntEqualProducesNoDiff() {
        assertEquals(0, newBuilder().append("i", 1, 1).build().getNumberOfDiffs());
    }

    @Test
    void testAppendIntBoundaryValues() {
        final DiffResult<String> result = newBuilder().append("i", Integer.MIN_VALUE, Integer.MAX_VALUE).build();
        assertEquals(1, result.getNumberOfDiffs());
        assertEquals(Integer.valueOf(Integer.MIN_VALUE), result.getDiffs().get(0).getLeft());
        assertEquals(Integer.valueOf(Integer.MAX_VALUE), result.getDiffs().get(0).getRight());
    }

    // --- append(String, int[]/int[]) ---

    @Test
    void testAppendIntArrayDifferentProducesDiff() {
        assertEquals(1, newBuilder().append("i", new int[] {1, 2}, new int[] {1, 3}).build().getNumberOfDiffs());
    }

    @Test
    void testAppendIntArrayEqualProducesNoDiff() {
        assertEquals(0, newBuilder().append("i", new int[] {1, 2}, new int[] {1, 2}).build().getNumberOfDiffs());
    }

    // --- append(String, long/long) ---

    @Test
    void testAppendLongDifferentProducesDiff() {
        final DiffResult<String> result = newBuilder().append("l", 1L, 2L).build();
        assertEquals(1, result.getNumberOfDiffs());
        assertEquals(Long.valueOf(1L), result.getDiffs().get(0).getLeft());
    }

    @Test
    void testAppendLongEqualProducesNoDiff() {
        assertEquals(0, newBuilder().append("l", 1L, 1L).build().getNumberOfDiffs());
    }

    // --- append(String, long[]/long[]) ---

    @Test
    void testAppendLongArrayDifferentProducesDiff() {
        assertEquals(1, newBuilder().append("l", new long[] {1L}, new long[] {2L}).build().getNumberOfDiffs());
    }

    @Test
    void testAppendLongArrayEqualProducesNoDiff() {
        assertEquals(0, newBuilder().append("l", new long[] {1L}, new long[] {1L}).build().getNumberOfDiffs());
    }

    // --- append(String, short/short) ---

    @Test
    void testAppendShortDifferentProducesDiff() {
        final DiffResult<String> result = newBuilder().append("s", (short) 1, (short) 2).build();
        assertEquals(1, result.getNumberOfDiffs());
        assertEquals(Short.valueOf((short) 1), result.getDiffs().get(0).getLeft());
    }

    @Test
    void testAppendShortEqualProducesNoDiff() {
        assertEquals(0, newBuilder().append("s", (short) 1, (short) 1).build().getNumberOfDiffs());
    }

    // --- append(String, short[]/short[]) ---

    @Test
    void testAppendShortArrayDifferentProducesDiff() {
        assertEquals(1, newBuilder().append("s", new short[] {1}, new short[] {2}).build().getNumberOfDiffs());
    }

    @Test
    void testAppendShortArrayEqualProducesNoDiff() {
        assertEquals(0, newBuilder().append("s", new short[] {1}, new short[] {1}).build().getNumberOfDiffs());
    }

    // --- append(String, Object/Object) ---

    @Test
    void testAppendObjectSameReferenceProducesNoDiffEvenWithNullFieldName() {
        final Object shared = new Object();
        // The lhs == rhs short-circuit happens before the field name is used, so a null field name is safe here.
        final DiffResult<String> result = newBuilder().append(null, shared, shared).build();
        assertEquals(0, result.getNumberOfDiffs());
    }

    @Test
    void testAppendObjectBothNullProducesNoDiff() {
        assertEquals(0, newBuilder().append("o", (Object) null, (Object) null).build().getNumberOfDiffs());
    }

    @Test
    void testAppendObjectOneNullProducesDiff() {
        final DiffResult<String> result = newBuilder().append("o", "x", (Object) null).build();
        assertEquals(1, result.getNumberOfDiffs());
        assertNotNull(result.getDiffs().get(0));
        assertEquals("x", result.getDiffs().get(0).getLeft());
        assertEquals(null, result.getDiffs().get(0).getRight());
    }

    @Test
    void testAppendObjectEqualValuesProducesNoDiff() {
        assertEquals(0, newBuilder().append("o", "same", new String("same")).build().getNumberOfDiffs());
    }

    @Test
    void testAppendObjectDifferentValuesProducesDiff() {
        final DiffResult<String> result = newBuilder().append("o", "x", "y").build();
        assertEquals(1, result.getNumberOfDiffs());
        assertEquals("x", result.getDiffs().get(0).getLeft());
        assertEquals("y", result.getDiffs().get(0).getRight());
    }

    @Test
    void testAppendObjectDelegatesToPrimitiveArrayOverloadForMatchingTypes() {
        final DiffResult<String> result = newBuilder().append("o", (Object) new int[] {1, 2}, (Object) new int[] {1, 3}).build();
        assertEquals(1, result.getNumberOfDiffs());
        assertTrue(result.getDiffs().get(0).getLeft() instanceof Integer[]);
    }

    @Test
    void testAppendObjectWithIncompatibleArrayTypesComparesAsPlainObjects() {
        final int[] left = {1, 2};
        final long[] right = {1L, 2L};
        final DiffResult<String> result = newBuilder().append("o", (Object) left, (Object) right).build();
        assertEquals(1, result.getNumberOfDiffs());
        assertSame(left, result.getDiffs().get(0).getLeft());
        assertSame(right, result.getDiffs().get(0).getRight());
    }

    @Test
    void testAppendObjectWithDifferentObjectArraySubtypesDelegatesToObjectArrayOverload() {
        final Object[] left = new String[] {"a"};
        final Object[] right = new Integer[] {1};
        final DiffResult<String> result = newBuilder().append("o", (Object) left, (Object) right).build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    void testAppendObjectNullFieldNameThrowsNpeWhenDiffIsActuallyAdded() {
        assertThrows(NullPointerException.class, () -> newBuilder().append(null, "x", "y"));
    }

    // --- append(String, Object[]/Object[]) ---

    @Test
    void testAppendObjectArrayEqualProducesNoDiff() {
        assertEquals(0, newBuilder().append("o", new String[] {"a", "b"}, new String[] {"a", "b"}).build().getNumberOfDiffs());
    }

    @Test
    void testAppendObjectArrayDifferentProducesDiff() {
        final DiffResult<String> result = newBuilder().append("o", new String[] {"a"}, new String[] {"b"}).build();
        assertEquals(1, result.getNumberOfDiffs());
        assertTrue(result.getDiffs().get(0).getLeft() instanceof Object[]);
    }

    // --- append(String, DiffResult) ---

    @Test
    void testAppendDiffResultNullThrowsNpe() {
        assertThrows(NullPointerException.class, () -> newBuilder().append("field", null));
    }

    @Test
    void testAppendDiffResultNullThrowsNpeEvenWhenShortCircuited() {
        // The objects-equal short-circuit must not bypass the null check for diffResult.
        final Person same = new Person("a", 1);
        final DiffBuilder<Person> builder = DiffBuilder.<Person>builder().setLeft(same).setRight(same).build();
        assertThrows(NullPointerException.class, () -> builder.append("field", null));
    }

    @Test
    void testAppendDiffResultMergesNestedDiffsWithPrefixedFieldNames() {
        final Address leftAddress = new Address("Paris");
        final Address rightAddress = new Address("Berlin");
        final DiffResult<Address> addressDiff = DiffBuilder.<Address>builder().setLeft(leftAddress).setRight(rightAddress).build()
                .append("city", leftAddress.city, rightAddress.city)
                .build();
        assertEquals(1, addressDiff.getNumberOfDiffs());

        final Person leftPerson = new Person("John", 30);
        final Person rightPerson = new Person("John", 31);
        final DiffResult<Person> personDiff = DiffBuilder.<Person>builder().setLeft(leftPerson).setRight(rightPerson).build()
                .append("age", leftPerson.age, rightPerson.age)
                .append("address", addressDiff)
                .build();

        assertEquals(2, personDiff.getNumberOfDiffs());
        final List<Diff<?>> diffs = personDiff.getDiffs();
        assertEquals("age", diffs.get(0).getFieldName());
        assertEquals("address.city", diffs.get(1).getFieldName());
        assertEquals("Paris", diffs.get(1).getLeft());
        assertEquals("Berlin", diffs.get(1).getRight());
    }

    @Test
    void testAppendDiffResultWithNoDiffsAddsNothing() {
        final Address sameAddress = new Address("Paris");
        final DiffResult<Address> emptyDiff = DiffBuilder.<Address>builder().setLeft(sameAddress).setRight(sameAddress).build()
                .append("city", sameAddress.city, sameAddress.city)
                .build();
        assertEquals(0, emptyDiff.getNumberOfDiffs());

        final Person left = new Person("John", 30);
        final Person right = new Person("Jane", 30);
        final DiffResult<Person> personDiff = DiffBuilder.<Person>builder().setLeft(left).setRight(right).build()
                .append("address", emptyDiff)
                .build();
        assertEquals(0, personDiff.getNumberOfDiffs());
    }

    @Test
    void testAppendDiffResultSkippedWhenBuilderObjectsEqual() {
        final Person same = new Person("a", 1);
        final Address leftAddress = new Address("Paris");
        final Address rightAddress = new Address("Berlin");
        final DiffResult<Address> addressDiff = DiffBuilder.<Address>builder().setLeft(leftAddress).setRight(rightAddress).build()
                .append("city", leftAddress.city, rightAddress.city)
                .build();
        assertEquals(1, addressDiff.getNumberOfDiffs());

        final DiffResult<Person> result = DiffBuilder.<Person>builder().setLeft(same).setRight(same).build()
                .append("address", addressDiff)
                .build();
        assertEquals(0, result.getNumberOfDiffs());
    }

    // --- Fluent chaining / build() ---

    @Test
    void testAppendReturnsSameBuilderInstanceForChaining() {
        final DiffBuilder<String> builder = newBuilder();
        final DiffBuilder<String> returned = builder.append("a", 1, 2);
        assertSame(builder, returned);
    }

    @Test
    void testBuildReturnsIndependentResultsReflectingDiffsAtCallTime() {
        final DiffBuilder<String> builder = newBuilder();
        final DiffResult<String> before = builder.build();
        assertEquals(0, before.getNumberOfDiffs());
        builder.append("a", 1, 2);
        final DiffResult<String> after = builder.build();
        assertEquals(1, after.getNumberOfDiffs());
        assertEquals("L", after.getLeft());
        assertEquals("R", after.getRight());
    }

    private DiffBuilder<String> newBuilder() {
        return DiffBuilder.<String>builder().setLeft("L").setRight("R").build();
    }
}
