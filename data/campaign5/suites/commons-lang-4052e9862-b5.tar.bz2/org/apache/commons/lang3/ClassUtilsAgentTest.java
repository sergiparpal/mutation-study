/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link ClassUtils}.
 */
public class ClassUtilsAgentTest {

    interface AgentInterfaceA {
        // marker
    }

    interface AgentInterfaceB extends AgentInterfaceA {
        // marker
    }

    static class AgentSuperclass implements AgentInterfaceB {
        // marker
    }

    static class AgentSubclass extends AgentSuperclass {
        // marker
    }

    public static class AgentInnerHolder {
        public class AgentInner {
            // marker
        }
    }

    @Test
    public void testComparator() {
        final List<Class<?>> list = new ArrayList<>(Arrays.asList(String.class, Integer.class, null));
        list.sort(ClassUtils.comparator());
        // null sorts first because Objects.compare treats nulls via getName -> "" for null class
        assertEquals(null, list.get(0));
        assertEquals(Integer.class, list.get(1));
        assertEquals(String.class, list.get(2));
    }

    @Test
    public void testConvertClassesToClassNames() {
        assertNull(ClassUtils.convertClassesToClassNames(null));
        final List<Class<?>> classes = new ArrayList<>();
        classes.add(String.class);
        classes.add(null);
        final List<String> names = ClassUtils.convertClassesToClassNames(classes);
        assertEquals(2, names.size());
        assertEquals("java.lang.String", names.get(0));
        assertNull(names.get(1));
    }

    @Test
    public void testConvertClassNamesToClasses() {
        assertNull(ClassUtils.convertClassNamesToClasses(null));
        final List<String> names = new ArrayList<>();
        names.add("java.lang.String");
        names.add("does.not.Exist");
        names.add(null);
        final List<Class<?>> classes = ClassUtils.convertClassNamesToClasses(names);
        assertEquals(3, classes.size());
        assertEquals(String.class, classes.get(0));
        assertNull(classes.get(1));
        assertNull(classes.get(2));
    }

    @Test
    public void testGetAbbreviatedNameClass() {
        assertEquals("", ClassUtils.getAbbreviatedName((Class<?>) null, 1));
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName(String.class, 10));
    }

    @Test
    public void testGetAbbreviatedNameString() {
        assertEquals("", ClassUtils.getAbbreviatedName((String) null, 1));
        assertEquals("java.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 30));
        assertEquals("j.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 15));
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName("java.lang.String", 5));
        assertThrows(IllegalArgumentException.class, () -> ClassUtils.getAbbreviatedName("java.lang.String", 0));
        assertThrows(IllegalArgumentException.class, () -> ClassUtils.getAbbreviatedName("java.lang.String", -1));
    }

    @Test
    public void testGetAllInterfaces() {
        assertNull(ClassUtils.getAllInterfaces(null));
        final List<Class<?>> interfaces = ClassUtils.getAllInterfaces(AgentSubclass.class);
        assertTrue(interfaces.contains(AgentInterfaceA.class));
        assertTrue(interfaces.contains(AgentInterfaceB.class));
        assertEquals(2, interfaces.size());
    }

    @Test
    public void testGetAllSuperclasses() {
        assertNull(ClassUtils.getAllSuperclasses(null));
        final List<Class<?>> superclasses = ClassUtils.getAllSuperclasses(AgentSubclass.class);
        assertEquals(2, superclasses.size());
        assertEquals(AgentSuperclass.class, superclasses.get(0));
        assertEquals(Object.class, superclasses.get(1));
    }

    @Test
    public void testGetCanonicalNameClass() {
        assertEquals("", ClassUtils.getCanonicalName((Class<?>) null));
        assertEquals("VALUE", ClassUtils.getCanonicalName((Class<?>) null, "VALUE"));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName(String.class));
        assertEquals("java.lang.String[]", ClassUtils.getCanonicalName(String[].class));
    }

    @Test
    public void testGetCanonicalNameObject() {
        assertEquals("", ClassUtils.getCanonicalName((Object) null));
        assertEquals("VALUE", ClassUtils.getCanonicalName((Object) null, "VALUE"));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName((Object) "hello"));
    }

    @Test
    public void testGetClassWithLoaderAndName() throws ClassNotFoundException {
        final ClassLoader loader = ClassUtilsAgentTest.class.getClassLoader();
        assertEquals(String.class, ClassUtils.getClass(loader, "java.lang.String"));
        assertEquals(int.class, ClassUtils.getClass(loader, "int"));
        assertEquals(int[].class, ClassUtils.getClass(loader, "[I"));
        assertEquals(String[].class, ClassUtils.getClass(loader, "java.lang.String[]"));
        assertEquals(AgentInnerHolder.AgentInner.class,
                ClassUtils.getClass(loader, "org.apache.commons.lang3.ClassUtilsAgentTest.AgentInnerHolder.AgentInner"));
        assertThrows(ClassNotFoundException.class, () -> ClassUtils.getClass(loader, "does.not.Exist"));
    }

    @Test
    public void testGetClassByName() throws ClassNotFoundException {
        assertEquals(String.class, ClassUtils.getClass("java.lang.String"));
        assertThrows(ClassNotFoundException.class, () -> ClassUtils.getClass("not.a.real.ClassName"));
        assertThrows(NullPointerException.class, () -> ClassUtils.getClass((String) null));
    }

    @Test
    public void testGetComponentType() {
        assertNull(ClassUtils.getComponentType(null));
        assertEquals(String.class, ClassUtils.getComponentType(String[].class));
    }

    @Test
    public void testGetName() {
        assertEquals("", ClassUtils.getName((Class<?>) null));
        assertEquals("java.lang.String", ClassUtils.getName(String.class));
        assertEquals("VALUE", ClassUtils.getName((Class<?>) null, "VALUE"));
        assertEquals("", ClassUtils.getName((Object) null));
        assertEquals("java.lang.String", ClassUtils.getName((Object) "x"));
        assertEquals("VALUE", ClassUtils.getName((Object) null, "VALUE"));
    }

    @Test
    public void testGetPackageCanonicalName() {
        assertEquals("", ClassUtils.getPackageCanonicalName((Class<?>) null));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName(String.class));
        assertEquals("VALUE", ClassUtils.getPackageCanonicalName((Object) null, "VALUE"));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName((Object) "x", "VALUE"));
        assertEquals("", ClassUtils.getPackageCanonicalName((String) null));
    }

    @Test
    public void testGetPackageName() {
        assertEquals("", ClassUtils.getPackageName((Class<?>) null));
        assertEquals("java.lang", ClassUtils.getPackageName(String.class));
        assertEquals("VALUE", ClassUtils.getPackageName((Object) null, "VALUE"));
        assertEquals("java.lang", ClassUtils.getPackageName((Object) "x", "VALUE"));
        assertEquals("", ClassUtils.getPackageName((String) null));
        assertEquals("", ClassUtils.getPackageName(""));
        assertEquals("", ClassUtils.getPackageName("NoPackage"));
        assertEquals("java.lang", ClassUtils.getPackageName("java.lang.String"));
    }

    @Test
    public void testGetPublicMethod() throws Exception {
        final java.lang.reflect.Method method = ClassUtils.getPublicMethod(java.util.ArrayList.class, "size");
        assertNotNull(method);
        assertEquals("size", method.getName());
        assertThrows(NoSuchMethodException.class, () -> ClassUtils.getPublicMethod(String.class, "noSuchMethodHere"));
        assertThrows(NullPointerException.class, () -> ClassUtils.getPublicMethod(null, "size"));
    }

    @Test
    public void testGetShortCanonicalName() {
        assertEquals("", ClassUtils.getShortCanonicalName((Class<?>) null));
        assertEquals("String", ClassUtils.getShortCanonicalName(String.class));
        assertEquals("String[]", ClassUtils.getShortCanonicalName(String[].class));
        assertEquals("VALUE", ClassUtils.getShortCanonicalName((Object) null, "VALUE"));
        assertEquals("String", ClassUtils.getShortCanonicalName((Object) "x", "VALUE"));
        assertEquals("int[]", ClassUtils.getShortCanonicalName("[I"));
    }

    @Test
    public void testGetShortClassName() {
        assertEquals("", ClassUtils.getShortClassName((Class<?>) null));
        assertEquals("String", ClassUtils.getShortClassName(String.class));
        assertEquals("VALUE", ClassUtils.getShortClassName((Object) null, "VALUE"));
        assertEquals("String", ClassUtils.getShortClassName((Object) "x", "VALUE"));
        assertEquals("", ClassUtils.getShortClassName((String) null));
        assertEquals("", ClassUtils.getShortClassName(""));
        assertEquals("String[]", ClassUtils.getShortClassName("[Ljava.lang.String;"));
        assertEquals("int[]", ClassUtils.getShortClassName("[I"));
        assertEquals("Map.Entry", ClassUtils.getShortClassName("java.util.Map$Entry"));
    }

    @Test
    public void testGetSimpleName() {
        assertEquals("", ClassUtils.getSimpleName((Class<?>) null));
        assertEquals("String", ClassUtils.getSimpleName(String.class));
        assertEquals("VALUE", ClassUtils.getSimpleName((Class<?>) null, "VALUE"));
        assertEquals("", ClassUtils.getSimpleName((Object) null));
        assertEquals("String", ClassUtils.getSimpleName((Object) "x"));
        assertEquals("VALUE", ClassUtils.getSimpleName((Object) null, "VALUE"));
    }

    @Test
    public void testHierarchyExcludeInterfaces() {
        final Iterator<Class<?>> it = ClassUtils.hierarchy(AgentSubclass.class).iterator();
        assertEquals(AgentSubclass.class, it.next());
        assertEquals(AgentSuperclass.class, it.next());
        assertEquals(Object.class, it.next());
        assertFalse(it.hasNext());
    }

    @Test
    public void testHierarchyIncludeInterfaces() {
        final List<Class<?>> result = new ArrayList<>();
        for (final Class<?> c : ClassUtils.hierarchy(AgentSubclass.class, ClassUtils.Interfaces.INCLUDE)) {
            result.add(c);
        }
        assertTrue(result.contains(AgentSubclass.class));
        assertTrue(result.contains(AgentSuperclass.class));
        assertTrue(result.contains(AgentInterfaceA.class));
        assertTrue(result.contains(AgentInterfaceB.class));
        assertTrue(result.contains(Object.class));
    }

    @Test
    public void testHierarchyIteratorRemoveUnsupported() {
        final Iterator<Class<?>> it = ClassUtils.hierarchy(AgentSubclass.class).iterator();
        assertThrows(UnsupportedOperationException.class, it::remove);
    }

    @Test
    public void testIsAssignable() {
        assertTrue(ClassUtils.isAssignable((Class<?>) null, Object.class));
        assertFalse(ClassUtils.isAssignable((Class<?>) null, int.class));
        assertFalse(ClassUtils.isAssignable(String.class, null));
        assertTrue(ClassUtils.isAssignable(int.class, long.class));
        assertFalse(ClassUtils.isAssignable(long.class, int.class));
        assertTrue(ClassUtils.isAssignable(Integer.class, int.class));
        assertFalse(ClassUtils.isAssignable(Integer.class, int.class, false));
        assertTrue(ClassUtils.isAssignable(String.class, Object.class));
        assertFalse(ClassUtils.isAssignable(Object.class, String.class));
    }

    @Test
    public void testIsAssignableArrays() {
        assertTrue(ClassUtils.isAssignable(new Class<?>[] {String.class}, new Class<?>[] {Object.class}));
        assertFalse(ClassUtils.isAssignable(new Class<?>[] {String.class}, new Class<?>[] {Object.class, Object.class}));
        assertTrue(ClassUtils.isAssignable((Class<?>[]) null, (Class<?>[]) null));
        assertTrue(ClassUtils.isAssignable(new Class<?>[] {Integer.class}, new Class<?>[] {int.class}, true));
        assertFalse(ClassUtils.isAssignable(new Class<?>[] {Integer.class}, new Class<?>[] {int.class}, false));
    }

    @Test
    public void testIsInnerClass() {
        assertFalse(ClassUtils.isInnerClass(null));
        assertFalse(ClassUtils.isInnerClass(String.class));
        assertTrue(ClassUtils.isInnerClass(AgentInnerHolder.AgentInner.class));
        assertTrue(ClassUtils.isInnerClass(AgentInnerHolder.class));
    }

    @Test
    public void testIsPrimitiveOrWrapper() {
        assertFalse(ClassUtils.isPrimitiveOrWrapper(null));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(int.class));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(Integer.class));
        assertFalse(ClassUtils.isPrimitiveOrWrapper(String.class));
    }

    @Test
    public void testIsPrimitiveWrapper() {
        assertFalse(ClassUtils.isPrimitiveWrapper(null));
        assertFalse(ClassUtils.isPrimitiveWrapper(int.class));
        assertTrue(ClassUtils.isPrimitiveWrapper(Integer.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(String.class));
    }

    @Test
    public void testIsPublic() {
        assertTrue(ClassUtils.isPublic(String.class));
        assertFalse(ClassUtils.isPublic(AgentSuperclass.class));
        assertThrows(NullPointerException.class, () -> ClassUtils.isPublic(null));
    }

    @Test
    public void testPrimitivesToWrappers() {
        assertNull(ClassUtils.primitivesToWrappers((Class<?>[]) null));
        assertEquals(0, ClassUtils.primitivesToWrappers().length);
        final Class<?>[] result = ClassUtils.primitivesToWrappers(int.class, String.class, null);
        assertEquals(Integer.class, result[0]);
        assertEquals(String.class, result[1]);
        assertNull(result[2]);
    }

    @Test
    public void testPrimitiveToWrapper() {
        assertNull(ClassUtils.primitiveToWrapper(null));
        assertEquals(Integer.class, ClassUtils.primitiveToWrapper(int.class));
        assertEquals(String.class, ClassUtils.primitiveToWrapper(String.class));
        assertEquals(Void.TYPE, ClassUtils.primitiveToWrapper(Void.TYPE));
    }

    @Test
    public void testToClass() {
        assertNull(ClassUtils.toClass((Object[]) null));
        assertEquals(0, ClassUtils.toClass().length);
        final Class<?>[] result = ClassUtils.toClass("x", 1, null);
        assertEquals(String.class, result[0]);
        assertEquals(Integer.class, result[1]);
        assertNull(result[2]);
    }

    @Test
    public void testWrappersToPrimitives() {
        assertNull(ClassUtils.wrappersToPrimitives((Class<?>[]) null));
        assertEquals(0, ClassUtils.wrappersToPrimitives().length);
        final Class<?>[] result = ClassUtils.wrappersToPrimitives(Integer.class, String.class, null);
        assertEquals(int.class, result[0]);
        assertNull(result[1]);
        assertNull(result[2]);
    }

    @Test
    public void testWrapperToPrimitive() {
        assertNull(ClassUtils.wrapperToPrimitive(null));
        assertEquals(int.class, ClassUtils.wrapperToPrimitive(Integer.class));
        assertNull(ClassUtils.wrapperToPrimitive(String.class));
    }

    @Test
    public void testConstructorIsPublic() {
        assertNotNull(new ClassUtils());
    }
}
