/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.fail;

import java.util.UUID;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link Conversion}.
 */
class ConversionAgentTest {

    @Test
    void testConstructor() {
        assertNotNull(new Conversion());
    }

    @Test
    void testBinaryBeMsb0ToHexDigit() {
        assertEquals('8', Conversion.binaryBeMsb0ToHexDigit(new boolean[] { true, false, false, false }));

        final boolean[] src = { true, false, false, false, false, false, false, false, false, false, false, true, false, true, false, false };
        assertEquals('5', Conversion.binaryBeMsb0ToHexDigit(src, 2));

        try {
            Conversion.binaryBeMsb0ToHexDigit(new boolean[0]);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }

        try {
            Conversion.binaryBeMsb0ToHexDigit(new boolean[] { true, false, false, false }, 4);
            fail("Expected IndexOutOfBoundsException");
        } catch (final IndexOutOfBoundsException expected) {
            // expected
        }
    }

    @Test
    void testBinaryToByte() {
        assertEquals((byte) 5, Conversion.binaryToByte(new boolean[] { true, false, true, false }, 0, (byte) 0, 0, 4));
        assertEquals((byte) 0xF5, Conversion.binaryToByte(new boolean[] { true, false, true, false }, 0, (byte) 0xF0, 0, 4));
        assertEquals((byte) 7, Conversion.binaryToByte(new boolean[0], 0, (byte) 7, 0, 0));

        try {
            Conversion.binaryToByte(new boolean[] { true }, 0, (byte) 0, 8, 1);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testBinaryToHexDigit() {
        assertEquals('1', Conversion.binaryToHexDigit(new boolean[] { true, false, false, false }));
        assertEquals('6', Conversion.binaryToHexDigit(new boolean[] { false, false, true, true, false, true }, 1));

        try {
            Conversion.binaryToHexDigit(new boolean[0]);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }

        try {
            Conversion.binaryToHexDigit(new boolean[0], 0);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testBinaryToHexDigitMsb0_4bits() {
        assertEquals('8', Conversion.binaryToHexDigitMsb0_4bits(new boolean[] { true, false, false, false }));
        assertEquals('d', Conversion.binaryToHexDigitMsb0_4bits(new boolean[] { true, false, false, true, true, false, true, false }, 3));

        try {
            Conversion.binaryToHexDigitMsb0_4bits(new boolean[9]);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }

        try {
            Conversion.binaryToHexDigitMsb0_4bits(new boolean[] { true, true, true }, 0);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testBinaryToInt() {
        final boolean[] src = { true, false, true, false, true };
        assertEquals(21, Conversion.binaryToInt(src, 0, 0, 0, 5));
        assertEquals(99, Conversion.binaryToInt(new boolean[0], 0, 99, 0, 0));

        try {
            Conversion.binaryToInt(new boolean[] { true }, 0, 0, 32, 1);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testBinaryToLong() {
        final boolean[] src = { true, false, true, false, true };
        assertEquals(21L, Conversion.binaryToLong(src, 0, 0L, 0, 5));
        assertEquals(99L, Conversion.binaryToLong(new boolean[0], 0, 99L, 0, 0));

        try {
            Conversion.binaryToLong(new boolean[] { true }, 0, 0L, 64, 1);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testBinaryToShort() {
        final boolean[] src = { true, false, true, false, true };
        assertEquals((short) 21, Conversion.binaryToShort(src, 0, (short) 0, 0, 5));
        assertEquals((short) 99, Conversion.binaryToShort(new boolean[0], 0, (short) 99, 0, 0));

        try {
            Conversion.binaryToShort(new boolean[] { true }, 0, (short) 0, 16, 1);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testByteArrayToInt() {
        assertEquals(513, Conversion.byteArrayToInt(new byte[] { 1, 2 }, 0, 0, 0, 2));
        assertEquals(42, Conversion.byteArrayToInt(new byte[0], 0, 42, 0, 0));

        try {
            Conversion.byteArrayToInt(new byte[] { 0 }, 0, 0, 32, 1);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testByteArrayToLong() {
        assertEquals(513L, Conversion.byteArrayToLong(new byte[] { 1, 2 }, 0, 0L, 0, 2));
        assertEquals(42L, Conversion.byteArrayToLong(new byte[0], 0, 42L, 0, 0));

        try {
            Conversion.byteArrayToLong(new byte[] { 0 }, 0, 0L, 64, 1);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testByteArrayToShort() {
        assertEquals((short) 513, Conversion.byteArrayToShort(new byte[] { 1, 2 }, 0, (short) 0, 0, 2));
        assertEquals((short) 42, Conversion.byteArrayToShort(new byte[0], 0, (short) 42, 0, 0));

        try {
            Conversion.byteArrayToShort(new byte[] { 0 }, 0, (short) 0, 16, 1);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testByteArrayToUuidRoundTrip() {
        final byte[] original = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
        final UUID uuid = Conversion.byteArrayToUuid(original, 0);
        assertNotNull(uuid);
        final byte[] roundTrip = new byte[16];
        Conversion.uuidToByteArray(uuid, roundTrip, 0, 16);
        assertArrayEquals(original, roundTrip);

        try {
            Conversion.byteArrayToUuid(new byte[15], 0);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testByteToBinary() {
        final boolean[] dst = new boolean[4];
        final boolean[] result = Conversion.byteToBinary((byte) 5, 0, dst, 0, 4);
        assertArrayEquals(new boolean[] { true, false, true, false }, result);
        assertEquals(dst, result);

        final boolean[] unchanged = { false, false };
        assertEquals(unchanged, Conversion.byteToBinary((byte) 5, 0, unchanged, 0, 0));
        assertArrayEquals(new boolean[] { false, false }, unchanged);

        try {
            Conversion.byteToBinary((byte) 1, 8, new boolean[1], 0, 1);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testByteToHex() {
        assertEquals("a0", Conversion.byteToHex((byte) 0x0A, 0, "", 0, 2));
        assertEquals("init", Conversion.byteToHex((byte) 0x0A, 0, "init", 0, 0));

        try {
            Conversion.byteToHex((byte) 1, 8, "", 0, 3);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testHexDigitMsb0ToBinary() {
        assertArrayEquals(new boolean[] { false, false, false, false }, Conversion.hexDigitMsb0ToBinary('0'));
        assertArrayEquals(new boolean[] { false, false, false, true }, Conversion.hexDigitMsb0ToBinary('1'));
        assertArrayEquals(new boolean[] { true, true, true, true }, Conversion.hexDigitMsb0ToBinary('F'));
        assertArrayEquals(new boolean[] { true, true, true, true }, Conversion.hexDigitMsb0ToBinary('f'));

        try {
            Conversion.hexDigitMsb0ToBinary('g');
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testHexDigitMsb0ToInt() {
        assertEquals(0x0, Conversion.hexDigitMsb0ToInt('0'));
        assertEquals(0x8, Conversion.hexDigitMsb0ToInt('1'));
        assertEquals(0xF, Conversion.hexDigitMsb0ToInt('f'));
        assertEquals(0xF, Conversion.hexDigitMsb0ToInt('F'));

        try {
            Conversion.hexDigitMsb0ToInt('z');
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testHexDigitToBinary() {
        assertArrayEquals(new boolean[] { false, false, false, false }, Conversion.hexDigitToBinary('0'));
        assertArrayEquals(new boolean[] { true, false, false, false }, Conversion.hexDigitToBinary('1'));
        assertArrayEquals(new boolean[] { true, true, true, true }, Conversion.hexDigitToBinary('f'));

        try {
            Conversion.hexDigitToBinary('g');
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testHexDigitToInt() {
        assertEquals(0, Conversion.hexDigitToInt('0'));
        assertEquals(9, Conversion.hexDigitToInt('9'));
        assertEquals(10, Conversion.hexDigitToInt('a'));
        assertEquals(15, Conversion.hexDigitToInt('F'));

        try {
            Conversion.hexDigitToInt('g');
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testHexToByte() {
        assertEquals((byte) 10, Conversion.hexToByte("A0", 0, (byte) 0, 0, 2));
        assertEquals((byte) 7, Conversion.hexToByte("", 0, (byte) 7, 0, 0));

        try {
            Conversion.hexToByte("", 0, (byte) 0, 0, 3);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testHexToInt() {
        assertEquals(0x12, Conversion.hexToInt("21", 0, 0, 0, 2));
        assertEquals(7, Conversion.hexToInt("", 0, 7, 0, 0));

        try {
            Conversion.hexToInt("", 0, 0, 0, 9);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testHexToLong() {
        assertEquals(0x12L, Conversion.hexToLong("21", 0, 0L, 0, 2));
        assertEquals(7L, Conversion.hexToLong("", 0, 7L, 0, 0));

        try {
            Conversion.hexToLong("", 0, 0L, 0, 17);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testHexToShort() {
        assertEquals((short) 0x12, Conversion.hexToShort("21", 0, (short) 0, 0, 2));
        assertEquals((short) 7, Conversion.hexToShort("", 0, (short) 7, 0, 0));

        try {
            Conversion.hexToShort("", 0, (short) 0, 0, 5);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testIntArrayToLong() {
        assertEquals(8589934593L, Conversion.intArrayToLong(new int[] { 1, 2 }, 0, 0L, 0, 2));
        assertEquals(42L, Conversion.intArrayToLong(new int[0], 0, 42L, 0, 0));

        try {
            Conversion.intArrayToLong(new int[] { 0 }, 0, 0L, 64, 1);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testIntToBinary() {
        final boolean[] dst = new boolean[4];
        final boolean[] result = Conversion.intToBinary(5, 0, dst, 0, 4);
        assertArrayEquals(new boolean[] { true, false, true, false }, result);

        final boolean[] unchanged = { false, false };
        Conversion.intToBinary(5, 0, unchanged, 0, 0);
        assertArrayEquals(new boolean[] { false, false }, unchanged);

        try {
            Conversion.intToBinary(1, 32, new boolean[1], 0, 1);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testIntToByteArray() {
        final byte[] dst = new byte[2];
        final byte[] result = Conversion.intToByteArray(513, 0, dst, 0, 2);
        assertArrayEquals(new byte[] { 1, 2 }, result);

        try {
            Conversion.intToByteArray(1, 32, new byte[1], 0, 1);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testIntToHex() {
        assertEquals("21", Conversion.intToHex(0x12, 0, "", 0, 2));
        assertEquals("init", Conversion.intToHex(0x12, 0, "init", 0, 0));

        try {
            Conversion.intToHex(1, 32, "", 0, 9);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testIntToHexDigit() {
        assertEquals('0', Conversion.intToHexDigit(0));
        assertEquals('a', Conversion.intToHexDigit(10));
        assertEquals('f', Conversion.intToHexDigit(15));

        try {
            Conversion.intToHexDigit(16);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }

        try {
            Conversion.intToHexDigit(-1);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testIntToHexDigitMsb0() {
        assertEquals('0', Conversion.intToHexDigitMsb0(0x0));
        assertEquals('8', Conversion.intToHexDigitMsb0(0x1));
        assertEquals('f', Conversion.intToHexDigitMsb0(0xF));

        try {
            Conversion.intToHexDigitMsb0(16);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testIntToShortArray() {
        final short[] dst = new short[2];
        final short[] result = Conversion.intToShortArray(65541, 0, dst, 0, 2);
        assertArrayEquals(new short[] { 5, 1 }, result);

        try {
            Conversion.intToShortArray(1, 32, new short[1], 0, 1);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testLongToBinary() {
        final boolean[] dst = new boolean[4];
        final boolean[] result = Conversion.longToBinary(5L, 0, dst, 0, 4);
        assertArrayEquals(new boolean[] { true, false, true, false }, result);

        try {
            Conversion.longToBinary(1L, 64, new boolean[1], 0, 1);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testLongToByteArray() {
        final byte[] dst = new byte[2];
        final byte[] result = Conversion.longToByteArray(513L, 0, dst, 0, 2);
        assertArrayEquals(new byte[] { 1, 2 }, result);

        try {
            Conversion.longToByteArray(1L, 64, new byte[1], 0, 1);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testLongToHex() {
        assertEquals("21", Conversion.longToHex(0x12L, 0, "", 0, 2));

        try {
            Conversion.longToHex(1L, 64, "", 0, 17);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testLongToIntArray() {
        final int[] dst = new int[2];
        final int[] result = Conversion.longToIntArray(4294967303L, 0, dst, 0, 2);
        assertArrayEquals(new int[] { 7, 1 }, result);

        try {
            Conversion.longToIntArray(1L, 64, new int[1], 0, 1);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testLongToShortArray() {
        final short[] dst = new short[2];
        final short[] result = Conversion.longToShortArray(65541L, 0, dst, 0, 2);
        assertArrayEquals(new short[] { 5, 1 }, result);

        try {
            Conversion.longToShortArray(1L, 64, new short[1], 0, 1);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testShortArrayToInt() {
        assertEquals(65541, Conversion.shortArrayToInt(new short[] { 5, 1 }, 0, 0, 0, 2));
        assertEquals(42, Conversion.shortArrayToInt(new short[0], 0, 42, 0, 0));

        try {
            Conversion.shortArrayToInt(new short[] { 0 }, 0, 0, 32, 1);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testShortArrayToLong() {
        assertEquals(65541L, Conversion.shortArrayToLong(new short[] { 5, 1 }, 0, 0L, 0, 2));
        assertEquals(42L, Conversion.shortArrayToLong(new short[0], 0, 42L, 0, 0));

        try {
            Conversion.shortArrayToLong(new short[] { 0 }, 0, 0L, 64, 1);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testShortToBinary() {
        final boolean[] dst = new boolean[4];
        final boolean[] result = Conversion.shortToBinary((short) 5, 0, dst, 0, 4);
        assertArrayEquals(new boolean[] { true, false, true, false }, result);

        try {
            Conversion.shortToBinary((short) 1, 16, new boolean[1], 0, 1);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testShortToByteArray() {
        final byte[] dst = new byte[2];
        final byte[] result = Conversion.shortToByteArray((short) 513, 0, dst, 0, 2);
        assertArrayEquals(new byte[] { 1, 2 }, result);

        try {
            Conversion.shortToByteArray((short) 1, 16, new byte[1], 0, 1);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testShortToHex() {
        assertEquals("21", Conversion.shortToHex((short) 0x12, 0, "", 0, 2));

        try {
            Conversion.shortToHex((short) 1, 16, "", 0, 5);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testUuidToByteArray() {
        final UUID uuid = new UUID(0x0102030405060708L, 0x090A0B0C0D0E0F10L);
        final byte[] dst = new byte[16];
        final byte[] result = Conversion.uuidToByteArray(uuid, dst, 0, 16);
        assertArrayEquals(new byte[] { 8, 7, 6, 5, 4, 3, 2, 1, 16, 15, 14, 13, 12, 11, 10, 9 }, result);

        final byte[] unchanged = { 1, 2 };
        Conversion.uuidToByteArray(uuid, unchanged, 0, 0);
        assertArrayEquals(new byte[] { 1, 2 }, unchanged);

        try {
            Conversion.uuidToByteArray(uuid, new byte[16], 0, 17);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }
}
