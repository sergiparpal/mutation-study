/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import org.junit.jupiter.api.Test;

/**
 * Package-private, top-level (not nested) so that a method it declares is reported by reflection
 * with this class as the declaring class, exercising the "public method in default access superclass" case.
 */
class MemberUtilsAgentTestPackagePrivateBase {
    public void basePublicMethod() {
        // empty
    }
}

/**
 * Tests {@link MemberUtils}.
 */
public class MemberUtilsAgentTest {

    public static class PublicFixture extends MemberUtilsAgentTestPackagePrivateBase {
        public PublicFixture() {
            // empty
        }

        public PublicFixture(final String s) {
            // empty
        }

        public PublicFixture(final Object o) {
            // empty
        }

        public void publicMethod() {
            // empty
        }

        public void acceptObject(final Object o) {
            // empty
        }

        public void acceptString(final String s) {
            // empty
        }

        public void varArgsMethod(final String first, final int... rest) {
            // empty
        }

        protected void protectedMethod() {
            // empty
        }

        private void privateMethod() {
            // empty
        }

        void packageMethod() {
            // empty
        }

        public static void staticMethod() {
            // empty
        }
    }

    @Test
    public void testIsPublicNullMember() {
        assertFalse(MemberUtils.isPublic(null));
    }

    @Test
    public void testIsPublicTrue() throws Exception {
        final Method m = PublicFixture.class.getMethod("publicMethod");
        assertTrue(MemberUtils.isPublic(m));
    }

    @Test
    public void testIsPublicFalseForProtected() throws Exception {
        final Method m = PublicFixture.class.getDeclaredMethod("protectedMethod");
        assertFalse(MemberUtils.isPublic(m));
    }

    @Test
    public void testIsPublicFalseForPrivate() throws Exception {
        final Method m = PublicFixture.class.getDeclaredMethod("privateMethod");
        assertFalse(MemberUtils.isPublic(m));
    }

    @Test
    public void testIsStaticNullMember() {
        assertFalse(MemberUtils.isStatic(null));
    }

    @Test
    public void testIsStaticTrue() throws Exception {
        final Method m = PublicFixture.class.getMethod("staticMethod");
        assertTrue(MemberUtils.isStatic(m));
    }

    @Test
    public void testIsStaticFalse() throws Exception {
        final Method m = PublicFixture.class.getMethod("publicMethod");
        assertFalse(MemberUtils.isStatic(m));
    }

    @Test
    public void testIsPackagePublicModifiersFalse() {
        assertFalse(MemberUtils.isPackage(Modifier.PUBLIC));
    }

    @Test
    public void testIsPackageProtectedModifiersFalse() {
        assertFalse(MemberUtils.isPackage(Modifier.PROTECTED));
    }

    @Test
    public void testIsPackagePrivateModifiersFalse() {
        assertFalse(MemberUtils.isPackage(Modifier.PRIVATE));
    }

    @Test
    public void testIsPackageTrueForPackagePrivate() {
        // No access modifiers set at all implies package access.
        assertTrue(MemberUtils.isPackage(Modifier.STATIC));
        assertTrue(MemberUtils.isPackage(0));
    }

    @Test
    public void testIsAccessiblePublicNonSynthetic() throws Exception {
        final Method m = PublicFixture.class.getMethod("publicMethod");
        assertTrue(MemberUtils.isAccessible(m));
    }

    @Test
    public void testIsAccessibleFalseForNonPublic() throws Exception {
        final Method m = PublicFixture.class.getDeclaredMethod("packageMethod");
        assertFalse(MemberUtils.isAccessible(m));
    }

    @Test
    public void testIsMatchingMethodExact() throws Exception {
        final Method m = PublicFixture.class.getMethod("publicMethod");
        assertTrue(MemberUtils.isMatchingMethod(m, new Class[0]));
    }

    @Test
    public void testIsMatchingMethodWrongArgCount() throws Exception {
        final Method m = PublicFixture.class.getMethod("publicMethod");
        assertFalse(MemberUtils.isMatchingMethod(m, new Class[] { String.class }));
    }

    @Test
    public void testIsMatchingMethodVarArgsNoneProvided() throws Exception {
        final Method m = PublicFixture.class.getMethod("varArgsMethod", String.class, int[].class);
        assertTrue(MemberUtils.isMatchingMethod(m, new Class[] { String.class }));
    }

    @Test
    public void testIsMatchingMethodVarArgsSomeProvided() throws Exception {
        final Method m = PublicFixture.class.getMethod("varArgsMethod", String.class, int[].class);
        assertTrue(MemberUtils.isMatchingMethod(m, new Class[] { String.class, Integer.class, Integer.class }));
    }

    @Test
    public void testIsMatchingMethodVarArgsMismatchedType() throws Exception {
        final Method m = PublicFixture.class.getMethod("varArgsMethod", String.class, int[].class);
        assertFalse(MemberUtils.isMatchingMethod(m, new Class[] { String.class, Object.class }));
    }

    @Test
    public void testIsMatchingMethodNullParameterTypesTreatedAsEmpty() throws Exception {
        final Method m = PublicFixture.class.getMethod("publicMethod");
        assertTrue(MemberUtils.isMatchingMethod(m, null));
    }

    @Test
    public void testIsMatchingConstructor() throws Exception {
        final Constructor<?> c = PublicFixture.class.getConstructor(String.class);
        assertTrue(MemberUtils.isMatchingConstructor(c, new Class[] { String.class }));
        assertFalse(MemberUtils.isMatchingConstructor(c, new Class[] { Integer.class }));
    }

    @Test
    public void testCompareMethodFitSelfComparisonIsEqual() throws Exception {
        final Method exact = PublicFixture.class.getMethod("varArgsMethod", String.class, int[].class);
        // Compared with itself, fit should be equal (0).
        assertEquals(0, MemberUtils.compareMethodFit(exact, exact, new Class[] { String.class, Integer.class }));
    }

    @Test
    public void testCompareMethodFitPrefersMoreSpecificType() throws Exception {
        final Method acceptString = PublicFixture.class.getMethod("acceptString", String.class);
        final Method acceptObject = PublicFixture.class.getMethod("acceptObject", Object.class);
        // A String argument fits acceptString(String) exactly, and only assignably fits acceptObject(Object),
        // so acceptString should be considered the better (lower cost) fit.
        final int result = MemberUtils.compareMethodFit(acceptString, acceptObject, new Class[] { String.class });
        assertTrue(result < 0);
        // And the opposite comparison should be consistently reversed.
        final int reversed = MemberUtils.compareMethodFit(acceptObject, acceptString, new Class[] { String.class });
        assertTrue(reversed > 0);
    }

    @Test
    public void testCompareConstructorFitPrefersMoreSpecificType() throws Exception {
        final Constructor<?> stringCtor = PublicFixture.class.getConstructor(String.class);
        final Constructor<?> objectCtor = PublicFixture.class.getConstructor(Object.class);
        final int result = MemberUtils.compareConstructorFit(stringCtor, objectCtor, new Class[] { String.class });
        assertTrue(result < 0);
    }

    @Test
    public void testSetAccessibleWorkaroundNull() {
        assertEquals(null, MemberUtils.setAccessibleWorkaround(null));
    }

    @Test
    public void testSetAccessibleWorkaroundLeavesPublicMethodOfPublicClassUnaffected() throws Exception {
        final Method m = PublicFixture.class.getMethod("publicMethod");
        final boolean before = m.isAccessible();
        final Method result = MemberUtils.setAccessibleWorkaround(m);
        assertNotNull(result);
        // Declaring class is public, so the workaround should not force accessibility.
        assertEquals(before, result.isAccessible());
    }

    @Test
    public void testSetAccessibleWorkaroundForcesAccessForPublicMethodOfPackagePrivateSuperclass() throws Exception {
        final Method m = PublicFixture.class.getMethod("basePublicMethod");
        assertEquals(MemberUtilsAgentTestPackagePrivateBase.class, m.getDeclaringClass());
        assertFalse(m.isAccessible());
        final Method result = MemberUtils.setAccessibleWorkaround(m);
        assertNotNull(result);
        assertTrue(result.isAccessible());
    }
}
