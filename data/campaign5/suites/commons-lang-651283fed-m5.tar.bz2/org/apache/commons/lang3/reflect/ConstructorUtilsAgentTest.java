/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests {@link ConstructorUtils}.
 */
public class ConstructorUtilsAgentTest {

    public static class BaseClass {
        // empty
    }

    public static class SubClass extends BaseClass {
        // empty
    }

    public static class PublicClass {

        public final String calledWith;

        public PublicClass() {
            calledWith = "()";
        }

        public PublicClass(final String s) {
            calledWith = "(String)";
        }

        public PublicClass(final Object o) {
            calledWith = "(Object)";
        }

        public PublicClass(final BaseClass b) {
            calledWith = "(BaseClass)";
        }

        public PublicClass(final String first, final int... rest) {
            calledWith = "(String, int...)";
        }

        public PublicClass(final boolean willThrow) {
            throw new IllegalStateException("boom");
        }
    }

    public abstract static class AbstractClass {
        public AbstractClass() {
            // empty
        }
    }

    static class PackagePrivateClass {
        public PackagePrivateClass() {
            // empty
        }
    }

    @Test
    public void testConstructorAgentTestFixturesLoad() {
        assertNotNull(new PublicClass());
    }

    @Test
    public void testGetAccessibleConstructorExactMatch() throws Exception {
        final Constructor<PublicClass> ctor = ConstructorUtils.getAccessibleConstructor(PublicClass.class, String.class);
        assertNotNull(ctor);
        assertEquals(1, ctor.getParameterTypes().length);
        assertEquals(String.class, ctor.getParameterTypes()[0]);
    }

    @Test
    public void testGetAccessibleConstructorNoMatch() {
        final Constructor<PublicClass> ctor = ConstructorUtils.getAccessibleConstructor(PublicClass.class, Integer.class, Integer.class);
        assertNull(ctor);
    }

    @Test
    public void testGetAccessibleConstructorNonPublicClass() {
        // Non-public declaring class: no accessible constructor can be returned.
        final Constructor<PackagePrivateClass> ctor = ConstructorUtils.getAccessibleConstructor(PackagePrivateClass.class);
        assertNull(ctor);
    }

    @Test
    public void testGetAccessibleConstructorNullClassThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ConstructorUtils.getAccessibleConstructor((Class<Object>) null);
            }
        });
    }

    @Test
    public void testGetAccessibleConstructorFromConstructorObject() throws Exception {
        final Constructor<PublicClass> raw = PublicClass.class.getConstructor(String.class);
        final Constructor<PublicClass> result = ConstructorUtils.getAccessibleConstructor(raw);
        assertNotNull(result);
        assertEquals(raw, result);
    }

    @Test
    public void testGetAccessibleConstructorFromConstructorObjectNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ConstructorUtils.getAccessibleConstructor((Constructor<Object>) null);
            }
        });
    }

    @Test
    public void testGetMatchingAccessibleConstructorExact() {
        final Constructor<PublicClass> ctor = ConstructorUtils.getMatchingAccessibleConstructor(PublicClass.class, String.class);
        assertNotNull(ctor);
        assertEquals(String.class, ctor.getParameterTypes()[0]);
    }

    @Test
    public void testGetMatchingAccessibleConstructorAssignable() {
        // SubClass is assignable to BaseClass, so the (BaseClass) constructor should match.
        final Constructor<PublicClass> ctor = ConstructorUtils.getMatchingAccessibleConstructor(PublicClass.class, SubClass.class);
        assertNotNull(ctor);
        assertEquals(BaseClass.class, ctor.getParameterTypes()[0]);
    }

    @Test
    public void testGetMatchingAccessibleConstructorVarArgs() {
        final Constructor<PublicClass> ctor = ConstructorUtils.getMatchingAccessibleConstructor(PublicClass.class, String.class, Integer.class, Integer.class);
        assertNotNull(ctor);
        assertTrue(ctor.isVarArgs());
    }

    @Test
    public void testGetMatchingAccessibleConstructorNoMatch() {
        final Constructor<PublicClass> ctor = ConstructorUtils.getMatchingAccessibleConstructor(PublicClass.class, java.util.List.class, java.util.List.class);
        assertNull(ctor);
    }

    @Test
    public void testGetMatchingAccessibleConstructorNullClassThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ConstructorUtils.getMatchingAccessibleConstructor((Class<Object>) null);
            }
        });
    }

    @Test
    public void testInvokeConstructorNoArgs() throws Exception {
        final PublicClass instance = ConstructorUtils.invokeConstructor(PublicClass.class);
        assertEquals("()", instance.calledWith);
    }

    @Test
    public void testInvokeConstructorWithStringArg() throws Exception {
        final PublicClass instance = ConstructorUtils.invokeConstructor(PublicClass.class, "hello");
        assertEquals("(String)", instance.calledWith);
    }

    @Test
    public void testInvokeConstructorChoosesMostSpecificOverObject() throws Exception {
        final PublicClass instance = ConstructorUtils.invokeConstructor(PublicClass.class, new SubClass());
        // SubClass matches both (Object) and (BaseClass); (BaseClass) is more specific.
        assertEquals("(BaseClass)", instance.calledWith);
    }

    @Test
    public void testInvokeConstructorVarArgs() throws Exception {
        final PublicClass instance = ConstructorUtils.invokeConstructor(PublicClass.class, "s", 1, 2, 3);
        assertEquals("(String, int...)", instance.calledWith);
    }

    @Test
    public void testInvokeConstructorNoMatchThrowsNoSuchMethodException() {
        // Two plain Object arguments match none of PublicClass's constructors: not the no-arg or
        // single-arg ones (wrong count), and not the varargs (String, int...) one (first arg isn't a String).
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ConstructorUtils.invokeConstructor(PublicClass.class, new Object(), new Object());
            }
        });
    }

    @Test
    public void testInvokeConstructorAbstractClassThrowsInstantiationException() {
        assertThrows(InstantiationException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ConstructorUtils.invokeConstructor(AbstractClass.class);
            }
        });
    }

    @Test
    public void testInvokeConstructorPropagatesUnderlyingException() {
        final InvocationTargetException thrown = assertThrows(InvocationTargetException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ConstructorUtils.invokeConstructor(PublicClass.class, Boolean.TRUE);
            }
        });
        assertTrue(thrown.getCause() instanceof IllegalStateException);
    }

    @Test
    public void testInvokeConstructorWithExplicitParameterTypes() throws Exception {
        final PublicClass instance = ConstructorUtils.invokeConstructor(PublicClass.class, new Object[] { "x" }, new Class<?>[] { Object.class });
        assertEquals("(Object)", instance.calledWith);
    }

    @Test
    public void testInvokeExactConstructorExactMatch() throws Exception {
        final PublicClass instance = ConstructorUtils.invokeExactConstructor(PublicClass.class, "hello");
        assertEquals("(String)", instance.calledWith);
    }

    @Test
    public void testInvokeExactConstructorNoWideningThrows() {
        // SubClass is not an exact parameter-type match for (Object) or (BaseClass) constructors;
        // exact-match search requires the signature itself, so this should fail.
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ConstructorUtils.invokeExactConstructor(PublicClass.class, new SubClass());
            }
        });
    }

    @Test
    public void testInvokeExactConstructorWithExplicitParameterTypes() throws Exception {
        final PublicClass instance = ConstructorUtils.invokeExactConstructor(PublicClass.class, new Object[] { "x" }, new Class<?>[] { String.class });
        assertEquals("(String)", instance.calledWith);
    }

    @Test
    public void testInvokeExactConstructorNullParameterTypesTreatedAsEmpty() throws Exception {
        final PublicClass instance = ConstructorUtils.invokeExactConstructor(PublicClass.class, null, null);
        assertEquals("()", instance.calledWith);
    }

    @Test
    public void testDeprecatedPublicNoArgConstructorExists() {
        assertNotNull(new ConstructorUtils());
    }
}
