/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests {@link MethodUtils}.
 */
public class MethodUtilsAgentTest {

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    public @interface MarkerAnnotation {
        // empty
    }

    interface PackagePrivateInterface {
        String interfaceMethod();
    }

    public static class Base {
        public String overridden() {
            return "base";
        }

        @MarkerAnnotation
        public void annotated() {
            // empty
        }
    }

    public static class Derived extends Base implements PackagePrivateInterface {

        public final List<String> callLog = new java.util.ArrayList<String>();

        @Override
        public String overridden() {
            return "derived";
        }

        @Override
        public String interfaceMethod() {
            return "fromInterface";
        }

        public String echo(final String s) {
            callLog.add("echo(String)");
            return "echo:" + s;
        }

        public String overload(final Object o) {
            return "overload(Object)";
        }

        public String overload(final String s) {
            return "overload(String)";
        }

        public String varArgs(final String first, final int... rest) {
            return first + ":" + rest.length;
        }

        private String privateMethod() {
            return "private";
        }

        public String throwingMethod() {
            throw new IllegalStateException("boom");
        }

        public static String staticEcho(final String s) {
            return "static:" + s;
        }

        @MarkerAnnotation
        public void annotatedOverride() {
            // empty
        }
    }

    @Test
    public void testGetMethodObjectFound() {
        final Method m = MethodUtils.getMethodObject(Derived.class, "echo", String.class);
        assertNotNull(m);
        assertEquals("echo", m.getName());
    }

    @Test
    public void testGetMethodObjectNotFoundReturnsNull() {
        assertNull(MethodUtils.getMethodObject(Derived.class, "doesNotExist"));
    }

    @Test
    public void testGetMethodObjectNullNameReturnsNull() {
        assertNull(MethodUtils.getMethodObject(Derived.class, null));
    }

    @Test
    public void testGetMethodObjectNullClassReturnsNull() {
        assertNull(MethodUtils.getMethodObject(null, "echo", String.class));
    }

    @Test
    public void testGetAccessibleMethodPublic() throws Exception {
        final Method raw = Derived.class.getMethod("echo", String.class);
        final Method result = MethodUtils.getAccessibleMethod(raw);
        assertNotNull(result);
        assertEquals(raw, result);
    }

    @Test
    public void testGetAccessibleMethodNull() {
        assertNull(MethodUtils.getAccessibleMethod((Method) null));
    }

    @Test
    public void testGetAccessibleMethodByNameNotFound() {
        assertNull(MethodUtils.getAccessibleMethod(Derived.class, "doesNotExist"));
    }

    @Test
    public void testGetAccessibleMethodByNameFound() {
        final Method result = MethodUtils.getAccessibleMethod(Derived.class, "echo", String.class);
        assertNotNull(result);
        assertEquals("echo", result.getName());
    }

    @Test
    public void testGetMatchingAccessibleMethodExact() {
        final Method m = MethodUtils.getMatchingAccessibleMethod(Derived.class, "echo", String.class);
        assertNotNull(m);
        assertEquals(String.class, m.getParameterTypes()[0]);
    }

    @Test
    public void testGetMatchingAccessibleMethodChoosesMostSpecificOverload() {
        final Method m = MethodUtils.getMatchingAccessibleMethod(Derived.class, "overload", String.class);
        assertNotNull(m);
        assertEquals(String.class, m.getParameterTypes()[0]);
    }

    @Test
    public void testGetMatchingAccessibleMethodVarArgs() {
        final Method m = MethodUtils.getMatchingAccessibleMethod(Derived.class, "varArgs", String.class, Integer.class, Integer.class);
        assertNotNull(m);
        assertTrue(m.isVarArgs());
    }

    @Test
    public void testGetMatchingAccessibleMethodNoMatchReturnsNull() {
        assertNull(MethodUtils.getMatchingAccessibleMethod(Derived.class, "echo", Integer.class, Integer.class));
    }

    @Test
    public void testGetMatchingMethodExact() {
        final Method m = MethodUtils.getMatchingMethod(Derived.class, "echo", String.class);
        assertNotNull(m);
        assertEquals("echo", m.getName());
    }

    @Test
    public void testGetMatchingMethodFindsPrivate() {
        final Method m = MethodUtils.getMatchingMethod(Derived.class, "privateMethod");
        assertNotNull(m);
        assertEquals("privateMethod", m.getName());
    }

    @Test
    public void testGetMatchingMethodNoMatchReturnsNull() {
        assertNull(MethodUtils.getMatchingMethod(Derived.class, "noSuchMethodAtAll"));
    }

    @Test
    public void testGetMatchingMethodNullClassThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.getMatchingMethod(null, "echo");
            }
        });
    }

    @Test
    public void testGetMatchingMethodEmptyNameThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.getMatchingMethod(Derived.class, "");
            }
        });
    }

    @Test
    public void testGetAnnotationDirect() throws Exception {
        final Method m = Base.class.getMethod("annotated");
        final MarkerAnnotation annotation = MethodUtils.getAnnotation(m, MarkerAnnotation.class, false, false);
        assertNotNull(annotation);
    }

    @Test
    public void testGetAnnotationNullMethodThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.getAnnotation(null, MarkerAnnotation.class, false, false);
            }
        });
    }

    @Test
    public void testGetAnnotationNullAnnotationClassThrows() throws Exception {
        final Method m = Base.class.getMethod("annotated");
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.getAnnotation(m, null, false, false);
            }
        });
    }

    @Test
    public void testGetAnnotationNotPresentReturnsNull() throws Exception {
        final Method m = Derived.class.getMethod("echo", String.class);
        assertNull(MethodUtils.getAnnotation(m, MarkerAnnotation.class, false, false));
    }

    @Test
    public void testGetMethodsWithAnnotation() {
        final Method[] methods = MethodUtils.getMethodsWithAnnotation(Base.class, MarkerAnnotation.class);
        assertEquals(1, methods.length);
        assertEquals("annotated", methods[0].getName());
    }

    @Test
    public void testGetMethodsListWithAnnotationEmptyWhenNoneMatch() {
        final List<Method> methods = MethodUtils.getMethodsListWithAnnotation(Derived.class, Deprecated.class);
        assertTrue(methods.isEmpty());
    }

    @Test
    public void testGetMethodsListWithAnnotationNullClassThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.getMethodsListWithAnnotation(null, MarkerAnnotation.class);
            }
        });
    }

    @Test
    public void testInvokeMethodNoArgs() throws Exception {
        final Derived d = new Derived();
        final Object result = MethodUtils.invokeMethod(d, "overridden");
        assertEquals("derived", result);
    }

    @Test
    public void testInvokeMethodWithArgs() throws Exception {
        final Derived d = new Derived();
        final Object result = MethodUtils.invokeMethod(d, "echo", "hi");
        assertEquals("echo:hi", result);
        assertEquals(1, d.callLog.size());
    }

    @Test
    public void testInvokeMethodChoosesMostSpecificOverload() throws Exception {
        final Derived d = new Derived();
        final Object result = MethodUtils.invokeMethod(d, "overload", "hi");
        assertEquals("overload(String)", result);
    }

    @Test
    public void testInvokeMethodVarArgs() throws Exception {
        final Derived d = new Derived();
        final Object result = MethodUtils.invokeMethod(d, "varArgs", "x", 1, 2);
        assertEquals("x:2", result);
    }

    @Test
    public void testInvokeMethodNoMatchThrowsNoSuchMethodException() {
        final Derived d = new Derived();
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeMethod(d, "doesNotExist");
            }
        });
    }

    @Test
    public void testInvokeMethodNullObjectThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeMethod(null, "echo", "hi");
            }
        });
    }

    @Test
    public void testInvokeMethodPropagatesUnderlyingException() {
        final Derived d = new Derived();
        final InvocationTargetException thrown = assertThrows(InvocationTargetException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeMethod(d, "throwingMethod");
            }
        });
        assertTrue(thrown.getCause() instanceof IllegalStateException);
    }

    @Test
    public void testInvokeMethodForceAccessInvokesPrivateMethod() throws Exception {
        final Derived d = new Derived();
        final Object result = MethodUtils.invokeMethod(d, true, "privateMethod");
        assertEquals("private", result);
    }

    @Test
    public void testInvokeMethodWithoutForceAccessFailsOnPrivateMethod() {
        final Derived d = new Derived();
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeMethod(d, false, "privateMethod");
            }
        });
    }

    @Test
    public void testInvokeExactMethodMatch() throws Exception {
        final Derived d = new Derived();
        final Object result = MethodUtils.invokeExactMethod(d, "echo", "hi");
        assertEquals("echo:hi", result);
    }

    @Test
    public void testInvokeExactMethodNoWideningThrows() {
        final Derived d = new Derived();
        // overload(Object) is declared, but passing a String does not exactly match (Object);
        // overload(String) exists and matches exactly, so this is really testing a genuine mismatch:
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeExactMethod(d, "echo", Integer.valueOf(1));
            }
        });
    }

    @Test
    public void testInvokeStaticMethod() throws Exception {
        final Object result = MethodUtils.invokeStaticMethod(Derived.class, "staticEcho", "hi");
        assertEquals("static:hi", result);
    }

    @Test
    public void testInvokeStaticMethodNoMatchThrows() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeStaticMethod(Derived.class, "doesNotExist");
            }
        });
    }

    @Test
    public void testInvokeExactStaticMethod() throws Exception {
        final Object result = MethodUtils.invokeExactStaticMethod(Derived.class, "staticEcho", "hi");
        assertEquals("static:hi", result);
    }

    @Test
    public void testGetOverrideHierarchy() {
        final Method baseMethod;
        try {
            baseMethod = Base.class.getMethod("overridden");
        } catch (final NoSuchMethodException e) {
            throw new AssertionError(e);
        }
        final java.util.Set<Method> hierarchy = MethodUtils.getOverrideHierarchy(baseMethod, org.apache.commons.lang3.ClassUtils.Interfaces.EXCLUDE);
        assertEquals(1, hierarchy.size());
        assertTrue(hierarchy.contains(baseMethod));
    }

    @Test
    public void testGetOverrideHierarchyNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.getOverrideHierarchy(null, org.apache.commons.lang3.ClassUtils.Interfaces.EXCLUDE);
            }
        });
    }

    @Test
    public void testDeprecatedPublicNoArgConstructorExists() {
        assertNotNull(new MethodUtils());
    }

    @Test
    public void testVarArgsEmptyRest() throws Exception {
        final Derived d = new Derived();
        final Object result = MethodUtils.invokeMethod(d, "varArgs", "onlyFirst");
        assertEquals("onlyFirst:0", result);
    }

    @Test
    public void testArraySorterUnused() {
        // Sanity check for the array returned by getMethodsWithAnnotation being a real array, not null.
        final Method[] methods = MethodUtils.getMethodsWithAnnotation(Derived.class, Deprecated.class);
        assertArrayEquals(new Method[0], methods);
        assertFalse(methods.length > 0);
    }
}
