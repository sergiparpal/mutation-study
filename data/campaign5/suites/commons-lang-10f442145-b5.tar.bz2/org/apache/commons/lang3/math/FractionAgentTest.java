/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link Fraction}.
 */
class FractionAgentTest {

    @Test
    void testGetFractionDouble() {
        assertEquals(Fraction.getFraction(1, 2), Fraction.getFraction(0.5d));
        assertEquals(Fraction.getFraction(-1, 2), Fraction.getFraction(-0.5d));
        assertEquals(Fraction.ZERO, Fraction.getFraction(0.0d));
        assertEquals(Fraction.getFraction(7, 1), Fraction.getFraction(7.0d));
    }

    @Test
    void testGetFractionDoubleTooLargeThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction((double) Integer.MAX_VALUE + 1.0d);
            }
        });
    }

    @Test
    void testGetFractionDoubleNaNThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(Double.NaN);
            }
        });
    }

    @Test
    void testGetFractionIntInt() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertEquals(3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    void testGetFractionIntIntNegativeDenominatorMovesSignToNumerator() {
        final Fraction f = Fraction.getFraction(3, -7);
        assertEquals(-3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    void testGetFractionIntIntZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(1, 0);
            }
        });
    }

    @Test
    void testGetFractionIntIntOverflowOnNegateThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(Integer.MIN_VALUE, -1);
            }
        });
    }

    @Test
    void testGetFractionWholeNumeratorDenominator() {
        final Fraction f = Fraction.getFraction(1, 3, 7);
        assertEquals(10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    void testGetFractionWholeNumeratorDenominatorNegativeWhole() {
        final Fraction f = Fraction.getFraction(-1, 3, 7);
        assertEquals(-10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    void testGetFractionWholeZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(1, 1, 0);
            }
        });
    }

    @Test
    void testGetFractionWholeNegativeDenominatorThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(1, 1, -1);
            }
        });
    }

    @Test
    void testGetFractionWholeNegativeNumeratorThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(1, -1, 2);
            }
        });
    }

    @Test
    void testGetFractionWholeNumeratorOverflowThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(Integer.MAX_VALUE, 1, 2);
            }
        });
    }

    @Test
    void testGetFractionStringDoubleFormat() {
        final Fraction f = Fraction.getFraction("0.5");
        assertEquals(Fraction.getFraction(1, 2), f);
    }

    @Test
    void testGetFractionStringWholeNumeratorDenominatorFormat() {
        final Fraction f = Fraction.getFraction("1 3/7");
        assertEquals(10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    void testGetFractionStringNumeratorDenominatorFormat() {
        final Fraction f = Fraction.getFraction("3/7");
        assertEquals(3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    void testGetFractionStringWholeNumberFormat() {
        final Fraction f = Fraction.getFraction("5");
        assertEquals(5, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    void testGetFractionStringNullThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction((String) null);
            }
        });
    }

    @Test
    void testGetFractionStringMalformedWholeFormatThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction("1 3-7");
            }
        });
    }

    @Test
    void testGetFractionStringInvalidThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getFraction("abc");
            }
        });
    }

    @Test
    void testGetReducedFraction() {
        final Fraction f = Fraction.getReducedFraction(2, 4);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    void testGetReducedFractionZeroNumeratorNormalizesToZero() {
        assertSame(Fraction.ZERO, Fraction.getReducedFraction(0, 5));
    }

    @Test
    void testGetReducedFractionNegativeDenominator() {
        final Fraction f = Fraction.getReducedFraction(2, -4);
        assertEquals(-1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    void testGetReducedFractionZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.getReducedFraction(1, 0);
            }
        });
    }

    @Test
    void testAbs() {
        assertEquals(Fraction.getFraction(3, 5), Fraction.getFraction(3, 5).abs());
        assertEquals(Fraction.getFraction(3, 5), Fraction.getFraction(-3, 5).abs());
        assertSame(Fraction.ZERO, Fraction.ZERO.abs());
    }

    @Test
    void testAbsSamePositiveInstance() {
        final Fraction f = Fraction.getFraction(3, 5);
        assertSame(f, f.abs());
    }

    @Test
    void testAdd() {
        final Fraction result = Fraction.getFraction(1, 2).add(Fraction.getFraction(1, 3));
        assertEquals(5, result.getNumerator());
        assertEquals(6, result.getDenominator());
    }

    @Test
    void testAddZeroIdentity() {
        final Fraction f = Fraction.getFraction(1, 3);
        assertEquals(f, Fraction.ZERO.add(f));
        assertSame(f, f.add(Fraction.ZERO));
    }

    @Test
    void testAddNullThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.ONE.add(null);
            }
        });
    }

    @Test
    void testAddOverflowThrows() {
        final Fraction f1 = Fraction.getFraction(Integer.MAX_VALUE, 1);
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                f1.add(Fraction.ONE);
            }
        });
    }

    @Test
    void testCompareTo() {
        assertEquals(0, Fraction.getFraction(1, 2).compareTo(Fraction.getFraction(1, 2)));
        assertEquals(0, Fraction.getFraction(1, 2).compareTo(Fraction.getFraction(2, 4)));
        assertTrue(Fraction.getFraction(1, 3).compareTo(Fraction.getFraction(1, 2)) < 0);
        assertTrue(Fraction.getFraction(1, 2).compareTo(Fraction.getFraction(1, 3)) > 0);
    }

    @Test
    void testCompareToSameInstance() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertEquals(0, f.compareTo(f));
    }

    @Test
    void testCompareToNullThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.ONE.compareTo(null);
            }
        });
    }

    @Test
    void testDivideBy() {
        final Fraction result = Fraction.getFraction(1, 2).divideBy(Fraction.getFraction(1, 3));
        assertEquals(3, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    @Test
    void testDivideByZeroThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.ONE.divideBy(Fraction.ZERO);
            }
        });
    }

    @Test
    void testDivideByNullThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.ONE.divideBy(null);
            }
        });
    }

    @Test
    void testDoubleValue() {
        assertEquals(0.5d, Fraction.getFraction(1, 2).doubleValue(), 0.0d);
        assertEquals(-0.25d, Fraction.getFraction(-1, 4).doubleValue(), 0.0d);
    }

    @Test
    void testEquals() {
        assertEquals(Fraction.getFraction(1, 2), Fraction.getFraction(1, 2));
        assertNotEquals(Fraction.getFraction(1, 2), Fraction.getFraction(2, 4));
        assertNotEquals(Fraction.ONE, "1");
        assertNotEquals(Fraction.ONE, null);
        assertEquals(Fraction.ONE, Fraction.ONE);
    }

    @Test
    void testFloatValue() {
        assertEquals(0.5f, Fraction.getFraction(1, 2).floatValue(), 0.0f);
    }

    @Test
    void testGetDenominatorAndNumerator() {
        final Fraction f = Fraction.getFraction(7, 4);
        assertEquals(7, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    void testGetProperNumerator() {
        assertEquals(3, Fraction.getFraction(7, 4).getProperNumerator());
        assertEquals(3, Fraction.getFraction(-7, 4).getProperNumerator());
        assertEquals(0, Fraction.getFraction(8, 4).getProperNumerator());
    }

    @Test
    void testGetProperWhole() {
        assertEquals(1, Fraction.getFraction(7, 4).getProperWhole());
        assertEquals(-1, Fraction.getFraction(-7, 4).getProperWhole());
        assertEquals(0, Fraction.getFraction(3, 4).getProperWhole());
    }

    @Test
    void testHashCode() {
        assertEquals(Fraction.getFraction(1, 2).hashCode(), Fraction.getFraction(1, 2).hashCode());
        assertNotEquals(Fraction.getFraction(1, 2).hashCode(), Fraction.getFraction(2, 4).hashCode());
    }

    @Test
    void testIntValue() {
        assertEquals(1, Fraction.getFraction(7, 4).intValue());
        assertEquals(-1, Fraction.getFraction(-7, 4).intValue());
        assertEquals(0, Fraction.getFraction(3, 4).intValue());
    }

    @Test
    void testInvert() {
        final Fraction f = Fraction.getFraction(3, 7).invert();
        assertEquals(7, f.getNumerator());
        assertEquals(3, f.getDenominator());
    }

    @Test
    void testInvertNegative() {
        final Fraction f = Fraction.getFraction(-3, 7).invert();
        assertEquals(-7, f.getNumerator());
        assertEquals(3, f.getDenominator());
    }

    @Test
    void testInvertZeroThrows() {
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.ZERO.invert();
            }
        });
    }

    @Test
    void testInvertMinValueNumeratorThrows() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                f.invert();
            }
        });
    }

    @Test
    void testLongValue() {
        assertEquals(1L, Fraction.getFraction(7, 4).longValue());
        assertEquals(-1L, Fraction.getFraction(-7, 4).longValue());
    }

    @Test
    void testMultiplyBy() {
        final Fraction result = Fraction.getFraction(2, 3).multiplyBy(Fraction.getFraction(3, 4));
        assertEquals(1, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    @Test
    void testMultiplyByZero() {
        assertSame(Fraction.ZERO, Fraction.getFraction(2, 3).multiplyBy(Fraction.ZERO));
        assertSame(Fraction.ZERO, Fraction.ZERO.multiplyBy(Fraction.getFraction(2, 3)));
    }

    @Test
    void testMultiplyByNullThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.ONE.multiplyBy(null);
            }
        });
    }

    @Test
    void testNegate() {
        final Fraction f = Fraction.getFraction(3, 7).negate();
        assertEquals(-3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    void testNegateMinValueThrows() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                f.negate();
            }
        });
    }

    @Test
    void testPowOne() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertSame(f, f.pow(1));
    }

    @Test
    void testPowZero() {
        assertSame(Fraction.ONE, Fraction.getFraction(3, 7).pow(0));
        assertSame(Fraction.ONE, Fraction.ZERO.pow(0));
    }

    @Test
    void testPowPositive() {
        final Fraction f = Fraction.getFraction(2, 3).pow(3);
        assertEquals(8, f.getNumerator());
        assertEquals(27, f.getDenominator());
    }

    @Test
    void testPowNegative() {
        final Fraction f = Fraction.getFraction(2, 3).pow(-2);
        assertEquals(9, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    void testPowMinValueDoesNotThrow() {
        final Fraction f = Fraction.getFraction(1, 1);
        final Fraction result = f.pow(Integer.MIN_VALUE);
        assertEquals(1, result.getNumerator());
        assertEquals(1, result.getDenominator());
    }

    @Test
    void testReduce() {
        final Fraction f = Fraction.getFraction(2, 4).reduce();
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    void testReduceAlreadyReducedReturnsSameInstance() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertSame(f, f.reduce());
    }

    @Test
    void testReduceZeroNumeratorNormalizesToZero() {
        final Fraction f = Fraction.getFraction(0, 5);
        assertEquals(Fraction.ZERO, f.reduce());
    }

    @Test
    void testSubtract() {
        final Fraction result = Fraction.getFraction(1, 2).subtract(Fraction.getFraction(1, 3));
        assertEquals(1, result.getNumerator());
        assertEquals(6, result.getDenominator());
    }

    @Test
    void testSubtractNullThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                Fraction.ONE.subtract(null);
            }
        });
    }

    @Test
    void testToProperString() {
        assertEquals("0", Fraction.ZERO.toProperString());
        assertEquals("1", Fraction.ONE.toProperString());
        assertEquals("-1", Fraction.getFraction(-1, 1).toProperString());
        assertEquals("1 3/4", Fraction.getFraction(7, 4).toProperString());
        assertEquals("-1 3/4", Fraction.getFraction(-7, 4).toProperString());
        assertEquals("3/4", Fraction.getFraction(3, 4).toProperString());
    }

    @Test
    void testToString() {
        assertEquals("3/4", Fraction.getFraction(3, 4).toString());
        assertEquals("-3/4", Fraction.getFraction(-3, 4).toString());
    }

    @Test
    void testConstants() {
        assertEquals(Fraction.getFraction(0, 1), Fraction.ZERO);
        assertEquals(Fraction.getFraction(1, 1), Fraction.ONE);
        assertEquals(Fraction.getFraction(1, 2), Fraction.ONE_HALF);
        assertEquals(Fraction.getFraction(1, 3), Fraction.ONE_THIRD);
        assertEquals(Fraction.getFraction(2, 3), Fraction.TWO_THIRDS);
        assertEquals(Fraction.getFraction(1, 4), Fraction.ONE_QUARTER);
        assertEquals(Fraction.getFraction(2, 4), Fraction.TWO_QUARTERS);
        assertEquals(Fraction.getFraction(3, 4), Fraction.THREE_QUARTERS);
        assertEquals(Fraction.getFraction(1, 5), Fraction.ONE_FIFTH);
        assertEquals(Fraction.getFraction(2, 5), Fraction.TWO_FIFTHS);
        assertEquals(Fraction.getFraction(3, 5), Fraction.THREE_FIFTHS);
        assertEquals(Fraction.getFraction(4, 5), Fraction.FOUR_FIFTHS);
    }

    @Test
    void testSerialization() throws Exception {
        final Fraction original = Fraction.getFraction(3, 7);
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        final ObjectOutputStream oos = new ObjectOutputStream(baos);
        oos.writeObject(original);
        oos.close();

        final ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(baos.toByteArray()));
        final Fraction deserialized = (Fraction) ois.readObject();
        ois.close();

        assertEquals(original, deserialized);
        assertEquals(original.hashCode(), deserialized.hashCode());
        assertFalse(deserialized == original);
    }
}
