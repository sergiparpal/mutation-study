/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.ClassUtils.Interfaces;
import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link MethodUtils}.
 */
public class MethodUtilsAgentTest {

    @Retention(RetentionPolicy.RUNTIME)
    private @interface MarkerAnnotation {
    }

    public interface MarkerInterface {
        void interfaceMethod();
    }

    public interface PublicGreeter {
        String greet();
    }

    static class PackagePrivateGreeterImpl implements PublicGreeter {
        @Override
        public String greet() {
            return "hello";
        }
    }

    public static class GrandParent {
        @MarkerAnnotation
        public String greet() {
            return "grandparent";
        }
    }

    public static class Parent extends GrandParent implements MarkerInterface {
        @Override
        public String greet() {
            return "parent";
        }

        @Override
        public void interfaceMethod() {
            // no-op
        }
    }

    public static class Child extends Parent {
        @Override
        public String greet() {
            return "child";
        }

        public String overload(final String s) {
            return "String:" + s;
        }

        public String overload(final Object o) {
            return "Object:" + o;
        }

        public String overload(final int i) {
            return "int:" + i;
        }

        public String flag(final boolean b) {
            return "flag:" + b;
        }

        public String varArgsMethod(final String first, final String... rest) {
            return first + ":" + rest.length;
        }

        public static String staticMethod(final String s) {
            return "static:" + s;
        }

        public String throwing() {
            throw new IllegalStateException("boom");
        }

        @SuppressWarnings("unused")
        private String privateMethod() {
            return "private result";
        }
    }

    interface IfaceX {
    }

    interface IfaceY {
    }

    static class ArgClass implements IfaceX, IfaceY {
    }

    static class Ambiguous {
        public String process(final IfaceX x) {
            return "X";
        }

        public String process(final IfaceY y) {
            return "Y";
        }
    }

    // --- getAccessibleMethod ---

    @Test
    public void testGetAccessibleMethodFindsInterfaceMethodForPackagePrivateImpl() throws Exception {
        final Method declared = PackagePrivateGreeterImpl.class.getMethod("greet");
        assertEquals(PackagePrivateGreeterImpl.class, declared.getDeclaringClass());
        final Method accessible = MethodUtils.getAccessibleMethod(PackagePrivateGreeterImpl.class, declared);
        assertNotNull(accessible);
        assertEquals(PublicGreeter.class, accessible.getDeclaringClass());
    }

    @Test
    public void testGetAccessibleMethodByNameAndParams() {
        final Method method = MethodUtils.getAccessibleMethod(Child.class, "greet");
        assertNotNull(method);
        assertEquals("greet", method.getName());
    }

    @Test
    public void testGetAccessibleMethodReturnsNullForNonExistentMethod() {
        assertNull(MethodUtils.getAccessibleMethod(Child.class, "doesNotExist"));
    }

    @Test
    public void testGetAccessibleMethodNullMethodReturnsNull() {
        assertNull(MethodUtils.getAccessibleMethod((Method) null));
    }

    @Test
    public void testGetAccessibleMethodRejectsPrivateMethod() throws Exception {
        final Method privateMethod = Child.class.getDeclaredMethod("privateMethod");
        assertNull(MethodUtils.getAccessibleMethod(Child.class, privateMethod));
    }

    // --- getMatchingAccessibleMethod ---

    @Test
    public void testGetMatchingAccessibleMethodExactOverload() {
        final Method method = MethodUtils.getMatchingAccessibleMethod(Child.class, "overload", String.class);
        assertNotNull(method);
        assertArrayEqualsParams(new Class<?>[] {String.class}, method.getParameterTypes());
    }

    @Test
    public void testGetMatchingAccessibleMethodPicksMostSpecificOverload() {
        // A String argument is assignable to both overload(String) and overload(Object);
        // the more specific overload(String) must win.
        final Method method = MethodUtils.getMatchingAccessibleMethod(Child.class, "overload", String.class);
        assertEquals(String.class, method.getParameterTypes()[0]);
    }

    @Test
    public void testGetMatchingAccessibleMethodAutoboxing() {
        final Method method = MethodUtils.getMatchingAccessibleMethod(Child.class, "overload", Integer.class);
        assertNotNull(method);
        assertEquals(int.class, method.getParameterTypes()[0]);
    }

    @Test
    public void testGetMatchingAccessibleMethodReturnsNullWhenNoMatch() {
        assertNull(MethodUtils.getMatchingAccessibleMethod(Child.class, "noSuchMethodAtAll", String.class));
    }

    // --- getMatchingMethod ---

    @Test
    public void testGetMatchingMethodExactMatch() {
        final Method method = MethodUtils.getMatchingMethod(Child.class, "overload", String.class);
        assertNotNull(method);
        assertEquals(String.class, method.getParameterTypes()[0]);
    }

    @Test
    public void testGetMatchingMethodAssignableMatch() {
        final Method method = MethodUtils.getMatchingMethod(Child.class, "overload", Double.class);
        assertNotNull(method);
        assertEquals(Object.class, method.getParameterTypes()[0]);
    }

    @Test
    public void testGetMatchingMethodNullClassThrowsNpe() {
        assertThrows(NullPointerException.class, () -> MethodUtils.getMatchingMethod(null, "overload", String.class));
    }

    @Test
    public void testGetMatchingMethodEmptyNameThrowsIllegalArgument() {
        assertThrows(IllegalArgumentException.class, () -> MethodUtils.getMatchingMethod(Child.class, ""));
    }

    @Test
    public void testGetMatchingMethodNullNameThrowsNpe() {
        assertThrows(NullPointerException.class, () -> MethodUtils.getMatchingMethod(Child.class, (String) null));
    }

    @Test
    public void testGetMatchingMethodAmbiguousThrowsIllegalState() {
        final IllegalStateException ex = assertThrows(IllegalStateException.class,
                () -> MethodUtils.getMatchingMethod(Ambiguous.class, "process", ArgClass.class));
        assertTrue(ex.getMessage().contains("process"));
    }

    // --- getMethodObject ---

    @Test
    public void testGetMethodObjectFound() {
        final Method method = MethodUtils.getMethodObject(Child.class, "greet");
        assertNotNull(method);
        assertEquals("greet", method.getName());
    }

    @Test
    public void testGetMethodObjectNullName() {
        assertNull(MethodUtils.getMethodObject(Child.class, null));
    }

    @Test
    public void testGetMethodObjectNullClass() {
        assertNull(MethodUtils.getMethodObject(null, "greet"));
    }

    @Test
    public void testGetMethodObjectNotFound() {
        assertNull(MethodUtils.getMethodObject(Child.class, "nope"));
    }

    // --- getAnnotation ---

    @Test
    public void testGetAnnotationDirectlyPresent() throws Exception {
        final Method method = GrandParent.class.getMethod("greet");
        final MarkerAnnotation annotation = MethodUtils.getAnnotation(method, MarkerAnnotation.class, false, false);
        assertNotNull(annotation);
    }

    @Test
    public void testGetAnnotationSearchSupersFindsParentAnnotation() throws Exception {
        final Method method = Child.class.getMethod("greet");
        assertNull(method.getAnnotation(MarkerAnnotation.class));
        final MarkerAnnotation found = MethodUtils.getAnnotation(method, MarkerAnnotation.class, true, true);
        assertNotNull(found);
    }

    @Test
    public void testGetAnnotationWithoutSearchSupersReturnsNull() throws Exception {
        final Method method = Child.class.getMethod("greet");
        assertNull(MethodUtils.getAnnotation(method, MarkerAnnotation.class, false, true));
    }

    @Test
    public void testGetAnnotationNullMethodThrowsNpe() {
        assertThrows(NullPointerException.class, () -> MethodUtils.getAnnotation(null, MarkerAnnotation.class, true, true));
    }

    @Test
    public void testGetAnnotationNullAnnotationClassThrowsNpe() throws Exception {
        final Method method = Child.class.getMethod("greet");
        assertThrows(NullPointerException.class, () -> MethodUtils.getAnnotation(method, null, true, true));
    }

    // --- getMethodsWithAnnotation / getMethodsListWithAnnotation ---

    @Test
    public void testGetMethodsWithAnnotationNoSearchSupers() {
        final Method[] methods = MethodUtils.getMethodsWithAnnotation(GrandParent.class, MarkerAnnotation.class);
        assertEquals(1, methods.length);
        assertEquals("greet", methods[0].getName());
    }

    @Test
    public void testGetMethodsWithAnnotationChildWithoutSearchSupersFindsNone() {
        final Method[] methods = MethodUtils.getMethodsWithAnnotation(Child.class, MarkerAnnotation.class);
        assertEquals(0, methods.length);
    }

    @Test
    public void testGetMethodsListWithAnnotationSearchSupersFindsInherited() {
        final List<Method> methods = MethodUtils.getMethodsListWithAnnotation(Child.class, MarkerAnnotation.class, true, false);
        assertEquals(1, methods.size());
        assertEquals(GrandParent.class, methods.get(0).getDeclaringClass());
    }

    @Test
    public void testGetMethodsWithAnnotationNullClassThrowsNpe() {
        assertThrows(NullPointerException.class, () -> MethodUtils.getMethodsWithAnnotation(null, MarkerAnnotation.class));
    }

    @Test
    public void testGetMethodsWithAnnotationNullAnnotationThrowsNpe() {
        assertThrows(NullPointerException.class, () -> MethodUtils.getMethodsWithAnnotation(Child.class, null));
    }

    // --- getOverrideHierarchy ---

    @Test
    public void testGetOverrideHierarchyExcludeInterfaces() throws Exception {
        final Method method = Child.class.getMethod("greet");
        final Set<Method> hierarchy = MethodUtils.getOverrideHierarchy(method, Interfaces.EXCLUDE);
        assertEquals(3, hierarchy.size());
        final Method[] asArray = hierarchy.toArray(new Method[0]);
        assertEquals(Child.class, asArray[0].getDeclaringClass());
        assertEquals(Parent.class, asArray[1].getDeclaringClass());
        assertEquals(GrandParent.class, asArray[2].getDeclaringClass());
    }

    @Test
    public void testGetOverrideHierarchyNullMethodThrowsNpe() {
        assertThrows(NullPointerException.class, () -> MethodUtils.getOverrideHierarchy(null, Interfaces.EXCLUDE));
    }

    // --- invokeMethod ---

    @Test
    public void testInvokeMethodNoArgs() throws Exception {
        final Child child = new Child();
        assertEquals("child", MethodUtils.invokeMethod(child, "greet"));
    }

    @Test
    public void testInvokeMethodWithArgsAutoboxing() throws Exception {
        final Child child = new Child();
        assertEquals("flag:true", MethodUtils.invokeMethod(child, "flag", Boolean.TRUE));
    }

    @Test
    public void testInvokeMethodVarArgsMultiple() throws Exception {
        final Child child = new Child();
        assertEquals("a:2", MethodUtils.invokeMethod(child, "varArgsMethod", "a", "b", "c"));
    }

    @Test
    public void testInvokeMethodVarArgsNone() throws Exception {
        final Child child = new Child();
        assertEquals("a:0", MethodUtils.invokeMethod(child, "varArgsMethod", "a"));
    }

    @Test
    public void testInvokeMethodVarArgsAlreadyCanonicalArray() throws Exception {
        final Child child = new Child();
        final Object result = MethodUtils.invokeMethod(child, "varArgsMethod", new Object[] {"a", new String[] {"x", "y"}});
        assertEquals("a:2", result);
    }

    @Test
    public void testInvokeMethodNoSuchMethodThrows() {
        final Child child = new Child();
        assertThrows(NoSuchMethodException.class, () -> MethodUtils.invokeMethod(child, "noSuchMethod"));
    }

    @Test
    public void testInvokeMethodNullObjectThrowsNpe() {
        assertThrows(NullPointerException.class, () -> MethodUtils.invokeMethod(null, "greet"));
    }

    @Test
    public void testInvokeMethodPropagatesInvocationTargetException() {
        final Child child = new Child();
        final InvocationTargetException ex = assertThrows(InvocationTargetException.class, () -> MethodUtils.invokeMethod(child, "throwing"));
        assertTrue(ex.getCause() instanceof IllegalStateException);
        assertEquals("boom", ex.getCause().getMessage());
    }

    @Test
    public void testInvokeMethodForceAccessInvokesPrivateMethod() throws Exception {
        final Child child = new Child();
        assertEquals("private result", MethodUtils.invokeMethod(child, true, "privateMethod"));
    }

    @Test
    public void testInvokeMethodWithoutForceAccessRejectsPrivateMethod() {
        final Child child = new Child();
        assertThrows(NoSuchMethodException.class, () -> MethodUtils.invokeMethod(child, false, "privateMethod"));
    }

    // --- invokeExactMethod ---

    @Test
    public void testInvokeExactMethodMatchesExactType() throws Exception {
        final Child child = new Child();
        assertEquals("String:hi", MethodUtils.invokeExactMethod(child, "overload", "hi"));
    }

    @Test
    public void testInvokeExactMethodMatchesObjectOverload() throws Exception {
        final Child child = new Child();
        final Object arg = new Object();
        assertEquals("Object:" + arg, MethodUtils.invokeExactMethod(child, "overload", arg));
    }

    @Test
    public void testInvokeExactMethodFailsOnPrimitiveMismatch() {
        final Child child = new Child();
        // Integer.class does not exactly match the declared primitive int parameter.
        assertThrows(NoSuchMethodException.class, () -> MethodUtils.invokeExactMethod(child, "overload", Integer.valueOf(5)));
    }

    // --- invokeStaticMethod / invokeExactStaticMethod ---

    @Test
    public void testInvokeStaticMethod() throws Exception {
        assertEquals("static:x", MethodUtils.invokeStaticMethod(Child.class, "staticMethod", "x"));
    }

    @Test
    public void testInvokeExactStaticMethod() throws Exception {
        assertEquals("static:y", MethodUtils.invokeExactStaticMethod(Child.class, "staticMethod", "y"));
    }

    @Test
    public void testInvokeStaticMethodNoSuchMethodThrows() {
        assertThrows(NoSuchMethodException.class, () -> MethodUtils.invokeStaticMethod(Child.class, "noSuchStaticMethod"));
    }

    private static void assertArrayEqualsParams(final Class<?>[] expected, final Class<?>[] actual) {
        assertEquals(expected.length, actual.length);
        for (int i = 0; i < expected.length; i++) {
            assertEquals(expected[i], actual[i]);
        }
    }
}
