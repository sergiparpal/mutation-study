/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Random;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

public class RandomStringUtilsAgentTest {

    @Test
    public void testSingletonsAreStableAndDistinct() {
        final RandomStringUtils insecure = RandomStringUtils.insecure();
        final RandomStringUtils secure = RandomStringUtils.secure();
        final RandomStringUtils secureStrong = RandomStringUtils.secureStrong();
        assertNotNull(insecure);
        assertNotNull(secure);
        assertNotNull(secureStrong);
        assertSame(insecure, RandomStringUtils.insecure());
        assertSame(secure, RandomStringUtils.secure());
        assertSame(secureStrong, RandomStringUtils.secureStrong());
    }

    @Test
    public void testRandomZeroCountReturnsEmptyString() {
        assertEquals("", RandomStringUtils.random(0));
        assertEquals("", RandomStringUtils.random(0, true, true));
        assertEquals("", RandomStringUtils.random(0, (char[]) null));
        assertEquals("", RandomStringUtils.random(0, (String) null));
        assertEquals("", RandomStringUtils.secure().next(0));
    }

    @Test
    public void testRandomNegativeCountThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(-1);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.secure().next(-5);
            }
        });
    }

    @Test
    public void testRandomWithEmptyCharsArrayThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, new char[0]);
            }
        });
    }

    @Test
    public void testRandomWithCustomCharsOnlyUsesThoseChars() {
        final char[] chars = { 'x', 'y', 'z' };
        final String result = RandomStringUtils.random(100, chars);
        assertEquals(100, result.length());
        for (int i = 0; i < result.length(); i++) {
            final char c = result.charAt(i);
            assertTrue(c == 'x' || c == 'y' || c == 'z', "Unexpected char: " + c);
        }
    }

    @Test
    public void testRandomAlphabeticOnlyContainsLetters() {
        final String result = RandomStringUtils.randomAlphabetic(200);
        assertEquals(200, result.length());
        for (int i = 0; i < result.length(); i++) {
            assertTrue(Character.isLetter(result.charAt(i)));
        }
    }

    @Test
    public void testRandomNumericOnlyContainsDigits() {
        final String result = RandomStringUtils.randomNumeric(200);
        assertEquals(200, result.length());
        for (int i = 0; i < result.length(); i++) {
            assertTrue(Character.isDigit(result.charAt(i)));
        }
    }

    @Test
    public void testRandomAlphanumericOnlyContainsLettersOrDigits() {
        final String result = RandomStringUtils.randomAlphanumeric(200);
        assertEquals(200, result.length());
        for (int i = 0; i < result.length(); i++) {
            final char c = result.charAt(i);
            assertTrue(Character.isLetter(c) || Character.isDigit(c));
        }
    }

    @Test
    public void testRandomAsciiInExpectedRange() {
        final String result = RandomStringUtils.randomAscii(200);
        assertEquals(200, result.length());
        for (int i = 0; i < result.length(); i++) {
            final char c = result.charAt(i);
            assertTrue(c >= 32 && c <= 126, "Char out of ASCII range: " + (int) c);
        }
    }

    @Test
    public void testRandomGraphExcludesSpace() {
        final String result = RandomStringUtils.randomGraph(200);
        assertEquals(200, result.length());
        for (int i = 0; i < result.length(); i++) {
            final char c = result.charAt(i);
            assertTrue(c >= 33 && c <= 126, "Char out of graph range: " + (int) c);
        }
    }

    @Test
    public void testRandomPrintIncludesOnlyPrintableAscii() {
        final String result = RandomStringUtils.randomPrint(200);
        assertEquals(200, result.length());
        for (int i = 0; i < result.length(); i++) {
            final char c = result.charAt(i);
            assertTrue(c >= 32 && c <= 126, "Char out of print range: " + (int) c);
        }
    }

    @Test
    public void testRandomAlphabeticMinMaxBoundaryProducesLengthWithinRange() {
        for (int i = 0; i < 20; i++) {
            final String result = RandomStringUtils.randomAlphabetic(3, 6);
            assertTrue(result.length() >= 3 && result.length() < 6,
                    "Length " + result.length() + " not in [3,6)");
        }
    }

    @Test
    public void testRandomAlphabeticMinEqualsMaxProducesFixedLength() {
        final String result = RandomStringUtils.randomAlphabetic(4, 4);
        assertEquals(4, result.length());
    }

    @Test
    public void testRandomAlphabeticNegativeMinThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.randomAlphabetic(-1, 5);
            }
        });
    }

    @Test
    public void testRandomAlphabeticMaxSmallerThanMinThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.randomAlphabetic(5, 3);
            }
        });
    }

    @Test
    public void testRandomWithNullCharsUsesFullCodePointRangeAndRespectsCount() {
        final String result = RandomStringUtils.random(50, (char[]) null);
        assertEquals(50, result.length());
    }

    @Test
    public void testRandomWithStringCharsMatchesCharArrayBehavior() {
        final String result = RandomStringUtils.random(50, "ab");
        assertEquals(50, result.length());
        for (int i = 0; i < result.length(); i++) {
            final char c = result.charAt(i);
            assertTrue(c == 'a' || c == 'b');
        }
    }

    @Test
    public void testRandomWithEmptyStringCharsThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, "");
            }
        });
    }

    @Test
    public void testFullRandomMethodEndLessThanOrEqualStartThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 10, 5, false, false);
            }
        });
    }

    @Test
    public void testFullRandomMethodNegativeStartThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, -1, 10, false, false);
            }
        });
    }

    @Test
    public void testFullRandomMethodNoLettersInRangeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                // '0'-'9' range only, but letters requested
                RandomStringUtils.random(5, '0', '9' + 1, true, false);
            }
        });
    }

    @Test
    public void testFullRandomMethodNoDigitsInRangeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                // 'A'-'Z' range only, but digits requested
                RandomStringUtils.random(5, 'A', 'Z' + 1, false, true);
            }
        });
    }

    @Test
    public void testFullRandomMethodStartBeyondCharsLengthThrows() {
        final char[] chars = { 'a', 'b', 'c' };
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 5, 5, false, false, chars);
            }
        });
    }

    @Test
    public void testFullRandomMethodWithFixedSeedIsDeterministic() {
        final char[] chars = { 'a', 'b', 'c', 'd', 'e' };
        final String result1 = RandomStringUtils.random(20, 0, chars.length, false, false, chars, new Random(42L));
        final String result2 = RandomStringUtils.random(20, 0, chars.length, false, false, chars, new Random(42L));
        assertEquals(result1, result2);
        assertEquals(20, result1.length());
    }

    @Test
    public void testNextOnInsecureInstanceProducesRequestedLength() {
        final RandomStringUtils insecure = RandomStringUtils.insecure();
        final String result = insecure.next(15);
        assertEquals(15, result.length());
    }

    @Test
    public void testNextAlphabeticMinMaxOnInstance() {
        final RandomStringUtils secure = RandomStringUtils.secure();
        for (int i = 0; i < 10; i++) {
            final String result = secure.nextAlphabetic(2, 5);
            assertTrue(result.length() >= 2 && result.length() < 5);
            for (int j = 0; j < result.length(); j++) {
                assertTrue(Character.isLetter(result.charAt(j)));
            }
        }
    }

    @Test
    public void testDeprecatedNoArgConstructorStillWorks() {
        @SuppressWarnings("deprecation")
        final RandomStringUtils instance = new RandomStringUtils();
        final String result = instance.next(10);
        assertEquals(10, result.length());
    }

    @Test
    public void testToStringContainsClassNameAndRandom() {
        final String result = RandomStringUtils.secure().toString();
        assertNotNull(result);
        assertTrue(result.startsWith("RandomStringUtils ["));
    }

    @Test
    public void testRandomSingleCharacterCount() {
        final String result = RandomStringUtils.randomAlphabetic(1);
        assertEquals(1, result.length());
    }

    @Test
    public void testNextWithNullCharVarargsUsesFullRange() {
        final RandomStringUtils secure = RandomStringUtils.secure();
        final String result = secure.next(10, (char[]) null);
        assertEquals(10, result.length());
    }

    @Test
    public void testNextWithNullStringUsesFullRange() {
        final RandomStringUtils secure = RandomStringUtils.secure();
        final String result = secure.next(10, (String) null);
        assertEquals(10, result.length());
    }
}
