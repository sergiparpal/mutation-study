/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text.translate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.IOException;
import java.io.StringWriter;

import org.junit.jupiter.api.Test;

@Deprecated
class UnicodeUnescaperAgentTest {

    private final UnicodeUnescaper unicodeUnescaper = new UnicodeUnescaper();

    @Test
    void testTranslateBasic() throws IOException {
        final StringWriter out = new StringWriter();
        final int consumed = unicodeUnescaper.translate("\\u0041", 0, out);
        assertEquals(6, consumed);
        assertEquals("A", out.toString());
    }

    @Test
    void testTranslateViaCharSequenceTranslator() {
        assertEquals("ABC", unicodeUnescaper.translate("\\u0041\\u0042\\u0043"));
    }

    @Test
    void testTranslateWithPlusSign() throws IOException {
        final StringWriter out = new StringWriter();
        final int consumed = unicodeUnescaper.translate("\\u+0041", 0, out);
        assertEquals(7, consumed);
        assertEquals("A", out.toString());
    }

    @Test
    void testTranslateWithMultipleUChars() throws IOException {
        final StringWriter out = new StringWriter();
        final int consumed = unicodeUnescaper.translate("\\uuuu0041", 0, out);
        assertEquals(9, consumed);
        assertEquals("A", out.toString());
    }

    @Test
    void testTranslateWithMultipleUCharsAndPlusSign() throws IOException {
        final StringWriter out = new StringWriter();
        final int consumed = unicodeUnescaper.translate("\\uu+0041", 0, out);
        assertEquals(8, consumed);
        assertEquals("A", out.toString());
    }

    @Test
    void testTranslateNotEscape() throws IOException {
        final StringWriter out = new StringWriter();
        final int consumed = unicodeUnescaper.translate("abc", 0, out);
        assertEquals(0, consumed);
        assertEquals("", out.toString());
    }

    @Test
    void testTranslateBackslashAtEndOfInput() throws IOException {
        final StringWriter out = new StringWriter();
        final int consumed = unicodeUnescaper.translate("\\", 0, out);
        assertEquals(0, consumed);
        assertEquals("", out.toString());
    }

    @Test
    void testTranslateBackslashFollowedByNonU() throws IOException {
        final StringWriter out = new StringWriter();
        final int consumed = unicodeUnescaper.translate("\\n", 0, out);
        assertEquals(0, consumed);
        assertEquals("", out.toString());
    }

    @Test
    void testTranslateAtNonZeroIndex() throws IOException {
        final StringWriter out = new StringWriter();
        final int consumed = unicodeUnescaper.translate("xx\\u0041", 2, out);
        assertEquals(6, consumed);
        assertEquals("A", out.toString());
    }

    @Test
    void testTranslateInsufficientHexDigitsThrows() {
        final StringWriter out = new StringWriter();
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> unicodeUnescaper.translate("\\u123", 0, out));
        assertEquals("Less than 4 hex digits in unicode value: '\\u123' due to end of CharSequence", ex.getMessage());
    }

    @Test
    void testTranslateNoHexDigitsAtAllThrows() {
        final StringWriter out = new StringWriter();
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> unicodeUnescaper.translate("\\u", 0, out));
        assertEquals("Less than 4 hex digits in unicode value: '\\u' due to end of CharSequence", ex.getMessage());
    }

    @Test
    void testTranslateInvalidHexDigitsThrows() {
        final StringWriter out = new StringWriter();
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> unicodeUnescaper.translate("\\uZZZZ", 0, out));
        assertEquals("Unable to parse unicode value: ZZZZ", ex.getMessage());
    }

    @Test
    void testTranslateLeadingPlusSignInHexValueThrows() {
        // The single '+' right after the 'u' is consumed as the optional prefix,
        // so a second '+' is needed to land inside the 4-digit hex value itself.
        final StringWriter out = new StringWriter();
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> unicodeUnescaper.translate("\\u++041", 0, out));
        assertEquals("Sign character in unicode value: '+041'", ex.getMessage());
    }

    @Test
    void testTranslateLeadingMinusSignInHexValueThrows() {
        final StringWriter out = new StringWriter();
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> unicodeUnescaper.translate("\\u-041", 0, out));
        assertEquals("Sign character in unicode value: '-041'", ex.getMessage());
    }

    @Test
    void testTranslateLowercaseHex() throws IOException {
        final StringWriter out = new StringWriter();
        final int consumed = unicodeUnescaper.translate("\\uface", 0, out);
        assertEquals(6, consumed);
        assertEquals(1, out.toString().length());
        assertEquals(0xface, out.toString().charAt(0));
    }

    @Test
    void testTranslateZeroValue() throws IOException {
        final StringWriter out = new StringWriter();
        final int consumed = unicodeUnescaper.translate("\\u0000", 0, out);
        assertEquals(6, consumed);
        assertEquals(1, out.toString().length());
        assertEquals(0, out.toString().charAt(0));
    }

    @Test
    void testTranslateMaxValue() throws IOException {
        final StringWriter out = new StringWriter();
        final int consumed = unicodeUnescaper.translate("\\uffff", 0, out);
        assertEquals(6, consumed);
        assertEquals(1, out.toString().length());
        assertEquals(0xffff, out.toString().charAt(0));
    }
}
