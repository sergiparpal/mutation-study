/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.function.FailableRunnable;
import org.apache.commons.lang3.function.FailableSupplier;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests {@link StopWatch}.
 */
public class StopWatchAgentTest {

    private static void sleepQuietly(final long millis) {
        try {
            Thread.sleep(millis);
        } catch (final InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    @Test
    public void testCreateUnstarted() {
        final StopWatch sw = StopWatch.create();
        assertFalse(sw.isStarted());
        assertFalse(sw.isSuspended());
        assertTrue(sw.isStopped());
        assertEquals(0, sw.getTime());
        assertNull(sw.getMessage());
    }

    @Test
    public void testCreateStarted() {
        final StopWatch sw = StopWatch.createStarted();
        assertTrue(sw.isStarted());
        assertFalse(sw.isStopped());
        assertFalse(sw.isSuspended());
    }

    @Test
    public void testDefaultConstructorMessageIsNull() {
        final StopWatch sw = new StopWatch();
        assertNull(sw.getMessage());
    }

    @Test
    public void testMessageConstructor() {
        final StopWatch sw = new StopWatch("myMessage");
        assertEquals("myMessage", sw.getMessage());
        sw.start();
        sw.stop();
        assertTrue(sw.toString().startsWith("myMessage "));
    }

    @Test
    public void testStartStopGetTime() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sleepQuietly(20);
        sw.stop();
        assertTrue(sw.isStopped());
        assertFalse(sw.isStarted());
        assertTrue(sw.getTime() >= 0);
        assertTrue(sw.getNanoTime() >= 0);
        assertEquals(sw.getTime(), sw.getNanoTime() / 1000000L);
    }

    @Test
    public void testUnstartedGetNanoTimeIsZero() {
        final StopWatch sw = new StopWatch();
        assertEquals(0L, sw.getNanoTime());
    }

    @Test
    public void testStartTwiceThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        final IllegalStateException e = assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.start();
            }
        });
        assertEquals("Stopwatch already started.", e.getMessage());
    }

    @Test
    public void testStartAfterStopWithoutResetThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.stop();
        final IllegalStateException e = assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.start();
            }
        });
        assertEquals("Stopwatch must be reset before being restarted.", e.getMessage());
    }

    @Test
    public void testStopWithoutStartThrows() {
        final StopWatch sw = new StopWatch();
        final IllegalStateException e = assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.stop();
            }
        });
        assertEquals("Stopwatch is not running.", e.getMessage());
    }

    @Test
    public void testStopTwiceThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.stop();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.stop();
            }
        });
    }

    @Test
    public void testSuspendWithoutStartThrows() {
        final StopWatch sw = new StopWatch();
        final IllegalStateException e = assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.suspend();
            }
        });
        assertEquals("Stopwatch must be running to suspend.", e.getMessage());
    }

    @Test
    public void testSuspendTwiceThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.suspend();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.suspend();
            }
        });
    }

    @Test
    public void testResumeWithoutSuspendThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        final IllegalStateException e = assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.resume();
            }
        });
        assertEquals("Stopwatch must be suspended to resume.", e.getMessage());
    }

    @Test
    public void testResumeOnUnstartedThrows() {
        final StopWatch sw = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.resume();
            }
        });
    }

    @Test
    public void testSuspendResumeExcludesPausedTime() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sleepQuietly(20);
        sw.suspend();
        assertTrue(sw.isSuspended());
        final long atSuspend = sw.getTime();
        sleepQuietly(50);
        assertEquals(atSuspend, sw.getTime());
        sw.resume();
        assertTrue(sw.isStarted());
        assertFalse(sw.isSuspended());
        sleepQuietly(10);
        sw.stop();
        assertTrue(sw.getTime() >= atSuspend);
    }

    @Test
    public void testSplitWithoutStartThrows() {
        final StopWatch sw = new StopWatch();
        final IllegalStateException e = assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.split();
            }
        });
        assertEquals("Stopwatch is not running.", e.getMessage());
    }

    @Test
    public void testSplitTwiceWhileRunningAddsTwoSplits() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.split();
        sw.split();
        assertEquals(2, sw.getSplits().size());
    }

    @Test
    public void testSplitAfterStopThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.stop();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.split();
            }
        });
    }

    @Test
    public void testSplitAndGetSplitTime() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sleepQuietly(20);
        sw.split();
        final long splitTime = sw.getSplitTime();
        assertTrue(splitTime >= 0);
        assertEquals(splitTime, sw.getSplitNanoTime() / 1000000L);
        sleepQuietly(20);
        // total time keeps advancing while split, split time should remain fixed
        assertEquals(splitTime, sw.getSplitTime());
        assertTrue(sw.getTime() >= splitTime);
    }

    @Test
    public void testGetSplitTimeWithoutSplitThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        final IllegalStateException e = assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.getSplitTime();
            }
        });
        assertEquals("Stopwatch must be split to get the split time.", e.getMessage());
    }

    @Test
    public void testUnsplitWithoutSplitThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        final IllegalStateException e = assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.unsplit();
            }
        });
        assertEquals("Stopwatch has not been split.", e.getMessage());
    }

    @Test
    public void testSplitUnsplitThenSplitAgainWorks() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.split();
        sw.unsplit();
        // should be allowed to split again now
        sw.split();
        assertEquals(1, sw.getSplits().size());
    }

    @Test
    public void testGetSplitsAccumulatesLabelsAndIsUnmodifiable() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.split("first");
        sw.split("second");
        final List<StopWatch.Split> splits = sw.getSplits();
        assertEquals(2, splits.size());
        assertEquals("first", splits.get(0).getLabel());
        assertEquals("second", splits.get(1).getLabel());
        assertNotNull(splits.get(0).getDuration());
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                splits.add(new StopWatch.Split("x", Duration.ZERO));
            }
        });
    }

    @Test
    public void testSplitDefaultLabelIsIndex() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.split();
        sw.split();
        final List<StopWatch.Split> splits = sw.getSplits();
        assertEquals("0", splits.get(0).getLabel());
        assertEquals("1", splits.get(1).getLabel());
    }

    @Test
    public void testResetClearsStateAndSplits() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.split();
        sw.reset();
        assertFalse(sw.isStarted());
        assertTrue(sw.isStopped());
        assertFalse(sw.isSuspended());
        assertTrue(sw.getSplits().isEmpty());
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.getSplitTime();
            }
        });
        // after reset, start() must succeed again
        sw.start();
        assertTrue(sw.isStarted());
    }

    @Test
    public void testGetStartInstantBeforeStartThrows() {
        final StopWatch sw = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.getStartInstant();
            }
        });
    }

    @Test
    public void testGetStopInstantBeforeStartThrows() {
        final StopWatch sw = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.getStopInstant();
            }
        });
    }

    @Test
    public void testGetStartInstantAfterStartDoesNotThrow() {
        final StopWatch sw = new StopWatch();
        final Instant before = Instant.now();
        sw.start();
        final Instant after = Instant.now();
        final Instant started = sw.getStartInstant();
        assertNotNull(started);
        assertFalse(started.isBefore(before));
        assertFalse(started.isAfter(after));
    }

    @Test
    public void testGetStopInstantWhileRunningIsNull() {
        final StopWatch sw = new StopWatch();
        sw.start();
        assertNull(sw.getStopInstant());
    }

    @Test
    public void testGetStopInstantAfterStop() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.stop();
        assertNotNull(sw.getStopInstant());
        assertEquals(sw.getStopInstant().toEpochMilli(), sw.getStopTime());
    }

    @Test
    public void testGetStartTimeMatchesStartInstant() {
        final StopWatch sw = new StopWatch();
        sw.start();
        assertEquals(sw.getStartInstant().toEpochMilli(), sw.getStartTime());
    }

    @Test
    public void testGetDurationMatchesGetTime() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sleepQuietly(5);
        sw.stop();
        final Duration duration = sw.getDuration();
        assertEquals(sw.getNanoTime(), duration.toNanos());
    }

    @Test
    public void testGetTimeWithTimeUnit() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sleepQuietly(5);
        sw.stop();
        final long millis = sw.getTime(TimeUnit.MILLISECONDS);
        final long nanos = sw.getTime(TimeUnit.NANOSECONDS);
        assertEquals(millis, nanos / 1000000L);
        // Large unit rounds down and should be 0 for a sub-second run.
        assertEquals(0L, sw.getTime(TimeUnit.HOURS));
    }

    @Test
    public void testFormatTimeAndSplitTime() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.split();
        final String splitStr = sw.formatSplitTime();
        assertNotNull(splitStr);
        assertTrue(splitStr.contains(":"));
        sw.stop();
        final String timeStr = sw.formatTime();
        assertNotNull(timeStr);
        assertTrue(timeStr.contains(":"));
    }

    @Test
    public void testToStringWithoutMessage() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.stop();
        assertEquals(sw.formatTime(), sw.toString());
    }

    @Test
    public void testToSplitStringWithoutMessage() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.split();
        assertEquals(sw.formatSplitTime(), sw.toSplitString());
    }

    @Test
    public void testRunDelegatesAndRecordsTime() {
        final StopWatch sw = new StopWatch();
        final int[] calls = {0};
        sw.run(new Runnable() {
            @Override
            public void run() {
                calls[0]++;
                sleepQuietly(5);
            }
        });
        assertEquals(1, calls[0]);
        assertTrue(sw.isSuspended());
        assertTrue(sw.getTime() > 0);
    }

    @Test
    public void testGetDelegatesAndReturnsValue() {
        final StopWatch sw = new StopWatch();
        final String result = sw.get(new java.util.function.Supplier<String>() {
            @Override
            public String get() {
                return "value";
            }
        });
        assertEquals("value", result);
        assertTrue(sw.isSuspended());
    }

    @Test
    public void testRunTPropagatesCheckedException() {
        final StopWatch sw = new StopWatch();
        final Exception ex = assertThrows(Exception.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                sw.runT(new FailableRunnable<IOException>() {
                    @Override
                    public void run() throws IOException {
                        throw new IOException("boom");
                    }
                });
            }
        });
        assertEquals("boom", ex.getMessage());
        assertTrue(sw.isSuspended());
    }

    @Test
    public void testGetTPropagatesCheckedException() {
        final StopWatch sw = new StopWatch();
        final Exception ex = assertThrows(Exception.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                sw.getT(new FailableSupplier<String, IOException>() {
                    @Override
                    public String get() throws IOException {
                        throw new IOException("boom");
                    }
                });
            }
        });
        assertEquals("boom", ex.getMessage());
        assertTrue(sw.isSuspended());
    }

    @Test
    public void testSplitClassGettersAndToString() {
        final Duration d = Duration.ofSeconds(5);
        final StopWatch.Split split = new StopWatch.Split("label", d);
        assertEquals("label", split.getLabel());
        assertSame(d, split.getDuration());
        assertEquals("Split [label, PT5S])", split.toString());
    }
}
