/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.Reader;
import java.io.StringWriter;
import java.io.Writer;
import java.nio.CharBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;

@SuppressWarnings("deprecation")
public class StrBuilderAgentTest {

    /** A minimal Readable that is not a Reader or CharBuffer, to exercise the generic readFrom path. */
    static class PlainReadable implements Readable {
        private final CharBuffer source;

        PlainReadable(final String s) {
            source = CharBuffer.wrap(s.toCharArray());
        }

        @Override
        public int read(final CharBuffer cb) {
            if (!source.hasRemaining()) {
                return -1;
            }
            final int n = Math.min(cb.remaining(), source.remaining());
            final char[] tmp = new char[n];
            source.get(tmp);
            cb.put(tmp);
            return n;
        }
    }

    // --- constructors ---

    @Test
    public void testDefaultConstructor() {
        final StrBuilder sb = new StrBuilder();
        assertEquals(0, sb.length());
        assertEquals(32, sb.capacity());
        assertEquals("", sb.toString());
    }

    @Test
    public void testCapacityConstructorNonPositiveFallsBackToDefault() {
        assertEquals(32, new StrBuilder(0).capacity());
        assertEquals(32, new StrBuilder(-5).capacity());
        assertEquals(64, new StrBuilder(64).capacity());
    }

    @Test
    public void testStringConstructorNullTreatedAsEmpty() {
        final StrBuilder sb = new StrBuilder((String) null);
        assertEquals(0, sb.length());
        assertEquals("", sb.toString());
    }

    @Test
    public void testStringConstructorCopiesContent() {
        final StrBuilder sb = new StrBuilder("hello");
        assertEquals(5, sb.length());
        assertEquals("hello", sb.toString());
        assertTrue(sb.capacity() >= 5);
    }

    // --- append ---

    @Test
    public void testAppendBoolean() {
        final StrBuilder sb = new StrBuilder();
        sb.append(true).append(' ').append(false);
        assertEquals("true false", sb.toString());
    }

    @Test
    public void testAppendChar() {
        final StrBuilder sb = new StrBuilder();
        final StrBuilder result = sb.append('x');
        assertSame(sb, result);
        assertEquals("x", sb.toString());
    }

    @Test
    public void testAppendCharArrayNullCallsAppendNull() {
        final StrBuilder sb = new StrBuilder().setNullText("NULL");
        sb.append((char[]) null);
        assertEquals("NULL", sb.toString());
    }

    @Test
    public void testAppendCharArray() {
        final StrBuilder sb = new StrBuilder();
        sb.append(new char[] {'a', 'b', 'c'});
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendCharArrayRange() {
        final StrBuilder sb = new StrBuilder();
        sb.append(new char[] {'a', 'b', 'c', 'd'}, 1, 2);
        assertEquals("bc", sb.toString());
    }

    @Test
    public void testAppendCharArrayRangeInvalidStartIndexThrows() {
        final StrBuilder sb = new StrBuilder();
        assertThrows(StringIndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                sb.append(new char[] {'a'}, -1, 1);
            }
        });
        assertThrows(StringIndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                sb.append(new char[] {'a'}, 2, 1);
            }
        });
    }

    @Test
    public void testAppendCharArrayRangeInvalidLengthThrows() {
        final StrBuilder sb = new StrBuilder();
        assertThrows(StringIndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                sb.append(new char[] {'a', 'b'}, 0, -1);
            }
        });
        assertThrows(StringIndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                sb.append(new char[] {'a', 'b'}, 0, 3);
            }
        });
    }

    @Test
    public void testAppendCharBuffer() {
        final StrBuilder sb = new StrBuilder();
        sb.append(CharBuffer.wrap("hello".toCharArray()));
        assertEquals("hello", sb.toString());
    }

    @Test
    public void testAppendCharBufferRange() {
        final StrBuilder sb = new StrBuilder();
        sb.append(CharBuffer.wrap("hello".toCharArray()), 1, 3);
        assertEquals("ell", sb.toString());
    }

    @Test
    public void testAppendCharSequence() {
        final StrBuilder sb = new StrBuilder();
        final CharSequence seq = "abc";
        sb.append(seq);
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendCharSequenceRange() {
        final StrBuilder sb = new StrBuilder();
        sb.append((CharSequence) "abcdef", 1, 3);
        assertEquals("bcd", sb.toString());
    }

    @Test
    public void testAppendDoubleFloatIntLong() {
        final StrBuilder sb = new StrBuilder();
        sb.append(1.5d).append(',').append(2.5f).append(',').append(3).append(',').append(4L);
        assertEquals("1.5,2.5,3,4", sb.toString());
    }

    @Test
    public void testAppendObjectNullCallsAppendNull() {
        final StrBuilder sb = new StrBuilder();
        sb.append((Object) null);
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendObject() {
        final StrBuilder sb = new StrBuilder();
        sb.append(Integer.valueOf(42));
        assertEquals("42", sb.toString());
    }

    @Test
    public void testAppendStrBuilder() {
        final StrBuilder sb = new StrBuilder("foo");
        final StrBuilder other = new StrBuilder("bar");
        sb.append(other);
        assertEquals("foobar", sb.toString());
    }

    @Test
    public void testAppendStrBuilderRangeInvalidThrows() {
        final StrBuilder sb = new StrBuilder();
        final StrBuilder other = new StrBuilder("bar");
        assertThrows(StringIndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                sb.append(other, -1, 1);
            }
        });
        assertThrows(StringIndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                sb.append(other, 0, 10);
            }
        });
    }

    @Test
    public void testAppendStringRangeInvalidThrows() {
        final StrBuilder sb = new StrBuilder();
        assertThrows(StringIndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                sb.append("abc", -1, 1);
            }
        });
        assertThrows(StringIndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                sb.append("abc", 0, 10);
            }
        });
    }

    @Test
    public void testAppendFormat() {
        final StrBuilder sb = new StrBuilder();
        sb.append("%s-%d", "x", 5);
        assertEquals("x-5", sb.toString());
    }

    @Test
    public void testAppendStringBuffer() {
        final StrBuilder sb = new StrBuilder();
        sb.append(new StringBuffer("abc"));
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendStringBuilder() {
        final StrBuilder sb = new StrBuilder();
        sb.append(new StringBuilder("abc"));
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendAllIterable() {
        final StrBuilder sb = new StrBuilder();
        final List<String> list = Arrays.asList("a", "b", "c");
        sb.appendAll((Iterable<?>) list);
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendAllIterableNullNoEffect() {
        final StrBuilder sb = new StrBuilder();
        sb.appendAll((Iterable<?>) null);
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendAllIterator() {
        final StrBuilder sb = new StrBuilder();
        final List<String> list = Arrays.asList("x", "y");
        sb.appendAll(list.iterator());
        assertEquals("xy", sb.toString());
    }

    @Test
    public void testAppendAllArray() {
        final StrBuilder sb = new StrBuilder();
        sb.appendAll("a", "b", "c");
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadLeft() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft(7, 4, '0');
        assertEquals("0007", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadLeftTruncatesFromLeft() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft(123456, 3, '0');
        assertEquals("456", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadLeftZeroWidthNoEffect() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft(7, 0, '0');
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadRight() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadRight(7, 4, '0');
        assertEquals("7000", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadRightTruncatesFromRight() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadRight(123456, 3, '0');
        assertEquals("123", sb.toString());
    }

    // --- appendln ---

    @Test
    public void testAppendlnString() {
        final StrBuilder sb = new StrBuilder();
        sb.setNewLineText("\n");
        sb.appendln("abc");
        assertEquals("abc\n", sb.toString());
    }

    @Test
    public void testAppendNewLineDefaultsToSystemLineSeparator() {
        final StrBuilder sb = new StrBuilder();
        sb.appendNewLine();
        assertEquals(System.lineSeparator(), sb.toString());
    }

    @Test
    public void testSetNewLineTextAndGetNewLineText() {
        final StrBuilder sb = new StrBuilder();
        assertNull(sb.getNewLineText());
        sb.setNewLineText("|");
        assertEquals("|", sb.getNewLineText());
        sb.appendNewLine();
        assertEquals("|", sb.toString());
    }

    // --- appendNull / nullText ---

    @Test
    public void testAppendNullDefaultIsNoOp() {
        final StrBuilder sb = new StrBuilder();
        assertNull(sb.getNullText());
        sb.appendNull();
        assertEquals("", sb.toString());
    }

    @Test
    public void testSetNullTextEmptyBecomesNull() {
        final StrBuilder sb = new StrBuilder();
        sb.setNullText("");
        assertNull(sb.getNullText());
        sb.setNullText(null);
        assertNull(sb.getNullText());
    }

    // --- appendPadding ---

    @Test
    public void testAppendPaddingPositive() {
        final StrBuilder sb = new StrBuilder();
        sb.appendPadding(3, '*');
        assertEquals("***", sb.toString());
    }

    @Test
    public void testAppendPaddingNegativeNoEffect() {
        final StrBuilder sb = new StrBuilder("x");
        sb.appendPadding(-1, '*');
        assertEquals("x", sb.toString());
    }

    @Test
    public void testAppendPaddingZero() {
        final StrBuilder sb = new StrBuilder("x");
        sb.appendPadding(0, '*');
        assertEquals("x", sb.toString());
    }

    // --- appendSeparator ---

    @Test
    public void testAppendSeparatorCharOnlyWhenNonEmpty() {
        final StrBuilder sb = new StrBuilder();
        sb.appendSeparator(',');
        assertEquals("", sb.toString());
        sb.append("a").appendSeparator(',').append("b");
        assertEquals("a,b", sb.toString());
    }

    @Test
    public void testAppendSeparatorCharWithDefaultIfEmpty() {
        final StrBuilder sb = new StrBuilder();
        sb.appendSeparator(',', ';');
        assertEquals(";", sb.toString());
        sb.appendSeparator(',', ';');
        assertEquals(";,", sb.toString());
    }

    @Test
    public void testAppendSeparatorCharLoopIndex() {
        final StrBuilder sb = new StrBuilder();
        for (int i = 0; i < 3; i++) {
            sb.appendSeparator(',', i);
            sb.append(i);
        }
        assertEquals("0,1,2", sb.toString());
    }

    @Test
    public void testAppendSeparatorStringNullHasNoEffect() {
        final StrBuilder sb = new StrBuilder("a");
        sb.appendSeparator((String) null);
        assertEquals("a", sb.toString());
    }

    @Test
    public void testAppendSeparatorStringLoopIndex() {
        final StrBuilder sb = new StrBuilder();
        for (int i = 0; i < 3; i++) {
            sb.appendSeparator("-", i);
            sb.append(i);
        }
        assertEquals("0-1-2", sb.toString());
    }

    @Test
    public void testAppendSeparatorStringStandardAndDefault() {
        final StrBuilder sb = new StrBuilder();
        sb.appendSeparator(" and", " where");
        assertEquals(" where", sb.toString());
        sb.appendSeparator(" and", " where");
        assertEquals(" where and", sb.toString());
    }

    // --- appendWithSeparators ---

    @Test
    public void testAppendWithSeparatorsIterable() {
        final StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators(Arrays.asList("a", "b", "c"), ",");
        assertEquals("a,b,c", sb.toString());
    }

    @Test
    public void testAppendWithSeparatorsIterableNullSeparatorUsesEmpty() {
        final StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators(Arrays.asList("a", "b"), null);
        assertEquals("ab", sb.toString());
    }

    @Test
    public void testAppendWithSeparatorsIterator() {
        final StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators(Arrays.asList("a", "b").iterator(), "-");
        assertEquals("a-b", sb.toString());
    }

    @Test
    public void testAppendWithSeparatorsArray() {
        final StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators(new Object[] {"a", "b", "c"}, ";");
        assertEquals("a;b;c", sb.toString());
    }

    @Test
    public void testAppendWithSeparatorsArrayEmptyNoEffect() {
        final StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators(new Object[0], ";");
        assertEquals("", sb.toString());
    }

    // --- appendTo ---

    @Test
    public void testAppendToWriter() throws IOException {
        final StrBuilder sb = new StrBuilder("hello");
        final Writer w = new StringWriter();
        sb.appendTo(w);
        assertEquals("hello", w.toString());
    }

    @Test
    public void testAppendToStringBuilder() throws IOException {
        final StrBuilder sb = new StrBuilder("hello");
        final StringBuilder target = new StringBuilder();
        sb.appendTo(target);
        assertEquals("hello", target.toString());
    }

    @Test
    public void testAppendToStringBuffer() throws IOException {
        final StrBuilder sb = new StrBuilder("hello");
        final StringBuffer target = new StringBuffer();
        sb.appendTo(target);
        assertEquals("hello", target.toString());
    }

    @Test
    public void testAppendToCharBuffer() throws IOException {
        final StrBuilder sb = new StrBuilder("hello");
        final CharBuffer target = CharBuffer.allocate(10);
        sb.appendTo(target);
        target.flip();
        assertEquals("hello", target.toString());
    }

    // --- asReader / asWriter / asTokenizer ---

    @Test
    public void testAsReaderReadsContent() throws IOException {
        final StrBuilder sb = new StrBuilder("ab");
        final Reader r = sb.asReader();
        assertEquals('a', r.read());
        assertEquals('b', r.read());
        assertEquals(-1, r.read());
    }

    @Test
    public void testAsReaderMarkAndReset() throws IOException {
        final StrBuilder sb = new StrBuilder("abc");
        final Reader r = sb.asReader();
        assertTrue(r.markSupported());
        assertEquals('a', r.read());
        r.mark(0);
        assertEquals('b', r.read());
        r.reset();
        assertEquals('b', r.read());
    }

    @Test
    public void testAsReaderBulkRead() throws IOException {
        final StrBuilder sb = new StrBuilder("abcdef");
        final Reader r = sb.asReader();
        final char[] buf = new char[4];
        final int n = r.read(buf, 0, 4);
        assertEquals(4, n);
        assertEquals("abcd", new String(buf));
    }

    @Test
    public void testAsReaderBulkReadInvalidArgsThrows() {
        final StrBuilder sb = new StrBuilder("abc");
        final Reader r = sb.asReader();
        assertThrows(IndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                r.read(new char[3], -1, 2);
            }
        });
        assertThrows(IndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                r.read(new char[3], 0, 10);
            }
        });
    }

    @Test
    public void testAsWriterWritesIntoBuilder() throws IOException {
        final StrBuilder sb = new StrBuilder();
        final Writer w = sb.asWriter();
        w.write("hi");
        w.write('!');
        w.write(new char[] {'a', 'b'});
        assertEquals("hi!ab", sb.toString());
    }

    @Test
    public void testAsTokenizerTokenizesContent() {
        final StrBuilder sb = new StrBuilder("a b c");
        final StrTokenizer t = sb.asTokenizer();
        final String[] tokens = t.getTokenArray();
        assertArrayEquals(new String[] {"a", "b", "c"}, tokens);
    }

    // --- build() ---

    @Test
    public void testBuildReturnsString() {
        final StrBuilder sb = new StrBuilder("abc");
        assertEquals("abc", sb.build());
    }

    // --- capacity / length / size / isEmpty ---

    @Test
    public void testIsEmptyIsNotEmpty() {
        final StrBuilder sb = new StrBuilder();
        assertTrue(sb.isEmpty());
        assertFalse(sb.isNotEmpty());
        sb.append('a');
        assertFalse(sb.isEmpty());
        assertTrue(sb.isNotEmpty());
    }

    @Test
    public void testLengthEqualsSize() {
        final StrBuilder sb = new StrBuilder("abcd");
        assertEquals(4, sb.length());
        assertEquals(sb.length(), sb.size());
    }

    // --- charAt ---

    @Test
    public void testCharAt() {
        final StrBuilder sb = new StrBuilder("abc");
        assertEquals('a', sb.charAt(0));
        assertEquals('c', sb.charAt(2));
    }

    @Test
    public void testCharAtOutOfBoundsThrows() {
        final StrBuilder sb = new StrBuilder("abc");
        assertThrows(StringIndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                sb.charAt(-1);
            }
        });
        assertThrows(StringIndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                sb.charAt(3);
            }
        });
    }

    // --- clear ---

    @Test
    public void testClearResetsSizeButNotCapacity() {
        final StrBuilder sb = new StrBuilder("abcdef");
        final int cap = sb.capacity();
        final StrBuilder result = sb.clear();
        assertSame(sb, result);
        assertEquals(0, sb.length());
        assertEquals(cap, sb.capacity());
        assertEquals("", sb.toString());
    }

    // --- contains ---

    @Test
    public void testContainsChar() {
        final StrBuilder sb = new StrBuilder("abc");
        assertTrue(sb.contains('b'));
        assertFalse(sb.contains('z'));
    }

    @Test
    public void testContainsString() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertTrue(sb.contains("cde"));
        assertFalse(sb.contains("xyz"));
    }

    @Test
    public void testContainsMatcher() {
        final StrBuilder sb = new StrBuilder("abc123");
        assertTrue(sb.contains(StrMatcher.charMatcher('1')));
        assertFalse(sb.contains(StrMatcher.charMatcher('z')));
        assertFalse(sb.contains((StrMatcher) null));
    }

    // --- delete ---

    @Test
    public void testDeleteRange() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.delete(1, 3);
        assertEquals("adef", sb.toString());
    }

    @Test
    public void testDeleteRangeEndIndexTooLargeTreatedAsEnd() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.delete(2, 1000);
        assertEquals("ab", sb.toString());
    }

    @Test
    public void testDeleteRangeNoOpWhenEmptyRange() {
        final StrBuilder sb = new StrBuilder("abc");
        sb.delete(1, 1);
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testDeleteRangeInvalidStartThrows() {
        final StrBuilder sb = new StrBuilder("abc");
        assertThrows(StringIndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                sb.delete(-1, 2);
            }
        });
    }

    @Test
    public void testDeleteRangeStartGreaterThanEndThrows() {
        final StrBuilder sb = new StrBuilder("abc");
        assertThrows(StringIndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                sb.delete(2, 1);
            }
        });
    }

    @Test
    public void testDeleteAllChar() {
        final StrBuilder sb = new StrBuilder("ababab");
        sb.deleteAll('a');
        assertEquals("bbb", sb.toString());
    }

    @Test
    public void testDeleteAllCharNoMatchNoEffect() {
        final StrBuilder sb = new StrBuilder("abc");
        sb.deleteAll('z');
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testDeleteAllString() {
        final StrBuilder sb = new StrBuilder("foobarfoobaz");
        sb.deleteAll("foo");
        assertEquals("barbaz", sb.toString());
    }

    @Test
    public void testDeleteAllStringNullNoEffect() {
        final StrBuilder sb = new StrBuilder("abc");
        sb.deleteAll((String) null);
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testDeleteAllMatcher() {
        final StrBuilder sb = new StrBuilder("a1b2c3");
        sb.deleteAll(StrMatcher.charSetMatcher("123"));
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testDeleteCharAt() {
        final StrBuilder sb = new StrBuilder("abc");
        sb.deleteCharAt(1);
        assertEquals("ac", sb.toString());
    }

    @Test
    public void testDeleteCharAtOutOfBoundsThrows() {
        final StrBuilder sb = new StrBuilder("abc");
        assertThrows(StringIndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                sb.deleteCharAt(-1);
            }
        });
        assertThrows(StringIndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                sb.deleteCharAt(3);
            }
        });
    }

    @Test
    public void testDeleteFirstChar() {
        final StrBuilder sb = new StrBuilder("ababab");
        sb.deleteFirst('a');
        assertEquals("babab", sb.toString());
    }

    @Test
    public void testDeleteFirstString() {
        final StrBuilder sb = new StrBuilder("foobarfoo");
        sb.deleteFirst("foo");
        assertEquals("barfoo", sb.toString());
    }

    @Test
    public void testDeleteFirstMatcher() {
        final StrBuilder sb = new StrBuilder("a1b2c3");
        sb.deleteFirst(StrMatcher.charSetMatcher("123"));
        assertEquals("ab2c3", sb.toString());
    }

    // --- endsWith / startsWith ---

    @Test
    public void testEndsWith() {
        final StrBuilder sb = new StrBuilder("hello world");
        assertTrue(sb.endsWith("world"));
        assertFalse(sb.endsWith("hello"));
        assertTrue(sb.endsWith(""));
        assertFalse(sb.endsWith(null));
        assertFalse(sb.endsWith("this string is far too long"));
    }

    @Test
    public void testStartsWith() {
        final StrBuilder sb = new StrBuilder("hello world");
        assertTrue(sb.startsWith("hello"));
        assertFalse(sb.startsWith("world"));
        assertTrue(sb.startsWith(""));
        assertFalse(sb.startsWith(null));
        assertFalse(sb.startsWith("this string is far too long"));
    }

    // --- ensureCapacity ---

    @Test
    public void testEnsureCapacityGrows() {
        final StrBuilder sb = new StrBuilder(4);
        assertEquals(4, sb.capacity());
        sb.ensureCapacity(100);
        assertTrue(sb.capacity() >= 100);
    }

    @Test
    public void testEnsureCapacityNoOpWhenSufficient() {
        final StrBuilder sb = new StrBuilder(100);
        sb.ensureCapacity(10);
        assertEquals(100, sb.capacity());
    }

    // --- equals / hashCode / equalsIgnoreCase ---

    @Test
    public void testEqualsObjectAndStrBuilder() {
        final StrBuilder a = new StrBuilder("abc");
        final StrBuilder b = new StrBuilder("abc");
        final StrBuilder c = new StrBuilder("xyz");
        assertTrue(a.equals(b));
        assertTrue(a.equals((Object) b));
        assertFalse(a.equals(c));
        assertFalse(a.equals((StrBuilder) null));
        assertFalse(a.equals((Object) null));
        assertFalse(a.equals("abc"));
        assertTrue(a.equals(a));
    }

    @Test
    public void testHashCodeConsistentWithEquals() {
        final StrBuilder a = new StrBuilder("abc");
        final StrBuilder b = new StrBuilder("abc");
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    public void testEqualsIgnoreCase() {
        final StrBuilder a = new StrBuilder("AbC");
        final StrBuilder b = new StrBuilder("aBc");
        final StrBuilder c = new StrBuilder("xyz");
        assertTrue(a.equalsIgnoreCase(b));
        assertFalse(a.equalsIgnoreCase(c));
        assertTrue(a.equalsIgnoreCase(a));
    }

    // --- getChars ---

    @Test
    public void testGetCharsNullDestinationCreatesArray() {
        final StrBuilder sb = new StrBuilder("abc");
        final char[] result = sb.getChars((char[]) null);
        assertArrayEquals(new char[] {'a', 'b', 'c'}, result);
    }

    @Test
    public void testGetCharsTooSmallDestinationCreatesNewArray() {
        final StrBuilder sb = new StrBuilder("abc");
        final char[] small = new char[1];
        final char[] result = sb.getChars(small);
        assertEquals(3, result.length);
        assertArrayEquals(new char[] {'a', 'b', 'c'}, result);
    }

    @Test
    public void testGetCharsRange() {
        final StrBuilder sb = new StrBuilder("abcdef");
        final char[] dest = new char[6];
        sb.getChars(1, 4, dest, 2);
        assertArrayEquals(new char[] {0, 0, 'b', 'c', 'd', 0}, dest);
    }

    @Test
    public void testGetCharsRangeInvalidThrows() {
        final StrBuilder sb = new StrBuilder("abc");
        final char[] dest = new char[3];
        assertThrows(StringIndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                sb.getChars(-1, 2, dest, 0);
            }
        });
        assertThrows(StringIndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                sb.getChars(0, 10, dest, 0);
            }
        });
        assertThrows(StringIndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                sb.getChars(2, 1, dest, 0);
            }
        });
    }

    // --- indexOf ---

    @Test
    public void testIndexOfChar() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(1, sb.indexOf('b'));
        assertEquals(-1, sb.indexOf('z'));
    }

    @Test
    public void testIndexOfCharWithStart() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(4, sb.indexOf('b', 2));
        assertEquals(1, sb.indexOf('b', -5));
        assertEquals(-1, sb.indexOf('b', 100));
    }

    @Test
    public void testIndexOfString() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(1, sb.indexOf("bc"));
        assertEquals(-1, sb.indexOf((String) null));
    }

    @Test
    public void testIndexOfStringWithStart() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(4, sb.indexOf("bc", 2));
    }

    @Test
    public void testIndexOfMatcher() {
        final StrBuilder sb = new StrBuilder("abc123");
        assertEquals(3, sb.indexOf(StrMatcher.charSetMatcher("0123456789")));
        assertEquals(-1, sb.indexOf((StrMatcher) null));
    }

    @Test
    public void testIndexOfMatcherWithStart() {
        final StrBuilder sb = new StrBuilder("1a1b1");
        assertEquals(2, sb.indexOf(StrMatcher.charMatcher('1'), 1));
        assertEquals(-1, sb.indexOf(StrMatcher.charMatcher('1'), 100));
    }

    // --- insert ---

    @Test
    public void testInsertBoolean() {
        final StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, true);
        assertEquals("atruec", sb.toString());
    }

    @Test
    public void testInsertChar() {
        final StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, 'b');
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testInsertCharArray() {
        final StrBuilder sb = new StrBuilder("ad");
        sb.insert(1, new char[] {'b', 'c'});
        assertEquals("abcd", sb.toString());
    }

    @Test
    public void testInsertCharArrayNullUsesNullText() {
        final StrBuilder sb = new StrBuilder("ac").setNullText("X");
        sb.insert(1, (char[]) null);
        assertEquals("aXc", sb.toString());
    }

    @Test
    public void testInsertCharArrayRange() {
        final StrBuilder sb = new StrBuilder("az");
        sb.insert(1, new char[] {'b', 'c', 'd'}, 1, 2);
        assertEquals("acdz", sb.toString());
    }

    @Test
    public void testInsertCharArrayRangeInvalidThrows() {
        final StrBuilder sb = new StrBuilder("az");
        assertThrows(StringIndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                sb.insert(1, new char[] {'a'}, -1, 1);
            }
        });
        assertThrows(StringIndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                sb.insert(1, new char[] {'a'}, 0, -1);
            }
        });
        assertThrows(StringIndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                sb.insert(1, new char[] {'a'}, 0, 5);
            }
        });
    }

    @Test
    public void testInsertNumericValues() {
        final StrBuilder sb = new StrBuilder();
        sb.insert(0, 1.5d);
        sb.insert(0, 1);
        sb.insert(0, 2L);
        sb.insert(0, 2.5f);
        assertEquals("2.5211.5", sb.toString());
    }

    @Test
    public void testInsertObjectNullUsesNullText() {
        final StrBuilder sb = new StrBuilder("ac").setNullText("X");
        sb.insert(1, (Object) null);
        assertEquals("aXc", sb.toString());
    }

    @Test
    public void testInsertObject() {
        final StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, Integer.valueOf(9));
        assertEquals("a9c", sb.toString());
    }

    @Test
    public void testInsertStringNullUsesNullText() {
        final StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, (String) null);
        assertEquals("ac", sb.toString());
        sb.setNullText("NULL");
        sb.insert(1, (String) null);
        assertEquals("aNULLc", sb.toString());
    }

    @Test
    public void testInsertIndexOutOfBoundsThrows() {
        final StrBuilder sb = new StrBuilder("abc");
        assertThrows(StringIndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                sb.insert(-1, "x");
            }
        });
        assertThrows(StringIndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                sb.insert(4, "x");
            }
        });
    }

    @Test
    public void testInsertAtEndIsValid() {
        final StrBuilder sb = new StrBuilder("abc");
        sb.insert(3, "d");
        assertEquals("abcd", sb.toString());
    }

    // --- lastIndexOf ---

    @Test
    public void testLastIndexOfChar() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(4, sb.lastIndexOf('b'));
        assertEquals(-1, sb.lastIndexOf('z'));
    }

    @Test
    public void testLastIndexOfCharWithStart() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(1, sb.lastIndexOf('b', 3));
        assertEquals(-1, new StrBuilder("").lastIndexOf('a', 0));
    }

    @Test
    public void testLastIndexOfString() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(3, sb.lastIndexOf("abc"));
        assertEquals(-1, sb.lastIndexOf((String) null));
    }

    @Test
    public void testLastIndexOfMatcher() {
        final StrBuilder sb = new StrBuilder("a1b2c3");
        assertEquals(5, sb.lastIndexOf(StrMatcher.charSetMatcher("0123456789")));
        assertEquals(-1, sb.lastIndexOf((StrMatcher) null));
    }

    // --- leftString / midString / rightString ---

    @Test
    public void testLeftString() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("abc", sb.leftString(3));
        assertEquals("", sb.leftString(-1));
        assertEquals("abcdef", sb.leftString(100));
    }

    @Test
    public void testMidString() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("cde", sb.midString(2, 3));
        assertEquals("", sb.midString(2, -1));
        assertEquals("abc", sb.midString(-5, 3));
        assertEquals("", sb.midString(100, 3));
        assertEquals("def", sb.midString(3, 100));
    }

    @Test
    public void testRightString() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("def", sb.rightString(3));
        assertEquals("", sb.rightString(-1));
        assertEquals("abcdef", sb.rightString(100));
    }

    // --- minimizeCapacity ---

    @Test
    public void testMinimizeCapacity() {
        final StrBuilder sb = new StrBuilder(100);
        sb.append("abc");
        sb.minimizeCapacity();
        assertEquals(3, sb.capacity());
        assertEquals("abc", sb.toString());
    }

    // --- readFrom ---

    @Test
    public void testReadFromReader() throws IOException {
        final StrBuilder sb = new StrBuilder();
        final Reader r = new java.io.StringReader("hello");
        final int read = sb.readFrom(r);
        assertEquals(5, read);
        assertEquals("hello", sb.toString());
    }

    @Test
    public void testReadFromCharBuffer() throws IOException {
        final StrBuilder sb = new StrBuilder();
        final CharBuffer cb = CharBuffer.wrap("world".toCharArray());
        final int read = sb.readFrom(cb);
        assertEquals(5, read);
        assertEquals("world", sb.toString());
    }

    @Test
    public void testReadFromGenericReadable() throws IOException {
        final StrBuilder sb = new StrBuilder();
        final int read = sb.readFrom(new PlainReadable("hi there"));
        assertEquals(8, read);
        assertEquals("hi there", sb.toString());
    }

    // --- replace ---

    @Test
    public void testReplaceRangeShrink() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.replace(1, 4, "X");
        assertEquals("aXef", sb.toString());
    }

    @Test
    public void testReplaceRangeGrow() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.replace(1, 2, "XYZ");
        assertEquals("aXYZcdef", sb.toString());
    }

    @Test
    public void testReplaceRangeNullDeletes() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.replace(1, 4, null);
        assertEquals("aef", sb.toString());
    }

    @Test
    public void testReplaceRangeEndTooLargeTreatedAsEnd() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.replace(4, 1000, "Z");
        assertEquals("abcdZ", sb.toString());
    }

    @Test
    public void testReplaceMatcher() {
        final StrBuilder sb = new StrBuilder("a1b2c3");
        sb.replace(StrMatcher.charSetMatcher("0123456789"), "#", 0, sb.length(), -1);
        assertEquals("a#b#c#", sb.toString());
    }

    @Test
    public void testReplaceMatcherLimitedCount() {
        final StrBuilder sb = new StrBuilder("a1b2c3");
        sb.replace(StrMatcher.charSetMatcher("0123456789"), "#", 0, sb.length(), 1);
        assertEquals("a#b2c3", sb.toString());
    }

    @Test
    public void testReplaceAllChar() {
        final StrBuilder sb = new StrBuilder("banana");
        sb.replaceAll('a', 'o');
        assertEquals("bonono", sb.toString());
    }

    @Test
    public void testReplaceAllString() {
        final StrBuilder sb = new StrBuilder("foobarfoo");
        sb.replaceAll("foo", "X");
        assertEquals("XbarX", sb.toString());
    }

    @Test
    public void testReplaceAllStringNullReplaceActsAsEmpty() {
        final StrBuilder sb = new StrBuilder("foobarfoo");
        sb.replaceAll("foo", null);
        assertEquals("bar", sb.toString());
    }

    @Test
    public void testReplaceAllMatcher() {
        final StrBuilder sb = new StrBuilder("a1b2c3");
        sb.replaceAll(StrMatcher.charSetMatcher("0123456789"), "#");
        assertEquals("a#b#c#", sb.toString());
    }

    @Test
    public void testReplaceFirstChar() {
        final StrBuilder sb = new StrBuilder("banana");
        sb.replaceFirst('a', 'o');
        assertEquals("bonana", sb.toString());
    }

    @Test
    public void testReplaceFirstString() {
        final StrBuilder sb = new StrBuilder("foobarfoo");
        sb.replaceFirst("foo", "X");
        assertEquals("XbarfXoo".replace("fXoo", "foo"), sb.toString());
    }

    @Test
    public void testReplaceFirstMatcher() {
        final StrBuilder sb = new StrBuilder("a1b2c3");
        sb.replaceFirst(StrMatcher.charSetMatcher("0123456789"), "#");
        assertEquals("a#b2c3", sb.toString());
    }

    // --- reverse ---

    @Test
    public void testReverseSimple() {
        final StrBuilder sb = new StrBuilder("abcde");
        sb.reverse();
        assertEquals("edcba", sb.toString());
    }

    @Test
    public void testReverseEmptyNoOp() {
        final StrBuilder sb = new StrBuilder();
        sb.reverse();
        assertEquals("", sb.toString());
    }

    @Test
    public void testReverseSingleCharNoOp() {
        final StrBuilder sb = new StrBuilder("a");
        sb.reverse();
        assertEquals("a", sb.toString());
    }

    @Test
    public void testReverseKeepsSurrogatePairsIntact() {
        final String supplementary = new String(Character.toChars(0x1F600));
        final StrBuilder sb = new StrBuilder("a" + supplementary + "b");
        sb.reverse();
        assertEquals("b" + supplementary + "a", sb.toString());
    }

    // --- setCharAt ---

    @Test
    public void testSetCharAt() {
        final StrBuilder sb = new StrBuilder("abc");
        sb.setCharAt(1, 'X');
        assertEquals("aXc", sb.toString());
    }

    @Test
    public void testSetCharAtOutOfBoundsThrows() {
        final StrBuilder sb = new StrBuilder("abc");
        assertThrows(StringIndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                sb.setCharAt(-1, 'X');
            }
        });
        assertThrows(StringIndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                sb.setCharAt(3, 'X');
            }
        });
    }

    // --- setLength ---

    @Test
    public void testSetLengthShrink() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.setLength(3);
        assertEquals(3, sb.length());
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testSetLengthGrowPadsWithNul() {
        final StrBuilder sb = new StrBuilder("ab");
        sb.setLength(4);
        assertEquals(4, sb.length());
        assertEquals('\0', sb.charAt(2));
        assertEquals('\0', sb.charAt(3));
    }

    @Test
    public void testSetLengthNegativeThrows() {
        final StrBuilder sb = new StrBuilder("abc");
        assertThrows(StringIndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                sb.setLength(-1);
            }
        });
    }

    @Test
    public void testSetLengthSameValueNoOp() {
        final StrBuilder sb = new StrBuilder("abc");
        sb.setLength(3);
        assertEquals("abc", sb.toString());
    }

    // --- subSequence ---

    @Test
    public void testSubSequence() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("bcd", sb.subSequence(1, 4));
    }

    @Test
    public void testSubSequenceInvalidThrows() {
        final StrBuilder sb = new StrBuilder("abc");
        assertThrows(StringIndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                sb.subSequence(-1, 2);
            }
        });
        assertThrows(StringIndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                sb.subSequence(0, 10);
            }
        });
        assertThrows(StringIndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                sb.subSequence(2, 1);
            }
        });
    }

    // --- substring ---

    @Test
    public void testSubstringFrom() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("cdef", sb.substring(2));
    }

    @Test
    public void testSubstringRangeEndTooLargeTreatedAsEnd() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("cdef", sb.substring(2, 1000));
    }

    @Test
    public void testSubstringInvalidStartThrows() {
        final StrBuilder sb = new StrBuilder("abc");
        assertThrows(StringIndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                sb.substring(-1, 2);
            }
        });
    }

    // --- toCharArray ---

    @Test
    public void testToCharArrayEmpty() {
        final StrBuilder sb = new StrBuilder();
        assertEquals(0, sb.toCharArray().length);
    }

    @Test
    public void testToCharArrayFull() {
        final StrBuilder sb = new StrBuilder("abc");
        assertArrayEquals(new char[] {'a', 'b', 'c'}, sb.toCharArray());
    }

    @Test
    public void testToCharArrayRange() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertArrayEquals(new char[] {'b', 'c', 'd'}, sb.toCharArray(1, 4));
    }

    @Test
    public void testToCharArrayRangeEmpty() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertEquals(0, sb.toCharArray(2, 2).length);
    }

    // --- toString / toStringBuffer / toStringBuilder ---

    @Test
    public void testToStringIsIndependentCopy() {
        final StrBuilder sb = new StrBuilder("abc");
        final String s = sb.toString();
        sb.append("def");
        assertEquals("abc", s);
        assertEquals("abcdef", sb.toString());
    }

    @Test
    public void testToStringBuffer() {
        final StrBuilder sb = new StrBuilder("abc");
        final StringBuffer buf = sb.toStringBuffer();
        assertEquals("abc", buf.toString());
    }

    @Test
    public void testToStringBuilder() {
        final StrBuilder sb = new StrBuilder("abc");
        final StringBuilder builder = sb.toStringBuilder();
        assertEquals("abc", builder.toString());
    }

    // --- trim ---

    @Test
    public void testTrimRemovesLeadingAndTrailingWhitespace() {
        final StrBuilder sb = new StrBuilder("  abc  ");
        sb.trim();
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testTrimAllWhitespaceBecomesEmpty() {
        final StrBuilder sb = new StrBuilder("   ");
        sb.trim();
        assertEquals("", sb.toString());
    }

    @Test
    public void testTrimEmptyNoOp() {
        final StrBuilder sb = new StrBuilder();
        sb.trim();
        assertEquals("", sb.toString());
    }

    @Test
    public void testTrimNoWhitespaceNoOp() {
        final StrBuilder sb = new StrBuilder("abc");
        sb.trim();
        assertEquals("abc", sb.toString());
    }

    // --- chained fluent API returns this ---

    @Test
    public void testFluentChainingReturnsSameInstance() {
        final StrBuilder sb = new StrBuilder();
        final StrBuilder result = sb.append("a").append(1).append(true).insert(0, 'x').deleteCharAt(0);
        assertSame(sb, result);
        assertEquals("a1true", sb.toString());
    }

    // --- CharSequence default methods (via Appendable interface use) ---

    @Test
    public void testAppendableInterfaceAppendsCharSequenceCharAndSubSequence() throws IOException {
        final Appendable sb = new StrBuilder();
        sb.append("abc");
        sb.append('d');
        sb.append("xxbcxx", 2, 2);
        assertEquals("abcdbc", sb.toString());
    }

    @Test
    public void testArrayListOfAppendedValuesPreservesInsertionOrder() {
        final StrBuilder sb = new StrBuilder();
        final List<String> expected = new ArrayList<String>();
        for (int i = 0; i < 5; i++) {
            sb.appendSeparator(',');
            sb.append(i);
            expected.add(String.valueOf(i));
        }
        assertEquals(String.join(",", expected), sb.toString());
    }
}
