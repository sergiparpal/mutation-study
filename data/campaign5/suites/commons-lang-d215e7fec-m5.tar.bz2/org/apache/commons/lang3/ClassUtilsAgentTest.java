/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link ClassUtils}.
 */
public class ClassUtilsAgentTest {

    private static class PrivateInner {
        class Member {
            // empty
        }
    }

    public static class PublicOuter {
        public static class PublicMember {
            // empty
        }
    }

    @Test
    public void testComparator() {
        final Comparator<Class<?>> comparator = ClassUtils.comparator();
        assertNotNull(comparator);
        assertTrue(comparator.compare(String.class, Integer.class) > 0);
        assertTrue(comparator.compare(Integer.class, String.class) < 0);
        assertEquals(0, comparator.compare(String.class, String.class));
        final List<Class<?>> list = new ArrayList<Class<?>>(Arrays.asList(String.class, Integer.class, Boolean.class));
        list.sort(comparator);
        assertEquals(Arrays.asList(Boolean.class, Integer.class, String.class), list);
    }

    @Test
    public void testConvertClassesToClassNames() {
        assertNull(ClassUtils.convertClassesToClassNames(null));
        final List<Class<?>> classes = new ArrayList<Class<?>>();
        classes.add(String.class);
        classes.add(null);
        classes.add(Integer.class);
        final List<String> names = ClassUtils.convertClassesToClassNames(classes);
        assertEquals(Arrays.asList("java.lang.String", null, "java.lang.Integer"), names);
    }

    @Test
    public void testConvertClassNamesToClasses() {
        assertNull(ClassUtils.convertClassNamesToClasses(null));
        final List<String> names = Arrays.asList("java.lang.String", "does.not.Exist", null);
        final List<Class<?>> classes = ClassUtils.convertClassNamesToClasses(names);
        assertEquals(3, classes.size());
        assertEquals(String.class, classes.get(0));
        assertNull(classes.get(1));
        assertNull(classes.get(2));
    }

    @Test
    public void testGetAbbreviatedNameClass() {
        assertEquals("", ClassUtils.getAbbreviatedName((Class<?>) null, 1));
        assertEquals("java.lang.String", ClassUtils.getAbbreviatedName(String.class, 30));
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName(String.class, 5));
    }

    @Test
    public void testGetAbbreviatedNameClassInvalidLength() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ClassUtils.getAbbreviatedName(String.class, 0);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ClassUtils.getAbbreviatedName("java.lang.String", -1);
            }
        });
    }

    @Test
    public void testGetAbbreviatedNameString() {
        assertEquals("", ClassUtils.getAbbreviatedName((String) null, 1));
        assertEquals("java.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 16));
        assertEquals("j.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 15));
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName("java.lang.String", 5));
        assertEquals("o.a.c.l.ClassUtils", ClassUtils.getAbbreviatedName("org.apache.commons.lang3.ClassUtils", 18));
    }

    @Test
    public void testGetAllInterfaces() {
        assertNull(ClassUtils.getAllInterfaces(null));
        final List<Class<?>> interfaces = ClassUtils.getAllInterfaces(ArrayList.class);
        assertTrue(interfaces.contains(List.class));
        assertTrue(interfaces.contains(Iterable.class));
    }

    @Test
    public void testGetAllSuperclasses() {
        assertNull(ClassUtils.getAllSuperclasses(null));
        final List<Class<?>> superclasses = ClassUtils.getAllSuperclasses(ArrayList.class);
        assertTrue(superclasses.contains(Object.class));
        assertEquals(Object.class, superclasses.get(superclasses.size() - 1));
        assertEquals(0, ClassUtils.getAllSuperclasses(Object.class).size());
    }

    @Test
    public void testGetCanonicalNameClass() {
        assertEquals("", ClassUtils.getCanonicalName((Class<?>) null));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName(String.class));
        assertEquals("int[]", ClassUtils.getCanonicalName(int[].class));
        assertEquals("NA", ClassUtils.getCanonicalName((Class<?>) null, "NA"));
    }

    @Test
    public void testGetCanonicalNameObject() {
        assertEquals("", ClassUtils.getCanonicalName((Object) null));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName("hello"));
        assertEquals("NA", ClassUtils.getCanonicalName((Object) null, "NA"));
    }

    @Test
    public void testGetClassVariants() throws ClassNotFoundException {
        assertEquals(String.class, ClassUtils.getClass("java.lang.String"));
        assertEquals(int.class, ClassUtils.getClass("int"));
        assertEquals(String[].class, ClassUtils.getClass("[Ljava.lang.String;"));
        assertEquals(String[].class, ClassUtils.getClass("java.lang.String[]"));
        assertEquals(Map.Entry.class, ClassUtils.getClass("java.util.Map.Entry"));
        assertEquals(Map.Entry.class, ClassUtils.getClass("java.util.Map$Entry"));
        // whitespace is normalized away by the lenient variant
        assertEquals(String.class, ClassUtils.getClass(" java.lang.String "));
    }

    @Test
    public void testGetClassNotFound() {
        assertThrows(ClassNotFoundException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws ClassNotFoundException {
                ClassUtils.getClass("does.not.Exist");
            }
        });
    }

    @Test
    public void testGetClassNullPointer() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws ClassNotFoundException {
                ClassUtils.getClass((String) null);
            }
        });
    }

    @Test
    public void testGetClassStrict() throws ClassNotFoundException {
        assertEquals(String.class, ClassUtils.getClassStrict("java.lang.String"));
        // the strict variant does not normalize whitespace away, so this must fail
        assertThrows(ClassNotFoundException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws ClassNotFoundException {
                ClassUtils.getClassStrict(" java.lang.String ");
            }
        });
    }

    @Test
    public void testGetClassArrayDimensionTooLarge() {
        final StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 300; i++) {
            sb.append('[');
        }
        sb.append("Ljava.lang.String;");
        final String tooManyDims = sb.toString();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws ClassNotFoundException {
                ClassUtils.getClass(tooManyDims);
            }
        });
    }

    @Test
    public void testGetClassNameTooLong() {
        final StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 70000; i++) {
            sb.append('a');
        }
        final String tooLongName = sb.toString();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws ClassNotFoundException {
                ClassUtils.getClass(tooLongName);
            }
        });
    }

    @Test
    public void testGetComponentType() {
        assertNull(ClassUtils.getComponentType(null));
        assertEquals(String.class, ClassUtils.getComponentType(String[].class));
    }

    @Test
    public void testGetName() {
        assertEquals("", ClassUtils.getName((Class<?>) null));
        assertEquals("java.lang.String", ClassUtils.getName(String.class));
        assertEquals("NA", ClassUtils.getName((Class<?>) null, "NA"));
        assertEquals("", ClassUtils.getName((Object) null));
        assertEquals("java.lang.String", ClassUtils.getName("hello"));
        assertEquals("NA", ClassUtils.getName((Object) null, "NA"));
    }

    @Test
    public void testGetPackageCanonicalName() {
        assertEquals("", ClassUtils.getPackageCanonicalName((Class<?>) null));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName(String.class));
        assertEquals("", ClassUtils.getPackageCanonicalName(int[].class));
        assertEquals("NA", ClassUtils.getPackageCanonicalName((Object) null, "NA"));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName("hello", "NA"));
    }

    @Test
    public void testGetPackageName() {
        assertEquals("", ClassUtils.getPackageName((Class<?>) null));
        assertEquals("java.lang", ClassUtils.getPackageName(String.class));
        assertEquals("", ClassUtils.getPackageName(int[].class));
        assertEquals("NA", ClassUtils.getPackageName((Object) null, "NA"));
        assertEquals("java.lang", ClassUtils.getPackageName((Object) "hello", "NA"));
        assertEquals("", ClassUtils.getPackageName((String) null));
        assertEquals("", ClassUtils.getPackageName(""));
        assertEquals("java.lang", ClassUtils.getPackageName("java.lang.String"));
        assertEquals("java.lang", ClassUtils.getPackageName("[Ljava.lang.String;"));
    }

    @Test
    public void testGetPublicMethod() throws Exception {
        assertNotNull(ClassUtils.getPublicMethod(String.class, "length", new Class[0]));
        assertThrows(NoSuchMethodException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws NoSuchMethodException {
                ClassUtils.getPublicMethod(String.class, "noSuchMethodAtAll", new Class[0]);
            }
        });
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws NoSuchMethodException {
                ClassUtils.getPublicMethod(null, "length", new Class[0]);
            }
        });
    }

    @Test
    public void testGetShortCanonicalName() {
        assertEquals("", ClassUtils.getShortCanonicalName((Class<?>) null));
        assertEquals("String", ClassUtils.getShortCanonicalName(String.class));
        assertEquals("String[]", ClassUtils.getShortCanonicalName(String[].class));
        assertEquals("int[]", ClassUtils.getShortCanonicalName(int[].class));
        assertEquals("Entry", ClassUtils.getShortCanonicalName(Map.Entry.class));
        assertEquals("NA", ClassUtils.getShortCanonicalName((Object) null, "NA"));
        assertEquals("String", ClassUtils.getShortCanonicalName((Object) "hello", "NA"));
    }

    @Test
    public void testGetShortClassNameFromClass() {
        assertEquals("", ClassUtils.getShortClassName((Class<?>) null));
        assertEquals("ClassUtils", ClassUtils.getShortClassName(ClassUtils.class));
        assertEquals("ClassUtils[]", ClassUtils.getShortClassName(ClassUtils[].class));
        assertEquals("int[]", ClassUtils.getShortClassName(int[].class));
        assertEquals("Map.Entry", ClassUtils.getShortClassName(Map.Entry.class));
        assertEquals("NA", ClassUtils.getShortClassName((Object) null, "NA"));
        assertEquals("String", ClassUtils.getShortClassName((Object) "hello", "NA"));
    }

    @Test
    public void testGetShortClassNameFromString() {
        assertEquals("", ClassUtils.getShortClassName((String) null));
        assertEquals("", ClassUtils.getShortClassName(""));
        assertEquals("Map.Entry", ClassUtils.getShortClassName("java.util.Map$Entry"));
        assertEquals("ClassUtils", ClassUtils.getShortClassName("org.apache.commons.lang3.ClassUtils"));
        assertEquals("ClassUtils[]", ClassUtils.getShortClassName("[Lorg.apache.commons.lang3.ClassUtils;"));
        assertEquals("ClassUtils[][]", ClassUtils.getShortClassName("[[Lorg.apache.commons.lang3.ClassUtils;"));
        assertEquals("int[]", ClassUtils.getShortClassName("[I"));
        assertEquals("int[][]", ClassUtils.getShortClassName("[[I"));
    }

    @Test
    public void testGetSimpleName() {
        assertEquals("", ClassUtils.getSimpleName((Class<?>) null));
        assertEquals("String", ClassUtils.getSimpleName(String.class));
        assertEquals("NA", ClassUtils.getSimpleName((Class<?>) null, "NA"));
        assertEquals("", ClassUtils.getSimpleName((Object) null));
        assertEquals("String", ClassUtils.getSimpleName("hello"));
        assertEquals("NA", ClassUtils.getSimpleName((Object) null, "NA"));
    }

    @Test
    public void testHierarchyExcludeInterfaces() {
        final Iterable<Class<?>> hierarchy = ClassUtils.hierarchy(ArrayList.class);
        final List<Class<?>> list = new ArrayList<Class<?>>();
        final Iterator<Class<?>> it = hierarchy.iterator();
        while (it.hasNext()) {
            list.add(it.next());
        }
        assertEquals(ArrayList.class, list.get(0));
        assertTrue(list.contains(Object.class));
        assertFalse(list.contains(List.class));
        assertEquals(Object.class, list.get(list.size() - 1));
    }

    @Test
    public void testHierarchyIncludeInterfaces() {
        final Iterable<Class<?>> hierarchy = ClassUtils.hierarchy(ArrayList.class, ClassUtils.Interfaces.INCLUDE);
        final List<Class<?>> list = new ArrayList<Class<?>>();
        final Iterator<Class<?>> it = hierarchy.iterator();
        while (it.hasNext()) {
            list.add(it.next());
        }
        assertTrue(list.contains(List.class));
        assertTrue(list.contains(Iterable.class));
        assertTrue(list.contains(Object.class));
    }

    @Test
    public void testIsAssignable() {
        assertFalse(ClassUtils.isAssignable(String.class, null));
        assertTrue(ClassUtils.isAssignable((Class<?>) null, String.class));
        assertFalse(ClassUtils.isAssignable((Class<?>) null, int.class));
        assertTrue(ClassUtils.isAssignable(int.class, long.class));
        assertFalse(ClassUtils.isAssignable(int.class, Long.class));
        assertFalse(ClassUtils.isAssignable(int.class, Long.class, false));
        assertFalse(ClassUtils.isAssignable(long.class, int.class));
        assertTrue(ClassUtils.isAssignable(Integer.class, int.class));
        assertFalse(ClassUtils.isAssignable(Integer.class, int.class, false));
        assertTrue(ClassUtils.isAssignable(String.class, Object.class));
        assertFalse(ClassUtils.isAssignable(Object.class, String.class));
        assertTrue(ClassUtils.isAssignable(byte.class, short.class));
        assertTrue(ClassUtils.isAssignable(byte.class, double.class));
        assertFalse(ClassUtils.isAssignable(boolean.class, int.class));
        assertTrue(ClassUtils.isAssignable(boolean.class, boolean.class));
    }

    @Test
    public void testIsAssignableArray() {
        assertFalse(ClassUtils.isAssignable(new Class[] {String.class}, new Class[] {String.class, Integer.class}));
        assertTrue(ClassUtils.isAssignable(new Class[] {String.class, int.class}, new Class[] {Object.class, long.class}));
        assertTrue(ClassUtils.isAssignable((Class<?>[]) null, (Class<?>[]) null));
        assertFalse(ClassUtils.isAssignable(new Class[] {String.class}, (Class<?>[]) null));
    }

    @Test
    public void testIsInnerClass() {
        assertFalse(ClassUtils.isInnerClass(null));
        assertFalse(ClassUtils.isInnerClass(String.class));
        assertTrue(ClassUtils.isInnerClass(Map.Entry.class));
        assertTrue(ClassUtils.isInnerClass(PublicOuter.PublicMember.class));
    }

    @Test
    public void testIsPrimitiveOrWrapper() {
        assertFalse(ClassUtils.isPrimitiveOrWrapper(null));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(int.class));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(Integer.class));
        assertFalse(ClassUtils.isPrimitiveOrWrapper(String.class));
    }

    @Test
    public void testIsPrimitiveWrapper() {
        assertFalse(ClassUtils.isPrimitiveWrapper(null));
        assertTrue(ClassUtils.isPrimitiveWrapper(Integer.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(int.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(String.class));
    }

    @Test
    public void testIsPublic() {
        assertTrue(ClassUtils.isPublic(String.class));
        assertFalse(ClassUtils.isPublic(PrivateInner.class));
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ClassUtils.isPublic(null);
            }
        });
    }

    @Test
    public void testPrimitivesToWrappers() {
        assertNull(ClassUtils.primitivesToWrappers((Class<?>[]) null));
        assertEquals(0, ClassUtils.primitivesToWrappers(new Class[0]).length);
        final Class<?>[] result = ClassUtils.primitivesToWrappers(int.class, String.class, null);
        assertEquals(Integer.class, result[0]);
        assertEquals(String.class, result[1]);
        assertNull(result[2]);
    }

    @Test
    public void testPrimitiveToWrapper() {
        assertNull(ClassUtils.primitiveToWrapper(null));
        assertEquals(Integer.class, ClassUtils.primitiveToWrapper(int.class));
        assertEquals(String.class, ClassUtils.primitiveToWrapper(String.class));
        assertSame(Void.TYPE, ClassUtils.primitiveToWrapper(Void.TYPE));
    }

    @Test
    public void testToClass() {
        assertNull(ClassUtils.toClass((Object[]) null));
        assertEquals(0, ClassUtils.toClass().length);
        final Class<?>[] result = ClassUtils.toClass("hello", null, 1);
        assertEquals(String.class, result[0]);
        assertNull(result[1]);
        assertEquals(Integer.class, result[2]);
    }

    @Test
    public void testWrappersToPrimitives() {
        assertNull(ClassUtils.wrappersToPrimitives((Class<?>[]) null));
        assertEquals(0, ClassUtils.wrappersToPrimitives(new Class[0]).length);
        final Class<?>[] result = ClassUtils.wrappersToPrimitives(Integer.class, String.class, null);
        assertEquals(int.class, result[0]);
        assertNull(result[1]);
        assertNull(result[2]);
    }

    @Test
    public void testWrapperToPrimitive() {
        assertNull(ClassUtils.wrapperToPrimitive(null));
        assertEquals(int.class, ClassUtils.wrapperToPrimitive(Integer.class));
        assertNull(ClassUtils.wrapperToPrimitive(String.class));
    }

    @Test
    public void testConstructorIsPublic() {
        assertNotNull(new ClassUtils());
    }

    @Test
    public void testPackageSeparatorConstants() {
        assertEquals('.', ClassUtils.PACKAGE_SEPARATOR_CHAR);
        assertEquals(".", ClassUtils.PACKAGE_SEPARATOR);
        assertEquals('$', ClassUtils.INNER_CLASS_SEPARATOR_CHAR);
        assertEquals("$", ClassUtils.INNER_CLASS_SEPARATOR);
    }

    @Test
    public void testIsAssignableNotEquals() {
        assertNotEquals(ClassUtils.isAssignable(String.class, Integer.class), ClassUtils.isAssignable(Integer.class, Integer.class));
    }
}
