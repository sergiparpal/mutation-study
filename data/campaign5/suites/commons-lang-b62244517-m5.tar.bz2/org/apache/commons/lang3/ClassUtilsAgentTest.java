/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link ClassUtils}.
 */
class ClassUtilsAgentTest {

    interface FixtureInterfaceA {
        // marker interface
    }

    interface FixtureInterfaceB extends FixtureInterfaceA {
        // marker interface extending another
    }

    static class FixtureBase implements FixtureInterfaceA {
        // base fixture class
    }

    static class FixtureChild extends FixtureBase implements FixtureInterfaceB {
        // child fixture class
    }

    static class Outer {
        static class Inner {
            // static nested class used to test isInnerClass/getShortClassName
        }
    }

    @Test
    void testGetAbbreviatedName_classOverload_nullClass() {
        assertEquals("", ClassUtils.getAbbreviatedName((Class<?>) null, 10));
    }

    @Test
    void testGetAbbreviatedName_classOverload() {
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName(String.class, 5));
    }

    @Test
    void testGetAbbreviatedName_stringOverload_nullName() {
        assertEquals("", ClassUtils.getAbbreviatedName((String) null, 10));
    }

    @Test
    void testGetAbbreviatedName_stringOverload_fitsWithoutShortening() {
        assertEquals("java.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 30));
    }

    @Test
    void testGetAbbreviatedName_stringOverload_partialShortening() {
        assertEquals("j.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 15));
    }

    @Test
    void testGetAbbreviatedName_stringOverload_fullShortening() {
        assertEquals("o.a.c.l.ClassUtils", ClassUtils.getAbbreviatedName("org.apache.commons.lang3.ClassUtils", 18));
    }

    @Test
    void testGetAbbreviatedName_lengthHintZeroThrows() {
        assertThrows(IllegalArgumentException.class, () -> ClassUtils.getAbbreviatedName("java.lang.String", 0));
    }

    @Test
    void testGetAbbreviatedName_lengthHintNegativeThrows() {
        assertThrows(IllegalArgumentException.class, () -> ClassUtils.getAbbreviatedName("java.lang.String", -1));
    }

    @Test
    void testGetAllInterfaces_nullReturnsNull() {
        assertNull(ClassUtils.getAllInterfaces(null));
    }

    @Test
    void testGetAllInterfaces_ordersAndDeduplicates() {
        final List<Class<?>> interfaces = ClassUtils.getAllInterfaces(FixtureChild.class);
        assertTrue(interfaces.contains(FixtureInterfaceA.class));
        assertTrue(interfaces.contains(FixtureInterfaceB.class));
        // FixtureInterfaceA appears only once even though it is reachable via two paths
        int countA = 0;
        for (final Class<?> c : interfaces) {
            if (c.equals(FixtureInterfaceA.class)) {
                countA++;
            }
        }
        assertEquals(1, countA);
    }

    @Test
    void testGetAllSuperclasses_nullReturnsNull() {
        assertNull(ClassUtils.getAllSuperclasses(null));
    }

    @Test
    void testGetAllSuperclasses_endsWithObject() {
        final List<Class<?>> superclasses = ClassUtils.getAllSuperclasses(FixtureChild.class);
        assertEquals(FixtureBase.class, superclasses.get(0));
        assertEquals(Object.class, superclasses.get(superclasses.size() - 1));
    }

    @Test
    void testGetCanonicalName_classNull() {
        assertEquals("", ClassUtils.getCanonicalName((Class<?>) null));
    }

    @Test
    void testGetCanonicalName_classWithValueIfNull() {
        assertEquals("fallback", ClassUtils.getCanonicalName((Class<?>) null, "fallback"));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName(String.class, "fallback"));
    }

    @Test
    void testGetCanonicalName_objectNull() {
        assertEquals("", ClassUtils.getCanonicalName((Object) null));
        assertEquals("fallback", ClassUtils.getCanonicalName((Object) null, "fallback"));
    }

    @Test
    void testGetCanonicalName_objectNonNull() {
        assertEquals("java.lang.String", ClassUtils.getCanonicalName("hello", "fallback"));
    }

    @Test
    void testGetClass_primitiveAndArraySyntaxes() throws ClassNotFoundException {
        assertSame(int.class, ClassUtils.getClass("int"));
        assertEquals("[I", ClassUtils.getClass("int[]").getName());
        assertEquals("[Ljava.lang.String;", ClassUtils.getClass("java.lang.String[]").getName());
        assertEquals(Outer.Inner.class, ClassUtils.getClass("org.apache.commons.lang3.ClassUtilsAgentTest.Outer.Inner"));
        assertEquals(Outer.Inner.class, ClassUtils.getClass("org.apache.commons.lang3.ClassUtilsAgentTest$Outer$Inner"));
    }

    @Test
    void testGetClass_notFoundThrows() {
        assertThrows(ClassNotFoundException.class, () -> ClassUtils.getClass("com.example.DoesNotExist"));
    }

    @Test
    void testGetClass_nullNameThrowsNPE() {
        assertThrows(NullPointerException.class, () -> ClassUtils.getClass((String) null));
    }

    @Test
    void testGetClass_withExplicitClassLoader() throws ClassNotFoundException {
        final ClassLoader loader = ClassUtilsAgentTest.class.getClassLoader();
        assertSame(String.class, ClassUtils.getClass(loader, "java.lang.String"));
    }

    @Test
    void testGetComponentType() {
        assertNull(ClassUtils.getComponentType(null));
        assertEquals(String.class, ClassUtils.getComponentType(String[].class));
    }

    @Test
    void testGetName_classOverloads() {
        assertEquals("", ClassUtils.getName((Class<?>) null));
        assertEquals("fallback", ClassUtils.getName((Class<?>) null, "fallback"));
        assertEquals("java.lang.String", ClassUtils.getName(String.class));
    }

    @Test
    void testGetName_objectOverloads() {
        assertEquals("", ClassUtils.getName((Object) null));
        assertEquals("fallback", ClassUtils.getName((Object) null, "fallback"));
        assertEquals("java.lang.String", ClassUtils.getName("hi"));
    }

    @Test
    void testGetPackageCanonicalName() {
        assertEquals("", ClassUtils.getPackageCanonicalName((Class<?>) null));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName(String.class));
        assertEquals("fallback", ClassUtils.getPackageCanonicalName((Object) null, "fallback"));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName("hi", "fallback"));
    }

    @Test
    void testGetPackageName_variants() {
        assertEquals("", ClassUtils.getPackageName((Class<?>) null));
        assertEquals("java.lang", ClassUtils.getPackageName(String.class));
        assertEquals("fallback", ClassUtils.getPackageName((Object) null, "fallback"));
        assertEquals("java.lang", ClassUtils.getPackageName("hi", "fallback"));
        assertEquals("", ClassUtils.getPackageName((String) null));
        assertEquals("", ClassUtils.getPackageName(""));
        assertEquals("", ClassUtils.getPackageName("NoPackageClass"));
    }

    @Test
    void testGetPublicMethod_foundOnNonPublicImpl() throws Exception {
        final List<String> unmodifiable = Collections.unmodifiableList(new ArrayList<String>());
        final Method method = ClassUtils.getPublicMethod(unmodifiable.getClass(), "isEmpty");
        assertTrue(ClassUtils.isPublic(method.getDeclaringClass()));
        assertEquals(Boolean.TRUE, method.invoke(unmodifiable));
    }

    @Test
    void testGetPublicMethod_notFoundThrows() {
        assertThrows(NoSuchMethodException.class, () -> ClassUtils.getPublicMethod(String.class, "noSuchMethodHere"));
    }

    @Test
    void testGetShortCanonicalName() {
        assertEquals("", ClassUtils.getShortCanonicalName((Class<?>) null));
        assertEquals("String", ClassUtils.getShortCanonicalName(String.class));
        assertEquals("fallback", ClassUtils.getShortCanonicalName((Object) null, "fallback"));
        assertEquals("String[]", ClassUtils.getShortCanonicalName("[Ljava.lang.String;"));
    }

    @Test
    void testGetShortClassName_classOverload() {
        assertEquals("", ClassUtils.getShortClassName((Class<?>) null));
        assertEquals("String", ClassUtils.getShortClassName(String.class));
    }

    @Test
    void testGetShortClassName_innerClassUsesDotSeparator() {
        assertEquals("ClassUtilsAgentTest.Outer.Inner", ClassUtils.getShortClassName(Outer.Inner.class));
    }

    @Test
    void testGetShortClassName_arrayEncoding() {
        assertEquals("int[]", ClassUtils.getShortClassName("[I"));
        assertEquals("String[]", ClassUtils.getShortClassName("[Ljava.lang.String;"));
    }

    @Test
    void testGetShortClassName_objectOverload() {
        assertEquals("fallback", ClassUtils.getShortClassName((Object) null, "fallback"));
        assertEquals("String", ClassUtils.getShortClassName("hi", "fallback"));
    }

    @Test
    void testGetSimpleName_classOverload() {
        assertEquals("", ClassUtils.getSimpleName((Class<?>) null));
        assertEquals("fallback", ClassUtils.getSimpleName((Class<?>) null, "fallback"));
        assertEquals("String", ClassUtils.getSimpleName(String.class));
    }

    @Test
    void testGetSimpleName_objectOverload() {
        assertEquals("", ClassUtils.getSimpleName((Object) null));
        assertEquals("fallback", ClassUtils.getSimpleName((Object) null, "fallback"));
        assertEquals("String", ClassUtils.getSimpleName("hi"));
    }

    @Test
    void testHierarchy_excludesInterfacesByDefault() {
        final Iterator<Class<?>> it = ClassUtils.hierarchy(FixtureChild.class).iterator();
        assertEquals(FixtureChild.class, it.next());
        assertEquals(FixtureBase.class, it.next());
        assertEquals(Object.class, it.next());
        assertFalse(it.hasNext());
    }

    @Test
    void testHierarchy_includesInterfaces() {
        final List<Class<?>> classes = new ArrayList<>();
        for (final Class<?> c : ClassUtils.hierarchy(FixtureChild.class, ClassUtils.Interfaces.INCLUDE)) {
            classes.add(c);
        }
        assertTrue(classes.contains(FixtureInterfaceA.class));
        assertTrue(classes.contains(FixtureInterfaceB.class));
        assertTrue(classes.contains(FixtureBase.class));
        assertTrue(classes.contains(Object.class));
    }

    @Test
    void testIsAssignable_basic() {
        assertTrue(ClassUtils.isAssignable(String.class, Object.class));
        assertFalse(ClassUtils.isAssignable(Object.class, String.class));
        assertFalse(ClassUtils.isAssignable(String.class, (Class<?>) null));
        assertTrue(ClassUtils.isAssignable((Class<?>) null, Object.class));
        assertFalse(ClassUtils.isAssignable((Class<?>) null, int.class));
    }

    @Test
    void testIsAssignable_primitiveWideningAndAutoboxing() {
        assertTrue(ClassUtils.isAssignable(int.class, long.class));
        assertFalse(ClassUtils.isAssignable(long.class, int.class));
        assertFalse(ClassUtils.isAssignable(int.class, Long.class));
        assertFalse(ClassUtils.isAssignable(int.class, Long.class, false));
        assertTrue(ClassUtils.isAssignable(Integer.class, int.class));
    }

    @Test
    void testIsAssignable_arrayOverload() {
        assertTrue(ClassUtils.isAssignable(new Class<?>[] { String.class, Integer.class }, Object.class, Number.class));
        assertFalse(ClassUtils.isAssignable(new Class<?>[] { String.class }, Object.class, Number.class));
        assertFalse(ClassUtils.isAssignable((Class<?>[]) null, new Class<?>[] { Object.class }));
        assertTrue(ClassUtils.isAssignable((Class<?>[]) null, (Class<?>[]) null));
    }

    @Test
    void testIsInnerClass() {
        assertTrue(ClassUtils.isInnerClass(Outer.Inner.class));
        assertFalse(ClassUtils.isInnerClass(String.class));
        assertFalse(ClassUtils.isInnerClass(null));
    }

    @Test
    void testIsPrimitiveOrWrapperAndWrapper() {
        assertTrue(ClassUtils.isPrimitiveOrWrapper(int.class));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(Integer.class));
        assertFalse(ClassUtils.isPrimitiveOrWrapper(String.class));
        assertFalse(ClassUtils.isPrimitiveOrWrapper(null));

        assertFalse(ClassUtils.isPrimitiveWrapper(int.class));
        assertTrue(ClassUtils.isPrimitiveWrapper(Integer.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(null));
    }

    @Test
    void testIsPublic() {
        assertTrue(ClassUtils.isPublic(String.class));
        assertFalse(ClassUtils.isPublic(Collections.unmodifiableList(new ArrayList<String>()).getClass()));
    }

    @Test
    void testIsPublic_nullThrowsNPE() {
        assertThrows(NullPointerException.class, () -> ClassUtils.isPublic(null));
    }

    @Test
    void testPrimitivesToWrappers() {
        assertNull(ClassUtils.primitivesToWrappers((Class<?>[]) null));
        assertEquals(0, ClassUtils.primitivesToWrappers().length);
        final Class<?>[] result = ClassUtils.primitivesToWrappers(int.class, String.class, null);
        assertEquals(Integer.class, result[0]);
        assertEquals(String.class, result[1]);
        assertNull(result[2]);
    }

    @Test
    void testPrimitiveToWrapper() {
        assertEquals(Integer.class, ClassUtils.primitiveToWrapper(int.class));
        assertEquals(String.class, ClassUtils.primitiveToWrapper(String.class));
        assertNull(ClassUtils.primitiveToWrapper(null));
        assertEquals(Void.TYPE, ClassUtils.primitiveToWrapper(Void.TYPE));
    }

    @Test
    void testToClass() {
        assertNull(ClassUtils.toClass((Object[]) null));
        assertEquals(0, ClassUtils.toClass().length);
        final Class<?>[] result = ClassUtils.toClass("a", 1, null);
        assertEquals(String.class, result[0]);
        assertEquals(Integer.class, result[1]);
        assertNull(result[2]);
    }

    @Test
    void testWrappersToPrimitives() {
        assertNull(ClassUtils.wrappersToPrimitives((Class<?>[]) null));
        assertEquals(0, ClassUtils.wrappersToPrimitives().length);
        final Class<?>[] result = ClassUtils.wrappersToPrimitives(Integer.class, String.class, null);
        assertEquals(int.class, result[0]);
        assertNull(result[1]);
        assertNull(result[2]);
    }

    @Test
    void testWrapperToPrimitive() {
        assertEquals(int.class, ClassUtils.wrapperToPrimitive(Integer.class));
        assertNull(ClassUtils.wrapperToPrimitive(String.class));
        assertNull(ClassUtils.wrapperToPrimitive(null));
    }

    @Test
    void testComparator() {
        final List<Class<?>> list = new ArrayList<>();
        list.add(String.class);
        list.add(Integer.class);
        Collections.sort(list, ClassUtils.comparator());
        assertEquals(Integer.class, list.get(0));
        assertEquals(String.class, list.get(1));
    }

    @Test
    void testConvertClassesToClassNames() {
        assertNull(ClassUtils.convertClassesToClassNames(null));
        final List<Class<?>> classes = new ArrayList<>();
        classes.add(String.class);
        classes.add(null);
        final List<String> names = ClassUtils.convertClassesToClassNames(classes);
        assertEquals("java.lang.String", names.get(0));
        assertNull(names.get(1));
    }

    @Test
    void testConvertClassNamesToClasses() {
        assertNull(ClassUtils.convertClassNamesToClasses(null));
        final List<String> names = new ArrayList<>();
        names.add("java.lang.String");
        names.add("com.example.DoesNotExist");
        names.add(null);
        final List<Class<?>> classes = ClassUtils.convertClassNamesToClasses(names);
        assertEquals(String.class, classes.get(0));
        assertNull(classes.get(1));
        assertNull(classes.get(2));
    }

    @Test
    void testInterfacesEnum() {
        assertEquals(2, ClassUtils.Interfaces.values().length);
        assertNotNull(ClassUtils.Interfaces.valueOf("INCLUDE"));
        assertNotNull(ClassUtils.Interfaces.valueOf("EXCLUDE"));
    }

    @Test
    void testPublicConstructor() {
        assertNotNull(new ClassUtils());
    }
}
