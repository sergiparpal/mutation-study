/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZonedDateTime;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;
import java.util.NoSuchElementException;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

class DateUtilsAgentTest {

    private static Calendar newCalendar(final int year, final int month, final int day, final int hour, final int minute, final int second,
            final int millis) {
        final Calendar c = Calendar.getInstance();
        c.clear();
        c.set(year, month, day, hour, minute, second);
        c.set(Calendar.MILLISECOND, millis);
        return c;
    }

    private static Date newDate(final int year, final int month, final int day, final int hour, final int minute, final int second, final int millis) {
        return newCalendar(year, month, day, hour, minute, second, millis).getTime();
    }

    // ---- add*() ----

    @Test
    void testAddDays() {
        final Date date = newDate(2020, Calendar.FEBRUARY, 28, 10, 0, 0, 0);
        final Date result = DateUtils.addDays(date, 2);
        assertEquals(newDate(2020, Calendar.MARCH, 1, 10, 0, 0, 0), result);
        // original is unchanged
        assertEquals(newDate(2020, Calendar.FEBRUARY, 28, 10, 0, 0, 0), date);
        assertEquals(newDate(2020, Calendar.FEBRUARY, 26, 10, 0, 0, 0), DateUtils.addDays(date, -2));
    }

    @Test
    void testAddHoursMinutesSecondsMilliseconds() {
        final Date date = newDate(2020, Calendar.JANUARY, 1, 23, 59, 59, 999);
        assertEquals(newDate(2020, Calendar.JANUARY, 2, 0, 59, 59, 999), DateUtils.addHours(date, 1));
        assertEquals(newDate(2020, Calendar.JANUARY, 2, 0, 0, 59, 999), DateUtils.addMinutes(date, 1));
        assertEquals(newDate(2020, Calendar.JANUARY, 2, 0, 0, 0, 999), DateUtils.addSeconds(date, 1));
        assertEquals(newDate(2020, Calendar.JANUARY, 2, 0, 0, 0, 0), DateUtils.addMilliseconds(date, 1));
    }

    @Test
    void testAddMonthsAndYearsAndWeeks() {
        final Date date = newDate(2019, Calendar.DECEMBER, 31, 0, 0, 0, 0);
        assertEquals(newDate(2020, Calendar.JANUARY, 31, 0, 0, 0, 0), DateUtils.addMonths(date, 1));
        assertEquals(newDate(2020, Calendar.DECEMBER, 31, 0, 0, 0, 0), DateUtils.addYears(date, 1));
        assertEquals(newDate(2020, Calendar.JANUARY, 7, 0, 0, 0, 0), DateUtils.addWeeks(date, 1));
    }

    @Test
    void testAddNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, () -> DateUtils.addDays(null, 1));
        assertThrows(NullPointerException.class, () -> DateUtils.addHours(null, 1));
        assertThrows(NullPointerException.class, () -> DateUtils.addMinutes(null, 1));
        assertThrows(NullPointerException.class, () -> DateUtils.addSeconds(null, 1));
        assertThrows(NullPointerException.class, () -> DateUtils.addMilliseconds(null, 1));
        assertThrows(NullPointerException.class, () -> DateUtils.addMonths(null, 1));
        assertThrows(NullPointerException.class, () -> DateUtils.addYears(null, 1));
        assertThrows(NullPointerException.class, () -> DateUtils.addWeeks(null, 1));
    }

    // ---- ceiling / round / truncate ----

    @Test
    void testCeilingDate() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 14, 0, 0, 0), DateUtils.ceiling(date, Calendar.HOUR));
        assertEquals(newDate(2002, Calendar.APRIL, 1, 0, 0, 0, 0), DateUtils.ceiling(date, Calendar.MONTH));
    }

    @Test
    void testCeilingCalendarUnchangedWhenAlreadyOnBoundary() {
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 14, 0, 0, 0);
        final Calendar ceil = DateUtils.ceiling(cal, Calendar.HOUR);
        assertEquals(cal, ceil);
        // input calendar is not mutated
        assertEquals(14, cal.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    void testCeilingObjectDispatch() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertEquals(DateUtils.ceiling(date, Calendar.HOUR), DateUtils.ceiling((Object) date, Calendar.HOUR));
        assertEquals(DateUtils.ceiling(date, Calendar.HOUR), DateUtils.ceiling((Object) cal, Calendar.HOUR));
    }

    @Test
    void testCeilingNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, () -> DateUtils.ceiling((Date) null, Calendar.YEAR));
        assertThrows(NullPointerException.class, () -> DateUtils.ceiling((Calendar) null, Calendar.YEAR));
        assertThrows(NullPointerException.class, () -> DateUtils.ceiling((Object) null, Calendar.YEAR));
    }

    @Test
    void testCeilingInvalidObjectTypeThrowsClassCastException() {
        assertThrows(ClassCastException.class, () -> DateUtils.ceiling("not a date", Calendar.YEAR));
    }

    @Test
    void testCeilingInvalidFieldThrowsIllegalArgumentException() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertThrows(IllegalArgumentException.class, () -> DateUtils.ceiling(date, Calendar.ZONE_OFFSET));
    }

    @Test
    void testModifyHugeYearThrowsArithmeticException() {
        final Calendar cal = Calendar.getInstance();
        cal.set(Calendar.YEAR, 280000001);
        assertThrows(ArithmeticException.class, () -> DateUtils.round(cal, Calendar.YEAR));
        assertThrows(ArithmeticException.class, () -> DateUtils.truncate(cal, Calendar.YEAR));
        assertThrows(ArithmeticException.class, () -> DateUtils.ceiling(cal, Calendar.YEAR));
    }

    @Test
    void testRoundSemiMonthSpecialCases() {
        // day 1 is already on the boundary, rounds (down) to itself
        final Date firstOfMonth = newDate(2021, Calendar.MARCH, 1, 0, 0, 0, 0);
        assertEquals(newDate(2021, Calendar.MARCH, 1, 0, 0, 0, 0), DateUtils.round(firstOfMonth, DateUtils.SEMI_MONTH));
        // day 9 is past the midpoint of the first half, rounds up to the 16th
        final Date pastMidpointFirstHalf = newDate(2021, Calendar.MARCH, 9, 10, 0, 0, 0);
        assertEquals(newDate(2021, Calendar.MARCH, 16, 0, 0, 0, 0), DateUtils.round(pastMidpointFirstHalf, DateUtils.SEMI_MONTH));
        // day 24 is past the midpoint of the second half, rounds up to the 1st of the next month
        final Date pastMidpointSecondHalf = newDate(2021, Calendar.MARCH, 24, 10, 0, 0, 0);
        assertEquals(newDate(2021, Calendar.APRIL, 1, 0, 0, 0, 0), DateUtils.round(pastMidpointSecondHalf, DateUtils.SEMI_MONTH));
    }

    @Test
    void testRoundAmPmSpecialCase() {
        // 7am is past the midpoint of AM, rounds up to noon the same day
        final Date morning = newDate(2021, Calendar.MARCH, 5, 7, 30, 0, 0);
        assertEquals(newDate(2021, Calendar.MARCH, 5, 12, 0, 0, 0), DateUtils.round(morning, Calendar.AM_PM));
        // 6pm is past the midpoint of PM, rounds up to midnight the next day
        final Date evening = newDate(2021, Calendar.MARCH, 5, 18, 30, 0, 0);
        assertEquals(newDate(2021, Calendar.MARCH, 6, 0, 0, 0, 0), DateUtils.round(evening, Calendar.AM_PM));
    }

    @Test
    void testTruncateDate() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 13, 0, 0, 0), DateUtils.truncate(date, Calendar.HOUR));
        assertEquals(newDate(2002, Calendar.MARCH, 1, 0, 0, 0, 0), DateUtils.truncate(date, Calendar.MONTH));
    }

    @Test
    void testTruncateMillisecondIsIdentity() {
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Calendar truncated = DateUtils.truncate(cal, Calendar.MILLISECOND);
        assertEquals(cal, truncated);
    }

    @Test
    void testTruncateNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, () -> DateUtils.truncate((Date) null, Calendar.YEAR));
        assertThrows(NullPointerException.class, () -> DateUtils.truncate((Calendar) null, Calendar.YEAR));
        assertThrows(NullPointerException.class, () -> DateUtils.truncate((Object) null, Calendar.YEAR));
    }

    @Test
    void testTruncateInvalidObjectTypeThrowsClassCastException() {
        assertThrows(ClassCastException.class, () -> DateUtils.truncate(Integer.valueOf(1), Calendar.YEAR));
    }

    @Test
    void testRoundInvalidObjectTypeThrowsClassCastException() {
        assertThrows(ClassCastException.class, () -> DateUtils.round(Integer.valueOf(1), Calendar.YEAR));
    }

    @Test
    void testRoundNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, () -> DateUtils.round((Date) null, Calendar.YEAR));
        assertThrows(NullPointerException.class, () -> DateUtils.round((Calendar) null, Calendar.YEAR));
        assertThrows(NullPointerException.class, () -> DateUtils.round((Object) null, Calendar.YEAR));
    }

    // ---- truncatedCompareTo / truncatedEquals ----

    @Test
    void testTruncatedEqualsAndCompareToDate() {
        final Date d1 = newDate(2021, Calendar.MARCH, 5, 10, 15, 0, 0);
        final Date d2 = newDate(2021, Calendar.MARCH, 5, 23, 59, 59, 999);
        final Date d3 = newDate(2021, Calendar.MARCH, 6, 0, 0, 0, 0);
        assertTrue(DateUtils.truncatedEquals(d1, d2, Calendar.DATE));
        assertEquals(0, DateUtils.truncatedCompareTo(d1, d2, Calendar.DATE));
        assertFalse(DateUtils.truncatedEquals(d1, d3, Calendar.DATE));
        assertTrue(DateUtils.truncatedCompareTo(d1, d3, Calendar.DATE) < 0);
        assertTrue(DateUtils.truncatedCompareTo(d3, d1, Calendar.DATE) > 0);
    }

    @Test
    void testTruncatedEqualsAndCompareToCalendar() {
        final Calendar c1 = newCalendar(2021, Calendar.MARCH, 5, 10, 15, 0, 0);
        final Calendar c2 = newCalendar(2021, Calendar.MARCH, 5, 23, 59, 59, 999);
        assertTrue(DateUtils.truncatedEquals(c1, c2, Calendar.DATE));
        assertEquals(0, DateUtils.truncatedCompareTo(c1, c2, Calendar.DATE));
    }

    // ---- fragments ----

    @Test
    void testGetFragmentInDays() {
        final Date date = newDate(2008, Calendar.FEBRUARY, 28, 7, 15, 10, 538);
        assertEquals(59, DateUtils.getFragmentInDays(date, Calendar.YEAR));
        assertEquals(28, DateUtils.getFragmentInDays(date, Calendar.MONTH));
        assertEquals(0, DateUtils.getFragmentInDays(date, Calendar.DATE));
        assertEquals(0, DateUtils.getFragmentInDays(date, Calendar.MILLISECOND));
    }

    @Test
    void testGetFragmentInHours() {
        final Date oneDay = newDate(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        final Date sixDays = newDate(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(7, DateUtils.getFragmentInHours(oneDay, Calendar.DAY_OF_YEAR));
        assertEquals(7, DateUtils.getFragmentInHours(oneDay, Calendar.MONTH));
        assertEquals(127, DateUtils.getFragmentInHours(sixDays, Calendar.MONTH));
    }

    @Test
    void testGetFragmentInMinutesSecondsMillis() {
        final Date date = newDate(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(15, DateUtils.getFragmentInMinutes(date, Calendar.HOUR_OF_DAY));
        assertEquals(7635, DateUtils.getFragmentInMinutes(date, Calendar.MONTH));
        assertEquals(10, DateUtils.getFragmentInSeconds(date, Calendar.MINUTE));
        assertEquals(26110, DateUtils.getFragmentInSeconds(date, Calendar.DAY_OF_YEAR));
        assertEquals(538, DateUtils.getFragmentInMilliseconds(date, Calendar.SECOND));
        assertEquals(10538, DateUtils.getFragmentInMilliseconds(date, Calendar.MINUTE));
    }

    @Test
    void testGetFragmentCalendarOverload() {
        final Calendar cal = newCalendar(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(DateUtils.getFragmentInSeconds(cal.getTime(), Calendar.DAY_OF_YEAR), DateUtils.getFragmentInSeconds(cal, Calendar.DAY_OF_YEAR));
    }

    @Test
    void testGetFragmentUnsupportedFieldThrowsIllegalArgumentException() {
        final Date date = newDate(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertThrows(IllegalArgumentException.class, () -> DateUtils.getFragmentInDays(date, Calendar.ZONE_OFFSET));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.getFragmentInHours(date, Calendar.ZONE_OFFSET));
    }

    @Test
    void testGetFragmentNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, () -> DateUtils.getFragmentInDays((Date) null, Calendar.DATE));
        assertThrows(NullPointerException.class, () -> DateUtils.getFragmentInDays((Calendar) null, Calendar.DATE));
    }

    // ---- isSameDay / isSameInstant / isSameLocalTime ----

    @Test
    void testIsSameDay() {
        final Date d1 = newDate(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        final Date d2 = newDate(2002, Calendar.MARCH, 28, 6, 1, 0, 0);
        final Date d3 = newDate(2002, Calendar.MARCH, 12, 13, 45, 0, 0);
        assertTrue(DateUtils.isSameDay(d1, d2));
        assertFalse(DateUtils.isSameDay(d1, d3));
        assertTrue(DateUtils.isSameDay(DateUtils.toCalendar(d1), DateUtils.toCalendar(d2)));
        assertFalse(DateUtils.isSameDay(DateUtils.toCalendar(d1), DateUtils.toCalendar(d3)));
    }

    @Test
    void testIsSameDayNullThrowsNullPointerException() {
        final Date date = new Date();
        assertThrows(NullPointerException.class, () -> DateUtils.isSameDay((Date) null, date));
        assertThrows(NullPointerException.class, () -> DateUtils.isSameDay((Calendar) null, Calendar.getInstance()));
    }

    @Test
    void testIsSameInstant() {
        final Date d1 = new Date(10000L);
        final Date d2 = new Date(10000L);
        final Date d3 = new Date(10001L);
        assertTrue(DateUtils.isSameInstant(d1, d2));
        assertFalse(DateUtils.isSameInstant(d1, d3));
        final Calendar c1 = Calendar.getInstance();
        c1.setTime(d1);
        final Calendar c2 = Calendar.getInstance();
        c2.setTime(d2);
        assertTrue(DateUtils.isSameInstant(c1, c2));
    }

    @Test
    void testIsSameInstantNullThrowsNullPointerException() {
        final Date date = new Date();
        assertThrows(NullPointerException.class, () -> DateUtils.isSameInstant((Date) null, date));
        assertThrows(NullPointerException.class, () -> DateUtils.isSameInstant(date, (Date) null));
        assertThrows(NullPointerException.class, () -> DateUtils.isSameInstant((Calendar) null, Calendar.getInstance()));
    }

    @Test
    void testIsSameLocalTime() {
        final Calendar c1 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        final Calendar c2 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        assertTrue(DateUtils.isSameLocalTime(c1, c2));
        c2.add(Calendar.SECOND, 1);
        assertFalse(DateUtils.isSameLocalTime(c1, c2));
    }

    @Test
    void testIsSameLocalTimeDifferentCalendarClass() {
        final Calendar c1 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        final Calendar c2 = new java.util.GregorianCalendar() {
            private static final long serialVersionUID = 1L;
        };
        c2.setTime(c1.getTime());
        // different runtime class (anonymous subclass) -> not considered the same
        assertFalse(DateUtils.isSameLocalTime(c1, c2));
    }

    @Test
    void testIsSameLocalTimeNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, () -> DateUtils.isSameLocalTime((Calendar) null, Calendar.getInstance()));
    }

    // ---- iterator ----

    @Test
    void testIteratorRangeWeekSunday() {
        // Thursday July 4, 2002
        final Calendar focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        final Calendar first = it.next();
        assertEquals(Calendar.SUNDAY, first.get(Calendar.DAY_OF_WEEK));
        int count = 1;
        Calendar last = first;
        while (it.hasNext()) {
            last = it.next();
            count++;
        }
        assertEquals(7, count);
        assertEquals(Calendar.SATURDAY, last.get(Calendar.DAY_OF_WEEK));
    }

    @Test
    void testIteratorRangeMonthSunday() {
        // Thursday July 4, 2002 -> range starts Sun June 30, ends Sat Aug 3
        final Calendar focus = newCalendar(2002, Calendar.JULY, 4, 15, 30, 0, 0);
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_MONTH_SUNDAY);
        final Calendar first = it.next();
        assertEquals(2002, first.get(Calendar.YEAR));
        assertEquals(Calendar.JUNE, first.get(Calendar.MONTH));
        assertEquals(30, first.get(Calendar.DAY_OF_MONTH));
        Calendar last = first;
        while (it.hasNext()) {
            last = it.next();
        }
        assertEquals(Calendar.AUGUST, last.get(Calendar.MONTH));
        assertEquals(3, last.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testIteratorExhaustedThrowsNoSuchElementException() {
        final Calendar focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        while (it.hasNext()) {
            it.next();
        }
        assertFalse(it.hasNext());
        assertThrows(NoSuchElementException.class, it::next);
    }

    @Test
    void testIteratorRemoveThrowsUnsupportedOperationException() {
        final Calendar focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        assertThrows(UnsupportedOperationException.class, it::remove);
    }

    @Test
    void testIteratorDateAndObjectOverloads() {
        final Date focus = newDate(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        final Iterator<Calendar> fromDate = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        final Iterator<?> fromObjectDate = DateUtils.iterator((Object) focus, DateUtils.RANGE_WEEK_SUNDAY);
        final Iterator<?> fromObjectCalendar = DateUtils.iterator((Object) DateUtils.toCalendar(focus), DateUtils.RANGE_WEEK_SUNDAY);
        final Calendar first = fromDate.next();
        assertEquals(first, fromObjectDate.next());
        assertEquals(first, fromObjectCalendar.next());
    }

    @Test
    void testIteratorInvalidRangeStyleThrowsIllegalArgumentException() {
        final Calendar focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        assertThrows(IllegalArgumentException.class, () -> DateUtils.iterator(focus, -999));
    }

    @Test
    void testIteratorNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, () -> DateUtils.iterator((Calendar) null, DateUtils.RANGE_WEEK_SUNDAY));
        assertThrows(NullPointerException.class, () -> DateUtils.iterator((Date) null, DateUtils.RANGE_WEEK_SUNDAY));
        assertThrows(NullPointerException.class, () -> DateUtils.iterator((Object) null, DateUtils.RANGE_WEEK_SUNDAY));
    }

    @Test
    void testIteratorInvalidObjectTypeThrowsClassCastException() {
        assertThrows(ClassCastException.class, () -> DateUtils.iterator("not a date", DateUtils.RANGE_WEEK_SUNDAY));
    }

    // ---- parseDate / parseDateStrictly ----

    @Test
    void testParseDateSuccess() throws ParseException {
        final Date parsed = DateUtils.parseDate("2021-03-05", "yyyy-MM-dd");
        assertEquals(newDate(2021, Calendar.MARCH, 5, 0, 0, 0, 0), parsed);
    }

    @Test
    void testParseDateTriesEachPatternInTurn() throws ParseException {
        final Date parsed = DateUtils.parseDate("05/03/2021", "yyyy-MM-dd", "dd/MM/yyyy");
        assertEquals(newDate(2021, Calendar.MARCH, 5, 0, 0, 0, 0), parsed);
    }

    @Test
    void testParseDateWithLocale() throws ParseException {
        final Date parsed = DateUtils.parseDate("05-mars-2021", Locale.FRENCH, "dd-MMMM-yyyy");
        assertEquals(newDate(2021, Calendar.MARCH, 5, 0, 0, 0, 0), parsed);
    }

    @Test
    void testParseDateNoMatchingPatternThrowsParseException() {
        assertThrows(ParseException.class, () -> DateUtils.parseDate("not-a-date", "yyyy-MM-dd"));
    }

    @Test
    void testParseDateNoPatternsThrowsParseException() {
        assertThrows(ParseException.class, () -> DateUtils.parseDate("2021-03-05"));
    }

    @Test
    void testParseDatePartialMatchFailsWhenNotWholeString() {
        // trailing garbage means the whole string is not consumed
        assertThrows(ParseException.class, () -> DateUtils.parseDate("2021-03-05extra", "yyyy-MM-dd"));
    }

    @Test
    void testParseDateNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, () -> DateUtils.parseDate(null, "yyyy-MM-dd"));
        assertThrows(NullPointerException.class, () -> DateUtils.parseDate("2021-03-05", (String[]) null));
    }

    @Test
    void testParseDateLenientAcceptsOverflow() throws ParseException {
        // Lenient parsing normalizes day 32 of January into February 1
        final Date parsed = DateUtils.parseDate("2021-01-32", "yyyy-MM-dd");
        assertEquals(newDate(2021, Calendar.FEBRUARY, 1, 0, 0, 0, 0), parsed);
    }

    @Test
    void testParseDateStrictlyRejectsOverflow() {
        assertThrows(ParseException.class, () -> DateUtils.parseDateStrictly("2021-01-32", "yyyy-MM-dd"));
    }

    @Test
    void testParseDateStrictlySuccess() throws ParseException {
        final Date parsed = DateUtils.parseDateStrictly("2021-03-05", "yyyy-MM-dd");
        assertEquals(newDate(2021, Calendar.MARCH, 5, 0, 0, 0, 0), parsed);
    }

    @Test
    void testParseDateStrictlyWithLocale() throws ParseException {
        final Date parsed = DateUtils.parseDateStrictly("05-mars-2021", Locale.FRENCH, "dd-MMMM-yyyy");
        assertEquals(newDate(2021, Calendar.MARCH, 5, 0, 0, 0, 0), parsed);
    }

    @Test
    void testParseDateStrictlyNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, () -> DateUtils.parseDateStrictly(null, "yyyy-MM-dd"));
        assertThrows(NullPointerException.class, () -> DateUtils.parseDateStrictly("2021-03-05", (String[]) null));
    }

    // ---- set*() ----

    @Test
    void testSetDaysValid() {
        final Date date = newDate(2021, Calendar.MARCH, 5, 10, 20, 30, 40);
        assertEquals(newDate(2021, Calendar.MARCH, 15, 10, 20, 30, 40), DateUtils.setDays(date, 15));
    }

    @Test
    void testSetDaysInvalidThrowsIllegalArgumentException() {
        final Date date = newDate(2021, Calendar.MARCH, 5, 10, 20, 30, 40);
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setDays(date, 32));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setDays(date, 0));
    }

    @Test
    void testSetHoursValidAndInvalid() {
        final Date date = newDate(2021, Calendar.MARCH, 5, 10, 20, 30, 40);
        assertEquals(newDate(2021, Calendar.MARCH, 5, 23, 20, 30, 40), DateUtils.setHours(date, 23));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setHours(date, 24));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setHours(date, -1));
    }

    @Test
    void testSetMillisecondsValidAndInvalid() {
        final Date date = newDate(2021, Calendar.MARCH, 5, 10, 20, 30, 40);
        assertEquals(newDate(2021, Calendar.MARCH, 5, 10, 20, 30, 999), DateUtils.setMilliseconds(date, 999));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setMilliseconds(date, 1000));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setMilliseconds(date, -1));
    }

    @Test
    void testSetMinutesValidAndInvalid() {
        final Date date = newDate(2021, Calendar.MARCH, 5, 10, 20, 30, 40);
        assertEquals(newDate(2021, Calendar.MARCH, 5, 10, 59, 30, 40), DateUtils.setMinutes(date, 59));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setMinutes(date, 60));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setMinutes(date, -1));
    }

    @Test
    void testSetMonthsValidAndInvalid() {
        final Date date = newDate(2021, Calendar.MARCH, 5, 10, 20, 30, 40);
        assertEquals(newDate(2021, Calendar.DECEMBER, 5, 10, 20, 30, 40), DateUtils.setMonths(date, Calendar.DECEMBER));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setMonths(date, 12));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setMonths(date, -1));
    }

    @Test
    void testSetSecondsValidAndInvalid() {
        final Date date = newDate(2021, Calendar.MARCH, 5, 10, 20, 30, 40);
        assertEquals(newDate(2021, Calendar.MARCH, 5, 10, 20, 59, 40), DateUtils.setSeconds(date, 59));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setSeconds(date, 60));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setSeconds(date, -1));
    }

    @Test
    void testSetYears() {
        final Date date = newDate(2021, Calendar.MARCH, 5, 10, 20, 30, 40);
        assertEquals(newDate(1999, Calendar.MARCH, 5, 10, 20, 30, 40), DateUtils.setYears(date, 1999));
    }

    @Test
    void testSetNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, () -> DateUtils.setDays(null, 1));
        assertThrows(NullPointerException.class, () -> DateUtils.setHours(null, 1));
        assertThrows(NullPointerException.class, () -> DateUtils.setMilliseconds(null, 1));
        assertThrows(NullPointerException.class, () -> DateUtils.setMinutes(null, 1));
        assertThrows(NullPointerException.class, () -> DateUtils.setMonths(null, 1));
        assertThrows(NullPointerException.class, () -> DateUtils.setSeconds(null, 1));
        assertThrows(NullPointerException.class, () -> DateUtils.setYears(null, 1));
    }

    // ---- toCalendar / toLocalDateTime / toOffsetDateTime / toZonedDateTime ----

    @Test
    void testToCalendar() {
        final Date date = newDate(2021, Calendar.MARCH, 5, 10, 20, 30, 40);
        final Calendar cal = DateUtils.toCalendar(date);
        assertEquals(date, cal.getTime());
    }

    @Test
    void testToCalendarNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, () -> DateUtils.toCalendar(null));
        assertThrows(NullPointerException.class, () -> DateUtils.toCalendar(null, TimeZone.getDefault()));
        final Date date = new Date();
        assertThrows(NullPointerException.class, () -> DateUtils.toCalendar(date, null));
    }

    @Test
    void testToCalendarWithTimeZone() {
        final Date date = new Date(0L);
        final TimeZone utc = TimeZone.getTimeZone("UTC");
        final Calendar cal = DateUtils.toCalendar(date, utc);
        assertEquals(utc, cal.getTimeZone());
        assertEquals(0L, cal.getTimeInMillis());
    }

    @Test
    void testToLocalDateTime() {
        final TimeZone utc = TimeZone.getTimeZone("UTC");
        final Date date = new Date(0L);
        final LocalDateTime ldt = DateUtils.toLocalDateTime(date, utc);
        assertEquals(LocalDateTime.of(1970, 1, 1, 0, 0, 0), ldt);
        // null timeZone maps to the default time zone, should not throw
        final LocalDateTime defaultZoneResult = DateUtils.toLocalDateTime(date, null);
        assertEquals(DateUtils.toLocalDateTime(date), defaultZoneResult);
    }

    @Test
    void testToOffsetDateTime() {
        final TimeZone utc = TimeZone.getTimeZone("UTC");
        final Date date = new Date(0L);
        final OffsetDateTime odt = DateUtils.toOffsetDateTime(date, utc);
        assertEquals(0L, odt.toInstant().toEpochMilli());
    }

    @Test
    void testToZonedDateTime() {
        final TimeZone utc = TimeZone.getTimeZone("UTC");
        final Date date = new Date(0L);
        final ZonedDateTime zdt = DateUtils.toZonedDateTime(date, utc);
        assertEquals(0L, zdt.toInstant().toEpochMilli());
    }

    // ---- constants ----

    @Test
    void testMillisConstants() {
        assertEquals(1000L, DateUtils.MILLIS_PER_SECOND);
        assertEquals(60000L, DateUtils.MILLIS_PER_MINUTE);
        assertEquals(3600000L, DateUtils.MILLIS_PER_HOUR);
        assertEquals(86400000L, DateUtils.MILLIS_PER_DAY);
    }

    // ---- deprecated public constructor (kept for JavaBean tools) ----

    @Test
    void testPublicConstructorIsUsable() {
        final DateUtils instance = new DateUtils();
        assertFalse(instance == null);
    }
}
