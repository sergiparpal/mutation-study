/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.Serializable;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Supplier;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link ObjectUtils}.
 */
public class ObjectUtilsAgentTest {

    /** Simple cloneable fixture with a mutable field. */
    private static final class CloneableObject implements Cloneable {
        int value;

        CloneableObject(final int value) {
            this.value = value;
        }

        @Override
        public CloneableObject clone() throws CloneNotSupportedException {
            return (CloneableObject) super.clone();
        }
    }

    /** Cloneable fixture whose clone() throws, to exercise the failure path. */
    private static final class ThrowingCloneable implements Cloneable {
        @Override
        public Object clone() throws CloneNotSupportedException {
            throw new CloneNotSupportedException("nope");
        }
    }

    /** Non-cloneable fixture. */
    private static final class NotCloneable {
        // intentionally does not implement Cloneable
    }

    private static final class FixedComparable implements Comparable<FixedComparable> {
        final int n;

        FixedComparable(final int n) {
            this.n = n;
        }

        @Override
        public int compareTo(final FixedComparable o) {
            return Integer.compare(n, o.n);
        }

        @Override
        public String toString() {
            return "FixedComparable(" + n + ")";
        }
    }

    // --- allNotNull / allNull / anyNotNull / anyNull ---

    @Test
    public void testAllNotNull() {
        assertTrue(ObjectUtils.allNotNull());
        assertTrue(ObjectUtils.allNotNull("a"));
        assertTrue(ObjectUtils.allNotNull("a", "b"));
        assertFalse(ObjectUtils.allNotNull((Object) null));
        assertFalse(ObjectUtils.allNotNull(null, null));
        assertFalse(ObjectUtils.allNotNull(null, "a"));
        assertFalse(ObjectUtils.allNotNull("a", null));
        assertFalse(ObjectUtils.allNotNull((Object[]) null));
    }

    @Test
    public void testAllNull() {
        assertTrue(ObjectUtils.allNull());
        assertTrue(ObjectUtils.allNull((Object[]) null));
        assertTrue(ObjectUtils.allNull((Object) null));
        assertTrue(ObjectUtils.allNull(null, null));
        assertFalse(ObjectUtils.allNull("a"));
        assertFalse(ObjectUtils.allNull(null, "a"));
    }

    @Test
    public void testAnyNotNull() {
        assertFalse(ObjectUtils.anyNotNull());
        assertFalse(ObjectUtils.anyNotNull((Object[]) null));
        assertFalse(ObjectUtils.anyNotNull((Object) null));
        assertFalse(ObjectUtils.anyNotNull(null, null));
        assertTrue(ObjectUtils.anyNotNull("a"));
        assertTrue(ObjectUtils.anyNotNull(null, "a"));
    }

    @Test
    public void testAnyNull() {
        assertTrue(ObjectUtils.anyNull((Object) null));
        assertTrue(ObjectUtils.anyNull((Object[]) null));
        assertTrue(ObjectUtils.anyNull(null, "a"));
        assertFalse(ObjectUtils.anyNull());
        assertFalse(ObjectUtils.anyNull("a", "b"));
    }

    // --- clone / cloneIfPossible ---

    @Test
    public void testCloneNull() {
        assertNull(ObjectUtils.clone(null));
    }

    @Test
    public void testCloneNotCloneableReturnsNull() {
        assertNull(ObjectUtils.clone(new NotCloneable()));
    }

    @Test
    public void testCloneCloneableObject() {
        final CloneableObject original = new CloneableObject(42);
        final CloneableObject cloned = ObjectUtils.clone(original);
        assertNotNull(cloned);
        assertEquals(42, cloned.value);
        assertFalse(original == cloned);
    }

    @Test
    public void testCloneArray() {
        final int[] array = {1, 2, 3};
        final int[] cloned = ObjectUtils.clone(array);
        assertArrayEquals(array, cloned);
        assertFalse(array == cloned);
    }

    @Test
    public void testCloneFailedException() {
        assertThrows(org.apache.commons.lang3.exception.CloneFailedException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() {
                        ObjectUtils.clone(new ThrowingCloneable());
                    }
                });
    }

    @Test
    public void testCloneIfPossibleNull() {
        assertNull(ObjectUtils.cloneIfPossible(null));
    }

    @Test
    public void testCloneIfPossibleNotCloneableReturnsSameInstance() {
        final NotCloneable obj = new NotCloneable();
        assertSame(obj, ObjectUtils.cloneIfPossible(obj));
    }

    @Test
    public void testCloneIfPossibleCloneable() {
        final CloneableObject original = new CloneableObject(7);
        final CloneableObject result = ObjectUtils.cloneIfPossible(original);
        assertFalse(original == result);
        assertEquals(7, result.value);
    }

    // --- compare ---

    @Test
    public void testCompareBothNull() {
        assertEquals(0, ObjectUtils.compare((String) null, (String) null));
    }

    @Test
    public void testCompareNullLessByDefault() {
        assertTrue(ObjectUtils.compare(null, "a") < 0);
        assertTrue(ObjectUtils.compare("a", null) > 0);
    }

    @Test
    public void testCompareNullGreaterFlag() {
        assertTrue(ObjectUtils.compare(null, "a", true) > 0);
        assertTrue(ObjectUtils.compare("a", null, true) < 0);
    }

    @Test
    public void testCompareNonNullValues() {
        assertTrue(ObjectUtils.compare("a", "b") < 0);
        assertTrue(ObjectUtils.compare("b", "a") > 0);
        assertEquals(0, ObjectUtils.compare("a", "a"));
    }

    // --- CONST / CONST_BYTE / CONST_SHORT ---

    @Test
    public void testConstOverloads() {
        assertTrue(ObjectUtils.CONST(true));
        assertEquals((byte) 127, ObjectUtils.CONST((byte) 127));
        assertEquals('a', ObjectUtils.CONST('a'));
        assertEquals(1.0d, ObjectUtils.CONST(1.0d), 0d);
        assertEquals(1.0f, ObjectUtils.CONST(1.0f), 0f);
        assertEquals(123, ObjectUtils.CONST(123));
        assertEquals(123L, ObjectUtils.CONST(123L));
        assertEquals((short) 123, ObjectUtils.CONST((short) 123));
        assertEquals("abc", ObjectUtils.CONST("abc"));
    }

    @Test
    public void testConstByteBoundaries() {
        assertEquals((byte) 127, ObjectUtils.CONST_BYTE(127));
        assertEquals((byte) -128, ObjectUtils.CONST_BYTE(-128));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.CONST_BYTE(128);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.CONST_BYTE(-129);
            }
        });
    }

    @Test
    public void testConstShortBoundaries() {
        assertEquals((short) 32767, ObjectUtils.CONST_SHORT(32767));
        assertEquals((short) -32768, ObjectUtils.CONST_SHORT(-32768));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.CONST_SHORT(32768);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.CONST_SHORT(-32769);
            }
        });
    }

    // --- defaultIfNull / getIfNull ---

    @Test
    public void testDefaultIfNull() {
        assertNull(ObjectUtils.defaultIfNull(null, null));
        assertEquals("", ObjectUtils.defaultIfNull(null, ""));
        assertEquals("zz", ObjectUtils.defaultIfNull(null, "zz"));
        assertEquals("abc", ObjectUtils.defaultIfNull("abc", "other"));
    }

    @Test
    public void testGetIfNullWithValue() {
        assertNull(ObjectUtils.getIfNull(null, (String) null));
        assertEquals("zz", ObjectUtils.getIfNull(null, "zz"));
        assertEquals("abc", ObjectUtils.getIfNull("abc", "other"));
    }

    @Test
    public void testGetIfNullWithSupplier() {
        assertEquals("zz", ObjectUtils.getIfNull(null, new Supplier<String>() {
            @Override
            public String get() {
                return "zz";
            }
        }));
        assertEquals("abc", ObjectUtils.getIfNull("abc", new Supplier<String>() {
            @Override
            public String get() {
                throw new IllegalStateException("should not be invoked");
            }
        }));
    }

    // --- equals / notEqual ---

    @Test
    public void testEquals() {
        assertTrue(ObjectUtils.equals(null, null));
        assertFalse(ObjectUtils.equals(null, ""));
        assertFalse(ObjectUtils.equals("", null));
        assertTrue(ObjectUtils.equals("", ""));
        assertFalse(ObjectUtils.equals(Boolean.TRUE, "true"));
    }

    @Test
    public void testNotEqual() {
        assertFalse(ObjectUtils.notEqual(null, null));
        assertTrue(ObjectUtils.notEqual(null, ""));
        assertTrue(ObjectUtils.notEqual("", null));
        assertFalse(ObjectUtils.notEqual("", ""));
    }

    // --- firstNonNull / getFirstNonNull / anyNotNull interplay ---

    @Test
    public void testFirstNonNull() {
        assertNull(ObjectUtils.firstNonNull((Object[]) null));
        assertNull(ObjectUtils.firstNonNull());
        assertNull(ObjectUtils.firstNonNull(null, null));
        assertEquals("zz", ObjectUtils.firstNonNull(null, "zz"));
        assertEquals("abc", ObjectUtils.firstNonNull("abc", "other"));
    }

    @Test
    public void testGetFirstNonNullLazyShortCircuits() {
        final List<String> calls = new ArrayList<String>();
        final Supplier<String> first = new Supplier<String>() {
            @Override
            public String get() {
                calls.add("first");
                return "value";
            }
        };
        final Supplier<String> second = new Supplier<String>() {
            @Override
            public String get() {
                calls.add("second");
                return "unused";
            }
        };
        final String result = ObjectUtils.getFirstNonNull(first, second);
        assertEquals("value", result);
        assertEquals(Collections.singletonList("first"), calls);
    }

    @Test
    public void testGetFirstNonNullAllNull() {
        assertNull(ObjectUtils.getFirstNonNull());
    }

    // --- getClass ---

    @Test
    public void testGetClass() {
        assertNull(ObjectUtils.getClass(null));
        assertEquals(String.class, ObjectUtils.getClass("abc"));
    }

    // --- hashCode / hashCodeHex / hashCodeMulti / identityHashCodeHex ---

    @Test
    public void testHashCode() {
        assertEquals(0, ObjectUtils.hashCode(null));
        assertEquals("abc".hashCode(), ObjectUtils.hashCode("abc"));
    }

    @Test
    public void testHashCodeHex() {
        assertEquals(Integer.toHexString("abc".hashCode()), ObjectUtils.hashCodeHex("abc"));
        assertEquals(Integer.toHexString(0), ObjectUtils.hashCodeHex(null));
    }

    @Test
    public void testHashCodeMulti() {
        assertEquals(1, ObjectUtils.hashCodeMulti());
        assertEquals(1, ObjectUtils.hashCodeMulti((Object[]) null));
        final Object a = "a";
        final Object b = "b";
        assertEquals((31 + a.hashCode()) * 31 + b.hashCode(), ObjectUtils.hashCodeMulti(a, b));
    }

    @Test
    public void testIdentityHashCodeHex() {
        final Object obj = new Object();
        assertEquals(Integer.toHexString(System.identityHashCode(obj)), ObjectUtils.identityHashCodeHex(obj));
    }

    // --- identityToString overloads ---

    @Test
    public void testIdentityToStringNull() {
        assertNull(ObjectUtils.identityToString(null));
    }

    @Test
    public void testIdentityToStringObject() {
        final Object obj = new Object();
        final String result = ObjectUtils.identityToString(obj);
        final String expected = obj.getClass().getName() + "@" + Integer.toHexString(System.identityHashCode(obj));
        assertEquals(expected, result);
    }

    @Test
    public void testIdentityToStringAppendable() throws IOException {
        final Object obj = "hello";
        final StringBuilder appendable = new StringBuilder();
        ObjectUtils.identityToString((Appendable) appendable, obj);
        final String expected = obj.getClass().getName() + "@" + Integer.toHexString(System.identityHashCode(obj));
        assertEquals(expected, appendable.toString());
    }

    @Test
    public void testIdentityToStringAppendableNullObjectThrows() {
        final StringBuilder appendable = new StringBuilder();
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws IOException {
                ObjectUtils.identityToString((Appendable) appendable, null);
            }
        });
    }

    @Test
    public void testIdentityToStringStringBuffer() {
        final Object obj = "hello";
        final StringBuffer buffer = new StringBuffer();
        ObjectUtils.identityToString(buffer, obj);
        final String expected = obj.getClass().getName() + "@" + Integer.toHexString(System.identityHashCode(obj));
        assertEquals(expected, buffer.toString());
    }

    @Test
    public void testIdentityToStringStringBufferNullObjectThrows() {
        final StringBuffer buffer = new StringBuffer();
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.identityToString(buffer, null);
            }
        });
    }

    @Test
    public void testIdentityToStringStringBuilder() {
        final Object obj = "hello";
        final StringBuilder builder = new StringBuilder();
        ObjectUtils.identityToString(builder, obj);
        final String expected = obj.getClass().getName() + "@" + Integer.toHexString(System.identityHashCode(obj));
        assertEquals(expected, builder.toString());
    }

    @Test
    public void testIdentityToStringStringBuilderNullObjectThrows() {
        final StringBuilder builder = new StringBuilder();
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.identityToString(builder, null);
            }
        });
    }

    // --- isArray ---

    @Test
    public void testIsArray() {
        assertFalse(ObjectUtils.isArray(null));
        assertFalse(ObjectUtils.isArray(""));
        assertFalse(ObjectUtils.isArray("ab"));
        assertTrue(ObjectUtils.isArray(new int[]{}));
        assertTrue(ObjectUtils.isArray(new int[]{1, 2, 3}));
        assertFalse(ObjectUtils.isArray(1234));
    }

    // --- isEmpty / isNotEmpty ---

    @Test
    public void testIsEmpty() {
        assertTrue(ObjectUtils.isEmpty(null));
        assertTrue(ObjectUtils.isEmpty(""));
        assertFalse(ObjectUtils.isEmpty("ab"));
        assertTrue(ObjectUtils.isEmpty(new int[]{}));
        assertFalse(ObjectUtils.isEmpty(new int[]{1, 2, 3}));
        assertFalse(ObjectUtils.isEmpty(1234));
        assertFalse(ObjectUtils.isEmpty(Optional.of("")));
        assertTrue(ObjectUtils.isEmpty(Optional.empty()));
        assertTrue(ObjectUtils.isEmpty(new ArrayList<Object>()));
        assertFalse(ObjectUtils.isEmpty(Collections.singletonList("a")));
        assertTrue(ObjectUtils.isEmpty(new HashMap<Object, Object>()));
        final Map<String, String> map = new HashMap<String, String>();
        map.put("k", "v");
        assertFalse(ObjectUtils.isEmpty(map));
    }

    @Test
    public void testIsNotEmpty() {
        assertFalse(ObjectUtils.isNotEmpty(null));
        assertFalse(ObjectUtils.isNotEmpty(""));
        assertTrue(ObjectUtils.isNotEmpty("ab"));
        assertFalse(ObjectUtils.isNotEmpty(new int[]{}));
        assertTrue(ObjectUtils.isNotEmpty(new int[]{1, 2, 3}));
        assertTrue(ObjectUtils.isNotEmpty(Optional.of("")));
        assertFalse(ObjectUtils.isNotEmpty(Optional.empty()));
    }

    // --- max / min ---

    @Test
    public void testMaxAllNull() {
        assertNull(ObjectUtils.max((String) null, (String) null));
        assertNull(ObjectUtils.max((String[]) null));
    }

    @Test
    public void testMax() {
        assertEquals("c", ObjectUtils.max("a", "c", "b"));
        assertEquals("c", ObjectUtils.max(null, "c", null));
        assertEquals("a", ObjectUtils.max("a"));
    }

    @Test
    public void testMinAllNull() {
        assertNull(ObjectUtils.min((String) null, (String) null));
        assertNull(ObjectUtils.min((String[]) null));
    }

    @Test
    public void testMin() {
        assertEquals("a", ObjectUtils.min("b", "a", "c"));
        assertEquals("a", ObjectUtils.min(null, "a", null));
        assertEquals("a", ObjectUtils.min("a"));
    }

    // --- median ---

    @Test
    public void testMedianOddCount() {
        assertEquals(Integer.valueOf(2), ObjectUtils.median(1, 2, 3));
    }

    @Test
    public void testMedianEvenCountReturnsLowerMiddle() {
        assertEquals(Integer.valueOf(2), ObjectUtils.median(1, 2, 3, 4));
    }

    @Test
    public void testMedianUnsortedInput() {
        assertEquals(Integer.valueOf(3), ObjectUtils.median(5, 1, 3, 4, 2));
    }

    @Test
    public void testMedianEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.median();
            }
        });
    }

    @Test
    public void testMedianNullElementThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.median("a", null, "b");
            }
        });
    }

    @Test
    public void testMedianWithComparator() {
        final java.util.Comparator<FixedComparable> reversed = new java.util.Comparator<FixedComparable>() {
            @Override
            public int compare(final FixedComparable o1, final FixedComparable o2) {
                return o2.n - o1.n;
            }
        };
        final FixedComparable result = ObjectUtils.median(reversed,
                new FixedComparable(1), new FixedComparable(2), new FixedComparable(3));
        assertEquals(2, result.n);
    }

    @Test
    public void testMedianNullComparatorThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.median((java.util.Comparator<String>) null, "a", "b");
            }
        });
    }

    // --- mode ---

    @Test
    public void testModeEmptyReturnsNull() {
        assertNull(ObjectUtils.mode());
        assertNull(ObjectUtils.mode((Object[]) null));
    }

    @Test
    public void testModeSingleWinner() {
        assertEquals("a", ObjectUtils.mode("a", "b", "a", "c", "a"));
    }

    @Test
    public void testModeTieReturnsNull() {
        assertNull(ObjectUtils.mode("a", "b"));
    }

    // --- requireNonEmpty ---

    @Test
    public void testRequireNonEmptyReturnsObject() {
        assertEquals("abc", ObjectUtils.requireNonEmpty("abc"));
    }

    @Test
    public void testRequireNonEmptyNullThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.requireNonEmpty(null);
            }
        });
    }

    @Test
    public void testRequireNonEmptyEmptyThrowsIae() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.requireNonEmpty("");
            }
        });
    }

    @Test
    public void testRequireNonEmptyWithMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() {
                        ObjectUtils.requireNonEmpty("", "myMessage");
                    }
                });
        assertEquals("myMessage", ex.getMessage());
        final NullPointerException npe = assertThrows(NullPointerException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() {
                        ObjectUtils.requireNonEmpty(null, "myOtherMessage");
                    }
                });
        assertEquals("myOtherMessage", npe.getMessage());
    }

    // --- toString overloads ---

    @Test
    public void testToStringObject() {
        assertEquals("", ObjectUtils.toString(null));
        assertEquals("", ObjectUtils.toString(""));
        assertEquals("bat", ObjectUtils.toString("bat"));
        assertEquals("true", ObjectUtils.toString(Boolean.TRUE));
    }

    @Test
    public void testToStringObjectWithNullStr() {
        assertNull(ObjectUtils.toString((Object) null, (String) null));
        assertEquals("null", ObjectUtils.toString(null, "null"));
        assertEquals("", ObjectUtils.toString("", "null"));
        assertEquals("bat", ObjectUtils.toString("bat", "null"));
    }

    @Test
    public void testToStringWithSupplierForNullObject() {
        assertEquals("bat", ObjectUtils.toString((Object) null, new Supplier<String>() {
            @Override
            public String get() {
                return "bat";
            }
        }));
        assertEquals("abc", ObjectUtils.toString("abc", new Supplier<String>() {
            @Override
            public String get() {
                throw new IllegalStateException("should not be invoked");
            }
        }));
    }

    @Test
    public void testToStringSupplierOfObjectOverload() {
        final Supplier<Object> supplier = new Supplier<Object>() {
            @Override
            public Object get() {
                return "value";
            }
        };
        assertEquals("value", ObjectUtils.toString(supplier, new Supplier<String>() {
            @Override
            public String get() {
                throw new IllegalStateException("should not be invoked");
            }
        }));
        assertEquals("fallback", ObjectUtils.toString((Supplier<Object>) null, new Supplier<String>() {
            @Override
            public String get() {
                return "fallback";
            }
        }));
    }

    // --- wait ---

    @Test
    public void testWaitNegativeDurationThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws InterruptedException {
                ObjectUtils.wait(new Object(), Duration.ofSeconds(-1));
            }
        });
    }

    @Test
    public void testWaitShortDurationReturnsAfterTimeout() throws InterruptedException {
        final Object monitor = new Object();
        final long start = System.nanoTime();
        synchronized (monitor) {
            ObjectUtils.wait(monitor, Duration.ofMillis(50));
        }
        final long elapsedMillis = (System.nanoTime() - start) / 1000000L;
        assertTrue(elapsedMillis >= 0);
    }

    // --- Null placeholder ---

    @Test
    public void testNullSingletonIsSerializable() {
        assertTrue(ObjectUtils.NULL instanceof Serializable);
        assertNotNull(ObjectUtils.NULL);
    }

    @Test
    public void testConstructorIsPublic() {
        assertNotNull(new ObjectUtils());
    }
}
