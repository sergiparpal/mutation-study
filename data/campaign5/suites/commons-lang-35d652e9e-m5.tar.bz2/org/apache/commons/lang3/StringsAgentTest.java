/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link Strings}.
 */
public class StringsAgentTest {

    // --- builder() ---

    @Test
    public void testBuilderDefaults() {
        final Strings s = Strings.builder().get();
        assertTrue(s.isCaseSensitive());
        assertFalse(s.equals("A", "a"));
    }

    @Test
    public void testBuilderCaseSensitive() {
        final Strings s = Strings.builder().setIgnoreCase(false).get();
        assertTrue(s.isCaseSensitive());
        assertFalse(s.equals("A", "a"));
    }

    @Test
    public void testBuilderNullIsLessTrue() {
        final Strings s = Strings.builder().setNullIsLess(true).get();
        assertTrue(s.compare(null, "a") < 0);
        assertTrue(s.compare("a", null) > 0);
    }

    @Test
    public void testBuilderNullIsLessFalse() {
        final Strings s = Strings.builder().setNullIsLess(false).get();
        assertTrue(s.compare(null, "a") > 0);
        assertTrue(s.compare("a", null) < 0);
    }

    // --- isCaseSensitive() ---

    @Test
    public void testIsCaseSensitive() {
        assertTrue(Strings.CS.isCaseSensitive());
        assertFalse(Strings.CI.isCaseSensitive());
    }

    // --- compare(String, String) ---

    @Test
    public void testCompareCsBothNull() {
        assertEquals(0, Strings.CS.compare(null, null));
    }

    @Test
    public void testCompareCsNullLessThanNonNull() {
        assertTrue(Strings.CS.compare(null, "a") < 0);
        assertTrue(Strings.CS.compare("a", null) > 0);
    }

    @Test
    public void testCompareCsEqual() {
        assertEquals(0, Strings.CS.compare("abc", "abc"));
    }

    @Test
    public void testCompareCsCaseSensitive() {
        assertTrue(Strings.CS.compare("a", "B") > 0);
    }

    @Test
    public void testCompareCiCaseInsensitive() {
        assertEquals(0, Strings.CI.compare("abc", "ABC"));
        assertTrue(Strings.CI.compare("a", "B") < 0);
    }

    // --- contains(CharSequence, CharSequence) ---

    @Test
    public void testContainsCsNullArgs() {
        assertFalse(Strings.CS.contains(null, "a"));
        assertFalse(Strings.CS.contains("a", null));
    }

    @Test
    public void testContainsCsEmptyNeedle() {
        assertTrue(Strings.CS.contains("abc", ""));
        assertTrue(Strings.CS.contains("", ""));
    }

    @Test
    public void testContainsCsFoundAndNotFound() {
        assertTrue(Strings.CS.contains("abc", "a"));
        assertFalse(Strings.CS.contains("abc", "z"));
        assertFalse(Strings.CS.contains("abc", "A"));
    }

    @Test
    public void testContainsCiCaseInsensitive() {
        assertTrue(Strings.CI.contains("abc", "A"));
        assertFalse(Strings.CI.contains("abc", "Z"));
        assertFalse(Strings.CI.contains(null, "a"));
        assertFalse(Strings.CI.contains("a", null));
    }

    // --- containsAny(CharSequence, CharSequence...) ---

    @Test
    public void testContainsAnyNullOrEmpty() {
        assertFalse(Strings.CS.containsAny(null, "a"));
        assertFalse(Strings.CS.containsAny("", "a"));
        assertFalse(Strings.CS.containsAny("abc", (CharSequence[]) null));
        assertFalse(Strings.CS.containsAny("abc"));
    }

    @Test
    public void testContainsAnyMatch() {
        assertTrue(Strings.CS.containsAny("abcd", "ab", null));
        assertTrue(Strings.CS.containsAny("abc", "d", "abc"));
        assertFalse(Strings.CS.containsAny("abc", "d", "e"));
    }

    @Test
    public void testContainsAnyCaseInsensitive() {
        assertTrue(Strings.CI.containsAny("ABC", "d", "abc"));
    }

    // --- endsWith(CharSequence, CharSequence) ---

    @Test
    public void testEndsWithBothNull() {
        assertTrue(Strings.CS.endsWith(null, null));
    }

    @Test
    public void testEndsWithOneNull() {
        assertFalse(Strings.CS.endsWith(null, "def"));
        assertFalse(Strings.CS.endsWith("abcdef", null));
    }

    @Test
    public void testEndsWithSuffixLongerThanString() {
        assertFalse(Strings.CS.endsWith("ab", "abc"));
    }

    @Test
    public void testEndsWithCaseSensitive() {
        assertTrue(Strings.CS.endsWith("abcdef", "def"));
        assertFalse(Strings.CS.endsWith("ABCDEF", "def"));
        assertTrue(Strings.CS.endsWith("ABCDEF", ""));
    }

    @Test
    public void testEndsWithCaseInsensitive() {
        assertTrue(Strings.CI.endsWith("ABCDEF", "def"));
    }

    // --- endsWithAny(CharSequence, CharSequence...) ---

    @Test
    public void testEndsWithAnyNullOrEmpty() {
        assertFalse(Strings.CS.endsWithAny(null, (CharSequence) null));
        assertFalse(Strings.CS.endsWithAny(null, "abc"));
        assertFalse(Strings.CS.endsWithAny("abcxyz", (CharSequence[]) null));
    }

    @Test
    public void testEndsWithAnyMatch() {
        assertTrue(Strings.CS.endsWithAny("abcxyz", ""));
        assertTrue(Strings.CS.endsWithAny("abcxyz", "xyz"));
        assertTrue(Strings.CS.endsWithAny("abcxyz", null, "xyz", "abc"));
        assertTrue(Strings.CS.endsWithAny("abcXYZ", "def", "XYZ"));
        assertFalse(Strings.CS.endsWithAny("abcXYZ", "def", "xyz"));
    }

    // --- equals(CharSequence, CharSequence) ---

    @Test
    public void testEqualsCsCharSequence() {
        final StringBuilder sb1 = new StringBuilder("abc");
        final StringBuilder sb2 = new StringBuilder("abc");
        assertTrue(Strings.CS.equals((CharSequence) sb1, (CharSequence) sb2));
        assertFalse(Strings.CS.equals((CharSequence) new StringBuilder("abc"), (CharSequence) new StringBuilder("ABC")));
    }

    @Test
    public void testEqualsCsCharSequenceSameRef() {
        final CharSequence cs = "abc";
        assertTrue(Strings.CS.equals(cs, cs));
    }

    @Test
    public void testEqualsCsCharSequenceNulls() {
        assertTrue(Strings.CS.equals((CharSequence) null, (CharSequence) null));
        assertFalse(Strings.CS.equals((CharSequence) null, (CharSequence) "a"));
        assertFalse(Strings.CS.equals((CharSequence) "a", (CharSequence) null));
    }

    @Test
    public void testEqualsCsCharSequenceDifferentLength() {
        assertFalse(Strings.CS.equals((CharSequence) new StringBuilder("ab"), (CharSequence) new StringBuilder("abc")));
    }

    @Test
    public void testEqualsCiCharSequence() {
        assertTrue(Strings.CI.equals((CharSequence) new StringBuilder("abc"), (CharSequence) new StringBuilder("ABC")));
    }

    // --- equals(String, String) ---

    @Test
    public void testEqualsCsString() {
        assertTrue(Strings.CS.equals((String) null, (String) null));
        assertFalse(Strings.CS.equals((String) null, "abc"));
        assertFalse(Strings.CS.equals("abc", (String) null));
        assertTrue(Strings.CS.equals("abc", "abc"));
        assertFalse(Strings.CS.equals("abc", "ABC"));
    }

    @Test
    public void testEqualsCiString() {
        assertTrue(Strings.CI.equals("abc", "ABC"));
        assertTrue(Strings.CI.equals((String) null, (String) null));
    }

    // --- equalsAny(CharSequence, CharSequence...) ---

    @Test
    public void testEqualsAnyNullSearchStrings() {
        assertFalse(Strings.CS.equalsAny(null, (CharSequence[]) null));
    }

    @Test
    public void testEqualsAnyBothNullEntries() {
        assertTrue(Strings.CS.equalsAny(null, null, null));
    }

    @Test
    public void testEqualsAnyMatchAndNoMatch() {
        assertFalse(Strings.CS.equalsAny(null, "abc", "def"));
        assertFalse(Strings.CS.equalsAny("abc", null, "def"));
        assertTrue(Strings.CS.equalsAny("abc", "abc", "def"));
        assertFalse(Strings.CS.equalsAny("abc", "ABC", "DEF"));
        assertTrue(Strings.CI.equalsAny("abc", "ABC", "DEF"));
    }

    // --- indexOf(CharSequence, CharSequence) ---

    @Test
    public void testIndexOfTwoArgNulls() {
        assertEquals(-1, Strings.CS.indexOf(null, "a"));
        assertEquals(-1, Strings.CS.indexOf("a", null));
    }

    @Test
    public void testIndexOfTwoArgFound() {
        assertEquals(0, Strings.CS.indexOf("", ""));
        assertEquals(1, Strings.CS.indexOf("aabaabaa", "ab"));
    }

    // --- indexOf(CharSequence, CharSequence, int) ---

    @Test
    public void testIndexOfThreeArgNulls() {
        assertEquals(-1, Strings.CS.indexOf(null, "a", 0));
        assertEquals(-1, Strings.CS.indexOf("a", null, 0));
    }

    @Test
    public void testIndexOfThreeArgCaseSensitive() {
        assertEquals(0, Strings.CS.indexOf("aabaabaa", "a", 0));
        assertEquals(5, Strings.CS.indexOf("aabaabaa", "b", 3));
        assertEquals(-1, Strings.CS.indexOf("aabaabaa", "b", 9));
        assertEquals(2, Strings.CS.indexOf("aabaabaa", "b", -1));
        assertEquals(2, Strings.CS.indexOf("aabaabaa", "", 2));
        assertEquals(3, Strings.CS.indexOf("abc", "", 9));
    }

    @Test
    public void testIndexOfThreeArgCaseInsensitive() {
        assertEquals(0, Strings.CI.indexOf("aabaabaa", "A", 0));
        assertEquals(5, Strings.CI.indexOf("aabaabaa", "B", 3));
        assertEquals(-1, Strings.CI.indexOf("aabaabaa", "B", 9));
        assertEquals(2, Strings.CI.indexOf("aabaabaa", "B", -1));
        assertEquals(2, Strings.CI.indexOf("aabaabaa", "", 2));
        assertEquals(-1, Strings.CI.indexOf("abc", "", 9));
        assertEquals(0, Strings.CI.indexOf("", "", 0));
    }

    // --- lastIndexOf(CharSequence, CharSequence) ---

    @Test
    public void testLastIndexOfTwoArgNull() {
        assertEquals(-1, Strings.CS.lastIndexOf(null, "a"));
    }

    @Test
    public void testLastIndexOfTwoArgFound() {
        assertEquals(0, Strings.CS.lastIndexOf("", ""));
        assertEquals(7, Strings.CS.lastIndexOf("aabaabaa", "a"));
        assertEquals(5, Strings.CS.lastIndexOf("aabaabaa", "b"));
        assertEquals(4, Strings.CS.lastIndexOf("aabaabaa", "ab"));
        assertEquals(8, Strings.CS.lastIndexOf("aabaabaa", ""));
    }

    // --- lastIndexOf(CharSequence, CharSequence, int) ---

    @Test
    public void testLastIndexOfThreeArgNulls() {
        assertEquals(-1, Strings.CS.lastIndexOf(null, "a", 1));
        assertEquals(-1, Strings.CS.lastIndexOf("a", null, 1));
    }

    @Test
    public void testLastIndexOfThreeArgCaseSensitive() {
        assertEquals(7, Strings.CS.lastIndexOf("aabaabaa", "a", 8));
        assertEquals(5, Strings.CS.lastIndexOf("aabaabaa", "b", 9));
        assertEquals(-1, Strings.CS.lastIndexOf("aabaabaa", "b", -1));
        assertEquals(0, Strings.CS.lastIndexOf("aabaabaa", "a", 0));
        assertEquals(-1, Strings.CS.lastIndexOf("aabaabaa", "b", 0));
        assertEquals(2, Strings.CS.lastIndexOf("aabaabaa", "b", 2));
        assertEquals(2, Strings.CS.lastIndexOf("aabaabaa", "ba", 2));
    }

    @Test
    public void testLastIndexOfThreeArgCaseInsensitive() {
        assertEquals(7, Strings.CI.lastIndexOf("aabaabaa", "A", 8));
        assertEquals(5, Strings.CI.lastIndexOf("aabaabaa", "B", 9));
        assertEquals(-1, Strings.CI.lastIndexOf("aabaabaa", "B", -1));
        assertEquals(0, Strings.CI.lastIndexOf("aabaabaa", "A", 0));
        assertEquals(-1, Strings.CI.lastIndexOf("aabaabaa", "B", 0));
    }

    // --- appendIfMissing ---

    @Test
    public void testAppendIfMissingNulls() {
        assertNull(Strings.CS.appendIfMissing(null, null));
        assertEquals("abc", Strings.CS.appendIfMissing("abc", null));
    }

    @Test
    public void testAppendIfMissingNoExtras() {
        assertEquals("xyz", Strings.CS.appendIfMissing("", "xyz"));
        assertEquals("abcxyz", Strings.CS.appendIfMissing("abc", "xyz"));
        assertEquals("abcxyz", Strings.CS.appendIfMissing("abcxyz", "xyz"));
        assertEquals("abcXYZxyz", Strings.CS.appendIfMissing("abcXYZ", "xyz"));
    }

    @Test
    public void testAppendIfMissingCaseInsensitive() {
        assertEquals("abcXYZ", Strings.CI.appendIfMissing("abcXYZ", "xyz"));
    }

    @Test
    public void testAppendIfMissingWithExtras() {
        assertEquals("abc", Strings.CS.appendIfMissing("abc", "xyz", ""));
        assertEquals("abcxyz", Strings.CS.appendIfMissing("abc", "xyz", "mno"));
        assertEquals("abcmno", Strings.CS.appendIfMissing("abcmno", "xyz", "mno"));
        assertEquals("abcXYZxyz", Strings.CS.appendIfMissing("abcXYZ", "xyz", "mno"));
        assertEquals("abcxyz", Strings.CS.appendIfMissing("abc", "xyz", new CharSequence[] {null}));
    }

    // --- prependIfMissing ---

    @Test
    public void testPrependIfMissingNulls() {
        assertNull(Strings.CS.prependIfMissing(null, null));
        assertEquals("abc", Strings.CS.prependIfMissing("abc", null));
    }

    @Test
    public void testPrependIfMissingBasic() {
        assertEquals("xyz", Strings.CS.prependIfMissing("", "xyz"));
        assertEquals("xyzabc", Strings.CS.prependIfMissing("abc", "xyz"));
        assertEquals("xyzabc", Strings.CS.prependIfMissing("xyzabc", "xyz"));
        assertEquals("xyzXYZabc", Strings.CS.prependIfMissing("XYZabc", "xyz"));
    }

    @Test
    public void testPrependIfMissingCaseInsensitive() {
        assertEquals("XYZabc", Strings.CI.prependIfMissing("XYZabc", "xyz"));
    }

    @Test
    public void testPrependIfMissingWithExtras() {
        assertEquals("abc", Strings.CS.prependIfMissing("abc", "xyz", ""));
        assertEquals("xyzabc", Strings.CS.prependIfMissing("abc", "xyz", "mno"));
        assertEquals("mnoabc", Strings.CS.prependIfMissing("mnoabc", "xyz", "mno"));
    }

    // --- remove ---

    @Test
    public void testRemoveNullAndEmpty() {
        assertNull(Strings.CS.remove(null, "x"));
        assertEquals("", Strings.CS.remove("", "x"));
        assertEquals("abc", Strings.CS.remove("abc", null));
        assertEquals("abc", Strings.CS.remove("abc", ""));
    }

    @Test
    public void testRemoveMatch() {
        assertEquals("qd", Strings.CS.remove("queued", "ue"));
        assertEquals("queued", Strings.CS.remove("queued", "zz"));
        assertEquals("qd", Strings.CI.remove("quEUed", "UE"));
    }

    // --- removeEnd ---

    @Test
    public void testRemoveEndNullAndEmpty() {
        assertNull(Strings.CS.removeEnd(null, "x"));
        assertEquals("", Strings.CS.removeEnd("", "x"));
        assertEquals("abc", Strings.CS.removeEnd("abc", null));
    }

    @Test
    public void testRemoveEndMatch() {
        assertEquals("www.domain.com", Strings.CS.removeEnd("www.domain.com", ".com."));
        assertEquals("www.domain", Strings.CS.removeEnd("www.domain.com", ".com"));
        assertEquals("www.domain.com", Strings.CS.removeEnd("www.domain.com", "domain"));
        assertEquals("abc", Strings.CS.removeEnd("abc", ""));
    }

    @Test
    public void testRemoveEndCaseInsensitive() {
        assertEquals("www.domain", Strings.CI.removeEnd("www.domain.com", ".COM"));
        assertEquals("www.domain", Strings.CI.removeEnd("www.domain.COM", ".com"));
    }

    // --- removeStart ---

    @Test
    public void testRemoveStartNullAndEmpty() {
        assertNull(Strings.CS.removeStart(null, "x"));
        assertEquals("", Strings.CS.removeStart("", "x"));
        assertEquals("abc", Strings.CS.removeStart("abc", null));
    }

    @Test
    public void testRemoveStartMatch() {
        assertEquals("domain.com", Strings.CS.removeStart("www.domain.com", "www."));
        assertEquals("domain.com", Strings.CS.removeStart("domain.com", "www."));
        assertEquals("www.domain.com", Strings.CS.removeStart("www.domain.com", "domain"));
        assertEquals("abc", Strings.CS.removeStart("abc", ""));
    }

    @Test
    public void testRemoveStartCaseInsensitive() {
        assertEquals("domain.com", Strings.CI.removeStart("www.domain.com", "WWW."));
    }

    // --- replace(text, search, replacement) ---

    @Test
    public void testReplaceThreeArgNulls() {
        assertNull(Strings.CS.replace(null, "a", "b"));
        assertEquals("", Strings.CS.replace("", "a", "b"));
        assertEquals("any", Strings.CS.replace("any", null, "b"));
        assertEquals("any", Strings.CS.replace("any", "a", null));
        assertEquals("any", Strings.CS.replace("any", "", "b"));
    }

    @Test
    public void testReplaceThreeArgBasic() {
        assertEquals("aba", Strings.CS.replace("aba", "a", null));
        assertEquals("b", Strings.CS.replace("aba", "a", ""));
        assertEquals("zbz", Strings.CS.replace("aba", "a", "z"));
    }

    @Test
    public void testReplaceThreeArgCaseInsensitive() {
        assertEquals("b", Strings.CI.replace("abA", "A", ""));
        assertEquals("zbz", Strings.CI.replace("aba", "A", "z"));
    }

    // --- replace(text, search, replacement, max) ---

    @Test
    public void testReplaceFourArgMaxZero() {
        assertEquals("any", Strings.CS.replace("any", "a", "b", 0));
    }

    @Test
    public void testReplaceFourArgMaxLimits() {
        assertEquals("abaa", Strings.CS.replace("abaa", "a", null, -1));
        assertEquals("b", Strings.CS.replace("abaa", "a", "", -1));
        assertEquals("zbaa", Strings.CS.replace("abaa", "a", "z", 1));
        assertEquals("zbza", Strings.CS.replace("abaa", "a", "z", 2));
        assertEquals("zbzz", Strings.CS.replace("abaa", "a", "z", -1));
    }

    @Test
    public void testReplaceFourArgCaseInsensitive() {
        assertEquals("zbaa", Strings.CI.replace("abaa", "A", "z", 1));
        assertEquals("zbza", Strings.CI.replace("abAa", "a", "z", 2));
        assertEquals("zbzz", Strings.CI.replace("abAa", "a", "z", -1));
    }

    @Test
    public void testReplaceFourArgGrowsBeyondOriginalLength() {
        final String result = Strings.CS.replace("aaaa", "a", "bb", -1);
        assertEquals("bbbbbbbb", result);
    }

    // --- replaceOnce ---

    @Test
    public void testReplaceOnceNullsAndEmpty() {
        assertNull(Strings.CS.replaceOnce(null, "a", "b"));
        assertEquals("", Strings.CS.replaceOnce("", "a", "b"));
        assertEquals("any", Strings.CS.replaceOnce("any", null, "b"));
    }

    @Test
    public void testReplaceOnceBasic() {
        assertEquals("ba", Strings.CS.replaceOnce("aba", "a", ""));
        assertEquals("zba", Strings.CS.replaceOnce("aba", "a", "z"));
    }

    @Test
    public void testReplaceOnceCaseInsensitive() {
        assertEquals("Foofoo", Strings.CI.replaceOnce("FoOFoofoo", "foo", ""));
    }

    // --- startsWith ---

    @Test
    public void testStartsWithBothNull() {
        assertTrue(Strings.CS.startsWith(null, null));
    }

    @Test
    public void testStartsWithOneNull() {
        assertFalse(Strings.CS.startsWith(null, "abc"));
        assertFalse(Strings.CS.startsWith("abcdef", null));
    }

    @Test
    public void testStartsWithPrefixLongerThanString() {
        assertFalse(Strings.CS.startsWith("ab", "abc"));
    }

    @Test
    public void testStartsWithCaseSensitiveAndInsensitive() {
        assertTrue(Strings.CS.startsWith("abcdef", "abc"));
        assertFalse(Strings.CS.startsWith("ABCDEF", "abc"));
        assertTrue(Strings.CI.startsWith("ABCDEF", "abc"));
    }

    // --- startsWithAny ---

    @Test
    public void testStartsWithAnyNullOrEmpty() {
        assertFalse(Strings.CS.startsWithAny(null, (CharSequence[]) null));
        assertFalse(Strings.CS.startsWithAny(null, "abc"));
        assertFalse(Strings.CS.startsWithAny("abcxyz", (CharSequence[]) null));
    }

    @Test
    public void testStartsWithAnyMatch() {
        assertTrue(Strings.CS.startsWithAny("abcxyz", ""));
        assertTrue(Strings.CS.startsWithAny("abcxyz", "abc"));
        assertTrue(Strings.CS.startsWithAny("abcxyz", (CharSequence) null, "xyz", "abc"));
        assertFalse(Strings.CS.startsWithAny("abcxyz", null, "xyz", "ABCX"));
        assertTrue(Strings.CI.startsWithAny("abcxyz", null, "xyz", "ABCX"));
    }

    // --- initialCapacity (package-private static helper) ---

    @Test
    public void testInitialCapacityNoGrowth() {
        assertEquals(10, Strings.initialCapacity(10, 5, 2, -1));
    }

    @Test
    public void testInitialCapacityUnboundedMax() {
        assertEquals(10 + 3 * 16, Strings.initialCapacity(10, 1, 4, -1));
    }

    @Test
    public void testInitialCapacityBoundedMax() {
        assertEquals(10 + 3 * 5, Strings.initialCapacity(10, 1, 4, 5));
    }

    @Test
    public void testInitialCapacityClampedToMax64Multiplier() {
        assertEquals(10 + 3 * 64, Strings.initialCapacity(10, 1, 4, 1000));
    }

    @Test
    public void testInitialCapacityClampedToSafeMax() {
        final int result = Strings.initialCapacity(Integer.MAX_VALUE - 10, 0, 1000, -1);
        assertEquals(ArrayUtils.SAFE_MAX_ARRAY_LENGTH, result);
    }

    // --- Builder chaining returns same instance ---

    @Test
    public void testBuilderChainingReturnsSameBuilder() {
        final Strings.Builder builder = Strings.builder();
        assertSame(builder, builder.setIgnoreCase(true));
        assertSame(builder, builder.setNullIsLess(true));
        assertNotNull(builder.get());
    }

    // --- Singletons ---

    @Test
    public void testSingletonsAreDistinctInstances() {
        assertNotNull(Strings.CS);
        assertNotNull(Strings.CI);
        assertTrue(Strings.CS != Strings.CI);
    }
}
