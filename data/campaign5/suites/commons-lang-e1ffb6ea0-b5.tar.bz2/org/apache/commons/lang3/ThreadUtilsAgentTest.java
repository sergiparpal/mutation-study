/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Duration;
import java.util.Collection;
import java.util.Iterator;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.function.Predicate;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link ThreadUtils}.
 */
class ThreadUtilsAgentTest {

    /**
     * A thread which signals that it has started and then blocks until explicitly released.
     */
    private static final class PausingThread extends Thread {

        private final CountDownLatch startedLatch = new CountDownLatch(1);
        private final CountDownLatch releaseLatch = new CountDownLatch(1);

        PausingThread(final ThreadGroup group, final String name) {
            super(group, name);
        }

        PausingThread(final String name) {
            super(name);
        }

        void awaitStarted() throws InterruptedException {
            assertTrue(startedLatch.await(5, TimeUnit.SECONDS), "thread did not start in time");
        }

        void finishAndJoin() throws InterruptedException {
            releaseLatch.countDown();
            join(5000);
        }

        @Override
        public void run() {
            startedLatch.countDown();
            try {
                releaseLatch.await();
            } catch (final InterruptedException ignore) {
                // ignore
            }
        }
    }

    private static final class SameThreadPredicate implements Predicate<Thread> {

        private final Thread target;

        SameThreadPredicate(final Thread target) {
            this.target = target;
        }

        @Override
        public boolean test(final Thread thread) {
            return thread == target;
        }
    }

    // --- findThreadById(long) ---

    @Test
    void testFindThreadByIdZeroOrNegativeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable0() {
            @Override
            void run() {
                ThreadUtils.findThreadById(0);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable0() {
            @Override
            void run() {
                ThreadUtils.findThreadById(-1);
            }
        });
    }

    @Test
    void testFindThreadByIdNotFound() {
        assertNull(ThreadUtils.findThreadById(Long.MAX_VALUE));
    }

    @Test
    void testFindThreadByIdFound() throws InterruptedException {
        final PausingThread thread = new PausingThread("ThreadUtilsAgentTest-findById-" + System.nanoTime());
        thread.start();
        try {
            thread.awaitStarted();
            final Thread found = ThreadUtils.findThreadById(thread.getId());
            assertSame(thread, found);
        } finally {
            thread.finishAndJoin();
        }
        assertFalse(thread.isAlive());
    }

    // --- findThreadById(long, String) ---

    @Test
    void testFindThreadByIdWithGroupNameNullThrows() {
        assertThrows(NullPointerException.class, new Executable0() {
            @Override
            void run() {
                ThreadUtils.findThreadById(1, (String) null);
            }
        });
    }

    @Test
    void testFindThreadByIdWithGroupNameMatchAndMismatch() throws InterruptedException {
        final PausingThread thread = new PausingThread("ThreadUtilsAgentTest-byGroupName-" + System.nanoTime());
        thread.start();
        try {
            thread.awaitStarted();
            final String actualGroupName = thread.getThreadGroup().getName();
            assertSame(thread, ThreadUtils.findThreadById(thread.getId(), actualGroupName));
            assertNull(ThreadUtils.findThreadById(thread.getId(), actualGroupName + "-does-not-exist"));
        } finally {
            thread.finishAndJoin();
        }
    }

    // --- findThreadById(long, ThreadGroup) ---

    @Test
    void testFindThreadByIdWithThreadGroupNullThrows() {
        assertThrows(NullPointerException.class, new Executable0() {
            @Override
            void run() {
                ThreadUtils.findThreadById(1, (ThreadGroup) null);
            }
        });
    }

    @Test
    void testFindThreadByIdWithThreadGroupMatchAndMismatch() throws InterruptedException {
        final ThreadGroup ownGroup = new ThreadGroup("ThreadUtilsAgentTest-ownGroup-" + System.nanoTime());
        final ThreadGroup otherGroup = new ThreadGroup("ThreadUtilsAgentTest-otherGroup-" + System.nanoTime());
        final PausingThread thread = new PausingThread(ownGroup, "ThreadUtilsAgentTest-byGroup-" + System.nanoTime());
        thread.start();
        try {
            thread.awaitStarted();
            assertSame(thread, ThreadUtils.findThreadById(thread.getId(), ownGroup));
            assertNull(ThreadUtils.findThreadById(thread.getId(), otherGroup));
        } finally {
            thread.finishAndJoin();
        }
        ownGroup.destroy();
        otherGroup.destroy();
    }

    // --- findThreadGroups ---

    @Test
    void testFindThreadGroupsNullPredicateThrows() {
        assertThrows(NullPointerException.class, new Executable0() {
            @Override
            void run() {
                ThreadUtils.findThreadGroups((Predicate<ThreadGroup>) null);
            }
        });
    }

    @Test
    void testFindThreadGroupsNullThreadGroupThrows() {
        assertThrows(NullPointerException.class, new Executable0() {
            @Override
            void run() {
                ThreadUtils.findThreadGroups(null, true, new AlwaysTrueThreadGroupPredicate());
            }
        });
    }

    @Test
    void testFindThreadGroupsThreeArgNullPredicateThrows() {
        final ThreadGroup group = new ThreadGroup("ThreadUtilsAgentTest-npeGroup-" + System.nanoTime());
        try {
            assertThrows(NullPointerException.class, new Executable0() {
                @Override
                void run() {
                    ThreadUtils.findThreadGroups(group, true, (Predicate<ThreadGroup>) null);
                }
            });
        } finally {
            group.destroy();
        }
    }

    @Test
    void testFindThreadGroupsByNameFoundAndNotFound() {
        final String name = "ThreadUtilsAgentTest-group-" + System.nanoTime();
        final ThreadGroup group = new ThreadGroup(name);
        try {
            final Collection<ThreadGroup> found = ThreadUtils.findThreadGroupsByName(name);
            assertEquals(1, found.size());
            assertSame(group, found.iterator().next());

            final Collection<ThreadGroup> notFound = ThreadUtils.findThreadGroupsByName(name + "-missing");
            assertTrue(notFound.isEmpty());
        } finally {
            group.destroy();
        }
    }

    @Test
    void testFindThreadGroupsResultIsUnmodifiable() {
        final Collection<ThreadGroup> groups = ThreadUtils.getAllThreadGroups();
        assertThrows(UnsupportedOperationException.class, new Executable0() {
            @Override
            void run() {
                groups.add(null);
            }
        });
    }

    // --- findThreads ---

    @Test
    void testFindThreadsNullPredicateThrows() {
        assertThrows(NullPointerException.class, new Executable0() {
            @Override
            void run() {
                ThreadUtils.findThreads((Predicate<Thread>) null);
            }
        });
    }

    @Test
    void testFindThreadsNullThreadGroupThrows() {
        assertThrows(NullPointerException.class, new Executable0() {
            @Override
            void run() {
                ThreadUtils.findThreads(null, true, new SameThreadPredicate(Thread.currentThread()));
            }
        });
    }

    @Test
    void testFindThreadsFindsCurrentThread() {
        final Collection<Thread> found = ThreadUtils.findThreads(new SameThreadPredicate(Thread.currentThread()));
        assertEquals(1, found.size());
        assertSame(Thread.currentThread(), found.iterator().next());
    }

    @Test
    void testFindThreadsResultIsUnmodifiable() {
        final Collection<Thread> threads = ThreadUtils.getAllThreads();
        assertThrows(UnsupportedOperationException.class, new Executable0() {
            @Override
            void run() {
                threads.add(null);
            }
        });
    }

    // --- findThreadsByName ---

    @Test
    void testFindThreadsByNameFoundAndNotFound() throws InterruptedException {
        final String name = "ThreadUtilsAgentTest-byName-" + System.nanoTime();
        final PausingThread thread = new PausingThread(name);
        thread.start();
        try {
            thread.awaitStarted();
            final Collection<Thread> found = ThreadUtils.findThreadsByName(name);
            assertEquals(1, found.size());
            assertSame(thread, found.iterator().next());

            final Collection<Thread> notFound = ThreadUtils.findThreadsByName(name + "-missing");
            assertTrue(notFound.isEmpty());
        } finally {
            thread.finishAndJoin();
        }
    }

    @Test
    void testFindThreadsByNameWithGroupNameNullThreadNameThrows() {
        assertThrows(NullPointerException.class, new Executable0() {
            @Override
            void run() {
                ThreadUtils.findThreadsByName(null, "someGroup");
            }
        });
    }

    @Test
    void testFindThreadsByNameWithGroupNameNullGroupNameThrows() {
        assertThrows(NullPointerException.class, new Executable0() {
            @Override
            void run() {
                ThreadUtils.findThreadsByName("someThread", (String) null);
            }
        });
    }

    @Test
    void testFindThreadsByNameWithGroupNameMatch() throws InterruptedException {
        final String groupName = "ThreadUtilsAgentTest-byNameGroup-" + System.nanoTime();
        final String threadName = "ThreadUtilsAgentTest-byNameThread-" + System.nanoTime();
        final ThreadGroup group = new ThreadGroup(groupName);
        final PausingThread thread = new PausingThread(group, threadName);
        thread.start();
        try {
            thread.awaitStarted();
            final Collection<Thread> found = ThreadUtils.findThreadsByName(threadName, groupName);
            assertEquals(1, found.size());
            assertSame(thread, found.iterator().next());

            final Collection<Thread> notFound = ThreadUtils.findThreadsByName(threadName, groupName + "-missing");
            assertTrue(notFound.isEmpty());
        } finally {
            thread.finishAndJoin();
            group.destroy();
        }
    }

    @Test
    void testFindThreadsByNameWithThreadGroupNullThrows() {
        assertThrows(NullPointerException.class, new Executable0() {
            @Override
            void run() {
                ThreadUtils.findThreadsByName("someThread", (ThreadGroup) null);
            }
        });
    }

    @Test
    void testFindThreadsByNameWithThreadGroupMatchAndMismatch() throws InterruptedException {
        final ThreadGroup group = new ThreadGroup("ThreadUtilsAgentTest-byGroupObj-" + System.nanoTime());
        final ThreadGroup otherGroup = new ThreadGroup("ThreadUtilsAgentTest-byGroupObjOther-" + System.nanoTime());
        final String threadName = "ThreadUtilsAgentTest-byGroupObjThread-" + System.nanoTime();
        final PausingThread thread = new PausingThread(group, threadName);
        thread.start();
        try {
            thread.awaitStarted();
            final Collection<Thread> found = ThreadUtils.findThreadsByName(threadName, group);
            assertEquals(1, found.size());
            assertSame(thread, found.iterator().next());

            final Collection<Thread> notFound = ThreadUtils.findThreadsByName(threadName, otherGroup);
            assertTrue(notFound.isEmpty());
        } finally {
            thread.finishAndJoin();
            group.destroy();
            otherGroup.destroy();
        }
    }

    // --- getAllThreadGroups / getAllThreads / getSystemThreadGroup ---

    @Test
    void testGetAllThreadGroupsContainsCreatedGroup() {
        final String name = "ThreadUtilsAgentTest-allGroups-" + System.nanoTime();
        final ThreadGroup group = new ThreadGroup(name);
        try {
            boolean contained = false;
            final Iterator<ThreadGroup> it = ThreadUtils.getAllThreadGroups().iterator();
            while (it.hasNext()) {
                if (it.next() == group) {
                    contained = true;
                }
            }
            assertTrue(contained);
        } finally {
            group.destroy();
        }
    }

    @Test
    void testGetAllThreadsContainsCurrentThread() {
        boolean contained = false;
        final Iterator<Thread> it = ThreadUtils.getAllThreads().iterator();
        while (it.hasNext()) {
            if (it.next() == Thread.currentThread()) {
                contained = true;
            }
        }
        assertTrue(contained);
    }

    @Test
    void testGetSystemThreadGroupHasNoParent() {
        final ThreadGroup systemGroup = ThreadUtils.getSystemThreadGroup();
        assertNotNull(systemGroup);
        assertNull(systemGroup.getParent());
    }

    // --- join ---

    @Test
    void testJoinWaitsForThreadToFinish() throws InterruptedException {
        final PausingThread thread = new PausingThread("ThreadUtilsAgentTest-join-" + System.nanoTime());
        thread.start();
        thread.awaitStarted();
        thread.releaseLatch.countDown();
        ThreadUtils.join(thread, Duration.ofSeconds(5));
        assertFalse(thread.isAlive());
    }

    @Test
    void testJoinWithNullDurationIsNoOp() throws InterruptedException {
        final PausingThread thread = new PausingThread("ThreadUtilsAgentTest-joinNull-" + System.nanoTime());
        thread.start();
        try {
            thread.awaitStarted();
            ThreadUtils.join(thread, null);
            assertTrue(thread.isAlive());
        } finally {
            thread.finishAndJoin();
        }
    }

    // --- sleep / sleepQuietly ---

    @Test
    void testSleepSleepsAtLeastRequestedDuration() throws InterruptedException {
        final long start = System.nanoTime();
        ThreadUtils.sleep(Duration.ofMillis(50));
        final long elapsedMillis = (System.nanoTime() - start) / 1000000L;
        assertTrue(elapsedMillis >= 40, "expected to sleep at least ~50ms but slept " + elapsedMillis + "ms");
    }

    @Test
    void testSleepWithNullDurationIsNoOp() throws InterruptedException {
        final long start = System.nanoTime();
        ThreadUtils.sleep(null);
        final long elapsedMillis = (System.nanoTime() - start) / 1000000L;
        assertTrue(elapsedMillis < 1000, "expected near-instant return but took " + elapsedMillis + "ms");
    }

    @Test
    void testSleepQuietlySwallowsInterruptedException() {
        Thread.currentThread().interrupt();
        final long start = System.nanoTime();
        ThreadUtils.sleepQuietly(Duration.ofSeconds(5));
        final long elapsedMillis = (System.nanoTime() - start) / 1000000L;
        assertTrue(elapsedMillis < 2000, "expected the interrupt to cut the sleep short, took " + elapsedMillis + "ms");
        assertFalse(Thread.interrupted(), "interrupted status should have been consumed");
    }

    // --- NamePredicate ---

    @Test
    void testNamePredicateNullNameThrows() {
        assertThrows(NullPointerException.class, new Executable0() {
            @Override
            void run() {
                new ThreadUtils.NamePredicate(null);
            }
        });
    }

    @Test
    void testNamePredicateMatchesByName() {
        final String name = "ThreadUtilsAgentTest-namePred-" + System.nanoTime();
        final ThreadUtils.NamePredicate predicate = new ThreadUtils.NamePredicate(name);
        final Thread matchingThread = new Thread((Runnable) null, name);
        final Thread otherThread = new Thread((Runnable) null, name + "-other");
        final ThreadGroup matchingGroup = new ThreadGroup(name);
        final ThreadGroup otherGroup = new ThreadGroup(name + "-other");
        try {
            assertTrue(predicate.test(matchingThread));
            assertFalse(predicate.test(otherThread));
            assertFalse(predicate.test((Thread) null));

            assertTrue(predicate.test(matchingGroup));
            assertFalse(predicate.test(otherGroup));
            assertFalse(predicate.test((ThreadGroup) null));
        } finally {
            matchingGroup.destroy();
            otherGroup.destroy();
        }
    }

    // --- ThreadIdPredicate ---

    @Test
    void testThreadIdPredicateZeroOrNegativeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable0() {
            @Override
            void run() {
                new ThreadUtils.ThreadIdPredicate(0);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable0() {
            @Override
            void run() {
                new ThreadUtils.ThreadIdPredicate(-1);
            }
        });
    }

    @Test
    void testThreadIdPredicateMatchesById() {
        final Thread current = Thread.currentThread();
        final ThreadUtils.ThreadIdPredicate predicate = new ThreadUtils.ThreadIdPredicate(current.getId());
        assertTrue(predicate.test(current));
        assertFalse(predicate.test((Thread) null));
        assertFalse(predicate.test(new Thread()));
    }

    // --- ALWAYS_TRUE_PREDICATE ---

    @Test
    void testAlwaysTruePredicateAlwaysReturnsTrue() {
        final ThreadUtils.ThreadPredicate threadPredicate = ThreadUtils.ALWAYS_TRUE_PREDICATE;
        final ThreadUtils.ThreadGroupPredicate groupPredicate = ThreadUtils.ALWAYS_TRUE_PREDICATE;
        assertTrue(threadPredicate.test((Thread) null));
        assertTrue(threadPredicate.test(Thread.currentThread()));
        assertTrue(groupPredicate.test((ThreadGroup) null));
        assertTrue(groupPredicate.test(Thread.currentThread().getThreadGroup()));
    }

    // --- constructor ---

    @Test
    void testPublicConstructorIsUsable() {
        assertNotNull(new ThreadUtils());
    }

    /**
     * Minimal no-arg executable used with {@code assertThrows}, avoiding lambdas.
     */
    private abstract static class Executable0 implements org.junit.jupiter.api.function.Executable {

        abstract void run() throws Throwable;

        @Override
        public void execute() throws Throwable {
            run();
        }
    }

    private static final class AlwaysTrueThreadGroupPredicate implements Predicate<ThreadGroup> {

        @Override
        public boolean test(final ThreadGroup threadGroup) {
            return true;
        }
    }
}
