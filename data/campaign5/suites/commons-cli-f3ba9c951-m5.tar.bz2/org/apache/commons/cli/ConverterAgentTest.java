/*
  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      https://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
 */
package org.apache.commons.cli;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;

import org.junit.jupiter.api.Test;

class ConverterAgentTest {

    @Test
    void testDefaultConverterReturnsSameString() throws Exception {
        final Converter<?, RuntimeException> converter = Converter.DEFAULT;
        assertEquals("abc", converter.apply("abc"));
        assertEquals("", converter.apply(""));
        assertNull(converter.apply(null));
    }

    @Test
    void testClassConverterHappyPath() throws Exception {
        final Class<?> result = Converter.CLASS.apply("java.lang.String");
        assertEquals(String.class, result);
    }

    @Test
    void testClassConverterUnknownClassThrows() {
        assertThrows(ClassNotFoundException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.CLASS.apply("no.such.ClassName");
            }
        });
    }

    @Test
    void testFileConverterHappyPath() throws Exception {
        final File result = Converter.FILE.apply("some-file.txt");
        assertEquals(new File("some-file.txt"), result);
    }

    @Test
    void testFileConverterEmptyString() throws Exception {
        final File result = Converter.FILE.apply("");
        assertEquals(new File(""), result);
    }

    @Test
    void testFileConverterNullThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.FILE.apply(null);
            }
        });
    }

    @Test
    void testPathConverterHappyPath() throws Exception {
        final Path result = Converter.PATH.apply("some-path/sub");
        assertEquals(Paths.get("some-path/sub"), result);
    }

    @Test
    void testPathConverterNullThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.PATH.apply(null);
            }
        });
    }

    @Test
    void testNumberConverterInteger() throws Exception {
        final Number result = Converter.NUMBER.apply("123");
        assertTrue(result instanceof Long);
        assertEquals(123L, result.longValue());
    }

    @Test
    void testNumberConverterDecimal() throws Exception {
        final Number result = Converter.NUMBER.apply("123.45");
        assertTrue(result instanceof Double);
        assertEquals(123.45d, result.doubleValue(), 0.0001d);
    }

    @Test
    void testNumberConverterNegative() throws Exception {
        final Number result = Converter.NUMBER.apply("-7");
        assertTrue(result instanceof Long);
        assertEquals(-7L, result.longValue());
    }

    @Test
    void testNumberConverterInvalidThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.NUMBER.apply("not-a-number");
            }
        });
    }

    @Test
    void testNumberConverterInvalidDecimalThrows() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.NUMBER.apply("1.2.3");
            }
        });
    }

    @Test
    void testObjectConverterHappyPath() throws Exception {
        final Object result = Converter.OBJECT.apply(ArrayList.class.getName());
        assertTrue(result instanceof ArrayList);
        assertTrue(((ArrayList<?>) result).isEmpty());
    }

    @Test
    void testObjectConverterNoDefaultConstructorThrows() {
        assertThrows(ReflectiveOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.OBJECT.apply(Integer.class.getName());
            }
        });
    }

    @Test
    void testObjectConverterUnknownClassThrows() {
        assertThrows(ReflectiveOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.OBJECT.apply("no.such.ClassName");
            }
        });
    }

    @Test
    void testUrlConverterHappyPath() throws Exception {
        final URL result = Converter.URL.apply("https://commons.apache.org");
        assertEquals("https://commons.apache.org", result.toString());
    }

    @Test
    void testUrlConverterMalformedThrows() {
        assertThrows(MalformedURLException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.URL.apply("not a url");
            }
        });
    }

    @Test
    void testDateConverterHappyPath() throws Exception {
        final Date original = new Date(0);
        final String formatted = original.toString();
        final Date parsed = Converter.DATE.apply(formatted);
        assertEquals(original, parsed);
    }

    @Test
    void testDateConverterInvalidThrows() {
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.DATE.apply("not-a-date");
            }
        });
    }

    @Test
    void testDateConverterEmptyStringThrows() {
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.DATE.apply("");
            }
        });
    }

    /**
     * A custom functional interface implementation that throws a checked exception
     * other than the ones provided by the built-in constants.
     */
    private static final class UpperCaseConverter implements Converter<String, java.io.IOException> {
        @Override
        public String apply(final String string) throws java.io.IOException {
            if (string == null) {
                throw new java.io.IOException("null input");
            }
            return string.toUpperCase();
        }
    }

    @Test
    void testCustomConverterHappyPath() throws Exception {
        final Converter<String, java.io.IOException> converter = new UpperCaseConverter();
        assertEquals("HELLO", converter.apply("hello"));
    }

    @Test
    void testCustomConverterThrowsDeclaredException() {
        final Converter<String, java.io.IOException> converter = new UpperCaseConverter();
        final java.io.IOException thrown = assertThrows(java.io.IOException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                converter.apply(null);
            }
        });
        assertEquals("null input", thrown.getMessage());
    }

    @Test
    void testDefaultConverterIsNotSameInstanceAsClassConverter() {
        final Object defaultConverter = Converter.DEFAULT;
        final Object classConverter = Converter.CLASS;
        assertFalse(defaultConverter == classConverter);
        assertNotNull(defaultConverter);
        assertNotNull(classConverter);
    }

    @Test
    void testAllPublicConstantsAreDistinctAndNonNull() {
        assertNotNull(Converter.DEFAULT);
        assertNotNull(Converter.CLASS);
        assertNotNull(Converter.FILE);
        assertNotNull(Converter.PATH);
        assertNotNull(Converter.NUMBER);
        assertNotNull(Converter.OBJECT);
        assertNotNull(Converter.URL);
        assertNotNull(Converter.DATE);
    }
}
