/*
  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      https://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
 */
package org.apache.commons.cli;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.util.Date;

import org.junit.jupiter.api.Test;

class ConverterAgentTest {

    @Test
    void testDefaultReturnsArgumentUnchanged() {
        final Converter<?, RuntimeException> converter = Converter.DEFAULT;
        assertEquals("hello", converter.apply("hello"));
        assertEquals("", converter.apply(""));
    }

    @Test
    void testClassConvertsKnownClassName() throws ClassNotFoundException {
        final Class<?> result = Converter.CLASS.apply("java.lang.String");
        assertEquals(String.class, result);
    }

    @Test
    void testClassThrowsOnUnknownClassName() {
        assertThrows(ClassNotFoundException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.CLASS.apply("this.class.does.not.Exist");
            }
        });
    }

    @Test
    void testFileConvertsPathString() throws NullPointerException {
        final File result = Converter.FILE.apply("some/relative/path.txt");
        assertEquals(new File("some/relative/path.txt"), result);
    }

    @Test
    void testFileThrowsOnNullArgument() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.FILE.apply(null);
            }
        });
    }

    @Test
    void testPathConvertsPathString() throws InvalidPathException {
        final Path result = Converter.PATH.apply("some/relative/path.txt");
        assertEquals(Paths.get("some/relative/path.txt"), result);
    }

    @Test
    void testPathThrowsOnInvalidPathString() {
        assertThrows(InvalidPathException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.PATH.apply("foo\u0000bar");
            }
        });
    }

    @Test
    void testNumberConvertsIntegerString() {
        final Number result = Converter.NUMBER.apply("42");
        assertEquals(Long.valueOf(42L), result);
        assertTrue(result instanceof Long);
    }

    @Test
    void testNumberConvertsDecimalString() {
        final Number result = Converter.NUMBER.apply("42.5");
        assertEquals(Double.valueOf(42.5d), result);
        assertTrue(result instanceof Double);
    }

    @Test
    void testNumberThrowsOnNonNumericString() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.NUMBER.apply("not-a-number");
            }
        });
    }

    @Test
    void testObjectInstantiatesDefaultConstructor() throws ReflectiveOperationException {
        final Object result = Converter.OBJECT.apply("java.lang.Object");
        assertNotNull(result);
        assertEquals(Object.class, result.getClass());
    }

    @Test
    void testObjectThrowsOnUnknownClassName() {
        assertThrows(ReflectiveOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.OBJECT.apply("this.class.does.not.Exist");
            }
        });
    }

    @Test
    void testObjectThrowsOnClassWithoutNoArgConstructor() {
        // java.lang.Runnable is an interface: getConstructor() fails with NoSuchMethodException,
        // which is a ReflectiveOperationException.
        assertThrows(ReflectiveOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.OBJECT.apply("java.lang.Runnable");
            }
        });
    }

    @Test
    void testUrlConvertsValidUrlString() throws MalformedURLException {
        final URL result = Converter.URL.apply("https://example.com/path");
        assertEquals("https://example.com/path", result.toString());
    }

    @Test
    void testUrlThrowsOnInvalidUrlString() {
        assertThrows(MalformedURLException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.URL.apply("not a url");
            }
        });
    }

    @Test
    void testDateConvertsValidDateString() throws ParseException {
        final Date source = new Date(0L);
        final Date result = Converter.DATE.apply(source.toString());
        assertEquals(source, result);
    }

    @Test
    void testDateThrowsOnUnparseableString() {
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.DATE.apply("not a date");
            }
        });
    }

    @Test
    void testDateThrowsOnOutOfRangeDayOfMonth() {
        // February never has 30 days; with lenient parsing disabled this must be rejected
        // rather than silently rolled over into March.
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.DATE.apply("Mon Feb 30 00:00:00 GMT 2021");
            }
        });
    }
}
