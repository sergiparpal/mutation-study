/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Self-contained test class for {@link WordUtils}.
 */
public class WordUtilsAgentTest {

    // -----------------------------------------------------------------
    // capitalize(String)
    // -----------------------------------------------------------------

    @Test
    public void testCapitalize_nullInput() {
        assertNull(WordUtils.capitalize(null));
    }

    @Test
    public void testCapitalize_emptyInput() {
        assertEquals("", WordUtils.capitalize(""));
    }

    @Test
    public void testCapitalize_basic() {
        assertEquals("I Am FINE", WordUtils.capitalize("i am FINE"));
    }

    @Test
    public void testCapitalize_singleChar() {
        assertEquals("A", WordUtils.capitalize("a"));
    }

    @Test
    public void testCapitalize_withLeadingWhitespace() {
        assertEquals(" Foo Bar", WordUtils.capitalize(" foo bar"));
    }

    // -----------------------------------------------------------------
    // capitalize(String, char...)
    // -----------------------------------------------------------------

    @Test
    public void testCapitalizeWithDelimiters_nullInput() {
        assertNull(WordUtils.capitalize(null, '.'));
    }

    @Test
    public void testCapitalizeWithDelimiters_emptyInput() {
        assertEquals("", WordUtils.capitalize("", '.'));
    }

    @Test
    public void testCapitalizeWithDelimiters_emptyDelimiterArrayReturnsSameValue() {
        final String input = "i am fine";
        assertEquals(input, WordUtils.capitalize(input, new char[0]));
    }

    @Test
    public void testCapitalizeWithDelimiters_nullDelimitersMeansWhitespace() {
        assertEquals("I Am Fine", WordUtils.capitalize("i am fine", (char[]) null));
    }

    @Test
    public void testCapitalizeWithDelimiters_customDelimiter() {
        assertEquals("I aM.Fine", WordUtils.capitalize("i aM.fine", new char[] {'.'}));
    }

    // -----------------------------------------------------------------
    // capitalizeFully(String)
    // -----------------------------------------------------------------

    @Test
    public void testCapitalizeFully_nullInput() {
        assertNull(WordUtils.capitalizeFully(null));
    }

    @Test
    public void testCapitalizeFully_emptyInput() {
        assertEquals("", WordUtils.capitalizeFully(""));
    }

    @Test
    public void testCapitalizeFully_basic() {
        assertEquals("I Am Fine", WordUtils.capitalizeFully("i am FINE"));
    }

    // -----------------------------------------------------------------
    // capitalizeFully(String, char...)
    // -----------------------------------------------------------------

    @Test
    public void testCapitalizeFullyWithDelimiters_nullInput() {
        assertNull(WordUtils.capitalizeFully(null, '.'));
    }

    @Test
    public void testCapitalizeFullyWithDelimiters_emptyInput() {
        assertEquals("", WordUtils.capitalizeFully("", '.'));
    }

    @Test
    public void testCapitalizeFullyWithDelimiters_nullDelimitersMeansWhitespace() {
        assertEquals("I Am.fine", WordUtils.capitalizeFully("I AM.FINE", (char[]) null));
    }

    @Test
    public void testCapitalizeFullyWithDelimiters_emptyDelimiterArrayReturnsSameValue() {
        final String input = "I AM.FINE";
        assertEquals(input, WordUtils.capitalizeFully(input, new char[0]));
    }

    @Test
    public void testCapitalizeFullyWithDelimiters_customDelimiter() {
        assertEquals("I am.Fine", WordUtils.capitalizeFully("i aM.fine", new char[] {'.'}));
    }

    // -----------------------------------------------------------------
    // containsAllWords(CharSequence, CharSequence...)
    // -----------------------------------------------------------------

    @Test
    public void testContainsAllWords_nullWord() {
        assertEquals(false, WordUtils.containsAllWords(null, "ab"));
    }

    @Test
    public void testContainsAllWords_emptyWord() {
        assertEquals(false, WordUtils.containsAllWords("", "ab"));
    }

    @Test
    public void testContainsAllWords_nullWordsArray() {
        assertEquals(false, WordUtils.containsAllWords("abcd", (CharSequence[]) null));
    }

    @Test
    public void testContainsAllWords_emptyWordsArray() {
        assertEquals(false, WordUtils.containsAllWords("abcd", new CharSequence[0]));
    }

    @Test
    public void testContainsAllWords_substringsNotWholeWords() {
        assertEquals(false, WordUtils.containsAllWords("abcd", "ab", "cd"));
    }

    @Test
    public void testContainsAllWords_allWordsPresent() {
        assertTrue(WordUtils.containsAllWords("abc def", "def", "abc"));
    }

    @Test
    public void testContainsAllWords_oneWordMissing() {
        assertEquals(false, WordUtils.containsAllWords("abc def", "def", "ghi"));
    }

    @Test
    public void testContainsAllWords_blankSearchWord() {
        assertEquals(false, WordUtils.containsAllWords("abc def", "abc", " "));
    }

    // -----------------------------------------------------------------
    // initials(String)
    // -----------------------------------------------------------------

    @Test
    public void testInitials_nullInput() {
        assertNull(WordUtils.initials(null));
    }

    @Test
    public void testInitials_emptyInput() {
        assertEquals("", WordUtils.initials(""));
    }

    @Test
    public void testInitials_multipleWords() {
        assertEquals("BJL", WordUtils.initials("Ben John Lee"));
    }

    @Test
    public void testInitials_dotIsNotDelimiterByDefault() {
        assertEquals("BJ", WordUtils.initials("Ben J.Lee"));
    }

    // -----------------------------------------------------------------
    // initials(String, char...)
    // -----------------------------------------------------------------

    @Test
    public void testInitialsWithDelimiters_nullInput() {
        assertNull(WordUtils.initials(null, '.'));
    }

    @Test
    public void testInitialsWithDelimiters_emptyInput() {
        assertEquals("", WordUtils.initials("", '.'));
    }

    @Test
    public void testInitialsWithDelimiters_nullDelimitersMeansWhitespace() {
        assertEquals("BJL", WordUtils.initials("Ben John Lee", (char[]) null));
    }

    @Test
    public void testInitialsWithDelimiters_customDelimiters() {
        assertEquals("BJL", WordUtils.initials("Ben J.Lee", new char[] {' ', '.'}));
    }

    @Test
    public void testInitialsWithDelimiters_emptyDelimiterArrayReturnsEmptyString() {
        assertEquals("", WordUtils.initials("Ben John Lee", new char[0]));
    }

    // -----------------------------------------------------------------
    // swapCase(String)
    // -----------------------------------------------------------------

    @Test
    public void testSwapCase_nullInput() {
        assertNull(WordUtils.swapCase(null));
    }

    @Test
    public void testSwapCase_emptyInput() {
        assertEquals("", WordUtils.swapCase(""));
    }

    @Test
    public void testSwapCase_basic() {
        assertEquals("tHE DOG HAS A bone", WordUtils.swapCase("The dog has a BONE"));
    }

    @Test
    public void testSwapCase_nonLetterCharactersPreserved() {
        assertEquals("1 2 3", WordUtils.swapCase("1 2 3"));
    }

    // -----------------------------------------------------------------
    // uncapitalize(String)
    // -----------------------------------------------------------------

    @Test
    public void testUncapitalize_nullInput() {
        assertNull(WordUtils.uncapitalize(null));
    }

    @Test
    public void testUncapitalize_emptyInput() {
        assertEquals("", WordUtils.uncapitalize(""));
    }

    @Test
    public void testUncapitalize_basic() {
        assertEquals("i am fINE", WordUtils.uncapitalize("I Am FINE"));
    }

    // -----------------------------------------------------------------
    // uncapitalize(String, char...)
    // -----------------------------------------------------------------

    @Test
    public void testUncapitalizeWithDelimiters_nullInput() {
        assertNull(WordUtils.uncapitalize(null, '.'));
    }

    @Test
    public void testUncapitalizeWithDelimiters_emptyInput() {
        assertEquals("", WordUtils.uncapitalize("", '.'));
    }

    @Test
    public void testUncapitalizeWithDelimiters_nullDelimitersMeansWhitespace() {
        assertEquals("i aM.FINE", WordUtils.uncapitalize("I AM.FINE", (char[]) null));
    }

    @Test
    public void testUncapitalizeWithDelimiters_emptyDelimiterArrayReturnsSameValue() {
        final String input = "I AM.FINE";
        assertEquals(input, WordUtils.uncapitalize(input, new char[0]));
    }

    @Test
    public void testUncapitalizeWithDelimiters_customDelimiter() {
        assertEquals("i AM.fINE", WordUtils.uncapitalize("I AM.FINE", new char[] {'.'}));
    }

    // -----------------------------------------------------------------
    // wrap(String, int)
    // -----------------------------------------------------------------

    @Test
    public void testWrap_nullInput() {
        assertNull(WordUtils.wrap(null, 20));
    }

    @Test
    public void testWrap_emptyInput() {
        assertEquals("", WordUtils.wrap("", 20));
    }

    @Test
    public void testWrap_basic() {
        final String input = "Here is one line of text that is going to be wrapped after 20 columns.";
        final String expected = "Here is one line of" + System.lineSeparator()
                + "text that is going" + System.lineSeparator()
                + "to be wrapped after" + System.lineSeparator()
                + "20 columns.";
        assertEquals(expected, WordUtils.wrap(input, 20));
    }

    @Test
    public void testWrap_shortStringUnchanged() {
        assertEquals("short", WordUtils.wrap("short", 20));
    }

    // -----------------------------------------------------------------
    // wrap(String, int, String, boolean)
    // -----------------------------------------------------------------

    @Test
    public void testWrap4_nullInput() {
        assertNull(WordUtils.wrap(null, 20, "\n", true));
    }

    @Test
    public void testWrap4_emptyInput() {
        assertEquals("", WordUtils.wrap("", 20, "\n", true));
    }

    @Test
    public void testWrap4_customNewLineString() {
        final String input = "Here is one line of text that is going to be wrapped after 20 columns.";
        final String expected = "Here is one line of<br />text that is going<br />to be wrapped after<br />20 columns.";
        assertEquals(expected, WordUtils.wrap(input, 20, "<br />", false));
    }

    @Test
    public void testWrap4_noWrapLongWordsLeavesLongWordIntact() {
        final String input = "Click here to jump to the commons website - https://commons.apache.org";
        final String expected = "Click here to jump\nto the commons\nwebsite -\nhttps://commons.apache.org";
        assertEquals(expected, WordUtils.wrap(input, 20, "\n", false));
    }

    @Test
    public void testWrap4_wrapLongWordsSplitsLongWord() {
        final String input = "Click here to jump to the commons website - https://commons.apache.org";
        final String expected = "Click here to jump\nto the commons\nwebsite -\nhttps://commons.apac\nhe.org";
        assertEquals(expected, WordUtils.wrap(input, 20, "\n", true));
    }

    @Test
    public void testWrap4_wrapLengthLessThanOneTreatedAsOne() {
        final String result = WordUtils.wrap("ab cd", 0, "\n", true);
        assertNotNull(result);
        assertTrue(result.indexOf('\n') >= 0);
    }

    // -----------------------------------------------------------------
    // wrap(String, int, String, boolean, String)
    // -----------------------------------------------------------------

    @Test
    public void testWrap5_nullInput() {
        assertNull(WordUtils.wrap(null, 20, "\n", true, "/"));
    }

    @Test
    public void testWrap5_emptyInput() {
        assertEquals("", WordUtils.wrap("", 20, "\n", true, "/"));
    }

    @Test
    public void testWrap5_customWrapOnPattern() {
        final String input = "flammable/inflammable";
        final String expected = "flammable\ninflammable";
        assertEquals(expected, WordUtils.wrap(input, 20, "\n", true, "/"));
    }

    @Test
    public void testWrap5_nullNewLineUsesSystemLineSeparator() {
        final String input = "aaaa bbbb cccc";
        final String result = WordUtils.wrap(input, 5, null, false, " ");
        assertTrue(result.indexOf(System.lineSeparator()) >= 0);
    }

    @Test
    public void testWrap5_blankWrapOnDefaultsToSpace() {
        final String input = "aaaa bbbb cccc";
        final String expected = WordUtils.wrap(input, 5, "\n", false, " ");
        assertEquals(expected, WordUtils.wrap(input, 5, "\n", false, ""));
    }

    // -----------------------------------------------------------------
    // constructor
    // -----------------------------------------------------------------

    @Test
    public void testConstructor_isPublic() {
        final WordUtils instance = new WordUtils();
        assertNotNull(instance);
    }
}
