/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.concurrent;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.Test;

/**
 * Self-contained test class for {@link BackgroundInitializer}.
 */
public class BackgroundInitializerAgentTest {

    /**
     * A concrete {@link BackgroundInitializer} that can be controlled for test
     * purposes: it can be made to wait for a latch before producing a result,
     * count how many times {@link #initialize()} was invoked, and optionally
     * throw a given exception.
     */
    private static class AgentBackgroundInitializer extends BackgroundInitializer<Integer> {

        /** Latch used to block initialize() until released by the test. */
        private final CountDownLatch latch;

        /** Number of times initialize() was called. */
        private int initializeCalls;

        /** An exception to throw from initialize(), if any. */
        private final Exception exceptionToThrow;

        /** The result to return from initialize(). */
        private final Integer result;

        AgentBackgroundInitializer() {
            this(null, null, Integer.valueOf(42));
        }

        AgentBackgroundInitializer(final ExecutorService exec) {
            super(exec);
            latch = null;
            exceptionToThrow = null;
            result = Integer.valueOf(42);
        }

        AgentBackgroundInitializer(final CountDownLatch latch, final Exception exceptionToThrow, final Integer result) {
            this.latch = latch;
            this.exceptionToThrow = exceptionToThrow;
            this.result = result;
        }

        public synchronized int getInitializeCalls() {
            return initializeCalls;
        }

        @Override
        protected Integer initialize() throws Exception {
            synchronized (this) {
                initializeCalls++;
            }
            if (latch != null) {
                latch.await();
            }
            if (exceptionToThrow != null) {
                throw exceptionToThrow;
            }
            return result;
        }
    }

    @Test
    public void testDefaultConstructorHasNoExternalExecutor() {
        final AgentBackgroundInitializer init = new AgentBackgroundInitializer();
        assertEquals(null, init.getExternalExecutor(), "External executor should be null by default");
        assertFalse(init.isStarted(), "Should not be started before start() is called");
    }

    @Test
    public void testExecutorConstructorSetsExternalExecutor() throws InterruptedException {
        final ExecutorService exec = Executors.newSingleThreadExecutor();
        try {
            final AgentBackgroundInitializer init = new AgentBackgroundInitializer(exec);
            assertSame(exec, init.getExternalExecutor(), "Executor was not set");
        } finally {
            exec.shutdown();
            exec.awaitTermination(1, TimeUnit.SECONDS);
        }
    }

    @Test
    public void testGetFutureBeforeStartThrows() {
        final AgentBackgroundInitializer init = new AgentBackgroundInitializer();
        final IllegalStateException ex = assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                init.getFuture();
            }
        });
        assertNotNull(ex.getMessage());
    }

    @Test
    public void testSetExternalExecutorAfterStartThrows() {
        final AgentBackgroundInitializer init = new AgentBackgroundInitializer();
        assertTrue(init.start(), "First start() should succeed");
        final ExecutorService exec = Executors.newSingleThreadExecutor();
        try {
            assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
                @Override
                public void execute() throws Throwable {
                    init.setExternalExecutor(exec);
                }
            });
        } finally {
            exec.shutdown();
        }
    }

    @Test
    public void testStartReturnsTrueOnlyOnce() throws ConcurrentException {
        final AgentBackgroundInitializer init = new AgentBackgroundInitializer();
        assertFalse(init.isStarted(), "Should not be started yet");
        assertTrue(init.start(), "First start() should return true");
        assertTrue(init.isStarted(), "Should be started now");
        assertFalse(init.start(), "Second start() should return false");
        assertFalse(init.start(), "Third start() should also return false");
        assertEquals(Integer.valueOf(42), init.get());
    }

    @Test
    public void testGetBlocksUntilInitializationComplete() throws ConcurrentException, InterruptedException {
        final CountDownLatch latch = new CountDownLatch(1);
        final AgentBackgroundInitializer init = new AgentBackgroundInitializer(latch, null, Integer.valueOf(99));
        init.start();
        assertFalse(init.isInitialized(), "Should not be initialized while blocked");
        latch.countDown();
        final Integer result = init.get();
        assertEquals(Integer.valueOf(99), result, "Wrong result returned by get()");
        assertTrue(init.isInitialized(), "Should be initialized after get() returns");
        assertEquals(1, init.getInitializeCalls(), "initialize() should be called exactly once");
    }

    @Test
    public void testGetWrapsCheckedExceptionInConcurrentException() {
        final Exception cause = new java.io.IOException("boom");
        final AgentBackgroundInitializer init = new AgentBackgroundInitializer(null, cause, null);
        init.start();
        final ConcurrentException ex = assertThrows(ConcurrentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                init.get();
            }
        });
        assertSame(cause, ex.getCause(), "Cause should be the original checked exception");
    }

    @Test
    public void testGetRethrowsRuntimeExceptionUnwrapped() {
        final RuntimeException cause = new IllegalArgumentException("bad");
        final AgentBackgroundInitializer init = new AgentBackgroundInitializer(null, cause, null);
        init.start();
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                init.get();
            }
        });
        assertSame(cause, ex, "The original RuntimeException should be thrown directly");
    }

    @Test
    public void testIsInitializedFalseAfterFailure() {
        final Exception cause = new java.io.IOException("boom");
        final AgentBackgroundInitializer init = new AgentBackgroundInitializer(null, cause, null);
        init.start();
        // Wait for the background task to complete (it fails, so getFuture().get() throws).
        try {
            init.getFuture().get();
        } catch (final Exception ignored) {
            // expected: the task failed
        }
        assertFalse(init.isInitialized(), "isInitialized() should be false after a failed initialization");
    }

    @Test
    public void testGetActiveExecutorUsesTemporaryExecutorWhenNoneProvided() {
        final AgentBackgroundInitializer init = new AgentBackgroundInitializer();
        assertEquals(null, init.getActiveExecutor(), "No executor should be active before start()");
        init.start();
        assertNotNull(init.getActiveExecutor(), "An executor should be created and active after start()");
        assertNotSame(init.getExternalExecutor(), init.getActiveExecutor(), "A temporary executor should differ from the (null) external one");
    }

    @Test
    public void testGetActiveExecutorUsesExternalExecutorWhenProvided() throws InterruptedException {
        final ExecutorService exec = Executors.newSingleThreadExecutor();
        try {
            final AgentBackgroundInitializer init = new AgentBackgroundInitializer(exec);
            init.start();
            assertSame(exec, init.getActiveExecutor(), "The external executor should be used as the active executor");
        } finally {
            exec.shutdown();
            exec.awaitTermination(1, TimeUnit.SECONDS);
        }
    }

    @Test
    public void testGetTaskCountDefaultIsOne() {
        final AgentBackgroundInitializer init = new AgentBackgroundInitializer();
        assertEquals(1, init.getTaskCount(), "Default task count should be 1");
    }

    @Test
    public void testBuilderCreatesWorkingInitializer() throws ConcurrentException {
        final BackgroundInitializer.Builder<BackgroundInitializer<String>, String> builder = BackgroundInitializer.builder();
        builder.setInitializer(new org.apache.commons.lang3.function.FailableSupplier<String, ConcurrentException>() {
            @Override
            public String get() {
                return "built-value";
            }
        });
        final BackgroundInitializer<String> init = builder.get();
        init.start();
        assertEquals("built-value", init.get(), "Builder-created initializer should use the configured supplier");
    }

    @Test
    public void testBuilderWithExternalExecutor() throws InterruptedException, ConcurrentException {
        final ExecutorService exec = Executors.newSingleThreadExecutor();
        try {
            final BackgroundInitializer.Builder<BackgroundInitializer<String>, String> builder = BackgroundInitializer.builder();
            builder.setExternalExecutor(exec);
            builder.setInitializer(new org.apache.commons.lang3.function.FailableSupplier<String, ConcurrentException>() {
                @Override
                public String get() {
                    return "value";
                }
            });
            final BackgroundInitializer<String> init = builder.get();
            assertSame(exec, init.getExternalExecutor(), "Builder should propagate the external executor");
            init.start();
            assertEquals("value", init.get());
        } finally {
            exec.shutdown();
            exec.awaitTermination(1, TimeUnit.SECONDS);
        }
    }
}
