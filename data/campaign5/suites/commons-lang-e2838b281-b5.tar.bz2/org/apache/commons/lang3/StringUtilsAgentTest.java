/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link StringUtils}.
 */
class StringUtilsAgentTest {

    @Test
    void testIsEmptyIsBlank() {
        assertTrue(StringUtils.isEmpty(null));
        assertTrue(StringUtils.isEmpty(""));
        assertFalse(StringUtils.isEmpty(" "));
        assertFalse(StringUtils.isEmpty("bob"));

        assertTrue(StringUtils.isBlank(null));
        assertTrue(StringUtils.isBlank(""));
        assertTrue(StringUtils.isBlank("  \t\n"));
        assertFalse(StringUtils.isBlank("bob"));
        assertFalse(StringUtils.isBlank("  bob  "));

        assertFalse(StringUtils.isNotEmpty(null));
        assertTrue(StringUtils.isNotEmpty("a"));
        assertFalse(StringUtils.isNotBlank(" "));
        assertTrue(StringUtils.isNotBlank("a"));
    }

    @Test
    void testTrimAndStrip() {
        assertNull(StringUtils.trim(null));
        assertEquals("", StringUtils.trim(""));
        assertEquals("", StringUtils.trim("   "));
        assertEquals("abc", StringUtils.trim("  abc  "));

        assertNull(StringUtils.trimToNull("   "));
        assertEquals("", StringUtils.trimToEmpty(null));
        assertEquals("abc", StringUtils.trimToEmpty("  abc  "));

        assertNull(StringUtils.strip(null));
        assertEquals("abc", StringUtils.strip(" abc "));
        assertEquals("abc", StringUtils.strip("xxabcxx", "x"));
        assertEquals("", StringUtils.strip("xx", "x"));
    }

    @Test
    void testEquals() {
        assertTrue(StringUtils.equals(null, null));
        assertFalse(StringUtils.equals(null, "abc"));
        assertFalse(StringUtils.equals("abc", null));
        assertTrue(StringUtils.equals("abc", "abc"));
        assertFalse(StringUtils.equals("abc", "ABC"));

        assertTrue(StringUtils.equalsIgnoreCase(null, null));
        assertFalse(StringUtils.equalsIgnoreCase(null, "abc"));
        assertTrue(StringUtils.equalsIgnoreCase("abc", "ABC"));
        assertFalse(StringUtils.equalsIgnoreCase("abc", "abcd"));

        assertFalse(StringUtils.equalsAny("abc", (CharSequence[]) null));
        assertTrue(StringUtils.equalsAny("abc", "xyz", "abc"));
        assertFalse(StringUtils.equalsAny("abc", "xyz", "def"));
    }

    @Test
    void testIndexOfAndLastIndexOf() {
        assertEquals(-1, StringUtils.indexOf(null, "a"));
        assertEquals(-1, StringUtils.indexOf("abc", null));
        assertEquals(0, StringUtils.indexOf("abc", ""));
        assertEquals(1, StringUtils.indexOf("abc", "b"));
        assertEquals(-1, StringUtils.indexOf("abc", "z"));

        assertEquals(-1, StringUtils.lastIndexOf(null, "a"));
        assertEquals(3, StringUtils.lastIndexOf("abcabc", "abc"));
        assertEquals(-1, StringUtils.lastIndexOf("abc", "z"));

        assertEquals(1, StringUtils.indexOfIgnoreCase("aBc", "bc"));
        assertEquals(-1, StringUtils.indexOfIgnoreCase(null, "bc"));

        assertEquals(1, StringUtils.ordinalIndexOf("aabaabaa", "a", 2));
        assertEquals(-1, StringUtils.ordinalIndexOf("aabaabaa", "a", 0));
    }

    @Test
    void testContains() {
        assertFalse(StringUtils.contains(null, "a"));
        assertFalse(StringUtils.contains("abc", null));
        assertTrue(StringUtils.contains("abc", ""));
        assertTrue(StringUtils.contains("abc", 'a'));
        assertFalse(StringUtils.contains("abc", 'z'));

        assertFalse(StringUtils.containsIgnoreCase(null, "a"));
        assertTrue(StringUtils.containsIgnoreCase("abc", "B"));

        assertFalse(StringUtils.containsAny(null, 'a'));
        assertTrue(StringUtils.containsAny("zzabyy", 'a', 'b'));
        assertFalse(StringUtils.containsAny("zzzz", 'a', 'b'));

        assertFalse(StringUtils.containsWhitespace(""));
        assertTrue(StringUtils.containsWhitespace("ab cd"));

        assertFalse(StringUtils.containsOnly("", (char[]) null));
        assertTrue(StringUtils.containsOnly("abab", 'a', 'b'));
        assertFalse(StringUtils.containsOnly("abcab", 'a', 'b'));

        assertTrue(StringUtils.containsNone("abc", 'x', 'y', 'z'));
        assertFalse(StringUtils.containsNone("abc", 'a'));
    }

    @Test
    void testSubstring() {
        assertNull(StringUtils.substring(null, 0));
        assertEquals("", StringUtils.substring("", 0));
        assertEquals("cde", StringUtils.substring("abcde", 2));
        assertEquals("cde", StringUtils.substring("abcde", -3));
        assertEquals("", StringUtils.substring("abc", 10));

        assertNull(StringUtils.substring(null, 0, 2));
        assertEquals("", StringUtils.substring("abc", 2, 1));
        assertEquals("b", StringUtils.substring("abc", 1, 2));
        assertEquals("ab", StringUtils.substring("abc", 0, -1));

        assertNull(StringUtils.left(null, 2));
        assertEquals("", StringUtils.left("abc", -1));
        assertEquals("ab", StringUtils.left("abc", 2));
        assertEquals("abc", StringUtils.left("abc", 10));

        assertNull(StringUtils.right(null, 2));
        assertEquals("", StringUtils.right("abc", -1));
        assertEquals("bc", StringUtils.right("abc", 2));
        assertEquals("abc", StringUtils.right("abc", 10));

        assertNull(StringUtils.mid(null, 0, 2));
        assertEquals("", StringUtils.mid("abc", 0, -1));
        assertEquals("bc", StringUtils.mid("abc", 1, 2));
        assertEquals("abc", StringUtils.mid("abc", -1, 10));
    }

    @Test
    void testSplit() {
        assertNull(StringUtils.split(null));
        assertEquals(0, StringUtils.split("").length);
        assertArrayEquals3("a", "b", "c", StringUtils.split("a b c"));
        assertArrayEquals3("a", "b", "c", StringUtils.split("a..b.c", "."));

        String[] parts = StringUtils.split("a.b.c", '.');
        assertEquals(3, parts.length);
        assertEquals("a", parts[0]);
        assertEquals("c", parts[2]);
    }

    private void assertArrayEquals3(String a, String b, String c, String[] actual) {
        assertEquals(3, actual.length);
        assertEquals(a, actual[0]);
        assertEquals(b, actual[1]);
        assertEquals(c, actual[2]);
    }

    @Test
    void testJoin() {
        assertNull(StringUtils.join((Object[]) null, ','));
        assertEquals("", StringUtils.join(new Object[0], ','));
        assertEquals("a,b,c", StringUtils.join(new String[] {"a", "b", "c"}, ','));
        assertEquals("a,,c", StringUtils.join(new String[] {"a", null, "c"}, ','));

        assertEquals("a-b-c", StringUtils.join(new String[] {"a", "b", "c"}, "-"));
        assertNull(StringUtils.join((Object[]) null, "-"));

        List<String> list = new ArrayList<String>(Arrays.asList("x", "y", "z"));
        assertEquals("x,y,z", StringUtils.join(list, ','));
        assertEquals("x-y-z", StringUtils.join((Iterable<?>) list, "-"));

        assertEquals("1,2,3", StringUtils.join(new int[] {1, 2, 3}, ','));
        assertEquals("", StringUtils.join(new int[0], ','));
    }

    @Test
    void testReplaceAndRemove() {
        assertNull(StringUtils.replace(null, "a", "b"));
        assertEquals("abc", StringUtils.replace("abc", null, "x"));
        assertEquals("xbxbxb", StringUtils.replace("ababab", "a", "x"));
        assertEquals("xbab", StringUtils.replace("abab", "a", "x", 1));

        assertNull(StringUtils.remove(null, "a"));
        assertEquals("bc", StringUtils.remove("abc", "a"));
        assertEquals("bc", StringUtils.remove("abc", 'a'));
        assertEquals("abc", StringUtils.remove("abc", (String) null));

        assertEquals("", StringUtils.removeStart("", "www."));
        assertEquals("domain.com", StringUtils.removeStart("www.domain.com", "www."));
        assertEquals("domain.com", StringUtils.removeEnd("domain.com", ""));
        assertEquals("www.domain", StringUtils.removeEnd("www.domain.com", ".com"));
    }

    @Test
    void testStartsEndsWith() {
        assertFalse(StringUtils.startsWith(null, "abc"));
        assertFalse(StringUtils.startsWith("abcdef", null));
        assertTrue(StringUtils.startsWith("abcdef", "abc"));
        assertFalse(StringUtils.startsWith("ABCDEF", "abc"));

        assertTrue(StringUtils.startsWithIgnoreCase("ABCDEF", "abc"));

        assertFalse(StringUtils.endsWith(null, "def"));
        assertTrue(StringUtils.endsWith("abcdef", "def"));
        assertFalse(StringUtils.endsWith("ABCDEF", "def"));
        assertTrue(StringUtils.endsWithIgnoreCase("ABCDEF", "def"));

        assertFalse(StringUtils.startsWithAny(null, "abc"));
        assertTrue(StringUtils.startsWithAny("abcdef", "xyz", "abc"));
    }

    @Test
    void testCapitalizeAndSwapCase() {
        assertNull(StringUtils.capitalize(null));
        assertEquals("", StringUtils.capitalize(""));
        assertEquals("Cat", StringUtils.capitalize("cat"));
        assertEquals("CAt", StringUtils.capitalize("CAt"));

        assertNull(StringUtils.uncapitalize(null));
        assertEquals("cat", StringUtils.uncapitalize("Cat"));
        assertEquals("", StringUtils.uncapitalize(""));

        assertNull(StringUtils.swapCase(null));
        assertEquals("", StringUtils.swapCase(""));
        assertEquals("tHE DOG has a BONE", StringUtils.swapCase("The dog HAS A bone"));
    }

    @Test
    void testReverse() {
        assertNull(StringUtils.reverse(null));
        assertEquals("", StringUtils.reverse(""));
        assertEquals("cba", StringUtils.reverse("abc"));
    }

    @Test
    void testRepeat() {
        assertNull(StringUtils.repeat(null, 2));
        assertEquals("", StringUtils.repeat("ab", 0));
        assertEquals("", StringUtils.repeat("ab", -1));
        assertEquals("ababab", StringUtils.repeat("ab", 3));

        assertEquals("", StringUtils.repeat('e', 0));
        assertEquals("eee", StringUtils.repeat('e', 3));

        assertNull(StringUtils.repeat(null, ",", 2));
        assertEquals("", StringUtils.repeat("", null, 2));
        assertEquals("a,a,a", StringUtils.repeat("a", ",", 3));
        assertEquals("", StringUtils.repeat("a", ",", 0));
    }

    @Test
    void testIsAlphaNumericEtc() {
        assertFalse(StringUtils.isAlpha(null));
        assertFalse(StringUtils.isAlpha(""));
        assertFalse(StringUtils.isAlpha(" "));
        assertTrue(StringUtils.isAlpha("abcABC"));
        assertFalse(StringUtils.isAlpha("ab2c"));

        assertFalse(StringUtils.isNumeric(null));
        assertFalse(StringUtils.isNumeric(""));
        assertTrue(StringUtils.isNumeric("12345"));
        assertFalse(StringUtils.isNumeric("12.3"));
        assertFalse(StringUtils.isNumeric("-123"));

        assertFalse(StringUtils.isAlphanumeric(null));
        assertTrue(StringUtils.isAlphanumeric("ab12"));
        assertFalse(StringUtils.isAlphanumeric("ab 12"));

        assertFalse(StringUtils.isWhitespace(null));
        assertTrue(StringUtils.isWhitespace(""));
        assertTrue(StringUtils.isWhitespace("  \t"));
        assertFalse(StringUtils.isWhitespace(" a "));
    }

    @Test
    void testCountMatches() {
        assertEquals(0, StringUtils.countMatches(null, "a"));
        assertEquals(0, StringUtils.countMatches("abcde", ""));
        assertEquals(2, StringUtils.countMatches("abcabc", "a"));
        assertEquals(0, StringUtils.countMatches("abc", "z"));
        assertEquals(3, StringUtils.countMatches("aaa", 'a'));
    }

    @Test
    void testPadding() {
        assertNull(StringUtils.leftPad(null, 3));
        assertEquals("  ab", StringUtils.leftPad("ab", 4));
        assertEquals("ab", StringUtils.leftPad("ab", 1));
        assertEquals("xxab", StringUtils.leftPad("ab", 4, 'x'));

        assertNull(StringUtils.rightPad(null, 3));
        assertEquals("ab  ", StringUtils.rightPad("ab", 4));
        assertEquals("ab", StringUtils.rightPad("ab", 1));
        assertEquals("abxx", StringUtils.rightPad("ab", 4, 'x'));

        assertNull(StringUtils.center(null, 4));
        assertEquals("ab", StringUtils.center("ab", 2));
        assertEquals(" ab ", StringUtils.center("ab", 4));
        assertEquals("xxabxx", StringUtils.center("ab", 6, 'x'));
    }

    @Test
    void testAbbreviateAndTruncate() {
        assertNull(StringUtils.abbreviate(null, 4));
        assertEquals("abcd", StringUtils.abbreviate("abcd", 6));
        assertEquals("abc...", StringUtils.abbreviate("abcdefg", 6));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.abbreviate("abcdefg", 3);
            }
        });

        assertNull(StringUtils.truncate(null, 3));
        assertEquals("", StringUtils.truncate("abcdef", 0));
        assertEquals("abc", StringUtils.truncate("abcdef", 3));
        assertEquals("abcdef", StringUtils.truncate("abcdef", 10));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.truncate("abcdef", -1);
            }
        });
    }

    @Test
    void testDefaultString() {
        assertEquals("", StringUtils.defaultString(null));
        assertEquals("bat", StringUtils.defaultString("bat"));
        assertEquals("NULL", StringUtils.defaultString(null, "NULL"));

        assertEquals("bat", StringUtils.defaultIfEmpty("bat", "NULL"));
        assertEquals("NULL", StringUtils.defaultIfEmpty("", "NULL"));
        assertEquals("NULL", StringUtils.defaultIfEmpty(null, "NULL"));

        assertEquals("bat", StringUtils.defaultIfBlank("bat", "NULL"));
        assertEquals("NULL", StringUtils.defaultIfBlank("  ", "NULL"));
        assertEquals("NULL", StringUtils.defaultIfBlank(null, "NULL"));
    }

    @Test
    void testChompAndDeleteWhitespace() {
        assertNull(StringUtils.chomp(null));
        assertEquals("", StringUtils.chomp(""));
        assertEquals("abc", StringUtils.chomp("abc\n"));
        assertEquals("abc", StringUtils.chomp("abc\r\n"));
        assertEquals("abc", StringUtils.chomp("abc"));

        assertNull(StringUtils.deleteWhitespace(null));
        assertEquals("", StringUtils.deleteWhitespace("  \t  "));
        assertEquals("abc", StringUtils.deleteWhitespace(" a b  c  "));
    }

    @Test
    void testDifferenceAndCompare() {
        assertNull(StringUtils.difference(null, null));
        assertEquals("", StringUtils.difference("", ""));
        assertEquals("", StringUtils.difference("abc", "abc"));
        assertEquals("yz", StringUtils.difference("abc", "abyz"));

        assertEquals(0, StringUtils.compare(null, null));
        assertTrue(StringUtils.compare(null, "a") < 0);
        assertTrue(StringUtils.compare("a", null) > 0);
        assertEquals(0, StringUtils.compare("abc", "abc"));
        assertTrue(StringUtils.compare("abc", "abd") < 0);
    }

    @Test
    void testNormalizeSpaceAndWrap() {
        assertNull(StringUtils.normalizeSpace(null));
        assertEquals("", StringUtils.normalizeSpace("   "));
        assertEquals("a b c", StringUtils.normalizeSpace("  a   b  c  "));

        assertNull(StringUtils.wrap(null, '"'));
        assertEquals("\"abc\"", StringUtils.wrap("abc", '"'));
        assertEquals("", StringUtils.wrap("", '"'));

        assertNull(StringUtils.wrap(null, "[]"));
        assertEquals("[]abc[]", StringUtils.wrap("abc", "[]"));
    }

    @Test
    void testRotateAndGetDigits() {
        assertNull(StringUtils.rotate(null, 2));
        assertEquals("", StringUtils.rotate("", 2));
        assertEquals("abc", StringUtils.rotate("abc", 0));
        assertEquals("deabc", StringUtils.rotate("abcde", 2));
        assertEquals("deabc", StringUtils.rotate("abcde", -3));

        assertNull(StringUtils.getDigits(null));
        assertEquals("", StringUtils.getDigits("abc"));
        assertEquals("12345", StringUtils.getDigits("a1b2c3d4e5"));
    }

    @Test
    void testIdentityShortCircuits() {
        String s = "unchanged";
        assertSame(s, StringUtils.trim(s));
        assertSame(s, StringUtils.left(s, 100));
        assertSame(s, StringUtils.right(s, 100));
    }
}
