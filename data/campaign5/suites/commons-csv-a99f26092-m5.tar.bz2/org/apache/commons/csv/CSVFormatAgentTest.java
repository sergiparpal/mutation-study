/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import org.apache.commons.csv.CSVFormat.Builder;
import org.apache.commons.csv.CSVFormat.Predefined;
import org.junit.jupiter.api.Test;

/**
 * Tests {@link CSVFormat}.
 */
class CSVFormatAgentTest {

    private enum TestHeaderEnum {
        Name, Email, Phone
    }

    @Test
    void testDefaultFormatBasics() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertTrue(format.getIgnoreEmptyLines());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
        assertFalse(format.getAllowMissingColumnNames());
        assertFalse(format.getTrim());
        assertFalse(format.isEscapeCharacterSet());
        assertNull(format.getHeader());
    }

    @Test
    void testExcelFormat() {
        final CSVFormat format = CSVFormat.EXCEL;
        assertFalse(format.getIgnoreEmptyLines());
        assertTrue(format.getAllowMissingColumnNames());
        assertTrue(format.getTrailingData());
        assertTrue(format.getLenientEof());
    }

    @Test
    void testMySqlFormat() {
        final CSVFormat format = CSVFormat.MYSQL;
        assertEquals("\t", format.getDelimiterString());
        assertFalse(format.isQuoteCharacterSet());
        assertEquals("\\N", format.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, format.getQuoteMode());
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
    }

    @Test
    void testTdfFormat() {
        final CSVFormat format = CSVFormat.TDF;
        assertEquals("\t", format.getDelimiterString());
        assertTrue(format.getIgnoreSurroundingSpaces());
    }

    @Test
    void testRfc4180Format() {
        final CSVFormat format = CSVFormat.RFC4180;
        assertFalse(format.getIgnoreEmptyLines());
    }

    @Test
    void testNewFormat() {
        final CSVFormat format = CSVFormat.newFormat(';');
        assertEquals(";", format.getDelimiterString());
        assertNull(format.getQuoteCharacter());
        assertNull(format.getRecordSeparator());
        assertFalse(format.getIgnoreEmptyLines());
        assertNull(format.getHeader());
    }

    @Test
    void testValueOf() {
        assertSame(CSVFormat.DEFAULT, CSVFormat.valueOf(Predefined.Default.name()));
        assertSame(CSVFormat.EXCEL, CSVFormat.valueOf(Predefined.Excel.name()));
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.valueOf("NoSuchFormat"));
    }

    @Test
    void testPredefinedGetFormat() {
        assertEquals(CSVFormat.MYSQL, Predefined.MySQL.getFormat());
        assertEquals(CSVFormat.TDF, Predefined.TDF.getFormat());
    }

    @Test
    void testBuilderSetDelimiterChar() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter('|').get();
        assertEquals("|", format.getDelimiterString());
    }

    @Test
    void testBuilderSetDelimiterRejectsLineBreak() {
        final Builder builder = Builder.create();
        assertThrows(IllegalArgumentException.class, () -> builder.setDelimiter('\n'));
        assertThrows(IllegalArgumentException.class, () -> builder.setDelimiter("\r"));
    }

    @Test
    void testBuilderSetDelimiterRejectsEmptyString() {
        final Builder builder = Builder.create();
        assertThrows(IllegalArgumentException.class, () -> builder.setDelimiter(""));
    }

    @Test
    void testBuilderSetCommentMarkerRejectsLineBreak() {
        final Builder builder = Builder.create();
        assertThrows(IllegalArgumentException.class, () -> builder.setCommentMarker('\n'));
        assertThrows(IllegalArgumentException.class, () -> builder.setCommentMarker(Character.valueOf('\r')));
    }

    @Test
    void testBuilderSetEscapeRejectsLineBreak() {
        final Builder builder = Builder.create();
        assertThrows(IllegalArgumentException.class, () -> builder.setEscape('\n'));
    }

    @Test
    void testBuilderSetQuoteRejectsLineBreak() {
        final Builder builder = Builder.create();
        assertThrows(IllegalArgumentException.class, () -> builder.setQuote('\r'));
    }

    @Test
    void testValidateQuoteAndDelimiterSame() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setDelimiter(',').setQuote('"').setDelimiter("\"").get());
    }

    @Test
    void testValidateEscapeAndDelimiterSame() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setDelimiter(',').setEscape(',').get());
    }

    @Test
    void testValidateCommentAndDelimiterSame() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setDelimiter(',').setCommentMarker(',').get());
    }

    @Test
    void testValidateQuoteAndCommentSame() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setQuote('#').setCommentMarker('#').get());
    }

    @Test
    void testValidateEscapeAndCommentSame() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setEscape('#').setCommentMarker('#').get());
    }

    @Test
    void testValidateQuoteModeNoneRequiresEscape() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setQuoteMode(QuoteMode.NONE).get());
        // Should succeed when escape is set.
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuoteMode(QuoteMode.NONE).setEscape('\\').get();
        assertEquals(QuoteMode.NONE, format.getQuoteMode());
    }

    @Test
    void testValidateDuplicateHeaderNamesDisallowed() {
        assertThrows(IllegalArgumentException.class,
                () -> CSVFormat.DEFAULT.builder().setHeader("A", "B", "A").setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).get());
    }

    @Test
    void testValidateDuplicateHeaderNamesAllowedByDefault() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("A", "B", "A").get();
        assertArrayEquals(new String[] { "A", "B", "A" }, format.getHeader());
    }

    @Test
    void testValidateDuplicateEmptyHeadersAllowEmpty() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("A", "", "").setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).get();
        assertArrayEquals(new String[] { "A", "", "" }, format.getHeader());
    }

    @Test
    void testValidateDuplicateNonEmptyHeadersDisallowedEvenWithAllowEmpty() {
        assertThrows(IllegalArgumentException.class,
                () -> CSVFormat.DEFAULT.builder().setHeader("A", "A").setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).get());
    }

    @Test
    void testSetDuplicateHeaderModeNullThrows() {
        final Builder builder = Builder.create();
        assertThrows(NullPointerException.class, () -> builder.setDuplicateHeaderMode(null));
    }

    @Test
    void testGetHeaderReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("A", "B").get();
        final String[] header1 = format.getHeader();
        header1[0] = "mutated";
        final String[] header2 = format.getHeader();
        assertEquals("A", header2[0]);
        assertNotSame(header1, header2);
    }

    @Test
    void testSetHeaderEnum() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(TestHeaderEnum.class).get();
        assertArrayEquals(new String[] { "Name", "Email", "Phone" }, format.getHeader());
    }

    @Test
    void testSetHeaderEnumNull() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader((Class<? extends Enum<?>>) null).get();
        assertNull(format.getHeader());
    }

    @Test
    void testSetHeaderResultSetMetaData() throws SQLException {
        final ResultSetMetaData metaData = new StubResultSetMetaData(new String[] { "col1", "col2" });
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(metaData).get();
        assertArrayEquals(new String[] { "col1", "col2" }, format.getHeader());
    }

    @Test
    void testSetHeaderResultSet() throws SQLException {
        final ResultSetMetaData metaData = new StubResultSetMetaData(new String[] { "x", "y", "z" });
        final ResultSet resultSet = new StubResultSet(metaData);
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(resultSet).get();
        assertArrayEquals(new String[] { "x", "y", "z" }, format.getHeader());
    }

    @Test
    void testSetHeaderCommentsDefensiveCopy() {
        final Object[] comments = { "line1", "line2" };
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeaderComments(comments).get();
        comments[0] = "mutated";
        assertEquals("line1", format.getHeaderComments()[0]);
    }

    @Test
    void testGetHeaderCommentsReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeaderComments("a", "b").get();
        final String[] comments1 = format.getHeaderComments();
        comments1[0] = "mutated";
        assertEquals("a", format.getHeaderComments()[0]);
    }

    @Test
    void testFormatValues() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertEquals("a,b,c", format.format("a", "b", "c"));
    }

    @Test
    void testFormatQuotesValueWithDelimiter() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertEquals("a,\"b,c\",d", format.format("a", "b,c", "d"));
    }

    @Test
    void testFormatNullValue() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertEquals(",a", format.format((Object) null, "a"));
    }

    @Test
    void testPrintRecordAndAppendable() throws IOException {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.printRecord(sb, "a", "b");
        assertEquals("a,b\r\n", sb.toString());
    }

    @Test
    void testPrintlnTrailingDelimiter() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).setRecordSeparator('\n').get();
        final StringBuilder sb = new StringBuilder();
        format.println(sb);
        assertEquals(",\n", sb.toString());
    }

    @Test
    void testPrintReaderValueWithQuoting() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT;
        final StringBuilder sb = new StringBuilder();
        final Reader reader = new StringReader("x\"y");
        format.print(reader, sb, true);
        assertEquals("\"x\"\"y\"", sb.toString());
    }

    @Test
    void testToStringContainsDelimiter() {
        final String s = CSVFormat.DEFAULT.toString();
        assertTrue(s.contains("Delimiter=<,>"));
    }

    @Test
    void testEqualsAndHashCode() {
        final CSVFormat a = CSVFormat.DEFAULT.builder().setDelimiter(',').get();
        final CSVFormat b = CSVFormat.DEFAULT.builder().setDelimiter(',').get();
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
        assertNotEquals(a, CSVFormat.DEFAULT.builder().setDelimiter(';').get());
        assertNotEquals(a, null);
        assertNotEquals(a, "not a format");
        assertEquals(a, a);
    }

    @Test
    void testCopyProducesEqualButDistinctInstance() {
        final CSVFormat original = CSVFormat.DEFAULT.builder().setHeader("A").get();
        final CSVFormat copy = CSVFormat.copy(original);
        assertEquals(original, copy);
        assertNotSame(original, copy);
        assertNull(CSVFormat.copy(null));
    }

    @Test
    void testBuilderCreateFromFormatCopiesSettings() {
        final CSVFormat original = CSVFormat.DEFAULT.builder().setDelimiter('|').setNullString("NULL").setTrim(true).get();
        final CSVFormat rebuilt = Builder.create(original).get();
        assertEquals(original, rebuilt);
    }

    @Test
    void testGetMaxRowsDefaultIsZero() {
        assertEquals(0L, CSVFormat.DEFAULT.getMaxRows());
        assertFalse(CSVFormat.DEFAULT.useMaxRows());
    }

    @Test
    void testSetMaxRows() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(5L).get();
        assertEquals(5L, format.getMaxRows());
        assertTrue(format.useMaxRows());
        assertTrue(format.useRow(5L));
        assertFalse(format.useRow(6L));
    }

    @Test
    void testNullStringAndQuotedNullString() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuote('"').setNullString("NULL").setQuoteMode(QuoteMode.ALL).get();
        assertTrue(format.isNullStringSet());
        assertEquals("\"NULL\"", format.format((Object) null));
    }

    @Test
    void testDeprecatedGetDelimiterReturnsFirstChar() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter(',').get();
        assertEquals(',', format.getDelimiter());
    }

    @Test
    void testDeprecatedAllowDuplicateHeaderNamesGetter() {
        final CSVFormat allowed = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_ALL).get();
        assertTrue(allowed.getAllowDuplicateHeaderNames());
        final CSVFormat disallowed = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).get();
        assertFalse(disallowed.getAllowDuplicateHeaderNames());
    }

    @Test
    void testWithFirstRecordAsHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.withFirstRecordAsHeader();
        assertTrue(format.getSkipHeaderRecord());
        assertArrayEquals(new String[0], format.getHeader());
    }

    @Test
    void testWithNullStringDeprecated() {
        final CSVFormat format = CSVFormat.DEFAULT.withNullString("N/A");
        assertEquals("N/A", format.getNullString());
    }

    @Test
    void testWithTrailingDelimiterDeprecated() {
        final CSVFormat format = CSVFormat.DEFAULT.withTrailingDelimiter();
        assertTrue(format.getTrailingDelimiter());
    }

    @Test
    void testWithTrimDeprecated() {
        final CSVFormat format = CSVFormat.DEFAULT.withTrim();
        assertTrue(format.getTrim());
    }

    @Test
    void testParseReturnsParserOverRecords() throws IOException {
        final CSVParser parser = CSVFormat.DEFAULT.parse(new StringReader("a,b\r\n1,2\r\n"));
        try {
            final CSVRecord record = parser.iterator().next();
            assertEquals("a", record.get(0));
            assertEquals("b", record.get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    void testPrintReturnsUsablePrinter() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = CSVFormat.DEFAULT.print(sb);
        try {
            printer.printRecord("1", "2");
        } finally {
            printer.close();
        }
        assertEquals("1,2\r\n", sb.toString());
    }

    @Test
    void testEscapeCharacterSetAndGetEscapeCharacter() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        assertTrue(format.isEscapeCharacterSet());
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
    }

    @Test
    void testQuoteCharacterNullDisablesQuoting() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuote((Character) null).get();
        assertFalse(format.isQuoteCharacterSet());
        assertNull(format.getQuoteCharacter());
    }

    /** Minimal stub, only what setHeader(ResultSetMetaData) needs. */
    private static final class StubResultSetMetaData implements ResultSetMetaData {
        private final String[] labels;

        StubResultSetMetaData(final String[] labels) {
            this.labels = labels;
        }

        @Override
        public int getColumnCount() {
            return labels.length;
        }

        @Override
        public String getColumnLabel(final int column) {
            return labels[column - 1];
        }

        @Override
        public <T> T unwrap(final Class<T> iface) {
            return null;
        }

        @Override
        public boolean isWrapperFor(final Class<?> iface) {
            return false;
        }

        @Override
        public boolean isAutoIncrement(final int column) {
            return false;
        }

        @Override
        public boolean isCaseSensitive(final int column) {
            return false;
        }

        @Override
        public boolean isSearchable(final int column) {
            return false;
        }

        @Override
        public boolean isCurrency(final int column) {
            return false;
        }

        @Override
        public int isNullable(final int column) {
            return 0;
        }

        @Override
        public boolean isSigned(final int column) {
            return false;
        }

        @Override
        public int getColumnDisplaySize(final int column) {
            return 0;
        }

        @Override
        public String getColumnName(final int column) {
            return labels[column - 1];
        }

        @Override
        public String getSchemaName(final int column) {
            return "";
        }

        @Override
        public int getPrecision(final int column) {
            return 0;
        }

        @Override
        public int getScale(final int column) {
            return 0;
        }

        @Override
        public String getTableName(final int column) {
            return "";
        }

        @Override
        public String getCatalogName(final int column) {
            return "";
        }

        @Override
        public int getColumnType(final int column) {
            return 0;
        }

        @Override
        public String getColumnTypeName(final int column) {
            return "";
        }

        @Override
        public boolean isReadOnly(final int column) {
            return false;
        }

        @Override
        public boolean isWritable(final int column) {
            return false;
        }

        @Override
        public boolean isDefinitelyWritable(final int column) {
            return false;
        }

        @Override
        public String getColumnClassName(final int column) {
            return "";
        }
    }

    /** Minimal stub, only what setHeader(ResultSet) needs. */
    private static final class StubResultSet implements ResultSet {
        private final ResultSetMetaData metaData;

        StubResultSet(final ResultSetMetaData metaData) {
            this.metaData = metaData;
        }

        @Override
        public ResultSetMetaData getMetaData() {
            return metaData;
        }

        @Override
        public <T> T unwrap(final Class<T> iface) {
            return null;
        }

        @Override
        public boolean isWrapperFor(final Class<?> iface) {
            return false;
        }

        @Override
        public boolean next() {
            return false;
        }

        @Override
        public void close() {
            // no-op
        }

        @Override
        public boolean wasNull() {
            return false;
        }

        @Override
        public String getString(final int columnIndex) {
            return null;
        }

        @Override
        public boolean getBoolean(final int columnIndex) {
            return false;
        }

        @Override
        public byte getByte(final int columnIndex) {
            return 0;
        }

        @Override
        public short getShort(final int columnIndex) {
            return 0;
        }

        @Override
        public int getInt(final int columnIndex) {
            return 0;
        }

        @Override
        public long getLong(final int columnIndex) {
            return 0;
        }

        @Override
        public float getFloat(final int columnIndex) {
            return 0;
        }

        @Override
        public double getDouble(final int columnIndex) {
            return 0;
        }

        @Override
        public java.math.BigDecimal getBigDecimal(final int columnIndex, final int scale) {
            return null;
        }

        @Override
        public byte[] getBytes(final int columnIndex) {
            return null;
        }

        @Override
        public java.sql.Date getDate(final int columnIndex) {
            return null;
        }

        @Override
        public java.sql.Time getTime(final int columnIndex) {
            return null;
        }

        @Override
        public java.sql.Timestamp getTimestamp(final int columnIndex) {
            return null;
        }

        @Override
        public java.io.InputStream getAsciiStream(final int columnIndex) {
            return null;
        }

        @Override
        public java.io.InputStream getUnicodeStream(final int columnIndex) {
            return null;
        }

        @Override
        public java.io.InputStream getBinaryStream(final int columnIndex) {
            return null;
        }

        @Override
        public String getString(final String columnLabel) {
            return null;
        }

        @Override
        public boolean getBoolean(final String columnLabel) {
            return false;
        }

        @Override
        public byte getByte(final String columnLabel) {
            return 0;
        }

        @Override
        public short getShort(final String columnLabel) {
            return 0;
        }

        @Override
        public int getInt(final String columnLabel) {
            return 0;
        }

        @Override
        public long getLong(final String columnLabel) {
            return 0;
        }

        @Override
        public float getFloat(final String columnLabel) {
            return 0;
        }

        @Override
        public double getDouble(final String columnLabel) {
            return 0;
        }

        @Override
        public java.math.BigDecimal getBigDecimal(final String columnLabel, final int scale) {
            return null;
        }

        @Override
        public byte[] getBytes(final String columnLabel) {
            return null;
        }

        @Override
        public java.sql.Date getDate(final String columnLabel) {
            return null;
        }

        @Override
        public java.sql.Time getTime(final String columnLabel) {
            return null;
        }

        @Override
        public java.sql.Timestamp getTimestamp(final String columnLabel) {
            return null;
        }

        @Override
        public java.io.InputStream getAsciiStream(final String columnLabel) {
            return null;
        }

        @Override
        public java.io.InputStream getUnicodeStream(final String columnLabel) {
            return null;
        }

        @Override
        public java.io.InputStream getBinaryStream(final String columnLabel) {
            return null;
        }

        @Override
        public String getCursorName() {
            return null;
        }

        @Override
        public java.sql.SQLWarning getWarnings() {
            return null;
        }

        @Override
        public void clearWarnings() {
            // no-op
        }

        @Override
        public java.io.Reader getCharacterStream(final int columnIndex) {
            return null;
        }

        @Override
        public java.io.Reader getCharacterStream(final String columnLabel) {
            return null;
        }

        @Override
        public java.math.BigDecimal getBigDecimal(final int columnIndex) {
            return null;
        }

        @Override
        public java.math.BigDecimal getBigDecimal(final String columnLabel) {
            return null;
        }

        @Override
        public boolean isBeforeFirst() {
            return false;
        }

        @Override
        public boolean isAfterLast() {
            return false;
        }

        @Override
        public boolean isFirst() {
            return false;
        }

        @Override
        public boolean isLast() {
            return false;
        }

        @Override
        public void beforeFirst() {
            // no-op
        }

        @Override
        public void afterLast() {
            // no-op
        }

        @Override
        public boolean first() {
            return false;
        }

        @Override
        public boolean last() {
            return false;
        }

        @Override
        public int getRow() {
            return 0;
        }

        @Override
        public boolean absolute(final int row) {
            return false;
        }

        @Override
        public boolean relative(final int rows) {
            return false;
        }

        @Override
        public boolean previous() {
            return false;
        }

        @Override
        public void setFetchDirection(final int direction) {
            // no-op
        }

        @Override
        public int getFetchDirection() {
            return 0;
        }

        @Override
        public void setFetchSize(final int rows) {
            // no-op
        }

        @Override
        public int getFetchSize() {
            return 0;
        }

        @Override
        public int getType() {
            return 0;
        }

        @Override
        public int getConcurrency() {
            return 0;
        }

        @Override
        public boolean rowUpdated() {
            return false;
        }

        @Override
        public boolean rowInserted() {
            return false;
        }

        @Override
        public boolean rowDeleted() {
            return false;
        }

        @Override
        public void updateNull(final int columnIndex) {
            // no-op
        }

        @Override
        public void updateBoolean(final int columnIndex, final boolean x) {
            // no-op
        }

        @Override
        public void updateByte(final int columnIndex, final byte x) {
            // no-op
        }

        @Override
        public void updateShort(final int columnIndex, final short x) {
            // no-op
        }

        @Override
        public void updateInt(final int columnIndex, final int x) {
            // no-op
        }

        @Override
        public void updateLong(final int columnIndex, final long x) {
            // no-op
        }

        @Override
        public void updateFloat(final int columnIndex, final float x) {
            // no-op
        }

        @Override
        public void updateDouble(final int columnIndex, final double x) {
            // no-op
        }

        @Override
        public void updateBigDecimal(final int columnIndex, final java.math.BigDecimal x) {
            // no-op
        }

        @Override
        public void updateString(final int columnIndex, final String x) {
            // no-op
        }

        @Override
        public void updateBytes(final int columnIndex, final byte[] x) {
            // no-op
        }

        @Override
        public void updateDate(final int columnIndex, final java.sql.Date x) {
            // no-op
        }

        @Override
        public void updateTime(final int columnIndex, final java.sql.Time x) {
            // no-op
        }

        @Override
        public void updateTimestamp(final int columnIndex, final java.sql.Timestamp x) {
            // no-op
        }

        @Override
        public void updateAsciiStream(final int columnIndex, final java.io.InputStream x, final int length) {
            // no-op
        }

        @Override
        public void updateBinaryStream(final int columnIndex, final java.io.InputStream x, final int length) {
            // no-op
        }

        @Override
        public void updateCharacterStream(final int columnIndex, final java.io.Reader x, final int length) {
            // no-op
        }

        @Override
        public void updateObject(final int columnIndex, final Object x, final int scaleOrLength) {
            // no-op
        }

        @Override
        public void updateObject(final int columnIndex, final Object x) {
            // no-op
        }

        @Override
        public void updateNull(final String columnLabel) {
            // no-op
        }

        @Override
        public void updateBoolean(final String columnLabel, final boolean x) {
            // no-op
        }

        @Override
        public void updateByte(final String columnLabel, final byte x) {
            // no-op
        }

        @Override
        public void updateShort(final String columnLabel, final short x) {
            // no-op
        }

        @Override
        public void updateInt(final String columnLabel, final int x) {
            // no-op
        }

        @Override
        public void updateLong(final String columnLabel, final long x) {
            // no-op
        }

        @Override
        public void updateFloat(final String columnLabel, final float x) {
            // no-op
        }

        @Override
        public void updateDouble(final String columnLabel, final double x) {
            // no-op
        }

        @Override
        public void updateBigDecimal(final String columnLabel, final java.math.BigDecimal x) {
            // no-op
        }

        @Override
        public void updateString(final String columnLabel, final String x) {
            // no-op
        }

        @Override
        public void updateBytes(final String columnLabel, final byte[] x) {
            // no-op
        }

        @Override
        public void updateDate(final String columnLabel, final java.sql.Date x) {
            // no-op
        }

        @Override
        public void updateTime(final String columnLabel, final java.sql.Time x) {
            // no-op
        }

        @Override
        public void updateTimestamp(final String columnLabel, final java.sql.Timestamp x) {
            // no-op
        }

        @Override
        public void updateAsciiStream(final String columnLabel, final java.io.InputStream x, final int length) {
            // no-op
        }

        @Override
        public void updateBinaryStream(final String columnLabel, final java.io.InputStream x, final int length) {
            // no-op
        }

        @Override
        public void updateCharacterStream(final String columnLabel, final java.io.Reader reader, final int length) {
            // no-op
        }

        @Override
        public void updateObject(final String columnLabel, final Object x, final int scaleOrLength) {
            // no-op
        }

        @Override
        public void updateObject(final String columnLabel, final Object x) {
            // no-op
        }

        @Override
        public void insertRow() {
            // no-op
        }

        @Override
        public void updateRow() {
            // no-op
        }

        @Override
        public void deleteRow() {
            // no-op
        }

        @Override
        public void refreshRow() {
            // no-op
        }

        @Override
        public void cancelRowUpdates() {
            // no-op
        }

        @Override
        public void moveToInsertRow() {
            // no-op
        }

        @Override
        public void moveToCurrentRow() {
            // no-op
        }

        @Override
        public java.sql.Statement getStatement() {
            return null;
        }

        @Override
        public Object getObject(final int columnIndex, final java.util.Map<String, Class<?>> map) {
            return null;
        }

        @Override
        public java.sql.Ref getRef(final int columnIndex) {
            return null;
        }

        @Override
        public java.sql.Blob getBlob(final int columnIndex) {
            return null;
        }

        @Override
        public java.sql.Clob getClob(final int columnIndex) {
            return null;
        }

        @Override
        public java.sql.Array getArray(final int columnIndex) {
            return null;
        }

        @Override
        public Object getObject(final String columnLabel, final java.util.Map<String, Class<?>> map) {
            return null;
        }

        @Override
        public java.sql.Ref getRef(final String columnLabel) {
            return null;
        }

        @Override
        public java.sql.Blob getBlob(final String columnLabel) {
            return null;
        }

        @Override
        public java.sql.Clob getClob(final String columnLabel) {
            return null;
        }

        @Override
        public java.sql.Array getArray(final String columnLabel) {
            return null;
        }

        @Override
        public java.sql.Date getDate(final int columnIndex, final java.util.Calendar cal) {
            return null;
        }

        @Override
        public java.sql.Date getDate(final String columnLabel, final java.util.Calendar cal) {
            return null;
        }

        @Override
        public java.sql.Time getTime(final int columnIndex, final java.util.Calendar cal) {
            return null;
        }

        @Override
        public java.sql.Time getTime(final String columnLabel, final java.util.Calendar cal) {
            return null;
        }

        @Override
        public java.sql.Timestamp getTimestamp(final int columnIndex, final java.util.Calendar cal) {
            return null;
        }

        @Override
        public java.sql.Timestamp getTimestamp(final String columnLabel, final java.util.Calendar cal) {
            return null;
        }

        @Override
        public java.net.URL getURL(final int columnIndex) {
            return null;
        }

        @Override
        public java.net.URL getURL(final String columnLabel) {
            return null;
        }

        @Override
        public void updateRef(final int columnIndex, final java.sql.Ref x) {
            // no-op
        }

        @Override
        public void updateRef(final String columnLabel, final java.sql.Ref x) {
            // no-op
        }

        @Override
        public void updateBlob(final int columnIndex, final java.sql.Blob x) {
            // no-op
        }

        @Override
        public void updateBlob(final String columnLabel, final java.sql.Blob x) {
            // no-op
        }

        @Override
        public void updateClob(final int columnIndex, final java.sql.Clob x) {
            // no-op
        }

        @Override
        public void updateClob(final String columnLabel, final java.sql.Clob x) {
            // no-op
        }

        @Override
        public void updateArray(final int columnIndex, final java.sql.Array x) {
            // no-op
        }

        @Override
        public void updateArray(final String columnLabel, final java.sql.Array x) {
            // no-op
        }

        @Override
        public java.sql.RowId getRowId(final int columnIndex) {
            return null;
        }

        @Override
        public java.sql.RowId getRowId(final String columnLabel) {
            return null;
        }

        @Override
        public void updateRowId(final int columnIndex, final java.sql.RowId x) {
            // no-op
        }

        @Override
        public void updateRowId(final String columnLabel, final java.sql.RowId x) {
            // no-op
        }

        @Override
        public int getHoldability() {
            return 0;
        }

        @Override
        public boolean isClosed() {
            return false;
        }

        @Override
        public void updateNString(final int columnIndex, final String nString) {
            // no-op
        }

        @Override
        public void updateNString(final String columnLabel, final String nString) {
            // no-op
        }

        @Override
        public void updateNClob(final int columnIndex, final java.sql.NClob nClob) {
            // no-op
        }

        @Override
        public void updateNClob(final String columnLabel, final java.sql.NClob nClob) {
            // no-op
        }

        @Override
        public java.sql.NClob getNClob(final int columnIndex) {
            return null;
        }

        @Override
        public java.sql.NClob getNClob(final String columnLabel) {
            return null;
        }

        @Override
        public java.sql.SQLXML getSQLXML(final int columnIndex) {
            return null;
        }

        @Override
        public java.sql.SQLXML getSQLXML(final String columnLabel) {
            return null;
        }

        @Override
        public void updateSQLXML(final int columnIndex, final java.sql.SQLXML xmlObject) {
            // no-op
        }

        @Override
        public void updateSQLXML(final String columnLabel, final java.sql.SQLXML xmlObject) {
            // no-op
        }

        @Override
        public String getNString(final int columnIndex) {
            return null;
        }

        @Override
        public String getNString(final String columnLabel) {
            return null;
        }

        @Override
        public java.io.Reader getNCharacterStream(final int columnIndex) {
            return null;
        }

        @Override
        public java.io.Reader getNCharacterStream(final String columnLabel) {
            return null;
        }

        @Override
        public void updateNCharacterStream(final int columnIndex, final java.io.Reader x, final long length) {
            // no-op
        }

        @Override
        public void updateNCharacterStream(final String columnLabel, final java.io.Reader reader, final long length) {
            // no-op
        }

        @Override
        public void updateAsciiStream(final int columnIndex, final java.io.InputStream x, final long length) {
            // no-op
        }

        @Override
        public void updateBinaryStream(final int columnIndex, final java.io.InputStream x, final long length) {
            // no-op
        }

        @Override
        public void updateCharacterStream(final int columnIndex, final java.io.Reader x, final long length) {
            // no-op
        }

        @Override
        public void updateAsciiStream(final String columnLabel, final java.io.InputStream x, final long length) {
            // no-op
        }

        @Override
        public void updateBinaryStream(final String columnLabel, final java.io.InputStream x, final long length) {
            // no-op
        }

        @Override
        public void updateCharacterStream(final String columnLabel, final java.io.Reader reader, final long length) {
            // no-op
        }

        @Override
        public void updateBlob(final int columnIndex, final java.io.InputStream inputStream, final long length) {
            // no-op
        }

        @Override
        public void updateBlob(final String columnLabel, final java.io.InputStream inputStream, final long length) {
            // no-op
        }

        @Override
        public void updateClob(final int columnIndex, final java.io.Reader reader, final long length) {
            // no-op
        }

        @Override
        public void updateClob(final String columnLabel, final java.io.Reader reader, final long length) {
            // no-op
        }

        @Override
        public void updateNClob(final int columnIndex, final java.io.Reader reader, final long length) {
            // no-op
        }

        @Override
        public void updateNClob(final String columnLabel, final java.io.Reader reader, final long length) {
            // no-op
        }

        @Override
        public void updateNCharacterStream(final int columnIndex, final java.io.Reader x) {
            // no-op
        }

        @Override
        public void updateNCharacterStream(final String columnLabel, final java.io.Reader reader) {
            // no-op
        }

        @Override
        public void updateAsciiStream(final int columnIndex, final java.io.InputStream x) {
            // no-op
        }

        @Override
        public void updateBinaryStream(final int columnIndex, final java.io.InputStream x) {
            // no-op
        }

        @Override
        public void updateCharacterStream(final int columnIndex, final java.io.Reader x) {
            // no-op
        }

        @Override
        public void updateAsciiStream(final String columnLabel, final java.io.InputStream x) {
            // no-op
        }

        @Override
        public void updateBinaryStream(final String columnLabel, final java.io.InputStream x) {
            // no-op
        }

        @Override
        public void updateCharacterStream(final String columnLabel, final java.io.Reader reader) {
            // no-op
        }

        @Override
        public void updateBlob(final int columnIndex, final java.io.InputStream inputStream) {
            // no-op
        }

        @Override
        public void updateBlob(final String columnLabel, final java.io.InputStream inputStream) {
            // no-op
        }

        @Override
        public void updateClob(final int columnIndex, final java.io.Reader reader) {
            // no-op
        }

        @Override
        public void updateClob(final String columnLabel, final java.io.Reader reader) {
            // no-op
        }

        @Override
        public void updateNClob(final int columnIndex, final java.io.Reader reader) {
            // no-op
        }

        @Override
        public void updateNClob(final String columnLabel, final java.io.Reader reader) {
            // no-op
        }

        @Override
        public <T> T getObject(final int columnIndex, final Class<T> type) {
            return null;
        }

        @Override
        public <T> T getObject(final String columnLabel, final Class<T> type) {
            return null;
        }

        @Override
        public Object getObject(final int columnIndex) {
            return null;
        }

        @Override
        public Object getObject(final String columnLabel) {
            return null;
        }

        @Override
        public int findColumn(final String columnLabel) {
            return 0;
        }
    }
}
