/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.IOException;
import java.io.Serializable;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.ClassUtils.Interfaces;
import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link MethodUtils}.
 */
public class MethodUtilsAgentTest {

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    private @interface AgentMarker {
    }

    public interface AgentGreeter {
        String greet();
    }

    private static class AgentPrivateImpl implements AgentGreeter {
        @Override
        public String greet() {
            return "hi";
        }
    }

    public static class AgentAnnotatedBase {
        @AgentMarker
        public void annotated() {
        }

        public void plain() {
        }
    }

    public static class AgentAnnotatedSub extends AgentAnnotatedBase {
        @Override
        public void annotated() {
        }
    }

    public static class AgentAmbiguous {
        public void process(final Number n) {
        }

        public void process(final Serializable s) {
        }
    }

    public interface AgentShape {
        String name();
    }

    public static class AgentCircle implements AgentShape {
        @Override
        public String name() {
            return "circle";
        }
    }

    public static class AgentOps {

        public static String staticOp(final String s) {
            return "static-" + s;
        }

        public String noArgs() {
            return "no-args";
        }

        public String greet(final String name) {
            return "Hello " + name;
        }

        public String sum(final int a, final int b) {
            return String.valueOf(a + b);
        }

        public String concat(final String prefix, final int... nums) {
            final StringBuilder sb = new StringBuilder(prefix);
            for (final int n : nums) {
                sb.append(n);
            }
            return sb.toString();
        }

        @SuppressWarnings("unused")
        private String secret() {
            return "secret";
        }

        public String explode() throws IOException {
            throw new IOException("boom");
        }

        public void overload(final Object o) {
        }

        public void overload(final String s) {
        }
    }

    // --- getAccessibleMethod ---

    @Test
    public void testGetAccessibleMethodFromNonPublicClassFindsInterfaceMethod() throws Exception {
        final Method accessible = MethodUtils.getAccessibleMethod(AgentPrivateImpl.class, "greet");
        assertNotNull(accessible);
        assertEquals(AgentGreeter.class, accessible.getDeclaringClass());
        assertEquals("hi", accessible.invoke(new AgentPrivateImpl()));
    }

    @Test
    public void testGetAccessibleMethodNotFoundReturnsNull() {
        assertNull(MethodUtils.getAccessibleMethod(AgentOps.class, "doesNotExist"));
    }

    @Test
    public void testGetAccessibleMethodNullMethodReturnsNull() {
        assertNull(MethodUtils.getAccessibleMethod((Method) null));
    }

    // --- getMatchingAccessibleMethod ---

    @Test
    public void testGetMatchingAccessibleMethodExact() {
        final Method m = MethodUtils.getMatchingAccessibleMethod(AgentOps.class, "greet", String.class);
        assertNotNull(m);
        assertEquals("greet", m.getName());
    }

    @Test
    public void testGetMatchingAccessibleMethodVarargsCompatible() {
        final Method m = MethodUtils.getMatchingAccessibleMethod(AgentOps.class, "concat", String.class, Integer.class, Integer.class);
        assertNotNull(m);
        assertTrue(m.isVarArgs());
    }

    @Test
    public void testGetMatchingAccessibleMethodVarargsIncompatibleReturnsNull() {
        final Method m = MethodUtils.getMatchingAccessibleMethod(AgentOps.class, "concat", String.class, Object.class);
        assertNull(m);
    }

    @Test
    public void testGetMatchingAccessibleMethodNoMatchReturnsNull() {
        assertNull(MethodUtils.getMatchingAccessibleMethod(AgentOps.class, "noArgs", String.class));
    }

    // --- getMatchingMethod ---

    @Test
    public void testGetMatchingMethodExact() {
        final Method m = MethodUtils.getMatchingMethod(AgentOps.class, "secret");
        assertNotNull(m);
        assertEquals("secret", m.getName());
    }

    @Test
    public void testGetMatchingMethodNotFoundReturnsNull() {
        assertNull(MethodUtils.getMatchingMethod(AgentOps.class, "greet", Integer.class, Integer.class, Integer.class));
    }

    @Test
    public void testGetMatchingMethodNullClassThrowsNpe() {
        try {
            MethodUtils.getMatchingMethod(null, "greet");
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    public void testGetMatchingMethodNullNameThrowsNpe() {
        try {
            MethodUtils.getMatchingMethod(AgentOps.class, null);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    public void testGetMatchingMethodEmptyNameThrowsIllegalArgument() {
        try {
            MethodUtils.getMatchingMethod(AgentOps.class, "");
            fail("expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    public void testGetMatchingMethodAmbiguousThrowsIllegalState() {
        try {
            MethodUtils.getMatchingMethod(AgentAmbiguous.class, "process", Integer.class);
            fail("expected IllegalStateException");
        } catch (final IllegalStateException expected) {
            // expected
        }
    }

    // --- getMethodObject ---

    @Test
    public void testGetMethodObjectFound() {
        final Method m = MethodUtils.getMethodObject(AgentOps.class, "greet", String.class);
        assertNotNull(m);
        assertEquals("greet", m.getName());
    }

    @Test
    public void testGetMethodObjectNotFoundReturnsNull() {
        assertNull(MethodUtils.getMethodObject(AgentOps.class, "doesNotExist"));
    }

    @Test
    public void testGetMethodObjectNullArgsReturnNull() {
        assertNull(MethodUtils.getMethodObject(null, "greet", String.class));
        assertNull(MethodUtils.getMethodObject(AgentOps.class, null));
    }

    // --- getAnnotation ---

    @Test
    public void testGetAnnotationDirectlyPresent() throws Exception {
        final Method m = AgentAnnotatedBase.class.getMethod("annotated");
        final AgentMarker marker = MethodUtils.getAnnotation(m, AgentMarker.class, false, false);
        assertNotNull(marker);
    }

    @Test
    public void testGetAnnotationNoSearchSupersReturnsNullWhenOverridden() throws Exception {
        final Method m = AgentAnnotatedSub.class.getMethod("annotated");
        assertNull(MethodUtils.getAnnotation(m, AgentMarker.class, false, false));
    }

    @Test
    public void testGetAnnotationSearchSupersFindsInherited() throws Exception {
        final Method m = AgentAnnotatedSub.class.getMethod("annotated");
        final AgentMarker marker = MethodUtils.getAnnotation(m, AgentMarker.class, true, false);
        assertNotNull(marker);
    }

    @Test
    public void testGetAnnotationAbsentReturnsNull() throws Exception {
        final Method m = AgentAnnotatedBase.class.getMethod("plain");
        assertNull(MethodUtils.getAnnotation(m, AgentMarker.class, true, false));
    }

    @Test
    public void testGetAnnotationNullMethodThrowsNpe() {
        try {
            MethodUtils.getAnnotation(null, AgentMarker.class, false, false);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    // --- getMethodsListWithAnnotation / getMethodsWithAnnotation ---

    @Test
    public void testGetMethodsListWithAnnotationFindsDirect() {
        final List<Method> methods = MethodUtils.getMethodsListWithAnnotation(AgentAnnotatedBase.class, AgentMarker.class);
        assertEquals(1, methods.size());
        assertEquals("annotated", methods.get(0).getName());
    }

    @Test
    public void testGetMethodsListWithAnnotationNoneFound() {
        final List<Method> methods = MethodUtils.getMethodsListWithAnnotation(AgentOps.class, AgentMarker.class);
        assertTrue(methods.isEmpty());
    }

    @Test
    public void testGetMethodsListWithAnnotationNullClassThrowsNpe() {
        try {
            MethodUtils.getMethodsListWithAnnotation(null, AgentMarker.class);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    public void testGetMethodsListWithAnnotationNullAnnotationThrowsNpe() {
        try {
            MethodUtils.getMethodsListWithAnnotation(AgentOps.class, null);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    @Test
    public void testGetMethodsWithAnnotationReturnsArray() {
        final Method[] methods = MethodUtils.getMethodsWithAnnotation(AgentAnnotatedBase.class, AgentMarker.class);
        assertEquals(1, methods.length);
    }

    // --- getOverrideHierarchy ---

    @Test
    public void testGetOverrideHierarchyIncludeInterfaces() throws Exception {
        final Method m = AgentCircle.class.getMethod("name");
        final Set<Method> hierarchy = MethodUtils.getOverrideHierarchy(m, Interfaces.INCLUDE);
        assertEquals(2, hierarchy.size());
    }

    @Test
    public void testGetOverrideHierarchyExcludeInterfaces() throws Exception {
        final Method m = AgentCircle.class.getMethod("name");
        final Set<Method> hierarchy = MethodUtils.getOverrideHierarchy(m, Interfaces.EXCLUDE);
        assertEquals(1, hierarchy.size());
    }

    @Test
    public void testGetOverrideHierarchyNullThrowsNpe() {
        try {
            MethodUtils.getOverrideHierarchy(null, Interfaces.INCLUDE);
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
    }

    // --- invokeMethod ---

    @Test
    public void testInvokeMethodNoArgs() throws Exception {
        assertEquals("no-args", MethodUtils.invokeMethod(new AgentOps(), "noArgs"));
    }

    @Test
    public void testInvokeMethodWithArgs() throws Exception {
        assertEquals("Hello World", MethodUtils.invokeMethod(new AgentOps(), "greet", "World"));
    }

    @Test
    public void testInvokeMethodPrimitiveArgs() throws Exception {
        assertEquals("3", MethodUtils.invokeMethod(new AgentOps(), "sum", Integer.valueOf(1), Integer.valueOf(2)));
    }

    @Test
    public void testInvokeMethodVarargs() throws Exception {
        final Object result = MethodUtils.invokeMethod(new AgentOps(), "concat", "p", Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(3));
        assertEquals("p123", result);
    }

    @Test
    public void testInvokeMethodPrivateWithoutForceAccessThrows() {
        try {
            MethodUtils.invokeMethod(new AgentOps(), "secret");
            fail("expected NoSuchMethodException");
        } catch (final NoSuchMethodException expected) {
            // expected
        } catch (final Exception e) {
            fail("expected NoSuchMethodException but got " + e);
        }
    }

    @Test
    public void testInvokeMethodPrivateWithForceAccess() throws Exception {
        assertEquals("secret", MethodUtils.invokeMethod(new AgentOps(), true, "secret"));
    }

    @Test
    public void testInvokeMethodCheckedExceptionWrapped() {
        try {
            MethodUtils.invokeMethod(new AgentOps(), "explode");
            fail("expected InvocationTargetException");
        } catch (final InvocationTargetException expected) {
            assertTrue(expected.getCause() instanceof IOException);
            assertEquals("boom", expected.getCause().getMessage());
        } catch (final Exception e) {
            fail("expected InvocationTargetException but got " + e);
        }
    }

    @Test
    public void testInvokeMethodNullObjectThrowsNpe() {
        try {
            MethodUtils.invokeMethod(null, "greet", "World");
            fail("expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        } catch (final Exception e) {
            fail("expected NullPointerException but got " + e);
        }
    }

    // --- invokeStaticMethod ---

    @Test
    public void testInvokeStaticMethodBasic() throws Exception {
        assertEquals("static-X", MethodUtils.invokeStaticMethod(AgentOps.class, "staticOp", "X"));
    }

    @Test
    public void testInvokeStaticMethodNotFoundThrowsNoSuchMethod() {
        try {
            MethodUtils.invokeStaticMethod(AgentOps.class, "doesNotExist");
            fail("expected NoSuchMethodException");
        } catch (final NoSuchMethodException expected) {
            // expected
        } catch (final Exception e) {
            fail("expected NoSuchMethodException but got " + e);
        }
    }

    // --- invokeExactMethod / invokeExactStaticMethod ---

    @Test
    public void testInvokeExactMethodMatch() throws Exception {
        assertEquals("Hello World", MethodUtils.invokeExactMethod(new AgentOps(), "greet", "World"));
    }

    @Test
    public void testInvokeExactMethodNoExactMatchThrows() {
        try {
            MethodUtils.invokeExactMethod(new AgentOps(), "greet", Integer.valueOf(1));
            fail("expected NoSuchMethodException");
        } catch (final NoSuchMethodException expected) {
            // expected
        } catch (final Exception e) {
            fail("expected NoSuchMethodException but got " + e);
        }
    }

    @Test
    public void testInvokeExactStaticMethodMatch() throws Exception {
        assertEquals("static-X", MethodUtils.invokeExactStaticMethod(AgentOps.class, "staticOp", "X"));
    }

    @Test
    public void testInvokeExactStaticMethodNoExactMatchThrows() {
        try {
            MethodUtils.invokeExactStaticMethod(AgentOps.class, "staticOp", Integer.valueOf(1));
            fail("expected NoSuchMethodException");
        } catch (final NoSuchMethodException expected) {
            // expected
        } catch (final Exception e) {
            fail("expected NoSuchMethodException but got " + e);
        }
    }

    // --- sanity on fixtures themselves (observable state, not just no-exception) ---

    @Test
    public void testOverloadResolutionPicksMostSpecific() throws Exception {
        final Method m = MethodUtils.getMatchingAccessibleMethod(AgentOps.class, "overload", String.class);
        assertNotNull(m);
        assertEquals(String.class, m.getParameterTypes()[0]);
        assertFalse(new ArrayList<Method>().contains(m));
    }
}
