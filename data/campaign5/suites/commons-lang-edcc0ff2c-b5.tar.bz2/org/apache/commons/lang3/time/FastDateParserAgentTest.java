/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link FastDateParser}. Lives in the same package so it can use the package-private
 * (and protected) constructor and helpers directly, rather than going through the {@code FastDateFormat} cache.
 */
class FastDateParserAgentTest {

    private static final TimeZone GMT = TimeZone.getTimeZone("GMT");

    private static Calendar newGmtCalendar() {
        final Calendar cal = Calendar.getInstance(GMT, Locale.US);
        cal.clear();
        return cal;
    }

    @Test
    void testParseBasicDateTime() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd'T'HH:mm:ss", GMT, Locale.US);
        final Date date = parser.parse("2023-06-15T13:45:30");
        final Calendar cal = newGmtCalendar();
        cal.setTime(date);
        assertEquals(2023, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JUNE, cal.get(Calendar.MONTH));
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
        assertEquals(13, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals(45, cal.get(Calendar.MINUTE));
        assertEquals(30, cal.get(Calendar.SECOND));
    }

    @Test
    void testParseDoesNotRequireFullConsumption() throws ParseException {
        // "Not all source text needs to be consumed" per the parse(String, ParsePosition) contract.
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("2023-06-15 and then some trailing text", pos);
        assertNotNull(date);
        assertEquals(10, pos.getIndex());
        final Calendar cal = newGmtCalendar();
        cal.setTime(date);
        assertEquals(2023, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JUNE, cal.get(Calendar.MONTH));
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseWithOffsetStartPosition() {
        final FastDateParser parser = new FastDateParser("dd", GMT, Locale.US);
        final ParsePosition pos = new ParsePosition(2);
        final Date date = parser.parse("xx15", pos);
        assertNotNull(date);
        assertEquals(4, pos.getIndex());
        final Calendar cal = newGmtCalendar();
        cal.setTime(date);
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseInvalidThrowsParseException() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final ParseException thrown = assertThrows(ParseException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                parser.parse("not-a-date");
            }
        });
        assertTrue(thrown.getMessage().contains("Unparseable date"));
    }

    @Test
    void testParseReturnsNullAndSetsErrorIndexOnFailure() {
        final FastDateParser parser = new FastDateParser("yyyy", GMT, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("abcd", pos);
        assertNull(date);
        assertEquals(0, pos.getErrorIndex());
        assertEquals(0, pos.getIndex());
    }

    @Test
    void testLiteralMismatchCausesParseFailure() {
        final FastDateParser parser = new FastDateParser("yyyy'T'HH", GMT, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("2023X10", pos);
        assertNull(date);
        assertEquals(4, pos.getErrorIndex());
    }

    @Test
    void testCheckLengthRejectsStartPositionBeyondSourceLength() {
        final FastDateParser parser = new FastDateParser("yyyy", GMT, Locale.US);
        final ParsePosition pos = new ParsePosition(100);
        final Date date = parser.parse("abc", pos);
        assertNull(date);
        assertEquals(100, pos.getErrorIndex());
    }

    @Test
    void testNumberOverflowCausesParseFailureInsteadOfException() {
        final FastDateParser parser = new FastDateParser("yyyy", GMT, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        // 11 digits overflows a signed 32-bit int; NumberStrategy must convert the NumberFormatException
        // into a parse failure rather than letting it propagate.
        final Date date = parser.parse("99999999999", pos);
        assertNull(date);
        assertEquals(0, pos.getErrorIndex());
    }

    @Test
    void testNumberStrategyMaxWidthLimitsGreedyField() throws ParseException {
        // 'yyyy' is immediately followed by another numeric field ('MM'), so it must stop at 4 digits
        // instead of greedily consuming all 5 and starving the month field.
        final FastDateParser parser = new FastDateParser("yyyyMM", GMT, Locale.US);
        final Date date = parser.parse("20231");
        final Calendar cal = newGmtCalendar();
        cal.setTime(date);
        assertEquals(2023, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));
        assertEquals(1, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseUpdatesSuppliedCalendarDirectly() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final Calendar cal = newGmtCalendar();
        final ParsePosition pos = new ParsePosition(0);
        final boolean ok = parser.parse("2024-12-31", pos, cal);
        assertTrue(ok);
        assertEquals(10, pos.getIndex());
        assertEquals(2024, cal.get(Calendar.YEAR));
        assertEquals(Calendar.DECEMBER, cal.get(Calendar.MONTH));
        assertEquals(31, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testGetPatternLocaleTimeZone() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        assertEquals("yyyy-MM-dd", parser.getPattern());
        assertEquals(Locale.US, parser.getLocale());
        assertEquals(GMT, parser.getTimeZone());
    }

    @Test
    void testGetTimeZoneReturnsDefensiveCopy() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final TimeZone tz1 = parser.getTimeZone();
        final TimeZone tz2 = parser.getTimeZone();
        assertNotSame(tz1, tz2);
        assertEquals(tz1, tz2);
    }

    @Test
    void testEqualsAndHashCode() {
        final FastDateParser a = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final FastDateParser b = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final FastDateParser diffPattern = new FastDateParser("MM/dd/yyyy", GMT, Locale.US);
        final FastDateParser diffZone = new FastDateParser("yyyy-MM-dd", TimeZone.getTimeZone("America/New_York"), Locale.US);
        final FastDateParser diffLocale = new FastDateParser("yyyy-MM-dd", GMT, Locale.FRANCE);

        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
        assertNotEquals(a, diffPattern);
        assertNotEquals(a, diffZone);
        assertNotEquals(a, diffLocale);
    }

    @Test
    void testEqualsWithNullOrDifferentType() {
        final FastDateParser a = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        assertNotEquals(a, null);
        assertNotEquals(a, "yyyy-MM-dd");
    }

    @Test
    void testToStringContainsPatternAndTimeZone() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final String s = parser.toString();
        assertTrue(s.contains("yyyy-MM-dd"));
        assertTrue(s.contains("GMT"));
    }

    @Test
    void testToStringAllContainsPatternDetails() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final String s = parser.toStringAll();
        assertTrue(s.contains("pattern=yyyy-MM-dd"));
        assertTrue(s.contains("locale="));
    }

    @Test
    void testConstructorRejectsNullPattern() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                new FastDateParser(null, GMT, Locale.US);
            }
        });
    }

    @Test
    void testConstructorRejectsNullTimeZone() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                new FastDateParser("yyyy", null, Locale.US);
            }
        });
    }

    @Test
    void testConstructorNullLocaleFallsBackToDefault() {
        final FastDateParser parser = new FastDateParser("yyyy", GMT, null);
        assertEquals(Locale.getDefault(), parser.getLocale());
    }

    @Test
    void testConstructorRejectsUnterminatedQuote() {
        final IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new FastDateParser("yyyy'MM", GMT, Locale.US);
            }
        });
        assertTrue(thrown.getMessage().contains("Unterminated quote"));
    }

    @Test
    void testConstructorRejectsUnsupportedFormatLetter() {
        final IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new FastDateParser("yyyy-QQ", GMT, Locale.US);
            }
        });
        assertTrue(thrown.getMessage().contains("not supported"));
    }

    @Test
    void testConstructorRejectsInvalidIso8601Width() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new FastDateParser("XXXX", GMT, Locale.US);
            }
        });
    }

    @Test
    void testCenturyAdjustmentWithExplicitCenturyStart() throws ParseException {
        final Calendar centuryStartCal = newGmtCalendar();
        centuryStartCal.set(1950, Calendar.JANUARY, 1);
        final FastDateParser parser = new FastDateParser("yy-MM-dd", GMT, Locale.US, centuryStartCal.getTime());

        final Calendar atStart = newGmtCalendar();
        atStart.setTime(parser.parse("50-01-01"));
        assertEquals(1950, atStart.get(Calendar.YEAR));

        final Calendar justBefore = newGmtCalendar();
        justBefore.setTime(parser.parse("49-01-01"));
        assertEquals(2049, justBefore.get(Calendar.YEAR));
    }

    @Test
    void testIso8601TimeZoneStrategyWidths() {
        final Calendar cal1 = newGmtCalendar();
        assertTrue(new FastDateParser("X", GMT, Locale.US).parse("+05", new ParsePosition(0), cal1));
        assertEquals(5 * 3600000, cal1.getTimeZone().getRawOffset());

        final Calendar cal2 = newGmtCalendar();
        assertTrue(new FastDateParser("XX", GMT, Locale.US).parse("+0530", new ParsePosition(0), cal2));
        assertEquals(5 * 3600000 + 30 * 60000, cal2.getTimeZone().getRawOffset());

        final Calendar cal3 = newGmtCalendar();
        assertTrue(new FastDateParser("XXX", GMT, Locale.US).parse("-05:30", new ParsePosition(0), cal3));
        assertEquals(-(5 * 3600000 + 30 * 60000), cal3.getTimeZone().getRawOffset());
    }

    @Test
    void testTimeZoneStrategyParsesGmtOffsetLiteral() {
        final FastDateParser parser = new FastDateParser("z", GMT, Locale.US);
        final Calendar cal = newGmtCalendar();
        final boolean ok = parser.parse("GMT+05:30", new ParsePosition(0), cal);
        assertTrue(ok);
        assertEquals(5 * 3600000 + 30 * 60000, cal.getTimeZone().getRawOffset());
    }

    @Test
    void testTextMonthNameParsingLocaleUS() throws ParseException {
        final FastDateParser parser = new FastDateParser("MMMM d, yyyy", GMT, Locale.US);
        final Date date = parser.parse("June 15, 2023");
        final Calendar cal = newGmtCalendar();
        cal.setTime(date);
        assertEquals(Calendar.JUNE, cal.get(Calendar.MONTH));
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
        assertEquals(2023, cal.get(Calendar.YEAR));
    }

    @Test
    void testTextMonthNameParsingIsCaseInsensitive() throws ParseException {
        final FastDateParser parser = new FastDateParser("MMMM d, yyyy", GMT, Locale.US);
        final Date date = parser.parse("JUNE 15, 2023");
        final Calendar cal = newGmtCalendar();
        cal.setTime(date);
        assertEquals(Calendar.JUNE, cal.get(Calendar.MONTH));
    }

    @Test
    void testUnknownMonthNameCausesParseFailure() {
        final FastDateParser parser = new FastDateParser("MMMM d, yyyy", GMT, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("Smarch 15, 2023", pos);
        assertNull(date);
        assertEquals(0, pos.getErrorIndex());
    }

    @Test
    void testHour12StrategyBoundary() throws ParseException {
        final FastDateParser parser = new FastDateParser("hh:mm a", GMT, Locale.US);
        final Calendar noon = newGmtCalendar();
        noon.setTime(parser.parse("12:30 PM"));
        assertEquals(12, noon.get(Calendar.HOUR_OF_DAY));

        final Calendar midnight = newGmtCalendar();
        midnight.setTime(parser.parse("12:30 AM"));
        assertEquals(0, midnight.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    void testHour24StrategyBoundary() throws ParseException {
        final FastDateParser parser = new FastDateParser("kk:mm", GMT, Locale.US);
        final Calendar cal = newGmtCalendar();
        cal.setTime(parser.parse("24:00"));
        assertEquals(0, cal.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    void testWeekYearParsing() {
        final Calendar expected = newGmtCalendar();
        expected.setWeekDate(2023, 1, Calendar.MONDAY);

        final FastDateParser parser = new FastDateParser("YYYY-ww-u", GMT, Locale.US);
        final Calendar actual = newGmtCalendar();
        final boolean ok = parser.parse("2023-01-1", new ParsePosition(0), actual);
        assertTrue(ok);
        assertEquals(expected.getTime(), actual.getTime());
    }

    @Test
    void testSerializationRoundTripReinitializesTransientState() throws Exception {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final ByteArrayOutputStream bos = new ByteArrayOutputStream();
        final ObjectOutputStream oos = new ObjectOutputStream(bos);
        oos.writeObject(parser);
        oos.close();

        final ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(bos.toByteArray()));
        final FastDateParser deserialized;
        try {
            deserialized = (FastDateParser) ois.readObject();
        } finally {
            ois.close();
        }

        assertEquals(parser, deserialized);
        final Date date = deserialized.parse("2023-06-15");
        final Calendar cal = newGmtCalendar();
        cal.setTime(date);
        assertEquals(2023, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JUNE, cal.get(Calendar.MONTH));
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testStaticClearDoesNotBreakSubsequentParsing() throws ParseException {
        final FastDateParser parser = new FastDateParser("MMMM d, yyyy", GMT, Locale.US);
        FastDateParser.clear();
        final Date date = parser.parse("June 15, 2023");
        final Calendar cal = newGmtCalendar();
        cal.setTime(date);
        assertEquals(Calendar.JUNE, cal.get(Calendar.MONTH));
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testSkipTimeZoneHelper() {
        assertTrue(FastDateParser.TimeZoneStrategy.skipTimeZone("GMT"));
        assertTrue(FastDateParser.TimeZoneStrategy.skipTimeZone("gmt"));
        assertFalse(FastDateParser.TimeZoneStrategy.skipTimeZone("PST"));
    }

    @Test
    void testJapaneseImperialLocaleConstant() {
        assertEquals(new Locale("ja", "JP", "JP"), FastDateParser.JAPANESE_IMPERIAL);
    }

    @Test
    void testParseObjectDelegatesToParse() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, Locale.US);
        final Object result = parser.parseObject("2023-06-15");
        assertTrue(result instanceof Date);
        final Calendar cal = newGmtCalendar();
        cal.setTime((Date) result);
        assertEquals(2023, cal.get(Calendar.YEAR));

        final Object nullResult = parser.parseObject("garbage", new ParsePosition(0));
        assertNull(nullResult);
    }
}
