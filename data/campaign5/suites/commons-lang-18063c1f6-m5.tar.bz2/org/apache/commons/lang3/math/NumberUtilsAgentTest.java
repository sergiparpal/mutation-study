/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link NumberUtils}.
 */
class NumberUtilsAgentTest {

    @Test
    void testConstructor() {
        assertNotNull(new NumberUtils());
    }

    @Test
    void testCompareByte() {
        assertEquals(0, NumberUtils.compare((byte) 1, (byte) 1));
        assertTrue(NumberUtils.compare((byte) 1, (byte) 2) < 0);
        assertTrue(NumberUtils.compare((byte) 2, (byte) 1) > 0);
    }

    @Test
    void testCompareInt() {
        assertEquals(0, NumberUtils.compare(1, 1));
        assertTrue(NumberUtils.compare(1, 2) < 0);
        assertTrue(NumberUtils.compare(2, 1) > 0);
    }

    @Test
    void testCompareLong() {
        assertEquals(0, NumberUtils.compare(1L, 1L));
        assertTrue(NumberUtils.compare(1L, 2L) < 0);
        assertTrue(NumberUtils.compare(2L, 1L) > 0);
    }

    @Test
    void testCompareShort() {
        assertEquals(0, NumberUtils.compare((short) 1, (short) 1));
        assertTrue(NumberUtils.compare((short) 1, (short) 2) < 0);
        assertTrue(NumberUtils.compare((short) 2, (short) 1) > 0);
    }

    @Test
    void testCreateBigDecimal() {
        assertNull(NumberUtils.createBigDecimal(null));
        assertEquals(new BigDecimal("1.1"), NumberUtils.createBigDecimal("1.1"));
        try {
            NumberUtils.createBigDecimal(" ");
            fail("Expected NumberFormatException for blank string");
        } catch (final NumberFormatException expected) {
            // expected
        }
        try {
            NumberUtils.createBigDecimal("not a number");
            fail("Expected NumberFormatException for non-numeric string");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    @Test
    void testCreateBigInteger() {
        assertNull(NumberUtils.createBigInteger(null));
        assertEquals(BigInteger.valueOf(255), NumberUtils.createBigInteger("0xFF"));
        assertEquals(BigInteger.valueOf(255), NumberUtils.createBigInteger("0XFF"));
        assertEquals(BigInteger.valueOf(255), NumberUtils.createBigInteger("#FF"));
        assertEquals(BigInteger.valueOf(8), NumberUtils.createBigInteger("010"));
        assertEquals(BigInteger.valueOf(-8), NumberUtils.createBigInteger("-010"));
        assertEquals(BigInteger.valueOf(123), NumberUtils.createBigInteger("123"));
        assertEquals(BigInteger.valueOf(-255), NumberUtils.createBigInteger("-0xFF"));
        try {
            NumberUtils.createBigInteger("");
            fail("Expected NumberFormatException for empty string");
        } catch (final NumberFormatException expected) {
            // expected
        }
        try {
            NumberUtils.createBigInteger("--1");
            fail("Expected NumberFormatException for double sign");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    @Test
    void testCreateDouble() {
        assertNull(NumberUtils.createDouble(null));
        assertEquals(1.1d, NumberUtils.createDouble("1.1").doubleValue(), 0.0d);
        try {
            NumberUtils.createDouble("not a number");
            fail("Expected NumberFormatException");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    @Test
    void testCreateFloat() {
        assertNull(NumberUtils.createFloat(null));
        assertEquals(1.1f, NumberUtils.createFloat("1.1").floatValue(), 0.0f);
        try {
            NumberUtils.createFloat("not a number");
            fail("Expected NumberFormatException");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    @Test
    void testCreateInteger() {
        assertNull(NumberUtils.createInteger(null));
        assertEquals(Integer.valueOf(12345), NumberUtils.createInteger("12345"));
        assertEquals(Integer.valueOf(255), NumberUtils.createInteger("0xFF"));
        try {
            NumberUtils.createInteger("not a number");
            fail("Expected NumberFormatException");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    @Test
    void testCreateLong() {
        assertNull(NumberUtils.createLong(null));
        assertEquals(Long.valueOf(12345L), NumberUtils.createLong("12345"));
        try {
            NumberUtils.createLong("not a number");
            fail("Expected NumberFormatException");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    @Test
    void testCreateNumberNull() {
        assertNull(NumberUtils.createNumber(null));
    }

    @Test
    void testCreateNumberBlankThrows() {
        try {
            NumberUtils.createNumber(" ");
            fail("Expected NumberFormatException for blank string");
        } catch (final NumberFormatException expected) {
            // expected
        }
        try {
            NumberUtils.createNumber("");
            fail("Expected NumberFormatException for empty string");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    @Test
    void testCreateNumberIntegerTypes() {
        assertEquals(Integer.valueOf(12345), NumberUtils.createNumber("12345"));
        assertTrue(NumberUtils.createNumber("12345") instanceof Integer);
        assertTrue(NumberUtils.createNumber("" + ((long) Integer.MAX_VALUE + 1L)) instanceof Long);
        assertTrue(NumberUtils.createNumber("123456789012345678901234567890") instanceof BigInteger);
    }

    @Test
    void testCreateNumberHex() {
        assertEquals(Integer.valueOf(255), NumberUtils.createNumber("0xFF"));
        assertTrue(NumberUtils.createNumber("0xFF") instanceof Integer);
        assertTrue(NumberUtils.createNumber("0xFFL") instanceof Long);
        assertTrue(NumberUtils.createNumber("0x1FFFFFFFF") instanceof Long);
        assertTrue(NumberUtils.createNumber("0x1FFFFFFFFFFFFFFFF") instanceof BigInteger);
    }

    @Test
    void testCreateNumberFloatingTypes() {
        assertTrue(NumberUtils.createNumber("1.1") instanceof Float);
        assertTrue(NumberUtils.createNumber("1.1f") instanceof Float);
        assertTrue(NumberUtils.createNumber("1.1d") instanceof Double);
        assertTrue(NumberUtils.createNumber("1.1D") instanceof Double);
        assertTrue(NumberUtils.createNumber("1.1e300d") instanceof Double);
    }

    @Test
    void testCreateNumberLongSuffix() {
        assertEquals(Long.valueOf(123L), NumberUtils.createNumber("123L"));
        assertTrue(NumberUtils.createNumber("123L") instanceof Long);
        try {
            NumberUtils.createNumber("1.1L");
            fail("Expected NumberFormatException for non-integral long literal");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    @Test
    void testCreateNumberInvalid() {
        try {
            NumberUtils.createNumber("not a number");
            fail("Expected NumberFormatException");
        } catch (final NumberFormatException expected) {
            // expected
        }
        try {
            NumberUtils.createNumber("1.1.1");
            fail("Expected NumberFormatException");
        } catch (final NumberFormatException expected) {
            // expected
        }
        try {
            NumberUtils.createNumber("--1");
            fail("Expected NumberFormatException");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    @Test
    void testIsCreatable() {
        assertFalse(NumberUtils.isCreatable(null));
        assertFalse(NumberUtils.isCreatable(""));
        assertFalse(NumberUtils.isCreatable(" "));
        assertTrue(NumberUtils.isCreatable("12345"));
        assertTrue(NumberUtils.isCreatable("-12345"));
        assertTrue(NumberUtils.isCreatable("12345.1"));
        assertTrue(NumberUtils.isCreatable("0xFF"));
        assertFalse(NumberUtils.isCreatable("12345e"));
        assertFalse(NumberUtils.isCreatable("not a number"));
        assertFalse(NumberUtils.isCreatable("09"));
        assertTrue(NumberUtils.isCreatable("0.09"));
    }

    @Test
    @SuppressWarnings("deprecation")
    void testIsNumberDelegatesToIsCreatable() {
        assertEquals(NumberUtils.isCreatable("12345"), NumberUtils.isNumber("12345"));
        assertEquals(NumberUtils.isCreatable(""), NumberUtils.isNumber(""));
        assertEquals(NumberUtils.isCreatable("not a number"), NumberUtils.isNumber("not a number"));
    }

    @Test
    void testIsDigits() {
        assertFalse(NumberUtils.isDigits(null));
        assertFalse(NumberUtils.isDigits(""));
        assertTrue(NumberUtils.isDigits("12345"));
        assertFalse(NumberUtils.isDigits("12 345"));
        assertFalse(NumberUtils.isDigits("1234.5"));
        assertFalse(NumberUtils.isDigits("-12345"));
        assertFalse(NumberUtils.isDigits("abc"));
    }

    @Test
    void testIsParsable() {
        assertFalse(NumberUtils.isParsable(null));
        assertFalse(NumberUtils.isParsable(""));
        assertTrue(NumberUtils.isParsable("123"));
        assertTrue(NumberUtils.isParsable("-123"));
        assertTrue(NumberUtils.isParsable("1.23"));
        assertTrue(NumberUtils.isParsable("1.23e10"));
        assertFalse(NumberUtils.isParsable("1.23.45"));
        assertFalse(NumberUtils.isParsable("abc"));
        assertFalse(NumberUtils.isParsable("."));
        assertTrue(NumberUtils.isParsable("123."));
    }

    @Test
    void testMaxByteArray() {
        assertEquals((byte) 3, NumberUtils.max((byte) 1, (byte) 3, (byte) 2));
        try {
            NumberUtils.max((byte[]) null);
            fail("Expected NullPointerException for null array");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.max(new byte[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMaxByteThreeArgs() {
        assertEquals((byte) 3, NumberUtils.max((byte) 1, (byte) 2, (byte) 3));
        assertEquals((byte) 3, NumberUtils.max((byte) 3, (byte) 2, (byte) 1));
        assertEquals((byte) 3, NumberUtils.max((byte) 1, (byte) 3, (byte) 1));
    }

    @Test
    void testMaxDoubleArray() {
        assertEquals(3.5d, NumberUtils.max(1.0d, 3.5d, 2.0d), 0.0d);
        assertTrue(Double.isNaN(NumberUtils.max(1.0d, Double.NaN, 2.0d)));
        try {
            NumberUtils.max((double[]) null);
            fail("Expected NullPointerException for null array");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.max(new double[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMaxDoubleThreeArgs() {
        assertEquals(3.5d, NumberUtils.max(1.0d, 3.5d, 2.0d), 0.0d);
        assertTrue(Double.isNaN(NumberUtils.max(1.0d, Double.NaN, 2.0d)));
    }

    @Test
    void testMaxFloatArray() {
        assertEquals(3.5f, NumberUtils.max(1.0f, 3.5f, 2.0f), 0.0f);
        assertTrue(Float.isNaN(NumberUtils.max(1.0f, Float.NaN, 2.0f)));
        try {
            NumberUtils.max((float[]) null);
            fail("Expected NullPointerException for null array");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.max(new float[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMaxFloatThreeArgs() {
        assertEquals(3.5f, NumberUtils.max(1.0f, 3.5f, 2.0f), 0.0f);
        assertTrue(Float.isNaN(NumberUtils.max(1.0f, Float.NaN, 2.0f)));
    }

    @Test
    void testMaxIntArray() {
        assertEquals(3, NumberUtils.max(1, 3, 2));
        try {
            NumberUtils.max((int[]) null);
            fail("Expected NullPointerException for null array");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.max(new int[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMaxIntThreeArgs() {
        assertEquals(3, NumberUtils.max(1, 2, 3));
        assertEquals(3, NumberUtils.max(3, 2, 1));
        assertEquals(3, NumberUtils.max(1, 3, 1));
    }

    @Test
    void testMaxLongArray() {
        assertEquals(3L, NumberUtils.max(1L, 3L, 2L));
        try {
            NumberUtils.max((long[]) null);
            fail("Expected NullPointerException for null array");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.max(new long[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMaxLongThreeArgs() {
        assertEquals(3L, NumberUtils.max(1L, 2L, 3L));
        assertEquals(3L, NumberUtils.max(3L, 2L, 1L));
    }

    @Test
    void testMaxShortArray() {
        assertEquals((short) 3, NumberUtils.max((short) 1, (short) 3, (short) 2));
        try {
            NumberUtils.max((short[]) null);
            fail("Expected NullPointerException for null array");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.max(new short[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMaxShortThreeArgs() {
        assertEquals((short) 3, NumberUtils.max((short) 1, (short) 2, (short) 3));
        assertEquals((short) 3, NumberUtils.max((short) 3, (short) 2, (short) 1));
    }

    @Test
    void testMinByteArray() {
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 3, (byte) 2));
        try {
            NumberUtils.min((byte[]) null);
            fail("Expected NullPointerException for null array");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.min(new byte[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMinByteThreeArgs() {
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 2, (byte) 3));
        assertEquals((byte) 1, NumberUtils.min((byte) 3, (byte) 2, (byte) 1));
    }

    @Test
    void testMinDoubleArray() {
        assertEquals(1.0d, NumberUtils.min(1.0d, 3.5d, 2.0d), 0.0d);
        assertTrue(Double.isNaN(NumberUtils.min(1.0d, Double.NaN, 2.0d)));
        try {
            NumberUtils.min((double[]) null);
            fail("Expected NullPointerException for null array");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.min(new double[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMinDoubleThreeArgs() {
        assertEquals(1.0d, NumberUtils.min(1.0d, 3.5d, 2.0d), 0.0d);
        assertTrue(Double.isNaN(NumberUtils.min(1.0d, Double.NaN, 2.0d)));
    }

    @Test
    void testMinFloatArray() {
        assertEquals(1.0f, NumberUtils.min(1.0f, 3.5f, 2.0f), 0.0f);
        assertTrue(Float.isNaN(NumberUtils.min(1.0f, Float.NaN, 2.0f)));
        try {
            NumberUtils.min((float[]) null);
            fail("Expected NullPointerException for null array");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.min(new float[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMinFloatThreeArgs() {
        assertEquals(1.0f, NumberUtils.min(1.0f, 3.5f, 2.0f), 0.0f);
        assertTrue(Float.isNaN(NumberUtils.min(1.0f, Float.NaN, 2.0f)));
    }

    @Test
    void testMinIntArray() {
        assertEquals(1, NumberUtils.min(1, 3, 2));
        try {
            NumberUtils.min((int[]) null);
            fail("Expected NullPointerException for null array");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.min(new int[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMinIntThreeArgs() {
        assertEquals(1, NumberUtils.min(1, 2, 3));
        assertEquals(1, NumberUtils.min(3, 2, 1));
    }

    @Test
    void testMinLongArray() {
        assertEquals(1L, NumberUtils.min(1L, 3L, 2L));
        try {
            NumberUtils.min((long[]) null);
            fail("Expected NullPointerException for null array");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.min(new long[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMinLongThreeArgs() {
        assertEquals(1L, NumberUtils.min(1L, 2L, 3L));
        assertEquals(1L, NumberUtils.min(3L, 2L, 1L));
    }

    @Test
    void testMinShortArray() {
        assertEquals((short) 1, NumberUtils.min((short) 1, (short) 3, (short) 2));
        try {
            NumberUtils.min((short[]) null);
            fail("Expected NullPointerException for null array");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.min(new short[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMinShortThreeArgs() {
        assertEquals((short) 1, NumberUtils.min((short) 1, (short) 2, (short) 3));
        assertEquals((short) 1, NumberUtils.min((short) 3, (short) 2, (short) 1));
    }

    @Test
    void testToByte() {
        assertEquals((byte) 0, NumberUtils.toByte(null));
        assertEquals((byte) 0, NumberUtils.toByte(""));
        assertEquals((byte) 1, NumberUtils.toByte("1"));
        assertEquals((byte) 1, NumberUtils.toByte(null, (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("", (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("1", (byte) 0));
        assertEquals((byte) 2, NumberUtils.toByte("not a number", (byte) 2));
    }

    @Test
    void testToDoubleBigDecimal() {
        assertEquals(0.0d, NumberUtils.toDouble((BigDecimal) null), 0.0d);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d)), 0.0d);
        assertEquals(1.1d, NumberUtils.toDouble((BigDecimal) null, 1.1d), 0.0d);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d), 1.1d), 0.0d);
    }

    @Test
    void testToDoubleString() {
        assertEquals(0.0d, NumberUtils.toDouble((String) null), 0.0d);
        assertEquals(0.0d, NumberUtils.toDouble(""), 0.0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5"), 0.0d);
        assertEquals(1.1d, NumberUtils.toDouble((String) null, 1.1d), 0.0d);
        assertEquals(1.1d, NumberUtils.toDouble("", 1.1d), 0.0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5", 0.0d), 0.0d);
        assertEquals(2.2d, NumberUtils.toDouble("not a number", 2.2d), 0.0d);
    }

    @Test
    void testToFloat() {
        assertEquals(0.0f, NumberUtils.toFloat(null), 0.0f);
        assertEquals(0.0f, NumberUtils.toFloat(""), 0.0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5"), 0.0f);
        assertEquals(1.1f, NumberUtils.toFloat(null, 1.1f), 0.0f);
        assertEquals(1.1f, NumberUtils.toFloat("", 1.1f), 0.0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5", 0.0f), 0.0f);
        assertEquals(2.2f, NumberUtils.toFloat("not a number", 2.2f), 0.0f);
    }

    @Test
    void testToInt() {
        assertEquals(0, NumberUtils.toInt(null));
        assertEquals(0, NumberUtils.toInt(""));
        assertEquals(1, NumberUtils.toInt("1"));
        assertEquals(1, NumberUtils.toInt(null, 1));
        assertEquals(1, NumberUtils.toInt("", 1));
        assertEquals(1, NumberUtils.toInt("1", 0));
        assertEquals(2, NumberUtils.toInt("not a number", 2));
    }

    @Test
    void testToLong() {
        assertEquals(0L, NumberUtils.toLong(null));
        assertEquals(0L, NumberUtils.toLong(""));
        assertEquals(1L, NumberUtils.toLong("1"));
        assertEquals(1L, NumberUtils.toLong(null, 1L));
        assertEquals(1L, NumberUtils.toLong("", 1L));
        assertEquals(1L, NumberUtils.toLong("1", 0L));
        assertEquals(2L, NumberUtils.toLong("not a number", 2L));
    }

    @Test
    void testToShort() {
        assertEquals((short) 0, NumberUtils.toShort(null));
        assertEquals((short) 0, NumberUtils.toShort(""));
        assertEquals((short) 1, NumberUtils.toShort("1"));
        assertEquals((short) 1, NumberUtils.toShort(null, (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("", (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("1", (short) 0));
        assertEquals((short) 2, NumberUtils.toShort("not a number", (short) 2));
    }

    @Test
    void testToScaledBigDecimalBigDecimal() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null));
        assertEquals(new BigDecimal("1.23"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.234")));
        assertEquals(new BigDecimal("1.234"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.234"), 3, RoundingMode.DOWN));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null, 3, RoundingMode.DOWN));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.245"), 2, null));
    }

    @Test
    void testToScaledBigDecimalDouble() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null));
        assertEquals(new BigDecimal("1.23"), NumberUtils.toScaledBigDecimal(Double.valueOf(1.234d)));
        assertEquals(new BigDecimal("1.234"), NumberUtils.toScaledBigDecimal(Double.valueOf(1.234d), 3, RoundingMode.DOWN));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null, 3, RoundingMode.DOWN));
    }

    @Test
    void testToScaledBigDecimalFloat() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null));
        assertEquals(new BigDecimal("1.23"), NumberUtils.toScaledBigDecimal(Float.valueOf(1.234f)));
        assertEquals(new BigDecimal("1.233"), NumberUtils.toScaledBigDecimal(Float.valueOf(1.234f), 3, RoundingMode.DOWN));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null, 3, RoundingMode.DOWN));
    }

    @Test
    void testToScaledBigDecimalString() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null));
        assertEquals(new BigDecimal("1.23"), NumberUtils.toScaledBigDecimal("1.234"));
        assertEquals(new BigDecimal("1.234"), NumberUtils.toScaledBigDecimal("1.234", 3, RoundingMode.DOWN));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null, 3, RoundingMode.DOWN));
    }

    @Test
    void testConstants() {
        assertEquals(0L, NumberUtils.LONG_ZERO.longValue());
        assertEquals(1L, NumberUtils.LONG_ONE.longValue());
        assertEquals(-1L, NumberUtils.LONG_MINUS_ONE.longValue());
        assertEquals(0, NumberUtils.INTEGER_ZERO.intValue());
        assertEquals(1, NumberUtils.INTEGER_ONE.intValue());
        assertEquals(2, NumberUtils.INTEGER_TWO.intValue());
        assertEquals(-1, NumberUtils.INTEGER_MINUS_ONE.intValue());
        assertEquals((short) 0, NumberUtils.SHORT_ZERO.shortValue());
        assertEquals((short) 1, NumberUtils.SHORT_ONE.shortValue());
        assertEquals((short) -1, NumberUtils.SHORT_MINUS_ONE.shortValue());
        assertEquals((byte) 0, NumberUtils.BYTE_ZERO.byteValue());
        assertEquals((byte) 1, NumberUtils.BYTE_ONE.byteValue());
        assertEquals((byte) -1, NumberUtils.BYTE_MINUS_ONE.byteValue());
        assertEquals(0.0d, NumberUtils.DOUBLE_ZERO.doubleValue(), 0.0d);
        assertEquals(1.0d, NumberUtils.DOUBLE_ONE.doubleValue(), 0.0d);
        assertEquals(-1.0d, NumberUtils.DOUBLE_MINUS_ONE.doubleValue(), 0.0d);
        assertEquals(0.0f, NumberUtils.FLOAT_ZERO.floatValue(), 0.0f);
        assertEquals(1.0f, NumberUtils.FLOAT_ONE.floatValue(), 0.0f);
        assertEquals(-1.0f, NumberUtils.FLOAT_MINUS_ONE.floatValue(), 0.0f);
        assertEquals(Integer.MAX_VALUE, NumberUtils.LONG_INT_MAX_VALUE.longValue());
        assertEquals(Integer.MIN_VALUE, NumberUtils.LONG_INT_MIN_VALUE.longValue());
    }
}
