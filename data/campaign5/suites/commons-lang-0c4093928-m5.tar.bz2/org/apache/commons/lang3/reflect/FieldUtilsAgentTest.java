/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link FieldUtils}.
 */
public class FieldUtilsAgentTest {

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.FIELD)
    private @interface AgentAnnotated {
        // marker annotation for fields
    }

    public interface AgentInterfaceWithField {
        String INTERFACE_FIELD = "interfaceValue";
    }

    public static class AgentParent implements AgentInterfaceWithField {
        public static String staticPublicParent = "staticPublicParentValue";
        protected static final String STATIC_FINAL_PARENT = "staticFinalParentValue";
        public String publicParentField = "publicParentValue";
        @AgentAnnotated
        protected String protectedParentField = "protectedParentValue";
        private String privateParentField = "privateParentValue";
    }

    public static class AgentChild extends AgentParent {
        public String publicChildField = "publicChildValue";
        @AgentAnnotated
        private String privateChildField = "privateChildValue";
        private final int finalIntField = 42;
    }

    //
    // getAllFields / getAllFieldsList
    //

    @Test
    public void testGetAllFieldsIncludesDeclaredAndInherited() {
        final Field[] fields = FieldUtils.getAllFields(AgentChild.class);
        boolean foundChildPublic = false;
        boolean foundParentPrivate = false;
        for (final Field f : fields) {
            if ("publicChildField".equals(f.getName())) {
                foundChildPublic = true;
            }
            if ("privateParentField".equals(f.getName())) {
                foundParentPrivate = true;
            }
        }
        assertTrue(foundChildPublic);
        assertTrue(foundParentPrivate);
    }

    @Test
    public void testGetAllFieldsListMatchesArray() {
        final List<Field> list = FieldUtils.getAllFieldsList(AgentChild.class);
        final Field[] array = FieldUtils.getAllFields(AgentChild.class);
        assertEquals(array.length, list.size());
    }

    @Test
    public void testGetAllFieldsNullClassThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                FieldUtils.getAllFields(null);
            }
        });
    }

    @Test
    public void testGetAllFieldsListEmptyForObject() {
        final List<Field> list = FieldUtils.getAllFieldsList(Object.class);
        assertNotNull(list);
        assertEquals(0, list.size());
    }

    //
    // getDeclaredField
    //

    @Test
    public void testGetDeclaredFieldPublicOnOwnClass() {
        final Field f = FieldUtils.getDeclaredField(AgentChild.class, "publicChildField");
        assertNotNull(f);
        assertEquals("publicChildField", f.getName());
    }

    @Test
    public void testGetDeclaredFieldDoesNotLookAtSuperclass() {
        final Field f = FieldUtils.getDeclaredField(AgentChild.class, "publicParentField");
        assertNull(f);
    }

    @Test
    public void testGetDeclaredFieldPrivateWithoutForceAccessReturnsNull() {
        final Field f = FieldUtils.getDeclaredField(AgentChild.class, "privateChildField");
        assertNull(f);
    }

    @Test
    public void testGetDeclaredFieldPrivateWithForceAccess() {
        final Field f = FieldUtils.getDeclaredField(AgentChild.class, "privateChildField", true);
        assertNotNull(f);
        assertTrue(f.isAccessible());
    }

    @Test
    public void testGetDeclaredFieldUnknownNameReturnsNull() {
        final Field f = FieldUtils.getDeclaredField(AgentChild.class, "doesNotExist");
        assertNull(f);
    }

    @Test
    public void testGetDeclaredFieldBlankNameThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                FieldUtils.getDeclaredField(AgentChild.class, "   ");
            }
        });
    }

    @Test
    public void testGetDeclaredFieldNullNameThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                FieldUtils.getDeclaredField(AgentChild.class, null);
            }
        });
    }

    @Test
    public void testGetDeclaredFieldNullClassThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                FieldUtils.getDeclaredField(null, "x");
            }
        });
    }

    //
    // getField
    //

    @Test
    public void testGetFieldFindsPublicFieldOnSuperclass() {
        final Field f = FieldUtils.getField(AgentChild.class, "publicParentField");
        assertNotNull(f);
        assertEquals(AgentParent.class, f.getDeclaringClass());
    }

    @Test
    public void testGetFieldPrivateFieldOnSuperclassWithoutForceAccessReturnsNull() {
        final Field f = FieldUtils.getField(AgentChild.class, "privateParentField");
        assertNull(f);
    }

    @Test
    public void testGetFieldPrivateFieldOnSuperclassWithForceAccess() {
        final Field f = FieldUtils.getField(AgentChild.class, "privateParentField", true);
        assertNotNull(f);
        assertTrue(f.isAccessible());
    }

    @Test
    public void testGetFieldFromInterface() {
        final Field f = FieldUtils.getField(AgentChild.class, "INTERFACE_FIELD");
        assertNotNull(f);
        assertEquals(AgentInterfaceWithField.class, f.getDeclaringClass());
    }

    @Test
    public void testGetFieldUnknownReturnsNull() {
        assertNull(FieldUtils.getField(AgentChild.class, "doesNotExist"));
    }

    @Test
    public void testGetFieldBlankNameThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                FieldUtils.getField(AgentChild.class, "");
            }
        });
    }

    @Test
    public void testGetFieldNullClassThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                FieldUtils.getField(null, "x");
            }
        });
    }

    //
    // getFieldsWithAnnotation / getFieldsListWithAnnotation
    //

    @Test
    public void testGetFieldsWithAnnotation() {
        final Field[] fields = FieldUtils.getFieldsWithAnnotation(AgentChild.class, AgentAnnotated.class);
        assertEquals(2, fields.length);
    }

    @Test
    public void testGetFieldsListWithAnnotationEmptyWhenNoneMatch() {
        final List<Field> fields = FieldUtils.getFieldsListWithAnnotation(Object.class, AgentAnnotated.class);
        assertTrue(fields.isEmpty());
    }

    @Test
    public void testGetFieldsWithAnnotationNullAnnotationThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                FieldUtils.getFieldsWithAnnotation(AgentChild.class, null);
            }
        });
    }

    //
    // readField / readDeclaredField / readStaticField / readDeclaredStaticField
    //

    @Test
    public void testReadFieldByNamePublicOnInstance() throws IllegalAccessException {
        final AgentChild child = new AgentChild();
        final Object value = FieldUtils.readField(child, "publicChildField");
        assertEquals("publicChildValue", value);
    }

    @Test
    public void testReadFieldByNamePrivateOnSuperclassWithForceAccess() throws IllegalAccessException {
        final AgentChild child = new AgentChild();
        final Object value = FieldUtils.readField(child, "privateParentField", true);
        assertEquals("privateParentValue", value);
    }

    @Test
    public void testReadFieldByNameUnknownThrowsIllegalArgument() {
        final AgentChild child = new AgentChild();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                FieldUtils.readField(child, "doesNotExist");
            }
        });
    }

    @Test
    public void testReadFieldByNameNullTargetThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                FieldUtils.readField((Object) null, "publicChildField");
            }
        });
    }

    @Test
    public void testReadFieldPrivateWithoutForceAccessThrowsIllegalAccess() throws Exception {
        final AgentChild child = new AgentChild();
        final Field field = AgentChild.class.getDeclaredField("privateChildField");
        assertFalse(field.isAccessible());
        assertThrows(IllegalAccessException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                FieldUtils.readField(field, child, false);
            }
        });
    }

    @Test
    public void testReadFieldWithForceAccess() throws Exception {
        final AgentChild child = new AgentChild();
        final Field field = AgentChild.class.getDeclaredField("privateChildField");
        final Object value = FieldUtils.readField(field, child, true);
        assertEquals("privateChildValue", value);
    }

    @Test
    public void testReadFieldNullFieldThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                FieldUtils.readField((Field) null, new AgentChild());
            }
        });
    }

    @Test
    public void testReadDeclaredFieldOnlyOwnClass() throws IllegalAccessException {
        final AgentChild child = new AgentChild();
        final Object value = FieldUtils.readDeclaredField(child, "publicChildField");
        assertEquals("publicChildValue", value);
    }

    @Test
    public void testReadDeclaredFieldDoesNotSeeSuperclassField() {
        final AgentChild child = new AgentChild();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                FieldUtils.readDeclaredField(child, "publicParentField");
            }
        });
    }

    @Test
    public void testReadStaticFieldByClass() throws IllegalAccessException {
        final Object value = FieldUtils.readStaticField(AgentParent.class, "staticPublicParent");
        assertEquals("staticPublicParentValue", value);
    }

    @Test
    public void testReadStaticFieldNonStaticThrows() throws Exception {
        final Field field = AgentChild.class.getDeclaredField("publicChildField");
        field.setAccessible(true);
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                FieldUtils.readStaticField(field);
            }
        });
    }

    @Test
    public void testReadDeclaredStaticFieldWithForceAccessOnProtectedFinal() throws IllegalAccessException {
        final Object value = FieldUtils.readDeclaredStaticField(AgentParent.class, "STATIC_FINAL_PARENT", true);
        assertEquals("staticFinalParentValue", value);
    }

    @Test
    public void testReadDeclaredStaticFieldUnknownThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                FieldUtils.readDeclaredStaticField(AgentParent.class, "doesNotExist");
            }
        });
    }

    //
    // writeField / writeDeclaredField / writeStaticField / writeDeclaredStaticField
    //

    @Test
    public void testWriteFieldByNamePublic() throws IllegalAccessException {
        final AgentChild child = new AgentChild();
        FieldUtils.writeField(child, "publicChildField", "newValue");
        assertEquals("newValue", child.publicChildField);
    }

    @Test
    public void testWriteFieldByNamePrivateOnSuperclassWithForceAccess() throws IllegalAccessException {
        final AgentChild child = new AgentChild();
        FieldUtils.writeField(child, "privateParentField", "updated", true);
        final Object value = FieldUtils.readField(child, "privateParentField", true);
        assertEquals("updated", value);
    }

    @Test
    public void testWriteFieldByNameUnknownThrows() {
        final AgentChild child = new AgentChild();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                FieldUtils.writeField(child, "doesNotExist", "x");
            }
        });
    }

    @Test
    public void testWriteFieldNullTargetThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                FieldUtils.writeField((Object) null, "publicChildField", "x");
            }
        });
    }

    @Test
    public void testWriteFieldWrongTypeThrows() {
        final AgentChild child = new AgentChild();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                FieldUtils.writeField(child, "publicChildField", Integer.valueOf(5));
            }
        });
    }

    @Test
    public void testWriteDeclaredFieldOnlyOwnClass() throws IllegalAccessException {
        final AgentChild child = new AgentChild();
        FieldUtils.writeDeclaredField(child, "publicChildField", "declaredValue");
        assertEquals("declaredValue", child.publicChildField);
    }

    @Test
    public void testWriteDeclaredFieldDoesNotSeeSuperclassField() {
        final AgentChild child = new AgentChild();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                FieldUtils.writeDeclaredField(child, "publicParentField", "x");
            }
        });
    }

    @Test
    public void testWriteStaticField() throws IllegalAccessException {
        FieldUtils.writeStaticField(AgentParent.class, "staticPublicParent", "changed");
        assertEquals("changed", AgentParent.staticPublicParent);
        // restore for test isolation
        AgentParent.staticPublicParent = "staticPublicParentValue";
    }

    @Test
    public void testWriteStaticFieldNonStaticThrows() throws Exception {
        final Field field = AgentChild.class.getDeclaredField("publicChildField");
        field.setAccessible(true);
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                FieldUtils.writeStaticField(field, "x");
            }
        });
    }

    @Test
    public void testWriteDeclaredStaticFieldFinalWithForceAccessThrowsIllegalAccess() {
        assertThrows(IllegalAccessException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                FieldUtils.writeDeclaredStaticField(AgentParent.class, "STATIC_FINAL_PARENT", "x", true);
            }
        });
    }

    @Test
    public void testWriteDeclaredStaticFieldUnknownWithoutForceAccessThrowsNullPointer() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                FieldUtils.writeDeclaredStaticField(AgentParent.class, "STATIC_FINAL_PARENT", "x", false);
            }
        });
    }

    @Test
    public void testWriteFieldNullFieldThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                FieldUtils.writeField((Field) null, new AgentChild(), "x");
            }
        });
    }

    //
    // removeFinalModifier
    //

    @Test
    public void testRemoveFinalModifierRemovesFinalFlag() throws Exception {
        final Field field = AgentChild.class.getDeclaredField("finalIntField");
        assertTrue(Modifier.isFinal(field.getModifiers()));
        FieldUtils.removeFinalModifier(field);
        assertFalse(Modifier.isFinal(field.getModifiers()));
    }

    @Test
    public void testRemoveFinalModifierNullFieldThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                FieldUtils.removeFinalModifier(null);
            }
        });
    }

    @Test
    public void testRemoveFinalModifierOnNonFinalFieldIsNoOp() throws Exception {
        final Field field = AgentChild.class.getDeclaredField("publicChildField");
        assertFalse(Modifier.isFinal(field.getModifiers()));
        FieldUtils.removeFinalModifier(field);
        assertFalse(Modifier.isFinal(field.getModifiers()));
    }
}
