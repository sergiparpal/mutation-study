/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link NumberUtils}.
 */
class NumberUtilsAgentTest {

    @Test
    void testConstructor() {
        assertEquals(NumberUtils.class, new NumberUtils().getClass());
    }

    @Test
    void testConstants() {
        assertEquals(Long.valueOf(0L), NumberUtils.LONG_ZERO);
        assertEquals(Long.valueOf(1L), NumberUtils.LONG_ONE);
        assertEquals(Long.valueOf(-1L), NumberUtils.LONG_MINUS_ONE);
        assertEquals(Integer.valueOf(0), NumberUtils.INTEGER_ZERO);
        assertEquals(Integer.valueOf(1), NumberUtils.INTEGER_ONE);
        assertEquals(Integer.valueOf(2), NumberUtils.INTEGER_TWO);
        assertEquals(Integer.valueOf(-1), NumberUtils.INTEGER_MINUS_ONE);
        assertEquals(Short.valueOf((short) 0), NumberUtils.SHORT_ZERO);
        assertEquals(Short.valueOf((short) 1), NumberUtils.SHORT_ONE);
        assertEquals(Short.valueOf((short) -1), NumberUtils.SHORT_MINUS_ONE);
        assertEquals(Byte.valueOf((byte) 0), NumberUtils.BYTE_ZERO);
        assertEquals(Byte.valueOf((byte) 1), NumberUtils.BYTE_ONE);
        assertEquals(Byte.valueOf((byte) -1), NumberUtils.BYTE_MINUS_ONE);
        assertEquals(Double.valueOf(0.0d), NumberUtils.DOUBLE_ZERO);
        assertEquals(Double.valueOf(1.0d), NumberUtils.DOUBLE_ONE);
        assertEquals(Double.valueOf(-1.0d), NumberUtils.DOUBLE_MINUS_ONE);
        assertEquals(Float.valueOf(0.0f), NumberUtils.FLOAT_ZERO);
        assertEquals(Float.valueOf(1.0f), NumberUtils.FLOAT_ONE);
        assertEquals(Float.valueOf(-1.0f), NumberUtils.FLOAT_MINUS_ONE);
        assertEquals(Long.valueOf(Integer.MAX_VALUE), NumberUtils.LONG_INT_MAX_VALUE);
        assertEquals(Long.valueOf(Integer.MIN_VALUE), NumberUtils.LONG_INT_MIN_VALUE);
    }

    // --- compare ---

    @Test
    void testCompareByte() {
        assertEquals(0, NumberUtils.compare((byte) 1, (byte) 1));
        assertTrue(NumberUtils.compare((byte) 1, (byte) 2) < 0);
        assertTrue(NumberUtils.compare((byte) 2, (byte) 1) > 0);
    }

    @Test
    void testCompareInt() {
        assertEquals(0, NumberUtils.compare(1, 1));
        assertTrue(NumberUtils.compare(1, 2) < 0);
        assertTrue(NumberUtils.compare(2, 1) > 0);
    }

    @Test
    void testCompareLong() {
        assertEquals(0, NumberUtils.compare(1L, 1L));
        assertTrue(NumberUtils.compare(1L, 2L) < 0);
        assertTrue(NumberUtils.compare(2L, 1L) > 0);
    }

    @Test
    void testCompareShort() {
        assertEquals(0, NumberUtils.compare((short) 1, (short) 1));
        assertTrue(NumberUtils.compare((short) 1, (short) 2) < 0);
        assertTrue(NumberUtils.compare((short) 2, (short) 1) > 0);
    }

    // --- createBigDecimal ---

    @Test
    void testCreateBigDecimal() {
        assertNull(NumberUtils.createBigDecimal(null));
        assertEquals(new BigDecimal("1.23"), NumberUtils.createBigDecimal("1.23"));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createBigDecimal(""));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createBigDecimal("   "));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createBigDecimal("not a number"));
    }

    // --- createBigInteger ---

    @Test
    void testCreateBigInteger() {
        assertNull(NumberUtils.createBigInteger(null));
        assertEquals(BigInteger.valueOf(10), NumberUtils.createBigInteger("10"));
        assertEquals(BigInteger.valueOf(-10), NumberUtils.createBigInteger("-10"));
        assertEquals(BigInteger.valueOf(16), NumberUtils.createBigInteger("0x10"));
        assertEquals(BigInteger.valueOf(16), NumberUtils.createBigInteger("0X10"));
        assertEquals(BigInteger.valueOf(16), NumberUtils.createBigInteger("#10"));
        assertEquals(BigInteger.valueOf(8), NumberUtils.createBigInteger("010"));
        assertEquals(BigInteger.valueOf(-16), NumberUtils.createBigInteger("-0x10"));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createBigInteger(""));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createBigInteger("not a number"));
    }

    // --- createDouble ---

    @Test
    void testCreateDouble() {
        assertNull(NumberUtils.createDouble(null));
        assertEquals(Double.valueOf(1.5d), NumberUtils.createDouble("1.5"));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createDouble(""));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createDouble("not a number"));
    }

    // --- createFloat ---

    @Test
    void testCreateFloat() {
        assertNull(NumberUtils.createFloat(null));
        assertEquals(Float.valueOf(1.5f), NumberUtils.createFloat("1.5"));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createFloat(""));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createFloat("not a number"));
    }

    // --- createInteger ---

    @Test
    void testCreateInteger() {
        assertNull(NumberUtils.createInteger(null));
        assertEquals(Integer.valueOf(12), NumberUtils.createInteger("12"));
        assertEquals(Integer.valueOf(0xFF), NumberUtils.createInteger("0xFF"));
        assertEquals(Integer.valueOf(8), NumberUtils.createInteger("010"));
        assertEquals(Integer.valueOf(-12), NumberUtils.createInteger("-12"));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createInteger(""));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createInteger("not a number"));
    }

    // --- createLong ---

    @Test
    void testCreateLong() {
        assertNull(NumberUtils.createLong(null));
        assertEquals(Long.valueOf(12L), NumberUtils.createLong("12"));
        assertEquals(Long.valueOf(0xFFL), NumberUtils.createLong("0xFF"));
        assertEquals(Long.valueOf(-12L), NumberUtils.createLong("-12"));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createLong(""));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createLong("not a number"));
    }

    // --- createNumber ---

    @Test
    void testCreateNumberNullAndBlank() {
        assertNull(NumberUtils.createNumber(null));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber(""));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber("   "));
    }

    @Test
    void testCreateNumberIntegers() {
        assertEquals(Integer.valueOf(12345), NumberUtils.createNumber("12345"));
        assertEquals(Long.valueOf(12345678901L), NumberUtils.createNumber("12345678901"));
        assertEquals(new BigInteger("123456789012345678901234567890"), NumberUtils.createNumber("123456789012345678901234567890"));
    }

    @Test
    void testCreateNumberHex() {
        assertEquals(Integer.valueOf(0xFF), NumberUtils.createNumber("0xFF"));
        assertEquals(Long.valueOf(0xFFFFFFFFFL), NumberUtils.createNumber("0xFFFFFFFFF"));
        assertEquals(new BigInteger("FFFFFFFFFFFFFFFFF", 16), NumberUtils.createNumber("0xFFFFFFFFFFFFFFFFF"));
    }

    @Test
    void testCreateNumberFloatsAndDoubles() {
        assertEquals(Float.valueOf(1.5f), NumberUtils.createNumber("1.5f"));
        assertEquals(Double.valueOf(1.5d), NumberUtils.createNumber("1.5d"));
        // no type requested and the value is exactly representable as a Float, so Float is preferred
        assertEquals(Float.valueOf(1.5f), NumberUtils.createNumber("1.5"));
    }

    @Test
    void testCreateNumberLongSuffix() {
        assertEquals(Long.valueOf(100L), NumberUtils.createNumber("100L"));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber("1.5L"));
    }

    @Test
    void testCreateNumberBigDecimalFallback() {
        // too large for a double/float, so falls back to BigDecimal
        assertEquals(new BigDecimal("1e400"), NumberUtils.createNumber("1e400"));
    }

    @Test
    void testCreateNumberInvalid() {
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber("1.2.3"));
        assertThrows(NumberFormatException.class, () -> NumberUtils.createNumber("abc"));
    }

    // --- isCreatable / isNumber ---

    @Test
    void testIsCreatable() {
        assertFalse(NumberUtils.isCreatable(null));
        assertFalse(NumberUtils.isCreatable(""));
        assertFalse(NumberUtils.isCreatable("   "));
        assertTrue(NumberUtils.isCreatable("12345"));
        assertTrue(NumberUtils.isCreatable("-12.5e10"));
        assertTrue(NumberUtils.isCreatable("0xFF"));
        assertFalse(NumberUtils.isCreatable("09")); // invalid octal
        assertTrue(NumberUtils.isCreatable("0.09"));
        assertFalse(NumberUtils.isCreatable("abc"));
    }

    @SuppressWarnings("deprecation")
    @Test
    void testIsNumberDelegatesToIsCreatable() {
        assertEquals(NumberUtils.isCreatable("12345"), NumberUtils.isNumber("12345"));
        assertEquals(NumberUtils.isCreatable("abc"), NumberUtils.isNumber("abc"));
    }

    // --- isDigits ---

    @Test
    void testIsDigits() {
        assertFalse(NumberUtils.isDigits(null));
        assertFalse(NumberUtils.isDigits(""));
        assertTrue(NumberUtils.isDigits("12345"));
        assertFalse(NumberUtils.isDigits("12.45"));
        assertFalse(NumberUtils.isDigits("12 45"));
        assertFalse(NumberUtils.isDigits("-12345"));
    }

    // --- isParsable ---

    @Test
    void testIsParsable() {
        assertFalse(NumberUtils.isParsable(null));
        assertFalse(NumberUtils.isParsable(""));
        assertTrue(NumberUtils.isParsable("1.2"));
        assertTrue(NumberUtils.isParsable("123"));
        assertFalse(NumberUtils.isParsable("1.2.3"));
        assertFalse(NumberUtils.isParsable("abc"));
    }

    // --- max array ---

    @Test
    void testMaxByteArray() {
        assertEquals((byte) 3, NumberUtils.max((byte) 1, (byte) 3, (byte) 2));
        assertEquals((byte) 5, NumberUtils.max((byte) 5));
        assertThrows(NullPointerException.class, () -> NumberUtils.max((byte[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.max(new byte[0]));
    }

    @Test
    void testMaxByteThreeArgs() {
        assertEquals((byte) 3, NumberUtils.max((byte) 1, (byte) 2, (byte) 3));
        assertEquals((byte) 3, NumberUtils.max((byte) 3, (byte) 2, (byte) 1));
    }

    @Test
    void testMaxDoubleArray() {
        assertEquals(3.0d, NumberUtils.max(1.0d, 3.0d, 2.0d));
        assertTrue(Double.isNaN(NumberUtils.max(1.0d, Double.NaN, 2.0d)));
        assertThrows(NullPointerException.class, () -> NumberUtils.max((double[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.max(new double[0]));
    }

    @Test
    void testMaxDoubleThreeArgs() {
        assertEquals(3.0d, NumberUtils.max(1.0d, 2.0d, 3.0d));
        assertTrue(Double.isNaN(NumberUtils.max(1.0d, Double.NaN, 2.0d)));
    }

    @Test
    void testMaxFloatArray() {
        assertEquals(3.0f, NumberUtils.max(1.0f, 3.0f, 2.0f));
        assertTrue(Float.isNaN(NumberUtils.max(1.0f, Float.NaN, 2.0f)));
        assertThrows(NullPointerException.class, () -> NumberUtils.max((float[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.max(new float[0]));
    }

    @Test
    void testMaxFloatThreeArgs() {
        assertEquals(3.0f, NumberUtils.max(1.0f, 2.0f, 3.0f));
    }

    @Test
    void testMaxIntArray() {
        assertEquals(3, NumberUtils.max(1, 3, 2));
        assertThrows(NullPointerException.class, () -> NumberUtils.max((int[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.max(new int[0]));
    }

    @Test
    void testMaxIntThreeArgs() {
        assertEquals(3, NumberUtils.max(1, 2, 3));
        assertEquals(3, NumberUtils.max(3, 2, 1));
    }

    @Test
    void testMaxLongArray() {
        assertEquals(3L, NumberUtils.max(1L, 3L, 2L));
        assertThrows(NullPointerException.class, () -> NumberUtils.max((long[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.max(new long[0]));
    }

    @Test
    void testMaxLongThreeArgs() {
        assertEquals(3L, NumberUtils.max(1L, 2L, 3L));
    }

    @Test
    void testMaxShortArray() {
        assertEquals((short) 3, NumberUtils.max((short) 1, (short) 3, (short) 2));
        assertThrows(NullPointerException.class, () -> NumberUtils.max((short[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.max(new short[0]));
    }

    @Test
    void testMaxShortThreeArgs() {
        assertEquals((short) 3, NumberUtils.max((short) 1, (short) 2, (short) 3));
    }

    // --- min array ---

    @Test
    void testMinByteArray() {
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 3, (byte) 2));
        assertThrows(NullPointerException.class, () -> NumberUtils.min((byte[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.min(new byte[0]));
    }

    @Test
    void testMinByteThreeArgs() {
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 2, (byte) 3));
        assertEquals((byte) 1, NumberUtils.min((byte) 3, (byte) 2, (byte) 1));
    }

    @Test
    void testMinDoubleArray() {
        assertEquals(1.0d, NumberUtils.min(1.0d, 3.0d, 2.0d));
        assertTrue(Double.isNaN(NumberUtils.min(1.0d, Double.NaN, 2.0d)));
        assertThrows(NullPointerException.class, () -> NumberUtils.min((double[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.min(new double[0]));
    }

    @Test
    void testMinDoubleThreeArgs() {
        assertEquals(1.0d, NumberUtils.min(1.0d, 2.0d, 3.0d));
        assertTrue(Double.isNaN(NumberUtils.min(1.0d, Double.NaN, 2.0d)));
    }

    @Test
    void testMinFloatArray() {
        assertEquals(1.0f, NumberUtils.min(1.0f, 3.0f, 2.0f));
        assertTrue(Float.isNaN(NumberUtils.min(1.0f, Float.NaN, 2.0f)));
        assertThrows(NullPointerException.class, () -> NumberUtils.min((float[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.min(new float[0]));
    }

    @Test
    void testMinFloatThreeArgs() {
        assertEquals(1.0f, NumberUtils.min(1.0f, 2.0f, 3.0f));
    }

    @Test
    void testMinIntArray() {
        assertEquals(1, NumberUtils.min(1, 3, 2));
        assertThrows(NullPointerException.class, () -> NumberUtils.min((int[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.min(new int[0]));
    }

    @Test
    void testMinIntThreeArgs() {
        assertEquals(1, NumberUtils.min(1, 2, 3));
        assertEquals(1, NumberUtils.min(3, 2, 1));
    }

    @Test
    void testMinLongArray() {
        assertEquals(1L, NumberUtils.min(1L, 3L, 2L));
        assertThrows(NullPointerException.class, () -> NumberUtils.min((long[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.min(new long[0]));
    }

    @Test
    void testMinLongThreeArgs() {
        assertEquals(1L, NumberUtils.min(1L, 2L, 3L));
    }

    @Test
    void testMinShortArray() {
        assertEquals((short) 1, NumberUtils.min((short) 1, (short) 3, (short) 2));
        assertThrows(NullPointerException.class, () -> NumberUtils.min((short[]) null));
        assertThrows(IllegalArgumentException.class, () -> NumberUtils.min(new short[0]));
    }

    @Test
    void testMinShortThreeArgs() {
        assertEquals((short) 1, NumberUtils.min((short) 1, (short) 2, (short) 3));
    }

    // --- toByte ---

    @Test
    void testToByte() {
        assertEquals((byte) 0, NumberUtils.toByte(null));
        assertEquals((byte) 0, NumberUtils.toByte(""));
        assertEquals((byte) 1, NumberUtils.toByte("1"));
        assertEquals((byte) 0, NumberUtils.toByte("not a byte"));
    }

    @Test
    void testToByteWithDefault() {
        assertEquals((byte) 1, NumberUtils.toByte(null, (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("", (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("1", (byte) 0));
        assertEquals((byte) 9, NumberUtils.toByte("not a byte", (byte) 9));
    }

    // --- toDouble ---

    @Test
    void testToDoubleBigDecimal() {
        assertEquals(0.0d, NumberUtils.toDouble((BigDecimal) null));
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d)));
    }

    @Test
    void testToDoubleBigDecimalWithDefault() {
        assertEquals(1.1d, NumberUtils.toDouble((BigDecimal) null, 1.1d));
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d), 1.1d));
    }

    @Test
    void testToDoubleString() {
        assertEquals(0.0d, NumberUtils.toDouble((String) null));
        assertEquals(0.0d, NumberUtils.toDouble(""));
        assertEquals(1.5d, NumberUtils.toDouble("1.5"));
    }

    @Test
    void testToDoubleStringWithDefault() {
        assertEquals(1.1d, NumberUtils.toDouble((String) null, 1.1d));
        assertEquals(1.1d, NumberUtils.toDouble("", 1.1d));
        assertEquals(1.5d, NumberUtils.toDouble("1.5", 0.0d));
        assertEquals(9.9d, NumberUtils.toDouble("not a double", 9.9d));
    }

    // --- toFloat ---

    @Test
    void testToFloat() {
        assertEquals(0.0f, NumberUtils.toFloat(null));
        assertEquals(0.0f, NumberUtils.toFloat(""));
        assertEquals(1.5f, NumberUtils.toFloat("1.5"));
    }

    @Test
    void testToFloatWithDefault() {
        assertEquals(1.1f, NumberUtils.toFloat(null, 1.1f));
        assertEquals(1.1f, NumberUtils.toFloat("", 1.1f));
        assertEquals(1.5f, NumberUtils.toFloat("1.5", 0.0f));
        assertEquals(9.9f, NumberUtils.toFloat("not a float", 9.9f));
    }

    // --- toInt ---

    @Test
    void testToInt() {
        assertEquals(0, NumberUtils.toInt(null));
        assertEquals(0, NumberUtils.toInt(""));
        assertEquals(1, NumberUtils.toInt("1"));
        assertEquals(0, NumberUtils.toInt("not an int"));
    }

    @Test
    void testToIntWithDefault() {
        assertEquals(1, NumberUtils.toInt(null, 1));
        assertEquals(1, NumberUtils.toInt("", 1));
        assertEquals(1, NumberUtils.toInt("1", 0));
        assertEquals(9, NumberUtils.toInt("not an int", 9));
    }

    // --- toLong ---

    @Test
    void testToLong() {
        assertEquals(0L, NumberUtils.toLong(null));
        assertEquals(0L, NumberUtils.toLong(""));
        assertEquals(1L, NumberUtils.toLong("1"));
        assertEquals(0L, NumberUtils.toLong("not a long"));
    }

    @Test
    void testToLongWithDefault() {
        assertEquals(1L, NumberUtils.toLong(null, 1L));
        assertEquals(1L, NumberUtils.toLong("", 1L));
        assertEquals(1L, NumberUtils.toLong("1", 0L));
        assertEquals(9L, NumberUtils.toLong("not a long", 9L));
    }

    // --- toShort ---

    @Test
    void testToShort() {
        assertEquals((short) 0, NumberUtils.toShort(null));
        assertEquals((short) 0, NumberUtils.toShort(""));
        assertEquals((short) 1, NumberUtils.toShort("1"));
        assertEquals((short) 0, NumberUtils.toShort("not a short"));
    }

    @Test
    void testToShortWithDefault() {
        assertEquals((short) 1, NumberUtils.toShort(null, (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("", (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("1", (short) 0));
        assertEquals((short) 9, NumberUtils.toShort("not a short", (short) 9));
    }

    // --- toScaledBigDecimal ---

    @Test
    void testToScaledBigDecimalBigDecimal() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null));
        assertEquals(new BigDecimal("1.23"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.234")));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.236")));
    }

    @Test
    void testToScaledBigDecimalBigDecimalWithScaleAndRounding() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null, 2, RoundingMode.HALF_UP));
        assertEquals(new BigDecimal("1.235"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.2345"), 3, RoundingMode.HALF_UP));
        // null roundingMode defaults to HALF_EVEN
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.235"), 2, null));
    }

    @Test
    void testToScaledBigDecimalDouble() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null));
        assertEquals(new BigDecimal("1.23"), NumberUtils.toScaledBigDecimal(Double.valueOf(1.234d)));
    }

    @Test
    void testToScaledBigDecimalDoubleWithScaleAndRounding() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null, 2, RoundingMode.HALF_UP));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal(Double.valueOf(1.235d), 2, RoundingMode.HALF_UP));
    }

    @Test
    void testToScaledBigDecimalFloat() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null));
        assertEquals(new BigDecimal("1.23"), NumberUtils.toScaledBigDecimal(Float.valueOf(1.234f)));
    }

    @Test
    void testToScaledBigDecimalFloatWithScaleAndRounding() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null, 2, RoundingMode.HALF_UP));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal(Float.valueOf(1.235f), 2, RoundingMode.HALF_UP));
    }

    @Test
    void testToScaledBigDecimalString() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null));
        assertEquals(new BigDecimal("1.23"), NumberUtils.toScaledBigDecimal("1.234"));
    }

    @Test
    void testToScaledBigDecimalStringWithScaleAndRounding() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null, 2, RoundingMode.HALF_UP));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal("1.235", 2, RoundingMode.HALF_UP));
    }
}
