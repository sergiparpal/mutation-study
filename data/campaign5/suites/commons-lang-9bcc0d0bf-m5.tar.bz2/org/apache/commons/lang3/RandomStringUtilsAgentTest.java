/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Random;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link RandomStringUtils}.
 */
class RandomStringUtilsAgentTest {

    @Test
    void testInsecureSingletonIsStableAndDistinctFromSecure() {
        assertSame(RandomStringUtils.insecure(), RandomStringUtils.insecure());
        assertNotNull(RandomStringUtils.secure());
        assertNotNull(RandomStringUtils.secureStrong());
    }

    @Test
    void testNextZeroCountReturnsEmptyString() {
        assertEquals("", RandomStringUtils.insecure().next(0));
    }

    @Test
    void testNextNegativeCountThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.insecure().next(-1);
            }
        });
    }

    @Test
    void testNextCountReturnsExpectedLength() {
        final String s = RandomStringUtils.insecure().next(50);
        assertEquals(50, s.length());
    }

    @Test
    void testNextAlphabeticOnlyContainsLetters() {
        final String s = RandomStringUtils.insecure().nextAlphabetic(200);
        assertEquals(200, s.length());
        for (int i = 0; i < s.length(); i++) {
            assertTrue(Character.isLetter(s.charAt(i)), "Expected letter at index " + i + " but was '" + s.charAt(i) + "'");
        }
    }

    @Test
    void testNextAlphabeticRangeRespectsMinAndMax() {
        final String s = RandomStringUtils.insecure().nextAlphabetic(3, 4);
        assertEquals(3, s.length());
    }

    @Test
    void testNextNumericOnlyContainsDigits() {
        final String s = RandomStringUtils.insecure().nextNumeric(200);
        assertEquals(200, s.length());
        for (int i = 0; i < s.length(); i++) {
            assertTrue(Character.isDigit(s.charAt(i)), "Expected digit at index " + i + " but was '" + s.charAt(i) + "'");
        }
    }

    @Test
    void testNextAlphanumericOnlyContainsLettersOrDigits() {
        final String s = RandomStringUtils.insecure().nextAlphanumeric(200);
        assertEquals(200, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(Character.isLetter(c) || Character.isDigit(c), "Unexpected character '" + c + "'");
        }
    }

    @Test
    void testNextAsciiWithinRange() {
        final String s = RandomStringUtils.insecure().nextAscii(200);
        assertEquals(200, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 32 && c <= 126, "Char out of ASCII range: " + (int) c);
        }
    }

    @Test
    void testNextGraphWithinRangeAndExcludesSpace() {
        final String s = RandomStringUtils.insecure().nextGraph(200);
        assertEquals(200, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 33 && c <= 126, "Char out of graph range: " + (int) c);
        }
    }

    @Test
    void testNextPrintWithinRange() {
        final String s = RandomStringUtils.insecure().nextPrint(200);
        assertEquals(200, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 32 && c <= 126, "Char out of print range: " + (int) c);
        }
    }

    @Test
    void testNextWithCustomCharArray() {
        final char[] chars = { 'x', 'y', 'z' };
        final String s = RandomStringUtils.insecure().next(100, chars);
        assertEquals(100, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c == 'x' || c == 'y' || c == 'z', "Unexpected char: " + c);
        }
    }

    @Test
    void testNextWithNullCharArrayUsesAllChars() {
        final char[] nullChars = null;
        final String s = RandomStringUtils.insecure().next(10, nullChars);
        assertEquals(10, s.length());
    }

    @Test
    void testNextWithEmptyCharArrayThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.insecure().next(5, new char[0]);
            }
        });
    }

    @Test
    void testNextWithStringChars() {
        final String s = RandomStringUtils.insecure().next(20, "ab");
        assertEquals(20, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c == 'a' || c == 'b', "Unexpected char: " + c);
        }
    }

    @Test
    void testNextWithNullStringCharsUsesAllChars() {
        final String nullString = null;
        final String s = RandomStringUtils.insecure().next(10, nullString);
        assertEquals(10, s.length());
    }

    @Test
    void testNextWithEmptyStringCharsThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.insecure().next(5, "");
            }
        });
    }

    @Test
    void testRandomStaticWithStartEndLettersNumbersAndChars() {
        final Random random = new Random(42);
        final char[] chars = { 'a', 'b', 'c', 'd' };
        final String s = RandomStringUtils.random(10, 0, chars.length, false, false, chars, random);
        assertEquals(10, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c == 'a' || c == 'b' || c == 'c' || c == 'd', "Unexpected char: " + c);
        }
    }

    @Test
    void testRandomStaticZeroCountReturnsEmptyRegardlessOfOtherArgs() {
        final Random random = new Random(1);
        assertEquals("", RandomStringUtils.random(0, 0, 0, true, true, null, random));
    }

    @Test
    void testRandomStaticNegativeCountThrows() {
        final Random random = new Random(1);
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(-5, 0, 0, false, false, null, random);
            }
        });
    }

    @Test
    void testRandomStaticEndNotGreaterThanStartThrows() {
        final Random random = new Random(1);
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 10, 5, false, false, null, random);
            }
        });
    }

    @Test
    void testRandomStaticNegativeStartThrows() {
        final Random random = new Random(1);
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, -1, 10, false, false, null, random);
            }
        });
    }

    @Test
    void testRandomStaticStartBeyondCharsLengthThrows() {
        final Random random = new Random(1);
        final char[] chars = { 'a', 'b', 'c' };
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 3, 4, false, false, chars, random);
            }
        });
    }

    @Test
    void testRandomStaticEndBeyondCharsLengthThrows() {
        final Random random = new Random(1);
        final char[] chars = { 'a', 'b', 'c' };
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 0, 4, false, false, chars, random);
            }
        });
    }

    @Test
    void testRandomStaticNoLettersInRangeThrows() {
        final Random random = new Random(1);
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, '0', '9' + 1, true, false, null, random);
            }
        });
    }

    @Test
    void testRandomStaticNoDigitsInRangeThrows() {
        final Random random = new Random(1);
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 'a', 'z' + 1, false, true, null, random);
            }
        });
    }

    @Test
    void testDeprecatedRandomCountReturnsExpectedLength() {
        final String s = RandomStringUtils.random(30);
        assertEquals(30, s.length());
    }

    @Test
    void testDeprecatedRandomAlphabeticReturnsOnlyLetters() {
        final String s = RandomStringUtils.randomAlphabetic(50);
        assertEquals(50, s.length());
        for (int i = 0; i < s.length(); i++) {
            assertTrue(Character.isLetter(s.charAt(i)));
        }
    }

    @Test
    void testDeprecatedRandomAlphanumericReturnsOnlyLettersOrDigits() {
        final String s = RandomStringUtils.randomAlphanumeric(50);
        assertEquals(50, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(Character.isLetter(c) || Character.isDigit(c));
        }
    }

    @Test
    void testDeprecatedRandomNumericReturnsOnlyDigits() {
        final String s = RandomStringUtils.randomNumeric(50);
        assertEquals(50, s.length());
        for (int i = 0; i < s.length(); i++) {
            assertTrue(Character.isDigit(s.charAt(i)));
        }
    }

    @Test
    void testDeprecatedRandomAsciiWithinRange() {
        final String s = RandomStringUtils.randomAscii(50);
        assertEquals(50, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 32 && c <= 126);
        }
    }

    @Test
    void testDeprecatedRandomGraphWithinRange() {
        final String s = RandomStringUtils.randomGraph(50);
        assertEquals(50, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 33 && c <= 126);
        }
    }

    @Test
    void testDeprecatedRandomPrintWithinRange() {
        final String s = RandomStringUtils.randomPrint(50);
        assertEquals(50, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 32 && c <= 126);
        }
    }

    @Test
    void testDeprecatedRandomWithCharArray() {
        final char[] chars = { '1', '2' };
        final String s = RandomStringUtils.random(20, chars);
        assertEquals(20, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c == '1' || c == '2');
        }
    }

    @Test
    void testDeprecatedRandomWithStringChars() {
        final String s = RandomStringUtils.random(20, "xy");
        assertEquals(20, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c == 'x' || c == 'y');
        }
    }

    @Test
    void testDeprecatedRandomWithLettersNumbersFlags() {
        final String s = RandomStringUtils.random(30, true, true);
        assertEquals(30, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(Character.isLetter(c) || Character.isDigit(c));
        }
    }

    @Test
    void testDeprecatedRandomWithStartEndLettersNumbers() {
        final String s = RandomStringUtils.random(30, 'a', 'z' + 1, true, false);
        assertEquals(30, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 'a' && c < 'z' + 1);
        }
    }

    @Test
    void testDeprecatedPublicConstructor() {
        final RandomStringUtils instance = new RandomStringUtils();
        assertNotNull(instance);
        assertNotNull(instance.next(5));
    }

    @Test
    void testToStringContainsClassName() {
        final String s = RandomStringUtils.insecure().toString();
        assertTrue(s.contains("RandomStringUtils"));
    }

    @Test
    void testMinEqualsMaxRangeProducesMinLength() {
        final String s = RandomStringUtils.insecure().nextAlphabetic(5, 6);
        assertEquals(5, s.length());
    }

    @Test
    void testNextWithExplicitRandomIsRepeatable() {
        final Random random1 = new Random(123);
        final Random random2 = new Random(123);
        final char[] chars = { 'a', 'b', 'c', 'd', 'e' };
        final String s1 = RandomStringUtils.random(15, 0, chars.length, false, false, chars, random1);
        final String s2 = RandomStringUtils.random(15, 0, chars.length, false, false, chars, random2);
        assertEquals(s1, s2);
    }
}
