/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Map;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link ArrayUtils}.
 */
class ArrayUtilsAgentTest {

    @Test
    void testIsEmptyAndIsNotEmpty() {
        assertTrue(ArrayUtils.isEmpty((Object[]) null));
        assertTrue(ArrayUtils.isEmpty(new Object[0]));
        assertFalse(ArrayUtils.isEmpty(new Object[] {"a"}));
        assertFalse(ArrayUtils.isNotEmpty((int[]) null));
        assertTrue(ArrayUtils.isNotEmpty(new int[] {1}));
        assertTrue(ArrayUtils.isEmpty((boolean[]) null));
        assertTrue(ArrayUtils.isEmpty(new boolean[0]));
    }

    @Test
    void testGetLength() {
        assertEquals(0, ArrayUtils.getLength(null));
        assertEquals(0, ArrayUtils.getLength(new Object[0]));
        assertEquals(3, ArrayUtils.getLength(new int[] {1, 2, 3}));
        assertEquals(2, ArrayUtils.getLength(new String[] {"a", "b"}));
    }

    @Test
    void testGetLengthNonArrayThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ArrayUtils.getLength("not an array");
            }
        });
    }

    @Test
    void testGetComponentType() {
        final String[] array = {"a", "b"};
        assertEquals(String.class, ArrayUtils.getComponentType(array));
    }

    @Test
    void testHashCode() {
        assertEquals(ArrayUtils.hashCode(null), ArrayUtils.hashCode(null));
        final int[] array1 = {1, 2, 3};
        final int[] array2 = {1, 2, 3};
        final int[] array3 = {3, 2, 1};
        assertEquals(ArrayUtils.hashCode(array1), ArrayUtils.hashCode(array2));
        assertFalse(ArrayUtils.hashCode(array1) == ArrayUtils.hashCode(array3));
    }

    @Test
    void testContainsPrimitivesAndObjects() {
        final int[] intArray = {1, 2, 3};
        assertTrue(ArrayUtils.contains(intArray, 2));
        assertFalse(ArrayUtils.contains(intArray, 4));
        assertFalse(ArrayUtils.contains((int[]) null, 1));

        final Object[] objArray = {"a", "b", null};
        assertTrue(ArrayUtils.contains(objArray, "a"));
        assertTrue(ArrayUtils.contains(objArray, null));
        assertFalse(ArrayUtils.contains(objArray, "z"));
        assertFalse(ArrayUtils.contains((Object[]) null, "a"));

        assertTrue(ArrayUtils.contains(new double[] {1.0, 2.0}, 1.0005, 0.01));
        assertFalse(ArrayUtils.contains(new double[] {1.0, 2.0}, 1.5, 0.01));
    }

    @Test
    void testContainsAny() {
        final int[] intArray = {1, 2, 3};
        assertTrue(ArrayUtils.containsAny(intArray, 5, 2));
        assertFalse(ArrayUtils.containsAny(intArray, 5, 6));
        assertFalse(ArrayUtils.containsAny((int[]) null, 1));

        final Object[] objArray = {"a", "b"};
        assertTrue(ArrayUtils.containsAny(objArray, "z", "b"));
        assertFalse(ArrayUtils.containsAny(objArray, "y", "z"));
    }

    @Test
    void testIndexOfAndLastIndexOf() {
        final int[] array = {5, 6, 7, 6, 5};
        assertEquals(0, ArrayUtils.indexOf(array, 5));
        assertEquals(1, ArrayUtils.indexOf(array, 6));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf(array, 42));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf((int[]) null, 5));
        // negative startIndex treated as 0
        assertEquals(0, ArrayUtils.indexOf(array, 5, -5));
        // startIndex beyond length returns not found
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf(array, 5, 100));

        assertEquals(4, ArrayUtils.lastIndexOf(array, 5));
        assertEquals(3, ArrayUtils.lastIndexOf(array, 6));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.lastIndexOf(array, 42));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.lastIndexOf((int[]) null, 5));
    }

    @Test
    void testIndexOfObjectWithNullElement() {
        final Object[] array = {"a", null, "b", null};
        assertEquals(1, ArrayUtils.indexOf(array, null));
        assertEquals(3, ArrayUtils.lastIndexOf(array, null));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf(array, "zzz"));
    }

    @Test
    void testIsArrayIndexValid() {
        final String[] array = {"a", "b"};
        assertTrue(ArrayUtils.isArrayIndexValid(array, 0));
        assertTrue(ArrayUtils.isArrayIndexValid(array, 1));
        assertFalse(ArrayUtils.isArrayIndexValid(array, 2));
        assertFalse(ArrayUtils.isArrayIndexValid(array, -1));
        assertFalse(ArrayUtils.isArrayIndexValid((String[]) null, 0));
    }

    @Test
    void testIsSameLengthAndIsSameType() {
        assertTrue(ArrayUtils.isSameLength(new int[] {1, 2}, new int[] {3, 4}));
        assertFalse(ArrayUtils.isSameLength(new int[] {1, 2}, new int[] {3}));
        assertTrue(ArrayUtils.isSameLength((Object[]) null, (Object[]) null));
        assertFalse(ArrayUtils.isSameLength(new Object[] {1}, null));

        assertTrue(ArrayUtils.isSameType(new String[0], new String[0]));
        assertFalse(ArrayUtils.isSameType(new String[0], new Integer[0]));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ArrayUtils.isSameType(null, new Object[0]);
            }
        });
    }

    @Test
    void testIsSorted() {
        assertTrue(ArrayUtils.isSorted(new int[] {1, 2, 3}));
        assertFalse(ArrayUtils.isSorted(new int[] {3, 2, 1}));
        assertTrue(ArrayUtils.isSorted((int[]) null));
        assertTrue(ArrayUtils.isSorted(new int[0]));
        assertTrue(ArrayUtils.isSorted(new int[] {1}));
    }

    @Test
    void testCloneArrays() {
        assertNull(ArrayUtils.clone((Object[]) null));
        assertNull(ArrayUtils.clone((int[]) null));

        final int[] intArray = {1, 2, 3};
        final int[] intClone = ArrayUtils.clone(intArray);
        assertArrayEquals(intArray, intClone);
        assertNotSame(intArray, intClone);

        final String[] strArray = {"a", "b"};
        final String[] strClone = ArrayUtils.clone(strArray);
        assertArrayEquals(strArray, strClone);
        assertNotSame(strArray, strClone);
    }

    @Test
    void testReverse() {
        final int[] array = {1, 2, 3, 4, 5};
        ArrayUtils.reverse(array);
        assertArrayEquals(new int[] {5, 4, 3, 2, 1}, array);

        final int[] partial = {1, 2, 3, 4, 5};
        ArrayUtils.reverse(partial, 1, 4);
        assertArrayEquals(new int[] {1, 4, 3, 2, 5}, partial);

        // null and empty arrays are no-ops, not errors
        ArrayUtils.reverse((int[]) null);
        final int[] empty = {};
        ArrayUtils.reverse(empty);
        assertEquals(0, empty.length);
    }

    @Test
    void testSwap() {
        final int[] array = {1, 2, 3};
        ArrayUtils.swap(array, 0, 2);
        assertArrayEquals(new int[] {3, 2, 1}, array);

        // overflow index -> no-op
        final int[] array2 = {1, 2, 3};
        ArrayUtils.swap(array2, 0, 5);
        assertArrayEquals(new int[] {1, 2, 3}, array2);

        // negative index promoted to 0
        final int[] array3 = {1, 2, 3};
        ArrayUtils.swap(array3, -1, 1);
        assertArrayEquals(new int[] {2, 1, 3}, array3);

        // null array is a no-op, does not throw
        ArrayUtils.swap((int[]) null, 0, 1);
    }

    @Test
    void testShift() {
        final int[] array = {1, 2, 3, 4, 5};
        ArrayUtils.shift(array, 1);
        assertArrayEquals(new int[] {5, 1, 2, 3, 4}, array);

        final int[] array2 = {1, 2, 3, 4, 5};
        ArrayUtils.shift(array2, -1);
        assertArrayEquals(new int[] {2, 3, 4, 5, 1}, array2);

        // null and empty are no-ops
        ArrayUtils.shift((int[]) null, 1);
        final int[] empty = {};
        ArrayUtils.shift(empty, 1);
        assertEquals(0, empty.length);
    }

    @Test
    void testSubarray() {
        final int[] array = {1, 2, 3, 4, 5};
        assertArrayEquals(new int[] {2, 3}, ArrayUtils.subarray(array, 1, 3));
        assertNull(ArrayUtils.subarray((int[]) null, 0, 1));

        // undervalue start promoted to 0
        assertArrayEquals(new int[] {1, 2}, ArrayUtils.subarray(array, -5, 2));
        // overvalue end demoted to array length
        assertArrayEquals(new int[] {4, 5}, ArrayUtils.subarray(array, 3, 100));
        // end <= start yields empty array, not an error
        assertArrayEquals(new int[0], ArrayUtils.subarray(array, 3, 1));
    }

    @Test
    void testStartsWith() {
        assertTrue(ArrayUtils.startsWith(new byte[] {1, 2, 3}, new byte[] {1, 2}));
        assertFalse(ArrayUtils.startsWith(new byte[] {1, 2, 3}, new byte[] {2, 3}));
        assertTrue(ArrayUtils.startsWith((byte[]) null, (byte[]) null));
        assertFalse(ArrayUtils.startsWith(new byte[] {1}, null));
        assertFalse(ArrayUtils.startsWith(null, new byte[] {1}));
        // expected longer than data
        assertFalse(ArrayUtils.startsWith(new byte[] {1}, new byte[] {1, 2}));
        assertTrue(ArrayUtils.startsWith(new byte[] {1, 2, 3}, new byte[] {1, 2, 3}));
    }

    @Test
    void testToObjectAndToPrimitive() {
        final int[] primitiveInts = {1, 2, 3};
        final Integer[] boxedInts = ArrayUtils.toObject(primitiveInts);
        assertArrayEquals(new Integer[] {1, 2, 3}, boxedInts);

        final Integer[] boxedWithNull = {1, null, 3};
        final int[] unboxed = ArrayUtils.toPrimitive(boxedWithNull, -1);
        assertArrayEquals(new int[] {1, -1, 3}, unboxed);

        assertNull(ArrayUtils.toPrimitive((Integer[]) null));
        assertEquals(0, ArrayUtils.toPrimitive(new Integer[0]).length);

        final boolean[] primitiveBools = ArrayUtils.toPrimitive(new Boolean[] {Boolean.TRUE, Boolean.FALSE});
        assertArrayEquals(new boolean[] {true, false}, primitiveBools);
    }

    @Test
    void testToPrimitiveObjectOverload() {
        final Integer[] boxed = {1, 2, 3};
        final Object result = ArrayUtils.toPrimitive(boxed);
        assertArrayEquals(new int[] {1, 2, 3}, (int[]) result);
        assertNull(ArrayUtils.toPrimitive((Object) null));
    }

    @Test
    void testToMap() {
        assertNull(ArrayUtils.toMap(null));

        final Map<Object, Object> map = ArrayUtils.toMap(new String[][] {
                {"key1", "value1"}, {"key2", "value2"}
        });
        assertEquals(2, map.size());
        assertEquals("value1", map.get("key1"));
        assertEquals("value2", map.get("key2"));

        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ArrayUtils.toMap(new Object[] {"notAnEntryOrArray"});
            }
        });

        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ArrayUtils.toMap(new Object[] {new Object[] {"onlyOneElement"}});
            }
        });
    }

    @Test
    void testToStringAndToStringArray() {
        assertEquals("{}", ArrayUtils.toString(null));
        assertEquals("<null>", ArrayUtils.toString(null, "<null>"));
        assertEquals("{1,2,3}", ArrayUtils.toString(new int[] {1, 2, 3}));

        final String[] strings = ArrayUtils.toStringArray(new Object[] {1, "x", null});
        assertEquals("1", strings[0]);
        assertEquals("x", strings[1]);
        assertEquals("<empty>", ArrayUtils.toStringArray(new Object[] {null}, "<empty>")[0]);
    }

    @Test
    void testNewInstance() {
        final String[] array = ArrayUtils.newInstance(String.class, 3);
        assertEquals(3, array.length);
        assertNull(array[0]);
        assertEquals(String.class, array.getClass().getComponentType());

        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ArrayUtils.newInstance(null, 1);
            }
        });
    }

    @Test
    void testNullToAndNullToEmpty() {
        final String[] defaultArray = {"default"};
        assertSame(defaultArray, ArrayUtils.nullTo(null, defaultArray));
        final String[] nonEmpty = {"a"};
        assertSame(nonEmpty, ArrayUtils.nullTo(nonEmpty, defaultArray));

        assertArrayEquals(ArrayUtils.EMPTY_INT_ARRAY, ArrayUtils.nullToEmpty((int[]) null));
        final int[] ints = {1, 2};
        assertSame(ints, ArrayUtils.nullToEmpty(ints));
    }

    @Test
    void testConcat() {
        final int[] concatenated = ArrayUtils.concat(new int[] {1, 2}, new int[] {3, 4});
        assertArrayEquals(new int[] {1, 2, 3, 4}, concatenated);
        // a null array among the varargs is simply skipped
        assertArrayEquals(new int[] {1, 2, 3}, ArrayUtils.concat(new int[] {1, 2}, null, new int[] {3}));
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ArrayUtils.concat((int[][]) null);
            }
        });
    }

    @Test
    void testAddAll() {
        final int[] combined = ArrayUtils.addAll(new int[] {1, 2}, 3, 4);
        assertArrayEquals(new int[] {1, 2, 3, 4}, combined);
        assertArrayEquals(new int[] {1, 2}, ArrayUtils.addAll(new int[] {1, 2}, (int[]) null));
        assertArrayEquals(new int[] {1, 2}, ArrayUtils.addAll((int[]) null, 1, 2));
    }

    @Test
    void testGetAndGetWithDefault() {
        final String[] array = {"a", "b"};
        assertEquals("a", ArrayUtils.get(array, 0));
        assertNull(ArrayUtils.get(array, -1));
        assertNull(ArrayUtils.get(array, 5));
        assertEquals("default", ArrayUtils.get(array, 5, "default"));
        assertEquals("b", ArrayUtils.get(array, 1, "default"));
    }

    @Test
    void testRemoveAndInsertBoundaryErrors() {
        final int[] array = {1, 2, 3};
        assertArrayEquals(new int[] {1, 3}, ArrayUtils.remove(array, 1));

        assertThrows(IndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ArrayUtils.remove(array, 10);
            }
        });

        final String[] inserted = ArrayUtils.insert(1, new String[] {"a", "c"}, "b");
        assertArrayEquals(new String[] {"a", "b", "c"}, inserted);

        assertThrows(IndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ArrayUtils.insert(-1, new String[] {"a"}, "b");
            }
        });
    }

    @Test
    void testGetDimensions() {
        assertEquals(0, ArrayUtils.getDimensions(null));
        assertEquals(0, ArrayUtils.getDimensions("not an array"));
        assertEquals(1, ArrayUtils.getDimensions(new int[3]));
        assertEquals(2, ArrayUtils.getDimensions(new int[2][2]));
    }
}
