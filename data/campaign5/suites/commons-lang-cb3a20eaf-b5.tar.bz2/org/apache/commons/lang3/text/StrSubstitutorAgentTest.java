/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link StrSubstitutor}.
 */
@SuppressWarnings("deprecation")
class StrSubstitutorAgentTest {

    /** Subclass used to verify that {@link StrSubstitutor#resolveVariable} is invoked with correct positions. */
    private static final class RecordingSubstitutor extends StrSubstitutor {

        private String lastVariableName;
        private int lastStartPos = -1;
        private int lastEndPos = -1;
        private int callCount;

        RecordingSubstitutor(final Map<String, String> valueMap) {
            super(valueMap);
        }

        @Override
        protected String resolveVariable(final String variableName, final StrBuilder buf, final int startPos, final int endPos) {
            lastVariableName = variableName;
            lastStartPos = startPos;
            lastEndPos = endPos;
            callCount++;
            return super.resolveVariable(variableName, buf, startPos, endPos);
        }
    }

    private Map<String, String> createMap() {
        final Map<String, String> map = new HashMap<String, String>();
        map.put("animal", "quick brown fox");
        map.put("target", "lazy dog");
        return map;
    }

    @Test
    void testStaticReplaceWithMap() {
        final Map<String, String> map = createMap();
        final String result = StrSubstitutor.replace("The ${animal} jumps over the ${target}.", map);
        assertEquals("The quick brown fox jumps over the lazy dog.", result);
    }

    @Test
    void testStaticReplaceWithMapAndCustomPrefixSuffix() {
        final Map<String, String> map = createMap();
        final String result = StrSubstitutor.replace("The <animal> jumps over the <target>.", map, "<", ">");
        assertEquals("The quick brown fox jumps over the lazy dog.", result);
    }

    @Test
    void testStaticReplaceWithNullOrEmptyPrefixSuffixThrows() {
        final Map<String, String> map = createMap();
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StrSubstitutor.replace("x", map, null, ">");
            }
        });
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StrSubstitutor.replace("x", map, "<", null);
            }
        });
    }

    @Test
    void testStaticReplaceWithProperties() {
        final Properties props = new Properties();
        props.setProperty("name", "world");
        final String result = StrSubstitutor.replace("Hello ${name}!", props);
        assertEquals("Hello world!", result);
    }

    @Test
    void testStaticReplaceWithNullProperties() {
        final String source = "Hello ${name}!";
        final Properties props = null;
        final String result = StrSubstitutor.replace(source, props);
        assertEquals(source, result);
    }

    @Test
    void testStaticReplaceSystemProperties() {
        final String javaVersion = System.getProperty("java.version");
        final String result = StrSubstitutor.replaceSystemProperties("Running Java ${java.version}");
        assertEquals("Running Java " + javaVersion, result);
    }

    @Test
    void testReplaceNullSourcesReturnNull() {
        final StrSubstitutor sub = new StrSubstitutor(createMap());
        assertNull(sub.replace((String) null));
        assertNull(sub.replace((Object) null));
        assertNull(sub.replace((char[]) null));
        assertNull(sub.replace((CharSequence) null));
        assertNull(sub.replace((StrBuilder) null));
        assertNull(sub.replace((StringBuffer) null));
    }

    @Test
    void testReplaceCharArray() {
        final StrSubstitutor sub = new StrSubstitutor(createMap());
        final char[] source = "The ${animal} ran.".toCharArray();
        final String result = sub.replace(source);
        assertEquals("The quick brown fox ran.", result);
        // original array must not be altered
        assertEquals("The ${animal} ran.", new String(source));
    }

    @Test
    void testReplaceCharArrayWithOffsetAndLength() {
        final StrSubstitutor sub = new StrSubstitutor(createMap());
        final char[] source = "XXX${animal}YYY".toCharArray();
        final String result = sub.replace(source, 3, 9);
        assertEquals("quick brown fox", result);
    }

    @Test
    void testReplaceCharSequenceWithOffsetAndLength() {
        final StrSubstitutor sub = new StrSubstitutor(createMap());
        final CharSequence source = "XXX${animal}YYY";
        final String result = sub.replace(source, 3, 9);
        assertEquals("quick brown fox", result);
    }

    @Test
    void testReplaceStringBuilderArgument() {
        final StrSubstitutor sub = new StrSubstitutor(createMap());
        final StrBuilder source = new StrBuilder("The ${target} sleeps.");
        final String result = sub.replace(source);
        assertEquals("The lazy dog sleeps.", result);
        // the input builder must be unchanged
        assertEquals("The ${target} sleeps.", source.toString());
    }

    @Test
    void testReplaceStringBufferArgument() {
        final StrSubstitutor sub = new StrSubstitutor(createMap());
        final StringBuffer source = new StringBuffer("The ${target} sleeps.");
        final String result = sub.replace(source);
        assertEquals("The lazy dog sleeps.", result);
        assertEquals("The ${target} sleeps.", source.toString());
    }

    @Test
    void testReplaceStringOffsetLengthBoundary() {
        final StrSubstitutor sub = new StrSubstitutor(createMap());
        final String source = "XXX${animal}YYY";
        // zero-length region: nothing to substitute
        assertEquals("", sub.replace(source, 3, 0));
        // full variable only
        assertEquals("quick brown fox", sub.replace(source, 3, 9));
    }

    @Test
    void testReplaceStringUnchangedReturnsEqualValue() {
        final StrSubstitutor sub = new StrSubstitutor(createMap());
        final String source = "no variables here";
        assertEquals(source, sub.replace(source));
    }

    @Test
    void testReplaceInStrBuilderMutatesAndReturnsTrue() {
        final StrSubstitutor sub = new StrSubstitutor(createMap());
        final StrBuilder source = new StrBuilder("The ${animal} jumps.");
        final boolean altered = sub.replaceIn(source);
        assertTrue(altered);
        assertEquals("The quick brown fox jumps.", source.toString());
    }

    @Test
    void testReplaceInStrBuilderNoVariablesReturnsFalse() {
        final StrSubstitutor sub = new StrSubstitutor(createMap());
        final StrBuilder source = new StrBuilder("nothing to replace");
        final boolean altered = sub.replaceIn(source);
        assertFalse(altered);
        assertEquals("nothing to replace", source.toString());
    }

    @Test
    void testReplaceInStrBuilderNullReturnsFalse() {
        final StrSubstitutor sub = new StrSubstitutor(createMap());
        assertFalse(sub.replaceIn((StrBuilder) null));
    }

    @Test
    void testReplaceInStringBufferMutatesAndReturnsTrue() {
        final StrSubstitutor sub = new StrSubstitutor(createMap());
        final StringBuffer source = new StringBuffer("The ${animal} jumps.");
        final boolean altered = sub.replaceIn(source);
        assertTrue(altered);
        assertEquals("The quick brown fox jumps.", source.toString());
    }

    @Test
    void testReplaceInStringBufferNullReturnsFalse() {
        final StrSubstitutor sub = new StrSubstitutor(createMap());
        assertFalse(sub.replaceIn((StringBuffer) null));
    }

    @Test
    void testReplaceInStringBuilderMutatesAndReturnsTrue() {
        final StrSubstitutor sub = new StrSubstitutor(createMap());
        final StringBuilder source = new StringBuilder("The ${animal} jumps.");
        final boolean altered = sub.replaceIn(source);
        assertTrue(altered);
        assertEquals("The quick brown fox jumps.", source.toString());
    }

    @Test
    void testReplaceInStringBuilderNullReturnsFalse() {
        final StrSubstitutor sub = new StrSubstitutor(createMap());
        assertFalse(sub.replaceIn((StringBuilder) null));
    }

    @Test
    void testUnknownVariableLeftUnresolved() {
        final StrSubstitutor sub = new StrSubstitutor(createMap());
        final String result = sub.replace("Hello ${unknown}!");
        assertEquals("Hello ${unknown}!", result);
    }

    @Test
    void testDefaultValueDelimiterUsed() {
        final StrSubstitutor sub = new StrSubstitutor(createMap());
        final String result = sub.replace("Value: ${missing:-fallback}");
        assertEquals("Value: fallback", result);
    }

    @Test
    void testDefaultValueDelimiterDisabledLeavesLiteral() {
        final StrSubstitutor sub = new StrSubstitutor(createMap());
        sub.setValueDelimiterMatcher(null);
        assertNull(sub.getValueDelimiterMatcher());
        final String result = sub.replace("Value: ${missing:-fallback}");
        assertEquals("Value: ${missing:-fallback}", result);
    }

    @Test
    void testCustomSingleCharValueDelimiter() {
        final StrSubstitutor sub = new StrSubstitutor(createMap());
        sub.setValueDelimiter('=');
        final String result = sub.replace("Value: ${missing=fallback}");
        assertEquals("Value: fallback", result);
    }

    @Test
    void testCustomStringValueDelimiterEmptyDisables() {
        final StrSubstitutor sub = new StrSubstitutor(createMap());
        sub.setValueDelimiter("");
        assertNull(sub.getValueDelimiterMatcher());
    }

    @Test
    void testRecursiveVariableValues() {
        final Map<String, String> map = new HashMap<String, String>();
        map.put("name", "${city}");
        map.put("city", "Paris");
        final StrSubstitutor sub = new StrSubstitutor(map);
        assertEquals("Paris", sub.replace("${name}"));
    }

    @Test
    void testCyclicSubstitutionThrows() {
        final Map<String, String> map = new HashMap<String, String>();
        map.put("a", "${b}");
        map.put("b", "${a}");
        final StrSubstitutor sub = new StrSubstitutor(map);
        final IllegalStateException ex = assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sub.replace("${a}");
            }
        });
        assertTrue(ex.getMessage().contains("Infinite loop"));
    }

    @Test
    void testMaxSubstitutionDepthExceededThrows() {
        final int chainLength = 300;
        final Map<String, String> map = new HashMap<String, String>();
        for (int i = 0; i < chainLength; i++) {
            map.put("v" + i, "${v" + (i + 1) + "}");
        }
        map.put("v" + chainLength, "end");
        final StrSubstitutor sub = new StrSubstitutor(map);
        final IllegalStateException ex = assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sub.replace("${v0}");
            }
        });
        assertTrue(ex.getMessage().contains("Maximum interpolation depth"));
    }

    @Test
    void testMaxSubstitutionLengthExceededThrows() {
        final int size = 16 * 1024 * 1024 + 1;
        final char[] chars = new char[size];
        Arrays.fill(chars, 'x');
        final String huge = new String(chars);
        final Map<String, String> map = new HashMap<String, String>();
        map.put("big", huge);
        final StrSubstitutor sub = new StrSubstitutor(map);
        final IllegalStateException ex = assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sub.replace("${big}");
            }
        });
        assertTrue(ex.getMessage().contains("Maximum interpolation size"));
    }

    @Test
    void testEscapeCharacterPreventsSubstitutionByDefault() {
        final StrSubstitutor sub = new StrSubstitutor(createMap());
        final String result = sub.replace("Escaped: $${animal}");
        assertEquals("Escaped: ${animal}", result);
    }

    @Test
    void testPreserveEscapesKeepsEscapeCharacter() {
        final StrSubstitutor sub = new StrSubstitutor(createMap());
        assertFalse(sub.isPreserveEscapes());
        sub.setPreserveEscapes(true);
        assertTrue(sub.isPreserveEscapes());
        final String result = sub.replace("Escaped: $${animal}");
        assertEquals("Escaped: $${animal}", result);
    }

    @Test
    void testCustomEscapeCharacter() {
        final StrSubstitutor sub = new StrSubstitutor(createMap());
        sub.setEscapeChar('~');
        assertEquals('~', sub.getEscapeChar());
        final String result = sub.replace("Escaped: ~${animal} Normal: ${target}");
        assertEquals("Escaped: ${animal} Normal: lazy dog", result);
    }

    @Test
    void testEnableSubstitutionInVariablesDefaultFalse() {
        final StrSubstitutor sub = new StrSubstitutor(createMap());
        assertFalse(sub.isEnableSubstitutionInVariables());
        final Map<String, String> map = new HashMap<String, String>();
        map.put("x", "1");
        map.put("jre-1", "Java8");
        final StrSubstitutor sub2 = new StrSubstitutor(map);
        final String result = sub2.replace("${jre-${x}}");
        assertEquals("${jre-${x}}", result);
    }

    @Test
    void testEnableSubstitutionInVariablesResolvesNestedNames() {
        final Map<String, String> map = new HashMap<String, String>();
        map.put("x", "1");
        map.put("jre-1", "Java8");
        final StrSubstitutor sub = new StrSubstitutor(map);
        sub.setEnableSubstitutionInVariables(true);
        assertTrue(sub.isEnableSubstitutionInVariables());
        final String result = sub.replace("${jre-${x}}");
        assertEquals("Java8", result);
    }

    @Test
    void testCustomPrefixSuffixMatchers() {
        final StrSubstitutor sub = new StrSubstitutor(createMap());
        sub.setVariablePrefix('<');
        sub.setVariableSuffix('>');
        assertNotNull(sub.getVariablePrefixMatcher());
        assertNotNull(sub.getVariableSuffixMatcher());
        final String result = sub.replace("The <animal> jumps.");
        assertEquals("The quick brown fox jumps.", result);
    }

    @Test
    void testSetVariablePrefixNullThrows() {
        final StrSubstitutor sub = new StrSubstitutor(createMap());
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sub.setVariablePrefix((String) null);
            }
        });
    }

    @Test
    void testSetVariableSuffixNullThrows() {
        final StrSubstitutor sub = new StrSubstitutor(createMap());
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sub.setVariableSuffix((String) null);
            }
        });
    }

    @Test
    void testSetVariablePrefixMatcherNullThrows() {
        final StrSubstitutor sub = new StrSubstitutor(createMap());
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sub.setVariablePrefixMatcher(null);
            }
        });
    }

    @Test
    void testSetVariableSuffixMatcherNullThrows() {
        final StrSubstitutor sub = new StrSubstitutor(createMap());
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sub.setVariableSuffixMatcher(null);
            }
        });
    }

    @Test
    void testGetAndSetVariableResolver() {
        final StrLookup<String> resolver = StrLookup.mapLookup(createMap());
        final StrSubstitutor sub = new StrSubstitutor();
        assertNull(sub.getVariableResolver());
        sub.setVariableResolver(resolver);
        assertSame(resolver, sub.getVariableResolver());
        assertEquals("quick brown fox", sub.replace("${animal}"));
    }

    @Test
    void testResolveVariableReceivesCorrectPositions() {
        final RecordingSubstitutor sub = new RecordingSubstitutor(createMap());
        final String source = "The ${animal} jumps.";
        final String result = sub.replace(source);
        assertEquals("The quick brown fox jumps.", result);
        assertEquals(1, sub.callCount);
        assertEquals("animal", sub.lastVariableName);
        assertEquals(4, sub.lastStartPos);
        assertEquals(13, sub.lastEndPos);
    }

    @Test
    void testNoVariableResolverReturnsNullFromResolveVariable() {
        final StrSubstitutor sub = new StrSubstitutor();
        final String result = sub.replace("Hello ${name}!");
        assertEquals("Hello ${name}!", result);
    }

    @Test
    void testMultipleOccurrencesOfSameVariable() {
        final StrSubstitutor sub = new StrSubstitutor(createMap());
        final String result = sub.replace("${animal} and ${animal} again");
        assertEquals("quick brown fox and quick brown fox again", result);
    }

    @Test
    void testConstantsHaveExpectedValues() {
        assertEquals('$', StrSubstitutor.DEFAULT_ESCAPE);
        assertNotNull(StrSubstitutor.DEFAULT_PREFIX);
        assertNotNull(StrSubstitutor.DEFAULT_SUFFIX);
        assertNotNull(StrSubstitutor.DEFAULT_VALUE_DELIMITER);
    }
}
