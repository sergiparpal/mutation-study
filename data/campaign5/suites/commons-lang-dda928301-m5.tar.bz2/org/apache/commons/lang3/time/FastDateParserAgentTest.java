/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link FastDateParser}.
 */
class FastDateParserAgentTest {

    private static final TimeZone UTC = TimeZone.getTimeZone("UTC");

    private static Calendar calendarFor(final Date date, final TimeZone tz) {
        final Calendar cal = Calendar.getInstance(tz, Locale.US);
        cal.setTime(date);
        return cal;
    }

    @Test
    void testBasicParseYearMonthDay() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final Date date = parser.parse("2021-07-04");
        final Calendar cal = calendarFor(date, UTC);
        assertEquals(2021, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JULY, cal.get(Calendar.MONTH));
        assertEquals(4, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseThrowsOnUnparseableDate() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final ParseException ex = assertThrows(ParseException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                parser.parse("not-a-date");
            }
        });
        assertTrue(ex.getMessage().contains("Unparseable date"));
        assertTrue(ex.getErrorOffset() >= 0);
    }

    @Test
    void testParseWithParsePositionPartialConsumption() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("2021-07-04 trailing", pos);
        assertNotNull(date);
        // Only the date portion should have been consumed, leaving the rest unparsed.
        assertEquals(10, pos.getIndex());
    }

    @Test
    void testParseWithParsePositionFailureSetsErrorIndexAndReturnsNull() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("20xx-07-04", pos);
        assertNull(date);
        // The error index points at the character that broke the match ('x' after the year digits).
        assertEquals(2, pos.getErrorIndex());
    }

    @Test
    void testParseCalendarOverloadReturnsFalseOnFailure() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.clear();
        final boolean result = parser.parse("bogus", pos, cal);
        assertFalse(result);
    }

    @Test
    void testParseCalendarOverloadReturnsTrueAndUpdatesCalendarOnSuccess() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.clear();
        final boolean result = parser.parse("1999-12-31", pos, cal);
        assertTrue(result);
        assertEquals(1999, cal.get(Calendar.YEAR));
        assertEquals(Calendar.DECEMBER, cal.get(Calendar.MONTH));
        assertEquals(31, cal.get(Calendar.DAY_OF_MONTH));
        assertEquals(10, pos.getIndex());
    }

    @Test
    void testParseObjectDelegatesToParse() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final Object obj = parser.parseObject("2020-01-02");
        assertTrue(obj instanceof Date);
        final Calendar cal = calendarFor((Date) obj, UTC);
        assertEquals(2020, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));
        assertEquals(2, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseObjectWithPosition() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Object obj = parser.parseObject("2020-01-02", pos);
        assertNotNull(obj);
        assertEquals(10, pos.getIndex());
    }

    @Test
    void testTwoDigitYearAdjustment() throws ParseException {
        // No explicit centuryStart: current year - 80 is used as the pivot.
        final FastDateParser parser = new FastDateParser("yy", UTC, Locale.US);
        final Date date = parser.parse("30");
        final Calendar cal = calendarFor(date, UTC);
        // The two digit year '30' should resolve to a 4 digit year ending in 30.
        assertEquals(30, cal.get(Calendar.YEAR) % 100);
    }

    @Test
    void testTwoDigitYearWithExplicitCenturyStart() throws ParseException {
        final Date centuryStart = new GregorianCalendar(1950, Calendar.JANUARY, 1, 0, 0, 0).getTime();
        final FastDateParser parser = new FastDateParser("yy-MM-dd", UTC, Locale.US, centuryStart);
        // 49 is below the startYear pivot (50) so it rolls to the next century: 2049.
        final Date below = parser.parse("49-01-01");
        assertEquals(2049, calendarFor(below, UTC).get(Calendar.YEAR));
        // 50 is at or above the pivot so it stays in the base century: 1950.
        final Date atPivot = parser.parse("50-01-01");
        assertEquals(1950, calendarFor(atPivot, UTC).get(Calendar.YEAR));
    }

    @Test
    void testFourDigitYearIsNotAdjusted() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final Date date = parser.parse("0030-01-01");
        assertEquals(30, calendarFor(date, UTC).get(Calendar.YEAR));
    }

    @Test
    void testIso8601TimeZoneOneDigit() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd'T'HH:mm:ssX", UTC, Locale.US);
        final Date date = parser.parse("2021-01-01T00:00:00Z");
        assertNotNull(date);
    }

    @Test
    void testIso8601TimeZoneInvalidWidthThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new FastDateParser("XXXX", UTC, Locale.US);
            }
        });
    }

    @Test
    void testUnsupportedFormatLetterThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new FastDateParser("yyyy-QQ-dd", UTC, Locale.US);
            }
        });
        assertTrue(ex.getMessage().contains("Q"));
    }

    @Test
    void testUnterminatedQuoteThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new FastDateParser("yyyy-MM-dd'bad", UTC, Locale.US);
            }
        });
    }

    @Test
    void testLiteralTextMustMatchExactly() {
        final FastDateParser parser = new FastDateParser("yyyy'-'MM'-'dd", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("2021-07-04", pos);
        assertNotNull(date);
        final ParsePosition failPos = new ParsePosition(0);
        final Date failDate = parser.parse("2021/07/04", failPos);
        assertNull(failDate);
        assertTrue(failPos.getErrorIndex() >= 0);
    }

    @Test
    void testLiteralTextFailsWhenSourceTooShort() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("2021", pos);
        assertNull(date);
    }

    @Test
    void testEscapedQuoteLiteral() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy''MM''dd", UTC, Locale.US);
        final Date date = parser.parse("2021'07'04");
        final Calendar cal = calendarFor(date, UTC);
        assertEquals(2021, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JULY, cal.get(Calendar.MONTH));
        assertEquals(4, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testTwelveHourMidnightNoonMapping() throws ParseException {
        final FastDateParser parser = new FastDateParser("hh:mm a", UTC, Locale.US);
        final Date midnight = parser.parse("12:00 AM");
        assertEquals(0, calendarFor(midnight, UTC).get(Calendar.HOUR_OF_DAY));
        final Date noon = parser.parse("12:00 PM");
        assertEquals(12, calendarFor(noon, UTC).get(Calendar.HOUR_OF_DAY));
    }

    @Test
    void testTwentyFourHourClockWrap() throws ParseException {
        final FastDateParser parser = new FastDateParser("kk:mm", UTC, Locale.US);
        final Date midnight = parser.parse("24:00");
        assertEquals(0, calendarFor(midnight, UTC).get(Calendar.HOUR_OF_DAY));
    }

    @Test
    void testOverflowingNumberFieldFailsGracefully() {
        // Running a huge run of digits into an int-valued field must not throw
        // NumberFormatException; it should instead be reported as a parse failure.
        final FastDateParser parser = new FastDateParser("yyyy", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("99999999999999999999", pos);
        assertNull(date);
        assertTrue(pos.getErrorIndex() >= 0);
    }

    @Test
    void testGettersReturnConstructorArguments() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.FRANCE);
        assertEquals("yyyy-MM-dd", parser.getPattern());
        assertEquals(UTC, parser.getTimeZone());
        assertEquals(Locale.FRANCE, parser.getLocale());
    }

    @Test
    void testEqualsAndHashCodeContract() {
        final FastDateParser p1 = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final FastDateParser p2 = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final FastDateParser diffPattern = new FastDateParser("MM-dd-yyyy", UTC, Locale.US);
        final FastDateParser diffZone = new FastDateParser("yyyy-MM-dd", TimeZone.getTimeZone("America/New_York"), Locale.US);
        final FastDateParser diffLocale = new FastDateParser("yyyy-MM-dd", UTC, Locale.FRANCE);

        assertEquals(p1, p2);
        assertEquals(p1.hashCode(), p2.hashCode());
        assertNotEquals(p1, diffPattern);
        assertNotEquals(p1, diffZone);
        assertNotEquals(p1, diffLocale);
        assertNotEquals(p1, null);
        assertNotEquals(p1, "yyyy-MM-dd");
    }

    @Test
    void testToStringContainsPatternLocaleAndTimeZone() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final String str = parser.toString();
        assertTrue(str.contains("yyyy-MM-dd"));
        assertTrue(str.contains("UTC"));
    }

    @Test
    void testToStringAllContainsCenturyAndStartYear() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final String str = parser.toStringAll();
        assertTrue(str.contains("century="));
        assertTrue(str.contains("startYear="));
        assertTrue(str.contains("pattern=yyyy-MM-dd"));
    }

    @Test
    void testConstructorRejectsNullPattern() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                new FastDateParser(null, UTC, Locale.US);
            }
        });
    }

    @Test
    void testConstructorRejectsNullTimeZone() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                new FastDateParser("yyyy-MM-dd", null, Locale.US);
            }
        });
    }

    @Test
    void testConstructorAcceptsNullLocaleUsingDefault() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, null);
        assertNotNull(parser.getLocale());
    }

    @Test
    void testSerializationRoundTrip() throws Exception {
        final FastDateParser original = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);

        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        final ObjectOutputStream oos = new ObjectOutputStream(baos);
        oos.writeObject(original);
        oos.close();

        final ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(baos.toByteArray()));
        final FastDateParser restored = (FastDateParser) ois.readObject();
        ois.close();

        assertEquals(original, restored);
        final Date date = restored.parse("2022-05-17");
        final Calendar cal = calendarFor(date, UTC);
        assertEquals(2022, cal.get(Calendar.YEAR));
        assertEquals(Calendar.MAY, cal.get(Calendar.MONTH));
        assertEquals(17, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testTextFieldCaseInsensitiveMonthName() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MMMM-dd", UTC, Locale.US);
        final Date date = parser.parse("2021-july-04");
        final Calendar cal = calendarFor(date, UTC);
        assertEquals(Calendar.JULY, cal.get(Calendar.MONTH));
    }

    @Test
    void testTextFieldUnknownValueFails() {
        final FastDateParser parser = new FastDateParser("yyyy-MMMM-dd", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("2021-notamonth-04", pos);
        assertNull(date);
    }
}
