/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.nio.file.Path;
import java.nio.file.Paths;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link SystemProperties}.
 */
public class SystemPropertiesAgentTest {

    private static final String MISSING_PROPERTY_NAME = "org.apache.commons.lang3.SystemPropertiesAgentTest.missing";

    private final java.util.List<String> propertiesToClear = new java.util.ArrayList<>();

    @AfterEach
    public void tearDown() {
        for (final String name : propertiesToClear) {
            System.clearProperty(name);
        }
        propertiesToClear.clear();
    }

    private void setTestProperty(final String name, final String value) {
        System.setProperty(name, value);
        propertiesToClear.add(name);
    }

    // --- getProperty(String) ---

    @Test
    public void testGetPropertyKnown() {
        assertEquals(System.getProperty("java.version"), SystemProperties.getProperty("java.version"));
        assertEquals(System.getProperty(SystemProperties.JAVA_VERSION), SystemProperties.getJavaVersion());
    }

    @Test
    public void testGetPropertyUnknownReturnsNull() {
        assertNull(SystemProperties.getProperty(MISSING_PROPERTY_NAME));
    }

    @Test
    public void testGetPropertyNullKeyReturnsNull() {
        assertNull(SystemProperties.getProperty((String) null));
    }

    @Test
    public void testGetPropertyEmptyKeyReturnsNull() {
        assertNull(SystemProperties.getProperty(""));
    }

    // --- package-private getProperty(String, String) ---

    @Test
    public void testGetPropertyWithStringDefaultWhenAbsent() {
        assertEquals("fallback", SystemProperties.getProperty(MISSING_PROPERTY_NAME, "fallback"));
    }

    @Test
    public void testGetPropertyWithStringDefaultWhenPresent() {
        setTestProperty(MISSING_PROPERTY_NAME, "actual");
        assertEquals("actual", SystemProperties.getProperty(MISSING_PROPERTY_NAME, "fallback"));
    }

    // --- package-private getProperty(String, Supplier<String>) ---

    @Test
    public void testGetPropertyWithSupplierDefaultWhenAbsent() {
        assertEquals("fromSupplier", SystemProperties.getProperty(MISSING_PROPERTY_NAME, () -> "fromSupplier"));
    }

    @Test
    public void testGetPropertyWithSupplierDefaultWhenPresent() {
        setTestProperty(MISSING_PROPERTY_NAME, "actual");
        assertEquals("actual", SystemProperties.getProperty(MISSING_PROPERTY_NAME, () -> "fromSupplier"));
    }

    // --- isPropertySet ---

    @Test
    public void testIsPropertySetTrueForKnownProperty() {
        assertTrue(SystemProperties.isPropertySet("java.version"));
    }

    @Test
    public void testIsPropertySetFalseForUnknownProperty() {
        assertFalse(SystemProperties.isPropertySet(MISSING_PROPERTY_NAME));
    }

    // --- getBoolean(String, BooleanSupplier) ---

    @Test
    public void testGetBooleanParsesTrue() {
        setTestProperty(MISSING_PROPERTY_NAME, "true");
        assertTrue(SystemProperties.getBoolean(MISSING_PROPERTY_NAME, () -> false));
    }

    @Test
    public void testGetBooleanParsesFalseForGarbageValue() {
        setTestProperty(MISSING_PROPERTY_NAME, "not-a-boolean");
        assertFalse(SystemProperties.getBoolean(MISSING_PROPERTY_NAME, () -> true));
    }

    @Test
    public void testGetBooleanUsesSupplierWhenAbsent() {
        assertTrue(SystemProperties.getBoolean(MISSING_PROPERTY_NAME, () -> true));
        assertFalse(SystemProperties.getBoolean(MISSING_PROPERTY_NAME, () -> false));
    }

    @Test
    public void testGetBooleanNullSupplierWhenAbsentReturnsFalse() {
        assertFalse(SystemProperties.getBoolean(MISSING_PROPERTY_NAME, null));
    }

    @Test
    public void testGetBooleanWithClassKey() {
        setTestProperty("String." + MISSING_PROPERTY_NAME, "true");
        assertTrue(SystemProperties.getBoolean(String.class, MISSING_PROPERTY_NAME, () -> false));
    }

    // --- getInt(String, IntSupplier) ---

    @Test
    public void testGetIntParsesValue() {
        setTestProperty(MISSING_PROPERTY_NAME, "42");
        assertEquals(42, SystemProperties.getInt(MISSING_PROPERTY_NAME, () -> -1));
    }

    @Test
    public void testGetIntUsesSupplierWhenAbsent() {
        assertEquals(7, SystemProperties.getInt(MISSING_PROPERTY_NAME, () -> 7));
    }

    @Test
    public void testGetIntNullSupplierWhenAbsentReturnsZero() {
        assertEquals(0, SystemProperties.getInt(MISSING_PROPERTY_NAME, null));
    }

    @Test
    public void testGetIntInvalidValueThrows() {
        setTestProperty(MISSING_PROPERTY_NAME, "not-a-number");
        assertThrows(NumberFormatException.class, () -> SystemProperties.getInt(MISSING_PROPERTY_NAME, () -> 0));
    }

    @Test
    public void testGetIntWithClassKey() {
        setTestProperty("String." + MISSING_PROPERTY_NAME, "99");
        assertEquals(99, SystemProperties.getInt(String.class, MISSING_PROPERTY_NAME, () -> -1));
    }

    // --- getLong(String, LongSupplier) ---

    @Test
    public void testGetLongParsesValue() {
        setTestProperty(MISSING_PROPERTY_NAME, "123456789012");
        assertEquals(123456789012L, SystemProperties.getLong(MISSING_PROPERTY_NAME, () -> -1L));
    }

    @Test
    public void testGetLongUsesSupplierWhenAbsent() {
        assertEquals(555L, SystemProperties.getLong(MISSING_PROPERTY_NAME, () -> 555L));
    }

    @Test
    public void testGetLongNullSupplierWhenAbsentReturnsZero() {
        assertEquals(0L, SystemProperties.getLong(MISSING_PROPERTY_NAME, null));
    }

    @Test
    public void testGetLongInvalidValueThrows() {
        setTestProperty(MISSING_PROPERTY_NAME, "not-a-number");
        assertThrows(NumberFormatException.class, () -> SystemProperties.getLong(MISSING_PROPERTY_NAME, () -> 0L));
    }

    @Test
    public void testGetLongWithClassKey() {
        setTestProperty("String." + MISSING_PROPERTY_NAME, "888");
        assertEquals(888L, SystemProperties.getLong(String.class, MISSING_PROPERTY_NAME, () -> -1L));
    }

    // --- getPath(String, Supplier<Path>) ---

    @Test
    public void testGetPathParsesValue() {
        setTestProperty(MISSING_PROPERTY_NAME, "/tmp/some-dir");
        assertEquals(Paths.get("/tmp/some-dir"), SystemProperties.getPath(MISSING_PROPERTY_NAME, () -> null));
    }

    @Test
    public void testGetPathUsesSupplierWhenAbsent() {
        final Path expected = Paths.get("/fallback");
        assertEquals(expected, SystemProperties.getPath(MISSING_PROPERTY_NAME, () -> expected));
    }

    @Test
    public void testGetPathNullSupplierWhenAbsentReturnsNull() {
        assertNull(SystemProperties.getPath(MISSING_PROPERTY_NAME, null));
    }

    // --- getLineSeparator / overload with Supplier ---

    @Test
    public void testGetLineSeparatorMatchesSystemProperty() {
        assertEquals(System.getProperty("line.separator"), SystemProperties.getLineSeparator());
    }

    @Test
    public void testGetLineSeparatorWithSupplierReturnsActualValueWhenPresent() {
        assertEquals(System.getProperty("line.separator"), SystemProperties.getLineSeparator(() -> "fallback"));
    }

    // --- getJavaSpecificationVersion(String) ---

    @Test
    public void testGetJavaSpecificationVersionWithDefaultReturnsActualWhenPresent() {
        assertEquals(System.getProperty("java.specification.version"), SystemProperties.getJavaSpecificationVersion("fallback"));
    }

    // --- getUserName(String) ---

    @Test
    public void testGetUserNameWithDefaultReturnsActualWhenPresent() {
        assertEquals(System.getProperty("user.name"), SystemProperties.getUserName("fallback"));
    }

    // --- Spot checks on well-known simple getters against System.getProperty ---

    @Test
    public void testSimpleGettersMatchSystemProperties() {
        assertEquals(System.getProperty("java.home"), SystemProperties.getJavaHome());
        assertEquals(System.getProperty("java.io.tmpdir"), SystemProperties.getJavaIoTmpdir());
        assertEquals(System.getProperty("java.vendor"), SystemProperties.getJavaVendor());
        assertEquals(System.getProperty("os.name"), SystemProperties.getOsName());
        assertEquals(System.getProperty("os.arch"), SystemProperties.getOsArch());
        assertEquals(System.getProperty("os.version"), SystemProperties.getOsVersion());
        assertEquals(System.getProperty("file.separator"), SystemProperties.getFileSeparator());
        assertEquals(System.getProperty("path.separator"), SystemProperties.getPathSeparator());
        assertEquals(System.getProperty("user.dir"), SystemProperties.getUserDir());
        assertEquals(System.getProperty("user.home"), SystemProperties.getUserHome());
        assertEquals(System.getProperty("user.name"), SystemProperties.getUserName());
    }

    @Test
    public void testConstantValues() {
        assertEquals("java.version", SystemProperties.JAVA_VERSION);
        assertEquals("java.home", SystemProperties.JAVA_HOME);
        assertEquals("os.name", SystemProperties.OS_NAME);
        assertEquals("user.home", SystemProperties.USER_HOME);
        assertEquals("file.separator", SystemProperties.FILE_SEPARATOR);
        assertEquals("path.separator", SystemProperties.PATH_SEPARATOR);
        assertEquals("line.separator", SystemProperties.LINE_SEPARATOR);
    }

    @Test
    public void testDeprecatedPublicConstructorDoesNotThrow() {
        assertNotNull(new SystemProperties());
    }
}
