/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link NumberUtils}.
 */
class NumberUtilsAgentTest {

    // ----- compare -----

    @Test
    void testCompareByte() {
        assertEquals(0, NumberUtils.compare((byte) 1, (byte) 1));
        assertTrue(NumberUtils.compare((byte) 1, (byte) 2) < 0);
        assertTrue(NumberUtils.compare((byte) 2, (byte) 1) > 0);
    }

    @Test
    void testCompareInt() {
        assertEquals(0, NumberUtils.compare(1, 1));
        assertTrue(NumberUtils.compare(1, 2) < 0);
        assertTrue(NumberUtils.compare(2, 1) > 0);
    }

    @Test
    void testCompareLong() {
        assertEquals(0, NumberUtils.compare(1L, 1L));
        assertTrue(NumberUtils.compare(1L, 2L) < 0);
        assertTrue(NumberUtils.compare(2L, 1L) > 0);
    }

    @Test
    void testCompareShort() {
        assertEquals(0, NumberUtils.compare((short) 1, (short) 1));
        assertTrue(NumberUtils.compare((short) 1, (short) 2) < 0);
        assertTrue(NumberUtils.compare((short) 2, (short) 1) > 0);
    }

    // ----- createBigDecimal -----

    @Test
    void testCreateBigDecimalNull() {
        assertNull(NumberUtils.createBigDecimal(null));
    }

    @Test
    void testCreateBigDecimalBlankThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigDecimal("");
            }
        });
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigDecimal("   ");
            }
        });
    }

    @Test
    void testCreateBigDecimalValid() {
        assertEquals(new BigDecimal("1.23"), NumberUtils.createBigDecimal("1.23"));
    }

    @Test
    void testCreateBigDecimalInvalidThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigDecimal("not a number");
            }
        });
    }

    // ----- createBigInteger -----

    @Test
    void testCreateBigIntegerNull() {
        assertNull(NumberUtils.createBigInteger(null));
    }

    @Test
    void testCreateBigIntegerEmptyThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigInteger("");
            }
        });
    }

    @Test
    void testCreateBigIntegerDecimal() {
        assertEquals(BigInteger.valueOf(123), NumberUtils.createBigInteger("123"));
        assertEquals(BigInteger.valueOf(-123), NumberUtils.createBigInteger("-123"));
        assertEquals(BigInteger.valueOf(123), NumberUtils.createBigInteger("+123"));
    }

    @Test
    void testCreateBigIntegerHex() {
        assertEquals(BigInteger.valueOf(255), NumberUtils.createBigInteger("0xFF"));
        assertEquals(BigInteger.valueOf(255), NumberUtils.createBigInteger("0XFF"));
        assertEquals(BigInteger.valueOf(255), NumberUtils.createBigInteger("#FF"));
        assertEquals(BigInteger.valueOf(-255), NumberUtils.createBigInteger("-0xFF"));
    }

    @Test
    void testCreateBigIntegerOctal() {
        assertEquals(BigInteger.valueOf(8), NumberUtils.createBigInteger("010"));
    }

    @Test
    void testCreateBigIntegerDoubleSignThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigInteger("--1");
            }
        });
    }

    // ----- createDouble/createFloat/createInteger/createLong -----

    @Test
    void testCreateDouble() {
        assertNull(NumberUtils.createDouble(null));
        assertEquals(Double.valueOf(1.5d), NumberUtils.createDouble("1.5"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createDouble("abc");
            }
        });
    }

    @Test
    void testCreateFloat() {
        assertNull(NumberUtils.createFloat(null));
        assertEquals(Float.valueOf(1.5f), NumberUtils.createFloat("1.5"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createFloat("abc");
            }
        });
    }

    @Test
    void testCreateInteger() {
        assertNull(NumberUtils.createInteger(null));
        assertEquals(Integer.valueOf(123), NumberUtils.createInteger("123"));
        assertEquals(Integer.valueOf(255), NumberUtils.createInteger("0xFF"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createInteger("abc");
            }
        });
    }

    @Test
    void testCreateLong() {
        assertNull(NumberUtils.createLong(null));
        assertEquals(Long.valueOf(123L), NumberUtils.createLong("123"));
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createLong("abc");
            }
        });
    }

    // ----- createNumber -----

    @Test
    void testCreateNumberNull() {
        assertNull(NumberUtils.createNumber(null));
    }

    @Test
    void testCreateNumberEmptyThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("");
            }
        });
    }

    @Test
    void testCreateNumberLeadingSpaceThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber(" 1");
            }
        });
    }

    @Test
    void testCreateNumberPlainInteger() {
        final Number n = NumberUtils.createNumber("123");
        assertTrue(n instanceof Integer);
        assertEquals(123, n.intValue());
    }

    @Test
    void testCreateNumberLong() {
        final Number n = NumberUtils.createNumber("" + ((long) Integer.MAX_VALUE + 1L));
        assertTrue(n instanceof Long);
    }

    @Test
    void testCreateNumberBigIntegerWhenTooLargeForLong() {
        final String tooBig = "99999999999999999999999999999";
        final Number n = NumberUtils.createNumber(tooBig);
        assertTrue(n instanceof BigInteger);
        assertEquals(new BigInteger(tooBig), n);
    }

    @Test
    void testCreateNumberHexAndTypeSuffixes() {
        assertTrue(NumberUtils.createNumber("0xFF") instanceof Integer);
        assertEquals(255, NumberUtils.createNumber("0xFF").intValue());
        assertTrue(NumberUtils.createNumber("0xFFL") instanceof Long);
        assertTrue(NumberUtils.createNumber("123L") instanceof Long);
        assertTrue(NumberUtils.createNumber("1.5F") instanceof Float);
        assertTrue(NumberUtils.createNumber("1.5D") instanceof Double);
    }

    @Test
    void testCreateNumberDecimalAndExponent() {
        assertTrue(NumberUtils.createNumber("1.5") instanceof Float || NumberUtils.createNumber("1.5") instanceof Double);
        final Number exp = NumberUtils.createNumber("1.5e10");
        assertEquals(1.5e10, exp.doubleValue(), 0.0001);
    }

    @Test
    void testCreateNumberInvalidThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("--1");
            }
        });
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("1.2.3");
            }
        });
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("Z");
            }
        });
    }

    // ----- isCreatable / isNumber -----

    @Test
    void testIsCreatable() {
        assertFalse(NumberUtils.isCreatable(null));
        assertFalse(NumberUtils.isCreatable(""));
        assertFalse(NumberUtils.isCreatable(" "));
        assertTrue(NumberUtils.isCreatable("123"));
        assertTrue(NumberUtils.isCreatable("1.5e10"));
        assertFalse(NumberUtils.isCreatable("--1"));
        assertFalse(NumberUtils.isCreatable("abc"));
    }

    @Test
    void testIsNumberDeprecatedMatchesIsCreatable() {
        assertEquals(NumberUtils.isCreatable("123"), NumberUtils.isNumber("123"));
        assertEquals(NumberUtils.isCreatable("abc"), NumberUtils.isNumber("abc"));
    }

    // ----- isDigits -----

    @Test
    void testIsDigits() {
        assertFalse(NumberUtils.isDigits(null));
        assertFalse(NumberUtils.isDigits(""));
        assertTrue(NumberUtils.isDigits("12345"));
        assertFalse(NumberUtils.isDigits("12.45"));
        assertFalse(NumberUtils.isDigits("-123"));
        assertFalse(NumberUtils.isDigits("abc"));
    }

    // ----- isParsable -----

    @Test
    void testIsParsable() {
        assertFalse(NumberUtils.isParsable(null));
        assertFalse(NumberUtils.isParsable(""));
        assertTrue(NumberUtils.isParsable("123"));
        assertTrue(NumberUtils.isParsable("1.2e-5"));
        assertTrue(NumberUtils.isParsable("NaN"));
        assertTrue(NumberUtils.isParsable("Infinity"));
        assertFalse(NumberUtils.isParsable("123L"));
        assertFalse(NumberUtils.isParsable("abc"));
    }

    // ----- max/min arrays -----

    @Test
    void testMaxByteArray() {
        assertEquals((byte) 5, NumberUtils.max((byte) 1, (byte) 5, (byte) 3));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max((byte[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new byte[0]);
            }
        });
    }

    @Test
    void testMaxIntArray() {
        assertEquals(5, NumberUtils.max(1, 5, 3));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max((int[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new int[0]);
            }
        });
    }

    @Test
    void testMaxLongArray() {
        assertEquals(5L, NumberUtils.max(1L, 5L, 3L));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max((long[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new long[0]);
            }
        });
    }

    @Test
    void testMaxShortArray() {
        assertEquals((short) 5, NumberUtils.max((short) 1, (short) 5, (short) 3));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max((short[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new short[0]);
            }
        });
    }

    @Test
    void testMaxDoubleArray() {
        assertEquals(5.0d, NumberUtils.max(1.0, 5.0, 3.0), 0.0001);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max((double[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new double[0]);
            }
        });
    }

    @Test
    void testMaxFloatArray() {
        assertEquals(5.0f, NumberUtils.max(1.0f, 5.0f, 3.0f), 0.0001f);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max((float[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new float[0]);
            }
        });
    }

    @Test
    void testMinByteArray() {
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 5, (byte) 3));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min((byte[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new byte[0]);
            }
        });
    }

    @Test
    void testMinIntArray() {
        assertEquals(1, NumberUtils.min(1, 5, 3));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min((int[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new int[0]);
            }
        });
    }

    @Test
    void testMinLongArray() {
        assertEquals(1L, NumberUtils.min(1L, 5L, 3L));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min((long[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new long[0]);
            }
        });
    }

    @Test
    void testMinShortArray() {
        assertEquals((short) 1, NumberUtils.min((short) 1, (short) 5, (short) 3));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min((short[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new short[0]);
            }
        });
    }

    @Test
    void testMinDoubleArray() {
        assertEquals(1.0d, NumberUtils.min(1.0, 5.0, 3.0), 0.0001);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min((double[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new double[0]);
            }
        });
    }

    @Test
    void testMinFloatArray() {
        assertEquals(1.0f, NumberUtils.min(1.0f, 5.0f, 3.0f), 0.0001f);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min((float[]) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new float[0]);
            }
        });
    }

    // ----- 3-param max/min -----

    @Test
    void testMaxMinThreeParams() {
        assertEquals((byte) 3, NumberUtils.max((byte) 1, (byte) 2, (byte) 3));
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 2, (byte) 3));
        assertEquals(3, NumberUtils.max(1, 2, 3));
        assertEquals(1, NumberUtils.min(1, 2, 3));
        assertEquals(3L, NumberUtils.max(1L, 2L, 3L));
        assertEquals(1L, NumberUtils.min(1L, 2L, 3L));
        assertEquals((short) 3, NumberUtils.max((short) 1, (short) 2, (short) 3));
        assertEquals((short) 1, NumberUtils.min((short) 1, (short) 2, (short) 3));
        assertEquals(3.0d, NumberUtils.max(1.0, 2.0, 3.0), 0.0001);
        assertEquals(1.0d, NumberUtils.min(1.0, 2.0, 3.0), 0.0001);
        assertEquals(3.0f, NumberUtils.max(1.0f, 2.0f, 3.0f), 0.0001f);
        assertEquals(1.0f, NumberUtils.min(1.0f, 2.0f, 3.0f), 0.0001f);
    }

    @Test
    void testMaxMinWithNaN() {
        assertTrue(Double.isNaN(NumberUtils.max(1.0, 2.0, Double.NaN)));
        assertTrue(Double.isNaN(NumberUtils.min(1.0, 2.0, Double.NaN)));
        assertTrue(Float.isNaN(NumberUtils.max(1.0f, 2.0f, Float.NaN)));
        assertTrue(Float.isNaN(NumberUtils.min(1.0f, 2.0f, Float.NaN)));
    }

    // ----- toX conversions -----

    @Test
    void testToByte() {
        assertEquals((byte) 0, NumberUtils.toByte(null));
        assertEquals((byte) 0, NumberUtils.toByte(""));
        assertEquals((byte) 1, NumberUtils.toByte("1"));
        assertEquals((byte) 1, NumberUtils.toByte(null, (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("abc", (byte) 1));
    }

    @Test
    void testToDoubleFromString() {
        assertEquals(0.0d, NumberUtils.toDouble((String) null), 0.0001);
        assertEquals(0.0d, NumberUtils.toDouble(""), 0.0001);
        assertEquals(1.5d, NumberUtils.toDouble("1.5"), 0.0001);
        assertEquals(1.1d, NumberUtils.toDouble((String) null, 1.1d), 0.0001);
        assertEquals(1.1d, NumberUtils.toDouble("abc", 1.1d), 0.0001);
    }

    @Test
    void testToDoubleFromBigDecimal() {
        assertEquals(0.0d, NumberUtils.toDouble((BigDecimal) null), 0.0001);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d)), 0.0001);
        assertEquals(1.1d, NumberUtils.toDouble((BigDecimal) null, 1.1d), 0.0001);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d), 1.1d), 0.0001);
    }

    @Test
    void testToFloat() {
        assertEquals(0.0f, NumberUtils.toFloat(null), 0.0001f);
        assertEquals(0.0f, NumberUtils.toFloat(""), 0.0001f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5"), 0.0001f);
        assertEquals(1.1f, NumberUtils.toFloat(null, 1.1f), 0.0001f);
        assertEquals(1.1f, NumberUtils.toFloat("abc", 1.1f), 0.0001f);
    }

    @Test
    void testToInt() {
        assertEquals(0, NumberUtils.toInt(null));
        assertEquals(0, NumberUtils.toInt(""));
        assertEquals(1, NumberUtils.toInt("1"));
        assertEquals(1, NumberUtils.toInt(null, 1));
        assertEquals(1, NumberUtils.toInt("abc", 1));
    }

    @Test
    void testToLong() {
        assertEquals(0L, NumberUtils.toLong(null));
        assertEquals(0L, NumberUtils.toLong(""));
        assertEquals(1L, NumberUtils.toLong("1"));
        assertEquals(1L, NumberUtils.toLong(null, 1L));
        assertEquals(1L, NumberUtils.toLong("abc", 1L));
    }

    @Test
    void testToShort() {
        assertEquals((short) 0, NumberUtils.toShort(null));
        assertEquals((short) 0, NumberUtils.toShort(""));
        assertEquals((short) 1, NumberUtils.toShort("1"));
        assertEquals((short) 1, NumberUtils.toShort(null, (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("abc", (short) 1));
    }

    // ----- toScaledBigDecimal -----

    @Test
    void testToScaledBigDecimalFromBigDecimal() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.235")));
        assertEquals(new BigDecimal("1.000"), NumberUtils.toScaledBigDecimal(new BigDecimal("1"), 3, RoundingMode.HALF_UP));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null, 3, RoundingMode.HALF_UP));
    }

    @Test
    void testToScaledBigDecimalFromDouble() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal(Double.valueOf(1.235d)));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null, 3, RoundingMode.HALF_UP));
    }

    @Test
    void testToScaledBigDecimalFromFloat() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null, 3, RoundingMode.HALF_UP));
        assertNotNull(NumberUtils.toScaledBigDecimal(Float.valueOf(1.5f)));
    }

    @Test
    void testToScaledBigDecimalFromString() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal("1.235"));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null, 3, RoundingMode.HALF_UP));
    }

    @Test
    void testToScaledBigDecimalNullRoundingModeDefaultsToHalfEven() {
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.235"), 2, null));
    }

    // ----- constants -----

    @Test
    void testConstants() {
        assertEquals(Long.valueOf(0L), NumberUtils.LONG_ZERO);
        assertEquals(Long.valueOf(1L), NumberUtils.LONG_ONE);
        assertEquals(Long.valueOf(-1L), NumberUtils.LONG_MINUS_ONE);
        assertEquals(Integer.valueOf(0), NumberUtils.INTEGER_ZERO);
        assertEquals(Integer.valueOf(1), NumberUtils.INTEGER_ONE);
        assertEquals(Integer.valueOf(2), NumberUtils.INTEGER_TWO);
        assertEquals(Integer.valueOf(-1), NumberUtils.INTEGER_MINUS_ONE);
        assertEquals(Short.valueOf((short) 0), NumberUtils.SHORT_ZERO);
        assertEquals(Short.valueOf((short) 1), NumberUtils.SHORT_ONE);
        assertEquals(Short.valueOf((short) -1), NumberUtils.SHORT_MINUS_ONE);
        assertEquals(Byte.valueOf((byte) 0), NumberUtils.BYTE_ZERO);
        assertEquals(Byte.valueOf((byte) 1), NumberUtils.BYTE_ONE);
        assertEquals(Byte.valueOf((byte) -1), NumberUtils.BYTE_MINUS_ONE);
        assertEquals(Double.valueOf(0.0d), NumberUtils.DOUBLE_ZERO);
        assertEquals(Double.valueOf(1.0d), NumberUtils.DOUBLE_ONE);
        assertEquals(Double.valueOf(-1.0d), NumberUtils.DOUBLE_MINUS_ONE);
        assertEquals(Float.valueOf(0.0f), NumberUtils.FLOAT_ZERO);
        assertEquals(Float.valueOf(1.0f), NumberUtils.FLOAT_ONE);
        assertEquals(Float.valueOf(-1.0f), NumberUtils.FLOAT_MINUS_ONE);
        assertEquals(Long.valueOf(Integer.MAX_VALUE), NumberUtils.LONG_INT_MAX_VALUE);
        assertEquals(Long.valueOf(Integer.MIN_VALUE), NumberUtils.LONG_INT_MIN_VALUE);
    }

    // ----- constructor -----

    @Test
    void testConstructor() {
        assertNotNull(new NumberUtils());
    }
}
