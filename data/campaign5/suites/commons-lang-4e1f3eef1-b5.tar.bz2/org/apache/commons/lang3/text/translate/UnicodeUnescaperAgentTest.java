/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text.translate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringWriter;

import org.junit.jupiter.api.Test;

/**
 * Tests for {@link UnicodeUnescaper}.
 */
@Deprecated
class UnicodeUnescaperAgentTest {

    @Test
    void testValidUnicode() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final String input = "\\u0041";
        final String result = uu.translate(input);
        assertEquals("A", result);
    }

    @Test
    void testValidUnicodeSurroundedByText() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final String input = "foo \\u0041 bar";
        final String result = uu.translate(input);
        assertEquals("foo A bar", result);
    }

    @Test
    void testMultipleUChars() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final String input = "\\uu0041";
        final String result = uu.translate(input);
        assertEquals("A", result);
    }

    @Test
    void testManyUChars() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final String input = "\\uuuuu0041";
        final String result = uu.translate(input);
        assertEquals("A", result);
    }

    @Test
    void testPlusVariant() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final String input = "\\u+0041";
        final String result = uu.translate(input);
        assertEquals("A", result);
    }

    @Test
    void testMultipleUCharsWithPlus() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final String input = "\\uu+0041";
        final String result = uu.translate(input);
        assertEquals("A", result);
    }

    @Test
    void testLowerCaseHexDigits() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final String input = "\\u00ff";
        final String result = uu.translate(input);
        assertEquals("ÿ", result);
    }

    @Test
    void testNoLeadingBackslashIsUntouched() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final String input = "u0041";
        final String result = uu.translate(input);
        assertEquals("u0041", result);
    }

    @Test
    void testBackslashWithoutUIsUntouched() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final String input = "\\n0041";
        final String result = uu.translate(input);
        assertEquals("\\n0041", result);
    }

    @Test
    void testTrailingBackslashOnlyIsUntouched() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final String input = "\\";
        final String result = uu.translate(input);
        assertEquals("\\", result);
    }

    @Test
    void testEmptyStringTranslatesToEmptyString() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final String result = uu.translate("");
        assertEquals("", result);
    }

    @Test
    void testNullInputTranslatesToNull() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final String result = uu.translate((String) null);
        assertEquals(null, result);
    }

    @Test
    void testNotEnoughHexDigitsThrowsIllegalArgumentException() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final String input = "\\u004";
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                uu.translate(input);
            }
        });
        assertTrue(ex.getMessage().contains("Less than 4 hex digits"));
    }

    @Test
    void testNoHexDigitsAtAllThrowsIllegalArgumentException() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final String input = "\\u";
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                uu.translate(input);
            }
        });
        assertTrue(ex.getMessage().contains("Less than 4 hex digits"));
    }

    @Test
    void testInvalidHexDigitsThrowsIllegalArgumentExceptionWithCause() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final String input = "\\uZZZZ";
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                uu.translate(input);
            }
        });
        assertTrue(ex.getMessage().contains("Unable to parse unicode value"));
        assertTrue(ex.getCause() instanceof NumberFormatException);
    }

    @Test
    void testTranslateWholeOnWriterReturnsNothingAppended() throws IOException {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final StringWriter writer = new StringWriter();
        uu.translate("plain text", writer);
        assertEquals("plain text", writer.toString());
    }

    @Test
    void testTranslateAtIndexReturnsZeroWhenNoMatch() throws IOException {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final StringWriter writer = new StringWriter();
        final int consumed = uu.translate("abc", 0, writer);
        assertEquals(0, consumed);
        assertEquals("", writer.toString());
    }

    @Test
    void testTranslateAtIndexReturnsConsumedCountForSimpleEscape() throws IOException {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final StringWriter writer = new StringWriter();
        final int consumed = uu.translate("\\u0041", 0, writer);
        assertEquals(6, consumed);
        assertEquals("A", writer.toString());
    }

    @Test
    void testTranslateAtIndexReturnsConsumedCountForMultipleUAndPlus() throws IOException {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final StringWriter writer = new StringWriter();
        final int consumed = uu.translate("\\uuu+0041", 0, writer);
        assertEquals(9, consumed);
        assertEquals("A", writer.toString());
    }

    @Test
    void testBackslashAtVeryEndOfInputIsUntouchedByIndexedTranslate() throws IOException {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final StringWriter writer = new StringWriter();
        final int consumed = uu.translate("x\\", 1, writer);
        assertEquals(0, consumed);
        assertEquals("", writer.toString());
    }

    @Test
    void testHighCodePointValue() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final String input = "\\uffff";
        final String result = uu.translate(input);
        assertEquals("￿", result);
    }

    @Test
    void testZeroCodePointValue() {
        final UnicodeUnescaper uu = new UnicodeUnescaper();
        final String input = "\\u0000";
        final String result = uu.translate(input);
        assertEquals("\u0000", result);
    }
}
