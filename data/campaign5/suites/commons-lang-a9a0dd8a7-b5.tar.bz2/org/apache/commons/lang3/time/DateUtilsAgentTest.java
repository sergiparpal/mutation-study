/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZonedDateTime;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

class DateUtilsAgentTest {

    private static Date newDate(final int year, final int month, final int day, final int hour, final int minute, final int second,
            final int millis) {
        final Calendar c = Calendar.getInstance();
        c.clear();
        c.set(year, month, day, hour, minute, second);
        c.set(Calendar.MILLISECOND, millis);
        return c.getTime();
    }

    @Test
    void testAddDays() {
        final Date date = newDate(2020, Calendar.JANUARY, 31, 10, 0, 0, 0);
        final Date result = DateUtils.addDays(date, 1);
        final Calendar c = DateUtils.toCalendar(result);
        assertEquals(Calendar.FEBRUARY, c.get(Calendar.MONTH));
        assertEquals(1, c.get(Calendar.DAY_OF_MONTH));
        // original unchanged
        assertEquals(31, DateUtils.toCalendar(date).get(Calendar.DAY_OF_MONTH));

        final Date negative = DateUtils.addDays(date, -31);
        assertEquals(Calendar.DECEMBER, DateUtils.toCalendar(negative).get(Calendar.MONTH));

        assertThrows(NullPointerException.class, () -> DateUtils.addDays(null, 1));
    }

    @Test
    void testAddHours() {
        final Date date = newDate(2020, Calendar.JANUARY, 1, 23, 0, 0, 0);
        final Calendar result = DateUtils.toCalendar(DateUtils.addHours(date, 2));
        assertEquals(2, result.get(Calendar.DAY_OF_MONTH));
        assertEquals(1, result.get(Calendar.HOUR_OF_DAY));
        assertThrows(NullPointerException.class, () -> DateUtils.addHours(null, 1));
    }

    @Test
    void testAddMilliseconds() {
        final Date date = newDate(2020, Calendar.JANUARY, 1, 0, 0, 0, 999);
        final Calendar result = DateUtils.toCalendar(DateUtils.addMilliseconds(date, 2));
        assertEquals(1, result.get(Calendar.SECOND));
        assertEquals(1, result.get(Calendar.MILLISECOND));
        assertThrows(NullPointerException.class, () -> DateUtils.addMilliseconds(null, 1));
    }

    @Test
    void testAddMinutes() {
        final Date date = newDate(2020, Calendar.JANUARY, 1, 0, 59, 0, 0);
        final Calendar result = DateUtils.toCalendar(DateUtils.addMinutes(date, 2));
        assertEquals(1, result.get(Calendar.HOUR_OF_DAY));
        assertEquals(1, result.get(Calendar.MINUTE));
        assertThrows(NullPointerException.class, () -> DateUtils.addMinutes(null, 1));
    }

    @Test
    void testAddMonths() {
        // Jan 31 + 1 month pins the day-of-month to the last valid day, it does not roll into March
        final Date date = newDate(2020, Calendar.JANUARY, 31, 0, 0, 0, 0);
        final Calendar result = DateUtils.toCalendar(DateUtils.addMonths(date, 1));
        assertEquals(Calendar.FEBRUARY, result.get(Calendar.MONTH));
        assertEquals(29, result.get(Calendar.DAY_OF_MONTH));
        assertThrows(NullPointerException.class, () -> DateUtils.addMonths(null, 1));
    }

    @Test
    void testAddSeconds() {
        final Date date = newDate(2020, Calendar.JANUARY, 1, 0, 0, 59, 0);
        final Calendar result = DateUtils.toCalendar(DateUtils.addSeconds(date, 2));
        assertEquals(1, result.get(Calendar.MINUTE));
        assertEquals(1, result.get(Calendar.SECOND));
        assertThrows(NullPointerException.class, () -> DateUtils.addSeconds(null, 1));
    }

    @Test
    void testAddWeeks() {
        final Date date = newDate(2020, Calendar.JANUARY, 1, 0, 0, 0, 0);
        final Calendar result = DateUtils.toCalendar(DateUtils.addWeeks(date, 1));
        assertEquals(8, result.get(Calendar.DAY_OF_MONTH));
        assertThrows(NullPointerException.class, () -> DateUtils.addWeeks(null, 1));
    }

    @Test
    void testAddYears() {
        // Feb 29 2020 (leap) + 1 year pins to Feb 28 2021 (not leap)
        final Date date = newDate(2020, Calendar.FEBRUARY, 29, 0, 0, 0, 0);
        final Calendar result = DateUtils.toCalendar(DateUtils.addYears(date, 1));
        assertEquals(2021, result.get(Calendar.YEAR));
        assertEquals(Calendar.FEBRUARY, result.get(Calendar.MONTH));
        assertEquals(28, result.get(Calendar.DAY_OF_MONTH));
        assertThrows(NullPointerException.class, () -> DateUtils.addYears(null, 1));
    }

    @Test
    void testCeilingCalendar() {
        final Calendar cal = DateUtils.toCalendar(newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231));
        final Calendar result = DateUtils.ceiling(cal, Calendar.HOUR_OF_DAY);
        assertEquals(14, result.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, result.get(Calendar.MINUTE));
        assertEquals(0, result.get(Calendar.SECOND));
        assertEquals(0, result.get(Calendar.MILLISECOND));
        // input unchanged
        assertEquals(13, cal.get(Calendar.HOUR_OF_DAY));
        assertThrows(NullPointerException.class, () -> DateUtils.ceiling((Calendar) null, Calendar.HOUR_OF_DAY));
    }

    @Test
    void testCeilingDate() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Date result = DateUtils.ceiling(date, Calendar.MONTH);
        final Calendar c = DateUtils.toCalendar(result);
        assertEquals(Calendar.APRIL, c.get(Calendar.MONTH));
        assertEquals(1, c.get(Calendar.DAY_OF_MONTH));
        assertThrows(NullPointerException.class, () -> DateUtils.ceiling((Date) null, Calendar.MONTH));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.ceiling(date, Calendar.DAY_OF_WEEK));
    }

    @Test
    void testCeilingAmPmSpecialCase() {
        final Date date = newDate(2020, Calendar.MARCH, 10, 5, 0, 0, 0);
        final Calendar result = DateUtils.toCalendar(DateUtils.ceiling(date, Calendar.AM_PM));
        assertEquals(12, result.get(Calendar.HOUR_OF_DAY));
        assertEquals(10, result.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testCeilingObject() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Calendar cal = DateUtils.toCalendar(date);
        assertNotNull(DateUtils.ceiling((Object) date, Calendar.HOUR_OF_DAY));
        assertNotNull(DateUtils.ceiling((Object) cal, Calendar.HOUR_OF_DAY));
        assertThrows(NullPointerException.class, () -> DateUtils.ceiling((Object) null, Calendar.HOUR_OF_DAY));
        assertThrows(ClassCastException.class, () -> DateUtils.ceiling("not a date", Calendar.HOUR_OF_DAY));
    }

    @Test
    void testCeilingArithmeticExceptionForHugeYear() {
        final Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(Calendar.YEAR, 300000000);
        assertThrows(ArithmeticException.class, () -> DateUtils.ceiling(cal, Calendar.HOUR_OF_DAY));
    }

    @Test
    void testGetFragmentInDays() {
        final Date jan28 = newDate(2008, Calendar.JANUARY, 28, 7, 15, 10, 538);
        assertEquals(28, DateUtils.getFragmentInDays(jan28, Calendar.MONTH));
        assertEquals(28, DateUtils.getFragmentInDays(jan28, Calendar.YEAR));
        assertEquals(0, DateUtils.getFragmentInDays(jan28, Calendar.MILLISECOND));

        final Date feb28 = newDate(2008, Calendar.FEBRUARY, 28, 7, 15, 10, 538);
        assertEquals(59, DateUtils.getFragmentInDays(feb28, Calendar.YEAR));

        assertThrows(NullPointerException.class, () -> DateUtils.getFragmentInDays((Date) null, Calendar.YEAR));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.getFragmentInDays(jan28, Calendar.DAY_OF_WEEK));
    }

    @Test
    void testGetFragmentInHours() {
        final Date jan1 = newDate(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        assertEquals(7, DateUtils.getFragmentInHours(jan1, Calendar.DAY_OF_YEAR));
        assertEquals(7, DateUtils.getFragmentInHours(jan1, Calendar.MONTH));

        final Date jan6 = newDate(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(127, DateUtils.getFragmentInHours(jan6, Calendar.MONTH));
        assertEquals(0, DateUtils.getFragmentInHours(jan6, Calendar.MILLISECOND));

        assertThrows(NullPointerException.class, () -> DateUtils.getFragmentInHours((Calendar) null, Calendar.MONTH));
    }

    @Test
    void testGetFragmentInMinutes() {
        final Date jan1 = newDate(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        assertEquals(15, DateUtils.getFragmentInMinutes(jan1, Calendar.HOUR_OF_DAY));
        assertEquals(435, DateUtils.getFragmentInMinutes(jan1, Calendar.MONTH));

        final Date jan6 = newDate(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(15, DateUtils.getFragmentInMinutes(jan6, Calendar.HOUR_OF_DAY));
        assertEquals(7635, DateUtils.getFragmentInMinutes(jan6, Calendar.MONTH));
    }

    @Test
    void testGetFragmentInSeconds() {
        final Date jan1 = newDate(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        assertEquals(10, DateUtils.getFragmentInSeconds(jan1, Calendar.MINUTE));

        final Date jan6 = newDate(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(26110, DateUtils.getFragmentInSeconds(jan6, Calendar.DAY_OF_YEAR));
    }

    @Test
    void testGetFragmentInMilliseconds() {
        final Date jan1 = newDate(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        assertEquals(538, DateUtils.getFragmentInMilliseconds(jan1, Calendar.SECOND));

        final Date jan6 = newDate(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(10538, DateUtils.getFragmentInMilliseconds(jan6, Calendar.MINUTE));
        assertEquals(0, DateUtils.getFragmentInMilliseconds(jan6, Calendar.MILLISECOND));

        assertThrows(NullPointerException.class, () -> DateUtils.getFragmentInMilliseconds((Date) null, Calendar.SECOND));
    }

    @Test
    void testIsSameDay() {
        final Date d1 = newDate(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        final Date d2 = newDate(2002, Calendar.MARCH, 28, 6, 1, 0, 0);
        final Date d3 = newDate(2002, Calendar.MARCH, 12, 13, 45, 0, 0);
        assertTrue(DateUtils.isSameDay(d1, d2));
        assertFalse(DateUtils.isSameDay(d1, d3));
        assertTrue(DateUtils.isSameDay(DateUtils.toCalendar(d1), DateUtils.toCalendar(d2)));
        assertThrows(NullPointerException.class, () -> DateUtils.isSameDay((Date) null, d2));
        assertThrows(NullPointerException.class, () -> DateUtils.isSameDay(d1, (Date) null));
    }

    @Test
    void testIsSameInstant() {
        final Date d1 = newDate(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        final Date d2 = new Date(d1.getTime());
        final Date d3 = new Date(d1.getTime() + 1);
        assertTrue(DateUtils.isSameInstant(d1, d2));
        assertFalse(DateUtils.isSameInstant(d1, d3));
        assertThrows(NullPointerException.class, () -> DateUtils.isSameInstant(null, d2));
        assertThrows(NullPointerException.class, () -> DateUtils.isSameInstant(d1, null));
    }

    @Test
    void testIsSameLocalTime() {
        final Calendar c1 = Calendar.getInstance();
        c1.clear();
        c1.set(2020, Calendar.JANUARY, 1, 1, 1, 1);
        c1.set(Calendar.MILLISECOND, 1);
        final Calendar c2 = Calendar.getInstance();
        c2.clear();
        c2.set(2020, Calendar.JANUARY, 1, 1, 1, 1);
        c2.set(Calendar.MILLISECOND, 1);
        assertTrue(DateUtils.isSameLocalTime(c1, c2));

        final Calendar c3 = Calendar.getInstance();
        c3.clear();
        c3.set(2020, Calendar.JANUARY, 2, 1, 1, 1);
        c3.set(Calendar.MILLISECOND, 1);
        assertFalse(DateUtils.isSameLocalTime(c1, c3));

        assertThrows(NullPointerException.class, () -> DateUtils.isSameLocalTime(null, c2));
        assertThrows(NullPointerException.class, () -> DateUtils.isSameLocalTime(c1, null));
    }

    @Test
    void testIteratorRangeMonthSunday() {
        final Calendar focus = DateUtils.toCalendar(newDate(2002, Calendar.JULY, 4, 10, 0, 0, 0));
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_MONTH_SUNDAY);
        Calendar first = null;
        Calendar last = null;
        int count = 0;
        while (it.hasNext()) {
            final Calendar c = it.next();
            if (first == null) {
                first = c;
            }
            last = c;
            count++;
        }
        assertEquals(35, count);
        assertEquals(Calendar.SUNDAY, first.get(Calendar.DAY_OF_WEEK));
        assertEquals(30, first.get(Calendar.DAY_OF_MONTH));
        assertEquals(Calendar.JUNE, first.get(Calendar.MONTH));
        assertEquals(Calendar.SATURDAY, last.get(Calendar.DAY_OF_WEEK));
        assertEquals(3, last.get(Calendar.DAY_OF_MONTH));
        assertEquals(Calendar.AUGUST, last.get(Calendar.MONTH));
        assertThrows(NoSuchElementException.class, it::next);
    }

    @Test
    void testIteratorRangeWeekRelativeAndCenter() {
        final Date focus = newDate(2002, Calendar.JULY, 4, 10, 0, 0, 0);

        final Iterator<Calendar> relative = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_RELATIVE);
        Calendar first = relative.next();
        Calendar last = first;
        while (relative.hasNext()) {
            last = relative.next();
        }
        assertEquals(Calendar.THURSDAY, first.get(Calendar.DAY_OF_WEEK));
        assertEquals(4, first.get(Calendar.DAY_OF_MONTH));
        assertEquals(Calendar.WEDNESDAY, last.get(Calendar.DAY_OF_WEEK));
        assertEquals(10, last.get(Calendar.DAY_OF_MONTH));

        final Iterator<Calendar> center = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_CENTER);
        first = center.next();
        last = first;
        while (center.hasNext()) {
            last = center.next();
        }
        assertEquals(1, first.get(Calendar.DAY_OF_MONTH));
        assertEquals(7, last.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testIteratorObjectAndErrors() {
        final Date focus = newDate(2002, Calendar.JULY, 4, 10, 0, 0, 0);
        assertNotNull(DateUtils.iterator((Object) focus, DateUtils.RANGE_WEEK_SUNDAY));
        assertNotNull(DateUtils.iterator((Object) DateUtils.toCalendar(focus), DateUtils.RANGE_WEEK_SUNDAY));
        assertThrows(NullPointerException.class, () -> DateUtils.iterator((Object) null, DateUtils.RANGE_WEEK_SUNDAY));
        assertThrows(ClassCastException.class, () -> DateUtils.iterator("not a date", DateUtils.RANGE_WEEK_SUNDAY));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.iterator(DateUtils.toCalendar(focus), 999));

        final Iterator<Calendar> it = DateUtils.iterator(DateUtils.toCalendar(focus), DateUtils.RANGE_WEEK_SUNDAY);
        assertThrows(UnsupportedOperationException.class, it::remove);
    }

    @Test
    void testParseDate() throws ParseException {
        final Date parsed = DateUtils.parseDate("2020-03-15", "yyyy-MM-dd");
        final Calendar c = DateUtils.toCalendar(parsed);
        assertEquals(2020, c.get(Calendar.YEAR));
        assertEquals(Calendar.MARCH, c.get(Calendar.MONTH));
        assertEquals(15, c.get(Calendar.DAY_OF_MONTH));

        // second pattern matches when the first does not
        final Date parsed2 = DateUtils.parseDate("15/03/2020", "yyyy-MM-dd", "dd/MM/yyyy");
        assertEquals(15, DateUtils.toCalendar(parsed2).get(Calendar.DAY_OF_MONTH));

        assertThrows(ParseException.class, () -> DateUtils.parseDate("not a date", "yyyy-MM-dd"));
        // lenient: Feb 31 rolls over to March 3
        final Date lenient = DateUtils.parseDate("20230231", "yyyyMMdd");
        final Calendar lc = DateUtils.toCalendar(lenient);
        assertEquals(Calendar.MARCH, lc.get(Calendar.MONTH));
        assertEquals(3, lc.get(Calendar.DAY_OF_MONTH));

        assertThrows(NullPointerException.class, () -> DateUtils.parseDate(null, "yyyy-MM-dd"));
        assertThrows(NullPointerException.class, () -> DateUtils.parseDate("2020-03-15", (String[]) null));
    }

    @Test
    void testParseDateStrictly() throws ParseException {
        final Date parsed = DateUtils.parseDateStrictly("2020-03-15", "yyyy-MM-dd");
        assertEquals(15, DateUtils.toCalendar(parsed).get(Calendar.DAY_OF_MONTH));

        // strict rejects Feb 31 instead of rolling over
        assertThrows(ParseException.class, () -> DateUtils.parseDateStrictly("20230231", "yyyyMMdd"));
        assertThrows(NullPointerException.class, () -> DateUtils.parseDateStrictly(null, "yyyy-MM-dd"));
    }

    @Test
    void testRoundCalendar() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Calendar result = DateUtils.round(DateUtils.toCalendar(date), Calendar.HOUR_OF_DAY);
        assertEquals(14, result.get(Calendar.HOUR_OF_DAY));
        assertThrows(NullPointerException.class, () -> DateUtils.round((Calendar) null, Calendar.HOUR_OF_DAY));
    }

    @Test
    void testRoundSemiMonthSpecialCase() {
        final Date firstHalf = newDate(2020, Calendar.MARCH, 10, 0, 0, 0, 0);
        final Calendar r1 = DateUtils.toCalendar(DateUtils.round(firstHalf, DateUtils.SEMI_MONTH));
        assertEquals(16, r1.get(Calendar.DAY_OF_MONTH));
        assertEquals(Calendar.MARCH, r1.get(Calendar.MONTH));

        final Date secondHalf = newDate(2020, Calendar.MARCH, 20, 0, 0, 0, 0);
        final Calendar r2 = DateUtils.toCalendar(DateUtils.round(secondHalf, DateUtils.SEMI_MONTH));
        assertEquals(16, r2.get(Calendar.DAY_OF_MONTH));
        assertEquals(Calendar.MARCH, r2.get(Calendar.MONTH));
    }

    @Test
    void testRoundObjectAndErrors() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertNotNull(DateUtils.round((Object) date, Calendar.HOUR_OF_DAY));
        assertNotNull(DateUtils.round((Object) DateUtils.toCalendar(date), Calendar.HOUR_OF_DAY));
        assertThrows(NullPointerException.class, () -> DateUtils.round((Object) null, Calendar.HOUR_OF_DAY));
        assertThrows(ClassCastException.class, () -> DateUtils.round("not a date", Calendar.HOUR_OF_DAY));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.round(date, Calendar.DAY_OF_WEEK));
    }

    @Test
    void testRoundArithmeticExceptionForHugeYear() {
        final Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(Calendar.YEAR, 300000000);
        assertThrows(ArithmeticException.class, () -> DateUtils.round(cal, Calendar.HOUR_OF_DAY));
    }

    @Test
    void testSetDays() {
        final Date date = newDate(2020, Calendar.JANUARY, 1, 10, 0, 0, 0);
        assertEquals(15, DateUtils.toCalendar(DateUtils.setDays(date, 15)).get(Calendar.DAY_OF_MONTH));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setDays(date, 0));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setDays(date, 32));
        assertThrows(NullPointerException.class, () -> DateUtils.setDays(null, 15));
    }

    @Test
    void testSetHours() {
        final Date date = newDate(2020, Calendar.JANUARY, 1, 10, 0, 0, 0);
        assertEquals(23, DateUtils.toCalendar(DateUtils.setHours(date, 23)).get(Calendar.HOUR_OF_DAY));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setHours(date, 24));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setHours(date, -1));
        assertThrows(NullPointerException.class, () -> DateUtils.setHours(null, 1));
    }

    @Test
    void testSetMilliseconds() {
        final Date date = newDate(2020, Calendar.JANUARY, 1, 10, 0, 0, 0);
        assertEquals(999, DateUtils.toCalendar(DateUtils.setMilliseconds(date, 999)).get(Calendar.MILLISECOND));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setMilliseconds(date, 1000));
        assertThrows(NullPointerException.class, () -> DateUtils.setMilliseconds(null, 1));
    }

    @Test
    void testSetMinutes() {
        final Date date = newDate(2020, Calendar.JANUARY, 1, 10, 0, 0, 0);
        assertEquals(59, DateUtils.toCalendar(DateUtils.setMinutes(date, 59)).get(Calendar.MINUTE));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setMinutes(date, 60));
        assertThrows(NullPointerException.class, () -> DateUtils.setMinutes(null, 1));
    }

    @Test
    void testSetMonths() {
        final Date date = newDate(2020, Calendar.JANUARY, 1, 10, 0, 0, 0);
        assertEquals(Calendar.DECEMBER, DateUtils.toCalendar(DateUtils.setMonths(date, Calendar.DECEMBER)).get(Calendar.MONTH));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setMonths(date, 12));
        assertThrows(NullPointerException.class, () -> DateUtils.setMonths(null, 1));
    }

    @Test
    void testSetSeconds() {
        final Date date = newDate(2020, Calendar.JANUARY, 1, 10, 0, 0, 0);
        assertEquals(59, DateUtils.toCalendar(DateUtils.setSeconds(date, 59)).get(Calendar.SECOND));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.setSeconds(date, 60));
        assertThrows(NullPointerException.class, () -> DateUtils.setSeconds(null, 1));
    }

    @Test
    void testSetYears() {
        final Date date = newDate(2020, Calendar.JANUARY, 1, 10, 0, 0, 0);
        assertEquals(1999, DateUtils.toCalendar(DateUtils.setYears(date, 1999)).get(Calendar.YEAR));
        assertThrows(NullPointerException.class, () -> DateUtils.setYears(null, 1));
    }

    @Test
    void testToCalendar() {
        final Date date = newDate(2020, Calendar.JANUARY, 1, 10, 0, 0, 0);
        final Calendar c = DateUtils.toCalendar(date);
        assertEquals(date.getTime(), c.getTime().getTime());
        assertThrows(NullPointerException.class, () -> DateUtils.toCalendar(null));
    }

    @Test
    void testToCalendarWithTimeZone() {
        final Date date = newDate(2020, Calendar.JANUARY, 1, 10, 0, 0, 0);
        final TimeZone tz = TimeZone.getTimeZone("UTC");
        final Calendar c = DateUtils.toCalendar(date, tz);
        assertEquals(tz, c.getTimeZone());
        assertEquals(date.getTime(), c.getTime().getTime());
        assertThrows(NullPointerException.class, () -> DateUtils.toCalendar(null, tz));
        assertThrows(NullPointerException.class, () -> DateUtils.toCalendar(date, null));
    }

    @Test
    void testToLocalDateTime() {
        final Date date = newDate(2020, Calendar.JANUARY, 1, 10, 30, 0, 0);
        final LocalDateTime ldt = DateUtils.toLocalDateTime(date);
        assertEquals(2020, ldt.getYear());
        assertEquals(1, ldt.getMonthValue());
        assertEquals(1, ldt.getDayOfMonth());
        assertEquals(10, ldt.getHour());
        assertEquals(30, ldt.getMinute());

        final LocalDateTime ldtUtc = DateUtils.toLocalDateTime(date, TimeZone.getTimeZone("UTC"));
        assertNotNull(ldtUtc);
    }

    @Test
    void testToOffsetDateTime() {
        final Date date = newDate(2020, Calendar.JANUARY, 1, 10, 30, 0, 0);
        final OffsetDateTime odt = DateUtils.toOffsetDateTime(date);
        assertEquals(date.toInstant(), odt.toInstant());

        final OffsetDateTime odtUtc = DateUtils.toOffsetDateTime(date, TimeZone.getTimeZone("UTC"));
        assertEquals(0, odtUtc.getOffset().getTotalSeconds());
    }

    @Test
    void testToZonedDateTime() {
        final Date date = newDate(2020, Calendar.JANUARY, 1, 10, 30, 0, 0);
        final ZonedDateTime zdt = DateUtils.toZonedDateTime(date);
        assertEquals(date.toInstant(), zdt.toInstant());

        final ZonedDateTime zdtUtc = DateUtils.toZonedDateTime(date, TimeZone.getTimeZone("UTC"));
        assertEquals("UTC", zdtUtc.getZone().getId());
    }

    @Test
    void testTruncateCalendar() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Calendar result = DateUtils.truncate(DateUtils.toCalendar(date), Calendar.HOUR_OF_DAY);
        assertEquals(13, result.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, result.get(Calendar.MINUTE));
        assertEquals(0, result.get(Calendar.SECOND));
        assertEquals(0, result.get(Calendar.MILLISECOND));
        assertThrows(NullPointerException.class, () -> DateUtils.truncate((Calendar) null, Calendar.HOUR_OF_DAY));
    }

    @Test
    void testTruncateDate() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Date result = DateUtils.truncate(date, Calendar.MONTH);
        final Calendar c = DateUtils.toCalendar(result);
        assertEquals(1, c.get(Calendar.DAY_OF_MONTH));
        assertEquals(0, c.get(Calendar.HOUR_OF_DAY));
        assertThrows(NullPointerException.class, () -> DateUtils.truncate((Date) null, Calendar.MONTH));
        assertThrows(IllegalArgumentException.class, () -> DateUtils.truncate(date, Calendar.DAY_OF_WEEK));
    }

    @Test
    void testTruncateObjectAndErrors() {
        final Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertNotNull(DateUtils.truncate((Object) date, Calendar.HOUR_OF_DAY));
        assertNotNull(DateUtils.truncate((Object) DateUtils.toCalendar(date), Calendar.HOUR_OF_DAY));
        assertThrows(NullPointerException.class, () -> DateUtils.truncate((Object) null, Calendar.HOUR_OF_DAY));
        assertThrows(ClassCastException.class, () -> DateUtils.truncate("not a date", Calendar.HOUR_OF_DAY));
    }

    @Test
    void testTruncateMillisecondFieldIsNoOp() {
        final Calendar cal = DateUtils.toCalendar(newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231));
        final Calendar result = DateUtils.truncate(cal, Calendar.MILLISECOND);
        assertEquals(231, result.get(Calendar.MILLISECOND));
    }

    @Test
    void testTruncatedCompareToAndEquals() {
        final Date d1 = newDate(2020, Calendar.MARCH, 10, 5, 30, 0, 0);
        final Date d2 = newDate(2020, Calendar.MARCH, 10, 9, 15, 0, 0);
        assertTrue(DateUtils.truncatedEquals(d1, d2, Calendar.DATE));
        assertFalse(DateUtils.truncatedEquals(d1, d2, Calendar.HOUR_OF_DAY));
        assertEquals(0, DateUtils.truncatedCompareTo(d1, d2, Calendar.DATE));
        assertTrue(DateUtils.truncatedCompareTo(d1, d2, Calendar.HOUR_OF_DAY) < 0);

        final Calendar c1 = DateUtils.toCalendar(d1);
        final Calendar c2 = DateUtils.toCalendar(d2);
        assertTrue(DateUtils.truncatedEquals(c1, c2, Calendar.DATE));
        assertFalse(DateUtils.truncatedEquals(c1, c2, Calendar.HOUR_OF_DAY));
    }

    @Test
    void testConstants() {
        assertEquals(1000L, DateUtils.MILLIS_PER_SECOND);
        assertEquals(60000L, DateUtils.MILLIS_PER_MINUTE);
        assertEquals(3600000L, DateUtils.MILLIS_PER_HOUR);
        assertEquals(86400000L, DateUtils.MILLIS_PER_DAY);
        assertEquals(1001, DateUtils.SEMI_MONTH);
        assertEquals(1, DateUtils.RANGE_WEEK_SUNDAY);
        assertEquals(2, DateUtils.RANGE_WEEK_MONDAY);
        assertEquals(3, DateUtils.RANGE_WEEK_RELATIVE);
        assertEquals(4, DateUtils.RANGE_WEEK_CENTER);
        assertEquals(5, DateUtils.RANGE_MONTH_SUNDAY);
        assertEquals(6, DateUtils.RANGE_MONTH_MONDAY);
    }

    @Test
    void testPublicConstructor() {
        // deprecated public constructor, retained for tools requiring a bean instance
        assertNotNull(new DateUtils());
    }

    @Test
    void testDateIteratorNoSuchElementAfterExhaustion() {
        final Calendar start = Calendar.getInstance();
        start.clear();
        start.set(2020, Calendar.JANUARY, 1);
        final Iterator<Calendar> it = DateUtils.iterator(start, DateUtils.RANGE_WEEK_RELATIVE);
        while (it.hasNext()) {
            it.next();
        }
        assertFalse(it.hasNext());
        assertThrows(NoSuchElementException.class, it::next);
    }

    @Test
    void testIsSameLocalTimeDifferentCalendarTypeIsFalse() {
        final Calendar g1 = new GregorianCalendar();
        g1.clear();
        g1.set(2020, Calendar.JANUARY, 1, 1, 1, 1);
        final Calendar g2 = Calendar.getInstance();
        g2.clear();
        g2.set(2020, Calendar.JANUARY, 1, 1, 1, 1);
        // same values, same concrete class (GregorianCalendar by default) -> true
        assertEquals(g1.getClass(), g2.getClass());
        assertTrue(DateUtils.isSameLocalTime(g1, g2));
    }
}
