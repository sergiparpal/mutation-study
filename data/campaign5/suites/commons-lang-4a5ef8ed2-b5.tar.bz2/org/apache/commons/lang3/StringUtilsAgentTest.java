/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link StringUtils}.
 */
class StringUtilsAgentTest {

    @Test
    void testIsEmptyIsBlank() {
        assertTrue(StringUtils.isEmpty(null));
        assertTrue(StringUtils.isEmpty(""));
        assertFalse(StringUtils.isEmpty(" "));
        assertFalse(StringUtils.isEmpty("abc"));

        assertTrue(StringUtils.isBlank(null));
        assertTrue(StringUtils.isBlank(""));
        assertTrue(StringUtils.isBlank(" \t\n"));
        assertFalse(StringUtils.isBlank(" a "));

        assertFalse(StringUtils.isNotEmpty(null));
        assertTrue(StringUtils.isNotEmpty("x"));

        assertFalse(StringUtils.isNotBlank(" "));
        assertTrue(StringUtils.isNotBlank("x"));
    }

    @Test
    void testIsAnyAllNoneBlankEmpty() {
        assertTrue(StringUtils.isAnyEmpty("a", ""));
        assertFalse(StringUtils.isAnyEmpty("a", "b"));
        assertFalse(StringUtils.isAnyEmpty());

        assertTrue(StringUtils.isAllEmpty("", null));
        assertFalse(StringUtils.isAllEmpty("", "a"));
        assertTrue(StringUtils.isAllEmpty());

        assertTrue(StringUtils.isAnyBlank("a", " "));
        assertFalse(StringUtils.isAnyBlank("a", "b"));

        assertTrue(StringUtils.isAllBlank(" ", null, ""));
        assertFalse(StringUtils.isAllBlank(" ", "b"));

        assertTrue(StringUtils.isNoneEmpty("a", "b"));
        assertFalse(StringUtils.isNoneEmpty("a", ""));

        assertTrue(StringUtils.isNoneBlank("a", "b"));
        assertFalse(StringUtils.isNoneBlank("a", " "));
    }

    @Test
    void testTrimAndStrip() {
        assertNull(StringUtils.trim(null));
        assertEquals("", StringUtils.trim("   "));
        assertEquals("abc", StringUtils.trim("  abc  "));

        assertEquals("", StringUtils.trimToEmpty(null));
        assertEquals("abc", StringUtils.trimToEmpty(" abc "));

        assertNull(StringUtils.trimToNull("   "));
        assertEquals("abc", StringUtils.trimToNull(" abc "));

        assertNull(StringUtils.strip(null));
        assertEquals("abc", StringUtils.strip(" abc "));
        assertEquals("abc", StringUtils.strip("xxabcxx", "x"));

        assertEquals("", StringUtils.stripToEmpty(null));
        assertNull(StringUtils.stripToNull("   "));

        assertEquals("abc  ", StringUtils.stripStart("  abc  ", null));
        assertEquals("  abc", StringUtils.stripEnd("  abc  ", null));
    }

    @Test
    void testEquals() {
        assertTrue(StringUtils.equals(null, null));
        assertFalse(StringUtils.equals(null, "abc"));
        assertFalse(StringUtils.equals("abc", null));
        assertTrue(StringUtils.equals("abc", "abc"));
        assertFalse(StringUtils.equals("abc", "abcd"));
        assertTrue(StringUtils.equals(new StringBuilder("abc"), "abc"));

        assertTrue(StringUtils.equalsIgnoreCase(null, null));
        assertFalse(StringUtils.equalsIgnoreCase(null, "abc"));
        assertTrue(StringUtils.equalsIgnoreCase("ABC", "abc"));
        assertFalse(StringUtils.equalsIgnoreCase("ABCD", "abc"));

        assertTrue(StringUtils.equalsAny("abc", "x", "abc"));
        assertFalse(StringUtils.equalsAny("abc", "x", "y"));
        assertFalse(StringUtils.equalsAny("abc"));

        assertTrue(StringUtils.equalsAnyIgnoreCase("ABC", "x", "abc"));
    }

    @Test
    void testCompare() {
        assertEquals(0, StringUtils.compare(null, null));
        assertTrue(StringUtils.compare(null, "a") < 0);
        assertTrue(StringUtils.compare("a", null) > 0);
        assertTrue(StringUtils.compare("a", "b") < 0);

        assertTrue(StringUtils.compare(null, "a", true) < 0);
        assertTrue(StringUtils.compare(null, "a", false) > 0);

        assertEquals(0, StringUtils.compareIgnoreCase("ABC", "abc"));
    }

    @Test
    void testIndexOf() {
        assertEquals(-1, StringUtils.indexOf(null, "a"));
        assertEquals(-1, StringUtils.indexOf("abc", null));
        assertEquals(0, StringUtils.indexOf("", ""));
        assertEquals(2, StringUtils.indexOf("abcabc", "c"));
        assertEquals(2, StringUtils.indexOf("abcabc", "c", 0));
        assertEquals(5, StringUtils.indexOf("abcabc", "c", 3));

        assertEquals(-1, StringUtils.indexOf((CharSequence) null, 'a'));
        assertEquals(1, StringUtils.indexOf("abc", 'b'));
        assertEquals(-1, StringUtils.indexOf("abc", 'z'));

        assertEquals(1, StringUtils.indexOfIgnoreCase("aBc", "B"));
        assertEquals(StringUtils.INDEX_NOT_FOUND, StringUtils.indexOfIgnoreCase("abc", "z"));

        assertEquals(4, StringUtils.lastIndexOf("aabaabaa", "ab"));
        assertEquals(-1, StringUtils.lastIndexOf(null, "a"));
        assertEquals(5, StringUtils.lastIndexOf("abcabc", 'c'));

        assertEquals(0, StringUtils.indexOfAny("zzabyycdxx", 'z', 'a'));
        assertEquals(-1, StringUtils.indexOfAny((CharSequence) null, 'a'));
        assertEquals(-1, StringUtils.indexOfAny("abc", 'z'));

        assertEquals(2, StringUtils.indexOfAnyBut("zzabyycdxx", 'z'));
        assertEquals(4, StringUtils.ordinalIndexOf("aabaabaa", "a", 4));
        assertEquals(-1, StringUtils.ordinalIndexOf(null, "a", 1));
    }

    @Test
    void testContains() {
        assertFalse(StringUtils.contains(null, "a"));
        assertFalse(StringUtils.contains("abc", null));
        assertTrue(StringUtils.contains("abc", ""));
        assertTrue(StringUtils.contains("abc", "b"));
        assertFalse(StringUtils.contains("abc", "z"));

        assertTrue(StringUtils.contains("abc", 'a'));
        assertFalse(StringUtils.contains((CharSequence) null, 'a'));

        assertTrue(StringUtils.containsIgnoreCase("ABC", "b"));
        assertFalse(StringUtils.containsIgnoreCase(null, "b"));

        assertTrue(StringUtils.containsAny("abc", 'z', 'a'));
        assertFalse(StringUtils.containsAny("abc", 'y', 'z'));

        assertTrue(StringUtils.containsNone("abc", 'x', 'y'));
        assertFalse(StringUtils.containsNone("abc", 'a'));

        assertTrue(StringUtils.containsOnly("aabbcc", 'a', 'b', 'c'));
        assertFalse(StringUtils.containsOnly("aabbccd", 'a', 'b', 'c'));

        assertTrue(StringUtils.containsWhitespace(" a"));
        assertFalse(StringUtils.containsWhitespace("abc"));
    }

    @Test
    void testStartsEndsWith() {
        assertTrue(StringUtils.startsWith("abcdef", "abc"));
        assertFalse(StringUtils.startsWith(null, "abc"));
        assertTrue(StringUtils.startsWith(null, null));

        assertTrue(StringUtils.startsWithIgnoreCase("ABCdef", "abc"));
        assertTrue(StringUtils.startsWithAny("abcdef", "xyz", "abc"));
        assertFalse(StringUtils.startsWithAny("abcdef", "xyz", "def"));

        assertTrue(StringUtils.endsWith("abcdef", "def"));
        assertFalse(StringUtils.endsWith("abcdef", "abc"));
        assertTrue(StringUtils.endsWithIgnoreCase("abcDEF", "def"));
        assertTrue(StringUtils.endsWithAny("abcdef", "xyz", "def"));
    }

    @Test
    void testSubstring() {
        assertNull(StringUtils.substring(null, 0));
        assertEquals("cde", StringUtils.substring("abcde", 2));
        assertEquals("de", StringUtils.substring("abcde", -2));
        assertEquals("", StringUtils.substring("abcde", 10));

        assertNull(StringUtils.substring(null, 0, 2));
        assertEquals("ab", StringUtils.substring("abcde", 0, 2));
        assertEquals("abc", StringUtils.substring("abcde", -5, 3));
        assertEquals("", StringUtils.substring("abcde", 3, 1));

        assertEquals("def", StringUtils.substringAfter("abcdef", "c"));
        assertEquals("", StringUtils.substringAfter("abcdef", "z"));
        assertNull(StringUtils.substringAfter(null, "c"));

        assertEquals("ab", StringUtils.substringBefore("abcdef", "c"));
        assertEquals("abcdef", StringUtils.substringBefore("abcdef", "z"));

        assertEquals("a", StringUtils.substringAfterLast("abcba", "b"));
        assertEquals("", StringUtils.substringAfterLast("abcba", "a"));

        assertEquals("bcb", StringUtils.substringBetween("abcba", "a"));
        assertNull(StringUtils.substringBetween("abc", "x"));
        assertEquals("b", StringUtils.substringBetween("yabcz", "a", "c"));

        assertArrayEquals(new String[] {"a", "b"}, StringUtils.substringsBetween("[a][b]", "[", "]"));
    }

    @Test
    void testLeftRightMid() {
        assertNull(StringUtils.left(null, 3));
        assertEquals("", StringUtils.left("abc", -1));
        assertEquals("ab", StringUtils.left("abc", 2));
        assertEquals("abc", StringUtils.left("abc", 10));

        assertNull(StringUtils.right(null, 3));
        assertEquals("", StringUtils.right("abc", -1));
        assertEquals("bc", StringUtils.right("abc", 2));
        assertEquals("abc", StringUtils.right("abc", 10));

        assertNull(StringUtils.mid(null, 0, 2));
        assertEquals("", StringUtils.mid("abc", 0, -1));
        assertEquals("bc", StringUtils.mid("abc", 1, 2));
        assertEquals("ab", StringUtils.mid("abc", -1, 2));
        assertEquals("", StringUtils.mid("abc", 10, 2));
    }

    @Test
    void testPadding() {
        assertNull(StringUtils.leftPad(null, 3));
        assertEquals("  abc", StringUtils.leftPad("abc", 5));
        assertEquals("abc", StringUtils.leftPad("abc", 2));
        assertEquals("00abc", StringUtils.leftPad("abc", 5, '0'));
        assertEquals("xyxyabc", StringUtils.leftPad("abc", 7, "xy"));

        assertEquals("abc  ", StringUtils.rightPad("abc", 5));
        assertEquals("abc00", StringUtils.rightPad("abc", 5, '0'));
        assertEquals("abcxyxy", StringUtils.rightPad("abc", 7, "xy"));
    }

    @Test
    void testCenter() {
        assertNull(StringUtils.center(null, 4));
        assertEquals("abc", StringUtils.center("abc", 2));
        assertEquals("  abc   ", StringUtils.center("abc", 8));
        assertEquals("aabcaa", StringUtils.center("abc", 6, 'a'));
        assertEquals("ababcab", StringUtils.center("abc", 7, "ab"));
    }

    @Test
    void testRepeat() {
        assertNull(StringUtils.repeat(null, 2));
        assertEquals("", StringUtils.repeat("ab", 0));
        assertEquals("", StringUtils.repeat("ab", -1));
        assertEquals("ababab", StringUtils.repeat("ab", 3));
        assertEquals("aaa", StringUtils.repeat('a', 3));
        assertEquals("", StringUtils.repeat('a', 0));
        assertEquals("a-a-a", StringUtils.repeat("a", "-", 3));
        assertEquals("", StringUtils.repeat("a", "-", 0));
    }

    @Test
    void testReplace() {
        assertNull(StringUtils.replace(null, "a", "b"));
        assertEquals("abc", StringUtils.replace("abc", null, "b"));
        assertEquals("abc", StringUtils.replace("abc", "a", null));
        assertEquals("zbc", StringUtils.replace("abc", "a", "z"));
        assertEquals("zbzb", StringUtils.replace("abab", "a", "z"));
        assertEquals("zbab", StringUtils.replace("abab", "a", "z", 1));
        assertEquals("abab", StringUtils.replace("abab", "a", "z", 0));

        assertEquals("fooBAR", StringUtils.replaceIgnoreCase("foobar", "bar", "BAR"));
        assertEquals("barfoo", StringUtils.replaceOnce("foofoo", "foo", "bar"));
        assertNull(StringUtils.replaceOnce(null, "a", "b"));

        assertEquals("fizzfizz", StringUtils.replaceEach("hellohello", new String[] {"hello", "hello"}, new String[] {"fizz", "buzz"}));
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.replaceEachRepeatedly("abcde", new String[] {"ab", "d"}, new String[] {"d", "ab"});
            }
        });

        assertEquals("ayzaa", StringUtils.replaceChars("abcaa", "bc", "yz"));
        assertEquals("1bc11", StringUtils.replaceChars("abcaa", 'a', '1'));
    }

    @Test
    void testRemove() {
        assertNull(StringUtils.remove(null, 'a'));
        assertEquals("qeot", StringUtils.remove("queout", 'u'));
        assertEquals("abc", StringUtils.remove("abc", 'd'));

        assertNull(StringUtils.remove(null, "an"));
        assertEquals("ueue", StringUtils.remove("queueq", "q"));
        assertEquals("abc", StringUtils.remove("abc", "x"));

        assertEquals("www.domain.com", StringUtils.removeStart("www.domain.com", "http://"));
        assertEquals("domain.com", StringUtils.removeStart("www.domain.com", "www."));
        assertEquals("domain.com", StringUtils.removeStartIgnoreCase("WWW.domain.com", "www."));

        assertEquals("www.domain", StringUtils.removeEnd("www.domain.com", ".com"));
        assertEquals("www.domain", StringUtils.removeEndIgnoreCase("www.domain.COM", ".com"));

        assertEquals("Qeee", StringUtils.removeIgnoreCase("QueUee", "U"));
        assertNull(StringUtils.removeIgnoreCase(null, "u"));
    }

    @Test
    void testCapitalizeAndSwapCase() {
        assertNull(StringUtils.capitalize(null));
        assertEquals("", StringUtils.capitalize(""));
        assertEquals("Cat", StringUtils.capitalize("cat"));
        assertEquals("CAT", StringUtils.capitalize("CAT"));

        assertNull(StringUtils.uncapitalize(null));
        assertEquals("cat", StringUtils.uncapitalize("Cat"));
        assertEquals("cAT", StringUtils.uncapitalize("CAT"));

        assertNull(StringUtils.swapCase(null));
        assertEquals("", StringUtils.swapCase(""));
        assertEquals("tHE DOG HAS A bone", StringUtils.swapCase("The dog has a BONE"));
    }

    @Test
    void testCaseConversion() {
        assertNull(StringUtils.upperCase(null));
        assertEquals("ABC", StringUtils.upperCase("abc"));
        assertNull(StringUtils.lowerCase(null));
        assertEquals("abc", StringUtils.lowerCase("ABC"));
    }

    @Test
    void testReverse() {
        assertNull(StringUtils.reverse(null));
        assertEquals("", StringUtils.reverse(""));
        assertEquals("cba", StringUtils.reverse("abc"));

        assertEquals("c.b.a", StringUtils.reverseDelimited("a.b.c", '.'));
    }

    @Test
    void testIsNumericAlpha() {
        assertFalse(StringUtils.isNumeric(null));
        assertFalse(StringUtils.isNumeric(""));
        assertTrue(StringUtils.isNumeric("123"));
        assertFalse(StringUtils.isNumeric("12 3"));
        assertFalse(StringUtils.isNumeric("-123"));

        assertTrue(StringUtils.isNumericSpace("12 3"));
        assertTrue(StringUtils.isNumericSpace(""));

        assertFalse(StringUtils.isAlpha(null));
        assertTrue(StringUtils.isAlpha("abc"));
        assertFalse(StringUtils.isAlpha("abc123"));

        assertTrue(StringUtils.isAlphanumeric("abc123"));
        assertFalse(StringUtils.isAlphanumeric("abc 123"));

        assertTrue(StringUtils.isAlphanumericSpace("abc 123"));
        assertTrue(StringUtils.isAlphaSpace("ab c"));

        assertTrue(StringUtils.isAllLowerCase("abc"));
        assertFalse(StringUtils.isAllLowerCase("abC"));
        assertTrue(StringUtils.isAllUpperCase("ABC"));
        assertFalse(StringUtils.isAllUpperCase(""));

        assertTrue(StringUtils.isMixedCase("aB"));
        assertFalse(StringUtils.isMixedCase("AB"));
        assertFalse(StringUtils.isMixedCase(null));

        assertTrue(StringUtils.isWhitespace("   "));
        assertFalse(StringUtils.isWhitespace(" a "));

        assertTrue(StringUtils.isAsciiPrintable("abc 123!"));
        assertFalse(StringUtils.isAsciiPrintable("abc\u0001"));
        assertFalse(StringUtils.isAsciiPrintable(null));
    }

    @Test
    void testJoin() {
        assertEquals("a,b,c", StringUtils.join(new String[] {"a", "b", "c"}, ','));
        assertNull(StringUtils.join((Object[]) null, ','));
        assertEquals("", StringUtils.join(new Object[0], ','));
        assertEquals("abc", StringUtils.join(new String[] {"a", null, "b", null, "c"}, (String) null));
        assertEquals("1-2", StringUtils.join(new int[] {1, 2}, '-'));
        assertEquals("1,2,3", StringUtils.join(Arrays.asList(1, 2, 3).iterator(), ','));
        assertEquals("1,2,3", StringUtils.join(Arrays.asList(1, 2, 3), ','));
        assertEquals("a:b", StringUtils.joinWith(":", "a", "b"));

        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.joinWith(":", (Object[]) null);
            }
        });
    }

    @Test
    void testSplit() {
        assertArrayEquals(new String[] {"ab", "cd", "ef"}, StringUtils.split("ab cd ef"));
        assertArrayEquals(new String[0], StringUtils.split(""));
        assertNull(StringUtils.split((String) null));

        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.split("a.b.c", '.'));
        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.split("a..b.c", '.'));

        assertArrayEquals(new String[] {"a", "", "b", "c"}, StringUtils.splitPreserveAllTokens("a..b.c", '.'));

        assertArrayEquals(new String[] {"a", "b.c"}, StringUtils.split("a.b.c", ".", 2));

        assertArrayEquals(new String[] {"ab", "cd"}, StringUtils.splitByWholeSeparator("ab--cd", "--"));
        assertArrayEquals(new String[] {"ab", "cd-!-ef"}, StringUtils.splitByWholeSeparator("ab-!-cd-!-ef", "-!-", 2));

        assertArrayEquals(new String[] {"ab", "cd:ef"}, StringUtils.splitByWholeSeparatorPreserveAllTokens("ab:cd:ef", ":", 2));
    }

    @Test
    void testSplitByCharacterType() {
        assertArrayEquals(new String[] {"ab", "CD"}, StringUtils.splitByCharacterType("abCD"));
        assertArrayEquals(new String[] {"foo", "Bar"}, StringUtils.splitByCharacterTypeCamelCase("fooBar"));
        assertArrayEquals(new String[] {"ASF", "Rules"}, StringUtils.splitByCharacterTypeCamelCase("ASFRules"));
        assertNull(StringUtils.splitByCharacterType(null));
    }

    @Test
    void testCountMatches() {
        assertEquals(0, StringUtils.countMatches(null, "a"));
        assertEquals(0, StringUtils.countMatches("abba", ""));
        assertEquals(2, StringUtils.countMatches("abba", "a"));
        assertEquals(1, StringUtils.countMatches("abba", "ab"));

        assertEquals(0, StringUtils.countMatches(null, 'a'));
        assertEquals(2, StringUtils.countMatches("abba", 'a'));
    }

    @Test
    void testAbbreviate() {
        assertNull(StringUtils.abbreviate(null, 4));
        assertEquals("", StringUtils.abbreviate("", 4));
        assertEquals("abc...", StringUtils.abbreviate("abcdefg", 6));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", 10));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.abbreviate("abcdefg", 3);
            }
        });

        assertEquals("...ghij...", StringUtils.abbreviate("abcdefghijklmno", 6, 10));
        assertEquals("abcdefg", StringUtils.abbreviateMiddle("abcdefg", ".", 1000));
        assertEquals("ab.fg", StringUtils.abbreviateMiddle("abcdefg", ".", 5));
    }

    @Test
    void testDifferenceAndCommonPrefix() {
        assertEquals("abc", StringUtils.difference(null, "abc"));
        assertEquals("abc", StringUtils.difference("abc", null));
        assertEquals("", StringUtils.difference("abc", "abc"));
        assertEquals("d", StringUtils.difference("abc", "abcd"));
        assertEquals("y", StringUtils.difference("ab", "ay"));

        assertEquals("abc", StringUtils.getCommonPrefix("abc", "abcd", "abcde"));
        assertEquals("", StringUtils.getCommonPrefix("abc", "xyz"));
        assertEquals("", StringUtils.getCommonPrefix());

        assertEquals(-1, StringUtils.indexOfDifference("abc", "abc"));
        assertEquals(2, StringUtils.indexOfDifference("abc", "abd"));
    }

    @Test
    void testDefaultString() {
        assertEquals("", StringUtils.defaultString(null));
        assertEquals("abc", StringUtils.defaultString("abc"));
        assertEquals("NULL", StringUtils.defaultString(null, "NULL"));

        assertEquals("abc", StringUtils.defaultIfEmpty("", "abc"));
        assertEquals("xyz", StringUtils.defaultIfEmpty("xyz", "abc"));

        assertEquals("abc", StringUtils.defaultIfBlank("  ", "abc"));
        assertEquals("xyz", StringUtils.defaultIfBlank("xyz", "abc"));

        assertEquals("a", StringUtils.firstNonBlank(null, "", " ", "a", "b"));
        assertEquals("a", StringUtils.firstNonEmpty(null, "", "a", "b"));
        assertNull(StringUtils.firstNonBlank());
    }

    @Test
    void testChompChop() {
        assertNull(StringUtils.chomp(null));
        assertEquals("abc", StringUtils.chomp("abc\n"));
        assertEquals("abc", StringUtils.chomp("abc\r\n"));
        assertEquals("abc", StringUtils.chomp("abc"));
        assertEquals("foo", StringUtils.chomp("foobar", "bar"));

        assertNull(StringUtils.chop(null));
        assertEquals("", StringUtils.chop(""));
        assertEquals("ab", StringUtils.chop("abc"));
        assertEquals("", StringUtils.chop("a"));
        assertEquals("abc", StringUtils.chop("abc\r\n"));
    }

    @Test
    void testNormalizeAndDeleteWhitespace() {
        assertNull(StringUtils.normalizeSpace(null));
        assertEquals("a b c", StringUtils.normalizeSpace("  a   b  c  "));

        assertEquals("", StringUtils.deleteWhitespace("   "));
        assertEquals("abc", StringUtils.deleteWhitespace(" a b c "));
        assertNull(StringUtils.deleteWhitespace(null));
    }

    @Test
    void testWrapAndUnwrap() {
        assertNull(StringUtils.wrap(null, '"'));
        assertEquals("\"abc\"", StringUtils.wrap("abc", '"'));
        assertEquals("\"\"abc\"\"", StringUtils.wrap("\"abc\"", '"'));
        assertEquals("'ab'", StringUtils.wrap("ab", "'"));

        assertEquals("abc", StringUtils.unwrap("\"abc\"", '"'));
        assertEquals("\"abc", StringUtils.unwrap("\"abc", '"'));

        assertEquals("'ab'", StringUtils.wrapIfMissing("ab", "'"));
        assertEquals("'ab'", StringUtils.wrapIfMissing("'ab'", "'"));
        assertEquals("'ab'", StringUtils.wrapIfMissing("ab", '\''));
        assertEquals("ab", StringUtils.wrapIfMissing("ab", '\0'));
    }

    @Test
    void testOverlayAndRotate() {
        assertEquals("abef", StringUtils.overlay("abcdef", "", 2, 4));
        assertEquals("abzzzdef", StringUtils.overlay("abcdef", "zzz", 2, 3));
        assertNull(StringUtils.overlay(null, "x", 0, 0));

        assertEquals("fgabcde", StringUtils.rotate("abcdefg", 2));
        assertEquals("cdefgab", StringUtils.rotate("abcdefg", -2));
        assertEquals("abcdefg", StringUtils.rotate("abcdefg", 0));
        assertNull(StringUtils.rotate(null, 2));
        assertEquals("", StringUtils.rotate("", 2));
    }

    @Test
    void testTruncate() {
        assertNull(StringUtils.truncate(null, 10));
        assertEquals("", StringUtils.truncate("", 10));
        assertEquals("abc", StringUtils.truncate("abcdefghij", 3));
        assertEquals("abcdefghij", StringUtils.truncate("abcdefghij", 20));

        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.truncate("abc", -1);
            }
        });

        assertEquals("fghij", StringUtils.truncate("abcdefghij", 5, 6));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.truncate("abcdefghij", -2, 4);
            }
        });
    }

    @Test
    void testGetBytesAndToString() throws UnsupportedEncodingException {
        byte[] bytes = StringUtils.getBytes("abc", StandardCharsets.UTF_8);
        assertEquals(3, bytes.length);

        byte[] bytesByName = StringUtils.getBytes("abc", "UTF-8");
        assertArrayEquals(bytes, bytesByName);

        assertThrows(UnsupportedEncodingException.class, new Executable() {
            @Override
            public void execute() throws UnsupportedEncodingException {
                StringUtils.getBytes("abc", "NOT-A-REAL-CHARSET");
            }
        });

        assertEquals("abc", StringUtils.toString(new byte[] {'a', 'b', 'c'}, "UTF-8"));
    }

    @Test
    void testLevenshteinDistance() {
        assertEquals(0, StringUtils.getLevenshteinDistance("", ""));
        assertEquals(3, StringUtils.getLevenshteinDistance("", "abc"));
        assertEquals(1, StringUtils.getLevenshteinDistance("abc", "abd"));
        assertEquals(0, StringUtils.getLevenshteinDistance("frog", "frog"));

        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.getLevenshteinDistance(null, "abc");
            }
        });

        assertEquals(1, StringUtils.getLevenshteinDistance("abc", "abd", 5));
        assertEquals(-1, StringUtils.getLevenshteinDistance("abc", "xyz", 1));
    }

    @Test
    void testLengthAndToCodePoints() {
        assertEquals(0, StringUtils.length(null));
        assertEquals(3, StringUtils.length("abc"));

        int[] codePoints = StringUtils.toCodePoints("ab");
        assertArrayEquals(new int[] {'a', 'b'}, codePoints);
        assertNull(StringUtils.toCodePoints(null));
    }

    @Test
    void testStripAll() {
        assertArrayEquals(new String[] {"abc", "def"}, StringUtils.stripAll(" abc ", " def "));
        assertNull(StringUtils.stripAll((String[]) null));
    }
}
