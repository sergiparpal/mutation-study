/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.apache.commons.csv.Constants.UNDEFINED;
import static org.apache.commons.io.IOUtils.EOF;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.StandardCharsets;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link ExtendedBufferedReader}.
 */
class ExtendedBufferedReaderAgentTest {

    private ExtendedBufferedReader create(final String s) {
        return new ExtendedBufferedReader(new StringReader(s));
    }

    @Test
    void testInitialState() throws IOException {
        final ExtendedBufferedReader br = create("abc");
        assertEquals(UNDEFINED, br.getLastChar());
        assertEquals(0, br.getLineNumber());
        assertEquals(0, br.getPosition());
        assertEquals(0, br.getBytesRead());
        br.close();
    }

    @Test
    void testReadZeroLengthOnNonEmptyStreamDoesNotAdvance() throws IOException {
        final ExtendedBufferedReader br = create("abc");
        final char[] buf = new char[3];
        assertEquals(0, br.read(buf, 0, 0));
        assertEquals(0, br.getPosition());
        assertEquals(UNDEFINED, br.getLastChar());
        // Subsequent real read still starts from the beginning.
        assertEquals('a', br.read());
        assertEquals(1, br.getPosition());
        br.close();
    }

    @Test
    void testReadBufferAtEofReturnsEofAndSetsLastChar() throws IOException {
        final ExtendedBufferedReader br = create("");
        final char[] buf = new char[5];
        assertEquals(EOF, br.read(buf, 0, 5));
        assertEquals(EOF, br.getLastChar());
        assertEquals(EOF, br.getPosition());
        br.close();
    }

    @Test
    void testPositionTracksSingleCharReads() throws IOException {
        final ExtendedBufferedReader br = create("xyz");
        assertEquals(0, br.getPosition());
        assertEquals('x', br.read());
        assertEquals(1, br.getPosition());
        assertEquals('y', br.read());
        assertEquals(2, br.getPosition());
        assertEquals('z', br.read());
        assertEquals(3, br.getPosition());
        assertEquals(EOF, br.read());
        assertEquals(4, br.getPosition());
        br.close();
    }

    @Test
    void testPeekDoesNotAdvancePositionOrLastChar() throws IOException {
        final ExtendedBufferedReader br = create("ab");
        assertEquals('a', br.peek());
        assertEquals(0, br.getPosition());
        assertEquals(UNDEFINED, br.getLastChar());
        assertEquals('a', br.read());
        assertEquals('b', br.peek());
        assertEquals(1, br.getPosition());
        assertEquals('a', br.getLastChar());
        br.close();
    }

    @Test
    void testGetLineNumberMidLineVsAtEol() throws IOException {
        final ExtendedBufferedReader br = create("ab\ncd");
        assertEquals(0, br.getLineNumber());
        br.read(); // 'a'
        assertEquals(1, br.getLineNumber()); // mid-line: counter + 1
        br.read(); // 'b'
        assertEquals(1, br.getLineNumber());
        br.read(); // '\n'
        assertEquals(1, br.getLineNumber()); // at EOL: counter is accurate
        br.read(); // 'c'
        assertEquals(2, br.getLineNumber());
        br.close();
    }

    @Test
    void testCrLfPairInSingleBufferReadCountsAsOneLineEach() throws IOException {
        final ExtendedBufferedReader br = create("\r\n\r\n");
        final char[] buf = new char[4];
        assertEquals(4, br.read(buf, 0, 4));
        assertEquals(2, br.getLineNumber());
        assertEquals(EOF, br.read());
        assertEquals(2, br.getLineNumber());
        br.close();
    }

    @Test
    void testReadLineTrailingCrOnlyThenEof() throws IOException {
        final ExtendedBufferedReader br = create("abc\r");
        assertEquals("abc", br.readLine());
        assertNull(br.readLine());
        assertEquals('\r', br.getLastChar());
        br.close();
    }

    @Test
    void testReadLineOnEmptyReturnsNull() throws IOException {
        final ExtendedBufferedReader br = create("");
        assertNull(br.readLine());
        br.close();
    }

    @Test
    void testMarkAndResetRestoreFullState() throws IOException {
        final ExtendedBufferedReader br = create("ab\ncd\nef");
        br.read(); // 'a'
        br.read(); // 'b'
        br.read(); // '\n' -> lineNumber=1, position=3, lastChar='\n'
        final long positionBeforeMark = br.getPosition();
        final long lineNumberBeforeMark = br.getLineNumber();
        final int lastCharBeforeMark = br.getLastChar();

        br.mark(16);
        br.read(); // 'c'
        br.read(); // 'd'
        br.read(); // '\n'
        assertEquals(positionBeforeMark + 3, br.getPosition());

        br.reset();
        assertEquals(positionBeforeMark, br.getPosition());
        assertEquals(lineNumberBeforeMark, br.getLineNumber());
        assertEquals(lastCharBeforeMark, br.getLastChar());

        // Reading after reset replays the same characters.
        assertEquals('c', br.read());
        br.close();
    }

    @Test
    void testCloseSetsLastCharToEofAndRejectsFurtherReads() throws IOException {
        final ExtendedBufferedReader br = create("abc");
        br.read();
        br.close();
        assertEquals(EOF, br.getLastChar());
        assertThrows(IOException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                br.read();
            }
        });
    }

    @Test
    void testBytesReadWithoutCharsetTrackingStaysZero() throws IOException {
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("hello"), StandardCharsets.UTF_8, false);
        br.read();
        final char[] buf = new char[4];
        br.read(buf, 0, 4);
        assertEquals(0, br.getBytesRead());
        br.close();
    }

    @Test
    void testBytesReadWithoutCharsetAtAllStaysZero() throws IOException {
        final ExtendedBufferedReader br = create("hello");
        br.read();
        assertEquals(0, br.getBytesRead());
        br.close();
    }

    @Test
    void testBytesReadAsciiMatchesCharCountSingleReads() throws IOException {
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("abc"), StandardCharsets.UTF_8, true);
        br.read();
        br.read();
        br.read();
        assertEquals(3, br.getBytesRead());
        br.close();
    }

    @Test
    void testBytesReadAsciiMatchesCharCountBulkRead() throws IOException {
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("abcdef"), StandardCharsets.UTF_8, true);
        final char[] buf = new char[6];
        assertEquals(6, br.read(buf, 0, 6));
        assertEquals(6, br.getBytesRead());
        br.close();
    }

    @Test
    void testBytesReadSupplementaryCharacterSplitAcrossReads() throws IOException {
        final String input = "😀"; // a single supplementary code point as a surrogate pair
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader(input), StandardCharsets.UTF_8, true);
        final int high = br.read();
        assertEquals(0, br.getBytesRead()); // high surrogate alone contributes no bytes yet
        final int low = br.read();
        assertEquals(input.codePointAt(0), Character.toCodePoint((char) high, (char) low));
        assertEquals(input.getBytes(StandardCharsets.UTF_8).length, br.getBytesRead());
        br.close();
    }

    @Test
    void testUnpairedLowSurrogateThrowsCharacterCodingException() throws IOException {
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("\udc00"), StandardCharsets.UTF_8, true);
        assertThrows(CharacterCodingException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                br.read();
            }
        });
        br.close();
    }

    @Test
    void testMarkSupported() throws IOException {
        final ExtendedBufferedReader br = create("abc");
        assertTrue(br.markSupported());
        br.close();
    }

    @Test
    void testReadLineDoesNotLoseCharactersAcrossRepeatedCalls() throws IOException {
        final ExtendedBufferedReader br = create("one\ntwo\nthree");
        assertEquals("one", br.readLine());
        assertEquals("two", br.readLine());
        assertEquals("three", br.readLine());
        assertNull(br.readLine());
        assertEquals(EOF, br.read());
        br.close();
    }
}
