/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.concurrent;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.Test;

/**
 * Test class for {@code EventCountCircuitBreaker}.
 */
class EventCountCircuitBreakerAgentTest {

    /**
     * A subclass that allows controlling the clock used by the circuit breaker so that tests
     * do not depend on real time passing.
     */
    private static final class MutableTimeCircuitBreaker extends EventCountCircuitBreaker {

        private long currentTime;

        MutableTimeCircuitBreaker(final int openingThreshold, final long openingInterval, final TimeUnit openingUnit,
                final int closingThreshold, final long closingInterval, final TimeUnit closingUnit) {
            super(openingThreshold, openingInterval, openingUnit, closingThreshold, closingInterval, closingUnit);
            currentTime = 0;
        }

        @Override
        long nanoTime() {
            return currentTime;
        }

        void advance(final long nanos) {
            currentTime += nanos;
        }
    }

    private static final class RecordingListener implements PropertyChangeListener {

        private final List<PropertyChangeEvent> events = new ArrayList<PropertyChangeEvent>();

        @Override
        public void propertyChange(final PropertyChangeEvent evt) {
            events.add(evt);
        }
    }

    @Test
    void testInitialStateIsClosed() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(5, 1, TimeUnit.MINUTES);
        assertTrue(breaker.isClosed(), "Breaker should start closed");
        assertFalse(breaker.isOpen(), "Breaker should not start open");
        assertTrue(breaker.checkState(), "checkState() should return true when closed");
    }

    @Test
    void testGetters() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(10, 2, TimeUnit.SECONDS, 3, 4, TimeUnit.SECONDS);
        assertEquals(10, breaker.getOpeningThreshold());
        assertEquals(TimeUnit.SECONDS.toNanos(2), breaker.getOpeningInterval());
        assertEquals(3, breaker.getClosingThreshold());
        assertEquals(TimeUnit.SECONDS.toNanos(4), breaker.getClosingInterval());
    }

    @Test
    void testTwoArgConstructorUsesSameThresholdForClosing() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(7, 1, TimeUnit.SECONDS);
        assertEquals(7, breaker.getOpeningThreshold());
        assertEquals(7, breaker.getClosingThreshold());
        assertEquals(TimeUnit.SECONDS.toNanos(1), breaker.getOpeningInterval());
        assertEquals(TimeUnit.SECONDS.toNanos(1), breaker.getClosingInterval());
    }

    @Test
    void testFourArgConstructorUsesSameIntervalForOpeningAndClosing() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(7, 1, TimeUnit.SECONDS, 2);
        assertEquals(7, breaker.getOpeningThreshold());
        assertEquals(2, breaker.getClosingThreshold());
        assertEquals(TimeUnit.SECONDS.toNanos(1), breaker.getOpeningInterval());
        assertEquals(TimeUnit.SECONDS.toNanos(1), breaker.getClosingInterval());
    }

    @Test
    void testIncrementAndCheckStateDoesNotOpenBelowThreshold() {
        final MutableTimeCircuitBreaker breaker = new MutableTimeCircuitBreaker(5, 1, TimeUnit.MINUTES, 5, 1, TimeUnit.MINUTES);
        assertTrue(breaker.incrementAndCheckState(5));
        assertTrue(breaker.isClosed());
    }

    @Test
    void testIncrementAndCheckStateOpensAboveThreshold() {
        final MutableTimeCircuitBreaker breaker = new MutableTimeCircuitBreaker(5, 1, TimeUnit.MINUTES, 5, 1, TimeUnit.MINUTES);
        assertFalse(breaker.incrementAndCheckState(6));
        assertTrue(breaker.isOpen());
        assertFalse(breaker.checkState(), "checkState() should report false while open");
    }

    @Test
    void testIncrementAndCheckStateDefaultIncrementOfOne() {
        final MutableTimeCircuitBreaker breaker = new MutableTimeCircuitBreaker(1, 1, TimeUnit.MINUTES, 1, 1, TimeUnit.MINUTES);
        assertTrue(breaker.incrementAndCheckState());
        assertFalse(breaker.incrementAndCheckState());
        assertTrue(breaker.isOpen());
    }

    @Test
    void testNegativeIncrementIsRejected() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(5, 1, TimeUnit.MINUTES);
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() throws Throwable {
                        breaker.incrementAndCheckState(-1);
                    }
                });
        assertTrue(ex.getMessage().contains("-1"));
        assertTrue(breaker.isClosed(), "A rejected increment must not change the state");
    }

    @Test
    void testCircuitClosesAgainBelowClosingThresholdAfterInterval() {
        final MutableTimeCircuitBreaker breaker = new MutableTimeCircuitBreaker(2, 1, TimeUnit.NANOSECONDS, 2, 1, TimeUnit.NANOSECONDS);
        assertFalse(breaker.incrementAndCheckState(3));
        assertTrue(breaker.isOpen());

        // Move past the end of the current (opening) check interval so that the next call
        // starts a fresh interval; fewer events than the closing threshold are reported in it.
        breaker.advance(10);
        assertTrue(breaker.incrementAndCheckState(1));

        // A second interval with still-low event count triggers the actual close transition.
        breaker.advance(10);
        assertTrue(breaker.incrementAndCheckState(1));
        assertTrue(breaker.isClosed());
    }

    @Test
    void testCircuitStaysOpenWhenEventsRemainAboveClosingThreshold() {
        final MutableTimeCircuitBreaker breaker = new MutableTimeCircuitBreaker(2, 1, TimeUnit.NANOSECONDS, 2, 100, TimeUnit.NANOSECONDS);
        assertFalse(breaker.incrementAndCheckState(3));
        assertTrue(breaker.isOpen());

        // Accumulate enough events within the still-running closing interval.
        assertFalse(breaker.incrementAndCheckState(5));
        assertTrue(breaker.isOpen());

        // Once the closing interval elapses, the accumulated count (5) is still at or above the
        // closing threshold (2), so the breaker must remain open instead of closing.
        breaker.advance(200);
        assertFalse(breaker.incrementAndCheckState(1));
        assertTrue(breaker.isOpen(), "Breaker should remain open while events stay above the closing threshold");
    }

    @Test
    void testManualOpenAndCloseResetCheckInterval() {
        final MutableTimeCircuitBreaker breaker = new MutableTimeCircuitBreaker(5, 1, TimeUnit.MINUTES, 5, 1, TimeUnit.MINUTES);
        breaker.open();
        assertTrue(breaker.isOpen());
        breaker.close();
        assertTrue(breaker.isClosed());
        // After an explicit close, the internal counter starts fresh so the same increments
        // that caused the open earlier do not immediately reopen it in a new interval.
        assertTrue(breaker.incrementAndCheckState(5));
    }

    @Test
    void testManualOpenWhileAlreadyOpenHasNoSideEffectOnState() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(5, 1, TimeUnit.MINUTES);
        breaker.open();
        assertTrue(breaker.isOpen());
        breaker.open();
        assertTrue(breaker.isOpen());
    }

    @Test
    void testChangeListenerNotifiedOnOpenAndClose() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(5, 1, TimeUnit.MINUTES);
        final RecordingListener listener = new RecordingListener();
        breaker.addChangeListener(listener);

        breaker.open();
        assertEquals(1, listener.events.size());
        assertEquals(Boolean.FALSE, listener.events.get(0).getOldValue());
        assertEquals(Boolean.TRUE, listener.events.get(0).getNewValue());

        breaker.close();
        assertEquals(2, listener.events.size());
        assertEquals(Boolean.TRUE, listener.events.get(1).getOldValue());
        assertEquals(Boolean.FALSE, listener.events.get(1).getNewValue());
    }

    @Test
    void testChangeListenerNotNotifiedWhenStateDoesNotActuallyChange() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(5, 1, TimeUnit.MINUTES);
        final RecordingListener listener = new RecordingListener();
        breaker.addChangeListener(listener);

        // Already closed; closing again must not fire a change event.
        breaker.close();
        assertTrue(listener.events.isEmpty());
    }

    @Test
    void testRemoveChangeListenerStopsNotifications() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(5, 1, TimeUnit.MINUTES);
        final RecordingListener listener = new RecordingListener();
        breaker.addChangeListener(listener);
        breaker.removeChangeListener(listener);

        breaker.open();
        assertTrue(listener.events.isEmpty(), "Removed listener must not receive further events");
    }

    @Test
    void testNullChangeListenerIsSilentlyIgnored() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(5, 1, TimeUnit.MINUTES);
        breaker.addChangeListener(null);
        // Must not throw when triggering a state change afterwards.
        breaker.open();
        assertTrue(breaker.isOpen());
    }

    @Test
    void testEventCountSaturatesAtLongMaxValueInsteadOfWrappingNegative() {
        final MutableTimeCircuitBreaker breaker = new MutableTimeCircuitBreaker(Integer.MAX_VALUE, 1, TimeUnit.DAYS, Integer.MAX_VALUE, 1,
                TimeUnit.DAYS);
        assertTrue(breaker.incrementAndCheckState(Integer.MAX_VALUE));
        assertFalse(breaker.incrementAndCheckState(Integer.MAX_VALUE), "Large cumulative increments must eventually exceed the opening threshold");
        assertTrue(breaker.isOpen());
    }

    @Test
    void testZeroIncrementDoesNotChangeEventCountOrState() {
        final MutableTimeCircuitBreaker breaker = new MutableTimeCircuitBreaker(5, 1, TimeUnit.MINUTES, 5, 1, TimeUnit.MINUTES);
        assertTrue(breaker.incrementAndCheckState(0));
        assertTrue(breaker.isClosed());
        assertTrue(breaker.incrementAndCheckState(5));
        assertTrue(breaker.isClosed());
        assertFalse(breaker.incrementAndCheckState(1));
        assertTrue(breaker.isOpen());
    }

}
