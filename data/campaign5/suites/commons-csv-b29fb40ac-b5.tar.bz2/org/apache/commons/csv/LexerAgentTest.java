/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.apache.commons.io.IOUtils.EOF;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;

import org.junit.jupiter.api.Test;

/**
 * Test {@link Lexer}.
 */
class LexerAgentTest {

    private static Lexer createLexer(final CSVFormat format, final String input) {
        return new Lexer(format, new ExtendedBufferedReader(new StringReader(input)));
    }

    @Test
    void testSimpleTokensWithDelimiterAndEorecordAndEof() throws IOException {
        final CSVFormat format = CSVFormat.Builder.create().setDelimiter(',').setIgnoreEmptyLines(false).get();
        final Lexer lexer = createLexer(format, "a,b,c\r\n");
        Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a", token.content.toString());

        token.reset();
        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("b", token.content.toString());

        token.reset();
        lexer.nextToken(token);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("c", token.content.toString());
        assertEquals("\r\n", lexer.getFirstEol());

        token.reset();
        lexer.nextToken(token);
        assertEquals(Token.Type.EOF, token.type);
        assertFalse(token.isReady);
        lexer.close();
    }

    @Test
    void testEmptyInputYieldsEofImmediately() throws IOException {
        final CSVFormat format = CSVFormat.Builder.create().get();
        final Lexer lexer = createLexer(format, "");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.EOF, token.type);
        assertFalse(token.isReady);
        assertEquals(0, token.content.length());
        lexer.close();
    }

    @Test
    void testQuotedTokenWithDoubledQuoteEscaping() throws IOException {
        final CSVFormat format = CSVFormat.Builder.create().setDelimiter(',').setQuote('"').get();
        final Lexer lexer = createLexer(format, "\"he said \"\"hi\"\"\"\r\n");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("he said \"hi\"", token.content.toString());
        assertTrue(token.isQuoted);
        lexer.close();
    }

    @Test
    void testEscapeCharacterEscapesDelimiterInSimpleToken() throws IOException {
        final CSVFormat format = CSVFormat.Builder.create().setDelimiter(',').setEscape('\\').get();
        final Lexer lexer = createLexer(format, "a\\,b,c\r\n");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a,b", token.content.toString());

        token.reset();
        lexer.nextToken(token);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("c", token.content.toString());
        lexer.close();
    }

    @Test
    void testReadEscapeStandardSequences() throws IOException {
        final CSVFormat format = CSVFormat.Builder.create().setEscape('\\').setQuote('"').get();

        assertEquals(Constants.CR, createLexer(format, "r").readEscape());
        assertEquals(Constants.LF, createLexer(format, "n").readEscape());
        assertEquals(Constants.TAB, createLexer(format, "t").readEscape());
        assertEquals(Constants.BACKSPACE, createLexer(format, "b").readEscape());
        assertEquals(Constants.FF, createLexer(format, "f").readEscape());
        // Literal control char after escape is passed through unchanged.
        assertEquals(Constants.CR, createLexer(format, "\r").readEscape());
        assertEquals(Constants.LF, createLexer(format, "\n").readEscape());
        // Meta character (the quote char here) is passed through.
        assertEquals('"', createLexer(format, "\"").readEscape());
    }

    @Test
    void testReadEscapeUnexpectedCharacterReturnsEof() throws IOException {
        final CSVFormat format = CSVFormat.Builder.create().setEscape('\\').setQuote('"').get();
        final Lexer lexer = createLexer(format, "x");
        assertEquals(EOF, lexer.readEscape());
    }

    @Test
    void testReadEscapeAtEndOfStreamThrows() throws IOException {
        final CSVFormat format = CSVFormat.Builder.create().setEscape('\\').get();
        final Lexer lexer = createLexer(format, "");
        final CSVException thrown = assertThrows(CSVException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                lexer.readEscape();
            }
        });
        assertTrue(thrown.getMessage().contains("EOF while processing escape sequence"));
    }

    @Test
    void testCommentLineIsTrimmedAndTyped() throws IOException {
        final CSVFormat format = CSVFormat.Builder.create().setDelimiter(',').setCommentMarker('#').setIgnoreEmptyLines(false).get();
        final Lexer lexer = createLexer(format, "# a comment \nvalue\n");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.COMMENT, token.type);
        assertEquals("a comment", token.content.toString());

        token.reset();
        lexer.nextToken(token);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("value", token.content.toString());

        token.reset();
        lexer.nextToken(token);
        assertEquals(Token.Type.EOF, token.type);
        assertFalse(token.isReady);
        lexer.close();
    }

    @Test
    void testIgnoreEmptyLinesSkipsLeadingBlankLines() throws IOException {
        final CSVFormat format = CSVFormat.Builder.create().setDelimiter(',').setIgnoreEmptyLines(true).get();
        final Lexer lexer = createLexer(format, "\n\na\n");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("a", token.content.toString());

        token.reset();
        lexer.nextToken(token);
        assertEquals(Token.Type.EOF, token.type);
        lexer.close();
    }

    @Test
    void testIgnoreEmptyLinesAllBlankReachesEofWithinLoop() throws IOException {
        final CSVFormat format = CSVFormat.Builder.create().setDelimiter(',').setIgnoreEmptyLines(true).get();
        final Lexer lexer = createLexer(format, "\n\n");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.EOF, token.type);
        assertFalse(token.isReady);
        assertEquals(0, token.content.length());
        lexer.close();
    }

    @Test
    void testIgnoreSurroundingSpacesTrimsLeadingAndTrailingSpaces() throws IOException {
        final CSVFormat format = CSVFormat.Builder.create().setDelimiter(',').setIgnoreSurroundingSpaces(true).setIgnoreEmptyLines(false).get();
        final Lexer lexer = createLexer(format, "  hello  , world \r\n");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("hello", token.content.toString());

        token.reset();
        lexer.nextToken(token);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("world", token.content.toString());
        assertEquals("\r\n", lexer.getFirstEol());
        lexer.close();
    }

    @Test
    void testEncapsulatedTokenWithTrailingCharacterThrowsWhenTrailingDataDisabled() throws IOException {
        final CSVFormat format = CSVFormat.Builder.create().setDelimiter(',').setQuote('"').setTrailingData(false).get();
        final Lexer lexer = createLexer(format, "\"abc\"xyz,\n");
        final Token token = new Token();
        final CSVException thrown = assertThrows(CSVException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                lexer.nextToken(token);
            }
        });
        assertTrue(thrown.getMessage().contains("Invalid character between encapsulated token and delimiter"));
        lexer.close();
    }

    @Test
    void testEncapsulatedTokenWithTrailingDataEnabledAppendsCharacters() throws IOException {
        final CSVFormat format = CSVFormat.Builder.create().setDelimiter(',').setQuote('"').setTrailingData(true).get();
        final Lexer lexer = createLexer(format, "\"abc\"xyz,\n");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("abcxyz", token.content.toString());
        lexer.close();
    }

    @Test
    void testEncapsulatedTokenEofBeforeClosingQuoteThrowsWhenNotLenient() throws IOException {
        final CSVFormat format = CSVFormat.Builder.create().setDelimiter(',').setQuote('"').setLenientEof(false).get();
        final Lexer lexer = createLexer(format, "\"abc");
        final Token token = new Token();
        final CSVException thrown = assertThrows(CSVException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                lexer.nextToken(token);
            }
        });
        assertTrue(thrown.getMessage().contains("EOF reached before encapsulated token finished"));
        lexer.close();
    }

    @Test
    void testEncapsulatedTokenEofBeforeClosingQuoteLenient() throws IOException {
        final CSVFormat format = CSVFormat.Builder.create().setDelimiter(',').setQuote('"').setLenientEof(true).get();
        final Lexer lexer = createLexer(format, "\"abc");
        final Token token = new Token();
        lexer.nextToken(token);
        assertEquals(Token.Type.EOF, token.type);
        assertTrue(token.isReady);
        assertEquals("abc", token.content.toString());
        lexer.close();
    }

    @Test
    void testIsDelimiterMultiCharMatchConsumesBuffer() throws IOException {
        final CSVFormat format = CSVFormat.Builder.create().setDelimiter("::").get();
        final Lexer lexer = createLexer(format, "::abc");
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("::abc"));
        final Lexer lexer2 = new Lexer(format, reader);
        final int first = reader.read();
        assertEquals(':', first);
        assertTrue(lexer2.isDelimiter(first));
        // The rest of the multi-char delimiter has been consumed, leaving "abc".
        assertEquals('a', reader.read());
        lexer2.close();
        lexer.close();
    }

    @Test
    void testIsDelimiterMultiCharNoMatchDoesNotConsume() throws IOException {
        final CSVFormat format = CSVFormat.Builder.create().setDelimiter("::").get();
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader(":x"));
        final Lexer lexer = new Lexer(format, reader);
        final int first = reader.read();
        assertEquals(':', first);
        assertFalse(lexer.isDelimiter(first));
        // Peek does not consume, so the 'x' is still available.
        assertEquals('x', reader.read());
        lexer.close();
    }

    @Test
    void testIsDelimiterDifferentFirstCharReturnsFalse() throws IOException {
        final CSVFormat format = CSVFormat.Builder.create().setDelimiter(',').get();
        final Lexer lexer = createLexer(format, "x");
        assertFalse(lexer.isDelimiter('a'));
        lexer.close();
    }

    @Test
    void testIsEscapeDelimiterMatchesMultiCharEscapedSequence() throws IOException {
        final CSVFormat format = CSVFormat.Builder.create().setDelimiter("[|]").setEscape('!').get();
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("![!|!]XYZ"));
        final Lexer lexer = new Lexer(format, reader);
        // Consume the leading escape char, as the real caller (appendNextEscapedCharacterToToken) does.
        assertEquals('!', reader.read());
        assertTrue(lexer.isEscapeDelimiter());
        assertEquals('X', reader.read());
        lexer.close();
    }

    @Test
    void testIsEscapeDelimiterNoMatchReturnsFalse() throws IOException {
        final CSVFormat format = CSVFormat.Builder.create().setDelimiter("[|]").setEscape('!').get();
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("!ZZZZZrest"));
        final Lexer lexer = new Lexer(format, reader);
        assertEquals('!', reader.read());
        assertFalse(lexer.isEscapeDelimiter());
        lexer.close();
    }

    @Test
    void testReadEndOfLineHandlesCrLfLfAndCr() throws IOException {
        final CSVFormat format = CSVFormat.Builder.create().get();

        final Lexer crlfLexer = createLexer(format, "\r\nrest");
        final ExtendedBufferedReader crlfReader = new ExtendedBufferedReader(new StringReader("\r\nrest"));
        final Lexer crlfLexer2 = new Lexer(format, crlfReader);
        final int crChar = crlfReader.read();
        assertTrue(crlfLexer2.readEndOfLine(crChar));
        assertEquals(Constants.CRLF, crlfLexer2.getFirstEol());
        assertEquals('r', crlfReader.read());
        crlfLexer2.close();
        crlfLexer.close();

        final ExtendedBufferedReader lfReader = new ExtendedBufferedReader(new StringReader("\nrest"));
        final Lexer lfLexer = new Lexer(format, lfReader);
        assertTrue(lfLexer.readEndOfLine(lfReader.read()));
        assertEquals("\n", lfLexer.getFirstEol());
        lfLexer.close();

        final ExtendedBufferedReader crReader = new ExtendedBufferedReader(new StringReader("\rrest"));
        final Lexer crLexer = new Lexer(format, crReader);
        assertTrue(crLexer.readEndOfLine(crReader.read()));
        assertEquals("\r", crLexer.getFirstEol());
        crLexer.close();
    }

    @Test
    void testReadEndOfLineReturnsFalseForNonEolAndFirstEolStaysNull() throws IOException {
        final CSVFormat format = CSVFormat.Builder.create().get();
        final Lexer lexer = createLexer(format, "a");
        assertNull(lexer.getFirstEol());
        assertFalse(lexer.readEndOfLine('a'));
        assertNull(lexer.getFirstEol());
        lexer.close();
    }

    @Test
    void testSimplePredicateMethods() throws IOException {
        final CSVFormat format = CSVFormat.Builder.create().setQuote('\'').setEscape('\\').setCommentMarker('#').get();
        final Lexer lexer = createLexer(format, "data");

        assertTrue(lexer.isQuoteChar('\''));
        assertFalse(lexer.isQuoteChar('"'));

        assertTrue(lexer.isEscape('\\'));
        assertFalse(lexer.isEscape('x'));

        assertTrue(lexer.isCommentStart('#'));
        assertFalse(lexer.isCommentStart('%'));

        assertTrue(lexer.isEndOfFile(EOF));
        assertFalse(lexer.isEndOfFile('a'));

        assertTrue(lexer.isStartOfLine(Constants.LF));
        assertTrue(lexer.isStartOfLine(Constants.CR));
        assertTrue(lexer.isStartOfLine(Constants.UNDEFINED));
        assertFalse(lexer.isStartOfLine('a'));

        lexer.close();
    }

    @Test
    void testDisabledMetaCharactersNeverMatch() throws IOException {
        final CSVFormat format = CSVFormat.Builder.create().get();
        final Lexer lexer = createLexer(format, "data");
        // No quote, escape, or comment marker configured: default format disables quote? No - DEFAULT has a quote.
        assertFalse(lexer.isEscape('\\'));
        assertFalse(lexer.isCommentStart('#'));
        lexer.close();
    }

    @Test
    void testPositionLineNumberAndBytesReadTracking() throws IOException {
        final CSVFormat format = CSVFormat.Builder.create().setDelimiter(',').setIgnoreEmptyLines(false).get();
        final Lexer lexer = createLexer(format, "ab,cd\nef\n");
        final Token token = new Token();

        assertEquals(0, lexer.getCharacterPosition());
        assertEquals(0, lexer.getBytesRead());

        lexer.nextToken(token); // "ab"
        assertEquals(Token.Type.TOKEN, token.type);
        assertTrue(lexer.getCharacterPosition() > 0);
        // No charset/byte tracking was configured, so bytes read is never updated.
        assertEquals(0, lexer.getBytesRead());

        token.reset();
        lexer.nextToken(token); // "cd" EORECORD
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals(1, lexer.getCurrentLineNumber());

        token.reset();
        lexer.nextToken(token); // "ef" EORECORD
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals(2, lexer.getCurrentLineNumber());

        lexer.close();
    }

    @Test
    void testCloseMarksReaderClosedAndSubsequentReadFails() throws IOException {
        final CSVFormat format = CSVFormat.Builder.create().get();
        final Lexer lexer = createLexer(format, "a,b\n");
        assertFalse(lexer.isClosed());
        lexer.close();
        assertTrue(lexer.isClosed());
        final Token token = new Token();
        assertThrows(IOException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                lexer.nextToken(token);
            }
        });
    }

    @Test
    void testTrimTrailingSpacesRemovesOnlyTrailingWhitespace() {
        final CSVFormat format = CSVFormat.Builder.create().get();
        Lexer lexer;
        try {
            lexer = createLexer(format, "");
        } catch (final Exception e) {
            throw new AssertionError(e);
        }

        final StringBuilder sb = new StringBuilder(" a b  \t ");
        lexer.trimTrailingSpaces(sb);
        assertEquals(" a b", sb.toString());

        final StringBuilder noTrailing = new StringBuilder("abc");
        lexer.trimTrailingSpaces(noTrailing);
        assertEquals("abc", noTrailing.toString());

        final StringBuilder allSpaces = new StringBuilder("   ");
        lexer.trimTrailingSpaces(allSpaces);
        assertEquals(0, allSpaces.length());
    }
}
