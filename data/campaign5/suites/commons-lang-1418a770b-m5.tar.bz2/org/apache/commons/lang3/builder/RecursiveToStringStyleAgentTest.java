/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.builder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

import org.apache.commons.lang3.mutable.MutableBoolean;
import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link RecursiveToStringStyle}.
 */
class RecursiveToStringStyleAgentTest {

    static class Job {
        String title;

        Job(final String title) {
            this.title = title;
        }
    }

    static class Person {
        String name;
        int age;
        boolean smoker;
        Job job;
    }

    private static String classPrefix(final Object object) {
        return object.getClass().getName() + "@" + Integer.toHexString(System.identityHashCode(object));
    }

    private static String toString(final Object object) {
        return new ReflectionToStringBuilder(object, new RecursiveToStringStyle()).toString();
    }

    // --- accept(Class) boundary tests ---

    @Test
    void acceptRejectsPrimitiveWrapperClasses() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        assertFalse(style.accept(Integer.class));
        assertFalse(style.accept(Boolean.class));
        assertFalse(style.accept(Byte.class));
        assertFalse(style.accept(Character.class));
        assertFalse(style.accept(Short.class));
        assertFalse(style.accept(Long.class));
        assertFalse(style.accept(Double.class));
        assertFalse(style.accept(Float.class));
    }

    @Test
    void acceptRejectsString() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        assertFalse(style.accept(String.class));
    }

    @Test
    void acceptRejectsNumberSubclassesThatAreNotWrappers() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        assertFalse(style.accept(BigInteger.class));
        assertFalse(style.accept(BigDecimal.class));
    }

    @Test
    void acceptRejectsAtomicBooleanAndMutableBoolean() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        assertFalse(style.accept(AtomicBoolean.class));
        assertFalse(style.accept(MutableBoolean.class));
    }

    @Test
    void acceptAllowsCustomClass() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        assertTrue(style.accept(Person.class));
        assertTrue(style.accept(Job.class));
    }

    @Test
    void acceptAllowsPrimitiveTypeItself() {
        // int.class is neither a wrapper class nor a Number subclass, so it is accepted.
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        assertTrue(style.accept(int.class));
        assertTrue(style.accept(boolean.class));
    }

    // --- appendDetail(StringBuffer, String, Object) tests ---

    @Test
    void appendDetailWithNullValueDelegatesToSuperAppend() {
        // Called directly (bypassing ToStringStyle.append's null interception), the null value
        // falls through accept()'s null-safety check to the inherited behavior: StringBuffer#append(Object).
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "field", (Object) null);
        assertEquals("null", buffer.toString());
    }

    @Test
    void appendDetailWithStringAppendsRawValue() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "field", "hello");
        assertEquals("hello", buffer.toString());
    }

    @Test
    void appendDetailWithBoxedPrimitiveAppendsRawValue() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "field", Integer.valueOf(42));
        assertEquals("42", buffer.toString());
    }

    @Test
    void appendDetailWithAtomicBooleanAppendsRawValue() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        final AtomicBoolean value = new AtomicBoolean(true);
        style.appendDetail(buffer, "field", value);
        assertEquals(value.toString(), buffer.toString());
    }

    @Test
    void appendDetailWithMutableBooleanAppendsRawValue() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        final MutableBoolean value = new MutableBoolean(true);
        style.appendDetail(buffer, "field", value);
        assertEquals(value.toString(), buffer.toString());
    }

    @Test
    void appendDetailWithCustomObjectRecursesIntoFields() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        final Job job = new Job("Manager");
        style.appendDetail(buffer, "field", job);
        final String expected = classPrefix(job) + "[title=Manager]";
        assertEquals(expected, buffer.toString());
    }

    // --- appendDetail(StringBuffer, String, Collection) tests ---

    @Test
    void appendDetailWithEmptyCollection() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        final List<Job> jobs = new ArrayList<>();
        style.appendDetail(buffer, "field", jobs);
        final String expected = classPrefix(jobs) + "{}";
        assertEquals(expected, buffer.toString());
    }

    @Test
    void appendDetailWithCollectionOfCustomObjectsRecurses() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        final Job job1 = new Job("Manager");
        final Job job2 = new Job("Director");
        final List<Job> jobs = new ArrayList<>();
        jobs.add(job1);
        jobs.add(job2);
        style.appendDetail(buffer, "field", jobs);
        final String expected = classPrefix(jobs) + "{"
                + classPrefix(job1) + "[title=Manager],"
                + classPrefix(job2) + "[title=Director]"
                + "}";
        assertEquals(expected, buffer.toString());
    }

    // --- full ReflectionToStringBuilder integration (happy path + nested null) ---

    @Test
    void reflectionToStringBuilderProducesRecursiveSingleLineOutput() {
        final Person person = new Person();
        person.name = "Stephen";
        person.age = 29;
        person.smoker = false;
        person.job = new Job("Manager");
        final String expected = classPrefix(person) + "[age=29,job="
                + classPrefix(person.job) + "[title=Manager],name=Stephen,smoker=false]";
        assertEquals(expected, toString(person));
    }

    @Test
    void reflectionToStringBuilderHandlesNullNestedField() {
        final Person person = new Person();
        person.name = "Douglas";
        person.age = 42;
        person.smoker = true;
        person.job = null;
        final String expected = classPrefix(person) + "[age=42,job=<null>,name=Douglas,smoker=true]";
        assertEquals(expected, toString(person));
    }
}
