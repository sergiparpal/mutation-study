/*
  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      https://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
 */

package org.apache.commons.cli.help;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.apache.commons.cli.help.TextStyle.Alignment;
import org.apache.commons.cli.help.TextStyle.Builder;
import org.junit.jupiter.api.Test;

class TextStyleAgentTest {

    @Test
    void testBuilderDefaultValues() {
        final Builder builder = TextStyle.builder();
        assertEquals(Alignment.LEFT, TextStyle.builder().get().getAlignment());
        assertEquals(0, builder.getLeftPad());
        assertEquals(0, builder.getIndent());
        assertTrue(builder.isScalable());
        assertEquals(0, builder.getMinWidth());
        assertEquals(TextStyle.UNSET_MAX_WIDTH, builder.getMaxWidth());
    }

    @Test
    void testDefaultTextStyleMatchesDefaultBuilder() {
        final TextStyle style = TextStyle.DEFAULT;
        assertEquals(Alignment.LEFT, style.getAlignment());
        assertEquals(0, style.getLeftPad());
        assertEquals(0, style.getIndent());
        assertTrue(style.isScalable());
        assertEquals(0, style.getMinWidth());
        assertEquals(TextStyle.UNSET_MAX_WIDTH, style.getMaxWidth());
    }

    @Test
    void testUnsetMaxWidthIsIntegerMaxValue() {
        assertEquals(Integer.MAX_VALUE, TextStyle.UNSET_MAX_WIDTH);
    }

    @Test
    void testBuilderSettersReturnSameInstanceAndSetValues() {
        final Builder builder = TextStyle.builder();
        assertSame(builder, builder.setAlignment(Alignment.RIGHT));
        assertSame(builder, builder.setLeftPad(3));
        assertSame(builder, builder.setIndent(4));
        assertSame(builder, builder.setScalable(false));
        assertSame(builder, builder.setMinWidth(5));
        assertSame(builder, builder.setMaxWidth(20));

        assertEquals(Alignment.RIGHT, builder.get().getAlignment());
        assertEquals(3, builder.getLeftPad());
        assertEquals(4, builder.getIndent());
        assertFalse(builder.isScalable());
        assertEquals(5, builder.getMinWidth());
        assertEquals(20, builder.getMaxWidth());
    }

    @Test
    void testBuilderGetCreatesTextStyleWithConfiguredValues() {
        final TextStyle style = TextStyle.builder().setAlignment(Alignment.CENTER).setLeftPad(2).setIndent(3).setScalable(false).setMinWidth(1)
                .setMaxWidth(10).get();
        assertEquals(Alignment.CENTER, style.getAlignment());
        assertEquals(2, style.getLeftPad());
        assertEquals(3, style.getIndent());
        assertFalse(style.isScalable());
        assertEquals(1, style.getMinWidth());
        assertEquals(10, style.getMaxWidth());
    }

    @Test
    void testBuilderMutationAfterGetDoesNotAffectPreviousInstance() {
        final Builder builder = TextStyle.builder().setMaxWidth(10);
        final TextStyle first = builder.get();
        builder.setMaxWidth(50);
        final TextStyle second = builder.get();

        assertEquals(10, first.getMaxWidth());
        assertEquals(50, second.getMaxWidth());
    }

    @Test
    void testSetTextStyleCopiesAllFields() {
        final TextStyle source = TextStyle.builder().setAlignment(Alignment.RIGHT).setLeftPad(7).setIndent(8).setScalable(false).setMinWidth(9)
                .setMaxWidth(99).get();

        final Builder target = TextStyle.builder();
        assertSame(target, target.setTextStyle(source));

        assertEquals(Alignment.RIGHT, target.get().getAlignment());
        assertEquals(7, target.getLeftPad());
        assertEquals(8, target.getIndent());
        assertFalse(target.isScalable());
        assertEquals(9, target.getMinWidth());
        assertEquals(99, target.getMaxWidth());
    }

    @Test
    void testPadReturnsUnchangedTextWhenLengthEqualsMaxWidth() {
        final TextStyle style = TextStyle.builder().setMaxWidth(5).get();
        final CharSequence text = "abcde";
        assertSame(text, style.pad(false, text));
    }

    @Test
    void testPadReturnsUnchangedTextWhenLengthExceedsMaxWidth() {
        final TextStyle style = TextStyle.builder().setMaxWidth(3).get();
        final CharSequence text = "abcdef";
        assertSame(text, style.pad(true, text));
    }

    @Test
    void testPadLeftAlignmentUnsetMaxWidthWithoutIndent() {
        final TextStyle style = TextStyle.builder().setAlignment(Alignment.LEFT).setIndent(4).get();
        assertEquals("abc", style.pad(false, "abc").toString());
    }

    @Test
    void testPadLeftAlignmentUnsetMaxWidthWithIndent() {
        final TextStyle style = TextStyle.builder().setAlignment(Alignment.LEFT).setIndent(4).get();
        assertEquals("    abc", style.pad(true, "abc").toString());
    }

    @Test
    void testPadRightAlignmentUnsetMaxWidthWithIndent() {
        final TextStyle style = TextStyle.builder().setAlignment(Alignment.RIGHT).setIndent(2).get();
        assertEquals("  abc", style.pad(true, "abc").toString());
    }

    @Test
    void testPadLeftAlignmentWithMaxWidthAndIndentFits() {
        final TextStyle style = TextStyle.builder().setAlignment(Alignment.LEFT).setMaxWidth(10).setIndent(2).get();
        final String result = style.pad(true, "ab").toString();
        assertEquals("  ab      ", result);
        assertEquals(10, result.length());
    }

    @Test
    void testPadLeftAlignmentWithMaxWidthAndIndentDoesNotFit() {
        final TextStyle style = TextStyle.builder().setAlignment(Alignment.LEFT).setMaxWidth(3).setIndent(2).get();
        final String result = style.pad(true, "ab").toString();
        assertEquals("ab ", result);
        assertEquals(3, result.length());
    }

    @Test
    void testPadLeftAlignmentWithMaxWidthNoIndentRequested() {
        final TextStyle style = TextStyle.builder().setAlignment(Alignment.LEFT).setMaxWidth(6).setIndent(2).get();
        final String result = style.pad(false, "ab").toString();
        assertEquals("ab    ", result);
        assertEquals(6, result.length());
    }

    @Test
    void testPadRightAlignmentWithMaxWidth() {
        final TextStyle style = TextStyle.builder().setAlignment(Alignment.RIGHT).setMaxWidth(6).get();
        final String result = style.pad(false, "ab").toString();
        assertEquals("    ab", result);
        assertEquals(6, result.length());
    }

    @Test
    void testPadCenterAlignmentUnsetMaxWidthWithIndent() {
        final TextStyle style = TextStyle.builder().setAlignment(Alignment.CENTER).setIndent(4).get();
        assertEquals("  abc  ", style.pad(true, "abc").toString());
    }

    @Test
    void testPadCenterAlignmentUnsetMaxWidthWithoutIndent() {
        final TextStyle style = TextStyle.builder().setAlignment(Alignment.CENTER).setIndent(4).get();
        assertEquals("abc", style.pad(false, "abc").toString());
    }

    @Test
    void testPadCenterAlignmentWithMaxWidthEvenPadding() {
        final TextStyle style = TextStyle.builder().setAlignment(Alignment.CENTER).setMaxWidth(10).get();
        final String result = style.pad(false, "ab").toString();
        assertEquals("    ab    ", result);
        assertEquals(10, result.length());
    }

    @Test
    void testPadCenterAlignmentWithMaxWidthOddPadding() {
        final TextStyle style = TextStyle.builder().setAlignment(Alignment.CENTER).setMaxWidth(11).get();
        final String result = style.pad(false, "ab").toString();
        assertEquals(11, result.length());
        assertEquals("    ab     ", result);
    }

    @Test
    void testPadWithNonStringCharSequence() {
        final TextStyle style = TextStyle.builder().setAlignment(Alignment.LEFT).setMaxWidth(6).get();
        final StringBuilder input = new StringBuilder("ab");
        final String result = style.pad(false, input).toString();
        assertEquals("ab    ", result);
    }

    @Test
    void testPadWithEmptyText() {
        final TextStyle style = TextStyle.builder().setAlignment(Alignment.LEFT).setMaxWidth(4).get();
        final String result = style.pad(false, "").toString();
        assertEquals("    ", result);
        assertEquals(4, result.length());
    }

    @Test
    void testToStringWithUnsetMaxWidth() {
        final TextStyle style = TextStyle.builder().setAlignment(Alignment.LEFT).setLeftPad(1).setIndent(2).setScalable(true).setMinWidth(3).get();
        assertEquals("TextStyle{LEFT, l:1, i:2, true, min:3, max:unset}", style.toString());
    }

    @Test
    void testToStringWithExplicitMaxWidth() {
        final TextStyle style = TextStyle.builder().setAlignment(Alignment.RIGHT).setLeftPad(1).setIndent(2).setScalable(false).setMinWidth(3)
                .setMaxWidth(40).get();
        assertEquals("TextStyle{RIGHT, l:1, i:2, false, min:3, max:40}", style.toString());
    }

    @Test
    void testAlignmentEnumValues() {
        final Alignment[] values = Alignment.values();
        assertEquals(3, values.length);
        assertEquals(Alignment.LEFT, Alignment.valueOf("LEFT"));
        assertEquals(Alignment.CENTER, Alignment.valueOf("CENTER"));
        assertEquals(Alignment.RIGHT, Alignment.valueOf("RIGHT"));
    }
}
