/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.function.FailableConsumer;
import org.apache.commons.lang3.function.FailableRunnable;
import org.junit.jupiter.api.Test;

/**
 * Tests {@link DurationUtils}.
 */
class DurationUtilsAgentTest {

    @Test
    void testAcceptNullConsumerIsNoop() throws Exception {
        // Must not throw even though the consumer is null.
        DurationUtils.accept(null, Duration.ofMillis(1234));
    }

    @Test
    void testAcceptNullDurationIsNoop() throws Exception {
        final List<Object> calls = new ArrayList<Object>();
        DurationUtils.accept(new org.apache.commons.lang3.function.FailableBiConsumer<Long, Integer, Exception>() {
            @Override
            public void accept(final Long millis, final Integer nanos) {
                calls.add(millis);
            }
        }, null);
        assertTrue(calls.isEmpty());
    }

    @Test
    void testAcceptSplitsMillisAndNanos() throws Exception {
        final Duration duration = Duration.ofSeconds(1, 1_500_000); // 1s + 1.5ms in nanos
        final List<Long> millisHolder = new ArrayList<Long>();
        final List<Integer> nanosHolder = new ArrayList<Integer>();
        DurationUtils.accept(new org.apache.commons.lang3.function.FailableBiConsumer<Long, Integer, Exception>() {
            @Override
            public void accept(final Long millis, final Integer nanos) {
                millisHolder.add(millis);
                nanosHolder.add(nanos);
            }
        }, duration);
        assertEquals(1, millisHolder.size());
        assertEquals(duration.toMillis(), millisHolder.get(0).longValue());
        assertEquals(DurationUtils.getNanosOfMilli(duration), nanosHolder.get(0).intValue());
    }

    @Test
    void testGetDefaultWhenKeyEmpty() {
        final Duration result = DurationUtils.get("", ChronoUnit.SECONDS, 42L);
        assertEquals(Duration.ofSeconds(42), result);
    }

    @Test
    void testGetDefaultWhenPropertyMissing() {
        final String key = "org.apache.commons.lang3.time.DurationUtilsAgentTest.missing." + System.nanoTime();
        final Duration result = DurationUtils.get(key, ChronoUnit.MINUTES, 7L);
        assertEquals(Duration.ofMinutes(7), result);
    }

    @Test
    void testGetMillisDefault() {
        final String key = "org.apache.commons.lang3.time.DurationUtilsAgentTest.millis." + System.nanoTime();
        assertEquals(Duration.ofMillis(123), DurationUtils.getMillis(key, 123L));
    }

    @Test
    void testGetNanosOfMiiliDeprecatedDelegates() {
        final Duration duration = Duration.ofSeconds(5, 999_999);
        assertEquals(DurationUtils.getNanosOfMilli(duration), DurationUtils.getNanosOfMiili(duration));
    }

    @Test
    void testGetNanosOfMilliBoundary() {
        assertEquals(0, DurationUtils.getNanosOfMilli(Duration.ofSeconds(1, 1_000_000)));
        assertEquals(999_999, DurationUtils.getNanosOfMilli(Duration.ofSeconds(1, 1_999_999)));
    }

    @Test
    void testGetNanosOfMilliOnNull() {
        assertEquals(0, DurationUtils.getNanosOfMilli(null));
    }

    @Test
    void testGetSecondsDefault() {
        final String key = "org.apache.commons.lang3.time.DurationUtilsAgentTest.seconds." + System.nanoTime();
        assertEquals(Duration.ofSeconds(99), DurationUtils.getSeconds(key, 99L));
    }

    @Test
    void testIsPositive() {
        assertTrue(DurationUtils.isPositive(Duration.ofNanos(1)));
        assertFalse(DurationUtils.isPositive(Duration.ZERO));
        assertFalse(DurationUtils.isPositive(Duration.ofSeconds(-1)));
    }

    @Test
    void testOfConsumerReturnsNonNegativeDuration() throws Exception {
        final Duration duration = DurationUtils.of(new FailableConsumer<Instant, Exception>() {
            @Override
            public void accept(final Instant start) {
                assertNotNull(start);
            }
        });
        assertFalse(duration.isNegative());
    }

    @Test
    void testOfConsumerPropagatesException() {
        final RuntimeException expected = new RuntimeException("boom");
        final RuntimeException thrown = assertThrows(RuntimeException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                DurationUtils.of(new FailableConsumer<Instant, RuntimeException>() {
                    @Override
                    public void accept(final Instant start) {
                        throw expected;
                    }
                });
            }
        });
        assertEquals(expected, thrown);
    }

    @Test
    void testOfRunnableReturnsNonNegativeDuration() throws Exception {
        final Duration duration = DurationUtils.of(new FailableRunnable<Exception>() {
            @Override
            public void run() {
                // no-op
            }
        });
        assertFalse(duration.isNegative());
    }

    @Test
    void testOfRunnablePropagatesException() {
        final IllegalStateException expected = new IllegalStateException("fail");
        final IllegalStateException thrown = assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                DurationUtils.of(new FailableRunnable<IllegalStateException>() {
                    @Override
                    public void run() {
                        throw expected;
                    }
                });
            }
        });
        assertEquals(expected, thrown);
    }

    @Test
    void testSinceReturnsNonNegativeDuration() {
        final Instant start = Instant.now().minusSeconds(1);
        final Duration duration = DurationUtils.since(start);
        assertFalse(duration.isNegative());
        assertTrue(duration.getSeconds() >= 1);
    }

    @Test
    void testToDurationAllUnits() {
        assertEquals(Duration.ofNanos(5), DurationUtils.toDuration(5, TimeUnit.NANOSECONDS));
        assertEquals(Duration.ofNanos(5000), DurationUtils.toDuration(5, TimeUnit.MICROSECONDS));
        assertEquals(Duration.ofMillis(5), DurationUtils.toDuration(5, TimeUnit.MILLISECONDS));
        assertEquals(Duration.ofSeconds(5), DurationUtils.toDuration(5, TimeUnit.SECONDS));
        assertEquals(Duration.ofMinutes(5), DurationUtils.toDuration(5, TimeUnit.MINUTES));
        assertEquals(Duration.ofHours(5), DurationUtils.toDuration(5, TimeUnit.HOURS));
        assertEquals(Duration.ofDays(5), DurationUtils.toDuration(5, TimeUnit.DAYS));
    }

    @Test
    void testToDurationNullTimeUnitThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationUtils.toDuration(1, null);
            }
        });
    }

    @Test
    void testToMillisIntNormalValue() {
        assertEquals(1000, DurationUtils.toMillisInt(Duration.ofSeconds(1)));
    }

    @Test
    void testToMillisIntClampsAboveIntRange() {
        // Valid millis but greater than Integer.MAX_VALUE, no ArithmeticException expected.
        assertEquals(Integer.MAX_VALUE, DurationUtils.toMillisInt(Duration.ofSeconds(Integer.MAX_VALUE)));
    }

    @Test
    void testToMillisIntClampsBelowIntRange() {
        assertEquals(Integer.MIN_VALUE, DurationUtils.toMillisInt(Duration.ofSeconds(-((long) Integer.MAX_VALUE))));
    }

    @Test
    void testToMillisIntClampsToMaxValueOnOverflow() {
        // Duration.toMillis() overflows (ArithmeticException) for seconds this large.
        final Duration huge = Duration.ofSeconds(Long.MAX_VALUE);
        assertEquals(Integer.MAX_VALUE, DurationUtils.toMillisInt(huge));
    }

    @Test
    void testToMillisIntClampsToMinValueOnOverflow() {
        final Duration huge = Duration.ofSeconds(Long.MIN_VALUE);
        assertEquals(Integer.MIN_VALUE, DurationUtils.toMillisInt(huge));
    }

    @Test
    void testToMillisIntNullThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationUtils.toMillisInt(null);
            }
        });
    }

    @Test
    void testZeroIfNullWithNull() {
        assertEquals(Duration.ZERO, DurationUtils.zeroIfNull(null));
    }

    @Test
    void testZeroIfNullWithNonNull() {
        final Duration duration = Duration.ofSeconds(42);
        assertEquals(duration, DurationUtils.zeroIfNull(duration));
    }

    @Test
    void testConstructorDoesNotThrow() {
        assertNotNull(new DurationUtils());
    }
}
