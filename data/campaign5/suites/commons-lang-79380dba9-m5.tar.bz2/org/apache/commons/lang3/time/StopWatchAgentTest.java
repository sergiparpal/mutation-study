/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests {@link StopWatch}.
 */
class StopWatchAgentTest {

    @Test
    void testCreateUnstarted() {
        final StopWatch watch = StopWatch.create();
        assertFalse(watch.isStarted());
        assertTrue(watch.isStopped());
        assertFalse(watch.isSuspended());
        assertEquals(0, watch.getTime());
        assertEquals(0, watch.getNanoTime());
    }

    @Test
    void testCreateStarted() {
        final StopWatch watch = StopWatch.createStarted();
        assertTrue(watch.isStarted());
        assertFalse(watch.isStopped());
        assertFalse(watch.isSuspended());
    }

    @Test
    void testMessageConstructor() {
        final StopWatch watch = new StopWatch("hello");
        assertEquals("hello", watch.getMessage());
        final StopWatch noMessage = new StopWatch();
        assertNull(noMessage.getMessage());
    }

    @Test
    void testStartTwiceThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.start();
            }
        });
    }

    @Test
    void testStartAfterStopWithoutResetThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.start();
            }
        });
    }

    @Test
    void testStartAfterResetSucceeds() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        watch.reset();
        watch.start(); // must not throw
        assertTrue(watch.isStarted());
    }

    @Test
    void testStopWithoutStartThrows() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.stop();
            }
        });
    }

    @Test
    void testStopThenGetTimeStable() throws InterruptedException {
        final StopWatch watch = new StopWatch();
        watch.start();
        Thread.sleep(5);
        watch.stop();
        final long time1 = watch.getTime();
        Thread.sleep(5);
        final long time2 = watch.getTime();
        assertEquals(time1, time2);
        assertTrue(watch.isStopped());
        assertFalse(watch.isStarted());
    }

    @Test
    void testSuspendResume() throws InterruptedException {
        final StopWatch watch = new StopWatch();
        watch.start();
        Thread.sleep(5);
        watch.suspend();
        assertTrue(watch.isSuspended());
        assertTrue(watch.isStarted());
        final long suspendedTime = watch.getTime();
        Thread.sleep(10);
        assertEquals(suspendedTime, watch.getTime());
        watch.resume();
        assertFalse(watch.isSuspended());
        watch.stop();
        assertTrue(watch.getTime() >= suspendedTime);
    }

    @Test
    void testSuspendWithoutStartThrows() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.suspend();
            }
        });
    }

    @Test
    void testSuspendTwiceThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.suspend();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.suspend();
            }
        });
    }

    @Test
    void testResumeWithoutSuspendThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.resume();
            }
        });
    }

    @Test
    void testResumeOnUnstartedThrows() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.resume();
            }
        });
    }

    @Test
    void testSplitAndUnsplit() throws InterruptedException {
        final StopWatch watch = new StopWatch();
        watch.start();
        Thread.sleep(5);
        watch.split();
        final long splitTime = watch.getSplitTime();
        assertTrue(splitTime >= 0);
        assertEquals(1, watch.getSplits().size());
        watch.unsplit();
        assertEquals(0, watch.getSplits().size());
        // Watch keeps running after unsplit.
        assertTrue(watch.isStarted());
    }

    @Test
    void testSplitWithLabel() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split("first");
        final List<StopWatch.Split> splits = watch.getSplits();
        assertEquals(1, splits.size());
        assertEquals("first", splits.get(0).getLabel());
        assertEquals(splits.get(0).getDuration(), watch.getSplitDuration());
    }

    @Test
    void testSplitsAccumulate() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split("a");
        watch.split("b");
        watch.split("c");
        assertEquals(3, watch.getSplits().size());
        assertEquals("a", watch.getSplits().get(0).getLabel());
        assertEquals("b", watch.getSplits().get(1).getLabel());
        assertEquals("c", watch.getSplits().get(2).getLabel());
    }

    @Test
    void testGetSplitsIsUnmodifiable() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        final List<StopWatch.Split> splits = watch.getSplits();
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                splits.clear();
            }
        });
    }

    @Test
    void testSplitWithoutStartThrows() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.split();
            }
        });
    }

    @Test
    void testUnsplitWithoutSplitThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.unsplit();
            }
        });
    }

    @Test
    void testGetSplitNanoTimeWithoutSplitThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.getSplitNanoTime();
            }
        });
    }

    @Test
    void testGetStartInstantWithoutStartThrows() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.getStartInstant();
            }
        });
    }

    @Test
    void testGetStopInstantWithoutStartThrows() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.getStopInstant();
            }
        });
    }

    @Test
    void testGetStopTimeBeforeStopIsZero() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertEquals(0L, watch.getStopTime());
    }

    @Test
    void testGetStartAndStopTimesAfterStop() throws InterruptedException {
        final StopWatch watch = new StopWatch();
        watch.start();
        Thread.sleep(5);
        watch.stop();
        assertTrue(watch.getStartInstant().isBefore(watch.getStopInstant()) || watch.getStartInstant().equals(watch.getStopInstant()));
        assertEquals(watch.getStartInstant().toEpochMilli(), watch.getStartTime());
        assertEquals(watch.getStopInstant().toEpochMilli(), watch.getStopTime());
    }

    @Test
    void testGetDurationMatchesGetTime() throws InterruptedException {
        final StopWatch watch = new StopWatch();
        watch.start();
        Thread.sleep(5);
        watch.stop();
        assertEquals(watch.getTime(), watch.getDuration().toMillis());
    }

    @Test
    void testGetTimeWithUnitConversion() throws InterruptedException {
        final StopWatch watch = new StopWatch();
        watch.start();
        Thread.sleep(5);
        watch.stop();
        final long nanos = watch.getNanoTime();
        assertEquals(TimeUnit.NANOSECONDS.toMillis(nanos), watch.getTime(TimeUnit.MILLISECONDS));
        assertEquals(TimeUnit.NANOSECONDS.toSeconds(nanos), watch.getTime(TimeUnit.SECONDS));
    }

    @Test
    void testReset() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        watch.stop();
        watch.reset();
        assertFalse(watch.isStarted());
        assertTrue(watch.isStopped());
        assertFalse(watch.isSuspended());
        assertEquals(0, watch.getSplits().size());
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                watch.getSplitNanoTime();
            }
        });
    }

    @Test
    void testToStringZeroElapsed() {
        final StopWatch watch = StopWatch.create();
        assertEquals("00:00:00.000", watch.toString());
    }

    @Test
    void testToStringWithMessagePrefix() {
        final StopWatch watch = new StopWatch("Baking cookies");
        assertEquals("Baking cookies 00:00:00.000", watch.toString());
    }

    @Test
    void testToSplitStringWithMessagePrefix() {
        final StopWatch watch = new StopWatch("Baking cookies");
        watch.start();
        watch.split();
        assertTrue(watch.toSplitString().startsWith("Baking cookies "));
    }

    @Test
    void testFormatSplitTimeMatchesPattern() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        assertEquals("00:00:00.000".length(), watch.formatSplitTime().length());
    }

    @Test
    void testRunRecordsTimeAndResumesState() {
        final StopWatch watch = new StopWatch();
        final boolean[] ran = new boolean[1];
        watch.run(new Runnable() {
            @Override
            public void run() {
                ran[0] = true;
            }
        });
        assertTrue(ran[0]);
        assertTrue(watch.isSuspended());
        assertTrue(watch.getTime() >= 0);
    }

    @Test
    void testGetSupplierReturnsValue() {
        final StopWatch watch = new StopWatch();
        final String result = watch.get(new Supplier<String>() {
            @Override
            public String get() {
                return "value";
            }
        });
        assertEquals("value", result);
        assertTrue(watch.isSuspended());
    }

    @Test
    void testRunTPropagatesCheckedException() {
        final StopWatch watch = new StopWatch();
        final Exception expected = new Exception("checked");
        final Throwable thrown = assertThrows(Exception.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                watch.runT(new org.apache.commons.lang3.function.FailableRunnable<Exception>() {
                    @Override
                    public void run() throws Exception {
                        throw expected;
                    }
                });
            }
        });
        assertSame(expected, thrown);
        assertTrue(watch.isSuspended());
    }

    @Test
    void testGetTPropagatesCheckedExceptionAndReturnsOnSuccess() throws Throwable {
        final StopWatch watch = new StopWatch();
        final Integer value = watch.getT(new org.apache.commons.lang3.function.FailableSupplier<Integer, Exception>() {
            @Override
            public Integer get() {
                return 7;
            }
        });
        assertEquals(Integer.valueOf(7), value);
        assertTrue(watch.isSuspended());
    }

    @Test
    void testSplitLabelDefaultsToIndex() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        assertEquals("0", watch.getSplits().get(0).getLabel());
    }

    @Test
    void testSplitToString() {
        final StopWatch.Split split = new StopWatch.Split("label", java.time.Duration.ofSeconds(1));
        assertEquals("Split [label, PT1S])", split.toString());
        assertEquals("label", split.getLabel());
        assertEquals(java.time.Duration.ofSeconds(1), split.getDuration());
    }
}
