/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link ExtendedMessageFormat}.
 */
@SuppressWarnings("deprecation")
class ExtendedMessageFormatAgentTest {

    /**
     * Simple format factory that always returns the same upper-casing format, ignoring arguments.
     */
    private static final class UpperFormatFactory implements FormatFactory {
        private static final UpperFormat INSTANCE = new UpperFormat();

        @Override
        public Format getFormat(final String name, final String arguments, final Locale locale) {
            // Return a shared instance so that formats compare equal across ExtendedMessageFormat instances.
            return INSTANCE;
        }
    }

    /**
     * Format that upper-cases the String representation of the value.
     */
    private static final class UpperFormat extends Format {
        private static final long serialVersionUID = 1L;

        @Override
        public StringBuffer format(final Object obj, final StringBuffer toAppendTo, final java.text.FieldPosition pos) {
            return toAppendTo.append(String.valueOf(obj).toUpperCase(Locale.ROOT));
        }

        @Override
        public Object parseObject(final String source, final java.text.ParsePosition pos) {
            return null;
        }
    }

    private Map<String, FormatFactory> upperRegistry() {
        final Map<String, FormatFactory> registry = new HashMap<>();
        registry.put("upper", new UpperFormatFactory());
        return registry;
    }

    @Test
    void testBasicPatternNoRegistry() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello, {0}!");
        assertEquals("Hello, World!", emf.format(new Object[] {"World"}));
        assertEquals("Hello, {0}!", emf.toPattern());
    }

    @Test
    void testCustomFormatRegistry() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("Name: {0,upper}", upperRegistry());
        assertEquals("Name: ABC", emf.format(new Object[] {"abc"}));
        assertEquals("Name: {0,upper}", emf.toPattern());
    }

    @Test
    void testCustomFormatWithStyle() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper,ignored-style}", upperRegistry());
        assertEquals("ABC", emf.format(new Object[] {"abc"}));
        assertEquals("{0,upper,ignored-style}", emf.toPattern());
    }

    @Test
    void testUnknownFormatNameFallsBackToStandardAndThrows() {
        // "unknown" is not in our registry, so it is passed through to the base
        // MessageFormat parser, which rejects it as an unrecognized built-in format type.
        final Map<String, FormatFactory> registry = upperRegistry();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{0,unknown}", registry);
            }
        });
    }

    @Test
    void testNullRegistryUsesStandardMessageFormat() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number}", (Map<String, FormatFactory>) null);
        assertEquals("3", emf.format(new Object[] {3}));
    }

    @Test
    void testConstructorWithLocale() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", Locale.US);
        assertEquals(Locale.US, emf.getLocale());
        assertEquals("value", emf.format(new Object[] {"value"}));
    }

    @Test
    void testConstructorWithLocaleAndRegistry() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", Locale.US, upperRegistry());
        assertEquals("ABC", emf.format(new Object[] {"abc"}));
        assertEquals(Locale.US, emf.getLocale());
    }

    @Test
    void testApplyPatternNullRegistryDelegatesToSuper() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("start", (Map<String, FormatFactory>) null);
        emf.applyPattern("{0}-{1}");
        assertEquals("a-b", emf.format(new Object[] {"a", "b"}));
        assertEquals("{0}-{1}", emf.toPattern());
    }

    @Test
    void testQuotedTextIsLiteral() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("it''s {0,upper} time", upperRegistry());
        assertEquals("it's ABC time", emf.format(new Object[] {"abc"}));
        assertTrue(emf.toPattern().contains("it''s"));
    }

    @Test
    void testUnmatchedQuoteTreatedAsClosedAtEnd() {
        // An unmatched single quote is treated as closed at the end of the pattern, same as MessageFormat.
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("abc'def", (Map<String, FormatFactory>) null);
        assertEquals("abcdef", emf.format(new Object[] {}));
    }

    @Test
    void testUnterminatedFormatElementThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{0,upper", upperRegistry());
            }
        });
    }

    @Test
    void testInvalidArgumentIndexThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{x}", upperRegistry());
            }
        });
    }

    @Test
    void testSetFormatThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormat(0, new SimpleDateFormat());
            }
        });
    }

    @Test
    void testSetFormatByArgumentIndexThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormatByArgumentIndex(0, new SimpleDateFormat());
            }
        });
    }

    @Test
    void testSetFormatsThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormats(new Format[] {new SimpleDateFormat()});
            }
        });
    }

    @Test
    void testSetFormatsByArgumentIndexThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormatsByArgumentIndex(new Format[] {new SimpleDateFormat()});
            }
        });
    }

    @Test
    void testEqualsAndHashCodeSamePatternAndRegistry() {
        final Map<String, FormatFactory> registry = upperRegistry();
        final ExtendedMessageFormat emf1 = new ExtendedMessageFormat("{0,upper}", registry);
        final ExtendedMessageFormat emf2 = new ExtendedMessageFormat("{0,upper}", registry);
        assertEquals(emf1, emf2);
        assertEquals(emf1.hashCode(), emf2.hashCode());
    }

    @Test
    void testEqualsDifferentPattern() {
        final ExtendedMessageFormat emf1 = new ExtendedMessageFormat("{0}");
        final ExtendedMessageFormat emf2 = new ExtendedMessageFormat("{0}{1}");
        assertNotEquals(emf1, emf2);
    }

    @Test
    void testEqualsDifferentType() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertFalse(emf.equals("not an ExtendedMessageFormat"));
        assertFalse(emf.equals(null));
    }

    @Test
    void testEqualsSameInstance() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertTrue(emf.equals(emf));
    }

    @Test
    void testEmptyPattern() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("");
        assertEquals("", emf.format(new Object[] {}));
        assertEquals("", emf.toPattern());
    }

    @Test
    void testMissingClosingBraceThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{0", (Map<String, FormatFactory>) null);
            }
        });
    }

    @Test
    void testMultipleArgumentsWithMixedRegisteredAndUnregisteredFormats() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper} and {1}", upperRegistry());
        assertEquals("ABC and def", emf.format(new Object[] {"abc", "def"}));
        assertEquals("{0,upper} and {1}", emf.toPattern());
    }

    @Test
    void testRepeatedArgumentIndex() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}-{0}", (Map<String, FormatFactory>) null);
        assertEquals("x-x", emf.format(new Object[] {"x"}));
    }
}
