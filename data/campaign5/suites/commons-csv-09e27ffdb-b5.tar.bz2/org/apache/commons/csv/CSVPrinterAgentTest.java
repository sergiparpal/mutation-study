/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.Closeable;
import java.io.Flushable;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link CSVPrinter}.
 */
class CSVPrinterAgentTest {

    /**
     * An Appendable that is also Closeable and Flushable so that close()/flush() behavior can be observed.
     */
    private static final class TrackingAppendable implements Appendable, Closeable, Flushable {

        private final StringBuilder sb = new StringBuilder();
        private boolean closed;
        private int flushCount;

        @Override
        public Appendable append(final char c) throws IOException {
            sb.append(c);
            return this;
        }

        @Override
        public Appendable append(final CharSequence csq) throws IOException {
            sb.append(csq);
            return this;
        }

        @Override
        public Appendable append(final CharSequence csq, final int start, final int end) throws IOException {
            sb.append(csq, start, end);
            return this;
        }

        @Override
        public void close() throws IOException {
            closed = true;
        }

        @Override
        public void flush() throws IOException {
            flushCount++;
        }

        int getFlushCount() {
            return flushCount;
        }

        boolean isClosed() {
            return closed;
        }

        @Override
        public String toString() {
            return sb.toString();
        }
    }

    private Connection newH2Connection() throws SQLException {
        return DriverManager.getConnection("jdbc:h2:mem:CSVPrinterAgentTest" + System.nanoTime());
    }

    private ResultSet newTwoRowResultSet(final Connection connection) throws SQLException {
        try (Statement statement = connection.createStatement()) {
            statement.execute("CREATE TABLE T (ID INT, NAME VARCHAR(20))");
            statement.execute("INSERT INTO T VALUES (1, 'a')");
            statement.execute("INSERT INTO T VALUES (2, 'b')");
        }
        final Statement statement = connection.createStatement();
        return statement.executeQuery("SELECT ID, NAME FROM T ORDER BY ID");
    }

    @Test
    void testConstructorNullAppendable() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new CSVPrinter(null, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    void testConstructorNullFormat() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new CSVPrinter(new StringBuilder(), null);
            }
        });
    }

    @Test
    void testConstructorPrintsHeaderComments() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').setHeaderComments("line1", "line2")
                .setHeader("a", "b").get();
        final CSVPrinter printer = new CSVPrinter(sb, format);
        printer.close();
        final String[] lines = sb.toString().split("\r\n");
        assertEquals("# line1", lines[0]);
        assertEquals("# line2", lines[1]);
        assertEquals("a,b", lines[2]);
    }

    @Test
    void testConstructorPrintsHeaderWhenNotSkipped() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("col1", "col2").get();
        final CSVPrinter printer = new CSVPrinter(sb, format);
        printer.close();
        assertEquals("col1,col2\r\n", sb.toString());
    }

    @Test
    void testConstructorSkipsHeaderWhenSkipHeaderRecordTrue() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("col1", "col2").setSkipHeaderRecord(true).get();
        final CSVPrinter printer = new CSVPrinter(sb, format);
        printer.close();
        assertEquals("", sb.toString());
    }

    @Test
    void testFlushCallsFlushableAppendable() throws IOException {
        final TrackingAppendable appendable = new TrackingAppendable();
        final CSVPrinter printer = new CSVPrinter(appendable, CSVFormat.DEFAULT);
        assertEquals(0, appendable.getFlushCount());
        printer.flush();
        assertEquals(1, appendable.getFlushCount());
        printer.flush();
        assertEquals(2, appendable.getFlushCount());
    }

    @Test
    void testFlushNoopWhenAppendableNotFlushable() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        // Must not throw, StringBuilder is not Flushable.
        printer.flush();
        assertEquals("", sb.toString());
    }

    @Test
    void testCloseDoesNotFlushWhenAutoFlushFalseAndFlushParamFalse() throws IOException {
        final TrackingAppendable appendable = new TrackingAppendable();
        final CSVPrinter printer = new CSVPrinter(appendable, CSVFormat.DEFAULT);
        printer.close(false);
        assertEquals(0, appendable.getFlushCount());
        assertTrue(appendable.isClosed());
    }

    @Test
    void testCloseFlushesWhenAutoFlushTrue() throws IOException {
        final TrackingAppendable appendable = new TrackingAppendable();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setAutoFlush(true).get();
        final CSVPrinter printer = new CSVPrinter(appendable, format);
        printer.close();
        assertEquals(1, appendable.getFlushCount());
        assertTrue(appendable.isClosed());
    }

    @Test
    void testCloseFlushesWhenFlushParamTrueRegardlessOfAutoFlush() throws IOException {
        final TrackingAppendable appendable = new TrackingAppendable();
        final CSVPrinter printer = new CSVPrinter(appendable, CSVFormat.DEFAULT);
        printer.close(true);
        assertEquals(1, appendable.getFlushCount());
        assertTrue(appendable.isClosed());
    }

    @Test
    void testCloseNonCloseableAppendableDoesNotThrow() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.close();
        // No exception, and no content was written because no records were printed.
        assertEquals("", sb.toString());
    }

    @Test
    void testGetOutReturnsSameInstance() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        assertTrue(printer.getOut() == sb);
    }

    @Test
    void testGetRecordCountInitiallyZero() throws IOException {
        final CSVPrinter printer = new CSVPrinter(new StringBuilder(), CSVFormat.DEFAULT);
        assertEquals(0L, printer.getRecordCount());
    }

    @Test
    void testPrintAndRecordCountUnaffectedByPrint() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("hello");
        assertEquals("hello", sb.toString());
        assertEquals(0L, printer.getRecordCount());
    }

    @Test
    void testPrintNullValue() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print(null);
        assertEquals("", sb.toString());
    }

    @Test
    void testPrintlnWritesSeparatorButDoesNotIncrementRecordCount() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.println();
        assertEquals("\r\n", sb.toString());
        assertEquals(0L, printer.getRecordCount());
    }

    @Test
    void testPrintRecordVarargsIncrementsRecordCount() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord("a", "b", "c");
        assertEquals("a,b,c\r\n", sb.toString());
        assertEquals(1L, printer.getRecordCount());
        printer.printRecord("d", "e");
        assertEquals("a,b,c\r\nd,e\r\n", sb.toString());
        assertEquals(2L, printer.getRecordCount());
    }

    @Test
    void testPrintRecordEmptyVarargsStillWritesSeparatorAndCounts() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord();
        assertEquals("\r\n", sb.toString());
        assertEquals(1L, printer.getRecordCount());
    }

    @Test
    void testPrintRecordIterable() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        final List<String> values = new ArrayList<String>();
        values.add("x");
        values.add("y");
        printer.printRecord(values);
        assertEquals("x,y\r\n", sb.toString());
        assertEquals(1L, printer.getRecordCount());
    }

    @Test
    void testPrintRecordQuotesValuesContainingDelimiter() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord("a,b", "c");
        assertEquals("\"a,b\",c\r\n", sb.toString());
    }

    @Test
    void testPrintRecordStream() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord(Stream.of("p", "q", "r"));
        assertEquals("p,q,r\r\n", sb.toString());
        assertEquals(1L, printer.getRecordCount());
    }

    @Test
    void testPrintRecordsVarargsFlat() throws IOException {
        // Each top-level simple value becomes its own record (unlike printRecord(Object...)).
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecords("a", "b", "c");
        assertEquals("a\r\nb\r\nc\r\n", sb.toString());
        assertEquals(3L, printer.getRecordCount());
    }

    @Test
    void testPrintRecordsVarargsNestedArrays() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecords((Object) new String[] { "A", "B" }, (Object) new String[] { "1", "2" });
        assertEquals("A,B\r\n1,2\r\n", sb.toString());
        assertEquals(2L, printer.getRecordCount());
    }

    @Test
    void testPrintRecordsIterableNested() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        final List<Object> data = new ArrayList<Object>();
        data.add(Arrays.asList("A", "B", "C"));
        data.add(Arrays.asList("1", "2", "3"));
        printer.printRecords(data);
        assertEquals("A,B,C\r\n1,2,3\r\n", sb.toString());
        assertEquals(2L, printer.getRecordCount());
    }

    @Test
    void testPrintRecordsIterableFlat() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecords(Arrays.asList("x", "y"));
        assertEquals("x\r\ny\r\n", sb.toString());
        assertEquals(2L, printer.getRecordCount());
    }

    @Test
    void testPrintRecordsStream() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecords(Stream.of("x", "y", "z"));
        assertEquals("x\r\ny\r\nz\r\n", sb.toString());
        assertEquals(3L, printer.getRecordCount());
    }

    @Test
    void testPrintCommentNoopWhenCommentMarkerNotSet() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printComment("this is a comment");
        assertEquals("", sb.toString());
    }

    @Test
    void testPrintCommentNullIsNoop() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVPrinter printer = new CSVPrinter(sb, format);
        printer.printComment(null);
        assertEquals("", sb.toString());
    }

    @Test
    void testPrintCommentSingleLine() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVPrinter printer = new CSVPrinter(sb, format);
        printer.printComment("hello");
        assertEquals("# hello\r\n", sb.toString());
    }

    @Test
    void testPrintCommentMultiLineWithLf() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVPrinter printer = new CSVPrinter(sb, format);
        printer.printComment("line1\nline2");
        assertEquals("# line1\r\n# line2\r\n", sb.toString());
    }

    @Test
    void testPrintCommentMultiLineWithCrLf() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVPrinter printer = new CSVPrinter(sb, format);
        printer.printComment("line1\r\nline2");
        assertEquals("# line1\r\n# line2\r\n", sb.toString());
    }

    @Test
    void testPrintCommentStartsNewLineWhenMidRecord() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVPrinter printer = new CSVPrinter(sb, format);
        printer.print("value1");
        printer.printComment("note");
        assertEquals("value1\r\n# note\r\n", sb.toString());
    }

    @Test
    void testPrintRecordsResultSet() throws IOException, SQLException {
        final Connection connection = newH2Connection();
        try {
            final ResultSet resultSet = newTwoRowResultSet(connection);
            final StringBuilder sb = new StringBuilder();
            final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
            printer.printRecords(resultSet);
            assertEquals("1,a\r\n2,b\r\n", sb.toString());
            assertEquals(2L, printer.getRecordCount());
        } finally {
            connection.close();
        }
    }

    @Test
    void testPrintRecordsResultSetRespectsMaxRows() throws IOException, SQLException {
        final Connection connection = newH2Connection();
        try {
            final ResultSet resultSet = newTwoRowResultSet(connection);
            final StringBuilder sb = new StringBuilder();
            final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(1).get();
            final CSVPrinter printer = new CSVPrinter(sb, format);
            printer.printRecords(resultSet);
            assertEquals("1,a\r\n", sb.toString());
            assertEquals(1L, printer.getRecordCount());
        } finally {
            connection.close();
        }
    }

    @Test
    void testPrintHeadersResultSet() throws IOException, SQLException {
        final Connection connection = newH2Connection();
        try {
            final ResultSet resultSet = newTwoRowResultSet(connection);
            final StringBuilder sb = new StringBuilder();
            final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
            printer.printHeaders(resultSet);
            assertEquals("ID,NAME\r\n", sb.toString());
            // Header printing must not count as a record.
            assertEquals(0L, printer.getRecordCount());
        } finally {
            connection.close();
        }
    }

    @Test
    void testPrintRecordsResultSetWithHeaderFlagTrue() throws IOException, SQLException {
        final Connection connection = newH2Connection();
        try {
            final ResultSet resultSet = newTwoRowResultSet(connection);
            final StringBuilder sb = new StringBuilder();
            final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
            printer.printRecords(resultSet, true);
            assertEquals("ID,NAME\r\n1,a\r\n2,b\r\n", sb.toString());
            assertEquals(2L, printer.getRecordCount());
        } finally {
            connection.close();
        }
    }

    @Test
    void testPrintRecordsResultSetWithHeaderFlagFalse() throws IOException, SQLException {
        final Connection connection = newH2Connection();
        try {
            final ResultSet resultSet = newTwoRowResultSet(connection);
            final StringBuilder sb = new StringBuilder();
            final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
            printer.printRecords(resultSet, false);
            assertEquals("1,a\r\n2,b\r\n", sb.toString());
            assertEquals(2L, printer.getRecordCount());
        } finally {
            connection.close();
        }
    }

    @Test
    void testPrintRecordsResultSetEmpty() throws IOException, SQLException {
        final Connection connection = newH2Connection();
        try {
            final Statement statement = connection.createStatement();
            statement.execute("CREATE TABLE EMPTY_T (ID INT)");
            final ResultSet resultSet = statement.executeQuery("SELECT ID FROM EMPTY_T");
            final StringBuilder sb = new StringBuilder();
            final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
            printer.printRecords(resultSet);
            assertEquals("", sb.toString());
            assertEquals(0L, printer.getRecordCount());
        } finally {
            connection.close();
        }
    }

    @Test
    void testPrintRecordNullElementInArray() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord("a", null, "c");
        assertEquals("a,,c\r\n", sb.toString());
        assertFalse(sb.toString().isEmpty());
    }
}
