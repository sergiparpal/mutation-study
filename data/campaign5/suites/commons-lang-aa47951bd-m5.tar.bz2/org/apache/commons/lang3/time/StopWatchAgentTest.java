/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.function.FailableRunnable;
import org.apache.commons.lang3.function.FailableSupplier;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link StopWatch}.
 */
class StopWatchAgentTest {

    @Test
    void testCreateUnstarted() {
        final StopWatch sw = StopWatch.create();
        assertFalse(sw.isStarted());
        assertTrue(sw.isStopped());
        assertFalse(sw.isSuspended());
        assertEquals(0, sw.getTime());
        assertEquals(Duration.ZERO, sw.getDuration());
        assertNull(sw.getMessage());
        assertTrue(sw.getSplits().isEmpty());
    }

    @Test
    void testCreateStarted() {
        final StopWatch sw = StopWatch.createStarted();
        assertTrue(sw.isStarted());
        assertFalse(sw.isStopped());
        assertFalse(sw.isSuspended());
    }

    @Test
    void testMessageConstructor() {
        final StopWatch sw = new StopWatch("myLabel");
        assertEquals("myLabel", sw.getMessage());
        final StopWatch unlabeled = new StopWatch();
        assertNull(unlabeled.getMessage());
    }

    @Test
    void testStartTwiceThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.start();
            }
        });
    }

    @Test
    void testStartAfterStopWithoutResetThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.stop();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.start();
            }
        });
        sw.reset();
        sw.start();
        assertTrue(sw.isStarted());
    }

    @Test
    void testStopWithoutStartThrows() {
        final StopWatch sw = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.stop();
            }
        });
    }

    @Test
    void testStopTwiceThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.stop();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.stop();
            }
        });
    }

    @Test
    void testSuspendWithoutStartThrows() {
        final StopWatch sw = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.suspend();
            }
        });
    }

    @Test
    void testSuspendTwiceThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.suspend();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.suspend();
            }
        });
    }

    @Test
    void testResumeWithoutSuspendThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.resume();
            }
        });
    }

    @Test
    void testResumeOnUnstartedThrows() {
        final StopWatch sw = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.resume();
            }
        });
    }

    @Test
    void testSplitWithoutStartThrows() {
        final StopWatch sw = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.split();
            }
        });
    }

    @Test
    void testSplitAfterStopThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.stop();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.split();
            }
        });
    }

    @Test
    void testUnsplitWithoutSplitThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.unsplit();
            }
        });
    }

    @Test
    void testGetSplitTimeWithoutSplitThrows() {
        final StopWatch sw = new StopWatch();
        sw.start();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.getSplitNanoTime();
            }
        });
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.getSplitDuration();
            }
        });
    }

    @Test
    void testGetStartAndStopInstantUnstartedThrows() {
        final StopWatch sw = new StopWatch();
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.getStartInstant();
            }
        });
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.getStopInstant();
            }
        });
    }

    @Test
    void testGetStopInstantNullBeforeStop() {
        final StopWatch sw = new StopWatch();
        sw.start();
        assertNull(sw.getStopInstant());
        sw.stop();
        assertNotNull(sw.getStopInstant());
    }

    @Test
    void testResetClearsState() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.split();
        sw.reset();
        assertFalse(sw.isStarted());
        assertTrue(sw.isStopped());
        assertFalse(sw.isSuspended());
        assertTrue(sw.getSplits().isEmpty());
        assertEquals(0, sw.getTime());
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                sw.getSplitDuration();
            }
        });
    }

    @Test
    void testGetSplitsUnmodifiable() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.split();
        final List<StopWatch.Split> splits = sw.getSplits();
        assertEquals(1, splits.size());
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                splits.add(new StopWatch.Split("x", Duration.ZERO));
            }
        });
    }

    @Test
    void testSplitLabelsDefaultIndex() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.split();
        sw.split();
        final List<StopWatch.Split> splits = sw.getSplits();
        assertEquals(2, splits.size());
        assertEquals("0", splits.get(0).getLabel());
        assertEquals("1", splits.get(1).getLabel());
    }

    @Test
    void testSplitWithCustomLabel() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.split("first");
        assertEquals("first", sw.getSplits().get(0).getLabel());
        assertEquals(sw.getSplitDuration(), sw.getSplits().get(0).getDuration());
    }

    @Test
    void testUnsplitRemovesLastSplit() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.split();
        sw.split();
        sw.unsplit();
        assertEquals(1, sw.getSplits().size());
        assertEquals("0", sw.getSplits().get(0).getLabel());
    }

    @Test
    void testSplitDoesNotStopRunningState() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.split();
        assertTrue(sw.isStarted());
        assertFalse(sw.isStopped());
        assertFalse(sw.isSuspended());
    }

    @Test
    void testFormatTimeAndToStringNoMessage() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.stop();
        assertTrue(sw.toString().matches("\\d+:\\d{2}:\\d{2}\\.\\d{3}"), sw.toString());
        assertTrue(sw.formatTime().matches("\\d+:\\d{2}:\\d{2}\\.\\d{3}"), sw.formatTime());
    }

    @Test
    void testToStringWithMessage() {
        final StopWatch sw = new StopWatch("Label");
        sw.start();
        sw.stop();
        assertTrue(sw.toString().startsWith("Label "), sw.toString());
    }

    @Test
    void testToSplitStringWithAndWithoutMessage() {
        final StopWatch unlabeled = new StopWatch();
        unlabeled.start();
        unlabeled.split();
        assertTrue(unlabeled.toSplitString().matches("\\d+:\\d{2}:\\d{2}\\.\\d{3}"), unlabeled.toSplitString());

        final StopWatch labeled = new StopWatch("Label");
        labeled.start();
        labeled.split();
        assertTrue(labeled.toSplitString().startsWith("Label "), labeled.toSplitString());
    }

    @Test
    void testGetTimeTimeUnitConversion() throws InterruptedException {
        final StopWatch sw = new StopWatch();
        sw.start();
        Thread.sleep(20);
        sw.stop();
        final long millis = sw.getTime();
        assertEquals(millis, sw.getTime(TimeUnit.MILLISECONDS));
        assertEquals(0, sw.getTime(TimeUnit.HOURS));
        assertTrue(sw.getTime(TimeUnit.NANOSECONDS) >= millis * 1000000L);
    }

    @Test
    void testSuspendFreezesElapsedTime() throws InterruptedException {
        final StopWatch sw = new StopWatch();
        sw.start();
        Thread.sleep(20);
        sw.suspend();
        final long frozen = sw.getTime();
        Thread.sleep(40);
        assertEquals(frozen, sw.getTime());
        sw.resume();
        assertTrue(sw.isStarted());
        assertFalse(sw.isSuspended());
        sw.stop();
        assertTrue(sw.getTime() >= frozen);
    }

    @Test
    void testStopAfterSuspendKeepsSuspendedTime() throws InterruptedException {
        final StopWatch sw = new StopWatch();
        sw.start();
        Thread.sleep(10);
        sw.suspend();
        final long suspendedTime = sw.getTime();
        Thread.sleep(10);
        sw.stop();
        assertEquals(suspendedTime, sw.getTime());
    }

    @Test
    void testGetDurationMatchesGetTime() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.stop();
        assertEquals(sw.getTime(), sw.getDuration().toMillis());
    }

    @Test
    void testDeprecatedGettersMatchNonDeprecated() {
        final StopWatch sw = new StopWatch();
        sw.start();
        sw.split();
        sw.stop();
        assertEquals(sw.getSplitDuration().toMillis(), sw.getSplitTime());
        assertEquals(sw.getStartInstant().toEpochMilli(), sw.getStartTime());
        assertEquals(sw.getStopInstant().toEpochMilli(), sw.getStopTime());
    }

    @Test
    void testGetDelegatesToSupplierAndSuspends() {
        final StopWatch sw = StopWatch.create();
        final String result = sw.get(new java.util.function.Supplier<String>() {
            @Override
            public String get() {
                return "value";
            }
        });
        assertEquals("value", result);
        assertTrue(sw.isSuspended());
    }

    @Test
    void testRunDelegatesToRunnableAndSuspends() {
        final StopWatch sw = StopWatch.create();
        final boolean[] executed = {false};
        sw.run(new Runnable() {
            @Override
            public void run() {
                executed[0] = true;
            }
        });
        assertTrue(executed[0]);
        assertTrue(sw.isSuspended());
    }

    @Test
    void testGetTPropagatesExceptionAndStillSuspends() {
        final StopWatch sw = StopWatch.create();
        final IOException thrown = new IOException("boom");
        final Throwable caught = assertThrows(IOException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                sw.getT(new FailableSupplier<String, IOException>() {
                    @Override
                    public String get() throws IOException {
                        throw thrown;
                    }
                });
            }
        });
        assertEquals(thrown, caught);
        assertTrue(sw.isSuspended());
    }

    @Test
    void testRunTPropagatesExceptionAndStillSuspends() {
        final StopWatch sw = StopWatch.create();
        final IOException thrown = new IOException("boom");
        final Throwable caught = assertThrows(IOException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                sw.runT(new FailableRunnable<IOException>() {
                    @Override
                    public void run() throws IOException {
                        throw thrown;
                    }
                });
            }
        });
        assertEquals(thrown, caught);
        assertTrue(sw.isSuspended());
    }

    @Test
    void testGetAndRunResumeAfterSuspendedState() {
        final StopWatch sw = StopWatch.create();
        sw.get(new java.util.function.Supplier<Object>() {
            @Override
            public Object get() {
                return null;
            }
        });
        assertTrue(sw.isSuspended());
        final String result = sw.get(new java.util.function.Supplier<String>() {
            @Override
            public String get() {
                return "second";
            }
        });
        assertEquals("second", result);
        assertTrue(sw.isSuspended());
    }
}
