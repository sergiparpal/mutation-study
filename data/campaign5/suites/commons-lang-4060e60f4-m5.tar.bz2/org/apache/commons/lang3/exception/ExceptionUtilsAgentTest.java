/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.exception;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.lang.reflect.UndeclaredThrowableException;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

import org.junit.jupiter.api.Test;

/**
 * Tests for {@link ExceptionUtils}.
 */
class ExceptionUtilsAgentTest {

    /**
     * Throwable whose getCause() is settable to form a cycle, bypassing the
     * normal initCause() self-causation restriction.
     */
    private static class CyclicThrowable extends Throwable {
        private static final long serialVersionUID = 1L;
        private transient Throwable other;

        void setOther(final Throwable other) {
            this.other = other;
        }

        @Override
        public synchronized Throwable getCause() {
            return other;
        }
    }

    /**
     * Exception exposing a legacy wrapped-exception accessor method, but with
     * no real (constructor/initCause) cause set.
     */
    private static class CustomTargetException extends Exception {
        private static final long serialVersionUID = 1L;
        private final transient Throwable target;

        CustomTargetException(final String message, final Throwable target) {
            super(message);
            this.target = target;
        }

        public Throwable getTargetException() {
            return target;
        }
    }

    private Exception newRoot() {
        return new IOException("rootMsg");
    }

    private Exception newMid(final Throwable cause) {
        return new IllegalArgumentException("midMsg", cause);
    }

    private RuntimeException newTop(final Throwable cause) {
        return new RuntimeException("topMsg", cause);
    }

    @Test
    void testAsRuntimeException() {
        final IOException cause = new IOException("boom");
        Throwable caught = null;
        try {
            throw ExceptionUtils.<RuntimeException>asRuntimeException(cause);
        } catch (final Throwable t) {
            caught = t;
        }
        assertSame(cause, caught);
    }

    @Test
    void testForEach() {
        final Exception root = newRoot();
        final Exception mid = newMid(root);
        final RuntimeException top = newTop(mid);
        final List<Throwable> seen = new ArrayList<>();
        ExceptionUtils.forEach(top, new Consumer<Throwable>() {
            @Override
            public void accept(final Throwable t) {
                seen.add(t);
            }
        });
        assertEquals(3, seen.size());
        assertSame(top, seen.get(0));
        assertSame(mid, seen.get(1));
        assertSame(root, seen.get(2));
    }

    @Test
    void testForEachNull() {
        final List<Throwable> seen = new ArrayList<>();
        ExceptionUtils.forEach(null, new Consumer<Throwable>() {
            @Override
            public void accept(final Throwable t) {
                seen.add(t);
            }
        });
        assertTrue(seen.isEmpty());
    }

    @Test
    void testGetCauseNull() {
        assertNull(ExceptionUtils.getCause(null));
    }

    @Test
    void testGetCauseRealCause() {
        final IOException cause = new IOException("c");
        final Exception wrapper = new Exception("w", cause);
        assertSame(cause, ExceptionUtils.getCause(wrapper));
    }

    @Test
    void testGetCauseByDefaultMethodNames() {
        final IOException target = new IOException("target");
        final CustomTargetException custom = new CustomTargetException("outer", target);
        assertNull(custom.getCause());
        assertSame(target, ExceptionUtils.getCause(custom));
    }

    @Test
    void testGetCauseByExplicitMethodNames() {
        final IOException target = new IOException("target");
        final CustomTargetException custom = new CustomTargetException("outer", target);
        final String[] names = {"getTargetException"};
        assertSame(target, ExceptionUtils.getCause(custom, names));
    }

    @Test
    void testGetCauseNoMatch() {
        final RuntimeException plain = new RuntimeException("plain");
        assertNull(ExceptionUtils.getCause(plain, new String[] {"noSuchMethod"}));
    }

    @Test
    void testGetDefaultCauseMethodNames() {
        final String[] names = ExceptionUtils.getDefaultCauseMethodNames();
        assertTrue(names.length > 0);
        boolean foundGetCause = false;
        boolean foundTarget = false;
        for (final String name : names) {
            if ("getCause".equals(name)) {
                foundGetCause = true;
            }
            if ("getTargetException".equals(name)) {
                foundTarget = true;
            }
        }
        assertTrue(foundGetCause);
        assertTrue(foundTarget);

        // mutating the returned clone must not affect subsequent calls
        names[0] = "mutated";
        final String[] namesAgain = ExceptionUtils.getDefaultCauseMethodNames();
        assertEquals("getCause", namesAgain[0]);
    }

    @Test
    void testGetMessageNull() {
        assertEquals("", ExceptionUtils.getMessage(null));
    }

    @Test
    void testGetMessage() {
        final Exception e = new IllegalStateException("bad state");
        assertEquals("IllegalStateException: bad state", ExceptionUtils.getMessage(e));
    }

    @Test
    void testGetRootCauseNull() {
        assertNull(ExceptionUtils.getRootCause(null));
    }

    @Test
    void testGetRootCauseChain() {
        final Exception root = newRoot();
        final Exception mid = newMid(root);
        final RuntimeException top = newTop(mid);
        assertSame(root, ExceptionUtils.getRootCause(top));
    }

    @Test
    void testGetRootCauseCyclic() {
        final CyclicThrowable a = new CyclicThrowable();
        final CyclicThrowable b = new CyclicThrowable();
        a.setOther(b);
        b.setOther(a);
        assertSame(b, ExceptionUtils.getRootCause(a));
    }

    @Test
    void testGetRootCauseMessageNull() {
        assertEquals("", ExceptionUtils.getRootCauseMessage(null));
    }

    @Test
    void testGetRootCauseMessage() {
        final Exception root = newRoot();
        final Exception mid = newMid(root);
        final RuntimeException top = newTop(mid);
        assertEquals("IOException: rootMsg", ExceptionUtils.getRootCauseMessage(top));
    }

    @Test
    void testGetRootCauseStackTraceNull() {
        assertEquals(0, ExceptionUtils.getRootCauseStackTrace(null).length);
        assertTrue(ExceptionUtils.getRootCauseStackTraceList(null).isEmpty());
    }

    @Test
    void testGetRootCauseStackTraceChain() {
        final Exception root = newRoot();
        final Exception mid = newMid(root);
        final RuntimeException top = newTop(mid);
        final List<String> frames = ExceptionUtils.getRootCauseStackTraceList(top);
        assertFalse(frames.isEmpty());
        assertEquals(root.toString(), frames.get(0));
        assertTrue(frames.contains(ExceptionUtils.WRAPPED_MARKER + mid.toString()));
        assertTrue(frames.contains(ExceptionUtils.WRAPPED_MARKER + top.toString()));

        final String[] asArray = ExceptionUtils.getRootCauseStackTrace(top);
        assertArrayEquals(frames.toArray(new String[0]), asArray);
    }

    @Test
    void testGetStackFrameList() {
        final Exception e = new Exception("x");
        final List<String> frames = ExceptionUtils.getStackFrameList(e);
        assertFalse(frames.isEmpty());
        for (final String frame : frames) {
            assertTrue(frame.trim().startsWith("at "), frame);
        }
    }

    @Test
    void testGetStackFramesString() {
        final String text = "line1" + System.lineSeparator() + "line2";
        final String[] lines = ExceptionUtils.getStackFrames(text);
        assertEquals(2, lines.length);
        assertEquals("line1", lines[0]);
        assertEquals("line2", lines[1]);
    }

    @Test
    void testGetStackFramesThrowableNull() {
        assertEquals(0, ExceptionUtils.getStackFrames((Throwable) null).length);
    }

    @Test
    void testGetStackFramesThrowable() {
        final Exception e = new Exception("y");
        final String[] frames = ExceptionUtils.getStackFrames(e);
        assertTrue(frames.length > 1);
        assertEquals(e.toString(), frames[0]);
    }

    @Test
    void testGetStackTraceNull() {
        assertEquals("", ExceptionUtils.getStackTrace(null));
    }

    @Test
    void testGetStackTrace() {
        final Exception e = new Exception("z");
        final String trace = ExceptionUtils.getStackTrace(e);
        assertTrue(trace.contains("z"));
        assertTrue(trace.contains("Exception"));
    }

    @Test
    void testGetThrowableCountNull() {
        assertEquals(0, ExceptionUtils.getThrowableCount(null));
    }

    @Test
    void testGetThrowableCountChain() {
        final Exception root = newRoot();
        final Exception mid = newMid(root);
        final RuntimeException top = newTop(mid);
        assertEquals(3, ExceptionUtils.getThrowableCount(top));
    }

    @Test
    void testGetThrowableCountCyclic() {
        final CyclicThrowable a = new CyclicThrowable();
        final CyclicThrowable b = new CyclicThrowable();
        a.setOther(b);
        b.setOther(a);
        assertEquals(2, ExceptionUtils.getThrowableCount(a));
    }

    @Test
    void testGetThrowableListAndArray() {
        final Exception root = newRoot();
        final Exception mid = newMid(root);
        final RuntimeException top = newTop(mid);
        final List<Throwable> list = ExceptionUtils.getThrowableList(top);
        assertEquals(3, list.size());
        assertSame(top, list.get(0));
        assertSame(mid, list.get(1));
        assertSame(root, list.get(2));

        final Throwable[] array = ExceptionUtils.getThrowables(top);
        assertEquals(3, array.length);
        assertSame(top, array[0]);
        assertSame(root, array[2]);
    }

    @Test
    void testGetThrowableListNull() {
        assertTrue(ExceptionUtils.getThrowableList(null).isEmpty());
        assertEquals(0, ExceptionUtils.getThrowables(null).length);
    }

    @Test
    void testHasCauseDirect() {
        final IOException io = new IOException("io");
        assertTrue(ExceptionUtils.hasCause(io, IOException.class));
        assertFalse(ExceptionUtils.hasCause(io, IllegalStateException.class));
    }

    @Test
    void testHasCauseUndeclared() {
        final IOException io = new IOException("io");
        final UndeclaredThrowableException wrapped = new UndeclaredThrowableException(io);
        assertTrue(ExceptionUtils.hasCause(wrapped, IOException.class));
    }

    @Test
    void testHasCauseNullChain() {
        assertFalse(ExceptionUtils.hasCause(null, Exception.class));
    }

    @Test
    void testIndexOfThrowable() {
        final Exception root = newRoot();
        final Exception mid = newMid(root);
        final RuntimeException top = newTop(mid);
        assertEquals(1, ExceptionUtils.indexOfThrowable(top, IllegalArgumentException.class));
        assertEquals(-1, ExceptionUtils.indexOfThrowable(top, Exception.class));
        assertEquals(-1, ExceptionUtils.indexOfThrowable(null, IllegalArgumentException.class));
        assertEquals(-1, ExceptionUtils.indexOfThrowable(top, null));
    }

    @Test
    void testIndexOfThrowableFromIndex() {
        final Exception root = newRoot();
        final Exception mid = newMid(root);
        final RuntimeException top = newTop(mid);
        assertEquals(1, ExceptionUtils.indexOfThrowable(top, IllegalArgumentException.class, -5));
        assertEquals(-1, ExceptionUtils.indexOfThrowable(top, IllegalArgumentException.class, 2));
        assertEquals(-1, ExceptionUtils.indexOfThrowable(top, IllegalArgumentException.class, 10));
    }

    @Test
    void testIndexOfType() {
        final Exception root = newRoot();
        final Exception mid = newMid(root);
        final RuntimeException top = newTop(mid);
        assertEquals(0, ExceptionUtils.indexOfType(top, RuntimeException.class));
        assertEquals(2, ExceptionUtils.indexOfType(top, IOException.class));
        assertEquals(-1, ExceptionUtils.indexOfType(top, IllegalStateException.class));
    }

    @Test
    void testIndexOfTypeFromIndex() {
        final Exception root = newRoot();
        final Exception mid = newMid(root);
        final RuntimeException top = newTop(mid);
        assertEquals(2, ExceptionUtils.indexOfType(top, IOException.class, 1));
        assertEquals(-1, ExceptionUtils.indexOfType(top, IOException.class, 3));
    }

    @Test
    void testIsChecked() {
        assertFalse(ExceptionUtils.isChecked(null));
        assertTrue(ExceptionUtils.isChecked(new IOException("x")));
        assertFalse(ExceptionUtils.isChecked(new RuntimeException("x")));
        assertFalse(ExceptionUtils.isChecked(new Error("x")));
    }

    @Test
    void testIsUnchecked() {
        assertFalse(ExceptionUtils.isUnchecked(null));
        assertFalse(ExceptionUtils.isUnchecked(new IOException("x")));
        assertTrue(ExceptionUtils.isUnchecked(new RuntimeException("x")));
        assertTrue(ExceptionUtils.isUnchecked(new Error("x")));
    }

    @Test
    void testPrintRootCauseStackTraceOneArg() {
        final PrintStream originalErr = System.err;
        final ByteArrayOutputStream capture = new ByteArrayOutputStream();
        System.setErr(new PrintStream(capture));
        try {
            ExceptionUtils.printRootCauseStackTrace(newRoot());
        } finally {
            System.setErr(originalErr);
        }
        final String output = capture.toString();
        assertTrue(output.contains("rootMsg"));
    }

    @Test
    void testPrintRootCauseStackTracePrintStream() {
        final Exception root = newRoot();
        final Exception mid = newMid(root);
        final RuntimeException top = newTop(mid);
        final ByteArrayOutputStream out = new ByteArrayOutputStream();
        ExceptionUtils.printRootCauseStackTrace(top, new PrintStream(out));
        final String output = out.toString();
        assertTrue(output.contains("rootMsg"));
    }

    @Test
    void testPrintRootCauseStackTracePrintStreamNullThrowable() {
        // Must not throw even though the stream is also null: early-return on null throwable.
        ExceptionUtils.printRootCauseStackTrace(null, (PrintStream) null);
    }

    @Test
    void testPrintRootCauseStackTracePrintStreamNullStream() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ExceptionUtils.printRootCauseStackTrace(newRoot(), (PrintStream) null);
            }
        });
    }

    @Test
    void testPrintRootCauseStackTracePrintWriter() {
        final Exception root = newRoot();
        final Exception mid = newMid(root);
        final RuntimeException top = newTop(mid);
        final java.io.StringWriter sw = new java.io.StringWriter();
        ExceptionUtils.printRootCauseStackTrace(top, new PrintWriter(sw));
        assertTrue(sw.toString().contains("rootMsg"));
    }

    @Test
    void testPrintRootCauseStackTracePrintWriterNullThrowable() {
        ExceptionUtils.printRootCauseStackTrace(null, (PrintWriter) null);
    }

    @Test
    void testPrintRootCauseStackTracePrintWriterNullWriter() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ExceptionUtils.printRootCauseStackTrace(newRoot(), (PrintWriter) null);
            }
        });
    }

    @Test
    void testRemoveCommonFrames() {
        final List<String> causeFrames = new ArrayList<>();
        causeFrames.add("c1");
        causeFrames.add("c2");
        causeFrames.add("common1");
        causeFrames.add("common2");
        final List<String> wrapperFrames = new ArrayList<>();
        wrapperFrames.add("w1");
        wrapperFrames.add("common1");
        wrapperFrames.add("common2");

        ExceptionUtils.removeCommonFrames(causeFrames, wrapperFrames);

        assertEquals(2, causeFrames.size());
        assertEquals("c1", causeFrames.get(0));
        assertEquals("c2", causeFrames.get(1));
    }

    @Test
    void testRemoveCommonFramesNullArgs() {
        final List<String> nonNull = new ArrayList<>();
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ExceptionUtils.removeCommonFrames(null, nonNull);
            }
        });
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ExceptionUtils.removeCommonFrames(nonNull, null);
            }
        });
    }

    @Test
    void testRethrow() {
        final IOException cause = new IOException("rethrown");
        Throwable caught = null;
        try {
            final Object unused = ExceptionUtils.<Object>rethrow(cause);
            fail("expected rethrow to throw, got " + unused);
        } catch (final Throwable t) {
            caught = t;
        }
        assertSame(cause, caught);
    }

    @Test
    void testStream() {
        final Exception root = newRoot();
        final Exception mid = newMid(root);
        final RuntimeException top = newTop(mid);
        final List<Throwable> collected = new ArrayList<>();
        ExceptionUtils.stream(top).forEach(new Consumer<Throwable>() {
            @Override
            public void accept(final Throwable t) {
                collected.add(t);
            }
        });
        assertEquals(3, collected.size());
        assertSame(top, collected.get(0));
    }

    @Test
    void testStreamNull() {
        assertEquals(0L, ExceptionUtils.stream(null).count());
    }

    @Test
    void testThrowableOfThrowable() {
        final Exception root = newRoot();
        final Exception mid = newMid(root);
        final RuntimeException top = newTop(mid);
        assertSame(top, ExceptionUtils.throwableOfThrowable(top, RuntimeException.class));
        assertNull(ExceptionUtils.throwableOfThrowable(top, Exception.class));
        assertNull(ExceptionUtils.throwableOfThrowable(null, RuntimeException.class));
        assertNull(ExceptionUtils.throwableOfThrowable(top, null));
    }

    @Test
    void testThrowableOfThrowableFromIndex() {
        final Exception root = newRoot();
        final Exception mid = newMid(root);
        final RuntimeException top = newTop(mid);
        assertSame(mid, ExceptionUtils.throwableOfThrowable(top, IllegalArgumentException.class, -3));
        assertNull(ExceptionUtils.throwableOfThrowable(top, IllegalArgumentException.class, 2));
        assertNull(ExceptionUtils.throwableOfThrowable(top, IllegalArgumentException.class, 10));
    }

    @Test
    void testThrowableOfType() {
        final Exception root = newRoot();
        final Exception mid = newMid(root);
        final RuntimeException top = newTop(mid);
        assertSame(top, ExceptionUtils.throwableOfType(top, RuntimeException.class));
        assertSame(root, ExceptionUtils.throwableOfType(top, IOException.class));
        assertNull(ExceptionUtils.throwableOfType(top, IllegalStateException.class));
    }

    @Test
    void testThrowableOfTypeFromIndex() {
        final Exception root = newRoot();
        final Exception mid = newMid(root);
        final RuntimeException top = newTop(mid);
        assertSame(root, ExceptionUtils.throwableOfType(top, IOException.class, 1));
        assertNull(ExceptionUtils.throwableOfType(top, IOException.class, 3));
    }

    @Test
    @SuppressWarnings("deprecation")
    void testThrowUncheckedDeprecatedRaw() {
        final Object re = new RuntimeException("legacy");
        Throwable caught = null;
        try {
            final Object result = ExceptionUtils.throwUnchecked(re);
            fail("expected to throw, got " + result);
        } catch (final RuntimeException t) {
            caught = t;
        }
        assertSame(re, caught);
    }

    @Test
    @SuppressWarnings("deprecation")
    void testThrowUncheckedDeprecatedRawChecked() {
        final Object checked = new IOException("stays");
        final Object result = ExceptionUtils.throwUnchecked(checked);
        assertSame(checked, result);
    }

    @Test
    void testThrowUncheckedModernUnchecked() {
        final RuntimeException re = new RuntimeException("modern");
        Throwable caught = null;
        try {
            final RuntimeException result = ExceptionUtils.throwUnchecked(re);
            fail("expected to throw, got " + result);
        } catch (final Throwable t) {
            caught = t;
        }
        assertSame(re, caught);
    }

    @Test
    void testThrowUncheckedModernChecked() {
        final IOException checked = new IOException("keep");
        final IOException result = ExceptionUtils.throwUnchecked(checked);
        assertSame(checked, result);
    }

    @Test
    void testWrapAndThrowChecked() {
        final IOException checked = new IOException("checked");
        Throwable caught = null;
        try {
            ExceptionUtils.wrapAndThrow(checked);
            fail("expected to throw");
        } catch (final Throwable t) {
            caught = t;
        }
        assertTrue(caught instanceof UndeclaredThrowableException);
        assertSame(checked, caught.getCause());
    }

    @Test
    void testWrapAndThrowUnchecked() {
        final RuntimeException unchecked = new RuntimeException("unchecked");
        Throwable caught = null;
        try {
            ExceptionUtils.wrapAndThrow(unchecked);
            fail("expected to throw");
        } catch (final Throwable t) {
            caught = t;
        }
        assertSame(unchecked, caught);
    }

    @Test
    void testWrapAndThrowError() {
        final Error error = new Error("err");
        Throwable caught = null;
        try {
            ExceptionUtils.wrapAndThrow(error);
            fail("expected to throw");
        } catch (final Throwable t) {
            caught = t;
        }
        assertSame(error, caught);
    }

    @Test
    void testPublicConstructor() {
        assertNotNull(new ExceptionUtils());
    }
}
