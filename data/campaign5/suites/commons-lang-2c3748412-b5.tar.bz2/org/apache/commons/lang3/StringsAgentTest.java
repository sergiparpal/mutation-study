/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link Strings}.
 */
public class StringsAgentTest {

    // --- compare ---

    @Test
    public void testCompareCsBothNull() {
        assertEquals(0, Strings.CS.compare(null, null));
    }

    @Test
    public void testCompareCsNullLessByDefault() {
        assertTrue(Strings.CS.compare(null, "a") < 0);
        assertTrue(Strings.CS.compare("a", null) > 0);
    }

    @Test
    public void testCompareCsEqualAndOrdering() {
        assertEquals(0, Strings.CS.compare("abc", "abc"));
        assertTrue(Strings.CS.compare("a", "b") < 0);
        assertTrue(Strings.CS.compare("b", "a") > 0);
        assertTrue(Strings.CS.compare("a", "B") > 0);
        assertTrue(Strings.CS.compare("ab", "abc") < 0);
    }

    @Test
    public void testCompareCiCaseInsensitive() {
        assertEquals(0, Strings.CI.compare(null, null));
        assertTrue(Strings.CI.compare(null, "a") < 0);
        assertTrue(Strings.CI.compare("a", null) > 0);
        assertEquals(0, Strings.CI.compare("abc", "ABC"));
        assertTrue(Strings.CI.compare("a", "B") < 0);
    }

    @Test
    public void testCompareBuilderNullIsLessFalse() {
        final Strings s = Strings.builder().setIgnoreCase(false).setNullIsLess(false).get();
        assertTrue(s.compare(null, "a") > 0);
        assertTrue(s.compare("a", null) < 0);
    }

    // --- contains ---

    @Test
    public void testContainsCsNullInputs() {
        assertFalse(Strings.CS.contains(null, "a"));
        assertFalse(Strings.CS.contains("a", null));
    }

    @Test
    public void testContainsCsEmptyAndBoundaries() {
        assertTrue(Strings.CS.contains("", ""));
        assertTrue(Strings.CS.contains("abc", ""));
        assertTrue(Strings.CS.contains("abc", "a"));
        assertFalse(Strings.CS.contains("abc", "z"));
        assertFalse(Strings.CS.contains("abc", "A"));
    }

    @Test
    public void testContainsCiCaseInsensitive() {
        assertFalse(Strings.CI.contains(null, "a"));
        assertTrue(Strings.CI.contains("", ""));
        assertTrue(Strings.CI.contains("abc", "A"));
        assertFalse(Strings.CI.contains("abc", "Z"));
    }

    // --- containsAny ---

    @Test
    public void testContainsAnyCsNullAndEmpty() {
        assertFalse(Strings.CS.containsAny(null, "a"));
        assertFalse(Strings.CS.containsAny("", "a"));
        assertFalse(Strings.CS.containsAny("abc", (CharSequence[]) null));
        assertFalse(Strings.CS.containsAny("abc", new CharSequence[0]));
    }

    @Test
    public void testContainsAnyCsMatches() {
        assertTrue(Strings.CS.containsAny("abcd", "ab", null));
        assertTrue(Strings.CS.containsAny("abcd", "ab", "cd"));
        assertTrue(Strings.CS.containsAny("abc", "d", "abc"));
    }

    @Test
    public void testContainsAnyCiMatches() {
        assertTrue(Strings.CI.containsAny("abc", "D", "ABC"));
        assertTrue(Strings.CI.containsAny("ABC", "d", "abc"));
    }

    // --- endsWith / endsWithAny ---

    @Test
    public void testEndsWithCs() {
        assertTrue(Strings.CS.endsWith(null, null));
        assertFalse(Strings.CS.endsWith(null, "def"));
        assertFalse(Strings.CS.endsWith("abcdef", null));
        assertTrue(Strings.CS.endsWith("abcdef", "def"));
        assertFalse(Strings.CS.endsWith("ABCDEF", "def"));
        assertTrue(Strings.CS.endsWith("ABCDEF", ""));
    }

    @Test
    public void testEndsWithCi() {
        assertTrue(Strings.CI.endsWith(null, null));
        assertTrue(Strings.CI.endsWith("abcdef", "def"));
        assertTrue(Strings.CI.endsWith("ABCDEF", "def"));
        assertFalse(Strings.CI.endsWith("ABCDEF", "cde"));
    }

    @Test
    public void testEndsWithAny() {
        assertFalse(Strings.CS.endsWithAny(null, (CharSequence[]) null));
        assertFalse(Strings.CS.endsWithAny(null, "abc"));
        assertFalse(Strings.CS.endsWithAny("abcxyz", (CharSequence[]) null));
        assertTrue(Strings.CS.endsWithAny("abcxyz", ""));
        assertTrue(Strings.CS.endsWithAny("abcxyz", "xyz"));
        assertTrue(Strings.CS.endsWithAny("abcxyz", (CharSequence) null, "xyz", "abc"));
        assertTrue(Strings.CS.endsWithAny("abcXYZ", "def", "XYZ"));
        assertFalse(Strings.CS.endsWithAny("abcXYZ", "def", "xyz"));
    }

    // --- equals (CharSequence) ---

    @Test
    public void testEqualsCharSequenceCs() {
        assertTrue(Strings.CS.equals((CharSequence) null, (CharSequence) null));
        assertFalse(Strings.CS.equals((CharSequence) null, "abc"));
        assertFalse(Strings.CS.equals("abc", (CharSequence) null));
        assertTrue(Strings.CS.equals((CharSequence) "abc", (CharSequence) "abc"));
        assertFalse(Strings.CS.equals((CharSequence) "abc", (CharSequence) "ABC"));
    }

    @Test
    public void testEqualsCharSequenceCi() {
        assertTrue(Strings.CI.equals((CharSequence) null, (CharSequence) null));
        assertFalse(Strings.CI.equals((CharSequence) null, "abc"));
        assertTrue(Strings.CI.equals((CharSequence) "abc", (CharSequence) "ABC"));
    }

    @Test
    public void testEqualsCharSequenceNonStringStepwise() {
        // Force the step-wise comparison branch in CsStrings#equals(CharSequence, CharSequence)
        final CharSequence a = new StringBuilder("abc");
        final CharSequence b = new StringBuilder("abc");
        final CharSequence c = new StringBuilder("abd");
        assertTrue(Strings.CS.equals(a, b));
        assertFalse(Strings.CS.equals(a, c));
    }

    // --- equals (String) ---

    @Test
    public void testEqualsStringCs() {
        assertTrue(Strings.CS.equals((String) null, (String) null));
        assertFalse(Strings.CS.equals((String) null, "abc"));
        assertFalse(Strings.CS.equals("abc", (String) null));
        assertTrue(Strings.CS.equals("abc", "abc"));
        assertFalse(Strings.CS.equals("abc", "ABC"));
    }

    @Test
    public void testEqualsStringCi() {
        assertTrue(Strings.CI.equals((String) null, (String) null));
        assertFalse(Strings.CI.equals((String) null, "abc"));
        assertTrue(Strings.CI.equals("abc", "ABC"));
    }

    // --- equalsAny ---

    @Test
    public void testEqualsAny() {
        assertFalse(Strings.CS.equalsAny(null, (CharSequence[]) null));
        assertTrue(Strings.CS.equalsAny(null, (CharSequence) null, null));
        assertFalse(Strings.CS.equalsAny(null, "abc", "def"));
        assertFalse(Strings.CS.equalsAny("abc", null, "def"));
        assertTrue(Strings.CS.equalsAny("abc", "abc", "def"));
        assertFalse(Strings.CS.equalsAny("abc", "ABC", "DEF"));
        assertTrue(Strings.CI.equalsAny("abc", "ABC", "DEF"));
    }

    // --- indexOf ---

    @Test
    public void testIndexOfTwoArgCs() {
        assertEquals(-1, Strings.CS.indexOf(null, "a"));
        assertEquals(-1, Strings.CS.indexOf("a", null));
        assertEquals(0, Strings.CS.indexOf("", ""));
        assertEquals(0, Strings.CS.indexOf("aabaabaa", "a"));
        assertEquals(2, Strings.CS.indexOf("aabaabaa", "b"));
        assertEquals(1, Strings.CS.indexOf("aabaabaa", "ab"));
    }

    @Test
    public void testIndexOfThreeArgCs() {
        assertEquals(-1, Strings.CS.indexOf(null, "a", 0));
        assertEquals(-1, Strings.CS.indexOf("a", null, 0));
        assertEquals(0, Strings.CS.indexOf("", "", 0));
        assertEquals(5, Strings.CS.indexOf("aabaabaa", "b", 3));
        assertEquals(-1, Strings.CS.indexOf("aabaabaa", "b", 9));
        assertEquals(2, Strings.CS.indexOf("aabaabaa", "b", -1));
        assertEquals(2, Strings.CS.indexOf("aabaabaa", "", 2));
        assertEquals(3, Strings.CS.indexOf("abc", "", 9));
    }

    @Test
    public void testIndexOfThreeArgCi() {
        assertEquals(-1, Strings.CI.indexOf(null, "a", 0));
        assertEquals(0, Strings.CI.indexOf("aabaabaa", "A", 0));
        assertEquals(2, Strings.CI.indexOf("aabaabaa", "B", 0));
        assertEquals(1, Strings.CI.indexOf("aabaabaa", "AB", 0));
        assertEquals(5, Strings.CI.indexOf("aabaabaa", "B", 3));
        assertEquals(-1, Strings.CI.indexOf("aabaabaa", "B", 9));
        assertEquals(2, Strings.CI.indexOf("aabaabaa", "B", -1));
        assertEquals(2, Strings.CI.indexOf("aabaabaa", "", 2));
        assertEquals(-1, Strings.CI.indexOf("abc", "", 9));
    }

    // --- isCaseSensitive ---

    @Test
    public void testIsCaseSensitive() {
        assertTrue(Strings.CS.isCaseSensitive());
        assertFalse(Strings.CI.isCaseSensitive());
    }

    // --- lastIndexOf ---

    @Test
    public void testLastIndexOfTwoArgCs() {
        assertEquals(-1, Strings.CS.lastIndexOf(null, "a"));
        assertEquals(-1, Strings.CS.lastIndexOf("a", null));
        assertEquals(0, Strings.CS.lastIndexOf("", ""));
        assertEquals(7, Strings.CS.lastIndexOf("aabaabaa", "a"));
        assertEquals(5, Strings.CS.lastIndexOf("aabaabaa", "b"));
        assertEquals(4, Strings.CS.lastIndexOf("aabaabaa", "ab"));
        assertEquals(8, Strings.CS.lastIndexOf("aabaabaa", ""));
    }

    @Test
    public void testLastIndexOfThreeArgCs() {
        assertEquals(-1, Strings.CS.lastIndexOf(null, "a", 0));
        assertEquals(-1, Strings.CS.lastIndexOf("a", null, 0));
        assertEquals(7, Strings.CS.lastIndexOf("aabaabaa", "a", 8));
        assertEquals(5, Strings.CS.lastIndexOf("aabaabaa", "b", 9));
        assertEquals(-1, Strings.CS.lastIndexOf("aabaabaa", "b", -1));
        assertEquals(0, Strings.CS.lastIndexOf("aabaabaa", "a", 0));
        assertEquals(-1, Strings.CS.lastIndexOf("aabaabaa", "b", 0));
        assertEquals(-1, Strings.CS.lastIndexOf("aabaabaa", "b", 1));
        assertEquals(2, Strings.CS.lastIndexOf("aabaabaa", "b", 2));
        assertEquals(2, Strings.CS.lastIndexOf("aabaabaa", "ba", 2));
    }

    @Test
    public void testLastIndexOfThreeArgCi() {
        assertEquals(-1, Strings.CI.lastIndexOf(null, "a", 0));
        assertEquals(7, Strings.CI.lastIndexOf("aabaabaa", "A", 8));
        assertEquals(5, Strings.CI.lastIndexOf("aabaabaa", "B", 8));
        assertEquals(4, Strings.CI.lastIndexOf("aabaabaa", "AB", 8));
        assertEquals(5, Strings.CI.lastIndexOf("aabaabaa", "B", 9));
        assertEquals(-1, Strings.CI.lastIndexOf("aabaabaa", "B", -1));
        assertEquals(0, Strings.CI.lastIndexOf("aabaabaa", "A", 0));
        assertEquals(-1, Strings.CI.lastIndexOf("aabaabaa", "B", 0));
    }

    // --- appendIfMissing ---

    @Test
    public void testAppendIfMissingCs() {
        assertNull(Strings.CS.appendIfMissing(null, null));
        assertEquals("abc", Strings.CS.appendIfMissing("abc", null));
        assertEquals("xyz", Strings.CS.appendIfMissing("", "xyz"));
        assertEquals("abcxyz", Strings.CS.appendIfMissing("abc", "xyz"));
        assertEquals("abcxyz", Strings.CS.appendIfMissing("abcxyz", "xyz"));
        assertEquals("abcXYZxyz", Strings.CS.appendIfMissing("abcXYZ", "xyz"));
    }

    @Test
    public void testAppendIfMissingCsWithAdditionalSuffixes() {
        assertNull(Strings.CS.appendIfMissing(null, null, (CharSequence) null));
        assertEquals("abcxyz", Strings.CS.appendIfMissing("abc", "xyz", new CharSequence[] {null}));
        assertEquals("abc", Strings.CS.appendIfMissing("abc", "xyz", ""));
        assertEquals("abcmno", Strings.CS.appendIfMissing("abcmno", "xyz", "mno"));
        assertEquals("abcMNOxyz", Strings.CS.appendIfMissing("abcMNO", "xyz", "mno"));
    }

    @Test
    public void testAppendIfMissingCi() {
        assertEquals("abcXYZ", Strings.CI.appendIfMissing("abcXYZ", "xyz"));
        assertEquals("abcMNO", Strings.CI.appendIfMissing("abcMNO", "xyz", "mno"));
    }

    // --- prependIfMissing ---

    @Test
    public void testPrependIfMissingCs() {
        assertNull(Strings.CS.prependIfMissing(null, null));
        assertEquals("abc", Strings.CS.prependIfMissing("abc", null));
        assertEquals("xyz", Strings.CS.prependIfMissing("", "xyz"));
        assertEquals("xyzabc", Strings.CS.prependIfMissing("abc", "xyz"));
        assertEquals("xyzabc", Strings.CS.prependIfMissing("xyzabc", "xyz"));
        assertEquals("xyzXYZabc", Strings.CS.prependIfMissing("XYZabc", "xyz"));
    }

    @Test
    public void testPrependIfMissingCsWithAdditionalPrefixes() {
        assertEquals("xyzabc", Strings.CS.prependIfMissing("abc", "xyz", new CharSequence[] {null}));
        assertEquals("abc", Strings.CS.prependIfMissing("abc", "xyz", ""));
        assertEquals("mnoabc", Strings.CS.prependIfMissing("mnoabc", "xyz", "mno"));
        assertEquals("xyzMNOabc", Strings.CS.prependIfMissing("MNOabc", "xyz", "mno"));
    }

    @Test
    public void testPrependIfMissingCi() {
        assertEquals("XYZabc", Strings.CI.prependIfMissing("XYZabc", "xyz"));
        assertEquals("MNOabc", Strings.CI.prependIfMissing("MNOabc", "xyz", "mno"));
    }

    // --- remove ---

    @Test
    public void testRemove() {
        assertNull(Strings.CS.remove(null, "a"));
        assertEquals("", Strings.CS.remove("", "a"));
        assertEquals("queued", Strings.CS.remove("queued", null));
        assertEquals("queued", Strings.CS.remove("queued", ""));
        assertEquals("qd", Strings.CS.remove("queued", "ue"));
        assertEquals("queued", Strings.CS.remove("queued", "zz"));
        assertEquals("qd", Strings.CI.remove("quEUed", "UE"));
        assertEquals("queued", Strings.CI.remove("queued", "zZ"));
    }

    // --- removeEnd ---

    @Test
    public void testRemoveEnd() {
        assertNull(Strings.CS.removeEnd(null, "x"));
        assertEquals("", Strings.CS.removeEnd("", "x"));
        assertEquals("www.domain.com", Strings.CS.removeEnd("www.domain.com", (CharSequence) null));
        assertEquals("www.domain.com", Strings.CS.removeEnd("www.domain.com", ".com."));
        assertEquals("www.domain", Strings.CS.removeEnd("www.domain.com", ".com"));
        assertEquals("www.domain.com", Strings.CS.removeEnd("www.domain.com", "domain"));
        assertEquals("abc", Strings.CS.removeEnd("abc", ""));
        assertEquals("www.domain", Strings.CI.removeEnd("www.domain.com", ".COM"));
        assertEquals("www.domain", Strings.CI.removeEnd("www.domain.COM", ".com"));
    }

    // --- removeStart ---

    @Test
    public void testRemoveStart() {
        assertNull(Strings.CS.removeStart(null, "x"));
        assertEquals("", Strings.CS.removeStart("", "x"));
        assertEquals("www.domain.com", Strings.CS.removeStart("www.domain.com", (CharSequence) null));
        assertEquals("domain.com", Strings.CS.removeStart("www.domain.com", "www."));
        assertEquals("domain.com", Strings.CS.removeStart("domain.com", "www."));
        assertEquals("www.domain.com", Strings.CS.removeStart("www.domain.com", "domain"));
        assertEquals("abc", Strings.CS.removeStart("abc", ""));
        assertEquals("domain.com", Strings.CI.removeStart("www.domain.com", "WWW."));
    }

    // --- replace / replaceOnce ---

    @Test
    public void testReplaceCs() {
        assertNull(Strings.CS.replace(null, "a", "b"));
        assertEquals("", Strings.CS.replace("", "a", "b"));
        assertEquals("any", Strings.CS.replace("any", null, "b"));
        assertEquals("any", Strings.CS.replace("any", "a", null));
        assertEquals("any", Strings.CS.replace("any", "", "b"));
        assertEquals("aba", Strings.CS.replace("aba", "a", null));
        assertEquals("b", Strings.CS.replace("aba", "a", ""));
        assertEquals("zbz", Strings.CS.replace("aba", "a", "z"));
    }

    @Test
    public void testReplaceCi() {
        assertEquals("b", Strings.CI.replace("abA", "A", ""));
        assertEquals("zbz", Strings.CI.replace("aba", "A", "z"));
    }

    @Test
    public void testReplaceWithMax() {
        assertEquals("abaa", Strings.CS.replace("abaa", "a", "z", 0));
        assertEquals("zbaa", Strings.CS.replace("abaa", "a", "z", 1));
        assertEquals("zbza", Strings.CS.replace("abaa", "a", "z", 2));
        assertEquals("zbzz", Strings.CS.replace("abaa", "a", "z", -1));
    }

    @Test
    public void testReplaceOnce() {
        assertNull(Strings.CS.replaceOnce(null, "a", "b"));
        assertEquals("ba", Strings.CS.replaceOnce("aba", "a", ""));
        assertEquals("zba", Strings.CS.replaceOnce("aba", "a", "z"));
        assertEquals("Foofoo", Strings.CI.replaceOnce("FoOFoofoo", "foo", ""));
    }

    // --- startsWith / startsWithAny ---

    @Test
    public void testStartsWithCs() {
        assertTrue(Strings.CS.startsWith(null, null));
        assertFalse(Strings.CS.startsWith(null, "abc"));
        assertFalse(Strings.CS.startsWith("abcdef", null));
        assertTrue(Strings.CS.startsWith("abcdef", "abc"));
        assertFalse(Strings.CS.startsWith("ABCDEF", "abc"));
    }

    @Test
    public void testStartsWithCi() {
        assertTrue(Strings.CI.startsWith(null, null));
        assertTrue(Strings.CI.startsWith("ABCDEF", "abc"));
    }

    @Test
    public void testStartsWithAny() {
        assertFalse(Strings.CS.startsWithAny(null, (CharSequence[]) null));
        assertFalse(Strings.CS.startsWithAny(null, "abc"));
        assertFalse(Strings.CS.startsWithAny("abcxyz", (CharSequence[]) null));
        assertTrue(Strings.CS.startsWithAny("abcxyz", ""));
        assertTrue(Strings.CS.startsWithAny("abcxyz", "abc"));
        assertTrue(Strings.CS.startsWithAny("abcxyz", (CharSequence) null, "xyz", "abc"));
        assertFalse(Strings.CS.startsWithAny("abcxyz", (CharSequence) null, "xyz", "ABCX"));
        assertTrue(Strings.CI.startsWithAny("abcxyz", (CharSequence) null, "xyz", "ABCX"));
    }

    // --- builder ---

    @Test
    public void testBuilderDefaultsToCaseSensitive() {
        final Strings s = Strings.builder().get();
        assertNotNull(s);
        assertTrue(s.isCaseSensitive());
    }

    @Test
    public void testBuilderIgnoreCaseProducesCaseInsensitiveInstance() {
        final Strings s = Strings.builder().setIgnoreCase(true).get();
        assertFalse(s.isCaseSensitive());
        assertTrue(s.equals("abc", "ABC"));
    }

    @Test
    public void testSingletonIdentities() {
        assertSame(Strings.CS, Strings.CS);
        assertSame(Strings.CI, Strings.CI);
        assertTrue(Strings.CS.isCaseSensitive());
        assertFalse(Strings.CI.isCaseSensitive());
    }
}
