/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link Fraction}.
 */
public class FractionAgentTest {

    @Test
    public void testGetFractionIntIntNegativeOnDenominator() {
        final Fraction f = Fraction.getFraction(1, -2);
        assertEquals(-1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetFractionIntIntZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(1, 0));
    }

    @Test
    public void testGetFractionIntIntDenominatorMinValueOverflow() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(5, Integer.MIN_VALUE));
    }

    @Test
    public void testGetFractionIntIntNumeratorMinValueDenominatorNegativeOverflow() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(Integer.MIN_VALUE, -2));
    }

    @Test
    public void testGetFractionWholeNumerDenom() {
        final Fraction f = Fraction.getFraction(1, 3, 7);
        assertEquals(10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionWholeNegativeWhole() {
        final Fraction f = Fraction.getFraction(-1, 3, 7);
        assertEquals(-10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionWholeNegativeDenominatorThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(1, 1, -1));
    }

    @Test
    public void testGetFractionWholeNegativeNumeratorThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(1, -1, 2));
    }

    @Test
    public void testGetFractionWholeZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(1, 1, 0));
    }

    @Test
    public void testGetFractionWholeOverflow() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(Integer.MAX_VALUE, 1, 2));
    }

    @Test
    public void testGetFractionDouble() {
        final Fraction f = Fraction.getFraction(0.5d);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetFractionDoubleNegative() {
        final Fraction f = Fraction.getFraction(-0.25d);
        assertEquals(-1, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionDoubleNaNThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(Double.NaN));
    }

    @Test
    public void testGetFractionDoubleTooLargeThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction((double) Integer.MAX_VALUE + 1000.0d));
    }

    @Test
    public void testGetFractionDoubleZero() {
        final Fraction f = Fraction.getFraction(0.0d);
        assertEquals(0, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    public void testGetFractionStringDouble() {
        final Fraction f = Fraction.getFraction("0.25");
        assertEquals(1, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionStringWholeNumerDenom() {
        final Fraction f = Fraction.getFraction("1 3/7");
        assertEquals(10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionStringNumerDenom() {
        final Fraction f = Fraction.getFraction("3/7");
        assertEquals(3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionStringWhole() {
        final Fraction f = Fraction.getFraction("5");
        assertEquals(5, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    public void testGetFractionStringNullThrows() {
        assertThrows(NullPointerException.class, () -> Fraction.getFraction((String) null));
    }

    @Test
    public void testGetFractionStringMissingDenominatorThrows() {
        assertThrows(NumberFormatException.class, () -> Fraction.getFraction("1 3"));
    }

    @Test
    public void testGetFractionStringInvalidThrows() {
        assertThrows(NumberFormatException.class, () -> Fraction.getFraction("abc"));
    }

    @Test
    public void testGetReducedFractionNormal() {
        final Fraction f = Fraction.getReducedFraction(2, 4);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetReducedFractionZeroNumeratorIsZeroConstant() {
        final Fraction f = Fraction.getReducedFraction(0, 5);
        assertSame(Fraction.ZERO, f);
    }

    @Test
    public void testGetReducedFractionZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getReducedFraction(1, 0));
    }

    @Test
    public void testGetReducedFractionNegativeDenominator() {
        final Fraction f = Fraction.getReducedFraction(1, -2);
        assertEquals(-1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testConstantsValues() {
        assertEquals(0, Fraction.ZERO.getNumerator());
        assertEquals(1, Fraction.ZERO.getDenominator());
        assertEquals(1, Fraction.ONE.getNumerator());
        assertEquals(1, Fraction.ONE.getDenominator());
        assertEquals(1, Fraction.ONE_HALF.getNumerator());
        assertEquals(2, Fraction.ONE_HALF.getDenominator());
        assertEquals(4, Fraction.FOUR_FIFTHS.getNumerator());
        assertEquals(5, Fraction.FOUR_FIFTHS.getDenominator());
    }

    @Test
    public void testGetProperNumeratorAndWhole() {
        final Fraction f = Fraction.getFraction(7, 4);
        assertEquals(3, f.getProperNumerator());
        assertEquals(1, f.getProperWhole());
    }

    @Test
    public void testGetProperNumeratorAndWholeNegative() {
        final Fraction f = Fraction.getFraction(-7, 4);
        assertEquals(3, f.getProperNumerator());
        assertEquals(-1, f.getProperWhole());
    }

    @Test
    public void testAbsPositiveReturnsSameInstance() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertSame(f, f.abs());
    }

    @Test
    public void testAbsNegative() {
        final Fraction f = Fraction.getFraction(-1, 2);
        final Fraction abs = f.abs();
        assertEquals(1, abs.getNumerator());
        assertEquals(2, abs.getDenominator());
    }

    @Test
    public void testAbsOverflow() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, f::abs);
    }

    @Test
    public void testAddSimple() {
        final Fraction f1 = Fraction.getFraction(1, 2);
        final Fraction f2 = Fraction.getFraction(1, 3);
        final Fraction result = f1.add(f2);
        assertEquals(5, result.getNumerator());
        assertEquals(6, result.getDenominator());
    }

    @Test
    public void testAddZeroIdentity() {
        final Fraction f = Fraction.getFraction(3, 5);
        assertEquals(f, Fraction.ZERO.add(f));
        assertEquals(f, f.add(Fraction.ZERO));
    }

    @Test
    public void testAddNullThrows() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, () -> f.add(null));
    }

    @Test
    public void testAddOverflowThrows() {
        final Fraction f1 = Fraction.getFraction(Integer.MAX_VALUE, 1);
        final Fraction f2 = Fraction.getFraction(1, 1);
        assertThrows(ArithmeticException.class, () -> f1.add(f2));
    }

    @Test
    public void testSubtractSimple() {
        final Fraction f1 = Fraction.getFraction(1, 2);
        final Fraction f2 = Fraction.getFraction(1, 3);
        final Fraction result = f1.subtract(f2);
        assertEquals(1, result.getNumerator());
        assertEquals(6, result.getDenominator());
    }

    @Test
    public void testSubtractNullThrows() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, () -> f.subtract(null));
    }

    @Test
    public void testMultiplyBySimple() {
        final Fraction f1 = Fraction.getFraction(2, 3);
        final Fraction f2 = Fraction.getFraction(3, 4);
        final Fraction result = f1.multiplyBy(f2);
        assertEquals(1, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    @Test
    public void testMultiplyByZero() {
        final Fraction f1 = Fraction.getFraction(2, 3);
        final Fraction result = f1.multiplyBy(Fraction.ZERO);
        assertSame(Fraction.ZERO, result);
    }

    @Test
    public void testMultiplyByNullThrows() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, () -> f.multiplyBy(null));
    }

    @Test
    public void testDivideBySimple() {
        final Fraction f1 = Fraction.getFraction(1, 2);
        final Fraction f2 = Fraction.getFraction(1, 3);
        final Fraction result = f1.divideBy(f2);
        assertEquals(3, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    @Test
    public void testDivideByZeroThrows() {
        final Fraction f1 = Fraction.getFraction(1, 2);
        assertThrows(ArithmeticException.class, () -> f1.divideBy(Fraction.ZERO));
    }

    @Test
    public void testDivideByNullThrows() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, () -> f.divideBy(null));
    }

    @Test
    public void testInvertSimple() {
        final Fraction f = Fraction.getFraction(2, 3);
        final Fraction inverted = f.invert();
        assertEquals(3, inverted.getNumerator());
        assertEquals(2, inverted.getDenominator());
    }

    @Test
    public void testInvertNegative() {
        final Fraction f = Fraction.getFraction(-2, 3);
        final Fraction inverted = f.invert();
        assertEquals(-3, inverted.getNumerator());
        assertEquals(2, inverted.getDenominator());
    }

    @Test
    public void testInvertZeroThrows() {
        assertThrows(ArithmeticException.class, Fraction.ZERO::invert);
    }

    @Test
    public void testInvertMinValueNumeratorThrows() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, f::invert);
    }

    @Test
    public void testNegateSimple() {
        final Fraction f = Fraction.getFraction(3, 5);
        final Fraction negated = f.negate();
        assertEquals(-3, negated.getNumerator());
        assertEquals(5, negated.getDenominator());
    }

    @Test
    public void testNegateOverflowThrows() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, f::negate);
    }

    @Test
    public void testPowPositive() {
        final Fraction f = Fraction.getFraction(2, 3);
        final Fraction result = f.pow(3);
        assertEquals(8, result.getNumerator());
        assertEquals(27, result.getDenominator());
    }

    @Test
    public void testPowZeroReturnsOne() {
        final Fraction f = Fraction.getFraction(2, 3);
        assertSame(Fraction.ONE, f.pow(0));
        assertSame(Fraction.ONE, Fraction.ZERO.pow(0));
    }

    @Test
    public void testPowOneReturnsSameInstance() {
        final Fraction f = Fraction.getFraction(2, 3);
        assertSame(f, f.pow(1));
    }

    @Test
    public void testPowNegative() {
        final Fraction f = Fraction.getFraction(2, 3);
        final Fraction result = f.pow(-2);
        assertEquals(9, result.getNumerator());
        assertEquals(4, result.getDenominator());
    }

    @Test
    public void testPowMinValue() {
        final Fraction result = Fraction.ONE.pow(Integer.MIN_VALUE);
        assertEquals(1, result.getNumerator());
        assertEquals(1, result.getDenominator());
    }

    @Test
    public void testPowMinValueOverflowThrows() {
        final Fraction f = Fraction.getFraction(2, 1);
        assertThrows(ArithmeticException.class, () -> f.pow(Integer.MIN_VALUE));
    }

    @Test
    public void testReduceSimple() {
        final Fraction f = Fraction.getFraction(4, 8);
        final Fraction reduced = f.reduce();
        assertEquals(1, reduced.getNumerator());
        assertEquals(2, reduced.getDenominator());
    }

    @Test
    public void testReduceAlreadyReducedReturnsSameInstance() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertSame(f, f.reduce());
    }

    @Test
    public void testReduceZeroNumeratorNonZeroConstant() {
        final Fraction f = Fraction.getFraction(0, 5);
        final Fraction reduced = f.reduce();
        assertSame(Fraction.ZERO, reduced);
    }

    @Test
    public void testCompareToEqualValuesDifferentRepresentation() {
        final Fraction f1 = Fraction.getFraction(1, 2);
        final Fraction f2 = Fraction.getFraction(2, 4);
        assertEquals(0, f1.compareTo(f2));
    }

    @Test
    public void testCompareToLessAndGreater() {
        final Fraction f1 = Fraction.getFraction(1, 3);
        final Fraction f2 = Fraction.getFraction(1, 2);
        assertTrue(f1.compareTo(f2) < 0);
        assertTrue(f2.compareTo(f1) > 0);
    }

    @Test
    public void testCompareToSameInstance() {
        final Fraction f1 = Fraction.getFraction(5, 7);
        assertEquals(0, f1.compareTo(f1));
    }

    @Test
    public void testCompareToNullThrows() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, () -> f.compareTo(null));
    }

    @Test
    public void testEqualsUnequalRepresentation() {
        final Fraction f1 = Fraction.getFraction(1, 2);
        final Fraction f2 = Fraction.getFraction(2, 4);
        assertFalse(f1.equals(f2));
    }

    @Test
    public void testEqualsSameValue() {
        final Fraction f1 = Fraction.getFraction(1, 2);
        final Fraction f2 = Fraction.getFraction(1, 2);
        assertTrue(f1.equals(f2));
    }

    @Test
    public void testEqualsNullAndOtherType() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertFalse(f.equals(null));
        assertFalse(f.equals("1/2"));
    }

    @Test
    public void testHashCodeConsistentWithEquals() {
        final Fraction f1 = Fraction.getFraction(1, 2);
        final Fraction f2 = Fraction.getFraction(1, 2);
        assertEquals(f1.hashCode(), f2.hashCode());
    }

    @Test
    public void testIntValueTruncates() {
        final Fraction f = Fraction.getFraction(7, 4);
        assertEquals(1, f.intValue());
        final Fraction negative = Fraction.getFraction(-7, 4);
        assertEquals(-1, negative.intValue());
    }

    @Test
    public void testLongValueTruncates() {
        final Fraction f = Fraction.getFraction(7, 4);
        assertEquals(1L, f.longValue());
    }

    @Test
    public void testFloatValue() {
        final Fraction f = Fraction.getFraction(1, 4);
        assertEquals(0.25f, f.floatValue(), 0.0001f);
    }

    @Test
    public void testDoubleValue() {
        final Fraction f = Fraction.getFraction(1, 4);
        assertEquals(0.25d, f.doubleValue(), 0.0001d);
    }

    @Test
    public void testToStringFormat() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertEquals("3/7", f.toString());
    }

    @Test
    public void testToStringCachedSameInstance() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertSame(f.toString(), f.toString());
    }

    @Test
    public void testToProperStringZero() {
        assertEquals("0", Fraction.ZERO.toProperString());
    }

    @Test
    public void testToProperStringOne() {
        final Fraction f = Fraction.getFraction(4, 4);
        assertEquals("1", f.toProperString());
    }

    @Test
    public void testToProperStringMinusOne() {
        final Fraction f = Fraction.getFraction(-4, 4);
        assertEquals("-1", f.toProperString());
    }

    @Test
    public void testToProperStringImproperPositive() {
        final Fraction f = Fraction.getFraction(7, 4);
        assertEquals("1 3/4", f.toProperString());
    }

    @Test
    public void testToProperStringImproperNegative() {
        final Fraction f = Fraction.getFraction(-7, 4);
        assertEquals("-1 3/4", f.toProperString());
    }

    @Test
    public void testToProperStringProperFraction() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertEquals("3/7", f.toProperString());
    }

    @Test
    public void testToProperStringMinValueNumerator() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertEquals(Integer.toString(Integer.MIN_VALUE), f.toProperString());
    }
}
