/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link FastDateParser}.
 */
class FastDateParserAgentTest {

    private static final TimeZone UTC = TimeZone.getTimeZone("UTC");

    private static int yearOf(final Date date, final TimeZone tz, final Locale locale) {
        final Calendar cal = Calendar.getInstance(tz, locale);
        cal.setTime(date);
        return cal.get(Calendar.YEAR);
    }

    @Test
    void testBasicGetters() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        assertEquals("yyyy-MM-dd", parser.getPattern());
        assertEquals(Locale.US, parser.getLocale());
        assertEquals(UTC, parser.getTimeZone());
    }

    @Test
    void testParseSimpleDate() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final Date date = parser.parse("2023-01-15");
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.setTime(date);
        assertEquals(2023, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseThrowsParseExceptionOnInvalidInput() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final ParseException e = assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                parser.parse("not-a-date");
            }
        });
        assertTrue(e.getMessage().contains("Unparseable date"));
        assertEquals(0, e.getErrorOffset());
    }

    @Test
    void testParsePositionReturnsNullOnFailure() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("garbage", pos);
        assertNull(date);
        assertNotEquals(-1, pos.getErrorIndex());
    }

    @Test
    void testParsePositionIndexBeyondSourceLengthFails() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(5);
        final Date date = parser.parse("ab", pos);
        assertNull(date);
        assertEquals(5, pos.getErrorIndex());
    }

    @Test
    void testParseCalendarVariantBoundary() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(10);
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        final boolean result = parser.parse("short", pos, cal);
        assertFalse(result);
        assertEquals(10, pos.getErrorIndex());
    }

    @Test
    void testParsePartialConsumesOnlyMatchedPrefix() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("2023-01-15 trailing text", pos);
        assertNotNull(date);
        assertEquals(10, pos.getIndex());
        assertEquals(-1, pos.getErrorIndex());
    }

    @Test
    void testTwoDigitYearAdjustment() throws ParseException {
        final Calendar start = Calendar.getInstance(UTC, Locale.US);
        start.clear();
        start.set(1950, Calendar.JANUARY, 1, 12, 0, 0);
        final Date centuryStart = start.getTime();

        final FastDateParser parser = new FastDateParser("yy", UTC, Locale.US, centuryStart);
        // century = 1900, startYear = 50
        assertEquals(2030, yearOf(parser.parse("30"), UTC, Locale.US));
        assertEquals(1960, yearOf(parser.parse("60"), UTC, Locale.US));
        assertEquals(1950, yearOf(parser.parse("50"), UTC, Locale.US));
        assertEquals(2049, yearOf(parser.parse("49"), UTC, Locale.US));
    }

    @Test
    void testJapaneseImperialLocaleAddsExplanation() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, FastDateParser.JAPANESE_IMPERIAL);
        final ParseException e = assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                parser.parse("not-a-date");
            }
        });
        assertTrue(e.getMessage().contains("does not support dates before 1868-01-01"));
    }

    @Test
    void testEqualsAndHashCode() {
        final FastDateParser a = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final FastDateParser b = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final FastDateParser c = new FastDateParser("MM/dd/yyyy", UTC, Locale.US);

        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
        assertNotEquals(a, c);
        assertFalse(a.equals("yyyy-MM-dd"));
        assertFalse(a.equals(null));
    }

    @Test
    void testGetTimeZoneReturnsDefensiveCopy() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final TimeZone tz1 = parser.getTimeZone();
        tz1.setID("Mutated/Zone");
        final TimeZone tz2 = parser.getTimeZone();
        assertEquals("UTC", tz2.getID());
    }

    @Test
    void testGetPatternsStrategyCount() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final List<?> patterns = parser.getPatterns();
        // yyyy, '-', MM, '-', dd => 5 strategies
        assertEquals(5, patterns.size());
    }

    @Test
    void testUnsupportedPatternLetterThrowsAtConstruction() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDateParser("q", UTC, Locale.US);
            }
        });
    }

    @Test
    void testUnterminatedQuoteThrowsAtConstruction() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDateParser("yyyy'bad", UTC, Locale.US);
            }
        });
    }

    @Test
    void testInvalidIsoWidthThrowsAtConstruction() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDateParser("XXXX", UTC, Locale.US);
            }
        });
    }

    @Test
    void testTextStrategyRejectsUnknownMonthName() {
        final FastDateParser parser = new FastDateParser("MMMM d, yyyy", UTC, Locale.US);
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                parser.parse("Fooember 1, 2020");
            }
        });
    }

    @Test
    void testTextStrategyParsesKnownMonthName() throws ParseException {
        final FastDateParser parser = new FastDateParser("MMMM d, yyyy", UTC, Locale.US);
        final Date date = parser.parse("March 5, 2021");
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.setTime(date);
        assertEquals(2021, cal.get(Calendar.YEAR));
        assertEquals(Calendar.MARCH, cal.get(Calendar.MONTH));
        assertEquals(5, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testLiteralTextMustMatchExactly() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("2020/01/01", pos);
        assertNull(date);
        assertEquals(4, pos.getErrorIndex());
    }

    @Test
    void testNullPatternThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDateParser(null, UTC, Locale.US);
            }
        });
    }

    @Test
    void testNullTimeZoneThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDateParser("yyyy-MM-dd", null, Locale.US);
            }
        });
    }

    @Test
    void testNullLocaleDefaultsToSystemDefault() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, null);
        assertEquals(Locale.getDefault(), parser.getLocale());
    }

    @Test
    void testParseObjectVariants() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final Object fromString = parser.parseObject("2023-01-15");
        assertTrue(fromString instanceof Date);

        final ParsePosition pos = new ParsePosition(0);
        final Object fromPos = parser.parseObject("2023-01-15", pos);
        assertEquals(fromString, fromPos);
        assertEquals(10, pos.getIndex());
    }

    @Test
    void testHourStrategyBoundaryValues() throws ParseException {
        final FastDateParser hh = new FastDateParser("hh:mm", UTC, Locale.US);
        Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.setTime(hh.parse("12:00"));
        assertEquals(0, cal.get(Calendar.HOUR));

        final FastDateParser kk = new FastDateParser("kk:mm", UTC, Locale.US);
        cal = Calendar.getInstance(UTC, Locale.US);
        cal.setTime(kk.parse("24:00"));
        assertEquals(0, cal.get(Calendar.HOUR_OF_DAY));

        cal = Calendar.getInstance(UTC, Locale.US);
        cal.setTime(kk.parse("13:00"));
        assertEquals(13, cal.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    void testNumberOverflowCausesParseFailure() {
        final FastDateParser parser = new FastDateParser("yyyy", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("99999999999", pos);
        assertNull(date);
        assertEquals(0, pos.getErrorIndex());
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                parser.parse("99999999999");
            }
        });
    }

    @Test
    void testWeekYearPattern() {
        final FastDateParser parser = new FastDateParser("YYYY-'W'ww-u", UTC, Locale.US);
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.setMinimalDaysInFirstWeek(4);
        cal.setFirstDayOfWeek(Calendar.MONDAY);
        cal.clear();

        final boolean ok = parser.parse("2004-W53-6", new ParsePosition(0), cal);
        assertTrue(ok);

        final Calendar expected = new GregorianCalendar(UTC, Locale.US);
        expected.clear();
        expected.set(2005, Calendar.JANUARY, 1);
        assertEquals(expected.getTime(), cal.getTime());
    }

    @Test
    void testTimeZoneSkipHelper() {
        assertTrue(FastDateParser.TimeZoneStrategy.skipTimeZone("GMT"));
        assertTrue(FastDateParser.TimeZoneStrategy.skipTimeZone("gmt"));
        assertFalse(FastDateParser.TimeZoneStrategy.skipTimeZone("PST"));
    }

    @Test
    void testSerializationRoundTrip() throws IOException, ClassNotFoundException {
        final FastDateParser original = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        final ObjectOutputStream oos = new ObjectOutputStream(baos);
        oos.writeObject(original);
        oos.close();

        final ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(baos.toByteArray()));
        final FastDateParser restored;
        try {
            restored = (FastDateParser) ois.readObject();
        } finally {
            ois.close();
        }

        assertEquals(original, restored);
        Date date = null;
        try {
            date = restored.parse("2024-06-30");
        } catch (final ParseException e) {
            throw new AssertionError(e);
        }
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.setTime(date);
        assertEquals(2024, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JUNE, cal.get(Calendar.MONTH));
        assertEquals(30, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testToStringAndToStringAll() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final String s = parser.toString();
        assertTrue(s.contains("yyyy-MM-dd"));
        assertTrue(s.contains("UTC"));

        final String all = parser.toStringAll();
        assertTrue(all.contains("pattern=yyyy-MM-dd"));
        assertTrue(all.contains("century="));
        assertTrue(all.contains("startYear="));
    }
}
