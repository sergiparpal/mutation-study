/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3.builder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link HashCodeBuilder}.
 */
class HashCodeBuilderAgentTest {

    /**
     * Fixture with a variety of field types, used for reflectionHashCode tests.
     */
    static class ReflectionFixture {
        private final int intField;
        private final String stringField;
        private transient int transientField;
        private static int staticField = 999;
        @HashCodeExclude
        private int excludedField;

        ReflectionFixture(final int intField, final String stringField) {
            this.intField = intField;
            this.stringField = stringField;
        }
    }

    /**
     * Fixture exercising superclass reflection.
     */
    static class ReflectionFixtureChild extends ReflectionFixture {
        private final int childField;

        ReflectionFixtureChild(final int intField, final String stringField, final int childField) {
            super(intField, stringField);
            this.childField = childField;
        }
    }

    /**
     * Fixture with a self-referencing field to test cycle detection.
     */
    static class CyclicFixture {
        CyclicFixture self;

        @Override
        public int hashCode() {
            return HashCodeBuilder.reflectionHashCode(this);
        }
    }

    // --- Constructors ---

    @Test
    void testDefaultConstructorToHashCode() {
        final HashCodeBuilder builder = new HashCodeBuilder();
        assertEquals(17, builder.toHashCode());
    }

    @Test
    void testTwoArgConstructorStoresValuesInToHashCode() {
        final HashCodeBuilder builder = new HashCodeBuilder(19, 7);
        assertEquals(19, builder.toHashCode());
        builder.append(1);
        assertEquals(19 * 7 + 1, builder.toHashCode());
    }

    @Test
    void testConstructorRejectsEvenInitialValue() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new HashCodeBuilder(18, 7);
            }
        });
    }

    @Test
    void testConstructorRejectsEvenMultiplier() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new HashCodeBuilder(17, 8);
            }
        });
    }

    // --- Append primitives ---

    @Test
    void testAppendBooleanTrueIsZeroContribution() {
        final int result = new HashCodeBuilder(17, 37).append(true).toHashCode();
        assertEquals(17 * 37 + 0, result);
    }

    @Test
    void testAppendBooleanFalseIsOneContribution() {
        final int result = new HashCodeBuilder(17, 37).append(false).toHashCode();
        assertEquals(17 * 37 + 1, result);
    }

    @Test
    void testAppendBooleanArrayNull() {
        final boolean[] array = null;
        final int result = new HashCodeBuilder(17, 37).append(array).toHashCode();
        assertEquals(17 * 37, result);
    }

    @Test
    void testAppendBooleanArrayMatchesElementwise() {
        final boolean[] array = {true, false, true};
        final int actual = new HashCodeBuilder(17, 37).append(array).toHashCode();
        final int expected = new HashCodeBuilder(17, 37).append(true).append(false).append(true).toHashCode();
        assertEquals(expected, actual);
    }

    @Test
    void testAppendByte() {
        final int result = new HashCodeBuilder(17, 37).append((byte) 5).toHashCode();
        assertEquals(17 * 37 + 5, result);
    }

    @Test
    void testAppendByteArrayNull() {
        final byte[] array = null;
        assertEquals(17 * 37, new HashCodeBuilder(17, 37).append(array).toHashCode());
    }

    @Test
    void testAppendByteArray() {
        final byte[] array = {1, 2, 3};
        final int actual = new HashCodeBuilder(17, 37).append(array).toHashCode();
        final int expected = new HashCodeBuilder(17, 37).append((byte) 1).append((byte) 2).append((byte) 3).toHashCode();
        assertEquals(expected, actual);
    }

    @Test
    void testAppendChar() {
        final int result = new HashCodeBuilder(17, 37).append('a').toHashCode();
        assertEquals(17 * 37 + 'a', result);
    }

    @Test
    void testAppendCharArrayNull() {
        final char[] array = null;
        assertEquals(17 * 37, new HashCodeBuilder(17, 37).append(array).toHashCode());
    }

    @Test
    void testAppendCharArray() {
        final char[] array = {'a', 'b'};
        final int actual = new HashCodeBuilder(17, 37).append(array).toHashCode();
        final int expected = new HashCodeBuilder(17, 37).append('a').append('b').toHashCode();
        assertEquals(expected, actual);
    }

    @Test
    void testAppendDoubleMatchesDoubleToLongBits() {
        final double value = 3.14d;
        final int actual = new HashCodeBuilder(17, 37).append(value).toHashCode();
        final int expected = new HashCodeBuilder(17, 37).append(Double.doubleToLongBits(value)).toHashCode();
        assertEquals(expected, actual);
    }

    @Test
    void testAppendDoubleArrayNull() {
        final double[] array = null;
        assertEquals(17 * 37, new HashCodeBuilder(17, 37).append(array).toHashCode());
    }

    @Test
    void testAppendDoubleArray() {
        final double[] array = {1.1d, 2.2d};
        final int actual = new HashCodeBuilder(17, 37).append(array).toHashCode();
        final int expected = new HashCodeBuilder(17, 37).append(1.1d).append(2.2d).toHashCode();
        assertEquals(expected, actual);
    }

    @Test
    void testAppendFloatMatchesFloatToIntBits() {
        final float value = 2.5f;
        final int actual = new HashCodeBuilder(17, 37).append(value).toHashCode();
        final int expected = 17 * 37 + Float.floatToIntBits(value);
        assertEquals(expected, actual);
    }

    @Test
    void testAppendFloatArrayNull() {
        final float[] array = null;
        assertEquals(17 * 37, new HashCodeBuilder(17, 37).append(array).toHashCode());
    }

    @Test
    void testAppendFloatArray() {
        final float[] array = {1.1f, 2.2f};
        final int actual = new HashCodeBuilder(17, 37).append(array).toHashCode();
        final int expected = new HashCodeBuilder(17, 37).append(1.1f).append(2.2f).toHashCode();
        assertEquals(expected, actual);
    }

    @Test
    void testAppendInt() {
        final int result = new HashCodeBuilder(17, 37).append(42).toHashCode();
        assertEquals(17 * 37 + 42, result);
    }

    @Test
    void testAppendIntArrayNull() {
        final int[] array = null;
        assertEquals(17 * 37, new HashCodeBuilder(17, 37).append(array).toHashCode());
    }

    @Test
    void testAppendIntArray() {
        final int[] array = {1, 2, 3};
        final int actual = new HashCodeBuilder(17, 37).append(array).toHashCode();
        final int expected = new HashCodeBuilder(17, 37).append(1).append(2).append(3).toHashCode();
        assertEquals(expected, actual);
    }

    @Test
    void testAppendLong() {
        final long value = 123456789L;
        final int actual = new HashCodeBuilder(17, 37).append(value).toHashCode();
        final int expected = 17 * 37 + (int) (value ^ value >> 32);
        assertEquals(expected, actual);
    }

    @Test
    void testAppendLongArrayNull() {
        final long[] array = null;
        assertEquals(17 * 37, new HashCodeBuilder(17, 37).append(array).toHashCode());
    }

    @Test
    void testAppendLongArray() {
        final long[] array = {1L, 2L};
        final int actual = new HashCodeBuilder(17, 37).append(array).toHashCode();
        final int expected = new HashCodeBuilder(17, 37).append(1L).append(2L).toHashCode();
        assertEquals(expected, actual);
    }

    @Test
    void testAppendShort() {
        final int result = new HashCodeBuilder(17, 37).append((short) 9).toHashCode();
        assertEquals(17 * 37 + 9, result);
    }

    @Test
    void testAppendShortArrayNull() {
        final short[] array = null;
        assertEquals(17 * 37, new HashCodeBuilder(17, 37).append(array).toHashCode());
    }

    @Test
    void testAppendShortArray() {
        final short[] array = {(short) 1, (short) 2};
        final int actual = new HashCodeBuilder(17, 37).append(array).toHashCode();
        final int expected = new HashCodeBuilder(17, 37).append((short) 1).append((short) 2).toHashCode();
        assertEquals(expected, actual);
    }

    // --- Append Object / Object[] ---

    @Test
    void testAppendObjectNull() {
        final Object obj = null;
        assertEquals(17 * 37, new HashCodeBuilder(17, 37).append(obj).toHashCode());
    }

    @Test
    void testAppendObjectUsesHashCode() {
        final String s = "hello";
        final int actual = new HashCodeBuilder(17, 37).append((Object) s).toHashCode();
        assertEquals(17 * 37 + s.hashCode(), actual);
    }

    @Test
    void testAppendObjectArrayNull() {
        final Object[] array = null;
        assertEquals(17 * 37, new HashCodeBuilder(17, 37).append(array).toHashCode());
    }

    @Test
    void testAppendObjectArrayDispatchesElementwise() {
        final Object[] array = {"a", "b", null};
        final int actual = new HashCodeBuilder(17, 37).append(array).toHashCode();
        final int expected = new HashCodeBuilder(17, 37).append((Object) "a").append((Object) "b").append((Object) null).toHashCode();
        assertEquals(expected, actual);
    }

    @Test
    void testAppendObjectDetectsPrimitiveArrayViaObjectOverload() {
        final int[] primitiveArray = {5, 6};
        final Object object = primitiveArray;
        final int viaAppendObject = new HashCodeBuilder(17, 37).append(object).toHashCode();
        final int viaAppendIntArray = new HashCodeBuilder(17, 37).append(primitiveArray).toHashCode();
        assertEquals(viaAppendIntArray, viaAppendObject);
    }

    @Test
    void testAppendObjectArrayWithSelfReferenceDoesNotInfiniteLoop() {
        final Object[] array = new Object[2];
        array[0] = "first";
        array[1] = array;
        final int result = new HashCodeBuilder(17, 37).append((Object) array).toHashCode();
        assertNotNull(Integer.valueOf(result));
    }

    // --- appendSuper ---

    @Test
    void testAppendSuper() {
        final int result = new HashCodeBuilder(17, 37).appendSuper(99).toHashCode();
        assertEquals(17 * 37 + 99, result);
    }

    // --- chaining / toHashCode ---

    @Test
    void testAppendReturnsSameInstanceForChaining() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        final HashCodeBuilder returned = builder.append(1);
        assertTrue(builder == returned);
    }

    @Test
    void testToHashCodeIsIdempotent() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37).append(5).append("x");
        final int first = builder.toHashCode();
        final int second = builder.toHashCode();
        assertEquals(first, second);
    }

    // --- build(), Builder<Integer> ---

    @Test
    void testBuildReturnsBoxedToHashCode() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37).append(7);
        assertEquals(Integer.valueOf(builder.toHashCode()), builder.build());
    }

    // --- equals()/hashCode() of HashCodeBuilder itself ---

    @Test
    void testEqualsSameTotalIsEqual() {
        final HashCodeBuilder a = new HashCodeBuilder(17, 37).append(5);
        final HashCodeBuilder b = new HashCodeBuilder(17, 37).append(5);
        assertTrue(a.equals(b));
        assertTrue(b.equals(a));
    }

    @Test
    void testEqualsDifferentTotalIsNotEqual() {
        final HashCodeBuilder a = new HashCodeBuilder(17, 37).append(5);
        final HashCodeBuilder b = new HashCodeBuilder(17, 37).append(6);
        assertFalse(a.equals(b));
    }

    @Test
    void testEqualsSameInstance() {
        final HashCodeBuilder a = new HashCodeBuilder(17, 37);
        assertTrue(a.equals(a));
    }

    @Test
    void testEqualsNullIsFalse() {
        final HashCodeBuilder a = new HashCodeBuilder(17, 37);
        assertFalse(a.equals(null));
    }

    @Test
    void testEqualsDifferentTypeIsFalse() {
        final HashCodeBuilder a = new HashCodeBuilder(17, 37);
        assertFalse(a.equals("not a builder"));
    }

    @Test
    void testHashCodeMatchesToHashCode() {
        final HashCodeBuilder a = new HashCodeBuilder(17, 37).append(5).append("foo");
        assertEquals(a.toHashCode(), a.hashCode());
    }

    // --- builder()/Builder static inner class ---

    @Test
    void testStaticBuilderFactoryProducesWorkingInstance() {
        final HashCodeBuilder.Builder metaBuilder = HashCodeBuilder.builder();
        metaBuilder.setInitialOddNumber(21).setMultiplierOddNumber(7);
        final HashCodeBuilder built = metaBuilder.get();
        assertEquals(21, built.toHashCode());
        built.append(1);
        assertEquals(21 * 7 + 1, built.toHashCode());
    }

    @Test
    void testStaticBuilderSettersReturnSameInstanceForChaining() {
        final HashCodeBuilder.Builder metaBuilder = HashCodeBuilder.builder();
        final HashCodeBuilder.Builder returned = metaBuilder.setInitialOddNumber(1).setMultiplierOddNumber(3);
        assertTrue(metaBuilder == returned);
    }

    // --- reflectionHashCode ---

    @Test
    void testReflectionHashCodeNullObjectThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                HashCodeBuilder.reflectionHashCode(null);
            }
        });
    }

    @Test
    void testReflectionHashCodeEvenInitialNumberThrows() {
        final ReflectionFixture fixture = new ReflectionFixture(1, "a");
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                HashCodeBuilder.reflectionHashCode(18, 37, fixture);
            }
        });
    }

    @Test
    void testReflectionHashCodeEvenMultiplierThrows() {
        final ReflectionFixture fixture = new ReflectionFixture(1, "a");
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                HashCodeBuilder.reflectionHashCode(17, 38, fixture);
            }
        });
    }

    @Test
    void testReflectionHashCodeConsistentAcrossCalls() {
        final ReflectionFixture fixture = new ReflectionFixture(1, "a");
        final int first = HashCodeBuilder.reflectionHashCode(fixture);
        final int second = HashCodeBuilder.reflectionHashCode(fixture);
        assertEquals(first, second);
    }

    @Test
    void testReflectionHashCodeDifferentFieldValuesDifferentHash() {
        final ReflectionFixture a = new ReflectionFixture(1, "a");
        final ReflectionFixture b = new ReflectionFixture(2, "b");
        assertNotEquals(HashCodeBuilder.reflectionHashCode(a), HashCodeBuilder.reflectionHashCode(b));
    }

    @Test
    void testReflectionHashCodeIgnoresExcludedField() {
        final ReflectionFixture a = new ReflectionFixture(1, "a");
        a.excludedField = 100;
        final ReflectionFixture b = new ReflectionFixture(1, "a");
        b.excludedField = 200;
        assertEquals(HashCodeBuilder.reflectionHashCode(a), HashCodeBuilder.reflectionHashCode(b));
    }

    @Test
    void testReflectionHashCodeIgnoresTransientByDefault() {
        final ReflectionFixture a = new ReflectionFixture(1, "a");
        a.transientField = 5;
        final ReflectionFixture b = new ReflectionFixture(1, "a");
        b.transientField = 999;
        assertEquals(HashCodeBuilder.reflectionHashCode(a), HashCodeBuilder.reflectionHashCode(b));
    }

    @Test
    void testReflectionHashCodeIncludesTransientWhenRequested() {
        final ReflectionFixture a = new ReflectionFixture(1, "a");
        a.transientField = 5;
        final ReflectionFixture b = new ReflectionFixture(1, "a");
        b.transientField = 999;
        assertNotEquals(HashCodeBuilder.reflectionHashCode(a, true), HashCodeBuilder.reflectionHashCode(b, true));
    }

    @Test
    void testReflectionHashCodeWithExcludeFieldsArray() {
        final ReflectionFixture a = new ReflectionFixture(1, "a");
        final ReflectionFixture b = new ReflectionFixture(2, "a");
        final String[] excludeFields = {"intField"};
        assertEquals(HashCodeBuilder.reflectionHashCode(a, excludeFields), HashCodeBuilder.reflectionHashCode(b, excludeFields));
    }

    @Test
    void testReflectionHashCodeWithExcludeFieldsCollection() {
        final ReflectionFixture a = new ReflectionFixture(1, "a");
        final ReflectionFixture b = new ReflectionFixture(2, "a");
        final List<String> excludeFields = Arrays.asList("intField");
        assertEquals(HashCodeBuilder.reflectionHashCode(a, excludeFields), HashCodeBuilder.reflectionHashCode(b, excludeFields));
    }

    @Test
    void testReflectionHashCodeIncludesSuperclassFieldsByDefault() {
        final ReflectionFixtureChild a = new ReflectionFixtureChild(1, "a", 10);
        final ReflectionFixtureChild b = new ReflectionFixtureChild(2, "a", 10);
        assertNotEquals(HashCodeBuilder.reflectionHashCode(a), HashCodeBuilder.reflectionHashCode(b));
    }

    @Test
    void testReflectionHashCodeStopsAtReflectUpToClass() {
        final ReflectionFixtureChild a = new ReflectionFixtureChild(1, "a", 10);
        final ReflectionFixtureChild b = new ReflectionFixtureChild(2, "a", 10);
        final int hashA = HashCodeBuilder.reflectionHashCode(17, 37, a, false, ReflectionFixtureChild.class);
        final int hashB = HashCodeBuilder.reflectionHashCode(17, 37, b, false, ReflectionFixtureChild.class);
        assertEquals(hashA, hashB);
    }

    @Test
    void testReflectionHashCodeHandlesCyclicReferencesWithoutStackOverflow() {
        final CyclicFixture x = new CyclicFixture();
        final CyclicFixture y = new CyclicFixture();
        x.self = y;
        y.self = x;
        final int result = HashCodeBuilder.reflectionHashCode(x);
        assertNotNull(Integer.valueOf(result));
    }

    @Test
    void testReflectionHashCodeIgnoresStaticFields() {
        final ReflectionFixture a = new ReflectionFixture(1, "a");
        ReflectionFixture.staticField = 1;
        final int before = HashCodeBuilder.reflectionHashCode(a);
        ReflectionFixture.staticField = 2;
        final int after = HashCodeBuilder.reflectionHashCode(a);
        assertEquals(before, after);
    }
}
