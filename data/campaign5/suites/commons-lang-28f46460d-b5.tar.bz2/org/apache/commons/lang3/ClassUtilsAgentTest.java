/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link ClassUtils}.
 */
public class ClassUtilsAgentTest {

    interface IA {
        // marker
    }

    interface IB extends IA {
        // marker
    }

    static class Base implements IB {
        // empty
    }

    static class Derived extends Base implements Comparable<Derived> {
        @Override
        public int compareTo(final Derived o) {
            return 0;
        }
    }

    static class Outer {
        class Inner {
            // empty
        }
    }

    @Test
    public void testComparator() {
        final List<Class<?>> list = new ArrayList<Class<?>>();
        list.add(String.class);
        list.add(Integer.class);
        list.add(Boolean.class);
        Collections.sort(list, ClassUtils.comparator());
        assertEquals(Boolean.class, list.get(0));
        assertEquals(Integer.class, list.get(1));
        assertEquals(String.class, list.get(2));
    }

    @Test
    public void testConvertClassesToClassNames() {
        assertNull(ClassUtils.convertClassesToClassNames(null));
        final List<Class<?>> classes = new ArrayList<Class<?>>();
        classes.add(String.class);
        classes.add(null);
        final List<String> names = ClassUtils.convertClassesToClassNames(classes);
        assertEquals(2, names.size());
        assertEquals("java.lang.String", names.get(0));
        assertNull(names.get(1));
    }

    @Test
    public void testConvertClassNamesToClasses() {
        assertNull(ClassUtils.convertClassNamesToClasses(null));
        final List<String> names = new ArrayList<String>();
        names.add("java.lang.String");
        names.add("not.a.real.ClassName");
        names.add(null);
        final List<Class<?>> classes = ClassUtils.convertClassNamesToClasses(names);
        assertEquals(3, classes.size());
        assertEquals(String.class, classes.get(0));
        assertNull(classes.get(1));
        assertNull(classes.get(2));
    }

    @Test
    public void testGetAbbreviatedNameClass() {
        assertEquals("", ClassUtils.getAbbreviatedName((Class<?>) null, 1));
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName(String.class, 5));
    }

    @Test
    public void testGetAbbreviatedNameString() {
        assertEquals("", ClassUtils.getAbbreviatedName((String) null, 1));
        assertEquals("java.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 30));
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName("java.lang.String", 5));
        assertEquals("j.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 13));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getAbbreviatedName("java.lang.String", 0);
            }
        });
    }

    @Test
    public void testGetAbbreviatedNameInvalidLengthThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getAbbreviatedName("java.lang.String", -1);
            }
        });
        assertNotNull(ex.getMessage());
    }

    @Test
    public void testGetAllInterfaces() {
        assertNull(ClassUtils.getAllInterfaces(null));
        final List<Class<?>> interfaces = ClassUtils.getAllInterfaces(Derived.class);
        assertEquals(3, interfaces.size());
        assertEquals(Comparable.class, interfaces.get(0));
        assertEquals(IB.class, interfaces.get(1));
        assertEquals(IA.class, interfaces.get(2));
    }

    @Test
    public void testGetAllSuperclasses() {
        assertNull(ClassUtils.getAllSuperclasses(null));
        final List<Class<?>> superclasses = ClassUtils.getAllSuperclasses(Derived.class);
        assertEquals(2, superclasses.size());
        assertEquals(Base.class, superclasses.get(0));
        assertEquals(Object.class, superclasses.get(1));
    }

    @Test
    public void testGetCanonicalName() {
        assertEquals("", ClassUtils.getCanonicalName((Class<?>) null));
        assertEquals("NULL", ClassUtils.getCanonicalName((Class<?>) null, "NULL"));
        assertEquals("int[]", ClassUtils.getCanonicalName(int[].class));
        assertEquals("", ClassUtils.getCanonicalName((Object) null));
        assertEquals("NULL", ClassUtils.getCanonicalName((Object) null, "NULL"));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName("hello"));
    }

    @Test
    public void testGetClassByName() throws ClassNotFoundException {
        assertEquals(String.class, ClassUtils.getClass("java.lang.String"));
        assertEquals(int[].class, ClassUtils.getClass("[I"));
        assertEquals(String[].class, ClassUtils.getClass("[Ljava.lang.String;"));
        assertEquals(String[].class, ClassUtils.getClass("java.lang.String[]"));
        assertEquals(int.class, ClassUtils.getClass("int"));
    }

    @Test
    public void testGetClassNotFound() {
        assertThrows(ClassNotFoundException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass("not.a.real.ClassName");
            }
        });
    }

    @Test
    public void testGetClassNullNameThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass((String) null);
            }
        });
    }

    @Test
    public void testGetClassEmptyNameThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass("");
            }
        });
    }

    @Test
    public void testGetClassNameTooLongThrows() {
        final StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 65536; i++) {
            sb.append('a');
        }
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass(sb.toString());
            }
        });
    }

    @Test
    public void testGetClassArrayDimensionTooLargeThrows() {
        final StringBuilder sb = new StringBuilder("java.lang.String");
        for (int i = 0; i < 256; i++) {
            sb.append("[]");
        }
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass(sb.toString());
            }
        });
    }

    @Test
    public void testGetComponentType() {
        assertNull(ClassUtils.getComponentType(null));
        assertEquals(String.class, ClassUtils.getComponentType(String[].class));
    }

    @Test
    public void testGetName() {
        assertEquals("", ClassUtils.getName((Class<?>) null));
        assertEquals("NULL", ClassUtils.getName((Class<?>) null, "NULL"));
        assertEquals("java.lang.String", ClassUtils.getName(String.class));
        assertEquals("", ClassUtils.getName((Object) null));
        assertEquals("NULL", ClassUtils.getName((Object) null, "NULL"));
        assertEquals("java.lang.String", ClassUtils.getName("hello"));
    }

    @Test
    public void testGetPackageCanonicalName() {
        assertEquals("", ClassUtils.getPackageCanonicalName((Class<?>) null));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName(String.class));
        assertEquals("NULL", ClassUtils.getPackageCanonicalName((Object) null, "NULL"));
        assertEquals("", ClassUtils.getPackageCanonicalName("[I"));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getPackageCanonicalName("[X");
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getPackageCanonicalName("[");
            }
        });
    }

    @Test
    public void testGetPackageName() {
        assertEquals("", ClassUtils.getPackageName((Class<?>) null));
        assertEquals("java.lang", ClassUtils.getPackageName(String.class));
        assertEquals("NULL", ClassUtils.getPackageName((Object) null, "NULL"));
        assertEquals("java.lang", ClassUtils.getPackageName("java.lang.String"));
        assertEquals("", ClassUtils.getPackageName("NoPackage"));
        assertEquals("", ClassUtils.getPackageName((String) null));
        assertEquals("", ClassUtils.getPackageName(""));
        assertEquals("java.lang", ClassUtils.getPackageName("[Ljava.lang.String;"));
    }

    @Test
    public void testGetPublicMethod() throws Exception {
        final Set<String> set = Collections.unmodifiableSet(new HashSet<String>());
        final Method method = ClassUtils.getPublicMethod(set.getClass(), "isEmpty");
        assertNotNull(method);
        assertTrue(Modifier.isPublic(method.getDeclaringClass().getModifiers()));
        assertEquals(Boolean.TRUE, method.invoke(set));
    }

    @Test
    public void testGetPublicMethodNoSuchMethod() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getPublicMethod(String.class, "notARealMethodName");
            }
        });
    }

    @Test
    public void testGetShortCanonicalName() {
        assertEquals("", ClassUtils.getShortCanonicalName((Class<?>) null));
        assertEquals("String", ClassUtils.getShortCanonicalName(String.class));
        assertEquals("NULL", ClassUtils.getShortCanonicalName((Object) null, "NULL"));
        assertEquals("String[]", ClassUtils.getShortCanonicalName("[Ljava.lang.String;"));
        assertEquals("int[]", ClassUtils.getShortCanonicalName("[I"));
    }

    @Test
    public void testGetShortClassNameClass() {
        assertEquals("", ClassUtils.getShortClassName((Class<?>) null));
        assertEquals("String", ClassUtils.getShortClassName(String.class));
        assertEquals("int[]", ClassUtils.getShortClassName(int[].class));
        assertEquals("String[][]", ClassUtils.getShortClassName(String[][].class));
        assertEquals("ClassUtilsAgentTest.Outer.Inner", ClassUtils.getShortClassName(Outer.Inner.class));
    }

    @Test
    public void testGetShortClassNameAnonymous() {
        final Runnable anon = new Runnable() {
            @Override
            public void run() {
                // no-op
            }
        };
        final String simpleName = anon.getClass().getSimpleName();
        final String expected = "ClassUtilsAgentTest." + anon.getClass().getName().substring(anon.getClass().getName().lastIndexOf('$') + 1);
        assertEquals("", simpleName);
        assertEquals(expected, ClassUtils.getShortClassName(anon.getClass()));
        assertTrue(expected.matches("ClassUtilsAgentTest\\.\\d+"));
    }

    @Test
    public void testGetShortClassNameObject() {
        assertEquals("NULL", ClassUtils.getShortClassName((Object) null, "NULL"));
        assertEquals("String", ClassUtils.getShortClassName("hello", "NULL"));
    }

    @Test
    public void testGetShortClassNameString() {
        assertEquals("", ClassUtils.getShortClassName((String) null));
        assertEquals("", ClassUtils.getShortClassName(""));
        assertEquals("String", ClassUtils.getShortClassName("java.lang.String"));
        assertEquals("Map.Entry", ClassUtils.getShortClassName("java.util.Map$Entry"));
        assertEquals("String[]", ClassUtils.getShortClassName("[Ljava.lang.String;"));
        assertEquals("int[]", ClassUtils.getShortClassName("[I"));
    }

    @Test
    public void testGetSimpleName() {
        assertEquals("", ClassUtils.getSimpleName((Class<?>) null));
        assertEquals("NULL", ClassUtils.getSimpleName((Class<?>) null, "NULL"));
        assertEquals("String", ClassUtils.getSimpleName(String.class));
        assertEquals("", ClassUtils.getSimpleName((Object) null));
        assertEquals("NULL", ClassUtils.getSimpleName((Object) null, "NULL"));
        assertEquals("String", ClassUtils.getSimpleName("hello"));
    }

    @Test
    public void testHierarchyExcludeInterfaces() {
        final List<Class<?>> result = new ArrayList<Class<?>>();
        final Iterator<Class<?>> it = ClassUtils.hierarchy(Derived.class).iterator();
        while (it.hasNext()) {
            result.add(it.next());
        }
        assertEquals(3, result.size());
        assertEquals(Derived.class, result.get(0));
        assertEquals(Base.class, result.get(1));
        assertEquals(Object.class, result.get(2));
    }

    @Test
    public void testHierarchyIncludeInterfaces() {
        final List<Class<?>> result = new ArrayList<Class<?>>();
        final Iterator<Class<?>> it = ClassUtils.hierarchy(Derived.class, ClassUtils.Interfaces.INCLUDE).iterator();
        while (it.hasNext()) {
            result.add(it.next());
        }
        assertEquals(6, result.size());
        assertEquals(Derived.class, result.get(0));
        assertEquals(Comparable.class, result.get(1));
        assertEquals(Base.class, result.get(2));
        assertEquals(IB.class, result.get(3));
        assertEquals(IA.class, result.get(4));
        assertEquals(Object.class, result.get(5));
    }

    @Test
    public void testHierarchyIteratorRemoveUnsupported() {
        final Iterator<Class<?>> it = ClassUtils.hierarchy(Derived.class).iterator();
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                it.remove();
            }
        });
    }

    @Test
    public void testIsAssignable() {
        assertFalse(ClassUtils.isAssignable(String.class, null));
        assertTrue(ClassUtils.isAssignable(null, String.class));
        assertFalse(ClassUtils.isAssignable(null, int.class));
        assertTrue(ClassUtils.isAssignable(int.class, long.class));
        assertFalse(ClassUtils.isAssignable(long.class, int.class));
        assertTrue(ClassUtils.isAssignable(Integer.class, int.class));
        assertFalse(ClassUtils.isAssignable(Integer.class, int.class, false));
        assertTrue(ClassUtils.isAssignable(int.class, int.class, false));
        assertFalse(ClassUtils.isAssignable(boolean.class, int.class));
        assertTrue(ClassUtils.isAssignable(String.class, Object.class));
    }

    @Test
    public void testIsAssignableArrays() {
        assertFalse(ClassUtils.isAssignable(new Class<?>[] {String.class}, new Class<?>[] {String.class, Integer.class}));
        assertTrue(ClassUtils.isAssignable(new Class<?>[] {int.class, String.class}, new Class<?>[] {long.class, Object.class}));
        assertTrue(ClassUtils.isAssignable((Class<?>[]) null, (Class<?>[]) null));
    }

    @Test
    public void testIsInnerClass() {
        assertFalse(ClassUtils.isInnerClass(null));
        assertFalse(ClassUtils.isInnerClass(String.class));
        assertTrue(ClassUtils.isInnerClass(Outer.Inner.class));
        assertTrue(ClassUtils.isInnerClass(Outer.class));
    }

    @Test
    public void testIsPrimitiveOrWrapper() {
        assertFalse(ClassUtils.isPrimitiveOrWrapper(null));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(int.class));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(Integer.class));
        assertFalse(ClassUtils.isPrimitiveOrWrapper(String.class));
    }

    @Test
    public void testIsPrimitiveWrapper() {
        assertFalse(ClassUtils.isPrimitiveWrapper(null));
        assertTrue(ClassUtils.isPrimitiveWrapper(Integer.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(int.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(String.class));
    }

    @Test
    public void testIsPublic() {
        assertTrue(ClassUtils.isPublic(String.class));
        assertFalse(ClassUtils.isPublic(Outer.Inner.class));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.isPublic(null);
            }
        });
    }

    @Test
    public void testPrimitivesToWrappers() {
        assertNull(ClassUtils.primitivesToWrappers((Class<?>[]) null));
        assertEquals(0, ClassUtils.primitivesToWrappers().length);
        final Class<?>[] result = ClassUtils.primitivesToWrappers(int.class, String.class, null);
        assertEquals(3, result.length);
        assertEquals(Integer.class, result[0]);
        assertEquals(String.class, result[1]);
        assertNull(result[2]);
    }

    @Test
    public void testPrimitiveToWrapper() {
        assertNull(ClassUtils.primitiveToWrapper(null));
        assertEquals(Integer.class, ClassUtils.primitiveToWrapper(int.class));
        assertEquals(String.class, ClassUtils.primitiveToWrapper(String.class));
        assertEquals(Void.TYPE, ClassUtils.primitiveToWrapper(Void.TYPE));
    }

    @Test
    public void testToClass() {
        assertNull(ClassUtils.toClass((Object[]) null));
        assertEquals(0, ClassUtils.toClass().length);
        final Class<?>[] result = ClassUtils.toClass("hello", Integer.valueOf(1), null);
        assertEquals(3, result.length);
        assertEquals(String.class, result[0]);
        assertEquals(Integer.class, result[1]);
        assertNull(result[2]);
    }

    @Test
    public void testWrappersToPrimitives() {
        assertNull(ClassUtils.wrappersToPrimitives((Class<?>[]) null));
        assertEquals(0, ClassUtils.wrappersToPrimitives().length);
        final Class<?>[] result = ClassUtils.wrappersToPrimitives(Integer.class, String.class, null);
        assertEquals(3, result.length);
        assertEquals(int.class, result[0]);
        assertNull(result[1]);
        assertNull(result[2]);
    }

    @Test
    public void testWrapperToPrimitive() {
        assertNull(ClassUtils.wrapperToPrimitive(null));
        assertEquals(int.class, ClassUtils.wrapperToPrimitive(Integer.class));
        assertNull(ClassUtils.wrapperToPrimitive(String.class));
        assertNull(ClassUtils.wrapperToPrimitive(Void.TYPE));
    }

    @Test
    public void testConstructor() {
        assertNotNull(new ClassUtils());
    }
}
