/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.junit.jupiter.api.Test;

/**
 * Self-contained test class for {@link StrSubstitutor}.
 */
@SuppressWarnings("deprecation")
class StrSubstitutorAgentTest {

    private Map<String, Object> newMap() {
        final Map<String, Object> map = new HashMap<>();
        map.put("animal", "quick brown fox");
        map.put("target", "lazy dog");
        return map;
    }

    @Test
    void testReplaceStringHappyPath() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final String result = sub.replace("The ${animal} jumps over the ${target}.");
        assertEquals("The quick brown fox jumps over the lazy dog.", result);
    }

    @Test
    void testReplaceReturnsSameInstanceWhenNoSubstitution() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final String source = "No variables here.";
        final String result = sub.replace(source);
        assertSame(source, result);
    }

    @Test
    void testReplaceNullSourceReturnsNull() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        assertNull(sub.replace((String) null));
        assertNull(sub.replace((Object) null));
        assertNull(sub.replace((char[]) null));
        assertNull(sub.replace((StrBuilder) null));
        assertNull(sub.replace((StringBuffer) null));
    }

    @Test
    void testUnknownVariableLeftUnresolved() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final String result = sub.replace("Hello ${unknown}!");
        assertEquals("Hello ${unknown}!", result);
    }

    @Test
    void testDefaultValueDelimiterResolvesUnknown() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final String result = sub.replace("${undefined.number:-1234567890}");
        assertEquals("1234567890", result);
    }

    @Test
    void testDefaultValueDelimiterIgnoredWhenVariableKnown() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final String result = sub.replace("${animal:-ignored}");
        assertEquals("quick brown fox", result);
    }

    @Test
    void testEscapeCharacterPreventsSubstitutionByDefault() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final String result = sub.replace("$${${animal}}");
        assertEquals("${quick brown fox}", result);
    }

    @Test
    void testPreserveEscapesKeepsEscapeCharacter() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        assertFalse(sub.isPreserveEscapes());
        sub.setPreserveEscapes(true);
        assertTrue(sub.isPreserveEscapes());
        final String result = sub.replace("$${${animal}}");
        assertEquals("$${quick brown fox}", result);
    }

    @Test
    void testCustomPrefixAndSuffix() {
        final Map<String, Object> map = newMap();
        final StrSubstitutor sub = new StrSubstitutor(map, "<", ">");
        final String result = sub.replace("The <animal> jumps over the <target>.");
        assertEquals("The quick brown fox jumps over the lazy dog.", result);
    }

    @Test
    void testRecursiveVariableValue() {
        final Map<String, Object> map = new HashMap<>();
        map.put("name", "x");
        map.put("x", "value-of-x");
        final StrSubstitutor sub = new StrSubstitutor(map);
        // name's value "x" is itself resolved as a variable reference in the source text
        final String result = sub.replace("${name} and ${x}");
        assertEquals("x and value-of-x", result);
    }

    @Test
    void testCyclicSubstitutionThrows() {
        final Map<String, Object> map = new HashMap<>();
        map.put("a", "${b}");
        map.put("b", "${a}");
        final StrSubstitutor sub = new StrSubstitutor(map);
        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sub.replace("${a}");
            }
        });
    }

    @Test
    void testEnableSubstitutionInVariableNames() {
        final Map<String, Object> map = new HashMap<>();
        map.put("name", "x");
        map.put("jre-x", "resolved");
        final StrSubstitutor sub = new StrSubstitutor(map);
        assertFalse(sub.isEnableSubstitutionInVariables());
        sub.setEnableSubstitutionInVariables(true);
        assertTrue(sub.isEnableSubstitutionInVariables());
        final String result = sub.replace("${jre-${name}}");
        assertEquals("resolved", result);
    }

    @Test
    void testReplaceInStrBuilderAltersAndReturnsTrue() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final StrBuilder builder = new StrBuilder("The ${animal}.");
        final boolean altered = sub.replaceIn(builder);
        assertTrue(altered);
        assertEquals("The quick brown fox.", builder.toString());
    }

    @Test
    void testReplaceInStrBuilderNoChangeReturnsFalse() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final StrBuilder builder = new StrBuilder("no vars");
        final boolean altered = sub.replaceIn(builder);
        assertFalse(altered);
        assertEquals("no vars", builder.toString());
    }

    @Test
    void testReplaceInNullStrBuilderReturnsFalse() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        assertFalse(sub.replaceIn((StrBuilder) null));
    }

    @Test
    void testReplaceInStringBuffer() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final StringBuffer buffer = new StringBuffer("The ${animal}.");
        final boolean altered = sub.replaceIn(buffer);
        assertTrue(altered);
        assertEquals("The quick brown fox.", buffer.toString());
    }

    @Test
    void testReplaceInNullStringBufferReturnsFalse() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        assertFalse(sub.replaceIn((StringBuffer) null));
    }

    @Test
    void testReplaceInStringBuilder() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final StringBuilder builder = new StringBuilder("The ${animal}.");
        final boolean altered = sub.replaceIn(builder);
        assertTrue(altered);
        assertEquals("The quick brown fox.", builder.toString());
    }

    @Test
    void testReplaceInNullStringBuilderReturnsFalse() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        assertFalse(sub.replaceIn((StringBuilder) null));
    }

    @Test
    void testReplaceInWithOffsetAndLengthOnlyProcessesPortion() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final StringBuilder builder = new StringBuilder("X${animal}Y${target}Z");
        // only process the "${animal}" part (indices 1..10)
        final boolean altered = sub.replaceIn(builder, 1, 9);
        assertTrue(altered);
        assertEquals("Xquick brown foxY${target}Z", builder.toString());
    }

    @Test
    void testReplaceCharArrayWithOffsetAndLength() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final char[] source = "${animal}Y${target}Z".toCharArray();
        // only the first 9 chars ("${animal}") are processed; the rest is discarded, not just skipped
        final String result = sub.replace(source, 0, 9);
        assertEquals("quick brown fox", result);
        // without the length restriction, the whole array is substituted
        final String resultFull = sub.replace(source);
        assertEquals("quick brown foxYlazy dogZ", resultFull);
    }

    @Test
    void testReplaceCharSequenceWithOffsetAndLength() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final CharSequence source = "X${animal}Y";
        final String result = sub.replace(source, 1, 9);
        assertEquals("quick brown fox", result);
    }

    @Test
    void testReplaceStringBufferSource() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final StringBuffer source = new StringBuffer("${animal}");
        final String result = sub.replace(source);
        assertEquals("quick brown fox", result);
    }

    @Test
    void testReplaceStrBuilderSource() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final StrBuilder source = new StrBuilder("${animal}");
        final String result = sub.replace(source);
        assertEquals("quick brown fox", result);
    }

    @Test
    void testStaticReplaceWithMap() {
        final String result = StrSubstitutor.replace("${animal}", newMap());
        assertEquals("quick brown fox", result);
    }

    @Test
    void testStaticReplaceWithMapAndCustomDelimiters() {
        final String result = StrSubstitutor.replace("<animal>", newMap(), "<", ">");
        assertEquals("quick brown fox", result);
    }

    @Test
    void testStaticReplaceWithProperties() {
        final Properties props = new Properties();
        props.setProperty("key", "value");
        final String result = StrSubstitutor.replace("${key}", props);
        assertEquals("value", result);
    }

    @Test
    void testStaticReplaceWithNullPropertiesReturnsSourceToString() {
        final String result = StrSubstitutor.replace("${key}", (Properties) null);
        assertEquals("${key}", result);
    }

    @Test
    void testStaticReplaceSystemProperties() {
        final String javaVersion = System.getProperty("java.version");
        final String result = StrSubstitutor.replaceSystemProperties("Version: ${java.version}");
        assertEquals("Version: " + javaVersion, result);
    }

    @Test
    void testGettersAndDefaultConstructorDefaults() {
        final StrSubstitutor sub = new StrSubstitutor();
        assertEquals(StrSubstitutor.DEFAULT_ESCAPE, sub.getEscapeChar());
        assertSame(StrSubstitutor.DEFAULT_PREFIX, sub.getVariablePrefixMatcher());
        assertSame(StrSubstitutor.DEFAULT_SUFFIX, sub.getVariableSuffixMatcher());
        assertSame(StrSubstitutor.DEFAULT_VALUE_DELIMITER, sub.getValueDelimiterMatcher());
        assertNull(sub.getVariableResolver());
    }

    @Test
    void testSetVariablePrefixCharUpdatesMatcher() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final StrSubstitutor returned = sub.setVariablePrefix('<');
        assertSame(sub, returned);
        sub.setVariableSuffix('>');
        final String result = sub.replace("<animal>");
        assertEquals("quick brown fox", result);
    }

    @Test
    void testSetVariablePrefixNullThrows() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sub.setVariablePrefix((String) null);
            }
        });
    }

    @Test
    void testSetVariableSuffixNullThrows() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sub.setVariableSuffix((String) null);
            }
        });
    }

    @Test
    void testSetVariablePrefixMatcherNullThrows() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sub.setVariablePrefixMatcher(null);
            }
        });
    }

    @Test
    void testSetVariableSuffixMatcherNullThrows() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sub.setVariableSuffixMatcher(null);
            }
        });
    }

    @Test
    void testSetValueDelimiterEmptyStringDisablesDefaultValue() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final StrSubstitutor returned = sub.setValueDelimiter("");
        assertSame(sub, returned);
        assertNull(sub.getValueDelimiterMatcher());
        final String result = sub.replace("${missing:-fallback}");
        assertEquals("${missing:-fallback}", result);
    }

    @Test
    void testSetValueDelimiterCharWorks() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        sub.setValueDelimiter('=');
        final String result = sub.replace("${missing=fallback}");
        assertEquals("fallback", result);
    }

    @Test
    void testSetVariableResolver() {
        final StrSubstitutor sub = new StrSubstitutor();
        assertNull(sub.getVariableResolver());
        final StrLookup<Object> lookup = StrLookup.mapLookup(newMap());
        sub.setVariableResolver(lookup);
        assertSame(lookup, sub.getVariableResolver());
        assertEquals("quick brown fox", sub.replace("${animal}"));
    }

    @Test
    void testEmptySourceStringReturnsEmpty() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        assertEquals("", sub.replace(""));
    }

    @Test
    void testUnterminatedVariableLeftAsIs() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final String result = sub.replace("${animal");
        assertEquals("${animal", result);
    }

    @Test
    void testReplaceStringWithOffsetAndLengthOutOfRangePortion() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final String source = "AB${animal}CD";
        final String result = sub.replace(source, 2, 9);
        assertEquals("quick brown fox", result);
    }

    @Test
    void testReplaceStringWithOffsetAndLengthNoAlterationReturnsSubstring() {
        final StrSubstitutor sub = new StrSubstitutor(newMap());
        final String source = "ABCDEFGH";
        final String result = sub.replace(source, 2, 3);
        assertEquals("CDE", result);
    }

    @Test
    void testNullValueMapConstructorStillWorks() {
        final StrSubstitutor sub = new StrSubstitutor((Map<String, Object>) null);
        final String result = sub.replace("${anything}");
        assertEquals("${anything}", result);
    }
}
