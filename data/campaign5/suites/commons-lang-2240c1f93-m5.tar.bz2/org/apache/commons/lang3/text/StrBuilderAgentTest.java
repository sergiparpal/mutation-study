/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link StrBuilder}.
 */
class StrBuilderAgentTest {

    @Test
    void testConstructorsAndLength() {
        StrBuilder empty = new StrBuilder();
        assertEquals(0, empty.length());
        assertTrue(empty.isEmpty());

        StrBuilder fromString = new StrBuilder("abc");
        assertEquals(3, fromString.length());
        assertEquals("abc", fromString.toString());

        StrBuilder fromNull = new StrBuilder((String) null);
        assertEquals(0, fromNull.length());

        StrBuilder withCapacity = new StrBuilder(32);
        assertTrue(withCapacity.capacity() >= 32);
        assertEquals(0, withCapacity.length());
    }

    @Test
    void testAppendVariants() {
        StrBuilder sb = new StrBuilder();
        sb.append("abc").append(123).append(' ').append(true).append((Object) null);
        assertEquals("abc123 true", sb.toString());

        StrBuilder sb2 = new StrBuilder();
        sb2.append(new char[] {'x', 'y', 'z'});
        assertEquals("xyz", sb2.toString());

        StrBuilder sb3 = new StrBuilder();
        sb3.append("hello world", 0, 5);
        assertEquals("hello", sb3.toString());
    }

    @Test
    void testAppendNullTextDefaultsToEmpty() {
        StrBuilder sb = new StrBuilder();
        sb.append((String) null);
        assertEquals(0, sb.length());
        assertEquals("", sb.toString());
    }

    @Test
    void testAppendNullCustomNullText() {
        StrBuilder sb = new StrBuilder();
        sb.setNullText("NULL");
        assertEquals("NULL", sb.getNullText());
        sb.append((Object) null);
        assertEquals("NULL", sb.toString());
    }

    @Test
    void testInsertAndDelete() {
        StrBuilder sb = new StrBuilder("abcdef");
        sb.insert(3, "-X-");
        assertEquals("abc-X-def", sb.toString());

        sb.deleteCharAt(0);
        assertEquals("bc-X-def", sb.toString());

        sb.delete(0, 2);
        assertEquals("-X-def", sb.toString());

        StrBuilder sb2 = new StrBuilder("aabbaa");
        sb2.deleteAll('a');
        assertEquals("bb", sb2.toString());

        StrBuilder sb3 = new StrBuilder("foobarfoo");
        sb3.deleteAll("foo");
        assertEquals("bar", sb3.toString());
    }

    @Test
    void testDeleteCharAtOutOfBoundsThrows() {
        final StrBuilder sb = new StrBuilder("abc");
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                sb.deleteCharAt(10);
            }
        });
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                sb.deleteCharAt(-1);
            }
        });
    }

    @Test
    void testCharAtOutOfBoundsThrows() {
        final StrBuilder sb = new StrBuilder("abc");
        assertEquals('a', sb.charAt(0));
        assertEquals('c', sb.charAt(2));
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                sb.charAt(3);
            }
        });
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                sb.charAt(-1);
            }
        });
    }

    @Test
    void testReplace() {
        StrBuilder sb = new StrBuilder("abcdef");
        sb.replace(1, 3, "XY");
        assertEquals("aXYdef", sb.toString());

        StrBuilder sb2 = new StrBuilder("foobarfoo");
        sb2.replaceAll("foo", "X");
        assertEquals("XbarX", sb2.toString());

        StrBuilder sb3 = new StrBuilder("aaa");
        sb3.replaceFirst("a", "b");
        assertEquals("baa", sb3.toString());

        StrBuilder sb4 = new StrBuilder("aaa");
        sb4.replaceAll('a', 'b');
        assertEquals("bbb", sb4.toString());
    }

    @Test
    void testReverse() {
        assertEquals("cba", new StrBuilder("abc").reverse().toString());
        assertEquals("", new StrBuilder("").reverse().toString());
        assertEquals("a", new StrBuilder("a").reverse().toString());
    }

    @Test
    void testIndexOfAndContains() {
        StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(1, sb.indexOf('b'));
        assertEquals(4, sb.indexOf('b', 2));
        assertEquals(-1, sb.indexOf('z'));

        assertEquals(0, sb.indexOf("abc"));
        assertEquals(3, sb.indexOf("abc", 1));
        assertEquals(-1, sb.indexOf("xyz"));

        assertTrue(sb.contains('a'));
        assertFalse(sb.contains('z'));
        assertTrue(sb.contains("bca"));
        assertFalse(sb.contains("zzz"));

        assertEquals(4, sb.lastIndexOf('b'));
        assertEquals(3, sb.lastIndexOf("abc"));
    }

    @Test
    void testStartsWithEndsWith() {
        StrBuilder sb = new StrBuilder("hello world");
        assertTrue(sb.startsWith("hello"));
        assertFalse(sb.startsWith("world"));
        assertTrue(sb.endsWith("world"));
        assertFalse(sb.endsWith("hello"));
    }

    @Test
    void testSubstringVariants() {
        StrBuilder sb = new StrBuilder("hello world");
        assertEquals("hello", sb.leftString(5));
        assertEquals("world", sb.rightString(5));
        assertEquals("lo wo", sb.midString(3, 5));
        assertEquals("world", sb.substring(6));
        assertEquals("hello", sb.substring(0, 5));

        assertEquals("", sb.leftString(0));
        assertEquals("hello world", sb.leftString(1000));
        assertEquals("", sb.rightString(-5));
    }

    @Test
    void testSetLengthAndEnsureCapacity() {
        StrBuilder sb = new StrBuilder("abcdef");
        sb.setLength(3);
        assertEquals("abc", sb.toString());
        assertEquals(3, sb.length());

        sb.setLength(5);
        assertEquals(5, sb.length());

        sb.ensureCapacity(100);
        assertTrue(sb.capacity() >= 100);
    }

    @Test
    void testSetLengthNegativeThrows() {
        final StrBuilder sb = new StrBuilder("abc");
        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                sb.setLength(-1);
            }
        });
    }

    @Test
    void testClearAndIsEmpty() {
        StrBuilder sb = new StrBuilder("abc");
        assertFalse(sb.isEmpty());
        StrBuilder result = sb.clear();
        assertSame(sb, result);
        assertTrue(sb.isEmpty());
        assertEquals(0, sb.length());
        assertEquals("", sb.toString());
    }

    @Test
    void testEqualsAndHashCode() {
        StrBuilder sb1 = new StrBuilder("abc");
        StrBuilder sb2 = new StrBuilder("abc");
        StrBuilder sb3 = new StrBuilder("abd");

        assertTrue(sb1.equals(sb2));
        assertTrue(sb1.equals((Object) sb2));
        assertFalse(sb1.equals(sb3));
        assertFalse(sb1.equals((Object) "abc"));
        assertFalse(sb1.equals((Object) null));
        assertEquals(sb1.hashCode(), sb2.hashCode());

        assertTrue(sb1.equalsIgnoreCase(new StrBuilder("ABC")));
        assertFalse(sb1.equalsIgnoreCase(sb3));
    }

    @Test
    void testToCharArrayAndGetChars() {
        StrBuilder sb = new StrBuilder("abcdef");
        char[] all = sb.toCharArray();
        assertEquals(6, all.length);
        assertEquals('a', all[0]);

        char[] part = sb.toCharArray(1, 4);
        assertEquals(3, part.length);
        assertEquals('b', part[0]);
        assertEquals('d', part[2]);

        char[] dest = new char[6];
        sb.getChars(dest);
        assertEquals('a', dest[0]);
        assertEquals('f', dest[5]);
    }

    @Test
    void testAppendSeparator() {
        StrBuilder sb = new StrBuilder();
        for (int i = 0; i < 3; i++) {
            sb.appendSeparator(",");
            sb.append(i);
        }
        assertEquals("0,1,2", sb.toString());
    }

    @Test
    void testBuildAndSize() {
        StrBuilder sb = new StrBuilder("hello");
        assertEquals("hello", sb.build());
        assertEquals(5, sb.size());
    }

    @Test
    void testTrim() {
        assertEquals("abc", new StrBuilder("  abc  ").trim().toString());
        assertEquals("", new StrBuilder("   ").trim().toString());
        assertEquals("", new StrBuilder("").trim().toString());
    }

    @Test
    void testMinimizeCapacity() {
        StrBuilder sb = new StrBuilder(100);
        sb.append("abc");
        sb.minimizeCapacity();
        assertEquals(3, sb.capacity());
        assertEquals("abc", sb.toString());
    }

    @Test
    void testAppendPadding() {
        StrBuilder sb = new StrBuilder();
        sb.appendPadding(3, 'x');
        assertEquals("xxx", sb.toString());

        StrBuilder sb2 = new StrBuilder();
        sb2.appendPadding(-1, 'x');
        assertEquals(0, sb2.length());
    }

    @Test
    void testAppendFixedWidthPad() {
        StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft(5, 4, '0');
        assertEquals("0005", sb.toString());

        StrBuilder sb2 = new StrBuilder();
        sb2.appendFixedWidthPadRight(5, 4, '0');
        assertEquals("5000", sb2.toString());
    }
}
