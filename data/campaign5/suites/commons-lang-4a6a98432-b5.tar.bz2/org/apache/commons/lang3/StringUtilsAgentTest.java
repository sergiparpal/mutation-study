/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link StringUtils}.
 */
class StringUtilsAgentTest {

    @Test
    void testAbbreviate() {
        assertNull(StringUtils.abbreviate(null, 4));
        assertEquals("", StringUtils.abbreviate("", 4));
        assertEquals("abc...", StringUtils.abbreviate("abcdefg", 6));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", 7));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", 8));
        assertEquals("a...", StringUtils.abbreviate("abcdefg", 4));
        try {
            StringUtils.abbreviate("abcdefg", 3);
            fail("expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    void testAbbreviateWithOffset() {
        assertNull(StringUtils.abbreviate(null, 2, 10));
        assertEquals("", StringUtils.abbreviate("", 0, 4));
        assertEquals("abcdefg...", StringUtils.abbreviate("abcdefghijklmno", -1, 10));
        assertEquals("...ijklmno", StringUtils.abbreviate("abcdefghijklmno", 12, 10));
        try {
            StringUtils.abbreviate("abcdefghij", 5, 6);
            fail("expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    void testAbbreviateMiddle() {
        assertNull(StringUtils.abbreviateMiddle(null, ".", 10));
        assertEquals("abc", StringUtils.abbreviateMiddle("abc", ".", 0));
        assertEquals("abc", StringUtils.abbreviateMiddle("abc", null, 10));
        assertEquals("abc", StringUtils.abbreviateMiddle("abc", ".", 10));
        assertEquals("ab.f", StringUtils.abbreviateMiddle("abcdef", ".", 4));
    }

    @Test
    void testAppendIfMissing() {
        assertNull(StringUtils.appendIfMissing(null, "xyz"));
        assertEquals("abcxyz", StringUtils.appendIfMissing("abc", "xyz"));
        assertEquals("abcxyz", StringUtils.appendIfMissing("abcxyz", "xyz"));
        assertEquals("abcXYZ", StringUtils.appendIfMissing("abcXYZ", "xyz"));
        assertEquals("abcXYZ", StringUtils.appendIfMissingIgnoreCase("abcXYZ", "xyz"));
    }

    @Test
    void testCapitalizeAndUncapitalize() {
        assertNull(StringUtils.capitalize(null));
        assertEquals("", StringUtils.capitalize(""));
        assertEquals("Cat", StringUtils.capitalize("cat"));
        assertEquals("CAt", StringUtils.capitalize("CAt"));
        assertNull(StringUtils.uncapitalize(null));
        assertEquals("", StringUtils.uncapitalize(""));
        assertEquals("cat", StringUtils.uncapitalize("Cat"));
        assertEquals("cAT", StringUtils.uncapitalize("CAT"));
    }

    @Test
    void testCenter() {
        assertNull(StringUtils.center(null, 4));
        assertEquals("    ", StringUtils.center("", 4));
        assertEquals("ab", StringUtils.center("ab", -1));
        assertEquals("  ab  ", StringUtils.center("ab", 6));
        assertEquals("xxabxx", StringUtils.center("ab", 6, 'x'));
        assertEquals("ab", StringUtils.center("ab", 2));
        assertEquals("ab", StringUtils.center("a", 1));
    }

    @Test
    void testChompAndChop() {
        assertNull(StringUtils.chomp(null));
        assertEquals("", StringUtils.chomp(""));
        assertEquals("abc", StringUtils.chomp("abc\r\n"));
        assertEquals("abc", StringUtils.chomp("abc\n"));
        assertEquals("abc\r", StringUtils.chomp("abc\r"));

        assertNull(StringUtils.chop(null));
        assertEquals("", StringUtils.chop(""));
        assertEquals("abc", StringUtils.chop("abcx"));
        assertEquals("", StringUtils.chop("x"));
        assertEquals("abc", StringUtils.chop("abc\r\n"));
    }

    @Test
    void testCompare() {
        assertEquals(0, StringUtils.compare(null, null));
        assertTrue(StringUtils.compare(null, "a") < 0);
        assertTrue(StringUtils.compare("a", null) > 0);
        assertTrue(StringUtils.compare("a", "b") < 0);
        assertEquals(0, StringUtils.compare("a", "a"));

        assertEquals(0, StringUtils.compare(null, null, false));
        assertTrue(StringUtils.compare(null, "a", true) < 0);
        assertTrue(StringUtils.compare(null, "a", false) > 0);
    }

    @Test
    void testCompareIgnoreCase() {
        assertEquals(0, StringUtils.compareIgnoreCase("ABC", "abc"));
        assertTrue(StringUtils.compareIgnoreCase(null, "a") < 0);
        assertTrue(StringUtils.compareIgnoreCase(null, "a", false) > 0);
    }

    @Test
    void testContains() {
        assertFalse(StringUtils.contains(null, null));
        assertFalse(StringUtils.contains("abc", null));
        assertFalse(StringUtils.contains(null, "a"));
        assertTrue(StringUtils.contains("abc", "a"));
        assertTrue(StringUtils.contains("abc", ""));
        assertFalse(StringUtils.contains("abc", 'z'));
        assertTrue(StringUtils.contains("abc", 'b'));
    }

    @Test
    void testContainsAnyAndNoneAndOnly() {
        assertFalse(StringUtils.containsAny(null, 'a'));
        assertFalse(StringUtils.containsAny("abc", (char[]) null));
        assertTrue(StringUtils.containsAny("abc", 'z', 'c'));
        assertTrue(StringUtils.containsAny("abc", "cz"));
        assertTrue(StringUtils.containsAny("abc", "cz", "xy"));
        assertTrue(StringUtils.containsAnyIgnoreCase("ABC", "xy", "bc"));

        assertTrue(StringUtils.containsNone(null, 'a'));
        assertFalse(StringUtils.containsNone("abc", 'a'));
        assertTrue(StringUtils.containsNone("abc", "xyz"));

        assertTrue(StringUtils.containsOnly("abab", 'a', 'b'));
        assertFalse(StringUtils.containsOnly("abcab", 'a', 'b'));
        assertFalse(StringUtils.containsOnly((CharSequence) null, 'a'));
        assertTrue(StringUtils.containsOnly("abab", "ab"));
    }

    @Test
    void testContainsIgnoreCaseAndWhitespace() {
        assertFalse(StringUtils.containsIgnoreCase(null, "a"));
        assertTrue(StringUtils.containsIgnoreCase("ABC", "bc"));
        assertFalse(StringUtils.containsWhitespace(""));
        assertTrue(StringUtils.containsWhitespace("ab c"));
    }

    @Test
    void testCountMatches() {
        assertEquals(0, StringUtils.countMatches(null, 'a'));
        assertEquals(0, StringUtils.countMatches("", 'a'));
        assertEquals(3, StringUtils.countMatches("abaabaa", 'a'));
        assertEquals(0, StringUtils.countMatches(null, "ab"));
        assertEquals(0, StringUtils.countMatches("abba", ""));
        assertEquals(2, StringUtils.countMatches("abaabaa", "aa"));
    }

    @Test
    void testDefaultIfBlankAndEmpty() {
        assertEquals("default", StringUtils.defaultIfBlank(null, "default"));
        assertEquals("default", StringUtils.defaultIfBlank("  ", "default"));
        assertEquals("abc", StringUtils.defaultIfBlank("abc", "default"));
        assertNull(StringUtils.defaultIfBlank(null, null));

        assertEquals("default", StringUtils.defaultIfEmpty(null, "default"));
        assertEquals("", StringUtils.defaultIfEmpty("", ""));
        assertEquals("abc", StringUtils.defaultIfEmpty("abc", "default"));
    }

    @Test
    void testDefaultString() {
        assertEquals("", StringUtils.defaultString(null));
        assertEquals("abc", StringUtils.defaultString("abc"));
        assertEquals("NULL", StringUtils.defaultString(null, "NULL"));
        assertEquals("abc", StringUtils.defaultString("abc", "NULL"));
    }

    @Test
    void testDeleteWhitespace() {
        assertNull(StringUtils.deleteWhitespace(null));
        assertEquals("", StringUtils.deleteWhitespace(""));
        assertEquals("abc", StringUtils.deleteWhitespace("  a b  c  "));
    }

    @Test
    void testDifference() {
        assertNull(StringUtils.difference(null, null));
        assertEquals("", StringUtils.difference("", ""));
        assertEquals("abc", StringUtils.difference(null, "abc"));
        assertEquals("", StringUtils.difference("abc", null));
        assertEquals("", StringUtils.difference("abc", "abc"));
        assertEquals("t", StringUtils.difference("ab", "abt"));
        assertEquals("", StringUtils.difference("abcde", "abcd"));
    }

    @Test
    void testEndsWith() {
        assertTrue(StringUtils.endsWith(null, null));
        assertFalse(StringUtils.endsWith(null, "abc"));
        assertTrue(StringUtils.endsWith("abcdef", "def"));
        assertFalse(StringUtils.endsWith("ABCDEF", "def"));
        assertTrue(StringUtils.endsWithIgnoreCase("ABCDEF", "def"));
        assertTrue(StringUtils.endsWithAny("abcxyz", "xyz", "123"));
        assertFalse(StringUtils.endsWithAny("abcxyz", "aaa", "123"));
    }

    @Test
    void testEqualsFamily() {
        assertTrue(StringUtils.equals(null, null));
        assertFalse(StringUtils.equals(null, "abc"));
        assertTrue(StringUtils.equals("abc", "abc"));
        assertFalse(StringUtils.equals("abc", "abd"));

        assertFalse(StringUtils.equalsIgnoreCase(null, "abc"));
        assertTrue(StringUtils.equalsIgnoreCase("ABC", "abc"));

        assertTrue(StringUtils.equalsAny("abc", "xyz", "abc"));
        assertFalse(StringUtils.equalsAny("abc", "xyz", "def"));
        assertTrue(StringUtils.equalsAnyIgnoreCase("ABC", "xyz", "abc"));
    }

    @Test
    void testFirstNonBlankAndEmpty() {
        assertNull(StringUtils.firstNonBlank());
        assertNull(StringUtils.firstNonBlank(null, "", "  "));
        assertEquals("abc", StringUtils.firstNonBlank(null, "", "abc"));
        assertNull(StringUtils.firstNonEmpty());
        assertEquals("abc", StringUtils.firstNonEmpty(null, "", "abc"));
    }

    @Test
    void testGetCommonPrefix() {
        assertEquals("", StringUtils.getCommonPrefix((String[]) null));
        assertEquals("", StringUtils.getCommonPrefix());
        assertEquals("", StringUtils.getCommonPrefix("abc", null));
        assertEquals("i am a ", StringUtils.getCommonPrefix("i am a machine", "i am a robot"));
        assertEquals("", StringUtils.getCommonPrefix("abc", "xyz"));
    }

    @Test
    void testGetDigits() {
        assertNull(StringUtils.getDigits(null));
        assertEquals("", StringUtils.getDigits(""));
        assertEquals("12345", StringUtils.getDigits("12 34 56-78/9 a b"));
        assertEquals("", StringUtils.getDigits("abc"));
    }

    @Test
    void testGetLevenshteinDistance() {
        assertEquals(0, StringUtils.getLevenshteinDistance("", ""));
        assertEquals(1, StringUtils.getLevenshteinDistance("", "a"));
        assertEquals(7, StringUtils.getLevenshteinDistance("aaapppp", ""));
        assertEquals(1, StringUtils.getLevenshteinDistance("frog", "fog"));
        assertEquals(7, StringUtils.getLevenshteinDistance("elephant", "hippo"));
        try {
            StringUtils.getLevenshteinDistance(null, "a");
            fail("expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }

        assertEquals(0, StringUtils.getLevenshteinDistance("", "", 0));
        assertEquals(7, StringUtils.getLevenshteinDistance("aaapppp", "", 8));
        assertEquals(-1, StringUtils.getLevenshteinDistance("aaapppp", "", 6));
        assertEquals(7, StringUtils.getLevenshteinDistance("elephant", "hippo", 7));
        assertEquals(-1, StringUtils.getLevenshteinDistance("elephant", "hippo", 6));
        try {
            StringUtils.getLevenshteinDistance("a", "b", -1);
            fail("expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    void testIndexOf() {
        assertEquals(-1, StringUtils.indexOf(null, "a"));
        assertEquals(-1, StringUtils.indexOf("abc", null));
        assertEquals(0, StringUtils.indexOf("", ""));
        assertEquals(2, StringUtils.indexOf("aabaabaa", "b"));
        assertEquals(5, StringUtils.indexOf("aabaabaa", "b", 3));
        assertEquals(-1, StringUtils.indexOf((CharSequence) null, 'a'));
        assertEquals(2, StringUtils.indexOf("aabaabaa", 'b'));
        assertEquals(5, StringUtils.indexOf("aabaabaa", 'b', 3));
    }

    @Test
    void testIndexOfAnyAndAnyBut() {
        assertEquals(-1, StringUtils.indexOfAny(null, (char[]) null));
        assertEquals(0, StringUtils.indexOfAny("zzabyycdxx", 'z', 'a'));
        assertEquals(-1, StringUtils.indexOfAny("ab", 'z'));
        assertEquals(-1, StringUtils.indexOfAny((CharSequence) null, (CharSequence[]) null));
        assertEquals(2, StringUtils.indexOfAny("zzabyycdxx", "ab", "cd"));
        assertEquals(0, StringUtils.indexOfAnyBut("aba", 'z'));
        assertEquals(3, StringUtils.indexOfAnyBut("zzabyycdxx", 'z', 'a'));
        assertEquals(-1, StringUtils.indexOfAnyBut("aba", 'a', 'b'));
    }

    @Test
    void testIndexOfDifference() {
        assertEquals(-1, StringUtils.indexOfDifference("abc", "abc"));
        assertEquals(1, StringUtils.indexOfDifference("abc", "a"));
        assertEquals(0, StringUtils.indexOfDifference("abc", "xyz"));
        assertEquals(-1, StringUtils.indexOfDifference((CharSequence[]) null));
        assertEquals(-1, StringUtils.indexOfDifference("abc"));
    }

    @Test
    void testIndexOfIgnoreCase() {
        assertEquals(-1, StringUtils.indexOfIgnoreCase(null, "a"));
        assertEquals(0, StringUtils.indexOfIgnoreCase("aabaabaa", "A"));
        assertEquals(5, StringUtils.indexOfIgnoreCase("aabaabaa", "B", 3));
    }

    @Test
    void testIsXxxFamily() {
        assertFalse(StringUtils.isEmpty(" "));
        assertTrue(StringUtils.isEmpty(null));
        assertTrue(StringUtils.isEmpty(""));
        assertTrue(StringUtils.isBlank(" "));
        assertFalse(StringUtils.isNotBlank(" "));
        assertTrue(StringUtils.isNotEmpty("a"));

        assertTrue(StringUtils.isAlpha("abc"));
        assertFalse(StringUtils.isAlpha("ab1"));
        assertFalse(StringUtils.isAlpha(""));
        assertTrue(StringUtils.isAlphanumeric("ab1"));
        assertFalse(StringUtils.isAlphanumeric(""));
        assertTrue(StringUtils.isAlphanumericSpace("ab1 "));
        assertTrue(StringUtils.isAlphaSpace("ab c"));
        assertTrue(StringUtils.isNumeric("123"));
        assertFalse(StringUtils.isNumeric("-123"));
        assertTrue(StringUtils.isNumericSpace("123 "));
        assertTrue(StringUtils.isWhitespace("   "));
        assertFalse(StringUtils.isWhitespace(" a "));
        assertTrue(StringUtils.isAsciiPrintable("abc123! "));
        assertFalse(StringUtils.isAsciiPrintable("ab\u0000c"));

        assertTrue(StringUtils.isAllLowerCase("abc"));
        assertFalse(StringUtils.isAllLowerCase("abC"));
        assertFalse(StringUtils.isAllLowerCase(""));
        assertTrue(StringUtils.isAllUpperCase("ABC"));
        assertTrue(StringUtils.isMixedCase("aBc"));
        assertFalse(StringUtils.isMixedCase("ABC"));
        assertFalse(StringUtils.isMixedCase(""));
        assertFalse(StringUtils.isMixedCase(null));

        assertTrue(StringUtils.isAllBlank(null, "", "  "));
        assertFalse(StringUtils.isAllBlank(null, "a"));
        assertTrue(StringUtils.isAllEmpty(null, ""));
        assertFalse(StringUtils.isAllEmpty(null, " "));
        assertTrue(StringUtils.isAnyBlank("a", " "));
        assertFalse(StringUtils.isAnyBlank("a", "b"));
        assertTrue(StringUtils.isAnyEmpty("a", ""));
        assertTrue(StringUtils.isNoneBlank("a", "b"));
        assertFalse(StringUtils.isNoneBlank("a", " "));
        assertTrue(StringUtils.isNoneEmpty("a", "b"));
        assertFalse(StringUtils.isNoneEmpty("a", ""));
    }

    @Test
    void testJoinArrays() {
        assertNull(StringUtils.join((Object[]) null, ','));
        assertEquals("", StringUtils.join(new Object[0], ','));
        assertEquals("a,b,c", StringUtils.join(new Object[] {"a", "b", "c"}, ','));
        assertEquals("a,,c", StringUtils.join(new Object[] {"a", null, "c"}, ','));
        assertEquals("a-b-c", StringUtils.join(new Object[] {"a", "b", "c"}, "-"));
        assertEquals("b-c", StringUtils.join(new Object[] {"a", "b", "c"}, "-", 1, 3));

        final int[] ints = {1, 2, 3};
        assertEquals("1,2,3", StringUtils.join(ints, ','));
        assertEquals("2,3", StringUtils.join(ints, ',', 1, 3));

        final long[] longs = {1L, 2L, 3L};
        assertEquals("1,2,3", StringUtils.join(longs, ','));

        final boolean[] bools = {true, false};
        assertEquals("true,false", StringUtils.join(bools, ','));

        final char[] chars = {'a', 'b'};
        assertEquals("a,b", StringUtils.join(chars, ','));
    }

    @Test
    void testJoinIterableAndIterator() {
        final List<String> list = new ArrayList<String>();
        list.add("a");
        list.add("b");
        list.add(null);
        assertEquals("a,b,", StringUtils.join((Iterable<?>) list, ','));
        assertEquals("a,b,", StringUtils.join(list.iterator(), ','));
        assertNull(StringUtils.join((Iterable<?>) null, ','));
        assertNull(StringUtils.join((Iterator<?>) null, ','));
        assertEquals("a-b-", StringUtils.join(list, "-", 0, 3));
        assertEquals("a,b,c", StringUtils.join("a", "b", "c"));
    }

    @Test
    void testJoinWith() {
        assertEquals("a,b,c", StringUtils.joinWith(",", "a", "b", "c"));
        assertEquals("", StringUtils.joinWith(","));
        assertEquals("ab", StringUtils.joinWith(null, "a", "b"));
        try {
            StringUtils.joinWith(",", (Object[]) null);
            fail("expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    void testLastIndexOf() {
        assertEquals(-1, StringUtils.lastIndexOf(null, "a"));
        assertEquals(7, StringUtils.lastIndexOf("aabaabaa", "a"));
        assertEquals(5, StringUtils.lastIndexOf("aabaabaa", "a", 6));
        assertEquals(7, StringUtils.lastIndexOf((CharSequence) "aabaabaa", 'a'));
        assertEquals(5, StringUtils.lastIndexOf("aabaabaa", 'a', 6));
        assertEquals(-1, StringUtils.lastIndexOfAny("zzabyycdxx", (CharSequence[]) null));
        assertEquals(6, StringUtils.lastIndexOfAny("zzabyycdxx", "ab", "cd"));
    }

    @Test
    void testLastIndexOfIgnoreCaseAndOrdinal() {
        assertEquals(7, StringUtils.lastIndexOfIgnoreCase("aabaabAA", "A"));
        assertEquals(5, StringUtils.lastIndexOfIgnoreCase("aabaabAA", "A", 6));
        assertEquals(-1, StringUtils.ordinalIndexOf(null, "a", 1));
        assertEquals(0, StringUtils.ordinalIndexOf("aabaabaa", "a", 1));
        assertEquals(1, StringUtils.ordinalIndexOf("aabaabaa", "a", 2));
        assertEquals(7, StringUtils.lastOrdinalIndexOf("aabaabaa", "a", 1));
        assertEquals(6, StringUtils.lastOrdinalIndexOf("aabaabaa", "a", 2));
    }

    @Test
    void testLeftRightMid() {
        assertNull(StringUtils.left(null, 3));
        assertEquals("", StringUtils.left("abc", -1));
        assertEquals("ab", StringUtils.left("abc", 2));
        assertEquals("abc", StringUtils.left("abc", 4));

        assertNull(StringUtils.right(null, 3));
        assertEquals("", StringUtils.right("abc", -1));
        assertEquals("bc", StringUtils.right("abc", 2));
        assertEquals("abc", StringUtils.right("abc", 4));

        assertNull(StringUtils.mid(null, 0, 3));
        assertEquals("", StringUtils.mid("abc", 0, -1));
        assertEquals("", StringUtils.mid("abc", 10, 2));
        assertEquals("bc", StringUtils.mid("abc", 1, 2));
        assertEquals("ab", StringUtils.mid("abc", -1, 2));
    }

    @Test
    void testPad() {
        assertNull(StringUtils.leftPad(null, 3));
        assertEquals("abc", StringUtils.leftPad("abc", 2));
        assertEquals("  abc", StringUtils.leftPad("abc", 5));
        assertEquals("xxabc", StringUtils.leftPad("abc", 5, 'x'));
        assertEquals("xyxyabc", StringUtils.leftPad("abc", 7, "xy"));

        assertNull(StringUtils.rightPad(null, 3));
        assertEquals("abc", StringUtils.rightPad("abc", 2));
        assertEquals("abc  ", StringUtils.rightPad("abc", 5));
        assertEquals("abcxx", StringUtils.rightPad("abc", 5, 'x'));
        assertEquals("abcxyxy", StringUtils.rightPad("abc", 7, "xy"));
    }

    @Test
    void testLength() {
        assertEquals(0, StringUtils.length(null));
        assertEquals(0, StringUtils.length(""));
        assertEquals(3, StringUtils.length("abc"));
    }

    @Test
    void testLowerUpperCase() {
        assertNull(StringUtils.lowerCase(null));
        assertEquals("abc", StringUtils.lowerCase("ABC"));
        assertEquals("abc", StringUtils.lowerCase("ABC", Locale.ROOT));
        assertNull(StringUtils.upperCase(null));
        assertEquals("ABC", StringUtils.upperCase("abc"));
        assertEquals("ABC", StringUtils.upperCase("abc", Locale.ROOT));
        assertEquals("abc", StringUtils.toRootLowerCase("ABC"));
        assertEquals("ABC", StringUtils.toRootUpperCase("abc"));
        assertNull(StringUtils.toRootLowerCase(null));
    }

    @Test
    void testNormalizeSpace() {
        assertNull(StringUtils.normalizeSpace(null));
        assertEquals("", StringUtils.normalizeSpace(""));
        assertEquals("a b c", StringUtils.normalizeSpace("  a   b  c  "));
    }

    @Test
    void testOverlay() {
        assertNull(StringUtils.overlay(null, "abc", 0, 0));
        assertEquals("abef", StringUtils.overlay("abcdef", "", 2, 4));
        assertEquals("abzzzzef", StringUtils.overlay("abcdef", "zzzz", 2, 4));
        assertEquals("abzzzzef", StringUtils.overlay("abcdef", "zzzz", 4, 2));
    }

    @Test
    void testPrependIfMissing() {
        assertNull(StringUtils.prependIfMissing(null, "xyz"));
        assertEquals("xyzabc", StringUtils.prependIfMissing("abc", "xyz"));
        assertEquals("xyzabc", StringUtils.prependIfMissing("xyzabc", "xyz"));
        assertEquals("xyzabc", StringUtils.prependIfMissingIgnoreCase("xyzabc", "XYZ"));
    }

    @Test
    void testRemove() {
        assertNull(StringUtils.remove(null, 'a'));
        assertEquals("qeout", StringUtils.remove("queued", 'u'));
        assertNull(StringUtils.remove(null, "ue"));
        assertEquals("abc", StringUtils.remove("abxxc", "xx"));
        assertNull(StringUtils.removeIgnoreCase(null, "ue"));
        assertEquals("abc", StringUtils.removeIgnoreCase("abXXc", "xx"));
    }

    @Test
    void testRemoveStartEnd() {
        assertNull(StringUtils.removeStart(null, "a"));
        assertEquals("domain.com", StringUtils.removeStart("www.domain.com", "www."));
        assertEquals("domain.com", StringUtils.removeStart("domain.com", "www."));
        assertNull(StringUtils.removeStart(null, 'a'));
        assertEquals("bc", StringUtils.removeStart("abc", 'a'));
        assertEquals("domain.com", StringUtils.removeStartIgnoreCase("WWW.domain.com", "www."));

        assertNull(StringUtils.removeEnd(null, ".com"));
        assertEquals("www.domain", StringUtils.removeEnd("www.domain.com", ".com"));
        assertEquals("www.domain", StringUtils.removeEndIgnoreCase("www.domain.COM", ".com"));
    }

    @Test
    void testRemoveAllFirstAndPattern() {
        assertNull(StringUtils.removeAll(null, "a"));
        assertEquals("A\nB", StringUtils.removeAll("A<__>\n<__>B", "<.*>"));
        assertEquals("AB\n", StringUtils.removeAll("A<__>\n<__>B", "(?s)<.*>"));
        assertEquals("A\n<__>B", StringUtils.removeFirst("A<__>\n<__>B", "<.*>"));
        assertEquals("", StringUtils.removePattern("<A>\n<B>", "<.*>"));
    }

    @Test
    void testRepeat() {
        assertNull(StringUtils.repeat(null, 2));
        assertEquals("", StringUtils.repeat("ab", 0));
        assertEquals("ababab", StringUtils.repeat("ab", 3));
        assertEquals("", StringUtils.repeat("ab", -2));
        assertEquals("aaa", StringUtils.repeat('a', 3));
        assertEquals("", StringUtils.repeat('a', -1));
        assertNull(StringUtils.repeat(null, "x", 2));
        assertEquals("xx", StringUtils.repeat("", "x", 3));
        assertEquals("?, ?, ?", StringUtils.repeat("?", ", ", 3));
        assertEquals("a-a-a", StringUtils.repeat("a", "-", 3));
    }

    @Test
    void testReplaceFamily() {
        assertNull(StringUtils.replace(null, "a", "b"));
        assertEquals("foofoo", StringUtils.replace("foofoo", "x", "y"));
        assertEquals("barbar", StringUtils.replace("foofoo", "foo", "bar"));
        assertEquals("barfoo", StringUtils.replace("foofoo", "foo", "bar", 1));
        assertEquals("foofoo", StringUtils.replace("foofoo", "foo", "bar", 0));

        assertEquals("A\nB", StringUtils.replaceAll("A<__>\n<__>B", "<.*>", ""));
        assertEquals("A\n<__>B", StringUtils.replaceFirst("A<__>\n<__>B", "<.*>", ""));
        assertEquals("", StringUtils.replacePattern("<A>\n<B>", "<.*>", ""));

        assertEquals("barbar", StringUtils.replaceIgnoreCase("fooFOO", "foo", "bar"));
        assertEquals("barFOO", StringUtils.replaceIgnoreCase("fooFOO", "foo", "bar", 1));
        assertEquals("barFOO", StringUtils.replaceOnce("fooFOO", "foo", "bar"));
        assertEquals("zba", StringUtils.replaceOnceIgnoreCase("aba", "a", "z"));
    }

    @Test
    void testReplaceChars() {
        assertNull(StringUtils.replaceChars(null, 'a', 'b'));
        assertEquals("tsst", StringUtils.replaceChars("test", 'e', 's'));
        assertEquals("ayzya", StringUtils.replaceChars("abcba", "bc", "yz"));
        assertEquals("ac", StringUtils.replaceChars("abc", "b", ""));
        assertEquals("abc", StringUtils.replaceChars("abc", "", "x"));
    }

    @Test
    void testReplaceEach() {
        assertNull(StringUtils.replaceEach(null, new String[] {"a"}, new String[] {"b"}));
        assertEquals("wcte", StringUtils.replaceEach("abcde", new String[] {"ab", "d"}, new String[] {"w", "t"}));
        assertEquals("tcte", StringUtils.replaceEachRepeatedly("abcde", new String[] {"ab", "d"}, new String[] {"d", "t"}));
    }

    @Test
    void testReverseFamily() {
        assertNull(StringUtils.reverse(null));
        assertEquals("", StringUtils.reverse(""));
        assertEquals("cba", StringUtils.reverse("abc"));
        assertNull(StringUtils.reverseDelimited(null, '.'));
        assertEquals("c.b.a", StringUtils.reverseDelimited("a.b.c", '.'));
    }

    @Test
    void testRotate() {
        assertNull(StringUtils.rotate(null, 1));
        assertEquals("", StringUtils.rotate("", 1));
        assertEquals("abcdefg", StringUtils.rotate("abcdefg", 0));
        assertEquals("fgabcde", StringUtils.rotate("abcdefg", 2));
        assertEquals("cdefgab", StringUtils.rotate("abcdefg", -2));
    }

    @Test
    void testSplit() {
        assertNull(StringUtils.split(null));
        assertArrayEquals(new String[0], StringUtils.split(""));
        assertArrayEquals(new String[] {"ab", "cd", "ef"}, StringUtils.split("ab cd ef"));
        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.split("a.b.c", '.'));
        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.split("a..b..c", "."));
        assertArrayEquals(new String[] {"a", "b.c"}, StringUtils.split("a.b.c", ".", 2));
    }

    @Test
    void testSplitPreserveAllTokens() {
        assertNull(StringUtils.splitPreserveAllTokens(null));
        assertArrayEquals(new String[] {"ab", "", "cd"}, StringUtils.splitPreserveAllTokens("ab  cd", ' '));
        assertArrayEquals(new String[] {"a", "", "b", "c"}, StringUtils.splitPreserveAllTokens("a..b.c", "."));
    }

    @Test
    void testSplitByWholeSeparator() {
        assertNull(StringUtils.splitByWholeSeparator(null, "."));
        assertArrayEquals(new String[0], StringUtils.splitByWholeSeparator("", "."));
        assertArrayEquals(new String[] {"ab", "cd", "ef"}, StringUtils.splitByWholeSeparator("ab-!-cd-!-ef", "-!-"));
        assertArrayEquals(new String[] {"ab", "cd:ef"}, StringUtils.splitByWholeSeparator("ab:cd:ef", ":", 2));
        assertArrayEquals(new String[] {"ab", "cd", "ef"}, StringUtils.splitByWholeSeparatorPreserveAllTokens("ab-!-cd-!-ef", "-!-"));
        assertArrayEquals(new String[] {"ab", "", "", "de", "fg"}, StringUtils.splitByWholeSeparatorPreserveAllTokens("ab   de fg", null));
    }

    @Test
    void testSplitByCharacterType() {
        assertNull(StringUtils.splitByCharacterType(null));
        assertArrayEquals(new String[0], StringUtils.splitByCharacterType(""));
        assertArrayEquals(new String[] {"ab", " ", "de", " ", "fg"}, StringUtils.splitByCharacterType("ab de fg"));
        assertArrayEquals(new String[] {"foo", "B", "ar"}, StringUtils.splitByCharacterType("fooBar"));
        assertArrayEquals(new String[] {"foo", "Bar"}, StringUtils.splitByCharacterTypeCamelCase("fooBar"));
        assertArrayEquals(new String[] {"ASF", "Rules"}, StringUtils.splitByCharacterTypeCamelCase("ASFRules"));
    }

    @Test
    void testStartsWith() {
        assertTrue(StringUtils.startsWith(null, null));
        assertFalse(StringUtils.startsWith(null, "abc"));
        assertTrue(StringUtils.startsWith("abcdef", "abc"));
        assertFalse(StringUtils.startsWith("ABCDEF", "abc"));
        assertTrue(StringUtils.startsWithIgnoreCase("ABCDEF", "abc"));
        assertTrue(StringUtils.startsWithAny("abcxyz", "xyz", "abc"));
        assertFalse(StringUtils.startsWithAny("abcxyz", "xyz", "123"));
    }

    @Test
    void testStrip() {
        assertNull(StringUtils.strip(null));
        assertEquals("", StringUtils.strip("   "));
        assertEquals("abc", StringUtils.strip("  abc  "));
        assertEquals("abc", StringUtils.strip("xxabcyy", "xy"));
        assertEquals("  abc", StringUtils.stripEnd("  abc  ", null));
        assertEquals("abc  ", StringUtils.stripStart("  abc  ", null));
        assertEquals("", StringUtils.stripToEmpty(null));
        assertEquals("abc", StringUtils.stripToEmpty("  abc  "));
        assertNull(StringUtils.stripToNull("   "));
        assertEquals("abc", StringUtils.stripToNull("  abc  "));
        assertArrayEquals(new String[] {"abc", null}, StringUtils.stripAll("  abc  ", null));
        assertArrayEquals(new String[] {"abc"}, StringUtils.stripAll(new String[] {"xabcx"}, "x"));
    }

    @Test
    void testStripAccents() {
        assertNull(StringUtils.stripAccents(null));
        assertEquals("control", StringUtils.stripAccents("control"));
        assertEquals("eclair", StringUtils.stripAccents("éclair"));
    }

    @Test
    void testSubstring() {
        assertNull(StringUtils.substring(null, 0));
        assertEquals("", StringUtils.substring("", 1));
        assertEquals("cde", StringUtils.substring("abcde", 2));
        assertEquals("cde", StringUtils.substring("abcde", -3));
        assertEquals("", StringUtils.substring("abcde", 10));

        assertNull(StringUtils.substring(null, 0, 2));
        assertEquals("ab", StringUtils.substring("abc", 0, 2));
        assertEquals("", StringUtils.substring("abc", 2, 0));
        assertEquals("abc", StringUtils.substring("abc", -4, 10));
    }

    @Test
    void testSubstringAfterBefore() {
        assertNull(StringUtils.substringAfter(null, "a"));
        assertEquals("", StringUtils.substringAfter("abc", "d"));
        assertEquals("bc", StringUtils.substringAfter("abc", "a"));
        assertEquals("cba", StringUtils.substringAfter("abcba", 'c'));

        assertNull(StringUtils.substringBefore(null, "a"));
        assertEquals("abc", StringUtils.substringBefore("abc", "d"));
        assertEquals("a", StringUtils.substringBefore("abc", "b"));
        assertEquals("ab", StringUtils.substringBefore("abc", 'c'));

        assertEquals("", StringUtils.substringAfterLast("abcbac", "d"));
        assertEquals("c", StringUtils.substringAfterLast("abcbac", "a"));
        assertEquals("abcba", StringUtils.substringBeforeLast("abcbac", "c"));
    }

    @Test
    void testSubstringBetween() {
        assertNull(StringUtils.substringBetween(null, "tag"));
        assertEquals("", StringUtils.substringBetween("tagabctag", "tag"));
        assertEquals("abc", StringUtils.substringBetween("yabczy", "y", "z"));
        assertNull(StringUtils.substringBetween("abc", "(", ")"));
        assertArrayEquals(new String[] {"abc", "def"}, StringUtils.substringsBetween("[abc][def]", "[", "]"));
        assertNull(StringUtils.substringsBetween(null, "[", "]"));
    }

    @Test
    void testSwapCase() {
        assertNull(StringUtils.swapCase(null));
        assertEquals("", StringUtils.swapCase(""));
        assertEquals("tHE DOG HAS A bone", StringUtils.swapCase("The dog has a BONE"));
    }

    @Test
    void testToCodePoints() {
        final int[] empty = {};
        assertArrayEquals(empty, StringUtils.toCodePoints(""));
        assertArrayEquals(new int[] {'a', 'b', 'c'}, StringUtils.toCodePoints("abc"));
        try {
            StringUtils.toCodePoints(null);
            fail("expected NullPointerException");
        } catch (final NullPointerException e) {
            // expected
        }
    }

    @Test
    void testTrim() {
        assertNull(StringUtils.trim(null));
        assertEquals("", StringUtils.trim("  "));
        assertEquals("abc", StringUtils.trim("  abc  "));
        assertEquals("", StringUtils.trimToEmpty(null));
        assertEquals("abc", StringUtils.trimToEmpty("  abc  "));
        assertNull(StringUtils.trimToNull("  "));
        assertEquals("abc", StringUtils.trimToNull("  abc  "));
    }

    @Test
    void testTruncate() {
        assertNull(StringUtils.truncate(null, 10));
        assertEquals("abc", StringUtils.truncate("abcdefg", 3));
        assertEquals("abcdefg", StringUtils.truncate("abcdefg", 10));
        try {
            StringUtils.truncate("abcdefg", -1);
            fail("expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
        assertEquals("cde", StringUtils.truncate("abcdefg", 2, 3));
        try {
            StringUtils.truncate("abcdefg", -1, 3);
            fail("expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    void testUnwrap() {
        assertNull(StringUtils.unwrap(null, 'x'));
        assertEquals("abc", StringUtils.unwrap("xabcx", 'x'));
        assertEquals("ab", StringUtils.unwrap("ab", 'x'));
        assertEquals("abc", StringUtils.unwrap("\"abc\"", "\""));
    }

    @Test
    void testValueOf() {
        assertNull(StringUtils.valueOf((char[]) null));
        final char[] chars = {'a', 'b', 'c'};
        assertEquals("abc", StringUtils.valueOf(chars));
    }

    @Test
    void testWrap() {
        assertNull(StringUtils.wrap(null, 'x'));
        assertEquals("xabx", StringUtils.wrap("ab", 'x'));
        assertEquals("abc", StringUtils.wrap("abc", (String) null));
        assertNull(StringUtils.wrapIfMissing(null, 'x'));
        assertEquals("xabx", StringUtils.wrapIfMissing("ab", 'x'));
        assertEquals("xabx", StringUtils.wrapIfMissing("xabx", 'x'));
        assertEquals("xabx", StringUtils.wrapIfMissing("ab", "x"));
    }

    @Test
    void testIndexOfConstants() {
        assertEquals(-1, StringUtils.INDEX_NOT_FOUND);
        assertEquals(" ", StringUtils.SPACE);
        assertEquals("", StringUtils.EMPTY);
        assertEquals("\n", StringUtils.LF);
        assertEquals("\r", StringUtils.CR);
    }

    @Test
    void testGetFuzzyDistance() {
        assertEquals(0, StringUtils.getFuzzyDistance("", "", Locale.ENGLISH));
        assertEquals(0, StringUtils.getFuzzyDistance("Workshop", "b", Locale.ENGLISH));
        assertEquals(1, StringUtils.getFuzzyDistance("Workshop", "w", Locale.ENGLISH));
        assertEquals(3, StringUtils.getFuzzyDistance("Apache Software Foundation", "asf", Locale.ENGLISH));
        try {
            StringUtils.getFuzzyDistance(null, "a", Locale.ENGLISH);
            fail("expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    void testGetJaroWinklerDistance() {
        assertEquals(1.0d, StringUtils.getJaroWinklerDistance("foo", "foo"), 0.0001d);
        assertEquals(0.0d, StringUtils.getJaroWinklerDistance("", ""), 0.0001d);
        try {
            StringUtils.getJaroWinklerDistance(null, "a");
            fail("expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    void testGetBytes() {
        final byte[] bytes = StringUtils.getBytes("abc", java.nio.charset.StandardCharsets.UTF_8);
        assertArrayEquals(new byte[] {'a', 'b', 'c'}, bytes);
        assertEquals("", StringUtils.toRootLowerCase(""));
    }
}
