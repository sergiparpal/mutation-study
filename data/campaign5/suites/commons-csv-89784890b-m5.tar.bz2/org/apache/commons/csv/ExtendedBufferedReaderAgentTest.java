/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.apache.commons.csv.Constants.CR;
import static org.apache.commons.csv.Constants.LF;
import static org.apache.commons.csv.Constants.UNDEFINED;
import static org.apache.commons.io.IOUtils.EOF;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests for {@link ExtendedBufferedReader}.
 */
public class ExtendedBufferedReaderAgentTest {

    @Test
    public void testInitialStateBeforeAnyRead() {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"));
        assertEquals(UNDEFINED, reader.getLastChar());
        assertEquals(0, reader.getPosition());
        assertEquals(0, reader.getLineNumber());
        assertEquals(0, reader.getBytesRead());
    }

    @Test
    public void testReadSingleCharUpdatesStateAndPosition() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("ab"));
        assertEquals('a', reader.read());
        assertEquals('a', reader.getLastChar());
        assertEquals(1, reader.getPosition());
        assertEquals('b', reader.read());
        assertEquals('b', reader.getLastChar());
        assertEquals(2, reader.getPosition());
    }

    @Test
    public void testReadReturnsEofAtEndAndPositionStillAdvances() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("a"));
        assertEquals('a', reader.read());
        assertEquals(EOF, reader.read());
        assertEquals(EOF, reader.getLastChar());
        // The implementation increments position even on an EOF read.
        assertEquals(2, reader.getPosition());
        assertEquals(EOF, reader.read());
        assertEquals(3, reader.getPosition());
    }

    @Test
    public void testReadCharArrayZeroLengthReturnsZeroWithoutConsuming() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"));
        final char[] buf = new char[0];
        assertEquals(0, reader.read(buf, 0, 0));
        assertEquals(0, reader.getPosition());
        assertEquals(UNDEFINED, reader.getLastChar());
        assertEquals('a', reader.read());
    }

    @Test
    public void testReadCharArrayFillsBufferAndUpdatesState() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("hello"));
        final char[] buf = new char[5];
        final int len = reader.read(buf, 0, 5);
        assertEquals(5, len);
        assertEquals("hello", new String(buf));
        assertEquals('o', reader.getLastChar());
        assertEquals(5, reader.getPosition());
    }

    @Test
    public void testReadCharArrayIntoOffsetPortion() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("xy"));
        final char[] buf = new char[] { 'Z', 'Z', 'Z', 'Z' };
        final int len = reader.read(buf, 1, 2);
        assertEquals(2, len);
        assertEquals('Z', buf[0]);
        assertEquals('x', buf[1]);
        assertEquals('y', buf[2]);
        assertEquals('Z', buf[3]);
        assertEquals('y', reader.getLastChar());
    }

    @Test
    public void testReadCharArrayAtEofReturnsEof() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("hi"));
        final char[] buf = new char[5];
        assertEquals(2, reader.read(buf, 0, 5));
        final int len = reader.read(buf, 0, 5);
        assertEquals(EOF, len);
        assertEquals(EOF, reader.getLastChar());
    }

    @Test
    public void testLineNumberTracksDifferentEolStyles() throws IOException {
        // "a\nb\rc\r\nd" -- LF, CR, and CRLF line endings mixed together.
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("a\nb\rc\r\nd"));
        assertEquals('a', reader.read());
        assertEquals(1, reader.getLineNumber());
        assertEquals(LF, reader.read());
        assertEquals(1, reader.getLineNumber());
        assertEquals('b', reader.read());
        assertEquals(2, reader.getLineNumber());
        assertEquals(CR, reader.read());
        assertEquals(2, reader.getLineNumber());
        assertEquals('c', reader.read());
        assertEquals(3, reader.getLineNumber());
        assertEquals(CR, reader.read());
        assertEquals(3, reader.getLineNumber());
        assertEquals(LF, reader.read());
        // CRLF counts as a single line terminator.
        assertEquals(3, reader.getLineNumber());
        assertEquals('d', reader.read());
        assertEquals(4, reader.getLineNumber());
        assertEquals(EOF, reader.read());
        assertEquals(4, reader.getLineNumber());
    }

    @Test
    public void testLineNumberViaBulkReadMatchesSingleCharRead() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("a\nb\r\nc"));
        final char[] buf = new char[6];
        final int len = reader.read(buf, 0, 6);
        assertEquals(6, len);
        assertEquals("a\nb\r\nc", new String(buf));
        assertEquals('c', reader.getLastChar());
        // Two line terminators were consumed (LF, then CR+LF counted once); the last char read
        // is not itself a terminator, so getLineNumber() reports one past the counter.
        assertEquals(3, reader.getLineNumber());
    }

    @Test
    public void testPeekDoesNotConsumeCharacter() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("xy"));
        assertEquals('x', reader.peek());
        assertEquals('x', reader.peek());
        assertEquals(0, reader.getPosition());
        assertEquals(UNDEFINED, reader.getLastChar());
        assertEquals('x', reader.read());
        assertEquals('y', reader.peek());
        assertEquals('y', reader.read());
    }

    @Test
    public void testPeekAtEndOfStreamReturnsEof() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader(""));
        assertEquals(EOF, reader.peek());
        assertEquals(EOF, reader.peek());
    }

    @Test
    public void testPeekArrayZeroLengthReturnsZero() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"));
        assertEquals(0, reader.peek(new char[0]));
        assertEquals('a', reader.read());
    }

    @Test
    public void testPeekArrayFillsLookaheadWithoutConsuming() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abcdef"));
        final char[] arr = new char[3];
        final int n = reader.peek(arr);
        assertEquals(3, n);
        assertEquals("abc", new String(arr));
        assertEquals(0, reader.getPosition());
        final char[] full = new char[6];
        assertEquals(6, reader.read(full, 0, 6));
        assertEquals("abcdef", new String(full));
    }

    @Test
    public void testPeekArrayPartialFillAtEof() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("ab"));
        final char[] arr = new char[5];
        final int n = reader.peek(arr);
        assertEquals(2, n);
        assertEquals('a', arr[0]);
        assertEquals('b', arr[1]);
        // Peek must not have consumed anything.
        assertEquals('a', reader.read());
        assertEquals('b', reader.read());
    }

    @Test
    public void testPeekArrayFullEofReturnsEof() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader(""));
        assertEquals(EOF, reader.peek(new char[3]));
    }

    @Test
    public void testReadLineDropsTerminatorsForDifferentStyles() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("line1\nline2\r\nline3\rline4"));
        assertEquals("line1", reader.readLine());
        assertEquals("line2", reader.readLine());
        assertEquals("line3", reader.readLine());
        assertEquals("line4", reader.readLine());
        assertNull(reader.readLine());
    }

    @Test
    public void testReadLineReturnsNullAtImmediateEof() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader(""));
        assertNull(reader.readLine());
    }

    @Test
    public void testReadLineOnFinalLineWithoutTerminatorSetsEofLastChar() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"));
        assertEquals("abc", reader.readLine());
        assertEquals(EOF, reader.getLastChar());
        assertNull(reader.readLine());
    }

    @Test
    public void testReadLineOnEmptyLineReturnsEmptyString() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("\nabc"));
        assertEquals("", reader.readLine());
        assertEquals("abc", reader.readLine());
    }

    @Test
    public void testMarkAndResetRestorePositionLastCharAndLineNumber() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("ab\ncdef"));
        assertEquals('a', reader.read());
        assertEquals('b', reader.read());
        reader.mark(10);
        final long markedPosition = reader.getPosition();
        final int markedLastChar = reader.getLastChar();
        final long markedLineNumber = reader.getLineNumber();

        assertEquals(LF, reader.read());
        assertEquals('c', reader.read());
        assertEquals(4, reader.getPosition());

        reader.reset();
        assertEquals(markedPosition, reader.getPosition());
        assertEquals(markedLastChar, reader.getLastChar());
        assertEquals(markedLineNumber, reader.getLineNumber());

        // Reading after reset must replay from the marked point.
        assertEquals(LF, reader.read());
        assertEquals('c', reader.read());
    }

    @Test
    public void testCloseSetsLastCharToEofAndBlocksFurtherReads() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"));
        assertEquals('a', reader.read());
        reader.close();
        assertEquals(EOF, reader.getLastChar());
        assertThrows(IOException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                reader.read();
            }
        });
    }

    @Test
    public void testBytesReadIsZeroWhenTrackingDisabledByDefaultConstructor() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("hello"));
        final char[] buf = new char[5];
        reader.read(buf, 0, 5);
        assertEquals(0, reader.getBytesRead());
    }

    @Test
    public void testBytesReadIsZeroWhenTrackBytesFalse() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("hello"), StandardCharsets.UTF_8, false);
        reader.read();
        reader.read();
        assertEquals(0, reader.getBytesRead());
    }

    @Test
    public void testBytesReadIsZeroWhenCharsetIsNullEvenIfTrackBytesTrue() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("hello"), null, true);
        reader.read();
        reader.read();
        assertEquals(0, reader.getBytesRead());
    }

    @Test
    public void testBytesReadTracksAsciiAndMultiByteCharsUnderUtf8() throws IOException {
        // 'A' is 1 byte in UTF-8, the e-acute character is 2 bytes in UTF-8.
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("Aé"), StandardCharsets.UTF_8, true);
        assertEquals('A', reader.read());
        assertEquals(1, reader.getBytesRead());
        assertEquals('é', reader.read());
        assertEquals(3, reader.getBytesRead());
    }

    @Test
    public void testBytesReadForBulkReadMatchesPerCharEncodingUnderUtf8() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("AéB"), StandardCharsets.UTF_8, true);
        final char[] buf = new char[3];
        final int len = reader.read(buf, 0, 3);
        assertEquals(3, len);
        assertEquals(4, reader.getBytesRead());
    }

    @Test
    public void testBytesReadAcrossSupplementaryCharacterSurrogatePair() throws IOException {
        // U+1F600 (a supplementary character) is 4 bytes in UTF-8 and is represented as a
        // high surrogate followed by a low surrogate in the char stream.
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("😀"), StandardCharsets.UTF_8, true);
        assertEquals('\uD83D', reader.read());
        // The high surrogate alone contributes no bytes; it is deferred until its pair arrives.
        assertEquals(0, reader.getBytesRead());
        assertEquals('\uDE00', reader.read());
        assertEquals(4, reader.getBytesRead());
    }

    @Test
    public void testBytesReadThrowsOnLoneLowSurrogate() {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("\uDE00"), StandardCharsets.UTF_8, true);
        assertThrows(IOException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                reader.read();
            }
        });
    }

    @Test
    public void testMarkRestoresBytesReadToo() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("ABéC"), StandardCharsets.UTF_8, true);
        assertEquals('A', reader.read());
        reader.mark(10);
        final long markedBytes = reader.getBytesRead();
        assertEquals('B', reader.read());
        assertEquals('é', reader.read());
        assertTrue(reader.getBytesRead() > markedBytes);
        reader.reset();
        assertEquals(markedBytes, reader.getBytesRead());
    }

    @Test
    public void testDefaultConstructorUsesNullCharsetBehavior() {
        final Charset nullCharset = null;
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"), nullCharset, true);
        assertEquals(0, reader.getBytesRead());
    }
}
