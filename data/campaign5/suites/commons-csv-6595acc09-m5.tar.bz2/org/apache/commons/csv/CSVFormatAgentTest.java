/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.List;

import org.apache.commons.csv.CSVFormat.Builder;
import org.junit.jupiter.api.Test;

/**
 * Tests {@link CSVFormat}.
 */
class CSVFormatAgentTest {

    public enum Header {
        Name, Email, Phone
    }

    /** Builds a {@link ResultSetMetaData} proxy backed by the given column labels, avoiding a mocking dependency. */
    private static ResultSetMetaData metaDataOf(final String... labels) {
        final InvocationHandler handler = new InvocationHandler() {
            @Override
            public Object invoke(final Object proxy, final Method method, final Object[] args) {
                if ("getColumnCount".equals(method.getName())) {
                    return Integer.valueOf(labels.length);
                }
                if ("getColumnLabel".equals(method.getName())) {
                    final int index = ((Integer) args[0]).intValue();
                    return labels[index - 1];
                }
                throw new UnsupportedOperationException(method.getName());
            }
        };
        return (ResultSetMetaData) Proxy.newProxyInstance(CSVFormatAgentTest.class.getClassLoader(), new Class<?>[] {ResultSetMetaData.class}, handler);
    }

    /** Builds a {@link ResultSet} proxy whose getMetaData() returns the given metadata. */
    private static ResultSet resultSetOf(final ResultSetMetaData metaData) {
        final InvocationHandler handler = new InvocationHandler() {
            @Override
            public Object invoke(final Object proxy, final Method method, final Object[] args) {
                if ("getMetaData".equals(method.getName())) {
                    return metaData;
                }
                throw new UnsupportedOperationException(method.getName());
            }
        };
        return (ResultSet) Proxy.newProxyInstance(CSVFormatAgentTest.class.getClassLoader(), new Class<?>[] {ResultSet.class}, handler);
    }

    // --- Predefined formats and defaults -------------------------------------------------

    @Test
    void testDefaultFormat() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertTrue(format.getIgnoreEmptyLines());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
        assertNull(format.getCommentMarker());
        assertNull(format.getEscapeCharacter());
        assertFalse(format.getSkipHeaderRecord());
        assertNull(format.getHeader());
        assertEquals(0L, format.getMaxRows());
        assertFalse(format.getAutoFlush());
        assertFalse(format.getLenientEof());
        assertFalse(format.getTrailingData());
    }

    @Test
    void testExcelFormat() {
        final CSVFormat format = CSVFormat.EXCEL;
        assertFalse(format.getIgnoreEmptyLines());
        assertTrue(format.getAllowMissingColumnNames());
        assertTrue(format.getTrailingData());
        assertTrue(format.getLenientEof());
    }

    @Test
    void testTdfFormat() {
        final CSVFormat format = CSVFormat.TDF;
        assertEquals("\t", format.getDelimiterString());
        assertTrue(format.getIgnoreSurroundingSpaces());
    }

    @Test
    void testMySqlFormat() {
        final CSVFormat format = CSVFormat.MYSQL;
        assertEquals("\t", format.getDelimiterString());
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
        assertNull(format.getQuoteCharacter());
        assertEquals("\n", format.getRecordSeparator());
        assertEquals("\\N", format.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, format.getQuoteMode());
    }

    @Test
    void testRfc4180Format() {
        final CSVFormat format = CSVFormat.RFC4180;
        assertFalse(format.getIgnoreEmptyLines());
    }

    @Test
    void testValueOfKnownPredefined() {
        assertEquals(CSVFormat.EXCEL, CSVFormat.valueOf("Excel"));
        assertEquals(CSVFormat.MYSQL, CSVFormat.valueOf("MySQL"));
    }

    @Test
    void testValueOfUnknownThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                CSVFormat.valueOf("DoesNotExist");
            }
        });
    }

    // --- newFormat -------------------------------------------------------------------------

    @Test
    void testNewFormat() {
        final CSVFormat format = CSVFormat.newFormat(';');
        assertEquals(";", format.getDelimiterString());
        assertNull(format.getQuoteCharacter());
        assertNull(format.getRecordSeparator());
        assertFalse(format.getIgnoreEmptyLines());
        assertNull(format.getHeader());
    }

    @Test
    void testNewFormatLineBreakDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                CSVFormat.newFormat('\n');
            }
        });
    }

    // --- Builder: delimiter -------------------------------------------------------------

    @Test
    void testSetDelimiterEmptyThrows() {
        final Builder builder = CSVFormat.DEFAULT.builder();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                builder.setDelimiter("");
            }
        });
    }

    @Test
    void testSetDelimiterLineBreakThrows() {
        final Builder builder = CSVFormat.DEFAULT.builder();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                builder.setDelimiter("\r");
            }
        });
    }

    @Test
    void testSetDelimiterMultiChar() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("||").get();
        assertEquals("||", format.getDelimiterString());
        assertArrayEquals(new char[] {'|', '|'}, format.getDelimiterCharArray());
    }

    // --- Builder: comment marker / escape / quote line-break guards ---------------------

    @Test
    void testSetCommentMarkerLineBreakThrows() {
        final Builder builder = CSVFormat.DEFAULT.builder();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                builder.setCommentMarker('\n');
            }
        });
    }

    @Test
    void testSetEscapeLineBreakThrows() {
        final Builder builder = CSVFormat.DEFAULT.builder();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                builder.setEscape('\r');
            }
        });
    }

    @Test
    void testSetQuoteLineBreakThrows() {
        final Builder builder = CSVFormat.DEFAULT.builder();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                builder.setQuote('\n');
            }
        });
    }

    @Test
    void testSetQuoteNullCharacterDisablesQuoting() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuote((Character) null).get();
        assertFalse(format.isQuoteCharacterSet());
        assertNull(format.getQuoteCharacter());
    }

    // --- validate(): conflicting characters ----------------------------------------------

    @Test
    void testValidateQuoteEqualsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDelimiter(',').setQuote(',').get();
            }
        });
    }

    @Test
    void testValidateEscapeEqualsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDelimiter(',').setEscape(',').get();
            }
        });
    }

    @Test
    void testValidateCommentEqualsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDelimiter(',').setCommentMarker(',').get();
            }
        });
    }

    @Test
    void testValidateQuoteEqualsCommentThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setQuote('#').setCommentMarker('#').get();
            }
        });
    }

    @Test
    void testValidateEscapeEqualsCommentThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setEscape('#').setCommentMarker('#').get();
            }
        });
    }

    @Test
    void testValidateQuoteModeNoneWithoutEscapeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setQuoteMode(QuoteMode.NONE).get();
            }
        });
    }

    @Test
    void testValidateQuoteModeNoneWithEscapeOk() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').setQuoteMode(QuoteMode.NONE).get();
        assertEquals(QuoteMode.NONE, format.getQuoteMode());
    }

    // --- Builder: headers and duplicate handling ------------------------------------------

    @Test
    void testSetHeaderDefensiveCopy() {
        final String[] original = {"a", "b"};
        final Builder builder = CSVFormat.DEFAULT.builder().setHeader(original);
        original[0] = "mutated";
        final CSVFormat format = builder.get();
        assertArrayEquals(new String[] {"a", "b"}, format.getHeader());
    }

    @Test
    void testGetHeaderReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "b").get();
        final String[] gotten = format.getHeader();
        gotten[0] = "mutated";
        assertArrayEquals(new String[] {"a", "b"}, format.getHeader());
    }

    @Test
    void testSetHeaderFromEnum() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(Header.class).get();
        assertArrayEquals(new String[] {"Name", "Email", "Phone"}, format.getHeader());
    }

    @Test
    void testSetHeaderFromNullEnumDisables() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader((Class<? extends Enum<?>>) null).get();
        assertNull(format.getHeader());
    }

    @Test
    void testSetHeaderFromResultSetMetaData() throws SQLException {
        final ResultSetMetaData metaData = metaDataOf("Col1", "Col2", "Col3");
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(metaData).get();
        assertArrayEquals(new String[] {"Col1", "Col2", "Col3"}, format.getHeader());
    }

    @Test
    void testSetHeaderFromResultSet() throws SQLException {
        final ResultSetMetaData metaData = metaDataOf("A", "B");
        final ResultSet resultSet = resultSetOf(metaData);
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(resultSet).get();
        assertArrayEquals(new String[] {"A", "B"}, format.getHeader());
    }

    @Test
    void testSetHeaderFromNullResultSetDisables() throws SQLException {
        final ResultSet resultSet = null;
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(resultSet).get();
        assertNull(format.getHeader());
    }

    @Test
    void testDuplicateHeaderAllowedByDefault() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "a").get();
        assertArrayEquals(new String[] {"a", "a"}, format.getHeader());
    }

    @Test
    void testDuplicateHeaderDisallowedThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).setHeader("a", "a").get();
            }
        });
    }

    @Test
    void testDuplicateEmptyHeaderAllowedWithAllowEmptyMode() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("", "", "x").get();
        assertArrayEquals(new String[] {"", "", "x"}, format.getHeader());
    }

    @Test
    void testDuplicateNonEmptyHeaderDisallowedWithAllowEmptyMode() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("x", "x").get();
            }
        });
    }

    @Test
    void testSetDuplicateHeaderModeNullThrows() {
        final Builder builder = CSVFormat.DEFAULT.builder();
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                builder.setDuplicateHeaderMode(null);
            }
        });
    }

    // --- Builder: header comments ---------------------------------------------------------

    @Test
    void testSetHeaderCommentsDefensiveCopyAndConversion() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeaderComments("one", Integer.valueOf(2), null).get();
        assertArrayEquals(new String[] {"one", "2", null}, format.getHeaderComments());
    }

    @Test
    void testGetHeaderCommentsReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeaderComments("a").get();
        final String[] gotten = format.getHeaderComments();
        gotten[0] = "mutated";
        assertEquals("a", format.getHeaderComments()[0]);
    }

    // --- Builder: nullString / quotedNullString --------------------------------------------

    @Test
    void testSetNullStringWithQuoteAllWritesQuotedNullString() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuote('"').setNullString("NULL").setQuoteMode(QuoteMode.ALL).get();
        final StringWriter out = new StringWriter();
        format.print(null, out, true);
        format.println(out);
        assertEquals("\"NULL\"\r\n", out.toString());
    }

    @Test
    void testIsNullStringSet() {
        assertFalse(CSVFormat.DEFAULT.isNullStringSet());
        assertTrue(CSVFormat.DEFAULT.builder().setNullString("NULL").get().isNullStringSet());
    }

    // --- getters/predicates on a bare format -----------------------------------------------

    @Test
    void testIsSettersOnBareFormat() {
        final CSVFormat format = CSVFormat.newFormat(',');
        assertFalse(format.isCommentMarkerSet());
        assertFalse(format.isEscapeCharacterSet());
        assertFalse(format.isQuoteCharacterSet());
        assertFalse(format.isNullStringSet());
        assertEquals(0L, format.getMaxRows());
    }

    @Test
    void testGetDelimiterDeprecated() {
        assertEquals(',', CSVFormat.DEFAULT.getDelimiter());
    }

    @Test
    void testGetAllowDuplicateHeaderNamesDeprecated() {
        assertTrue(CSVFormat.DEFAULT.getAllowDuplicateHeaderNames());
        final CSVFormat disallowed = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).get();
        assertFalse(disallowed.getAllowDuplicateHeaderNames());
    }

    @Test
    void testMaxRows() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(5).get();
        assertEquals(5L, format.getMaxRows());
        assertTrue(format.useMaxRows());
        assertTrue(format.useRow(5));
        assertFalse(format.useRow(6));
    }

    @Test
    void testMaxRowsZeroMeansUnlimited() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertFalse(format.useMaxRows());
        assertTrue(format.useRow(Long.MAX_VALUE));
    }

    @Test
    void testAutoFlushLenientEofTrailingData() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setAutoFlush(true).setLenientEof(true).setTrailingData(true).get();
        assertTrue(format.getAutoFlush());
        assertTrue(format.getLenientEof());
        assertTrue(format.getTrailingData());
    }

    // --- builder()/copy independence --------------------------------------------------------

    @Test
    void testBuilderCreatesIndependentCopy() {
        final CSVFormat original = CSVFormat.DEFAULT;
        final CSVFormat modified = original.builder().setDelimiter(';').get();
        assertEquals(",", original.getDelimiterString());
        assertEquals(";", modified.getDelimiterString());
    }

    // --- equals/hashCode ---------------------------------------------------------------------

    @Test
    void testEqualsReflexiveAndValueBased() {
        final CSVFormat format1 = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        final CSVFormat format2 = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        assertEquals(format1, format1);
        assertEquals(format1, format2);
        assertEquals(format1.hashCode(), format2.hashCode());
    }

    @Test
    void testEqualsDifferByDelimiter() {
        final CSVFormat format1 = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        final CSVFormat format2 = CSVFormat.DEFAULT.builder().setDelimiter(',').get();
        assertNotEquals(format1, format2);
    }

    @Test
    void testEqualsAgainstNullAndOtherType() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertNotEquals(format, null);
        assertNotEquals(format, "not a CSVFormat");
    }

    // --- toString ------------------------------------------------------------------------------

    @Test
    void testToStringContainsDelimiter() {
        final String str = CSVFormat.DEFAULT.toString();
        assertTrue(str.contains("Delimiter=<,>"));
    }

    @Test
    void testToStringContainsQuoteAndEscapeAndComment() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuote('\'').setEscape('\\').setCommentMarker('#').setNullString("NULL").get();
        final String str = format.toString();
        assertTrue(str.contains("Escape=<\\>"));
        assertTrue(str.contains("QuoteChar=<'>"));
        assertTrue(str.contains("CommentStart=<#>"));
        assertTrue(str.contains("NullString=<NULL>"));
    }

    // --- format(Object...) ----------------------------------------------------------------------

    @Test
    void testFormatSimpleValues() {
        assertEquals("a,b,c", CSVFormat.DEFAULT.format("a", "b", "c"));
    }

    @Test
    void testFormatQuotesWhenNeeded() {
        assertEquals("\"a,b\",c", CSVFormat.DEFAULT.format("a,b", "c"));
    }

    // --- parse(Reader) / print(Appendable) round trip --------------------------------------------

    @Test
    void testParseProducesExpectedRecords() throws IOException {
        final CSVParser parser = CSVFormat.DEFAULT.parse(new StringReader("a,b,c\r\n1,2,3\r\n"));
        final List<CSVRecord> records = parser.getRecords();
        parser.close();
        assertEquals(2, records.size());
        assertEquals("a", records.get(0).get(0));
        assertEquals("3", records.get(1).get(2));
    }

    @Test
    void testPrintRecordWritesDelimitedLine() throws IOException {
        final StringWriter out = new StringWriter();
        final CSVPrinter printer = CSVFormat.DEFAULT.print(out);
        printer.printRecord("x", "y", "z");
        printer.close();
        assertEquals("x,y,z\r\n", out.toString());
    }

    @Test
    void testPrintSingleValueWithTrim() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrim(true).get();
        final StringWriter out = new StringWriter();
        format.print("  hello  ", out, true);
        assertEquals("hello", out.toString());
    }

    @Test
    void testPrintlnWritesTrailingDelimiterAndSeparator() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get();
        final StringWriter out = new StringWriter();
        format.println(out);
        assertEquals(",\r\n", out.toString());
    }

    // --- deprecated with* methods: spot-check a representative sample ------------------------------

    @Test
    void testWithDelimiter() {
        assertEquals(";", CSVFormat.DEFAULT.withDelimiter(';').getDelimiterString());
    }

    @Test
    void testWithQuoteCharAndCharacter() {
        assertEquals(Character.valueOf('\''), CSVFormat.DEFAULT.withQuote('\'').getQuoteCharacter());
        assertNull(CSVFormat.DEFAULT.withQuote((Character) null).getQuoteCharacter());
    }

    @Test
    void testWithEscapeCharAndCharacter() {
        assertEquals(Character.valueOf('\\'), CSVFormat.DEFAULT.withEscape('\\').getEscapeCharacter());
        assertNull(CSVFormat.DEFAULT.withEscape((Character) null).getEscapeCharacter());
    }

    @Test
    void testWithCommentMarkerCharAndCharacter() {
        assertEquals(Character.valueOf('#'), CSVFormat.DEFAULT.withCommentMarker('#').getCommentMarker());
        assertNull(CSVFormat.DEFAULT.withCommentMarker((Character) null).getCommentMarker());
    }

    @Test
    void testWithHeaderVarargs() {
        assertArrayEquals(new String[] {"a", "b"}, CSVFormat.DEFAULT.withHeader("a", "b").getHeader());
    }

    @Test
    void testWithHeaderComments() {
        assertArrayEquals(new String[] {"c1"}, CSVFormat.DEFAULT.withHeaderComments("c1").getHeaderComments());
    }

    @Test
    void testWithNullString() {
        assertEquals("NULL", CSVFormat.DEFAULT.withNullString("NULL").getNullString());
    }

    @Test
    void testWithQuoteMode() {
        assertEquals(QuoteMode.ALL, CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL).getQuoteMode());
    }

    @Test
    void testWithRecordSeparatorCharAndString() {
        assertEquals("\n", CSVFormat.DEFAULT.withRecordSeparator('\n').getRecordSeparator());
        assertEquals("\n\n", CSVFormat.DEFAULT.withRecordSeparator("\n\n").getRecordSeparator());
    }

    @Test
    void testWithSystemRecordSeparator() {
        assertEquals(System.lineSeparator(), CSVFormat.DEFAULT.withSystemRecordSeparator().getRecordSeparator());
    }

    @Test
    void testWithIgnoreEmptyLinesNoArgAndArg() {
        assertTrue(CSVFormat.RFC4180.withIgnoreEmptyLines().getIgnoreEmptyLines());
        assertFalse(CSVFormat.DEFAULT.withIgnoreEmptyLines(false).getIgnoreEmptyLines());
    }

    @Test
    void testWithIgnoreHeaderCaseNoArgAndArg() {
        assertTrue(CSVFormat.DEFAULT.withIgnoreHeaderCase().getIgnoreHeaderCase());
        assertFalse(CSVFormat.DEFAULT.withIgnoreHeaderCase(false).getIgnoreHeaderCase());
    }

    @Test
    void testWithIgnoreSurroundingSpacesNoArgAndArg() {
        assertTrue(CSVFormat.DEFAULT.withIgnoreSurroundingSpaces().getIgnoreSurroundingSpaces());
        assertFalse(CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(false).getIgnoreSurroundingSpaces());
    }

    @Test
    void testWithSkipHeaderRecordNoArgAndArg() {
        assertTrue(CSVFormat.DEFAULT.withSkipHeaderRecord().getSkipHeaderRecord());
        assertFalse(CSVFormat.DEFAULT.withSkipHeaderRecord(false).getSkipHeaderRecord());
    }

    @Test
    void testWithTrailingDelimiterNoArgAndArg() {
        assertTrue(CSVFormat.DEFAULT.withTrailingDelimiter().getTrailingDelimiter());
        assertFalse(CSVFormat.DEFAULT.withTrailingDelimiter(false).getTrailingDelimiter());
    }

    @Test
    void testWithTrimNoArgAndArg() {
        assertTrue(CSVFormat.DEFAULT.withTrim().getTrim());
        assertFalse(CSVFormat.DEFAULT.withTrim(false).getTrim());
    }

    @Test
    void testWithAllowMissingColumnNamesNoArgAndArg() {
        assertTrue(CSVFormat.DEFAULT.withAllowMissingColumnNames().getAllowMissingColumnNames());
        assertFalse(CSVFormat.DEFAULT.withAllowMissingColumnNames(false).getAllowMissingColumnNames());
    }

    @Test
    void testWithAllowDuplicateHeaderNamesNoArgAndArg() {
        assertTrue(CSVFormat.DEFAULT.withAllowDuplicateHeaderNames().getAllowDuplicateHeaderNames());
        assertFalse(CSVFormat.DEFAULT.withAllowDuplicateHeaderNames(false).getAllowDuplicateHeaderNames());
    }

    @Test
    void testWithAutoFlush() {
        assertTrue(CSVFormat.DEFAULT.withAutoFlush(true).getAutoFlush());
    }

    @Test
    void testWithFirstRecordAsHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.withFirstRecordAsHeader();
        assertTrue(format.getSkipHeaderRecord());
        assertArrayEquals(new String[0], format.getHeader());
    }

    @Test
    void testWithHeaderEnumClass() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader(Header.class);
        assertArrayEquals(new String[] {"Name", "Email", "Phone"}, format.getHeader());
    }

    @Test
    void testWithHeaderEnumClassNull() {
        assertNull(CSVFormat.DEFAULT.withHeader((Class<? extends Enum<?>>) null).getHeader());
    }

    @Test
    void testWithHeaderResultSet() throws SQLException {
        final ResultSet resultSet = resultSetOf(metaDataOf("X", "Y"));
        assertArrayEquals(new String[] {"X", "Y"}, CSVFormat.DEFAULT.withHeader(resultSet).getHeader());
    }

    @Test
    void testWithHeaderResultSetMetaData() throws SQLException {
        final ResultSetMetaData metaData = metaDataOf("P", "Q");
        assertArrayEquals(new String[] {"P", "Q"}, CSVFormat.DEFAULT.withHeader(metaData).getHeader());
    }
}
