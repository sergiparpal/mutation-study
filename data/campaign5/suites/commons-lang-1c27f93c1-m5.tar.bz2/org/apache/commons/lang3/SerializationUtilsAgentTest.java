/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InvalidObjectException;
import java.io.OutputStream;
import java.io.Serializable;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link SerializationUtils}.
 */
class SerializationUtilsAgentTest {

    /** A simple serializable fixture with value semantics for equality checks. */
    static final class Fixture implements Serializable {
        private static final long serialVersionUID = 1L;
        private final int value;
        private final String name;

        Fixture(final int value, final String name) {
            this.value = value;
            this.name = name;
        }

        @Override
        public boolean equals(final Object obj) {
            if (!(obj instanceof Fixture)) {
                return false;
            }
            final Fixture other = (Fixture) obj;
            return value == other.value && name.equals(other.name);
        }

        @Override
        public int hashCode() {
            return value * 31 + name.hashCode();
        }
    }

    /** Implements Serializable but holds a non-serializable field, so writing it must fail. */
    static final class NotReallySerializable implements Serializable {
        private static final long serialVersionUID = 1L;
        @SuppressWarnings("unused")
        private final Object notSerializable = new Object();
    }

    interface Greeter {
        String greet();
    }

    static final class GreetingHandler implements InvocationHandler, Serializable {
        private static final long serialVersionUID = 1L;

        @Override
        public Object invoke(final Object proxy, final Method method, final Object[] args) {
            return "hello";
        }
    }

    @Test
    void testCloneNull() {
        assertNull(SerializationUtils.clone(null));
    }

    @Test
    void testCloneReturnsEqualButDistinctObject() {
        final Fixture original = new Fixture(42, "answer");
        final Fixture cloned = SerializationUtils.clone(original);
        assertNotSame(original, cloned);
        assertEquals(original, cloned);
        assertEquals(Fixture.class, cloned.getClass());
    }

    @Test
    void testCloneArrayList() {
        final ArrayList<String> original = new ArrayList<>();
        original.add("a");
        original.add("b");
        final ArrayList<String> cloned = SerializationUtils.clone(original);
        assertNotSame(original, cloned);
        assertEquals(original, cloned);
    }

    @Test
    void testCloneOfObjectWithDynamicProxyField() {
        final Greeter proxy = (Greeter) Proxy.newProxyInstance(getClass().getClassLoader(), new Class[] {Greeter.class}, new GreetingHandler());
        assertTrue(proxy instanceof Serializable);
        final Greeter cloned = SerializationUtils.clone((Serializable & Greeter) proxy);
        assertNotSame(proxy, cloned);
        assertEquals("hello", cloned.greet());
    }

    @Test
    void testCloneOfNonSerializableFieldThrows() {
        assertThrows(SerializationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                SerializationUtils.clone(new NotReallySerializable());
            }
        });
    }

    @Test
    void testSerializeDeserializeRoundtripBytes() {
        final Fixture original = new Fixture(7, "seven");
        final byte[] bytes = SerializationUtils.serialize(original);
        assertNotNull(bytes);
        assertTrue(bytes.length > 0);
        final Fixture result = SerializationUtils.deserialize(bytes);
        assertEquals(original, result);
        assertNotSame(original, result);
    }

    @Test
    void testSerializeNullObjectProducesDeserializableNull() {
        final byte[] bytes = SerializationUtils.serialize(null);
        assertNotNull(bytes);
        final Object result = SerializationUtils.deserialize(bytes);
        assertNull(result);
    }

    @Test
    void testSerializeToOutputStreamNullOutputStreamThrowsNpe() {
        final OutputStream nullOut = null;
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                SerializationUtils.serialize(new Fixture(1, "x"), nullOut);
            }
        });
    }

    @Test
    void testSerializeToOutputStreamWritesExpectedBytes() {
        final Fixture original = new Fixture(99, "ninety-nine");
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        SerializationUtils.serialize(original, baos);
        final byte[] viaStream = baos.toByteArray();
        final byte[] viaArray = SerializationUtils.serialize(original);
        assertArrayEquals(viaArray, viaStream);
    }

    @Test
    void testDeserializeNullByteArrayThrowsNpe() {
        final byte[] nullArray = null;
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                SerializationUtils.deserialize(nullArray);
            }
        });
    }

    @Test
    void testDeserializeNullInputStreamThrowsNpe() {
        final InputStream nullStream = null;
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                SerializationUtils.deserialize(nullStream);
            }
        });
    }

    @Test
    void testDeserializeEmptyByteArrayThrowsSerializationException() {
        final byte[] empty = new byte[0];
        assertThrows(SerializationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                SerializationUtils.deserialize(empty);
            }
        });
    }

    @Test
    void testDeserializeGarbageBytesThrowsSerializationException() {
        final byte[] garbage = {1, 2, 3, 4, 5};
        assertThrows(SerializationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                SerializationUtils.deserialize(garbage);
            }
        });
    }

    @Test
    void testDeserializeFromInputStream() {
        final Fixture original = new Fixture(5, "five");
        final byte[] bytes = SerializationUtils.serialize(original);
        final InputStream in = new ByteArrayInputStream(bytes);
        final Fixture result = SerializationUtils.deserialize(in);
        assertEquals(original, result);
    }

    @Test
    void testRoundtrip() {
        final Fixture original = new Fixture(123, "onetwothree");
        final Fixture result = SerializationUtils.roundtrip(original);
        assertNotSame(original, result);
        assertEquals(original, result);
    }

    @Test
    void testRoundtripNull() {
        final Fixture result = SerializationUtils.roundtrip(null);
        assertNull(result);
    }

    @Test
    void testRequireNonNullReturnsSameInstance() throws InvalidObjectException {
        final Fixture fixture = new Fixture(1, "one");
        final Fixture result = SerializationUtils.requireNonNull(fixture, "must not be null");
        assertSame(fixture, result);
    }

    @Test
    void testRequireNonNullWithNullThrowsInvalidObjectExceptionWithMessage() {
        final InvalidObjectException ex = assertThrows(InvalidObjectException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws InvalidObjectException {
                SerializationUtils.requireNonNull(null, "boom");
            }
        });
        assertEquals("boom", ex.getMessage());
    }

    @Test
    void testPublicConstructorIsUsable() {
        assertNotNull(new SerializationUtils());
    }

    @Test
    void testCloneListIsIndependentCopy() {
        final List<String> original = new ArrayList<>();
        original.add("one");
        final List<String> cloned = SerializationUtils.clone((ArrayList<String>) original);
        cloned.add("two");
        assertEquals(1, original.size());
        assertEquals(2, cloned.size());
    }
}
