/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link AnnotationUtils}.
 */
class AnnotationUtilsAgentTest {

    @Retention(RetentionPolicy.RUNTIME)
    @interface Nested {
        String value();
    }

    enum Color {
        RED, GREEN, BLUE
    }

    @Retention(RetentionPolicy.RUNTIME)
    @interface Complex {
        Color color();
        Nested nested();
        Nested[] nesteds();
        String name();
        int number();
        int[] numbers();
        Class<?> type();
    }

    @Retention(RetentionPolicy.RUNTIME)
    @interface Simple {
        String value();
    }

    @Complex(name = "a", number = 1, numbers = {1, 2, 3}, type = String.class, color = Color.RED,
            nested = @Nested("x"), nesteds = {@Nested("x"), @Nested("y")})
    void annotatedMethod1() {
        // fixture, intentionally empty
    }

    @Complex(name = "a", number = 1, numbers = {1, 2, 3}, type = String.class, color = Color.RED,
            nested = @Nested("x"), nesteds = {@Nested("x"), @Nested("y")})
    void annotatedMethod2() {
        // fixture, intentionally empty
    }

    @Complex(name = "b", number = 2, numbers = {4, 5}, type = Integer.class, color = Color.BLUE,
            nested = @Nested("z"), nesteds = {})
    void annotatedMethod3() {
        // fixture, intentionally empty
    }

    @Simple("hello")
    void simpleAnnotatedMethod() {
        // fixture, intentionally empty
    }

    private Complex getComplex(final String methodName) throws NoSuchMethodException {
        return getClass().getDeclaredMethod(methodName).getAnnotation(Complex.class);
    }

    private Simple getSimple() throws NoSuchMethodException {
        return getClass().getDeclaredMethod("simpleAnnotatedMethod").getAnnotation(Simple.class);
    }

    /**
     * Builds a proxy for {@link Simple} whose {@code value()} member returns the given value
     * (possibly {@code null}) and whose {@code annotationType()} returns the given type
     * (possibly {@code null}, to exercise error paths that real annotation instances cannot).
     */
    private Simple buildSimpleProxy(final String value, final Class<? extends Annotation> annotationType) {
        return (Simple) Proxy.newProxyInstance(getClass().getClassLoader(), new Class<?>[] {Simple.class},
                new InvocationHandler() {
                    @Override
                    public Object invoke(final Object proxy, final Method method, final Object[] args) {
                        final String methodName = method.getName();
                        if ("value".equals(methodName)) {
                            return value;
                        }
                        if ("annotationType".equals(methodName)) {
                            return annotationType;
                        }
                        if ("equals".equals(methodName)) {
                            return proxy == args[0];
                        }
                        if ("hashCode".equals(methodName)) {
                            return System.identityHashCode(proxy);
                        }
                        if ("toString".equals(methodName)) {
                            return "SimpleProxy";
                        }
                        return null;
                    }
                });
    }

    @Test
    void testEqualsBothNull() {
        assertTrue(AnnotationUtils.equals(null, null));
    }

    @Test
    void testEqualsOneNull() throws NoSuchMethodException {
        final Complex a1 = getComplex("annotatedMethod1");
        assertFalse(AnnotationUtils.equals(a1, null));
        assertFalse(AnnotationUtils.equals(null, a1));
    }

    @Test
    void testEqualsSameInstance() throws NoSuchMethodException {
        final Complex a1 = getComplex("annotatedMethod1");
        assertTrue(AnnotationUtils.equals(a1, a1));
    }

    @Test
    void testEqualsEqualValuesDifferentInstances() throws NoSuchMethodException {
        final Complex a1 = getComplex("annotatedMethod1");
        final Complex a2 = getComplex("annotatedMethod2");
        assertTrue(AnnotationUtils.equals(a1, a2));
        assertTrue(AnnotationUtils.equals(a2, a1));
    }

    @Test
    void testEqualsDifferentValues() throws NoSuchMethodException {
        final Complex a1 = getComplex("annotatedMethod1");
        final Complex a3 = getComplex("annotatedMethod3");
        assertFalse(AnnotationUtils.equals(a1, a3));
        assertFalse(AnnotationUtils.equals(a3, a1));
    }

    @Test
    void testEqualsDifferentAnnotationTypes() throws NoSuchMethodException {
        final Complex a1 = getComplex("annotatedMethod1");
        final Simple s = getSimple();
        assertFalse(AnnotationUtils.equals(a1, s));
    }

    @Test
    void testEqualsThrowsOnNullAnnotationType() throws NoSuchMethodException {
        final Complex a1 = getComplex("annotatedMethod1");
        final Simple proxy = buildSimpleProxy("hello", null);
        assertThrows(NullPointerException.class, () -> AnnotationUtils.equals(proxy, a1));
        assertThrows(NullPointerException.class, () -> AnnotationUtils.equals(a1, proxy));
    }

    @Test
    void testHashCodeMatchesJdkAnnotationHashCode() throws NoSuchMethodException {
        final Complex a1 = getComplex("annotatedMethod1");
        assertEquals(a1.hashCode(), AnnotationUtils.hashCode(a1));
    }

    @Test
    void testHashCodeConsistentForEqualAnnotations() throws NoSuchMethodException {
        final Complex a1 = getComplex("annotatedMethod1");
        final Complex a2 = getComplex("annotatedMethod2");
        assertEquals(AnnotationUtils.hashCode(a1), AnnotationUtils.hashCode(a2));
    }

    @Test
    void testHashCodeDifferentForDifferentAnnotations() throws NoSuchMethodException {
        final Complex a1 = getComplex("annotatedMethod1");
        final Complex a3 = getComplex("annotatedMethod3");
        assertFalse(AnnotationUtils.hashCode(a1) == AnnotationUtils.hashCode(a3));
    }

    @Test
    void testHashCodeThrowsOnNullMemberValue() {
        final Simple proxy = buildSimpleProxy(null, Simple.class);
        final IllegalStateException ex = assertThrows(IllegalStateException.class,
                () -> AnnotationUtils.hashCode(proxy));
        assertTrue(ex.getMessage().contains("returned null"));
    }

    @Test
    void testIsValidAnnotationMemberTypeNull() {
        assertFalse(AnnotationUtils.isValidAnnotationMemberType(null));
    }

    @Test
    void testIsValidAnnotationMemberTypePrimitives() {
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(int.class));
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(boolean.class));
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(double.class));
    }

    @Test
    void testIsValidAnnotationMemberTypeStringClassEnumAnnotation() {
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(String.class));
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(Class.class));
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(Color.class));
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(Simple.class));
    }

    @Test
    void testIsValidAnnotationMemberTypeArrays() {
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(int[].class));
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(String[].class));
        assertFalse(AnnotationUtils.isValidAnnotationMemberType(Object[].class));
    }

    @Test
    void testIsValidAnnotationMemberTypeInvalidTypes() {
        assertFalse(AnnotationUtils.isValidAnnotationMemberType(Object.class));
        assertFalse(AnnotationUtils.isValidAnnotationMemberType(Integer.class));
    }

    @Test
    void testToStringContainsAnnotationNameAndMember() throws NoSuchMethodException {
        final Simple s = getSimple();
        final String result = AnnotationUtils.toString(s);
        assertNotNull(result);
        assertTrue(result.contains("@" + Simple.class.getName()), result);
        assertTrue(result.contains("value"), result);
        assertTrue(result.contains("hello"), result);
    }

    @Test
    void testToStringThrowsOnNull() {
        assertThrows(NullPointerException.class, () -> AnnotationUtils.toString(null));
    }

    @Test
    void testConstructorIsPublic() {
        final AnnotationUtils instance = new AnnotationUtils();
        assertNotNull(instance);
    }
}
