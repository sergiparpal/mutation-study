/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

class CSVFormatAgentTest {

    private enum FixtureHeader {
        NAME, EMAIL, PHONE
    }

    @Test
    void testNewFormat() {
        final CSVFormat format = CSVFormat.newFormat('!');
        assertEquals("!", format.getDelimiterString());
        assertNull(format.getQuoteCharacter());
        assertNull(format.getCommentMarker());
        assertNull(format.getRecordSeparator());
        assertFalse(format.getIgnoreEmptyLines());
        assertFalse(format.isQuoteCharacterSet());
    }

    @Test
    void testNewFormatRejectsLineBreakDelimiter() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.newFormat('\n');
            }
        });
    }

    @Test
    void testValueOfPredefined() {
        final CSVFormat format = CSVFormat.valueOf("Default");
        assertEquals(CSVFormat.DEFAULT, format);
        assertEquals(CSVFormat.Predefined.Default.getFormat(), format);
    }

    @Test
    void testValueOfUnknownThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.valueOf("DoesNotExist");
            }
        });
    }

    @Test
    void testDefaultFormatProperties() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertTrue(format.getIgnoreEmptyLines());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
    }

    @Test
    void testExcelFormatProperties() {
        final CSVFormat format = CSVFormat.EXCEL;
        assertFalse(format.getIgnoreEmptyLines());
        assertTrue(format.getAllowMissingColumnNames());
        assertTrue(format.getTrailingData());
        assertTrue(format.getLenientEof());
    }

    @Test
    void testRfc4180DisablesIgnoreEmptyLines() {
        assertFalse(CSVFormat.RFC4180.getIgnoreEmptyLines());
    }

    @Test
    void testMySqlFormatProperties() {
        final CSVFormat format = CSVFormat.MYSQL;
        assertEquals("\t", format.getDelimiterString());
        assertNull(format.getQuoteCharacter());
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
        assertEquals("\n", format.getRecordSeparator());
        assertEquals("\\N", format.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, format.getQuoteMode());
    }

    @Test
    void testTdfFormatProperties() {
        final CSVFormat format = CSVFormat.TDF;
        assertEquals("\t", format.getDelimiterString());
        assertTrue(format.getIgnoreSurroundingSpaces());
    }

    @Test
    void testBuilderSetDelimiterEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDelimiter("");
            }
        });
    }

    @Test
    void testBuilderSetDelimiterLineBreakThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDelimiter('\r');
            }
        });
    }

    @Test
    void testBuilderSetCommentMarkerLineBreakThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setCommentMarker('\n');
            }
        });
    }

    @Test
    void testBuilderSetEscapeLineBreakThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setEscape('\r');
            }
        });
    }

    @Test
    void testBuilderSetQuoteLineBreakThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setQuote('\n');
            }
        });
    }

    @Test
    void testBuilderSetDuplicateHeaderModeNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(null);
            }
        });
    }

    @Test
    void testValidateQuoteEqualsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDelimiter(',').setQuote(',').get();
            }
        });
    }

    @Test
    void testValidateEscapeEqualsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDelimiter(',').setQuote(null).setEscape(',').get();
            }
        });
    }

    @Test
    void testValidateCommentEqualsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDelimiter(',').setCommentMarker(',').get();
            }
        });
    }

    @Test
    void testValidateQuoteEqualsCommentThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setQuote('#').setCommentMarker('#').get();
            }
        });
    }

    @Test
    void testValidateEscapeEqualsCommentThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setQuote(null).setEscape('#').setCommentMarker('#').get();
            }
        });
    }

    @Test
    void testValidateQuoteModeNoneWithoutEscapeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setEscape(null).setQuoteMode(QuoteMode.NONE).get();
            }
        });
    }

    @Test
    void testValidateQuoteModeNoneWithEscapeIsAllowed() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').setQuoteMode(QuoteMode.NONE).get();
        assertEquals(QuoteMode.NONE, format.getQuoteMode());
    }

    @Test
    void testValidateDuplicateHeadersAllowedByDefaultBuilder() {
        final CSVFormat format = CSVFormat.Builder.create().setHeader("A", "A").get();
        assertArrayEquals(new String[] { "A", "A" }, format.getHeader());
    }

    @Test
    void testValidateDuplicateHeadersAllowedWithAllowAllMode() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("A", "A").setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_ALL).get();
        assertArrayEquals(new String[] { "A", "A" }, format.getHeader());
    }

    @Test
    void testValidateDuplicateHeadersDisallowModeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setHeader("A", "A").setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).get();
            }
        });
    }

    @Test
    void testValidateDuplicateHeadersAllowEmptyModeAllowsBlanks() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("A", "", "B", "")
                .setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).get();
        assertArrayEquals(new String[] { "A", "", "B", "" }, format.getHeader());
    }

    @Test
    void testValidateDuplicateHeadersAllowEmptyModeRejectsNonBlankDuplicates() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setHeader("A", "A").setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).get();
            }
        });
    }

    @Test
    void testGetHeaderReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("A", "B").get();
        final String[] header1 = format.getHeader();
        header1[0] = "MUTATED";
        final String[] header2 = format.getHeader();
        assertEquals("A", header2[0]);
        assertNotSame(header1, header2);
    }

    @Test
    void testGetHeaderNullWhenDisabled() {
        assertNull(CSVFormat.DEFAULT.getHeader());
    }

    @Test
    void testGetHeaderCommentsReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeaderComments("one", "two").get();
        final String[] comments1 = format.getHeaderComments();
        comments1[0] = "MUTATED";
        final String[] comments2 = format.getHeaderComments();
        assertEquals("one", comments2[0]);
    }

    @Test
    void testGetHeaderCommentsNullByDefault() {
        assertNull(CSVFormat.DEFAULT.getHeaderComments());
    }

    @Test
    void testSetHeaderFromEnum() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(FixtureHeader.class).get();
        assertArrayEquals(new String[] { "NAME", "EMAIL", "PHONE" }, format.getHeader());
    }

    @Test
    void testSetHeaderFromNullEnumDisablesHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader((Class<? extends Enum<?>>) null).get();
        assertNull(format.getHeader());
    }

    @Test
    void testEqualsReflexiveAndNullSafe() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertEquals(format, format);
        assertNotEquals(null, format);
        assertNotEquals(format, "not a CSVFormat");
    }

    @Test
    void testEqualsAndHashCodeConsistentForEqualFormats() {
        final CSVFormat a = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        final CSVFormat b = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    void testEqualsFalseForDifferentDelimiter() {
        final CSVFormat a = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        final CSVFormat b = CSVFormat.DEFAULT.builder().setDelimiter(',').get();
        assertNotEquals(a, b);
    }

    @Test
    void testToStringContainsDelimiter() {
        final String s = CSVFormat.DEFAULT.toString();
        assertTrue(s.contains("Delimiter=<,>"));
    }

    @Test
    void testToStringContainsQuoteAndCommentWhenSet() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').setNullString("NULL").get();
        final String s = format.toString();
        assertTrue(s.contains("QuoteChar=<\">"));
        assertTrue(s.contains("CommentStart=<#>"));
        assertTrue(s.contains("NullString=<NULL>"));
    }

    @Test
    void testFormatProducesExpectedCsvLine() {
        final String line = CSVFormat.DEFAULT.format("a", "b,c", "d");
        assertEquals("a,\"b,c\",d", line);
    }

    @Test
    void testFormatWithEmptyValues() {
        final String line = CSVFormat.DEFAULT.format();
        assertEquals("", line);
    }

    @Test
    void testPrintRecordAppendsRecordSeparator() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.printRecord(writer, "x", "y");
        assertEquals("x,y\r\n", writer.toString());
    }

    @Test
    void testPrintlnWithTrailingDelimiter() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get();
        format.println(writer);
        assertEquals(",\r\n", writer.toString());
    }

    @Test
    void testPrintlnWithoutTrailingDelimiterOrSeparator() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setRecordSeparator(null).get();
        format.println(writer);
        assertEquals("", writer.toString());
    }

    @Test
    void testPrintObjectQuotesWhenNeeded() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.print("a,b", writer, true);
        assertEquals("\"a,b\"", writer.toString());
    }

    @Test
    void testPrintObjectNullUsesNullString() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        format.print(null, writer, true);
        assertEquals("NULL", writer.toString());
    }

    @Test
    void testPrintObjectAddsDelimiterWhenNotNewRecord() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.print("value", writer, false);
        assertEquals(",value", writer.toString());
    }

    @Test
    void testBuilderCopiesExistingFormat() {
        final CSVFormat original = CSVFormat.DEFAULT.builder().setDelimiter(';').setCommentMarker('#').get();
        final CSVFormat copy = original.builder().get();
        assertEquals(original, copy);
        assertNotSame(original, copy);
    }

    @Test
    void testDeprecatedGetDelimiterReturnsFirstChar() {
        assertEquals(',', CSVFormat.DEFAULT.getDelimiter());
    }

    @Test
    void testDeprecatedWithHeaderCopiesArray() {
        final String[] header = { "A", "B" };
        final CSVFormat format = CSVFormat.DEFAULT.withHeader(header);
        header[0] = "MUTATED";
        assertEquals("A", format.getHeader()[0]);
    }

    @Test
    void testDeprecatedWithQuoteCharacter() {
        final CSVFormat format = CSVFormat.DEFAULT.withQuote('\'');
        assertEquals(Character.valueOf('\''), format.getQuoteCharacter());
    }

    @Test
    void testDeprecatedWithAllowDuplicateHeaderNamesFalse() {
        final CSVFormat format = CSVFormat.DEFAULT.withAllowDuplicateHeaderNames(false);
        assertEquals(DuplicateHeaderMode.ALLOW_EMPTY, format.getDuplicateHeaderMode());
        assertFalse(format.getAllowDuplicateHeaderNames());
    }

    @Test
    void testDeprecatedWithFirstRecordAsHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.withFirstRecordAsHeader();
        assertTrue(format.getSkipHeaderRecord());
        assertArrayEquals(new String[0], format.getHeader());
    }

    @Test
    void testParseReadsRecords() throws IOException {
        try (CSVParser parser = CSVFormat.DEFAULT.parse(new StringReader("1,2,3"))) {
            final CSVRecord record = parser.iterator().next();
            assertEquals("1", record.get(0));
            assertEquals("2", record.get(1));
            assertEquals("3", record.get(2));
        }
    }

    @Test
    void testIsCommentMarkerSetAndIsEscapeCharacterSet() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').setEscape('\\').setQuote(null).get();
        assertTrue(format.isCommentMarkerSet());
        assertTrue(format.isEscapeCharacterSet());
        assertFalse(format.isQuoteCharacterSet());
        assertFalse(CSVFormat.DEFAULT.isCommentMarkerSet());
    }

    @Test
    void testIsNullStringSet() {
        assertFalse(CSVFormat.DEFAULT.isNullStringSet());
        assertTrue(CSVFormat.DEFAULT.builder().setNullString("NULL").get().isNullStringSet());
    }

    @Test
    void testGetMaxRowsDefaultIsZero() {
        assertEquals(0L, CSVFormat.DEFAULT.getMaxRows());
    }

    @Test
    void testSetMaxRows() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(5L).get();
        assertEquals(5L, format.getMaxRows());
    }
}
