/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link Lexer}.
 */
class LexerAgentTest {

    private static Lexer createLexer(final CSVFormat format, final String input) {
        return new Lexer(format, new ExtendedBufferedReader(new StringReader(input)));
    }

    private static Token nextToken(final Lexer lexer) throws IOException {
        final Token token = new Token();
        lexer.nextToken(token);
        return token;
    }

    @Test
    void testSimpleTokenAndEorecordAndEof() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a,b\nc");
        final Token t1 = nextToken(lexer);
        assertEquals(Token.Type.TOKEN, t1.type);
        assertEquals("a", t1.content.toString());

        final Token t2 = nextToken(lexer);
        assertEquals(Token.Type.EORECORD, t2.type);
        assertEquals("b", t2.content.toString());

        final Token t3 = nextToken(lexer);
        assertEquals(Token.Type.EOF, t3.type);
        assertEquals("c", t3.content.toString());
        assertTrue(t3.isReady);

        lexer.close();
    }

    @Test
    void testEmptyInputReturnsEofImmediately() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "");
        final Token token = nextToken(lexer);
        assertEquals(Token.Type.EOF, token.type);
        assertEquals(0, token.content.length());
        lexer.close();
    }

    @Test
    void testEmptyTokenBetweenDelimiters() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a,,b");
        final Token t1 = nextToken(lexer);
        assertEquals(Token.Type.TOKEN, t1.type);
        assertEquals("a", t1.content.toString());

        final Token t2 = nextToken(lexer);
        assertEquals(Token.Type.TOKEN, t2.type);
        assertEquals("", t2.content.toString());

        final Token t3 = nextToken(lexer);
        assertEquals(Token.Type.EOF, t3.type);
        assertEquals("b", t3.content.toString());
        lexer.close();
    }

    @Test
    void testIgnoreEmptyLinesSkipsBlankLines() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreEmptyLines(true).get();
        final Lexer lexer = createLexer(format, "a\n\n\nb\n");
        final Token t1 = nextToken(lexer);
        assertEquals(Token.Type.EORECORD, t1.type);
        assertEquals("a", t1.content.toString());

        final Token t2 = nextToken(lexer);
        assertEquals(Token.Type.EORECORD, t2.type);
        assertEquals("b", t2.content.toString());

        final Token t3 = nextToken(lexer);
        assertEquals(Token.Type.EOF, t3.type);
        lexer.close();
    }

    @Test
    void testEmptyLinesPreservedWhenNotIgnored() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreEmptyLines(false).get();
        final Lexer lexer = createLexer(format, "a\n\nb\n");
        final Token t1 = nextToken(lexer);
        assertEquals(Token.Type.EORECORD, t1.type);
        assertEquals("a", t1.content.toString());

        final Token t2 = nextToken(lexer);
        assertEquals(Token.Type.EORECORD, t2.type);
        assertEquals("", t2.content.toString());

        final Token t3 = nextToken(lexer);
        assertEquals(Token.Type.EORECORD, t3.type);
        assertEquals("b", t3.content.toString());
        lexer.close();
    }

    @Test
    void testTrailingEmptyLineAtEofWithIgnoreEmptyLines() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreEmptyLines(true).get();
        final Lexer lexer = createLexer(format, "a\n\n");
        final Token t1 = nextToken(lexer);
        assertEquals(Token.Type.EORECORD, t1.type);
        assertEquals("a", t1.content.toString());

        final Token t2 = nextToken(lexer);
        assertEquals(Token.Type.EOF, t2.type);
        assertFalse(t2.isReady);
        lexer.close();
    }

    @Test
    void testQuotedTokenSimple() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "\"hello\",world");
        final Token t1 = nextToken(lexer);
        assertEquals(Token.Type.TOKEN, t1.type);
        assertEquals("hello", t1.content.toString());
        assertTrue(t1.isQuoted);

        final Token t2 = nextToken(lexer);
        assertEquals(Token.Type.EOF, t2.type);
        assertEquals("world", t2.content.toString());
        assertFalse(t2.isQuoted);
        lexer.close();
    }

    @Test
    void testQuotedTokenWithEscapedQuote() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "\"a\"\"b\"");
        final Token token = nextToken(lexer);
        assertEquals(Token.Type.EOF, token.type);
        assertEquals("a\"b", token.content.toString());
        assertTrue(token.isReady);
        lexer.close();
    }

    @Test
    void testQuotedTokenFollowedByEorecord() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "\"a\"\n\"b\"");
        final Token t1 = nextToken(lexer);
        assertEquals(Token.Type.EORECORD, t1.type);
        assertEquals("a", t1.content.toString());

        final Token t2 = nextToken(lexer);
        assertEquals(Token.Type.EOF, t2.type);
        assertEquals("b", t2.content.toString());
        lexer.close();
    }

    @Test
    void testUnterminatedQuoteThrowsCsvException() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "\"abc");
        final CSVException exception = assertThrows(CSVException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                nextToken(lexer);
            }
        });
        assertTrue(exception.getMessage().contains("EOF"));
        lexer.close();
    }

    @Test
    void testLenientEofAllowsUnterminatedQuote() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setLenientEof(true).get();
        final Lexer lexer = createLexer(format, "\"abc");
        final Token token = nextToken(lexer);
        assertEquals(Token.Type.EOF, token.type);
        assertEquals("abc", token.content.toString());
        assertTrue(token.isReady);
        lexer.close();
    }

    @Test
    void testInvalidCharacterAfterEncapsulatedTokenThrows() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "\"abc\"x,d");
        final CSVException exception = assertThrows(CSVException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                nextToken(lexer);
            }
        });
        assertTrue(exception.getMessage().contains("Invalid character"));
        lexer.close();
    }

    @Test
    void testTrailingDataAllowsCharacterAfterEncapsulatedToken() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingData(true).get();
        final Lexer lexer = createLexer(format, "\"abc\"x,d");
        final Token t1 = nextToken(lexer);
        assertEquals(Token.Type.TOKEN, t1.type);
        assertEquals("abcx", t1.content.toString());

        final Token t2 = nextToken(lexer);
        assertEquals(Token.Type.EOF, t2.type);
        assertEquals("d", t2.content.toString());
        lexer.close();
    }

    @Test
    void testCommentLineIsTrimmedAndTyped() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final Lexer lexer = createLexer(format, "# a comment \na,b");
        final Token t1 = nextToken(lexer);
        assertEquals(Token.Type.COMMENT, t1.type);
        assertEquals("a comment", t1.content.toString());

        final Token t2 = nextToken(lexer);
        assertEquals(Token.Type.TOKEN, t2.type);
        assertEquals("a", t2.content.toString());

        final Token t3 = nextToken(lexer);
        assertEquals(Token.Type.EOF, t3.type);
        assertEquals("b", t3.content.toString());
        lexer.close();
    }

    @Test
    void testCommentAtEofWithoutTrailingNewlineIsStillAComment() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final Lexer lexer = createLexer(format, "#comment");
        final Token token = nextToken(lexer);
        assertEquals(Token.Type.COMMENT, token.type);
        assertEquals("comment", token.content.toString());

        final Token next = nextToken(lexer);
        assertEquals(Token.Type.EOF, next.type);
        lexer.close();
    }

    @Test
    void testEscapeHandlingInSimpleToken() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').setDelimiter(',').get();
        final Lexer lexer = createLexer(format, "a\\,b,c");
        final Token t1 = nextToken(lexer);
        assertEquals(Token.Type.TOKEN, t1.type);
        assertEquals("a,b", t1.content.toString());

        final Token t2 = nextToken(lexer);
        assertEquals(Token.Type.EOF, t2.type);
        assertEquals("c", t2.content.toString());
        lexer.close();
    }

    @Test
    void testEscapeHandlingInEncapsulatedToken() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').setQuote('"').get();
        final Lexer lexer = createLexer(format, "\"a\\nb\"");
        final Token token = nextToken(lexer);
        assertEquals(Token.Type.EOF, token.type);
        assertEquals("a\nb", token.content.toString());
        lexer.close();
    }

    @Test
    void testReadEscapeRecognizedSequences() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        assertEquals(Constants.CR, readEscapeOf(format, "r"));
        assertEquals(Constants.LF, readEscapeOf(format, "n"));
        assertEquals(Constants.TAB, readEscapeOf(format, "t"));
        assertEquals(Constants.BACKSPACE, readEscapeOf(format, "b"));
        assertEquals(Constants.FF, readEscapeOf(format, "f"));
    }

    private static int readEscapeOf(final CSVFormat format, final String afterEscape) throws IOException {
        final Lexer lexer = createLexer(format, afterEscape);
        try {
            return lexer.readEscape();
        } finally {
            lexer.close();
        }
    }

    @Test
    void testReadEscapeUnexpectedCharReturnsEof() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer(format, "x");
        assertEquals(org.apache.commons.io.IOUtils.EOF, lexer.readEscape());
        lexer.close();
    }

    @Test
    void testReadEscapeAtEndOfFileThrows() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer(format, "");
        assertThrows(CSVException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                lexer.readEscape();
            }
        });
        lexer.close();
    }

    @Test
    void testIgnoreSurroundingSpacesTrimsToken() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreSurroundingSpaces(true).get();
        final Lexer lexer = createLexer(format, "  a  , b ,c");
        final Token t1 = nextToken(lexer);
        assertEquals(Token.Type.TOKEN, t1.type);
        assertEquals("a", t1.content.toString());

        final Token t2 = nextToken(lexer);
        assertEquals(Token.Type.TOKEN, t2.type);
        assertEquals("b", t2.content.toString());

        final Token t3 = nextToken(lexer);
        assertEquals(Token.Type.EOF, t3.type);
        assertEquals("c", t3.content.toString());
        lexer.close();
    }

    @Test
    void testTrimTrailingSpaces() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "");
        final StringBuilder sb = new StringBuilder("abc   ");
        lexer.trimTrailingSpaces(sb);
        assertEquals("abc", sb.toString());

        final StringBuilder noTrailing = new StringBuilder("abc");
        lexer.trimTrailingSpaces(noTrailing);
        assertEquals("abc", noTrailing.toString());

        final StringBuilder allSpaces = new StringBuilder("   ");
        lexer.trimTrailingSpaces(allSpaces);
        assertEquals("", allSpaces.toString());

        final StringBuilder empty = new StringBuilder();
        lexer.trimTrailingSpaces(empty);
        assertEquals("", empty.toString());
        lexer.close();
    }

    @Test
    void testIsDelimiterSingleChar() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, ",x");
        assertTrue(lexer.isDelimiter(','));
        assertFalse(lexer.isDelimiter('a'));
        lexer.close();
    }

    @Test
    void testIsDelimiterMultiCharMatches() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader(":x"));
        final int first = reader.read();
        final Lexer lexer = new Lexer(format, reader);
        // first char matches but the rest of the stream does not continue the delimiter
        assertFalse(lexer.isDelimiter(first));
        lexer.close();
    }

    @Test
    void testMultiCharDelimiterTokenizesCorrectly() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        final Lexer lexer = createLexer(format, "a::b::c");
        final Token t1 = nextToken(lexer);
        assertEquals(Token.Type.TOKEN, t1.type);
        assertEquals("a", t1.content.toString());

        final Token t2 = nextToken(lexer);
        assertEquals(Token.Type.TOKEN, t2.type);
        assertEquals("b", t2.content.toString());

        final Token t3 = nextToken(lexer);
        assertEquals(Token.Type.EOF, t3.type);
        assertEquals("c", t3.content.toString());
        lexer.close();
    }

    @Test
    void testIsEscapeDelimiterTrueForEscapedMultiCharDelimiter() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").setEscape('!').get();
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("!:!:rest"));
        reader.read(); // consume the leading escape, as the caller normally does before checking
        final Lexer lexer = new Lexer(format, reader);
        assertTrue(lexer.isEscapeDelimiter());
        lexer.close();
    }

    @Test
    void testIsEscapeDelimiterFalseWhenNotMatching() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").setEscape('!').get();
        final Lexer lexer = createLexer(format, "abcdef");
        assertFalse(lexer.isEscapeDelimiter());
        lexer.close();
    }

    @Test
    void testIsEndOfFile() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "");
        assertTrue(lexer.isEndOfFile(org.apache.commons.io.IOUtils.EOF));
        assertFalse(lexer.isEndOfFile('a'));
        lexer.close();
    }

    @Test
    void testIsStartOfLine() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "");
        assertTrue(lexer.isStartOfLine(Constants.LF));
        assertTrue(lexer.isStartOfLine(Constants.CR));
        assertTrue(lexer.isStartOfLine(Constants.UNDEFINED));
        assertFalse(lexer.isStartOfLine('a'));
        lexer.close();
    }

    @Test
    void testIsQuoteCharAndIsEscapeAndIsCommentStart() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuote('\'').setEscape('\\').setCommentMarker('#').get();
        final Lexer lexer = createLexer(format, "");
        assertTrue(lexer.isQuoteChar('\''));
        assertFalse(lexer.isQuoteChar('"'));
        assertTrue(lexer.isEscape('\\'));
        assertFalse(lexer.isEscape('/'));
        assertTrue(lexer.isCommentStart('#'));
        assertFalse(lexer.isCommentStart('%'));
        lexer.close();
    }

    @Test
    void testReadEndOfLineTracksFirstEolForLf() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a\nb");
        assertEquals(null, lexer.getFirstEol());
        nextToken(lexer);
        assertEquals("\n", lexer.getFirstEol());
        lexer.close();
    }

    @Test
    void testReadEndOfLineTracksFirstEolForCr() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a\rb");
        nextToken(lexer);
        assertEquals("\r", lexer.getFirstEol());
        lexer.close();
    }

    @Test
    void testReadEndOfLineTracksFirstEolForCrLf() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a\r\nb");
        nextToken(lexer);
        assertEquals("\r\n", lexer.getFirstEol());
        lexer.close();
    }

    @Test
    void testGetCurrentLineNumberAndCharacterPositionAdvance() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "a,b\nc,d");
        assertEquals(0, lexer.getCurrentLineNumber());
        assertEquals(0, lexer.getCharacterPosition());
        nextToken(lexer); // "a"
        nextToken(lexer); // "b" EORECORD, consumes the newline
        assertEquals(1, lexer.getCurrentLineNumber());
        assertTrue(lexer.getCharacterPosition() > 0);
        lexer.close();
    }

    @Test
    void testGetBytesReadWithoutByteTrackingStaysZero() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "abc");
        assertEquals(0, lexer.getBytesRead());
        nextToken(lexer);
        assertEquals(0, lexer.getBytesRead());
        lexer.close();
    }

    @Test
    void testGetBytesReadWithByteTrackingEnabledAdvances() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"), java.nio.charset.StandardCharsets.UTF_8, true);
        final Lexer lexer = new Lexer(CSVFormat.DEFAULT, reader);
        assertEquals(0, lexer.getBytesRead());
        nextToken(lexer);
        assertEquals(3, lexer.getBytesRead());
        lexer.close();
    }

    @Test
    void testCloseAndIsClosed() throws IOException {
        final Lexer lexer = createLexer(CSVFormat.DEFAULT, "abc");
        assertFalse(lexer.isClosed());
        lexer.close();
        assertTrue(lexer.isClosed());
    }
}
