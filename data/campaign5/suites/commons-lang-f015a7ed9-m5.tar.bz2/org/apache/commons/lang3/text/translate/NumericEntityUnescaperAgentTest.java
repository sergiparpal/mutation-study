/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3.text.translate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Tests for {@link org.apache.commons.lang3.text.translate.NumericEntityUnescaper}.
 */
@Deprecated
class NumericEntityUnescaperAgentTest {

    @Test
    void testDefaultOptionIsSemiColonRequired() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertTrue(neu.isSet(NumericEntityUnescaper.OPTION.semiColonRequired));
        assertFalse(neu.isSet(NumericEntityUnescaper.OPTION.semiColonOptional));
        assertFalse(neu.isSet(NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
    }

    @Test
    void testIsSetWithExplicitOptions() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.semiColonOptional,
                NumericEntityUnescaper.OPTION.errorIfNoSemiColon);
        assertTrue(neu.isSet(NumericEntityUnescaper.OPTION.semiColonOptional));
        assertTrue(neu.isSet(NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
        assertFalse(neu.isSet(NumericEntityUnescaper.OPTION.semiColonRequired));
    }

    @Test
    void testDecimalWithSemiColon() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("A", neu.translate("&#65;"));
    }

    @Test
    void testHexWithSemiColonLowerX() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("A", neu.translate("&#x41;"));
    }

    @Test
    void testHexWithSemiColonUpperX() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("A", neu.translate("&#X41;"));
    }

    @Test
    void testSemiColonRequiredButMissingLeavesUntranslated() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.semiColonRequired);
        assertEquals("&#65", neu.translate("&#65"));
    }

    @Test
    void testSemiColonOptionalWithoutSemiColon() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.semiColonOptional);
        assertEquals("A", neu.translate("&#65"));
    }

    @Test
    void testSemiColonOptionalWithSemiColon() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.semiColonOptional);
        assertEquals("A", neu.translate("&#65;"));
    }

    @Test
    void testErrorIfNoSemiColonThrows() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.errorIfNoSemiColon);
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                neu.translate("&#65");
            }
        });
        assertEquals("Semi-colon required at end of numeric entity", ex.getMessage());
    }

    @Test
    void testTrailingTextAfterSemiColon() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("A and", neu.translate("&#65; and"));
    }

    @Test
    void testTrailingTextWithoutSemiColonOptional() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.semiColonOptional);
        assertEquals("A and", neu.translate("&#65 and"));
    }

    @Test
    void testSupplementaryCodePoint() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final String expected = new String(Character.toChars(0x1D161));
        assertEquals(expected, neu.translate("&#119137;"));
    }

    @Test
    void testCodePointOutOfRangeIsUntranslated() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final String input = "&#1114112;";
        assertEquals(input, neu.translate(input));
    }

    @Test
    void testNonHexCharacterStopsHexParsing() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("&#x;", neu.translate("&#x;"));
    }

    @Test
    void testHexMissingDigitsAfterX() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final String input = "&#x";
        assertEquals(input, neu.translate(input));
    }

    @Test
    void testNotAnEntityNoAmpersand() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("hello", neu.translate("hello"));
    }

    @Test
    void testAmpersandWithoutHash() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("&amp;", neu.translate("&amp;"));
    }

    @Test
    void testTranslateReturnsConsumedCharCountDecimalWithSemiColon() throws java.io.IOException {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final java.io.StringWriter writer = new java.io.StringWriter();
        final int consumed = neu.translate("&#65;rest", 0, writer);
        assertEquals(5, consumed);
        assertEquals("A", writer.toString());
    }

    @Test
    void testTranslateReturnsConsumedCharCountHexWithSemiColon() throws java.io.IOException {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final java.io.StringWriter writer = new java.io.StringWriter();
        final int consumed = neu.translate("&#x41;rest", 0, writer);
        assertEquals(6, consumed);
        assertEquals("A", writer.toString());
    }

    @Test
    void testTranslateReturnsZeroWhenNoMatch() throws java.io.IOException {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final java.io.StringWriter writer = new java.io.StringWriter();
        final int consumed = neu.translate("no entity here", 0, writer);
        assertEquals(0, consumed);
        assertEquals("", writer.toString());
    }

    @Test
    void testInputTooShortForEntityPrefix() throws java.io.IOException {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final java.io.StringWriter writer = new java.io.StringWriter();
        final int consumed = neu.translate("&#", 0, writer);
        assertEquals(0, consumed);
        assertEquals("", writer.toString());
    }

    @Test
    void testInvalidNumberFormatLeavesUntranslated() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final String input = "&#;";
        assertEquals(input, neu.translate(input));
    }

    @Test
    void testZeroCodePoint() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("\u0000", neu.translate("&#0;"));
    }

    @Test
    void testMaxCodePoint() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final String expected = new String(Character.toChars(Character.MAX_CODE_POINT));
        assertEquals(expected, neu.translate("&#" + Character.MAX_CODE_POINT + ";"));
    }
}
