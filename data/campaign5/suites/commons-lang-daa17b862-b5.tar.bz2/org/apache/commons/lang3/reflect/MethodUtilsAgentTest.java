/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.annotation.Annotation;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.ClassUtils.Interfaces;
import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link MethodUtils}.
 */
class MethodUtilsAgentTest {

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    private @interface AgentAnno {
    }

    public interface AgentPublicInterface {
        void publicMethod();
    }

    static class AgentPackagePrivateImpl implements AgentPublicInterface {
        @Override
        public void publicMethod() {
            // no-op
        }
    }

    public static class AgentAnnoParent {
        @AgentAnno
        public void annotatedMethod() {
            // no-op
        }

        @AgentAnno
        private void privateAnnotatedMethod() {
            // no-op
        }
    }

    public static class AgentAnnoChild extends AgentAnnoParent {
        @Override
        public void annotatedMethod() {
            // overridden, no annotation here
        }
    }

    public static class AgentAmbiguous {
        public void ambiguous(final String s) {
            // no-op
        }

        public void ambiguous(final Long l) {
            // no-op
        }
    }

    public static class AgentFoo {

        public String methodReturningString() {
            return "foo";
        }

        public String methodWithArg(final String s) {
            return "echo:" + s;
        }

        public static String staticMethod(final String s) {
            return "static:" + s;
        }

        private String privateMethod() {
            return "private";
        }

        public String throwingMethod() {
            throw new IllegalStateException("boom");
        }

        public String varArgsMethod(final String... args) {
            final StringBuilder sb = new StringBuilder();
            for (final String a : args) {
                if (sb.length() > 0) {
                    sb.append(',');
                }
                sb.append(a);
            }
            return sb.toString();
        }

        public int intVarArgsMethod(final int... nums) {
            int sum = 0;
            for (final int n : nums) {
                sum += n;
            }
            return sum;
        }
    }

    public static class AgentBase {
        public String overridden() {
            return "base";
        }
    }

    public static class AgentDerived extends AgentBase {
        @Override
        public String overridden() {
            return "derived";
        }
    }

    public static class AgentVarArgHolder {
        public static String join(final String sep, final Object... parts) {
            final StringBuilder sb = new StringBuilder();
            for (final Object p : parts) {
                if (sb.length() > 0) {
                    sb.append(sep);
                }
                sb.append(p);
            }
            return sb.toString();
        }
    }

    public static class AgentVarArgHolder2 {
        public static String join(final String... parts) {
            final StringBuilder sb = new StringBuilder();
            for (final String p : parts) {
                sb.append(p);
            }
            return sb.toString();
        }
    }

    @Test
    void testGetAccessibleMethod_viaInterfaceNest() throws Exception {
        final Method declared = AgentPackagePrivateImpl.class.getMethod("publicMethod");
        final Method accessible = MethodUtils.getAccessibleMethod(AgentPackagePrivateImpl.class, declared);
        assertNotNull(accessible);
        assertEquals(AgentPublicInterface.class, accessible.getDeclaringClass());
    }

    @Test
    void testGetAccessibleMethod_nullMethod() {
        assertNull(MethodUtils.getAccessibleMethod(AgentFoo.class, (Method) null));
    }

    @Test
    void testGetAccessibleMethod_byNameAndTypes() {
        final Method m = MethodUtils.getAccessibleMethod(AgentFoo.class, "methodWithArg", String.class);
        assertNotNull(m);
        assertEquals("methodWithArg", m.getName());
        assertNull(MethodUtils.getAccessibleMethod(AgentFoo.class, "noSuchMethod"));
    }

    @Test
    void testGetAccessibleMethod_fromMethodOnly() throws Exception {
        final Method declared = AgentPackagePrivateImpl.class.getMethod("publicMethod");
        final Method accessible = MethodUtils.getAccessibleMethod(declared);
        assertNotNull(accessible);
        assertNull(MethodUtils.getAccessibleMethod((Method) null));
    }

    @Test
    void testGetAnnotation_directPresent() throws Exception {
        final Method m = AgentAnnoParent.class.getMethod("annotatedMethod");
        final AgentAnno anno = MethodUtils.getAnnotation(m, AgentAnno.class, false, false);
        assertNotNull(anno);
    }

    @Test
    void testGetAnnotation_notPresentWithoutSearchSupers() throws Exception {
        final Method m = AgentAnnoChild.class.getMethod("annotatedMethod");
        assertNull(MethodUtils.getAnnotation(m, AgentAnno.class, false, false));
    }

    @Test
    void testGetAnnotation_foundViaSearchSupers() throws Exception {
        final Method m = AgentAnnoChild.class.getMethod("annotatedMethod");
        final AgentAnno anno = MethodUtils.getAnnotation(m, AgentAnno.class, true, true);
        assertNotNull(anno);
    }

    @Test
    void testGetAnnotation_nullArgumentsThrow() throws Exception {
        final Method m = AgentAnnoParent.class.getMethod("annotatedMethod");
        assertThrows(NullPointerException.class, () -> MethodUtils.getAnnotation(null, AgentAnno.class, false, false));
        assertThrows(NullPointerException.class, () -> MethodUtils.getAnnotation(m, null, false, false));
    }

    @Test
    void testGetMatchingAccessibleMethod_exactAndAssignable() {
        final Method exact = MethodUtils.getMatchingAccessibleMethod(AgentFoo.class, "methodWithArg", String.class);
        assertNotNull(exact);
        assertEquals(String.class, exact.getParameterTypes()[0]);
    }

    @Test
    void testGetMatchingAccessibleMethod_varArgsMatch() {
        final Method m = MethodUtils.getMatchingAccessibleMethod(AgentVarArgHolder.class, "join", String.class, String.class, Integer.class);
        assertNotNull(m);
        assertTrue(m.isVarArgs());
    }

    @Test
    void testGetMatchingAccessibleMethod_varArgsTypeMismatchReturnsNull() {
        final Method m = MethodUtils.getMatchingAccessibleMethod(AgentVarArgHolder2.class, "join", Integer.class);
        assertNull(m);
    }

    @Test
    void testGetMatchingAccessibleMethod_notFound() {
        assertNull(MethodUtils.getMatchingAccessibleMethod(AgentFoo.class, "doesNotExist"));
    }

    @Test
    void testGetMatchingMethod_basic() throws Exception {
        final Method expected = AgentFoo.class.getMethod("methodWithArg", String.class);
        assertEquals(expected, MethodUtils.getMatchingMethod(AgentFoo.class, "methodWithArg", String.class));
    }

    @Test
    void testGetMatchingMethod_ambiguousThrows() {
        assertThrows(IllegalStateException.class, () -> MethodUtils.getMatchingMethod(AgentAmbiguous.class, "ambiguous", (Class<?>) null));
    }

    @Test
    void testGetMatchingMethod_nullClassThrows() {
        assertThrows(NullPointerException.class, () -> MethodUtils.getMatchingMethod(null, "foo"));
    }

    @Test
    void testGetMatchingMethod_emptyNameThrows() {
        assertThrows(IllegalArgumentException.class, () -> MethodUtils.getMatchingMethod(AgentFoo.class, ""));
    }

    @Test
    void testGetMethodObject_foundAndNotFound() throws Exception {
        assertEquals(AgentFoo.class.getMethod("methodReturningString"), MethodUtils.getMethodObject(AgentFoo.class, "methodReturningString"));
        assertNull(MethodUtils.getMethodObject(AgentFoo.class, "doesNotExist"));
        assertNull(MethodUtils.getMethodObject(null, "methodReturningString"));
        assertNull(MethodUtils.getMethodObject(AgentFoo.class, null));
    }

    @Test
    void testGetMethodsListWithAnnotation_publicOnlyNoSupers() {
        final List<Method> methods = MethodUtils.getMethodsListWithAnnotation(AgentAnnoChild.class, AgentAnno.class);
        assertTrue(methods.isEmpty());
    }

    @Test
    void testGetMethodsListWithAnnotation_searchSupersIgnoreAccess() {
        final List<Method> methods = MethodUtils.getMethodsListWithAnnotation(AgentAnnoChild.class, AgentAnno.class, true, true);
        assertFalse(methods.isEmpty());
        boolean foundPrivate = false;
        for (final Method m : methods) {
            if (m.getName().equals("privateAnnotatedMethod")) {
                foundPrivate = true;
            }
        }
        assertTrue(foundPrivate);
    }

    @Test
    void testGetMethodsListWithAnnotation_nullArgsThrow() {
        assertThrows(NullPointerException.class, () -> MethodUtils.getMethodsListWithAnnotation(null, AgentAnno.class));
        assertThrows(NullPointerException.class, () -> MethodUtils.getMethodsListWithAnnotation(AgentAnnoChild.class, null));
    }

    @Test
    void testGetMethodsWithAnnotation_arrayVariant() {
        final Method[] methods = MethodUtils.getMethodsWithAnnotation(AgentAnnoParent.class, AgentAnno.class);
        assertEquals(1, methods.length);
        assertEquals("annotatedMethod", methods[0].getName());
    }

    @Test
    void testGetOverrideHierarchy_basic() throws Exception {
        final Method m = AgentDerived.class.getMethod("overridden");
        final Set<Method> hierarchy = MethodUtils.getOverrideHierarchy(m, Interfaces.EXCLUDE);
        assertEquals(2, hierarchy.size());
        final Iterator<Method> it = hierarchy.iterator();
        assertEquals(AgentDerived.class, it.next().getDeclaringClass());
        assertEquals(AgentBase.class, it.next().getDeclaringClass());
    }

    @Test
    void testGetOverrideHierarchy_nullThrows() {
        assertThrows(NullPointerException.class, () -> MethodUtils.getOverrideHierarchy(null, Interfaces.EXCLUDE));
    }

    @Test
    void testInvokeExactMethod_noArgs() throws Exception {
        final AgentFoo foo = new AgentFoo();
        assertEquals("foo", MethodUtils.invokeExactMethod(foo, "methodReturningString"));
    }

    @Test
    void testInvokeExactMethod_withArgs() throws Exception {
        final AgentFoo foo = new AgentFoo();
        assertEquals("echo:hi", MethodUtils.invokeExactMethod(foo, "methodWithArg", "hi"));
    }

    @Test
    void testInvokeExactMethod_noSuchMethod() {
        final AgentFoo foo = new AgentFoo();
        assertThrows(NoSuchMethodException.class, () -> MethodUtils.invokeExactMethod(foo, "methodWithArg", 42));
    }

    @Test
    void testInvokeExactMethod_nullObjectThrows() {
        assertThrows(NullPointerException.class, () -> MethodUtils.invokeExactMethod(null, "methodReturningString"));
    }

    @Test
    void testInvokeExactMethod_exceptionWrapped() {
        final AgentFoo foo = new AgentFoo();
        final InvocationTargetException ite = assertThrows(InvocationTargetException.class, () -> MethodUtils.invokeExactMethod(foo, "throwingMethod"));
        assertTrue(ite.getCause() instanceof IllegalStateException);
    }

    @Test
    void testInvokeExactStaticMethod_basic() throws Exception {
        assertEquals("static:x", MethodUtils.invokeExactStaticMethod(AgentFoo.class, "staticMethod", "x"));
    }

    @Test
    void testInvokeExactStaticMethod_noSuchMethod() {
        assertThrows(NoSuchMethodException.class, () -> MethodUtils.invokeExactStaticMethod(AgentFoo.class, "staticMethod", 1));
    }

    @Test
    void testInvokeMethod_noArgs() throws Exception {
        final AgentFoo foo = new AgentFoo();
        assertEquals("foo", MethodUtils.invokeMethod(foo, "methodReturningString"));
    }

    @Test
    void testInvokeMethod_primitiveWrapperMatch() throws Exception {
        final AgentFoo foo = new AgentFoo();
        assertEquals(6, MethodUtils.invokeMethod(foo, "intVarArgsMethod", 1, 2, 3));
    }

    @Test
    void testInvokeMethod_forceAccessPrivate() throws Exception {
        final AgentFoo foo = new AgentFoo();
        assertEquals("private", MethodUtils.invokeMethod(foo, true, "privateMethod"));
    }

    @Test
    void testInvokeMethod_forceAccessFalsePrivateFails() {
        final AgentFoo foo = new AgentFoo();
        assertThrows(NoSuchMethodException.class, () -> MethodUtils.invokeMethod(foo, false, "privateMethod"));
    }

    @Test
    void testInvokeMethod_varArgs() throws Exception {
        final AgentFoo foo = new AgentFoo();
        assertEquals("a,b,c", MethodUtils.invokeMethod(foo, "varArgsMethod", "a", "b", "c"));
    }

    @Test
    void testInvokeMethod_nullObjectThrows() {
        assertThrows(NullPointerException.class, () -> MethodUtils.invokeMethod(null, "methodReturningString"));
    }

    @Test
    void testInvokeStaticMethod_basic() throws Exception {
        assertEquals("static:y", MethodUtils.invokeStaticMethod(AgentFoo.class, "staticMethod", "y"));
    }

    @Test
    void testInvokeStaticMethod_noSuchMethod() {
        assertThrows(NoSuchMethodException.class, () -> MethodUtils.invokeStaticMethod(AgentFoo.class, "doesNotExist"));
    }

    @Test
    void testConstructor_deprecatedButPublic() {
        assertNotNull(new MethodUtils());
    }
}
