/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.apache.commons.csv.Constants.UNDEFINED;
import static org.apache.commons.io.IOUtils.EOF;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;

import org.junit.jupiter.api.Test;

/**
 * Tests for {@link ExtendedBufferedReader}.
 */
class ExtendedBufferedReaderAgentTest {

    private ExtendedBufferedReader createReader(final String content) {
        return new ExtendedBufferedReader(new StringReader(content));
    }

    @Test
    void testInitialState() throws IOException {
        final ExtendedBufferedReader reader = createReader("abc");
        assertEquals(UNDEFINED, reader.getLastChar());
        assertEquals(0, reader.getPosition());
        assertEquals(0, reader.getLineNumber());
        assertEquals(0, reader.getBytesRead());
        reader.close();
    }

    @Test
    void testReadSingleChar() throws IOException {
        final ExtendedBufferedReader reader = createReader("ab");
        assertEquals('a', reader.read());
        assertEquals('a', reader.getLastChar());
        assertEquals(1, reader.getPosition());
        assertEquals('b', reader.read());
        assertEquals('b', reader.getLastChar());
        assertEquals(2, reader.getPosition());
        assertEquals(EOF, reader.read());
        assertEquals(EOF, reader.getLastChar());
        assertEquals(3, reader.getPosition());
        reader.close();
    }

    @Test
    void testReadEmptyReaderReturnsEof() throws IOException {
        final ExtendedBufferedReader reader = createReader("");
        assertEquals(EOF, reader.read());
        assertEquals(EOF, reader.getLastChar());
        reader.close();
    }

    @Test
    void testReadCharArrayZeroLengthReturnsZeroWithoutAdvancing() throws IOException {
        final ExtendedBufferedReader reader = createReader("abc");
        final char[] buf = new char[5];
        assertEquals(0, reader.read(buf, 0, 0));
        assertEquals(UNDEFINED, reader.getLastChar());
        assertEquals(0, reader.getPosition());
        reader.close();
    }

    @Test
    void testReadCharArrayFullRead() throws IOException {
        final ExtendedBufferedReader reader = createReader("abc");
        final char[] buf = new char[3];
        final int len = reader.read(buf, 0, 3);
        assertEquals(3, len);
        assertEquals('a', buf[0]);
        assertEquals('b', buf[1]);
        assertEquals('c', buf[2]);
        assertEquals('c', reader.getLastChar());
        assertEquals(3, reader.getPosition());
        reader.close();
    }

    @Test
    void testReadCharArrayAtEofReturnsEofAndSetsLastChar() throws IOException {
        final ExtendedBufferedReader reader = createReader("");
        final char[] buf = new char[3];
        final int len = reader.read(buf, 0, 3);
        assertEquals(EOF, len);
        assertEquals(EOF, reader.getLastChar());
        reader.close();
    }

    @Test
    void testReadCharArrayWithOffset() throws IOException {
        final ExtendedBufferedReader reader = createReader("xy");
        final char[] buf = new char[4];
        buf[0] = 'Z';
        final int len = reader.read(buf, 1, 2);
        assertEquals(2, len);
        assertEquals('Z', buf[0]);
        assertEquals('x', buf[1]);
        assertEquals('y', buf[2]);
        assertEquals('y', reader.getLastChar());
        assertEquals(2, reader.getPosition());
        reader.close();
    }

    @Test
    void testGetLineNumberBeforeAnyRead() throws IOException {
        final ExtendedBufferedReader reader = createReader("a\nb");
        assertEquals(0, reader.getLineNumber());
        reader.close();
    }

    @Test
    void testGetLineNumberLf() throws IOException {
        final ExtendedBufferedReader reader = createReader("a\nb\nc");
        reader.read(); // a
        assertEquals(1, reader.getLineNumber());
        reader.read(); // \n
        assertEquals(1, reader.getLineNumber());
        reader.read(); // b
        assertEquals(2, reader.getLineNumber());
        reader.read(); // \n
        assertEquals(2, reader.getLineNumber());
        reader.read(); // c
        assertEquals(3, reader.getLineNumber());
        reader.close();
    }

    @Test
    void testGetLineNumberCr() throws IOException {
        final ExtendedBufferedReader reader = createReader("a\rb");
        reader.read(); // a
        assertEquals(1, reader.getLineNumber());
        reader.read(); // \r
        assertEquals(1, reader.getLineNumber());
        reader.read(); // b
        assertEquals(2, reader.getLineNumber());
        reader.close();
    }

    @Test
    void testGetLineNumberCrLfCountsAsOneLine() throws IOException {
        final ExtendedBufferedReader reader = createReader("a\r\nb");
        reader.read(); // a
        assertEquals(1, reader.getLineNumber());
        reader.read(); // \r
        assertEquals(1, reader.getLineNumber());
        reader.read(); // \n (should not double count since lastChar == CR)
        assertEquals(1, reader.getLineNumber());
        reader.read(); // b
        assertEquals(2, reader.getLineNumber());
        reader.close();
    }

    @Test
    void testGetLineNumberAtEofWithoutTrailingEol() throws IOException {
        final ExtendedBufferedReader reader = createReader("abc");
        reader.read();
        reader.read();
        reader.read();
        assertEquals(1, reader.getLineNumber());
        reader.read(); // EOF, lastChar was 'c' (not CR/LF/EOF) so counts as new line
        assertEquals(EOF, reader.getLastChar());
        assertEquals(1, reader.getLineNumber());
        reader.close();
    }

    @Test
    void testPeekDoesNotAffectLastCharOrPosition() throws IOException {
        final ExtendedBufferedReader reader = createReader("ab");
        final int peeked = reader.peek();
        assertEquals('a', peeked);
        assertEquals(UNDEFINED, reader.getLastChar());
        assertEquals(0, reader.getPosition());
        assertEquals('a', reader.read());
        reader.close();
    }

    @Test
    void testPeekAtEofReturnsEof() throws IOException {
        final ExtendedBufferedReader reader = createReader("");
        assertEquals(EOF, reader.peek());
        reader.close();
    }

    @Test
    void testReadLineBasic() throws IOException {
        final ExtendedBufferedReader reader = createReader("line1\nline2");
        assertEquals("line1", reader.readLine());
        assertEquals("line2", reader.readLine());
        assertNull(reader.readLine());
        reader.close();
    }

    @Test
    void testReadLineWithCrLf() throws IOException {
        final ExtendedBufferedReader reader = createReader("line1\r\nline2\r\n");
        assertEquals("line1", reader.readLine());
        assertEquals("line2", reader.readLine());
        assertNull(reader.readLine());
        reader.close();
    }

    @Test
    void testReadLineEmptyInput() throws IOException {
        final ExtendedBufferedReader reader = createReader("");
        assertNull(reader.readLine());
        reader.close();
    }

    @Test
    void testReadLineWithEmptyLines() throws IOException {
        final ExtendedBufferedReader reader = createReader("\n\nabc");
        assertEquals("", reader.readLine());
        assertEquals("", reader.readLine());
        assertEquals("abc", reader.readLine());
        assertNull(reader.readLine());
        reader.close();
    }

    @Test
    void testMarkAndResetRestoreState() throws IOException {
        final ExtendedBufferedReader reader = createReader("abc\ndef");
        reader.read(); // a
        reader.mark(10);
        final long markedPosition = reader.getPosition();
        final long markedLine = reader.getLineNumber();
        final int markedLastChar = reader.getLastChar();
        reader.read(); // b
        reader.read(); // c
        reader.read(); // \n
        reader.read(); // d
        reader.reset();
        assertEquals(markedPosition, reader.getPosition());
        assertEquals(markedLine, reader.getLineNumber());
        assertEquals(markedLastChar, reader.getLastChar());
        assertEquals('b', reader.read());
        reader.close();
    }

    @Test
    void testCloseSetsLastCharToEof() throws IOException {
        final ExtendedBufferedReader reader = createReader("abc");
        reader.read();
        reader.close();
        assertEquals(EOF, reader.getLastChar());
    }

    @Test
    void testGetBytesReadWithoutTrackingIsZero() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"), StandardCharsets.UTF_8, false);
        reader.read();
        reader.read();
        assertEquals(0, reader.getBytesRead());
        reader.close();
    }

    @Test
    void testGetBytesReadWithNullCharsetIsZero() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"), null, true);
        reader.read();
        reader.read();
        assertEquals(0, reader.getBytesRead());
        reader.close();
    }

    @Test
    void testGetBytesReadAsciiOneBytePerChar() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"), StandardCharsets.UTF_8, true);
        reader.read();
        assertEquals(1, reader.getBytesRead());
        reader.read();
        assertEquals(2, reader.getBytesRead());
        reader.read();
        assertEquals(3, reader.getBytesRead());
        reader.read(); // EOF, should not add bytes
        assertEquals(3, reader.getBytesRead());
        reader.close();
    }

    @Test
    void testGetBytesReadViaBulkReadAscii() throws IOException {
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abcd"), StandardCharsets.UTF_8, true);
        final char[] buf = new char[4];
        final int len = reader.read(buf, 0, 4);
        assertEquals(4, len);
        assertEquals(4, reader.getBytesRead());
        reader.close();
    }

    @Test
    void testGetBytesReadMultiByteUtf8Character() throws IOException {
        // U+00E9 'é' encodes to 2 bytes in UTF-8
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("é"), StandardCharsets.UTF_8, true);
        reader.read();
        assertEquals(2, reader.getBytesRead());
        reader.close();
    }
}
