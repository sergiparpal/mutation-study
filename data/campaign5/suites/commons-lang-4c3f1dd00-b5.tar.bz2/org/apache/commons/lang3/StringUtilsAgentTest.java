/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link StringUtils}.
 */
class StringUtilsAgentTest {

    @Test
    void testIsEmptyIsBlank() {
        assertTrue(StringUtils.isEmpty(null));
        assertTrue(StringUtils.isEmpty(""));
        assertFalse(StringUtils.isEmpty(" "));
        assertFalse(StringUtils.isEmpty("abc"));

        assertTrue(StringUtils.isBlank(null));
        assertTrue(StringUtils.isBlank(""));
        assertTrue(StringUtils.isBlank("   "));
        assertFalse(StringUtils.isBlank("abc"));
        assertFalse(StringUtils.isBlank(" a "));
    }

    @Test
    void testTrimAndStrip() {
        assertNull(StringUtils.trim(null));
        assertEquals("", StringUtils.trim(""));
        assertEquals("abc", StringUtils.trim("  abc  "));

        assertEquals("", StringUtils.trimToEmpty(null));
        assertEquals("abc", StringUtils.trimToEmpty("  abc  "));

        assertNull(StringUtils.trimToNull("   "));
        assertEquals("abc", StringUtils.trimToNull("  abc  "));

        assertNull(StringUtils.strip(null));
        assertEquals("abc", StringUtils.strip("  abc  "));
        assertEquals("abc  ", StringUtils.stripStart("  abc  ", null));
        assertEquals("  abc", StringUtils.stripEnd("  abc  ", null));
    }

    @Test
    void testSubstring() {
        assertNull(StringUtils.substring(null, 0));
        assertEquals("", StringUtils.substring("", 1));
        assertEquals("cde", StringUtils.substring("abcde", 2));
        assertEquals("cde", StringUtils.substring("abcde", -3));
        assertEquals("", StringUtils.substring("abc", 10));

        assertEquals("b", StringUtils.substring("abc", 1, 2));
        assertEquals("bc", StringUtils.substring("abcde", 1, 3));
        assertEquals("", StringUtils.substring("abc", 2, 1));
        assertEquals("abc", StringUtils.substring("abc", 0, 100));
    }

    @Test
    void testSubstringBeforeAfter() {
        assertNull(StringUtils.substringBefore(null, "a"));
        assertEquals("abc", StringUtils.substringBefore("abc", "d"));
        assertEquals("", StringUtils.substringBefore("abcba", "a"));
        assertEquals("ab", StringUtils.substringBefore("abcba", "c"));

        assertNull(StringUtils.substringAfter(null, "a"));
        assertEquals("", StringUtils.substringAfter("abc", "d"));
        assertEquals("bc", StringUtils.substringAfter("abc", "a"));
        assertEquals("ba", StringUtils.substringAfter("abcba", "c"));

        assertEquals("abc", StringUtils.substringBeforeLast("abcba", "b"));
        assertEquals("", StringUtils.substringAfterLast("abc", "c"));
    }

    @Test
    void testIndexOfAndLastIndexOf() {
        assertEquals(-1, StringUtils.indexOf(null, "a"));
        assertEquals(-1, StringUtils.indexOf("abc", null));
        assertEquals(0, StringUtils.indexOf("", ""));
        assertEquals(2, StringUtils.indexOf("abcabc", "c"));

        assertEquals(-1, StringUtils.lastIndexOf(null, "a"));
        assertEquals(5, StringUtils.lastIndexOf("abcabc", "c"));

        assertEquals(-1, StringUtils.ordinalIndexOf(null, "a", 1));
        assertEquals(4, StringUtils.ordinalIndexOf("aabaabaa", "ab", 2));
        assertEquals(1, StringUtils.ordinalIndexOf("aabaabaa", "ab", 1));
    }

    @Test
    void testContainsFamily() {
        assertFalse(StringUtils.contains(null, "a"));
        assertFalse(StringUtils.contains("abc", null));
        assertTrue(StringUtils.contains("abc", "b"));
        assertTrue(StringUtils.contains("abc", ""));

        assertTrue(StringUtils.containsIgnoreCase("ABC", "b"));
        assertFalse(StringUtils.containsIgnoreCase(null, "b"));

        assertTrue(StringUtils.containsAny("abc", 'x', 'b'));
        assertFalse(StringUtils.containsAny("abc", 'x', 'y'));
        assertFalse(StringUtils.containsAny((CharSequence) null, 'x'));

        assertTrue(StringUtils.containsWhitespace("a b"));
        assertFalse(StringUtils.containsWhitespace("ab"));
        assertFalse(StringUtils.containsWhitespace(""));
    }

    @Test
    void testEqualsFamily() {
        assertTrue(StringUtils.equals(null, null));
        assertFalse(StringUtils.equals(null, "abc"));
        assertFalse(StringUtils.equals("abc", null));
        assertTrue(StringUtils.equals("abc", "abc"));
        assertFalse(StringUtils.equals("abc", "ABC"));

        assertTrue(StringUtils.equalsIgnoreCase("abc", "ABC"));
        assertTrue(StringUtils.equalsIgnoreCase(null, null));
        assertFalse(StringUtils.equalsIgnoreCase(null, "abc"));

        assertTrue(StringUtils.equalsAny("abc", "xyz", "abc"));
        assertFalse(StringUtils.equalsAny("abc", "xyz", "def"));
    }

    @Test
    void testStartsEndsWith() {
        assertFalse(StringUtils.startsWith(null, "a"));
        assertFalse(StringUtils.startsWith("abc", null));
        assertTrue(StringUtils.startsWith("abc", "ab"));
        assertFalse(StringUtils.startsWith("ab", "abc"));

        assertTrue(StringUtils.startsWithIgnoreCase("ABCDEF", "abc"));

        assertFalse(StringUtils.endsWith(null, "a"));
        assertTrue(StringUtils.endsWith("abc", "bc"));
        assertFalse(StringUtils.endsWith("abc", "bcd"));

        assertTrue(StringUtils.startsWithAny("abc", "xy", "ab"));
        assertFalse(StringUtils.startsWithAny("abc", "xy", "zz"));
    }

    @Test
    void testIsAlphaNumericEtc() {
        assertFalse(StringUtils.isAlpha(null));
        assertFalse(StringUtils.isAlpha(""));
        assertFalse(StringUtils.isAlpha(" "));
        assertTrue(StringUtils.isAlpha("abcXYZ"));
        assertFalse(StringUtils.isAlpha("abc123"));

        assertFalse(StringUtils.isNumeric(null));
        assertFalse(StringUtils.isNumeric(""));
        assertTrue(StringUtils.isNumeric("12345"));
        assertFalse(StringUtils.isNumeric("12 345"));
        assertFalse(StringUtils.isNumeric("-123"));

        assertFalse(StringUtils.isAlphanumeric(null));
        assertTrue(StringUtils.isAlphanumeric("abc123"));
        assertFalse(StringUtils.isAlphanumeric("abc 123"));

        assertFalse(StringUtils.isWhitespace(null));
        assertTrue(StringUtils.isWhitespace(""));
        assertTrue(StringUtils.isWhitespace("   "));
        assertFalse(StringUtils.isWhitespace("  a "));
    }

    @Test
    void testCapitalizeUncapitalizeSwapCase() {
        assertNull(StringUtils.capitalize(null));
        assertEquals("", StringUtils.capitalize(""));
        assertEquals("Cat", StringUtils.capitalize("cat"));
        assertEquals("CAt", StringUtils.capitalize("CAt"));

        assertNull(StringUtils.uncapitalize(null));
        assertEquals("cat", StringUtils.uncapitalize("Cat"));

        assertNull(StringUtils.swapCase(null));
        assertEquals("", StringUtils.swapCase(""));
        assertEquals("tHE DOG HAS A bone", StringUtils.swapCase("The dog has a BONE"));
    }

    @Test
    void testReverse() {
        assertNull(StringUtils.reverse(null));
        assertEquals("", StringUtils.reverse(""));
        assertEquals("cba", StringUtils.reverse("abc"));
        assertEquals("a", StringUtils.reverse("a"));
    }

    @Test
    void testRepeat() {
        assertNull(StringUtils.repeat(null, 2));
        assertEquals("", StringUtils.repeat("ab", 0));
        assertEquals("", StringUtils.repeat("ab", -1));
        assertEquals("ababab", StringUtils.repeat("ab", 3));

        assertEquals("", StringUtils.repeat('e', 0));
        assertEquals("eee", StringUtils.repeat('e', 3));

        assertEquals("a,a,a", StringUtils.repeat("a", ",", 3));
        assertEquals("", StringUtils.repeat("a", ",", 0));
        assertNull(StringUtils.repeat(null, ",", 3));
    }

    @Test
    void testLeftRightPad() {
        assertNull(StringUtils.leftPad(null, 3));
        assertEquals("  ab", StringUtils.leftPad("ab", 4));
        assertEquals("ab", StringUtils.leftPad("ab", 1));
        assertEquals("xxab", StringUtils.leftPad("ab", 4, 'x'));

        assertNull(StringUtils.rightPad(null, 3));
        assertEquals("ab  ", StringUtils.rightPad("ab", 4));
        assertEquals("abxx", StringUtils.rightPad("ab", 4, 'x'));
    }

    @Test
    void testLeftRightMid() {
        assertNull(StringUtils.left(null, 3));
        assertEquals("", StringUtils.left("abc", 0));
        assertEquals("", StringUtils.left("abc", -1));
        assertEquals("ab", StringUtils.left("abc", 2));
        assertEquals("abc", StringUtils.left("abc", 10));

        assertNull(StringUtils.right(null, 3));
        assertEquals("bc", StringUtils.right("abc", 2));
        assertEquals("abc", StringUtils.right("abc", 10));

        assertNull(StringUtils.mid(null, 0, 2));
        assertEquals("", StringUtils.mid("abc", 0, -1));
        assertEquals("ab", StringUtils.mid("abc", 0, 2));
        assertEquals("bc", StringUtils.mid("abc", 1, 5));
    }

    @Test
    void testAbbreviate() {
        assertNull(StringUtils.abbreviate(null, 4));
        assertEquals("", StringUtils.abbreviate("", 4));
        assertEquals("abc...", StringUtils.abbreviate("abcdefg", 6));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", 7));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", 10));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.abbreviate("abcdefg", 3);
            }
        });
    }

    @Test
    void testTruncate() {
        assertNull(StringUtils.truncate(null, 10));
        assertEquals("", StringUtils.truncate("", 10));
        assertEquals("abc", StringUtils.truncate("abcdefg", 3));
        assertEquals("abcdefg", StringUtils.truncate("abcdefg", 10));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.truncate("abcdefg", -1);
            }
        });
    }

    @Test
    void testJoinArrays() {
        assertNull(StringUtils.join((Object[]) null, ','));
        assertEquals("", StringUtils.join(new Object[0], ','));
        assertEquals("a,b,c", StringUtils.join(new Object[] {"a", "b", "c"}, ','));
        assertEquals("a,,c", StringUtils.join(new Object[] {"a", null, "c"}, ','));

        assertEquals("1-2-3", StringUtils.join(new int[] {1, 2, 3}, '-'));

        final List<String> list = new ArrayList<String>();
        list.add("x");
        list.add("y");
        assertEquals("x;y", StringUtils.join((Iterable<?>) list, ";"));
    }

    @Test
    void testSplit() {
        assertArrayEquals(null, StringUtils.split(null));
        assertArrayEquals(new String[0], StringUtils.split(""));
        assertArrayEquals(new String[] {"ab", "cd", "ef"}, StringUtils.split("ab cd ef"));
        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.split("a.b.c", '.'));
        assertArrayEquals(new String[] {"a", "", "b"}, StringUtils.splitPreserveAllTokens("a..b", '.'));
    }

    @Test
    void testReplace() {
        assertNull(StringUtils.replace(null, "a", "b"));
        assertEquals("abc", StringUtils.replace("abc", null, "x"));
        assertEquals("xbxbxb", StringUtils.replace("ababab", "a", "x"));
        assertEquals("xbabab", StringUtils.replace("ababab", "a", "x", 1));
        assertEquals("abc", StringUtils.replaceOnce("aabc", "a", ""));
    }

    @Test
    void testRemove() {
        assertNull(StringUtils.remove(null, 'a'));
        assertEquals("qeed", StringUtils.remove("queued", 'u'));
        assertEquals("abc", StringUtils.removeStart("xabc", "x"));
        assertEquals("abc", StringUtils.removeEnd("abcx", "x"));
        assertNull(StringUtils.removeStart(null, "x"));
    }

    @Test
    void testDefaultString() {
        assertEquals("", StringUtils.defaultString(null));
        assertEquals("abc", StringUtils.defaultString("abc"));
        assertEquals("NULL", StringUtils.defaultString(null, "NULL"));

        assertEquals("NULL", StringUtils.defaultIfEmpty("", "NULL"));
        assertEquals("abc", StringUtils.defaultIfEmpty("abc", "NULL"));
        assertEquals("NULL", StringUtils.defaultIfBlank("   ", "NULL"));
    }

    @Test
    void testCenter() {
        assertNull(StringUtils.center(null, 4));
        assertEquals("    ", StringUtils.center("", 4));
        assertEquals(" ab ", StringUtils.center("ab", 4));
        assertEquals("ab", StringUtils.center("ab", 1));
        assertEquals("xxabxx", StringUtils.center("ab", 6, 'x'));
    }

    @Test
    void testCountMatches() {
        assertEquals(0, StringUtils.countMatches(null, "a"));
        assertEquals(0, StringUtils.countMatches("abba", null));
        assertEquals(0, StringUtils.countMatches("abba", ""));
        assertEquals(2, StringUtils.countMatches("abba", "a"));
        assertEquals(1, StringUtils.countMatches("abba", "ab"));
    }

    @Test
    void testUpperLowerCase() {
        assertNull(StringUtils.upperCase(null));
        assertEquals("", StringUtils.upperCase(""));
        assertEquals("ABC", StringUtils.upperCase("abc"));

        assertNull(StringUtils.lowerCase(null));
        assertEquals("abc", StringUtils.lowerCase("ABC"));
    }

    @Test
    void testGetLevenshteinDistance() {
        assertEquals(0, StringUtils.getLevenshteinDistance("", ""));
        assertEquals(3, StringUtils.getLevenshteinDistance("", "abc"));
        assertEquals(1, StringUtils.getLevenshteinDistance("frog", "fog"));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.getLevenshteinDistance(null, "a");
            }
        });
    }

    @Test
    void testNormalizeSpace() {
        assertNull(StringUtils.normalizeSpace(null));
        assertEquals("", StringUtils.normalizeSpace(""));
        assertEquals("ab c", StringUtils.normalizeSpace(" ab   c  "));
    }

    @Test
    void testWrapAndUnwrap() {
        assertNull(StringUtils.wrap(null, '"'));
        assertEquals("\"abc\"", StringUtils.wrap("abc", '"'));
        assertEquals("", StringUtils.wrap("", '"'));

        assertNull(StringUtils.unwrap(null, '"'));
        assertEquals("abc", StringUtils.unwrap("\"abc\"", '"'));
        assertEquals("abc", StringUtils.unwrap("abc", '"'));
    }

    @Test
    void testLength() {
        assertEquals(0, StringUtils.length(null));
        assertEquals(0, StringUtils.length(""));
        assertEquals(3, StringUtils.length("abc"));
    }

    @Test
    void testDifference() {
        assertNull(StringUtils.difference(null, null));
        assertEquals("", StringUtils.difference(null, ""));
        assertEquals("abc", StringUtils.difference("", "abc"));
        assertEquals("ty", StringUtils.difference("abcde", "abcty"));
        assertEquals("", StringUtils.difference("abc", "abc"));
    }

    @Test
    void testCompare() {
        assertEquals(0, StringUtils.compare(null, null));
        assertTrue(StringUtils.compare(null, "a") < 0);
        assertTrue(StringUtils.compare("a", null) > 0);
        assertTrue(StringUtils.compare("a", "b") < 0);

        assertTrue(StringUtils.compare(null, "a", true) < 0);
        assertTrue(StringUtils.compare(null, "a", false) > 0);
    }
}
