/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.Test;

class CSVParserAgentTest {

    @Test
    void testParseSimpleRecords() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b,c\n1,2,3\n", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("b", records.get(0).get(1));
            assertEquals("c", records.get(0).get(2));
            assertEquals("1", records.get(1).get(0));
            assertEquals("2", records.get(1).get(1));
            assertEquals("3", records.get(1).get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    void testEmptyInputProducesNoRecords() throws IOException {
        final CSVParser parser = CSVParser.parse("", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertTrue(records.isEmpty());
        } finally {
            parser.close();
        }
    }

    @Test
    void testHeaderMapAndNames() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().setSkipHeaderRecord(true).get();
        final CSVParser parser = CSVParser.parse("name,age\nJohn,20\nJane,30\n", format);
        try {
            final Map<String, Integer> headerMap = parser.getHeaderMap();
            assertEquals(Integer.valueOf(0), headerMap.get("name"));
            assertEquals(Integer.valueOf(1), headerMap.get("age"));
            assertEquals(2, parser.getHeaderNames().size());
            assertEquals("name", parser.getHeaderNames().get(0));
            assertEquals("age", parser.getHeaderNames().get(1));

            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("John", records.get(0).get("name"));
            assertEquals("20", records.get(0).get("age"));
        } finally {
            parser.close();
        }
    }

    @Test
    void testGetHeaderMapIsCopyNotShared() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().setSkipHeaderRecord(true).get();
        final CSVParser parser = CSVParser.parse("a,b\n1,2\n", format);
        try {
            final Map<String, Integer> map1 = parser.getHeaderMap();
            map1.put("extra", Integer.valueOf(99));
            final Map<String, Integer> map2 = parser.getHeaderMap();
            assertFalse(map2.containsKey("extra"));
        } finally {
            parser.close();
        }
    }

    @Test
    void testGetHeaderMapNullWhenNoHeader() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n1,2\n", CSVFormat.DEFAULT);
        try {
            assertNull(parser.getHeaderMap());
            assertTrue(parser.getHeaderNames().isEmpty());
        } finally {
            parser.close();
        }
    }

    @Test
    void testDuplicateHeaderNameThrows() {
        final CSVFormat format = CSVFormat.DEFAULT.builder()
                .setHeader()
                .setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW)
                .get();
        try {
            CSVParser.parse("a,a\n1,2\n", format);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            assertTrue(e.getMessage().contains("duplicate"));
        } catch (final IOException e) {
            fail("Unexpected IOException: " + e);
        }
    }

    @Test
    void testDuplicateHeaderNameAllowedByDefault() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "a").get();
        final CSVParser parser = CSVParser.parse("1,2\n", format);
        try {
            assertEquals(2, parser.getHeaderNames().size());
            assertEquals("a", parser.getHeaderNames().get(0));
            assertEquals("a", parser.getHeaderNames().get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    void testMissingHeaderNameThrowsByDefault() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "").get();
        try {
            CSVParser.parse("1,2\n", format);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            assertTrue(e.getMessage().contains("missing"));
        }
    }

    @Test
    void testAllowMissingColumnNames() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "").setAllowMissingColumnNames(true).get();
        final CSVParser parser = CSVParser.parse("1,2\n", format);
        try {
            assertEquals(2, parser.getHeaderNames().size());
            assertEquals("a", parser.getHeaderNames().get(0));
            assertEquals("", parser.getHeaderNames().get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    void testRecordNumberIncrementsAndMatchesRecordValue() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n2\n3\n", CSVFormat.DEFAULT);
        try {
            assertEquals(0, parser.getRecordNumber());
            final Iterator<CSVRecord> it = parser.iterator();
            final CSVRecord r1 = it.next();
            assertEquals(1, parser.getRecordNumber());
            assertEquals(1, r1.getRecordNumber());
            final CSVRecord r2 = it.next();
            assertEquals(2, parser.getRecordNumber());
            assertEquals(2, r2.getRecordNumber());
            final CSVRecord r3 = it.next();
            assertEquals(3, parser.getRecordNumber());
            assertEquals(3, r3.getRecordNumber());
            assertFalse(it.hasNext());
        } finally {
            parser.close();
        }
    }

    @Test
    void testRecordNumberStartOffset() throws IOException {
        final CSVParser parser = CSVParser.builder()
                .setReader(new StringReader("1\n2\n"))
                .setFormat(CSVFormat.DEFAULT)
                .setRecordNumber(5)
                .get();
        try {
            final CSVRecord r1 = parser.iterator().next();
            assertEquals(5, r1.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    void testIteratorHasNextIsIdempotent() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            assertTrue(it.hasNext());
            assertTrue(it.hasNext());
            final CSVRecord record = it.next();
            assertEquals("1", record.get(0));
            assertFalse(it.hasNext());
        } finally {
            parser.close();
        }
    }

    @Test
    void testIteratorNextWithoutHasNextThrowsAtEnd() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            assertEquals("1", it.next().get(0));
            try {
                it.next();
                fail("Expected NoSuchElementException");
            } catch (final NoSuchElementException e) {
                // expected
            }
        } finally {
            parser.close();
        }
    }

    @Test
    void testIteratorRemoveUnsupported() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            try {
                it.remove();
                fail("Expected UnsupportedOperationException");
            } catch (final UnsupportedOperationException e) {
                // expected
            }
        } finally {
            parser.close();
        }
    }

    @Test
    void testCloseMakesIteratorEmptyAndParserClosed() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n2\n", CSVFormat.DEFAULT);
        assertFalse(parser.isClosed());
        parser.close();
        assertTrue(parser.isClosed());
        final Iterator<CSVRecord> it = parser.iterator();
        assertFalse(it.hasNext());
        try {
            it.next();
            fail("Expected NoSuchElementException");
        } catch (final NoSuchElementException e) {
            // expected
        }
    }

    @Test
    void testStreamCollectsAllRecords() throws IOException {
        final CSVParser parser = CSVParser.parse("a\nb\nc\n", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.stream().collect(java.util.stream.Collectors.toList());
            assertEquals(3, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("c", records.get(2).get(0));
        } finally {
            parser.close();
        }
    }

    @Test
    void testMaxRowsLimitsRecordsProduced() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(2).get();
        final CSVParser parser = CSVParser.parse("1\n2\n3\n4\n", format);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("1", records.get(0).get(0));
            assertEquals("2", records.get(1).get(0));
        } finally {
            parser.close();
        }
    }

    @Test
    void testCommentsIgnoredByDefault() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVParser parser = CSVParser.parse("# comment line\na,b\n", format);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("a", records.get(0).get(0));
            assertFalse(parser.hasHeaderComment());
        } finally {
            parser.close();
        }
    }

    @Test
    void testHeaderCommentCapturedWhenHeaderDefined() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder()
                .setCommentMarker('#')
                .setHeader()
                .setSkipHeaderRecord(true)
                .get();
        final CSVParser parser = CSVParser.parse("# a header comment\nname,age\nJohn,20\n", format);
        try {
            assertTrue(parser.hasHeaderComment());
            assertEquals("a header comment", parser.getHeaderComment());
        } finally {
            parser.close();
        }
    }

    @Test
    void testTrailerCommentCapturedAfterLastRecord() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVParser parser = CSVParser.parse("a,b\n# trailing comment", format);
        try {
            assertFalse(parser.hasTrailerComment());
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertTrue(parser.hasTrailerComment());
            assertEquals("trailing comment", parser.getTrailerComment());
        } finally {
            parser.close();
        }
    }

    @Test
    void testInvalidTokenThrowsCSVException() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuote('"').get();
        final CSVParser parser = CSVParser.parse("\"unterminated quote", format);
        try {
            try {
                parser.getRecords();
                fail("Expected UncheckedIOException wrapping CSVException");
            } catch (final java.io.UncheckedIOException e) {
                assertTrue(e.getCause() instanceof CSVException);
            }
        } finally {
            parser.close();
        }
    }

    @Test
    void testParseNullStringThrowsNpe() {
        try {
            CSVParser.parse((String) null, CSVFormat.DEFAULT);
            fail("Expected NullPointerException");
        } catch (final IOException e) {
            fail("Unexpected IOException: " + e);
        } catch (final NullPointerException e) {
            // expected
        }
    }

    @Test
    void testParseNullFileThrowsNpe() {
        try {
            CSVParser.parse((File) null, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
            fail("Expected NullPointerException");
        } catch (final IOException e) {
            fail("Unexpected IOException: " + e);
        } catch (final NullPointerException e) {
            // expected
        }
    }

    @Test
    void testParseNullPathThrowsNpe() {
        try {
            CSVParser.parse((Path) null, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
            fail("Expected NullPointerException");
        } catch (final IOException e) {
            fail("Unexpected IOException: " + e);
        } catch (final NullPointerException e) {
            // expected
        }
    }

    @Test
    void testParseNullUrlThrowsNpe() {
        try {
            CSVParser.parse((URL) null, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
            fail("Expected NullPointerException");
        } catch (final IOException e) {
            fail("Unexpected IOException: " + e);
        } catch (final NullPointerException e) {
            // expected
        }
    }

    @Test
    void testParseFileReadsRecords() throws IOException {
        final Path tempFile = Files.createTempFile("csv-parser-agent-test", ".csv");
        try {
            Files.write(tempFile, "x,y\n5,6\n".getBytes(StandardCharsets.UTF_8));
            final CSVParser parser = CSVParser.parse(tempFile.toFile(), StandardCharsets.UTF_8, CSVFormat.DEFAULT);
            try {
                final List<CSVRecord> records = parser.getRecords();
                assertEquals(2, records.size());
                assertEquals("5", records.get(1).get(0));
                assertEquals("6", records.get(1).get(1));
            } finally {
                parser.close();
            }
        } finally {
            Files.deleteIfExists(tempFile);
        }
    }

    @Test
    void testParsePathReadsRecords() throws IOException {
        final Path tempFile = Files.createTempFile("csv-parser-agent-test-path", ".csv");
        try {
            Files.write(tempFile, "p,q\n7,8\n".getBytes(StandardCharsets.UTF_8));
            final CSVParser parser = CSVParser.parse(tempFile, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
            try {
                final List<CSVRecord> records = parser.getRecords();
                assertEquals(2, records.size());
                assertEquals("7", records.get(1).get(0));
            } finally {
                parser.close();
            }
        } finally {
            Files.deleteIfExists(tempFile);
        }
    }

    @Test
    void testBuilderDefaultsToDefaultFormatWhenNullFormat() throws IOException {
        final CSVParser parser = CSVParser.builder().setReader(new StringReader("a,b\n")).setFormat(null).get();
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("a", records.get(0).get(0));
        } finally {
            parser.close();
        }
    }

    @Test
    void testDeprecatedConstructorWithOffsetsSetsRecordNumber() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("1\n2\n"), CSVFormat.DEFAULT, 0, 10);
        try {
            final CSVRecord record = parser.iterator().next();
            assertEquals(10, record.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    void testTrailingDelimiterDropsEmptyLastField() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get();
        final CSVParser parser = CSVParser.parse("a,b,\n", format);
        try {
            final CSVRecord record = parser.iterator().next();
            assertEquals(2, record.size());
            assertEquals("a", record.get(0));
            assertEquals("b", record.get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    void testNullStringConvertsFieldToNull() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        final CSVParser parser = CSVParser.parse("a,NULL,c\n", format);
        try {
            final CSVRecord record = parser.iterator().next();
            assertEquals("a", record.get(0));
            assertNull(record.get(1));
            assertEquals("c", record.get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    void testCurrentLineNumberAdvancesWhileReading() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n2\n3\n", CSVFormat.DEFAULT);
        try {
            assertEquals(0, parser.getCurrentLineNumber());
            parser.iterator().next();
            assertEquals(1, parser.getCurrentLineNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    void testGetFirstEndOfLineDetectsCrLf() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\r\nc,d\r\n", CSVFormat.DEFAULT);
        try {
            parser.getRecords();
            assertEquals("\r\n", parser.getFirstEndOfLine());
        } finally {
            parser.close();
        }
    }

    @Test
    void testEmptyHeaderArrayReadsHeaderFromFirstLine() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(new String[0]).get();
        final CSVParser parser = CSVParser.parse("x,y,z\n1,2,3\n", format);
        try {
            assertEquals(3, parser.getHeaderNames().size());
            assertEquals("x", parser.getHeaderNames().get(0));
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("1", records.get(0).get("x"));
        } finally {
            parser.close();
        }
    }

    @Test
    void testIgnoreEmptyLinesSkipsBlankLines() throws IOException {
        final CSVParser parser = CSVParser.parse("a\n\n\nb\n", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("b", records.get(1).get(0));
        } finally {
            parser.close();
        }
    }

    @Test
    void testGetRecordsOnAlreadyExhaustedParserReturnsEmptyList() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n2\n", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> first = parser.getRecords();
            assertEquals(2, first.size());
            final List<CSVRecord> second = parser.getRecords();
            assertTrue(second.isEmpty());
        } finally {
            parser.close();
        }
    }
}
