/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link Validate}.
 */
class ValidateAgentTest {

    // -- exclusiveBetween(double, double, double) -----------------------

    @Test
    void exclusiveBetweenDoubleInRange() {
        Validate.exclusiveBetween(0.0, 2.0, 1.0);
    }

    @Test
    void exclusiveBetweenDoubleOnLowerBoundThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.exclusiveBetween(0.0, 2.0, 0.0);
            }
        });
        assertTrue(ex.getMessage().contains("0.0"));
    }

    @Test
    void exclusiveBetweenDoubleOnUpperBoundThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.exclusiveBetween(0.0, 2.0, 2.0);
            }
        });
    }

    @Test
    void exclusiveBetweenDoubleNaNThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.exclusiveBetween(0.0, 2.0, Double.NaN);
            }
        });
    }

    @Test
    void exclusiveBetweenDoubleWithMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.exclusiveBetween(0.0, 2.0, 2.0, "out of range");
            }
        });
        assertEquals("out of range", ex.getMessage());
    }

    // -- exclusiveBetween(long, long, long) ------------------------------

    @Test
    void exclusiveBetweenLongInRange() {
        Validate.exclusiveBetween(0L, 2L, 1L);
    }

    @Test
    void exclusiveBetweenLongOutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.exclusiveBetween(0L, 2L, 3L);
            }
        });
    }

    @Test
    void exclusiveBetweenLongWithMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.exclusiveBetween(0L, 2L, 0L, "bad");
            }
        });
        assertEquals("bad", ex.getMessage());
    }

    // -- exclusiveBetween(T, T, Comparable) -------------------------------

    @Test
    void exclusiveBetweenComparableInRange() {
        Validate.exclusiveBetween("a", "z", "m");
    }

    @Test
    void exclusiveBetweenComparableAtBoundThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.exclusiveBetween("a", "z", "a");
            }
        });
    }

    @Test
    void exclusiveBetweenComparableWithMessageAndValues() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.exclusiveBetween(Integer.valueOf(0), Integer.valueOf(2), Integer.valueOf(5), "value %d is bad", Integer.valueOf(5));
            }
        });
        assertEquals("value 5 is bad", ex.getMessage());
    }

    // -- finite -----------------------------------------------------------

    @Test
    void finiteAcceptsFiniteValue() {
        Validate.finite(1.5);
    }

    @Test
    void finiteRejectsNaN() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.finite(Double.NaN);
            }
        });
    }

    @Test
    void finiteRejectsPositiveInfinity() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.finite(Double.POSITIVE_INFINITY);
            }
        });
    }

    @Test
    void finiteRejectsNegativeInfinityWithMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.finite(Double.NEGATIVE_INFINITY, "not finite: %d", Integer.valueOf(1));
            }
        });
        assertEquals("not finite: 1", ex.getMessage());
    }

    // -- inclusiveBetween(double, double, double) -------------------------

    @Test
    void inclusiveBetweenDoubleBoundsAreValid() {
        Validate.inclusiveBetween(0.0, 2.0, 0.0);
        Validate.inclusiveBetween(0.0, 2.0, 2.0);
    }

    @Test
    void inclusiveBetweenDoubleBelowLowerThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.inclusiveBetween(0.0, 2.0, -0.1);
            }
        });
    }

    @Test
    void inclusiveBetweenDoubleWithMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.inclusiveBetween(0.0, 2.0, 3.0, "range msg");
            }
        });
        assertEquals("range msg", ex.getMessage());
    }

    // -- inclusiveBetween(long, long, long) --------------------------------

    @Test
    void inclusiveBetweenLongBoundsAreValid() {
        Validate.inclusiveBetween(0L, 2L, 0L);
        Validate.inclusiveBetween(0L, 2L, 2L);
    }

    @Test
    void inclusiveBetweenLongAboveUpperThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.inclusiveBetween(0L, 2L, 3L);
            }
        });
    }

    @Test
    void inclusiveBetweenLongWithMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.inclusiveBetween(0L, 2L, 3L, "msg2");
            }
        });
        assertEquals("msg2", ex.getMessage());
    }

    // -- inclusiveBetween(T, T, Comparable) --------------------------------

    @Test
    void inclusiveBetweenComparableAtBoundsIsValid() {
        Validate.inclusiveBetween("a", "z", "a");
        Validate.inclusiveBetween("a", "z", "z");
    }

    @Test
    void inclusiveBetweenComparableOutOfRangeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.inclusiveBetween("a", "z", "zz");
            }
        });
    }

    @Test
    void inclusiveBetweenComparableWithMessageAndValues() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.inclusiveBetween(Integer.valueOf(0), Integer.valueOf(2), Integer.valueOf(5), "value %d is bad", Integer.valueOf(5));
            }
        });
        assertEquals("value 5 is bad", ex.getMessage());
    }

    // -- isAssignableFrom ---------------------------------------------------

    @Test
    void isAssignableFromAcceptsCompatibleTypes() {
        Validate.isAssignableFrom(Number.class, Integer.class);
    }

    @Test
    void isAssignableFromRejectsIncompatibleTypes() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.isAssignableFrom(String.class, Integer.class);
            }
        });
        assertTrue(ex.getMessage().contains("Integer"));
        assertTrue(ex.getMessage().contains("String"));
    }

    @Test
    void isAssignableFromWithMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.isAssignableFrom(String.class, Integer.class, "cannot assign %s", "Integer");
            }
        });
        assertEquals("cannot assign Integer", ex.getMessage());
    }

    // -- isInstanceOf --------------------------------------------------------

    @Test
    void isInstanceOfAcceptsMatchingInstance() {
        Validate.isInstanceOf(String.class, "hello");
    }

    @Test
    void isInstanceOfRejectsMismatchedInstance() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.isInstanceOf(String.class, Integer.valueOf(1));
            }
        });
        assertTrue(ex.getMessage().contains("String"));
    }

    @Test
    void isInstanceOfRejectsNullObject() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.isInstanceOf(String.class, null);
            }
        });
    }

    @Test
    void isInstanceOfWithMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.isInstanceOf(String.class, Integer.valueOf(1), "wrong class %s", "Integer");
            }
        });
        assertEquals("wrong class Integer", ex.getMessage());
    }

    // -- isTrue ---------------------------------------------------------------

    @Test
    void isTrueAcceptsTrueExpression() {
        Validate.isTrue(true);
    }

    @Test
    void isTrueRejectsFalseExpressionWithDefaultMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.isTrue(false);
            }
        });
        assertEquals("The validated expression is false", ex.getMessage());
    }

    @Test
    void isTrueWithDoubleValueMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.isTrue(false, "value must be positive: %s", 1.5);
            }
        });
        assertEquals("value must be positive: 1.5", ex.getMessage());
    }

    @Test
    void isTrueWithLongValueMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.isTrue(false, "value must be positive: %s", 7L);
            }
        });
        assertEquals("value must be positive: 7", ex.getMessage());
    }

    @Test
    void isTrueWithObjectVarargsMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.isTrue(false, "between %d and %d", Integer.valueOf(1), Integer.valueOf(5));
            }
        });
        assertEquals("between 1 and 5", ex.getMessage());
    }

    @Test
    void isTrueWithSupplierMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.isTrue(false, new Supplier<String>() {
                    @Override
                    public String get() {
                        return "supplied message";
                    }
                });
            }
        });
        assertEquals("supplied message", ex.getMessage());
    }

    // -- matchesPattern ---------------------------------------------------------

    @Test
    void matchesPatternAcceptsMatchingInput() {
        Validate.matchesPattern("hi", "[a-z]*");
    }

    @Test
    void matchesPatternRejectsNonMatchingInput() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.matchesPattern("Hi", "[a-z]*");
            }
        });
        assertTrue(ex.getMessage().contains("Hi"));
    }

    @Test
    void matchesPatternWithMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.matchesPattern("Hi", "[a-z]*", "no match for %s", "Hi");
            }
        });
        assertEquals("no match for Hi", ex.getMessage());
    }

    // -- noNullElements(Iterable) ------------------------------------------------

    @Test
    void noNullElementsIterableReturnsSameInstanceWhenValid() {
        final List<String> list = new ArrayList<String>();
        list.add("a");
        list.add("b");
        final List<String> result = Validate.noNullElements(list);
        assertSame(list, result);
    }

    @Test
    void noNullElementsIterableThrowsNpeWhenNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Validate.noNullElements((List<String>) null);
            }
        });
    }

    @Test
    void noNullElementsIterableThrowsIaeOnNullElementWithIndexInMessage() {
        final List<String> list = new ArrayList<String>();
        list.add("a");
        list.add(null);
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.noNullElements(list);
            }
        });
        assertEquals("The validated collection contains null element at index: 0", ex.getMessage());
    }

    // -- noNullElements(T[]) -------------------------------------------------------

    @Test
    void noNullElementsArrayReturnsSameInstanceWhenValid() {
        final String[] array = {"a", "b"};
        final String[] result = Validate.noNullElements(array);
        assertSame(array, result);
    }

    @Test
    void noNullElementsArrayThrowsNpeWhenNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Validate.noNullElements((String[]) null);
            }
        });
    }

    @Test
    void noNullElementsArrayThrowsIaeOnNullElement() {
        final String[] array = {"a", null, "c"};
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.noNullElements(array);
            }
        });
        assertTrue(ex.getMessage().contains("1"));
    }

    @Test
    void noNullElementsArrayWithMessage() {
        final String[] array = {null};
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.noNullElements(array, "null at %d");
            }
        });
        assertEquals("null at 0", ex.getMessage());
    }

    // -- notBlank -------------------------------------------------------------------

    @Test
    void notBlankReturnsSameInstanceWhenNonBlank() {
        final String value = "hello";
        final String result = Validate.notBlank(value);
        assertSame(value, result);
    }

    @Test
    void notBlankThrowsNpeWhenNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notBlank((String) null);
            }
        });
    }

    @Test
    void notBlankThrowsIaeWhenEmpty() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notBlank("");
            }
        });
        assertEquals("The validated character sequence is blank", ex.getMessage());
    }

    @Test
    void notBlankThrowsIaeWhenWhitespaceOnly() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notBlank("   ");
            }
        });
    }

    @Test
    void notBlankWithMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notBlank(" ", "must not be blank");
            }
        });
        assertEquals("must not be blank", ex.getMessage());
    }

    // -- notEmpty(Collection) ----------------------------------------------------------

    @Test
    void notEmptyCollectionReturnsSameInstanceWhenNonEmpty() {
        final List<String> list = new ArrayList<String>();
        list.add("a");
        final List<String> result = Validate.notEmpty(list);
        assertSame(list, result);
    }

    @Test
    void notEmptyCollectionThrowsNpeWhenNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notEmpty((List<String>) null);
            }
        });
    }

    @Test
    void notEmptyCollectionThrowsIaeWhenEmpty() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notEmpty(new ArrayList<String>());
            }
        });
        assertEquals("The validated collection is empty", ex.getMessage());
    }

    // -- notEmpty(Map) -------------------------------------------------------------------

    @Test
    void notEmptyMapReturnsSameInstanceWhenNonEmpty() {
        final Map<String, String> map = new HashMap<String, String>();
        map.put("k", "v");
        final Map<String, String> result = Validate.notEmpty(map);
        assertSame(map, result);
    }

    @Test
    void notEmptyMapThrowsIaeWhenEmpty() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notEmpty(new HashMap<String, String>());
            }
        });
        assertEquals("The validated map is empty", ex.getMessage());
    }

    @Test
    void notEmptyMapWithMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notEmpty(new HashMap<String, String>(), "map empty");
            }
        });
        assertEquals("map empty", ex.getMessage());
    }

    // -- notEmpty(CharSequence) -----------------------------------------------------------

    @Test
    void notEmptyCharSequenceReturnsSameInstanceWhenNonEmpty() {
        final String value = "x";
        final String result = Validate.notEmpty(value);
        assertSame(value, result);
    }

    @Test
    void notEmptyCharSequenceThrowsIaeWhenEmpty() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notEmpty("");
            }
        });
        assertEquals("The validated character sequence is empty", ex.getMessage());
    }

    @Test
    void notEmptyCharSequenceWithMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notEmpty("", "empty string");
            }
        });
        assertEquals("empty string", ex.getMessage());
    }

    // -- notEmpty(T[]) -----------------------------------------------------------------------

    @Test
    void notEmptyArrayReturnsSameInstanceWhenNonEmpty() {
        final String[] array = {"a"};
        final String[] result = Validate.notEmpty(array);
        assertSame(array, result);
    }

    @Test
    void notEmptyArrayThrowsNpeWhenNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notEmpty((String[]) null);
            }
        });
    }

    @Test
    void notEmptyArrayThrowsIaeWhenEmpty() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notEmpty(new String[0]);
            }
        });
        assertEquals("The validated array is empty", ex.getMessage());
    }

    @Test
    void notEmptyArrayWithMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notEmpty(new String[0], "array is empty!");
            }
        });
        assertEquals("array is empty!", ex.getMessage());
    }

    // -- notNaN --------------------------------------------------------------------------------

    @Test
    void notNaNAcceptsNumber() {
        Validate.notNaN(1.0);
    }

    @Test
    void notNaNRejectsNaN() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notNaN(Double.NaN);
            }
        });
        assertEquals("The validated value is not a number", ex.getMessage());
    }

    @Test
    void notNaNWithMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notNaN(Double.NaN, "is NaN");
            }
        });
        assertEquals("is NaN", ex.getMessage());
    }

    // -- notNull ------------------------------------------------------------------------------

    @Test
    void notNullReturnsSameInstance() {
        final Object value = new Object();
        assertSame(value, Validate.notNull(value));
    }

    @Test
    @SuppressWarnings("deprecation")
    void notNullDeprecatedOverloadThrowsNpeWithDefaultMessage() {
        final NullPointerException ex = assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notNull(null);
            }
        });
        assertEquals("The validated object is null", ex.getMessage());
    }

    @Test
    void notNullWithMessageThrowsNpe() {
        final NullPointerException ex = assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notNull(null, "must not be %s", "null");
            }
        });
        assertEquals("must not be null", ex.getMessage());
    }

    // -- validIndex(Collection) -----------------------------------------------------------------

    @Test
    void validIndexCollectionAcceptsBoundaryIndices() {
        final List<String> list = new ArrayList<String>();
        list.add("a");
        list.add("b");
        assertSame(list, Validate.validIndex(list, 0));
        assertSame(list, Validate.validIndex(list, 1));
    }

    @Test
    void validIndexCollectionRejectsNegativeIndex() {
        final List<String> list = new ArrayList<String>();
        list.add("a");
        final IndexOutOfBoundsException ex = assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                Validate.validIndex(list, -1);
            }
        });
        assertTrue(ex.getMessage().contains("-1"));
    }

    @Test
    void validIndexCollectionRejectsIndexEqualToSize() {
        final List<String> list = new ArrayList<String>();
        list.add("a");
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                Validate.validIndex(list, 1);
            }
        });
    }

    @Test
    void validIndexCollectionWithMessage() {
        final List<String> list = new ArrayList<String>();
        final IndexOutOfBoundsException ex = assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                Validate.validIndex(list, 0, "bad index %d", Integer.valueOf(0));
            }
        });
        assertEquals("bad index 0", ex.getMessage());
    }

    // -- validIndex(CharSequence) ---------------------------------------------------------------

    @Test
    void validIndexCharSequenceAcceptsBoundaryIndices() {
        final String value = "ab";
        assertSame(value, Validate.validIndex(value, 0));
        assertSame(value, Validate.validIndex(value, 1));
    }

    @Test
    void validIndexCharSequenceRejectsOutOfRangeIndex() {
        final IndexOutOfBoundsException ex = assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                Validate.validIndex("ab", 2);
            }
        });
        assertTrue(ex.getMessage().contains("2"));
    }

    @Test
    void validIndexCharSequenceThrowsNpeWhenNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Validate.validIndex((String) null, 0);
            }
        });
    }

    @Test
    void validIndexCharSequenceWithMessage() {
        final IndexOutOfBoundsException ex = assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                Validate.validIndex("ab", 5, "bad char index %d", Integer.valueOf(5));
            }
        });
        assertEquals("bad char index 5", ex.getMessage());
    }

    // -- validIndex(T[]) ------------------------------------------------------------------------

    @Test
    void validIndexArrayAcceptsBoundaryIndices() {
        final String[] array = {"a", "b"};
        assertArrayEquals(array, Validate.validIndex(array, 0));
        assertArrayEquals(array, Validate.validIndex(array, 1));
    }

    @Test
    void validIndexArrayRejectsOutOfRangeIndex() {
        final String[] array = {"a"};
        final IndexOutOfBoundsException ex = assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                Validate.validIndex(array, 1);
            }
        });
        assertTrue(ex.getMessage().contains("1"));
    }

    @Test
    void validIndexArrayThrowsNpeWhenNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Validate.validIndex((String[]) null, 0);
            }
        });
    }

    @Test
    void validIndexArrayWithMessage() {
        final String[] array = {"a"};
        final IndexOutOfBoundsException ex = assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                Validate.validIndex(array, -1, "bad array index %d", Integer.valueOf(-1));
            }
        });
        assertEquals("bad array index -1", ex.getMessage());
    }

    // -- validState -------------------------------------------------------------------------------

    @Test
    void validStateAcceptsTrueExpression() {
        Validate.validState(true);
    }

    @Test
    void validStateRejectsFalseExpressionWithDefaultMessage() {
        final IllegalStateException ex = assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                Validate.validState(false);
            }
        });
        assertEquals("The validated state is false", ex.getMessage());
    }

    @Test
    void validStateWithMessage() {
        final IllegalStateException ex = assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                Validate.validState(false, "state is %s", "bad");
            }
        });
        assertEquals("state is bad", ex.getMessage());
    }

    // -- constructor --------------------------------------------------------------------------------

    @Test
    @SuppressWarnings("deprecation")
    void defaultConstructorIsPublicAndUsable() {
        final Validate instance = new Validate();
        assertNotNull(instance);
        assertFalse(instance.getClass().isInterface());
    }
}
