/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.FieldPosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link FastDatePrinter}.
 */
class FastDatePrinterAgentTest {

    private static final TimeZone GMT = TimeZone.getTimeZone("GMT");

    private static Calendar newCalendar(final TimeZone tz, final Locale locale, final int year, final int month,
            final int day, final int hour, final int minute, final int second) {
        final Calendar cal = Calendar.getInstance(tz, locale);
        cal.clear();
        cal.set(year, month, day, hour, minute, second);
        return cal;
    }

    @Test
    void testFormatDate_basicPattern() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd'T'HH:mm:ss", GMT, Locale.US);
        final Calendar cal = newCalendar(GMT, Locale.US, 2023, Calendar.JANUARY, 15, 13, 5, 9);
        assertEquals("2023-01-15T13:05:09", printer.format(cal.getTime()));
    }

    @Test
    void testFormatLong_matchesFormatDate() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd HH:mm:ss", GMT, Locale.US);
        final Calendar cal = newCalendar(GMT, Locale.US, 2023, Calendar.JANUARY, 15, 13, 5, 9);
        final long millis = cal.getTime().getTime();
        assertEquals(printer.format(cal.getTime()), printer.format(millis));
    }

    @Test
    void testFormatDate_toAppendableAndStringBuffer() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy/MM/dd", GMT, Locale.US);
        final Date date = newCalendar(GMT, Locale.US, 2020, Calendar.MARCH, 3, 0, 0, 0).getTime();

        final StringBuilder sb = new StringBuilder();
        final StringBuilder returnedSb = printer.format(date, sb);
        assertSame(sb, returnedSb);
        assertEquals("2020/03/03", sb.toString());

        final StringBuffer buf = new StringBuffer();
        final StringBuffer returnedBuf = printer.format(date, buf);
        assertSame(buf, returnedBuf);
        assertEquals("2020/03/03", buf.toString());
    }

    @Test
    void testFormatLong_toAppendableAndStringBuffer() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy/MM/dd", GMT, Locale.US);
        final long millis = newCalendar(GMT, Locale.US, 2020, Calendar.MARCH, 3, 0, 0, 0).getTime().getTime();

        final StringBuilder sb = new StringBuilder();
        assertSame(sb, printer.format(millis, sb));
        assertEquals("2020/03/03", sb.toString());

        final StringBuffer buf = new StringBuffer();
        assertSame(buf, printer.format(millis, buf));
        assertEquals("2020/03/03", buf.toString());
    }

    @Test
    void testFormatCalendar_convertsToPrinterTimeZone() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd HH:mm", GMT, Locale.US);
        final TimeZone plusTwo = TimeZone.getTimeZone("GMT+02:00");
        // 08:30 UTC is 10:30 local time in GMT+2; the Calendar's instant (not its wall-clock
        // fields) must already be resolved for the printer's timezone conversion to apply.
        final long instant = newCalendar(GMT, Locale.US, 2023, Calendar.JUNE, 1, 8, 30, 0).getTimeInMillis();
        final Calendar cal = Calendar.getInstance(plusTwo, Locale.US);
        cal.setTimeInMillis(instant);
        assertEquals(10, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals("2023-06-01 08:30", printer.format(cal));
    }

    @Test
    void testFormatCalendar_sameTimeZone_noConversionNeeded() {
        final FastDatePrinter printer = new FastDatePrinter("HH:mm", GMT, Locale.US);
        final Calendar cal = newCalendar(GMT, Locale.US, 2023, Calendar.JUNE, 1, 10, 30, 0);
        assertEquals("10:30", printer.format(cal));
    }

    @Test
    void testFormatCalendar_stringBufferOverload_matchesAppendableOverload() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd HH:mm", GMT, Locale.US);
        final TimeZone plusTwo = TimeZone.getTimeZone("GMT+02:00");
        final long instant = newCalendar(GMT, Locale.US, 2023, Calendar.JUNE, 1, 8, 30, 0).getTimeInMillis();
        final Calendar cal = Calendar.getInstance(plusTwo, Locale.US);
        cal.setTimeInMillis(instant);
        final String viaAppendable = printer.format(cal);
        final String viaStringBuffer = printer.format(cal, new StringBuffer()).toString();
        assertEquals(viaAppendable, viaStringBuffer);
    }

    @Test
    void testGetPattern() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy", GMT, Locale.US);
        assertEquals("yyyy", printer.getPattern());
    }

    @Test
    void testGetLocale() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy", GMT, Locale.GERMANY);
        assertEquals(Locale.GERMANY, printer.getLocale());
    }

    @Test
    void testConstructor_nullLocale_usesDefaultLocale() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy", GMT, null);
        assertEquals(Locale.getDefault(), printer.getLocale());
    }

    @Test
    void testConstructor_nullPattern_throwsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new FastDatePrinter(null, GMT, Locale.US);
            }
        });
    }

    @Test
    void testConstructor_nullTimeZone_throwsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new FastDatePrinter("yyyy", null, Locale.US);
            }
        });
    }

    @Test
    void testGetTimeZone_returnsIndependentClone() {
        final TimeZone original = TimeZone.getTimeZone("America/New_York");
        final FastDatePrinter printer = new FastDatePrinter("yyyy", original, Locale.US);

        final TimeZone first = printer.getTimeZone();
        final TimeZone second = printer.getTimeZone();

        assertEquals(original, first);
        assertNotSame(first, second);

        // Mutating the clone's original source must not affect the printer's internal state.
        original.setID("Changed/Zone");
        assertEquals("America/New_York", printer.getTimeZone().getID());
    }

    @Test
    void testEqualsAndHashCode() {
        final FastDatePrinter a = new FastDatePrinter("yyyy-MM-dd", GMT, Locale.US);
        final FastDatePrinter b = new FastDatePrinter("yyyy-MM-dd", GMT, Locale.US);
        final FastDatePrinter differentPattern = new FastDatePrinter("yyyy/MM/dd", GMT, Locale.US);
        final FastDatePrinter differentZone = new FastDatePrinter("yyyy-MM-dd", TimeZone.getTimeZone("GMT+1"), Locale.US);
        final FastDatePrinter differentLocale = new FastDatePrinter("yyyy-MM-dd", GMT, Locale.FRANCE);

        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
        assertFalse(a.equals(differentPattern));
        assertFalse(a.equals(differentZone));
        assertFalse(a.equals(differentLocale));
        assertFalse(a.equals(null));
        assertFalse(a.equals("yyyy-MM-dd"));
    }

    @Test
    void testToString() {
        final TimeZone tz = TimeZone.getTimeZone("GMT");
        final FastDatePrinter printer = new FastDatePrinter("yyyy", tz, Locale.US);
        assertEquals("FastDatePrinter[yyyy," + Locale.US + "," + tz.getID() + "]", printer.toString());
    }

    @Test
    void testGetMaxLengthEstimate_fixedWidthPatternMatchesActualLength() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", GMT, Locale.US);
        final Calendar cal = newCalendar(GMT, Locale.US, 2023, Calendar.JANUARY, 5, 0, 0, 0);
        final String formatted = printer.format(cal.getTime());
        assertEquals(10, printer.getMaxLengthEstimate());
        assertEquals(10, formatted.length());
    }

    @Test
    void testGetMaxLengthEstimate_isUpperBoundForVariableWidthField() {
        final FastDatePrinter printer = new FastDatePrinter("d", GMT, Locale.US);
        final Calendar cal = newCalendar(GMT, Locale.US, 2023, Calendar.JANUARY, 5, 0, 0, 0);
        final String formatted = printer.format(cal.getTime());
        assertEquals("5", formatted);
        assertTrue(printer.getMaxLengthEstimate() >= formatted.length());
    }

    @Test
    void testEraPattern() {
        final FastDatePrinter printer = new FastDatePrinter("G", GMT, Locale.US);

        final GregorianCalendar ad = new GregorianCalendar(GMT, Locale.US);
        ad.clear();
        ad.set(Calendar.ERA, GregorianCalendar.AD);
        ad.set(2023, Calendar.JANUARY, 1, 0, 0, 0);
        assertEquals("AD", printer.format(ad.getTime()));

        final GregorianCalendar bc = new GregorianCalendar(GMT, Locale.US);
        bc.clear();
        bc.set(Calendar.ERA, GregorianCalendar.BC);
        bc.set(1, Calendar.JANUARY, 1, 0, 0, 0);
        assertEquals("BC", printer.format(bc.getTime()));
    }

    @Test
    void testTwoDigitYear() {
        final FastDatePrinter printer = new FastDatePrinter("yy", GMT, Locale.US);
        assertEquals("05", printer.format(newCalendar(GMT, Locale.US, 2005, Calendar.MARCH, 1, 0, 0, 0).getTime()));
        assertEquals("99", printer.format(newCalendar(GMT, Locale.US, 1999, Calendar.MARCH, 1, 0, 0, 0).getTime()));
        assertEquals("00", printer.format(newCalendar(GMT, Locale.US, 2000, Calendar.MARCH, 1, 0, 0, 0).getTime()));
    }

    @Test
    void testFourDigitYear() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy", GMT, Locale.US);
        assertEquals("2005", printer.format(newCalendar(GMT, Locale.US, 2005, Calendar.MARCH, 1, 0, 0, 0).getTime()));
    }

    @Test
    void testMonthPatterns() {
        final Calendar cal = newCalendar(GMT, Locale.US, 2023, Calendar.JANUARY, 1, 0, 0, 0);
        assertEquals("1", new FastDatePrinter("M", GMT, Locale.US).format(cal.getTime()));
        assertEquals("01", new FastDatePrinter("MM", GMT, Locale.US).format(cal.getTime()));
        assertEquals("Jan", new FastDatePrinter("MMM", GMT, Locale.US).format(cal.getTime()));
        assertEquals("January", new FastDatePrinter("MMMM", GMT, Locale.US).format(cal.getTime()));
    }

    @Test
    void testStandaloneMonthPatterns() {
        final Calendar cal = newCalendar(GMT, Locale.US, 2023, Calendar.JANUARY, 1, 0, 0, 0);
        assertEquals("1", new FastDatePrinter("L", GMT, Locale.US).format(cal.getTime()));
        assertEquals("01", new FastDatePrinter("LL", GMT, Locale.US).format(cal.getTime()));
        assertEquals("Jan", new FastDatePrinter("LLL", GMT, Locale.US).format(cal.getTime()));
        assertEquals("January", new FastDatePrinter("LLLL", GMT, Locale.US).format(cal.getTime()));
    }

    @Test
    void testDayOfWeekTextPattern() {
        // 2023-01-02 is a Monday.
        final Calendar cal = newCalendar(GMT, Locale.US, 2023, Calendar.JANUARY, 2, 0, 0, 0);
        assertEquals("Mon", new FastDatePrinter("E", GMT, Locale.US).format(cal.getTime()));
        assertEquals("Monday", new FastDatePrinter("EEEE", GMT, Locale.US).format(cal.getTime()));
    }

    @Test
    void testDayInWeekNumberPattern() {
        final FastDatePrinter printer = new FastDatePrinter("u", GMT, Locale.US);
        // 2023-01-02 Monday .. 2023-01-08 Sunday
        assertEquals("1", printer.format(newCalendar(GMT, Locale.US, 2023, Calendar.JANUARY, 2, 0, 0, 0).getTime()));
        assertEquals("6", printer.format(newCalendar(GMT, Locale.US, 2023, Calendar.JANUARY, 7, 0, 0, 0).getTime()));
        assertEquals("7", printer.format(newCalendar(GMT, Locale.US, 2023, Calendar.JANUARY, 8, 0, 0, 0).getTime()));
    }

    @Test
    void testDayInYearPattern() {
        final FastDatePrinter printer = new FastDatePrinter("D", GMT, Locale.US);
        assertEquals("2", printer.format(newCalendar(GMT, Locale.US, 2023, Calendar.JANUARY, 2, 0, 0, 0).getTime()));
    }

    @Test
    void testHourPatterns_midnightBoundary() {
        final Calendar midnight = newCalendar(GMT, Locale.US, 2023, Calendar.JANUARY, 2, 0, 0, 0);
        assertEquals("00", new FastDatePrinter("HH", GMT, Locale.US).format(midnight.getTime()));
        assertEquals("24", new FastDatePrinter("kk", GMT, Locale.US).format(midnight.getTime()));
        assertEquals("12", new FastDatePrinter("hh", GMT, Locale.US).format(midnight.getTime()));
        assertEquals("00", new FastDatePrinter("KK", GMT, Locale.US).format(midnight.getTime()));
    }

    @Test
    void testHourPatterns_afternoon() {
        final Calendar afternoon = newCalendar(GMT, Locale.US, 2023, Calendar.JANUARY, 2, 13, 0, 0);
        assertEquals("13", new FastDatePrinter("HH", GMT, Locale.US).format(afternoon.getTime()));
        assertEquals("13", new FastDatePrinter("kk", GMT, Locale.US).format(afternoon.getTime()));
        assertEquals("01", new FastDatePrinter("hh", GMT, Locale.US).format(afternoon.getTime()));
        assertEquals("01", new FastDatePrinter("KK", GMT, Locale.US).format(afternoon.getTime()));
    }

    @Test
    void testAmPmPattern() {
        final FastDatePrinter printer = new FastDatePrinter("a", GMT, Locale.US);
        assertEquals("AM", printer.format(newCalendar(GMT, Locale.US, 2023, Calendar.JANUARY, 2, 0, 0, 0).getTime()));
        assertEquals("PM", printer.format(newCalendar(GMT, Locale.US, 2023, Calendar.JANUARY, 2, 13, 0, 0).getTime()));
    }

    @Test
    void testMillisecondPattern() {
        final FastDatePrinter printer = new FastDatePrinter("SSS", GMT, Locale.US);
        final Calendar cal = newCalendar(GMT, Locale.US, 2023, Calendar.JANUARY, 2, 0, 0, 0);
        cal.set(Calendar.MILLISECOND, 7);
        assertEquals("007", printer.format(cal.getTime()));
    }

    @Test
    void testWeekYearPattern_matchesCalendarWeekYear() {
        final Calendar cal = newCalendar(GMT, Locale.US, 2023, Calendar.JANUARY, 2, 0, 0, 0);
        final FastDatePrinter printer = new FastDatePrinter("YYYY", GMT, Locale.US);
        final String formatted = printer.format(cal.getTime());
        assertEquals(String.valueOf(cal.getWeekYear()), formatted);
    }

    @Test
    void testWeekYearPattern_negativeWeekYearIsPrefixedWithMinus() {
        final GregorianCalendar cal = new GregorianCalendar(GMT, Locale.US);
        cal.clear();
        cal.setWeekDate(-1, 1, Calendar.MONDAY);
        assertTrue(cal.isWeekDateSupported());
        final int weekYear = cal.getWeekYear();
        assertTrue(weekYear < 0, "expected a negative week-year fixture, got " + weekYear);

        final FastDatePrinter printer = new FastDatePrinter("YYYY", GMT, Locale.US);
        final String formatted = printer.format(cal.getTime());

        final String expectedDigits = String.format("%04d", Math.abs(weekYear));
        assertEquals("-" + expectedDigits, formatted);
    }

    @Test
    void testTimeZoneNumberPattern_zeroOffset() {
        final Calendar cal = newCalendar(GMT, Locale.US, 2023, Calendar.JANUARY, 2, 0, 0, 0);
        assertEquals("+0000", new FastDatePrinter("Z", GMT, Locale.US).format(cal.getTime()));
        assertEquals("Z", new FastDatePrinter("ZZ", GMT, Locale.US).format(cal.getTime()));
        assertEquals("+00:00", new FastDatePrinter("ZZZ", GMT, Locale.US).format(cal.getTime()));
        assertEquals("Z", new FastDatePrinter("X", GMT, Locale.US).format(cal.getTime()));
        assertEquals("Z", new FastDatePrinter("XX", GMT, Locale.US).format(cal.getTime()));
        assertEquals("Z", new FastDatePrinter("XXX", GMT, Locale.US).format(cal.getTime()));
    }

    @Test
    void testTimeZoneNumberPattern_nonZeroOffset() {
        final TimeZone plusFiveThirty = TimeZone.getTimeZone("GMT+05:30");
        final Calendar cal = newCalendar(plusFiveThirty, Locale.US, 2023, Calendar.JANUARY, 2, 0, 0, 0);
        assertEquals("+0530", new FastDatePrinter("Z", plusFiveThirty, Locale.US).format(cal.getTime()));
        assertEquals("+05:30", new FastDatePrinter("ZZ", plusFiveThirty, Locale.US).format(cal.getTime()));
        assertEquals("+05:30", new FastDatePrinter("ZZZ", plusFiveThirty, Locale.US).format(cal.getTime()));
        // 'X' with a single token only renders whole hours, dropping any minutes (implementation quirk).
        assertEquals("+05", new FastDatePrinter("X", plusFiveThirty, Locale.US).format(cal.getTime()));
        assertEquals("+0530", new FastDatePrinter("XX", plusFiveThirty, Locale.US).format(cal.getTime()));
        assertEquals("+05:30", new FastDatePrinter("XXX", plusFiveThirty, Locale.US).format(cal.getTime()));
    }

    @Test
    void testTimeZoneNumberPattern_negativeOffset() {
        final TimeZone minusEight = TimeZone.getTimeZone("GMT-08:00");
        final Calendar cal = newCalendar(minusEight, Locale.US, 2023, Calendar.JANUARY, 2, 0, 0, 0);
        assertEquals("-0800", new FastDatePrinter("Z", minusEight, Locale.US).format(cal.getTime()));
        assertEquals("-08:00", new FastDatePrinter("ZZZ", minusEight, Locale.US).format(cal.getTime()));
    }

    @Test
    void testTimeZoneNameRule_matchesTimeZoneDisplayName() {
        final TimeZone tz = TimeZone.getTimeZone("GMT");
        final Calendar cal = newCalendar(tz, Locale.US, 2023, Calendar.JANUARY, 2, 0, 0, 0);

        final String expectedShort = tz.getDisplayName(false, TimeZone.SHORT, Locale.US);
        final String expectedLong = tz.getDisplayName(false, TimeZone.LONG, Locale.US);

        assertEquals(expectedShort, new FastDatePrinter("z", tz, Locale.US).format(cal.getTime()));
        assertEquals(expectedLong, new FastDatePrinter("zzzz", tz, Locale.US).format(cal.getTime()));
    }

    @Test
    void testIso8601Pattern_invalidTokenLength_throwsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new FastDatePrinter("XXXX", GMT, Locale.US);
            }
        });
    }

    @Test
    void testIllegalPatternComponent_throwsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new FastDatePrinter("yyyy-Q", GMT, Locale.US);
            }
        });
    }

    @Test
    void testLiteralTextWithQuotes() {
        final FastDatePrinter printer = new FastDatePrinter("'Date:' yyyy", GMT, Locale.US);
        final Calendar cal = newCalendar(GMT, Locale.US, 2023, Calendar.JANUARY, 2, 0, 0, 0);
        assertEquals("Date: 2023", printer.format(cal.getTime()));
    }

    @Test
    void testUnterminatedLiteralQuote_consumesRestOfPatternAsLiteral() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy'bad", GMT, Locale.US);
        final Calendar cal = newCalendar(GMT, Locale.US, 2023, Calendar.JANUARY, 2, 0, 0, 0);
        assertEquals("2023bad", printer.format(cal.getTime()));
    }

    @Test
    void testEscapedQuoteInLiteral() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy''MM", GMT, Locale.US);
        final Calendar cal = newCalendar(GMT, Locale.US, 2023, Calendar.JANUARY, 2, 0, 0, 0);
        assertEquals("2023'01", printer.format(cal.getTime()));
    }

    @Test
    void testFormatObject_dateCalendarLong() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", GMT, Locale.US);
        final Calendar cal = newCalendar(GMT, Locale.US, 2023, Calendar.JANUARY, 2, 0, 0, 0);
        final Date date = cal.getTime();
        final Long millis = Long.valueOf(date.getTime());

        assertEquals("2023-01-02", printer.format((Object) date));
        assertEquals("2023-01-02", printer.format((Object) cal));
        assertEquals("2023-01-02", printer.format((Object) millis));
    }

    @Test
    void testFormatObject_unsupportedType_throwsIllegalArgumentException() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", GMT, Locale.US);
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                printer.format((Object) "not a date");
            }
        });
    }

    @Test
    @SuppressWarnings("deprecation")
    void testDeprecatedFormatObjectStringBufferFieldPosition() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", GMT, Locale.US);
        final Calendar cal = newCalendar(GMT, Locale.US, 2023, Calendar.JANUARY, 2, 0, 0, 0);
        final Date date = cal.getTime();
        final Long millis = Long.valueOf(date.getTime());
        final FieldPosition pos = new FieldPosition(0);

        assertEquals("2023-01-02", printer.format(date, new StringBuffer(), pos).toString());
        assertEquals("2023-01-02", printer.format(cal, new StringBuffer(), pos).toString());
        assertEquals("2023-01-02", printer.format(millis, new StringBuffer(), pos).toString());

        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                printer.format("nope", new StringBuffer(), pos);
            }
        });
    }

    @Test
    void testSerialization_roundTripReinitializesTransientState() throws IOException, ClassNotFoundException {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd HH:mm:ss", GMT, Locale.US);

        final ByteArrayOutputStream bos = new ByteArrayOutputStream();
        final ObjectOutputStream oos = new ObjectOutputStream(bos);
        oos.writeObject(printer);
        oos.close();

        final ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(bos.toByteArray()));
        final FastDatePrinter restored = (FastDatePrinter) ois.readObject();
        ois.close();

        assertEquals(printer, restored);
        assertEquals(printer.getPattern(), restored.getPattern());

        final Calendar cal = newCalendar(GMT, Locale.US, 2023, Calendar.JANUARY, 2, 3, 4, 5);
        assertEquals(printer.format(cal.getTime()), restored.format(cal.getTime()));
        assertEquals("2023-01-02 03:04:05", restored.format(cal.getTime()));
    }

    @Test
    void testWeekOfYearAndWeekOfMonthAndDayOfWeekInMonth() {
        // 2023-01-02 is the first Monday of January 2023 (US locale, Sunday is first day of week).
        final Calendar cal = newCalendar(GMT, Locale.US, 2023, Calendar.JANUARY, 2, 0, 0, 0);
        assertEquals("1", new FastDatePrinter("w", GMT, Locale.US).format(cal.getTime()));
        assertEquals("1", new FastDatePrinter("W", GMT, Locale.US).format(cal.getTime()));
        assertEquals("1", new FastDatePrinter("F", GMT, Locale.US).format(cal.getTime()));
    }
}
