/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import java.util.Locale;
import java.util.Set;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link LocaleUtils}.
 */
public class LocaleUtilsAgentTest {

    // --- availableLocaleList / availableLocaleSet ---

    @Test
    public void testAvailableLocaleListNotEmptyAndContainsUs() {
        final List<Locale> locales = LocaleUtils.availableLocaleList();
        assertNotNull(locales);
        assertTrue(locales.size() > 0);
        assertTrue(locales.contains(Locale.US));
    }

    @Test
    public void testAvailableLocaleListIsUnmodifiable() {
        final List<Locale> locales = LocaleUtils.availableLocaleList();
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                locales.add(Locale.US);
            }
        });
    }

    @Test
    public void testAvailableLocaleListSameInstanceEachCall() {
        assertTrue(LocaleUtils.availableLocaleList() == LocaleUtils.availableLocaleList());
    }

    @Test
    public void testAvailableLocaleSetNotEmptyAndContainsUs() {
        final Set<Locale> locales = LocaleUtils.availableLocaleSet();
        assertNotNull(locales);
        assertTrue(locales.size() > 0);
        assertTrue(locales.contains(Locale.US));
    }

    @Test
    public void testAvailableLocaleSetIsUnmodifiable() {
        final Set<Locale> locales = LocaleUtils.availableLocaleSet();
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                locales.add(Locale.US);
            }
        });
    }

    @Test
    public void testAvailableLocaleListAndSetSameSize() {
        assertEquals(LocaleUtils.availableLocaleList().size(), LocaleUtils.availableLocaleSet().size());
    }

    // --- isAvailableLocale ---

    @Test
    public void testIsAvailableLocaleTrue() {
        assertTrue(LocaleUtils.isAvailableLocale(Locale.US));
    }

    @Test
    public void testIsAvailableLocaleFalseForBogusLocale() {
        assertFalse(LocaleUtils.isAvailableLocale(new Locale("xx", "YY", "not-a-real-variant")));
    }

    // --- isLanguageUndetermined ---

    @Test
    public void testIsLanguageUndeterminedNull() {
        assertTrue(LocaleUtils.isLanguageUndetermined(null));
    }

    @Test
    public void testIsLanguageUndeterminedKnownLanguage() {
        assertFalse(LocaleUtils.isLanguageUndetermined(Locale.ENGLISH));
    }

    @Test
    public void testIsLanguageUndeterminedMalformedLanguage() {
        assertTrue(LocaleUtils.isLanguageUndetermined(new Locale("a")));
    }

    // --- countriesByLanguage ---

    @Test
    public void testCountriesByLanguageNull() {
        final List<Locale> result = LocaleUtils.countriesByLanguage(null);
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testCountriesByLanguageUnknownLanguage() {
        final List<Locale> result = LocaleUtils.countriesByLanguage("zz");
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testCountriesByLanguageEnglishAllHaveCountryNoVariant() {
        final List<Locale> result = LocaleUtils.countriesByLanguage("en");
        assertNotNull(result);
        assertTrue(result.size() > 0);
        for (int i = 0; i < result.size(); i++) {
            final Locale locale = result.get(i);
            assertEquals("en", locale.getLanguage());
            assertFalse(locale.getCountry().isEmpty());
            assertTrue(locale.getVariant().isEmpty());
        }
    }

    @Test
    public void testCountriesByLanguageIsUnmodifiable() {
        final List<Locale> result = LocaleUtils.countriesByLanguage("en");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                result.add(Locale.US);
            }
        });
    }

    @Test
    public void testCountriesByLanguageIsCached() {
        assertTrue(LocaleUtils.countriesByLanguage("en") == LocaleUtils.countriesByLanguage("en"));
    }

    // --- languagesByCountry ---

    @Test
    public void testLanguagesByCountryNull() {
        final List<Locale> result = LocaleUtils.languagesByCountry(null);
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testLanguagesByCountryUnknownCountry() {
        final List<Locale> result = LocaleUtils.languagesByCountry("ZZ");
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testLanguagesByCountryGbAllHaveCountryNoVariant() {
        final List<Locale> result = LocaleUtils.languagesByCountry("GB");
        assertNotNull(result);
        assertTrue(result.size() > 0);
        for (int i = 0; i < result.size(); i++) {
            final Locale locale = result.get(i);
            assertEquals("GB", locale.getCountry());
            assertTrue(locale.getVariant().isEmpty());
        }
    }

    @Test
    public void testLanguagesByCountryIsUnmodifiable() {
        final List<Locale> result = LocaleUtils.languagesByCountry("GB");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                result.add(Locale.US);
            }
        });
    }

    // --- localeLookupList(Locale) ---

    @Test
    public void testLocaleLookupListSingleArgNull() {
        final List<Locale> result = LocaleUtils.localeLookupList(null);
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testLocaleLookupListSingleArgLanguageCountry() {
        final List<Locale> result = LocaleUtils.localeLookupList(Locale.US);
        assertEquals(2, result.size());
        assertEquals(Locale.US, result.get(0));
        assertEquals(new Locale("en"), result.get(1));
    }

    @Test
    public void testLocaleLookupListSingleArgLanguageCountryVariant() {
        final Locale locale = new Locale("fr", "CA", "xxx");
        final List<Locale> result = LocaleUtils.localeLookupList(locale);
        assertEquals(3, result.size());
        assertEquals(locale, result.get(0));
        assertEquals(new Locale("fr", "CA"), result.get(1));
        assertEquals(new Locale("fr"), result.get(2));
    }

    @Test
    public void testLocaleLookupListSingleArgLanguageOnly() {
        final List<Locale> result = LocaleUtils.localeLookupList(new Locale("fr"));
        assertEquals(1, result.size());
        assertEquals(new Locale("fr"), result.get(0));
    }

    @Test
    public void testLocaleLookupListSingleArgIsUnmodifiable() {
        final List<Locale> result = LocaleUtils.localeLookupList(Locale.US);
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                result.add(Locale.CANADA);
            }
        });
    }

    // --- localeLookupList(Locale, Locale) ---

    @Test
    public void testLocaleLookupListTwoArgsBothNull() {
        final List<Locale> result = LocaleUtils.localeLookupList(null, null);
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testLocaleLookupListTwoArgsAppendsDefaultWhenDifferent() {
        final List<Locale> result = LocaleUtils.localeLookupList(new Locale("fr"), Locale.ENGLISH);
        assertEquals(2, result.size());
        assertEquals(new Locale("fr"), result.get(0));
        assertEquals(Locale.ENGLISH, result.get(1));
    }

    @Test
    public void testLocaleLookupListTwoArgsDefaultAlreadyPresentNotDuplicated() {
        final List<Locale> result = LocaleUtils.localeLookupList(Locale.US, Locale.US);
        assertEquals(2, result.size());
        assertEquals(Locale.US, result.get(0));
        assertEquals(new Locale("en"), result.get(1));
    }

    // --- toLocale(Locale) ---

    @Test
    public void testToLocaleLocaleOverloadNonNull() {
        assertEquals(Locale.US, LocaleUtils.toLocale(Locale.US));
    }

    @Test
    public void testToLocaleLocaleOverloadNullReturnsDefault() {
        assertEquals(Locale.getDefault(), LocaleUtils.toLocale((Locale) null));
    }

    // --- toLocale(String) happy paths ---

    @Test
    public void testToLocaleStringNull() {
        assertNull(LocaleUtils.toLocale((String) null));
    }

    @Test
    public void testToLocaleStringEmpty() {
        final Locale locale = LocaleUtils.toLocale("");
        assertEquals("", locale.getLanguage());
        assertEquals("", locale.getCountry());
    }

    @Test
    public void testToLocaleStringLanguageOnly() {
        final Locale locale = LocaleUtils.toLocale("en");
        assertEquals("en", locale.getLanguage());
        assertEquals("", locale.getCountry());
    }

    @Test
    public void testToLocaleStringThreeLetterLanguage() {
        final Locale locale = LocaleUtils.toLocale("eng");
        assertEquals("eng", locale.getLanguage());
    }

    @Test
    public void testToLocaleStringLanguageAndCountryUnderscore() {
        final Locale locale = LocaleUtils.toLocale("en_GB");
        assertEquals("en", locale.getLanguage());
        assertEquals("GB", locale.getCountry());
    }

    @Test
    public void testToLocaleStringLanguageAndCountryDash() {
        final Locale locale = LocaleUtils.toLocale("en-GB");
        assertEquals("en", locale.getLanguage());
        assertEquals("GB", locale.getCountry());
    }

    @Test
    public void testToLocaleStringNumericAreaCode() {
        final Locale locale = LocaleUtils.toLocale("en_001");
        assertEquals("en", locale.getLanguage());
        assertEquals("001", locale.getCountry());
    }

    @Test
    public void testToLocaleStringLanguageCountryVariant() {
        final Locale locale = LocaleUtils.toLocale("en_GB_xxx");
        assertEquals("en", locale.getLanguage());
        assertEquals("GB", locale.getCountry());
        assertEquals("xxx", locale.getVariant());
    }

    @Test
    public void testToLocaleStringCountryOnlyIsoCode() {
        final Locale locale = LocaleUtils.toLocale("US");
        assertEquals("", locale.getLanguage());
        assertEquals("US", locale.getCountry());
    }

    @Test
    public void testToLocaleStringUnderscorePrefixCountryOnly() {
        final Locale locale = LocaleUtils.toLocale("_GB");
        assertEquals("", locale.getLanguage());
        assertEquals("GB", locale.getCountry());
    }

    @Test
    public void testToLocaleStringUnderscorePrefixCountryAndVariant() {
        final Locale locale = LocaleUtils.toLocale("_GB_xxx");
        assertEquals("", locale.getLanguage());
        assertEquals("GB", locale.getCountry());
        assertEquals("xxx", locale.getVariant());
    }

    @Test
    public void testToLocaleStringThaiSpecialCase() {
        final Locale locale = LocaleUtils.toLocale("th_TH_TH_#u-nu-thai");
        assertEquals("th", locale.getLanguage());
        assertEquals("TH", locale.getCountry());
        assertEquals("TH", locale.getVariant());
    }

    @Test
    public void testToLocaleStringJapaneseSpecialCase() {
        final Locale locale = LocaleUtils.toLocale("ja_JP_JP_#u-ca-japanese");
        assertEquals("ja", locale.getLanguage());
        assertEquals("JP", locale.getCountry());
        assertEquals("JP", locale.getVariant());
    }

    @Test
    public void testToLocaleStringNumericAreaCodeBypassesLanguageValidation() {
        final Locale locale = LocaleUtils.toLocale("ZZ_012");
        assertEquals("zz", locale.getLanguage());
        assertEquals("012", locale.getCountry());
    }

    // --- toLocale(String) boundary / error cases ---

    @Test
    public void testToLocaleStringTooShortThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("a");
            }
        });
    }

    @Test
    public void testToLocaleStringUnderscorePrefixTooShortThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("_G");
            }
        });
    }

    @Test
    public void testToLocaleStringUnderscorePrefixLowercaseThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("_gb");
            }
        });
    }

    @Test
    public void testToLocaleStringUnderscorePrefixLength4Throws() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("_GBx");
            }
        });
    }

    @Test
    public void testToLocaleStringUnderscorePrefixMismatchedSeparatorThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("_GBXxxx");
            }
        });
    }

    @Test
    public void testToLocaleStringLowercaseCountryThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("en_gb");
            }
        });
    }

    @Test
    public void testToLocaleStringNoSeparatorInvalidThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("enGB");
            }
        });
    }

    @Test
    public void testToLocaleStringFourLetterLanguageThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("engl");
            }
        });
    }

    // --- ofCountry (package-private) ---

    @Test
    public void testOfCountry() {
        final Locale locale = LocaleUtils.ofCountry("US");
        assertEquals("", locale.getLanguage());
        assertEquals("US", locale.getCountry());
    }

    @Test
    public void testOfCountryNullThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                LocaleUtils.ofCountry(null);
            }
        });
    }

    // --- constructor ---

    @Test
    public void testConstructorIsPublic() {
        assertNotNull(new LocaleUtils());
    }
}
