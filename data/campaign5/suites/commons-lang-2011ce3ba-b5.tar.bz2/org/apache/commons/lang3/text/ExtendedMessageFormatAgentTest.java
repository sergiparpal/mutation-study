/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.FieldPosition;
import java.text.Format;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.junit.jupiter.api.Test;

/**
 * Self-contained unit test for {@link ExtendedMessageFormat}.
 */
@Deprecated
class ExtendedMessageFormatAgentTest {

    /** Simple upper-casing format factory used as a fixture. */
    private static class UpperFormatFactory implements FormatFactory {
        @Override
        public Format getFormat(final String name, final String arguments, final Locale locale) {
            return new UpperFormat(arguments);
        }
    }

    /** Simple format that upper-cases its argument's String representation. */
    private static class UpperFormat extends Format {
        private static final long serialVersionUID = 1L;
        private final String arguments;

        UpperFormat(final String arguments) {
            this.arguments = arguments;
        }

        @Override
        public StringBuffer format(final Object obj, final StringBuffer toAppendTo, final FieldPosition pos) {
            return toAppendTo.append(String.valueOf(obj).toUpperCase());
        }

        @Override
        public Object parseObject(final String source, final java.text.ParsePosition pos) {
            return source;
        }

        @Override
        public boolean equals(final Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof UpperFormat)) {
                return false;
            }
            final UpperFormat other = (UpperFormat) obj;
            return arguments == null ? other.arguments == null : arguments.equals(other.arguments);
        }

        @Override
        public int hashCode() {
            return arguments == null ? 0 : arguments.hashCode();
        }
    }

    private Map<String, FormatFactory> createRegistry() {
        final Map<String, FormatFactory> registry = new HashMap<String, FormatFactory>();
        registry.put("upper", new UpperFormatFactory());
        return registry;
    }

    @Test
    void testSimplePatternWithoutRegistry() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello {0}!");
        assertEquals("Hello {0}!", emf.toPattern());
        assertEquals("Hello World!", emf.format(new Object[] {"World"}));
    }

    @Test
    void testConstructorWithLocale() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number}", Locale.US);
        assertEquals(Locale.US, emf.getLocale());
        assertEquals("1,234", emf.format(new Object[] {1234}));
    }

    @Test
    void testCustomFormatRegistry() {
        final Map<String, FormatFactory> registry = createRegistry();
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("Name: {0,upper}", registry);
        final String result = emf.format(new Object[] {"bob"});
        assertEquals("Name: BOB", result);
    }

    @Test
    void testCustomFormatRegistryWithStyle() {
        final Map<String, FormatFactory> registry = createRegistry();
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper,ignored}", registry);
        assertEquals("ABC", emf.format(new Object[] {"abc"}));
        assertTrue(emf.toPattern().contains("upper"));
    }

    @Test
    void testUnknownFormatNameFallsBackToStripped() {
        final Map<String, FormatFactory> registry = createRegistry();
        // unknown format falls through to MessageFormat's own handling, which throws
        // IllegalArgumentException for an invalid format type while applying the pattern.
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{0,unknownformat}", registry);
            }
        });
    }

    @Test
    void testNullRegistryUsesSuperApplyPattern() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("plain {0}", (Map<String, FormatFactory>) null);
        assertEquals("plain {0}", emf.toPattern());
    }

    @Test
    void testUnterminatedFormatElementThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{0", createRegistry());
            }
        });
    }

    @Test
    void testUnterminatedQuotedStringThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("it's a test", createRegistry());
            }
        });
    }

    @Test
    void testInvalidArgumentIndexThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{abc}", createRegistry());
            }
        });
    }

    @Test
    void testQuotedPatternIsPreserved() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("it''s a test {0}", createRegistry());
        assertEquals("it's a test one", emf.format(new Object[] {"one"}));
    }

    @Test
    void testEmptyPattern() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("");
        assertEquals("", emf.toPattern());
        assertEquals("", emf.format(new Object[0]));
    }

    @Test
    void testSetFormatThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormat(0, java.text.NumberFormat.getInstance());
            }
        });
    }

    @Test
    void testSetFormatByArgumentIndexThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormatByArgumentIndex(0, java.text.NumberFormat.getInstance());
            }
        });
    }

    @Test
    void testSetFormatsThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormats(new Format[] {java.text.NumberFormat.getInstance()});
            }
        });
    }

    @Test
    void testSetFormatsByArgumentIndexThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormatsByArgumentIndex(new Format[] {java.text.NumberFormat.getInstance()});
            }
        });
    }

    @Test
    void testEqualsAndHashCode() {
        final Map<String, FormatFactory> registry = createRegistry();
        final ExtendedMessageFormat emf1 = new ExtendedMessageFormat("{0,upper}", registry);
        final ExtendedMessageFormat emf2 = new ExtendedMessageFormat("{0,upper}", registry);
        assertEquals(emf1, emf2);
        assertEquals(emf1.hashCode(), emf2.hashCode());

        final ExtendedMessageFormat emf3 = new ExtendedMessageFormat("{0,upper,x}", registry);
        assertNotEquals(emf1, emf3);
    }

    @Test
    void testEqualsWithDifferentType() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertFalse(emf.equals("not an ExtendedMessageFormat"));
        assertFalse(emf.equals(null));
    }

    @Test
    void testEqualsReflexive() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertTrue(emf.equals(emf));
    }

    @Test
    void testParseIsInheritedFromMessageFormat() throws ParseException {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello {0}!");
        final Object[] parsed = emf.parse("Hello World!");
        assertEquals(1, parsed.length);
        assertEquals("World", parsed[0]);
    }

    @Test
    void testApplyPatternReparses() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", createRegistry());
        emf.applyPattern("{0,upper}");
        assertEquals("XYZ", emf.format(new Object[] {"xyz"}));
    }

    @Test
    void testMultipleArgumentsWithMixedCustomFormats() {
        final Map<String, FormatFactory> registry = createRegistry();
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper} and {1}", registry);
        assertEquals("FOO and bar", emf.format(new Object[] {"foo", "bar"}));
    }

    @Test
    void testNestedChoiceFormatPatternPreserved() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat(
                "{0,choice,0#zero|1#one|2#many}", createRegistry());
        assertEquals("one", emf.format(new Object[] {1}));
        assertEquals("many", emf.format(new Object[] {2}));
    }
}
