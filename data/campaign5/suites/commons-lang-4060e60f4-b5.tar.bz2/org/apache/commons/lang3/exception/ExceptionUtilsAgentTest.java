/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.exception;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.UndeclaredThrowableException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Collectors;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained JUnit tests for {@link ExceptionUtils}.
 */
class ExceptionUtilsAgentTest {

    /**
     * Mimics a legacy JDK 1.4 style wrapper exposing its wrapped exception through
     * a {@code getTargetException()} accessor, one of the default cause method names.
     */
    static class LegacyWrapperException extends Exception {
        private static final long serialVersionUID = 1L;
        private final Throwable target;

        LegacyWrapperException(final Throwable target) {
            this.target = target;
        }

        public Throwable getTargetException() {
            return target;
        }
    }

    @Test
    void testAsRuntimeException() {
        final IOException cause = new IOException("as-runtime");
        final IOException caught = assertThrows(IOException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                throw ExceptionUtils.<RuntimeException>asRuntimeException(cause);
            }
        });
        assertSame(cause, caught);
    }

    @Test
    void testConstructor() {
        assertNotNull(new ExceptionUtils());
    }

    @Test
    void testForEach() {
        final IllegalArgumentException root = new IllegalArgumentException("root");
        final RuntimeException wrapped = new RuntimeException("wrapped", root);
        final List<Throwable> collected = new ArrayList<Throwable>();
        ExceptionUtils.forEach(wrapped, new Consumer<Throwable>() {
            @Override
            public void accept(final Throwable t) {
                collected.add(t);
            }
        });
        assertEquals(Arrays.asList(wrapped, root), collected);

        ExceptionUtils.forEach(null, new Consumer<Throwable>() {
            @Override
            public void accept(final Throwable t) {
                fail("should not be called for a null throwable");
            }
        });
    }

    @Test
    void testGetCause() {
        assertNull(ExceptionUtils.getCause(null));

        final IOException io = new IOException("io");
        final LegacyWrapperException wrapper = new LegacyWrapperException(io);
        assertSame(io, ExceptionUtils.getCause(wrapper));
        assertSame(io, ExceptionUtils.getCause(wrapper, null));
        assertSame(io, ExceptionUtils.getCause(wrapper, new String[] {"getTargetException"}));
        assertSame(io, ExceptionUtils.getCause(wrapper, new String[] {null, "getTargetException"}));
        assertNull(ExceptionUtils.getCause(wrapper, new String[] {"noSuchMethod"}));

        assertNull(ExceptionUtils.getCause(new Exception("plain")));
    }

    @Test
    void testGetDefaultCauseMethodNames() {
        final String[] names1 = ExceptionUtils.getDefaultCauseMethodNames();
        final String[] names2 = ExceptionUtils.getDefaultCauseMethodNames();
        assertTrue(names1.length > 0);
        assertNotSame(names1, names2);
        assertArrayEquals(names1, names2);
    }

    @Test
    void testGetMessage() {
        assertEquals("", ExceptionUtils.getMessage(null));
        assertEquals("IllegalArgumentException: bad arg", ExceptionUtils.getMessage(new IllegalArgumentException("bad arg")));
        assertEquals("IllegalStateException: ", ExceptionUtils.getMessage(new IllegalStateException()));
    }

    @Test
    void testGetRootCause() {
        assertNull(ExceptionUtils.getRootCause(null));

        final IllegalArgumentException root = new IllegalArgumentException("root");
        assertSame(root, ExceptionUtils.getRootCause(root));

        final RuntimeException mid = new RuntimeException("mid", root);
        final IllegalStateException top = new IllegalStateException("top", mid);
        assertSame(root, ExceptionUtils.getRootCause(top));
    }

    @Test
    void testGetRootCauseCyclic() {
        final Exception a = new Exception("a");
        final Exception b = new Exception("b", a);
        a.initCause(b);

        assertEquals(2, ExceptionUtils.getThrowableCount(a));
        final List<Throwable> list = ExceptionUtils.getThrowableList(a);
        assertEquals(Arrays.asList(a, b), list);
        assertSame(b, ExceptionUtils.getRootCause(a));
    }

    @Test
    void testGetRootCauseMessage() {
        assertEquals("", ExceptionUtils.getRootCauseMessage(null));

        final IllegalArgumentException root = new IllegalArgumentException("root");
        final RuntimeException wrapped = new RuntimeException("wrapped", root);
        assertEquals("IllegalArgumentException: root", ExceptionUtils.getRootCauseMessage(wrapped));
    }

    @Test
    void testGetRootCauseStackTrace() {
        assertEquals(0, ExceptionUtils.getRootCauseStackTrace(null).length);
        assertTrue(ExceptionUtils.getRootCauseStackTraceList(null).isEmpty());

        final IllegalArgumentException root = new IllegalArgumentException("root");
        final RuntimeException wrapped = new RuntimeException("wrapped", root);

        final List<String> list = ExceptionUtils.getRootCauseStackTraceList(wrapped);
        assertFalse(list.isEmpty());
        assertEquals(root.toString(), list.get(0));

        boolean foundWrapperMarker = false;
        for (final String frame : list) {
            if (frame.startsWith(ExceptionUtils.WRAPPED_MARKER) && frame.contains(wrapped.toString())) {
                foundWrapperMarker = true;
            }
        }
        assertTrue(foundWrapperMarker);

        final String[] arr = ExceptionUtils.getRootCauseStackTrace(wrapped);
        assertArrayEquals(list.toArray(new String[0]), arr);
    }

    @Test
    void testGetStackFrameList() {
        final Exception e = new Exception("boom");
        final List<String> frames = ExceptionUtils.getStackFrameList(e);
        assertFalse(frames.isEmpty());
        for (final String frame : frames) {
            assertTrue(frame.trim().startsWith("at "), frame);
        }
    }

    @Test
    void testGetStackFramesFromString() {
        final String joined = "line1" + System.lineSeparator() + "line2";
        final String[] lines = ExceptionUtils.getStackFrames(joined);
        assertArrayEquals(new String[] {"line1", "line2"}, lines);
    }

    @Test
    void testGetStackFramesFromThrowable() {
        assertEquals(0, ExceptionUtils.getStackFrames((Throwable) null).length);

        final Exception e = new Exception("boom");
        final String[] frames = ExceptionUtils.getStackFrames(e);
        assertTrue(frames.length > 1);
        assertEquals("java.lang.Exception: boom", frames[0]);
    }

    @Test
    void testGetStackTrace() {
        assertEquals("", ExceptionUtils.getStackTrace(null));

        final Exception e = new Exception("boom");
        final String trace = ExceptionUtils.getStackTrace(e);
        assertTrue(trace.startsWith("java.lang.Exception: boom"));
        assertTrue(trace.contains("at "));
    }

    @Test
    void testGetThrowableCountAndList() {
        assertEquals(0, ExceptionUtils.getThrowableCount(null));
        assertTrue(ExceptionUtils.getThrowableList(null).isEmpty());
        assertEquals(0, ExceptionUtils.getThrowables(null).length);

        final IllegalArgumentException root = new IllegalArgumentException("root");
        final RuntimeException mid = new RuntimeException("mid", root);
        final IllegalStateException top = new IllegalStateException("top", mid);

        assertEquals(3, ExceptionUtils.getThrowableCount(top));
        assertEquals(Arrays.asList(top, mid, root), ExceptionUtils.getThrowableList(top));
        assertArrayEquals(new Throwable[] {top, mid, root}, ExceptionUtils.getThrowables(top));
    }

    @Test
    void testHasCause() {
        final Exception checked = new Exception("checked");
        final UndeclaredThrowableException ute = new UndeclaredThrowableException(checked);
        assertTrue(ExceptionUtils.hasCause(ute, Exception.class));
        assertFalse(ExceptionUtils.hasCause(ute, IllegalStateException.class));

        final RuntimeException re = new RuntimeException("re");
        assertTrue(ExceptionUtils.hasCause(re, RuntimeException.class));
        assertFalse(ExceptionUtils.hasCause(re, IOException.class));
    }

    @Test
    void testIndexOfThrowable() {
        final IllegalArgumentException root = new IllegalArgumentException("root");
        final RuntimeException mid = new RuntimeException("mid", root);
        final IllegalStateException top = new IllegalStateException("top", mid);

        assertEquals(-1, ExceptionUtils.indexOfThrowable(null, RuntimeException.class));
        assertEquals(-1, ExceptionUtils.indexOfThrowable(top, null));

        assertEquals(0, ExceptionUtils.indexOfThrowable(top, IllegalStateException.class));
        assertEquals(1, ExceptionUtils.indexOfThrowable(top, RuntimeException.class));
        assertEquals(2, ExceptionUtils.indexOfThrowable(top, IllegalArgumentException.class));
        assertEquals(-1, ExceptionUtils.indexOfThrowable(top, IOException.class));

        assertEquals(0, ExceptionUtils.indexOfThrowable(top, IllegalStateException.class, -3));
        assertEquals(-1, ExceptionUtils.indexOfThrowable(top, IllegalStateException.class, 1));
        assertEquals(2, ExceptionUtils.indexOfThrowable(top, IllegalArgumentException.class, 2));
        assertEquals(-1, ExceptionUtils.indexOfThrowable(top, IllegalArgumentException.class, 3));
    }

    @Test
    void testIndexOfType() {
        final IllegalArgumentException root = new IllegalArgumentException("root");
        final RuntimeException mid = new RuntimeException("mid", root);
        final IllegalStateException top = new IllegalStateException("top", mid);

        assertEquals(-1, ExceptionUtils.indexOfType(null, RuntimeException.class));
        assertEquals(-1, ExceptionUtils.indexOfType(top, null));

        // subclass match: top (an IllegalStateException) is already a RuntimeException.
        assertEquals(0, ExceptionUtils.indexOfType(top, RuntimeException.class));
        assertEquals(2, ExceptionUtils.indexOfType(top, IllegalArgumentException.class));
        assertEquals(-1, ExceptionUtils.indexOfType(top, IOException.class));
        assertEquals(1, ExceptionUtils.indexOfType(top, RuntimeException.class, 1));
    }

    @Test
    void testIsCheckedAndIsUnchecked() {
        assertFalse(ExceptionUtils.isChecked(null));
        assertTrue(ExceptionUtils.isChecked(new Exception("checked")));
        assertFalse(ExceptionUtils.isChecked(new RuntimeException("unchecked")));
        assertFalse(ExceptionUtils.isChecked(new Error("error")));

        assertFalse(ExceptionUtils.isUnchecked(null));
        assertTrue(ExceptionUtils.isUnchecked(new RuntimeException("unchecked")));
        assertTrue(ExceptionUtils.isUnchecked(new Error("error")));
        assertFalse(ExceptionUtils.isUnchecked(new Exception("checked")));
    }

    @Test
    void testPrintRootCauseStackTrace() {
        final IllegalArgumentException root = new IllegalArgumentException("root cause");
        final RuntimeException wrapped = new RuntimeException("wrapped", root);

        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        final PrintStream ps = new PrintStream(baos);
        ExceptionUtils.printRootCauseStackTrace(wrapped, ps);
        final String psOutput = baos.toString();
        assertTrue(psOutput.contains("IllegalArgumentException: root cause"));
        assertTrue(psOutput.contains(ExceptionUtils.WRAPPED_MARKER));

        final StringWriter sw = new StringWriter();
        final PrintWriter pw = new PrintWriter(sw);
        ExceptionUtils.printRootCauseStackTrace(wrapped, pw);
        assertTrue(sw.toString().contains("IllegalArgumentException: root cause"));

        // null throwable is a no-op and must not touch or require the stream.
        ExceptionUtils.printRootCauseStackTrace(null, (PrintStream) null);
        ExceptionUtils.printRootCauseStackTrace(null, (PrintWriter) null);
        ExceptionUtils.printRootCauseStackTrace((Throwable) null);

        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ExceptionUtils.printRootCauseStackTrace(wrapped, (PrintStream) null);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ExceptionUtils.printRootCauseStackTrace(wrapped, (PrintWriter) null);
            }
        });
    }

    @Test
    void testRemoveCommonFrames() {
        final List<String> causeFrames = new ArrayList<String>(Arrays.asList("at onlyInCause", "at common1", "at common2"));
        final List<String> wrapperFrames = new ArrayList<String>(Arrays.asList("at onlyInWrapper", "at common1", "at common2"));
        ExceptionUtils.removeCommonFrames(causeFrames, wrapperFrames);
        assertEquals(Collections.singletonList("at onlyInCause"), causeFrames);

        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ExceptionUtils.removeCommonFrames(null, new ArrayList<String>());
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ExceptionUtils.removeCommonFrames(new ArrayList<String>(), null);
            }
        });
    }

    @Test
    void testRethrow() {
        final IOException cause = new IOException("rethrow-me");
        final IOException caught = assertThrows(IOException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ExceptionUtils.rethrow(cause);
            }
        });
        assertSame(cause, caught);
    }

    @Test
    void testStream() {
        final IllegalArgumentException root = new IllegalArgumentException("root");
        final RuntimeException wrapped = new RuntimeException("wrapped", root);

        final List<Throwable> streamed = ExceptionUtils.stream(wrapped).collect(Collectors.toList());
        assertEquals(Arrays.asList(wrapped, root), streamed);
        assertEquals(0, ExceptionUtils.stream(null).count());
    }

    @Test
    void testThrowableOfThrowable() {
        final IllegalArgumentException root = new IllegalArgumentException("root");
        final RuntimeException mid = new RuntimeException("mid", root);
        final IllegalStateException top = new IllegalStateException("top", mid);

        assertNull(ExceptionUtils.throwableOfThrowable(null, RuntimeException.class));
        assertNull(ExceptionUtils.throwableOfThrowable(top, null));

        assertSame(top, ExceptionUtils.throwableOfThrowable(top, IllegalStateException.class));
        assertSame(mid, ExceptionUtils.throwableOfThrowable(top, RuntimeException.class));
        assertNull(ExceptionUtils.throwableOfThrowable(top, IOException.class));

        assertSame(root, ExceptionUtils.throwableOfThrowable(top, IllegalArgumentException.class, 1));
        assertNull(ExceptionUtils.throwableOfThrowable(top, IllegalStateException.class, 5));
    }

    @Test
    void testThrowableOfType() {
        final IllegalArgumentException root = new IllegalArgumentException("root");
        final RuntimeException mid = new RuntimeException("mid", root);
        final IllegalStateException top = new IllegalStateException("top", mid);

        assertNull(ExceptionUtils.throwableOfType(null, RuntimeException.class));
        assertNull(ExceptionUtils.throwableOfType(top, null));

        // subclass match: top (an IllegalStateException) is already a RuntimeException.
        assertSame(top, ExceptionUtils.throwableOfType(top, RuntimeException.class));
        assertSame(mid, ExceptionUtils.throwableOfType(top, RuntimeException.class, 1));
        assertNull(ExceptionUtils.throwableOfType(top, IOException.class));
    }

    @Test
    void testThrowUncheckedBoundedWithChecked() {
        final IOException checked = new IOException("checked");
        final Throwable returned = ExceptionUtils.throwUnchecked(checked);
        assertSame(checked, returned);
    }

    @Test
    void testThrowUncheckedBoundedWithUnchecked() {
        final RuntimeException re = new RuntimeException("unchecked");
        final RuntimeException caught = assertThrows(RuntimeException.class, new Executable() {
            @Override
            public void execute() {
                ExceptionUtils.throwUnchecked(re);
            }
        });
        assertSame(re, caught);
    }

    @Test
    void testThrowUncheckedDeprecatedWithNonThrowable() {
        final String notAThrowable = "not-a-throwable";
        final String returned = ExceptionUtils.throwUnchecked(notAThrowable);
        assertEquals(notAThrowable, returned);
    }

    @Test
    void testWrapAndThrowChecked() {
        final IOException checked = new IOException("checked");
        final UndeclaredThrowableException ute = assertThrows(UndeclaredThrowableException.class, new Executable() {
            @Override
            public void execute() {
                ExceptionUtils.wrapAndThrow(checked);
            }
        });
        assertSame(checked, ute.getCause());
    }

    @Test
    void testWrapAndThrowUnchecked() {
        final RuntimeException re = new RuntimeException("unchecked");
        final RuntimeException caught = assertThrows(RuntimeException.class, new Executable() {
            @Override
            public void execute() {
                ExceptionUtils.wrapAndThrow(re);
            }
        });
        assertSame(re, caught);
    }
}
