/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.function.FailableBiConsumer;
import org.apache.commons.lang3.function.FailableConsumer;
import org.apache.commons.lang3.function.FailableRunnable;
import org.junit.jupiter.api.Test;

class DurationUtilsAgentTest {

    private static final class TestException extends Exception {
        private static final long serialVersionUID = 1L;

        TestException(final String message) {
            super(message);
        }
    }

    @Test
    void testAcceptNullConsumer() throws TestException {
        // Should simply do nothing, not throw.
        DurationUtils.<TestException>accept(null, Duration.ofMillis(123));
    }

    @Test
    void testAcceptNullDuration() throws TestException {
        final List<Object> calls = new ArrayList<>();
        final FailableBiConsumer<Long, Integer, TestException> consumer = new FailableBiConsumer<Long, Integer, TestException>() {
            @Override
            public void accept(final Long millis, final Integer nanos) {
                calls.add(millis);
            }
        };
        DurationUtils.accept(consumer, null);
        assertTrue(calls.isEmpty());
    }

    @Test
    void testAcceptValid() throws TestException {
        final Duration duration = Duration.ofSeconds(2, 1_500_000); // 2s + 1.5ms in nanos
        final List<Long> millisCalls = new ArrayList<Long>();
        final List<Integer> nanosCalls = new ArrayList<Integer>();
        final FailableBiConsumer<Long, Integer, TestException> consumer = new FailableBiConsumer<Long, Integer, TestException>() {
            @Override
            public void accept(final Long millis, final Integer nanos) {
                millisCalls.add(millis);
                nanosCalls.add(nanos);
            }
        };
        DurationUtils.accept(consumer, duration);
        assertEquals(1, millisCalls.size());
        assertEquals(duration.toMillis(), millisCalls.get(0).longValue());
        assertEquals(DurationUtils.getNanosOfMilli(duration), nanosCalls.get(0).intValue());
    }

    @Test
    void testAcceptPropagatesException() {
        final FailableBiConsumer<Long, Integer, TestException> consumer = new FailableBiConsumer<Long, Integer, TestException>() {
            @Override
            public void accept(final Long millis, final Integer nanos) throws TestException {
                throw new TestException("boom");
            }
        };
        final TestException ex = assertThrows(TestException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() throws Throwable {
                        DurationUtils.accept(consumer, Duration.ofMillis(5));
                    }
                });
        assertEquals("boom", ex.getMessage());
    }

    @Test
    void testGetWithNullKeyReturnsDefault() {
        final Duration result = DurationUtils.get(null, ChronoUnit.SECONDS, 42L);
        assertEquals(Duration.ofSeconds(42L), result);
    }

    @Test
    void testGetWithEmptyKeyReturnsDefault() {
        final Duration result = DurationUtils.get("", ChronoUnit.SECONDS, 7L);
        assertEquals(Duration.ofSeconds(7L), result);
    }

    @Test
    void testGetWithUnsetPropertyReturnsDefault() {
        final Duration result = DurationUtils.get("org.apache.commons.lang3.time.DurationUtilsAgentTest.unset.key", ChronoUnit.MINUTES, 3L);
        assertEquals(Duration.of(3L, ChronoUnit.MINUTES), result);
    }

    @Test
    void testGetMillisWithNullKeyReturnsDefault() {
        assertEquals(Duration.ofMillis(100L), DurationUtils.getMillis(null, 100L));
    }

    @Test
    void testGetMillisWithEmptyKeyReturnsDefault() {
        assertEquals(Duration.ofMillis(0L), DurationUtils.getMillis("", 0L));
    }

    @Test
    void testGetSecondsWithNullKeyReturnsDefault() {
        assertEquals(Duration.ofSeconds(-5L), DurationUtils.getSeconds(null, -5L));
    }

    @Test
    void testGetSecondsWithEmptyKeyReturnsDefault() {
        assertEquals(Duration.ofSeconds(9L), DurationUtils.getSeconds("", 9L));
    }

    @Test
    void testGetNanosOfMilliNullDuration() {
        assertEquals(0, DurationUtils.getNanosOfMilli(null));
    }

    @Test
    void testGetNanosOfMilliZero() {
        assertEquals(0, DurationUtils.getNanosOfMilli(Duration.ZERO));
    }

    @Test
    void testGetNanosOfMilliNonZero() {
        // 123 full milliseconds plus 456,789 extra nanoseconds within the current millisecond.
        final Duration duration = Duration.ofNanos(123L * 1_000_000L + 456_789L);
        assertEquals(456_789, DurationUtils.getNanosOfMilli(duration));
    }

    @SuppressWarnings("deprecation")
    @Test
    void testGetNanosOfMiiliDeprecatedMatchesReplacement() {
        final Duration duration = Duration.ofNanos(7_000_123L);
        assertEquals(DurationUtils.getNanosOfMilli(duration), DurationUtils.getNanosOfMiili(duration));
    }

    @Test
    void testIsPositiveTrue() {
        assertTrue(DurationUtils.isPositive(Duration.ofSeconds(1)));
    }

    @Test
    void testIsPositiveFalseZero() {
        assertFalse(DurationUtils.isPositive(Duration.ZERO));
    }

    @Test
    void testIsPositiveFalseNegative() {
        assertFalse(DurationUtils.isPositive(Duration.ofSeconds(-1)));
    }

    @Test
    void testIsPositiveNullThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationUtils.isPositive(null);
            }
        });
    }

    @Test
    void testOfConsumerReturnsNonNegativeDuration() throws TestException {
        final Duration result = DurationUtils.of(new FailableConsumer<Instant, TestException>() {
            @Override
            public void accept(final Instant start) {
                // no-op, just measure elapsed time
            }
        });
        assertFalse(result.isNegative());
    }

    @Test
    void testOfConsumerPropagatesException() {
        final TestException ex = assertThrows(TestException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                DurationUtils.of(new FailableConsumer<Instant, TestException>() {
                    @Override
                    public void accept(final Instant start) throws TestException {
                        throw new TestException("consumer failed");
                    }
                });
            }
        });
        assertEquals("consumer failed", ex.getMessage());
    }

    @Test
    void testOfRunnableReturnsNonNegativeDuration() throws TestException {
        final Duration result = DurationUtils.of(new FailableRunnable<TestException>() {
            @Override
            public void run() {
                // no-op, just measure elapsed time
            }
        });
        assertFalse(result.isNegative());
    }

    @Test
    void testOfRunnablePropagatesException() {
        final TestException ex = assertThrows(TestException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                DurationUtils.of(new FailableRunnable<TestException>() {
                    @Override
                    public void run() throws TestException {
                        throw new TestException("runnable failed");
                    }
                });
            }
        });
        assertEquals("runnable failed", ex.getMessage());
    }

    @Test
    void testSinceReturnsNonNegativeDurationForPastInstant() {
        final Instant past = Instant.now().minusSeconds(1);
        final Duration result = DurationUtils.since(past);
        assertFalse(result.isNegative());
        assertTrue(result.toMillis() >= 900L);
    }

    @Test
    void testSinceNullThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationUtils.since(null);
            }
        });
    }

    @Test
    void testToChronoUnitMapsAllKnownUnits() {
        assertEquals(ChronoUnit.NANOS, DurationUtils.toChronoUnit(TimeUnit.NANOSECONDS));
        assertEquals(ChronoUnit.MICROS, DurationUtils.toChronoUnit(TimeUnit.MICROSECONDS));
        assertEquals(ChronoUnit.MILLIS, DurationUtils.toChronoUnit(TimeUnit.MILLISECONDS));
        assertEquals(ChronoUnit.SECONDS, DurationUtils.toChronoUnit(TimeUnit.SECONDS));
        assertEquals(ChronoUnit.MINUTES, DurationUtils.toChronoUnit(TimeUnit.MINUTES));
        assertEquals(ChronoUnit.HOURS, DurationUtils.toChronoUnit(TimeUnit.HOURS));
        assertEquals(ChronoUnit.DAYS, DurationUtils.toChronoUnit(TimeUnit.DAYS));
    }

    @Test
    void testToChronoUnitNullThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationUtils.toChronoUnit(null);
            }
        });
    }

    @Test
    void testToDuration() {
        assertEquals(Duration.ofSeconds(90L), DurationUtils.toDuration(90L, TimeUnit.SECONDS));
        assertEquals(Duration.ofMillis(-5L), DurationUtils.toDuration(-5L, TimeUnit.MILLISECONDS));
        assertEquals(Duration.ofDays(2L), DurationUtils.toDuration(2L, TimeUnit.DAYS));
    }

    @Test
    void testToMillisIntNullThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationUtils.toMillisInt(null);
            }
        });
    }

    @Test
    void testToMillisIntNormal() {
        assertEquals(1500, DurationUtils.toMillisInt(Duration.ofMillis(1500L)));
    }

    @Test
    void testToMillisIntClampsToMaxValue() {
        final Duration huge = Duration.ofMillis(Long.MAX_VALUE);
        assertEquals(Integer.MAX_VALUE, DurationUtils.toMillisInt(huge));
    }

    @Test
    void testToMillisIntClampsToMinValue() {
        final Duration hugeNegative = Duration.ofMillis(Long.MIN_VALUE);
        assertEquals(Integer.MIN_VALUE, DurationUtils.toMillisInt(hugeNegative));
    }

    @Test
    void testToMillisLongNullThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationUtils.toMillisLong(null);
            }
        });
    }

    @Test
    void testToMillisLongNormal() {
        assertEquals(5000L, DurationUtils.toMillisLong(Duration.ofSeconds(5L)));
    }

    @Test
    void testToMillisLongClampsToMaxValueOnOverflow() {
        final Duration overflowing = Duration.ofSeconds(Long.MAX_VALUE);
        assertEquals(Long.MAX_VALUE, DurationUtils.toMillisLong(overflowing));
    }

    @Test
    void testToMillisLongClampsToMinValueOnOverflow() {
        final Duration overflowing = Duration.ofSeconds(Long.MIN_VALUE);
        assertEquals(Long.MIN_VALUE, DurationUtils.toMillisLong(overflowing));
    }

    @Test
    void testZeroIfNullWithNull() {
        assertEquals(Duration.ZERO, DurationUtils.zeroIfNull(null));
    }

    @Test
    void testZeroIfNullWithNonNull() {
        final Duration value = Duration.ofMinutes(5L);
        assertEquals(value, DurationUtils.zeroIfNull(value));
    }

    @Test
    void testConstructorCreatesInstance() {
        assertTrue(new DurationUtils() instanceof DurationUtils);
    }
}
