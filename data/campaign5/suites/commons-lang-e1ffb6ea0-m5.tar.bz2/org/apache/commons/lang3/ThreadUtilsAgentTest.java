/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Duration;
import java.util.Collection;
import java.util.function.Predicate;

import org.apache.commons.lang3.function.Predicates;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

/**
 * Tests {@link ThreadUtils}.
 */
public class ThreadUtilsAgentTest {

    private Thread spawned;

    @AfterEach
    public void tearDown() throws InterruptedException {
        if (spawned != null) {
            spawned.interrupt();
            spawned.join(1000);
        }
    }

    private Thread startNamedThread(final String name) throws InterruptedException {
        final Object lock = new Object();
        final boolean[] started = new boolean[1];
        final Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                synchronized (lock) {
                    started[0] = true;
                    lock.notifyAll();
                }
                try {
                    Thread.sleep(60000);
                } catch (final InterruptedException ignore) {
                    // expected on teardown
                }
            }
        }, name);
        thread.setDaemon(true);
        spawned = thread;
        synchronized (lock) {
            thread.start();
            while (!started[0]) {
                lock.wait();
            }
        }
        return thread;
    }

    // --- findThreadById(long) ---

    @Test
    public void testFindThreadByIdZeroThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ThreadUtils.findThreadById(0);
            }
        });
    }

    @Test
    public void testFindThreadByIdNegativeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ThreadUtils.findThreadById(-1);
            }
        });
    }

    @Test
    public void testFindThreadByIdCurrentThread() {
        final Thread current = Thread.currentThread();
        final Thread found = ThreadUtils.findThreadById(current.getId());
        assertSame(current, found);
    }

    @Test
    public void testFindThreadByIdNonExistent() {
        long maxId = 1;
        for (final Thread t : ThreadUtils.getAllThreads()) {
            maxId = Math.max(maxId, t.getId());
        }
        final Thread found = ThreadUtils.findThreadById(maxId + 100000);
        assertNull(found);
    }

    // --- findThreadById(long, String) / (long, ThreadGroup) ---

    @Test
    public void testFindThreadByIdAndGroupNameNullGroupNameThrows() {
        final long id = Thread.currentThread().getId();
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ThreadUtils.findThreadById(id, (String) null);
            }
        });
    }

    @Test
    public void testFindThreadByIdAndGroupNullGroupThrows() {
        final long id = Thread.currentThread().getId();
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ThreadUtils.findThreadById(id, (ThreadGroup) null);
            }
        });
    }

    @Test
    public void testFindThreadByIdAndMatchingGroup() {
        final Thread current = Thread.currentThread();
        final ThreadGroup group = current.getThreadGroup();
        final Thread found = ThreadUtils.findThreadById(current.getId(), group);
        assertSame(current, found);
    }

    @Test
    public void testFindThreadByIdAndNonMatchingGroupName() {
        final Thread current = Thread.currentThread();
        final Thread found = ThreadUtils.findThreadById(current.getId(), "no-such-group-name-xyz");
        assertNull(found);
    }

    @Test
    public void testFindThreadByIdAndNonMatchingGroup() {
        final Thread current = Thread.currentThread();
        final ThreadGroup other = new ThreadGroup("ThreadUtilsAgentTest-other-group");
        try {
            final Thread found = ThreadUtils.findThreadById(current.getId(), other);
            assertNull(found);
        } finally {
            other.destroy();
        }
    }

    // --- findThreadGroups ---

    @Test
    public void testFindThreadGroupsNullPredicateThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ThreadUtils.findThreadGroups((Predicate<ThreadGroup>) null);
            }
        });
    }

    @Test
    public void testFindThreadGroupsNullGroupThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ThreadUtils.findThreadGroups(null, true, Predicates.<ThreadGroup>truePredicate());
            }
        });
    }

    @Test
    public void testFindThreadGroupsAlwaysTrueFindsCurrentGroup() {
        final ThreadGroup current = Thread.currentThread().getThreadGroup();
        final Collection<ThreadGroup> groups = ThreadUtils.findThreadGroups(Predicates.<ThreadGroup>truePredicate());
        assertTrue(groups.contains(current));
    }

    @Test
    public void testFindThreadGroupsUnmodifiable() {
        final Collection<ThreadGroup> groups = ThreadUtils.findThreadGroups(Predicates.<ThreadGroup>truePredicate());
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                groups.clear();
            }
        });
    }

    @Test
    public void testFindThreadGroupsByName() throws InterruptedException {
        final String groupName = "ThreadUtilsAgentTest-group-" + System.nanoTime();
        final ThreadGroup group = new ThreadGroup(groupName);
        try {
            final Collection<ThreadGroup> found = ThreadUtils.findThreadGroupsByName(groupName);
            assertEquals(1, found.size());
            assertSame(group, found.iterator().next());
        } finally {
            group.destroy();
        }
    }

    @Test
    public void testFindThreadGroupsByNameNonExistent() {
        final Collection<ThreadGroup> found = ThreadUtils.findThreadGroupsByName("no-such-group-name-xyz-" + System.nanoTime());
        assertNotNull(found);
        assertTrue(found.isEmpty());
    }

    @Test
    public void testFindThreadGroupsByNameNullThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ThreadUtils.findThreadGroupsByName(null);
            }
        });
    }

    // --- findThreads ---

    @Test
    public void testFindThreadsNullPredicateThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ThreadUtils.findThreads((Predicate<Thread>) null);
            }
        });
    }

    @Test
    public void testFindThreadsNullGroupThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ThreadUtils.findThreads(null, true, Predicates.<Thread>truePredicate());
            }
        });
    }

    @Test
    public void testFindThreadsAlwaysTrueFindsCurrentThread() {
        final Thread current = Thread.currentThread();
        final Collection<Thread> threads = ThreadUtils.findThreads(Predicates.<Thread>truePredicate());
        assertTrue(threads.contains(current));
    }

    @Test
    public void testFindThreadsUnmodifiable() {
        final Collection<Thread> threads = ThreadUtils.findThreads(Predicates.<Thread>truePredicate());
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                threads.clear();
            }
        });
    }

    @Test
    public void testFindThreadsByNameFindsSpawned() throws InterruptedException {
        final String name = "ThreadUtilsAgentTest-thread-" + System.nanoTime();
        final Thread thread = startNamedThread(name);
        final Collection<Thread> found = ThreadUtils.findThreadsByName(name);
        assertEquals(1, found.size());
        assertSame(thread, found.iterator().next());
    }

    @Test
    public void testFindThreadsByNameNonExistent() {
        final Collection<Thread> found = ThreadUtils.findThreadsByName("no-such-thread-name-xyz-" + System.nanoTime());
        assertNotNull(found);
        assertTrue(found.isEmpty());
    }

    @Test
    public void testFindThreadsByNameNullThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ThreadUtils.findThreadsByName(null);
            }
        });
    }

    @Test
    public void testFindThreadsByNameAndGroupName() throws InterruptedException {
        final String groupName = "ThreadUtilsAgentTest-group2-" + System.nanoTime();
        final ThreadGroup group = new ThreadGroup(groupName);
        final String threadName = "ThreadUtilsAgentTest-thread2-" + System.nanoTime();
        try {
            final boolean[] started = new boolean[1];
            final Object lock = new Object();
            final Thread thread = new Thread(group, new Runnable() {
                @Override
                public void run() {
                    synchronized (lock) {
                        started[0] = true;
                        lock.notifyAll();
                    }
                    try {
                        Thread.sleep(60000);
                    } catch (final InterruptedException ignore) {
                        // expected
                    }
                }
            }, threadName);
            thread.setDaemon(true);
            spawned = thread;
            synchronized (lock) {
                thread.start();
                while (!started[0]) {
                    lock.wait();
                }
            }
            final Collection<Thread> foundByGroupName = ThreadUtils.findThreadsByName(threadName, groupName);
            assertEquals(1, foundByGroupName.size());
            assertSame(thread, foundByGroupName.iterator().next());

            final Collection<Thread> foundByGroup = ThreadUtils.findThreadsByName(threadName, group);
            assertEquals(1, foundByGroup.size());
            assertSame(thread, foundByGroup.iterator().next());
        } finally {
            spawned.interrupt();
            spawned.join(1000);
            group.destroy();
        }
    }

    @Test
    public void testFindThreadsByNameAndGroupNameNullThreadNameThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ThreadUtils.findThreadsByName(null, "someGroup");
            }
        });
    }

    @Test
    public void testFindThreadsByNameAndGroupNameNullGroupNameThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ThreadUtils.findThreadsByName("someThread", (String) null);
            }
        });
    }

    @Test
    public void testFindThreadsByNameAndGroupNoMatch() {
        final Collection<Thread> found = ThreadUtils.findThreadsByName("no-such-thread-xyz", "no-such-group-xyz");
        assertNotNull(found);
        assertTrue(found.isEmpty());
    }

    // --- getAllThreadGroups / getAllThreads ---

    @Test
    public void testGetAllThreadGroupsContainsCurrent() {
        final ThreadGroup current = Thread.currentThread().getThreadGroup();
        final Collection<ThreadGroup> groups = ThreadUtils.getAllThreadGroups();
        assertTrue(groups.contains(current));
    }

    @Test
    public void testGetAllThreadsContainsCurrent() {
        final Thread current = Thread.currentThread();
        final Collection<Thread> threads = ThreadUtils.getAllThreads();
        assertTrue(threads.contains(current));
    }

    @Test
    public void testGetAllThreadsContainsSpawned() throws InterruptedException {
        final String name = "ThreadUtilsAgentTest-all-" + System.nanoTime();
        final Thread thread = startNamedThread(name);
        final Collection<Thread> threads = ThreadUtils.getAllThreads();
        assertTrue(threads.contains(thread));
    }

    // --- getSystemThreadGroup ---

    @Test
    public void testGetSystemThreadGroupHasNoParent() {
        final ThreadGroup systemGroup = ThreadUtils.getSystemThreadGroup();
        assertNotNull(systemGroup);
        assertNull(systemGroup.getParent());
    }

    @Test
    public void testGetSystemThreadGroupIsAncestorOfCurrent() {
        final ThreadGroup systemGroup = ThreadUtils.getSystemThreadGroup();
        ThreadGroup current = Thread.currentThread().getThreadGroup();
        boolean foundSystemAsAncestor = false;
        while (current != null) {
            if (current == systemGroup) {
                foundSystemAsAncestor = true;
                break;
            }
            current = current.getParent();
        }
        assertTrue(foundSystemAsAncestor);
    }

    // --- join ---

    @Test
    public void testJoinWithAlreadyFinishedThread() throws InterruptedException {
        final Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                // no-op, finishes immediately
            }
        });
        thread.start();
        thread.join();
        final long start = System.currentTimeMillis();
        ThreadUtils.join(thread, Duration.ofSeconds(5));
        final long elapsed = System.currentTimeMillis() - start;
        assertFalse(thread.isAlive());
        assertTrue(elapsed < 5000);
    }

    @Test
    public void testJoinTimesOutForLiveThread() throws InterruptedException {
        final String name = "ThreadUtilsAgentTest-join-" + System.nanoTime();
        final Thread thread = startNamedThread(name);
        final long start = System.currentTimeMillis();
        ThreadUtils.join(thread, Duration.ofMillis(100));
        final long elapsed = System.currentTimeMillis() - start;
        assertTrue(thread.isAlive());
        assertTrue(elapsed >= 90);
    }

    // --- sleep / sleepQuietly ---

    @Test
    public void testSleepDuration() throws InterruptedException {
        final long start = System.currentTimeMillis();
        ThreadUtils.sleep(Duration.ofMillis(100));
        final long elapsed = System.currentTimeMillis() - start;
        assertTrue(elapsed >= 90);
    }

    @Test
    public void testSleepQuietlyDuration() {
        final long start = System.currentTimeMillis();
        ThreadUtils.sleepQuietly(Duration.ofMillis(100));
        final long elapsed = System.currentTimeMillis() - start;
        assertTrue(elapsed >= 90);
    }

    @Test
    public void testSleepQuietlyHandlesInterrupt() throws InterruptedException {
        final boolean[] interruptedFlagAfterSleep = new boolean[1];
        final Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                ThreadUtils.sleepQuietly(Duration.ofSeconds(10));
                interruptedFlagAfterSleep[0] = Thread.currentThread().isInterrupted();
            }
        });
        thread.start();
        Thread.sleep(50);
        thread.interrupt();
        thread.join(5000);
        assertFalse(thread.isAlive());
        assertTrue(interruptedFlagAfterSleep[0]);
    }

    // --- predicates (deprecated inner classes) ---

    @Test
    public void testNamePredicateConstructorNullThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ThreadUtils.NamePredicate(null);
            }
        });
    }

    @Test
    public void testNamePredicateMatchesThreadByName() {
        final ThreadUtils.NamePredicate predicate = new ThreadUtils.NamePredicate("main");
        assertTrue(predicate.test(Thread.currentThread()) || !Thread.currentThread().getName().equals("main"));
        assertFalse(predicate.test((Thread) null));
        assertFalse(predicate.test((ThreadGroup) null));
    }

    @Test
    public void testNamePredicateMatchesThreadGroupByName() {
        final String groupName = "ThreadUtilsAgentTest-np-" + System.nanoTime();
        final ThreadGroup group = new ThreadGroup(groupName);
        try {
            final ThreadUtils.NamePredicate predicate = new ThreadUtils.NamePredicate(groupName);
            assertTrue(predicate.test(group));
            assertFalse(predicate.test(Thread.currentThread().getThreadGroup()));
        } finally {
            group.destroy();
        }
    }

    @Test
    public void testThreadIdPredicateZeroThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ThreadUtils.ThreadIdPredicate(0);
            }
        });
    }

    @Test
    public void testThreadIdPredicateNegativeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ThreadUtils.ThreadIdPredicate(-5);
            }
        });
    }

    @Test
    public void testThreadIdPredicateMatchesById() {
        final Thread current = Thread.currentThread();
        final ThreadUtils.ThreadIdPredicate predicate = new ThreadUtils.ThreadIdPredicate(current.getId());
        assertTrue(predicate.test(current));
        assertFalse(predicate.test((Thread) null));
    }

    @Test
    public void testThreadIdPredicateDoesNotMatchDifferentId() {
        final Thread current = Thread.currentThread();
        final ThreadUtils.ThreadIdPredicate predicate = new ThreadUtils.ThreadIdPredicate(current.getId() + 1);
        assertFalse(predicate.test(current));
    }

    @Test
    public void testAlwaysTruePredicateMatchesEverything() {
        final ThreadUtils.ThreadPredicate threadPredicate = ThreadUtils.ALWAYS_TRUE_PREDICATE;
        final ThreadUtils.ThreadGroupPredicate threadGroupPredicate = ThreadUtils.ALWAYS_TRUE_PREDICATE;
        assertTrue(threadPredicate.test(Thread.currentThread()));
        assertTrue(threadPredicate.test((Thread) null));
        assertTrue(threadGroupPredicate.test(Thread.currentThread().getThreadGroup()));
        assertTrue(threadGroupPredicate.test((ThreadGroup) null));
    }

    // --- deprecated ThreadPredicate/ThreadGroupPredicate overloads ---

    @Test
    public void testFindThreadsWithDeprecatedThreadPredicate() {
        final Thread current = Thread.currentThread();
        final ThreadUtils.ThreadIdPredicate predicate = new ThreadUtils.ThreadIdPredicate(current.getId());
        final Collection<Thread> found = ThreadUtils.findThreads(predicate);
        assertEquals(1, found.size());
        assertSame(current, found.iterator().next());
    }

    @Test
    public void testFindThreadGroupsWithDeprecatedThreadGroupPredicate() {
        final String groupName = "ThreadUtilsAgentTest-dep-" + System.nanoTime();
        final ThreadGroup group = new ThreadGroup(groupName);
        try {
            final ThreadUtils.NamePredicate predicate = new ThreadUtils.NamePredicate(groupName);
            final Collection<ThreadGroup> found = ThreadUtils.findThreadGroups(predicate);
            assertEquals(1, found.size());
            assertSame(group, found.iterator().next());
        } finally {
            group.destroy();
        }
    }

    @Test
    public void testFindThreadsWithGroupAndDeprecatedThreadPredicate() {
        final Thread current = Thread.currentThread();
        final ThreadGroup group = current.getThreadGroup();
        final ThreadUtils.ThreadIdPredicate predicate = new ThreadUtils.ThreadIdPredicate(current.getId());
        final Collection<Thread> found = ThreadUtils.findThreads(group, true, predicate);
        assertTrue(found.contains(current));
    }

    @Test
    public void testFindThreadGroupsWithGroupAndDeprecatedThreadGroupPredicate() {
        final String groupName = "ThreadUtilsAgentTest-dep2-" + System.nanoTime();
        final ThreadGroup parent = Thread.currentThread().getThreadGroup();
        final ThreadGroup group = new ThreadGroup(parent, groupName);
        try {
            final ThreadUtils.NamePredicate predicate = new ThreadUtils.NamePredicate(groupName);
            final Collection<ThreadGroup> found = ThreadUtils.findThreadGroups(parent, true, predicate);
            assertTrue(found.contains(group));
        } finally {
            group.destroy();
        }
    }

    // --- public constructor (deprecated but present for JavaBean tools) ---

    @Test
    public void testPublicConstructor() {
        final ThreadUtils instance = new ThreadUtils();
        assertNotNull(instance);
    }
}
