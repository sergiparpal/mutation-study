/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link CSVFormat}.
 */
class CSVFormatAgentTest {

    @Test
    void testDefaultFormatDefaults() {
        assertEquals(",", CSVFormat.DEFAULT.getDelimiterString());
        assertEquals(Character.valueOf('"'), CSVFormat.DEFAULT.getQuoteCharacter());
        assertEquals("\r\n", CSVFormat.DEFAULT.getRecordSeparator());
        assertTrue(CSVFormat.DEFAULT.getIgnoreEmptyLines());
        assertFalse(CSVFormat.DEFAULT.getAllowMissingColumnNames());
        assertFalse(CSVFormat.DEFAULT.getSkipHeaderRecord());
        assertNull(CSVFormat.DEFAULT.getCommentMarker());
        assertNull(CSVFormat.DEFAULT.getEscapeCharacter());
        assertNull(CSVFormat.DEFAULT.getHeader());
    }

    @Test
    void testRFC4180DiffersFromDefaultOnlyByIgnoreEmptyLines() {
        assertFalse(CSVFormat.RFC4180.getIgnoreEmptyLines());
        assertEquals(CSVFormat.DEFAULT.getDelimiterString(), CSVFormat.RFC4180.getDelimiterString());
        assertNotEquals(CSVFormat.DEFAULT, CSVFormat.RFC4180);
    }

    @Test
    void testExcelFormat() {
        assertFalse(CSVFormat.EXCEL.getIgnoreEmptyLines());
        assertTrue(CSVFormat.EXCEL.getAllowMissingColumnNames());
        assertTrue(CSVFormat.EXCEL.getTrailingData());
        assertTrue(CSVFormat.EXCEL.getLenientEof());
    }

    @Test
    void testTdfFormat() {
        assertEquals("\t", CSVFormat.TDF.getDelimiterString());
        assertTrue(CSVFormat.TDF.getIgnoreSurroundingSpaces());
    }

    @Test
    void testMySqlFormat() {
        assertEquals("\t", CSVFormat.MYSQL.getDelimiterString());
        assertNull(CSVFormat.MYSQL.getQuoteCharacter());
        assertEquals("\\N", CSVFormat.MYSQL.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, CSVFormat.MYSQL.getQuoteMode());
    }

    @Test
    void testNewFormatWithChar() {
        final CSVFormat format = CSVFormat.newFormat(';');
        assertEquals(";", format.getDelimiterString());
        assertNull(format.getQuoteCharacter());
        assertNull(format.getRecordSeparator());
        assertFalse(format.getIgnoreEmptyLines());
    }

    @Test
    void testValueOf() {
        assertEquals(CSVFormat.EXCEL, CSVFormat.valueOf("Excel"));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.valueOf("NoSuchFormat");
            }
        });
    }

    @Test
    void testBuilderSetDelimiterChar() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter('|').get();
        assertEquals("|", format.getDelimiterString());
        assertEquals('|', format.getDelimiter());
    }

    @Test
    void testBuilderSetDelimiterStringMultiChar() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        assertEquals("::", format.getDelimiterString());
    }

    @Test
    void testBuilderSetDelimiterEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDelimiter("");
            }
        });
    }

    @Test
    void testBuilderSetDelimiterLineBreakThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDelimiter("a\nb");
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDelimiter("a\rb");
            }
        });
    }

    @Test
    void testBuilderSetCommentMarkerLineBreakThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setCommentMarker('\n');
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setCommentMarker('\r');
            }
        });
    }

    @Test
    void testBuilderSetEscapeLineBreakThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setEscape('\n');
            }
        });
    }

    @Test
    void testBuilderSetQuoteLineBreakThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setQuote('\r');
            }
        });
    }

    @Test
    void testValidateQuoteCharacterSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDelimiter(',').setQuote(',').get();
            }
        });
    }

    @Test
    void testValidateEscapeCharacterSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDelimiter(',').setEscape(',').get();
            }
        });
    }

    @Test
    void testValidateCommentMarkerSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDelimiter(',').setCommentMarker(',').get();
            }
        });
    }

    @Test
    void testValidateQuoteSameAsCommentMarkerThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setQuote('#').setCommentMarker('#').get();
            }
        });
    }

    @Test
    void testValidateEscapeSameAsCommentMarkerThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setEscape('#').setCommentMarker('#').get();
            }
        });
    }

    @Test
    void testValidateQuoteModeNoneWithoutEscapeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setEscape((Character) null).setQuoteMode(QuoteMode.NONE).get();
            }
        });
    }

    @Test
    void testValidateQuoteModeNoneWithEscapeOk() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').setQuoteMode(QuoteMode.NONE).get();
        assertEquals(QuoteMode.NONE, format.getQuoteMode());
    }

    @Test
    void testValidateDuplicateHeaderNamesDisallowedThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setHeader("a", "b", "a").setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).get();
            }
        });
    }

    @Test
    void testValidateDuplicateHeaderNamesAllowAllOk() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "b", "a").setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_ALL).get();
        assertArrayEquals(new String[] { "a", "b", "a" }, format.getHeader());
    }

    @Test
    void testValidateDuplicateEmptyHeaderNamesAllowEmptyOk() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "", "").setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).get();
        assertArrayEquals(new String[] { "a", "", "" }, format.getHeader());
    }

    @Test
    void testGetHeaderReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "b").get();
        final String[] header1 = format.getHeader();
        header1[0] = "mutated";
        final String[] header2 = format.getHeader();
        assertEquals("a", header2[0]);
        assertNotSame(header1, header2);
    }

    @Test
    void testGetHeaderCommentsReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeaderComments("c1", "c2").get();
        final String[] comments1 = format.getHeaderComments();
        comments1[0] = "mutated";
        final String[] comments2 = format.getHeaderComments();
        assertEquals("c1", comments2[0]);
    }

    @Test
    void testEqualsAndHashCode() {
        final CSVFormat format1 = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        final CSVFormat format2 = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        assertEquals(format1, format2);
        assertEquals(format1.hashCode(), format2.hashCode());
        assertNotEquals(format1, CSVFormat.DEFAULT);
    }

    @Test
    void testEqualsNullAndOtherType() {
        assertFalse(CSVFormat.DEFAULT.equals(null));
        assertFalse(CSVFormat.DEFAULT.equals("not a CSVFormat"));
        assertTrue(CSVFormat.DEFAULT.equals(CSVFormat.DEFAULT));
    }

    @Test
    void testBuilderPreservesExistingFormatSettings() {
        final CSVFormat original = CSVFormat.DEFAULT.builder().setDelimiter('|').setHeader("x", "y").setNullString("NULL").get();
        final CSVFormat copy = original.builder().get();
        assertEquals(original, copy);
        assertNotSame(original, copy);
    }

    @Test
    void testFormatValues() {
        final String formatted = CSVFormat.DEFAULT.format("a", "b,c", "d\"e");
        assertEquals("a,\"b,c\",\"d\"\"e\"", formatted);
    }

    @Test
    void testFormatEmptyValues() {
        assertEquals("", CSVFormat.DEFAULT.format());
    }

    @Test
    void testPrintRecordWritesDelimiterAndSeparator() throws IOException {
        final StringWriter out = new StringWriter();
        CSVFormat.DEFAULT.printRecord(out, "1", "2", "3");
        assertEquals("1,2,3\r\n", out.toString());
    }

    @Test
    void testPrintNullValueUsesEmptyStringByDefault() throws IOException {
        final StringWriter out = new StringWriter();
        CSVFormat.DEFAULT.print(null, out, true);
        assertEquals("", out.toString());
    }

    @Test
    void testPrintNullValueUsesConfiguredNullString() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        final StringWriter out = new StringWriter();
        format.print(null, out, true);
        assertEquals("NULL", out.toString());
    }

    @Test
    void testIsQuoteCharacterSet() {
        assertTrue(CSVFormat.DEFAULT.isQuoteCharacterSet());
        assertFalse(CSVFormat.MYSQL.isQuoteCharacterSet());
    }

    @Test
    void testIsEscapeCharacterSet() {
        assertFalse(CSVFormat.DEFAULT.isEscapeCharacterSet());
        assertTrue(CSVFormat.MYSQL.isEscapeCharacterSet());
    }

    @Test
    void testIsCommentMarkerSet() {
        assertFalse(CSVFormat.DEFAULT.isCommentMarkerSet());
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        assertTrue(format.isCommentMarkerSet());
    }

    @Test
    void testIsNullStringSet() {
        assertFalse(CSVFormat.DEFAULT.isNullStringSet());
        assertTrue(CSVFormat.MYSQL.isNullStringSet());
    }

    @Test
    void testToStringContainsDelimiter() {
        final String str = CSVFormat.DEFAULT.toString();
        assertTrue(str.contains("Delimiter=<,>"));
    }

    @Test
    void testToStringReflectsCommentAndNullSettings() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').setNullString("NULL").get();
        final String str = format.toString();
        assertTrue(str.contains("CommentStart=<#>"));
        assertTrue(str.contains("NullString=<NULL>"));
    }

    @Test
    void testGetMaxRowsDefaultIsZero() {
        assertEquals(0L, CSVFormat.DEFAULT.getMaxRows());
    }

    @Test
    void testSetMaxRows() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(5).get();
        assertEquals(5L, format.getMaxRows());
    }

    @Test
    void testParseReturnsNonNullParser() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "b").get();
        try (CSVParser parser = format.parse(new StringReader("1,2\r\n3,4\r\n"))) {
            assertNotNull(parser);
            final java.util.List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("1", records.get(0).get("a"));
            assertEquals("4", records.get(1).get("b"));
        }
    }

    @Test
    void testPrintReturnsNonNullPrinter() throws IOException {
        final StringWriter out = new StringWriter();
        try (CSVPrinter printer = CSVFormat.DEFAULT.print(out)) {
            assertNotNull(printer);
            printer.printRecord("x", "y");
        }
        assertEquals("x,y\r\n", out.toString());
    }

    @Test
    void testDeprecatedWithDelimiter() {
        final CSVFormat format = CSVFormat.DEFAULT.withDelimiter('|');
        assertEquals("|", format.getDelimiterString());
    }

    @Test
    void testDeprecatedWithHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("a", "b");
        assertArrayEquals(new String[] { "a", "b" }, format.getHeader());
    }

    @Test
    void testDeprecatedWithFirstRecordAsHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.withFirstRecordAsHeader();
        assertTrue(format.getSkipHeaderRecord());
        assertArrayEquals(new String[0], format.getHeader());
    }

    @Test
    void testDeprecatedGetAllowDuplicateHeaderNames() {
        assertTrue(CSVFormat.DEFAULT.getAllowDuplicateHeaderNames());
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).get();
        assertFalse(format.getAllowDuplicateHeaderNames());
    }

    @Test
    void testGetEscapeCharacterDefaultNull() {
        assertNull(CSVFormat.DEFAULT.getEscapeCharacter());
    }

    @Test
    void testGetTrailingDelimiterDefault() {
        assertFalse(CSVFormat.DEFAULT.getTrailingDelimiter());
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get();
        assertTrue(format.getTrailingDelimiter());
    }

    @Test
    void testGetTrimDefault() {
        assertFalse(CSVFormat.DEFAULT.getTrim());
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrim(true).get();
        assertTrue(format.getTrim());
    }

    @Test
    void testPredefinedEnumGetFormat() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.Predefined.Default.getFormat());
        assertEquals(CSVFormat.TDF, CSVFormat.Predefined.TDF.getFormat());
    }
}
