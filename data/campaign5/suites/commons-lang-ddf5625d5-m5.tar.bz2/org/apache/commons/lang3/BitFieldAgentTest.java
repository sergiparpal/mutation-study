/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link BitField}.
 */
class BitFieldAgentTest {

    private static final BitField BLUE = new BitField(0xFF);
    private static final BitField GREEN = new BitField(0xFF00);
    private static final BitField RED = new BitField(0xFF0000);
    private static final BitField ANY_COLOR = new BitField(0xFFFFFF);
    private static final BitField IS_METALLIC = new BitField(0x1000000);
    private static final BitField ZERO_MASK = new BitField(0);
    private static final BitField FULL_INT_MASK = new BitField(0xFFFFFFFF);
    private static final BitField TOP_BIT_MASK = new BitField(0x80000000);
    private static final BitField HIGH_LONG_MASK = new BitField(0x00FF000000000000L);

    @Test
    void testIntConstructorComputesShiftFromTrailingZeros() {
        assertEquals(35, RED.getValue(RED.setValue(0, 35)));
        assertEquals(100, GREEN.getValue(GREEN.setValue(0, 100)));
        assertEquals(255, BLUE.getValue(BLUE.setValue(0, 255)));
    }

    @Test
    void testZeroMaskShiftIsZero() {
        assertEquals(0, ZERO_MASK.getValue(0xFFFFFFFF));
        assertEquals(0, ZERO_MASK.getRawValue(0xFFFFFFFF));
    }

    @Test
    void testPaintInstructionExample() {
        int paintInstruction = 0;
        paintInstruction = RED.setValue(paintInstruction, 35);
        paintInstruction = GREEN.setValue(paintInstruction, 100);
        paintInstruction = BLUE.setValue(paintInstruction, 255);

        assertTrue(ANY_COLOR.isSet(paintInstruction));
        assertEquals(35, RED.getValue(paintInstruction));
        assertEquals(100, GREEN.getValue(paintInstruction));
        assertEquals(255, BLUE.getValue(paintInstruction));
        assertFalse(IS_METALLIC.isSet(paintInstruction));
    }

    @Test
    void testClearInt() {
        assertEquals(0x00FFFF, RED.clear(0xFFFFFF));
        assertEquals(0, BLUE.clear(0xFF));
        assertEquals(~0xFF, BLUE.clear(-1));
    }

    @Test
    void testClearLong() {
        final BitField bf = new BitField(0x00FF000000000000L);
        final long holder = 0xFFFFFFFFFFFFFFFFL;
        assertEquals(0xFF00FFFFFFFFFFFFL, bf.clear(holder));
    }

    @Test
    void testClearByte() {
        final BitField bf = new BitField(0x40);
        assertEquals((byte) -65, bf.clearByte((byte) -1));
        assertEquals((byte) 0, bf.clearByte((byte) 0x40));
    }

    @Test
    void testClearShort() {
        final BitField bf = new BitField(0x4000);
        assertEquals((short) -16385, bf.clearShort((short) -1));
        assertEquals((short) 0, bf.clearShort((short) 0x4000));
    }

    @Test
    void testGetRawValueInt() {
        assertEquals(0xFF0000, RED.getRawValue(0xFFFFFF));
        assertEquals(0, RED.getRawValue(0x00FFFF));
    }

    @Test
    void testGetRawValueLong() {
        final BitField bf = new BitField(0x00FF000000000000L);
        assertEquals(0x00AB000000000000L, bf.getRawValue(0x00ABCDEF01234567L));
    }

    @Test
    void testGetShortRawValue() {
        final BitField bf = new BitField(0x0FF0);
        assertEquals((short) 0x0BC0, bf.getShortRawValue((short) 0xABCD));
    }

    @Test
    void testGetShortValue() {
        final BitField bf = new BitField(0x0FF0);
        assertEquals((short) 0x0BC, bf.getShortValue((short) 0xABCD));
    }

    @Test
    void testGetValueIntShiftedRight() {
        assertEquals(0xFF, RED.getValue(0xFFFFFF));
        assertEquals(0, RED.getValue(0x00FFFF));
    }

    @Test
    void testGetValueLongShiftedRight() {
        assertEquals(0xABL, HIGH_LONG_MASK.getValue(0x00ABCDEF01234567L));
    }

    @Test
    void testIsAllSetZeroMaskAlwaysTrue() {
        assertTrue(ZERO_MASK.isAllSet(0));
        assertTrue(ZERO_MASK.isAllSet(-1));
        assertTrue(ZERO_MASK.isAllSet(0L));
    }

    @Test
    void testIsAllSetInt() {
        assertTrue(ANY_COLOR.isAllSet(0xFFFFFF));
        assertFalse(ANY_COLOR.isAllSet(0x00FFFF));
        assertFalse(ANY_COLOR.isAllSet(0));
    }

    @Test
    void testIsAllSetLong() {
        final BitField bf = new BitField(0x00FF000000000000L);
        assertTrue(bf.isAllSet(0xFFFFFFFFFFFFFFFFL));
        assertFalse(bf.isAllSet(0L));
    }

    @Test
    void testIsSetZeroMaskAlwaysFalse() {
        assertFalse(ZERO_MASK.isSet(0));
        assertFalse(ZERO_MASK.isSet(-1));
    }

    @Test
    void testIsSetInt() {
        assertTrue(RED.isSet(0x010000));
        assertFalse(RED.isSet(0x00FFFF));
    }

    @Test
    void testIsSetLong() {
        final BitField bf = new BitField(0x00FF000000000000L);
        assertTrue(bf.isSet(0x0001000000000000L));
        assertFalse(bf.isSet(0x0000FFFFFFFFFFFFL));
    }

    @Test
    void testSetInt() {
        assertEquals(0xFF0000, RED.set(0));
        assertEquals(-1, FULL_INT_MASK.set(0));
    }

    @Test
    void testSetLong() {
        final BitField bf = new BitField(0x00FF000000000000L);
        assertEquals(0x00FF000000000000L, bf.set(0L));
    }

    @Test
    void testSetBooleanInt() {
        assertEquals(0xFF0000, RED.setBoolean(0, true));
        assertEquals(0, RED.setBoolean(0xFF0000, false));
    }

    @Test
    void testSetBooleanLong() {
        final BitField bf = new BitField(0x00FF000000000000L);
        assertEquals(0x00FF000000000000L, bf.setBoolean(0L, true));
        assertEquals(0L, bf.setBoolean(0x00FF000000000000L, false));
    }

    @Test
    void testSetByte() {
        final BitField bf = new BitField(0x80);
        assertEquals((byte) -128, bf.setByte((byte) 0));
    }

    @Test
    void testSetByteBoolean() {
        final BitField bf = new BitField(0x40);
        assertEquals((byte) 0x40, bf.setByteBoolean((byte) 0, true));
        assertEquals((byte) 0, bf.setByteBoolean((byte) 0x40, false));
    }

    @Test
    void testSetShort() {
        final BitField bf = new BitField(0x4000);
        assertEquals((short) 0x4000, bf.setShort((short) 0));
    }

    @Test
    void testSetShortBoolean() {
        final BitField bf = new BitField(0x4000);
        assertEquals((short) 0x4000, bf.setShortBoolean((short) 0, true));
        assertEquals((short) 0, bf.setShortBoolean((short) 0x4000, false));
    }

    @Test
    void testSetShortValue() {
        final BitField bf = new BitField(0x0FF0);
        final short result = bf.setShortValue((short) 0, (short) 0xAB);
        assertEquals((short) 0x0AB0, result);
        assertEquals((short) 0xAB, bf.getShortValue(result));
    }

    @Test
    void testSetValueIntTruncatesOverflow() {
        assertEquals(0xFF0000, RED.setValue(0, 0x1FF));
        assertEquals(0, RED.setValue(0xFF0000, 0x100));
    }

    @Test
    void testSetValueLong() {
        final BitField bf = new BitField(0x00FF000000000000L);
        final long result = bf.setValue(0L, 0x1ABL);
        assertEquals(0x00AB000000000000L, result);
        assertEquals(0xABL, bf.getValue(result));
    }

    @Test
    void testTopBitMaskUsesUnsignedConversion() {
        assertTrue(TOP_BIT_MASK.isSet(0x80000000));
        assertFalse(TOP_BIT_MASK.isSet(0x7FFFFFFF));
        // Sign bit from the int cast in getRawValue flows into the arithmetic right shift.
        assertEquals(-1, TOP_BIT_MASK.getValue(0x80000000));
        assertEquals(0x80000000, TOP_BIT_MASK.setValue(0, 1));
    }

    @Test
    void testHighLongMaskRoundTrip() {
        long holder = 0L;
        holder = HIGH_LONG_MASK.setValue(holder, 0x7F);
        assertEquals(0x7FL, HIGH_LONG_MASK.getValue(holder));
        assertTrue(HIGH_LONG_MASK.isSet(holder));
        holder = HIGH_LONG_MASK.clear(holder);
        assertEquals(0L, holder);
        assertFalse(HIGH_LONG_MASK.isSet(holder));
    }
}
