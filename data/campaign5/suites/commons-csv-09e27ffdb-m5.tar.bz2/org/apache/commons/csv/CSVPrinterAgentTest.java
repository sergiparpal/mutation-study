/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link CSVPrinter}.
 */
class CSVPrinterAgentTest {

    /** Writer that tracks whether flush/close were invoked, to observe CSVPrinter#close(boolean). */
    private static final class TrackingWriter extends StringWriter {
        private boolean flushed;
        private boolean closed;

        @Override
        public void flush() {
            flushed = true;
            super.flush();
        }

        @Override
        public void close() throws IOException {
            closed = true;
            super.close();
        }
    }

    /** Appendable that always fails, to exercise the IOException propagation path. */
    private static final class ThrowingAppendable implements Appendable {
        @Override
        public Appendable append(final CharSequence csq) throws IOException {
            throw new IOException("boom");
        }

        @Override
        public Appendable append(final CharSequence csq, final int start, final int end) throws IOException {
            throw new IOException("boom");
        }

        @Override
        public Appendable append(final char c) throws IOException {
            throw new IOException("boom");
        }
    }

    @Test
    void testPrintSimpleValue() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("a");
        assertEquals("a", sw.toString());
    }

    @Test
    void testPrintSecondValueAddsDelimiter() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("a");
        printer.print("b");
        assertEquals("a,b", sw.toString());
    }

    @Test
    void testPrintValueRequiringQuoting() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("a,b");
        assertEquals("\"a,b\"", sw.toString());
    }

    @Test
    void testPrintNullValueIsEmpty() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print(null);
        printer.print("x");
        assertEquals(",x", sw.toString());
    }

    @Test
    void testPrintThrowsIOExceptionFromAppendable() {
        assertThrows(IOException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                final CSVPrinter printer = new CSVPrinter(new ThrowingAppendable(), CSVFormat.DEFAULT);
                printer.print("x");
            }
        });
    }

    @Test
    void testPrintRecordObjectArray() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecord("a", "b", "c");
        assertEquals("a,b,c\r\n", sw.toString());
        assertEquals(1, printer.getRecordCount());
    }

    @Test
    void testPrintRecordEmptyArrayStillEndsRecord() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecord();
        assertEquals("\r\n", sw.toString());
        assertEquals(1, printer.getRecordCount());
    }

    @Test
    void testPrintRecordIterable() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final List<String> values = new ArrayList<String>();
        values.add("1");
        values.add("2");
        printer.printRecord(values);
        assertEquals("1,2\r\n", sw.toString());
        assertEquals(1, printer.getRecordCount());
    }

    @Test
    void testPrintRecordStream() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecord(Stream.of("x", "y", "z"));
        assertEquals("x,y,z\r\n", sw.toString());
        assertEquals(1, printer.getRecordCount());
    }

    @Test
    void testPrintRecordsIterableOfArraysNested() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final List<String[]> data = new ArrayList<String[]>();
        data.add(new String[] { "A", "B" });
        data.add(new String[] { "1", "2" });
        printer.printRecords(data);
        assertEquals("A,B\r\n1,2\r\n", sw.toString());
        assertEquals(2, printer.getRecordCount());
    }

    @Test
    void testPrintRecordsIterableOfSimpleValuesPrintsOneRecordPerValue() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final List<String> data = new ArrayList<String>();
        data.add("A");
        data.add("B");
        printer.printRecords(data);
        assertEquals("A\r\nB\r\n", sw.toString());
        assertEquals(2, printer.getRecordCount());
    }

    @Test
    void testPrintRecordsObjectArrayNested() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecords((Object) new String[] { "A", "B" }, (Object) new String[] { "1", "2" });
        assertEquals("A,B\r\n1,2\r\n", sw.toString());
        assertEquals(2, printer.getRecordCount());
    }

    @Test
    void testPrintRecordsStream() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecords(Stream.of(new String[] { "A", "B" }, new String[] { "1", "2" }));
        assertEquals("A,B\r\n1,2\r\n", sw.toString());
        assertEquals(2, printer.getRecordCount());
    }

    @Test
    void testPrintlnDoesNotIncrementRecordCount() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("a");
        printer.println();
        assertEquals("a\r\n", sw.toString());
        assertEquals(0, printer.getRecordCount());
    }

    @Test
    void testGetRecordCountStartsAtZero() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        assertEquals(0, printer.getRecordCount());
    }

    @Test
    void testGetOutReturnsConstructorArgument() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        assertTrue(sw == printer.getOut());
    }

    @Test
    void testPrintCommentDoesNothingWhenMarkerNotSet() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printComment("a comment");
        assertEquals("", sw.toString());
        assertEquals(0, printer.getRecordCount());
    }

    @Test
    void testPrintCommentNullIsIgnored() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printComment(null);
        assertEquals("", sw.toString());
    }

    @Test
    void testPrintCommentSingleLine() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printComment("hello");
        assertEquals("# hello\r\n", sw.toString());
    }

    @Test
    void testPrintCommentMultiLine() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printComment("line1\nline2");
        assertEquals("# line1\r\n# line2\r\n", sw.toString());
    }

    @Test
    void testPrintCommentFollowedByRecordStartsOnNewLine() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        printer.print("a");
        printer.printComment("hi");
        assertEquals("a\r\n# hi\r\n", sw.toString());
    }

    @Test
    void testConstructorRejectsNullAppendable() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new CSVPrinter(null, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    void testConstructorRejectsNullFormat() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new CSVPrinter(new StringWriter(), null);
            }
        });
    }

    @Test
    void testConstructorPrintsHeaderAutomatically() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("col1", "col2").get();
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        assertEquals("col1,col2\r\n", sw.toString());
        assertEquals(1, printer.getRecordCount());
    }

    @Test
    void testConstructorSkipsHeaderWhenRequested() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("col1", "col2").setSkipHeaderRecord(true).get();
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        assertEquals("", sw.toString());
        assertEquals(0, printer.getRecordCount());
    }

    @Test
    void testConstructorPrintsHeaderComments() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').setHeaderComments("generated").get();
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        assertEquals("# generated\r\n", sw.toString());
    }

    @Test
    void testFlushDelegatesToFlushableAppendable() throws IOException {
        final TrackingWriter writer = new TrackingWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        assertFalse(writer.flushed);
        printer.flush();
        assertTrue(writer.flushed);
    }

    @Test
    void testCloseWithoutFlushDoesNotFlushByDefault() throws IOException {
        final TrackingWriter writer = new TrackingWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        printer.close();
        assertFalse(writer.flushed);
        assertTrue(writer.closed);
    }

    @Test
    void testCloseWithExplicitFlushFlag() throws IOException {
        final TrackingWriter writer = new TrackingWriter();
        final CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        printer.close(true);
        assertTrue(writer.flushed);
        assertTrue(writer.closed);
    }

    @Test
    void testCloseFlushesWhenAutoFlushEnabled() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setAutoFlush(true).get();
        final TrackingWriter writer = new TrackingWriter();
        final CSVPrinter printer = new CSVPrinter(writer, format);
        printer.close();
        assertTrue(writer.flushed);
    }

    @Test
    void testCloseOnNonCloseableAppendableDoesNotThrow() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("x");
        printer.close();
        assertEquals("x", sb.toString());
    }

    @Test
    void testPrintHeadersFromResultSet() throws Exception {
        final ResultSetMetaData metaData = mock(ResultSetMetaData.class);
        when(metaData.getColumnCount()).thenReturn(2);
        when(metaData.getColumnLabel(1)).thenReturn("id");
        when(metaData.getColumnLabel(2)).thenReturn("name");
        final ResultSet resultSet = mock(ResultSet.class);
        when(resultSet.getMetaData()).thenReturn(metaData);

        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printHeaders(resultSet);
        assertEquals("id,name\r\n", sw.toString());
    }

    @Test
    void testPrintRecordsFromResultSet() throws Exception {
        final ResultSetMetaData metaData = mock(ResultSetMetaData.class);
        when(metaData.getColumnCount()).thenReturn(2);
        final ResultSet resultSet = mock(ResultSet.class);
        when(resultSet.getMetaData()).thenReturn(metaData);
        when(resultSet.next()).thenReturn(true, true, false);
        when(resultSet.getObject(1)).thenReturn("a1", "a2");
        when(resultSet.getObject(2)).thenReturn("b1", "b2");

        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecords(resultSet);
        assertEquals("a1,b1\r\na2,b2\r\n", sw.toString());
        assertEquals(2, printer.getRecordCount());
    }

    @Test
    void testPrintRecordsFromResultSetWithHeaderFlag() throws Exception {
        final ResultSetMetaData metaData = mock(ResultSetMetaData.class);
        when(metaData.getColumnCount()).thenReturn(1);
        when(metaData.getColumnLabel(1)).thenReturn("col");
        final ResultSet resultSet = mock(ResultSet.class);
        when(resultSet.getMetaData()).thenReturn(metaData);
        when(resultSet.next()).thenReturn(true, false);
        when(resultSet.getObject(1)).thenReturn("v1");

        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecords(resultSet, true);
        assertEquals("col\r\nv1\r\n", sw.toString());
        assertEquals(1, printer.getRecordCount());
    }

    @Test
    void testPrintRecordsFromResultSetRespectsMaxRows() throws Exception {
        final ResultSetMetaData metaData = mock(ResultSetMetaData.class);
        when(metaData.getColumnCount()).thenReturn(1);
        final ResultSet resultSet = mock(ResultSet.class);
        when(resultSet.getMetaData()).thenReturn(metaData);
        when(resultSet.next()).thenReturn(true, true, true, false);
        when(resultSet.getObject(1)).thenReturn("a", "b", "c");

        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(1).get();
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printRecords(resultSet);
        assertEquals("a\r\n", sw.toString());
        assertEquals(1, printer.getRecordCount());
    }

    @Test
    void testPrintRecordsFromEmptyResultSet() throws Exception {
        final ResultSetMetaData metaData = mock(ResultSetMetaData.class);
        when(metaData.getColumnCount()).thenReturn(1);
        final ResultSet resultSet = mock(ResultSet.class);
        when(resultSet.getMetaData()).thenReturn(metaData);
        when(resultSet.next()).thenReturn(false);

        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecords(resultSet);
        assertEquals("", sw.toString());
        assertEquals(0, printer.getRecordCount());
    }

    @Test
    void testPrintRecordsContinuesAfterComment() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printComment("note");
        printer.printRecord("a", "b");
        assertEquals("# note\r\na,b\r\n", sw.toString());
        assertEquals(1, printer.getRecordCount());
    }

    @Test
    void testPrintRecordObjectVarargsOverload() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final Object[] values = { 1, 2.5, "three" };
        printer.printRecord(values);
        assertEquals("1,2.5,three\r\n", sw.toString());
    }

    @Test
    void testCustomDelimiterAndRecordSeparator() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter(';').setRecordSeparator("\n").get();
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printRecord("a", "b");
        assertEquals("a;b\n", sw.toString());
    }

}
