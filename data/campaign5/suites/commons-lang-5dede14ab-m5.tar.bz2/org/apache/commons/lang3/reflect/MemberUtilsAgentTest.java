/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import org.junit.jupiter.api.Test;

/**
 * Tests MemberUtils.
 */
class MemberUtilsAgentTest {

    public static class PublicSample {

        public PublicSample() {
        }

        public PublicSample(final Object o) {
        }

        public PublicSample(final String s) {
        }

        public PublicSample(final String s, final int... nums) {
        }

        private void privateMethod() {
        }

        public void publicMethod() {
        }

        public static void staticOver(final int i) {
        }

        public static void staticOver(final long l) {
        }

        public static void staticOver(final Object o) {
        }

        public static void staticOver(final String s) {
        }

        public static void staticVarArgs(final String s, final int... nums) {
        }

        public static void staticMethod() {
        }
    }

    static class PackagePrivateSample {

        public void publicMethod() {
        }
    }

    @Test
    void testIsPublic() throws Exception {
        final Method publicMethod = PublicSample.class.getMethod("publicMethod");
        final Method privateMethod = PublicSample.class.getDeclaredMethod("privateMethod");
        assertTrue(MemberUtils.isPublic(publicMethod));
        assertFalse(MemberUtils.isPublic(privateMethod));
        assertFalse(MemberUtils.isPublic(null));
    }

    @Test
    void testIsStatic() throws Exception {
        final Method staticMethod = PublicSample.class.getMethod("staticMethod");
        final Method publicMethod = PublicSample.class.getMethod("publicMethod");
        assertTrue(MemberUtils.isStatic(staticMethod));
        assertFalse(MemberUtils.isStatic(publicMethod));
        assertFalse(MemberUtils.isStatic(null));
    }

    @Test
    void testIsPackage() {
        assertFalse(MemberUtils.isPackage(Modifier.PUBLIC));
        assertFalse(MemberUtils.isPackage(Modifier.PROTECTED));
        assertFalse(MemberUtils.isPackage(Modifier.PRIVATE));
        assertTrue(MemberUtils.isPackage(0));
        // STATIC bit is not part of the access mask, so it still counts as package access.
        assertTrue(MemberUtils.isPackage(Modifier.STATIC));
    }

    @Test
    void testIsAccessible() throws Exception {
        final Method publicMethod = PublicSample.class.getMethod("publicMethod");
        final Method privateMethod = PublicSample.class.getDeclaredMethod("privateMethod");
        assertTrue(MemberUtils.isAccessible(publicMethod));
        assertFalse(MemberUtils.isAccessible(privateMethod));
        // Must short-circuit on the null check and not throw.
        assertFalse(MemberUtils.isAccessible(null));
    }

    @Test
    void testIsMatchingMethodExactAndAssignable() throws Exception {
        final Method stringOver = PublicSample.class.getMethod("staticOver", String.class);
        assertTrue(MemberUtils.isMatchingMethod(stringOver, new Class<?>[] { String.class }));
        // CharSequence is assignable to String's position? No: actual must be assignable TO declared param.
        assertFalse(MemberUtils.isMatchingMethod(stringOver, new Class<?>[] { Object.class }));
        assertFalse(MemberUtils.isMatchingMethod(stringOver, new Class<?>[0]));
        assertFalse(MemberUtils.isMatchingMethod(stringOver, new Class<?>[] { String.class, String.class }));
    }

    @Test
    void testIsMatchingMethodVarArgsNoneProvided() throws Exception {
        final Method varArgs = PublicSample.class.getMethod("staticVarArgs", String.class, int[].class);
        assertTrue(MemberUtils.isMatchingMethod(varArgs, new Class<?>[] { String.class }));
    }

    @Test
    void testIsMatchingMethodVarArgsSomeProvided() throws Exception {
        final Method varArgs = PublicSample.class.getMethod("staticVarArgs", String.class, int[].class);
        assertTrue(MemberUtils.isMatchingMethod(varArgs, new Class<?>[] { String.class, Integer.class }));
        assertTrue(MemberUtils.isMatchingMethod(varArgs, new Class<?>[] { String.class, Integer.class, Integer.class }));
    }

    @Test
    void testIsMatchingMethodVarArgsExplicitArray() throws Exception {
        final Method varArgs = PublicSample.class.getMethod("staticVarArgs", String.class, int[].class);
        assertTrue(MemberUtils.isMatchingMethod(varArgs, new Class<?>[] { String.class, int[].class }));
    }

    @Test
    void testIsMatchingMethodVarArgsFirstParamMismatch() throws Exception {
        final Method varArgs = PublicSample.class.getMethod("staticVarArgs", String.class, int[].class);
        assertFalse(MemberUtils.isMatchingMethod(varArgs, new Class<?>[] { Integer.class, Integer.class }));
    }

    @Test
    void testIsMatchingConstructor() throws Exception {
        final Constructor<?> stringCtor = PublicSample.class.getConstructor(String.class);
        final Constructor<?> noArgCtor = PublicSample.class.getConstructor();
        final Constructor<?> varArgsCtor = PublicSample.class.getConstructor(String.class, int[].class);
        assertTrue(MemberUtils.isMatchingConstructor(stringCtor, new Class<?>[] { String.class }));
        assertFalse(MemberUtils.isMatchingConstructor(stringCtor, new Class<?>[] { Object.class }));
        assertTrue(MemberUtils.isMatchingConstructor(noArgCtor, new Class<?>[0]));
        assertFalse(MemberUtils.isMatchingConstructor(noArgCtor, new Class<?>[] { String.class }));
        assertTrue(MemberUtils.isMatchingConstructor(varArgsCtor, new Class<?>[] { String.class }));
        assertTrue(MemberUtils.isMatchingConstructor(varArgsCtor, new Class<?>[] { String.class, Integer.class, Integer.class }));
        assertTrue(MemberUtils.isMatchingConstructor(varArgsCtor, new Class<?>[] { String.class, int[].class }));
    }

    @Test
    void testCompareMethodFitPrefersExactTypeMatch() throws Exception {
        final Method stringOver = PublicSample.class.getMethod("staticOver", String.class);
        final Method objectOver = PublicSample.class.getMethod("staticOver", Object.class);
        final Class<?>[] actual = { String.class };
        assertTrue(MemberUtils.compareMethodFit(stringOver, objectOver, actual) < 0);
        assertTrue(MemberUtils.compareMethodFit(objectOver, stringOver, actual) > 0);
        assertEquals(0, MemberUtils.compareMethodFit(stringOver, stringOver, actual));
    }

    @Test
    void testCompareMethodFitPrefersNarrowerPrimitive() throws Exception {
        final Method intOver = PublicSample.class.getMethod("staticOver", int.class);
        final Method longOver = PublicSample.class.getMethod("staticOver", long.class);
        final Class<?>[] actual = { int.class };
        assertTrue(MemberUtils.compareMethodFit(intOver, longOver, actual) < 0);
        assertTrue(MemberUtils.compareMethodFit(longOver, intOver, actual) > 0);
    }

    @Test
    void testCompareConstructorFitPrefersExactTypeMatch() throws Exception {
        final Constructor<?> stringCtor = PublicSample.class.getConstructor(String.class);
        final Constructor<?> objectCtor = PublicSample.class.getConstructor(Object.class);
        final Class<?>[] actual = { String.class };
        assertTrue(MemberUtils.compareConstructorFit(stringCtor, objectCtor, actual) < 0);
        assertTrue(MemberUtils.compareConstructorFit(objectCtor, stringCtor, actual) > 0);
        assertEquals(0, MemberUtils.compareConstructorFit(stringCtor, stringCtor, actual));
    }

    @Test
    void testSetAccessibleWorkaroundAppliesToPackagePrivateDeclaringClass() throws Exception {
        final Method method = PackagePrivateSample.class.getMethod("publicMethod");
        assertFalse(method.isAccessible());
        final Method result = MemberUtils.setAccessibleWorkaround(method);
        assertSame(method, result);
        assertTrue(result.isAccessible());
    }

    @Test
    void testSetAccessibleWorkaroundLeavesPublicDeclaringClassUntouched() throws Exception {
        final Method method = PublicSample.class.getMethod("publicMethod");
        assertFalse(method.isAccessible());
        final Method result = MemberUtils.setAccessibleWorkaround(method);
        assertSame(method, result);
        assertFalse(result.isAccessible());
    }

    @Test
    void testSetAccessibleWorkaroundNoOpWhenAlreadyAccessible() throws Exception {
        final Method method = PublicSample.class.getMethod("publicMethod");
        method.setAccessible(true);
        final Method result = MemberUtils.setAccessibleWorkaround(method);
        assertSame(method, result);
        assertTrue(result.isAccessible());
    }
}
