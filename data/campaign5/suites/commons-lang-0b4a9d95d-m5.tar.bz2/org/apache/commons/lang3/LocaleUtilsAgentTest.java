/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import java.util.Locale;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained test class for {@link LocaleUtils}.
 */
class LocaleUtilsAgentTest {

    @Test
    void testAvailableLocaleList() {
        final List<Locale> list = LocaleUtils.availableLocaleList();
        assertNotNull(list);
        assertFalse(list.isEmpty());
        assertTrue(list.contains(Locale.US));
        // Calling again must return the same cached instance.
        assertSame(list, LocaleUtils.availableLocaleList());
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                list.add(Locale.CANADA);
            }
        });
    }

    @Test
    void testAvailableLocaleSet() {
        final Set<Locale> set = LocaleUtils.availableLocaleSet();
        assertNotNull(set);
        assertFalse(set.isEmpty());
        assertTrue(set.contains(Locale.US));
        assertEquals(LocaleUtils.availableLocaleList().size(), set.size());
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                set.add(Locale.CANADA);
            }
        });
    }

    @Test
    void testCountriesByLanguageNull() {
        final List<Locale> list = LocaleUtils.countriesByLanguage(null);
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    void testCountriesByLanguageKnown() {
        final List<Locale> list = LocaleUtils.countriesByLanguage("en");
        assertNotNull(list);
        assertFalse(list.isEmpty());
        for (final Locale locale : list) {
            assertEquals("en", locale.getLanguage());
            assertFalse(locale.getCountry().isEmpty());
            assertTrue(locale.getVariant().isEmpty());
        }
        // Result must be cached: same instance on a second call.
        assertSame(list, LocaleUtils.countriesByLanguage("en"));
    }

    @Test
    void testCountriesByLanguageUnknown() {
        final List<Locale> list = LocaleUtils.countriesByLanguage("zz");
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    void testLanguagesByCountryNull() {
        final List<Locale> list = LocaleUtils.languagesByCountry(null);
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    void testLanguagesByCountryKnown() {
        final List<Locale> list = LocaleUtils.languagesByCountry("GB");
        assertNotNull(list);
        assertFalse(list.isEmpty());
        for (final Locale locale : list) {
            assertEquals("GB", locale.getCountry());
            assertTrue(locale.getVariant().isEmpty());
        }
    }

    @Test
    void testIsAvailableLocale() {
        assertTrue(LocaleUtils.isAvailableLocale(Locale.US));
        assertFalse(LocaleUtils.isAvailableLocale(null));
        assertFalse(LocaleUtils.isAvailableLocale(new Locale("xx", "", "nonexistent-variant-zzz")));
    }

    @Test
    void testIsLanguageUndetermined() {
        assertTrue(LocaleUtils.isLanguageUndetermined(null));
        assertTrue(LocaleUtils.isLanguageUndetermined(new Locale("")));
        assertFalse(LocaleUtils.isLanguageUndetermined(Locale.US));
        assertFalse(LocaleUtils.isLanguageUndetermined(new Locale("en")));
    }

    @Test
    void testLocaleLookupListNull() {
        final List<Locale> list = LocaleUtils.localeLookupList(null);
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    void testLocaleLookupListSingleArg() {
        final Locale locale = new Locale("fr", "CA", "xxx");
        final List<Locale> list = LocaleUtils.localeLookupList(locale);
        assertEquals(3, list.size());
        assertEquals(new Locale("fr", "CA", "xxx"), list.get(0));
        assertEquals(new Locale("fr", "CA"), list.get(1));
        assertEquals(new Locale("fr"), list.get(2));
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                list.add(Locale.US);
            }
        });
    }

    @Test
    void testLocaleLookupListTwoArgWithDefault() {
        final Locale locale = new Locale("fr", "CA", "xxx");
        final Locale defaultLocale = new Locale("en");
        final List<Locale> list = LocaleUtils.localeLookupList(locale, defaultLocale);
        assertEquals(4, list.size());
        assertEquals(new Locale("fr", "CA", "xxx"), list.get(0));
        assertEquals(new Locale("fr", "CA"), list.get(1));
        assertEquals(new Locale("fr"), list.get(2));
        assertEquals(new Locale("en"), list.get(3));
    }

    @Test
    void testLocaleLookupListDefaultAlreadyPresent() {
        final Locale locale = new Locale("en", "GB");
        final List<Locale> list = LocaleUtils.localeLookupList(locale, new Locale("en"));
        // en_GB, en, en (default already present, no duplicate)
        assertEquals(2, list.size());
        assertEquals(new Locale("en", "GB"), list.get(0));
        assertEquals(new Locale("en"), list.get(1));
    }

    @Test
    void testToLocaleLocaleOverload() {
        assertEquals(Locale.getDefault(), LocaleUtils.toLocale((Locale) null));
        assertSame(Locale.US, LocaleUtils.toLocale(Locale.US));
    }

    @Test
    void testToLocaleStringNull() {
        assertNull(LocaleUtils.toLocale((String) null));
    }

    @Test
    void testToLocaleStringEmpty() {
        assertEquals(new Locale("", ""), LocaleUtils.toLocale(""));
    }

    @Test
    void testToLocaleStringLanguageOnly() {
        assertEquals(new Locale("en"), LocaleUtils.toLocale("en"));
        assertEquals(new Locale("eng"), LocaleUtils.toLocale("eng"));
    }

    @Test
    void testToLocaleStringLanguageAndCountryUnderscore() {
        assertEquals(new Locale("en", "GB"), LocaleUtils.toLocale("en_GB"));
    }

    @Test
    void testToLocaleStringLanguageAndCountryDash() {
        assertEquals(new Locale("en", "GB"), LocaleUtils.toLocale("en-GB"));
    }

    @Test
    void testToLocaleStringNumericArea() {
        assertEquals(new Locale("en", "001"), LocaleUtils.toLocale("en_001"));
    }

    @Test
    void testToLocaleStringWithVariant() {
        assertEquals(new Locale("en", "GB", "xxx"), LocaleUtils.toLocale("en_GB_xxx"));
    }

    @Test
    void testToLocaleStringCountryOnly() {
        assertEquals(new Locale("", "US"), LocaleUtils.toLocale("US"));
    }

    @Test
    void testToLocaleStringLeadingUnderscoreCountryOnly() {
        assertEquals(new Locale("", "GB"), LocaleUtils.toLocale("_GB"));
    }

    @Test
    void testToLocaleStringLeadingUnderscoreWithVariant() {
        assertEquals(new Locale("", "GB", "xxx"), LocaleUtils.toLocale("_GB_xxx"));
    }

    @Test
    void testToLocaleStringSpecialCaseThai() {
        assertEquals(new Locale("th", "TH", "TH"), LocaleUtils.toLocale("th_TH_TH_#u-nu-thai"));
    }

    @Test
    void testToLocaleStringSpecialCaseJapanese() {
        assertEquals(new Locale("ja", "JP", "JP"), LocaleUtils.toLocale("ja_JP_JP_#u-ca-japanese"));
    }

    @Test
    void testToLocaleStringTooShort() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                LocaleUtils.toLocale("e");
            }
        });
    }

    @Test
    void testToLocaleStringLeadingUnderscoreTooShort() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                LocaleUtils.toLocale("_G");
            }
        });
    }

    @Test
    void testToLocaleStringLeadingUnderscoreLowerCase() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                LocaleUtils.toLocale("_gb");
            }
        });
    }

    @Test
    void testToLocaleStringLeadingUnderscoreMissingSeparator() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                // length 4, less than 5: must fail length check before separator check.
                LocaleUtils.toLocale("_GBx");
            }
        });
    }

    @Test
    void testToLocaleStringLeadingUnderscoreBadSeparator() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                // charAt(3) must equal the leading separator char.
                LocaleUtils.toLocale("_GBxxx");
            }
        });
    }

    @Test
    void testToLocaleStringUppercaseLanguageInvalid() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                LocaleUtils.toLocale("ENGLISH");
            }
        });
    }

    @Test
    void testToLocaleStringLowercaseCountryInvalid() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                LocaleUtils.toLocale("en_gb");
            }
        });
    }

    @Test
    void testToLocaleStringEmptyVariantInvalid() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                LocaleUtils.toLocale("en_GB_");
            }
        });
    }

    @Test
    void testConstructorIsPublic() throws Exception {
        // Deprecated but public, kept for JavaBean-style tools.
        assertNotNull(new LocaleUtils());
    }
}
