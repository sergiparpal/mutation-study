/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.Iterator;
import java.util.List;

import org.junit.jupiter.api.Test;

class CSVFormatAgentTest {

    private enum Header {
        NAME, EMAIL, PHONE
    }

    // --- Predefined formats ---

    @Test
    void testDefaultFormatSettings() {
        assertEquals(",", CSVFormat.DEFAULT.getDelimiterString());
        assertEquals(Character.valueOf('"'), CSVFormat.DEFAULT.getQuoteCharacter());
        assertEquals("\r\n", CSVFormat.DEFAULT.getRecordSeparator());
        assertTrue(CSVFormat.DEFAULT.getIgnoreEmptyLines());
        assertFalse(CSVFormat.DEFAULT.isEscapeCharacterSet());
        assertNull(CSVFormat.DEFAULT.getHeader());
    }

    @Test
    void testRfc4180DoesNotIgnoreEmptyLines() {
        assertFalse(CSVFormat.RFC4180.getIgnoreEmptyLines());
    }

    @Test
    void testExcelFormatSettings() {
        assertFalse(CSVFormat.EXCEL.getIgnoreEmptyLines());
        assertTrue(CSVFormat.EXCEL.getAllowMissingColumnNames());
        assertTrue(CSVFormat.EXCEL.getTrailingData());
        assertTrue(CSVFormat.EXCEL.getLenientEof());
    }

    @Test
    void testTdfUsesTabAndIgnoresSurroundingSpaces() {
        assertEquals("\t", CSVFormat.TDF.getDelimiterString());
        assertTrue(CSVFormat.TDF.getIgnoreSurroundingSpaces());
    }

    @Test
    void testMySqlUsesNullQuoteAndBackslashEscape() {
        assertNull(CSVFormat.MYSQL.getQuoteCharacter());
        assertEquals(Character.valueOf('\\'), CSVFormat.MYSQL.getEscapeCharacter());
        assertEquals("\\N", CSVFormat.MYSQL.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, CSVFormat.MYSQL.getQuoteMode());
    }

    @Test
    void testValueOfReturnsPredefinedFormat() {
        assertSame(CSVFormat.EXCEL, CSVFormat.valueOf("Excel"));
        assertSame(CSVFormat.DEFAULT, CSVFormat.valueOf("Default"));
    }

    @Test
    void testValueOfUnknownNameThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.valueOf("NoSuchFormat"));
    }

    @Test
    void testPredefinedEnumGetFormat() {
        assertSame(CSVFormat.TDF, CSVFormat.Predefined.TDF.getFormat());
    }

    // --- newFormat / builder basics ---

    @Test
    void testNewFormatOnlySetsDelimiter() {
        final CSVFormat format = CSVFormat.newFormat(';');
        assertEquals(";", format.getDelimiterString());
        assertNull(format.getQuoteCharacter());
        assertNull(format.getCommentMarker());
        assertNull(format.getRecordSeparator());
        assertFalse(format.getIgnoreEmptyLines());
        assertNull(format.getHeader());
    }

    @Test
    void testBuilderCreateCopiesExistingFormat() {
        final CSVFormat original = CSVFormat.DEFAULT.builder().setDelimiter(';').setNullString("NULL").get();
        final CSVFormat copy = original.builder().get();
        assertEquals(original, copy);
        assertEquals(";", copy.getDelimiterString());
        assertEquals("NULL", copy.getNullString());
    }

    @Test
    void testGetHeaderReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "b").get();
        final String[] header1 = format.getHeader();
        header1[0] = "mutated";
        final String[] header2 = format.getHeader();
        assertEquals("a", header2[0]);
    }

    @Test
    void testSetHeaderFromEnum() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(Header.class).get();
        assertArrayEquals(new String[] {"NAME", "EMAIL", "PHONE"}, format.getHeader());
    }

    @Test
    void testSetHeaderNullEnumDisablesHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader((Class<? extends Enum<?>>) null).get();
        assertNull(format.getHeader());
    }

    @Test
    void testSetHeaderCommentsKeepsCopy() {
        final String[] comments = {"line1", "line2"};
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeaderComments(comments).get();
        comments[0] = "mutated";
        assertEquals("line1", format.getHeaderComments()[0]);
    }

    // --- Validation / boundary error cases ---

    @Test
    void testDelimiterCannotBeEmptyString() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setDelimiter("").get());
    }

    @Test
    void testDelimiterCannotBeLineBreak() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setDelimiter('\n').get());
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setDelimiter("a\rb").get());
    }

    @Test
    void testCommentMarkerCannotBeLineBreak() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setCommentMarker('\r').get());
    }

    @Test
    void testEscapeCannotBeLineBreak() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setEscape('\n').get());
    }

    @Test
    void testQuoteCannotBeLineBreak() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setQuote('\n').get());
    }

    @Test
    void testQuoteCharacterSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setDelimiter(',').setQuote(',').get());
    }

    @Test
    void testEscapeCharacterSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setDelimiter(',').setEscape(',').get());
    }

    @Test
    void testCommentMarkerSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setDelimiter(',').setCommentMarker(',').get());
    }

    @Test
    void testQuoteCharacterSameAsCommentMarkerThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setQuote('#').setCommentMarker('#').get());
    }

    @Test
    void testEscapeCharacterSameAsCommentMarkerThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setEscape('#').setCommentMarker('#').get());
    }

    @Test
    void testQuoteModeNoneWithoutEscapeThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setQuote(null).setQuoteMode(QuoteMode.NONE).get());
    }

    @Test
    void testQuoteModeNoneWithEscapeSucceeds() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuote(null).setEscape('\\').setQuoteMode(QuoteMode.NONE).get();
        assertEquals(QuoteMode.NONE, format.getQuoteMode());
    }

    @Test
    void testDuplicateHeaderDisallowedThrows() {
        assertThrows(IllegalArgumentException.class,
                () -> CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).setHeader("a", "a").get());
    }

    @Test
    void testDuplicateHeaderAllowEmptyPermitsBlankDuplicatesOnly() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("a", "", "").get();
        assertArrayEquals(new String[] {"a", "", ""}, format.getHeader());
        assertThrows(IllegalArgumentException.class,
                () -> CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("a", "a").get());
    }

    @Test
    void testDuplicateHeaderAllowAllPermitsDuplicates() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_ALL).setHeader("a", "a").get();
        assertArrayEquals(new String[] {"a", "a"}, format.getHeader());
    }

    @Test
    void testDeprecatedSetAllowDuplicateHeaderNamesDelegates() {
        final CSVFormat allowed = CSVFormat.DEFAULT.builder().setAllowDuplicateHeaderNames(true).get();
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, allowed.getDuplicateHeaderMode());
        final CSVFormat disallowed = CSVFormat.DEFAULT.builder().setAllowDuplicateHeaderNames(false).get();
        assertEquals(DuplicateHeaderMode.ALLOW_EMPTY, disallowed.getDuplicateHeaderMode());
    }

    // --- getDelimiter deprecated, getDelimiterCharArray-equivalent via public API ---

    @Test
    void testGetDelimiterDeprecatedReturnsFirstChar() {
        assertEquals(',', CSVFormat.DEFAULT.getDelimiter());
    }

    @Test
    void testGetEscapeCharacterNullWhenUnset() {
        assertNull(CSVFormat.DEFAULT.getEscapeCharacter());
        assertFalse(CSVFormat.DEFAULT.isEscapeCharacterSet());
    }

    @Test
    void testMaxRowsDefaultsToZero() {
        assertEquals(0L, CSVFormat.DEFAULT.getMaxRows());
        assertFalse(CSVFormat.DEFAULT.useMaxRows());
    }

    @Test
    void testSetMaxRows() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(5L).get();
        assertEquals(5L, format.getMaxRows());
        assertTrue(format.useMaxRows());
        assertTrue(format.useRow(5L));
        assertFalse(format.useRow(6L));
    }

    // --- equals / hashCode ---

    @Test
    void testEqualsReflexiveAndWithDifferentType() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.DEFAULT);
        assertNotEquals(CSVFormat.DEFAULT, "not a format");
        assertNotEquals(null, CSVFormat.DEFAULT);
    }

    @Test
    void testEqualsAndHashCodeForEquivalentFormats() {
        final CSVFormat a = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        final CSVFormat b = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    void testNotEqualsForDifferentDelimiter() {
        final CSVFormat a = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        final CSVFormat b = CSVFormat.DEFAULT.builder().setDelimiter(',').get();
        assertNotEquals(a, b);
    }

    // --- toString ---

    @Test
    void testToStringContainsDelimiterAndSkipHeaderRecord() {
        final String s = CSVFormat.DEFAULT.toString();
        assertTrue(s.contains("Delimiter=<,>"));
        assertTrue(s.contains("SkipHeaderRecord:false"));
    }

    @Test
    void testToStringIncludesHeaderWhenSet() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "b").get();
        final String s = format.toString();
        assertTrue(s.contains("Header:[a, b]"));
    }

    // --- format(Object...) ---

    @Test
    void testFormatSimpleValues() {
        assertEquals("a,b,c", CSVFormat.DEFAULT.format("a", "b", "c"));
    }

    @Test
    void testFormatQuotesValueContainingDelimiter() {
        assertEquals("\"a,b\",c", CSVFormat.DEFAULT.format("a,b", "c"));
    }

    @Test
    void testFormatWithNullValue() {
        assertEquals("a,,c", CSVFormat.DEFAULT.format("a", null, "c"));
    }

    // --- print / printRecord round trip ---

    @Test
    void testPrintRecordThenParseRoundTrips() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.printRecord(writer, "x", "y,z", "w");
        final String output = writer.toString();
        assertEquals("x,\"y,z\",w\r\n", output);
        try (CSVParser parser = CSVFormat.DEFAULT.parse(new StringReader(output))) {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            final CSVRecord record = records.get(0);
            assertEquals(3, record.size());
            assertEquals("x", record.get(0));
            assertEquals("y,z", record.get(1));
            assertEquals("w", record.get(2));
        }
    }

    @Test
    void testPrintlnWithTrailingDelimiterAndRecordSeparator() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).setRecordSeparator('\n').get();
        final StringWriter writer = new StringWriter();
        format.println(writer);
        assertEquals(",\n", writer.toString());
    }

    @Test
    void testPrintObjectAppliesTrim() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrim(true).get();
        final StringWriter writer = new StringWriter();
        format.print("  hello  ", writer, true);
        assertEquals("hello", writer.toString());
    }

    @Test
    void testPrinterFactoryMethodCreatesNonNullPrinter() throws IOException {
        final StringWriter writer = new StringWriter();
        try (CSVPrinter printer = CSVFormat.DEFAULT.print(writer)) {
            assertNotNull(printer);
            printer.printRecord("a", "b");
        }
        assertEquals("a,b\r\n", writer.toString());
    }

    // --- parse behavior with headers ---

    @Test
    void testParseWithHeaderAndSkipHeaderRecord() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().setSkipHeaderRecord(true).get();
        try (CSVParser parser = format.parse(new StringReader("name,age\r\nJohn,30\r\n"))) {
            final Iterator<CSVRecord> it = parser.iterator();
            assertTrue(it.hasNext());
            final CSVRecord record = it.next();
            assertEquals("John", record.get("name"));
            assertEquals("30", record.get("age"));
            assertFalse(it.hasNext());
        }
    }

    // --- builder() factory ---

    @Test
    void testBuilderReturnsIndependentInstanceNotAffectingOriginal() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder();
        builder.setDelimiter(';');
        final CSVFormat newFormat = builder.get();
        assertEquals(";", newFormat.getDelimiterString());
        assertEquals(",", CSVFormat.DEFAULT.getDelimiterString());
    }

    @Test
    void testIsQuoteCharacterSetAndIsNullStringSet() {
        assertTrue(CSVFormat.DEFAULT.isQuoteCharacterSet());
        assertFalse(CSVFormat.DEFAULT.isNullStringSet());
        final CSVFormat withNull = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        assertTrue(withNull.isNullStringSet());
    }

    @Test
    void testIsCommentMarkerSet() {
        assertFalse(CSVFormat.DEFAULT.isCommentMarkerSet());
        final CSVFormat withComment = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        assertTrue(withComment.isCommentMarkerSet());
        assertEquals(Character.valueOf('#'), withComment.getCommentMarker());
    }
}
