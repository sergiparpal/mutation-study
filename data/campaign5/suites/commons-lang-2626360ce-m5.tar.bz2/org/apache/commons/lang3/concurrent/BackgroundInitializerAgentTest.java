/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.concurrent;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.lang3.function.FailableSupplier;
import org.junit.jupiter.api.Test;

/**
 * Self-contained test class for {@link BackgroundInitializer}.
 */
class BackgroundInitializerAgentTest {

    /**
     * A concrete {@link BackgroundInitializer} used for testing that returns a fixed
     * result and allows injecting failures.
     */
    private static class TestBackgroundInitializer extends BackgroundInitializer<Integer> {

        static final Integer RESULT = Integer.valueOf(42);

        final AtomicInteger initializeCalls = new AtomicInteger();

        volatile Exception checkedExceptionToThrow;

        volatile RuntimeException runtimeExceptionToThrow;

        TestBackgroundInitializer() {
            super();
        }

        TestBackgroundInitializer(final ExecutorService exec) {
            super(exec);
        }

        @Override
        protected Integer initialize() throws Exception {
            initializeCalls.incrementAndGet();
            if (runtimeExceptionToThrow != null) {
                throw runtimeExceptionToThrow;
            }
            if (checkedExceptionToThrow != null) {
                throw checkedExceptionToThrow;
            }
            return RESULT;
        }
    }

    @Test
    void testGetTaskCountDefault() {
        final TestBackgroundInitializer init = new TestBackgroundInitializer();
        assertEquals(1, init.getTaskCount());
    }

    @Test
    void testIsStartedInitiallyFalse() {
        final TestBackgroundInitializer init = new TestBackgroundInitializer();
        assertFalse(init.isStarted());
        assertFalse(init.isInitialized());
    }

    @Test
    void testGetFutureBeforeStartThrowsIllegalStateException() {
        final TestBackgroundInitializer init = new TestBackgroundInitializer();
        try {
            init.getFuture();
            fail("Expected IllegalStateException");
        } catch (final IllegalStateException expected) {
            // expected
        }
    }

    @Test
    void testGetBeforeStartThrowsIllegalStateException() {
        final TestBackgroundInitializer init = new TestBackgroundInitializer();
        try {
            init.get();
            fail("Expected IllegalStateException");
        } catch (final IllegalStateException expected) {
            // expected
        } catch (final ConcurrentException e) {
            fail("Unexpected ConcurrentException: " + e);
        }
    }

    @Test
    void testStartReturnsTrueOnlyOnce() throws ConcurrentException {
        final TestBackgroundInitializer init = new TestBackgroundInitializer();
        assertTrue(init.start());
        assertTrue(init.isStarted());
        assertFalse(init.start());
        assertFalse(init.start());
        final Integer result = init.get();
        assertEquals(TestBackgroundInitializer.RESULT, result);
        assertEquals(1, init.initializeCalls.get());
    }

    @Test
    void testGetReturnsSameResultOnRepeatedCalls() throws ConcurrentException {
        final TestBackgroundInitializer init = new TestBackgroundInitializer();
        init.start();
        final Integer first = init.get();
        final Integer second = init.get();
        assertSame(first, second);
        assertEquals(1, init.initializeCalls.get());
    }

    @Test
    void testIsInitializedTrueAfterSuccessfulCompletion() throws ConcurrentException {
        final TestBackgroundInitializer init = new TestBackgroundInitializer();
        assertFalse(init.isInitialized());
        init.start();
        init.get();
        assertTrue(init.isInitialized());
    }

    @Test
    void testGetWrapsCheckedExceptionInConcurrentException() {
        final TestBackgroundInitializer init = new TestBackgroundInitializer();
        final IOException cause = new IOException("background failure");
        init.checkedExceptionToThrow = cause;
        init.start();
        try {
            init.get();
            fail("Expected ConcurrentException");
        } catch (final ConcurrentException e) {
            assertSame(cause, e.getCause());
        }
        assertFalse(init.isInitialized());
    }

    @Test
    void testGetRethrowsRuntimeExceptionDirectly() {
        final TestBackgroundInitializer init = new TestBackgroundInitializer();
        final RuntimeException runtimeCause = new IllegalArgumentException("bad input");
        init.runtimeExceptionToThrow = runtimeCause;
        init.start();
        try {
            init.get();
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            assertSame(runtimeCause, e);
        } catch (final ConcurrentException e) {
            fail("Unexpected ConcurrentException: " + e);
        }
        assertFalse(init.isInitialized());
    }

    @Test
    void testGetActiveExecutorNullBeforeStart() {
        final TestBackgroundInitializer init = new TestBackgroundInitializer();
        assertNull(init.getActiveExecutor());
    }

    @Test
    void testTemporaryExecutorIsCreatedAndShutDownAfterCompletion() throws ConcurrentException {
        final TestBackgroundInitializer init = new TestBackgroundInitializer();
        assertNull(init.getExternalExecutor());
        init.start();
        final ExecutorService active = init.getActiveExecutor();
        assertNotNull(active);
        init.get();
        assertTrue(active.isShutdown());
    }

    @Test
    void testExternalExecutorIsUsedAndNotShutDown() throws ConcurrentException, InterruptedException {
        final ExecutorService exec = Executors.newFixedThreadPool(1);
        try {
            final TestBackgroundInitializer init = new TestBackgroundInitializer(exec);
            assertSame(exec, init.getExternalExecutor());
            init.start();
            assertSame(exec, init.getActiveExecutor());
            final Integer result = init.get();
            assertEquals(TestBackgroundInitializer.RESULT, result);
            assertFalse(exec.isShutdown());
        } finally {
            exec.shutdown();
            exec.awaitTermination(2, TimeUnit.SECONDS);
        }
    }

    @Test
    void testSetExternalExecutorAfterStartThrowsIllegalStateException() throws ConcurrentException, InterruptedException {
        final TestBackgroundInitializer init = new TestBackgroundInitializer();
        init.start();
        final ExecutorService otherExec = Executors.newSingleThreadExecutor();
        try {
            init.setExternalExecutor(otherExec);
            fail("Expected IllegalStateException");
        } catch (final IllegalStateException expected) {
            // expected
        } finally {
            otherExec.shutdown();
            otherExec.awaitTermination(2, TimeUnit.SECONDS);
        }
        init.get();
    }

    @Test
    void testSetExternalExecutorBeforeStartIsHonored() {
        final TestBackgroundInitializer init = new TestBackgroundInitializer();
        final ExecutorService exec = Executors.newSingleThreadExecutor();
        try {
            init.setExternalExecutor(exec);
            assertSame(exec, init.getExternalExecutor());
            init.setExternalExecutor(null);
            assertNull(init.getExternalExecutor());
        } finally {
            exec.shutdown();
        }
    }

    @Test
    void testBuilderDefaultInitializerReturnsNull() throws ConcurrentException {
        final BackgroundInitializer<Object> init = BackgroundInitializer.<Object>builder().get();
        assertFalse(init.isStarted());
        assertNull(init.getExternalExecutor());
        init.start();
        final Object result = init.get();
        assertNull(result);
    }

    @Test
    void testBuilderWithCustomInitializerSupplier() throws ConcurrentException {
        final FailableSupplier<Integer, Exception> supplier = new FailableSupplier<Integer, Exception>() {
            @Override
            public Integer get() {
                return Integer.valueOf(99);
            }
        };
        final BackgroundInitializer<Integer> init = BackgroundInitializer.<Integer>builder().setInitializer(supplier).get();
        init.start();
        assertEquals(Integer.valueOf(99), init.get());
    }

    @Test
    void testBuilderWithExternalExecutor() {
        final ExecutorService exec = Executors.newSingleThreadExecutor();
        try {
            final BackgroundInitializer.Builder<BackgroundInitializer<Object>, Object> builder = BackgroundInitializer.<Object>builder();
            builder.setExternalExecutor(exec);
            final BackgroundInitializer<Object> init = builder.get();
            assertSame(exec, init.getExternalExecutor());
        } finally {
            exec.shutdown();
        }
    }
}
