/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link NumberUtils}.
 */
class NumberUtilsAgentTest {

    @Test
    void testConstants() {
        assertEquals(Long.valueOf(0L), NumberUtils.LONG_ZERO);
        assertEquals(Long.valueOf(1L), NumberUtils.LONG_ONE);
        assertEquals(Long.valueOf(-1L), NumberUtils.LONG_MINUS_ONE);
        assertEquals(Integer.valueOf(0), NumberUtils.INTEGER_ZERO);
        assertEquals(Integer.valueOf(1), NumberUtils.INTEGER_ONE);
        assertEquals(Integer.valueOf(2), NumberUtils.INTEGER_TWO);
        assertEquals(Integer.valueOf(-1), NumberUtils.INTEGER_MINUS_ONE);
        assertEquals(Short.valueOf((short) 0), NumberUtils.SHORT_ZERO);
        assertEquals(Short.valueOf((short) 1), NumberUtils.SHORT_ONE);
        assertEquals(Short.valueOf((short) -1), NumberUtils.SHORT_MINUS_ONE);
        assertEquals(Byte.valueOf((byte) 0), NumberUtils.BYTE_ZERO);
        assertEquals(Byte.valueOf((byte) 1), NumberUtils.BYTE_ONE);
        assertEquals(Byte.valueOf((byte) -1), NumberUtils.BYTE_MINUS_ONE);
        assertEquals(Double.valueOf(0.0d), NumberUtils.DOUBLE_ZERO);
        assertEquals(Double.valueOf(1.0d), NumberUtils.DOUBLE_ONE);
        assertEquals(Double.valueOf(-1.0d), NumberUtils.DOUBLE_MINUS_ONE);
        assertEquals(Float.valueOf(0.0f), NumberUtils.FLOAT_ZERO);
        assertEquals(Float.valueOf(1.0f), NumberUtils.FLOAT_ONE);
        assertEquals(Float.valueOf(-1.0f), NumberUtils.FLOAT_MINUS_ONE);
        assertEquals(Long.valueOf(Integer.MAX_VALUE), NumberUtils.LONG_INT_MAX_VALUE);
        assertEquals(Long.valueOf(Integer.MIN_VALUE), NumberUtils.LONG_INT_MIN_VALUE);
    }

    @Test
    void testConstructor() {
        final NumberUtils instance = new NumberUtils();
        assertNotNull(instance);
    }

    @Test
    void testCompareByte() {
        assertEquals(0, NumberUtils.compare((byte) 5, (byte) 5));
        assertTrue(NumberUtils.compare((byte) 1, (byte) 2) < 0);
        assertTrue(NumberUtils.compare((byte) 2, (byte) 1) > 0);
    }

    @Test
    void testCompareInt() {
        assertEquals(0, NumberUtils.compare(5, 5));
        assertTrue(NumberUtils.compare(1, 2) < 0);
        assertTrue(NumberUtils.compare(2, 1) > 0);
    }

    @Test
    void testCompareLong() {
        assertEquals(0, NumberUtils.compare(5L, 5L));
        assertTrue(NumberUtils.compare(1L, 2L) < 0);
        assertTrue(NumberUtils.compare(2L, 1L) > 0);
    }

    @Test
    void testCompareShort() {
        assertEquals(0, NumberUtils.compare((short) 5, (short) 5));
        assertTrue(NumberUtils.compare((short) 1, (short) 2) < 0);
        assertTrue(NumberUtils.compare((short) 2, (short) 1) > 0);
    }

    @Test
    void testCreateBigDecimal() {
        assertNull(NumberUtils.createBigDecimal(null));
        assertEquals(new BigDecimal("1.5"), NumberUtils.createBigDecimal("1.5"));
        assertEquals(BigDecimal.ZERO, NumberUtils.createBigDecimal("0"));
        try {
            NumberUtils.createBigDecimal("");
            fail("Expected NumberFormatException for empty string");
        } catch (final NumberFormatException expected) {
            // expected
        }
        try {
            NumberUtils.createBigDecimal("   ");
            fail("Expected NumberFormatException for blank string");
        } catch (final NumberFormatException expected) {
            // expected
        }
        try {
            NumberUtils.createBigDecimal("not a number");
            fail("Expected NumberFormatException for invalid string");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    @Test
    void testCreateBigInteger() {
        assertNull(NumberUtils.createBigInteger(null));
        assertEquals(BigInteger.valueOf(10), NumberUtils.createBigInteger("10"));
        assertEquals(BigInteger.valueOf(-10), NumberUtils.createBigInteger("-10"));
        assertEquals(BigInteger.valueOf(26), NumberUtils.createBigInteger("0x1A"));
        assertEquals(BigInteger.valueOf(26), NumberUtils.createBigInteger("0X1A"));
        assertEquals(BigInteger.valueOf(26), NumberUtils.createBigInteger("#1A"));
        assertEquals(BigInteger.valueOf(-26), NumberUtils.createBigInteger("-0x1A"));
        assertEquals(BigInteger.valueOf(8), NumberUtils.createBigInteger("010"));
        try {
            NumberUtils.createBigInteger("");
            fail("Expected NumberFormatException for empty string");
        } catch (final NumberFormatException expected) {
            // expected
        }
        try {
            NumberUtils.createBigInteger("--1");
            fail("Expected NumberFormatException for double sign");
        } catch (final NumberFormatException expected) {
            // expected
        }
        try {
            NumberUtils.createBigInteger("++1");
            fail("Expected NumberFormatException for double sign");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    @Test
    void testCreateDouble() {
        assertNull(NumberUtils.createDouble(null));
        assertEquals(Double.valueOf(1.5d), NumberUtils.createDouble("1.5"));
        try {
            NumberUtils.createDouble("not a number");
            fail("Expected NumberFormatException for invalid string");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    @Test
    void testCreateFloat() {
        assertNull(NumberUtils.createFloat(null));
        assertEquals(Float.valueOf(1.5f), NumberUtils.createFloat("1.5"));
        try {
            NumberUtils.createFloat("not a number");
            fail("Expected NumberFormatException for invalid string");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    @Test
    void testCreateInteger() {
        assertNull(NumberUtils.createInteger(null));
        assertEquals(Integer.valueOf(123), NumberUtils.createInteger("123"));
        assertEquals(Integer.valueOf(26), NumberUtils.createInteger("0x1A"));
        assertEquals(Integer.valueOf(8), NumberUtils.createInteger("010"));
        try {
            NumberUtils.createInteger("not a number");
            fail("Expected NumberFormatException for invalid string");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    @Test
    void testCreateLong() {
        assertNull(NumberUtils.createLong(null));
        assertEquals(Long.valueOf(123L), NumberUtils.createLong("123"));
        assertEquals(Long.valueOf(26L), NumberUtils.createLong("0x1A"));
        try {
            NumberUtils.createLong("not a number");
            fail("Expected NumberFormatException for invalid string");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    @Test
    void testCreateNumberNullAndBlank() {
        assertNull(NumberUtils.createNumber(null));
        try {
            NumberUtils.createNumber("");
            fail("Expected NumberFormatException for empty string");
        } catch (final NumberFormatException expected) {
            // expected
        }
        try {
            NumberUtils.createNumber("   ");
            fail("Expected NumberFormatException for blank string");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    @Test
    void testCreateNumberIntegral() {
        final Number n1 = NumberUtils.createNumber("123");
        assertTrue(n1 instanceof Integer);
        assertEquals(123, n1.intValue());

        final Number n2 = NumberUtils.createNumber("123L");
        assertTrue(n2 instanceof Long);
        assertEquals(123L, n2.longValue());

        final Number n3 = NumberUtils.createNumber("2147483648");
        assertTrue(n3 instanceof Long);
        assertEquals(2147483648L, n3.longValue());

        final Number n4 = NumberUtils.createNumber("123456789012345678901234567890");
        assertTrue(n4 instanceof BigInteger);
        assertEquals(new BigInteger("123456789012345678901234567890"), n4);
    }

    @Test
    void testCreateNumberHex() {
        final Number n1 = NumberUtils.createNumber("0x1A");
        assertTrue(n1 instanceof Integer);
        assertEquals(26, n1.intValue());

        final Number n2 = NumberUtils.createNumber("0x1AL");
        assertTrue(n2 instanceof Long);
        assertEquals(26L, n2.longValue());

        final Number n3 = NumberUtils.createNumber("#1A");
        assertTrue(n3 instanceof Integer);
        assertEquals(26, n3.intValue());

        final Number n4 = NumberUtils.createNumber("0x100000000");
        assertTrue(n4 instanceof Long);
        assertEquals(0x100000000L, n4.longValue());
    }

    @Test
    void testCreateNumberFloatingAndTypeQualifiers() {
        final Number n1 = NumberUtils.createNumber("1.5d");
        assertEquals(1.5d, n1.doubleValue(), 0.0d);
        assertTrue(n1 instanceof Double);

        final Number n2 = NumberUtils.createNumber("1.5D");
        assertEquals(1.5d, n2.doubleValue(), 0.0d);
        assertTrue(n2 instanceof Double);

        final Number n3 = NumberUtils.createNumber("1.5f");
        assertEquals(1.5f, n3.floatValue(), 0.0f);
        assertTrue(n3 instanceof Float);

        final Number n4 = NumberUtils.createNumber("1.5F");
        assertEquals(1.5f, n4.floatValue(), 0.0f);
        assertTrue(n4 instanceof Float);

        final Number n5 = NumberUtils.createNumber("1.5");
        assertEquals(1.5d, n5.doubleValue(), 0.0001d);

        try {
            NumberUtils.createNumber("1.5X");
            fail("Expected NumberFormatException for invalid type qualifier");
        } catch (final NumberFormatException expected) {
            // expected
        }
        try {
            NumberUtils.createNumber("notanumber");
            fail("Expected NumberFormatException for invalid string");
        } catch (final NumberFormatException expected) {
            // expected
        }
        try {
            NumberUtils.createNumber("1.5.6");
            fail("Expected NumberFormatException for double decimal point");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    @Test
    void testIsCreatable() {
        assertFalse(NumberUtils.isCreatable(null));
        assertFalse(NumberUtils.isCreatable(""));
        assertTrue(NumberUtils.isCreatable("123"));
        assertTrue(NumberUtils.isCreatable("123.45"));
        assertTrue(NumberUtils.isCreatable("0x1A"));
        assertFalse(NumberUtils.isCreatable("abc"));
        assertFalse(NumberUtils.isCreatable("1.5.6"));
        assertFalse(NumberUtils.isCreatable("--1"));
    }

    @SuppressWarnings("deprecation")
    @Test
    void testIsNumberDeprecated() {
        assertTrue(NumberUtils.isNumber("123"));
        assertFalse(NumberUtils.isNumber("abc"));
        assertFalse(NumberUtils.isNumber(""));
    }

    @Test
    void testIsDigits() {
        assertTrue(NumberUtils.isDigits("12345"));
        assertFalse(NumberUtils.isDigits("12.345"));
        assertFalse(NumberUtils.isDigits(""));
        assertFalse(NumberUtils.isDigits(null));
        assertFalse(NumberUtils.isDigits("-123"));
    }

    @Test
    void testIsParsable() {
        assertFalse(NumberUtils.isParsable(null));
        assertFalse(NumberUtils.isParsable(""));
        assertTrue(NumberUtils.isParsable("123"));
        assertTrue(NumberUtils.isParsable("1.5"));
        assertTrue(NumberUtils.isParsable("1e10"));
        assertTrue(NumberUtils.isParsable("NaN"));
        assertFalse(NumberUtils.isParsable("0x1A"));
        assertFalse(NumberUtils.isParsable("abc"));
    }

    @Test
    void testMaxByteArray() {
        assertEquals((byte) 5, NumberUtils.max((byte) 1, (byte) 5, (byte) 3));
        assertEquals((byte) 5, NumberUtils.max(new byte[] {5}));
        try {
            NumberUtils.max((byte[]) null);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.max(new byte[0]);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMinByteArray() {
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 5, (byte) 3));
        assertEquals((byte) 1, NumberUtils.min(new byte[] {1}));
        try {
            NumberUtils.min((byte[]) null);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.min(new byte[0]);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMaxMinByteThreeParam() {
        assertEquals((byte) 3, NumberUtils.max((byte) 1, (byte) 2, (byte) 3));
        assertEquals((byte) 3, NumberUtils.max((byte) 3, (byte) 2, (byte) 1));
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 2, (byte) 3));
        assertEquals((byte) 1, NumberUtils.min((byte) 3, (byte) 2, (byte) 1));
    }

    @Test
    void testMaxDoubleArray() {
        assertEquals(5.5d, NumberUtils.max(1.1d, 5.5d, 3.3d), 0.0d);
        assertEquals(5.0d, NumberUtils.max(new double[] {5.0d}), 0.0d);
        try {
            NumberUtils.max((double[]) null);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.max(new double[0]);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
        assertTrue(Double.isNaN(NumberUtils.max(1.0d, Double.NaN, 2.0d)));
    }

    @Test
    void testMinDoubleArray() {
        assertEquals(1.1d, NumberUtils.min(1.1d, 5.5d, 3.3d), 0.0d);
        assertEquals(5.0d, NumberUtils.min(new double[] {5.0d}), 0.0d);
        try {
            NumberUtils.min((double[]) null);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.min(new double[0]);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
        assertTrue(Double.isNaN(NumberUtils.min(1.0d, Double.NaN, 2.0d)));
    }

    @Test
    void testMaxMinDoubleThreeParam() {
        assertEquals(3.0d, NumberUtils.max(1.0d, 2.0d, 3.0d), 0.0d);
        assertEquals(1.0d, NumberUtils.min(1.0d, 2.0d, 3.0d), 0.0d);
    }

    @Test
    void testMaxFloatArray() {
        assertEquals(5.5f, NumberUtils.max(1.1f, 5.5f, 3.3f), 0.0f);
        try {
            NumberUtils.max((float[]) null);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.max(new float[0]);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMinFloatArray() {
        assertEquals(1.1f, NumberUtils.min(1.1f, 5.5f, 3.3f), 0.0f);
        try {
            NumberUtils.min((float[]) null);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.min(new float[0]);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMaxMinFloatThreeParam() {
        assertEquals(3.0f, NumberUtils.max(1.0f, 2.0f, 3.0f), 0.0f);
        assertEquals(1.0f, NumberUtils.min(1.0f, 2.0f, 3.0f), 0.0f);
    }

    @Test
    void testMaxIntArray() {
        assertEquals(5, NumberUtils.max(1, 5, 3));
        assertEquals(5, NumberUtils.max(new int[] {5}));
        try {
            NumberUtils.max((int[]) null);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.max(new int[0]);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMinIntArray() {
        assertEquals(1, NumberUtils.min(1, 5, 3));
        assertEquals(5, NumberUtils.min(new int[] {5}));
        try {
            NumberUtils.min((int[]) null);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.min(new int[0]);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMaxMinIntThreeParam() {
        assertEquals(3, NumberUtils.max(1, 2, 3));
        assertEquals(3, NumberUtils.max(3, 2, 1));
        assertEquals(1, NumberUtils.min(1, 2, 3));
        assertEquals(1, NumberUtils.min(3, 2, 1));
    }

    @Test
    void testMaxLongArray() {
        assertEquals(5L, NumberUtils.max(1L, 5L, 3L));
        assertEquals(5L, NumberUtils.max(new long[] {5L}));
        try {
            NumberUtils.max((long[]) null);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.max(new long[0]);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMinLongArray() {
        assertEquals(1L, NumberUtils.min(1L, 5L, 3L));
        assertEquals(5L, NumberUtils.min(new long[] {5L}));
        try {
            NumberUtils.min((long[]) null);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.min(new long[0]);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMaxMinLongThreeParam() {
        assertEquals(3L, NumberUtils.max(1L, 2L, 3L));
        assertEquals(1L, NumberUtils.min(1L, 2L, 3L));
    }

    @Test
    void testMaxShortArray() {
        assertEquals((short) 5, NumberUtils.max((short) 1, (short) 5, (short) 3));
        assertEquals((short) 5, NumberUtils.max(new short[] {5}));
        try {
            NumberUtils.max((short[]) null);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.max(new short[0]);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMinShortArray() {
        assertEquals((short) 1, NumberUtils.min((short) 1, (short) 5, (short) 3));
        assertEquals((short) 5, NumberUtils.min(new short[] {5}));
        try {
            NumberUtils.min((short[]) null);
            fail("Expected NullPointerException");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.min(new short[0]);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMaxMinShortThreeParam() {
        assertEquals((short) 3, NumberUtils.max((short) 1, (short) 2, (short) 3));
        assertEquals((short) 1, NumberUtils.min((short) 1, (short) 2, (short) 3));
    }

    @Test
    void testToByte() {
        assertEquals((byte) 0, NumberUtils.toByte(null));
        assertEquals((byte) 0, NumberUtils.toByte(""));
        assertEquals((byte) 1, NumberUtils.toByte("1"));
        assertEquals((byte) 1, NumberUtils.toByte(null, (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("", (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("1", (byte) 0));
        assertEquals((byte) 2, NumberUtils.toByte("not a number", (byte) 2));
    }

    @Test
    void testToDoubleBigDecimal() {
        assertEquals(0.0d, NumberUtils.toDouble((BigDecimal) null), 0.0d);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d)), 0.0d);
        assertEquals(1.1d, NumberUtils.toDouble((BigDecimal) null, 1.1d), 0.0d);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d), 1.1d), 0.0d);
    }

    @Test
    void testToDoubleString() {
        assertEquals(0.0d, NumberUtils.toDouble((String) null), 0.0d);
        assertEquals(0.0d, NumberUtils.toDouble(""), 0.0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5"), 0.0d);
        assertEquals(1.1d, NumberUtils.toDouble((String) null, 1.1d), 0.0d);
        assertEquals(1.1d, NumberUtils.toDouble("", 1.1d), 0.0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5", 0.0d), 0.0d);
        assertEquals(2.2d, NumberUtils.toDouble("not a number", 2.2d), 0.0d);
    }

    @Test
    void testToFloat() {
        assertEquals(0.0f, NumberUtils.toFloat(null), 0.0f);
        assertEquals(0.0f, NumberUtils.toFloat(""), 0.0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5"), 0.0f);
        assertEquals(1.1f, NumberUtils.toFloat(null, 1.1f), 0.0f);
        assertEquals(1.1f, NumberUtils.toFloat("", 1.1f), 0.0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5", 0.0f), 0.0f);
        assertEquals(2.2f, NumberUtils.toFloat("not a number", 2.2f), 0.0f);
    }

    @Test
    void testToInt() {
        assertEquals(0, NumberUtils.toInt(null));
        assertEquals(0, NumberUtils.toInt(""));
        assertEquals(1, NumberUtils.toInt("1"));
        assertEquals(1, NumberUtils.toInt(null, 1));
        assertEquals(1, NumberUtils.toInt("", 1));
        assertEquals(1, NumberUtils.toInt("1", 0));
        assertEquals(2, NumberUtils.toInt("not a number", 2));
    }

    @Test
    void testToLong() {
        assertEquals(0L, NumberUtils.toLong(null));
        assertEquals(0L, NumberUtils.toLong(""));
        assertEquals(1L, NumberUtils.toLong("1"));
        assertEquals(1L, NumberUtils.toLong(null, 1L));
        assertEquals(1L, NumberUtils.toLong("", 1L));
        assertEquals(1L, NumberUtils.toLong("1", 0L));
        assertEquals(2L, NumberUtils.toLong("not a number", 2L));
    }

    @Test
    void testToShort() {
        assertEquals((short) 0, NumberUtils.toShort(null));
        assertEquals((short) 0, NumberUtils.toShort(""));
        assertEquals((short) 1, NumberUtils.toShort("1"));
        assertEquals((short) 1, NumberUtils.toShort(null, (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("", (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("1", (short) 0));
        assertEquals((short) 2, NumberUtils.toShort("not a number", (short) 2));
    }

    @Test
    void testToScaledBigDecimalBigDecimal() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.235")));
        assertEquals(new BigDecimal("1.22"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.225")));
        assertEquals(new BigDecimal("1.2350"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.235"), 4, RoundingMode.HALF_UP));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.235"), 2, null));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null, 4, RoundingMode.HALF_UP));
    }

    @Test
    void testToScaledBigDecimalDouble() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal(Double.valueOf(1.235d)));
        assertEquals(new BigDecimal("1.2350"), NumberUtils.toScaledBigDecimal(Double.valueOf(1.235d), 4, RoundingMode.HALF_UP));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null, 4, RoundingMode.HALF_UP));
    }

    @Test
    void testToScaledBigDecimalFloat() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null));
        assertEquals(new BigDecimal("1.23"), NumberUtils.toScaledBigDecimal(Float.valueOf(1.225f)));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null, 4, RoundingMode.HALF_UP));
    }

    @Test
    void testToScaledBigDecimalString() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null));
        assertEquals(new BigDecimal("1.24"), NumberUtils.toScaledBigDecimal("1.235"));
        assertEquals(new BigDecimal("1.2350"), NumberUtils.toScaledBigDecimal("1.235", 4, RoundingMode.HALF_UP));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null, 4, RoundingMode.HALF_UP));
    }
}
