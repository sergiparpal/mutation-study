/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.builder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link ToStringStyle}.
 */
class ToStringStyleAgentTest {

    /**
     * Minimal concrete subclass used to instantiate the abstract {@link ToStringStyle}
     * with every default setting left untouched.
     */
    private static final class TestStyle extends ToStringStyle {
        private static final long serialVersionUID = 1L;
    }

    /**
     * Fixture used for full round-trip append tests.
     */
    private static final class Person {
        String name;
        int age;
        boolean smoker;
    }

    @Test
    void testStaticStyleConstantsAreDistinctAndNotNull() {
        final ToStringStyle[] styles = { ToStringStyle.DEFAULT_STYLE, ToStringStyle.MULTI_LINE_STYLE, ToStringStyle.NO_FIELD_NAMES_STYLE,
                ToStringStyle.SHORT_PREFIX_STYLE, ToStringStyle.SIMPLE_STYLE, ToStringStyle.NO_CLASS_NAME_STYLE, ToStringStyle.JSON_STYLE };
        for (final ToStringStyle style : styles) {
            assertNotNull(style);
        }
        for (int i = 0; i < styles.length; i++) {
            for (int j = i + 1; j < styles.length; j++) {
                assertNotSame(styles[i], styles[j]);
            }
        }
    }

    @Test
    void testRegistryLifecycle() {
        assertTrue(ToStringStyle.getRegistry().isEmpty());
        final Object marker = new Object();
        assertFalse(ToStringStyle.isRegistered(marker));
        ToStringStyle.register(marker);
        assertTrue(ToStringStyle.isRegistered(marker));
        assertTrue(ToStringStyle.getRegistry().containsKey(marker));
        ToStringStyle.unregister(marker);
        assertFalse(ToStringStyle.isRegistered(marker));
        assertTrue(ToStringStyle.getRegistry().isEmpty());
        // Unregistering an object that was never registered, or null, must not fail.
        ToStringStyle.unregister(marker);
        ToStringStyle.unregister(null);
        ToStringStyle.register(null);
        assertTrue(ToStringStyle.getRegistry().isEmpty());
    }

    @Test
    void testVisitedLifecycleIsClearedWhenRegistryEmpties() {
        final Object marker = new Object();
        assertFalse(ToStringStyle.isVisited(marker));
        ToStringStyle.markVisited(marker);
        assertTrue(ToStringStyle.isVisited(marker));
        ToStringStyle.markVisited(null);
        // Emptying the registry clears the visited set as a side effect.
        ToStringStyle.register(marker);
        ToStringStyle.unregister(marker);
        assertFalse(ToStringStyle.isVisited(marker));
    }

    @Test
    void testDefaultGetterValues() {
        final TestStyle style = new TestStyle();
        assertEquals("{", style.getArrayStart());
        assertEquals("}", style.getArrayEnd());
        assertEquals(",", style.getArraySeparator());
        assertEquals("[", style.getContentStart());
        assertEquals("]", style.getContentEnd());
        assertEquals("=", style.getFieldNameValueSeparator());
        assertEquals(",", style.getFieldSeparator());
        assertEquals("<null>", style.getNullText());
        assertEquals("<size=", style.getSizeStartText());
        assertEquals(">", style.getSizeEndText());
        assertEquals("<", style.getSummaryObjectStartText());
        assertEquals(">", style.getSummaryObjectEndText());
        assertTrue(style.isArrayContentDetail());
        assertTrue(style.isDefaultFullDetail());
        assertFalse(style.isFieldSeparatorAtStart());
        assertFalse(style.isFieldSeparatorAtEnd());
        assertTrue(style.isUseClassName());
        assertTrue(style.isUseFieldNames());
        assertTrue(style.isUseIdentityHashCode());
        assertFalse(style.isUseShortClassName());
    }

    @Test
    void testStringSettersConvertNullToEmptyStringAndAcceptNonNull() {
        final TestStyle style = new TestStyle();

        style.setArrayStart("<<");
        assertEquals("<<", style.getArrayStart());
        style.setArrayStart(null);
        assertEquals("", style.getArrayStart());

        style.setArrayEnd(">>");
        assertEquals(">>", style.getArrayEnd());
        style.setArrayEnd(null);
        assertEquals("", style.getArrayEnd());

        style.setArraySeparator(";");
        assertEquals(";", style.getArraySeparator());
        style.setArraySeparator(null);
        assertEquals("", style.getArraySeparator());

        style.setContentStart("(");
        assertEquals("(", style.getContentStart());
        style.setContentStart(null);
        assertEquals("", style.getContentStart());

        style.setContentEnd(")");
        assertEquals(")", style.getContentEnd());
        style.setContentEnd(null);
        assertEquals("", style.getContentEnd());

        style.setFieldNameValueSeparator(":");
        assertEquals(":", style.getFieldNameValueSeparator());
        style.setFieldNameValueSeparator(null);
        assertEquals("", style.getFieldNameValueSeparator());

        style.setFieldSeparator("|");
        assertEquals("|", style.getFieldSeparator());
        style.setFieldSeparator(null);
        assertEquals("", style.getFieldSeparator());

        style.setNullText("NULL");
        assertEquals("NULL", style.getNullText());
        style.setNullText(null);
        assertEquals("", style.getNullText());

        style.setSizeStartText("[size:");
        assertEquals("[size:", style.getSizeStartText());
        style.setSizeStartText(null);
        assertEquals("", style.getSizeStartText());

        style.setSizeEndText("]");
        assertEquals("]", style.getSizeEndText());
        style.setSizeEndText(null);
        assertEquals("", style.getSizeEndText());

        style.setSummaryObjectStartText("{{");
        assertEquals("{{", style.getSummaryObjectStartText());
        style.setSummaryObjectStartText(null);
        assertEquals("", style.getSummaryObjectStartText());

        style.setSummaryObjectEndText("}}");
        assertEquals("}}", style.getSummaryObjectEndText());
        style.setSummaryObjectEndText(null);
        assertEquals("", style.getSummaryObjectEndText());
    }

    @Test
    void testBooleanSettersAndGetters() {
        final TestStyle style = new TestStyle();

        style.setArrayContentDetail(false);
        assertFalse(style.isArrayContentDetail());
        style.setArrayContentDetail(true);
        assertTrue(style.isArrayContentDetail());

        style.setDefaultFullDetail(false);
        assertFalse(style.isDefaultFullDetail());

        style.setFieldSeparatorAtStart(true);
        assertTrue(style.isFieldSeparatorAtStart());

        style.setFieldSeparatorAtEnd(true);
        assertTrue(style.isFieldSeparatorAtEnd());

        style.setUseClassName(false);
        assertFalse(style.isUseClassName());

        style.setUseFieldNames(false);
        assertFalse(style.isUseFieldNames());

        style.setUseIdentityHashCode(false);
        assertFalse(style.isUseIdentityHashCode());

        style.setUseShortClassName(true);
        assertTrue(style.isUseShortClassName());
    }

    @Test
    void testIsFullDetail() {
        final TestStyle style = new TestStyle();
        // Default defaultFullDetail is true, so null delegates to it.
        assertTrue(style.isFullDetail(null));
        assertTrue(style.isFullDetail(Boolean.TRUE));
        assertFalse(style.isFullDetail(Boolean.FALSE));

        style.setDefaultFullDetail(false);
        assertFalse(style.isFullDetail(null));
        assertTrue(style.isFullDetail(Boolean.TRUE));
    }

    @Test
    void testAppendPrimitiveScalars() {
        final TestStyle style = new TestStyle();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "flag", true);
        assertEquals("flag=true,", buffer.toString());

        buffer = new StringBuffer();
        style.append(buffer, "b", (byte) 5);
        assertEquals("b=5,", buffer.toString());

        buffer = new StringBuffer();
        style.append(buffer, "c", 'x');
        assertEquals("c=x,", buffer.toString());

        buffer = new StringBuffer();
        style.append(buffer, "d", 1.5d);
        assertEquals("d=1.5,", buffer.toString());

        buffer = new StringBuffer();
        style.append(buffer, "f", 2.5f);
        assertEquals("f=2.5,", buffer.toString());

        buffer = new StringBuffer();
        style.append(buffer, "i", 42);
        assertEquals("i=42,", buffer.toString());

        buffer = new StringBuffer();
        style.append(buffer, "l", 42L);
        assertEquals("l=42,", buffer.toString());

        buffer = new StringBuffer();
        style.append(buffer, "s", (short) 7);
        assertEquals("s=7,", buffer.toString());
    }

    @Test
    void testAppendPrimitiveArrayNullIsNullText() {
        final TestStyle style = new TestStyle();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", (int[]) null, Boolean.TRUE);
        assertEquals("arr=<null>,", buffer.toString());

        buffer = new StringBuffer();
        style.append(buffer, "arr", (boolean[]) null, Boolean.FALSE);
        assertEquals("arr=<null>,", buffer.toString());
    }

    @Test
    void testAppendPrimitiveArrayDetailAndSummary() {
        final TestStyle style = new TestStyle();
        final int[] values = { 1, 2, 3 };

        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", values, Boolean.TRUE);
        assertEquals("arr={1,2,3},", buffer.toString());

        buffer = new StringBuffer();
        style.append(buffer, "arr", values, Boolean.FALSE);
        assertEquals("arr=<size=3>,", buffer.toString());

        // fullDetail == null falls back to isDefaultFullDetail(), which is true by default.
        buffer = new StringBuffer();
        style.append(buffer, "arr", values, null);
        assertEquals("arr={1,2,3},", buffer.toString());
    }

    @Test
    void testAppendObjectValueNullDetailAndSummary() {
        final TestStyle style = new TestStyle();

        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "o", (Object) null, Boolean.TRUE);
        assertEquals("o=<null>,", buffer.toString());

        buffer = new StringBuffer();
        style.append(buffer, "o", "hello", Boolean.TRUE);
        assertEquals("o=hello,", buffer.toString());

        buffer = new StringBuffer();
        style.append(buffer, "o", "hello", Boolean.FALSE);
        assertEquals("o=<String>,", buffer.toString());
    }

    @Test
    void testAppendObjectArrayNullDetailAndSummary() {
        final TestStyle style = new TestStyle();
        final String[] values = { "a", "b" };

        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", (Object[]) null, Boolean.TRUE);
        assertEquals("arr=<null>,", buffer.toString());

        buffer = new StringBuffer();
        style.append(buffer, "arr", values, Boolean.TRUE);
        assertEquals("arr={a,b},", buffer.toString());

        buffer = new StringBuffer();
        style.append(buffer, "arr", values, Boolean.FALSE);
        assertEquals("arr=<size=2>,", buffer.toString());
    }

    @Test
    void testAppendDetailCollectionWithNullElementUsesNullText() {
        final TestStyle style = new TestStyle();
        final List<Object> list = new ArrayList<Object>();
        list.add("a");
        list.add(null);
        list.add(Integer.valueOf(1));

        final StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "field", list);
        assertEquals("[a, <null>, 1]", buffer.toString());
    }

    @Test
    void testAppendDetailMapWithNullValueAppendsLiteralNull() {
        final TestStyle style = new TestStyle();
        final Map<String, Object> map = new LinkedHashMap<String, Object>();
        map.put("k1", "v1");
        map.put("k2", null);

        final StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "field", map);
        // Unlike collection elements, a null map value is appended via appendDetail(Object),
        // not appendNullText, so it renders as the literal word "null" rather than "<null>".
        assertEquals("{k1=v1, k2=null}", buffer.toString());
    }

    @Test
    void testAppendInternalDetectsCyclicReference() {
        final TestStyle style = new TestStyle();
        final List<Object> cyclic = new ArrayList<Object>();
        cyclic.add(cyclic);

        final StringBuffer buffer = new StringBuffer();
        style.appendInternal(buffer, "field", cyclic, true);
        final String result = buffer.toString();
        assertTrue(result.startsWith("["));
        assertTrue(result.endsWith("]"));
        assertTrue(result.contains(cyclic.getClass().getName() + "@"));
        // The registry must be left clean after the call completes.
        assertTrue(ToStringStyle.getRegistry().isEmpty());
    }

    @Test
    void testAppendStartAndAppendEndFullRoundTrip() {
        final TestStyle style = new TestStyle();
        final Person person = new Person();
        person.name = "John Doe";
        person.age = 33;
        person.smoker = false;

        final StringBuffer buffer = new StringBuffer();
        style.appendStart(buffer, person);
        style.append(buffer, "name", person.name, Boolean.TRUE);
        style.append(buffer, "age", person.age);
        style.append(buffer, "smoker", person.smoker);
        style.appendEnd(buffer, person);

        final String result = buffer.toString();
        assertTrue(result.startsWith(Person.class.getName() + "@"));
        assertTrue(result.endsWith("[name=John Doe,age=33,smoker=false]"));
        // appendEnd() must unregister the object from the registry.
        assertTrue(ToStringStyle.getRegistry().isEmpty());
    }

    @Test
    void testAppendStartAndAppendEndWithNullObject() {
        final TestStyle style = new TestStyle();
        final StringBuffer buffer = new StringBuffer();
        style.appendStart(buffer, null);
        // appendStart() is a no-op for a null object: no class name, hash code or content start.
        assertEquals("", buffer.toString());
        style.appendEnd(buffer, null);
        // appendEnd() unconditionally appends the content end marker, even for a null object.
        assertEquals("]", buffer.toString());
    }

    @Test
    void testAppendToStringMergesContent() {
        final StringBuffer buffer = new StringBuffer("prefix,");
        ToStringStyle.DEFAULT_STYLE.appendToString(buffer, "Foo[a=1,b=2]");
        assertEquals("prefix,a=1,b=2,", buffer.toString());
    }

    @Test
    void testAppendToStringIgnoresNull() {
        final StringBuffer buffer = new StringBuffer("prefix,");
        ToStringStyle.DEFAULT_STYLE.appendToString(buffer, null);
        assertEquals("prefix,", buffer.toString());
    }

    @Test
    void testAppendToStringIgnoresEmptyContent() {
        final StringBuffer buffer = new StringBuffer("prefix,");
        ToStringStyle.DEFAULT_STYLE.appendToString(buffer, "Foo[]");
        assertEquals("prefix,", buffer.toString());
    }

    @Test
    void testAppendSuperDelegatesToAppendToString() {
        final StringBuffer buffer = new StringBuffer("prefix,");
        ToStringStyle.DEFAULT_STYLE.appendSuper(buffer, "Foo[a=1]");
        assertEquals("prefix,a=1,", buffer.toString());
    }

    @Test
    void testJsonStyleRejectsNullFieldNameOnScalarAppend() {
        final StringBuffer buffer = new StringBuffer();
        try {
            ToStringStyle.JSON_STYLE.append(buffer, null, 5);
            fail("Expected UnsupportedOperationException");
        } catch (final UnsupportedOperationException expected) {
            // expected: JSON field names are mandatory
        }
    }

    @Test
    void testJsonStyleRejectsNullFieldNameOnObjectAppend() {
        final StringBuffer buffer = new StringBuffer();
        try {
            ToStringStyle.JSON_STYLE.append(buffer, null, "value", Boolean.TRUE);
            fail("Expected UnsupportedOperationException");
        } catch (final UnsupportedOperationException expected) {
            // expected: JSON field names are mandatory
        }
    }

    @Test
    void testJsonStyleRejectsFullDetailFalse() {
        final StringBuffer buffer = new StringBuffer();
        try {
            ToStringStyle.JSON_STYLE.append(buffer, "field", "value", Boolean.FALSE);
            fail("Expected UnsupportedOperationException");
        } catch (final UnsupportedOperationException expected) {
            // expected: summary mode is not supported by JSON_STYLE
        }
    }

    @Test
    void testJsonStyleAllowsNullFullDetailBecauseDefaultIsTrue() {
        final StringBuffer buffer = new StringBuffer();
        ToStringStyle.JSON_STYLE.append(buffer, "field", "value", null);
        assertEquals("\"field\":\"value\",", buffer.toString());
    }

    @Test
    void testJsonStyleFullRoundTrip() {
        final Object marker = new Object();
        final StringBuffer buffer = new StringBuffer();
        ToStringStyle.JSON_STYLE.appendStart(buffer, marker);
        ToStringStyle.JSON_STYLE.append(buffer, "name", "John Doe", Boolean.TRUE);
        ToStringStyle.JSON_STYLE.append(buffer, "age", 33);
        ToStringStyle.JSON_STYLE.appendEnd(buffer, marker);

        assertEquals("{\"name\":\"John Doe\",\"age\":33}", buffer.toString());
        assertTrue(ToStringStyle.getRegistry().isEmpty());
    }
}
