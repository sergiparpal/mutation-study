/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import java.util.Locale;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests {@link LocaleUtils}.
 */
class LocaleUtilsAgentTest {

    private static void assertImmutable(final List<Locale> list) {
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                list.add(Locale.US);
            }
        });
    }

    private static void assertInvalidLocaleFormat(final String str) {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale(str);
            }
        });
    }

    @Test
    void testConstructor() {
        assertNotNull(new LocaleUtils());
    }

    @Test
    void testAvailableLocaleList() {
        final List<Locale> list = LocaleUtils.availableLocaleList();
        assertNotNull(list);
        // the list must be sorted and is cached, so successive calls return the same instance
        assertSame(list, LocaleUtils.availableLocaleList());
        assertTrue(list.contains(Locale.US));
        assertImmutable(list);
    }

    @Test
    void testAvailableLocaleSet() {
        final Set<Locale> set = LocaleUtils.availableLocaleSet();
        assertNotNull(set);
        assertSame(set, LocaleUtils.availableLocaleSet());
        assertTrue(set.contains(Locale.US));
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                set.add(Locale.CANADA_FRENCH);
            }
        });
    }

    @Test
    void testIsAvailableLocale() {
        assertTrue(LocaleUtils.isAvailableLocale(Locale.US));
        assertFalse(LocaleUtils.isAvailableLocale(new Locale("xx", "ZZZZZZ", "qqq")));
    }

    @Test
    void testCountriesByLanguageNull() {
        assertEquals(0, LocaleUtils.countriesByLanguage(null).size());
    }

    @Test
    void testCountriesByLanguageEmpty() {
        assertEquals(0, LocaleUtils.countriesByLanguage("").size());
    }

    @Test
    void testCountriesByLanguageInvalid() {
        // too long to be an ISO 639 code
        assertEquals(0, LocaleUtils.countriesByLanguage("toolong").size());
        // contains digits
        assertEquals(0, LocaleUtils.countriesByLanguage("e2").size());
    }

    @Test
    void testCountriesByLanguageValid() {
        final List<Locale> list = LocaleUtils.countriesByLanguage("en");
        assertNotNull(list);
        assertTrue(list.contains(Locale.US));
        // every locale returned must have the requested language and an empty country
        for (final Locale locale : list) {
            assertEquals("en", locale.getLanguage());
        }
        // cached: same reference returned on second call
        assertSame(list, LocaleUtils.countriesByLanguage("en"));
        assertImmutable(list);
    }

    @Test
    void testCountriesByLanguageUnknownButWellFormed() {
        // well-formed ISO 639 code, but no known locales -> empty, not null, and cached
        final List<Locale> list = LocaleUtils.countriesByLanguage("zz");
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    void testLanguagesByCountryNull() {
        assertEquals(0, LocaleUtils.languagesByCountry(null).size());
    }

    @Test
    void testLanguagesByCountryEmpty() {
        // an empty country code matches language-only locales (empty country, no variant)
        final List<Locale> list = LocaleUtils.languagesByCountry("");
        assertNotNull(list);
        assertFalse(list.isEmpty());
        for (final Locale locale : list) {
            assertEquals("", locale.getCountry());
            assertEquals("", locale.getVariant());
        }
    }

    @Test
    void testLanguagesByCountryInvalid() {
        // lowercase is not a valid ISO 3166 alpha-2 country code
        assertEquals(0, LocaleUtils.languagesByCountry("us").size());
        // wrong length
        assertEquals(0, LocaleUtils.languagesByCountry("USA1").size());
    }

    @Test
    void testLanguagesByCountryValid() {
        final List<Locale> list = LocaleUtils.languagesByCountry("US");
        assertNotNull(list);
        assertTrue(list.contains(Locale.US));
        for (final Locale locale : list) {
            assertEquals("US", locale.getCountry());
        }
        assertSame(list, LocaleUtils.languagesByCountry("US"));
    }

    @Test
    void testLanguagesByCountryNumericAreaCode() {
        // "001" is a valid UN M.49 numeric area code
        final List<Locale> list = LocaleUtils.languagesByCountry("001");
        assertNotNull(list);
    }

    @Test
    void testIsLanguageUndetermined() {
        assertTrue(LocaleUtils.isLanguageUndetermined(null));
        assertTrue(LocaleUtils.isLanguageUndetermined(new Locale("")));
        assertFalse(LocaleUtils.isLanguageUndetermined(Locale.ENGLISH));
    }

    @Test
    void testLocaleLookupListSingleArgNull() {
        final List<Locale> list = LocaleUtils.localeLookupList(null);
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    void testLocaleLookupListSingleArgLanguageOnly() {
        final List<Locale> list = LocaleUtils.localeLookupList(Locale.ENGLISH);
        assertEquals(1, list.size());
        assertEquals(Locale.ENGLISH, list.get(0));
    }

    @Test
    void testLocaleLookupListSingleArgLanguageAndCountry() {
        final List<Locale> list = LocaleUtils.localeLookupList(Locale.US);
        assertEquals(2, list.size());
        assertEquals(Locale.US, list.get(0));
        assertEquals(Locale.ENGLISH, list.get(1));
    }

    @Test
    void testLocaleLookupListSingleArgFull() {
        final Locale locale = new Locale("fr", "CA", "xxx");
        final List<Locale> list = LocaleUtils.localeLookupList(locale);
        assertEquals(3, list.size());
        assertEquals(locale, list.get(0));
        assertEquals(new Locale("fr", "CA"), list.get(1));
        assertEquals(new Locale("fr"), list.get(2));
        assertImmutable(list);
    }

    @Test
    void testLocaleLookupListTwoArgNullLocale() {
        final List<Locale> list = LocaleUtils.localeLookupList(null, Locale.ENGLISH);
        assertTrue(list.isEmpty());
    }

    @Test
    void testLocaleLookupListTwoArgWithDefault() {
        final Locale locale = new Locale("fr", "CA", "xxx");
        final List<Locale> list = LocaleUtils.localeLookupList(locale, Locale.ENGLISH);
        assertEquals(4, list.size());
        assertEquals(locale, list.get(0));
        assertEquals(new Locale("fr", "CA"), list.get(1));
        assertEquals(new Locale("fr"), list.get(2));
        assertEquals(Locale.ENGLISH, list.get(3));
    }

    @Test
    void testLocaleLookupListTwoArgNoDuplicate() {
        // default locale already present in the derived chain -> not appended again
        final List<Locale> list = LocaleUtils.localeLookupList(Locale.US, Locale.US);
        assertEquals(2, list.size());
        assertEquals(Locale.US, list.get(0));
        assertEquals(Locale.ENGLISH, list.get(1));
    }

    @Test
    void testToLocaleFromLocaleNull() {
        final Locale result = LocaleUtils.toLocale((Locale) null);
        assertEquals(Locale.getDefault(), result);
    }

    @Test
    void testToLocaleFromLocaleNonNull() {
        assertSame(Locale.US, LocaleUtils.toLocale(Locale.US));
    }

    @Test
    void testToLocaleStringNull() {
        assertNull(LocaleUtils.toLocale((String) null));
    }

    @Test
    void testToLocaleStringEmpty() {
        final Locale locale = LocaleUtils.toLocale("");
        assertEquals("", locale.getLanguage());
        assertEquals("", locale.getCountry());
    }

    @Test
    void testToLocaleStringTooShort() {
        assertInvalidLocaleFormat("a");
    }

    @Test
    void testToLocaleStringLanguageOnly() {
        final Locale locale = LocaleUtils.toLocale("en");
        assertEquals("en", locale.getLanguage());
        assertEquals("", locale.getCountry());
    }

    @Test
    void testToLocaleStringLanguageAndCountryUnderscore() {
        final Locale locale = LocaleUtils.toLocale("en_GB");
        assertEquals("en", locale.getLanguage());
        assertEquals("GB", locale.getCountry());
    }

    @Test
    void testToLocaleStringLanguageAndCountryDash() {
        final Locale locale = LocaleUtils.toLocale("en-GB");
        assertEquals("en", locale.getLanguage());
        assertEquals("GB", locale.getCountry());
    }

    @Test
    void testToLocaleStringNumericArea() {
        final Locale locale = LocaleUtils.toLocale("en_001");
        assertEquals("en", locale.getLanguage());
        assertEquals("001", locale.getCountry());
    }

    @Test
    void testToLocaleStringFullWithVariant() {
        final Locale locale = LocaleUtils.toLocale("en_GB_xxx");
        assertEquals("en", locale.getLanguage());
        assertEquals("GB", locale.getCountry());
        assertEquals("xxx", locale.getVariant());
    }

    @Test
    void testToLocaleStringCountryOnlyLeadingUnderscore() {
        final Locale locale = LocaleUtils.toLocale("_GB");
        assertEquals("", locale.getLanguage());
        assertEquals("GB", locale.getCountry());
    }

    @Test
    void testToLocaleStringCountryOnlyLeadingDash() {
        final Locale locale = LocaleUtils.toLocale("-GB");
        assertEquals("", locale.getLanguage());
        assertEquals("GB", locale.getCountry());
    }

    @Test
    void testToLocaleStringLeadingUnderscoreTooShort() {
        assertInvalidLocaleFormat("_G");
    }

    @Test
    void testToLocaleStringLeadingUnderscoreLowercase() {
        // country code after leading separator must be uppercase
        assertInvalidLocaleFormat("_gb");
    }

    @Test
    void testToLocaleStringCountryWithVariant() {
        final Locale locale = LocaleUtils.toLocale("_GB_xxx");
        assertEquals("", locale.getLanguage());
        assertEquals("GB", locale.getCountry());
        assertEquals("xxx", locale.getVariant());
    }

    @Test
    void testToLocaleStringCountryWithVariantMissingSeparator() {
        // length >= 5 but no 2nd separator matching the first one at index 3
        assertInvalidLocaleFormat("_GBxxx");
    }

    @Test
    void testToLocaleStringCountryVariantTooShort() {
        // leading separator, len==4, no room for a variant after a 2nd separator
        assertInvalidLocaleFormat("_GBx");
    }

    @Test
    void testToLocaleStringInvalidLanguageUppercase() {
        assertInvalidLocaleFormat("EN");
    }

    @Test
    void testToLocaleStringUnknownIsoCountryAsLanguagelessLocale() {
        // "US" is not a valid language code for a 2-char string with no separator, but it is a
        // known ISO country code, so toLocale falls back to a country-only locale.
        final Locale locale = LocaleUtils.toLocale("US");
        assertEquals("", locale.getLanguage());
        assertEquals("US", locale.getCountry());
    }

    @Test
    void testToLocaleStringInvalidFormat() {
        assertInvalidLocaleFormat("en_G");
        assertInvalidLocaleFormat("en_gb");
        assertInvalidLocaleFormat("1");
    }

    @Test
    void testToLocaleStringSpecialCaseThai() {
        final Locale locale = LocaleUtils.toLocale("th_TH_TH_#u-nu-thai");
        assertEquals("th", locale.getLanguage());
        assertEquals("TH", locale.getCountry());
        assertEquals("TH", locale.getVariant());
    }

    @Test
    void testToLocaleStringSpecialCaseJapanese() {
        final Locale locale = LocaleUtils.toLocale("ja_JP_JP_#u-ca-japanese");
        assertEquals("ja", locale.getLanguage());
        assertEquals("JP", locale.getCountry());
        assertEquals("JP", locale.getVariant());
    }
}
