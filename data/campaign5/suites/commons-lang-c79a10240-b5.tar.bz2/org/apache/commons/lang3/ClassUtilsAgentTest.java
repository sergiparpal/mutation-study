/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

public class ClassUtilsAgentTest {

    interface AgentInterfaceA {
        // marker
    }

    interface AgentInterfaceB extends AgentInterfaceA {
        // marker
    }

    static class AgentGrandparent implements AgentInterfaceB {
        // empty
    }

    static class AgentParent extends AgentGrandparent {
        // empty
    }

    static class AgentChild extends AgentParent {
        // empty
    }

    @Test
    public void testComparator() {
        final List<Class<?>> classes = new ArrayList<Class<?>>(Arrays.asList(String.class, Integer.class, Boolean.class));
        Collections.sort(classes, ClassUtils.comparator());
        assertEquals(Arrays.asList(Boolean.class, Integer.class, String.class), classes);
    }

    @Test
    public void testConvertClassesToClassNames() {
        assertNull(ClassUtils.convertClassesToClassNames(null));
        final List<Class<?>> classes = Arrays.asList(String.class, null);
        final List<String> names = ClassUtils.convertClassesToClassNames(classes);
        assertEquals(Arrays.asList("java.lang.String", null), names);
    }

    @Test
    public void testConvertClassNamesToClasses() {
        assertNull(ClassUtils.convertClassNamesToClasses(null));
        final List<String> names = Arrays.asList("java.lang.String", "no.such.ClassExists", null);
        final List<Class<?>> classes = ClassUtils.convertClassNamesToClasses(names);
        assertEquals(3, classes.size());
        assertSame(String.class, classes.get(0));
        assertNull(classes.get(1));
        assertNull(classes.get(2));
    }

    @Test
    public void testGetAbbreviatedNameFromClass() {
        assertEquals("", ClassUtils.getAbbreviatedName((Class<?>) null, 1));
        // null class short-circuits before the lengthHint check
        assertEquals("", ClassUtils.getAbbreviatedName((Class<?>) null, 0));
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName(String.class, 5));
        assertEquals("java.lang.String", ClassUtils.getAbbreviatedName(String.class, 30));
    }

    @Test
    public void testGetAbbreviatedNameFromString() {
        assertEquals("", ClassUtils.getAbbreviatedName((String) null, 1));
        assertEquals("j.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 15));
        assertEquals("java.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 16));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ClassUtils.getAbbreviatedName("java.lang.String", 0);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ClassUtils.getAbbreviatedName((String) null, 0);
            }
        });
    }

    @Test
    public void testGetAllInterfaces() {
        assertNull(ClassUtils.getAllInterfaces(null));
        final List<Class<?>> interfaces = ClassUtils.getAllInterfaces(AgentChild.class);
        assertEquals(Arrays.asList(AgentInterfaceB.class, AgentInterfaceA.class), interfaces);
    }

    @Test
    public void testGetAllSuperclasses() {
        assertNull(ClassUtils.getAllSuperclasses(null));
        final List<Class<?>> superclasses = ClassUtils.getAllSuperclasses(AgentChild.class);
        assertEquals(Arrays.asList(AgentParent.class, AgentGrandparent.class, Object.class), superclasses);
        assertEquals(Collections.emptyList(), ClassUtils.getAllSuperclasses(Object.class));
    }

    @Test
    public void testGetCanonicalName() {
        assertEquals("", ClassUtils.getCanonicalName((Class<?>) null));
        assertEquals("N/A", ClassUtils.getCanonicalName((Class<?>) null, "N/A"));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName(String.class));
        assertEquals("int[]", ClassUtils.getCanonicalName(int[].class));
        assertEquals("java.lang.String[]", ClassUtils.getCanonicalName(String[].class));
        assertEquals("", ClassUtils.getCanonicalName((Object) null));
        assertEquals("N/A", ClassUtils.getCanonicalName((Object) null, "N/A"));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName("hi"));
    }

    @Test
    public void testGetClassByName() throws ClassNotFoundException {
        assertSame(String.class, ClassUtils.getClass("java.lang.String"));
        assertSame(Integer.TYPE, ClassUtils.getClass("int"));
        assertSame(int[].class, ClassUtils.getClass("[I"));
        assertSame(int[].class, ClassUtils.getClass("int[]"));
        assertSame(Map.Entry.class, ClassUtils.getClass("java.util.Map.Entry"));
        assertThrows(ClassNotFoundException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass("no.such.ClassExists");
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass((String) null);
            }
        });
    }

    @Test
    public void testGetClassWithClassLoader() throws ClassNotFoundException {
        final ClassLoader loader = ClassUtilsAgentTest.class.getClassLoader();
        assertSame(String.class, ClassUtils.getClass(loader, "java.lang.String"));
        assertSame(String.class, ClassUtils.getClass(loader, "java.lang.String", false));
        assertThrows(ClassNotFoundException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass(loader, "no.such.ClassExists");
            }
        });
    }

    @Test
    public void testGetClassBlankNameIsIllegal() {
        final ClassLoader loader = ClassUtilsAgentTest.class.getClassLoader();
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass(loader, "   ");
            }
        });
        assertTrue(ex.getMessage().contains("empty"));
    }

    @Test
    public void testGetClassArrayDimensionTooLarge() {
        final ClassLoader loader = ClassUtilsAgentTest.class.getClassLoader();
        final StringBuilder sb = new StringBuilder("int");
        for (int i = 0; i <= 255; i++) {
            sb.append("[]");
        }
        final String className = sb.toString();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass(loader, className);
            }
        });
    }

    @Test
    public void testGetClassEncodedArrayDimensionTooLarge() {
        final ClassLoader loader = ClassUtilsAgentTest.class.getClassLoader();
        final StringBuilder sb = new StringBuilder();
        for (int i = 0; i <= 255; i++) {
            sb.append('[');
        }
        sb.append("Ljava.lang.String;");
        final String className = sb.toString();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass(loader, className);
            }
        });
    }

    @Test
    public void testGetComponentType() {
        assertNull(ClassUtils.getComponentType(null));
        assertSame(String.class, ClassUtils.getComponentType(String[].class));
    }

    @Test
    public void testGetNameFromClass() {
        assertEquals("", ClassUtils.getName((Class<?>) null));
        assertEquals("X", ClassUtils.getName((Class<?>) null, "X"));
        assertEquals("java.lang.String", ClassUtils.getName(String.class));
    }

    @Test
    public void testGetNameFromObject() {
        assertEquals("", ClassUtils.getName((Object) null));
        assertEquals("Y", ClassUtils.getName((Object) null, "Y"));
        assertEquals("java.lang.String", ClassUtils.getName("hi"));
    }

    @Test
    public void testGetPackageCanonicalName() {
        assertEquals("", ClassUtils.getPackageCanonicalName((Class<?>) null));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName(String.class));
        assertEquals("", ClassUtils.getPackageCanonicalName(int[].class));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName(String[].class));
        assertEquals("D", ClassUtils.getPackageCanonicalName((Object) null, "D"));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName((Object) "hi", "D"));
    }

    @Test
    public void testGetPackageName() {
        assertEquals("", ClassUtils.getPackageName((Class<?>) null));
        assertEquals("java.lang", ClassUtils.getPackageName(String.class));
        assertEquals("D", ClassUtils.getPackageName((Object) null, "D"));
        assertEquals("java.lang", ClassUtils.getPackageName((Object) "hi", "D"));
        assertEquals("", ClassUtils.getPackageName(""));
        assertEquals("", ClassUtils.getPackageName((String) null));
        assertEquals("", ClassUtils.getPackageName("NoPackageHere"));
        assertEquals("java.lang", ClassUtils.getPackageName("[Ljava.lang.String;"));
    }

    @Test
    public void testGetPublicMethod() throws Exception {
        final List<Object> list = Collections.unmodifiableList(new ArrayList<Object>());
        final Class<?> packagePrivateClass = list.getClass();
        assertFalse(ClassUtils.isPublic(packagePrivateClass));
        final Method method = ClassUtils.getPublicMethod(packagePrivateClass, "size");
        assertSame(List.class, method.getDeclaringClass());
        assertEquals(0, ((Integer) method.invoke(list)).intValue());
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getPublicMethod(String.class, "noSuchMethodHere");
            }
        });
    }

    @Test
    public void testGetShortCanonicalName() {
        assertEquals("", ClassUtils.getShortCanonicalName((String) null));
        assertEquals("", ClassUtils.getShortCanonicalName((Class<?>) null));
        assertEquals("int[]", ClassUtils.getShortCanonicalName("[I"));
        assertEquals("String[]", ClassUtils.getShortCanonicalName("[Ljava.lang.String;"));
        assertEquals("String[]", ClassUtils.getShortCanonicalName(String[].class));
        assertEquals("Entry", ClassUtils.getShortCanonicalName(Map.Entry.class));
        assertEquals("D", ClassUtils.getShortCanonicalName((Object) null, "D"));
        assertEquals("String", ClassUtils.getShortCanonicalName((Object) "hi", "D"));
    }

    @Test
    public void testGetShortClassNameFromClass() {
        assertEquals("", ClassUtils.getShortClassName((Class<?>) null));
        assertEquals("String", ClassUtils.getShortClassName(String.class));
        assertEquals("int[]", ClassUtils.getShortClassName(int[].class));
        assertEquals("String[][]", ClassUtils.getShortClassName(String[][].class));
        assertEquals("Map.Entry", ClassUtils.getShortClassName(Map.Entry.class));
        assertEquals("D", ClassUtils.getShortClassName((Object) null, "D"));
        assertEquals("String", ClassUtils.getShortClassName("hi", "D"));
    }

    @Test
    public void testGetShortClassNameAnonymous() {
        final Runnable r = new Runnable() {
            @Override
            public void run() {
                // no-op
            }
        };
        final Class<?> anonymousClass = r.getClass();
        final String name = anonymousClass.getName();
        final String expected = name.substring(name.lastIndexOf('.') + 1).replace('$', '.');
        assertEquals(expected, ClassUtils.getShortClassName(anonymousClass));
    }

    @Test
    public void testGetShortClassNameFromString() {
        assertEquals("", ClassUtils.getShortClassName((String) null));
        assertEquals("", ClassUtils.getShortClassName(""));
        assertEquals("int[]", ClassUtils.getShortClassName("[I"));
        assertEquals("int[][]", ClassUtils.getShortClassName("[[I"));
        assertEquals("String[]", ClassUtils.getShortClassName("[Ljava.lang.String;"));
        assertEquals("Map.Entry", ClassUtils.getShortClassName(Map.Entry.class.getName()));
        assertEquals("Entry", ClassUtils.getShortClassName(Map.Entry.class.getCanonicalName()));
    }

    @Test
    public void testGetSimpleName() {
        assertEquals("", ClassUtils.getSimpleName((Class<?>) null));
        assertEquals("D", ClassUtils.getSimpleName((Class<?>) null, "D"));
        assertEquals("String", ClassUtils.getSimpleName(String.class));
        assertEquals("", ClassUtils.getSimpleName((Object) null));
        assertEquals("D", ClassUtils.getSimpleName((Object) null, "D"));
        assertEquals("String", ClassUtils.getSimpleName("hi"));
    }

    @Test
    public void testHierarchyExcludingInterfaces() {
        final Iterator<Class<?>> it = ClassUtils.hierarchy(AgentChild.class).iterator();
        assertSame(AgentChild.class, it.next());
        assertSame(AgentParent.class, it.next());
        assertSame(AgentGrandparent.class, it.next());
        assertSame(Object.class, it.next());
        assertFalse(it.hasNext());
    }

    @Test
    public void testHierarchyIncludingInterfaces() {
        final Iterator<Class<?>> it = ClassUtils.hierarchy(AgentChild.class, ClassUtils.Interfaces.INCLUDE).iterator();
        assertSame(AgentChild.class, it.next());
        assertSame(AgentParent.class, it.next());
        assertSame(AgentGrandparent.class, it.next());
        assertSame(AgentInterfaceB.class, it.next());
        assertSame(AgentInterfaceA.class, it.next());
        assertSame(Object.class, it.next());
        assertFalse(it.hasNext());
    }

    @Test
    public void testHierarchyIteratorRemoveUnsupported() {
        final Iterator<Class<?>> it = ClassUtils.hierarchy(AgentChild.class).iterator();
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                it.remove();
            }
        });
    }

    @Test
    public void testInterfacesEnum() {
        assertEquals(2, ClassUtils.Interfaces.values().length);
        assertSame(ClassUtils.Interfaces.INCLUDE, ClassUtils.Interfaces.valueOf("INCLUDE"));
        assertSame(ClassUtils.Interfaces.EXCLUDE, ClassUtils.Interfaces.valueOf("EXCLUDE"));
    }

    @Test
    public void testIsAssignable() {
        assertTrue(ClassUtils.isAssignable(null, Object.class));
        assertFalse(ClassUtils.isAssignable(null, int.class));
        assertFalse(ClassUtils.isAssignable(String.class, null));
        assertTrue(ClassUtils.isAssignable(String.class, Object.class));
        assertTrue(ClassUtils.isAssignable(int.class, long.class));
        assertFalse(ClassUtils.isAssignable(long.class, int.class));
        assertFalse(ClassUtils.isAssignable(boolean.class, int.class));
        assertTrue(ClassUtils.isAssignable(byte.class, short.class));
        assertFalse(ClassUtils.isAssignable(short.class, byte.class));
    }

    @Test
    public void testIsAssignableAutoboxing() {
        assertTrue(ClassUtils.isAssignable(Integer.class, int.class, true));
        assertFalse(ClassUtils.isAssignable(Integer.class, int.class, false));
        assertTrue(ClassUtils.isAssignable(int.class, Integer.class, true));
        assertFalse(ClassUtils.isAssignable(int.class, Integer.class, false));
    }

    @Test
    public void testIsAssignableArrays() {
        assertTrue(ClassUtils.isAssignable((Class<?>[]) null, (Class<?>[]) null));
        assertTrue(ClassUtils.isAssignable(new Class<?>[] {int.class}, new Class<?>[] {long.class}));
        assertFalse(ClassUtils.isAssignable(new Class<?>[] {int.class}, new Class<?>[] {long.class, String.class}));
        assertFalse(ClassUtils.isAssignable(new Class<?>[] {boolean.class}, new Class<?>[] {int.class}));
    }

    @Test
    public void testIsInnerClass() {
        assertFalse(ClassUtils.isInnerClass(null));
        assertFalse(ClassUtils.isInnerClass(String.class));
        assertTrue(ClassUtils.isInnerClass(AgentChild.class));
        assertTrue(ClassUtils.isInnerClass(Map.Entry.class));
    }

    @Test
    public void testIsPrimitiveOrWrapper() {
        assertFalse(ClassUtils.isPrimitiveOrWrapper(null));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(int.class));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(Integer.class));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(Void.TYPE));
        assertFalse(ClassUtils.isPrimitiveOrWrapper(String.class));
    }

    @Test
    public void testIsPrimitiveWrapper() {
        assertFalse(ClassUtils.isPrimitiveWrapper(null));
        assertTrue(ClassUtils.isPrimitiveWrapper(Integer.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(int.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(Void.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(String.class));
    }

    @Test
    public void testIsPublic() {
        assertTrue(ClassUtils.isPublic(String.class));
        assertFalse(ClassUtils.isPublic(Collections.unmodifiableList(new ArrayList<Object>()).getClass()));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.isPublic(null);
            }
        });
    }

    @Test
    public void testPrimitivesToWrappers() {
        assertNull(ClassUtils.primitivesToWrappers((Class<?>[]) null));
        assertEquals(0, ClassUtils.primitivesToWrappers().length);
        final Class<?>[] result = ClassUtils.primitivesToWrappers(int.class, String.class, null);
        assertSame(Integer.class, result[0]);
        assertSame(String.class, result[1]);
        assertNull(result[2]);
    }

    @Test
    public void testPrimitiveToWrapper() {
        assertNull(ClassUtils.primitiveToWrapper(null));
        assertSame(Integer.class, ClassUtils.primitiveToWrapper(int.class));
        assertSame(String.class, ClassUtils.primitiveToWrapper(String.class));
        assertSame(Void.TYPE, ClassUtils.primitiveToWrapper(Void.TYPE));
    }

    @Test
    public void testToClass() {
        assertNull(ClassUtils.toClass((Object[]) null));
        assertEquals(0, ClassUtils.toClass().length);
        final Class<?>[] result = ClassUtils.toClass("hi", null, Integer.valueOf(1));
        assertSame(String.class, result[0]);
        assertNull(result[1]);
        assertSame(Integer.class, result[2]);
    }

    @Test
    public void testWrappersToPrimitives() {
        assertNull(ClassUtils.wrappersToPrimitives((Class<?>[]) null));
        assertEquals(0, ClassUtils.wrappersToPrimitives().length);
        final Class<?>[] result = ClassUtils.wrappersToPrimitives(Integer.class, String.class, null);
        assertSame(int.class, result[0]);
        assertNull(result[1]);
        assertNull(result[2]);
    }

    @Test
    public void testWrapperToPrimitive() {
        assertNull(ClassUtils.wrapperToPrimitive(null));
        assertSame(int.class, ClassUtils.wrapperToPrimitive(Integer.class));
        assertNull(ClassUtils.wrapperToPrimitive(String.class));
        assertNull(ClassUtils.wrapperToPrimitive(Void.class));
    }

    @Test
    public void testConstructorIsPublicAndUsable() {
        final ClassUtils instance = new ClassUtils();
        assertNotNull(instance);
    }
}
