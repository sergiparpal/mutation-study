/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text.translate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.IOException;
import java.io.StringWriter;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link NumericEntityUnescaper}.
 */
@Deprecated
class NumericEntityUnescaperAgentTest {

    @Test
    void testDefaultOptionIsSemiColonRequired() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertTrue(neu.isSet(NumericEntityUnescaper.OPTION.semiColonRequired));
        assertFalse(neu.isSet(NumericEntityUnescaper.OPTION.semiColonOptional));
        assertFalse(neu.isSet(NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
    }

    @Test
    void testIsSetWithExplicitOption() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.semiColonOptional);
        assertTrue(neu.isSet(NumericEntityUnescaper.OPTION.semiColonOptional));
        assertFalse(neu.isSet(NumericEntityUnescaper.OPTION.semiColonRequired));
    }

    @Test
    void testIsSetWithMultipleOptions() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper(
                NumericEntityUnescaper.OPTION.semiColonOptional, NumericEntityUnescaper.OPTION.errorIfNoSemiColon);
        assertTrue(neu.isSet(NumericEntityUnescaper.OPTION.semiColonOptional));
        assertTrue(neu.isSet(NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
        assertFalse(neu.isSet(NumericEntityUnescaper.OPTION.semiColonRequired));
    }

    @Test
    void testDecimalEntityWithSemiColon() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("Test A test", neu.translate("Test &#65; test"));
    }

    @Test
    void testHexEntityLowerCaseX() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("Test A test", neu.translate("Test &#x41; test"));
    }

    @Test
    void testHexEntityUpperCaseX() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("Test A test", neu.translate("Test &#X41; test"));
    }

    @Test
    void testOutOfBounds() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();

        assertEquals("Test &", neu.translate("Test &"));
        assertEquals("Test &#", neu.translate("Test &#"));
        assertEquals("Test &#x", neu.translate("Test &#x"));
        assertEquals("Test &#X", neu.translate("Test &#X"));
    }

    @Test
    void testSupplementaryUnescaping() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final String input = "&#68642;";
        final String expected = "𐰢";

        assertEquals(expected, neu.translate(input));
    }

    @Test
    void testUnfinishedEntityOptional() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.semiColonOptional);
        final String input = "Test &#x30 not test";
        final String expected = "Test 0 not test";

        assertEquals(expected, neu.translate(input));
    }

    @Test
    void testUnfinishedEntityIgnoredByDefault() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final String input = "Test &#x30 not test";

        assertEquals(input, neu.translate(input));
    }

    @Test
    void testUnfinishedEntityErrorIfNoSemiColon() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.errorIfNoSemiColon);
        final String input = "Test &#x30 not test";
        try {
            neu.translate(input);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            assertEquals("Semi-colon required at end of numeric entity", e.getMessage());
        }
    }

    @Test
    void testInvalidNumberIsIgnored() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final String input = "&#zzz;";
        assertEquals(input, neu.translate(input));
    }

    @Test
    void testOutOfRangeCodePointIsIgnored() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final String input = "&#99999999;";
        assertEquals(input, neu.translate(input));
    }

    @Test
    void testTranslateDirectWithIndexReturnsConsumedCount() throws IOException {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final StringWriter writer = new StringWriter();
        final int consumed = neu.translate("&#65;", 0, writer);
        assertEquals(5, consumed);
        assertEquals("A", writer.toString());
    }

    @Test
    void testTranslateDirectWithIndexReturnsZeroWhenNotAnEntity() throws IOException {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final StringWriter writer = new StringWriter();
        final int consumed = neu.translate("abc", 0, writer);
        assertEquals(0, consumed);
        assertEquals("", writer.toString());
    }

    @Test
    void testXWithNoDigitsIsIgnored() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.semiColonOptional);
        final String input = "&#x;";
        assertEquals(input, neu.translate(input));
    }

    @Test
    void testEmptyStringReturnsEmptyString() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("", neu.translate(""));
    }

    @Test
    void testNullInputReturnsNull() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals(null, neu.translate((String) null));
    }
}
