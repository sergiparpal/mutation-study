/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.concurrent;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

import org.junit.jupiter.api.Test;

/**
 * Self-contained test class for {@link TimedSemaphore}.
 */
public class TimedSemaphoreAgentTest {

    private static TimedSemaphore newSemaphore(final long period, final TimeUnit unit, final int limit) {
        return TimedSemaphore.builder().setPeriod(period).setTimeUnit(unit).setLimit(limit).get();
    }

    @Test
    public void testDeprecatedConstructorRejectsZeroPeriod() {
        try {
            new TimedSemaphore(0L, TimeUnit.SECONDS, 1);
            throw new AssertionError("expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testDeprecatedConstructorRejectsNegativePeriod() {
        try {
            new TimedSemaphore(-1L, TimeUnit.SECONDS, 1);
            throw new AssertionError("expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testDeprecatedConstructorStoresPeriodAndUnit() {
        final TimedSemaphore sem = new TimedSemaphore(5L, TimeUnit.SECONDS, 3);
        assertEquals(5L, sem.getPeriod());
        assertEquals(TimeUnit.SECONDS, sem.getUnit());
        assertEquals(3, sem.getLimit());
        sem.shutdown();
    }

    @Test
    public void testBuilderRejectsZeroPeriod() {
        final TimedSemaphore.Builder builder = TimedSemaphore.builder().setPeriod(0L).setTimeUnit(TimeUnit.SECONDS).setLimit(1);
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                builder.get();
            }
        });
    }

    @Test
    public void testBuilderRejectsNegativePeriod() {
        final TimedSemaphore.Builder builder = TimedSemaphore.builder().setPeriod(-5L).setTimeUnit(TimeUnit.SECONDS).setLimit(1);
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                builder.get();
            }
        });
    }

    @Test
    public void testBuilderCreatesInstanceWithExpectedState() {
        final TimedSemaphore sem = newSemaphore(2L, TimeUnit.SECONDS, 7);
        assertEquals(2L, sem.getPeriod());
        assertEquals(TimeUnit.SECONDS, sem.getUnit());
        assertEquals(7, sem.getLimit());
        assertFalse(sem.isShutdown());
        sem.shutdown();
    }

    @Test
    public void testGetLimitAndSetLimit() {
        final TimedSemaphore sem = newSemaphore(1L, TimeUnit.DAYS, 1);
        assertEquals(1, sem.getLimit());
        sem.setLimit(5);
        assertEquals(5, sem.getLimit());
        sem.shutdown();
    }

    @Test
    public void testTryAcquireHonoursLimit() {
        final TimedSemaphore sem = newSemaphore(1L, TimeUnit.DAYS, 2);
        assertTrue(sem.tryAcquire());
        assertEquals(1, sem.getAcquireCount());
        assertTrue(sem.tryAcquire());
        assertEquals(2, sem.getAcquireCount());
        assertFalse(sem.tryAcquire());
        assertEquals(2, sem.getAcquireCount());
        assertEquals(0, sem.getAvailablePermits());
        sem.shutdown();
    }

    @Test
    public void testGetAvailablePermitsDecreasesAsAcquired() {
        final TimedSemaphore sem = newSemaphore(1L, TimeUnit.DAYS, 3);
        assertEquals(3, sem.getAvailablePermits());
        assertTrue(sem.tryAcquire());
        assertEquals(2, sem.getAvailablePermits());
        assertTrue(sem.tryAcquire());
        assertEquals(1, sem.getAvailablePermits());
        sem.shutdown();
    }

    @Test
    public void testSetLimitDynamicallyAllowsMoreAcquisitions() {
        final TimedSemaphore sem = newSemaphore(1L, TimeUnit.DAYS, 1);
        assertTrue(sem.tryAcquire());
        assertFalse(sem.tryAcquire());
        sem.setLimit(2);
        assertTrue(sem.tryAcquire());
        assertEquals(2, sem.getAcquireCount());
        sem.shutdown();
    }

    @Test
    public void testNoLimitNeverBlocksAndCountsKeepGrowing() throws InterruptedException {
        final TimedSemaphore sem = newSemaphore(1L, TimeUnit.DAYS, TimedSemaphore.NO_LIMIT);
        assertEquals(0, TimedSemaphore.NO_LIMIT);
        for (int i = 0; i < 50; i++) {
            sem.acquire();
        }
        assertEquals(50, sem.getAcquireCount());
        assertEquals(TimedSemaphore.NO_LIMIT - 50, sem.getAvailablePermits());
        sem.shutdown();
    }

    @Test
    public void testEndOfPeriodResetsCounterAndUpdatesStatistics() {
        final TimedSemaphore sem = newSemaphore(1L, TimeUnit.DAYS, 3);
        assertTrue(sem.tryAcquire());
        assertTrue(sem.tryAcquire());
        sem.endOfPeriod();
        assertEquals(0, sem.getAcquireCount());
        assertEquals(2, sem.getLastAcquiresPerPeriod());
        assertEquals(2.0d, sem.getAverageCallsPerPeriod(), 0.0001d);

        assertTrue(sem.tryAcquire());
        sem.endOfPeriod();
        assertEquals(1, sem.getLastAcquiresPerPeriod());
        assertEquals(1.5d, sem.getAverageCallsPerPeriod(), 0.0001d);
        sem.shutdown();
    }

    @Test
    public void testAverageCallsPerPeriodIsZeroBeforeAnyPeriodEnds() {
        final TimedSemaphore sem = newSemaphore(1L, TimeUnit.DAYS, 3);
        assertEquals(0.0d, sem.getAverageCallsPerPeriod(), 0.0001d);
        sem.shutdown();
    }

    @Test
    public void testAcquireBlocksUntilEndOfPeriodReleasesWaiters() throws InterruptedException {
        final TimedSemaphore sem = newSemaphore(1L, TimeUnit.DAYS, 1);
        sem.acquire();
        assertEquals(1, sem.getAcquireCount());

        final AtomicBoolean acquired = new AtomicBoolean(false);
        final CountDownLatch started = new CountDownLatch(1);
        final Thread waiter = new Thread(new Runnable() {
            @Override
            public void run() {
                started.countDown();
                try {
                    sem.acquire();
                    acquired.set(true);
                } catch (final InterruptedException e) {
                    // ignore for this test
                }
            }
        });
        waiter.start();
        started.await();
        Thread.sleep(200L);
        assertFalse(acquired.get());
        assertTrue(waiter.isAlive());

        sem.endOfPeriod();
        waiter.join(5000L);
        assertFalse(waiter.isAlive());
        assertTrue(acquired.get());
        assertEquals(1, sem.getAcquireCount());

        sem.shutdown();
    }

    @Test
    public void testAcquireThrowsInterruptedExceptionWhenInterruptedWhileWaiting() throws InterruptedException {
        final TimedSemaphore sem = newSemaphore(1L, TimeUnit.DAYS, 1);
        sem.acquire();

        final AtomicBoolean interrupted = new AtomicBoolean(false);
        final CountDownLatch started = new CountDownLatch(1);
        final Thread waiter = new Thread(new Runnable() {
            @Override
            public void run() {
                started.countDown();
                try {
                    sem.acquire();
                } catch (final InterruptedException e) {
                    interrupted.set(true);
                }
            }
        });
        waiter.start();
        started.await();
        Thread.sleep(200L);
        waiter.interrupt();
        waiter.join(5000L);
        assertFalse(waiter.isAlive());
        assertTrue(interrupted.get());

        sem.shutdown();
    }

    @Test
    public void testRealTimerEventuallyResetsCounter() throws InterruptedException {
        final TimedSemaphore sem = newSemaphore(100L, TimeUnit.MILLISECONDS, 1);
        assertTrue(sem.tryAcquire());
        assertFalse(sem.tryAcquire());
        Thread.sleep(500L);
        assertTrue(sem.tryAcquire());
        sem.shutdown();
    }

    @Test
    public void testIsShutdownReflectsState() {
        final TimedSemaphore sem = newSemaphore(1L, TimeUnit.DAYS, 1);
        assertFalse(sem.isShutdown());
        sem.shutdown();
        assertTrue(sem.isShutdown());
    }

    @Test
    public void testShutdownIsIdempotent() {
        final TimedSemaphore sem = newSemaphore(1L, TimeUnit.DAYS, 1);
        sem.shutdown();
        sem.shutdown();
        sem.shutdown();
        assertTrue(sem.isShutdown());
    }

    @Test
    public void testAcquireAfterShutdownThrowsIllegalStateException() {
        final TimedSemaphore sem = newSemaphore(1L, TimeUnit.DAYS, 1);
        sem.shutdown();
        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                sem.acquire();
            }
        });
    }

    @Test
    public void testTryAcquireAfterShutdownThrowsIllegalStateException() {
        final TimedSemaphore sem = newSemaphore(1L, TimeUnit.DAYS, 1);
        sem.shutdown();
        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                sem.tryAcquire();
            }
        });
    }

    @Test
    public void testOwnExecutorIsShutDownOnShutdown() throws InterruptedException {
        final TimedSemaphore sem = newSemaphore(1L, TimeUnit.DAYS, 1);
        sem.acquire();
        final ScheduledExecutorService executor = sem.getExecutorService();
        assertFalse(executor.isShutdown());
        sem.shutdown();
        assertTrue(executor.isShutdown());
    }

    @Test
    public void testExternalExecutorIsNotShutDownOnShutdown() throws InterruptedException {
        final ScheduledThreadPoolExecutor externalExecutor = new ScheduledThreadPoolExecutor(1);
        final TimedSemaphore sem = TimedSemaphore.builder().setService(externalExecutor).setPeriod(1L).setTimeUnit(TimeUnit.DAYS).setLimit(1).get();
        assertSame(externalExecutor, sem.getExecutorService());
        sem.acquire();
        sem.shutdown();
        assertFalse(externalExecutor.isShutdown());
        externalExecutor.shutdownNow();
    }

    @Test
    public void testBuilderReturnsNewInstanceEachTime() {
        final TimedSemaphore.Builder b1 = TimedSemaphore.builder();
        final TimedSemaphore.Builder b2 = TimedSemaphore.builder();
        assertNotNull(b1);
        assertNotNull(b2);
        assertFalse(b1 == b2);
    }
}
