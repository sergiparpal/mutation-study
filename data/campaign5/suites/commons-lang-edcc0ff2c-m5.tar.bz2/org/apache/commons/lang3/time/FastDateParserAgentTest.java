/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link FastDateParser}.
 */
class FastDateParserAgentTest {

    private static final TimeZone GMT = TimeZone.getTimeZone("GMT");

    private static FastDateParser newParser(final String pattern) {
        return new FastDateParser(pattern, GMT, Locale.US);
    }

    @Test
    void testParseSimpleDate() throws ParseException {
        final FastDateParser parser = newParser("yyyy-MM-dd");
        final Date date = parser.parse("2003-02-10");
        final Calendar cal = Calendar.getInstance(GMT, Locale.US);
        cal.setTime(date);
        assertEquals(2003, cal.get(Calendar.YEAR));
        assertEquals(Calendar.FEBRUARY, cal.get(Calendar.MONTH));
        assertEquals(10, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseWithTimeFields() throws ParseException {
        final FastDateParser parser = newParser("yyyy-MM-dd HH:mm:ss");
        final Date date = parser.parse("2020-12-31 23:59:58");
        final Calendar cal = Calendar.getInstance(GMT, Locale.US);
        cal.setTime(date);
        assertEquals(2020, cal.get(Calendar.YEAR));
        assertEquals(Calendar.DECEMBER, cal.get(Calendar.MONTH));
        assertEquals(31, cal.get(Calendar.DAY_OF_MONTH));
        assertEquals(23, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals(59, cal.get(Calendar.MINUTE));
        assertEquals(58, cal.get(Calendar.SECOND));
    }

    @Test
    void testParseThrowsParseExceptionOnUnparseable() {
        final FastDateParser parser = newParser("yyyy-MM-dd");
        final ParseException e = assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                parser.parse("not-a-date");
            }
        });
        assertTrue(e.getMessage().contains("Unparseable date"));
        assertEquals(0, e.getErrorOffset());
    }

    @Test
    void testParsePartialConsumptionLeavesRemainderUnconsumed() {
        final FastDateParser parser = newParser("yyyy-MM-dd");
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("2003-02-10 trailing garbage", pos);
        assertNotNull(date);
        assertEquals(10, pos.getIndex());
    }

    @Test
    void testParseWithParsePositionFailureReturnsNullAndSetsErrorIndex() {
        final FastDateParser parser = newParser("yyyy-MM-dd");
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("abcd-02-10", pos);
        assertNull(date);
        assertEquals(0, pos.getErrorIndex());
        assertEquals(0, pos.getIndex());
    }

    @Test
    void testParseStartingMidStringUsesGivenIndex() {
        final FastDateParser parser = newParser("MM/dd/yyyy");
        final ParsePosition pos = new ParsePosition(6);
        final Date date = parser.parse("XXXXXX12/25/2021", pos);
        assertNotNull(date);
        final Calendar cal = Calendar.getInstance(GMT, Locale.US);
        cal.setTime(date);
        assertEquals(2021, cal.get(Calendar.YEAR));
        assertEquals(Calendar.DECEMBER, cal.get(Calendar.MONTH));
        assertEquals(25, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseWithPosIndexPastEndOfSourceFails() {
        final FastDateParser parser = newParser("yyyy");
        final ParsePosition pos = new ParsePosition(100);
        final Date date = parser.parse("2020", pos);
        assertNull(date);
        assertEquals(100, pos.getErrorIndex());
    }

    @Test
    void testParseIntoCalendarUpdatesCalendarFields() {
        final FastDateParser parser = newParser("yyyy-MM-dd");
        final ParsePosition pos = new ParsePosition(0);
        final Calendar cal = Calendar.getInstance(GMT, Locale.US);
        cal.clear();
        final boolean result = parser.parse("1999-07-04", pos, cal);
        assertTrue(result);
        assertEquals(1999, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JULY, cal.get(Calendar.MONTH));
        assertEquals(4, cal.get(Calendar.DAY_OF_MONTH));
        assertEquals(10, pos.getIndex());
    }

    @Test
    void testParseObjectDelegatesToParse() throws ParseException {
        final FastDateParser parser = newParser("yyyy-MM-dd");
        final Object obj = parser.parseObject("2003-02-10");
        assertTrue(obj instanceof Date);
        final ParsePosition pos = new ParsePosition(0);
        final Object obj2 = parser.parseObject("2003-02-10", pos);
        assertEquals(obj, obj2);
    }

    @Test
    void testTwoDigitYearCenturyAdjustmentWithCenturyStart() throws ParseException {
        final Calendar centuryStartCal = Calendar.getInstance(GMT, Locale.US);
        centuryStartCal.clear();
        centuryStartCal.set(1950, Calendar.JANUARY, 1);
        final FastDateParser parser = new FastDateParser("yy-MM-dd", GMT, Locale.US, centuryStartCal.getTime());

        final Date dateBelowStart = parser.parse("49-01-01");
        final Calendar calBelow = Calendar.getInstance(GMT, Locale.US);
        calBelow.setTime(dateBelowStart);
        assertEquals(2049, calBelow.get(Calendar.YEAR));

        final Date dateAtOrAboveStart = parser.parse("50-01-01");
        final Calendar calAtOrAbove = Calendar.getInstance(GMT, Locale.US);
        calAtOrAbove.setTime(dateAtOrAboveStart);
        assertEquals(1950, calAtOrAbove.get(Calendar.YEAR));
    }

    @Test
    void testGetPatternGetLocaleGetTimeZone() {
        final FastDateParser parser = newParser("yyyy-MM-dd");
        assertEquals("yyyy-MM-dd", parser.getPattern());
        assertEquals(Locale.US, parser.getLocale());
        assertEquals(GMT, parser.getTimeZone());
    }

    @Test
    void testGetTimeZoneReturnsDefensiveCopy() {
        final FastDateParser parser = newParser("yyyy-MM-dd");
        final TimeZone tz1 = parser.getTimeZone();
        tz1.setID("Something/Else");
        final TimeZone tz2 = parser.getTimeZone();
        assertEquals("GMT", tz2.getID());
    }

    @Test
    void testNullLocaleMapsToDefaultLocale() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, null);
        assertEquals(Locale.getDefault(), parser.getLocale());
    }

    @Test
    void testConstructorRejectsNullPattern() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDateParser(null, GMT, Locale.US);
            }
        });
    }

    @Test
    void testConstructorRejectsNullTimeZone() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDateParser("yyyy-MM-dd", null, Locale.US);
            }
        });
    }

    @Test
    void testUnsupportedPatternLetterThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDateParser("yyyy-nn-dd", GMT, Locale.US);
            }
        });
    }

    @Test
    void testUnterminatedQuoteThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDateParser("yyyy-MM-dd'T", GMT, Locale.US);
            }
        });
    }

    @Test
    void testEqualsAndHashCodeContract() {
        final FastDateParser p1 = newParser("yyyy-MM-dd");
        final FastDateParser p2 = newParser("yyyy-MM-dd");
        final FastDateParser p3 = newParser("MM/dd/yyyy");
        assertEquals(p1, p2);
        assertEquals(p1.hashCode(), p2.hashCode());
        assertNotEquals(p1, p3);
        assertFalse(p1.equals(null));
        assertFalse(p1.equals("not a parser"));
    }

    @Test
    void testToStringAndToStringAllContainPattern() {
        final FastDateParser parser = newParser("yyyy-MM-dd");
        assertTrue(parser.toString().contains("yyyy-MM-dd"));
        assertTrue(parser.toStringAll().contains("yyyy-MM-dd"));
    }

    @Test
    void testLiteralTextMustMatchExactly() {
        final FastDateParser parser = newParser("yyyy'-'MM'-'dd");
        final ParsePosition posGood = new ParsePosition(0);
        assertNotNull(parser.parse("2020-01-02", posGood));

        final ParsePosition posBad = new ParsePosition(0);
        assertNull(parser.parse("2020/01/02", posBad));
        assertEquals(4, posBad.getErrorIndex());
    }

    @Test
    void testDayOfWeekTextStrategyParsesFullAndAbbreviatedNames() throws ParseException {
        final FastDateParser parser = newParser("EEEE, MMMM d, yyyy");
        final Date date = parser.parse("Tuesday, February 10, 2004");
        final Calendar cal = Calendar.getInstance(GMT, Locale.US);
        cal.setTime(date);
        assertEquals(2004, cal.get(Calendar.YEAR));
        assertEquals(Calendar.FEBRUARY, cal.get(Calendar.MONTH));
        assertEquals(10, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testInvalidTextFieldValueFailsParseGracefully() {
        final FastDateParser parser = newParser("MMMM d, yyyy");
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("Blorptember 10, 2004", pos);
        assertNull(date);
    }

    @Test
    void testNumericOverflowFieldFailsParseGracefully() {
        final FastDateParser parser = newParser("yyyy");
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("99999999999999999999", pos);
        assertNull(date);
        assertTrue(pos.getErrorIndex() >= 0);
    }

    @Test
    void testTimeZoneOffsetPattern() throws ParseException {
        final FastDateParser parser = newParser("yyyy-MM-dd'T'HH:mm:ssZ");
        final Date date = parser.parse("2020-01-01T00:00:00+0200");
        final Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("GMT+02:00"), Locale.US);
        cal.setTime(date);
        assertEquals(0, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals(1, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testIso8601SingleXTimeZoneAcceptsZOrOffset() throws ParseException {
        final FastDateParser parser = newParser("yyyy-MM-dd'T'HH:mm:ssX");
        final Date zuluDate = parser.parse("2020-01-01T00:00:00Z");
        assertNotNull(zuluDate);

        final Date offsetDate = parser.parse("2020-01-01T00:00:00+05");
        assertNotNull(offsetDate);
        assertNotEquals(zuluDate, offsetDate);
    }

    @Test
    void testWeekYearPattern() throws ParseException {
        final FastDateParser parser = newParser("YYYY-'W'ww-u");
        final Date date = parser.parse("2004-W01-1");
        final GregorianCalendar expected = new GregorianCalendar(GMT, Locale.US);
        expected.clear();
        expected.setMinimalDaysInFirstWeek(4);
        expected.setFirstDayOfWeek(Calendar.MONDAY);
        expected.setWeekDate(2004, 1, Calendar.MONDAY);
        assertEquals(expected.getTime(), date);
    }

    @Test
    void testSerializationRoundTrip() throws Exception {
        final FastDateParser original = newParser("yyyy-MM-dd HH:mm:ss");
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        final ObjectOutputStream oos = new ObjectOutputStream(baos);
        oos.writeObject(original);
        oos.close();

        final ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(baos.toByteArray()));
        final FastDateParser deserialized = (FastDateParser) ois.readObject();
        ois.close();

        assertEquals(original, deserialized);
        assertEquals(original.getPattern(), deserialized.getPattern());
        final Date date = deserialized.parse("2010-05-06 07:08:09");
        final Calendar cal = Calendar.getInstance(GMT, Locale.US);
        cal.setTime(date);
        assertEquals(2010, cal.get(Calendar.YEAR));
        assertEquals(Calendar.MAY, cal.get(Calendar.MONTH));
        assertEquals(6, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testJapaneseImperialLocaleRejectsDatesBeforeEpoch() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", GMT, FastDateParser.JAPANESE_IMPERIAL);
        final ParseException e = assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                parser.parse("not-a-date");
            }
        });
        assertTrue(e.getMessage().contains("does not support dates before 1868-01-01"));
    }

    @Test
    void testAmPmStrategyParsesMorningAndAfternoon() throws ParseException {
        final FastDateParser parser = newParser("yyyy-MM-dd hh:mm a");
        final Date amDate = parser.parse("2020-01-01 11:30 AM");
        final Date pmDate = parser.parse("2020-01-01 11:30 PM");
        final Calendar amCal = Calendar.getInstance(GMT, Locale.US);
        amCal.setTime(amDate);
        final Calendar pmCal = Calendar.getInstance(GMT, Locale.US);
        pmCal.setTime(pmDate);
        assertEquals(11, amCal.get(Calendar.HOUR_OF_DAY));
        assertEquals(23, pmCal.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    void testHour24StrategyTreats24AsMidnight() throws ParseException {
        final FastDateParser parser = newParser("yyyy-MM-dd kk:mm");
        final Date date = parser.parse("2020-01-01 24:00");
        final Calendar cal = Calendar.getInstance(GMT, Locale.US);
        cal.setTime(date);
        assertEquals(0, cal.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    void testEmptySourceFailsToParse() {
        final FastDateParser parser = newParser("yyyy-MM-dd");
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("", pos);
        assertNull(date);
    }
}
