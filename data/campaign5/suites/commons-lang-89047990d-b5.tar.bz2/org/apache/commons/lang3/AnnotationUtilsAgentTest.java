/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained test class for {@link AnnotationUtils}.
 */
class AnnotationUtilsAgentTest {

    @Retention(RetentionPolicy.RUNTIME)
    private @interface Simple {
        int number() default 0;

        String value();
    }

    @Retention(RetentionPolicy.RUNTIME)
    private @interface WithArray {
        int[] values();
    }

    @Retention(RetentionPolicy.RUNTIME)
    private @interface WithNested {
        Simple nested();
    }

    private enum Color {
        RED, GREEN
    }

    @Retention(RetentionPolicy.RUNTIME)
    private @interface WithEnum {
        Color value();
    }

    @Simple(value = "hello", number = 1)
    private void method1() {
    }

    @Simple(value = "hello", number = 1)
    private void method2() {
    }

    @Simple(value = "world", number = 2)
    private void method3() {
    }

    @WithArray(values = { 1, 2, 3 })
    private void method4() {
    }

    @WithArray(values = { 1, 2, 3 })
    private void method5() {
    }

    @WithArray(values = { 1, 2, 4 })
    private void method6() {
    }

    @WithNested(nested = @Simple(value = "x", number = 9))
    private void method7() {
    }

    @WithNested(nested = @Simple(value = "x", number = 9))
    private void method8() {
    }

    @WithEnum(Color.RED)
    private void method9() {
    }

    @WithEnum(Color.GREEN)
    private void method10() {
    }

    private Annotation annotationOf(final String methodName, final Class<? extends Annotation> type)
            throws ReflectiveOperationException {
        final Method m = getClass().getDeclaredMethod(methodName);
        return m.getAnnotation(type);
    }

    @Test
    void testEqualsSameInstance() throws ReflectiveOperationException {
        final Annotation a = annotationOf("method1", Simple.class);
        assertTrue(AnnotationUtils.equals(a, a));
    }

    @Test
    void testEqualsBothNull() {
        assertTrue(AnnotationUtils.equals(null, null));
    }

    @Test
    void testEqualsOneNull() throws ReflectiveOperationException {
        final Annotation a = annotationOf("method1", Simple.class);
        assertFalse(AnnotationUtils.equals(a, null));
        assertFalse(AnnotationUtils.equals(null, a));
    }

    @Test
    void testEqualsDifferentInstancesSameValues() throws ReflectiveOperationException {
        final Annotation a1 = annotationOf("method1", Simple.class);
        final Annotation a2 = annotationOf("method2", Simple.class);
        assertFalse(a1 == a2);
        assertTrue(AnnotationUtils.equals(a1, a2));
        assertTrue(AnnotationUtils.equals(a2, a1));
    }

    @Test
    void testEqualsDifferentValues() throws ReflectiveOperationException {
        final Annotation a1 = annotationOf("method1", Simple.class);
        final Annotation a3 = annotationOf("method3", Simple.class);
        assertFalse(AnnotationUtils.equals(a1, a3));
    }

    @Test
    void testEqualsDifferentAnnotationTypes() throws ReflectiveOperationException {
        final Annotation a1 = annotationOf("method1", Simple.class);
        final Annotation arr = annotationOf("method4", WithArray.class);
        assertFalse(AnnotationUtils.equals(a1, arr));
    }

    @Test
    void testEqualsArrayMembersEqual() throws ReflectiveOperationException {
        final Annotation a4 = annotationOf("method4", WithArray.class);
        final Annotation a5 = annotationOf("method5", WithArray.class);
        assertTrue(AnnotationUtils.equals(a4, a5));
    }

    @Test
    void testEqualsArrayMembersDifferentLength() throws ReflectiveOperationException {
        final Method m = getClass().getDeclaredMethod("method4");
        final WithArray a4 = m.getAnnotation(WithArray.class);
        final WithArray shorter = new WithArray() {
            @Override
            public Class<? extends Annotation> annotationType() {
                return WithArray.class;
            }

            @Override
            public int[] values() {
                return new int[] { 1, 2 };
            }
        };
        assertFalse(AnnotationUtils.equals(a4, shorter));
    }

    @Test
    void testEqualsArrayMembersDifferentValues() throws ReflectiveOperationException {
        final Annotation a4 = annotationOf("method4", WithArray.class);
        final Annotation a6 = annotationOf("method6", WithArray.class);
        assertFalse(AnnotationUtils.equals(a4, a6));
    }

    @Test
    void testEqualsNestedAnnotationMembers() throws ReflectiveOperationException {
        final Annotation a7 = annotationOf("method7", WithNested.class);
        final Annotation a8 = annotationOf("method8", WithNested.class);
        assertTrue(AnnotationUtils.equals(a7, a8));
    }

    @Test
    void testEqualsEnumMembers() throws ReflectiveOperationException {
        final Annotation a9 = annotationOf("method9", WithEnum.class);
        final Annotation a9b = annotationOf("method9", WithEnum.class);
        final Annotation a10 = annotationOf("method10", WithEnum.class);
        assertTrue(AnnotationUtils.equals(a9, a9b));
        assertFalse(AnnotationUtils.equals(a9, a10));
    }

    @Test
    void testEqualsNullAnnotationTypeThrowsNullPointerException() {
        final InvocationHandler handler = new InvocationHandler() {
            @Override
            public Object invoke(final Object proxy, final Method method, final Object[] args) {
                if ("annotationType".equals(method.getName())) {
                    return null;
                }
                if ("value".equals(method.getName())) {
                    return "hello";
                }
                if ("number".equals(method.getName())) {
                    return 1;
                }
                return null;
            }
        };
        final Simple proxy1 = (Simple) Proxy.newProxyInstance(
                getClass().getClassLoader(), new Class[] { Simple.class }, handler);
        final Simple proxy2 = (Simple) Proxy.newProxyInstance(
                getClass().getClassLoader(), new Class[] { Simple.class }, handler);
        final NullPointerException ex = assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                AnnotationUtils.equals(proxy1, proxy2);
            }
        });
        assertNotNull(ex);
    }

    @Test
    void testHashCodeMatchesNaturalAnnotationHashCode() throws ReflectiveOperationException {
        final Annotation a1 = annotationOf("method1", Simple.class);
        assertEquals(a1.hashCode(), AnnotationUtils.hashCode(a1));
    }

    @Test
    void testHashCodeConsistentForEqualAnnotations() throws ReflectiveOperationException {
        final Annotation a1 = annotationOf("method1", Simple.class);
        final Annotation a2 = annotationOf("method2", Simple.class);
        assertEquals(AnnotationUtils.hashCode(a1), AnnotationUtils.hashCode(a2));
    }

    @Test
    void testHashCodeDifferentForDifferentAnnotations() throws ReflectiveOperationException {
        final Annotation a1 = annotationOf("method1", Simple.class);
        final Annotation a3 = annotationOf("method3", Simple.class);
        assertFalse(AnnotationUtils.hashCode(a1) == AnnotationUtils.hashCode(a3));
    }

    @Test
    void testHashCodeThrowsIllegalStateExceptionOnNullMember() {
        final Simple proxyWithNullValue = (Simple) Proxy.newProxyInstance(
                getClass().getClassLoader(), new Class[] { Simple.class }, new InvocationHandler() {
                    @Override
                    public Object invoke(final Object proxy, final Method method, final Object[] args) {
                        if ("annotationType".equals(method.getName())) {
                            return Simple.class;
                        }
                        if ("number".equals(method.getName())) {
                            return 1;
                        }
                        return null;
                    }
                });
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                AnnotationUtils.hashCode(proxyWithNullValue);
            }
        });
    }

    @Test
    void testIsValidAnnotationMemberTypeNull() {
        assertFalse(AnnotationUtils.isValidAnnotationMemberType(null));
    }

    @Test
    void testIsValidAnnotationMemberTypePrimitives() {
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(int.class));
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(boolean.class));
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(double.class));
    }

    @Test
    void testIsValidAnnotationMemberTypeStringClassEnumAnnotation() {
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(String.class));
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(Class.class));
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(Color.class));
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(Simple.class));
    }

    @Test
    void testIsValidAnnotationMemberTypeArraysOfValidTypes() {
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(int[].class));
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(String[].class));
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(Simple[].class));
    }

    @Test
    void testIsValidAnnotationMemberTypeInvalidTypes() {
        assertFalse(AnnotationUtils.isValidAnnotationMemberType(Object.class));
        assertFalse(AnnotationUtils.isValidAnnotationMemberType(Object[].class));
        assertFalse(AnnotationUtils.isValidAnnotationMemberType(Runnable.class));
    }

    @Test
    void testToStringContainsInterfaceNameAndMembers() throws ReflectiveOperationException {
        final Annotation a1 = annotationOf("method1", Simple.class);
        final String s = AnnotationUtils.toString(a1);
        assertNotNull(s);
        assertTrue(s.contains("@" + Simple.class.getName()), s);
        assertTrue(s.contains("value=hello"), s);
        assertTrue(s.contains("number=1"), s);
    }

    @Test
    void testToStringIncludesArrayMembers() throws ReflectiveOperationException {
        final Annotation a4 = annotationOf("method4", WithArray.class);
        final String s = AnnotationUtils.toString(a4);
        assertTrue(s.contains("1"), s);
        assertTrue(s.contains("2"), s);
        assertTrue(s.contains("3"), s);
    }

    @Test
    void testToStringDifferentForDifferentValues() throws ReflectiveOperationException {
        final Annotation a1 = annotationOf("method1", Simple.class);
        final Annotation a3 = annotationOf("method3", Simple.class);
        assertFalse(AnnotationUtils.toString(a1).equals(AnnotationUtils.toString(a3)));
    }

    @Test
    void testConstructorIsUsable() {
        final AnnotationUtils instance = new AnnotationUtils();
        assertNotNull(instance);
    }
}
