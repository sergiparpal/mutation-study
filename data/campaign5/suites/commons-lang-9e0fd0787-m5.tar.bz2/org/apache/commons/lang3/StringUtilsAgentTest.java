/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link StringUtils}.
 */
class StringUtilsAgentTest {

    @Test
    void testIsEmpty() {
        assertTrue(StringUtils.isEmpty(null));
        assertTrue(StringUtils.isEmpty(""));
        assertFalse(StringUtils.isEmpty(" "));
        assertFalse(StringUtils.isEmpty("bob"));
    }

    @Test
    void testIsBlank() {
        assertTrue(StringUtils.isBlank(null));
        assertTrue(StringUtils.isBlank(""));
        assertTrue(StringUtils.isBlank(" \t\n"));
        assertFalse(StringUtils.isBlank("bob"));
        assertFalse(StringUtils.isBlank("  bob  "));
    }

    @Test
    void testIsNotEmptyAndIsNotBlank() {
        assertFalse(StringUtils.isNotEmpty(null));
        assertFalse(StringUtils.isNotEmpty(""));
        assertTrue(StringUtils.isNotEmpty("abc"));

        assertFalse(StringUtils.isNotBlank(null));
        assertFalse(StringUtils.isNotBlank("   "));
        assertTrue(StringUtils.isNotBlank("abc"));
    }

    @Test
    void testTrim() {
        assertNull(StringUtils.trim(null));
        assertEquals("", StringUtils.trim(""));
        assertEquals("", StringUtils.trim("    "));
        assertEquals("abc", StringUtils.trim("  abc  "));
    }

    @Test
    void testTrimToNullAndTrimToEmpty() {
        assertNull(StringUtils.trimToNull(null));
        assertNull(StringUtils.trimToNull(""));
        assertNull(StringUtils.trimToNull("   "));
        assertEquals("abc", StringUtils.trimToNull("  abc  "));

        assertEquals("", StringUtils.trimToEmpty(null));
        assertEquals("", StringUtils.trimToEmpty("   "));
        assertEquals("abc", StringUtils.trimToEmpty("  abc  "));
    }

    @Test
    void testStripAndStripWithChars() {
        assertNull(StringUtils.strip(null));
        assertEquals("", StringUtils.strip("   "));
        assertEquals("abc", StringUtils.strip("  abc  "));

        assertNull(StringUtils.strip(null, "xyz"));
        assertEquals("abc", StringUtils.strip("xxabcxx", "x"));
        assertEquals("  abc  ", StringUtils.strip("  abc  ", ""));
    }

    @Test
    void testEquals() {
        assertTrue(StringUtils.equals(null, null));
        assertFalse(StringUtils.equals(null, "abc"));
        assertFalse(StringUtils.equals("abc", null));
        assertTrue(StringUtils.equals("abc", "abc"));
        assertFalse(StringUtils.equals("abc", "ABC"));
    }

    @Test
    void testEqualsIgnoreCase() {
        assertTrue(StringUtils.equalsIgnoreCase(null, null));
        assertFalse(StringUtils.equalsIgnoreCase(null, "abc"));
        assertTrue(StringUtils.equalsIgnoreCase("abc", "ABC"));
        assertFalse(StringUtils.equalsIgnoreCase("abc", "abd"));
    }

    @Test
    void testCompareBoundaries() {
        assertEquals(0, StringUtils.compare(null, null));
        assertTrue(StringUtils.compare(null, "a") < 0);
        assertTrue(StringUtils.compare("a", null) > 0);
        assertTrue(StringUtils.compare("a", "b") < 0);
    }

    @Test
    void testIndexOf() {
        assertEquals(-1, StringUtils.indexOf(null, "a"));
        assertEquals(-1, StringUtils.indexOf("abc", null));
        assertEquals(0, StringUtils.indexOf("", ""));
        assertEquals(2, StringUtils.indexOf("aabaabaa", "b"));
        assertEquals(2, StringUtils.indexOf("aabaabaa", "b", 2));
        assertEquals(5, StringUtils.indexOf("aabaabaa", "b", 3));
    }

    @Test
    void testLastIndexOf() {
        assertEquals(-1, StringUtils.lastIndexOf(null, "a"));
        assertEquals(-1, StringUtils.lastIndexOf("abc", null));
        assertEquals(5, StringUtils.lastIndexOf("aabaabaa", "b"));
    }

    @Test
    void testContains() {
        assertFalse(StringUtils.contains(null, "a"));
        assertFalse(StringUtils.contains("abc", null));
        assertTrue(StringUtils.contains("abc", ""));
        assertTrue(StringUtils.contains("abc", "b"));
        assertFalse(StringUtils.contains("abc", "z"));
    }

    @Test
    void testSubstringBoundaries() {
        assertNull(StringUtils.substring(null, 0));
        assertEquals("", StringUtils.substring("", 0));
        assertEquals("c", StringUtils.substring("abc", -1));
        assertEquals("abc", StringUtils.substring("abc", -100));
        assertEquals("", StringUtils.substring("abc", 100));
        assertEquals("abc", StringUtils.substring("abc", 0));

        assertNull(StringUtils.substring(null, 0, 1));
        assertEquals("", StringUtils.substring("abc", 2, 1));
        assertEquals("ab", StringUtils.substring("abc", 0, 2));
        assertEquals("ab", StringUtils.substring("abc", 0, -1));
    }

    @Test
    void testLeftRightMid() {
        assertNull(StringUtils.left(null, 2));
        assertEquals("", StringUtils.left("abc", -1));
        assertEquals("ab", StringUtils.left("abc", 2));
        assertEquals("abc", StringUtils.left("abc", 10));

        assertNull(StringUtils.right(null, 2));
        assertEquals("", StringUtils.right("abc", -1));
        assertEquals("bc", StringUtils.right("abc", 2));
        assertEquals("abc", StringUtils.right("abc", 10));

        assertNull(StringUtils.mid(null, 0, 2));
        assertEquals("", StringUtils.mid("abc", 0, -1));
        assertEquals("", StringUtils.mid("", 0, 2));
        assertEquals("bc", StringUtils.mid("abc", 1, 2));
        assertEquals("bc", StringUtils.mid("abc", 1, 10));
    }

    @Test
    void testJoinArray() {
        assertNull(StringUtils.join((Object[]) null, ','));
        assertEquals("", StringUtils.join(new Object[0], ','));
        assertEquals("a", StringUtils.join(new Object[] {"a"}, ','));
        assertEquals("a,b,c", StringUtils.join(new Object[] {"a", "b", "c"}, ','));
        assertEquals("a,,c", StringUtils.join(new Object[] {"a", null, "c"}, ','));
    }

    @Test
    void testJoinIterable() {
        List<String> list = Arrays.asList("a", "b", "c");
        assertEquals("a-b-c", StringUtils.join(list, "-"));
        assertEquals("", StringUtils.join(Arrays.asList(), "-"));
        assertNull(StringUtils.join((Iterable<?>) null, "-"));
    }

    @Test
    void testSplit() {
        assertNull(StringUtils.split(null));
        assertArrayEquals(new String[0], StringUtils.split(""));
        assertArrayEquals(new String[] {"ab", "cd", "ef"}, StringUtils.split("ab cd ef"));
        assertArrayEquals(new String[] {"ab", "cd"}, StringUtils.split("ab:cd:", ":"));
    }

    @Test
    void testReplace() {
        assertNull(StringUtils.replace(null, "a", "b"));
        assertEquals("any", StringUtils.replace("any", null, "b"));
        assertEquals("any", StringUtils.replace("any", "a", null));
        assertEquals("any", StringUtils.replace("any", "", "b"));
        assertEquals("zbczbcd", StringUtils.replace("abcabcd", "a", "z"));
        assertEquals("", StringUtils.replace("", "a", "b"));
    }

    @Test
    void testReplaceWithMax() {
        assertEquals("abcabcd", StringUtils.replace("abcabcd", "a", "z", 0));
        assertEquals("zbcabcd", StringUtils.replace("abcabcd", "a", "z", 1));
        assertEquals("zbczbcd", StringUtils.replace("abcabcd", "a", "z", 2));
        assertEquals("zbczbcd", StringUtils.replace("abcabcd", "a", "z", -1));
    }

    @Test
    void testUpperLowerCase() {
        assertNull(StringUtils.upperCase(null));
        assertEquals("", StringUtils.upperCase(""));
        assertEquals("ABC", StringUtils.upperCase("abc"));

        assertNull(StringUtils.lowerCase(null));
        assertEquals("", StringUtils.lowerCase(""));
        assertEquals("abc", StringUtils.lowerCase("ABC"));
    }

    @Test
    void testCapitalizeAndUncapitalize() {
        assertNull(StringUtils.capitalize(null));
        assertEquals("", StringUtils.capitalize(""));
        assertEquals("Cat", StringUtils.capitalize("cat"));
        assertEquals("CAt", StringUtils.capitalize("CAt"));

        assertNull(StringUtils.uncapitalize(null));
        assertEquals("", StringUtils.uncapitalize(""));
        assertEquals("cat", StringUtils.uncapitalize("Cat"));
        assertEquals("cAT", StringUtils.uncapitalize("CAT"));
    }

    @Test
    void testReverse() {
        assertNull(StringUtils.reverse(null));
        assertEquals("", StringUtils.reverse(""));
        assertEquals("cba", StringUtils.reverse("abc"));
    }

    @Test
    void testRepeat() {
        assertNull(StringUtils.repeat(null, 2));
        assertEquals("", StringUtils.repeat("ab", 0));
        assertEquals("", StringUtils.repeat("ab", -1));
        assertEquals("ababab", StringUtils.repeat("ab", 3));

        assertEquals("", StringUtils.repeat('a', -1));
        assertEquals("aaa", StringUtils.repeat('a', 3));
    }

    @Test
    void testIsNumeric() {
        assertFalse(StringUtils.isNumeric(null));
        assertFalse(StringUtils.isNumeric(""));
        assertFalse(StringUtils.isNumeric("  "));
        assertTrue(StringUtils.isNumeric("123"));
        assertFalse(StringUtils.isNumeric("12 3"));
        assertFalse(StringUtils.isNumeric("ab2c"));
        assertFalse(StringUtils.isNumeric("-123"));
        assertFalse(StringUtils.isNumeric("12.3"));
    }

    @Test
    void testIsAlphaAndIsAlphanumeric() {
        assertFalse(StringUtils.isAlpha(null));
        assertFalse(StringUtils.isAlpha(""));
        assertFalse(StringUtils.isAlpha("  "));
        assertTrue(StringUtils.isAlpha("abc"));
        assertFalse(StringUtils.isAlpha("ab2c"));
        assertFalse(StringUtils.isAlpha("ab-c"));

        assertFalse(StringUtils.isAlphanumeric(null));
        assertFalse(StringUtils.isAlphanumeric(""));
        assertTrue(StringUtils.isAlphanumeric("ab2c"));
        assertFalse(StringUtils.isAlphanumeric("ab-c"));
    }

    @Test
    void testDefaultIfEmptyAndBlank() {
        assertEquals("default", StringUtils.defaultIfEmpty(null, "default"));
        assertEquals("default", StringUtils.defaultIfEmpty("", "default"));
        assertEquals("abc", StringUtils.defaultIfEmpty("abc", "default"));

        assertEquals("default", StringUtils.defaultIfBlank(null, "default"));
        assertEquals("default", StringUtils.defaultIfBlank("   ", "default"));
        assertEquals("abc", StringUtils.defaultIfBlank("abc", "default"));
    }

    @Test
    void testStartsWithAndEndsWith() {
        assertFalse(StringUtils.startsWith(null, "abc"));
        assertFalse(StringUtils.startsWith("abcdef", null));
        assertTrue(StringUtils.startsWith("abcdef", "abc"));
        assertFalse(StringUtils.startsWith("ABCDEF", "abc"));

        assertTrue(StringUtils.startsWithIgnoreCase("ABCDEF", "abc"));

        assertFalse(StringUtils.endsWith(null, "def"));
        assertTrue(StringUtils.endsWith("abcdef", "def"));
        assertFalse(StringUtils.endsWith("ABCDEF", "def"));
        assertTrue(StringUtils.endsWithIgnoreCase("ABCDEF", "def"));
    }

    @Test
    void testAbbreviate() {
        assertNull(StringUtils.abbreviate(null, 4));
        assertEquals("", StringUtils.abbreviate("", 4));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", 7));
        assertEquals("abcd...", StringUtils.abbreviate("abcdefgh", 7));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.abbreviate("abcdefg", 3);
            }
        });
    }

    @Test
    void testCenterAndPad() {
        assertNull(StringUtils.center(null, 4));
        assertEquals("    ", StringUtils.center("", 4));
        assertEquals("ab", StringUtils.center("ab", -1));
        assertEquals("ab", StringUtils.center("ab", 0));
        assertEquals(" ab ", StringUtils.center("ab", 4));
        assertEquals("abcd", StringUtils.center("abcd", 2));

        assertNull(StringUtils.leftPad(null, 3));
        assertEquals("  ab", StringUtils.leftPad("ab", 4));
        assertEquals("ab", StringUtils.leftPad("ab", -1));
        assertEquals("ab", StringUtils.leftPad("ab", 1));

        assertNull(StringUtils.rightPad(null, 3));
        assertEquals("ab  ", StringUtils.rightPad("ab", 4));
        assertEquals("ab", StringUtils.rightPad("ab", -1));
    }

    @Test
    void testChomp() {
        assertNull(StringUtils.chomp(null));
        assertEquals("", StringUtils.chomp(""));
        assertEquals("abc", StringUtils.chomp("abc\n"));
        assertEquals("abc", StringUtils.chomp("abc\r\n"));
        assertEquals("abc", StringUtils.chomp("abc"));
    }

    @Test
    void testStripAccents() {
        assertNull(StringUtils.stripAccents(null));
        assertEquals("", StringUtils.stripAccents(""));
        assertEquals("control", StringUtils.stripAccents("control"));
        assertEquals("eclair", StringUtils.stripAccents("éclair"));
    }

    @Test
    void testCountMatches() {
        assertEquals(0, StringUtils.countMatches(null, "a"));
        assertEquals(0, StringUtils.countMatches("abcabc", null));
        assertEquals(0, StringUtils.countMatches("abcabc", ""));
        assertEquals(2, StringUtils.countMatches("abcabc", "a"));
        assertEquals(0, StringUtils.countMatches("abcabc", "z"));
    }

    @Test
    void testDeleteWhitespace() {
        assertNull(StringUtils.deleteWhitespace(null));
        assertEquals("", StringUtils.deleteWhitespace(""));
        assertEquals("abc", StringUtils.deleteWhitespace("  a b c  "));
    }

    @Test
    void testRemoveStartAndEnd() {
        assertNull(StringUtils.removeStart(null, "a"));
        assertEquals("abc", StringUtils.removeStart("abc", null));
        assertEquals("bc", StringUtils.removeStart("abc", "a"));
        assertEquals("abc", StringUtils.removeStart("abc", "x"));

        assertNull(StringUtils.removeEnd(null, "c"));
        assertEquals("abc", StringUtils.removeEnd("abc", null));
        assertEquals("ab", StringUtils.removeEnd("abc", "c"));
        assertEquals("abc", StringUtils.removeEnd("abc", "x"));
    }

    @Test
    void testChopAndLength() {
        assertNull(StringUtils.chop(null));
        assertEquals("", StringUtils.chop(""));
        assertEquals("", StringUtils.chop("x"));
        assertEquals("abc", StringUtils.chop("abcx"));

        assertEquals(0, StringUtils.length(null));
        assertEquals(0, StringUtils.length(""));
        assertEquals(3, StringUtils.length("abc"));
    }

    @Test
    void testGetLevenshteinDistance() {
        assertEquals(0, StringUtils.getLevenshteinDistance("", ""));
        assertEquals(3, StringUtils.getLevenshteinDistance("", "abc"));
        assertEquals(3, StringUtils.getLevenshteinDistance("abc", ""));
        assertEquals(0, StringUtils.getLevenshteinDistance("abc", "abc"));
        assertEquals(1, StringUtils.getLevenshteinDistance("abc", "abd"));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.getLevenshteinDistance(null, "abc");
            }
        });
    }

    @Test
    void testIndexOfAnyAndContainsAny() {
        assertEquals(-1, StringUtils.indexOfAny((CharSequence) null, "a", "b"));
        assertEquals(-1, StringUtils.indexOfAny("abc", (String[]) null));
        assertEquals(0, StringUtils.indexOfAny("abc", "a", "b"));
        assertEquals(-1, StringUtils.indexOfAny("abc", "x", "y"));

        assertFalse(StringUtils.containsAny(null, 'a'));
        assertFalse(StringUtils.containsAny("abc", (char[]) null));
        assertTrue(StringUtils.containsAny("abc", 'a', 'z'));
        assertFalse(StringUtils.containsAny("abc", 'x', 'y'));
    }

    @Test
    void testNormalizeSpace() {
        assertNull(StringUtils.normalizeSpace(null));
        assertEquals("", StringUtils.normalizeSpace(""));
        assertEquals("ab c", StringUtils.normalizeSpace("  ab   c  "));
    }

    @Test
    void testOrdinalIndexOf() {
        assertEquals(-1, StringUtils.ordinalIndexOf(null, "a", 1));
        assertEquals(-1, StringUtils.ordinalIndexOf("aabaabaa", "a", 0));
        assertEquals(0, StringUtils.ordinalIndexOf("aabaabaa", "a", 1));
        assertEquals(1, StringUtils.ordinalIndexOf("aabaabaa", "a", 2));
        assertEquals(3, StringUtils.ordinalIndexOf("aabaabaa", "a", 3));
    }

    @Test
    void testSwapCase() {
        assertNull(StringUtils.swapCase(null));
        assertEquals("", StringUtils.swapCase(""));
        assertEquals("ABcd", StringUtils.swapCase("abCD"));
    }

    @Test
    void testWrap() {
        assertNull(StringUtils.wrap(null, '"'));
        assertEquals("\"abc\"", StringUtils.wrap("abc", '"'));
        assertEquals("", StringUtils.wrap("", '"'));
    }

    @Test
    void testToStringFromBytes() {
        assertEquals("abc", StringUtils.toString("abc".getBytes(java.nio.charset.StandardCharsets.UTF_8), "UTF-8"));
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.toString(null, "UTF-8");
            }
        });
    }

    @Test
    void testUnwrap() {
        assertNull(StringUtils.unwrap(null, '"'));
        assertEquals("abc", StringUtils.unwrap("\"abc\"", '"'));
        assertEquals("abc", StringUtils.unwrap("abc", '"'));
        assertEquals("\"abc", StringUtils.unwrap("\"abc", '"'));
    }

    @Test
    void testFirstNonBlankAndFirstNonEmpty() {
        assertEquals("abc", StringUtils.firstNonBlank(null, "", "  ", "abc"));
        assertNull(StringUtils.firstNonBlank(null, "", "  "));

        assertEquals("abc", StringUtils.firstNonEmpty(null, "", "abc"));
        assertNull(StringUtils.firstNonEmpty(null, ""));
    }

    @Test
    void testConstructorIsPublicForSubclassing() {
        // StringUtils has a public constructor to allow tools that require a JavaBean
        // instance to operate, even though all methods are static.
        StringUtils instance = new StringUtils();
        assertSame(StringUtils.class, instance.getClass());
    }

    @Test
    void testIndexOfIgnoreCase() {
        assertEquals(-1, StringUtils.indexOfIgnoreCase(null, "a"));
        assertEquals(-1, StringUtils.indexOfIgnoreCase("abc", null));
        assertEquals(1, StringUtils.indexOfIgnoreCase("abc", "B"));
        assertEquals(-1, StringUtils.indexOfIgnoreCase("abc", "z"));
    }

    @Test
    void testTruncate() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.truncate("abc", -1);
            }
        });
        assertNull(StringUtils.truncate(null, 10));
        assertEquals("ab", StringUtils.truncate("abcdef", 2));
        assertEquals("abcdef", StringUtils.truncate("abcdef", 10));
    }
}
