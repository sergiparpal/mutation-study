/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link ConstructorUtils}.
 */
public class ConstructorUtilsAgentTest {

    public static class Foo {
        final String value;

        public Foo() {
            this.value = "no-arg";
        }

        public Foo(final Number n) {
            this.value = "number:" + n;
        }

        public Foo(final String s) {
            this.value = "string:" + s;
        }
    }

    public static class Multi {
        final String tag;

        public Multi(final Number n) {
            this.tag = "number";
        }

        public Multi(final Object o) {
            this.tag = "object";
        }
    }

    static class PackagePrivate {
        public PackagePrivate() {
            // empty
        }
    }

    public static class VarArgsHolder {
        final String[] items;

        public VarArgsHolder(final String... items) {
            this.items = items;
        }
    }

    @Test
    void testGetAccessibleConstructor_byClassAndParams() throws Exception {
        final Constructor<Foo> ctor = ConstructorUtils.getAccessibleConstructor(Foo.class);
        assertNotNull(ctor);
        assertEquals("no-arg", ctor.newInstance().value);
    }

    @Test
    void testGetAccessibleConstructor_byConstructor() throws Exception {
        final Constructor<Foo> raw = Foo.class.getConstructor(String.class);
        final Constructor<Foo> accessible = ConstructorUtils.getAccessibleConstructor(raw);
        assertNotNull(accessible);
        assertEquals("string:abc", accessible.newInstance("abc").value);
    }

    @Test
    void testGetAccessibleConstructor_declaringClassNotPublic() {
        final Constructor<PackagePrivate> ctor = ConstructorUtils.getAccessibleConstructor(PackagePrivate.class);
        assertNull(ctor);
    }

    @Test
    void testGetAccessibleConstructor_nonExistentSignature() {
        final Constructor<Foo> ctor = ConstructorUtils.getAccessibleConstructor(Foo.class, String.class, String.class);
        assertNull(ctor);
    }

    @Test
    void testGetAccessibleConstructor_nullClass() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ConstructorUtils.getAccessibleConstructor((Class<Foo>) null);
            }
        });
    }

    @Test
    void testGetAccessibleConstructor_nullConstructor() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ConstructorUtils.getAccessibleConstructor((Constructor<Foo>) null);
            }
        });
    }

    @Test
    void testGetMatchingAccessibleConstructor_compatible() throws Exception {
        final Constructor<Foo> ctor = ConstructorUtils.getMatchingAccessibleConstructor(Foo.class, Integer.class);
        assertNotNull(ctor);
        assertEquals("number:5", ctor.newInstance(Integer.valueOf(5)).value);
    }

    @Test
    void testGetMatchingAccessibleConstructor_declaringClassNotPublic() {
        final Constructor<PackagePrivate> ctor = ConstructorUtils.getMatchingAccessibleConstructor(PackagePrivate.class);
        assertNull(ctor);
    }

    @Test
    void testGetMatchingAccessibleConstructor_noMatch() {
        final Constructor<Foo> ctor = ConstructorUtils.getMatchingAccessibleConstructor(Foo.class, java.util.List.class);
        assertNull(ctor);
    }

    @Test
    void testInvokeConstructor_bestFitAmongCompatible() throws Exception {
        final Multi result = ConstructorUtils.invokeConstructor(Multi.class, Integer.valueOf(1));
        assertEquals("number", result.tag);
    }

    @Test
    void testInvokeConstructor_exactMatch() throws Exception {
        final Foo foo = ConstructorUtils.invokeConstructor(Foo.class, "abc");
        assertEquals("string:abc", foo.value);
    }

    @Test
    void testInvokeConstructor_noArgs() throws Exception {
        final Foo foo = ConstructorUtils.invokeConstructor(Foo.class);
        assertEquals("no-arg", foo.value);
    }

    @Test
    void testInvokeConstructor_noMatch() {
        assertThrows(NoSuchMethodException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                ConstructorUtils.invokeConstructor(Foo.class, new Object());
            }
        });
    }

    @Test
    void testInvokeConstructor_viaAssignableCompatibility() throws Exception {
        final Foo foo = ConstructorUtils.invokeConstructor(Foo.class, Integer.valueOf(5));
        assertEquals("number:5", foo.value);
    }

    @Test
    void testInvokeConstructor_withParameterTypesArray() throws Exception {
        final Foo foo = ConstructorUtils.invokeConstructor(Foo.class, new Object[] { "xyz" }, new Class<?>[] { String.class });
        assertEquals("string:xyz", foo.value);
    }

    @Test
    void testInvokeConstructor_withVarArgs() throws Exception {
        final VarArgsHolder empty = ConstructorUtils.invokeConstructor(VarArgsHolder.class);
        assertEquals(0, empty.items.length);
        final VarArgsHolder holder = ConstructorUtils.invokeConstructor(VarArgsHolder.class, "a", "b");
        assertEquals(2, holder.items.length);
        assertEquals("a", holder.items[0]);
        assertEquals("b", holder.items[1]);
    }

    @Test
    void testInvokeExactConstructor_exactMatch() throws Exception {
        final Foo foo = ConstructorUtils.invokeExactConstructor(Foo.class, "abc");
        assertEquals("string:abc", foo.value);
    }

    @Test
    void testInvokeExactConstructor_noExactMatch() {
        assertThrows(NoSuchMethodException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                ConstructorUtils.invokeExactConstructor(Foo.class, Integer.valueOf(5));
            }
        });
    }

    @Test
    void testInvokeExactConstructor_withParameterTypesArray() throws Exception {
        final Foo foo = ConstructorUtils.invokeExactConstructor(Foo.class, new Object[] { "xyz" }, new Class<?>[] { String.class });
        assertEquals("string:xyz", foo.value);
    }

    @Test
    void testInvokeTargetException() {
        // Underlying constructor throwing wraps in InvocationTargetException.
        final InvocationTargetException thrown = assertThrows(InvocationTargetException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                ConstructorUtils.invokeConstructor(Thrower.class);
            }
        });
        assertTrue(thrown.getCause() instanceof IllegalStateException);
    }

    @SuppressWarnings("deprecation")
    @Test
    void testPublicConstructor() {
        final ConstructorUtils instance = new ConstructorUtils();
        assertNotNull(instance);
    }

    public static class Thrower {
        public Thrower() {
            throw new IllegalStateException("boom");
        }
    }
}
