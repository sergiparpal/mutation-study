/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.ClassUtils.Interfaces;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link MethodUtils}.
 */
public class MethodUtilsAgentTest {

    public static class Ambiguous {
        public void foo(final Integer i, final Object o) {
            // empty
        }

        public void foo(final Object o, final Integer i) {
            // empty
        }
    }

    public static class Base {
        public String greet() {
            return "base";
        }
    }

    public static class Calc {
        @MarkerAnnotation
        public void annotated() {
            // empty
        }

        public int add(final int a, final int b) {
            return a + b;
        }

        public String concat(final String... parts) {
            final StringBuilder sb = new StringBuilder();
            for (final String p : parts) {
                sb.append(p);
            }
            return sb.toString();
        }

        public String greet(final String name) {
            return "Hello, " + name;
        }

        @MarkerAnnotation
        private void hiddenAnnotated() {
            // empty
        }

        public void notAnnotated() {
            // empty
        }

        public String ping() {
            return "pong";
        }

        private String secret() {
            return "hidden";
        }

        public static String staticGreet() {
            return "Hello";
        }

        public static String staticGreet(final String name) {
            return "Hello, " + name;
        }

        public static String staticLen(final CharSequence cs) {
            return "len:" + cs.length();
        }
    }

    public static class Derived extends Base {
        @Override
        public String greet() {
            return "derived";
        }
    }

    public interface Greetable {
        String greet();
    }

    public interface Greeter {
        String greet(String name);
    }

    static class GreetableImpl implements Greetable {
        @Override
        public String greet() {
            return "greetable";
        }
    }

    static class GreeterImpl implements Greeter {
        @Override
        public String greet(final String name) {
            return "Hi " + name;
        }
    }

    public interface Marked {
        @Deprecated
        void process(Number n);
    }

    public static class MarkedImpl implements Marked {
        public void process(final Integer i) {
            // intentionally not annotated
        }

        @SuppressWarnings("deprecation")
        @Override
        public void process(final Number n) {
            // inherited annotation on interface
        }
    }

    @Retention(RetentionPolicy.RUNTIME)
    @interface MarkerAnnotation {
        // empty
    }

    public static class Overloads {
        public String process(final Number n) {
            return "number";
        }

        public String process(final Object o) {
            return "object";
        }
    }

    public static class Thrower {
        public void boom() {
            throw new IllegalStateException("kaboom");
        }
    }

    @Test
    void testGetAccessibleMethod_byNameAndParams() {
        assertNotNull(MethodUtils.getAccessibleMethod(Calc.class, "ping"));
        assertNull(MethodUtils.getAccessibleMethod(Calc.class, "nonExistent"));
    }

    @Test
    void testGetAccessibleMethod_classAndMethod_nonPublicDeclaringClass() throws Exception {
        final Method implMethod = GreeterImpl.class.getMethod("greet", String.class);
        final Method accessible = MethodUtils.getAccessibleMethod(GreeterImpl.class, implMethod);
        assertNotNull(accessible);
        assertEquals(Greeter.class, accessible.getDeclaringClass());
    }

    @Test
    void testGetAccessibleMethod_classAndMethod_notPublicMember() throws Exception {
        final Method privateMethod = Calc.class.getDeclaredMethod("secret");
        assertNull(MethodUtils.getAccessibleMethod(Calc.class, privateMethod));
    }

    @Test
    void testGetAccessibleMethod_methodOverload_nonPublicDeclaringClass() throws Exception {
        final Method implMethod = GreeterImpl.class.getMethod("greet", String.class);
        final Method accessible = MethodUtils.getAccessibleMethod(implMethod);
        assertNotNull(accessible);
        assertEquals(Greeter.class, accessible.getDeclaringClass());
    }

    @Test
    void testGetAccessibleMethod_methodOverload_null() {
        assertNull(MethodUtils.getAccessibleMethod((Method) null));
    }

    @Test
    void testGetAnnotation_directPresent() throws Exception {
        final Method m = Calc.class.getMethod("annotated");
        assertNotNull(MethodUtils.getAnnotation(m, MarkerAnnotation.class, false, false));
    }

    @Test
    void testGetAnnotation_ignoreAccessFalse_inaccessibleReturnsNull() throws Exception {
        final Method hidden = Calc.class.getDeclaredMethod("hiddenAnnotated");
        assertNull(MethodUtils.getAnnotation(hidden, MarkerAnnotation.class, false, false));
    }

    @Test
    void testGetAnnotation_ignoreAccessTrue_inaccessibleReturnsAnnotation() throws Exception {
        final Method hidden = Calc.class.getDeclaredMethod("hiddenAnnotated");
        assertNotNull(MethodUtils.getAnnotation(hidden, MarkerAnnotation.class, false, true));
    }

    @Test
    void testGetAnnotation_notPresent() throws Exception {
        final Method m = Calc.class.getMethod("notAnnotated");
        assertNull(MethodUtils.getAnnotation(m, MarkerAnnotation.class, true, false));
    }

    @Test
    void testGetAnnotation_nullAnnotationClass() throws Exception {
        final Method m = Calc.class.getMethod("annotated");
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                MethodUtils.getAnnotation(m, null, false, false);
            }
        });
    }

    @Test
    void testGetAnnotation_nullMethod() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                MethodUtils.getAnnotation(null, MarkerAnnotation.class, false, false);
            }
        });
    }

    @Test
    void testGetAnnotation_searchSupers() throws Exception {
        final Method processNumber = MarkedImpl.class.getMethod("process", Number.class);
        assertNull(MethodUtils.getAnnotation(processNumber, Deprecated.class, false, false));
        assertNotNull(MethodUtils.getAnnotation(processNumber, Deprecated.class, true, false));
    }

    @Test
    void testGetMatchingAccessibleMethod_bestFitAmongCompatible() {
        final Method result = MethodUtils.getMatchingAccessibleMethod(Overloads.class, "process", Integer.class);
        assertNotNull(result);
        assertEquals(Number.class, result.getParameterTypes()[0]);
    }

    @Test
    void testGetMatchingAccessibleMethod_exact() {
        final Method result = MethodUtils.getMatchingAccessibleMethod(Calc.class, "add", int.class, int.class);
        assertNotNull(result);
        assertEquals("add", result.getName());
    }

    @Test
    void testGetMatchingAccessibleMethod_notFound() {
        assertNull(MethodUtils.getMatchingAccessibleMethod(Calc.class, "nonExistent"));
    }

    @Test
    void testGetMatchingMethod_ambiguousThrows() {
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                MethodUtils.getMatchingMethod(Ambiguous.class, "foo", Integer.class, Integer.class);
            }
        });
    }

    @Test
    void testGetMatchingMethod_emptyNameThrowsIAE() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                MethodUtils.getMatchingMethod(Calc.class, "");
            }
        });
    }

    @Test
    void testGetMatchingMethod_exact() {
        final Method result = MethodUtils.getMatchingMethod(Calc.class, "add", int.class, int.class);
        assertNotNull(result);
    }

    @Test
    void testGetMatchingMethod_noCandidatesReturnsNull() {
        assertNull(MethodUtils.getMatchingMethod(Calc.class, "add", String.class, String.class));
    }

    @Test
    void testGetMatchingMethod_nullClassThrowsNPE() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                MethodUtils.getMatchingMethod(null, "foo");
            }
        });
    }

    @Test
    void testGetMethodObject() {
        assertNotNull(MethodUtils.getMethodObject(Calc.class, "ping"));
        assertNull(MethodUtils.getMethodObject(Calc.class, null));
        assertNull(MethodUtils.getMethodObject(Calc.class, "nonExistent"));
    }

    @Test
    void testGetMethodsListWithAnnotation_ignoreAccessIncludesPrivate() {
        final List<Method> methods = MethodUtils.getMethodsListWithAnnotation(Calc.class, MarkerAnnotation.class, false, true);
        assertEquals(2, methods.size());
    }

    @Test
    void testGetMethodsListWithAnnotation_nullChecks() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                MethodUtils.getMethodsListWithAnnotation(null, MarkerAnnotation.class);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                MethodUtils.getMethodsListWithAnnotation(Calc.class, null);
            }
        });
    }

    @Test
    void testGetMethodsListWithAnnotation_publicOnly() {
        final List<Method> methods = MethodUtils.getMethodsListWithAnnotation(Calc.class, MarkerAnnotation.class);
        assertEquals(1, methods.size());
        assertEquals("annotated", methods.get(0).getName());
    }

    @Test
    void testGetMethodsWithAnnotation_arrayVariant() {
        assertEquals(1, MethodUtils.getMethodsWithAnnotation(Calc.class, MarkerAnnotation.class).length);
        assertEquals(2, MethodUtils.getMethodsWithAnnotation(Calc.class, MarkerAnnotation.class, false, true).length);
    }

    @Test
    void testGetOverrideHierarchy_classHierarchy() throws Exception {
        final Method derivedGreet = Derived.class.getMethod("greet");
        final Set<Method> hierarchy = MethodUtils.getOverrideHierarchy(derivedGreet, Interfaces.EXCLUDE);
        assertEquals(2, hierarchy.size());
        final Iterator<Method> it = hierarchy.iterator();
        assertEquals(Derived.class, it.next().getDeclaringClass());
        assertEquals(Base.class, it.next().getDeclaringClass());
    }

    @Test
    void testGetOverrideHierarchy_includeVsExcludeInterfaces() throws Exception {
        final Method greet = GreetableImpl.class.getMethod("greet");
        final Set<Method> withInterfaces = MethodUtils.getOverrideHierarchy(greet, Interfaces.INCLUDE);
        final Set<Method> withoutInterfaces = MethodUtils.getOverrideHierarchy(greet, Interfaces.EXCLUDE);
        assertEquals(1, withoutInterfaces.size());
        assertTrue(withInterfaces.size() > withoutInterfaces.size());
    }

    @Test
    void testGetOverrideHierarchy_nullThrowsNPE() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                MethodUtils.getOverrideHierarchy(null, Interfaces.INCLUDE);
            }
        });
    }

    @Test
    void testInvokeExactMethod_explicitArgsAndParamTypes() throws Exception {
        final Calc calc = new Calc();
        final Object result = MethodUtils.invokeExactMethod(calc, "greet", new Object[] { "World" }, new Class<?>[] { String.class });
        assertEquals("Hello, World", result);
    }

    @Test
    void testInvokeExactMethod_noArgs() throws Exception {
        final Calc calc = new Calc();
        assertEquals("pong", MethodUtils.invokeExactMethod(calc, "ping"));
    }

    @Test
    void testInvokeExactMethod_noExactMatchThrows() {
        final Calc calc = new Calc();
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeExactMethod(calc, "concat", "a", "b");
            }
        });
    }

    @Test
    void testInvokeExactMethod_nullObjectThrowsNPE() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeExactMethod(null, "ping");
            }
        });
    }

    @Test
    void testInvokeExactMethod_varArgsExactArraySignature() throws Exception {
        final Calc calc = new Calc();
        final Object result = MethodUtils.invokeExactMethod(calc, "concat", new Object[] { new String[] { "a", "b" } }, new Class<?>[] { String[].class });
        assertEquals("ab", result);
    }

    @Test
    void testInvokeExactStaticMethod_happy() throws Exception {
        assertEquals("Hello, Bob", MethodUtils.invokeExactStaticMethod(Calc.class, "staticGreet", "Bob"));
    }

    @Test
    void testInvokeExactStaticMethod_noArgOverload() throws Exception {
        assertEquals("Hello", MethodUtils.invokeExactStaticMethod(Calc.class, "staticGreet"));
    }

    @Test
    void testInvokeExactStaticMethod_noExactMatchThrows() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeExactStaticMethod(Calc.class, "staticGreet", Integer.valueOf(5));
            }
        });
    }

    @Test
    void testInvokeMethod_assignableCompatible() throws Exception {
        final Calc calc = new Calc();
        final Object result = MethodUtils.invokeMethod(calc, "add", Integer.valueOf(1), Integer.valueOf(2));
        assertEquals(Integer.valueOf(3), result);
    }

    @Test
    void testInvokeMethod_forceAccessFalse_privateMethodThrows() {
        final Calc calc = new Calc();
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeMethod(calc, false, "secret");
            }
        });
    }

    @Test
    void testInvokeMethod_forceAccessTrue_privateMethod() throws Exception {
        final Calc calc = new Calc();
        assertEquals("hidden", MethodUtils.invokeMethod(calc, true, "secret"));
    }

    @Test
    void testInvokeMethod_invocationTargetException() {
        final Thrower thrower = new Thrower();
        final InvocationTargetException thrown = assertThrows(InvocationTargetException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeMethod(thrower, "boom");
            }
        });
        assertTrue(thrown.getCause() instanceof IllegalStateException);
    }

    @Test
    void testInvokeMethod_noArgsConvenience() throws Exception {
        final Calc calc = new Calc();
        assertEquals("pong", MethodUtils.invokeMethod(calc, "ping"));
    }

    @Test
    void testInvokeMethod_varArgs() throws Exception {
        final Calc calc = new Calc();
        assertEquals("abc", MethodUtils.invokeMethod(calc, "concat", "a", "b", "c"));
    }

    @Test
    void testInvokeMethod_varArgsExplicitArray() throws Exception {
        final Calc calc = new Calc();
        final Object result = MethodUtils.invokeMethod(calc, "concat", new Object[] { new String[] { "x", "y" } }, new Class<?>[] { String[].class });
        assertEquals("xy", result);
    }

    @Test
    void testInvokeMethod_varArgsZeroArgs() throws Exception {
        final Calc calc = new Calc();
        assertEquals("", MethodUtils.invokeMethod(calc, "concat"));
    }

    @Test
    void testInvokeStaticMethod_assignableCompatible() throws Exception {
        assertEquals("len:5", MethodUtils.invokeStaticMethod(Calc.class, "staticLen", new StringBuilder("abcde")));
    }

    @Test
    void testInvokeStaticMethod_exact() throws Exception {
        assertEquals("Hello, Zoe", MethodUtils.invokeStaticMethod(Calc.class, "staticGreet", "Zoe"));
    }

    @Test
    void testInvokeStaticMethod_noMatchThrows() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeStaticMethod(Calc.class, "staticGreet", new Object());
            }
        });
    }

    @SuppressWarnings("deprecation")
    @Test
    void testPublicConstructor() {
        final MethodUtils instance = new MethodUtils();
        assertNotNull(instance);
    }
}
