/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for the package-private {@link MemberUtils}.
 * <p>
 * This test lives in the same package so it can call MemberUtils's package-private static methods directly.
 * </p>
 */
public class MemberUtilsAgentTest {

    public static class Box {
        public Box() {
            // empty
        }

        public Box(final Integer... nums) {
            // empty
        }

        public Box(final Object o) {
            // empty
        }

        public Box(final String s) {
            // empty
        }
    }

    public static class Lines {
        public static void staticLine() {
            // empty
        }

        private void hidden() {
            // empty
        }

        public void line(final Object o) {
            // empty
        }

        public void line(final String s) {
            // empty
        }

        public void varLine(final String... parts) {
            // empty
        }
    }

    static class PackagePrivateHost {
        public void doWork() {
            // empty
        }
    }

    @Test
    void testCompareConstructorFit() throws Exception {
        final Constructor<?> exact = Box.class.getConstructor(String.class);
        final Constructor<?> generic = Box.class.getConstructor(Object.class);
        final Class<?>[] actual = { String.class };
        assertTrue(MemberUtils.compareConstructorFit(exact, generic, actual) < 0);
        assertTrue(MemberUtils.compareConstructorFit(generic, exact, actual) > 0);
        assertEquals(0, MemberUtils.compareConstructorFit(exact, exact, actual));
    }

    @Test
    void testCompareMethodFit() throws Exception {
        final Method exact = Lines.class.getMethod("line", String.class);
        final Method generic = Lines.class.getMethod("line", Object.class);
        final Class<?>[] actual = { String.class };
        assertTrue(MemberUtils.compareMethodFit(exact, generic, actual) < 0);
        assertTrue(MemberUtils.compareMethodFit(generic, exact, actual) > 0);
        assertEquals(0, MemberUtils.compareMethodFit(exact, exact, actual));
    }

    @Test
    void testIsAccessible() throws Exception {
        final Method publicMethod = Lines.class.getMethod("line", String.class);
        assertTrue(MemberUtils.isAccessible(publicMethod));
        final Method privateMethod = Lines.class.getDeclaredMethod("hidden");
        assertFalse(MemberUtils.isAccessible(privateMethod));
        assertFalse(MemberUtils.isAccessible(null));
    }

    @Test
    void testIsMatchingConstructor() throws Exception {
        final Constructor<?> stringCtor = Box.class.getConstructor(String.class);
        assertTrue(MemberUtils.isMatchingConstructor(stringCtor, new Class<?>[] { String.class }));
        assertFalse(MemberUtils.isMatchingConstructor(stringCtor, new Class<?>[] { Integer.class }));
        final Constructor<?> varArgsCtor = Box.class.getConstructor(Integer[].class);
        assertTrue(MemberUtils.isMatchingConstructor(varArgsCtor, new Class<?>[] { Integer.class, Integer.class }));
        assertTrue(MemberUtils.isMatchingConstructor(varArgsCtor, new Class<?>[0]));
        assertFalse(MemberUtils.isMatchingConstructor(varArgsCtor, new Class<?>[] { String.class }));
    }

    @Test
    void testIsMatchingMethod() throws Exception {
        final Method varArgsMethod = Lines.class.getMethod("varLine", String[].class);
        assertTrue(MemberUtils.isMatchingMethod(varArgsMethod, new Class<?>[] { String.class, String.class }));
        assertTrue(MemberUtils.isMatchingMethod(varArgsMethod, new Class<?>[0]));
        assertFalse(MemberUtils.isMatchingMethod(varArgsMethod, new Class<?>[] { Integer.class }));
    }

    @Test
    void testIsPackage() {
        assertTrue(MemberUtils.isPackage(0));
        assertTrue(MemberUtils.isPackage(Modifier.STATIC));
        assertFalse(MemberUtils.isPackage(Modifier.PUBLIC));
        assertFalse(MemberUtils.isPackage(Modifier.PROTECTED));
        assertFalse(MemberUtils.isPackage(Modifier.PRIVATE));
        assertFalse(MemberUtils.isPackage(Modifier.PUBLIC | Modifier.STATIC));
    }

    @Test
    void testIsPublic() throws Exception {
        final Method publicMethod = Lines.class.getMethod("line", String.class);
        assertTrue(MemberUtils.isPublic(publicMethod));
        final Method privateMethod = Lines.class.getDeclaredMethod("hidden");
        assertFalse(MemberUtils.isPublic(privateMethod));
        assertFalse(MemberUtils.isPublic(null));
    }

    @Test
    void testIsStatic() throws Exception {
        final Method staticMethod = Lines.class.getMethod("staticLine");
        assertTrue(MemberUtils.isStatic(staticMethod));
        final Method instanceMethod = Lines.class.getMethod("line", String.class);
        assertFalse(MemberUtils.isStatic(instanceMethod));
        assertFalse(MemberUtils.isStatic(null));
    }

    @Test
    void testSetAccessibleWorkaround_null() {
        final Method result = MemberUtils.<Method>setAccessibleWorkaround(null);
        assertSame(null, result);
    }

    @Test
    void testSetAccessibleWorkaround_packagePrivateDeclaringClass() throws Exception {
        final Method method = PackagePrivateHost.class.getMethod("doWork");
        assertFalse(method.isAccessible());
        final Method result = MemberUtils.setAccessibleWorkaround(method);
        assertSame(method, result);
        assertTrue(method.isAccessible());
    }

    @Test
    void testSetAccessibleWorkaround_publicDeclaringClassNoop() throws Exception {
        final Constructor<?> ctor = Box.class.getConstructor(String.class);
        assertFalse(ctor.isAccessible());
        final Constructor<?> result = MemberUtils.setAccessibleWorkaround(ctor);
        assertSame(ctor, result);
        assertFalse(ctor.isAccessible());
    }
}
