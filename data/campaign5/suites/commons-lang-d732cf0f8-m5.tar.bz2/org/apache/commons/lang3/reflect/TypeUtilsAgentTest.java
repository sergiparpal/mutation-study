/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.GenericArrayType;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link TypeUtils}.
 */
public class TypeUtilsAgentTest {

    interface AgentIterableFixture<T> {
    }

    interface AgentCollectionFixture<T> extends AgentIterableFixture<T> {
    }

    static class AgentListFixture<T> implements AgentCollectionFixture<T> {
    }

    static class AgentStringListFixture extends AgentListFixture<String> {
    }

    static class AgentPairFixture<K, V> {
        K key;
        V value;
    }

    static class AgentBoundedFixture<T extends Number> {
    }

    static class AgentOuterFixture<K> {
        class AgentInnerFixture<V> {
        }
    }

    static class AgentUnknownType implements Type {
        @Override
        public String toString() {
            return "agentUnknownType";
        }
    }

    @Test
    public void testGetArrayComponentTypeForClassArray() {
        assertSame(int.class, TypeUtils.getArrayComponentType(int[].class));
    }

    @Test
    public void testGetArrayComponentTypeForNonArray() {
        assertNull(TypeUtils.getArrayComponentType(String.class));
    }

    @Test
    public void testGetArrayComponentTypeForGenericArrayType() {
        final GenericArrayType arrayType = TypeUtils.genericArrayType(String.class);
        assertSame(String.class, TypeUtils.getArrayComponentType(arrayType));
    }

    @Test
    public void testIsArrayType() {
        assertTrue(TypeUtils.isArrayType(int[].class));
        assertTrue(TypeUtils.isArrayType(TypeUtils.genericArrayType(String.class)));
        assertFalse(TypeUtils.isArrayType(String.class));
    }

    @Test
    public void testGenericArrayTypeRejectsNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.genericArrayType(null);
            }
        });
    }

    @Test
    public void testGetRawTypeForClass() {
        assertSame(String.class, TypeUtils.getRawType(String.class, null));
    }

    @Test
    public void testGetRawTypeForParameterizedType() {
        final ParameterizedType pt = TypeUtils.parameterize(List.class, String.class);
        assertSame(List.class, TypeUtils.getRawType(pt, null));
    }

    @Test
    public void testGetRawTypeForGenericArrayType() {
        final GenericArrayType arrayType = TypeUtils.genericArrayType(String.class);
        assertEquals(String[].class, TypeUtils.getRawType(arrayType, null));
    }

    @Test
    public void testGetRawTypeForWildcardReturnsNull() {
        assertNull(TypeUtils.getRawType(TypeUtils.WILDCARD_ALL, null));
    }

    @Test
    public void testGetRawTypeForTypeVariableWithoutAssigningTypeReturnsNull() {
        final TypeVariable<?> tv = AgentListFixture.class.getTypeParameters()[0];
        assertNull(TypeUtils.getRawType(tv, null));
    }

    @Test
    public void testGetRawTypeForTypeVariableResolvedThroughAssigningType() {
        final TypeVariable<?> tv = AgentListFixture.class.getTypeParameters()[0];
        assertSame(String.class, TypeUtils.getRawType(tv, AgentStringListFixture.class));
    }

    @Test
    public void testGetRawTypeForUnknownTypeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.getRawType(new AgentUnknownType(), null);
            }
        });
    }

    @Test
    public void testIsAssignableBasicClasses() {
        assertTrue(TypeUtils.isAssignable(Integer.class, Number.class));
        assertFalse(TypeUtils.isAssignable(Number.class, Integer.class));
        assertTrue(TypeUtils.isAssignable(String.class, String.class));
    }

    @Test
    public void testIsAssignableNullType() {
        assertTrue(TypeUtils.isAssignable((Type) null, Integer.class));
        assertFalse(TypeUtils.isAssignable((Type) null, int.class));
        assertTrue(TypeUtils.isAssignable((Type) null, (Type) null));
    }

    @Test
    public void testIsAssignableNullToType() {
        assertFalse(TypeUtils.isAssignable(Integer.class, (Type) null));
    }

    @Test
    public void testIsAssignableGenericArrayTypeCovariance() {
        final GenericArrayType numberArray = TypeUtils.genericArrayType(Number.class);
        assertTrue(TypeUtils.isAssignable(Integer[].class, numberArray));
        assertFalse(TypeUtils.isAssignable(Number[].class, TypeUtils.genericArrayType(Integer.class)));
        assertTrue(TypeUtils.isAssignable((Type) null, numberArray));
    }

    @Test
    public void testIsAssignableRawToParameterizedAllowsUncheckedByDefault() {
        final ParameterizedType target = TypeUtils.parameterize(AgentCollectionFixture.class, String.class);
        assertTrue(TypeUtils.isAssignable(AgentListFixture.class, target));
    }

    @Test
    public void testIsAssignableParameterizedTypeArgumentMismatch() {
        final ParameterizedType from = TypeUtils.parameterize(List.class, Integer.class);
        final ParameterizedType to = TypeUtils.parameterize(List.class, String.class);
        assertFalse(TypeUtils.isAssignable(from, to));
    }

    @Test
    public void testIsInstance() {
        assertTrue(TypeUtils.isInstance("hello", String.class));
        assertFalse(TypeUtils.isInstance(Integer.valueOf(1), String.class));
        assertTrue(TypeUtils.isInstance(null, String.class));
        assertFalse(TypeUtils.isInstance(null, int.class));
        assertFalse(TypeUtils.isInstance("x", null));
    }

    @Test
    public void testEqualsForParameterizedTypes() {
        final ParameterizedType a = TypeUtils.parameterize(List.class, String.class);
        final ParameterizedType b = TypeUtils.parameterize(List.class, String.class);
        assertTrue(TypeUtils.equals(a, b));
        final ParameterizedType c = TypeUtils.parameterize(List.class, Integer.class);
        assertFalse(TypeUtils.equals(a, c));
    }

    @Test
    public void testEqualsForWildcardTypes() {
        final WildcardType a = TypeUtils.wildcardType().withUpperBounds(Number.class).build();
        final WildcardType b = TypeUtils.wildcardType().withUpperBounds(Number.class).build();
        assertTrue(TypeUtils.equals(a, b));
        assertFalse(TypeUtils.equals(a, TypeUtils.WILDCARD_ALL));
    }

    @Test
    public void testEqualsForGenericArrayTypes() {
        final GenericArrayType a = TypeUtils.genericArrayType(String.class);
        final GenericArrayType b = TypeUtils.genericArrayType(String.class);
        assertTrue(TypeUtils.equals(a, b));
        assertFalse(TypeUtils.equals(a, TypeUtils.genericArrayType(Integer.class)));
    }

    @Test
    public void testParameterize() {
        final ParameterizedType pt = TypeUtils.parameterize(List.class, String.class);
        assertSame(List.class, pt.getRawType());
        assertArrayEquals(new Type[] {String.class}, pt.getActualTypeArguments());
        assertNull(pt.getOwnerType());
    }

    @Test
    public void testParameterizeRejectsNullRawClass() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.parameterize(null, String.class);
            }
        });
    }

    @Test
    public void testParameterizeRejectsArgumentCountMismatch() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.parameterize(List.class, String.class, Integer.class);
            }
        });
    }

    @Test
    public void testParameterizeRejectsNullElementInArguments() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.parameterize(List.class, (Type) null);
            }
        });
    }

    @Test
    public void testParameterizeWithOwnerRejectsOwnerForTopLevelClass() {
        final Type owner = TypeUtils.parameterize(AgentOuterFixture.class, String.class);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.parameterizeWithOwner(owner, List.class, String.class);
            }
        });
    }

    @Test
    public void testParameterizeWithOwnerSupportsNestedGenerics() {
        final Type ownerType = TypeUtils.parameterize(AgentOuterFixture.class, String.class);
        final ParameterizedType innerType = TypeUtils.parameterizeWithOwner(ownerType, AgentOuterFixture.AgentInnerFixture.class, Integer.class);
        final Map<TypeVariable<?>, Type> typeArguments = TypeUtils.getTypeArguments(innerType);
        assertEquals(2, typeArguments.size());
        assertEquals(String.class, typeArguments.get(AgentOuterFixture.class.getTypeParameters()[0]));
        assertEquals(Integer.class, typeArguments.get(AgentOuterFixture.AgentInnerFixture.class.getTypeParameters()[0]));
    }

    @Test
    public void testWildcardTypeBuilderDefaults() {
        final WildcardType wt = TypeUtils.wildcardType().build();
        assertArrayEquals(new Type[] {Object.class}, wt.getUpperBounds());
        assertArrayEquals(new Type[0], wt.getLowerBounds());
    }

    @Test
    public void testWildcardTypeBuilderWithBounds() {
        final WildcardType wt = TypeUtils.wildcardType().withUpperBounds(Number.class).build();
        assertArrayEquals(new Type[] {Number.class}, wt.getUpperBounds());
    }

    @Test
    public void testWildcardAllConstant() {
        assertArrayEquals(new Type[] {Object.class}, TypeUtils.WILDCARD_ALL.getUpperBounds());
        assertArrayEquals(new Type[0], TypeUtils.WILDCARD_ALL.getLowerBounds());
    }

    @Test
    public void testGetImplicitBoundsNoExplicitBound() {
        final TypeVariable<?> tv = AgentListFixture.class.getTypeParameters()[0];
        assertArrayEquals(new Type[] {Object.class}, TypeUtils.getImplicitBounds(tv));
    }

    @Test
    public void testGetImplicitBoundsRejectsNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.getImplicitBounds(null);
            }
        });
    }

    @Test
    public void testGetImplicitBoundsExplicitBound() {
        final TypeVariable<?> tv = AgentBoundedFixture.class.getTypeParameters()[0];
        assertArrayEquals(new Type[] {Number.class}, TypeUtils.getImplicitBounds(tv));
    }

    @Test
    public void testGetImplicitLowerBoundsNoneReturnsNullHolder() {
        final WildcardType wt = TypeUtils.WILDCARD_ALL;
        assertArrayEquals(new Type[] {null}, TypeUtils.getImplicitLowerBounds(wt));
    }

    @Test
    public void testGetImplicitLowerBoundsRejectsNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.getImplicitLowerBounds(null);
            }
        });
    }

    @Test
    public void testGetImplicitUpperBoundsNoneReturnsObject() {
        final WildcardType wt = TypeUtils.wildcardType().build();
        assertArrayEquals(new Type[] {Object.class}, TypeUtils.getImplicitUpperBounds(wt));
    }

    @Test
    public void testGetImplicitUpperBoundsRejectsNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.getImplicitUpperBounds(null);
            }
        });
    }

    @Test
    public void testNormalizeUpperBoundsRejectsNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.normalizeUpperBounds(null);
            }
        });
    }

    @Test
    public void testNormalizeUpperBoundsFewerThanTwoReturnedAsIs() {
        final Type[] single = {String.class};
        assertSame(single, TypeUtils.normalizeUpperBounds(single));
        final Type[] empty = {};
        assertSame(empty, TypeUtils.normalizeUpperBounds(empty));
    }

    @Test
    public void testNormalizeUpperBoundsRemovesRedundantSupertype() {
        final Type[] result = TypeUtils.normalizeUpperBounds(new Type[] {Collection.class, List.class});
        assertArrayEquals(new Type[] {List.class}, result);
    }

    @Test
    public void testTypesSatisfyVariablesRejectsNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.typesSatisfyVariables(null);
            }
        });
    }

    @Test
    public void testTypesSatisfyVariablesTrueWhenWithinBound() {
        final TypeVariable<?> tv = AgentBoundedFixture.class.getTypeParameters()[0];
        final Map<TypeVariable<?>, Type> map = new HashMap<TypeVariable<?>, Type>();
        map.put(tv, Integer.class);
        assertTrue(TypeUtils.typesSatisfyVariables(map));
    }

    @Test
    public void testTypesSatisfyVariablesFalseWhenOutsideBound() {
        final TypeVariable<?> tv = AgentBoundedFixture.class.getTypeParameters()[0];
        final Map<TypeVariable<?>, Type> map = new HashMap<TypeVariable<?>, Type>();
        map.put(tv, String.class);
        assertFalse(TypeUtils.typesSatisfyVariables(map));
    }

    @Test
    public void testToStringForClass() {
        assertEquals(String.class.getName(), TypeUtils.toString(String.class));
    }

    @Test
    public void testToStringForArrayClass() {
        assertEquals("int[]", TypeUtils.toString(int[].class));
    }

    @Test
    public void testToStringRejectsNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.toString((Type) null);
            }
        });
    }

    @Test
    public void testToLongString() {
        final TypeVariable<?> tv = AgentPairFixture.class.getTypeParameters()[0];
        final String longString = TypeUtils.toLongString(tv);
        assertTrue(longString.contains(AgentPairFixture.class.getSimpleName()));
        assertTrue(longString.endsWith(":K"));
    }

    @Test
    public void testToLongStringRejectsNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.toLongString(null);
            }
        });
    }

    @Test
    public void testContainsTypeVariables() {
        assertFalse(TypeUtils.containsTypeVariables(String.class));
        assertTrue(TypeUtils.containsTypeVariables(AgentPairFixture.class));
        assertFalse(TypeUtils.containsTypeVariables(TypeUtils.parameterize(List.class, String.class)));
        final TypeVariable<?> tv = AgentPairFixture.class.getTypeParameters()[0];
        assertTrue(TypeUtils.containsTypeVariables(TypeUtils.parameterize(List.class, tv)));
    }

    @Test
    public void testGetTypeArgumentsResolvesAcrossHierarchy() {
        final Map<TypeVariable<?>, Type> result = TypeUtils.getTypeArguments(AgentStringListFixture.class, AgentIterableFixture.class);
        assertNotNull(result);
        final TypeVariable<?> iterableT = AgentIterableFixture.class.getTypeParameters()[0];
        assertEquals(String.class, result.get(iterableT));
    }

    @Test
    public void testGetTypeArgumentsIncompatibleTypesReturnsNull() {
        assertNull(TypeUtils.getTypeArguments(String.class, List.class));
    }

    @Test
    public void testGetTypeArgumentsForParameterizedType() {
        final ParameterizedType pt = TypeUtils.parameterize(List.class, String.class);
        final Map<TypeVariable<?>, Type> result = TypeUtils.getTypeArguments(pt);
        assertEquals(1, result.size());
        assertEquals(String.class, result.get(List.class.getTypeParameters()[0]));
    }

    @Test
    public void testDetermineTypeArgumentsRejectsNullArguments() {
        final ParameterizedType pt = TypeUtils.parameterize(List.class, String.class);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.determineTypeArguments(null, pt);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.determineTypeArguments(List.class, null);
            }
        });
    }

    @Test
    public void testDetermineTypeArgumentsIncompatibleReturnsNull() {
        final ParameterizedType pt = TypeUtils.parameterize(List.class, String.class);
        assertNull(TypeUtils.determineTypeArguments(String.class, pt));
    }

    @Test
    public void testDetermineTypeArgumentsResolvesThroughInterfaceHierarchy() {
        final ParameterizedType superType = TypeUtils.parameterize(AgentIterableFixture.class, String.class);
        final Map<TypeVariable<?>, Type> result = TypeUtils.determineTypeArguments(AgentListFixture.class, superType);
        assertNotNull(result);
        final TypeVariable<?> listT = AgentListFixture.class.getTypeParameters()[0];
        assertEquals(String.class, result.get(listT));
    }

    @Test
    public void testUnrollVariablesSubstitutesTypeArgument() {
        final TypeVariable<?> t = AgentListFixture.class.getTypeParameters()[0];
        final Map<TypeVariable<?>, Type> map = new HashMap<TypeVariable<?>, Type>();
        map.put(t, String.class);
        final Type parameterizedWithVariable = TypeUtils.parameterize(AgentListFixture.class, t);
        final Type unrolled = TypeUtils.unrollVariables(map, parameterizedWithVariable);
        assertTrue(TypeUtils.equals(TypeUtils.parameterize(AgentListFixture.class, String.class), unrolled));
    }

    @Test
    public void testUnrollVariablesUnmappedVariableReturnsNull() {
        final TypeVariable<?> t = AgentListFixture.class.getTypeParameters()[0];
        assertNull(TypeUtils.unrollVariables(null, t));
    }

    @Test
    public void testWrapClass() {
        final Typed<String> typed = TypeUtils.wrap(String.class);
        assertSame(String.class, typed.getType());
    }

    @Test
    public void testWrapType() {
        final ParameterizedType pt = TypeUtils.parameterize(List.class, String.class);
        final Typed<List<String>> typed = TypeUtils.wrap((Type) pt);
        assertSame(pt, typed.getType());
    }
}
