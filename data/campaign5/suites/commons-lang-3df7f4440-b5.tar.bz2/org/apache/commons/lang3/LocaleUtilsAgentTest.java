/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import java.util.Locale;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests {@link LocaleUtils}.
 */
public class LocaleUtilsAgentTest {

    @Test
    public void testConstructorIsPublic() {
        // deprecated but public, per class javadoc
        assertNotNull(new LocaleUtils());
    }

    @Test
    public void testAvailableLocaleList() {
        final List<Locale> list = LocaleUtils.availableLocaleList();
        assertNotNull(list);
        // calling twice should return the same cached instance
        assertEquals(list, LocaleUtils.availableLocaleList());
        assertTrue(list.contains(Locale.US));
    }

    @Test
    public void testAvailableLocaleListIsUnmodifiable() {
        final List<Locale> list = LocaleUtils.availableLocaleList();
        try {
            list.add(Locale.CANADA);
            org.junit.jupiter.api.Assertions.fail("Expected UnsupportedOperationException");
        } catch (final UnsupportedOperationException expected) {
            // expected
        }
    }

    @Test
    public void testAvailableLocaleSet() {
        final Set<Locale> set = LocaleUtils.availableLocaleSet();
        assertNotNull(set);
        assertTrue(set.contains(Locale.US));
        try {
            set.add(Locale.CANADA);
            org.junit.jupiter.api.Assertions.fail("Expected UnsupportedOperationException");
        } catch (final UnsupportedOperationException expected) {
            // expected
        }
    }

    @Test
    public void testIsAvailableLocale() {
        assertTrue(LocaleUtils.isAvailableLocale(Locale.US));
        assertFalse(LocaleUtils.isAvailableLocale(new Locale("xx", "XX", "variant-does-not-exist")));
    }

    @Test
    public void testCountriesByLanguageNullReturnsEmpty() {
        final List<Locale> list = LocaleUtils.countriesByLanguage(null);
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    public void testCountriesByLanguageUnknownReturnsEmpty() {
        final List<Locale> list = LocaleUtils.countriesByLanguage("zz");
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    public void testCountriesByLanguageCached() {
        final List<Locale> list1 = LocaleUtils.countriesByLanguage("en");
        final List<Locale> list2 = LocaleUtils.countriesByLanguage("en");
        assertNotNull(list1);
        assertEquals(list1, list2);
        try {
            list1.add(Locale.US);
            org.junit.jupiter.api.Assertions.fail("Expected UnsupportedOperationException");
        } catch (final UnsupportedOperationException expected) {
            // expected
        }
    }

    @Test
    public void testLanguagesByCountryNullReturnsEmpty() {
        final List<Locale> list = LocaleUtils.languagesByCountry(null);
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    public void testLanguagesByCountryUnknownReturnsEmpty() {
        final List<Locale> list = LocaleUtils.languagesByCountry("ZZ");
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    public void testLanguagesByCountryCached() {
        final List<Locale> list1 = LocaleUtils.languagesByCountry("US");
        final List<Locale> list2 = LocaleUtils.languagesByCountry("US");
        assertNotNull(list1);
        assertEquals(list1, list2);
        try {
            list1.add(Locale.US);
            org.junit.jupiter.api.Assertions.fail("Expected UnsupportedOperationException");
        } catch (final UnsupportedOperationException expected) {
            // expected
        }
    }

    @Test
    public void testIsLanguageUndetermined() {
        assertTrue(LocaleUtils.isLanguageUndetermined(null));
        assertTrue(LocaleUtils.isLanguageUndetermined(new Locale("a")));
        assertFalse(LocaleUtils.isLanguageUndetermined(Locale.US));
        assertFalse(LocaleUtils.isLanguageUndetermined(new Locale("fr")));
    }

    @Test
    public void testLocaleLookupListSingleArg() {
        final List<Locale> list = LocaleUtils.localeLookupList(new Locale("fr", "CA", "xxx"));
        assertEquals(3, list.size());
        assertEquals(new Locale("fr", "CA", "xxx"), list.get(0));
        assertEquals(new Locale("fr", "CA"), list.get(1));
        assertEquals(new Locale("fr"), list.get(2));
    }

    @Test
    public void testLocaleLookupListNullReturnsEmpty() {
        final List<Locale> list = LocaleUtils.localeLookupList(null);
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    public void testLocaleLookupListTwoArgs() {
        final List<Locale> list = LocaleUtils.localeLookupList(new Locale("fr", "CA", "xxx"), new Locale("en"));
        assertEquals(4, list.size());
        assertEquals(new Locale("fr", "CA", "xxx"), list.get(0));
        assertEquals(new Locale("fr", "CA"), list.get(1));
        assertEquals(new Locale("fr"), list.get(2));
        assertEquals(new Locale("en"), list.get(3));
    }

    @Test
    public void testLocaleLookupListDoesNotDuplicateDefault() {
        // locale already contains the default at some point in the chain -> no duplicate
        final List<Locale> list = LocaleUtils.localeLookupList(new Locale("fr", "CA"), new Locale("fr"));
        assertEquals(2, list.size());
        assertEquals(new Locale("fr", "CA"), list.get(0));
        assertEquals(new Locale("fr"), list.get(1));
    }

    @Test
    public void testLocaleLookupListIsUnmodifiable() {
        final List<Locale> list = LocaleUtils.localeLookupList(Locale.US);
        try {
            list.add(Locale.CANADA);
            org.junit.jupiter.api.Assertions.fail("Expected UnsupportedOperationException");
        } catch (final UnsupportedOperationException expected) {
            // expected
        }
    }

    @Test
    public void testToLocaleFromLocaleNull() {
        assertEquals(Locale.getDefault(), LocaleUtils.toLocale((Locale) null));
    }

    @Test
    public void testToLocaleFromLocaleNonNull() {
        assertEquals(Locale.US, LocaleUtils.toLocale(Locale.US));
    }

    @Test
    public void testToLocaleStringNull() {
        assertNull(LocaleUtils.toLocale((String) null));
    }

    @Test
    public void testToLocaleStringEmpty() {
        final Locale locale = LocaleUtils.toLocale("");
        assertEquals("", locale.getLanguage());
        assertEquals("", locale.getCountry());
    }

    @Test
    public void testToLocaleStringLanguageOnly() {
        final Locale locale = LocaleUtils.toLocale("en");
        assertEquals("en", locale.getLanguage());
        assertEquals("", locale.getCountry());
    }

    @Test
    public void testToLocaleStringLanguageCountryUnderscore() {
        final Locale locale = LocaleUtils.toLocale("en_GB");
        assertEquals("en", locale.getLanguage());
        assertEquals("GB", locale.getCountry());
    }

    @Test
    public void testToLocaleStringLanguageCountryDash() {
        final Locale locale = LocaleUtils.toLocale("en-GB");
        assertEquals("en", locale.getLanguage());
        assertEquals("GB", locale.getCountry());
    }

    @Test
    public void testToLocaleStringNumericArea() {
        final Locale locale = LocaleUtils.toLocale("en_001");
        assertEquals("en", locale.getLanguage());
        assertEquals("001", locale.getCountry());
    }

    @Test
    public void testToLocaleStringLanguageCountryVariant() {
        final Locale locale = LocaleUtils.toLocale("en_GB_xxx");
        assertEquals("en", locale.getLanguage());
        assertEquals("GB", locale.getCountry());
        assertEquals("xxx", locale.getVariant());
    }

    @Test
    public void testToLocaleStringCountryOnlyIso() {
        final Locale locale = LocaleUtils.toLocale("US");
        assertEquals("", locale.getLanguage());
        assertEquals("US", locale.getCountry());
    }

    @Test
    public void testToLocaleStringUnderscorePrefix() {
        final Locale locale = LocaleUtils.toLocale("_GB");
        assertEquals("", locale.getLanguage());
        assertEquals("GB", locale.getCountry());
    }

    @Test
    public void testToLocaleStringUnderscorePrefixWithVariant() {
        final Locale locale = LocaleUtils.toLocale("_GB_xxx");
        assertEquals("", locale.getLanguage());
        assertEquals("GB", locale.getCountry());
        assertEquals("xxx", locale.getVariant());
    }

    @Test
    public void testToLocaleStringTooShortThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                LocaleUtils.toLocale("a");
            }
        });
    }

    @Test
    public void testToLocaleStringUnderscorePrefixTooShortThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                LocaleUtils.toLocale("_G");
            }
        });
    }

    @Test
    public void testToLocaleStringUnderscorePrefixLowerCaseThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                LocaleUtils.toLocale("_gb");
            }
        });
    }

    @Test
    public void testToLocaleStringUnderscorePrefixVariantTooShortThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                LocaleUtils.toLocale("_GBx");
            }
        });
    }

    @Test
    public void testToLocaleStringUnderscorePrefixMismatchedSeparatorThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                LocaleUtils.toLocale("_GB-xxx");
            }
        });
    }

    @Test
    public void testToLocaleStringWithHashThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                LocaleUtils.toLocale("en#GB");
            }
        });
    }

    @Test
    public void testToLocaleStringUpperCaseLanguageThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                LocaleUtils.toLocale("EN");
            }
        });
    }

    @Test
    public void testToLocaleStringLowerCaseCountryThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                LocaleUtils.toLocale("en_gb");
            }
        });
    }

    @Test
    public void testToLocaleStringInvalidFormatThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                LocaleUtils.toLocale("en_G");
            }
        });
    }

    @Test
    public void testToLocaleStringEmptyVariantThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                LocaleUtils.toLocale("en_GB_");
            }
        });
    }
}
