/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Locale;

import org.junit.jupiter.api.Test;

public class StringUtilsAgentTest {

    @Test
    public void testIsEmptyIsBlank() {
        assertTrue(StringUtils.isEmpty(null));
        assertTrue(StringUtils.isEmpty(""));
        assertFalse(StringUtils.isEmpty(" "));
        assertFalse(StringUtils.isEmpty("abc"));

        assertTrue(StringUtils.isBlank(null));
        assertTrue(StringUtils.isBlank(""));
        assertTrue(StringUtils.isBlank("   "));
        assertFalse(StringUtils.isBlank("abc"));
        assertFalse(StringUtils.isBlank(" a "));

        assertFalse(StringUtils.isNotEmpty(null));
        assertTrue(StringUtils.isNotEmpty("x"));

        assertFalse(StringUtils.isNotBlank(null));
        assertFalse(StringUtils.isNotBlank("  "));
        assertTrue(StringUtils.isNotBlank("x"));
    }

    @Test
    public void testIsAnyAllNoneBlankEmpty() {
        assertTrue(StringUtils.isAnyBlank((String) null));
        assertTrue(StringUtils.isAnyBlank("a", null));
        assertTrue(StringUtils.isAnyBlank("a", ""));
        assertFalse(StringUtils.isAnyBlank());
        assertFalse(StringUtils.isAnyBlank("a", "b"));

        assertTrue(StringUtils.isAllBlank());
        assertTrue(StringUtils.isAllBlank((String) null));
        assertTrue(StringUtils.isAllBlank(null, " "));
        assertFalse(StringUtils.isAllBlank(null, "a"));

        assertTrue(StringUtils.isAnyEmpty((String) null));
        assertTrue(StringUtils.isAnyEmpty("", "a"));
        assertFalse(StringUtils.isAnyEmpty());
        assertFalse(StringUtils.isAnyEmpty("a", "b"));

        assertTrue(StringUtils.isAllEmpty());
        assertTrue(StringUtils.isAllEmpty(null, ""));
        assertFalse(StringUtils.isAllEmpty(null, "a"));

        assertTrue(StringUtils.isNoneBlank());
        assertFalse(StringUtils.isNoneBlank("a", null));
        assertTrue(StringUtils.isNoneBlank("a", "b"));

        assertTrue(StringUtils.isNoneEmpty());
        assertFalse(StringUtils.isNoneEmpty("a", ""));
        assertTrue(StringUtils.isNoneEmpty("a", "b"));
    }

    @Test
    public void testTrimAndStrip() {
        assertNull(StringUtils.trim(null));
        assertEquals("", StringUtils.trim("   "));
        assertEquals("abc", StringUtils.trim("  abc  "));

        assertEquals("", StringUtils.trimToEmpty(null));
        assertEquals("abc", StringUtils.trimToEmpty("  abc  "));

        assertNull(StringUtils.trimToNull("   "));
        assertEquals("abc", StringUtils.trimToNull("  abc  "));

        assertNull(StringUtils.strip(null));
        assertEquals("", StringUtils.strip("  "));
        assertEquals("abc", StringUtils.strip(" \t abc \n "));

        assertEquals("abc", StringUtils.strip("xxabcxx", "x"));
        assertEquals("abcxx", StringUtils.stripStart("xxabcxx", "x"));
        assertEquals("xxabc", StringUtils.stripEnd("xxabcxx", "x"));

        assertEquals("", StringUtils.stripToEmpty(null));
        assertNull(StringUtils.stripToNull("   "));
    }

    @Test
    public void testEqualsFamily() {
        assertTrue(StringUtils.equals(null, null));
        assertFalse(StringUtils.equals(null, "abc"));
        assertFalse(StringUtils.equals("abc", null));
        assertTrue(StringUtils.equals("abc", "abc"));
        assertFalse(StringUtils.equals("abc", "abcd"));

        assertTrue(StringUtils.equalsIgnoreCase(null, null));
        assertFalse(StringUtils.equalsIgnoreCase(null, "abc"));
        assertTrue(StringUtils.equalsIgnoreCase("ABC", "abc"));
        assertFalse(StringUtils.equalsIgnoreCase("ABC", "abcd"));

        assertTrue(StringUtils.equalsAny("abc", "xyz", "abc"));
        assertFalse(StringUtils.equalsAny("abc", "xyz", "def"));
        assertFalse(StringUtils.equalsAny("abc", (CharSequence[]) null));

        assertTrue(StringUtils.equalsAnyIgnoreCase("ABC", "xyz", "abc"));
        assertFalse(StringUtils.equalsAnyIgnoreCase("ABC", "xyz", "def"));
    }

    @Test
    public void testCompare() {
        assertEquals(0, StringUtils.compare(null, null));
        assertTrue(StringUtils.compare(null, "a") < 0);
        assertTrue(StringUtils.compare("a", null) > 0);
        assertTrue(StringUtils.compare("a", "b") < 0);

        assertEquals(0, StringUtils.compare(null, null, false));
        assertTrue(StringUtils.compare(null, "a", true) < 0);
        assertTrue(StringUtils.compare(null, "a", false) > 0);

        assertTrue(StringUtils.compareIgnoreCase("A", "b") < 0);
        assertEquals(0, StringUtils.compareIgnoreCase("ABC", "abc"));
    }

    @Test
    public void testContainsFamily() {
        assertFalse(StringUtils.contains(null, "a"));
        assertFalse(StringUtils.contains("abc", null));
        assertTrue(StringUtils.contains("abc", ""));
        assertTrue(StringUtils.contains("abc", "b"));
        assertFalse(StringUtils.contains("abc", "d"));

        assertFalse(StringUtils.contains(null, 'a'));
        assertTrue(StringUtils.contains("abc", 'b'));

        assertFalse(StringUtils.containsIgnoreCase(null, "a"));
        assertTrue(StringUtils.containsIgnoreCase("abc", "B"));

        assertTrue(StringUtils.containsAny("abc", 'z', 'c'));
        assertFalse(StringUtils.containsAny("abc", 'z', 'y'));
        assertFalse(StringUtils.containsAny((CharSequence) null, 'a'));

        assertTrue(StringUtils.containsAny("abc", "xyz", "bc"));
        assertFalse(StringUtils.containsAnyIgnoreCase("abc", "XYZ"));
        assertTrue(StringUtils.containsAnyIgnoreCase("abc", "XYZ", "BC"));

        assertTrue(StringUtils.containsNone("abc", 'x', 'y'));
        assertFalse(StringUtils.containsNone("abc", 'a'));
        assertTrue(StringUtils.containsNone((CharSequence) null, 'a'));

        assertTrue(StringUtils.containsOnly("aabbcc", 'a', 'b', 'c'));
        assertFalse(StringUtils.containsOnly("aabbccd", 'a', 'b', 'c'));
        assertFalse(StringUtils.containsOnly((CharSequence) null, 'a'));
        assertFalse(StringUtils.containsOnly("", (char[]) null));

        assertTrue(StringUtils.containsWhitespace(" a"));
        assertFalse(StringUtils.containsWhitespace("abc"));
        assertFalse(StringUtils.containsWhitespace(""));
    }

    @Test
    public void testStartsEndsWith() {
        assertTrue(StringUtils.startsWith("abcdef", "abc"));
        assertFalse(StringUtils.startsWith("abcdef", "ABC"));
        assertFalse(StringUtils.startsWith(null, "abc"));
        assertTrue(StringUtils.startsWith(null, null));

        assertTrue(StringUtils.startsWithIgnoreCase("abcdef", "ABC"));
        assertTrue(StringUtils.startsWithAny("abcdef", "xyz", "abc"));
        assertFalse(StringUtils.startsWithAny("abcdef", "xyz", "def"));

        assertTrue(StringUtils.endsWith("abcdef", "def"));
        assertFalse(StringUtils.endsWith("abcdef", "DEF"));
        assertTrue(StringUtils.endsWithIgnoreCase("abcdef", "DEF"));
        assertTrue(StringUtils.endsWithAny("abcdef", "xyz", "def"));
        assertFalse(StringUtils.endsWithAny("abcdef", "xyz", "abc"));
    }

    @Test
    public void testIndexOfFamily() {
        assertEquals(-1, StringUtils.indexOf(null, "a"));
        assertEquals(-1, StringUtils.indexOf("abc", null));
        assertEquals(0, StringUtils.indexOf("", ""));
        assertEquals(1, StringUtils.indexOf("abc", "b"));

        assertEquals(1, StringUtils.indexOf("abc", "b", 0));
        assertEquals(-1, StringUtils.indexOf("abc", "b", 2));

        assertEquals(-1, StringUtils.indexOf((CharSequence) null, 'a'));
        assertEquals(1, StringUtils.indexOf("abc", 'b'));
        assertEquals(1, StringUtils.indexOf("abc", 'b', 0));

        assertEquals(-1, StringUtils.lastIndexOf(null, "a"));
        assertEquals(3, StringUtils.lastIndexOf("abcbc", "bc"));
        assertEquals(1, StringUtils.lastIndexOf("abcbc", "bc", 2));

        assertEquals(-1, StringUtils.indexOfIgnoreCase(null, "a"));
        assertEquals(0, StringUtils.indexOfIgnoreCase("ABC", "a"));

        assertEquals(5, StringUtils.lastIndexOfIgnoreCase("ABCABC", "C"));
        assertEquals(2, StringUtils.lastIndexOfIgnoreCase("ABCABC", "C", 2));

        assertEquals(0, StringUtils.indexOfAny("zzabyycdxx", 'z', 'a'));
        assertEquals(-1, StringUtils.indexOfAny("abc", (char[]) null));
        assertEquals(-1, StringUtils.indexOfAny((CharSequence) null, 'a'));

        assertEquals(2, StringUtils.indexOfAny("zzabyycdxx", "by", "ab"));

        assertEquals(2, StringUtils.indexOfAnyBut("zzabyycdxx", 'z'));
        assertEquals(3, StringUtils.indexOfAnyBut("zzabyycdxx", "za"));

        assertEquals(-1, StringUtils.indexOfDifference("abc", "abc"));
        assertEquals(1, StringUtils.indexOfDifference("abc", "aXc"));
        assertEquals(0, StringUtils.indexOfDifference(null, "abc"));

        assertEquals(3, StringUtils.lastIndexOfAny("zzabyycdxx", "by", "ab"));

        assertEquals(4, StringUtils.ordinalIndexOf("aabaabaa", "a", 4));
        assertEquals(-1, StringUtils.ordinalIndexOf(null, "a", 1));

        assertEquals(3, StringUtils.lastOrdinalIndexOf("aabaabaa", "a", 4));
    }

    @Test
    public void testCountMatches() {
        assertEquals(0, StringUtils.countMatches(null, 'a'));
        assertEquals(0, StringUtils.countMatches("", 'a'));
        assertEquals(4, StringUtils.countMatches("aXaXaXbXb", 'X'));

        assertEquals(0, StringUtils.countMatches(null, "ab"));
        assertEquals(0, StringUtils.countMatches("abba", ""));
        assertEquals(2, StringUtils.countMatches("abab", "ab"));
    }

    @Test
    public void testSubstringFamily() {
        assertNull(StringUtils.substring(null, 0));
        assertEquals("", StringUtils.substring("", 1));
        assertEquals("cde", StringUtils.substring("abcde", 2));
        assertEquals("de", StringUtils.substring("abcde", -2));
        assertEquals("", StringUtils.substring("abcde", 10));

        assertNull(StringUtils.substring(null, 0, 1));
        assertEquals("bc", StringUtils.substring("abcde", 1, 3));
        assertEquals("abc", StringUtils.substring("abcde", 0, -2));
        assertEquals("", StringUtils.substring("abcde", 3, 1));

        assertNull(StringUtils.substringAfter(null, "a"));
        assertEquals("", StringUtils.substringAfter("", "a"));
        assertEquals("", StringUtils.substringAfter("abc", "d"));
        assertEquals("bc", StringUtils.substringAfter("abc", "a"));
        assertEquals("abcba", StringUtils.substringAfter("abcba", ""));

        assertEquals("bc", StringUtils.substringAfter("abc", 'a'));

        assertNull(StringUtils.substringBefore(null, "a"));
        assertEquals("abc", StringUtils.substringBefore("abc", "d"));
        assertEquals("a", StringUtils.substringBefore("abc", "b"));
        assertEquals("", StringUtils.substringBefore("abc", 'a'));

        assertNull(StringUtils.substringAfterLast(null, "a"));
        assertEquals("", StringUtils.substringAfterLast("", "a"));
        assertEquals("al", StringUtils.substringAfterLast("abcbal", "b"));
        assertEquals("", StringUtils.substringAfterLast("abc", "c"));

        assertNull(StringUtils.substringBeforeLast(null, "a"));
        assertEquals("abc", StringUtils.substringBeforeLast("abcba", "b"));
        assertEquals("abc", StringUtils.substringBeforeLast("abc", "d"));

        assertNull(StringUtils.substringBetween(null, "tag"));
        assertEquals("bar", StringUtils.substringBetween("<foo>bar</foo>", "<foo>", "</foo>"));
        assertEquals("bar", StringUtils.substringBetween("tagbartag", "tag"));

        assertArrayEquals(new String[] {"bar", "baz"}, StringUtils.substringsBetween("[bar][baz]", "[", "]"));
        assertNull(StringUtils.substringsBetween(null, "[", "]"));
    }

    @Test
    public void testLeftRightMid() {
        assertNull(StringUtils.left(null, 3));
        assertEquals("", StringUtils.left("abc", -1));
        assertEquals("ab", StringUtils.left("abc", 2));
        assertEquals("abc", StringUtils.left("abc", 10));

        assertNull(StringUtils.right(null, 3));
        assertEquals("", StringUtils.right("abc", -1));
        assertEquals("bc", StringUtils.right("abc", 2));
        assertEquals("abc", StringUtils.right("abc", 10));

        assertNull(StringUtils.mid(null, 0, 2));
        assertEquals("", StringUtils.mid("abc", 0, -1));
        assertEquals("", StringUtils.mid("abc", 10, 2));
        assertEquals("bc", StringUtils.mid("abc", 1, 2));
        assertEquals("ab", StringUtils.mid("abc", -1, 2));
    }

    @Test
    public void testPadding() {
        assertNull(StringUtils.leftPad(null, 5));
        assertEquals("abc", StringUtils.leftPad("abc", 2));
        assertEquals("  abc", StringUtils.leftPad("abc", 5));
        assertEquals("xxabc", StringUtils.leftPad("abc", 5, 'x'));
        assertEquals("xyabc", StringUtils.leftPad("abc", 5, "xy"));

        assertNull(StringUtils.rightPad(null, 5));
        assertEquals("abc  ", StringUtils.rightPad("abc", 5));
        assertEquals("abcxx", StringUtils.rightPad("abc", 5, 'x'));
        assertEquals("abcxy", StringUtils.rightPad("abc", 5, "xy"));

        assertNull(StringUtils.center(null, 4));
        assertEquals("abc", StringUtils.center("abc", 2));
        assertEquals(" abc  ", StringUtils.center("abc", 6));
        assertEquals("xxabcxx", StringUtils.center("abc", 7, 'x'));
    }

    @Test
    public void testCaseConversion() {
        assertNull(StringUtils.upperCase(null));
        assertEquals("ABC", StringUtils.upperCase("abc"));
        assertEquals("ABC", StringUtils.upperCase("abc", Locale.ENGLISH));

        assertNull(StringUtils.lowerCase(null));
        assertEquals("abc", StringUtils.lowerCase("ABC"));
        assertEquals("abc", StringUtils.lowerCase("ABC", Locale.ENGLISH));

        assertNull(StringUtils.capitalize(null));
        assertEquals("", StringUtils.capitalize(""));
        assertEquals("Abc", StringUtils.capitalize("abc"));
        assertEquals("ABC", StringUtils.capitalize("ABC"));

        assertNull(StringUtils.uncapitalize(null));
        assertEquals("", StringUtils.uncapitalize(""));
        assertEquals("abc", StringUtils.uncapitalize("Abc"));

        assertNull(StringUtils.swapCase(null));
        assertEquals("", StringUtils.swapCase(""));
        assertEquals("ABcd", StringUtils.swapCase("abCD"));

        assertEquals("abc", StringUtils.toRootLowerCase("ABC"));
        assertEquals("ABC", StringUtils.toRootUpperCase("abc"));
        assertNull(StringUtils.toRootLowerCase(null));
        assertNull(StringUtils.toRootUpperCase(null));
    }

    @Test
    public void testIsAlphaNumericChecks() {
        assertFalse(StringUtils.isAlpha(null));
        assertFalse(StringUtils.isAlpha(""));
        assertTrue(StringUtils.isAlpha("abc"));
        assertFalse(StringUtils.isAlpha("ab2"));
        assertFalse(StringUtils.isAlpha("ab c"));

        assertFalse(StringUtils.isAlphaSpace(null));
        assertTrue(StringUtils.isAlphaSpace("ab c"));
        assertFalse(StringUtils.isAlphaSpace("ab2 c"));

        assertFalse(StringUtils.isAlphanumeric(null));
        assertTrue(StringUtils.isAlphanumeric("ab12"));
        assertFalse(StringUtils.isAlphanumeric("ab 12"));

        assertTrue(StringUtils.isAlphanumericSpace("ab 12"));
        assertFalse(StringUtils.isAlphanumericSpace("ab_12"));

        assertFalse(StringUtils.isNumeric(null));
        assertTrue(StringUtils.isNumeric("12345"));
        assertFalse(StringUtils.isNumeric("12.3"));
        assertFalse(StringUtils.isNumeric("12 3"));

        assertTrue(StringUtils.isNumericSpace("12 3"));
        assertFalse(StringUtils.isNumericSpace("12.3"));

        assertFalse(StringUtils.isWhitespace(null));
        assertTrue(StringUtils.isWhitespace("   "));
        assertTrue(StringUtils.isWhitespace(""));
        assertFalse(StringUtils.isWhitespace(" a "));

        assertFalse(StringUtils.isAllLowerCase(null));
        assertTrue(StringUtils.isAllLowerCase("abc"));
        assertFalse(StringUtils.isAllLowerCase("abC"));
        assertFalse(StringUtils.isAllLowerCase("ab c"));

        assertFalse(StringUtils.isAllUpperCase(null));
        assertTrue(StringUtils.isAllUpperCase("ABC"));
        assertFalse(StringUtils.isAllUpperCase("ABc"));

        assertFalse(StringUtils.isMixedCase(null));
        assertFalse(StringUtils.isMixedCase(""));
        assertFalse(StringUtils.isMixedCase("ABC"));
        assertTrue(StringUtils.isMixedCase("aBc"));

        assertFalse(StringUtils.isAsciiPrintable(null));
        assertTrue(StringUtils.isAsciiPrintable("abc123! "));
        assertFalse(StringUtils.isAsciiPrintable("ab\tc"));
    }

    @Test
    public void testJoin() {
        assertNull(StringUtils.join((Object[]) null, ','));
        assertEquals("", StringUtils.join(new Object[0], ','));
        assertEquals("a,b,c", StringUtils.join(new Object[] {"a", "b", "c"}, ','));
        assertEquals("a,,c", StringUtils.join(new Object[] {"a", null, "c"}, ','));

        assertEquals("a-b-c", StringUtils.join(new Object[] {"a", "b", "c"}, "-"));
        assertEquals("a-b", StringUtils.join(new Object[] {"a", "b", "c"}, "-", 0, 2));

        assertEquals("1,2,3", StringUtils.join(new int[] {1, 2, 3}, ','));
        assertEquals("2,3", StringUtils.join(new int[] {1, 2, 3}, ',', 1, 3));

        assertEquals("true,false", StringUtils.join(new boolean[] {true, false}, ','));

        assertEquals("a,b", StringUtils.join((Iterable<?>) java.util.Arrays.asList("a", "b"), ','));
        assertEquals("a,b", StringUtils.join(java.util.Arrays.asList("a", "b").iterator(), ','));

        assertEquals("a:b:c", StringUtils.joinWith(":", "a", "b", "c"));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                StringUtils.joinWith(",", (Object[]) null);
            }
        });
    }

    @Test
    public void testSplit() {
        assertNull(StringUtils.split(null));
        assertArrayEquals(new String[0], StringUtils.split(""));
        assertArrayEquals(new String[] {"ab", "cd", "ef"}, StringUtils.split("ab cd  ef"));

        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.split("a.b.c", '.'));
        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.split("a.b.c", "."));
        assertArrayEquals(new String[] {"a", "b.c"}, StringUtils.split("a.b.c", ".", 2));

        assertArrayEquals(new String[] {"ab", "", "cd"}, StringUtils.splitPreserveAllTokens("ab..cd", "."));

        assertArrayEquals(new String[] {"ab", "cd"}, StringUtils.splitByWholeSeparator("ab--cd", "--"));
        assertArrayEquals(new String[] {"a", "", "c"}, StringUtils.splitByWholeSeparatorPreserveAllTokens("a--c", "-"));

        assertArrayEquals(new String[] {"ab", "DEF", "g"}, StringUtils.splitByCharacterType("abDEFg"));
        assertArrayEquals(new String[] {"ab", "DE", "Fg"}, StringUtils.splitByCharacterTypeCamelCase("abDEFg"));
    }

    @Test
    public void testReplaceAndRemove() {
        assertNull(StringUtils.replace(null, "a", "b"));
        assertEquals("bcb", StringUtils.replace("aca", "a", "b"));
        assertEquals("baa", StringUtils.replace("aaaa", "aa", "b", 1));

        assertEquals("foo", StringUtils.replaceIgnoreCase("fOO", "oo", "oo"));
        assertEquals("fzz", StringUtils.replaceIgnoreCase("fOO", "oo", "zz"));

        assertEquals("3211", StringUtils.replaceOnce("1211", "1", "3"));

        assertNull(StringUtils.remove(null, "a"));
        assertEquals("qex", StringUtils.remove("queux", "u"));
        assertEquals("qex", StringUtils.remove("queux", 'u'));

        assertNull(StringUtils.removeStart(null, "ra"));
        assertEquals("qux", StringUtils.removeStart("raqux", "ra"));
        assertEquals("raqux", StringUtils.removeStart("raqux", "xyz"));

        assertEquals("domain.com", StringUtils.removeEnd("domain.com", ""));
        assertEquals("www.domain", StringUtils.removeEnd("www.domain.com", ".com"));

        assertEquals("abc", StringUtils.removeEndIgnoreCase("abcXYZ", "xyz"));
        assertEquals("abc", StringUtils.removeStartIgnoreCase("XYZabc", "xyz"));
        assertEquals("abc", StringUtils.removeIgnoreCase("axbXc", "x"));
    }

    @Test
    public void testAppendPrependIfMissing() {
        assertNull(StringUtils.appendIfMissing(null, "x"));
        assertEquals("abcx", StringUtils.appendIfMissing("abc", "x"));
        assertEquals("abcx", StringUtils.appendIfMissing("abcx", "x"));
        assertEquals("abcX", StringUtils.appendIfMissingIgnoreCase("abcX", "x"));

        assertNull(StringUtils.prependIfMissing(null, "x"));
        assertEquals("xabc", StringUtils.prependIfMissing("abc", "x"));
        assertEquals("xabc", StringUtils.prependIfMissing("xabc", "x"));
        assertEquals("Xabc", StringUtils.prependIfMissingIgnoreCase("Xabc", "x"));
    }

    @Test
    public void testAbbreviate() {
        assertNull(StringUtils.abbreviate(null, 4));
        assertEquals("", StringUtils.abbreviate("", 4));
        assertEquals("abc...", StringUtils.abbreviate("abcdefg", 6));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", 7));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                StringUtils.abbreviate("abcdefg", 3);
            }
        });

        assertEquals("...fg", StringUtils.abbreviate("abcdefg", 5, 5));
    }

    @Test
    public void testTruncate() {
        assertNull(StringUtils.truncate(null, 4));
        assertEquals("", StringUtils.truncate("", 4));
        assertEquals("abcd", StringUtils.truncate("abcdefg", 4));
        assertEquals("abcdefg", StringUtils.truncate("abcdefg", 10));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                StringUtils.truncate("abcdefg", -1);
            }
        });

        assertEquals("cdefg", StringUtils.truncate("abcdefg", 2, 10));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                StringUtils.truncate("abcdefg", -1, 5);
            }
        });
    }

    @Test
    public void testReverseAndRotate() {
        assertNull(StringUtils.reverse(null));
        assertEquals("", StringUtils.reverse(""));
        assertEquals("cba", StringUtils.reverse("abc"));

        assertNull(StringUtils.rotate(null, 2));
        assertEquals("abcd", StringUtils.rotate("abcd", 0));
        assertEquals("dabc", StringUtils.rotate("abcd", 1));
        assertEquals("bcda", StringUtils.rotate("abcd", -1));
    }

    @Test
    public void testDefaultIfs() {
        assertEquals("NULL", StringUtils.defaultString(null, "NULL"));
        assertEquals("abc", StringUtils.defaultString("abc", "NULL"));
        assertEquals("", StringUtils.defaultString(null));

        assertEquals("NULL", StringUtils.defaultIfEmpty("", "NULL"));
        assertEquals("abc", StringUtils.defaultIfEmpty("abc", "NULL"));

        assertEquals("NULL", StringUtils.defaultIfBlank("   ", "NULL"));
        assertEquals("abc", StringUtils.defaultIfBlank("abc", "NULL"));
    }

    @Test
    public void testFirstNonBlankEmpty() {
        assertEquals("abc", StringUtils.firstNonBlank(null, "", "  ", "abc"));
        assertNull(StringUtils.firstNonBlank(null, "", "  "));

        assertEquals("abc", StringUtils.firstNonEmpty(null, "", "abc"));
        assertNull(StringUtils.firstNonEmpty(null, ""));
    }

    @Test
    public void testLengthAndWrap() {
        assertEquals(0, StringUtils.length(null));
        assertEquals(3, StringUtils.length("abc"));

        assertNull(StringUtils.wrap(null, '"'));
        assertEquals("\"abc\"", StringUtils.wrap("abc", '"'));
        assertEquals("\"\"abc\"\"", StringUtils.wrap("\"abc\"", '"'));

        assertNull(StringUtils.unwrap(null, '"'));
        assertEquals("abc", StringUtils.unwrap("\"abc\"", '"'));
        assertEquals("abc", StringUtils.unwrap("abc", '"'));

        assertEquals("\"abc\"", StringUtils.wrapIfMissing("abc", '"'));
        assertEquals("\"abc\"", StringUtils.wrapIfMissing("\"abc\"", '"'));
    }

    @Test
    public void testDeleteAndNormalizeSpace() {
        assertNull(StringUtils.deleteWhitespace(null));
        assertEquals("", StringUtils.deleteWhitespace("   "));
        assertEquals("abc", StringUtils.deleteWhitespace(" a b c "));

        assertNull(StringUtils.normalizeSpace(null));
        assertEquals("", StringUtils.normalizeSpace("   "));
        assertEquals("ab cd", StringUtils.normalizeSpace("  ab   cd  "));
    }

    @Test
    public void testGetLevenshteinDistance() {
        assertEquals(0, StringUtils.getLevenshteinDistance("", ""));
        assertEquals(3, StringUtils.getLevenshteinDistance("", "abc"));
        assertEquals(1, StringUtils.getLevenshteinDistance("abc", "abd"));
        assertEquals(0, StringUtils.getLevenshteinDistance("abc", "abc"));

        assertEquals(-1, StringUtils.getLevenshteinDistance("abcdef", "xyz", 2));
        assertEquals(3, StringUtils.getLevenshteinDistance("abc", "xyz", 5));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                StringUtils.getLevenshteinDistance("abc", "xyz", -1);
            }
        });
    }

    @Test
    public void testGetCommonPrefixAndDigits() {
        assertEquals("", StringUtils.getCommonPrefix());
        assertEquals("", StringUtils.getCommonPrefix((String) null, "abc"));
        assertEquals("ab", StringUtils.getCommonPrefix("abcde", "abxyz"));
        assertEquals("abcde", StringUtils.getCommonPrefix("abcde", "abcde"));

        assertNull(StringUtils.getDigits(null));
        assertEquals("", StringUtils.getDigits(""));
        assertEquals("12345", StringUtils.getDigits("a1b2c3d4e5"));
    }

    @Test
    public void testToCodePointsAndValueOf() {
        assertArrayEquals(new int[] {'a', 'b', 'c'}, StringUtils.toCodePoints("abc"));
        assertArrayEquals(new int[0], StringUtils.toCodePoints(""));
        assertNull(StringUtils.toCodePoints(null));

        assertEquals("abc", StringUtils.valueOf(new char[] {'a', 'b', 'c'}));
        assertNull(StringUtils.valueOf(null));
    }

    @Test
    public void testChompAndChop() {
        assertNull(StringUtils.chomp(null));
        assertEquals("", StringUtils.chomp(""));
        assertEquals("abc", StringUtils.chomp("abc\n"));
        assertEquals("abc", StringUtils.chomp("abc\r\n"));
        assertEquals("abc", StringUtils.chomp("abc"));

        assertNull(StringUtils.chop(null));
        assertEquals("", StringUtils.chop(""));
        assertEquals("abc", StringUtils.chop("abcx"));
        assertEquals("abc", StringUtils.chop("abc\r\n"));
    }

    @Test
    public void testDifference() {
        assertNull(StringUtils.difference(null, null));
        assertEquals("abc", StringUtils.difference(null, "abc"));
        assertEquals("abc", StringUtils.difference("abc", null));
        assertEquals("", StringUtils.difference("abc", "abc"));
        assertEquals("ty", StringUtils.difference("abcde", "abcty"));
    }

    @Test
    public void testOverlayAndSame() {
        assertEquals("abef", StringUtils.overlay("abcdef", "", 2, 4));
        assertEquals("abzzzcdef", StringUtils.overlay("abcdef", "zzz", 2, 2));
        assertNull(StringUtils.overlay(null, "x", 0, 0));

        assertSame("abc", StringUtils.defaultString("abc"));
    }
}
