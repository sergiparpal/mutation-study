/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.concurrent;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Test class for {@code EventCountCircuitBreaker}.
 */
class EventCountCircuitBreakerAgentTest {

    /**
     * A subclass of {@code EventCountCircuitBreaker} whose notion of "now" is fully
     * controlled by the test so that check intervals can be crossed deterministically
     * without relying on real time.
     */
    private static final class FakeClockBreaker extends EventCountCircuitBreaker {

        private long currentTime;

        FakeClockBreaker(final int openingThreshold, final long openingInterval, final TimeUnit openingUnit,
                final int closingThreshold, final long closingInterval, final TimeUnit closingUnit) {
            super(openingThreshold, openingInterval, openingUnit, closingThreshold, closingInterval, closingUnit);
        }

        void advanceTime(final long nanos) {
            currentTime += nanos;
        }

        @Override
        long nanoTime() {
            return currentTime;
        }
    }

    /**
     * A simple listener recording every property change event it receives.
     */
    private static final class RecordingListener implements PropertyChangeListener {

        private final List<PropertyChangeEvent> events = new ArrayList<PropertyChangeEvent>();

        @Override
        public void propertyChange(final PropertyChangeEvent evt) {
            events.add(evt);
        }
    }

    @Test
    void testThreeArgConstructorUsesThresholdForBothAndSameInterval() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(5, 2, TimeUnit.SECONDS);
        assertEquals(5, breaker.getOpeningThreshold());
        assertEquals(5, breaker.getClosingThreshold());
        assertEquals(TimeUnit.SECONDS.toNanos(2), breaker.getOpeningInterval());
        assertEquals(TimeUnit.SECONDS.toNanos(2), breaker.getClosingInterval());
    }

    @Test
    void testFourArgConstructorUsesSameIntervalForBothChecks() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(10, 1, TimeUnit.MINUTES, 3);
        assertEquals(10, breaker.getOpeningThreshold());
        assertEquals(3, breaker.getClosingThreshold());
        assertEquals(TimeUnit.MINUTES.toNanos(1), breaker.getOpeningInterval());
        assertEquals(TimeUnit.MINUTES.toNanos(1), breaker.getClosingInterval());
    }

    @Test
    void testFullConstructorStoresAllDistinctValues() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(5, 2, TimeUnit.SECONDS, 3, 4, TimeUnit.SECONDS);
        assertEquals(5, breaker.getOpeningThreshold());
        assertEquals(3, breaker.getClosingThreshold());
        assertEquals(TimeUnit.SECONDS.toNanos(2), breaker.getOpeningInterval());
        assertEquals(TimeUnit.SECONDS.toNanos(4), breaker.getClosingInterval());
    }

    @Test
    void testInitialStateIsClosed() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(3, 1, TimeUnit.MINUTES);
        assertTrue(breaker.isClosed());
        assertFalse(breaker.isOpen());
        assertTrue(breaker.checkState());
    }

    @Test
    void testCheckStateWithoutIncrementNeverOpens() {
        final FakeClockBreaker breaker = new FakeClockBreaker(3, 1000, TimeUnit.NANOSECONDS, 3, 1000, TimeUnit.NANOSECONDS);
        for (int i = 0; i < 10; i++) {
            assertTrue(breaker.checkState());
            breaker.advanceTime(100);
        }
        assertTrue(breaker.isClosed());
    }

    @Test
    void testIncrementAndCheckStateOpensWhenThresholdExceeded() {
        final FakeClockBreaker breaker = new FakeClockBreaker(3, 1000, TimeUnit.NANOSECONDS, 3, 1000, TimeUnit.NANOSECONDS);
        assertTrue(breaker.incrementAndCheckState());
        assertTrue(breaker.incrementAndCheckState());
        assertTrue(breaker.incrementAndCheckState());
        assertFalse(breaker.incrementAndCheckState());
        assertTrue(breaker.isOpen());
    }

    @Test
    void testIncrementAndCheckStateIntegerNegativeThrowsAndLeavesStateUnchanged() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(3, 1, TimeUnit.MINUTES);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                breaker.incrementAndCheckState(Integer.valueOf(-1));
            }
        });
        assertTrue(breaker.isClosed());
        assertFalse(breaker.isOpen());
    }

    @Test
    void testIncrementAndCheckStateZeroDoesNotOpen() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(3, 1, TimeUnit.MINUTES);
        assertTrue(breaker.incrementAndCheckState(Integer.valueOf(0)));
        assertTrue(breaker.isClosed());
    }

    @Test
    void testOpeningThresholdZeroOpensOnFirstEvent() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(0, 1, TimeUnit.MINUTES);
        assertTrue(breaker.checkState());
        assertFalse(breaker.incrementAndCheckState());
        assertTrue(breaker.isOpen());
    }

    @Test
    void testCounterResetsOnceOpeningIntervalElapses() {
        final FakeClockBreaker breaker = new FakeClockBreaker(3, 1000, TimeUnit.NANOSECONDS, 3, 1000, TimeUnit.NANOSECONDS);
        assertTrue(breaker.incrementAndCheckState(3));
        assertTrue(breaker.isClosed());

        // Cross the opening interval boundary; the counter must restart from zero
        // instead of accumulating with the previous interval's count.
        breaker.advanceTime(2000);
        assertTrue(breaker.incrementAndCheckState(3));
        assertTrue(breaker.isClosed());
    }

    @Test
    void testCounterAccumulatesWithinSameOpeningInterval() {
        final FakeClockBreaker breaker = new FakeClockBreaker(3, 1000, TimeUnit.NANOSECONDS, 3, 1000, TimeUnit.NANOSECONDS);
        assertTrue(breaker.incrementAndCheckState(2));
        breaker.advanceTime(10);
        assertFalse(breaker.incrementAndCheckState(2));
        assertTrue(breaker.isOpen());
    }

    @Test
    void testBreakerClosesAgainWhenEventsStayBelowClosingThreshold() {
        final FakeClockBreaker breaker = new FakeClockBreaker(3, 1000, TimeUnit.NANOSECONDS, 2, 500, TimeUnit.NANOSECONDS);
        breaker.open();
        assertTrue(breaker.isOpen());

        breaker.advanceTime(600);
        assertTrue(breaker.checkState());
        assertTrue(breaker.isClosed());
    }

    @Test
    void testBreakerStaysOpenWhenEventsReachClosingThreshold() {
        final FakeClockBreaker breaker = new FakeClockBreaker(3, 1000, TimeUnit.NANOSECONDS, 2, 500, TimeUnit.NANOSECONDS);
        breaker.open();
        assertTrue(breaker.isOpen());

        assertFalse(breaker.incrementAndCheckState(3));
        assertTrue(breaker.isOpen());

        breaker.advanceTime(600);
        assertFalse(breaker.checkState());
        assertTrue(breaker.isOpen());
    }

    @Test
    void testManualOpenAndCloseResetTheCounter() {
        final FakeClockBreaker breaker = new FakeClockBreaker(3, 1000, TimeUnit.NANOSECONDS, 3, 1000, TimeUnit.NANOSECONDS);
        assertTrue(breaker.incrementAndCheckState(2));
        breaker.close();
        assertTrue(breaker.isClosed());

        // If close() had not reset the counter, 2 (previous) + 3 (now) would exceed the
        // threshold of 3 and open the breaker.
        assertTrue(breaker.incrementAndCheckState(3));
        assertTrue(breaker.isClosed());
    }

    @Test
    void testOpenIsIdempotentAndCloseIsIdempotent() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(3, 1, TimeUnit.MINUTES);
        breaker.open();
        breaker.open();
        assertTrue(breaker.isOpen());
        breaker.close();
        breaker.close();
        assertTrue(breaker.isClosed());
    }

    @Test
    void testChangeListenerIsNotifiedOnlyOnActualTransitions() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(3, 1, TimeUnit.MINUTES);
        final RecordingListener listener = new RecordingListener();
        breaker.addChangeListener(listener);

        breaker.open();
        assertEquals(1, listener.events.size());
        final PropertyChangeEvent firstEvent = listener.events.get(0);
        assertEquals(AbstractCircuitBreaker.PROPERTY_NAME, firstEvent.getPropertyName());
        assertEquals(Boolean.FALSE, firstEvent.getOldValue());
        assertEquals(Boolean.TRUE, firstEvent.getNewValue());

        // Opening an already open breaker must not fire another event.
        breaker.open();
        assertEquals(1, listener.events.size());

        breaker.close();
        assertEquals(2, listener.events.size());
        final PropertyChangeEvent secondEvent = listener.events.get(1);
        assertEquals(Boolean.TRUE, secondEvent.getOldValue());
        assertEquals(Boolean.FALSE, secondEvent.getNewValue());
    }

    @Test
    void testRemovedChangeListenerIsNoLongerNotified() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(3, 1, TimeUnit.MINUTES);
        final RecordingListener listener = new RecordingListener();
        breaker.addChangeListener(listener);
        breaker.removeChangeListener(listener);

        breaker.open();
        assertTrue(listener.events.isEmpty());
    }

    @Test
    void testNullChangeListenerIsSilentlyIgnored() {
        final EventCountCircuitBreaker breaker = new EventCountCircuitBreaker(3, 1, TimeUnit.MINUTES);
        breaker.addChangeListener(null);
        breaker.open();
        assertTrue(breaker.isOpen());
    }

}
