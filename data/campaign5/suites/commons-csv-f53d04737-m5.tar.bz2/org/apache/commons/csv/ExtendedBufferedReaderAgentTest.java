/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.apache.commons.csv.Constants.UNDEFINED;
import static org.apache.commons.io.IOUtils.EOF;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;

import org.junit.jupiter.api.Test;

/**
 * Tests for {@link ExtendedBufferedReader}.
 */
class ExtendedBufferedReaderAgentTest {

    private ExtendedBufferedReader createBufferedReader(final String s) {
        return new ExtendedBufferedReader(new StringReader(s));
    }

    @Test
    void testInitialStateBeforeAnyRead() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("abc");
        assertEquals(UNDEFINED, br.getLastChar());
        assertEquals(0, br.getLineNumber());
        assertEquals(0, br.getPosition());
        assertEquals(0, br.getBytesRead());
        br.close();
    }

    @Test
    void testCloseSetsLastCharToEofAndRejectsFurtherReads() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("abc");
        br.read();
        assertEquals('a', br.getLastChar());
        br.close();
        assertEquals(EOF, br.getLastChar());
        assertThrows(IOException.class, br::read);
    }

    @Test
    void testPositionTracksSingleCharReads() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("abcd");
        assertEquals('a', br.read());
        assertEquals(1, br.getPosition());
        assertEquals('b', br.read());
        assertEquals(2, br.getPosition());
        br.close();
    }

    @Test
    void testPositionTracksBulkReadsAndEofDoesNotAdvancePosition() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("abcd");
        final char[] buf = new char[10];
        final int n = br.read(buf, 0, 10);
        assertEquals(4, n);
        assertEquals(4, br.getPosition());
        assertEquals('d', br.getLastChar());
        // Further read at EOF must report EOF and leave lastChar as EOF, without growing position.
        final int n2 = br.read(buf, 0, 10);
        assertEquals(EOF, n2);
        assertEquals(EOF, br.getLastChar());
        // The reader adds the EOF sentinel (-1) to position on a failed bulk read.
        assertEquals(3, br.getPosition());
        br.close();
    }

    @Test
    void testReadZeroLengthReturnsZeroWithoutConsuming() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("abc");
        final char[] buf = new char[5];
        assertEquals(0, br.read(buf, 0, 0));
        assertEquals(0, br.getPosition());
        assertEquals(UNDEFINED, br.getLastChar());
        assertEquals('a', br.read());
        br.close();
    }

    @Test
    void testEmptyInputBehavior() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("");
        assertEquals(EOF, br.peek());
        assertEquals(EOF, br.read());
        assertEquals(EOF, br.getLastChar());
        assertNull(br.readLine());
        // Reaching EOF for the first time counts as an implicit terminated line.
        assertEquals(1, br.getLineNumber());
        br.close();
    }

    @Test
    void testPeekDoesNotConsumeOrAdvancePosition() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("xy");
        assertEquals('x', br.peek());
        assertEquals('x', br.peek());
        assertEquals(0, br.getPosition());
        assertEquals(UNDEFINED, br.getLastChar());
        assertEquals('x', br.read());
        assertEquals(1, br.getPosition());
        br.close();
    }

    @Test
    void testGetLineNumberBeforeAndAfterEol() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("a\nb");
        assertEquals(0, br.getLineNumber());
        br.read(); // 'a'
        assertEquals(1, br.getLineNumber()); // not yet at EOL, so counter + 1
        br.read(); // '\n'
        assertEquals(1, br.getLineNumber()); // exactly at EOL now
        br.read(); // 'b'
        assertEquals(2, br.getLineNumber());
        br.close();
    }

    @Test
    void testCrLfCountedAsSingleLine() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("a\r\nb");
        br.read(); // a
        br.read(); // \r -> line++
        assertEquals(1, br.getLineNumber());
        br.read(); // \n, previous was \r so no increment
        assertEquals(1, br.getLineNumber());
        br.read(); // b
        assertEquals(2, br.getLineNumber());
        br.close();
    }

    @Test
    void testMarkAndResetRestoreAllTrackedState() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("abc\nd");
        br.read(); // a
        br.read(); // b
        br.mark(10);
        final long positionAtMark = br.getPosition();
        final long lineAtMark = br.getLineNumber();
        final int lastCharAtMark = br.getLastChar();
        br.read(); // c
        br.read(); // \n
        br.read(); // d
        assertTrue(br.getPosition() > positionAtMark);
        br.reset();
        assertEquals(positionAtMark, br.getPosition());
        assertEquals(lineAtMark, br.getLineNumber());
        assertEquals(lastCharAtMark, br.getLastChar());
        assertEquals('c', br.read());
        br.close();
    }

    @Test
    void testReadLineDropsLineTerminatorsAndReturnsNullAtEof() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("foo\n\nbar");
        assertEquals("foo", br.readLine());
        assertEquals(1, br.getLineNumber());
        assertEquals("", br.readLine());
        assertEquals(2, br.getLineNumber());
        assertEquals("bar", br.readLine());
        assertNull(br.readLine());
        assertEquals(3, br.getLineNumber());
        br.close();
    }

    @Test
    void testReadLineOnEmptyStreamReturnsNull() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("");
        assertNull(br.readLine());
        br.close();
    }

    @Test
    void testReadLineHandlesCrLfAsOneTerminator() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("foo\r\nbar\r");
        assertEquals("foo", br.readLine());
        assertEquals("bar", br.readLine());
        assertNull(br.readLine());
        br.close();
    }

    @Test
    void testBytesReadIsZeroWithoutCharset() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("hello");
        final char[] buf = new char[10];
        br.read(buf, 0, 5);
        assertEquals(0, br.getBytesRead());
        br.close();
    }

    @Test
    void testBytesReadTracksSingleByteUtf8Characters() throws IOException {
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("abc"), StandardCharsets.UTF_8, true);
        br.read();
        assertEquals(1, br.getBytesRead());
        br.read();
        assertEquals(2, br.getBytesRead());
        br.read();
        assertEquals(3, br.getBytesRead());
        br.close();
    }

    @Test
    void testBytesReadNotIncrementedOnEof() throws IOException {
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("a"), StandardCharsets.UTF_8, true);
        br.read();
        assertEquals(1, br.getBytesRead());
        assertEquals(EOF, br.read());
        assertEquals(1, br.getBytesRead());
        br.close();
    }

    @Test
    void testBytesReadTracksMultiByteUtf8Character() throws IOException {
        // U+00E9 'é' encodes to 2 bytes in UTF-8.
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("é"), StandardCharsets.UTF_8, true);
        br.read();
        assertEquals(2, br.getBytesRead());
        br.close();
    }

    @Test
    void testBytesReadTracksSupplementaryCharacterViaBulkRead() throws IOException {
        final String input = "😀"; // a single supplementary character (surrogate pair), 4 bytes in UTF-8
        final char[] buffer = new char[input.length()];
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader(input), StandardCharsets.UTF_8, true);
        final int n = br.read(buffer, 0, buffer.length);
        assertEquals(2, n);
        assertEquals(4, br.getBytesRead());
        assertEquals(input.charAt(1), br.getLastChar());
        br.close();
    }

    @Test
    void testUnpairedLowSurrogateThrowsIOException() throws IOException {
        // A lone low surrogate with no preceding high surrogate is invalid and must fail encoding.
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("\udc00"), StandardCharsets.UTF_8, true);
        assertThrows(IOException.class, br::read);
        br.close();
    }

    @Test
    void testBytesReadWithUtf16DoesNotDoubleCountBom() throws IOException {
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("ab"), StandardCharsets.UTF_16, true);
        final char[] buf = new char[2];
        final int n = br.read(buf, 0, 2);
        assertEquals(2, n);
        // Each char is 2 bytes in UTF-16 (BOM excluded by bomLength subtraction), so 2 chars = 4 bytes.
        assertEquals(4, br.getBytesRead());
        br.close();
    }

    @Test
    void testReadMultipleBuffersAccumulatesLineNumberAcrossCalls() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("1\r\n2\r\n");
        final char[] tmp1 = new char[2];
        final char[] tmp2 = new char[4];
        br.read(tmp1, 0, 2);
        br.read(tmp2, 2, 2);
        assertEquals(2, br.getLineNumber());
        br.close();
    }

    @Test
    void testReadReturnsEofRepeatedlyAfterStreamExhausted() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("x");
        assertEquals('x', br.read());
        assertEquals(EOF, br.read());
        assertEquals(EOF, br.read());
        assertEquals(EOF, br.getLastChar());
        br.close();
    }

    @Test
    void testReadWithBufferThrowsAfterClose() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("abc");
        assertTrue(br.ready());
        br.close();
        assertThrows(IOException.class, () -> br.read(new char[1], 0, 1));
    }
}
