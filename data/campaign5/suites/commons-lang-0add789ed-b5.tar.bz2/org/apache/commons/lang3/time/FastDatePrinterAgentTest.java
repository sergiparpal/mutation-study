/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.FieldPosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link FastDatePrinter}.
 */
class FastDatePrinterAgentTest {

    private static final TimeZone UTC = TimeZone.getTimeZone("UTC");

    private static Calendar newCalendar(final int year, final int month, final int day,
            final int hour, final int minute, final int second, final int millis) {
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.clear();
        cal.set(year, month, day, hour, minute, second);
        cal.set(Calendar.MILLISECOND, millis);
        return cal;
    }

    private static FastDatePrinter newPrinter(final String pattern) {
        return new FastDatePrinter(pattern, UTC, Locale.US);
    }

    @Test
    void testFullDateTimePattern() {
        final Calendar cal = newCalendar(2023, Calendar.JUNE, 15, 14, 5, 9, 123);
        final FastDatePrinter printer = newPrinter("yyyy-MM-dd'T'HH:mm:ss.SSS");
        assertEquals("2023-06-15T14:05:09.123", printer.format(cal));
        assertEquals("2023-06-15T14:05:09.123", printer.format(cal.getTime()));
        assertEquals("2023-06-15T14:05:09.123", printer.format(cal.getTimeInMillis()));
    }

    @Test
    void testEraTextAndAmPmFields() {
        final Calendar cal = newCalendar(2023, Calendar.JUNE, 15, 14, 5, 9, 0);
        final FastDatePrinter printer = newPrinter("G EEEE MMMM MMM a");
        assertEquals("AD Thursday June Jun PM", printer.format(cal));

        final Calendar am = newCalendar(2023, Calendar.JUNE, 15, 2, 0, 0, 0);
        assertEquals("AM", newPrinter("a").format(am));
    }

    @Test
    void testTwoDigitYear() {
        assertEquals("23", newPrinter("yy").format(newCalendar(2023, Calendar.JUNE, 15, 0, 0, 0, 0)));
        assertEquals("05", newPrinter("yy").format(newCalendar(2005, Calendar.JUNE, 15, 0, 0, 0, 0)));
        assertEquals("00", newPrinter("yy").format(newCalendar(1800, Calendar.JUNE, 15, 0, 0, 0, 0)));
    }

    @Test
    void testFourDigitAndFullYear() {
        assertEquals("2023", newPrinter("yyyy").format(newCalendar(2023, Calendar.JUNE, 15, 0, 0, 0, 0)));
        // y with fewer than 2 pattern letters still gets at least 4 digits per selectNumberRule(..., max(tokenLen, 4))
        assertEquals("2023", newPrinter("y").format(newCalendar(2023, Calendar.JUNE, 15, 0, 0, 0, 0)));
        assertEquals("0023", newPrinter("y").format(newCalendar(23, Calendar.JUNE, 15, 0, 0, 0, 0)));
    }

    @Test
    void testUnpaddedAndPaddedMonth() {
        final Calendar january = newCalendar(2023, Calendar.JANUARY, 5, 0, 0, 0, 0);
        final Calendar october = newCalendar(2023, Calendar.OCTOBER, 5, 0, 0, 0, 0);
        assertEquals("1", newPrinter("M").format(january));
        assertEquals("10", newPrinter("M").format(october));
        assertEquals("01", newPrinter("MM").format(january));
        assertEquals("10", newPrinter("MM").format(october));
    }

    @Test
    void testStandaloneMonthPatternL() {
        final Calendar january = newCalendar(2023, Calendar.JANUARY, 5, 0, 0, 0, 0);
        assertEquals("1", newPrinter("L").format(january));
        assertEquals("01", newPrinter("LL").format(january));
        assertEquals("Jan", newPrinter("LLL").format(january));
        assertEquals("January", newPrinter("LLLL").format(january));
    }

    @Test
    void testHourFieldBoundariesAtMidnightAndNoon() {
        final Calendar midnight = newCalendar(2023, Calendar.JUNE, 15, 0, 0, 0, 0);
        final Calendar noon = newCalendar(2023, Calendar.JUNE, 15, 12, 0, 0, 0);

        assertEquals("12", newPrinter("h").format(midnight));
        assertEquals("0", newPrinter("H").format(midnight));
        assertEquals("24", newPrinter("k").format(midnight));
        assertEquals("0", newPrinter("K").format(midnight));

        assertEquals("12", newPrinter("h").format(noon));
        assertEquals("12", newPrinter("H").format(noon));
        assertEquals("12", newPrinter("k").format(noon));
        assertEquals("0", newPrinter("K").format(noon));
    }

    @Test
    void testHourFieldsAtRegularTime() {
        final Calendar cal = newCalendar(2023, Calendar.JUNE, 15, 14, 5, 9, 0);
        assertEquals("2", newPrinter("h").format(cal));
        assertEquals("14", newPrinter("H").format(cal));
        assertEquals("14", newPrinter("k").format(cal));
        assertEquals("2", newPrinter("K").format(cal));
    }

    @Test
    void testDayWeekAndCalendarDerivedFields() {
        final Calendar cal = newCalendar(2023, Calendar.JUNE, 15, 14, 5, 9, 0);
        assertEquals("166", newPrinter("D").format(cal));
        assertEquals("24", newPrinter("w").format(cal));
        assertEquals("3", newPrinter("W").format(cal));
        assertEquals("3", newPrinter("F").format(cal));
        // 'u' day in week: Monday=1 ... Sunday=7; Thursday -> 4
        assertEquals("4", newPrinter("u").format(cal));
    }

    @Test
    void testWeekYearPattern() {
        final Calendar cal = newCalendar(2023, Calendar.JUNE, 15, 0, 0, 0, 0);
        assertEquals("2023", newPrinter("YYYY").format(cal));
        // Non-GregorianCalendar-specific: regular year pattern should also match here
        assertEquals("2023", newPrinter("yyyy").format(cal));
    }

    @Test
    void testTimeZoneNumberPatternZ() {
        final Calendar cal = newCalendar(2023, Calendar.JUNE, 15, 0, 0, 0, 0);
        // 'Z' (1 letter) always shows numeric offset, even for zero offset (UTC)
        assertEquals("+0000", newPrinter("Z").format(cal));
        // 'ZZ' (2 letters) uses ISO 8601 rule which prints 'Z' for zero offset
        assertEquals("Z", newPrinter("ZZ").format(cal));
        // 'ZZZ' (3+ letters) uses the colon numeric rule
        assertEquals("+00:00", newPrinter("ZZZ").format(cal));

        final FastDatePrinter plusFive = new FastDatePrinter("Z", TimeZone.getTimeZone("GMT+05:30"), Locale.US);
        assertEquals("+0530", plusFive.format(cal));
        final FastDatePrinter minusEight = new FastDatePrinter("ZZZ", TimeZone.getTimeZone("GMT-08:00"), Locale.US);
        assertEquals("-08:00", minusEight.format(cal));
    }

    @Test
    void testIso8601PatternX() {
        final Calendar cal = newCalendar(2023, Calendar.JUNE, 15, 0, 0, 0, 0);
        assertEquals("Z", newPrinter("X").format(cal));
        assertEquals("Z", newPrinter("XX").format(cal));
        assertEquals("Z", newPrinter("XXX").format(cal));

        final FastDatePrinter plusFive = new FastDatePrinter("X", TimeZone.getTimeZone("GMT+05:30"), Locale.US);
        assertEquals("+05", plusFive.format(cal));
        final FastDatePrinter plusFiveXX = new FastDatePrinter("XX", TimeZone.getTimeZone("GMT+05:30"), Locale.US);
        assertEquals("+0530", plusFiveXX.format(cal));
        final FastDatePrinter plusFiveXXX = new FastDatePrinter("XXX", TimeZone.getTimeZone("GMT+05:30"), Locale.US);
        assertEquals("+05:30", plusFiveXXX.format(cal));
    }

    @Test
    void testIso8601PatternXXXXIsInvalid() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                newPrinter("XXXX");
            }
        });
    }

    @Test
    void testLiteralTextAndEscapedQuote() {
        final Calendar cal = newCalendar(2023, Calendar.JUNE, 15, 0, 0, 0, 0);
        assertEquals("Year: 2023", newPrinter("'Year: 'yyyy").format(cal));
        assertEquals("it's 2023", newPrinter("'it''s 'yyyy").format(cal));
        assertEquals("'", newPrinter("''").format(cal));
    }

    @Test
    void testInvalidPatternLetterThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new FastDatePrinter("q", UTC, Locale.US);
            }
        });
    }

    @Test
    void testNullPatternThrowsNpeOnConstruction() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new FastDatePrinter(null, UTC, Locale.US);
            }
        });
    }

    @Test
    void testNullTimeZoneThrowsOnFormat() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy", null, Locale.US);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                printer.format(new Date());
            }
        });
    }

    @Test
    void testNullLocaleFallsBackToDefaultLocale() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy", UTC, null);
        assertEquals(Locale.getDefault(), printer.getLocale());
    }

    @Test
    void testGetters() {
        final FastDatePrinter printer = newPrinter("yyyy-MM-dd");
        assertEquals("yyyy-MM-dd", printer.getPattern());
        assertEquals(UTC, printer.getTimeZone());
        assertEquals(Locale.US, printer.getLocale());
        assertTrue(printer.getMaxLengthEstimate() >= "yyyy-MM-dd".length());
    }

    @Test
    void testMaxLengthEstimateForLiteralOnlyPattern() {
        final FastDatePrinter printer = newPrinter("'fixed text'");
        assertEquals("fixed text".length(), printer.getMaxLengthEstimate());
        assertEquals("fixed text", printer.format(new Date()));
    }

    @Test
    void testEqualsAndHashCode() {
        final FastDatePrinter a = newPrinter("yyyy-MM-dd");
        final FastDatePrinter b = newPrinter("yyyy-MM-dd");
        final FastDatePrinter differentPattern = newPrinter("yyyy/MM/dd");
        final FastDatePrinter differentZone = new FastDatePrinter("yyyy-MM-dd", TimeZone.getTimeZone("GMT+1"), Locale.US);
        final FastDatePrinter differentLocale = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.GERMANY);

        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
        assertNotEquals(a, differentPattern);
        assertNotEquals(a, differentZone);
        assertNotEquals(a, differentLocale);
        assertFalse(a.equals("yyyy-MM-dd"));
        assertFalse(a.equals(null));
    }

    @Test
    void testToString() {
        final FastDatePrinter printer = newPrinter("yyyy");
        assertEquals("FastDatePrinter[yyyy,en_US,UTC]", printer.toString());
    }

    @Test
    void testFormatAppendableAndStringBufferOverloads() {
        final Calendar cal = newCalendar(2023, Calendar.JUNE, 15, 0, 0, 0, 0);
        final FastDatePrinter printer = newPrinter("yyyy-MM-dd");

        final StringBuilder sb = new StringBuilder();
        final StringBuilder returnedSb = printer.format(cal, sb);
        assertEquals("2023-06-15", sb.toString());
        assertTrue(sb == returnedSb);

        final StringBuffer buf = new StringBuffer();
        final StringBuffer returnedBuf = printer.format(cal, buf);
        assertEquals("2023-06-15", buf.toString());
        assertTrue(buf == returnedBuf);

        final StringBuffer dateBuf = new StringBuffer();
        printer.format(cal.getTime(), dateBuf);
        assertEquals("2023-06-15", dateBuf.toString());

        final StringBuffer millisBuf = new StringBuffer();
        printer.format(cal.getTimeInMillis(), millisBuf);
        assertEquals("2023-06-15", millisBuf.toString());

        final StringBuilder dateAppendable = new StringBuilder();
        printer.format(cal.getTime(), dateAppendable);
        assertEquals("2023-06-15", dateAppendable.toString());

        final StringBuilder millisAppendable = new StringBuilder();
        printer.format(cal.getTimeInMillis(), millisAppendable);
        assertEquals("2023-06-15", millisAppendable.toString());
    }

    @Test
    void testFormatCalendarWithDifferentZoneConvertsOnceInstantIsResolved() {
        // Printer is fixed to UTC. Once the calendar's instant has been resolved (by reading
        // getTimeInMillis() against its own GMT+2 zone), cloning it and swapping in the printer's zone
        // correctly re-derives the displayed fields for that instant in the new zone: 10:00 at GMT+2 is
        // 08:00 UTC. The original calendar must not be mutated.
        final TimeZone plusTwo = TimeZone.getTimeZone("GMT+02:00");
        final Calendar cal = Calendar.getInstance(plusTwo, Locale.US);
        cal.clear();
        cal.set(2023, Calendar.JUNE, 15, 10, 0, 0);
        cal.getTimeInMillis();

        final FastDatePrinter printer = newPrinter("HH");
        assertEquals("08", printer.format(cal));
        assertEquals(plusTwo, cal.getTimeZone());
    }

    @Test
    void testFormatCalendarWithDifferentZoneKeepsFieldsWhenInstantNotYetResolved() {
        // If the calendar's instant has NOT been resolved yet (no prior get()/getTimeInMillis() call),
        // format(Calendar) clones it and swaps in the printer's zone before the fields are ever
        // computed; the previously set wall-clock fields then get reinterpreted literally in the new
        // zone instead of being converted, so the displayed hour is unchanged (still 10, not 08).
        final TimeZone plusTwo = TimeZone.getTimeZone("GMT+02:00");
        final Calendar cal = Calendar.getInstance(plusTwo, Locale.US);
        cal.clear();
        cal.set(2023, Calendar.JUNE, 15, 10, 0, 0);

        final FastDatePrinter printer = newPrinter("HH");
        assertEquals("10", printer.format(cal));
        assertEquals(plusTwo, cal.getTimeZone());
    }

    @Test
    void testFormatCalendarWithStringBufferIgnoresCalendarZoneUsesPrinterZone() {
        final TimeZone plusTwo = TimeZone.getTimeZone("GMT+02:00");
        final Calendar cal = Calendar.getInstance(plusTwo, Locale.US);
        cal.clear();
        cal.set(2023, Calendar.JUNE, 15, 10, 0, 0);

        final FastDatePrinter printer = newPrinter("HH");
        final StringBuffer buf = new StringBuffer();
        printer.format(cal, buf);
        assertEquals("08", buf.toString());
    }

    @Test
    void testFormatObjectDispatch() {
        final FastDatePrinter printer = newPrinter("yyyy-MM-dd");
        final Calendar cal = newCalendar(2023, Calendar.JUNE, 15, 0, 0, 0, 0);

        assertEquals("2023-06-15", printer.format((Object) cal.getTime()));
        assertEquals("2023-06-15", printer.format((Object) cal));
        assertEquals("2023-06-15", printer.format((Object) Long.valueOf(cal.getTimeInMillis())));
    }

    @Test
    void testFormatObjectUnsupportedTypeThrows() {
        final FastDatePrinter printer = newPrinter("yyyy-MM-dd");
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                printer.format((Object) "not-a-date");
            }
        });
    }

    @Test
    @SuppressWarnings("deprecation")
    void testDeprecatedFormatObjectWithFieldPositionDispatch() {
        final FastDatePrinter printer = newPrinter("yyyy-MM-dd");
        final Calendar cal = newCalendar(2023, Calendar.JUNE, 15, 0, 0, 0, 0);
        final FieldPosition pos = new FieldPosition(0);

        final StringBuffer dateResult = printer.format(cal.getTime(), new StringBuffer(), pos);
        assertEquals("2023-06-15", dateResult.toString());

        final StringBuffer calResult = printer.format(cal, new StringBuffer(), pos);
        assertEquals("2023-06-15", calResult.toString());

        final StringBuffer longResult = printer.format(Long.valueOf(cal.getTimeInMillis()), new StringBuffer(), pos);
        assertEquals("2023-06-15", longResult.toString());
    }

    @Test
    @SuppressWarnings("deprecation")
    void testDeprecatedFormatObjectWithFieldPositionUnsupportedTypeThrows() {
        final FastDatePrinter printer = newPrinter("yyyy-MM-dd");
        final FieldPosition pos = new FieldPosition(0);
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                printer.format("not-a-date", new StringBuffer(), pos);
            }
        });
    }

    @Test
    void testDayInWeekFieldSundayWrapsToSeven() {
        final Calendar sunday = newCalendar(2023, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals("7", newPrinter("u").format(sunday));
        final Calendar monday = newCalendar(2023, Calendar.JANUARY, 2, 0, 0, 0, 0);
        assertEquals("1", newPrinter("u").format(monday));
    }

    @Test
    void testParsePatternRejectsUnknownLetterInsideLongerPattern() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new FastDatePrinter("yyyy-Qq", UTC, Locale.US);
            }
        });
    }

    @Test
    void testSerializationRoundTripReinitializesRules() throws Exception {
        final FastDatePrinter printer = newPrinter("yyyy-MM-dd");
        final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
        final java.io.ObjectOutputStream oos = new java.io.ObjectOutputStream(baos);
        oos.writeObject(printer);
        oos.close();

        final java.io.ObjectInputStream ois = new java.io.ObjectInputStream(new java.io.ByteArrayInputStream(baos.toByteArray()));
        final FastDatePrinter restored = (FastDatePrinter) ois.readObject();
        ois.close();

        assertEquals(printer, restored);
        assertEquals("2023-06-15", restored.format(newCalendar(2023, Calendar.JUNE, 15, 0, 0, 0, 0)));
    }

    @Test
    void testGregorianCalendarInputIsHonoredAsCalendarType() {
        final GregorianCalendar cal = new GregorianCalendar(UTC, Locale.US);
        cal.clear();
        cal.set(2024, Calendar.FEBRUARY, 29, 0, 0, 0);
        assertEquals("2024-02-29", newPrinter("yyyy-MM-dd").format((Calendar) cal));
    }
}
