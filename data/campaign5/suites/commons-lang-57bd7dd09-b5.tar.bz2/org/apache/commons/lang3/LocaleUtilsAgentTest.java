/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import java.util.Locale;
import java.util.Set;

import org.junit.jupiter.api.Test;

public class LocaleUtilsAgentTest {

    @Test
    public void testAvailableLocaleList() {
        final List<Locale> list = LocaleUtils.availableLocaleList();
        assertNotNull(list);
        assertFalse(list.isEmpty());
        assertTrue(list.contains(Locale.US));
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                list.add(Locale.US);
            }
        });
        // Calling again should return the same cached instance.
        assertTrue(list == LocaleUtils.availableLocaleList());
    }

    @Test
    public void testAvailableLocaleSet() {
        final Set<Locale> set = LocaleUtils.availableLocaleSet();
        assertNotNull(set);
        assertFalse(set.isEmpty());
        assertTrue(set.contains(Locale.US));
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                set.add(Locale.US);
            }
        });
    }

    @Test
    public void testCountriesByLanguageNull() {
        final List<Locale> list = LocaleUtils.countriesByLanguage(null);
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    public void testCountriesByLanguageEmpty() {
        final List<Locale> list = LocaleUtils.countriesByLanguage("");
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    public void testCountriesByLanguageInvalid() {
        // Not a syntactically valid ISO 639 code (too long / uppercase).
        assertTrue(LocaleUtils.countriesByLanguage("ENGLISH").isEmpty());
        assertTrue(LocaleUtils.countriesByLanguage("e").isEmpty());
    }

    @Test
    public void testCountriesByLanguageValid() {
        final List<Locale> list = LocaleUtils.countriesByLanguage("es");
        assertNotNull(list);
        for (final Locale locale : list) {
            assertEquals("es", locale.getLanguage());
            assertFalse(locale.getCountry().isEmpty());
        }
        // Result should be cached - same reference on second call.
        assertTrue(list == LocaleUtils.countriesByLanguage("es"));
    }

    @Test
    public void testIsAvailableLocale() {
        assertTrue(LocaleUtils.isAvailableLocale(Locale.US));
        assertFalse(LocaleUtils.isAvailableLocale(new Locale("xx", "XX", "myweirdvariant")));
    }

    @Test
    public void testIsLanguageUndetermined() {
        assertTrue(LocaleUtils.isLanguageUndetermined(null));
        assertTrue(LocaleUtils.isLanguageUndetermined(new Locale("")));
        assertFalse(LocaleUtils.isLanguageUndetermined(Locale.ENGLISH));
    }

    @Test
    public void testLanguagesByCountryNull() {
        final List<Locale> list = LocaleUtils.languagesByCountry(null);
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    public void testLanguagesByCountryEmpty() {
        final List<Locale> list = LocaleUtils.languagesByCountry("");
        assertNotNull(list);
        for (final Locale locale : list) {
            assertEquals("", locale.getCountry());
        }
    }

    @Test
    public void testLanguagesByCountryInvalid() {
        assertTrue(LocaleUtils.languagesByCountry("lowercase").isEmpty());
        assertTrue(LocaleUtils.languagesByCountry("u").isEmpty());
    }

    @Test
    public void testLanguagesByCountryValid() {
        final List<Locale> list = LocaleUtils.languagesByCountry("US");
        assertNotNull(list);
        for (final Locale locale : list) {
            assertEquals("US", locale.getCountry());
        }
        assertTrue(list == LocaleUtils.languagesByCountry("US"));
    }

    @Test
    public void testLanguagesByCountryNumericArea() {
        final List<Locale> list = LocaleUtils.languagesByCountry("001");
        assertNotNull(list);
        for (final Locale locale : list) {
            assertEquals("001", locale.getCountry());
        }
    }

    @Test
    public void testLocaleLookupListSingleArgNull() {
        final List<Locale> list = LocaleUtils.localeLookupList(null);
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    public void testLocaleLookupListSingleArgLanguageOnly() {
        final List<Locale> list = LocaleUtils.localeLookupList(new Locale("fr"));
        assertEquals(1, list.size());
        assertEquals(new Locale("fr"), list.get(0));
    }

    @Test
    public void testLocaleLookupListSingleArgFull() {
        final Locale locale = new Locale("fr", "CA", "xxx");
        final List<Locale> list = LocaleUtils.localeLookupList(locale);
        assertEquals(3, list.size());
        assertEquals(new Locale("fr", "CA", "xxx"), list.get(0));
        assertEquals(new Locale("fr", "CA"), list.get(1));
        assertEquals(new Locale("fr"), list.get(2));
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                list.add(Locale.US);
            }
        });
    }

    @Test
    public void testLocaleLookupListTwoArgsNullLocale() {
        final List<Locale> list = LocaleUtils.localeLookupList(null, Locale.ENGLISH);
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    public void testLocaleLookupListTwoArgsWithDefault() {
        final Locale locale = new Locale("fr", "CA", "xxx");
        final List<Locale> list = LocaleUtils.localeLookupList(locale, Locale.ENGLISH);
        assertEquals(4, list.size());
        assertEquals(new Locale("fr", "CA", "xxx"), list.get(0));
        assertEquals(new Locale("fr", "CA"), list.get(1));
        assertEquals(new Locale("fr"), list.get(2));
        assertEquals(Locale.ENGLISH, list.get(3));
    }

    @Test
    public void testLocaleLookupListTwoArgsDefaultAlreadyPresent() {
        final Locale locale = new Locale("fr");
        final List<Locale> list = LocaleUtils.localeLookupList(locale, new Locale("fr"));
        // defaultLocale equals locale already in the list, so it should not be duplicated.
        assertEquals(1, list.size());
        assertEquals(new Locale("fr"), list.get(0));
    }

    @Test
    public void testToLocaleLocaleOverload() {
        assertEquals(Locale.US, LocaleUtils.toLocale(Locale.US));
        assertEquals(Locale.getDefault(), LocaleUtils.toLocale((Locale) null));
    }

    @Test
    public void testToLocaleStringNull() {
        assertNull(LocaleUtils.toLocale((String) null));
    }

    @Test
    public void testToLocaleStringEmpty() {
        final Locale locale = LocaleUtils.toLocale("");
        assertEquals("", locale.getLanguage());
        assertEquals("", locale.getCountry());
    }

    @Test
    public void testToLocaleStringLanguageOnly() {
        final Locale locale = LocaleUtils.toLocale("en");
        assertEquals("en", locale.getLanguage());
        assertEquals("", locale.getCountry());
    }

    @Test
    public void testToLocaleStringLanguageCountryUnderscore() {
        final Locale locale = LocaleUtils.toLocale("en_GB");
        assertEquals("en", locale.getLanguage());
        assertEquals("GB", locale.getCountry());
    }

    @Test
    public void testToLocaleStringLanguageCountryDash() {
        final Locale locale = LocaleUtils.toLocale("en-GB");
        assertEquals("en", locale.getLanguage());
        assertEquals("GB", locale.getCountry());
    }

    @Test
    public void testToLocaleStringNumericArea() {
        final Locale locale = LocaleUtils.toLocale("en_001");
        assertEquals("en", locale.getLanguage());
        assertEquals("001", locale.getCountry());
    }

    @Test
    public void testToLocaleStringFullVariant() {
        final Locale locale = LocaleUtils.toLocale("en_GB_xxx");
        assertEquals("en", locale.getLanguage());
        assertEquals("GB", locale.getCountry());
        assertEquals("xxx", locale.getVariant());
    }

    @Test
    public void testToLocaleStringCountryOnly() {
        final Locale locale = LocaleUtils.toLocale("US");
        assertEquals("", locale.getLanguage());
        assertEquals("US", locale.getCountry());
    }

    @Test
    public void testToLocaleStringLeadingUnderscoreCountryOnly() {
        final Locale locale = LocaleUtils.toLocale("_GB");
        assertEquals("", locale.getLanguage());
        assertEquals("GB", locale.getCountry());
    }

    @Test
    public void testToLocaleStringLeadingUnderscoreWithVariant() {
        final Locale locale = LocaleUtils.toLocale("_GB_P");
        assertEquals("", locale.getLanguage());
        assertEquals("GB", locale.getCountry());
        assertEquals("P", locale.getVariant());
    }

    @Test
    public void testToLocaleStringSingleCharThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("a");
            }
        });
    }

    @Test
    public void testToLocaleStringLeadingUnderscoreTooShortThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("_G");
            }
        });
    }

    @Test
    public void testToLocaleStringLeadingUnderscoreLowerCaseThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("_gb");
            }
        });
    }

    @Test
    public void testToLocaleStringLeadingUnderscoreBadSeparatorThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("_GBP");
            }
        });
    }

    @Test
    public void testToLocaleStringInvalidLanguageThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("EN");
            }
        });
    }

    @Test
    public void testToLocaleStringLowerCaseCountryThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                LocaleUtils.toLocale("en_gb");
            }
        });
    }

    @Test
    public void testToLocaleStringSpecialCaseThai() {
        final Locale locale = LocaleUtils.toLocale("th_TH_TH_#u-nu-thai");
        assertEquals("th", locale.getLanguage());
        assertEquals("TH", locale.getCountry());
    }

    @Test
    public void testToLocaleStringSpecialCaseJapanese() {
        final Locale locale = LocaleUtils.toLocale("ja_JP_JP_#u-ca-japanese");
        assertEquals("ja", locale.getLanguage());
        assertEquals("JP", locale.getCountry());
    }

    @Test
    public void testConstructorIsPublicAndUsable() {
        assertNotNull(new LocaleUtils());
    }
}
