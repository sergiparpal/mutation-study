/*
  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      https://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
 */

package org.apache.commons.cli;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Collection;
import java.util.List;

import org.junit.jupiter.api.Test;

class OptionsAgentTest {

    @Test
    void testAddOptionInstanceReturnsSameOptionsForChaining() {
        final Options options = new Options();
        final Option opt = new Option("a", "alpha", false, "alpha option");
        final Options result = options.addOption(opt);
        assertSame(options, result, "addOption should return the same Options instance");
        assertTrue(options.hasOption("a"));
        assertTrue(options.hasOption("alpha"));
    }

    @Test
    void testAddOptionShortOnlyNoArg() {
        final Options options = new Options();
        options.addOption("v", false, "verbose");
        assertTrue(options.hasShortOption("v"));
        assertFalse(options.hasLongOption("v"));
        final Option opt = options.getOption("v");
        assertNotNull(opt);
        assertFalse(opt.hasArg());
        assertEquals("verbose", opt.getDescription());
    }

    @Test
    void testAddOptionShortWithDescriptionOnly() {
        final Options options = new Options();
        options.addOption("x", "x-desc");
        final Option opt = options.getOption("x");
        assertNotNull(opt);
        assertFalse(opt.hasArg(), "two-arg addOption should not require an argument");
        assertEquals("x-desc", opt.getDescription());
    }

    @Test
    void testAddOptionShortAndLongWithArg() {
        final Options options = new Options();
        options.addOption("f", "file", true, "file to read");
        assertTrue(options.hasShortOption("f"));
        assertTrue(options.hasLongOption("file"));
        final Option byShort = options.getOption("f");
        final Option byLong = options.getOption("file");
        assertSame(byShort, byLong, "short and long name should resolve to the same Option");
        assertTrue(byShort.hasArg());
    }

    @Test
    void testAddOptionWithoutLongNameIsNotInLongOpts() {
        final Options options = new Options();
        options.addOption("z", false, "zed");
        assertFalse(options.hasLongOption("z"));
        assertTrue(options.hasShortOption("z"));
    }

    @Test
    void testAddOptionReplacingSameKeyRemovesDuplicateFromRequired() {
        final Options options = new Options();
        final Option first = new Option("r", "req", false, "first");
        first.setRequired(true);
        options.addOption(first);
        assertEquals(1, options.getRequiredOptions().size());

        final Option second = new Option("r", "req", false, "second");
        second.setRequired(true);
        options.addOption(second);
        // the required list should not contain duplicate "r" entries
        assertEquals(1, options.getRequiredOptions().size());
        assertEquals("second", options.getOption("r").getDescription());
    }

    @Test
    void testAddRequiredOption() {
        final Options options = new Options();
        options.addRequiredOption("o", "out", true, "output file");
        final Option opt = options.getOption("o");
        assertNotNull(opt);
        assertTrue(opt.isRequired());
        assertTrue(options.getRequiredOptions().contains("o"));
    }

    @Test
    void testAddOptionGroupMakesOptionsOptional() {
        final Options options = new Options();
        final Option fileOpt = new Option("f", "file", false, "file");
        fileOpt.setRequired(true);
        final Option dirOpt = new Option("d", "dir", false, "dir");
        final OptionGroup group = new OptionGroup();
        group.addOption(fileOpt);
        group.addOption(dirOpt);
        group.setRequired(true);

        options.addOptionGroup(group);

        assertFalse(options.getOption("f").isRequired(), "options in a group must not be individually required");
        assertTrue(options.getRequiredOptions().contains(group));
        assertFalse(options.getRequiredOptions().contains("f"), "individual key should not remain in required list");
        assertSame(group, options.getOptionGroup(options.getOption("f")));
        assertSame(group, options.getOptionGroup(options.getOption("d")));
    }

    @Test
    void testAddOptionGroupNotRequiredIsNotInRequiredOptions() {
        final Options options = new Options();
        final OptionGroup group = new OptionGroup();
        group.addOption(new Option("a", "aa", false, "a"));
        group.addOption(new Option("b", "bb", false, "b"));
        options.addOptionGroup(group);
        assertFalse(options.getRequiredOptions().contains(group));
    }

    @Test
    void testAddOptionsCopiesOptionsAndGroups() {
        final Options source = new Options();
        source.addOption("a", false, "a option");
        source.addOption("b", true, "b option");

        final Options target = new Options();
        target.addOption("c", false, "c option");
        final Options result = target.addOptions(source);

        assertSame(target, result);
        assertTrue(target.hasOption("a"));
        assertTrue(target.hasOption("b"));
        assertTrue(target.hasOption("c"));
        assertEquals(3, target.getOptions().size());
    }

    @Test
    void testAddOptionsWithDuplicateKeyThrows() {
        final Options source = new Options();
        source.addOption("a", false, "duplicate a");

        final Options target = new Options();
        target.addOption("a", false, "original a");

        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                target.addOptions(source);
            }
        });
    }

    @Test
    void testAddOptionsCopiesOptionGroups() {
        final Options source = new Options();
        final OptionGroup group = new OptionGroup();
        group.addOption(new Option("x", "xx", false, "x option"));
        group.addOption(new Option("y", "yy", false, "y option"));
        source.addOptionGroup(group);

        final Options target = new Options();
        target.addOptions(source);

        assertNotNull(target.getOptionGroup(target.getOption("x")));
        assertNotNull(target.getOptionGroup(target.getOption("y")));
    }

    @Test
    void testGetMatchingOptionsExactMatchReturnsSingleton() {
        final Options options = new Options();
        options.addOption("f", "file", false, "file");
        options.addOption(null, "files", false, "files");
        final List<String> matches = options.getMatchingOptions("file");
        assertEquals(1, matches.size());
        assertEquals("file", matches.get(0));
    }

    @Test
    void testGetMatchingOptionsPartialMatch() {
        final Options options = new Options();
        options.addOption(null, "foo", false, "foo");
        options.addOption(null, "foobar", false, "foobar");
        options.addOption(null, "baz", false, "baz");
        final List<String> matches = options.getMatchingOptions("fo");
        assertEquals(2, matches.size());
        assertTrue(matches.contains("foo"));
        assertTrue(matches.contains("foobar"));
    }

    @Test
    void testGetMatchingOptionsNullOrEmptyReturnsEmptyList() {
        final Options options = new Options();
        options.addOption(null, "foo", false, "foo");
        assertTrue(options.getMatchingOptions(null).isEmpty());
        assertTrue(options.getMatchingOptions("").isEmpty());
    }

    @Test
    void testGetMatchingOptionsNoMatchReturnsEmptyList() {
        final Options options = new Options();
        options.addOption(null, "foo", false, "foo");
        assertTrue(options.getMatchingOptions("zzz").isEmpty());
    }

    @Test
    void testGetOptionStripsLeadingHyphens() {
        final Options options = new Options();
        options.addOption("f", "file", false, "file");
        assertSame(options.getOption("f"), options.getOption("-f"));
        assertSame(options.getOption("file"), options.getOption("--file"));
    }

    @Test
    void testGetOptionReturnsNullWhenAbsent() {
        final Options options = new Options();
        assertNull(options.getOption("missing"));
    }

    @Test
    void testGetOptionGroupReturnsNullWhenNotInGroup() {
        final Options options = new Options();
        options.addOption("a", false, "a option");
        assertNull(options.getOptionGroup(options.getOption("a")));
    }

    @Test
    void testGetOptionsIsUnmodifiable() {
        final Options options = new Options();
        options.addOption("a", false, "a option");
        final Collection<Option> opts = options.getOptions();
        assertEquals(1, opts.size());
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                opts.clear();
            }
        });
    }

    @Test
    void testGetOptionsEmptyWhenNoneAdded() {
        final Options options = new Options();
        assertTrue(options.getOptions().isEmpty());
    }

    @Test
    @SuppressWarnings("unchecked")
    void testGetRequiredOptionsIsUnmodifiable() {
        final Options options = new Options();
        options.addRequiredOption("r", "req", false, "required");
        final List<Object> required = (List<Object>) options.getRequiredOptions();
        assertEquals(1, required.size());
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                required.add("extra");
            }
        });
    }

    @Test
    void testGetRequiredOptionsEmptyWhenNoneRequired() {
        final Options options = new Options();
        options.addOption("a", false, "a option");
        assertTrue(options.getRequiredOptions().isEmpty());
    }

    @Test
    void testHasLongOptionTrueAndFalse() {
        final Options options = new Options();
        options.addOption("f", "file", false, "file");
        assertTrue(options.hasLongOption("file"));
        assertTrue(options.hasLongOption("--file"));
        assertFalse(options.hasLongOption("f"));
        assertFalse(options.hasLongOption("nope"));
    }

    @Test
    void testHasOptionMatchesShortOrLong() {
        final Options options = new Options();
        options.addOption("f", "file", false, "file");
        assertTrue(options.hasOption("f"));
        assertTrue(options.hasOption("file"));
        assertTrue(options.hasOption("-f"));
        assertTrue(options.hasOption("--file"));
        assertFalse(options.hasOption("x"));
    }

    @Test
    void testHasShortOptionTrueAndFalse() {
        final Options options = new Options();
        options.addOption("f", "file", false, "file");
        assertTrue(options.hasShortOption("f"));
        assertTrue(options.hasShortOption("-f"));
        assertFalse(options.hasShortOption("file"));
        assertFalse(options.hasShortOption("nope"));
    }

    @Test
    void testToStringContainsShortAndLongSections() {
        final Options options = new Options();
        options.addOption("f", "file", false, "file");
        final String str = options.toString();
        assertTrue(str.contains("[ Options: [ short"));
        assertTrue(str.contains("[ long"));
        assertTrue(str.contains("file"));
    }

    @Test
    void testToStringOnEmptyOptions() {
        final Options options = new Options();
        final String str = options.toString();
        assertNotNull(str);
        assertTrue(str.contains("[ Options: [ short"));
    }

    @Test
    void testGetOptionWithNullArgumentReturnsNull() {
        final Options options = new Options();
        options.addOption("f", "file", false, "file");
        assertNull(options.getOption(null));
    }

    @Test
    void testHasOptionWithNullArgumentReturnsFalse() {
        final Options options = new Options();
        assertFalse(options.hasOption(null));
    }
}
