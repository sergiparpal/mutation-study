/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.junit.jupiter.api.Test;

@SuppressWarnings("deprecation")
public class StrBuilderAgentTest {

    @Test
    public void testDefaultConstructor() {
        final StrBuilder sb = new StrBuilder();
        assertEquals(0, sb.length());
        assertEquals(32, sb.capacity());
        assertTrue(sb.isEmpty());
    }

    @Test
    public void testCapacityConstructorNonPositiveFallsBackToDefault() {
        assertEquals(32, new StrBuilder(0).capacity());
        assertEquals(32, new StrBuilder(-5).capacity());
        assertEquals(50, new StrBuilder(50).capacity());
    }

    @Test
    public void testStringConstructorNull() {
        final StrBuilder sb = new StrBuilder((String) null);
        assertEquals(0, sb.length());
        assertEquals("", sb.toString());
    }

    @Test
    public void testStringConstructor() {
        final StrBuilder sb = new StrBuilder("abc");
        assertEquals(3, sb.length());
        assertEquals("abc", sb.toString());
        assertTrue(sb.capacity() >= 3);
    }

    @Test
    public void testAppendBoolean() {
        final StrBuilder sb = new StrBuilder();
        sb.append(true);
        sb.append(false);
        assertEquals("truefalse", sb.toString());
    }

    @Test
    public void testAppendChar() {
        final StrBuilder sb = new StrBuilder();
        final StrBuilder result = sb.append('x');
        assertSame(sb, result);
        assertEquals("x", sb.toString());
    }

    @Test
    public void testAppendCharArrayNull() {
        final StrBuilder sb = new StrBuilder().append("a");
        sb.append((char[]) null);
        assertEquals("a", sb.toString());
    }

    @Test
    public void testAppendCharArray() {
        final StrBuilder sb = new StrBuilder();
        sb.append(new char[] {'a', 'b', 'c'});
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendCharArrayRange() {
        final StrBuilder sb = new StrBuilder();
        sb.append(new char[] {'a', 'b', 'c', 'd'}, 1, 2);
        assertEquals("bc", sb.toString());
    }

    @Test
    public void testAppendCharArrayRangeInvalidStartIndex() {
        final StrBuilder sb = new StrBuilder();
        final char[] chars = new char[] {'a', 'b'};
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append(chars, -1, 1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append(chars, 3, 1));
    }

    @Test
    public void testAppendCharArrayRangeInvalidLength() {
        final StrBuilder sb = new StrBuilder();
        final char[] chars = new char[] {'a', 'b'};
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append(chars, 0, -1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append(chars, 0, 5));
    }

    @Test
    public void testAppendCharSequence() {
        final StrBuilder sb = new StrBuilder();
        sb.append((CharSequence) "hi");
        assertEquals("hi", sb.toString());
        sb.append((CharSequence) null);
        assertEquals("hi", sb.toString());
    }

    @Test
    public void testAppendCharSequenceRange() {
        final StrBuilder sb = new StrBuilder();
        sb.append((CharSequence) "hello", 1, 3);
        assertEquals("ell", sb.toString());
    }

    @Test
    public void testAppendDoubleFloatIntLong() {
        final StrBuilder sb = new StrBuilder();
        sb.append(1.5d).append(' ').append(2.5f).append(' ').append(3).append(' ').append(4L);
        assertEquals("1.5 2.5 3 4", sb.toString());
    }

    @Test
    public void testAppendObjectNull() {
        final StrBuilder sb = new StrBuilder();
        sb.append((Object) null);
        assertEquals("", sb.toString());
        sb.setNullText("NULL");
        sb.append((Object) null);
        assertEquals("NULL", sb.toString());
    }

    @Test
    public void testAppendObject() {
        final StrBuilder sb = new StrBuilder();
        sb.append((Object) Integer.valueOf(42));
        assertEquals("42", sb.toString());
    }

    @Test
    public void testAppendStrBuilder() {
        final StrBuilder other = new StrBuilder("xyz");
        final StrBuilder sb = new StrBuilder("ab");
        sb.append(other);
        assertEquals("abxyz", sb.toString());
        sb.append((StrBuilder) null);
        assertEquals("abxyz", sb.toString());
    }

    @Test
    public void testAppendStrBuilderRangeInvalid() {
        final StrBuilder other = new StrBuilder("xyz");
        final StrBuilder sb = new StrBuilder();
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append(other, -1, 1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append(other, 0, 10));
    }

    @Test
    public void testAppendStringNull() {
        final StrBuilder sb = new StrBuilder();
        sb.append((String) null);
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendStringRangeInvalid() {
        final StrBuilder sb = new StrBuilder();
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append("abc", -1, 1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append("abc", 0, 10));
    }

    @Test
    public void testAppendFormattedString() {
        final StrBuilder sb = new StrBuilder();
        sb.append("%s-%d", "a", 1);
        assertEquals("a-1", sb.toString());
    }

    @Test
    public void testAppendStringBuffer() {
        final StrBuilder sb = new StrBuilder();
        sb.append(new StringBuffer("hello"));
        assertEquals("hello", sb.toString());
        sb.append((StringBuffer) null);
        assertEquals("hello", sb.toString());
    }

    @Test
    public void testAppendStringBuilderJdk() {
        final StrBuilder sb = new StrBuilder();
        sb.append(new StringBuilder("world"));
        assertEquals("world", sb.toString());
    }

    @Test
    public void testAppendAllVarargs() {
        final StrBuilder sb = new StrBuilder();
        sb.appendAll("a", "b", "c");
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendAllIterable() {
        final StrBuilder sb = new StrBuilder();
        final List<String> list = Arrays.asList("a", "b", "c");
        sb.appendAll((Iterable<?>) list);
        assertEquals("abc", sb.toString());
        sb.appendAll((Iterable<?>) null);
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendAllIterator() {
        final StrBuilder sb = new StrBuilder();
        final List<String> list = Arrays.asList("x", "y");
        sb.appendAll(list.iterator());
        assertEquals("xy", sb.toString());
        sb.appendAll((Iterator<?>) null);
        assertEquals("xy", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadLeft() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft(1, 3, '0');
        assertEquals("001", sb.toString());
        sb.clear();
        sb.appendFixedWidthPadLeft(12345, 3, '0');
        assertEquals("345", sb.toString());
        sb.clear();
        sb.appendFixedWidthPadLeft(5, -1, '0');
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadLeftObjectNull() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft((Object) null, 3, '*');
        assertEquals("***", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadRight() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadRight(1, 3, '0');
        assertEquals("100", sb.toString());
        sb.clear();
        sb.appendFixedWidthPadRight(12345, 3, '0');
        assertEquals("123", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadRightObjectNull() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadRight((Object) null, 3, '*');
        assertEquals("***", sb.toString());
    }

    @Test
    public void testAppendlnVariants() {
        final StrBuilder sb = new StrBuilder();
        sb.setNewLineText("|");
        sb.appendln(true).appendln('x').appendln(1).appendln(2L).appendln(1.5d).appendln(1.5f);
        assertEquals("true|x|1|2|1.5|1.5|", sb.toString());
    }

    @Test
    public void testAppendNewLineDefault() {
        final StrBuilder sb = new StrBuilder();
        sb.appendNewLine();
        assertEquals(System.lineSeparator(), sb.toString());
    }

    @Test
    public void testAppendNewLineCustom() {
        final StrBuilder sb = new StrBuilder();
        sb.setNewLineText("\n");
        assertEquals("\n", sb.getNewLineText());
        sb.appendNewLine();
        assertEquals("\n", sb.toString());
    }

    @Test
    public void testAppendNullDefaultIsNoOp() {
        final StrBuilder sb = new StrBuilder();
        assertNull(sb.getNullText());
        sb.appendNull();
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendPadding() {
        final StrBuilder sb = new StrBuilder();
        sb.appendPadding(3, '*');
        assertEquals("***", sb.toString());
        sb.appendPadding(-1, '*');
        assertEquals("***", sb.toString());
    }

    @Test
    public void testAppendSeparatorChar() {
        final StrBuilder sb = new StrBuilder();
        sb.appendSeparator(',');
        assertEquals("", sb.toString());
        sb.append("a");
        sb.appendSeparator(',');
        sb.append("b");
        assertEquals("a,b", sb.toString());
    }

    @Test
    public void testAppendSeparatorCharDefaultIfEmpty() {
        final StrBuilder sb = new StrBuilder();
        sb.appendSeparator(',', ';');
        assertEquals(";", sb.toString());
        sb.appendSeparator(',', ';');
        assertEquals(";,", sb.toString());
    }

    @Test
    public void testAppendSeparatorCharLoopIndex() {
        final StrBuilder sb = new StrBuilder();
        for (int i = 0; i < 3; i++) {
            sb.appendSeparator(',', i);
            sb.append(i);
        }
        assertEquals("0,1,2", sb.toString());
    }

    @Test
    public void testAppendSeparatorStringNull() {
        final StrBuilder sb = new StrBuilder("a");
        sb.appendSeparator((String) null);
        assertEquals("a", sb.toString());
    }

    @Test
    public void testAppendSeparatorStringLoopIndex() {
        final StrBuilder sb = new StrBuilder();
        for (int i = 0; i < 3; i++) {
            sb.appendSeparator("-", i);
            sb.append(i);
        }
        assertEquals("0-1-2", sb.toString());
    }

    @Test
    public void testAppendSeparatorStringStandardAndDefault() {
        final StrBuilder sb = new StrBuilder();
        sb.appendSeparator(" and", " where");
        sb.append("a=1");
        assertEquals(" wherea=1", sb.toString());
        sb.appendSeparator(" and", " where");
        sb.append("b=2");
        assertEquals(" wherea=1 andb=2", sb.toString());
    }

    @Test
    public void testAppendToWriter() throws IOException {
        final StrBuilder sb = new StrBuilder("hello");
        final StringWriter writer = new StringWriter();
        sb.appendTo(writer);
        assertEquals("hello", writer.toString());
    }

    @Test
    public void testAppendToStringBuilder() throws IOException {
        final StrBuilder sb = new StrBuilder("hello");
        final StringBuilder target = new StringBuilder();
        sb.appendTo(target);
        assertEquals("hello", target.toString());
    }

    @Test
    public void testAppendWithSeparatorsIterable() {
        final StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators(Arrays.asList("a", "b", "c"), ",");
        assertEquals("a,b,c", sb.toString());
        sb.clear();
        sb.appendWithSeparators((Iterable<?>) null, ",");
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendWithSeparatorsIterator() {
        final StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators(Arrays.asList("a", "b").iterator(), "-");
        assertEquals("a-b", sb.toString());
    }

    @Test
    public void testAppendWithSeparatorsArray() {
        final StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators(new Object[] {"a", "b", "c"}, ",");
        assertEquals("a,b,c", sb.toString());
        sb.clear();
        sb.appendWithSeparators((Object[]) null, ",");
        assertEquals("", sb.toString());
    }

    @Test
    public void testAsReaderReadsContent() throws IOException {
        final StrBuilder sb = new StrBuilder("ab");
        final Reader reader = sb.asReader();
        assertEquals('a', reader.read());
        assertEquals('b', reader.read());
        assertEquals(-1, reader.read());
    }

    @Test
    public void testAsReaderMarkReset() throws IOException {
        final StrBuilder sb = new StrBuilder("abc");
        final Reader reader = sb.asReader();
        assertTrue(reader.markSupported());
        assertEquals('a', reader.read());
        reader.mark(10);
        assertEquals('b', reader.read());
        reader.reset();
        assertEquals('b', reader.read());
    }

    @Test
    public void testAsReaderBulkReadInvalidArgs() {
        final StrBuilder sb = new StrBuilder("abc");
        final Reader reader = sb.asReader();
        final char[] buf = new char[3];
        assertThrows(IndexOutOfBoundsException.class, () -> reader.read(buf, -1, 1));
        assertThrows(IndexOutOfBoundsException.class, () -> reader.read(buf, 0, 10));
    }

    @Test
    public void testAsReaderBulkReadTruncatesToAvailable() throws IOException {
        final StrBuilder sb = new StrBuilder("ab");
        final Reader reader = sb.asReader();
        final char[] buf = new char[10];
        final int read = reader.read(buf, 0, 10);
        assertEquals(2, read);
        assertEquals('a', buf[0]);
        assertEquals('b', buf[1]);
        assertEquals(-1, reader.read(buf, 0, 1));
    }

    @Test
    public void testAsReaderSkip() throws IOException {
        final StrBuilder sb = new StrBuilder("abcdef");
        final Reader reader = sb.asReader();
        final long skipped = reader.skip(3);
        assertEquals(3, skipped);
        assertEquals('d', reader.read());
    }

    @Test
    public void testAsWriterWritesIntoBuilder() throws IOException {
        final StrBuilder sb = new StrBuilder();
        final Writer writer = sb.asWriter();
        writer.write("hi");
        writer.write('!');
        writer.write(new char[] {'a', 'b'});
        writer.write(new char[] {'x', 'y', 'z'}, 1, 2);
        assertEquals("hi!abyz", sb.toString());
    }

    @Test
    public void testAsTokenizer() {
        final StrBuilder sb = new StrBuilder("a b c");
        final StrTokenizer tokenizer = sb.asTokenizer();
        final String[] tokens = tokenizer.getTokenArray();
        assertEquals(3, tokens.length);
        assertEquals("a", tokens[0]);
        assertEquals("c", tokens[2]);
    }

    @Test
    public void testBuild() {
        final StrBuilder sb = new StrBuilder("hello");
        assertEquals("hello", sb.build());
    }

    @Test
    public void testCapacityAndEnsureCapacity() {
        final StrBuilder sb = new StrBuilder(5);
        assertEquals(5, sb.capacity());
        sb.ensureCapacity(100);
        assertTrue(sb.capacity() >= 100);
        final int cap = sb.capacity();
        sb.ensureCapacity(1);
        assertEquals(cap, sb.capacity());
    }

    @Test
    public void testCharAtValidAndInvalid() {
        final StrBuilder sb = new StrBuilder("abc");
        assertEquals('a', sb.charAt(0));
        assertEquals('c', sb.charAt(2));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.charAt(-1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.charAt(3));
    }

    @Test
    public void testClear() {
        final StrBuilder sb = new StrBuilder("abc");
        final StrBuilder result = sb.clear();
        assertSame(sb, result);
        assertEquals(0, sb.length());
        assertEquals("", sb.toString());
    }

    @Test
    public void testContainsChar() {
        final StrBuilder sb = new StrBuilder("abc");
        assertTrue(sb.contains('b'));
        assertFalse(sb.contains('z'));
    }

    @Test
    public void testContainsString() {
        final StrBuilder sb = new StrBuilder("hello world");
        assertTrue(sb.contains("wor"));
        assertFalse(sb.contains("xyz"));
    }

    @Test
    public void testContainsMatcher() {
        final StrBuilder sb = new StrBuilder("hello");
        assertTrue(sb.contains(StrMatcher.charMatcher('e')));
        assertFalse(sb.contains((StrMatcher) null));
    }

    @Test
    public void testDelete() {
        final StrBuilder sb = new StrBuilder("hello world");
        sb.delete(5, 11);
        assertEquals("hello", sb.toString());
    }

    @Test
    public void testDeleteEndIndexTooLargeIsTreatedAsSize() {
        final StrBuilder sb = new StrBuilder("hello");
        sb.delete(2, 1000);
        assertEquals("he", sb.toString());
    }

    @Test
    public void testDeleteInvalidStartIndex() {
        final StrBuilder sb = new StrBuilder("hello");
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.delete(-1, 2));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.delete(4, 2));
    }

    @Test
    public void testDeleteAllChar() {
        final StrBuilder sb = new StrBuilder("banana");
        sb.deleteAll('a');
        assertEquals("bnn", sb.toString());
    }

    @Test
    public void testDeleteAllString() {
        final StrBuilder sb = new StrBuilder("ababab");
        sb.deleteAll("ab");
        assertEquals("", sb.toString());
        sb.append("xyz");
        sb.deleteAll((String) null);
        assertEquals("xyz", sb.toString());
    }

    @Test
    public void testDeleteAllMatcher() {
        final StrBuilder sb = new StrBuilder("a1b2c3");
        sb.deleteAll(StrMatcher.charSetMatcher("123"));
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testDeleteCharAt() {
        final StrBuilder sb = new StrBuilder("abc");
        sb.deleteCharAt(1);
        assertEquals("ac", sb.toString());
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.deleteCharAt(10));
    }

    @Test
    public void testDeleteFirstChar() {
        final StrBuilder sb = new StrBuilder("banana");
        sb.deleteFirst('a');
        assertEquals("bnana", sb.toString());
    }

    @Test
    public void testDeleteFirstString() {
        final StrBuilder sb = new StrBuilder("ababab");
        sb.deleteFirst("ab");
        assertEquals("abab", sb.toString());
    }

    @Test
    public void testDeleteFirstMatcher() {
        final StrBuilder sb = new StrBuilder("a1b2");
        sb.deleteFirst(StrMatcher.charSetMatcher("12"));
        assertEquals("ab2", sb.toString());
    }

    @Test
    public void testEndsWith() {
        final StrBuilder sb = new StrBuilder("hello world");
        assertTrue(sb.endsWith("world"));
        assertFalse(sb.endsWith("hello"));
        assertFalse(sb.endsWith(null));
        assertTrue(sb.endsWith(""));
    }

    @Test
    public void testEqualsStrBuilder() {
        final StrBuilder sb1 = new StrBuilder("abc");
        final StrBuilder sb2 = new StrBuilder("abc");
        final StrBuilder sb3 = new StrBuilder("abd");
        assertTrue(sb1.equals(sb2));
        assertFalse(sb1.equals(sb3));
        assertFalse(sb1.equals((StrBuilder) null));
        assertTrue(sb1.equals(sb1));
    }

    @Test
    public void testEqualsObject() {
        final StrBuilder sb1 = new StrBuilder("abc");
        assertFalse(sb1.equals("abc"));
        assertFalse(sb1.equals(null));
    }

    @Test
    public void testEqualsIgnoreCase() {
        final StrBuilder sb1 = new StrBuilder("ABC");
        final StrBuilder sb2 = new StrBuilder("abc");
        final StrBuilder sb3 = new StrBuilder("abd");
        assertTrue(sb1.equalsIgnoreCase(sb2));
        assertFalse(sb1.equalsIgnoreCase(sb3));
        assertTrue(sb1.equalsIgnoreCase(sb1));
    }

    @Test
    public void testHashCodeConsistentWithEquals() {
        final StrBuilder sb1 = new StrBuilder("abc");
        final StrBuilder sb2 = new StrBuilder("abc");
        assertEquals(sb1.hashCode(), sb2.hashCode());
    }

    @Test
    public void testGetCharsNoDestination() {
        final StrBuilder sb = new StrBuilder("abc");
        final char[] result = sb.getChars((char[]) null);
        assertTrue(Arrays.equals(new char[] {'a', 'b', 'c'}, result));
    }

    @Test
    public void testGetCharsTooSmallDestinationCreatesNew() {
        final StrBuilder sb = new StrBuilder("abc");
        final char[] small = new char[1];
        final char[] result = sb.getChars(small);
        assertEquals(3, result.length);
        assertTrue(Arrays.equals(new char[] {'a', 'b', 'c'}, result));
    }

    @Test
    public void testGetCharsRange() {
        final StrBuilder sb = new StrBuilder("abcdef");
        final char[] dest = new char[6];
        sb.getChars(1, 4, dest, 0);
        assertEquals('b', dest[0]);
        assertEquals('c', dest[1]);
        assertEquals('d', dest[2]);
    }

    @Test
    public void testGetCharsRangeInvalid() {
        final StrBuilder sb = new StrBuilder("abc");
        final char[] dest = new char[3];
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.getChars(-1, 2, dest, 0));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.getChars(0, 10, dest, 0));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.getChars(2, 1, dest, 0));
    }

    @Test
    public void testIndexOfChar() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(1, sb.indexOf('b'));
        assertEquals(4, sb.indexOf('b', 2));
        assertEquals(-1, sb.indexOf('z'));
    }

    @Test
    public void testIndexOfString() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(0, sb.indexOf("abc"));
        assertEquals(3, sb.indexOf("abc", 1));
        assertEquals(-1, sb.indexOf((String) null));
    }

    @Test
    public void testIndexOfMatcher() {
        final StrBuilder sb = new StrBuilder("ab12cd");
        assertEquals(2, sb.indexOf(StrMatcher.charSetMatcher("0123456789")));
        assertEquals(-1, sb.indexOf((StrMatcher) null));
    }

    @Test
    public void testInsertBoolean() {
        final StrBuilder sb = new StrBuilder("ab");
        sb.insert(1, true);
        assertEquals("atrueb", sb.toString());
        sb.clear().append("ab").insert(1, false);
        assertEquals("afalseb", sb.toString());
    }

    @Test
    public void testInsertChar() {
        final StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, 'b');
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testInsertCharArrayNullUsesNullText() {
        final StrBuilder sb = new StrBuilder("ab");
        sb.setNullText("NULL");
        sb.insert(1, (char[]) null);
        assertEquals("aNULLb", sb.toString());
    }

    @Test
    public void testInsertCharArray() {
        final StrBuilder sb = new StrBuilder("ad");
        sb.insert(1, new char[] {'b', 'c'});
        assertEquals("abcd", sb.toString());
    }

    @Test
    public void testInsertCharArrayRange() {
        final StrBuilder sb = new StrBuilder("ad");
        sb.insert(1, new char[] {'x', 'b', 'c', 'y'}, 1, 2);
        assertEquals("abcd", sb.toString());
    }

    @Test
    public void testInsertCharArrayRangeInvalid() {
        final StrBuilder sb = new StrBuilder("ad");
        final char[] chars = new char[] {'b', 'c'};
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.insert(1, chars, -1, 1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.insert(1, chars, 0, 10));
    }

    @Test
    public void testInsertIndexOutOfBounds() {
        final StrBuilder sb = new StrBuilder("ab");
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.insert(-1, 'x'));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.insert(3, 'x'));
    }

    @Test
    public void testInsertNumericTypes() {
        final StrBuilder sb = new StrBuilder();
        sb.insert(0, 1.5d);
        sb.insert(0, "|");
        sb.insert(0, 2.5f);
        sb.insert(0, "|");
        sb.insert(0, 3);
        sb.insert(0, "|");
        sb.insert(0, 4L);
        assertEquals("4|3|2.5|1.5", sb.toString());
    }

    @Test
    public void testInsertObjectNull() {
        final StrBuilder sb = new StrBuilder("ab");
        sb.setNullText("N");
        sb.insert(1, (Object) null);
        assertEquals("aNb", sb.toString());
    }

    @Test
    public void testInsertStringNullUsesNullText() {
        final StrBuilder sb = new StrBuilder("ab");
        sb.insert(1, (String) null);
        assertEquals("ab", sb.toString());
        sb.setNullText("X");
        sb.insert(1, (String) null);
        assertEquals("aXb", sb.toString());
    }

    @Test
    public void testIsEmptyIsNotEmpty() {
        final StrBuilder sb = new StrBuilder();
        assertTrue(sb.isEmpty());
        assertFalse(sb.isNotEmpty());
        sb.append("x");
        assertFalse(sb.isEmpty());
        assertTrue(sb.isNotEmpty());
    }

    @Test
    public void testLastIndexOfChar() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(4, sb.lastIndexOf('b'));
        assertEquals(1, sb.lastIndexOf('b', 2));
        assertEquals(-1, sb.lastIndexOf('z'));
    }

    @Test
    public void testLastIndexOfString() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(3, sb.lastIndexOf("abc"));
        assertEquals(-1, sb.lastIndexOf((String) null));
    }

    @Test
    public void testLastIndexOfMatcher() {
        final StrBuilder sb = new StrBuilder("a1b2c3");
        assertEquals(5, sb.lastIndexOf(StrMatcher.charSetMatcher("0123456789")));
        assertEquals(-1, sb.lastIndexOf((StrMatcher) null));
    }

    @Test
    public void testLeftString() {
        final StrBuilder sb = new StrBuilder("hello");
        assertEquals("he", sb.leftString(2));
        assertEquals("hello", sb.leftString(100));
        assertEquals("", sb.leftString(-1));
        assertEquals("", sb.leftString(0));
    }

    @Test
    public void testMidString() {
        final StrBuilder sb = new StrBuilder("hello");
        assertEquals("ell", sb.midString(1, 3));
        assertEquals("hello", sb.midString(-5, 100));
        assertEquals("", sb.midString(1, -1));
        assertEquals("", sb.midString(100, 2));
    }

    @Test
    public void testRightString() {
        final StrBuilder sb = new StrBuilder("hello");
        assertEquals("lo", sb.rightString(2));
        assertEquals("hello", sb.rightString(100));
        assertEquals("", sb.rightString(-1));
    }

    @Test
    public void testLength() {
        final StrBuilder sb = new StrBuilder("hello");
        assertEquals(5, sb.length());
        assertEquals(5, sb.size());
    }

    @Test
    public void testMinimizeCapacity() {
        final StrBuilder sb = new StrBuilder(100);
        sb.append("abc");
        assertTrue(sb.capacity() >= 100);
        sb.minimizeCapacity();
        assertEquals(3, sb.capacity());
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testReadFromReader() throws IOException {
        final StrBuilder sb = new StrBuilder();
        final int read = sb.readFrom(new StringReader("hello"));
        assertEquals(5, read);
        assertEquals("hello", sb.toString());
    }

    @Test
    public void testReadFromCharBuffer() throws IOException {
        final StrBuilder sb = new StrBuilder();
        final java.nio.CharBuffer buf = java.nio.CharBuffer.wrap("world".toCharArray());
        final int read = sb.readFrom(buf);
        assertEquals(5, read);
        assertEquals("world", sb.toString());
    }

    @Test
    public void testReadFromGenericReadable() throws IOException {
        final StrBuilder sb = new StrBuilder();
        final Readable readable = new Readable() {
            private boolean done;
            @Override
            public int read(final java.nio.CharBuffer cb) {
                if (done) {
                    return -1;
                }
                done = true;
                cb.put("abc");
                return 3;
            }
        };
        final int read = sb.readFrom(readable);
        assertEquals(3, read);
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testReplace() {
        final StrBuilder sb = new StrBuilder("hello world");
        sb.replace(0, 5, "goodbye");
        assertEquals("goodbye world", sb.toString());
    }

    @Test
    public void testReplaceShrink() {
        final StrBuilder sb = new StrBuilder("hello world");
        sb.replace(6, 11, "x");
        assertEquals("hello x", sb.toString());
    }

    @Test
    public void testReplaceWithNullDeletesRange() {
        final StrBuilder sb = new StrBuilder("hello world");
        sb.replace(5, 11, null);
        assertEquals("hello", sb.toString());
    }

    @Test
    public void testReplaceMatcher() {
        final StrBuilder sb = new StrBuilder("a1b2c3");
        sb.replace(StrMatcher.charSetMatcher("0123456789"), "#", 0, sb.length(), -1);
        assertEquals("a#b#c#", sb.toString());
    }

    @Test
    public void testReplaceAllChar() {
        final StrBuilder sb = new StrBuilder("banana");
        sb.replaceAll('a', 'o');
        assertEquals("bonono", sb.toString());
    }

    @Test
    public void testReplaceAllString() {
        final StrBuilder sb = new StrBuilder("ababab");
        sb.replaceAll("ab", "x");
        assertEquals("xxx", sb.toString());
    }

    @Test
    public void testReplaceAllStringNullReplacement() {
        final StrBuilder sb = new StrBuilder("ababab");
        sb.replaceAll("ab", (String) null);
        assertEquals("", sb.toString());
    }

    @Test
    public void testReplaceAllMatcher() {
        final StrBuilder sb = new StrBuilder("a1b2c3");
        sb.replaceAll(StrMatcher.charSetMatcher("0123456789"), "#");
        assertEquals("a#b#c#", sb.toString());
    }

    @Test
    public void testReplaceFirstChar() {
        final StrBuilder sb = new StrBuilder("banana");
        sb.replaceFirst('a', 'o');
        assertEquals("bonana", sb.toString());
    }

    @Test
    public void testReplaceFirstString() {
        final StrBuilder sb = new StrBuilder("ababab");
        sb.replaceFirst("ab", "x");
        assertEquals("xabab", sb.toString());
    }

    @Test
    public void testReplaceFirstMatcher() {
        final StrBuilder sb = new StrBuilder("a1b2c3");
        sb.replaceFirst(StrMatcher.charSetMatcher("0123456789"), "#");
        assertEquals("a#b2c3", sb.toString());
    }

    @Test
    public void testReverseEmpty() {
        final StrBuilder sb = new StrBuilder();
        sb.reverse();
        assertEquals("", sb.toString());
    }

    @Test
    public void testReverseOddLength() {
        final StrBuilder sb = new StrBuilder("abcde");
        sb.reverse();
        assertEquals("edcba", sb.toString());
    }

    @Test
    public void testReverseSupplementaryCodePoint() {
        final String supplementary = new String(Character.toChars(0x1F600));
        final StrBuilder sb = new StrBuilder("a" + supplementary + "b");
        sb.reverse();
        assertEquals("b" + supplementary + "a", sb.toString());
    }

    @Test
    public void testSetCharAt() {
        final StrBuilder sb = new StrBuilder("abc");
        sb.setCharAt(1, 'X');
        assertEquals("aXc", sb.toString());
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.setCharAt(-1, 'x'));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.setCharAt(3, 'x'));
    }

    @Test
    public void testSetLengthShrinkAndGrow() {
        final StrBuilder sb = new StrBuilder("hello");
        sb.setLength(3);
        assertEquals("hel", sb.toString());
        sb.setLength(5);
        assertEquals(5, sb.length());
        assertEquals('\0', sb.charAt(3));
        assertEquals('\0', sb.charAt(4));
    }

    @Test
    public void testSetLengthNegativeThrows() {
        final StrBuilder sb = new StrBuilder("hello");
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.setLength(-1));
    }

    @Test
    public void testNullTextSetterGetter() {
        final StrBuilder sb = new StrBuilder();
        assertNull(sb.getNullText());
        sb.setNullText("NULL");
        assertEquals("NULL", sb.getNullText());
        sb.setNullText("");
        assertNull(sb.getNullText());
        sb.setNullText(null);
        assertNull(sb.getNullText());
    }

    @Test
    public void testStartsWith() {
        final StrBuilder sb = new StrBuilder("hello world");
        assertTrue(sb.startsWith("hello"));
        assertFalse(sb.startsWith("world"));
        assertFalse(sb.startsWith(null));
        assertTrue(sb.startsWith(""));
    }

    @Test
    public void testSubSequence() {
        final StrBuilder sb = new StrBuilder("hello");
        final CharSequence seq = sb.subSequence(1, 4);
        assertEquals("ell", seq.toString());
    }

    @Test
    public void testSubSequenceInvalid() {
        final StrBuilder sb = new StrBuilder("hello");
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.subSequence(-1, 2));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.subSequence(0, 100));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.subSequence(3, 1));
    }

    @Test
    public void testSubstringFromStart() {
        final StrBuilder sb = new StrBuilder("hello");
        assertEquals("llo", sb.substring(2));
    }

    @Test
    public void testSubstringRangeEndTooLargeTreatedAsSize() {
        final StrBuilder sb = new StrBuilder("hello");
        assertEquals("llo", sb.substring(2, 1000));
    }

    @Test
    public void testSubstringInvalid() {
        final StrBuilder sb = new StrBuilder("hello");
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.substring(-1, 2));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.substring(3, 1));
    }

    @Test
    public void testToCharArrayEmpty() {
        final StrBuilder sb = new StrBuilder();
        final char[] result = sb.toCharArray();
        assertEquals(0, result.length);
    }

    @Test
    public void testToCharArray() {
        final StrBuilder sb = new StrBuilder("abc");
        final char[] result = sb.toCharArray();
        assertTrue(Arrays.equals(new char[] {'a', 'b', 'c'}, result));
    }

    @Test
    public void testToCharArrayRange() {
        final StrBuilder sb = new StrBuilder("abcdef");
        final char[] result = sb.toCharArray(1, 4);
        assertTrue(Arrays.equals(new char[] {'b', 'c', 'd'}, result));
    }

    @Test
    public void testToCharArrayRangeEmpty() {
        final StrBuilder sb = new StrBuilder("abcdef");
        final char[] result = sb.toCharArray(2, 2);
        assertEquals(0, result.length);
    }

    @Test
    public void testToStringIndependentOfBuilder() {
        final StrBuilder sb = new StrBuilder("abc");
        final String str = sb.toString();
        sb.append("d");
        assertEquals("abc", str);
        assertEquals("abcd", sb.toString());
    }

    @Test
    public void testToStringBuffer() {
        final StrBuilder sb = new StrBuilder("abc");
        final StringBuffer buf = sb.toStringBuffer();
        assertEquals("abc", buf.toString());
    }

    @Test
    public void testToStringBuilderJdk() {
        final StrBuilder sb = new StrBuilder("abc");
        final StringBuilder jdkSb = sb.toStringBuilder();
        assertEquals("abc", jdkSb.toString());
    }

    @Test
    public void testTrim() {
        final StrBuilder sb = new StrBuilder("  hello world  ");
        sb.trim();
        assertEquals("hello world", sb.toString());
    }

    @Test
    public void testTrimAllWhitespace() {
        final StrBuilder sb = new StrBuilder("    ");
        sb.trim();
        assertEquals("", sb.toString());
    }

    @Test
    public void testTrimEmpty() {
        final StrBuilder sb = new StrBuilder();
        sb.trim();
        assertEquals("", sb.toString());
    }

    @Test
    public void testChainedAppendsReturnSameInstance() {
        final StrBuilder sb = new StrBuilder();
        final StrBuilder result = sb.append("a").append(1).append(true).append('c');
        assertSame(sb, result);
        assertEquals("a1truec", sb.toString());
    }

    @Test
    public void testCharSequenceInterfaceMethods() {
        final CharSequence seq = new StrBuilder("abc");
        assertEquals(3, seq.length());
        assertEquals('b', seq.charAt(1));
    }

    @Test
    public void testAppendableInterfaceMethod() throws IOException {
        final Appendable appendable = new StrBuilder();
        appendable.append('x');
        appendable.append("yz");
        assertEquals("xyz", appendable.toString());
    }

    @Test
    public void testGrowthBeyondInitialCapacity() {
        final StrBuilder sb = new StrBuilder(4);
        final List<Character> expected = new ArrayList<Character>();
        for (int i = 0; i < 50; i++) {
            sb.append((char) ('a' + i % 26));
            expected.add((char) ('a' + i % 26));
        }
        assertEquals(50, sb.length());
        assertTrue(sb.capacity() >= 50);
        final StringBuilder expectedStr = new StringBuilder();
        for (final Character c : expected) {
            expectedStr.append(c.charValue());
        }
        assertEquals(expectedStr.toString(), sb.toString());
    }
}
