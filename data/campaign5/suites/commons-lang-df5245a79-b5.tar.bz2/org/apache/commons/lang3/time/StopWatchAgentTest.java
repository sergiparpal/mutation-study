/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.Test;

/**
 * Tests for {@link StopWatch}.
 */
class StopWatchAgentTest {

    private static void sleepQuietly(final long millis) {
        try {
            Thread.sleep(millis);
        } catch (final InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    @Test
    void testCreateReturnsUnstartedStopWatch() {
        final StopWatch watch = StopWatch.create();
        assertFalse(watch.isStarted());
        assertTrue(watch.isStopped());
        assertFalse(watch.isSuspended());
        assertEquals(0, watch.getTime());
        assertEquals(0, watch.getNanoTime());
        assertTrue(watch.getSplits().isEmpty());
    }

    @Test
    void testCreateStartedReturnsRunningStopWatch() {
        final StopWatch watch = StopWatch.createStarted();
        assertTrue(watch.isStarted());
        assertFalse(watch.isStopped());
        assertFalse(watch.isSuspended());
    }

    @Test
    void testDefaultConstructorHasNullMessage() {
        final StopWatch watch = new StopWatch();
        assertNull(watch.getMessage());
    }

    @Test
    void testConstructorWithMessage() {
        final StopWatch watch = new StopWatch("my-watch");
        assertEquals("my-watch", watch.getMessage());
    }

    @Test
    void testStartAndStopRecordsNonNegativeTime() {
        final StopWatch watch = new StopWatch();
        watch.start();
        sleepQuietly(20);
        watch.stop();
        assertTrue(watch.isStopped());
        assertFalse(watch.isStarted());
        assertTrue(watch.getNanoTime() >= 0);
        assertTrue(watch.getTime() >= 0);
        assertTrue(watch.getTime(TimeUnit.NANOSECONDS) >= watch.getTime(TimeUnit.MILLISECONDS));
    }

    @Test
    void testStartTwiceWithoutResetThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        final IllegalStateException e = assertThrows(IllegalStateException.class, watch::start);
        assertEquals("Stopwatch already started.", e.getMessage());
    }

    @Test
    void testStartAfterStopWithoutResetThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        final IllegalStateException e = assertThrows(IllegalStateException.class, watch::start);
        assertEquals("Stopwatch must be reset before being restarted.", e.getMessage());
    }

    @Test
    void testStopBeforeStartThrows() {
        final StopWatch watch = new StopWatch();
        final IllegalStateException e = assertThrows(IllegalStateException.class, watch::stop);
        assertEquals("Stopwatch is not running.", e.getMessage());
    }

    @Test
    void testStopTwiceThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        assertThrows(IllegalStateException.class, watch::stop);
    }

    @Test
    void testResetAllowsRestart() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        watch.reset();
        assertFalse(watch.isStarted());
        assertTrue(watch.isStopped());
        assertEquals(0, watch.getTime());
        assertTrue(watch.getSplits().isEmpty());
        watch.start();
        assertTrue(watch.isStarted());
        watch.stop();
    }

    @Test
    void testSuspendBeforeStartThrows() {
        final StopWatch watch = new StopWatch();
        final IllegalStateException e = assertThrows(IllegalStateException.class, watch::suspend);
        assertEquals("Stopwatch must be running to suspend.", e.getMessage());
    }

    @Test
    void testResumeWithoutSuspendThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        final IllegalStateException e = assertThrows(IllegalStateException.class, watch::resume);
        assertEquals("Stopwatch must be suspended to resume.", e.getMessage());
    }

    @Test
    void testSuspendTwiceThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.suspend();
        assertTrue(watch.isSuspended());
        assertThrows(IllegalStateException.class, watch::suspend);
    }

    @Test
    void testSuspendResumeExcludesPausedTime() {
        final StopWatch watch = new StopWatch();
        watch.start();
        sleepQuietly(20);
        watch.suspend();
        final long suspendedNanos = watch.getNanoTime();
        sleepQuietly(50);
        assertEquals(suspendedNanos, watch.getNanoTime());
        watch.resume();
        assertTrue(watch.isStarted());
        assertFalse(watch.isSuspended());
        watch.stop();
        assertTrue(watch.getNanoTime() >= suspendedNanos);
    }

    @Test
    void testStopWhileSuspendedKeepsSuspendedTime() {
        final StopWatch watch = new StopWatch();
        watch.start();
        sleepQuietly(10);
        watch.suspend();
        final long suspendedNanos = watch.getNanoTime();
        sleepQuietly(30);
        watch.stop();
        assertTrue(watch.isStopped());
        assertEquals(suspendedNanos, watch.getNanoTime());
    }

    @Test
    void testSplitWithoutRunningThrows() {
        final StopWatch watch = new StopWatch();
        final IllegalStateException e = assertThrows(IllegalStateException.class, watch::split);
        assertEquals("Stopwatch is not running.", e.getMessage());
    }

    @Test
    void testUnsplitWithoutSplitThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        final IllegalStateException e = assertThrows(IllegalStateException.class, watch::unsplit);
        assertEquals("Stopwatch has not been split.", e.getMessage());
    }

    @Test
    void testGetSplitTimeWithoutSplitThrows() {
        final StopWatch watch = new StopWatch();
        watch.start();
        assertThrows(IllegalStateException.class, watch::getSplitNanoTime);
        assertThrows(IllegalStateException.class, watch::getSplitDuration);
        assertThrows(IllegalStateException.class, watch::getSplitTime);
    }

    @Test
    void testSplitRecordsSnapshotAndKeepsRunning() {
        final StopWatch watch = new StopWatch();
        watch.start();
        sleepQuietly(20);
        watch.split();
        final long splitNanos = watch.getSplitNanoTime();
        assertTrue(splitNanos >= 0);
        assertTrue(watch.isStarted());
        assertFalse(watch.isStopped());
        final List<StopWatch.Split> splits = watch.getSplits();
        assertEquals(1, splits.size());
        assertEquals("0", splits.get(0).getLabel());
        assertEquals(splitNanos, splits.get(0).getDuration().toNanos());
    }

    @Test
    void testSplitWithLabel() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split("first");
        assertEquals("first", watch.getSplits().get(0).getLabel());
        assertEquals(1, watch.getSplits().size());
    }

    @Test
    void testMultipleSplitsAccumulate() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split("a");
        sleepQuietly(10);
        watch.split("b");
        final List<StopWatch.Split> splits = watch.getSplits();
        assertEquals(2, splits.size());
        assertEquals("a", splits.get(0).getLabel());
        assertEquals("b", splits.get(1).getLabel());
        assertTrue(splits.get(1).getDuration().toNanos() >= splits.get(0).getDuration().toNanos());
    }

    @Test
    void testUnsplitRemovesLastSplit() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split("a");
        watch.split("b");
        assertEquals(2, watch.getSplits().size());
        watch.unsplit();
        assertEquals(1, watch.getSplits().size());
        assertEquals("a", watch.getSplits().get(0).getLabel());
    }

    @Test
    void testGetSplitsReturnsUnmodifiableList() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        final List<StopWatch.Split> splits = watch.getSplits();
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                splits.add(new StopWatch.Split("x", Duration.ZERO));
            }
        });
    }

    @Test
    void testSplitClassAccessors() {
        final Duration duration = Duration.ofMillis(123);
        final StopWatch.Split split = new StopWatch.Split("label", duration);
        assertEquals("label", split.getLabel());
        assertSame(duration, split.getDuration());
        assertEquals("Split [label, " + duration + "])", split.toString());
    }

    @Test
    void testGetStartInstantBeforeStartThrows() {
        final StopWatch watch = new StopWatch();
        final IllegalStateException e = assertThrows(IllegalStateException.class, watch::getStartInstant);
        assertEquals("Stopwatch has not been started", e.getMessage());
    }

    @Test
    void testGetStopInstantBeforeStartThrows() {
        final StopWatch watch = new StopWatch();
        assertThrows(IllegalStateException.class, watch::getStopInstant);
    }

    @Test
    void testGetStartInstantAndStopInstant() {
        final StopWatch watch = new StopWatch();
        final Instant before = Instant.now();
        watch.start();
        assertNotNull(watch.getStartInstant());
        assertNull(watch.getStopInstant());
        watch.stop();
        final Instant after = Instant.now();
        assertNotNull(watch.getStopInstant());
        assertFalse(watch.getStartInstant().isBefore(before.minusSeconds(1)));
        assertFalse(watch.getStopInstant().isAfter(after.plusSeconds(1)));
        assertTrue(!watch.getStopInstant().isBefore(watch.getStartInstant()));
    }

    @Test
    void testDeprecatedStartStopTimeMatchInstants() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        assertEquals(watch.getStartInstant().toEpochMilli(), watch.getStartTime());
        assertEquals(watch.getStopInstant().toEpochMilli(), watch.getStopTime());
    }

    @Test
    void testGetDurationMatchesNanoTime() {
        final StopWatch watch = new StopWatch();
        watch.start();
        sleepQuietly(10);
        watch.stop();
        assertEquals(Duration.ofNanos(watch.getNanoTime()), watch.getDuration());
    }

    @Test
    void testGetTimeTimeUnitConversion() {
        final StopWatch watch = new StopWatch();
        watch.start();
        sleepQuietly(5);
        watch.stop();
        final long nanos = watch.getNanoTime();
        assertEquals(TimeUnit.NANOSECONDS.toSeconds(nanos), watch.getTime(TimeUnit.SECONDS));
        assertEquals(TimeUnit.NANOSECONDS.toMillis(nanos), watch.getTime(TimeUnit.MILLISECONDS));
    }

    @Test
    void testToStringWithoutMessage() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.stop();
        assertEquals(watch.formatTime(), watch.toString());
    }

    @Test
    void testToStringWithMessage() {
        final StopWatch watch = new StopWatch("prefix");
        watch.start();
        watch.stop();
        assertEquals("prefix " + watch.formatTime(), watch.toString());
    }

    @Test
    void testToSplitStringWithAndWithoutMessage() {
        final StopWatch unnamed = new StopWatch();
        unnamed.start();
        unnamed.split();
        assertEquals(unnamed.formatSplitTime(), unnamed.toSplitString());

        final StopWatch named = new StopWatch("prefix");
        named.start();
        named.split();
        assertEquals("prefix " + named.formatSplitTime(), named.toSplitString());
    }

    @Test
    void testFormatTimeAndSplitTimeHaveExpectedPattern() {
        final StopWatch watch = new StopWatch();
        watch.start();
        watch.split();
        watch.stop();
        assertTrue(watch.formatTime().matches("\\d+:\\d{2}:\\d{2}\\.\\d{3}"));
        assertTrue(watch.formatSplitTime().matches("\\d+:\\d{2}:\\d{2}\\.\\d{3}"));
    }

    @Test
    void testGetOnSupplierStartsSuspendsAndReturnsValue() {
        final StopWatch watch = new StopWatch();
        final String result = watch.get(new java.util.function.Supplier<String>() {
            @Override
            public String get() {
                sleepQuietly(10);
                return "value";
            }
        });
        assertEquals("value", result);
        assertTrue(watch.isSuspended());
        assertTrue(watch.getNanoTime() > 0);
    }

    @Test
    void testRunOnRunnableStartsAndSuspends() {
        final StopWatch watch = new StopWatch();
        final boolean[] ran = new boolean[1];
        watch.run(new Runnable() {
            @Override
            public void run() {
                ran[0] = true;
                sleepQuietly(5);
            }
        });
        assertTrue(ran[0]);
        assertTrue(watch.isSuspended());
    }

    @Test
    void testRunResumesAlreadySuspendedWatch() {
        final StopWatch watch = new StopWatch();
        watch.start();
        sleepQuietly(5);
        watch.suspend();
        final long beforeResume = watch.getNanoTime();
        watch.run(new Runnable() {
            @Override
            public void run() {
                sleepQuietly(5);
            }
        });
        assertTrue(watch.isSuspended());
        assertTrue(watch.getNanoTime() >= beforeResume);
    }

    @Test
    void testGetTPropagatesCheckedException() {
        final StopWatch watch = new StopWatch();
        final Exception thrown = assertThrows(java.io.IOException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                watch.getT(new org.apache.commons.lang3.function.FailableSupplier<String, java.io.IOException>() {
                    @Override
                    public String get() throws java.io.IOException {
                        throw new java.io.IOException("boom");
                    }
                });
            }
        });
        assertEquals("boom", thrown.getMessage());
        assertTrue(watch.isSuspended());
    }

    @Test
    void testRunTPropagatesCheckedExceptionAndRunsSideEffect() {
        final StopWatch watch = new StopWatch();
        final boolean[] ran = new boolean[1];
        final Exception thrown = assertThrows(java.io.IOException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                watch.runT(new org.apache.commons.lang3.function.FailableRunnable<java.io.IOException>() {
                    @Override
                    public void run() throws java.io.IOException {
                        ran[0] = true;
                        throw new java.io.IOException("fail");
                    }
                });
            }
        });
        assertEquals("fail", thrown.getMessage());
        assertTrue(ran[0]);
        assertTrue(watch.isSuspended());
    }

    @Test
    void testIsStartedStoppedSuspendedForUnstartedWatch() {
        final StopWatch watch = new StopWatch();
        assertFalse(watch.isStarted());
        assertTrue(watch.isStopped());
        assertFalse(watch.isSuspended());
    }

    @Test
    void testNanoTimeZeroWhenUnstarted() {
        final StopWatch watch = new StopWatch();
        assertEquals(0, watch.getNanoTime());
        assertEquals(0, watch.getTime());
    }
}
