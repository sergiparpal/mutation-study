/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link FieldUtils}.
 */
public class FieldUtilsAgentTest {

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.FIELD)
    private @interface AgentMarker {
    }

    static class Grandparent {
        public static final String GRANDPARENT_STATIC = "grandparentStatic";
        @SuppressWarnings("unused")
        private final String privateGrandparentField = "privateGrandparent";
    }

    interface IfaceA {
        String AMBIGUOUS = "a";
    }

    interface IfaceB {
        String AMBIGUOUS = "b";
    }

    static class AmbiguousClass implements IfaceA, IfaceB {
    }

    interface InterfaceWithField {
        String INTERFACE_FIELD = "interfaceField";
    }

    static class Parent extends Grandparent {
        public static int publicStaticParentField = 1;
        protected String protectedParentField = "protectedParent";
        @AgentMarker
        private String annotatedField = "annotated";
        @SuppressWarnings("unused")
        private final String finalParentField = "finalParent";
    }

    static class Child extends Parent implements InterfaceWithField {
        public String publicChildField = "publicChild";
        @AgentMarker
        public String anotherAnnotated = "anotherAnnotated";
        @SuppressWarnings("unused")
        private String privateChildField = "privateChild";
    }

    static class StaticHolder {
        public static final int FINAL_STATIC = 42;
        public static int MUTABLE_STATIC = 10;
        protected static String PROTECTED_STATIC = "protectedStatic";
    }

    static class FinalFieldHolder {
        public final String value = "original";
    }

    // ---------- getAllFields / getAllFieldsList ----------

    @Test
    public void testGetAllFieldsNullClass() {
        assertThrows(NullPointerException.class, () -> FieldUtils.getAllFields(null));
    }

    @Test
    public void testGetAllFieldsIncludesInherited() {
        final Field[] fields = FieldUtils.getAllFields(Child.class);
        boolean foundPublicChild = false;
        boolean foundProtectedParent = false;
        boolean foundGrandparentStatic = false;
        for (final Field f : fields) {
            if ("publicChildField".equals(f.getName())) {
                foundPublicChild = true;
            }
            if ("protectedParentField".equals(f.getName())) {
                foundProtectedParent = true;
            }
            if ("GRANDPARENT_STATIC".equals(f.getName())) {
                foundGrandparentStatic = true;
            }
        }
        assertTrue(foundPublicChild);
        assertTrue(foundProtectedParent);
        assertTrue(foundGrandparentStatic);
    }

    @Test
    public void testGetAllFieldsListMatchesArray() {
        final List<Field> list = FieldUtils.getAllFieldsList(Child.class);
        final Field[] array = FieldUtils.getAllFields(Child.class);
        assertEquals(list.size(), array.length);
    }

    @Test
    public void testGetAllFieldsListNoParentFields() {
        // Object itself has no declared fields.
        final List<Field> list = FieldUtils.getAllFieldsList(Object.class);
        assertTrue(list.isEmpty());
    }

    // ---------- getDeclaredField ----------

    @Test
    public void testGetDeclaredFieldNullClass() {
        assertThrows(NullPointerException.class, () -> FieldUtils.getDeclaredField(null, "x"));
    }

    @Test
    public void testGetDeclaredFieldBlankName() {
        assertThrows(IllegalArgumentException.class, () -> FieldUtils.getDeclaredField(Child.class, " "));
        assertThrows(IllegalArgumentException.class, () -> FieldUtils.getDeclaredField(Child.class, ""));
        assertThrows(IllegalArgumentException.class, () -> FieldUtils.getDeclaredField(Child.class, null));
    }

    @Test
    public void testGetDeclaredFieldNotFound() {
        assertNull(FieldUtils.getDeclaredField(Child.class, "doesNotExist"));
    }

    @Test
    public void testGetDeclaredFieldOnlyConsidersOwnClass() {
        // protectedParentField is declared on Parent, not Child.
        assertNull(FieldUtils.getDeclaredField(Child.class, "protectedParentField", true));
        assertNotNull(FieldUtils.getDeclaredField(Parent.class, "protectedParentField", true));
    }

    @Test
    public void testGetDeclaredFieldPrivateWithoutForceAccess() {
        assertNull(FieldUtils.getDeclaredField(Child.class, "privateChildField"));
    }

    @Test
    public void testGetDeclaredFieldPrivateWithForceAccess() {
        final Field field = FieldUtils.getDeclaredField(Child.class, "privateChildField", true);
        assertNotNull(field);
        assertTrue(field.isAccessible());
    }

    @Test
    public void testGetDeclaredFieldPublic() {
        final Field field = FieldUtils.getDeclaredField(Child.class, "publicChildField");
        assertNotNull(field);
        assertEquals("publicChildField", field.getName());
    }

    // ---------- getField ----------

    @Test
    public void testGetFieldNullClass() {
        assertThrows(NullPointerException.class, () -> FieldUtils.getField(null, "x"));
    }

    @Test
    public void testGetFieldBlankName() {
        assertThrows(IllegalArgumentException.class, () -> FieldUtils.getField(Child.class, ""));
    }

    @Test
    public void testGetFieldInheritedPublicStatic() {
        final Field field = FieldUtils.getField(Child.class, "publicStaticParentField");
        assertNotNull(field);
        assertEquals(Parent.class, field.getDeclaringClass());
    }

    @Test
    public void testGetFieldInheritedFromGrandparent() {
        final Field field = FieldUtils.getField(Child.class, "GRANDPARENT_STATIC");
        assertNotNull(field);
        assertEquals(Grandparent.class, field.getDeclaringClass());
    }

    @Test
    public void testGetFieldNonPublicWithoutForceAccessReturnsNull() {
        assertNull(FieldUtils.getField(Child.class, "protectedParentField"));
    }

    @Test
    public void testGetFieldNonPublicWithForceAccess() {
        final Field field = FieldUtils.getField(Child.class, "protectedParentField", true);
        assertNotNull(field);
        assertTrue(field.isAccessible());
    }

    @Test
    public void testGetFieldFromInterface() {
        final Field field = FieldUtils.getField(Child.class, "INTERFACE_FIELD");
        assertNotNull(field);
        assertEquals(InterfaceWithField.class, field.getDeclaringClass());
    }

    @Test
    public void testGetFieldAmbiguousInterfaceFields() {
        assertThrows(IllegalArgumentException.class, () -> FieldUtils.getField(AmbiguousClass.class, "AMBIGUOUS"));
    }

    @Test
    public void testGetFieldNotFound() {
        assertNull(FieldUtils.getField(Child.class, "nonExistentField"));
    }

    // ---------- getFieldsWithAnnotation / getFieldsListWithAnnotation ----------

    @Test
    public void testGetFieldsListWithAnnotationNullAnnotation() {
        assertThrows(NullPointerException.class, () -> FieldUtils.getFieldsListWithAnnotation(Child.class, null));
    }

    @Test
    public void testGetFieldsListWithAnnotationNullClass() {
        assertThrows(NullPointerException.class, () -> FieldUtils.getFieldsListWithAnnotation(null, AgentMarker.class));
    }

    @Test
    public void testGetFieldsWithAnnotationFindsAllLevels() {
        final Field[] fields = FieldUtils.getFieldsWithAnnotation(Child.class, AgentMarker.class);
        assertEquals(2, fields.length);
        final List<Field> list = FieldUtils.getFieldsListWithAnnotation(Child.class, AgentMarker.class);
        assertEquals(2, list.size());
    }

    @Test
    public void testGetFieldsWithAnnotationNoneFound() {
        final Field[] fields = FieldUtils.getFieldsWithAnnotation(Grandparent.class, AgentMarker.class);
        assertEquals(0, fields.length);
    }

    // ---------- readField / readDeclaredField ----------

    @Test
    public void testReadFieldNullTarget() {
        assertThrows(NullPointerException.class, () -> FieldUtils.readField((Object) null, "x"));
    }

    @Test
    public void testReadFieldByNameOnInstance() throws IllegalAccessException {
        final Child child = new Child();
        final Object value = FieldUtils.readField(child, "publicChildField");
        assertEquals("publicChild", value);
    }

    @Test
    public void testReadFieldByNameNotFoundThrows() {
        final Child child = new Child();
        assertThrows(IllegalArgumentException.class, () -> FieldUtils.readField(child, "nope"));
    }

    @Test
    public void testReadFieldByNamePrivateWithoutForceAccessThrows() {
        final Child child = new Child();
        // privateChildField is not public anywhere so getField returns null -> IllegalArgumentException.
        assertThrows(IllegalArgumentException.class, () -> FieldUtils.readField(child, "privateChildField", false));
    }

    @Test
    public void testReadFieldByNamePrivateWithForceAccess() throws IllegalAccessException {
        final Child child = new Child();
        final Object value = FieldUtils.readField(child, "privateChildField", true);
        assertEquals("privateChild", value);
    }

    @Test
    public void testReadFieldNullField() {
        assertThrows(NullPointerException.class, () -> FieldUtils.readField((Field) null, new Child()));
    }

    @Test
    public void testReadFieldInaccessibleWithoutForceAccessThrows() throws Exception {
        final Field field = Child.class.getDeclaredField("privateChildField");
        assertThrows(IllegalAccessException.class, () -> FieldUtils.readField(field, new Child(), false));
    }

    @Test
    public void testReadFieldInaccessibleWithForceAccess() throws Exception {
        final Field field = Child.class.getDeclaredField("privateChildField");
        final Object value = FieldUtils.readField(field, new Child(), true);
        assertEquals("privateChild", value);
    }

    @Test
    public void testReadDeclaredFieldNullTarget() {
        assertThrows(NullPointerException.class, () -> FieldUtils.readDeclaredField(null, "x"));
    }

    @Test
    public void testReadDeclaredFieldOnlyOwnClass() {
        final Child child = new Child();
        // protectedParentField is declared on Parent, not Child, so readDeclaredField cannot find it.
        assertThrows(IllegalArgumentException.class, () -> FieldUtils.readDeclaredField(child, "protectedParentField", true));
    }

    @Test
    public void testReadDeclaredFieldWithForceAccess() throws IllegalAccessException {
        final Child child = new Child();
        final Object value = FieldUtils.readDeclaredField(child, "privateChildField", true);
        assertEquals("privateChild", value);
    }

    // ---------- readStaticField / readDeclaredStaticField ----------

    @Test
    public void testReadStaticFieldByName() throws IllegalAccessException {
        final Object value = FieldUtils.readStaticField(StaticHolder.class, "MUTABLE_STATIC");
        assertEquals(10, value);
    }

    @Test
    public void testReadStaticFieldByNameNotFoundThrows() {
        assertThrows(NullPointerException.class, () -> FieldUtils.readStaticField(StaticHolder.class, "nope"));
    }

    @Test
    public void testReadStaticFieldNonStaticFieldThrows() throws Exception {
        final Field field = FinalFieldHolder.class.getDeclaredField("value");
        assertThrows(IllegalArgumentException.class, () -> FieldUtils.readStaticField(field));
    }

    @Test
    public void testReadStaticFieldNullFieldThrows() {
        assertThrows(NullPointerException.class, () -> FieldUtils.readStaticField((Field) null));
    }

    @Test
    public void testReadDeclaredStaticFieldWithForceAccess() throws IllegalAccessException {
        final Object value = FieldUtils.readDeclaredStaticField(StaticHolder.class, "PROTECTED_STATIC", true);
        assertEquals("protectedStatic", value);
    }

    @Test
    public void testReadDeclaredStaticFieldNotFoundThrows() {
        assertThrows(NullPointerException.class, () -> FieldUtils.readDeclaredStaticField(StaticHolder.class, "missing"));
    }

    // ---------- writeField / writeDeclaredField ----------

    @Test
    public void testWriteFieldByNameAndReadBack() throws IllegalAccessException {
        final Child child = new Child();
        FieldUtils.writeField(child, "publicChildField", "changed");
        assertEquals("changed", child.publicChildField);
    }

    @Test
    public void testWriteFieldByNamePrivateWithoutForceAccessThrows() {
        final Child child = new Child();
        assertThrows(IllegalArgumentException.class, () -> FieldUtils.writeField(child, "privateChildField", "x", false));
    }

    @Test
    public void testWriteFieldByNamePrivateWithForceAccess() throws IllegalAccessException {
        final Child child = new Child();
        FieldUtils.writeField(child, "privateChildField", "newVal", true);
        assertEquals("newVal", FieldUtils.readField(child, "privateChildField", true));
    }

    @Test
    public void testWriteFieldNotAssignableValueThrows() {
        final Child child = new Child();
        assertThrows(IllegalArgumentException.class, () -> FieldUtils.writeField(child, "publicChildField", Integer.valueOf(1), false));
    }

    @Test
    public void testWriteFieldNullFieldThrows() {
        assertThrows(NullPointerException.class, () -> FieldUtils.writeField(null, new Child(), "x"));
    }

    @Test
    public void testWriteDeclaredFieldOnlyOwnClass() {
        final Child child = new Child();
        assertThrows(IllegalArgumentException.class, () -> FieldUtils.writeDeclaredField(child, "protectedParentField", "x", true));
    }

    @Test
    public void testWriteDeclaredFieldWithForceAccess() throws IllegalAccessException {
        final Child child = new Child();
        FieldUtils.writeDeclaredField(child, "privateChildField", "declaredWrite", true);
        assertEquals("declaredWrite", FieldUtils.readDeclaredField(child, "privateChildField", true));
    }

    // ---------- writeStaticField / writeDeclaredStaticField ----------

    @Test
    public void testWriteStaticFieldAndReadBack() throws IllegalAccessException {
        FieldUtils.writeStaticField(StaticHolder.class, "MUTABLE_STATIC", 99);
        assertEquals(99, StaticHolder.MUTABLE_STATIC);
        // restore for isolation from other tests.
        StaticHolder.MUTABLE_STATIC = 10;
    }

    @Test
    public void testWriteStaticFieldNonStaticThrows() throws Exception {
        final Field field = FinalFieldHolder.class.getDeclaredField("value");
        assertThrows(IllegalArgumentException.class, () -> FieldUtils.writeStaticField(field, "x"));
    }

    @Test
    public void testWriteStaticFieldNullFieldThrows() {
        assertThrows(NullPointerException.class, () -> FieldUtils.writeStaticField((Field) null, "x"));
    }

    @Test
    public void testWriteDeclaredStaticFieldWithForceAccess() throws IllegalAccessException {
        FieldUtils.writeDeclaredStaticField(StaticHolder.class, "PROTECTED_STATIC", "updated", true);
        assertEquals("updated", StaticHolder.PROTECTED_STATIC);
        StaticHolder.PROTECTED_STATIC = "protectedStatic";
    }

    @Test
    public void testWriteDeclaredStaticFieldNotFoundThrows() {
        assertThrows(NullPointerException.class, () -> FieldUtils.writeDeclaredStaticField(StaticHolder.class, "missing", "x"));
    }

    // ---------- removeFinalModifier ----------

    @Test
    @SuppressWarnings("deprecation")
    public void testRemoveFinalModifierOnFinalField() throws Exception {
        final Field field = FinalFieldHolder.class.getDeclaredField("value");
        assertTrue(Modifier.isFinal(field.getModifiers()));
        FieldUtils.removeFinalModifier(field);
        assertFalse(Modifier.isFinal(field.getModifiers()));
    }

    @Test
    @SuppressWarnings("deprecation")
    public void testRemoveFinalModifierNullFieldThrows() {
        assertThrows(NullPointerException.class, () -> FieldUtils.removeFinalModifier(null));
    }

    @Test
    @SuppressWarnings("deprecation")
    public void testRemoveFinalModifierOnNonFinalFieldIsNoOp() throws Exception {
        final Field field = StaticHolder.class.getDeclaredField("MUTABLE_STATIC");
        assertFalse(Modifier.isFinal(field.getModifiers()));
        FieldUtils.removeFinalModifier(field, true);
        assertFalse(Modifier.isFinal(field.getModifiers()));
    }

    // ---------- public constructor ----------

    @Test
    @SuppressWarnings("deprecation")
    public void testPublicConstructorExists() {
        assertNotNull(new FieldUtils());
    }
}
