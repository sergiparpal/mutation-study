/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link WordUtils}.
 */
@SuppressWarnings("deprecation")
class WordUtilsAgentTest {

    // ---- capitalize(String) ----

    @Test
    void testCapitalize_null() {
        assertNull(WordUtils.capitalize(null));
    }

    @Test
    void testCapitalize_empty() {
        assertEquals("", WordUtils.capitalize(""));
    }

    @Test
    void testCapitalize_basic() {
        assertEquals("I Am FINE", WordUtils.capitalize("i am FINE"));
    }

    @Test
    void testCapitalize_singleChar() {
        assertEquals("A", WordUtils.capitalize("a"));
    }

    // ---- capitalize(String, char[]) ----

    @Test
    void testCapitalizeWithDelimiters_null() {
        assertNull(WordUtils.capitalize(null, new char[] {'-'}));
    }

    @Test
    void testCapitalizeWithDelimiters_empty() {
        assertEquals("", WordUtils.capitalize("", new char[] {'-'}));
    }

    @Test
    void testCapitalizeWithDelimiters_emptyDelimiterArrayReturnsUnchanged() {
        assertEquals("i am fine", WordUtils.capitalize("i am fine", new char[0]));
    }

    @Test
    void testCapitalizeWithDelimiters_nullDelimitersMeansWhitespace() {
        assertEquals("I Am Fine", WordUtils.capitalize("i am fine", (char[]) null));
    }

    @Test
    void testCapitalizeWithDelimiters_customDelimiter() {
        assertEquals("I aM.Fine", WordUtils.capitalize("i aM.fine", new char[] {'.'}));
    }

    // ---- capitalizeFully(String) ----

    @Test
    void testCapitalizeFully_null() {
        assertNull(WordUtils.capitalizeFully(null));
    }

    @Test
    void testCapitalizeFully_empty() {
        assertEquals("", WordUtils.capitalizeFully(""));
    }

    @Test
    void testCapitalizeFully_basic() {
        assertEquals("I Am Fine", WordUtils.capitalizeFully("i am FINE"));
    }

    // ---- capitalizeFully(String, char[]) ----

    @Test
    void testCapitalizeFullyWithDelimiters_nullDelimitersArrayMeansWhitespace() {
        assertEquals("I Am.fine", WordUtils.capitalizeFully("i aM.fine", (char[]) null));
    }

    @Test
    void testCapitalizeFullyWithDelimiters_emptyDelimiterArray() {
        final String str = "i aM.fine";
        assertEquals(str, WordUtils.capitalizeFully(str, new char[0]));
    }

    @Test
    void testCapitalizeFullyWithDelimiters_customDelimiter() {
        assertEquals("I am.Fine", WordUtils.capitalizeFully("i aM.fine", new char[] {'.'}));
    }

    @Test
    void testCapitalizeFullyWithDelimiters_nullString() {
        assertNull(WordUtils.capitalizeFully(null, new char[] {'.'}));
    }

    // ---- containsAllWords ----

    @Test
    void testContainsAllWords_nullWord() {
        assertFalse(WordUtils.containsAllWords(null, "ab"));
    }

    @Test
    void testContainsAllWords_emptyWord() {
        assertFalse(WordUtils.containsAllWords("", "ab"));
    }

    @Test
    void testContainsAllWords_nullWordsArray() {
        assertFalse(WordUtils.containsAllWords("abc def", (CharSequence[]) null));
    }

    @Test
    void testContainsAllWords_emptyWordsArray() {
        assertFalse(WordUtils.containsAllWords("abc def"));
    }

    @Test
    void testContainsAllWords_substringNotWholeWord() {
        assertFalse(WordUtils.containsAllWords("abcd", "ab", "cd"));
    }

    @Test
    void testContainsAllWords_allWordsPresent() {
        assertTrue(WordUtils.containsAllWords("abc def", "def", "abc"));
    }

    @Test
    void testContainsAllWords_oneWordMissing() {
        assertFalse(WordUtils.containsAllWords("abc def", "def", "xyz"));
    }

    @Test
    void testContainsAllWords_blankElementInWordsArray() {
        assertFalse(WordUtils.containsAllWords("abc def", "abc", " "));
    }

    // ---- initials(String) ----

    @Test
    void testInitials_null() {
        assertNull(WordUtils.initials(null));
    }

    @Test
    void testInitials_empty() {
        assertEquals("", WordUtils.initials(""));
    }

    @Test
    void testInitials_basic() {
        assertEquals("BJL", WordUtils.initials("Ben John Lee"));
    }

    @Test
    void testInitials_withDotNoWhitespaceDelimiter() {
        assertEquals("BJ", WordUtils.initials("Ben J.Lee"));
    }

    // ---- initials(String, char[]) ----

    @Test
    void testInitialsWithDelimiters_null() {
        assertNull(WordUtils.initials(null, new char[] {' '}));
    }

    @Test
    void testInitialsWithDelimiters_empty() {
        assertEquals("", WordUtils.initials("", new char[] {' '}));
    }

    @Test
    void testInitialsWithDelimiters_nullMeansWhitespace() {
        assertEquals("BJL", WordUtils.initials("Ben John Lee", (char[]) null));
    }

    @Test
    void testInitialsWithDelimiters_customDelimiters() {
        assertEquals("BJL", WordUtils.initials("Ben J.Lee", new char[] {' ', '.'}));
    }

    @Test
    void testInitialsWithDelimiters_emptyArrayReturnsEmptyString() {
        assertEquals("", WordUtils.initials("Ben John Lee", new char[0]));
    }

    // ---- swapCase ----

    @Test
    void testSwapCase_null() {
        assertNull(WordUtils.swapCase(null));
    }

    @Test
    void testSwapCase_empty() {
        assertEquals("", WordUtils.swapCase(""));
    }

    @Test
    void testSwapCase_basic() {
        assertEquals("tHE DOG HAS A bone", WordUtils.swapCase("The dog has a BONE"));
    }

    @Test
    void testSwapCase_titleCaseCharacter() {
        // U+01C5 'Dz' is a title case character: should become lower case.
        final String input = "ǅbc";
        final String result = WordUtils.swapCase(input);
        assertEquals("ǆBC", result);
    }

    // ---- uncapitalize(String) ----

    @Test
    void testUncapitalize_null() {
        assertNull(WordUtils.uncapitalize(null));
    }

    @Test
    void testUncapitalize_empty() {
        assertEquals("", WordUtils.uncapitalize(""));
    }

    @Test
    void testUncapitalize_basic() {
        assertEquals("i am fINE", WordUtils.uncapitalize("I Am FINE"));
    }

    // ---- uncapitalize(String, char[]) ----

    @Test
    void testUncapitalizeWithDelimiters_nullString() {
        assertNull(WordUtils.uncapitalize(null, new char[] {'.'}));
    }

    @Test
    void testUncapitalizeWithDelimiters_emptyString() {
        assertEquals("", WordUtils.uncapitalize("", new char[] {'.'}));
    }

    @Test
    void testUncapitalizeWithDelimiters_nullDelimitersMeansWhitespace() {
        assertEquals("i aM.FINE", WordUtils.uncapitalize("I AM.FINE", (char[]) null));
    }

    @Test
    void testUncapitalizeWithDelimiters_emptyDelimiterArray() {
        final String str = "I AM.FINE";
        assertEquals(str, WordUtils.uncapitalize(str, new char[0]));
    }

    @Test
    void testUncapitalizeWithDelimiters_customDelimiter() {
        assertEquals("i AM.fINE", WordUtils.uncapitalize("I AM.FINE", new char[] {'.'}));
    }

    // ---- wrap(String, int) ----

    @Test
    void testWrap_null() {
        assertNull(WordUtils.wrap(null, 20));
    }

    @Test
    void testWrap_empty() {
        assertEquals("", WordUtils.wrap("", 20));
    }

    @Test
    void testWrap_basic() {
        final String input = "Here is one line of text that is going to be wrapped after 20 columns.";
        final String expected = "Here is one line of" + System.lineSeparator()
            + "text that is going" + System.lineSeparator()
            + "to be wrapped after" + System.lineSeparator()
            + "20 columns.";
        assertEquals(expected, WordUtils.wrap(input, 20));
    }

    @Test
    void testWrap_wrapLengthLessThanOneTreatedAsOne() {
        final String result0 = WordUtils.wrap("ab cd", 0);
        final String result1 = WordUtils.wrap("ab cd", 1);
        assertEquals(result1, result0);
    }

    @Test
    void testWrap_negativeWrapLengthTreatedAsOne() {
        final String result = WordUtils.wrap("ab cd", -5);
        final String expected = "ab" + System.lineSeparator() + "cd";
        assertEquals(expected, result);
    }

    @Test
    void testWrap_shortStringNotWrapped() {
        assertEquals("short", WordUtils.wrap("short", 20));
    }

    // ---- wrap(String, int, String, boolean) ----

    @Test
    void testWrapWithNewLineStr_customSeparator() {
        final String input = "Here is one line of text that is going to be wrapped after 20 columns.";
        final String expected = "Here is one line of<br />text that is going<br />to be wrapped after<br />20 columns.";
        assertEquals(expected, WordUtils.wrap(input, 20, "<br />", false));
    }

    @Test
    void testWrapWithNewLineStr_nullUsesSystemLineSeparator() {
        final String input = "Here is one line of text that is going to be wrapped after 20 columns.";
        final String expected = "Here is one line of" + System.lineSeparator()
            + "text that is going" + System.lineSeparator()
            + "to be wrapped after" + System.lineSeparator()
            + "20 columns.";
        assertEquals(expected, WordUtils.wrap(input, 20, null, false));
    }

    @Test
    void testWrapWithNewLineStr_longWordNotWrapped() {
        final String input = "Click here to jump to the commons website - https://commons.apache.org";
        final String expected = "Click here to jump\nto the commons\nwebsite -\nhttps://commons.apache.org";
        assertEquals(expected, WordUtils.wrap(input, 20, "\n", false));
    }

    @Test
    void testWrapWithNewLineStr_longWordWrapped() {
        final String input = "Click here to jump to the commons website - https://commons.apache.org";
        final String expected = "Click here to jump\nto the commons\nwebsite -\nhttps://commons.apac\nhe.org";
        assertEquals(expected, WordUtils.wrap(input, 20, "\n", true));
    }

    @Test
    void testWrapWithNewLineStr_nullInput() {
        assertNull(WordUtils.wrap(null, 20, "\n", true));
    }

    // ---- wrap(String, int, String, boolean, String) ----

    @Test
    void testWrapWithWrapOn_customWrapOnPattern() {
        final String input = "flammable/inflammable";
        final String expected = "flammable\ninflammable";
        assertEquals(expected, WordUtils.wrap(input, 20, "\n", true, "/"));
    }

    @Test
    void testWrapWithWrapOn_blankWrapOnDefaultsToSpace() {
        final String input = "ab cd ef gh";
        final String withBlank = WordUtils.wrap(input, 4, "\n", false, "   ");
        final String withSpace = WordUtils.wrap(input, 4, "\n", false, " ");
        assertEquals(withSpace, withBlank);
    }

    @Test
    void testWrapWithWrapOn_nullWrapOnDefaultsToSpace() {
        final String input = "ab cd ef gh";
        final String withNull = WordUtils.wrap(input, 4, "\n", false, null);
        final String withSpace = WordUtils.wrap(input, 4, "\n", false, " ");
        assertEquals(withSpace, withNull);
    }

    @Test
    void testWrapWithWrapOn_nullInputReturnsNullRegardlessOfOtherArgs() {
        assertNull(WordUtils.wrap(null, 20, "\n", true, "/"));
    }

    @Test
    void testWrapWithWrapOn_emptyInput() {
        assertEquals("", WordUtils.wrap("", 20, "\n", true, "/"));
    }

    // ---- constructor ----

    @Test
    void testConstructor_isPublic() {
        assertTrue(new WordUtils() instanceof WordUtils);
    }
}
