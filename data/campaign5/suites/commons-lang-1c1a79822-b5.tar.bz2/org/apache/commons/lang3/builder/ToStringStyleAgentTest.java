/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.builder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link ToStringStyle}.
 */
class ToStringStyleAgentTest {

    /**
     * Minimal exposed subclass used to call the protected members of {@link ToStringStyle} from the test.
     */
    private static final class ExposedToStringStyle extends ToStringStyle {
        private static final long serialVersionUID = 1L;

        @Override
        public String getArrayEnd() {
            return super.getArrayEnd();
        }

        @Override
        public String getArraySeparator() {
            return super.getArraySeparator();
        }

        @Override
        public String getArrayStart() {
            return super.getArrayStart();
        }

        @Override
        public String getContentEnd() {
            return super.getContentEnd();
        }

        @Override
        public String getContentStart() {
            return super.getContentStart();
        }

        @Override
        public String getFieldNameValueSeparator() {
            return super.getFieldNameValueSeparator();
        }

        @Override
        public String getFieldSeparator() {
            return super.getFieldSeparator();
        }

        @Override
        public String getNullText() {
            return super.getNullText();
        }

        @Override
        public String getSizeEndText() {
            return super.getSizeEndText();
        }

        @Override
        public String getSizeStartText() {
            return super.getSizeStartText();
        }

        @Override
        public String getSummaryObjectEndText() {
            return super.getSummaryObjectEndText();
        }

        @Override
        public String getSummaryObjectStartText() {
            return super.getSummaryObjectStartText();
        }

        @Override
        public boolean isArrayContentDetail() {
            return super.isArrayContentDetail();
        }

        @Override
        public boolean isDefaultFullDetail() {
            return super.isDefaultFullDetail();
        }

        @Override
        public boolean isFieldSeparatorAtEnd() {
            return super.isFieldSeparatorAtEnd();
        }

        @Override
        public boolean isFieldSeparatorAtStart() {
            return super.isFieldSeparatorAtStart();
        }

        @Override
        public boolean isFullDetail(final Boolean fullDetailRequest) {
            return super.isFullDetail(fullDetailRequest);
        }

        @Override
        public boolean isUseClassName() {
            return super.isUseClassName();
        }

        @Override
        public boolean isUseFieldNames() {
            return super.isUseFieldNames();
        }

        @Override
        public boolean isUseIdentityHashCode() {
            return super.isUseIdentityHashCode();
        }

        @Override
        public boolean isUseShortClassName() {
            return super.isUseShortClassName();
        }

        @Override
        public void setArrayContentDetail(final boolean arrayContentDetail) {
            super.setArrayContentDetail(arrayContentDetail);
        }

        @Override
        public void setArrayEnd(final String arrayEnd) {
            super.setArrayEnd(arrayEnd);
        }

        @Override
        public void setArraySeparator(final String arraySeparator) {
            super.setArraySeparator(arraySeparator);
        }

        @Override
        public void setArrayStart(final String arrayStart) {
            super.setArrayStart(arrayStart);
        }

        @Override
        public void setContentEnd(final String contentEnd) {
            super.setContentEnd(contentEnd);
        }

        @Override
        public void setContentStart(final String contentStart) {
            super.setContentStart(contentStart);
        }

        @Override
        public void setDefaultFullDetail(final boolean defaultFullDetail) {
            super.setDefaultFullDetail(defaultFullDetail);
        }

        @Override
        public void setFieldNameValueSeparator(final String fieldNameValueSeparator) {
            super.setFieldNameValueSeparator(fieldNameValueSeparator);
        }

        @Override
        public void setFieldSeparator(final String fieldSeparator) {
            super.setFieldSeparator(fieldSeparator);
        }

        @Override
        public void setFieldSeparatorAtEnd(final boolean fieldSeparatorAtEnd) {
            super.setFieldSeparatorAtEnd(fieldSeparatorAtEnd);
        }

        @Override
        public void setFieldSeparatorAtStart(final boolean fieldSeparatorAtStart) {
            super.setFieldSeparatorAtStart(fieldSeparatorAtStart);
        }

        @Override
        public void setNullText(final String nullText) {
            super.setNullText(nullText);
        }

        @Override
        public void setSizeEndText(final String sizeEndText) {
            super.setSizeEndText(sizeEndText);
        }

        @Override
        public void setSizeStartText(final String sizeStartText) {
            super.setSizeStartText(sizeStartText);
        }

        @Override
        public void setSummaryObjectEndText(final String summaryObjectEndText) {
            super.setSummaryObjectEndText(summaryObjectEndText);
        }

        @Override
        public void setSummaryObjectStartText(final String summaryObjectStartText) {
            super.setSummaryObjectStartText(summaryObjectStartText);
        }

        @Override
        public void setUseClassName(final boolean useClassName) {
            super.setUseClassName(useClassName);
        }

        @Override
        public void setUseFieldNames(final boolean useFieldNames) {
            super.setUseFieldNames(useFieldNames);
        }

        @Override
        public void setUseIdentityHashCode(final boolean useIdentityHashCode) {
            super.setUseIdentityHashCode(useIdentityHashCode);
        }

        @Override
        public void setUseShortClassName(final boolean useShortClassName) {
            super.setUseShortClassName(useShortClassName);
        }
    }

    /**
     * Fixture whose toString() exercises ToStringStyle via ToStringBuilder.
     */
    private static final class Fixture {
        String name = "John";
        int age = 33;
        boolean active = true;
        int[] values = {1, 2, 3};
        String nullField;

        @Override
        public String toString() {
            return new ToStringBuilder(this, ToStringStyle.DEFAULT_STYLE)
                    .append("name", name)
                    .append("age", age)
                    .append("active", active)
                    .append("values", values)
                    .append("nullField", nullField)
                    .toString();
        }
    }

    // --- null-to-empty-string conversion on setters ---

    @Test
    void testSetArrayEndNullBecomesEmpty() {
        final ExposedToStringStyle style = new ExposedToStringStyle();
        style.setArrayEnd(null);
        assertEquals("", style.getArrayEnd());
    }

    @Test
    void testSetArraySeparatorNullBecomesEmpty() {
        final ExposedToStringStyle style = new ExposedToStringStyle();
        style.setArraySeparator(null);
        assertEquals("", style.getArraySeparator());
    }

    @Test
    void testSetArrayStartNullBecomesEmpty() {
        final ExposedToStringStyle style = new ExposedToStringStyle();
        style.setArrayStart(null);
        assertEquals("", style.getArrayStart());
    }

    @Test
    void testSetContentEndNullBecomesEmpty() {
        final ExposedToStringStyle style = new ExposedToStringStyle();
        style.setContentEnd(null);
        assertEquals("", style.getContentEnd());
    }

    @Test
    void testSetContentStartNullBecomesEmpty() {
        final ExposedToStringStyle style = new ExposedToStringStyle();
        style.setContentStart(null);
        assertEquals("", style.getContentStart());
    }

    @Test
    void testSetFieldNameValueSeparatorNullBecomesEmpty() {
        final ExposedToStringStyle style = new ExposedToStringStyle();
        style.setFieldNameValueSeparator(null);
        assertEquals("", style.getFieldNameValueSeparator());
    }

    @Test
    void testSetFieldSeparatorNullBecomesEmpty() {
        final ExposedToStringStyle style = new ExposedToStringStyle();
        style.setFieldSeparator(null);
        assertEquals("", style.getFieldSeparator());
    }

    @Test
    void testSetNullTextNullBecomesEmpty() {
        final ExposedToStringStyle style = new ExposedToStringStyle();
        style.setNullText(null);
        assertEquals("", style.getNullText());
    }

    @Test
    void testSetSizeEndTextNullBecomesEmpty() {
        final ExposedToStringStyle style = new ExposedToStringStyle();
        style.setSizeEndText(null);
        assertEquals("", style.getSizeEndText());
    }

    @Test
    void testSetSizeStartTextNullBecomesEmpty() {
        final ExposedToStringStyle style = new ExposedToStringStyle();
        style.setSizeStartText(null);
        assertEquals("", style.getSizeStartText());
    }

    @Test
    void testSetSummaryObjectEndTextNullBecomesEmpty() {
        final ExposedToStringStyle style = new ExposedToStringStyle();
        style.setSummaryObjectEndText(null);
        assertEquals("", style.getSummaryObjectEndText());
    }

    @Test
    void testSetSummaryObjectStartTextNullBecomesEmpty() {
        final ExposedToStringStyle style = new ExposedToStringStyle();
        style.setSummaryObjectStartText(null);
        assertEquals("", style.getSummaryObjectStartText());
    }

    // --- non-null setter values round trip ---

    @Test
    void testSetArrayEndNonNullValueRoundTrips() {
        final ExposedToStringStyle style = new ExposedToStringStyle();
        style.setArrayEnd("}}");
        assertEquals("}}", style.getArrayEnd());
    }

    @Test
    void testSetContentStartNonNullValueRoundTrips() {
        final ExposedToStringStyle style = new ExposedToStringStyle();
        style.setContentStart("<<");
        assertEquals("<<", style.getContentStart());
    }

    @Test
    void testSetUseClassNameFlag() {
        final ExposedToStringStyle style = new ExposedToStringStyle();
        assertTrue(style.isUseClassName());
        style.setUseClassName(false);
        assertFalse(style.isUseClassName());
    }

    @Test
    void testSetUseFieldNamesFlag() {
        final ExposedToStringStyle style = new ExposedToStringStyle();
        assertTrue(style.isUseFieldNames());
        style.setUseFieldNames(false);
        assertFalse(style.isUseFieldNames());
    }

    @Test
    void testSetUseIdentityHashCodeFlag() {
        final ExposedToStringStyle style = new ExposedToStringStyle();
        assertTrue(style.isUseIdentityHashCode());
        style.setUseIdentityHashCode(false);
        assertFalse(style.isUseIdentityHashCode());
    }

    @Test
    void testSetUseShortClassNameFlag() {
        final ExposedToStringStyle style = new ExposedToStringStyle();
        assertFalse(style.isUseShortClassName());
        style.setUseShortClassName(true);
        assertTrue(style.isUseShortClassName());
    }

    @Test
    void testSetArrayContentDetailFlag() {
        final ExposedToStringStyle style = new ExposedToStringStyle();
        assertTrue(style.isArrayContentDetail());
        style.setArrayContentDetail(false);
        assertFalse(style.isArrayContentDetail());
    }

    @Test
    void testSetDefaultFullDetailFlag() {
        final ExposedToStringStyle style = new ExposedToStringStyle();
        assertTrue(style.isDefaultFullDetail());
        style.setDefaultFullDetail(false);
        assertFalse(style.isDefaultFullDetail());
    }

    @Test
    void testSetFieldSeparatorAtStartAndEndFlags() {
        final ExposedToStringStyle style = new ExposedToStringStyle();
        assertFalse(style.isFieldSeparatorAtStart());
        assertFalse(style.isFieldSeparatorAtEnd());
        style.setFieldSeparatorAtStart(true);
        style.setFieldSeparatorAtEnd(true);
        assertTrue(style.isFieldSeparatorAtStart());
        assertTrue(style.isFieldSeparatorAtEnd());
    }

    // --- isFullDetail boundary behavior ---

    @Test
    void testIsFullDetailNullUsesDefaultTrue() {
        final ExposedToStringStyle style = new ExposedToStringStyle();
        assertTrue(style.isFullDetail(null));
    }

    @Test
    void testIsFullDetailNullUsesDefaultFalseWhenOverridden() {
        final ExposedToStringStyle style = new ExposedToStringStyle();
        style.setDefaultFullDetail(false);
        assertFalse(style.isFullDetail(null));
    }

    @Test
    void testIsFullDetailExplicitTrueIgnoresDefault() {
        final ExposedToStringStyle style = new ExposedToStringStyle();
        style.setDefaultFullDetail(false);
        assertTrue(style.isFullDetail(Boolean.TRUE));
    }

    @Test
    void testIsFullDetailExplicitFalseIgnoresDefault() {
        final ExposedToStringStyle style = new ExposedToStringStyle();
        style.setDefaultFullDetail(true);
        assertFalse(style.isFullDetail(Boolean.FALSE));
    }

    // --- default field values ---

    @Test
    void testDefaultFieldValues() {
        final ExposedToStringStyle style = new ExposedToStringStyle();
        assertEquals("[", style.getContentStart());
        assertEquals("]", style.getContentEnd());
        assertEquals("=", style.getFieldNameValueSeparator());
        assertEquals(",", style.getFieldSeparator());
        assertEquals("{", style.getArrayStart());
        assertEquals(",", style.getArraySeparator());
        assertEquals("}", style.getArrayEnd());
        assertEquals("<null>", style.getNullText());
        assertEquals("<size=", style.getSizeStartText());
        assertEquals(">", style.getSizeEndText());
        assertEquals("<", style.getSummaryObjectStartText());
        assertEquals(">", style.getSummaryObjectEndText());
    }

    // --- append(...) behavior through public API, asserting on observable buffer state ---

    @Test
    void testAppendBooleanValue() {
        final StringBuffer buffer = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.append(buffer, "flag", true);
        assertEquals("flag=true,", buffer.toString());
    }

    @Test
    void testAppendIntValue() {
        final StringBuffer buffer = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.append(buffer, "count", 42);
        assertEquals("count=42,", buffer.toString());
    }

    @Test
    void testAppendNullObjectValueUsesNullText() {
        final StringBuffer buffer = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.append(buffer, "obj", (Object) null, Boolean.TRUE);
        assertEquals("obj=<null>,", buffer.toString());
    }

    @Test
    void testAppendNullArrayUsesNullText() {
        final StringBuffer buffer = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.append(buffer, "arr", (int[]) null, Boolean.TRUE);
        assertEquals("arr=<null>,", buffer.toString());
    }

    @Test
    void testAppendIntArrayFullDetail() {
        final StringBuffer buffer = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.append(buffer, "arr", new int[] {1, 2, 3}, Boolean.TRUE);
        assertEquals("arr={1,2,3},", buffer.toString());
    }

    @Test
    void testAppendIntArraySummary() {
        final StringBuffer buffer = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.append(buffer, "arr", new int[] {1, 2, 3}, Boolean.FALSE);
        assertEquals("arr=<size=3>,", buffer.toString());
    }

    @Test
    void testAppendEmptyIntArrayFullDetail() {
        final StringBuffer buffer = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.append(buffer, "arr", new int[0], Boolean.TRUE);
        assertEquals("arr={},", buffer.toString());
    }

    @Test
    void testAppendStringValueFullDetail() {
        final StringBuffer buffer = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.append(buffer, "name", "value", Boolean.TRUE);
        assertEquals("name=value,", buffer.toString());
    }

    @Test
    void testAppendCollectionDetail() {
        final StringBuffer buffer = new StringBuffer();
        final List<String> list = new ArrayList<String>();
        list.add("a");
        list.add("b");
        ToStringStyle.DEFAULT_STYLE.append(buffer, "list", list, Boolean.TRUE);
        assertEquals("list=[a, b],", buffer.toString());
    }

    @Test
    void testAppendEmptyCollectionDetail() {
        final StringBuffer buffer = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.append(buffer, "list", new ArrayList<String>(), Boolean.TRUE);
        assertEquals("list=[],", buffer.toString());
    }

    @Test
    void testAppendMapDetail() {
        final StringBuffer buffer = new StringBuffer();
        final Map<String, String> map = new LinkedHashMap<String, String>();
        map.put("k", "v");
        ToStringStyle.DEFAULT_STYLE.append(buffer, "map", map, Boolean.TRUE);
        assertEquals("map={k=v},", buffer.toString());
    }

    // --- field name handling ---

    @Test
    void testAppendFieldStartSkippedWhenFieldNameIsNull() {
        final StringBuffer buffer = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.append(buffer, null, 5);
        assertEquals("5,", buffer.toString());
    }

    @Test
    void testAppendFieldStartSkippedWhenUseFieldNamesFalse() {
        final ExposedToStringStyle style = new ExposedToStringStyle();
        style.setUseFieldNames(false);
        final StringBuffer buffer = new StringBuffer();
        style.append(buffer, "field", 5);
        assertEquals("5,", buffer.toString());
    }

    // --- appendSuper / appendToString boundary cases ---

    @Test
    void testAppendSuperWithNullIsNoop() {
        final StringBuffer buffer = new StringBuffer("[a=1]");
        ToStringStyle.DEFAULT_STYLE.appendSuper(buffer, null);
        assertEquals("[a=1]", buffer.toString());
    }

    @Test
    void testAppendSuperWithEmptyContentIsNoop() {
        final StringBuffer buffer = new StringBuffer("[a=1]");
        ToStringStyle.DEFAULT_STYLE.appendSuper(buffer, "Foo@1[]");
        assertEquals("[a=1]", buffer.toString());
    }

    @Test
    void testAppendToStringMergesContentAndAddsSeparator() {
        final StringBuffer buffer = new StringBuffer("[a=1");
        ToStringStyle.DEFAULT_STYLE.appendToString(buffer, "Foo@1[b=2]");
        assertEquals("[a=1b=2,", buffer.toString());
    }

    // --- appendStart / appendEnd lifecycle including registry cleanup ---

    @Test
    void testAppendStartAndEndProduceBalancedOutputForNullObject() {
        final StringBuffer buffer = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.appendStart(buffer, null);
        assertEquals("", buffer.toString());
        ToStringStyle.DEFAULT_STYLE.appendEnd(buffer, null);
        assertEquals("]", buffer.toString());
    }

    @Test
    void testAppendStartRegistersObjectAndAppendEndUnregisters() {
        final Fixture fixture = new Fixture();
        final StringBuffer buffer = new StringBuffer();
        ToStringStyle.DEFAULT_STYLE.appendStart(buffer, fixture);
        assertTrue(ToStringStyle.getRegistry().containsKey(fixture));
        ToStringStyle.DEFAULT_STYLE.appendEnd(buffer, fixture);
        assertFalse(ToStringStyle.getRegistry().containsKey(fixture));
    }

    @Test
    void testAppendEndRemovesTrailingFieldSeparatorByDefault() {
        final StringBuffer buffer = new StringBuffer("[a=1,");
        ToStringStyle.DEFAULT_STYLE.appendEnd(buffer, null);
        assertEquals("[a=1]", buffer.toString());
    }

    // --- cyclic object detection via a self-referencing fixture ---

    private static final class SelfReferencing {
        Object self;

        @Override
        public String toString() {
            return new ToStringBuilder(this, ToStringStyle.DEFAULT_STYLE)
                    .append("self", self)
                    .toString();
        }
    }

    @Test
    void testCyclicReferenceDoesNotThrowAndUsesIdentityString() {
        final SelfReferencing cyclic = new SelfReferencing();
        cyclic.self = cyclic;
        final String result = cyclic.toString();
        assertNotNull(result);
        assertTrue(result.contains("self="));
        assertFalse(ToStringStyle.getRegistry().containsKey(cyclic));
    }

    // --- full end-to-end rendering through ToStringBuilder, asserting observable string ---

    @Test
    void testFullToStringRenderingWithDefaultStyle() {
        final Fixture fixture = new Fixture();
        final String result = fixture.toString();
        assertTrue(result.contains("name=John"));
        assertTrue(result.contains("age=33"));
        assertTrue(result.contains("active=true"));
        assertTrue(result.contains("values={1,2,3}"));
        assertTrue(result.contains("nullField=<null>"));
        assertTrue(result.endsWith("]"));
    }

    // --- getShortClassName / appendClassName observable behavior ---

    @Test
    void testShortPrefixStyleOmitsPackageName() {
        final Fixture fixture = new Fixture();
        final String result = new ToStringBuilder(fixture, ToStringStyle.SHORT_PREFIX_STYLE)
                .append("name", fixture.name)
                .toString();
        assertFalse(result.contains("ToStringStyleAgentTest$Fixture"));
        assertTrue(result.contains("Fixture["));
    }

    @Test
    void testNoClassNameStyleOmitsClassNameAndIdentityHashCode() {
        final Fixture fixture = new Fixture();
        final String result = new ToStringBuilder(fixture, ToStringStyle.NO_CLASS_NAME_STYLE)
                .append("name", fixture.name)
                .toString();
        assertEquals("[name=John]", result);
    }

    @Test
    void testSimpleStyleOmitsEverythingButValues() {
        final Fixture fixture = new Fixture();
        final String result = new ToStringBuilder(fixture, ToStringStyle.SIMPLE_STYLE)
                .append("name", fixture.name)
                .append("age", fixture.age)
                .toString();
        assertEquals("John,33", result);
    }

    // --- JSON style error handling: field name is mandatory ---

    @Test
    void testJsonStyleThrowsWhenFieldNameMissing() {
        final StringBuffer buffer = new StringBuffer();
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                ToStringStyle.JSON_STYLE.append(buffer, null, 1);
            }
        });
    }

    @Test
    void testJsonStyleThrowsWhenFullDetailFalse() {
        final StringBuffer buffer = new StringBuffer();
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                ToStringStyle.JSON_STYLE.append(buffer, "field", new int[] {1}, Boolean.FALSE);
            }
        });
    }

    @Test
    void testJsonStyleProducesValidObjectSyntax() {
        final StringBuffer buffer = new StringBuffer();
        ToStringStyle.JSON_STYLE.append(buffer, "name", "value", Boolean.TRUE);
        assertEquals("\"name\":\"value\",", buffer.toString());
    }

    // --- serialization readResolve singleton guarantee ---

    @Test
    void testDefaultStyleSerializationPreservesSingleton() throws Exception {
        final Object resolved = deserialize(serialize(ToStringStyle.DEFAULT_STYLE));
        assertSame(ToStringStyle.DEFAULT_STYLE, resolved);
    }

    @Test
    void testJsonStyleSerializationPreservesSingleton() throws Exception {
        final Object resolved = deserialize(serialize(ToStringStyle.JSON_STYLE));
        assertSame(ToStringStyle.JSON_STYLE, resolved);
    }

    private static byte[] serialize(final Object obj) throws java.io.IOException {
        final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
        final java.io.ObjectOutputStream oos = new java.io.ObjectOutputStream(baos);
        oos.writeObject(obj);
        oos.close();
        return baos.toByteArray();
    }

    private static Object deserialize(final byte[] bytes) throws java.io.IOException, ClassNotFoundException {
        final java.io.ObjectInputStream ois = new java.io.ObjectInputStream(new java.io.ByteArrayInputStream(bytes));
        final Object result = ois.readObject();
        ois.close();
        return result;
    }

    // --- registry helpers ---

    @Test
    void testGetRegistryReturnsEmptyMapWhenNothingRegistered() {
        assertNotNull(ToStringStyle.getRegistry());
        assertTrue(ToStringStyle.getRegistry().isEmpty());
    }
}
