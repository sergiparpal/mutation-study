/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link ClassUtils}.
 */
class ClassUtilsAgentTest {

    interface AgentInterfaceA {
    }

    interface AgentInterfaceB {
    }

    static class AgentBase implements AgentInterfaceA {
    }

    static class AgentChild extends AgentBase implements AgentInterfaceB {
    }

    @Test
    void testConstructorIsPublic() {
        // Deprecated but still public for JavaBean tools.
        final ClassUtils instance = new ClassUtils();
        assertTrue(instance.getClass() == ClassUtils.class);
    }

    // --- getAbbreviatedName(Class, int) / (String, int) ---

    @Test
    void testGetAbbreviatedNameNullClass() {
        assertEquals("", ClassUtils.getAbbreviatedName((Class<?>) null, 10));
    }

    @Test
    void testGetAbbreviatedNameNullString() {
        assertEquals("", ClassUtils.getAbbreviatedName((String) null, 10));
    }

    @Test
    void testGetAbbreviatedNameLengthZeroThrows() {
        assertThrows(IllegalArgumentException.class, () -> ClassUtils.getAbbreviatedName("java.lang.String", 0));
    }

    @Test
    void testGetAbbreviatedNameLengthNegativeThrows() {
        assertThrows(IllegalArgumentException.class, () -> ClassUtils.getAbbreviatedName("java.lang.String", -1));
    }

    @Test
    void testGetAbbreviatedNameExamples() {
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName("java.lang.String", 5));
        assertEquals("java.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 30));
        assertEquals("o.a.c.l.ClassUtils", ClassUtils.getAbbreviatedName("org.apache.commons.lang3.ClassUtils", 18));
    }

    @Test
    void testGetAbbreviatedNameFromClass() {
        assertEquals(String.class.getName(), ClassUtils.getAbbreviatedName(String.class, 100));
    }

    // --- getAllInterfaces / getAllSuperclasses ---

    @Test
    void testGetAllInterfacesNull() {
        assertNull(ClassUtils.getAllInterfaces(null));
    }

    @Test
    void testGetAllInterfacesIncludesHierarchy() {
        final List<Class<?>> interfaces = ClassUtils.getAllInterfaces(AgentChild.class);
        assertTrue(interfaces.contains(AgentInterfaceA.class));
        assertTrue(interfaces.contains(AgentInterfaceB.class));
        assertEquals(2, interfaces.size());
    }

    @Test
    void testGetAllSuperclassesNull() {
        assertNull(ClassUtils.getAllSuperclasses(null));
    }

    @Test
    void testGetAllSuperclassesOrder() {
        final List<Class<?>> superclasses = ClassUtils.getAllSuperclasses(AgentChild.class);
        assertEquals(2, superclasses.size());
        assertEquals(AgentBase.class, superclasses.get(0));
        assertEquals(Object.class, superclasses.get(1));
    }

    @Test
    void testGetAllSuperclassesOfObject() {
        assertTrue(ClassUtils.getAllSuperclasses(Object.class).isEmpty());
    }

    // --- getCanonicalName ---

    @Test
    void testGetCanonicalNameClassNull() {
        assertEquals("", ClassUtils.getCanonicalName((Class<?>) null));
        assertEquals("N/A", ClassUtils.getCanonicalName((Class<?>) null, "N/A"));
    }

    @Test
    void testGetCanonicalNameClass() {
        assertEquals("java.lang.String", ClassUtils.getCanonicalName(String.class));
        assertEquals("java.lang.String[]", ClassUtils.getCanonicalName(String[].class));
    }

    @Test
    void testGetCanonicalNameObjectNull() {
        assertEquals("", ClassUtils.getCanonicalName((Object) null));
        assertEquals("N/A", ClassUtils.getCanonicalName((Object) null, "N/A"));
    }

    @Test
    void testGetCanonicalNameObject() {
        assertEquals("java.lang.String", ClassUtils.getCanonicalName("hello"));
    }

    // --- getClass(...) ---

    @Test
    void testGetClassByNameSimple() throws ClassNotFoundException {
        assertEquals(String.class, ClassUtils.getClass("java.lang.String"));
    }

    @Test
    void testGetClassByNamePrimitive() throws ClassNotFoundException {
        assertEquals(int.class, ClassUtils.getClass("int"));
    }

    @Test
    void testGetClassByNameArrayJvmSyntax() throws ClassNotFoundException {
        assertEquals(int[].class, ClassUtils.getClass("[I"));
        assertEquals(String[].class, ClassUtils.getClass("[Ljava.lang.String;"));
    }

    @Test
    void testGetClassByNameArrayCanonicalSyntax() throws ClassNotFoundException {
        assertEquals(String[].class, ClassUtils.getClass("java.lang.String[]"));
    }

    @Test
    void testGetClassInnerClassDotSyntax() throws ClassNotFoundException {
        assertEquals(java.util.Map.Entry.class, ClassUtils.getClass("java.util.Map.Entry"));
    }

    @Test
    void testGetClassInnerClassDollarSyntax() throws ClassNotFoundException {
        assertEquals(java.util.Map.Entry.class, ClassUtils.getClass("java.util.Map$Entry"));
    }

    @Test
    void testGetClassNotFoundThrows() {
        assertThrows(ClassNotFoundException.class, () -> ClassUtils.getClass("com.example.DoesNotExist12345"));
    }

    @Test
    void testGetClassNullNameThrowsNpe() {
        assertThrows(NullPointerException.class, () -> ClassUtils.getClass((String) null));
    }

    @Test
    void testGetClassStripsWhitespace() throws ClassNotFoundException {
        assertEquals(String.class, ClassUtils.getClass(" java . lang . String "));
    }

    @Test
    void testGetClassWithClassLoader() throws ClassNotFoundException {
        final ClassLoader cl = ClassUtilsAgentTest.class.getClassLoader();
        assertEquals(String.class, ClassUtils.getClass(cl, "java.lang.String"));
        assertEquals(String.class, ClassUtils.getClass(cl, "java.lang.String", false));
    }

    // --- getComponentType ---

    @Test
    void testGetComponentTypeNull() {
        assertNull(ClassUtils.getComponentType(null));
    }

    @Test
    void testGetComponentTypeArray() {
        assertEquals(String.class, ClassUtils.getComponentType(String[].class));
    }

    // --- getName ---

    @Test
    void testGetNameClassNull() {
        assertEquals("", ClassUtils.getName((Class<?>) null));
        assertEquals("X", ClassUtils.getName((Class<?>) null, "X"));
    }

    @Test
    void testGetNameClass() {
        assertEquals("java.lang.String", ClassUtils.getName(String.class));
    }

    @Test
    void testGetNameObjectNull() {
        assertEquals("", ClassUtils.getName((Object) null));
        assertEquals("X", ClassUtils.getName((Object) null, "X"));
    }

    @Test
    void testGetNameObject() {
        assertEquals("java.lang.String", ClassUtils.getName("hi"));
    }

    // --- getPackageName / getPackageCanonicalName ---

    @Test
    void testGetPackageNameClassNull() {
        assertEquals("", ClassUtils.getPackageName((Class<?>) null));
    }

    @Test
    void testGetPackageNameClass() {
        assertEquals("java.lang", ClassUtils.getPackageName(String.class));
    }

    @Test
    void testGetPackageNameDefaultPackage() {
        assertEquals("", ClassUtils.getPackageName("NoPackageClass"));
    }

    @Test
    void testGetPackageNameEmptyInput() {
        assertEquals("", ClassUtils.getPackageName(""));
        assertEquals("", ClassUtils.getPackageName((String) null));
    }

    @Test
    void testGetPackageNameObjectNull() {
        assertEquals("N/A", ClassUtils.getPackageName((Object) null, "N/A"));
    }

    @Test
    void testGetPackageCanonicalNameClassNull() {
        assertEquals("", ClassUtils.getPackageCanonicalName((Class<?>) null));
    }

    @Test
    void testGetPackageCanonicalNameArray() {
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName(new String[0].getClass()));
    }

    @Test
    void testGetPackageCanonicalNameObjectNull() {
        assertEquals("N/A", ClassUtils.getPackageCanonicalName((Object) null, "N/A"));
    }

    // --- getPublicMethod ---

    @Test
    void testGetPublicMethodFound() throws Exception {
        final java.lang.reflect.Method m = ClassUtils.getPublicMethod(Collections.unmodifiableSet(new java.util.HashSet<String>()).getClass(), "isEmpty");
        assertEquals("isEmpty", m.getName());
        assertTrue(java.lang.reflect.Modifier.isPublic(m.getDeclaringClass().getModifiers()));
    }

    @Test
    void testGetPublicMethodNotFoundThrows() {
        assertThrows(NoSuchMethodException.class, () -> ClassUtils.getPublicMethod(String.class, "noSuchMethodHere"));
    }

    @Test
    void testGetPublicMethodNullClassThrowsNpe() {
        assertThrows(NullPointerException.class, () -> ClassUtils.getPublicMethod(null, "toString"));
    }

    // --- getShortClassName / getShortCanonicalName ---

    @Test
    void testGetShortClassNameClassNull() {
        assertEquals("", ClassUtils.getShortClassName((Class<?>) null));
    }

    @Test
    void testGetShortClassNameSimple() {
        assertEquals("String", ClassUtils.getShortClassName(String.class));
    }

    @Test
    void testGetShortClassNameArray() {
        assertEquals("String[]", ClassUtils.getShortClassName(String[].class));
        assertEquals("int[]", ClassUtils.getShortClassName(int[].class));
    }

    @Test
    void testGetShortClassNameInnerClass() {
        assertEquals("Map.Entry", ClassUtils.getShortClassName(java.util.Map.Entry.class));
    }

    @Test
    void testGetShortClassNameStringNullOrEmpty() {
        assertEquals("", ClassUtils.getShortClassName((String) null));
        assertEquals("", ClassUtils.getShortClassName(""));
    }

    @Test
    void testGetShortClassNameStringFromJvmArrayEncoding() {
        assertEquals("int[]", ClassUtils.getShortClassName("[I"));
        assertEquals("String[]", ClassUtils.getShortClassName("[Ljava.lang.String;"));
    }

    @Test
    void testGetShortClassNameObjectNull() {
        assertEquals("X", ClassUtils.getShortClassName((Object) null, "X"));
    }

    @Test
    void testGetShortCanonicalNameClassNull() {
        assertEquals("", ClassUtils.getShortCanonicalName((Class<?>) null));
    }

    @Test
    void testGetShortCanonicalNameArray() {
        assertEquals("String[]", ClassUtils.getShortCanonicalName(String[].class));
        assertEquals("int[]", ClassUtils.getShortCanonicalName(int[].class));
    }

    @Test
    void testGetShortCanonicalNameObjectNull() {
        assertEquals("X", ClassUtils.getShortCanonicalName((Object) null, "X"));
    }

    @Test
    void testGetShortCanonicalNameString() {
        assertEquals("ClassUtils", ClassUtils.getShortCanonicalName("org.apache.commons.lang3.ClassUtils"));
        assertEquals("ClassUtils[][]", ClassUtils.getShortCanonicalName("[[Lorg.apache.commons.lang3.ClassUtils;"));
    }

    // --- getSimpleName ---

    @Test
    void testGetSimpleNameClassNull() {
        assertEquals("", ClassUtils.getSimpleName((Class<?>) null));
        assertEquals("X", ClassUtils.getSimpleName((Class<?>) null, "X"));
    }

    @Test
    void testGetSimpleNameClass() {
        assertEquals("String", ClassUtils.getSimpleName(String.class));
    }

    @Test
    void testGetSimpleNameObjectNull() {
        assertEquals("", ClassUtils.getSimpleName((Object) null));
        assertEquals("X", ClassUtils.getSimpleName((Object) null, "X"));
    }

    @Test
    void testGetSimpleNameObject() {
        assertEquals("String", ClassUtils.getSimpleName("hi"));
    }

    // --- hierarchy ---

    @Test
    void testHierarchyExcludeInterfaces() {
        final List<Class<?>> list = new ArrayList<>();
        for (final Class<?> c : ClassUtils.hierarchy(AgentChild.class)) {
            list.add(c);
        }
        assertEquals(java.util.Arrays.asList(AgentChild.class, AgentBase.class, Object.class), list);
    }

    @Test
    void testHierarchyIncludeInterfaces() {
        final List<Class<?>> list = new ArrayList<>();
        for (final Class<?> c : ClassUtils.hierarchy(AgentChild.class, ClassUtils.Interfaces.INCLUDE)) {
            list.add(c);
        }
        assertTrue(list.contains(AgentChild.class));
        assertTrue(list.contains(AgentBase.class));
        assertTrue(list.contains(Object.class));
        assertTrue(list.contains(AgentInterfaceA.class));
        assertTrue(list.contains(AgentInterfaceB.class));
    }

    @Test
    void testHierarchyIteratorRemoveUnsupported() {
        final Iterator<Class<?>> it = ClassUtils.hierarchy(AgentChild.class).iterator();
        assertThrows(UnsupportedOperationException.class, it::remove);
    }

    // --- isAssignable ---

    @Test
    void testIsAssignableNullToClassFalse() {
        assertFalse(ClassUtils.isAssignable(String.class, null));
    }

    @Test
    void testIsAssignableNullClassToNonPrimitiveTrue() {
        assertTrue(ClassUtils.isAssignable((Class<?>) null, String.class));
    }

    @Test
    void testIsAssignableNullClassToPrimitiveFalse() {
        assertFalse(ClassUtils.isAssignable((Class<?>) null, int.class));
    }

    @Test
    void testIsAssignablePrimitiveWidening() {
        assertTrue(ClassUtils.isAssignable(int.class, long.class));
        assertTrue(ClassUtils.isAssignable(int.class, double.class));
        assertFalse(ClassUtils.isAssignable(long.class, int.class));
        assertFalse(ClassUtils.isAssignable(double.class, int.class));
    }

    @Test
    void testIsAssignableAutoboxingDefaultTrue() {
        assertTrue(ClassUtils.isAssignable(Integer.class, int.class));
        assertTrue(ClassUtils.isAssignable(int.class, Integer.class));
    }

    @Test
    void testIsAssignableAutoboxingDisabledFalse() {
        assertFalse(ClassUtils.isAssignable(Integer.class, int.class, false));
        assertFalse(ClassUtils.isAssignable(int.class, Integer.class, false));
    }

    @Test
    void testIsAssignableSameClassTrue() {
        assertTrue(ClassUtils.isAssignable(String.class, String.class));
        assertTrue(ClassUtils.isAssignable(int.class, int.class));
    }

    @Test
    void testIsAssignableSuperclassTrue() {
        assertTrue(ClassUtils.isAssignable(AgentChild.class, AgentBase.class));
        assertFalse(ClassUtils.isAssignable(AgentBase.class, AgentChild.class));
    }

    @Test
    void testIsAssignableArraysNullBothTrue() {
        assertTrue(ClassUtils.isAssignable((Class<?>[]) null, (Class<?>[]) null));
    }

    @Test
    void testIsAssignableArraysDifferentLengthFalse() {
        assertFalse(ClassUtils.isAssignable(new Class<?>[] {String.class}, new Class<?>[] {String.class, String.class}));
    }

    @Test
    void testIsAssignableArraysMatching() {
        assertTrue(ClassUtils.isAssignable(new Class<?>[] {Integer.class, String.class}, new Class<?>[] {int.class, Object.class}));
    }

    // --- isInnerClass ---

    @Test
    void testIsInnerClassNullFalse() {
        assertFalse(ClassUtils.isInnerClass(null));
    }

    @Test
    void testIsInnerClassTopLevelFalse() {
        assertFalse(ClassUtils.isInnerClass(String.class));
    }

    @Test
    void testIsInnerClassNestedTrue() {
        assertTrue(ClassUtils.isInnerClass(AgentChild.class));
        assertTrue(ClassUtils.isInnerClass(java.util.Map.Entry.class));
    }

    // --- isPrimitiveOrWrapper / isPrimitiveWrapper ---

    @Test
    void testIsPrimitiveOrWrapperNullFalse() {
        assertFalse(ClassUtils.isPrimitiveOrWrapper(null));
    }

    @Test
    void testIsPrimitiveOrWrapperTrueCases() {
        assertTrue(ClassUtils.isPrimitiveOrWrapper(int.class));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(Integer.class));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(boolean.class));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(Boolean.class));
    }

    @Test
    void testIsPrimitiveOrWrapperFalseForOther() {
        assertFalse(ClassUtils.isPrimitiveOrWrapper(String.class));
    }

    @Test
    void testIsPrimitiveWrapperNullFalse() {
        assertFalse(ClassUtils.isPrimitiveWrapper(null));
    }

    @Test
    void testIsPrimitiveWrapperTrueFalse() {
        assertTrue(ClassUtils.isPrimitiveWrapper(Integer.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(int.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(String.class));
    }

    // --- isPublic ---

    @Test
    void testIsPublicTrue() {
        assertTrue(ClassUtils.isPublic(String.class));
    }

    @Test
    void testIsPublicFalseForPackagePrivate() {
        assertFalse(ClassUtils.isPublic(AgentChild.class));
    }

    @Test
    void testIsPublicNullThrowsNpe() {
        assertThrows(NullPointerException.class, () -> ClassUtils.isPublic(null));
    }

    // --- primitiveToWrapper / primitivesToWrappers ---

    @Test
    void testPrimitiveToWrapperNull() {
        assertNull(ClassUtils.primitiveToWrapper(null));
    }

    @Test
    void testPrimitiveToWrapperNonPrimitiveReturnsSame() {
        assertEquals(String.class, ClassUtils.primitiveToWrapper(String.class));
    }

    @Test
    void testPrimitiveToWrapperPrimitive() {
        assertEquals(Integer.class, ClassUtils.primitiveToWrapper(int.class));
        assertEquals(Void.TYPE, ClassUtils.primitiveToWrapper(Void.TYPE));
    }

    @Test
    void testPrimitivesToWrappersNull() {
        assertNull(ClassUtils.primitivesToWrappers((Class<?>[]) null));
    }

    @Test
    void testPrimitivesToWrappersEmpty() {
        assertEquals(0, ClassUtils.primitivesToWrappers().length);
    }

    @Test
    void testPrimitivesToWrappersMixed() {
        final Class<?>[] result = ClassUtils.primitivesToWrappers(int.class, String.class, null);
        assertArrayEquals(new Class<?>[] {Integer.class, String.class, null}, result);
    }

    // --- wrapperToPrimitive / wrappersToPrimitives ---

    @Test
    void testWrapperToPrimitiveNull() {
        assertNull(ClassUtils.wrapperToPrimitive(null));
    }

    @Test
    void testWrapperToPrimitiveNonWrapperNull() {
        assertNull(ClassUtils.wrapperToPrimitive(String.class));
    }

    @Test
    void testWrapperToPrimitiveWrapper() {
        assertEquals(int.class, ClassUtils.wrapperToPrimitive(Integer.class));
    }

    @Test
    void testWrappersToPrimitivesNull() {
        assertNull(ClassUtils.wrappersToPrimitives((Class<?>[]) null));
    }

    @Test
    void testWrappersToPrimitivesEmpty() {
        assertEquals(0, ClassUtils.wrappersToPrimitives().length);
    }

    @Test
    void testWrappersToPrimitivesMixed() {
        final Class<?>[] result = ClassUtils.wrappersToPrimitives(Integer.class, String.class, null);
        assertArrayEquals(new Class<?>[] {int.class, null, null}, result);
    }

    // --- toClass ---

    @Test
    void testToClassNull() {
        assertNull(ClassUtils.toClass((Object[]) null));
    }

    @Test
    void testToClassEmpty() {
        assertEquals(0, ClassUtils.toClass().length);
    }

    @Test
    void testToClassMixed() {
        final Class<?>[] result = ClassUtils.toClass("hello", 1, null);
        assertArrayEquals(new Class<?>[] {String.class, Integer.class, null}, result);
    }

    // --- convertClassesToClassNames / convertClassNamesToClasses ---

    @Test
    void testConvertClassesToClassNamesNull() {
        assertNull(ClassUtils.convertClassesToClassNames(null));
    }

    @Test
    void testConvertClassesToClassNames() {
        final List<Class<?>> classes = new ArrayList<>();
        classes.add(String.class);
        classes.add(null);
        final List<String> names = ClassUtils.convertClassesToClassNames(classes);
        assertEquals(java.util.Arrays.asList("java.lang.String", null), names);
    }

    @Test
    void testConvertClassNamesToClassesNull() {
        assertNull(ClassUtils.convertClassNamesToClasses(null));
    }

    @Test
    void testConvertClassNamesToClasses() {
        final List<String> names = new ArrayList<>();
        names.add("java.lang.String");
        names.add("not.a.real.Class");
        names.add(null);
        final List<Class<?>> classes = ClassUtils.convertClassNamesToClasses(names);
        assertEquals(String.class, classes.get(0));
        assertNull(classes.get(1));
        assertNull(classes.get(2));
    }

    // --- comparator() ---

    @Test
    void testComparatorOrdersByName() {
        final List<Class<?>> list = new ArrayList<>();
        list.add(String.class);
        list.add(Integer.class);
        list.add(AgentBase.class);
        Collections.sort(list, ClassUtils.comparator());
        for (int i = 1; i < list.size(); i++) {
            assertTrue(ClassUtils.getName(list.get(i - 1)).compareTo(ClassUtils.getName(list.get(i))) <= 0);
        }
    }

    @Test
    void testComparatorHandlesNullEntries() {
        final List<Class<?>> list = new ArrayList<>();
        list.add(String.class);
        list.add(null);
        // Should not throw when comparing a null entry since getName(null) == "".
        Collections.sort(list, ClassUtils.comparator());
        assertNull(list.get(0));
        assertEquals(String.class, list.get(1));
    }

    // --- Serializable sanity: ensure interfaces are detected across library classes ---

    @Test
    void testGetAllInterfacesDetectsSerializable() {
        assertTrue(ClassUtils.getAllInterfaces(Integer.class).contains(Serializable.class));
    }
}
