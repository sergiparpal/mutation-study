/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

public class FractionAgentTest {

    // ---- factory methods: getFraction(int, int) ----

    @Test
    public void testGetFractionIntInt_basic() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertEquals(3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionIntInt_negativeDenominatorMovesSignToNumerator() {
        final Fraction f = Fraction.getFraction(3, -7);
        assertEquals(-3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionIntInt_zeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(1, 0);
            }
        });
    }

    @Test
    public void testGetFractionIntInt_minValueDenominatorOverflowThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(1, Integer.MIN_VALUE);
            }
        });
    }

    @Test
    public void testGetFractionIntInt_minValueNumeratorWithNegativeDenominatorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(Integer.MIN_VALUE, -1);
            }
        });
    }

    // ---- factory methods: getFraction(int, int, int) ----

    @Test
    public void testGetFractionWholeNumDenom_basic() {
        final Fraction f = Fraction.getFraction(1, 3, 7);
        assertEquals(10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionWholeNumDenom_negativeWhole() {
        final Fraction f = Fraction.getFraction(-1, 3, 7);
        assertEquals(-10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionWholeNumDenom_negativeNumeratorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(1, -3, 7);
            }
        });
    }

    @Test
    public void testGetFractionWholeNumDenom_negativeDenominatorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(1, 3, -7);
            }
        });
    }

    @Test
    public void testGetFractionWholeNumDenom_zeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(1, 3, 0);
            }
        });
    }

    @Test
    public void testGetFractionWholeNumDenom_numeratorOverflowThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(Integer.MAX_VALUE, 1, 2);
            }
        });
    }

    // ---- factory methods: getFraction(String) ----

    @Test
    public void testGetFractionString_wholeNumber() {
        final Fraction f = Fraction.getFraction("5");
        assertEquals(5, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    public void testGetFractionString_simpleFraction() {
        final Fraction f = Fraction.getFraction("3/7");
        assertEquals(3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionString_mixedFraction() {
        final Fraction f = Fraction.getFraction("1 3/7");
        assertEquals(10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionString_decimal() {
        final Fraction f = Fraction.getFraction("1.5");
        assertEquals(Fraction.getFraction(3, 2), f.reduce());
    }

    @Test
    public void testGetFractionString_nullThrowsNPE() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction((String) null);
            }
        });
    }

    @Test
    public void testGetFractionString_malformedMixedFractionThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction("1 3");
            }
        });
    }

    @Test
    public void testGetFractionString_nonNumericThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction("abc");
            }
        });
    }

    // ---- factory methods: getFraction(double) ----

    @Test
    public void testGetFractionDouble_half() {
        final Fraction f = Fraction.getFraction(0.5d);
        assertEquals(Fraction.ONE_HALF, f);
    }

    @Test
    public void testGetFractionDouble_negative() {
        final Fraction f = Fraction.getFraction(-0.25d);
        assertEquals(-1.0d * 0.25d, f.doubleValue(), 0.0000001d);
        assertTrue(f.getNumerator() < 0);
    }

    @Test
    public void testGetFractionDouble_nanThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(Double.NaN);
            }
        });
    }

    @Test
    public void testGetFractionDouble_tooLargeThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getFraction(((double) Integer.MAX_VALUE) * 2.0d);
            }
        });
    }

    // ---- factory methods: getReducedFraction(int, int) ----

    @Test
    public void testGetReducedFraction_reduces() {
        final Fraction f = Fraction.getReducedFraction(2, 4);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetReducedFraction_zeroNumeratorNormalizesToZero() {
        final Fraction f = Fraction.getReducedFraction(0, 5);
        assertSame(Fraction.ZERO, f);
    }

    @Test
    public void testGetReducedFraction_negativeDenominator() {
        final Fraction f = Fraction.getReducedFraction(2, -4);
        assertEquals(-1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetReducedFraction_zeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.getReducedFraction(1, 0);
            }
        });
    }

    @Test
    public void testGetReducedFraction_minValueDenominatorWithEvenNumerator() {
        final Fraction f = Fraction.getReducedFraction(4, Integer.MIN_VALUE);
        assertTrue(f.getDenominator() > 0);
        assertEquals(4.0d / Integer.MIN_VALUE, f.doubleValue(), 0.0000000001d);
    }

    // ---- instance arithmetic ----

    @Test
    public void testAbs_positiveReturnsSameInstance() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertSame(f, f.abs());
    }

    @Test
    public void testAbs_negativeReturnsPositive() {
        final Fraction f = Fraction.getFraction(-3, 7);
        final Fraction abs = f.abs();
        assertEquals(3, abs.getNumerator());
        assertEquals(7, abs.getDenominator());
    }

    @Test
    public void testAdd_basic() {
        final Fraction f = Fraction.ONE_THIRD.add(Fraction.ONE_THIRD);
        assertEquals(Fraction.TWO_THIRDS, f);
    }

    @Test
    public void testAdd_zeroIdentity() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertSame(f, f.add(Fraction.ZERO));
    }

    @Test
    public void testAdd_differentDenominatorsRequiringBigIntegerPath() {
        // denominators 6 and 4 share a gcd > 1, exercising the BigInteger branch.
        final Fraction f = Fraction.getFraction(1, 6).add(Fraction.getFraction(1, 4));
        assertEquals(Fraction.getFraction(5, 12), f);
    }

    @Test
    public void testAdd_nullThrowsNPE() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                f.add(null);
            }
        });
    }

    @Test
    public void testAdd_overflowThrows() {
        final Fraction f = Fraction.getFraction(Integer.MAX_VALUE, 1);
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                f.add(Fraction.ONE);
            }
        });
    }

    @Test
    public void testSubtract_basic() {
        final Fraction f = Fraction.ONE.subtract(Fraction.ONE_THIRD);
        assertEquals(Fraction.TWO_THIRDS, f);
    }

    @Test
    public void testSubtract_nullThrowsNPE() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                f.subtract(null);
            }
        });
    }

    @Test
    public void testMultiplyBy_basic() {
        final Fraction f = Fraction.ONE_HALF.multiplyBy(Fraction.getFraction(2, 3));
        assertEquals(Fraction.ONE_THIRD, f);
    }

    @Test
    public void testMultiplyBy_byZeroReturnsZero() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertSame(Fraction.ZERO, f.multiplyBy(Fraction.ZERO));
    }

    @Test
    public void testMultiplyBy_nullThrowsNPE() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                f.multiplyBy(null);
            }
        });
    }

    @Test
    public void testDivideBy_basic() {
        final Fraction f = Fraction.ONE_HALF.divideBy(Fraction.ONE_THIRD);
        assertEquals(Fraction.getFraction(3, 2), f);
    }

    @Test
    public void testDivideBy_byZeroThrows() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                f.divideBy(Fraction.ZERO);
            }
        });
    }

    @Test
    public void testDivideBy_nullThrowsNPE() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                f.divideBy(null);
            }
        });
    }

    @Test
    public void testInvert_basic() {
        final Fraction f = Fraction.getFraction(3, 7).invert();
        assertEquals(7, f.getNumerator());
        assertEquals(3, f.getDenominator());
    }

    @Test
    public void testInvert_negativeNumeratorKeepsSignOnNumerator() {
        final Fraction f = Fraction.getFraction(-3, 7).invert();
        assertEquals(-7, f.getNumerator());
        assertEquals(3, f.getDenominator());
    }

    @Test
    public void testInvert_zeroThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                Fraction.ZERO.invert();
            }
        });
    }

    @Test
    public void testInvert_minValueNumeratorThrows() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                f.invert();
            }
        });
    }

    @Test
    public void testNegate_basic() {
        final Fraction f = Fraction.getFraction(3, 7).negate();
        assertEquals(-3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testNegate_minValueNumeratorThrows() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                f.negate();
            }
        });
    }

    // ---- pow ----

    @Test
    public void testPow_zeroYieldsOneEvenForZeroFraction() {
        assertSame(Fraction.ONE, Fraction.ZERO.pow(0));
    }

    @Test
    public void testPow_oneYieldsSameInstance() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertSame(f, f.pow(1));
    }

    @Test
    public void testPow_positive() {
        final Fraction f = Fraction.ONE_HALF.pow(3);
        assertEquals(Fraction.getFraction(1, 8), f);
    }

    @Test
    public void testPow_negative() {
        final Fraction f = Fraction.getFraction(2, 3).pow(-2);
        assertEquals(Fraction.getFraction(9, 4), f);
    }

    @Test
    public void testPow_minValueExponentDoesNotThrow() {
        // Exercises the special-cased branch for Integer.MIN_VALUE, which can't be negated directly.
        final Fraction f = Fraction.ONE.pow(Integer.MIN_VALUE);
        assertEquals(Fraction.ONE, f);
    }

    @Test
    public void testPow_overflowThrows() {
        final Fraction f = Fraction.getFraction(Integer.MAX_VALUE, 1);
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                f.pow(2);
            }
        });
    }

    // ---- reduce ----

    @Test
    public void testReduce_alreadyReducedReturnsSameInstance() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertSame(f, f.reduce());
    }

    @Test
    public void testReduce_reducesToLowestTerms() {
        final Fraction f = Fraction.getFraction(4, 8);
        final Fraction reduced = f.reduce();
        assertEquals(1, reduced.getNumerator());
        assertEquals(2, reduced.getDenominator());
    }

    @Test
    public void testReduce_zeroNumeratorNonCanonicalReturnsZero() {
        final Fraction f = Fraction.getFraction(0, 5);
        assertSame(Fraction.ZERO, f.reduce());
    }

    @Test
    public void testReduce_canonicalZeroReturnsSameInstance() {
        assertSame(Fraction.ZERO, Fraction.ZERO.reduce());
    }

    // ---- getters ----

    @Test
    public void testGetProperNumeratorAndWhole_positiveImproperFraction() {
        final Fraction f = Fraction.getFraction(7, 4);
        assertEquals(3, f.getProperNumerator());
        assertEquals(1, f.getProperWhole());
    }

    @Test
    public void testGetProperNumeratorAndWhole_negativeImproperFraction() {
        final Fraction f = Fraction.getFraction(-7, 4);
        assertEquals(3, f.getProperNumerator());
        assertEquals(-1, f.getProperWhole());
    }

    @Test
    public void testGetProperNumeratorAndWhole_properFraction() {
        final Fraction f = Fraction.getFraction(3, 4);
        assertEquals(3, f.getProperNumerator());
        assertEquals(0, f.getProperWhole());
    }

    // ---- Number conversions ----

    @Test
    public void testIntValue_truncatesTowardZero() {
        assertEquals(1, Fraction.getFraction(7, 4).intValue());
        assertEquals(-1, Fraction.getFraction(-7, 4).intValue());
    }

    @Test
    public void testLongValue_truncatesTowardZero() {
        assertEquals(1L, Fraction.getFraction(7, 4).longValue());
        assertEquals(-1L, Fraction.getFraction(-7, 4).longValue());
    }

    @Test
    public void testDoubleValue() {
        assertEquals(0.75d, Fraction.getFraction(3, 4).doubleValue(), 0.0000001d);
    }

    @Test
    public void testFloatValue() {
        assertEquals(0.75f, Fraction.getFraction(3, 4).floatValue(), 0.0000001f);
    }

    // ---- equals / hashCode ----

    @Test
    public void testEquals_sameValueEqual() {
        assertEquals(Fraction.getFraction(1, 2), Fraction.getFraction(1, 2));
    }

    @Test
    public void testEquals_unreducedFormsNotEqual() {
        // Documented behaviour: equals() is representation-sensitive, unlike compareTo().
        assertNotEquals(Fraction.getFraction(1, 2), Fraction.getFraction(2, 4));
    }

    @Test
    public void testEquals_nullIsFalse() {
        assertFalse(Fraction.getFraction(1, 2).equals(null));
    }

    @Test
    public void testEquals_differentTypeIsFalse() {
        assertFalse(Fraction.getFraction(1, 2).equals("1/2"));
    }

    @Test
    public void testEquals_sameInstance() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertTrue(f.equals(f));
    }

    @Test
    public void testHashCode_equalObjectsHaveEqualHashCodes() {
        final Fraction a = Fraction.getFraction(3, 7);
        final Fraction b = Fraction.getFraction(3, 7);
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    public void testHashCode_unreducedFormsDiffer() {
        assertNotEquals(Fraction.getFraction(1, 2).hashCode(), Fraction.getFraction(2, 4).hashCode());
    }

    // ---- compareTo ----

    @Test
    public void testCompareTo_sameInstance() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertEquals(0, f.compareTo(f));
    }

    @Test
    public void testCompareTo_equalValueDifferentRepresentation() {
        // compareTo treats 1/2 and 2/4 as equal, unlike equals().
        assertEquals(0, Fraction.getFraction(1, 2).compareTo(Fraction.getFraction(2, 4)));
    }

    @Test
    public void testCompareTo_lessAndGreater() {
        assertTrue(Fraction.getFraction(1, 3).compareTo(Fraction.getFraction(1, 2)) < 0);
        assertTrue(Fraction.getFraction(1, 2).compareTo(Fraction.getFraction(1, 3)) > 0);
    }

    @Test
    public void testCompareTo_nullThrowsNPE() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                f.compareTo(null);
            }
        });
    }

    // ---- String representations ----

    @Test
    public void testToString_isCached() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertEquals("3/7", f.toString());
        assertSame(f.toString(), f.toString());
    }

    @Test
    public void testToProperString_zero() {
        assertEquals("0", Fraction.ZERO.toProperString());
    }

    @Test
    public void testToProperString_wholeOne() {
        assertEquals("1", Fraction.getFraction(4, 4).toProperString());
    }

    @Test
    public void testToProperString_wholeNegativeOne() {
        assertEquals("-1", Fraction.getFraction(-4, 4).toProperString());
    }

    @Test
    public void testToProperString_properFraction() {
        assertEquals("3/4", Fraction.getFraction(3, 4).toProperString());
    }

    @Test
    public void testToProperString_improperFractionWithWholePart() {
        assertEquals("1 3/4", Fraction.getFraction(7, 4).toProperString());
    }

    @Test
    public void testToProperString_negativeImproperFractionWithWholePart() {
        assertEquals("-1 3/4", Fraction.getFraction(-7, 4).toProperString());
    }

    @Test
    public void testToProperString_minValueNumeratorDoesNotOverflow() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertEquals(Integer.toString(Integer.MIN_VALUE), f.toProperString());
    }

    // ---- constants ----

    @Test
    public void testConstants() {
        assertEquals(Fraction.getFraction(0, 1), Fraction.ZERO);
        assertEquals(Fraction.getFraction(1, 1), Fraction.ONE);
        assertEquals(Fraction.getFraction(1, 2), Fraction.ONE_HALF);
        assertEquals(Fraction.getFraction(1, 3), Fraction.ONE_THIRD);
        assertEquals(Fraction.getFraction(2, 3), Fraction.TWO_THIRDS);
        assertEquals(Fraction.getFraction(1, 4), Fraction.ONE_QUARTER);
        assertEquals(Fraction.getFraction(2, 4), Fraction.TWO_QUARTERS);
        assertEquals(Fraction.getFraction(3, 4), Fraction.THREE_QUARTERS);
        assertEquals(Fraction.getFraction(1, 5), Fraction.ONE_FIFTH);
        assertEquals(Fraction.getFraction(2, 5), Fraction.TWO_FIFTHS);
        assertEquals(Fraction.getFraction(3, 5), Fraction.THREE_FIFTHS);
        assertEquals(Fraction.getFraction(4, 5), Fraction.FOUR_FIFTHS);
    }
}
