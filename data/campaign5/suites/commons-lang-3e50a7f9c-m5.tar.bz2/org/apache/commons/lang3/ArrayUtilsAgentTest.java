/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Map;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link ArrayUtils}.
 */
class ArrayUtilsAgentTest {

    @Test
    void testIsEmptyAndIsNotEmpty() {
        assertTrue(ArrayUtils.isEmpty((Object[]) null));
        assertTrue(ArrayUtils.isEmpty(new Object[0]));
        assertFalse(ArrayUtils.isEmpty(new Object[] {"a"}));

        assertTrue(ArrayUtils.isEmpty((int[]) null));
        assertTrue(ArrayUtils.isEmpty(new int[0]));
        assertFalse(ArrayUtils.isEmpty(new int[] {1}));

        assertFalse(ArrayUtils.isNotEmpty((Object[]) null));
        assertFalse(ArrayUtils.isNotEmpty(new int[0]));
        assertTrue(ArrayUtils.isNotEmpty(new int[] {1}));
        assertTrue(ArrayUtils.isNotEmpty(new Object[] {"a"}));
    }

    @Test
    void testGetLength() {
        assertEquals(0, ArrayUtils.getLength(null));
        assertEquals(0, ArrayUtils.getLength(new Object[0]));
        assertEquals(3, ArrayUtils.getLength(new int[] {1, 2, 3}));
        assertEquals(2, ArrayUtils.getLength(new String[] {"a", "b"}));
        assertEquals(4, ArrayUtils.getLength(new int[][] {{1}, {2}, {3}, {4}}));
    }

    @Test
    void testContainsIndexOfLastIndexOf() {
        final int[] ints = {1, 2, 3, 2, 1};
        assertTrue(ArrayUtils.contains(ints, 2));
        assertFalse(ArrayUtils.contains(ints, 9));
        assertFalse(ArrayUtils.contains((int[]) null, 1));

        assertEquals(1, ArrayUtils.indexOf(ints, 2));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf(ints, 9));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf((int[]) null, 1));
        assertEquals(3, ArrayUtils.indexOf(ints, 2, 2));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf(ints, 2, 10));

        assertEquals(3, ArrayUtils.lastIndexOf(ints, 2));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.lastIndexOf(ints, 9));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.lastIndexOf((int[]) null, 1));
        assertEquals(1, ArrayUtils.lastIndexOf(ints, 2, 2));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.lastIndexOf(ints, 2, -1));

        final Object[] objs = {"a", "b", "c", "b"};
        assertTrue(ArrayUtils.contains(objs, "b"));
        assertFalse(ArrayUtils.contains(objs, "z"));
        assertFalse(ArrayUtils.contains((Object[]) null, "a"));
        assertEquals(1, ArrayUtils.indexOf(objs, "b"));
        assertEquals(3, ArrayUtils.lastIndexOf(objs, "b"));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf(objs, null));
    }

    @Test
    void testIsSameLengthAndIsSameType() {
        assertTrue(ArrayUtils.isSameLength(new int[] {1, 2}, new int[] {3, 4}));
        assertFalse(ArrayUtils.isSameLength(new int[] {1, 2}, new int[] {3}));
        assertTrue(ArrayUtils.isSameLength((Object[]) null, (Object[]) null));
        assertTrue(ArrayUtils.isSameLength((Object) null, new Object[0]));

        assertTrue(ArrayUtils.isSameType(new int[0], new int[0]));
        assertFalse(ArrayUtils.isSameType(new int[0], new long[0]));
        assertFalse(ArrayUtils.isSameType(new String[0], new Object[0]));
        assertThrows(IllegalArgumentException.class, () -> ArrayUtils.isSameType(null, new int[0]));
        assertThrows(IllegalArgumentException.class, () -> ArrayUtils.isSameType(new int[0], null));
    }

    @Test
    void testIsSorted() {
        assertTrue(ArrayUtils.isSorted(new int[] {1, 2, 2, 3}));
        assertFalse(ArrayUtils.isSorted(new int[] {3, 2, 1}));
        assertTrue(ArrayUtils.isSorted(new int[0]));
        assertTrue(ArrayUtils.isSorted(new int[] {1}));
        assertTrue(ArrayUtils.isSorted((int[]) null));
    }

    @Test
    void testIsArrayIndexValid() {
        final String[] array = {"a", "b", "c"};
        assertTrue(ArrayUtils.isArrayIndexValid(array, 0));
        assertTrue(ArrayUtils.isArrayIndexValid(array, 2));
        assertFalse(ArrayUtils.isArrayIndexValid(array, 3));
        assertFalse(ArrayUtils.isArrayIndexValid(array, -1));
        assertFalse(ArrayUtils.isArrayIndexValid(null, 0));
    }

    @Test
    void testClone() {
        final int[] original = {1, 2, 3};
        final int[] cloned = ArrayUtils.clone(original);
        assertArrayEquals(original, cloned);
        assertTrue(cloned != original);
        assertNull(ArrayUtils.clone((int[]) null));

        final String[] originalObjs = {"a", "b"};
        final String[] clonedObjs = ArrayUtils.clone(originalObjs);
        assertArrayEquals(originalObjs, clonedObjs);
        assertTrue(clonedObjs != originalObjs);
        assertNull(ArrayUtils.clone((Object[]) null));
    }

    @Test
    void testSubarray() {
        final int[] array = {1, 2, 3, 4, 5};
        assertArrayEquals(new int[] {2, 3}, ArrayUtils.subarray(array, 1, 3));
        assertArrayEquals(array, ArrayUtils.subarray(array, 0, 5));
        assertArrayEquals(new int[0], ArrayUtils.subarray(array, 3, 1));
        assertArrayEquals(array, ArrayUtils.subarray(array, -2, 10));
        assertNull(ArrayUtils.subarray((int[]) null, 0, 2));
        assertEquals(0, ArrayUtils.subarray(array, 5, 5).length);
    }

    @Test
    void testReverse() {
        final int[] array = {1, 2, 3, 4, 5};
        ArrayUtils.reverse(array);
        assertArrayEquals(new int[] {5, 4, 3, 2, 1}, array);

        final int[] partial = {1, 2, 3, 4, 5};
        ArrayUtils.reverse(partial, 1, 4);
        assertArrayEquals(new int[] {1, 4, 3, 2, 5}, partial);

        ArrayUtils.reverse((int[]) null);
        final int[] empty = {};
        ArrayUtils.reverse(empty);
        assertEquals(0, empty.length);
    }

    @Test
    void testSwap() {
        final int[] array = {1, 2, 3};
        ArrayUtils.swap(array, 0, 2);
        assertArrayEquals(new int[] {3, 2, 1}, array);

        final int[] noop = {1, 2, 3};
        ArrayUtils.swap(noop, 0, 5);
        assertArrayEquals(new int[] {1, 2, 3}, noop);

        final int[] negative = {1, 2, 3};
        ArrayUtils.swap(negative, -1, 1);
        assertArrayEquals(new int[] {2, 1, 3}, negative);

        ArrayUtils.swap((int[]) null, 0, 1);
    }

    @Test
    void testShift() {
        final int[] array = {1, 2, 3, 4, 5};
        ArrayUtils.shift(array, 1);
        assertArrayEquals(new int[] {5, 1, 2, 3, 4}, array);

        final int[] zeroOffset = {1, 2, 3};
        ArrayUtils.shift(zeroOffset, 0);
        assertArrayEquals(new int[] {1, 2, 3}, zeroOffset);

        ArrayUtils.shift((int[]) null, 1);
        final int[] empty = {};
        ArrayUtils.shift(empty, 1);
        assertEquals(0, empty.length);
    }

    @Test
    void testNullToEmpty() {
        final int[] nonNull = ArrayUtils.nullToEmpty((int[]) null);
        assertArrayEquals(new int[0], nonNull);
        final int[] original = {1, 2};
        assertSame(original, ArrayUtils.nullToEmpty(original));

        assertArrayEquals(new String[0], ArrayUtils.nullToEmpty((String[]) null));
        final String[] originalStrings = {"a"};
        assertSame(originalStrings, ArrayUtils.nullToEmpty(originalStrings));
    }

    @Test
    void testToObjectAndToPrimitive() {
        final int[] primitives = {1, 2, 3};
        final Integer[] objects = ArrayUtils.toObject(primitives);
        assertArrayEquals(new Integer[] {1, 2, 3}, objects);

        final int[] back = ArrayUtils.toPrimitive(objects);
        assertArrayEquals(primitives, back);

        assertNull(ArrayUtils.toPrimitive((Integer[]) null));
        assertThrows(NullPointerException.class,
                () -> ArrayUtils.toPrimitive(new Integer[] {1, null}));

        final int[] withDefault = ArrayUtils.toPrimitive(new Integer[] {1, null, 3}, -1);
        assertArrayEquals(new int[] {1, -1, 3}, withDefault);
    }

    @Test
    void testToStringArray() {
        final String[] result = ArrayUtils.toStringArray(new Object[] {1, "a", null});
        assertArrayEquals(new String[] {"1", "a", "null"}, result);
        assertNull(ArrayUtils.toStringArray(null));

        final String[] withDefault = ArrayUtils.toStringArray(new Object[] {1, null}, "NULL");
        assertArrayEquals(new String[] {"1", "NULL"}, withDefault);
    }

    @Test
    void testToMap() {
        assertNull(ArrayUtils.toMap(null));

        final Map<Object, Object> map = ArrayUtils.toMap(
                new String[][] {{"RED", "#FF0000"}, {"GREEN", "#00FF00"}});
        assertEquals(2, map.size());
        assertEquals("#FF0000", map.get("RED"));
        assertEquals("#00FF00", map.get("GREEN"));

        assertThrows(IllegalArgumentException.class,
                () -> ArrayUtils.toMap(new Object[] {new String[] {"ONLY_ONE"}}));
        assertThrows(IllegalArgumentException.class,
                () -> ArrayUtils.toMap(new Object[] {"not an entry or array"}));
    }

    @Test
    void testAddAll() {
        final int[] combined = ArrayUtils.addAll(new int[] {1, 2}, 3, 4);
        assertArrayEquals(new int[] {1, 2, 3, 4}, combined);
        assertArrayEquals(new int[] {3, 4}, ArrayUtils.addAll((int[]) null, 3, 4));
        assertArrayEquals(new int[] {1, 2}, ArrayUtils.addAll(new int[] {1, 2}, (int[]) null));

        final String[] combinedObjs = ArrayUtils.addAll(new String[] {"a"}, "b", "c");
        assertArrayEquals(new String[] {"a", "b", "c"}, combinedObjs);
    }

    @Test
    void testInsert() {
        final int[] array = {1, 2, 3};
        assertArrayEquals(new int[] {1, 9, 2, 3}, ArrayUtils.insert(1, array, 9));
        assertNull(ArrayUtils.insert(0, (int[]) null, 1));
        assertArrayEquals(array, ArrayUtils.insert(1, array, (int[]) null));

        assertThrows(IndexOutOfBoundsException.class, () -> ArrayUtils.insert(-1, array, 9));
        assertThrows(IndexOutOfBoundsException.class, () -> ArrayUtils.insert(4, array, 9));
    }

    @Test
    void testHashCode() {
        assertEquals(ArrayUtils.hashCode(null), ArrayUtils.hashCode(null));
        final int[] array1 = {1, 2, 3};
        final int[] array2 = {1, 2, 3};
        final int[] array3 = {3, 2, 1};
        assertEquals(ArrayUtils.hashCode(array1), ArrayUtils.hashCode(array2));
        assertTrue(ArrayUtils.hashCode(array1) != ArrayUtils.hashCode(array3));
    }
}
