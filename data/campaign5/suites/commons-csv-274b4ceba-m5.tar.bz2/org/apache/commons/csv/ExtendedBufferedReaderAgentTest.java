/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.apache.commons.csv.Constants.UNDEFINED;
import static org.apache.commons.io.IOUtils.EOF;
import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link ExtendedBufferedReader}.
 */
class ExtendedBufferedReaderAgentTest {

    private ExtendedBufferedReader createBufferedReader(final String s) {
        return new ExtendedBufferedReader(new StringReader(s));
    }

    @Test
    void testConstructorWithNullCharsetDoesNotTrackBytes() throws IOException {
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("abc"), null, true);
        try {
            assertEquals('a', br.read());
            assertEquals(0, br.getBytesRead());
        } finally {
            br.close();
        }
    }

    @Test
    void testConstructorWithCharsetButTrackBytesFalse() throws IOException {
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("abc"), StandardCharsets.UTF_8, false);
        try {
            assertEquals('a', br.read());
            assertEquals(0, br.getBytesRead());
        } finally {
            br.close();
        }
    }

    @Test
    void testBytesReadAsciiTracksOneBytePerChar() throws IOException {
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("abc"), StandardCharsets.UTF_8, true);
        try {
            assertEquals('a', br.read());
            assertEquals(1, br.getBytesRead());
            assertEquals('b', br.read());
            assertEquals(2, br.getBytesRead());
            assertEquals('c', br.read());
            assertEquals(3, br.getBytesRead());
            assertEquals(EOF, br.read());
            // EOF must not increase the byte count
            assertEquals(3, br.getBytesRead());
        } finally {
            br.close();
        }
    }

    @Test
    void testBytesReadWithBulkReadArray() throws IOException {
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("hello"), StandardCharsets.UTF_8, true);
        try {
            final char[] buf = new char[10];
            final int n = br.read(buf, 0, 5);
            assertEquals(5, n);
            assertEquals(5, br.getBytesRead());
        } finally {
            br.close();
        }
    }

    @Test
    void testGetLastCharInitiallyUndefined() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("abc");
        try {
            assertEquals(UNDEFINED, br.getLastChar());
        } finally {
            br.close();
        }
    }

    @Test
    void testGetLastCharAfterRead() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("abc");
        try {
            br.read();
            assertEquals('a', br.getLastChar());
            br.read();
            assertEquals('b', br.getLastChar());
        } finally {
            br.close();
        }
    }

    @Test
    void testGetLastCharAtEof() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("a");
        try {
            br.read();
            br.read();
            assertEquals(EOF, br.getLastChar());
        } finally {
            br.close();
        }
    }

    @Test
    void testGetPositionTracksCharactersRead() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("abcdef");
        try {
            assertEquals(0, br.getPosition());
            br.read();
            assertEquals(1, br.getPosition());
            final char[] buf = new char[3];
            br.read(buf, 0, 3);
            assertEquals(4, br.getPosition());
        } finally {
            br.close();
        }
    }

    @Test
    void testGetPositionDoesNotAdvanceOnPeek() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("abc");
        try {
            br.peek();
            br.peek();
            assertEquals(0, br.getPosition());
        } finally {
            br.close();
        }
    }

    @Test
    void testGetLineNumberOnEmptyInput() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("");
        try {
            assertEquals(0, br.getLineNumber());
            // Reaching EOF terminates the (empty) trailing line.
            assertEquals(EOF, br.read());
            assertEquals(1, br.getLineNumber());
        } finally {
            br.close();
        }
    }

    @Test
    void testGetLineNumberLookAheadBeforeEol() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("a\nb");
        try {
            br.read(); // 'a': not yet terminated, so getLineNumber() looks ahead by one
            assertEquals(1, br.getLineNumber());
            br.read(); // '\n' completes line 1
            assertEquals(1, br.getLineNumber());
            // 'b' has been read but not yet terminated: getLineNumber() looks ahead by one
            br.read();
            assertEquals(2, br.getLineNumber());
        } finally {
            br.close();
        }
    }

    @Test
    void testReadSingleCharReturnsEofAtEnd() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("x");
        try {
            assertEquals('x', br.read());
            assertEquals(EOF, br.read());
            assertEquals(EOF, br.read());
        } finally {
            br.close();
        }
    }

    @Test
    void testReadArrayWithZeroLengthReturnsZeroAndDoesNotAdvance() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("abc");
        try {
            final char[] buf = new char[5];
            assertEquals(0, br.read(buf, 0, 0));
            assertEquals(0, br.getPosition());
            assertEquals(UNDEFINED, br.getLastChar());
        } finally {
            br.close();
        }
    }

    @Test
    void testReadArrayOnEmptyStreamReturnsEofAndSetsLastChar() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("");
        try {
            final char[] buf = new char[5];
            assertEquals(EOF, br.read(buf, 0, 5));
            assertEquals(EOF, br.getLastChar());
        } finally {
            br.close();
        }
    }

    @Test
    void testReadArrayPartialFillAtEof() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("ab");
        try {
            final char[] buf = new char[5];
            final int n = br.read(buf, 0, 5);
            assertEquals(2, n);
            assertEquals('a', buf[0]);
            assertEquals('b', buf[1]);
            assertEquals('b', br.getLastChar());
        } finally {
            br.close();
        }
    }

    @Test
    void testPeekDoesNotConsumeAndMatchesSubsequentRead() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("ab");
        try {
            assertEquals('a', br.peek());
            assertEquals('a', br.peek());
            assertEquals('a', br.read());
            assertEquals('b', br.peek());
            assertEquals('b', br.read());
            assertEquals(EOF, br.peek());
            assertEquals(EOF, br.read());
        } finally {
            br.close();
        }
    }

    @Test
    void testReadLineReturnsNullOnEmptyInput() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("");
        try {
            assertNull(br.readLine());
        } finally {
            br.close();
        }
    }

    @Test
    void testReadLineDropsLineTerminators() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("foo\r\nbar\ngee\rend");
        try {
            assertEquals("foo", br.readLine());
            assertEquals("bar", br.readLine());
            assertEquals("gee", br.readLine());
            assertEquals("end", br.readLine());
            assertNull(br.readLine());
        } finally {
            br.close();
        }
    }

    @Test
    void testReadLineWithOnlyTerminatorReturnsEmptyString() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("\n");
        try {
            assertEquals("", br.readLine());
            assertNull(br.readLine());
        } finally {
            br.close();
        }
    }

    @Test
    void testMarkAndResetRestoreStateIncludingLineNumberAndPosition() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("ab\ncd");
        try {
            br.read(); // 'a'
            br.mark(10);
            final long markedLine = br.getLineNumber();
            final long markedPosition = br.getPosition();
            final int markedLastChar = br.getLastChar();

            br.read();
            br.read();
            br.read();

            br.reset();
            assertEquals(markedLine, br.getLineNumber());
            assertEquals(markedPosition, br.getPosition());
            assertEquals(markedLastChar, br.getLastChar());
            // Reading again from the reset point must reproduce the same characters
            assertEquals('b', br.read());
            assertEquals('\n', br.read());
        } finally {
            br.close();
        }
    }

    @Test
    void testMarkAndResetRestoresBytesRead() throws IOException {
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("abcdef"), StandardCharsets.UTF_8, true);
        try {
            br.read();
            br.read();
            br.mark(10);
            final long markedBytes = br.getBytesRead();
            br.read();
            br.read();
            assertTrue(br.getBytesRead() > markedBytes);
            br.reset();
            assertEquals(markedBytes, br.getBytesRead());
        } finally {
            br.close();
        }
    }

    @Test
    void testResetWithoutPriorMarkThrows() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("abc");
        try {
            assertThrows(IOException.class, new org.junit.jupiter.api.function.Executable() {
                @Override
                public void execute() throws Throwable {
                    br.reset();
                }
            });
        } finally {
            br.close();
        }
    }

    @Test
    void testCloseSetsLastCharToEofAndRejectsFurtherReads() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("abc");
        br.close();
        assertEquals(EOF, br.getLastChar());
        assertThrows(IOException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                br.read();
            }
        });
    }

    @Test
    void testCloseSetsLastCharToEofEvenIfUnderlyingReaderThrows() {
        final Reader throwingReader = new Reader() {
            @Override
            public int read(final char[] cbuf, final int off, final int len) throws IOException {
                return -1;
            }

            @Override
            public void close() throws IOException {
                throw new IOException("boom");
            }
        };
        final ExtendedBufferedReader br = new ExtendedBufferedReader(throwingReader);
        assertThrows(IOException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                br.close();
            }
        });
        assertEquals(EOF, br.getLastChar());
    }

    @Test
    void testMixedLineTerminatorsCountedCorrectlyAcrossReadModes() throws IOException {
        final String text = "a\nb\r\nc\rd";
        // 4 lines: "a", "b", "c", "d" (the trailing unterminated "d" line is closed by EOF)
        final ExtendedBufferedReader br = createBufferedReader(text);
        try {
            int count = 0;
            while (br.read() != EOF) {
                count++;
            }
            assertEquals(4, br.getLineNumber());
            assertEquals(text.length(), count);
        } finally {
            br.close();
        }
    }

    @Test
    void testCrlfSplitAcrossTwoBulkReadsCountsAsOneLine() throws IOException {
        final char[] tmp1 = new char[2];
        final char[] tmp2 = new char[4];
        final ExtendedBufferedReader br = createBufferedReader("1\r\n2\r\n");
        try {
            br.read(tmp1, 0, 2); // reads "1\r"
            br.read(tmp2, 2, 2); // reads "\n2"
            assertEquals(2, br.getLineNumber());
        } finally {
            br.close();
        }
    }

    @Test
    void testSupplementaryCharacterEncodedByteLength() throws IOException {
        final String input = "😀"; // a single supplementary character (surrogate pair)
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader(input), StandardCharsets.UTF_8, true);
        try {
            final char[] buffer = new char[input.length()];
            final int n = br.read(buffer, 0, buffer.length);
            assertEquals(input.length(), n);
            assertArrayEquals(input.toCharArray(), buffer);
            assertEquals(input.getBytes(StandardCharsets.UTF_8).length, br.getBytesRead());
            assertEquals(input.length(), br.getPosition());
        } finally {
            br.close();
        }
    }

    @Test
    void testMarkSupported() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("abc");
        try {
            assertTrue(br.markSupported());
        } finally {
            br.close();
        }
    }

    @Test
    void testReadyReflectsAvailability() throws IOException {
        final ExtendedBufferedReader br = createBufferedReader("abc");
        try {
            assertTrue(br.ready());
            br.read();
            br.read();
            br.read();
            assertEquals(EOF, br.read());
        } finally {
            br.close();
        }
    }
}
