/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.TimeZone;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests {@link DurationFormatUtils}.
 */
public class DurationFormatUtilsAgentTest {

    @Test
    public void testFormatDurationBasicPadded() {
        final long millis = (((2L * 24 + 3) * 60 + 4) * 60 + 5) * 1000 + 6;
        assertEquals("02d03h04m05s006", DurationFormatUtils.formatDuration(millis, "dd'd'HH'h'mm'm'ss's'SSS", true));
    }

    @Test
    public void testFormatDurationNoPadding() {
        final long millis = (((2L * 24 + 3) * 60 + 4) * 60 + 5) * 1000 + 6;
        // milliseconds following a seconds token are always padded to 3 digits, even with padWithZeros=false
        assertEquals("2d3h4m5s006", DurationFormatUtils.formatDuration(millis, "d'd'H'h'm'm's's'S", false));
    }

    @Test
    public void testFormatDurationZero() {
        assertEquals("00:00:00.000", DurationFormatUtils.formatDurationHMS(0));
    }

    @Test
    public void testFormatDurationDefaultsToPadded() {
        assertEquals(DurationFormatUtils.formatDuration(3661000L, "H:m:s", true), DurationFormatUtils.formatDuration(3661000L, "H:m:s"));
    }

    @Test
    public void testFormatDurationNegativeThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatDuration(-1L, "HH:mm:ss.SSS");
            }
        });
        assertTrue(ex.getMessage().contains("durationMillis"));
    }

    @Test
    public void testFormatDurationHMS() {
        assertEquals("01:02:03.004", DurationFormatUtils.formatDurationHMS(((1L * 60 + 2) * 60 + 3) * 1000 + 4));
    }

    @Test
    public void testFormatDurationHMSZero() {
        assertEquals("00:00:00.000", DurationFormatUtils.formatDurationHMS(0L));
    }

    @Test
    public void testFormatDurationISOZero() {
        assertEquals("P0Y0M0DT0H0M0.000S", DurationFormatUtils.formatDurationISO(0L));
    }

    @Test
    public void testFormatDurationISOOneDay() {
        assertEquals("P0Y0M1DT0H0M0.000S", DurationFormatUtils.formatDurationISO(24L * 60 * 60 * 1000));
    }

    @Test
    public void testFormatDurationWordsPlain() {
        final long millis = (((1L * 24 + 2) * 60 + 3) * 60 + 4) * 1000;
        assertEquals("1 day 2 hours 3 minutes 4 seconds", DurationFormatUtils.formatDurationWords(millis, false, false));
    }

    @Test
    public void testFormatDurationWordsZeroNoSuppression() {
        assertEquals("0 days 0 hours 0 minutes 0 seconds", DurationFormatUtils.formatDurationWords(0L, false, false));
    }

    @Test
    public void testFormatDurationWordsSuppressLeadingZero() {
        // only minutes and seconds present, days and hours are zero and should be suppressed
        final long millis = (3L * 60 + 4) * 1000;
        assertEquals("3 minutes 4 seconds", DurationFormatUtils.formatDurationWords(millis, true, false));
    }

    @Test
    public void testFormatDurationWordsSuppressTrailingZero() {
        // only days and hours present, minutes and seconds are zero and should be suppressed
        final long millis = ((1L * 24) + 2) * 60 * 60 * 1000;
        assertEquals("1 day 2 hours", DurationFormatUtils.formatDurationWords(millis, false, true));
    }

    @Test
    public void testFormatDurationWordsSuppressBothAllZero() {
        // leading suppression only strips the "0 days"/"0 hours"/"0 minutes" prefix, leaving the seconds field
        assertEquals("0 seconds", DurationFormatUtils.formatDurationWords(0L, true, true));
    }

    @Test
    public void testFormatDurationWordsSingularPluralization() {
        final long millis = ((1L * 24 + 1) * 60 + 1) * 60 * 1000 + 1000;
        assertEquals("1 day 1 hour 1 minute 1 second", DurationFormatUtils.formatDurationWords(millis, false, false));
    }

    @Test
    public void testFormatPeriodSimple() {
        final TimeZone gmt = TimeZone.getTimeZone("GMT");
        final long start = 0L;
        final long end = ((2L * 24 + 3) * 60 * 60 + 4 * 60 + 5) * 1000L;
        assertEquals("02 03:04:05", DurationFormatUtils.formatPeriod(start, end, "dd HH:mm:ss", true, gmt));
    }

    @Test
    public void testFormatPeriodZeroLength() {
        assertEquals("00:00:00", DurationFormatUtils.formatPeriod(1000L, 1000L, "HH:mm:ss"));
    }

    @Test
    public void testFormatPeriodStartAfterEndThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatPeriod(2000L, 1000L, "HH:mm:ss");
            }
        });
        assertTrue(ex.getMessage().contains("startMillis"));
    }

    @Test
    public void testFormatPeriodISOZero() {
        assertEquals("P0Y0M0DT0H0M0.000S", DurationFormatUtils.formatPeriodISO(1000L, 1000L));
    }

    @Test
    public void testFormatPeriodWithYearsAndMonths() {
        final TimeZone gmt = TimeZone.getTimeZone("GMT");
        final java.util.Calendar startCal = java.util.Calendar.getInstance(gmt);
        startCal.clear();
        startCal.set(2000, java.util.Calendar.JANUARY, 15, 0, 0, 0);
        final java.util.Calendar endCal = java.util.Calendar.getInstance(gmt);
        endCal.clear();
        endCal.set(2001, java.util.Calendar.MARCH, 10, 0, 0, 0);
        assertEquals("1 1 26", DurationFormatUtils.formatPeriod(startCal.getTimeInMillis(), endCal.getTimeInMillis(), "y M d", true, gmt));
    }

    @Test
    public void testOptionalBlockNonZeroIncluded() {
        final TimeZone gmt = TimeZone.getTimeZone("GMT");
        final long dayMillis = 24L * 60 * 60 * 1000;
        assertEquals("1d0s", DurationFormatUtils.formatPeriod(0L, dayMillis, "d'd'[H'h'm'm']s's'", true, gmt));
    }

    @Test
    public void testOptionalBlockZeroExcluded() {
        final TimeZone gmt = TimeZone.getTimeZone("GMT");
        final long hourMillis = 60L * 60 * 1000;
        assertEquals("0d1h0s", DurationFormatUtils.formatPeriod(0L, hourMillis, "d'd'[H'h'm'm']s's'", true, gmt));
    }

    @Test
    public void testLexxBasicTokensAreMerged() {
        final DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("yyyy-MM-dd");
        assertEquals(5, tokens.length);
        assertEquals("y", tokens[0].getValue());
        assertEquals(4, tokens[0].getCount());
        assertEquals("-", tokens[1].toString());
        assertEquals("M", tokens[2].getValue());
        assertEquals(2, tokens[2].getCount());
        assertEquals("-", tokens[3].toString());
        assertEquals("d", tokens[4].getValue());
        assertEquals(2, tokens[4].getCount());
    }

    @Test
    public void testLexxLiteralToken() {
        final DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("'literal text'd");
        assertEquals(2, tokens.length);
        assertEquals("literal text", tokens[0].toString());
        assertEquals("d", tokens[1].getValue());
    }

    @Test
    public void testLexxUnmatchedQuoteThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.lexx("'unterminated");
            }
        });
    }

    @Test
    public void testLexxUnmatchedOptionalOpenThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.lexx("[d");
            }
        });
    }

    @Test
    public void testLexxUnmatchedOptionalCloseThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.lexx("d]");
            }
        });
    }

    @Test
    public void testLexxNestedOptionalThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.lexx("[d[H]]");
            }
        });
    }

    @Test
    public void testTokenEqualsAndHashCode() {
        final DurationFormatUtils.Token[] tokensA = DurationFormatUtils.lexx("dd");
        final DurationFormatUtils.Token[] tokensB = DurationFormatUtils.lexx("dd");
        assertEquals(tokensA[0], tokensB[0]);
        assertEquals(tokensA[0].hashCode(), tokensB[0].hashCode());
        assertEquals("dd", tokensA[0].toString());
    }

    @Test
    public void testTokenNotEqualToDifferentCount() {
        final DurationFormatUtils.Token[] single = DurationFormatUtils.lexx("d");
        final DurationFormatUtils.Token[] doubled = DurationFormatUtils.lexx("dd");
        assertTrue(!single[0].equals(doubled[0]));
    }

    @Test
    public void testTokenNotEqualToNonToken() {
        final DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("d");
        assertTrue(!tokens[0].equals("d"));
    }

    @Test
    public void testConstructorIsPublic() {
        // deprecated but public constructor must still be usable
        assertTrue(new DurationFormatUtils() != null);
    }

    @Test
    public void testIsoExtendedFormatPatternConstant() {
        assertEquals("'P'yyyy'Y'M'M'd'DT'H'H'm'M's.SSS'S'", DurationFormatUtils.ISO_EXTENDED_FORMAT_PATTERN);
    }

    @Test
    public void testFormatDurationLargeValue() {
        // Just below Long.MAX_VALUE should not throw and should produce a non-empty result.
        final String result = DurationFormatUtils.formatDuration(Long.MAX_VALUE, "d");
        assertTrue(result.length() > 0);
    }
}
