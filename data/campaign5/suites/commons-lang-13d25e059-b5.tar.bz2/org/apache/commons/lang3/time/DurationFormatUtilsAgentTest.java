/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Calendar;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link DurationFormatUtils}.
 */
public class DurationFormatUtilsAgentTest {

    @Test
    public void testFormatDurationHMS_zero() {
        assertEquals("00:00:00.000", DurationFormatUtils.formatDurationHMS(0));
    }

    @Test
    public void testFormatDurationHMS_typical() {
        // 1h 2m 3s 4ms
        final long millis = ((1L * 60 + 2) * 60 + 3) * 1000 + 4;
        assertEquals("01:02:03.004", DurationFormatUtils.formatDurationHMS(millis));
    }

    @Test
    public void testFormatDuration_negativeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatDuration(-1, "HH:mm:ss.SSS");
            }
        });
    }

    @Test
    public void testFormatDuration_noPadding() {
        final long millis = ((1L * 60 + 2) * 60 + 3) * 1000 + 4;
        // milliseconds are always padded to at least 3 digits when preceded by seconds, even without padding requested
        assertEquals("1:2:3.004", DurationFormatUtils.formatDuration(millis, "H:m:s.S", false));
    }

    @Test
    public void testFormatDuration_withPadding() {
        final long millis = ((1L * 60 + 2) * 60 + 3) * 1000 + 4;
        assertEquals("01:02:03.004", DurationFormatUtils.formatDuration(millis, "HH:mm:ss.SSS", true));
    }

    @Test
    public void testFormatDurationISO() {
        // 1 day, 1 hour, 1 minute, 1.001 seconds
        final long millis = DateUtils.MILLIS_PER_DAY + DateUtils.MILLIS_PER_HOUR + DateUtils.MILLIS_PER_MINUTE + 1001;
        assertEquals("P0Y0M1DT1H1M1.001S", DurationFormatUtils.formatDurationISO(millis));
    }

    @Test
    public void testFormatDurationISO_zero() {
        assertEquals("P0Y0M0DT0H0M0.000S", DurationFormatUtils.formatDurationISO(0));
    }

    @Test
    public void testFormatDurationWords_noSuppression() {
        // 1 day, 1 hour, 1 minute, 1 second
        final long millis = DateUtils.MILLIS_PER_DAY + DateUtils.MILLIS_PER_HOUR + DateUtils.MILLIS_PER_MINUTE + 1000;
        assertEquals("1 day 1 hour 1 minute 1 second", DurationFormatUtils.formatDurationWords(millis, false, false));
    }

    @Test
    public void testFormatDurationWords_suppressLeadingZeroes() {
        // 0 days, 0 hours, 1 minute, 0 seconds
        final long millis = DateUtils.MILLIS_PER_MINUTE;
        assertEquals("1 minute 0 seconds", DurationFormatUtils.formatDurationWords(millis, true, false));
    }

    @Test
    public void testFormatDurationWords_suppressTrailingZeroes() {
        // 1 day, 0 hours, 0 minutes, 0 seconds
        final long millis = DateUtils.MILLIS_PER_DAY;
        assertEquals("1 day", DurationFormatUtils.formatDurationWords(millis, false, true));
    }

    @Test
    public void testFormatDurationWords_suppressBoth_allZero() {
        // leading-zero suppression consumes days/hours/minutes first, leaving a trailing "0 seconds"
        // that the subsequent trailing-zero suppression no longer matches (its leading space was stripped)
        assertEquals("0 seconds", DurationFormatUtils.formatDurationWords(0, true, true));
    }

    @Test
    public void testFormatDurationWords_pluralsSingular() {
        final long millis = DateUtils.MILLIS_PER_DAY + DateUtils.MILLIS_PER_HOUR + DateUtils.MILLIS_PER_MINUTE + 1000;
        final String text = DurationFormatUtils.formatDurationWords(millis, false, false);
        assertTrue(text.contains("1 day"));
        assertTrue(text.contains("1 hour"));
        assertTrue(text.contains("1 minute"));
        assertTrue(text.contains("1 second"));
        assertTrue(!text.contains("1 days"));
        assertTrue(!text.contains("1 hours"));
        assertTrue(!text.contains("1 minutes"));
        assertTrue(!text.contains("1 seconds"));
    }

    @Test
    public void testFormatPeriod_startGreaterThanEndThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatPeriod(1000L, 0L, "HH:mm:ss.SSS");
            }
        });
    }

    @Test
    public void testFormatPeriod_startEqualsEnd() {
        final TimeZone tz = TimeZone.getTimeZone("GMT");
        assertEquals("00:00:00.000", DurationFormatUtils.formatPeriod(0L, 0L, "HH:mm:ss.SSS", true, tz));
    }

    @Test
    public void testFormatPeriod_withYearsAndMonths() {
        final TimeZone tz = TimeZone.getTimeZone("GMT");
        final Calendar start = Calendar.getInstance(tz);
        start.clear();
        start.set(2000, Calendar.JANUARY, 15);
        final Calendar end = Calendar.getInstance(tz);
        end.clear();
        end.set(2000, Calendar.MARCH, 10);
        final String result = DurationFormatUtils.formatPeriod(start.getTimeInMillis(), end.getTimeInMillis(), "y'y' M'm' d'd'", true, tz);
        assertEquals("0y 1m 26d", result);
    }

    @Test
    public void testFormatPeriodISO() {
        final TimeZone tz = TimeZone.getDefault();
        final Calendar start = Calendar.getInstance(tz);
        start.clear();
        start.set(2000, Calendar.JANUARY, 1, 0, 0, 0);
        final Calendar end = Calendar.getInstance(tz);
        end.clear();
        end.set(2000, Calendar.JANUARY, 2, 1, 1, 1);
        final String result = DurationFormatUtils.formatPeriodISO(start.getTimeInMillis(), end.getTimeInMillis());
        assertEquals("P0Y0M1DT1H1M1.000S", result);
    }

    @Test
    public void testLexx_simpleTokens() {
        final DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("yyyy-MM-dd'T'HH:mm:ss");
        assertEquals(11, tokens.length);
        assertEquals("y", tokens[0].getValue());
        assertEquals(4, tokens[0].getCount());
        assertEquals("-", tokens[1].getValue().toString());
        assertEquals("M", tokens[2].getValue());
        assertEquals(2, tokens[2].getCount());
    }

    @Test
    public void testLexx_unmatchedQuoteThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.lexx("HH:mm:ss'bad");
            }
        });
    }

    @Test
    public void testLexx_nestedOptionalThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.lexx("[H[m]]");
            }
        });
    }

    @Test
    public void testLexx_unmatchedOpenOptionalThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.lexx("[Hm");
            }
        });
    }

    @Test
    public void testLexx_unmatchedCloseOptionalThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.lexx("H]m");
            }
        });
    }

    @Test
    public void testOptionalTokens_nonZeroPrinted() {
        // d'd'[H'h'm'm']s's' with 0 days, 1 hour, 0 min, 0 sec: the zero-valued "m" token and its
        // trailing literal are suppressed since they come after the first non-zero optional token
        final long millis = DateUtils.MILLIS_PER_HOUR;
        assertEquals("0d1h0s", DurationFormatUtils.formatDuration(millis, "d'd'[H'h'm'm']s's'", true));
    }

    @Test
    public void testOptionalTokens_zeroSuppressed() {
        // 0 days, 0 hours, 0 minutes, 0 seconds -> optional block suppressed entirely
        assertEquals("0d0s", DurationFormatUtils.formatDuration(0, "d'd'[H'h'm'm']s's'", true));
    }

    @Test
    public void testOptionalTokens_leadingOptionalBlock() {
        // [d'd'H'h'm'm']s's' with 1 day only -> "1d0s"
        assertEquals("1d0s", DurationFormatUtils.formatDuration(DateUtils.MILLIS_PER_DAY, "[d'd'H'h'm'm']s's'", true));
    }

    @Test
    public void testOptionalTokens_wholeBlockOptionalEmptyOnZero() {
        assertEquals("", DurationFormatUtils.formatDuration(0, "[d'd'H'h'm'm's's']", true));
    }

    @Test
    public void testIsoExtendedFormatPatternConstant() {
        assertEquals("'P'yyyy'Y'M'M'd'DT'H'H'm'M's.SSS'S'", DurationFormatUtils.ISO_EXTENDED_FORMAT_PATTERN);
    }

    @Test
    public void testDeprecatedPublicConstructor() {
        assertTrue(new DurationFormatUtils() instanceof DurationFormatUtils);
    }

    @Test
    public void testFormatDuration_largeValue() {
        // 100 days worth of millis, format using only days token
        final long days = 100;
        final long millis = days * DateUtils.MILLIS_PER_DAY;
        assertEquals("100", DurationFormatUtils.formatDuration(millis, "d"));
    }

    @Test
    public void testFormatDuration_maxLongDoesNotThrow() {
        final String result = DurationFormatUtils.formatDuration(Long.MAX_VALUE, "d");
        assertTrue(Long.parseLong(result) > 0);
    }
}
