/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link CSVFormat}.
 */
class CSVFormatAgentTest {

    private enum HeaderEnum {
        NAME, EMAIL
    }

    @Test
    void testDefaultFormatValues() {
        assertEquals(",", CSVFormat.DEFAULT.getDelimiterString());
        assertEquals(Character.valueOf('"'), CSVFormat.DEFAULT.getQuoteCharacter());
        assertEquals("\r\n", CSVFormat.DEFAULT.getRecordSeparator());
        assertTrue(CSVFormat.DEFAULT.getIgnoreEmptyLines());
        assertFalse(CSVFormat.DEFAULT.getTrim());
        assertNull(CSVFormat.DEFAULT.getCommentMarker());
        assertNull(CSVFormat.DEFAULT.getEscapeCharacter());
        assertNull(CSVFormat.DEFAULT.getHeader());
    }

    @Test
    void testNewFormatOnlySetsDelimiter() {
        final CSVFormat format = CSVFormat.newFormat(';');
        assertEquals(";", format.getDelimiterString());
        assertNull(format.getQuoteCharacter());
        assertNull(format.getEscapeCharacter());
        assertNull(format.getRecordSeparator());
        assertFalse(format.getIgnoreEmptyLines());
        assertFalse(format.getTrailingDelimiter());
    }

    @Test
    void testSetDelimiterRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDelimiter("a\nb").get();
            }
        });
    }

    @Test
    void testSetDelimiterRejectsEmptyString() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDelimiter("").get();
            }
        });
    }

    @Test
    void testSetCommentMarkerRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setCommentMarker('\n').get();
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setCommentMarker('\r').get();
            }
        });
    }

    @Test
    void testSetQuoteRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setQuote('\n').get();
            }
        });
    }

    @Test
    void testSetEscapeRejectsLineBreak() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setEscape('\r').get();
            }
        });
    }

    @Test
    void testValidateQuoteSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDelimiter(',').setQuote(',').get();
            }
        });
    }

    @Test
    void testValidateEscapeSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDelimiter(',').setEscape(',').get();
            }
        });
    }

    @Test
    void testValidateCommentSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDelimiter(',').setCommentMarker(',').get();
            }
        });
    }

    @Test
    void testValidateQuoteSameAsCommentThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setQuote('#').setCommentMarker('#').get();
            }
        });
    }

    @Test
    void testValidateEscapeSameAsCommentThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setEscape('#').setCommentMarker('#').get();
            }
        });
    }

    @Test
    void testValidateQuoteModeNoneWithoutEscapeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.newFormat(',').builder().setQuoteMode(QuoteMode.NONE).get();
            }
        });
    }

    @Test
    void testValidateQuoteModeNoneWithEscapeSucceeds() {
        final CSVFormat format = CSVFormat.newFormat(',').builder().setEscape('\\').setQuoteMode(QuoteMode.NONE).get();
        assertEquals(QuoteMode.NONE, format.getQuoteMode());
    }

    @Test
    void testValidateDisallowDuplicateHeadersThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setHeader("a", "a").setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).get();
            }
        });
    }

    @Test
    void testValidateAllowEmptyDuplicateHeadersPermitsBlanks() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("", "").setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).get();
        assertArrayEquals(new String[] {"", ""}, format.getHeader());
    }

    @Test
    void testValidateAllowEmptyDuplicateHeadersRejectsNonBlankDuplicates() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setHeader("a", "a").setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).get();
            }
        });
    }

    @Test
    void testValidateAllowAllPermitsDuplicateNonBlankHeaders() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "a").setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_ALL).get();
        assertArrayEquals(new String[] {"a", "a"}, format.getHeader());
    }

    @Test
    void testSetHeaderFromEnum() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(HeaderEnum.class).get();
        assertArrayEquals(new String[] {"NAME", "EMAIL"}, format.getHeader());
    }

    @Test
    void testSetHeaderNullDisablesHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader((Class<? extends Enum<?>>) null).get();
        assertNull(format.getHeader());
    }

    @Test
    void testGetHeaderReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "b").get();
        final String[] header = format.getHeader();
        header[0] = "mutated";
        assertArrayEquals(new String[] {"a", "b"}, format.getHeader());
    }

    @Test
    void testGetHeaderCommentsReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeaderComments("one", "two").get();
        final String[] comments = format.getHeaderComments();
        comments[0] = "mutated";
        assertArrayEquals(new String[] {"one", "two"}, format.getHeaderComments());
    }

    @Test
    void testBuilderIsIndependentFromSourceFormat() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder();
        builder.setDelimiter(';');
        assertEquals(",", CSVFormat.DEFAULT.getDelimiterString());
        assertEquals(";", builder.get().getDelimiterString());
    }

    @Test
    void testEqualsAndHashCode() {
        final CSVFormat copy = CSVFormat.DEFAULT.builder().get();
        assertEquals(CSVFormat.DEFAULT, copy);
        assertEquals(CSVFormat.DEFAULT.hashCode(), copy.hashCode());
        assertNotEquals(CSVFormat.DEFAULT, CSVFormat.RFC4180);
        assertNotEquals(CSVFormat.DEFAULT, null);
        assertNotEquals(CSVFormat.DEFAULT, "not a format");
        assertEquals(CSVFormat.DEFAULT, CSVFormat.DEFAULT);
    }

    @Test
    void testDeprecatedGetDelimiterReturnsFirstChar() {
        assertEquals(',', CSVFormat.DEFAULT.getDelimiter());
    }

    @Test
    void testDeprecatedWithDelimiterMatchesBuilder() {
        final CSVFormat viaWith = CSVFormat.DEFAULT.withDelimiter(';');
        final CSVFormat viaBuilder = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        assertEquals(viaBuilder, viaWith);
    }

    @Test
    void testValueOfReturnsPredefinedFormat() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.valueOf("Default"));
        assertEquals(CSVFormat.EXCEL, CSVFormat.valueOf("Excel"));
    }

    @Test
    void testValueOfUnknownNameThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                CSVFormat.valueOf("NotARealFormat");
            }
        });
    }

    @Test
    void testFormatProducesExpectedStringWithoutTrailingSeparator() {
        final CSVFormat format = CSVFormat.newFormat(';');
        assertEquals("a;b;c", format.format("a", "b", "c"));
    }

    @Test
    void testFormatWithDefaultTrimsTrailingRecordSeparator() {
        final String formatted = CSVFormat.DEFAULT.format("x", "y");
        assertEquals("x,y", formatted);
        assertFalse(formatted.endsWith("\r\n"));
    }

    @Test
    void testToStringContainsDelimiterAndSkipHeaderRecord() {
        final String str = CSVFormat.DEFAULT.toString();
        assertTrue(str.contains("Delimiter=<,>"));
        assertTrue(str.contains("SkipHeaderRecord:false"));
    }

    @Test
    void testToStringReflectsNonDefaultSettings() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').setEscape('\\').setNullString("NULL").setSkipHeaderRecord(true).get();
        final String str = format.toString();
        assertTrue(str.contains("CommentStart=<#>"));
        assertTrue(str.contains("Escape=<\\>"));
        assertTrue(str.contains("NullString=<NULL>"));
        assertTrue(str.contains("SkipHeaderRecord:true"));
    }

    @Test
    void testPrintNullWithQuoteModeAllQuotesTheNullString() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").setQuoteMode(QuoteMode.ALL).get();
        final StringBuilder sb = new StringBuilder();
        format.print(null, sb, true);
        assertEquals("\"NULL\"", sb.toString());
    }

    @Test
    void testPrintNullWithQuoteModeAllNonNullLeavesNullStringUnquoted() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("\\N").setQuoteMode(QuoteMode.ALL_NON_NULL).get();
        final StringBuilder sb = new StringBuilder();
        format.print(null, sb, true);
        assertEquals("\\N", sb.toString());
    }

    @Test
    void testPrintValueContainingDelimiterGetsQuoted() throws IOException {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.print("a,b", sb, true);
        assertEquals("\"a,b\"", sb.toString());
    }

    @Test
    void testPrintValueWithoutSpecialCharactersIsNotQuoted() throws IOException {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.print("plain", sb, true);
        assertEquals("plain", sb.toString());
    }

    @Test
    void testPrintAddsDelimiterWhenNotNewRecord() throws IOException {
        final StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.print("first", sb, true);
        CSVFormat.DEFAULT.print("second", sb, false);
        assertEquals("first,second", sb.toString());
    }

    @Test
    void testPrintRecordAppendsRecordSeparator() throws IOException {
        final StringWriter sw = new StringWriter();
        CSVFormat.DEFAULT.printRecord(sw, "a", "b");
        assertEquals("a,b\r\n", sw.toString());
    }

    @Test
    void testPrintlnWithTrailingDelimiter() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get();
        final StringWriter sw = new StringWriter();
        format.println(sw);
        assertEquals(",\r\n", sw.toString());
    }

    @Test
    void testPrintlnWithoutTrailingDelimiter() throws IOException {
        final StringWriter sw = new StringWriter();
        CSVFormat.DEFAULT.println(sw);
        assertEquals("\r\n", sw.toString());
    }

    @Test
    void testParseReturnsParserThatReadsFormattedRecord() throws IOException {
        final Reader reader = new StringReader("a,b,c\r\n");
        final CSVParser parser = CSVFormat.DEFAULT.parse(reader);
        try {
            final CSVRecord record = parser.iterator().next();
            assertEquals(3, record.size());
            assertEquals("a", record.get(0));
            assertEquals("b", record.get(1));
            assertEquals("c", record.get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    void testPrintReturnsWorkingPrinter() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = CSVFormat.DEFAULT.print(sw);
        try {
            printer.printRecord("x", "y");
        } finally {
            printer.close();
        }
        assertEquals("x,y\r\n", sw.toString());
    }

    @Test
    void testGetMaxRowsDefaultsToZeroMeaningNoLimit() {
        assertEquals(0L, CSVFormat.DEFAULT.getMaxRows());
    }

    @Test
    void testSetMaxRows() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(5L).get();
        assertEquals(5L, format.getMaxRows());
    }

    @Test
    void testIsQuoteCharacterSetAndIsEscapeCharacterSet() {
        assertTrue(CSVFormat.DEFAULT.isQuoteCharacterSet());
        assertFalse(CSVFormat.DEFAULT.isEscapeCharacterSet());
        final CSVFormat escaped = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        assertTrue(escaped.isEscapeCharacterSet());
    }

    @Test
    void testIsCommentMarkerSetAndNullStringSet() {
        assertFalse(CSVFormat.DEFAULT.isCommentMarkerSet());
        assertFalse(CSVFormat.DEFAULT.isNullStringSet());
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').setNullString("N/A").get();
        assertTrue(format.isCommentMarkerSet());
        assertTrue(format.isNullStringSet());
    }

    @Test
    void testWithHeaderStringArray() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("one", "two");
        assertArrayEquals(new String[] {"one", "two"}, format.getHeader());
    }

    @Test
    void testPredefinedExcelDiffersFromDefault() {
        assertTrue(CSVFormat.EXCEL.getAllowMissingColumnNames());
        assertFalse(CSVFormat.EXCEL.getIgnoreEmptyLines());
        assertTrue(CSVFormat.EXCEL.getTrailingData());
        assertTrue(CSVFormat.EXCEL.getLenientEof());
    }

    @Test
    void testMySqlFormatUsesTabAndBackslashEscape() {
        assertEquals("\t", CSVFormat.MYSQL.getDelimiterString());
        assertEquals(Character.valueOf('\\'), CSVFormat.MYSQL.getEscapeCharacter());
        assertNull(CSVFormat.MYSQL.getQuoteCharacter());
        assertEquals("\\N", CSVFormat.MYSQL.getNullString());
    }

    @Test
    void testDelimiterCharArrayMatchesDelimiterString() {
        final CSVFormat format = CSVFormat.newFormat('|');
        assertArrayEquals(new char[] {'|'}, format.getDelimiterCharArray());
    }

    @Test
    void testCopyProducesEqualButDistinctInstance() {
        final CSVFormat original = CSVFormat.DEFAULT.builder().setHeader("a").get();
        final CSVFormat copy = CSVFormat.copy(original);
        assertEquals(original, copy);
        assertNotSame(original, copy);
    }

    @Test
    void testCopyOfNullReturnsNull() {
        assertNull(CSVFormat.copy(null));
    }
}
