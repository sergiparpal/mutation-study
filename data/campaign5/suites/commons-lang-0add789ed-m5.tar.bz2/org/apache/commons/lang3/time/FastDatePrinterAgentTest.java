/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.FieldPosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link FastDatePrinter}.
 */
class FastDatePrinterAgentTest {

    private static final TimeZone GMT = TimeZone.getTimeZone("GMT");
    private static final TimeZone PLUS_0530 = TimeZone.getTimeZone("GMT+05:30");
    private static final Locale LOCALE = Locale.US;

    private static Calendar newCalendar(final TimeZone tz, final int year, final int month, final int day,
            final int hour, final int minute, final int second, final int millis) {
        final Calendar cal = Calendar.getInstance(tz, LOCALE);
        cal.clear();
        cal.set(year, month, day, hour, minute, second);
        cal.set(Calendar.MILLISECOND, millis);
        // force the absolute instant to be computed now, so that later changing this
        // Calendar's time zone (e.g. via FastDatePrinter#format) shifts the wall-clock
        // fields instead of silently keeping them (Calendar's lazy-field-computation quirk)
        cal.getTimeInMillis();
        return cal;
    }

    @Test
    void testFormatDateBasicPattern() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd HH:mm:ss.SSS", GMT, LOCALE);
        final Calendar cal = newCalendar(GMT, 2023, Calendar.MARCH, 15, 13, 7, 9, 250);
        assertEquals("2023-03-15 13:07:09.250", printer.format(cal.getTime()));
    }

    @Test
    void testFormatCalendarUsesPrinterTimeZoneNotCalendarZone() {
        // printer configured with GMT+05:30, calendar created in plain GMT
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd HH:mm:ss", PLUS_0530, LOCALE);
        final Calendar calInGmt = newCalendar(GMT, 2023, Calendar.JANUARY, 1, 0, 0, 0, 0);
        // same absolute instant, formatted result must reflect the printer's own time zone (+05:30)
        assertEquals("2023-01-01 05:30:00", printer.format(calInGmt));
    }

    @Test
    void testFormatLongMillis() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd'T'HH:mm:ss'Z'", GMT, LOCALE);
        assertEquals("1970-01-01T00:00:00Z", printer.format(0L));
    }

    @Test
    void testFormatIntoAppendable() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy", GMT, LOCALE);
        final Calendar cal = newCalendar(GMT, 2024, Calendar.JUNE, 1, 0, 0, 0, 0);
        final StringBuilder sb = new StringBuilder("prefix-");
        final StringBuilder result = printer.format(cal, sb);
        assertSame(sb, result);
        assertEquals("prefix-2024", result.toString());
    }

    @Test
    void testDeprecatedStringBufferOverloadsMatchAppendableOverloads() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd HH:mm:ss", PLUS_0530, LOCALE);
        final Calendar cal = newCalendar(GMT, 2023, Calendar.JANUARY, 1, 0, 0, 0, 0);

        final String viaCalendarAppendable = printer.format(cal, new StringBuilder()).toString();

        final StringBuffer buf1 = new StringBuffer();
        final StringBuffer returned1 = printer.format(cal, buf1);
        assertSame(buf1, returned1);
        assertEquals(viaCalendarAppendable, buf1.toString());

        final Date date = cal.getTime();
        final String viaDateAppendable = printer.format(date, new StringBuilder()).toString();
        final StringBuffer buf2 = new StringBuffer();
        final StringBuffer returned2 = printer.format(date, buf2);
        assertSame(buf2, returned2);
        assertEquals(viaDateAppendable, buf2.toString());

        final long millis = date.getTime();
        final String viaLongAppendable = printer.format(millis, new StringBuilder()).toString();
        final StringBuffer buf3 = new StringBuffer();
        final StringBuffer returned3 = printer.format(millis, buf3);
        assertSame(buf3, returned3);
        assertEquals(viaLongAppendable, buf3.toString());
    }

    @Test
    void testGetters() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", PLUS_0530, LOCALE);
        assertEquals("yyyy-MM-dd", printer.getPattern());
        assertEquals(PLUS_0530, printer.getTimeZone());
        assertEquals(LOCALE, printer.getLocale());
    }

    @Test
    void testMaxLengthEstimateIsNeverExceeded() {
        final FastDatePrinter printer = new FastDatePrinter("yyyyMMdd'T'HHmmss.SSS", GMT, LOCALE);
        final Calendar cal = newCalendar(GMT, 9999, Calendar.DECEMBER, 31, 23, 59, 59, 999);
        final String formatted = printer.format(cal.getTime());
        assertTrue(formatted.length() <= printer.getMaxLengthEstimate(),
                "formatted length " + formatted.length() + " exceeded estimate " + printer.getMaxLengthEstimate());
    }

    @Test
    void testEqualsAndHashCodeContract() {
        final FastDatePrinter printer1 = new FastDatePrinter("yyyy-MM-dd", GMT, LOCALE);
        final FastDatePrinter printer2 = new FastDatePrinter("yyyy-MM-dd", GMT, LOCALE);
        final FastDatePrinter differentPattern = new FastDatePrinter("yyyy/MM/dd", GMT, LOCALE);
        final FastDatePrinter differentZone = new FastDatePrinter("yyyy-MM-dd", PLUS_0530, LOCALE);
        final FastDatePrinter differentLocale = new FastDatePrinter("yyyy-MM-dd", GMT, Locale.GERMANY);

        assertEquals(printer1, printer2);
        assertEquals(printer1.hashCode(), printer2.hashCode());
        assertNotEquals(printer1, differentPattern);
        assertNotEquals(printer1, differentZone);
        assertNotEquals(printer1, differentLocale);
        assertFalse(printer1.equals(null));
        assertFalse(printer1.equals("yyyy-MM-dd"));
        assertTrue(printer1.equals(printer1));
    }

    @Test
    void testToStringContainsPatternLocaleAndTimeZoneId() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", PLUS_0530, LOCALE);
        final String str = printer.toString();
        assertTrue(str.contains("yyyy-MM-dd"));
        assertTrue(str.contains(PLUS_0530.getID()));
        assertTrue(str.contains(LOCALE.toString()));
    }

    @Test
    void testPackagePrivateFormatObjectVariants() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", GMT, LOCALE);
        final Calendar cal = newCalendar(GMT, 2024, Calendar.MARCH, 15, 0, 0, 0, 0);
        final Date date = cal.getTime();
        final Long millis = date.getTime();

        assertEquals(printer.format(date), printer.format((Object) date));
        assertEquals(printer.format(cal), printer.format((Object) cal));
        assertEquals(printer.format(millis.longValue()), printer.format((Object) millis));

        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                printer.format((Object) "not-a-date");
            }
        });
        assertTrue(ex.getMessage().contains("Unknown class"));
    }

    @Test
    void testDeprecatedFormatObjectWithFieldPosition() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", GMT, LOCALE);
        final Calendar cal = newCalendar(GMT, 2024, Calendar.MARCH, 15, 0, 0, 0, 0);
        final Date date = cal.getTime();
        final Long millis = date.getTime();
        final FieldPosition pos = new FieldPosition(0);

        final StringBuffer dateBuf = new StringBuffer();
        assertSame(dateBuf, printer.format((Object) date, dateBuf, pos));
        assertEquals("2024-03-15", dateBuf.toString());

        final StringBuffer calBuf = new StringBuffer();
        assertSame(calBuf, printer.format((Object) cal, calBuf, pos));
        assertEquals("2024-03-15", calBuf.toString());

        final StringBuffer longBuf = new StringBuffer();
        assertSame(longBuf, printer.format((Object) millis, longBuf, pos));
        assertEquals("2024-03-15", longBuf.toString());

        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                printer.format((Object) "nope", new StringBuffer(), pos);
            }
        });
    }

    @Test
    void testNullPatternThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDatePrinter(null, GMT, LOCALE);
            }
        });
    }

    @Test
    void testNullLocaleFallsBackToDefaultLocale() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy", GMT, null);
        assertEquals(Locale.getDefault(), printer.getLocale());
    }

    @Test
    void testNullTimeZoneThrowsOnFormat() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy", null, LOCALE);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                printer.format(new Date());
            }
        });
    }

    @Test
    void testInvalidPatternLetterThrowsIllegalArgumentException() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDatePrinter("q", GMT, LOCALE);
            }
        });
        assertTrue(ex.getMessage().contains("Illegal pattern component"));
    }

    @Test
    void testInvalidIso8601TokenLengthThrowsIllegalArgumentException() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDatePrinter("XXXX", GMT, LOCALE);
            }
        });
        assertTrue(ex.getMessage().contains("invalid number of X"));
    }

    @Test
    void testLiteralTextAndEscapedQuote() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-'o''clock'-MM", GMT, LOCALE);
        final Calendar cal = newCalendar(GMT, 2024, Calendar.MARCH, 1, 0, 0, 0, 0);
        assertEquals("2024-o'clock-03", printer.format(cal));
    }

    @Test
    void testTwoDigitYearVersusFourDigitYear() {
        final FastDatePrinter twoDigit = new FastDatePrinter("yy", GMT, LOCALE);
        final FastDatePrinter fourDigit = new FastDatePrinter("yyyy", GMT, LOCALE);

        assertEquals("05", twoDigit.format(newCalendar(GMT, 2005, Calendar.JANUARY, 1, 0, 0, 0, 0)));
        assertEquals("98", twoDigit.format(newCalendar(GMT, 1998, Calendar.JANUARY, 1, 0, 0, 0, 0)));
        assertEquals("0007", fourDigit.format(newCalendar(GMT, 7, Calendar.JANUARY, 1, 0, 0, 0, 0)));
    }

    @Test
    void testTwelveHourFieldMapsMidnightToTwelve() {
        final FastDatePrinter printer = new FastDatePrinter("hh", GMT, LOCALE);
        assertEquals("12", printer.format(newCalendar(GMT, 2024, Calendar.JANUARY, 1, 0, 0, 0, 0)));
        assertEquals("01", printer.format(newCalendar(GMT, 2024, Calendar.JANUARY, 1, 13, 0, 0, 0)));
        assertEquals("12", printer.format(newCalendar(GMT, 2024, Calendar.JANUARY, 1, 12, 0, 0, 0)));
    }

    @Test
    void testTwentyFourHourFieldMapsMidnightToTwentyFour() {
        final FastDatePrinter printer = new FastDatePrinter("kk", GMT, LOCALE);
        assertEquals("24", printer.format(newCalendar(GMT, 2024, Calendar.JANUARY, 1, 0, 0, 0, 0)));
        assertEquals("05", printer.format(newCalendar(GMT, 2024, Calendar.JANUARY, 1, 5, 0, 0, 0)));
    }

    @Test
    void testAmPmAndEraFields() {
        final FastDatePrinter ampm = new FastDatePrinter("a", GMT, LOCALE);
        assertEquals("AM", ampm.format(newCalendar(GMT, 2024, Calendar.JANUARY, 1, 5, 0, 0, 0)));
        assertEquals("PM", ampm.format(newCalendar(GMT, 2024, Calendar.JANUARY, 1, 17, 0, 0, 0)));

        final FastDatePrinter era = new FastDatePrinter("G", GMT, LOCALE);
        final Calendar bcCal = newCalendar(GMT, 44, Calendar.JANUARY, 1, 0, 0, 0, 0);
        bcCal.set(Calendar.ERA, GregorianCalendar.BC);
        assertEquals("BC", era.format(bcCal));
        assertEquals("AD", era.format(newCalendar(GMT, 2024, Calendar.JANUARY, 1, 0, 0, 0, 0)));
    }

    @Test
    void testNumericDayOfWeekField() {
        final FastDatePrinter printer = new FastDatePrinter("u", GMT, LOCALE);
        // 2024-01-01 is a Monday
        assertEquals("1", printer.format(newCalendar(GMT, 2024, Calendar.JANUARY, 1, 0, 0, 0, 0)));
        // 2024-01-07 is a Sunday, mapped to 7 (not 1)
        assertEquals("7", printer.format(newCalendar(GMT, 2024, Calendar.JANUARY, 7, 0, 0, 0, 0)));
    }

    @Test
    void testZeroOffsetTimeZoneNumberPatterns() {
        final Calendar cal = newCalendar(GMT, 2024, Calendar.JANUARY, 1, 0, 0, 0, 0);

        assertEquals("+0000", new FastDatePrinter("Z", GMT, LOCALE).format(cal));
        // lang3-specific 'ZZ' extension: ISO8601 hours:minutes, zero offset renders as literal "Z"
        assertEquals("Z", new FastDatePrinter("ZZ", GMT, LOCALE).format(cal));
        assertEquals("+00:00", new FastDatePrinter("ZZZ", GMT, LOCALE).format(cal));
    }

    @Test
    void testNonZeroOffsetTimeZoneNumberPatterns() {
        final Calendar cal = newCalendar(PLUS_0530, 2024, Calendar.JANUARY, 1, 0, 0, 0, 0);

        assertEquals("+0530", new FastDatePrinter("Z", PLUS_0530, LOCALE).format(cal));
        assertEquals("+05:30", new FastDatePrinter("ZZ", PLUS_0530, LOCALE).format(cal));
        assertEquals("+05:30", new FastDatePrinter("ZZZ", PLUS_0530, LOCALE).format(cal));
    }

    @Test
    void testIso8601XPatterns() {
        final Calendar zeroOffset = newCalendar(GMT, 2024, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals("Z", new FastDatePrinter("X", GMT, LOCALE).format(zeroOffset));
        assertEquals("Z", new FastDatePrinter("XX", GMT, LOCALE).format(zeroOffset));
        assertEquals("Z", new FastDatePrinter("XXX", GMT, LOCALE).format(zeroOffset));

        final Calendar plusOffset = newCalendar(PLUS_0530, 2024, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals("+05", new FastDatePrinter("X", PLUS_0530, LOCALE).format(plusOffset));
        assertEquals("+0530", new FastDatePrinter("XX", PLUS_0530, LOCALE).format(plusOffset));
        assertEquals("+05:30", new FastDatePrinter("XXX", PLUS_0530, LOCALE).format(plusOffset));
    }

    @Test
    void testWeekYearNegativeProleptic() {
        final FastDatePrinter printer = new FastDatePrinter("YYYY", GMT, LOCALE);
        final Calendar cal = Calendar.getInstance(GMT, LOCALE);
        cal.clear();
        cal.set(Calendar.ERA, GregorianCalendar.BC);
        cal.set(Calendar.YEAR, 100);
        cal.set(Calendar.MONTH, Calendar.JUNE);
        cal.set(Calendar.DAY_OF_MONTH, 15);

        assertTrue(cal.isWeekDateSupported());
        final int weekYear = cal.getWeekYear();
        assertTrue(weekYear < 0, "expected a negative proleptic week year, got " + weekYear);

        final String expected = "-" + String.format("%04d", -weekYear);
        assertEquals(expected, printer.format(cal));
    }

    @Test
    void testAgainstSimpleDateFormatForManyPatterns() {
        final String[] patterns = {
            "yyyy", "yy", "MMMM", "MMM", "MM", "M", "dd", "d",
            "EEEE", "EEE", "HH", "H", "hh", "h", "mm", "m", "ss", "s",
            "SSS", "S", "a", "G", "D", "F", "w", "W", "kk", "k", "KK", "K",
        };

        final Calendar[] calendars = {
            newCalendar(GMT, 2024, Calendar.JANUARY, 1, 0, 0, 0, 0),
            newCalendar(GMT, 2023, Calendar.MARCH, 15, 13, 7, 9, 250),
            newCalendar(GMT, 2024, Calendar.DECEMBER, 31, 23, 59, 59, 999),
            newCalendar(GMT, 7, Calendar.JUNE, 10, 5, 30, 20, 125),
        };

        for (final Calendar cal : calendars) {
            final Date date = cal.getTime();
            for (final String pattern : patterns) {
                final FastDatePrinter printer = new FastDatePrinter(pattern, GMT, LOCALE);
                final SimpleDateFormat sdf = new SimpleDateFormat(pattern, LOCALE);
                sdf.setTimeZone(GMT);
                assertEquals(sdf.format(date), printer.format(date),
                        "mismatch for pattern [" + pattern + "] and date [" + date + "]");
            }
        }
    }
}
