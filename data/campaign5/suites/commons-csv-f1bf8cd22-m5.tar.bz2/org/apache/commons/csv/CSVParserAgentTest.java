/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.StringReader;
import java.io.UncheckedIOException;
import java.io.Writer;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

/**
 * Self-contained tests for {@link CSVParser}.
 */
public class CSVParserAgentTest {

    @TempDir
    public Path tempDir;

    private CSVParser toClose;

    @AfterEach
    public void closeLeftovers() throws IOException {
        if (toClose != null) {
            toClose.close();
            toClose = null;
        }
    }

    private CSVParser parseString(final String data, final CSVFormat format) throws IOException {
        toClose = CSVParser.parse(data, format);
        return toClose;
    }

    // --- parse(String, CSVFormat) ---

    @Test
    public void testParseStringSimple() throws IOException {
        final CSVParser parser = parseString("a,b,c\nd,e,f\n", CSVFormat.DEFAULT);
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        assertEquals("a", records.get(0).get(0));
        assertEquals("b", records.get(0).get(1));
        assertEquals("c", records.get(0).get(2));
        assertEquals("f", records.get(1).get(2));
    }

    @Test
    public void testParseStringNullThrowsNPE() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse((String) null, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    public void testEmptyInputYieldsNoRecords() throws IOException {
        final CSVParser parser = parseString("", CSVFormat.DEFAULT);
        assertTrue(parser.getRecords().isEmpty());
    }

    // --- parse(File, Charset, CSVFormat) ---

    @Test
    public void testParseFileNullThrowsNPE() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse((File) null, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    public void testParseFile() throws IOException {
        final File file = tempDir.resolve("test.csv").toFile();
        final FileOutputStream fos = new FileOutputStream(file);
        try {
            final Writer writer = new OutputStreamWriter(fos, StandardCharsets.UTF_8);
            writer.write("1,2\n3,4\n");
            writer.flush();
        } finally {
            fos.close();
        }
        toClose = CSVParser.parse(file, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
        final List<CSVRecord> records = toClose.getRecords();
        assertEquals(2, records.size());
        assertEquals("1", records.get(0).get(0));
        assertEquals("4", records.get(1).get(1));
    }

    // --- parse(Path, Charset, CSVFormat) ---

    @Test
    public void testParsePathNullThrowsNPE() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse((Path) null, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
            }
        });
    }

    // --- parse(InputStream, Charset, CSVFormat) ---

    @Test
    public void testParseInputStream() throws IOException {
        final InputStream in = new java.io.ByteArrayInputStream("x,y\n".getBytes(StandardCharsets.UTF_8));
        toClose = CSVParser.parse(in, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
        final List<CSVRecord> records = toClose.getRecords();
        assertEquals(1, records.size());
        assertEquals("x", records.get(0).get(0));
    }

    // --- parse(URL, Charset, CSVFormat) ---

    @Test
    public void testParseURLNullThrowsNPE() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse((URL) null, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    public void testParseURL() throws IOException {
        final File file = tempDir.resolve("url.csv").toFile();
        final FileOutputStream fos = new FileOutputStream(file);
        try {
            fos.write("7,8\n".getBytes(StandardCharsets.UTF_8));
        } finally {
            fos.close();
        }
        toClose = CSVParser.parse(file.toURI().toURL(), StandardCharsets.UTF_8, CSVFormat.DEFAULT);
        final List<CSVRecord> records = toClose.getRecords();
        assertEquals(1, records.size());
        assertEquals("7", records.get(0).get(0));
        assertEquals("8", records.get(0).get(1));
    }

    // --- parse(Reader, CSVFormat) with null format ---

    @Test
    public void testParseReaderNullFormatDefaultsToDefault() throws IOException {
        final Reader reader = new StringReader("a,b\n");
        toClose = CSVParser.parse(reader, null);
        final List<CSVRecord> records = toClose.getRecords();
        assertEquals(1, records.size());
        assertEquals("a", records.get(0).get(0));
    }

    // --- deprecated constructors ---

    @Test
    @SuppressWarnings("deprecation")
    public void testDeprecatedTwoArgConstructor() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("1,2\n"), CSVFormat.DEFAULT);
        toClose = parser;
        assertEquals(1, parser.getRecords().size());
    }

    @Test
    @SuppressWarnings("deprecation")
    public void testDeprecatedFourArgConstructorOffsets() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("1,2\n3,4\n"), CSVFormat.DEFAULT, 100L, 5L);
        toClose = parser;
        final CSVRecord record = parser.nextRecord();
        assertEquals(5, record.getRecordNumber());
        assertEquals(100, record.getCharacterPosition());
        assertEquals(5, parser.getRecordNumber());
    }

    // --- builder() ---

    @Test
    public void testBuilderWithOffsetsAndRecordNumber() throws IOException {
        final CSVParser parser = CSVParser.builder()
                .setReader(new StringReader("a,b\n"))
                .setFormat(CSVFormat.DEFAULT)
                .setCharacterOffset(10L)
                .setRecordNumber(3L)
                .setTrackBytes(false)
                .get();
        toClose = parser;
        assertEquals(2, parser.getRecordNumber());
        final CSVRecord record = parser.nextRecord();
        assertEquals(3, record.getRecordNumber());
        assertEquals(10, record.getCharacterPosition());
        assertEquals(3, parser.getRecordNumber());
    }

    @Test
    public void testBuilderDefaultFormatIsDefault() throws IOException {
        final CSVParser parser = CSVParser.builder().setReader(new StringReader("a,b\n")).get();
        toClose = parser;
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(1, records.size());
        assertEquals("a", records.get(0).get(0));
    }

    // --- iterator / stream / records ---

    @Test
    public void testIteratorHasNextNext() throws IOException {
        final CSVParser parser = parseString("1\n2\n", CSVFormat.DEFAULT);
        final Iterator<CSVRecord> it = parser.iterator();
        assertTrue(it.hasNext());
        assertTrue(it.hasNext());
        assertEquals("1", it.next().get(0));
        assertTrue(it.hasNext());
        assertEquals("2", it.next().get(0));
        assertFalse(it.hasNext());
        assertThrows(NoSuchElementException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                it.next();
            }
        });
    }

    @Test
    public void testIteratorNextWithoutHasNext() throws IOException {
        final CSVParser parser = parseString("1\n", CSVFormat.DEFAULT);
        final Iterator<CSVRecord> it = parser.iterator();
        assertEquals("1", it.next().get(0));
        assertThrows(NoSuchElementException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                it.next();
            }
        });
    }

    @Test
    public void testIteratorRemoveUnsupported() throws IOException {
        final CSVParser parser = parseString("1\n", CSVFormat.DEFAULT);
        final Iterator<CSVRecord> it = parser.iterator();
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                it.remove();
            }
        });
    }

    @Test
    public void testIteratorSameInstanceEveryCall() throws IOException {
        final CSVParser parser = parseString("1\n", CSVFormat.DEFAULT);
        assertSame(parser.iterator(), parser.iterator());
    }

    @Test
    public void testStreamMatchesGetRecords() throws IOException {
        final CSVParser parser = parseString("1\n2\n3\n", CSVFormat.DEFAULT);
        final long count = parser.stream().count();
        assertEquals(3, count);
    }

    @Test
    public void testCloseStopsIteration() throws IOException {
        final CSVParser parser = parseString("1\n2\n", CSVFormat.DEFAULT);
        parser.close();
        assertTrue(parser.isClosed());
        final Iterator<CSVRecord> it = parser.iterator();
        assertFalse(it.hasNext());
        assertThrows(NoSuchElementException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                it.next();
            }
        });
        toClose = null;
    }

    @Test
    public void testIsClosedInitiallyFalse() throws IOException {
        final CSVParser parser = parseString("1\n", CSVFormat.DEFAULT);
        assertFalse(parser.isClosed());
    }

    // --- header map / names ---

    @Test
    public void testHeaderMapAndNames() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().setSkipHeaderRecord(true).get();
        final CSVParser parser = parseString("name,age\nbob,30\n", format);
        final Map<String, Integer> headerMap = parser.getHeaderMap();
        assertEquals(Integer.valueOf(0), headerMap.get("name"));
        assertEquals(Integer.valueOf(1), headerMap.get("age"));
        assertEquals(2, parser.getHeaderNames().size());
        assertEquals("name", parser.getHeaderNames().get(0));
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(1, records.size());
        assertEquals("bob", records.get(0).get("name"));
        assertEquals("30", records.get(0).get("age"));
    }

    @Test
    public void testHeaderMapIsIndependentCopy() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "b").get();
        final CSVParser parser = parseString("1,2\n", format);
        final Map<String, Integer> first = parser.getHeaderMap();
        first.put("c", 99);
        final Map<String, Integer> second = parser.getHeaderMap();
        assertFalse(second.containsKey("c"));
    }

    @Test
    public void testGetHeaderMapNullWhenNoHeaderDefined() throws IOException {
        final CSVParser parser = parseString("1,2\n", CSVFormat.DEFAULT);
        assertNull(parser.getHeaderMap());
        assertTrue(parser.getHeaderNames().isEmpty());
    }

    @Test
    public void testHeaderNamesUnmodifiable() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "b").get();
        final CSVParser parser = parseString("1,2\n", format);
        final List<String> names = parser.getHeaderNames();
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                names.add("c");
            }
        });
    }

    @Test
    public void testDuplicateHeaderNotAllowedThrowsIAE() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVFormat.DEFAULT.builder()
                        .setHeader("a", "a")
                        .setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW)
                        .get();
            }
        });
    }

    @Test
    public void testMissingColumnNameDisallowedThrowsIAE() {
        final CSVFormat format = CSVFormat.DEFAULT.builder()
                .setHeader("a", "")
                .setAllowMissingColumnNames(false)
                .get();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse("1,2\n", format);
            }
        });
    }

    @Test
    public void testMissingColumnNameAllowed() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder()
                .setHeader("a", "")
                .setAllowMissingColumnNames(true)
                .get();
        final CSVParser parser = parseString("1,2\n", format);
        assertEquals(2, parser.getHeaderNames().size());
        assertEquals("a", parser.getHeaderNames().get(0));
        assertEquals("", parser.getHeaderNames().get(1));
    }

    // --- record numbers / line numbers / positions ---

    @Test
    public void testGetRecordNumberIncrements() throws IOException {
        final CSVParser parser = parseString("a\nb\nc\n", CSVFormat.DEFAULT);
        assertEquals(0, parser.getRecordNumber());
        parser.nextRecord();
        assertEquals(1, parser.getRecordNumber());
        parser.nextRecord();
        assertEquals(2, parser.getRecordNumber());
        parser.nextRecord();
        assertEquals(3, parser.getRecordNumber());
        assertNull(parser.nextRecord());
        assertEquals(3, parser.getRecordNumber());
    }

    @Test
    public void testGetCurrentLineNumber() throws IOException {
        final CSVParser parser = parseString("a\nb\nc\n", CSVFormat.DEFAULT);
        assertEquals(0, parser.getCurrentLineNumber());
        parser.nextRecord();
        assertEquals(1, parser.getCurrentLineNumber());
        parser.nextRecord();
        assertEquals(2, parser.getCurrentLineNumber());
    }

    @Test
    public void testGetFirstEndOfLine() throws IOException {
        final CSVParser parser = parseString("a,b\r\nc,d\n", CSVFormat.DEFAULT);
        parser.getRecords();
        assertEquals("\r\n", parser.getFirstEndOfLine());
    }

    // --- comments ---

    @Test
    public void testHeaderAndTrailerComments() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final CSVParser parser = parseString("# header comment\na,b\n# trailer comment", format);
        assertFalse(parser.hasHeaderComment());
        assertFalse(parser.hasTrailerComment());
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(1, records.size());
        assertEquals("header comment", records.get(0).getComment());
        assertTrue(parser.hasTrailerComment());
        assertEquals("trailer comment", parser.getTrailerComment());
    }

    @Test
    public void testNoCommentsByDefault() throws IOException {
        final CSVParser parser = parseString("a,b\n", CSVFormat.DEFAULT);
        parser.getRecords();
        assertFalse(parser.hasHeaderComment());
        assertNull(parser.getHeaderComment());
        assertFalse(parser.hasTrailerComment());
        assertNull(parser.getTrailerComment());
    }

    // --- invalid input / CSVException ---

    @Test
    public void testUnterminatedQuoteThrowsCSVExceptionEagerlyWhenHeaderIsRead() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().get();
        final IOException thrown = assertThrows(CSVException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse("\"unterminated", format);
            }
        });
        assertTrue(thrown.getMessage().contains("EOF"));
    }

    @Test
    public void testUnterminatedQuoteThrowsUncheckedIOExceptionLazily() throws IOException {
        final CSVParser parser = parseString("\"unterminated", CSVFormat.DEFAULT);
        final UncheckedIOException thrown = assertThrows(UncheckedIOException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                parser.iterator().hasNext();
            }
        });
        assertTrue(thrown.getCause() instanceof CSVException);
    }

    @Test
    public void testNextRecordThrowsCSVExceptionDirectly() throws IOException {
        final CSVParser parser = parseString("\"unterminated", CSVFormat.DEFAULT);
        assertThrows(CSVException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                parser.nextRecord();
            }
        });
    }

    // --- null / empty string handling ---

    @Test
    public void testNullStringConvertsMatchingTokenToNull() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        final CSVParser parser = parseString("a,NULL,c\n", format);
        final CSVRecord record = parser.getRecords().get(0);
        assertEquals("a", record.get(0));
        assertNull(record.get(1));
        assertEquals("c", record.get(2));
    }

    @Test
    public void testTrailingDelimiterDropsLastEmptyField() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get();
        final CSVParser parser = parseString("a,b,\n", format);
        final CSVRecord record = parser.getRecords().get(0);
        assertEquals(2, record.size());
        assertEquals("a", record.get(0));
        assertEquals("b", record.get(1));
    }

    // --- max rows ---

    @Test
    public void testMaxRowsLimitsIteration() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(2).get();
        final CSVParser parser = parseString("1\n2\n3\n4\n", format);
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        assertEquals("1", records.get(0).get(0));
        assertEquals("2", records.get(1).get(0));
    }

    // --- getRecords exhaustion ---

    @Test
    public void testGetRecordsReturnsEmptyAfterManualConsumption() throws IOException {
        final CSVParser parser = parseString("1\n2\n", CSVFormat.DEFAULT);
        CSVRecord r;
        while ((r = parser.nextRecord()) != null) {
            // drain
        }
        assertTrue(parser.getRecords().isEmpty());
    }

    @Test
    public void testIgnoreHeaderCaseMapsHeaderCaseInsensitively() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().setIgnoreHeaderCase(true).setSkipHeaderRecord(true).get();
        final CSVParser parser = parseString("Name,Age\nbob,30\n", format);
        final Map<String, Integer> headerMap = parser.getHeaderMap();
        assertTrue(headerMap.containsKey("name"));
        assertTrue(headerMap.containsKey("NAME"));
        final CSVRecord record = parser.getRecords().get(0);
        assertEquals("bob", record.get("name"));
    }

    @Test
    public void testGetHeaderMapRawSameKeysAsPublicCopy() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("x", "y").get();
        final CSVParser parser = parseString("1,2\n", format);
        assertEquals(parser.getHeaderMap(), parser.getHeaderMapRaw());
    }
}
