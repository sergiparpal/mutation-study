/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Supplier;

import org.apache.commons.lang3.exception.CloneFailedException;
import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link ObjectUtils}.
 */
class ObjectUtilsAgentTest {

    static class CloneableValue implements Cloneable {
        final int value;

        CloneableValue(final int value) {
            this.value = value;
        }

        @Override
        public CloneableValue clone() {
            return new CloneableValue(value);
        }
    }

    static class ThrowingCloneable implements Cloneable {
        @Override
        public Object clone() {
            throw new IllegalStateException("boom");
        }
    }

    static class NotCloneable {
        // intentionally does not implement Cloneable
    }

    @Test
    void testAllNotNull() {
        assertTrue(ObjectUtils.allNotNull());
        assertTrue(ObjectUtils.allNotNull("a"));
        assertTrue(ObjectUtils.allNotNull("a", "b"));
        assertFalse(ObjectUtils.allNotNull((Object) null));
        assertFalse(ObjectUtils.allNotNull("a", null));
        assertFalse(ObjectUtils.allNotNull((Object[]) null));
    }

    @Test
    void testAllNull() {
        assertTrue(ObjectUtils.allNull());
        assertTrue(ObjectUtils.allNull((Object) null));
        assertTrue(ObjectUtils.allNull(null, null));
        assertFalse(ObjectUtils.allNull("a"));
        assertFalse(ObjectUtils.allNull(null, "a"));
        assertTrue(ObjectUtils.allNull((Object[]) null));
    }

    @Test
    void testAnyNotNull() {
        assertFalse(ObjectUtils.anyNotNull());
        assertFalse(ObjectUtils.anyNotNull((Object) null));
        assertFalse(ObjectUtils.anyNotNull(null, null));
        assertTrue(ObjectUtils.anyNotNull("a"));
        assertTrue(ObjectUtils.anyNotNull(null, "a"));
    }

    @Test
    void testAnyNull() {
        assertFalse(ObjectUtils.anyNull());
        assertTrue(ObjectUtils.anyNull((Object) null));
        assertTrue(ObjectUtils.anyNull("a", null));
        assertFalse(ObjectUtils.anyNull("a", "b"));
    }

    @Test
    void testCloneNull() {
        assertNull(ObjectUtils.clone(null));
    }

    @Test
    void testCloneNotCloneable() {
        assertNull(ObjectUtils.clone(new NotCloneable()));
        assertNull(ObjectUtils.clone("abc"));
    }

    @Test
    void testCloneCloneableObject() {
        final CloneableValue original = new CloneableValue(42);
        final CloneableValue cloned = ObjectUtils.clone(original);
        assertNotNull(cloned);
        assertNotSame(original, cloned);
        assertEquals(42, cloned.value);
    }

    @Test
    void testClonePrimitiveArray() {
        final int[] original = {1, 2, 3};
        final int[] cloned = ObjectUtils.clone(original);
        assertNotSame(original, cloned);
        assertEquals(3, cloned.length);
        assertEquals(1, cloned[0]);
        assertEquals(2, cloned[1]);
        assertEquals(3, cloned[2]);
    }

    @Test
    void testCloneObjectArray() {
        final String[] original = {"a", "b"};
        final String[] cloned = ObjectUtils.clone(original);
        assertNotSame(original, cloned);
        assertEquals(2, cloned.length);
        assertEquals("a", cloned[0]);
        assertEquals("b", cloned[1]);
    }

    @Test
    void testCloneThrowsCloneFailedException() {
        final ThrowingCloneable obj = new ThrowingCloneable();
        assertThrows(CloneFailedException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.clone(obj);
            }
        });
    }

    @Test
    void testCloneIfPossibleCloneable() {
        final CloneableValue original = new CloneableValue(7);
        final CloneableValue cloned = ObjectUtils.cloneIfPossible(original);
        assertNotSame(original, cloned);
        assertEquals(7, cloned.value);
    }

    @Test
    void testCloneIfPossibleNotCloneable() {
        final NotCloneable original = new NotCloneable();
        final NotCloneable result = ObjectUtils.cloneIfPossible(original);
        assertSame(original, result);
    }

    @Test
    void testCloneIfPossibleThrows() {
        final ThrowingCloneable obj = new ThrowingCloneable();
        assertThrows(CloneFailedException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.cloneIfPossible(obj);
            }
        });
    }

    @Test
    void testCompareTwoArg() {
        assertEquals(0, ObjectUtils.compare("a", "a"));
        assertTrue(ObjectUtils.compare("a", "b") < 0);
        assertTrue(ObjectUtils.compare("b", "a") > 0);
        assertTrue(ObjectUtils.compare(null, "a") < 0);
        assertTrue(ObjectUtils.compare("a", null) > 0);
        assertEquals(0, ObjectUtils.compare((String) null, (String) null));
    }

    @Test
    void testCompareThreeArgNullGreater() {
        assertTrue(ObjectUtils.compare(null, "a", true) > 0);
        assertTrue(ObjectUtils.compare("a", null, true) < 0);
        assertTrue(ObjectUtils.compare(null, "a", false) < 0);
        assertTrue(ObjectUtils.compare("a", null, false) > 0);
        assertEquals(0, ObjectUtils.compare((String) null, (String) null, true));
    }

    @Test
    void testConstOverloads() {
        assertTrue(ObjectUtils.CONST(true));
        assertFalse(ObjectUtils.CONST(false));
        assertEquals((byte) 127, ObjectUtils.CONST((byte) 127));
        assertEquals('a', ObjectUtils.CONST('a'));
        assertEquals(1.0d, ObjectUtils.CONST(1.0d), 0.0d);
        assertEquals(1.0f, ObjectUtils.CONST(1.0f), 0.0f);
        assertEquals(123, ObjectUtils.CONST(123));
        assertEquals(123L, ObjectUtils.CONST(123L));
        assertEquals((short) 123, ObjectUtils.CONST((short) 123));
        assertEquals("abc", ObjectUtils.CONST("abc"));
    }

    @Test
    void testConstByte() {
        assertEquals((byte) -128, ObjectUtils.CONST_BYTE(-128));
        assertEquals((byte) 127, ObjectUtils.CONST_BYTE(127));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.CONST_BYTE(128);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.CONST_BYTE(-129);
            }
        });
    }

    @Test
    void testConstShort() {
        assertEquals((short) -32768, ObjectUtils.CONST_SHORT(-32768));
        assertEquals((short) 32767, ObjectUtils.CONST_SHORT(32767));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.CONST_SHORT(32768);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.CONST_SHORT(-32769);
            }
        });
    }

    @SuppressWarnings("deprecation")
    @Test
    void testDefaultIfNull() {
        assertEquals("zz", ObjectUtils.defaultIfNull(null, "zz"));
        assertEquals("abc", ObjectUtils.defaultIfNull("abc", "zz"));
        assertNull(ObjectUtils.defaultIfNull(null, null));
    }

    @SuppressWarnings("deprecation")
    @Test
    void testEquals() {
        assertTrue(ObjectUtils.equals(null, null));
        assertFalse(ObjectUtils.equals(null, ""));
        assertFalse(ObjectUtils.equals("", null));
        assertTrue(ObjectUtils.equals("", ""));
        assertFalse(ObjectUtils.equals(Boolean.TRUE, "true"));
    }

    @Test
    void testFirstNonNull() {
        assertNull(ObjectUtils.firstNonNull());
        assertNull(ObjectUtils.firstNonNull((String) null, (String) null));
        assertEquals("zz", ObjectUtils.firstNonNull(null, "zz"));
        assertEquals("abc", ObjectUtils.firstNonNull("abc", "zz"));
    }

    @Test
    void testGetClass() {
        assertNull(ObjectUtils.getClass(null));
        assertEquals(String.class, ObjectUtils.getClass("abc"));
        assertEquals(Integer.class, ObjectUtils.getClass(Integer.valueOf(1)));
    }

    @Test
    void testGetFirstNonNullSuppliers() {
        assertNull(ObjectUtils.getFirstNonNull());
        assertEquals("zz", ObjectUtils.<String>getFirstNonNull(new Supplier<String>() {
            @Override
            public String get() {
                return null;
            }
        }, new Supplier<String>() {
            @Override
            public String get() {
                return "zz";
            }
        }));
        assertNull(ObjectUtils.<String>getFirstNonNull(new Supplier<String>() {
            @Override
            public String get() {
                return null;
            }
        }));
    }

    @Test
    void testGetIfNullWithSupplier() {
        assertEquals("abc", ObjectUtils.getIfNull("abc", (Supplier<String>) null));
        assertEquals("zz", ObjectUtils.getIfNull(null, new Supplier<String>() {
            @Override
            public String get() {
                return "zz";
            }
        }));
        assertNull(ObjectUtils.getIfNull(null, (Supplier<String>) null));
    }

    @Test
    void testGetIfNullWithValue() {
        assertEquals("abc", ObjectUtils.getIfNull("abc", "zz"));
        assertEquals("zz", ObjectUtils.getIfNull(null, "zz"));
        assertNull(ObjectUtils.getIfNull(null, null));
    }

    @SuppressWarnings("deprecation")
    @Test
    void testHashCode() {
        assertEquals(0, ObjectUtils.hashCode(null));
        assertEquals("abc".hashCode(), ObjectUtils.hashCode("abc"));
    }

    @Test
    void testHashCodeHex() {
        assertEquals(Integer.toHexString(0), ObjectUtils.hashCodeHex(null));
        assertEquals(Integer.toHexString("abc".hashCode()), ObjectUtils.hashCodeHex("abc"));
    }

    @SuppressWarnings("deprecation")
    @Test
    void testHashCodeMulti() {
        assertEquals(1, ObjectUtils.hashCodeMulti());
        assertEquals(1, ObjectUtils.hashCodeMulti((Object[]) null));
        final List<Object> list = new ArrayList<Object>();
        list.add("a");
        list.add("b");
        assertEquals(list.hashCode(), ObjectUtils.hashCodeMulti("a", "b"));
    }

    @Test
    void testIdentityHashCodeHex() {
        final Object obj = new Object();
        assertEquals(Integer.toHexString(System.identityHashCode(obj)), ObjectUtils.identityHashCodeHex(obj));
    }

    @Test
    void testIdentityToStringAppendable() throws Exception {
        final StringBuilder appendable = new StringBuilder();
        final String value = "abc";
        ObjectUtils.identityToString(appendable, value);
        assertEquals(value.getClass().getName() + "@" + ObjectUtils.identityHashCodeHex(value), appendable.toString());
    }

    @Test
    void testIdentityToStringAppendableNullObject() {
        final StringBuilder appendable = new StringBuilder();
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                ObjectUtils.identityToString(appendable, null);
            }
        });
    }

    @Test
    void testIdentityToStringObject() {
        assertNull(ObjectUtils.identityToString(null));
        final String value = "abc";
        assertEquals(value.getClass().getName() + "@" + ObjectUtils.identityHashCodeHex(value), ObjectUtils.identityToString(value));
    }

    @Test
    void testIdentityToStringStringBuffer() {
        final StringBuffer buffer = new StringBuffer("pre-");
        final String value = "abc";
        ObjectUtils.identityToString(buffer, value);
        assertEquals("pre-" + value.getClass().getName() + "@" + ObjectUtils.identityHashCodeHex(value), buffer.toString());
    }

    @Test
    void testIdentityToStringStringBufferNullObject() {
        final StringBuffer buffer = new StringBuffer();
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.identityToString(buffer, null);
            }
        });
    }

    @Test
    void testIdentityToStringStringBuilder() {
        final StringBuilder builder = new StringBuilder("pre-");
        final String value = "abc";
        ObjectUtils.identityToString(builder, value);
        assertEquals("pre-" + value.getClass().getName() + "@" + ObjectUtils.identityHashCodeHex(value), builder.toString());
    }

    @Test
    void testIdentityToStringStringBuilderNullObject() {
        final StringBuilder builder = new StringBuilder();
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.identityToString(builder, null);
            }
        });
    }

    @Test
    void testIsArray() {
        assertFalse(ObjectUtils.isArray(null));
        assertFalse(ObjectUtils.isArray(""));
        assertFalse(ObjectUtils.isArray("ab"));
        assertTrue(ObjectUtils.isArray(new int[]{}));
        assertTrue(ObjectUtils.isArray(new int[]{1, 2, 3}));
        assertFalse(ObjectUtils.isArray(Integer.valueOf(1234)));
    }

    @Test
    void testIsEmpty() {
        assertTrue(ObjectUtils.isEmpty(null));
        assertTrue(ObjectUtils.isEmpty(""));
        assertFalse(ObjectUtils.isEmpty("ab"));
        assertTrue(ObjectUtils.isEmpty(new int[]{}));
        assertFalse(ObjectUtils.isEmpty(new int[]{1, 2, 3}));
        assertFalse(ObjectUtils.isEmpty(Integer.valueOf(1234)));
        assertTrue(ObjectUtils.isEmpty(Optional.empty()));
        assertFalse(ObjectUtils.isEmpty(Optional.of("")));
        assertTrue(ObjectUtils.isEmpty(Collections.emptyList()));
        final List<String> list = new ArrayList<String>();
        list.add("a");
        assertFalse(ObjectUtils.isEmpty(list));
        assertTrue(ObjectUtils.isEmpty(new HashMap<String, String>()));
        final Map<String, String> map = new HashMap<String, String>();
        map.put("k", "v");
        assertFalse(ObjectUtils.isEmpty(map));
    }

    @Test
    void testIsNotEmpty() {
        assertFalse(ObjectUtils.isNotEmpty(null));
        assertFalse(ObjectUtils.isNotEmpty(""));
        assertTrue(ObjectUtils.isNotEmpty("ab"));
        assertFalse(ObjectUtils.isNotEmpty(new int[]{}));
        assertTrue(ObjectUtils.isNotEmpty(new int[]{1, 2, 3}));
        assertTrue(ObjectUtils.isNotEmpty(Optional.of("")));
        assertFalse(ObjectUtils.isNotEmpty(Optional.empty()));
    }

    @Test
    void testMax() {
        assertNull(ObjectUtils.max());
        assertNull(ObjectUtils.<String>max((String) null, (String) null));
        assertEquals("b", ObjectUtils.max("a", "b"));
        assertEquals("c", ObjectUtils.max("a", "c", "b"));
        assertEquals("a", ObjectUtils.max("a", null));
        assertEquals("a", ObjectUtils.max(null, "a"));
    }

    @Test
    void testMin() {
        assertNull(ObjectUtils.min());
        assertNull(ObjectUtils.<String>min((String) null, (String) null));
        assertEquals("a", ObjectUtils.min("a", "b"));
        assertEquals("a", ObjectUtils.min("a", "c", "b"));
        assertEquals("a", ObjectUtils.min("a", null));
        assertEquals("a", ObjectUtils.min(null, "a"));
    }

    @Test
    void testMedianVarargs() {
        assertEquals("b", ObjectUtils.median("c", "a", "b"));
        assertEquals("b", ObjectUtils.median("a", "b", "c", "d"));
        assertEquals("a", ObjectUtils.median("a"));
    }

    @Test
    void testMedianVarargsNullArray() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.median((String[]) null);
            }
        });
    }

    @Test
    void testMedianVarargsEmptyArray() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.median(new String[0]);
            }
        });
    }

    @Test
    void testMedianVarargsWithNullElement() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.median("a", null, "b");
            }
        });
    }

    @Test
    void testMedianWithComparator() {
        final Comparator<String> reverse = new Comparator<String>() {
            @Override
            public int compare(final String s1, final String s2) {
                return s2.compareTo(s1);
            }
        };
        assertEquals("b", ObjectUtils.median(reverse, "c", "a", "b"));
    }

    @Test
    void testMedianWithComparatorNullComparator() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.median((Comparator<String>) null, "a", "b");
            }
        });
    }

    @Test
    void testMode() {
        assertNull(ObjectUtils.mode());
        assertNull(ObjectUtils.mode("a", "b"));
        assertEquals("a", ObjectUtils.mode("a", "b", "a"));
        assertNull(ObjectUtils.mode("a", "b", "a", "b"));
    }

    @Test
    void testNotEqual() {
        assertFalse(ObjectUtils.notEqual(null, null));
        assertTrue(ObjectUtils.notEqual(null, ""));
        assertTrue(ObjectUtils.notEqual("", null));
        assertFalse(ObjectUtils.notEqual("", ""));
        assertTrue(ObjectUtils.notEqual(Boolean.TRUE, "true"));
    }

    @Test
    void testRequireNonEmptyOneArg() {
        assertEquals("abc", ObjectUtils.requireNonEmpty("abc"));
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.requireNonEmpty((String) null);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.requireNonEmpty("");
            }
        });
    }

    @Test
    void testRequireNonEmptyTwoArgs() {
        assertEquals("abc", ObjectUtils.requireNonEmpty("abc", "msg"));
        final NullPointerException npe = assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.requireNonEmpty((String) null, "myMessage");
            }
        });
        assertEquals("myMessage", npe.getMessage());
        final IllegalArgumentException iae = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ObjectUtils.requireNonEmpty("", "myMessage");
            }
        });
        assertEquals("myMessage", iae.getMessage());
    }

    @Test
    void testToStringObject() {
        assertEquals("", ObjectUtils.toString(null));
        assertEquals("", ObjectUtils.toString(""));
        assertEquals("bat", ObjectUtils.toString("bat"));
        assertEquals("true", ObjectUtils.toString(Boolean.TRUE));
    }

    @SuppressWarnings("deprecation")
    @Test
    void testToStringObjectNullStr() {
        assertNull(ObjectUtils.toString((Object) null, (String) null));
        assertEquals("null", ObjectUtils.toString((Object) null, "null"));
        assertEquals("", ObjectUtils.toString((Object) "", "null"));
        assertEquals("bat", ObjectUtils.toString((Object) "bat", "null"));
    }

    @Test
    void testToStringSupplierObjSupplierNullStr() {
        final Supplier<Object> presentSupplier = new Supplier<Object>() {
            @Override
            public Object get() {
                return "bat";
            }
        };
        final Supplier<Object> nullSupplier = new Supplier<Object>() {
            @Override
            public Object get() {
                return null;
            }
        };
        final Supplier<String> defaultSupplier = new Supplier<String>() {
            @Override
            public String get() {
                return "default";
            }
        };
        assertEquals("bat", ObjectUtils.toString(presentSupplier, defaultSupplier));
        assertEquals("default", ObjectUtils.toString(nullSupplier, defaultSupplier));
        assertEquals("default", ObjectUtils.toString((Supplier<Object>) null, defaultSupplier));
    }

    @Test
    void testToStringObjSupplierNullStr() {
        final Supplier<String> defaultSupplier = new Supplier<String>() {
            @Override
            public String get() {
                return "default";
            }
        };
        assertEquals("bat", ObjectUtils.toString("bat", defaultSupplier));
        assertEquals("default", ObjectUtils.<Object>toString(null, defaultSupplier));
    }

    @Test
    void testWaitNegativeDuration() {
        final Object obj = new Object();
        synchronized (obj) {
            assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
                @Override
                public void execute() throws Throwable {
                    ObjectUtils.wait(obj, java.time.Duration.ofMillis(-1));
                }
            });
        }
    }

    @Test
    void testWaitSmallPositiveDuration() throws InterruptedException {
        final Object obj = new Object();
        final long start = System.nanoTime();
        synchronized (obj) {
            ObjectUtils.wait(obj, java.time.Duration.ofMillis(1));
        }
        assertTrue(System.nanoTime() - start >= 0);
    }

    @Test
    void testNullSingletonSerializableAndSingleton() {
        assertNotNull(ObjectUtils.NULL);
        assertTrue(ObjectUtils.NULL instanceof java.io.Serializable);
    }
}
