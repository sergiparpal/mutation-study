/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.builder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests {@link HashCodeBuilder}.
 */
class HashCodeBuilderAgentTest {

    static class SimpleFields {
        @SuppressWarnings("unused")
        private final int a;
        @SuppressWarnings("unused")
        private final String b;
        @SuppressWarnings("unused")
        private final transient String c;
        @SuppressWarnings("unused")
        private static final int D = 99;

        SimpleFields(final int a, final String b, final String c) {
            this.a = a;
            this.b = b;
            this.c = c;
        }
    }

    static class ExcludedField {
        @SuppressWarnings("unused")
        private final int included;
        @SuppressWarnings("unused")
        private final int excluded;

        ExcludedField(final int included, final int excluded) {
            this.included = included;
            this.excluded = excluded;
        }
    }

    static class AnnotatedExclude {
        @SuppressWarnings("unused")
        private final int included;
        @HashCodeExclude
        @SuppressWarnings("unused")
        private final int excluded;

        AnnotatedExclude(final int included, final int excluded) {
            this.included = included;
            this.excluded = excluded;
        }
    }

    static class Parent {
        @SuppressWarnings("unused")
        private final int parentField;

        Parent(final int parentField) {
            this.parentField = parentField;
        }
    }

    static class Child extends Parent {
        @SuppressWarnings("unused")
        private final int childField;

        Child(final int parentField, final int childField) {
            super(parentField);
            this.childField = childField;
        }
    }

    static class NoFields {
        // deliberately empty, no instance fields
    }

    static class SelfReferencing {
        SelfReferencing self;
    }

    // ---- constructor tests ----

    @Test
    void defaultConstructorStartsAt17AndBuildsPredictableValue() {
        final int expected = 17 * 37 + 5;
        assertEquals(expected, new HashCodeBuilder().append(5).toHashCode());
    }

    @Test
    void twoArgConstructorUsesSuppliedConstants() {
        final int initial = 7;
        final int multiplier = 11;
        final int expected = initial * multiplier + 5;
        assertEquals(expected, new HashCodeBuilder(initial, multiplier).append(5).toHashCode());
    }

    @Test
    void constructorRejectsEvenInitialValue() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new HashCodeBuilder(16, 37);
            }
        });
    }

    @Test
    void constructorRejectsEvenMultiplier() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new HashCodeBuilder(17, 36);
            }
        });
    }

    @Test
    void constructorRejectsZeroInitialValue() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new HashCodeBuilder(0, 37);
            }
        });
    }

    @Test
    void constructorRejectsZeroMultiplier() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new HashCodeBuilder(17, 0);
            }
        });
    }

    @Test
    void constructorAllowsNegativeOddValues() {
        final int initial = -17;
        final int multiplier = -37;
        final int expected = initial * multiplier + 5;
        assertEquals(expected, new HashCodeBuilder(initial, multiplier).append(5).toHashCode());
    }

    // ---- builder() fluent API ----

    @Test
    void builderProducesEquivalentHashCodeBuilder() {
        final HashCodeBuilder hcb = HashCodeBuilder.builder()
                .setInitialOddNumber(17)
                .setMultiplierOddNumber(37)
                .get();
        assertEquals(new HashCodeBuilder(17, 37).append(5).toHashCode(), hcb.append(5).toHashCode());
    }

    // ---- primitive append tests ----

    @Test
    void appendBooleanTrueAddsZero() {
        final int before = new HashCodeBuilder(17, 37).toHashCode();
        final int after = new HashCodeBuilder(17, 37).append(true).toHashCode();
        assertEquals(before * 37, after);
    }

    @Test
    void appendBooleanFalseAddsOne() {
        final int after = new HashCodeBuilder(17, 37).append(false).toHashCode();
        assertEquals(17 * 37 + 1, after);
    }

    @Test
    void appendByte() {
        final byte value = 5;
        assertEquals(17 * 37 + value, new HashCodeBuilder(17, 37).append(value).toHashCode());
    }

    @Test
    void appendChar() {
        final char value = 'x';
        assertEquals(17 * 37 + value, new HashCodeBuilder(17, 37).append(value).toHashCode());
    }

    @Test
    void appendShort() {
        final short value = 12345;
        assertEquals(17 * 37 + value, new HashCodeBuilder(17, 37).append(value).toHashCode());
    }

    @Test
    void appendInt() {
        assertEquals(17 * 37 + 42, new HashCodeBuilder(17, 37).append(42).toHashCode());
    }

    @Test
    void appendLong() {
        final long value = 123456789012345L;
        final int expected = 17 * 37 + (int) (value ^ value >> 32);
        assertEquals(expected, new HashCodeBuilder(17, 37).append(value).toHashCode());
    }

    @Test
    void appendFloat() {
        final float value = 3.14f;
        final int expected = 17 * 37 + Float.floatToIntBits(value);
        assertEquals(expected, new HashCodeBuilder(17, 37).append(value).toHashCode());
    }

    @Test
    void appendDouble() {
        final double value = 3.14159;
        final long bits = Double.doubleToLongBits(value);
        final int expected = 17 * 37 + (int) (bits ^ bits >> 32);
        assertEquals(expected, new HashCodeBuilder(17, 37).append(value).toHashCode());
    }

    @Test
    void appendObjectNullIsSameAsNoOpMultiply() {
        final int expected = 17 * 37;
        assertEquals(expected, new HashCodeBuilder(17, 37).append((Object) null).toHashCode());
    }

    @Test
    void appendObjectDelegatesToItsHashCode() {
        final String s = "hello";
        final int expected = 17 * 37 + s.hashCode();
        assertEquals(expected, new HashCodeBuilder(17, 37).append((Object) s).toHashCode());
    }

    // ---- array append tests ----

    @Test
    void appendNullBooleanArray() {
        assertEquals(17 * 37, new HashCodeBuilder(17, 37).append((boolean[]) null).toHashCode());
    }

    @Test
    void appendEmptyBooleanArrayDiffersFromNullArray() {
        final int nullResult = new HashCodeBuilder(17, 37).append((boolean[]) null).toHashCode();
        final int emptyResult = new HashCodeBuilder(17, 37).append(new boolean[0]).toHashCode();
        assertNotEquals(nullResult, emptyResult);
        assertEquals(17, emptyResult);
        assertEquals(17 * 37, nullResult);
    }

    @Test
    void appendBooleanArrayAppendsEachElement() {
        final boolean[] array = {true, false, true};
        HashCodeBuilder expectedBuilder = new HashCodeBuilder(17, 37);
        for (final boolean b : array) {
            expectedBuilder = expectedBuilder.append(b);
        }
        assertEquals(expectedBuilder.toHashCode(), new HashCodeBuilder(17, 37).append(array).toHashCode());
    }

    @Test
    void appendNullIntArray() {
        assertEquals(17 * 37, new HashCodeBuilder(17, 37).append((int[]) null).toHashCode());
    }

    @Test
    void appendIntArrayMatchesSequentialAppends() {
        final int[] array = {1, 2, 3};
        final int expected = new HashCodeBuilder(17, 37).append(1).append(2).append(3).toHashCode();
        assertEquals(expected, new HashCodeBuilder(17, 37).append(array).toHashCode());
    }

    @Test
    void appendNullObjectArray() {
        assertEquals(17 * 37, new HashCodeBuilder(17, 37).append((Object[]) null).toHashCode());
    }

    @Test
    void appendObjectArrayMatchesSequentialAppends() {
        final Object[] array = {"a", "b"};
        final int expected = new HashCodeBuilder(17, 37).append((Object) "a").append((Object) "b").toHashCode();
        assertEquals(expected, new HashCodeBuilder(17, 37).append(array).toHashCode());
    }

    @Test
    void appendGenericObjectDispatchesToPrimitiveArrayHandling() {
        final int[] primitiveArray = {7, 8, 9};
        final int viaObjectOverload = new HashCodeBuilder(17, 37).append((Object) primitiveArray).toHashCode();
        final int viaArrayOverload = new HashCodeBuilder(17, 37).append(primitiveArray).toHashCode();
        assertEquals(viaArrayOverload, viaObjectOverload);
    }

    @Test
    void appendMultiDimensionalArrayIsHandled() {
        final int[][] array = {{1, 2}, {3, 4}};
        final int result = new HashCodeBuilder(17, 37).append(array).toHashCode();
        final int expected = new HashCodeBuilder(17, 37).append(new int[]{1, 2}).append(new int[]{3, 4}).toHashCode();
        assertEquals(expected, result);
    }

    // ---- appendSuper ----

    @Test
    void appendSuperFoldsInGivenValue() {
        final int superHash = 12345;
        final int expected = 17 * 37 + superHash;
        assertEquals(expected, new HashCodeBuilder(17, 37).appendSuper(superHash).toHashCode());
    }

    // ---- toHashCode / build / hashCode / equals ----

    @Test
    void toHashCodeReturnsRunningTotal() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37).append(1).append(2);
        assertEquals(builder.toHashCode(), builder.toHashCode());
    }

    @Test
    void buildReturnsBoxedToHashCode() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37).append("value");
        assertEquals(Integer.valueOf(builder.toHashCode()), builder.build());
    }

    @Test
    void hashCodeDelegatesToToHashCode() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37).append(42);
        assertEquals(builder.toHashCode(), builder.hashCode());
    }

    @Test
    void equalsComparesByComputedTotal() {
        final HashCodeBuilder a = new HashCodeBuilder(17, 37).append(42);
        final HashCodeBuilder b = new HashCodeBuilder(17, 37).append(42);
        assertTrue(a.equals(b));
        assertTrue(b.equals(a));
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    void equalsReturnsFalseForDifferentTotal() {
        final HashCodeBuilder a = new HashCodeBuilder(17, 37).append(42);
        final HashCodeBuilder b = new HashCodeBuilder(17, 37).append(43);
        assertFalse(a.equals(b));
    }

    @Test
    void equalsReturnsFalseForNull() {
        assertFalse(new HashCodeBuilder().equals(null));
    }

    @Test
    void equalsReturnsFalseForDifferentType() {
        assertFalse(new HashCodeBuilder().equals("not a builder"));
    }

    @Test
    void equalsIsReflexive() {
        final HashCodeBuilder a = new HashCodeBuilder(17, 37).append(1);
        assertTrue(a.equals(a));
        assertSame(a, a);
    }

    // ---- reflectionHashCode tests ----

    @Test
    void reflectionHashCodeNullObjectThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                HashCodeBuilder.reflectionHashCode(17, 37, null);
            }
        });
    }

    @Test
    void reflectionHashCodeRejectsEvenInitial() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                HashCodeBuilder.reflectionHashCode(16, 37, new SimpleFields(1, "b", "c"));
            }
        });
    }

    @Test
    void reflectionHashCodeIsConsistentForEqualFieldValues() {
        final SimpleFields first = new SimpleFields(1, "b", "c");
        final SimpleFields second = new SimpleFields(1, "b", "c");
        assertEquals(HashCodeBuilder.reflectionHashCode(first), HashCodeBuilder.reflectionHashCode(second));
    }

    @Test
    void reflectionHashCodeDiffersWhenFieldDiffers() {
        final SimpleFields first = new SimpleFields(1, "b", "c");
        final SimpleFields second = new SimpleFields(2, "b", "c");
        assertNotEquals(HashCodeBuilder.reflectionHashCode(first), HashCodeBuilder.reflectionHashCode(second));
    }

    @Test
    void reflectionHashCodeIgnoresTransientFieldsByDefault() {
        final SimpleFields withC1 = new SimpleFields(1, "b", "same");
        final SimpleFields withC2 = new SimpleFields(1, "b", "different");
        assertEquals(HashCodeBuilder.reflectionHashCode(withC1), HashCodeBuilder.reflectionHashCode(withC2));
    }

    @Test
    void reflectionHashCodeCanIncludeTransientFields() {
        final SimpleFields withC1 = new SimpleFields(1, "b", "same");
        final SimpleFields withC2 = new SimpleFields(1, "b", "different");
        final int hash1 = HashCodeBuilder.reflectionHashCode(17, 37, withC1, true);
        final int hash2 = HashCodeBuilder.reflectionHashCode(17, 37, withC2, true);
        assertNotEquals(hash1, hash2);
    }

    @Test
    void reflectionHashCodeWithStringVarargsExcludesNamedField() {
        final ExcludedField a = new ExcludedField(1, 100);
        final ExcludedField b = new ExcludedField(1, 200);
        assertEquals(HashCodeBuilder.reflectionHashCode(a, "excluded"), HashCodeBuilder.reflectionHashCode(b, "excluded"));
    }

    @Test
    void reflectionHashCodeWithCollectionExcludesNamedField() {
        final ExcludedField a = new ExcludedField(1, 100);
        final ExcludedField b = new ExcludedField(1, 200);
        final List<String> excludes = new ArrayList<String>();
        excludes.add("excluded");
        assertEquals(HashCodeBuilder.reflectionHashCode(a, excludes), HashCodeBuilder.reflectionHashCode(b, excludes));
    }

    @Test
    void reflectionHashCodeWithEmptyCollectionIncludesAllFields() {
        final ExcludedField a = new ExcludedField(1, 100);
        final ExcludedField b = new ExcludedField(1, 200);
        assertNotEquals(HashCodeBuilder.reflectionHashCode(a, Collections.<String>emptyList()),
                HashCodeBuilder.reflectionHashCode(b, Collections.<String>emptyList()));
    }

    @Test
    void reflectionHashCodeHonorsHashCodeExcludeAnnotation() {
        final AnnotatedExclude a = new AnnotatedExclude(1, 100);
        final AnnotatedExclude b = new AnnotatedExclude(1, 200);
        assertEquals(HashCodeBuilder.reflectionHashCode(a), HashCodeBuilder.reflectionHashCode(b));
    }

    @Test
    void reflectionHashCodeIncludesSuperclassFields() {
        final Child a = new Child(1, 2);
        final Child b = new Child(9, 2);
        assertNotEquals(HashCodeBuilder.reflectionHashCode(a), HashCodeBuilder.reflectionHashCode(b));
    }

    @Test
    void reflectionHashCodeUpToClassStopsAtGivenSuperclass() {
        final Child a = new Child(1, 2);
        final Child b = new Child(9, 2);
        final int hashA = HashCodeBuilder.reflectionHashCode(17, 37, a, false, Child.class);
        final int hashB = HashCodeBuilder.reflectionHashCode(17, 37, b, false, Child.class);
        assertEquals(hashA, hashB, "superclass fields must be excluded when reflectUpToClass is the object's own class");
    }

    @Test
    void reflectionHashCodeUpToClassIncludesGivenSuperclassInclusive() {
        final Child a = new Child(1, 2);
        final Child b = new Child(9, 2);
        final int hashA = HashCodeBuilder.reflectionHashCode(17, 37, a, false, Parent.class);
        final int hashB = HashCodeBuilder.reflectionHashCode(17, 37, b, false, Parent.class);
        assertNotEquals(hashA, hashB, "Parent fields are included up to and including reflectUpToClass");
    }

    @Test
    void reflectionHashCodeOnObjectWithNoFieldsIsConstant() {
        assertEquals(17, HashCodeBuilder.reflectionHashCode(new NoFields()));
        assertEquals(17, HashCodeBuilder.reflectionHashCode(new NoFields()));
    }

    @Test
    void reflectionHashCodeHandlesSelfReferentialCycleWithoutStackOverflow() {
        final SelfReferencing cyclic = new SelfReferencing();
        cyclic.self = cyclic;
        final int hash = HashCodeBuilder.reflectionHashCode(cyclic, false);
        assertEquals(hash, HashCodeBuilder.reflectionHashCode(cyclic, false));
    }
}
