/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link FastDateParser}.
 */
class FastDateParserAgentTest {

    private static final TimeZone UTC = TimeZone.getTimeZone("UTC");

    private static Date utcDate(final int year, final int month, final int day, final int hour, final int minute, final int second) {
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.clear();
        cal.set(year, month, day, hour, minute, second);
        return cal.getTime();
    }

    @Test
    void testBasicParseYearMonthDay() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final Date parsed = parser.parse("2021-01-15");
        assertEquals(utcDate(2021, 0, 15, 0, 0, 0), parsed);
    }

    @Test
    void testParseThrowsParseExceptionOnGarbage() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final ParseException ex = assertThrows(ParseException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                parser.parse("not-a-date");
            }
        });
        assertTrue(ex.getMessage().contains("not-a-date"));
    }

    @Test
    void testParseDoesNotRequireFullStringConsumption() throws ParseException {
        // parse(String) only requires the pattern's strategies to match a prefix of the input;
        // unlike SimpleDateFormat in strict mode, trailing unmatched text is not an error.
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final Date parsed = parser.parse("2021-01-15 extra stuff that is not part of the pattern");
        assertEquals(utcDate(2021, 0, 15, 0, 0, 0), parsed);
    }

    @Test
    void testParsePositionReturnsNullAndSetsErrorIndexOnFailure() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date result = parser.parse("garbage", pos);
        assertNull(result);
        assertNotEquals(-1, pos.getErrorIndex());
    }

    @Test
    void testParsePositionDoesNotConsumeEntireInput() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date result = parser.parse("2021-01-15TRAILING", pos);
        assertNotNull(result);
        assertEquals(10, pos.getIndex());
        assertEquals(utcDate(2021, 0, 15, 0, 0, 0), result);
    }

    @Test
    void testParseCalendarOverload() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.clear();
        final ParsePosition pos = new ParsePosition(0);
        final boolean success = parser.parse("2021-01-15", pos, cal);
        assertTrue(success);
        assertEquals(2021, cal.get(Calendar.YEAR));
        assertEquals(0, cal.get(Calendar.MONTH));
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseCalendarOverloadFailureReturnsFalse() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.clear();
        final ParsePosition pos = new ParsePosition(0);
        final boolean success = parser.parse("xxxx", pos, cal);
        assertFalse(success);
        assertNotEquals(-1, pos.getErrorIndex());
    }

    @Test
    void testParseObjectDelegatesToParse() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final Object result = parser.parseObject("2021-01-15");
        assertEquals(utcDate(2021, 0, 15, 0, 0, 0), result);
    }

    @Test
    void testParseObjectWithPositionDelegatesToParse() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Object result = parser.parseObject("2021-01-15", pos);
        assertEquals(utcDate(2021, 0, 15, 0, 0, 0), result);
    }

    @Test
    void testGetters() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        assertEquals("yyyy-MM-dd", parser.getPattern());
        assertEquals(UTC, parser.getTimeZone());
        assertEquals(Locale.US, parser.getLocale());
    }

    @Test
    void testNullLocaleDefaultsToSystemLocale() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, null);
        assertEquals(Locale.getDefault(), parser.getLocale());
    }

    @Test
    void testNullPatternThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDateParser(null, UTC, Locale.US);
            }
        });
    }

    @Test
    void testNullTimeZoneThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDateParser("yyyy-MM-dd", null, Locale.US);
            }
        });
    }

    @Test
    void testUnsupportedPatternCharacterThrowsIllegalArgumentException() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDateParser("yyyy-QQ-dd", UTC, Locale.US);
            }
        });
        assertTrue(ex.getMessage().contains("Q"));
    }

    @Test
    void testUnterminatedQuoteThrowsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDateParser("yyyy'unterminated", UTC, Locale.US);
            }
        });
    }

    @Test
    void testInvalidIso8601WidthThrowsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                new FastDateParser("yyyy-MM-ddXXXX", UTC, Locale.US);
            }
        });
    }

    @Test
    void testEqualsAndHashCode() {
        final FastDateParser a = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final FastDateParser b = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final FastDateParser diffPattern = new FastDateParser("yyyy/MM/dd", UTC, Locale.US);
        final FastDateParser diffZone = new FastDateParser("yyyy-MM-dd", TimeZone.getTimeZone("America/Los_Angeles"), Locale.US);
        final FastDateParser diffLocale = new FastDateParser("yyyy-MM-dd", UTC, Locale.FRANCE);

        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
        assertNotEquals(a, diffPattern);
        assertNotEquals(a, diffZone);
        assertNotEquals(a, diffLocale);
        assertNotEquals(a, "not a FastDateParser");
        assertNotEquals(a, null);
    }

    @Test
    void testToString() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final String str = parser.toString();
        assertTrue(str.contains("yyyy-MM-dd"));
        assertTrue(str.contains("UTC"));
    }

    @Test
    void testToStringAll() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final String str = parser.toStringAll();
        assertTrue(str.contains("yyyy-MM-dd"));
        assertTrue(str.contains("pattern="));
    }

    @Test
    void testSerializationRoundTrip() throws Exception {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, Locale.US);
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        final ObjectOutputStream oos = new ObjectOutputStream(baos);
        oos.writeObject(parser);
        oos.close();

        final ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(baos.toByteArray()));
        final FastDateParser deserialized = (FastDateParser) ois.readObject();
        ois.close();

        assertEquals(parser, deserialized);
        assertEquals(parser.parse("2021-01-15"), deserialized.parse("2021-01-15"));
    }

    @Test
    void testOverflowingNumericYearFailsGracefullyInsteadOfThrowingNfe() {
        // "yyyy" alone has no next number strategy to bound its width, so it consumes every
        // digit; an excessively long run of digits overflows int and must be a parse failure,
        // not an escaped NumberFormatException.
        final FastDateParser parser = new FastDateParser("yyyy", UTC, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date result = parser.parse("99999999999999999999", pos);
        assertNull(result);
        assertNotEquals(-1, pos.getErrorIndex());
    }

    @Test
    void testAdjacentNumericFieldsRespectWidth() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyyMMdd", UTC, Locale.US);
        final Date parsed = parser.parse("20210115");
        assertEquals(utcDate(2021, 0, 15, 0, 0, 0), parsed);
    }

    @Test
    void testTwoDigitYearWithCenturyStart() throws ParseException {
        final Calendar centuryCal = Calendar.getInstance(UTC, Locale.US);
        centuryCal.clear();
        centuryCal.set(1960, Calendar.JANUARY, 1);
        final Date centuryStart = centuryCal.getTime();

        final FastDateParser parser = new FastDateParser("yy", UTC, Locale.US, centuryStart);

        // startYear == 60, so twoDigitYear >= 60 maps to 1900 + value, otherwise 2000 + value.
        final Date below = parser.parse("59");
        final Calendar belowCal = Calendar.getInstance(UTC, Locale.US);
        belowCal.setTime(below);
        assertEquals(2059, belowCal.get(Calendar.YEAR));

        final Date atBoundary = parser.parse("60");
        final Calendar atCal = Calendar.getInstance(UTC, Locale.US);
        atCal.setTime(atBoundary);
        assertEquals(1960, atCal.get(Calendar.YEAR));
    }

    @Test
    void testIso8601TimeZoneWithColon() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd'T'HH:mm:ssXXX", UTC, Locale.US);
        final Date parsed = parser.parse("2020-01-02T03:04:05+01:00");
        assertEquals(utcDate(2020, 0, 2, 2, 4, 5), parsed);
    }

    @Test
    void testRfc822TimeZone() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd Z", UTC, Locale.US);
        final Date parsed = parser.parse("2020-01-02 +0100");
        assertEquals(utcDate(2020, 0, 2, -1, 0, 0), parsed);
    }

    @Test
    void testMonthNameTextStrategyCaseInsensitive() throws ParseException {
        final FastDateParser parser = new FastDateParser("d MMM yyyy", UTC, Locale.US);
        final Date lower = parser.parse("15 jan 2021");
        final Date mixed = parser.parse("15 Jan 2021");
        assertEquals(utcDate(2021, 0, 15, 0, 0, 0), lower);
        assertEquals(lower, mixed);
    }

    @Test
    void testDayOfWeekTextStrategyCaseInsensitive() throws ParseException {
        final FastDateParser parser = new FastDateParser("EEEE, d MMM yyyy", UTC, Locale.US);
        // 2021-01-15 is a Friday.
        final Date parsed = parser.parse("FRIDAY, 15 Jan 2021");
        assertEquals(utcDate(2021, 0, 15, 0, 0, 0), parsed);
    }

    @Test
    void testUnknownTextValueThrowsParseException() {
        final FastDateParser parser = new FastDateParser("d MMM yyyy", UTC, Locale.US);
        assertThrows(ParseException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                parser.parse("15 NotAMonth 2021");
            }
        });
    }

    @Test
    void testAmPmStrategy() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd hh:mm a", UTC, Locale.US);
        final Date pm = parser.parse("2021-01-15 02:30 PM");
        assertEquals(utcDate(2021, 0, 15, 14, 30, 0), pm);
        final Date am = parser.parse("2021-01-15 02:30 AM");
        assertEquals(utcDate(2021, 0, 15, 2, 30, 0), am);
    }

    @Test
    void testHour24OfDayWraps24ToZero() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd kk:mm", UTC, Locale.US);
        final Date parsed = parser.parse("2021-01-15 24:00");
        // k=24 means midnight of the *current* day per SimpleDateFormat semantics (modify maps 24 -> 0).
        assertEquals(utcDate(2021, 0, 15, 0, 0, 0), parsed);
    }

    @Test
    void testLiteralQuotedTextMustMatchExactly() {
        final FastDateParser parser = new FastDateParser("yyyy'-Q'MM", UTC, Locale.US);
        assertThrows(ParseException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                parser.parse("2021-X01");
            }
        });
    }

    @Test
    void testLiteralQuotedTextMatchesSuccessfully() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy'-Q'MM", UTC, Locale.US);
        final Date parsed = parser.parse("2021-Q01");
        assertEquals(utcDate(2021, 0, 1, 0, 0, 0), parsed);
    }

    @Test
    void testDayOfYearStrategy() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-DDD", UTC, Locale.US);
        final Date parsed = parser.parse("2021-015");
        assertEquals(utcDate(2021, 0, 15, 0, 0, 0), parsed);
    }

    @Test
    void testJapaneseImperialLocaleRejectsDatesBeforeEpoch() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", UTC, FastDateParser.JAPANESE_IMPERIAL);
        final ParseException ex = assertThrows(ParseException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                parser.parse("not-a-date");
            }
        });
        assertTrue(ex.getMessage().contains("1868-01-01"));
    }

    @Test
    void testEraStrategyParsesAd() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd G", UTC, Locale.US);
        final Date parsed = parser.parse("2021-01-15 AD");
        assertEquals(utcDate(2021, 0, 15, 0, 0, 0), parsed);
    }
}
