/*
  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      https://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
 */
package org.apache.commons.cli;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.text.ParseException;
import java.util.Date;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link Converter}.
 */
public class ConverterAgentTest {

    @Test
    public void testDefaultConverterReturnsInputUnchanged() {
        final Object result = Converter.DEFAULT.apply("hello");
        assertEquals("hello", result);
        assertSame("hello", result);
    }

    @Test
    public void testDefaultConverterWithEmptyString() {
        assertEquals("", Converter.DEFAULT.apply(""));
    }

    @Test
    public void testClassConverterFindsExistingClass() throws ClassNotFoundException {
        final Class<?> clazz = Converter.CLASS.apply("java.lang.String");
        assertEquals(String.class, clazz);
    }

    @Test
    public void testClassConverterThrowsOnUnknownClass() {
        assertThrows(ClassNotFoundException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.CLASS.apply("does.not.Exist");
            }
        });
    }

    @Test
    public void testFileConverterCreatesFile() {
        final File file = Converter.FILE.apply("some/path.txt");
        assertNotNull(file);
        assertEquals("some/path.txt".replace('/', File.separatorChar), file.getPath());
    }

    @Test
    public void testFileConverterThrowsOnNull() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.FILE.apply(null);
            }
        });
    }

    @Test
    public void testPathConverterCreatesPath() {
        final Path path = Converter.PATH.apply("a/b/c");
        assertNotNull(path);
        assertEquals("a/b/c".replace('/', File.separatorChar), path.toString());
    }

    @Test
    public void testPathConverterThrowsOnInvalidPath() {
        assertThrows(InvalidPathException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.PATH.apply("invalid\u0000path");
            }
        });
    }

    @Test
    public void testNumberConverterParsesLongWithoutDecimalPoint() throws Exception {
        final Number number = Converter.NUMBER.apply("42");
        assertEquals(Long.valueOf(42L), number);
        assertTrue(number instanceof Long);
    }

    @Test
    public void testNumberConverterParsesDoubleWithDecimalPoint() throws Exception {
        final Number number = Converter.NUMBER.apply("3.14");
        assertEquals(Double.valueOf(3.14), number);
        assertTrue(number instanceof Double);
    }

    @Test
    public void testNumberConverterThrowsOnInvalidInput() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.NUMBER.apply("not-a-number");
            }
        });
    }

    @Test
    public void testNumberConverterThrowsOnInvalidDecimalInput() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.NUMBER.apply("1.2.3");
            }
        });
    }

    @Test
    public void testObjectConverterInstantiatesClass() throws Exception {
        final Object obj = Converter.OBJECT.apply("java.lang.Object");
        assertNotNull(obj);
        assertEquals(Object.class, obj.getClass());
    }

    @Test
    public void testObjectConverterThrowsOnUnknownClass() {
        assertThrows(ReflectiveOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.OBJECT.apply("does.not.Exist");
            }
        });
    }

    @Test
    public void testUrlConverterCreatesUrl() throws MalformedURLException {
        final URL url = Converter.URL.apply("https://example.com/path");
        assertNotNull(url);
        assertEquals("https://example.com/path", url.toString());
    }

    @Test
    public void testUrlConverterThrowsOnMalformedUrl() {
        assertThrows(MalformedURLException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.URL.apply("not a url");
            }
        });
    }

    @Test
    public void testDateConverterParsesValidDate() throws ParseException {
        final Date date = Converter.DATE.apply("Wed Jan 04 12:08:56 UTC 2023");
        assertNotNull(date);
    }

    @Test
    public void testDateConverterThrowsOnInvalidOutOfRangeDate() {
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.DATE.apply("Wed Feb 30 12:08:56 UTC 2023");
            }
        });
    }

    @Test
    public void testDateConverterThrowsOnGarbageInput() {
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.DATE.apply("not a date");
            }
        });
    }

    /**
     * Simple custom converter implementation exercising the functional interface contract directly.
     */
    private static final class UpperCaseConverter implements Converter<String, IllegalArgumentException> {
        @Override
        public String apply(final String string) {
            if (string == null) {
                throw new IllegalArgumentException("null input");
            }
            return string.toUpperCase();
        }
    }

    @Test
    public void testCustomConverterImplementationHappyPath() throws IllegalArgumentException {
        final Converter<String, IllegalArgumentException> converter = new UpperCaseConverter();
        assertEquals("ABC", converter.apply("abc"));
    }

    @Test
    public void testCustomConverterImplementationThrowsDeclaredException() {
        final Converter<String, IllegalArgumentException> converter = new UpperCaseConverter();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                converter.apply(null);
            }
        });
    }
}
