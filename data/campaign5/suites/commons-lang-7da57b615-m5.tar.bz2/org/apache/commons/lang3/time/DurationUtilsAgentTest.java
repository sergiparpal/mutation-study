/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.function.FailableBiConsumer;
import org.apache.commons.lang3.function.FailableConsumer;
import org.apache.commons.lang3.function.FailableRunnable;
import org.junit.jupiter.api.Test;

/**
 * Tests for {@link DurationUtils}.
 */
class DurationUtilsAgentTest {

    @Test
    void testAcceptNullDurationIsNoop() throws Throwable {
        final boolean[] called = new boolean[1];
        DurationUtils.accept(new FailableBiConsumer<Long, Integer, Throwable>() {
            @Override
            public void accept(final Long millis, final Integer nanos) {
                called[0] = true;
            }
        }, null);
        assertFalse(called[0]);
    }

    @Test
    void testAcceptNullConsumerIsNoop() throws Throwable {
        // Must not throw even though the consumer is null.
        DurationUtils.accept(null, Duration.ofMillis(100));
    }

    @Test
    void testAcceptPositiveDuration() throws Throwable {
        final long[] millisHolder = new long[1];
        final int[] nanosHolder = new int[1];
        final Duration duration = Duration.ofSeconds(1, 500500000L);
        DurationUtils.accept(new FailableBiConsumer<Long, Integer, Throwable>() {
            @Override
            public void accept(final Long millis, final Integer nanos) {
                millisHolder[0] = millis.longValue();
                nanosHolder[0] = nanos.intValue();
            }
        }, duration);
        assertEquals(1500L, millisHolder[0]);
        assertEquals(500000, nanosHolder[0]);
    }

    @Test
    void testAcceptNegativeDuration() throws Throwable {
        final long[] millisHolder = new long[1];
        final int[] nanosHolder = new int[1];
        // -1 seconds + 0.5005 seconds == -0.4995 seconds
        final Duration duration = Duration.ofSeconds(-1, 500500000L);
        assertTrue(duration.isNegative());
        DurationUtils.accept(new FailableBiConsumer<Long, Integer, Throwable>() {
            @Override
            public void accept(final Long millis, final Integer nanos) {
                millisHolder[0] = millis.longValue();
                nanosHolder[0] = nanos.intValue();
            }
        }, duration);
        assertEquals(-500L, millisHolder[0]);
        assertEquals(500000, nanosHolder[0]);
        // Nanos must always be non-negative per the contract.
        assertTrue(nanosHolder[0] >= 0);
    }

    @Test
    void testGetWithEmptyKeyReturnsDefault() {
        final Duration result = DurationUtils.get("", ChronoUnit.SECONDS, 42L);
        assertEquals(Duration.ofSeconds(42L), result);
    }

    @Test
    void testGetWithRealPropertyReturnsPropertyValue() {
        final String key = "org.apache.commons.lang3.time.DurationUtilsAgentTest.get";
        System.setProperty(key, "7");
        try {
            final Duration result = DurationUtils.get(key, ChronoUnit.SECONDS, 99L);
            assertEquals(Duration.ofSeconds(7L), result);
        } finally {
            System.clearProperty(key);
        }
    }

    @Test
    void testGetMillisWithEmptyKeyReturnsDefault() {
        final Duration result = DurationUtils.getMillis("", 123L);
        assertEquals(Duration.ofMillis(123L), result);
    }

    @Test
    void testGetMillisWithRealProperty() {
        final String key = "org.apache.commons.lang3.time.DurationUtilsAgentTest.getMillis";
        System.setProperty(key, "250");
        try {
            final Duration result = DurationUtils.getMillis(key, 1L);
            assertEquals(Duration.ofMillis(250L), result);
        } finally {
            System.clearProperty(key);
        }
    }

    @Test
    void testGetSecondsWithEmptyKeyReturnsDefault() {
        final Duration result = DurationUtils.getSeconds("", 5L);
        assertEquals(Duration.ofSeconds(5L), result);
    }

    @Test
    void testGetSecondsWithRealProperty() {
        final String key = "org.apache.commons.lang3.time.DurationUtilsAgentTest.getSeconds";
        System.setProperty(key, "3");
        try {
            final Duration result = DurationUtils.getSeconds(key, 1L);
            assertEquals(Duration.ofSeconds(3L), result);
        } finally {
            System.clearProperty(key);
        }
    }

    @Test
    @SuppressWarnings("deprecation")
    void testGetNanosOfMiiliDeprecatedMatchesReplacement() {
        final Duration duration = Duration.ofSeconds(0, 1234567);
        assertEquals(DurationUtils.getNanosOfMilli(duration), DurationUtils.getNanosOfMiili(duration));
    }

    @Test
    void testGetNanosOfMilliNullIsZero() {
        assertEquals(0, DurationUtils.getNanosOfMilli(null));
    }

    @Test
    void testGetNanosOfMilliBoundary() {
        assertEquals(0, DurationUtils.getNanosOfMilli(Duration.ofMillis(5)));
        assertEquals(999999, DurationUtils.getNanosOfMilli(Duration.ofNanos(999999)));
        assertEquals(1, DurationUtils.getNanosOfMilli(Duration.ofSeconds(0, 1000001)));
    }

    @Test
    void testIsPositive() {
        assertTrue(DurationUtils.isPositive(Duration.ofMillis(1)));
        assertFalse(DurationUtils.isPositive(Duration.ZERO));
        assertFalse(DurationUtils.isPositive(Duration.ofMillis(-1)));
    }

    @Test
    void testIsPositiveNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationUtils.isPositive(null);
            }
        });
    }

    @Test
    void testOfConsumerReturnsNonNegativeDurationAndRuns() throws Throwable {
        final Instant[] seen = new Instant[1];
        final Duration result = DurationUtils.of(new FailableConsumer<Instant, Throwable>() {
            @Override
            public void accept(final Instant start) {
                seen[0] = start;
            }
        });
        assertNotNull(seen[0]);
        assertFalse(result.isNegative());
    }

    @Test
    void testOfConsumerPropagatesException() {
        final IOException expected = new IOException("boom");
        final IOException actual = assertThrows(IOException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                DurationUtils.of(new FailableConsumer<Instant, IOException>() {
                    @Override
                    public void accept(final Instant start) throws IOException {
                        throw expected;
                    }
                });
            }
        });
        assertSame(expected, actual);
    }

    @Test
    void testOfRunnableReturnsNonNegativeDurationAndRuns() throws Throwable {
        final boolean[] ran = new boolean[1];
        final Duration result = DurationUtils.of(new FailableRunnable<Throwable>() {
            @Override
            public void run() {
                ran[0] = true;
            }
        });
        assertTrue(ran[0]);
        assertFalse(result.isNegative());
    }

    @Test
    void testOfRunnablePropagatesException() {
        final IOException expected = new IOException("boom-runnable");
        final IOException actual = assertThrows(IOException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                DurationUtils.of(new FailableRunnable<IOException>() {
                    @Override
                    public void run() throws IOException {
                        throw expected;
                    }
                });
            }
        });
        assertSame(expected, actual);
    }

    @Test
    void testSinceReturnsElapsedDuration() {
        final Instant start = Instant.now().minusSeconds(5);
        final Duration elapsed = DurationUtils.since(start);
        assertFalse(elapsed.isNegative());
        assertTrue(elapsed.getSeconds() >= 4, "Expected at least ~5 seconds elapsed, got: " + elapsed);
    }

    @Test
    void testToChronoUnitMapsAllTimeUnits() {
        assertEquals(ChronoUnit.NANOS, DurationUtils.toChronoUnit(TimeUnit.NANOSECONDS));
        assertEquals(ChronoUnit.MICROS, DurationUtils.toChronoUnit(TimeUnit.MICROSECONDS));
        assertEquals(ChronoUnit.MILLIS, DurationUtils.toChronoUnit(TimeUnit.MILLISECONDS));
        assertEquals(ChronoUnit.SECONDS, DurationUtils.toChronoUnit(TimeUnit.SECONDS));
        assertEquals(ChronoUnit.MINUTES, DurationUtils.toChronoUnit(TimeUnit.MINUTES));
        assertEquals(ChronoUnit.HOURS, DurationUtils.toChronoUnit(TimeUnit.HOURS));
        assertEquals(ChronoUnit.DAYS, DurationUtils.toChronoUnit(TimeUnit.DAYS));
    }

    @Test
    void testToChronoUnitNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationUtils.toChronoUnit(null);
            }
        });
    }

    @Test
    void testToDuration() {
        assertEquals(Duration.ofSeconds(10), DurationUtils.toDuration(10, TimeUnit.SECONDS));
        assertEquals(Duration.ofMillis(-250), DurationUtils.toDuration(-250, TimeUnit.MILLISECONDS));
        assertEquals(Duration.ZERO, DurationUtils.toDuration(0, TimeUnit.DAYS));
    }

    @Test
    void testToMillisIntNormal() {
        assertEquals(1500, DurationUtils.toMillisInt(Duration.ofMillis(1500)));
        assertEquals(0, DurationUtils.toMillisInt(Duration.ZERO));
        assertEquals(-1500, DurationUtils.toMillisInt(Duration.ofMillis(-1500)));
    }

    @Test
    void testToMillisIntClampsToIntegerMaxValue() {
        final Duration duration = Duration.ofMillis(3000000000L);
        assertEquals(Integer.MAX_VALUE, DurationUtils.toMillisInt(duration));
    }

    @Test
    void testToMillisIntClampsToIntegerMinValue() {
        final Duration duration = Duration.ofMillis(-3000000000L);
        assertEquals(Integer.MIN_VALUE, DurationUtils.toMillisInt(duration));
    }

    @Test
    void testToMillisIntNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationUtils.toMillisInt(null);
            }
        });
    }

    @Test
    void testToMillisLongNormal() {
        assertEquals(1500L, DurationUtils.toMillisLong(Duration.ofMillis(1500)));
        assertEquals(0L, DurationUtils.toMillisLong(Duration.ZERO));
        assertEquals(-1500L, DurationUtils.toMillisLong(Duration.ofMillis(-1500)));
    }

    @Test
    void testToMillisLongClampsToLongMaxValueOnOverflow() {
        final Duration duration = Duration.ofSeconds(Long.MAX_VALUE);
        assertEquals(Long.MAX_VALUE, DurationUtils.toMillisLong(duration));
    }

    @Test
    void testToMillisLongClampsToLongMinValueOnOverflow() {
        final Duration duration = Duration.ofSeconds(Long.MIN_VALUE);
        assertEquals(Long.MIN_VALUE, DurationUtils.toMillisLong(duration));
    }

    @Test
    void testToMillisLongNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                DurationUtils.toMillisLong(null);
            }
        });
    }

    @Test
    void testZeroIfNull() {
        assertSame(Duration.ZERO, DurationUtils.zeroIfNull(null));
        final Duration duration = Duration.ofMillis(42);
        assertSame(duration, DurationUtils.zeroIfNull(duration));
    }

    @Test
    void testConstructor() {
        assertNotNull(new DurationUtils());
    }
}
