/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.cli;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Collection;
import java.util.List;

import org.junit.jupiter.api.Test;

class OptionsAgentTest {

    @Test
    void testAddOptionInstanceReturnsSameInstance() {
        final Options options = new Options();
        final Option opt = new Option("a", "alpha", false, "alpha option");
        final Options returned = options.addOption(opt);
        assertSame(options, returned);
        assertTrue(options.hasOption("a"));
        assertTrue(options.hasOption("alpha"));
    }

    @Test
    void testAddOptionShortOnly() {
        final Options options = new Options();
        options.addOption("a", true, "has an argument");
        final Option opt = options.getOption("a");
        assertNotNull(opt);
        assertTrue(opt.hasArg());
        assertEquals("has an argument", opt.getDescription());
        assertFalse(opt.hasLongOpt());
    }

    @Test
    void testAddOptionShortNoArg() {
        final Options options = new Options();
        options.addOption("b", "boolean flag");
        final Option opt = options.getOption("b");
        assertNotNull(opt);
        assertFalse(opt.hasArg());
        assertEquals("boolean flag", opt.getDescription());
    }

    @Test
    void testAddOptionShortAndLong() {
        final Options options = new Options();
        options.addOption("c", "charlie", true, "charlie option");
        assertTrue(options.hasShortOption("c"));
        assertTrue(options.hasLongOption("charlie"));
        final Option byShort = options.getOption("c");
        final Option byLong = options.getOption("charlie");
        assertSame(byShort, byLong);
    }

    @Test
    void testAddOptionWithLeadingHyphensIsStrippedOnLookup() {
        final Options options = new Options();
        options.addOption("d", "delta", false, "delta option");
        assertTrue(options.hasOption("-d"));
        assertTrue(options.hasOption("--delta"));
        assertNotNull(options.getOption("--delta"));
        assertNotNull(options.getOption("-d"));
    }

    @Test
    void testGetOptionReturnsNullWhenAbsent() {
        final Options options = new Options();
        assertNull(options.getOption("z"));
    }

    @Test
    void testHasOptionFalseForUnknown() {
        final Options options = new Options();
        options.addOption("a", false, "a option");
        assertFalse(options.hasOption("x"));
        assertFalse(options.hasShortOption("alpha"));
        assertFalse(options.hasLongOption("a"));
    }

    @Test
    void testAddRequiredOptionIsTrackedAsRequired() {
        final Options options = new Options();
        final Options returned = options.addRequiredOption("r", "required", true, "a required option");
        assertSame(options, returned);
        final List<?> required = options.getRequiredOptions();
        assertEquals(1, required.size());
        assertEquals("r", required.get(0));
        assertTrue(options.getOption("r").isRequired());
    }

    @Test
    void testAddOptionRequiredNotDuplicatedInRequiredList() {
        final Options options = new Options();
        final Option opt1 = new Option("r", "requiredOpt");
        opt1.setRequired(true);
        options.addOption(opt1);
        final Option opt2 = new Option("r", "requiredOpt");
        opt2.setRequired(true);
        options.addOption(opt2);
        final List<?> required = options.getRequiredOptions();
        assertEquals(1, required.size());
    }

    @Test
    void testGetRequiredOptionsIsUnmodifiable() {
        final Options options = new Options();
        options.addRequiredOption("r", "required", false, "desc");
        final List<?> required = options.getRequiredOptions();
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                required.clear();
            }
        });
    }

    @Test
    void testGetOptionsIsUnmodifiable() {
        final Options options = new Options();
        options.addOption("a", false, "desc");
        final Collection<Option> opts = options.getOptions();
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                opts.clear();
            }
        });
    }

    @Test
    void testGetOptionsReturnsAllAddedOptions() {
        final Options options = new Options();
        options.addOption("a", false, "desc a");
        options.addOption("b", false, "desc b");
        final Collection<Option> opts = options.getOptions();
        assertEquals(2, opts.size());
    }

    @Test
    void testGetOptionsEmptyWhenNoneAdded() {
        final Options options = new Options();
        assertTrue(options.getOptions().isEmpty());
        assertTrue(options.getRequiredOptions().isEmpty());
    }

    @Test
    void testAddOptionGroupSetsOptionsNotRequiredIndividually() {
        final Options options = new Options();
        final OptionGroup group = new OptionGroup();
        final Option opt1 = new Option("x", "xray");
        opt1.setRequired(true);
        final Option opt2 = new Option("y", "yankee");
        group.addOption(opt1);
        group.addOption(opt2);
        group.setRequired(true);

        final Options returned = options.addOptionGroup(group);
        assertSame(options, returned);

        assertFalse(options.getOption("x").isRequired());
        assertFalse(options.getOption("y").isRequired());
        assertTrue(options.getRequiredOptions().contains(group));
        assertFalse(options.getRequiredOptions().contains("x"));
    }

    @Test
    void testAddOptionGroupNotRequired() {
        final Options options = new Options();
        final OptionGroup group = new OptionGroup();
        group.addOption(new Option("x", "xray"));
        options.addOptionGroup(group);
        assertTrue(options.getRequiredOptions().isEmpty());
        assertSame(group, options.getOptionGroup(options.getOption("x")));
    }

    @Test
    void testGetOptionGroupReturnsNullWhenNotInGroup() {
        final Options options = new Options();
        options.addOption("a", false, "desc");
        assertNull(options.getOptionGroup(options.getOption("a")));
    }

    @Test
    void testAddOptionsCopiesOptionsAndGroups() {
        final Options source = new Options();
        source.addOption("a", false, "desc a");
        final OptionGroup group = new OptionGroup();
        group.addOption(new Option("x", "xray"));
        source.addOptionGroup(group);

        final Options target = new Options();
        final Options returned = target.addOptions(source);
        assertSame(target, returned);
        assertTrue(target.hasOption("a"));
        assertTrue(target.hasOption("x"));
        assertNotNull(target.getOptionGroup(target.getOption("x")));
    }

    @Test
    void testAddOptionsThrowsOnDuplicateKey() {
        final Options source = new Options();
        source.addOption("a", false, "desc a");

        final Options target = new Options();
        target.addOption("a", true, "other desc a");

        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                target.addOptions(source);
            }
        });
    }

    @Test
    void testGetMatchingOptionsExactMatch() {
        final Options options = new Options();
        options.addOption("a", "alpha", false, "desc");
        options.addOption("b", "alphabet", false, "desc");
        final List<String> matches = options.getMatchingOptions("alpha");
        assertEquals(1, matches.size());
        assertEquals("alpha", matches.get(0));
    }

    @Test
    void testGetMatchingOptionsPartialMatches() {
        final Options options = new Options();
        options.addOption("a", "alpha", false, "desc");
        options.addOption("b", "alphabet", false, "desc");
        options.addOption("c", "beta", false, "desc");
        final List<String> matches = options.getMatchingOptions("al");
        assertEquals(2, matches.size());
        assertTrue(matches.contains("alpha"));
        assertTrue(matches.contains("alphabet"));
    }

    @Test
    void testGetMatchingOptionsNoMatches() {
        final Options options = new Options();
        options.addOption("a", "alpha", false, "desc");
        final List<String> matches = options.getMatchingOptions("zzz");
        assertTrue(matches.isEmpty());
    }

    @Test
    void testGetMatchingOptionsStripsLeadingHyphens() {
        final Options options = new Options();
        options.addOption("a", "alpha", false, "desc");
        final List<String> matches = options.getMatchingOptions("--alpha");
        assertEquals(1, matches.size());
        assertEquals("alpha", matches.get(0));
    }

    @Test
    void testHelpOptionsReturnsShortOptionsInInsertionOrder() {
        final Options options = new Options();
        final Option first = new Option("a", "alpha", false, "desc");
        final Option second = new Option("b", "beta", false, "desc");
        options.addOption(first);
        options.addOption(second);
        final List<Option> help = options.helpOptions();
        assertEquals(2, help.size());
        assertSame(first, help.get(0));
        assertSame(second, help.get(1));
    }

    @Test
    void testGetOptionGroupsReturnsDistinctGroups() {
        final Options options = new Options();
        final OptionGroup group = new OptionGroup();
        group.addOption(new Option("x", "xray"));
        group.addOption(new Option("y", "yankee"));
        options.addOptionGroup(group);
        final Collection<OptionGroup> groups = options.getOptionGroups();
        assertEquals(1, groups.size());
        assertTrue(groups.contains(group));
    }

    @Test
    void testToStringContainsShortAndLongSections() {
        final Options options = new Options();
        options.addOption("a", "alpha", false, "desc");
        final String str = options.toString();
        assertTrue(str.contains("[ Options: [ short "));
        assertTrue(str.contains("[ long"));
        assertTrue(str.contains("alpha"));
    }

    @Test
    void testToStringOnEmptyOptions() {
        final Options options = new Options();
        final String str = options.toString();
        assertNotNull(str);
        assertTrue(str.startsWith("[ Options: [ short "));
    }
}
