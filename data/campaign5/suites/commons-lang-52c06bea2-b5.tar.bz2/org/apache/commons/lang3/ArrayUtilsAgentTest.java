/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.BitSet;
import java.util.Comparator;
import java.util.Random;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link ArrayUtils}.
 */
class ArrayUtilsAgentTest {

    private static final class Box {
        private final int value;

        Box(final int value) {
            this.value = value;
        }

        @Override
        public boolean equals(final Object obj) {
            return obj instanceof Box && ((Box) obj).value == value;
        }

        @Override
        public int hashCode() {
            return value;
        }

        @Override
        public String toString() {
            return "Box(" + value + ")";
        }
    }

    // ---------------------------------------------------------------
    // isEmpty / isNotEmpty
    // ---------------------------------------------------------------

    @Test
    void testIsEmptyIsNotEmptyPrimitives() {
        assertTrue(ArrayUtils.isEmpty((boolean[]) null));
        assertTrue(ArrayUtils.isEmpty(new boolean[0]));
        assertFalse(ArrayUtils.isEmpty(new boolean[] { true }));
        assertFalse(ArrayUtils.isNotEmpty((boolean[]) null));
        assertTrue(ArrayUtils.isNotEmpty(new boolean[] { true }));

        assertTrue(ArrayUtils.isEmpty((int[]) null));
        assertTrue(ArrayUtils.isEmpty(new int[0]));
        assertTrue(ArrayUtils.isNotEmpty(new int[] { 1 }));

        assertTrue(ArrayUtils.isEmpty((Object[]) null));
        assertTrue(ArrayUtils.isEmpty(new Object[0]));
        assertTrue(ArrayUtils.isNotEmpty(new Object[] { "a" }));
    }

    // ---------------------------------------------------------------
    // getLength
    // ---------------------------------------------------------------

    @Test
    void testGetLength() {
        assertEquals(0, ArrayUtils.getLength(null));
        assertEquals(0, ArrayUtils.getLength(new int[0]));
        assertEquals(3, ArrayUtils.getLength(new int[] { 1, 2, 3 }));
        assertEquals(2, ArrayUtils.getLength(new String[] { "a", "b" }));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ArrayUtils.getLength("not an array");
            }
        });
    }

    // ---------------------------------------------------------------
    // contains / containsAny
    // ---------------------------------------------------------------

    @Test
    void testContains() {
        assertFalse(ArrayUtils.contains((int[]) null, 1));
        assertTrue(ArrayUtils.contains(new int[] { 1, 2, 3 }, 2));
        assertFalse(ArrayUtils.contains(new int[] { 1, 2, 3 }, 4));

        assertTrue(ArrayUtils.contains(new Object[] { "a", null, "b" }, null));
        assertFalse(ArrayUtils.contains((Object[]) null, "a"));

        assertTrue(ArrayUtils.contains(new double[] { 1.0, 2.0 }, 2.05, 0.1));
        assertFalse(ArrayUtils.contains(new double[] { 1.0, 2.0 }, 2.5, 0.1));
    }

    @Test
    void testContainsAny() {
        assertTrue(ArrayUtils.containsAny(new int[] { 1, 2, 3 }, 5, 2));
        assertFalse(ArrayUtils.containsAny(new int[] { 1, 2, 3 }, 5, 6));
        assertFalse(ArrayUtils.containsAny((int[]) null, 1));

        assertTrue(ArrayUtils.containsAny(new Object[] { "a", "b" }, "x", "b"));
        assertFalse(ArrayUtils.containsAny(new Object[] { "a", "b" }, (Object[]) null));
    }

    // ---------------------------------------------------------------
    // indexOf / lastIndexOf / indexesOf
    // ---------------------------------------------------------------

    @Test
    void testIndexOfLastIndexOf() {
        final int[] array = { 1, 2, 3, 2, 1 };
        assertEquals(1, ArrayUtils.indexOf(array, 2));
        assertEquals(3, ArrayUtils.lastIndexOf(array, 2));
        assertEquals(-1, ArrayUtils.indexOf(array, 9));
        assertEquals(-1, ArrayUtils.indexOf((int[]) null, 9));
        assertEquals(3, ArrayUtils.indexOf(array, 2, 2));
        assertEquals(-1, ArrayUtils.indexOf(array, 2, 10));
        assertEquals(1, ArrayUtils.lastIndexOf(array, 2, 2));
        assertEquals(-1, ArrayUtils.lastIndexOf(array, 2, -1));
    }

    @Test
    void testIndexOfObjectWithNull() {
        final Object[] array = { "a", null, "b", null };
        assertEquals(1, ArrayUtils.indexOf(array, null));
        assertEquals(3, ArrayUtils.lastIndexOf(array, null));
        assertEquals(-1, ArrayUtils.indexOf(array, "z"));
    }

    @Test
    void testIndexesOf() {
        final int[] array = { 1, 2, 1, 3, 1 };
        final BitSet bits = ArrayUtils.indexesOf(array, 1);
        assertEquals(3, bits.cardinality());
        assertTrue(bits.get(0));
        assertTrue(bits.get(2));
        assertTrue(bits.get(4));
        assertFalse(bits.get(1));

        final BitSet fromStart = ArrayUtils.indexesOf(array, 1, 1);
        assertEquals(2, fromStart.cardinality());
        assertFalse(fromStart.get(0));
    }

    // ---------------------------------------------------------------
    // isArrayIndexValid
    // ---------------------------------------------------------------

    @Test
    void testIsArrayIndexValid() {
        assertFalse(ArrayUtils.isArrayIndexValid(null, 0));
        assertFalse(ArrayUtils.isArrayIndexValid(new String[0], 0));
        assertTrue(ArrayUtils.isArrayIndexValid(new String[] { "a" }, 0));
        assertFalse(ArrayUtils.isArrayIndexValid(new String[] { "a" }, 1));
        assertFalse(ArrayUtils.isArrayIndexValid(new String[] { "a" }, -1));
    }

    // ---------------------------------------------------------------
    // get
    // ---------------------------------------------------------------

    @Test
    void testGet() {
        final String[] array = { "a", "b" };
        assertEquals("a", ArrayUtils.get(array, 0));
        assertNull(ArrayUtils.get(array, 5));
        assertNull(ArrayUtils.get(array, -1));
        assertEquals("default", ArrayUtils.get(array, 5, "default"));
        assertEquals("b", ArrayUtils.get(array, 1, "default"));
    }

    // ---------------------------------------------------------------
    // isSameLength / isSameType
    // ---------------------------------------------------------------

    @Test
    void testIsSameLength() {
        assertTrue(ArrayUtils.isSameLength(new int[] { 1, 2 }, new int[] { 3, 4 }));
        assertFalse(ArrayUtils.isSameLength(new int[] { 1, 2 }, new int[] { 3 }));
        assertTrue(ArrayUtils.isSameLength((int[]) null, (int[]) null));
        assertFalse(ArrayUtils.isSameLength(new int[] { 1 }, null));

        assertTrue(ArrayUtils.isSameLength(new Object[] { "a" }, new Object[] { "b" }));
        assertFalse(ArrayUtils.isSameLength(new Object[] { "a" }, new Object[] { "b", "c" }));
    }

    @Test
    void testIsSameType() {
        assertTrue(ArrayUtils.isSameType(new int[0], new int[0]));
        assertFalse(ArrayUtils.isSameType(new int[0], new long[0]));
        assertFalse(ArrayUtils.isSameType(new String[0], new Object[0]));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ArrayUtils.isSameType(null, new int[0]);
            }
        });
    }

    // ---------------------------------------------------------------
    // isSorted
    // ---------------------------------------------------------------

    @Test
    void testIsSorted() {
        assertTrue(ArrayUtils.isSorted(new int[] { 1, 2, 3 }));
        assertFalse(ArrayUtils.isSorted(new int[] { 3, 2, 1 }));
        assertTrue(ArrayUtils.isSorted(new int[0]));
        assertTrue(ArrayUtils.isSorted((int[]) null));

        final Integer[] boxed = { 1, 2, 3 };
        assertTrue(ArrayUtils.isSorted(boxed));

        final Comparator<Integer> reverseComparator = new Comparator<Integer>() {
            @Override
            public int compare(final Integer a, final Integer b) {
                return b.compareTo(a);
            }
        };
        assertFalse(ArrayUtils.isSorted(boxed, reverseComparator));
        assertTrue(ArrayUtils.isSorted(new Integer[] { 3, 2, 1 }, reverseComparator));
    }

    // ---------------------------------------------------------------
    // nullToEmpty
    // ---------------------------------------------------------------

    @Test
    void testNullToEmpty() {
        assertSame(ArrayUtils.EMPTY_INT_ARRAY, ArrayUtils.nullToEmpty((int[]) null));
        assertSame(ArrayUtils.EMPTY_STRING_ARRAY, ArrayUtils.nullToEmpty((String[]) null));
        assertSame(ArrayUtils.EMPTY_BOOLEAN_ARRAY, ArrayUtils.nullToEmpty((boolean[]) null));

        final int[] original = { 1, 2 };
        assertSame(original, ArrayUtils.nullToEmpty(original));

        assertArrayEquals(new String[] { "a" }, ArrayUtils.nullToEmpty(new String[] { "a" }));
    }

    // ---------------------------------------------------------------
    // removeAllOccurrences
    // ---------------------------------------------------------------

    @Test
    void testRemoveAllOccurrences() {
        final int[] array = { 1, 2, 1, 3, 1 };
        final int[] result = ArrayUtils.removeAllOccurrences(array, 1);
        assertArrayEquals(new int[] { 2, 3 }, result);
        assertEquals(5, array.length, "original array must not be mutated");

        final int[] noMatch = ArrayUtils.removeAllOccurrences(new int[] { 1, 2 }, 9);
        assertArrayEquals(new int[] { 1, 2 }, noMatch);

        final String[] objArray = { "a", "b", "a" };
        assertArrayEquals(new String[] { "b" }, ArrayUtils.removeAllOccurrences(objArray, "a"));
    }

    // ---------------------------------------------------------------
    // reverse
    // ---------------------------------------------------------------

    @Test
    void testReverseFull() {
        final int[] array = { 1, 2, 3, 4, 5 };
        ArrayUtils.reverse(array);
        assertArrayEquals(new int[] { 5, 4, 3, 2, 1 }, array);

        // Null and empty must not throw.
        ArrayUtils.reverse((int[]) null);
        final int[] empty = {};
        ArrayUtils.reverse(empty);
        assertArrayEquals(new int[0], empty);
    }

    @Test
    void testReverseRange() {
        final int[] array = { 1, 2, 3, 4, 5 };
        ArrayUtils.reverse(array, 1, 4);
        assertArrayEquals(new int[] { 1, 4, 3, 2, 5 }, array);

        // Undervalue start index is promoted to 0.
        final int[] array2 = { 1, 2, 3 };
        ArrayUtils.reverse(array2, -5, 3);
        assertArrayEquals(new int[] { 3, 2, 1 }, array2);

        // Overvalue end index is demoted to array length, no exception.
        final int[] array3 = { 1, 2, 3 };
        ArrayUtils.reverse(array3, 0, 100);
        assertArrayEquals(new int[] { 3, 2, 1 }, array3);
    }

    // ---------------------------------------------------------------
    // shift
    // ---------------------------------------------------------------

    @Test
    void testShift() {
        final int[] array = { 1, 2, 3, 4, 5 };
        ArrayUtils.shift(array, 2);
        assertArrayEquals(new int[] { 4, 5, 1, 2, 3 }, array);

        final int[] array2 = { 1, 2, 3, 4, 5 };
        // Offset larger than length wraps via modulo.
        ArrayUtils.shift(array2, 7);
        assertArrayEquals(new int[] { 4, 5, 1, 2, 3 }, array2);

        final int[] array3 = { 1, 2, 3 };
        ArrayUtils.shift(array3, 0);
        assertArrayEquals(new int[] { 1, 2, 3 }, array3);

        // Null and empty must not throw.
        ArrayUtils.shift((int[]) null, 2);
        ArrayUtils.shift(new int[0], 2);
    }

    // ---------------------------------------------------------------
    // shuffle
    // ---------------------------------------------------------------

    @Test
    void testShuffle() {
        final int[] array = { 1, 2, 3, 4, 5 };
        final int[] copy = array.clone();
        ArrayUtils.shuffle(array, new Random(42));
        assertEquals(copy.length, array.length);
        final int[] sortedOriginal = copy.clone();
        final int[] sortedShuffled = array.clone();
        java.util.Arrays.sort(sortedOriginal);
        java.util.Arrays.sort(sortedShuffled);
        assertArrayEquals(sortedOriginal, sortedShuffled, "shuffle must be a permutation of the same elements");
    }

    // ---------------------------------------------------------------
    // startsWith
    // ---------------------------------------------------------------

    @Test
    void testStartsWith() {
        assertTrue(ArrayUtils.startsWith(new byte[] { 1, 2, 3 }, new byte[] { 1, 2 }));
        assertFalse(ArrayUtils.startsWith(new byte[] { 1, 2, 3 }, new byte[] { 2, 3 }));
        assertTrue(ArrayUtils.startsWith(new byte[] { 1, 2 }, new byte[] { 1, 2 }));
        assertFalse(ArrayUtils.startsWith(new byte[] { 1 }, new byte[] { 1, 2 }));
        assertFalse(ArrayUtils.startsWith(null, new byte[] { 1 }));
        assertFalse(ArrayUtils.startsWith(new byte[] { 1 }, null));
        final byte[] same = { 1, 2 };
        assertTrue(ArrayUtils.startsWith(same, same));
    }

    // ---------------------------------------------------------------
    // subarray
    // ---------------------------------------------------------------

    @Test
    void testSubarray() {
        final int[] array = { 0, 1, 2, 3, 4 };
        assertArrayEquals(new int[] { 1, 2, 3 }, ArrayUtils.subarray(array, 1, 4));
        assertNull(ArrayUtils.subarray((int[]) null, 0, 2));

        // Overvalue end index is demoted, no exception.
        assertArrayEquals(new int[] { 3, 4 }, ArrayUtils.subarray(array, 3, 100));

        // Undervalue start index is promoted to 0.
        assertArrayEquals(new int[] { 0, 1 }, ArrayUtils.subarray(array, -5, 2));

        // End before start produces an empty array, not an exception.
        assertArrayEquals(new int[0], ArrayUtils.subarray(array, 3, 1));
    }

    // ---------------------------------------------------------------
    // swap
    // ---------------------------------------------------------------

    @Test
    void testSwap() {
        final int[] array = { 1, 2, 3 };
        ArrayUtils.swap(array, 0, 2);
        assertArrayEquals(new int[] { 3, 2, 1 }, array);

        // Out-of-range offset is a no-op, not an exception.
        final int[] array2 = { 1, 2, 3 };
        ArrayUtils.swap(array2, 0, 5);
        assertArrayEquals(new int[] { 1, 2, 3 }, array2);

        // Negative offset is promoted to 0.
        final int[] array3 = { 1, 2, 3 };
        ArrayUtils.swap(array3, -1, 2);
        assertArrayEquals(new int[] { 3, 2, 1 }, array3);

        final int[] array4 = { 1, 2, 3, 4 };
        ArrayUtils.swap(array4, 0, 2, 2);
        assertArrayEquals(new int[] { 3, 4, 1, 2 }, array4);

        // Null and empty must not throw.
        ArrayUtils.swap((int[]) null, 0, 1);
        ArrayUtils.swap(new int[0], 0, 1);
    }

    // ---------------------------------------------------------------
    // toArray
    // ---------------------------------------------------------------

    @Test
    void testToArray() {
        final String[] array = ArrayUtils.toArray("a", "b", "c");
        assertArrayEquals(new String[] { "a", "b", "c" }, array);
    }

    // ---------------------------------------------------------------
    // toObject / toPrimitive
    // ---------------------------------------------------------------

    @Test
    void testToObjectToPrimitiveRoundTrip() {
        final int[] primitives = { 1, 2, 3 };
        final Integer[] objects = ArrayUtils.toObject(primitives);
        assertArrayEquals(new Integer[] { 1, 2, 3 }, objects);
        final int[] roundTrip = ArrayUtils.toPrimitive(objects);
        assertArrayEquals(primitives, roundTrip);

        assertNull(ArrayUtils.toObject((int[]) null));
        assertNull(ArrayUtils.toPrimitive((Integer[]) null));

        final boolean[] boolPrimitives = { true, false };
        assertArrayEquals(new Boolean[] { Boolean.TRUE, Boolean.FALSE }, ArrayUtils.toObject(boolPrimitives));
    }

    @Test
    void testToPrimitiveWithNullElementThrows() {
        final Integer[] withNull = { 1, null, 3 };
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ArrayUtils.toPrimitive(withNull);
            }
        });
    }

    @Test
    void testToPrimitiveWithDefaultForNull() {
        final Integer[] withNull = { 1, null, 3 };
        assertArrayEquals(new int[] { 1, -1, 3 }, ArrayUtils.toPrimitive(withNull, -1));
    }

    @Test
    void testToPrimitiveObjectOverload() {
        final Integer[] boxed = { 1, 2, 3 };
        final Object result = ArrayUtils.toPrimitive((Object) boxed);
        assertTrue(result instanceof int[]);
        assertArrayEquals(new int[] { 1, 2, 3 }, (int[]) result);

        assertNull(ArrayUtils.toPrimitive((Object) null));

        final String[] strings = { "a", "b" };
        assertSame(strings, ArrayUtils.toPrimitive((Object) strings));
    }

    // ---------------------------------------------------------------
    // toStringArray
    // ---------------------------------------------------------------

    @Test
    void testToStringArray() {
        assertArrayEquals(new String[] { "a", "1" }, ArrayUtils.toStringArray(new Object[] { "a", 1 }));
        assertArrayEquals(new String[] { "a", "null" }, ArrayUtils.toStringArray(new Object[] { "a", null }));
        assertArrayEquals(new String[] { "a", "NULL" }, ArrayUtils.toStringArray(new Object[] { "a", null }, "NULL"));
        assertNull(ArrayUtils.toStringArray(null));
        assertArrayEquals(new String[0], ArrayUtils.toStringArray(new Object[0]));
    }

    // ---------------------------------------------------------------
    // hashCode / isEquals
    // ---------------------------------------------------------------

    @Test
    void testHashCode() {
        assertEquals(ArrayUtils.hashCode(null), ArrayUtils.hashCode(null), "hash of null must be consistent");
        final int[] array1 = { 1, 2, 3 };
        final int[] array2 = { 1, 2, 3 };
        assertEquals(ArrayUtils.hashCode(array1), ArrayUtils.hashCode(array2));
        assertTrue(ArrayUtils.hashCode(array1) != ArrayUtils.hashCode(new int[] { 3, 2, 1 }));
    }

    @Test
    @SuppressWarnings("deprecation")
    void testIsEquals() {
        assertTrue(ArrayUtils.isEquals(null, null));
        assertFalse(ArrayUtils.isEquals(new int[] { 1 }, null));
        assertTrue(ArrayUtils.isEquals(new int[] { 1, 2 }, new int[] { 1, 2 }));
        assertFalse(ArrayUtils.isEquals(new int[] { 1, 2 }, new int[] { 2, 1 }));
    }

    // ---------------------------------------------------------------
    // clone
    // ---------------------------------------------------------------

    @Test
    void testClone() {
        assertNull(ArrayUtils.clone((int[]) null));

        final int[] array = { 1, 2, 3 };
        final int[] cloned = ArrayUtils.clone(array);
        assertArrayEquals(array, cloned);
        assertNotNull(cloned);
        assertTrue(array != cloned, "clone must return a new array instance");

        final String[] objArray = { "a", "b" };
        final String[] clonedObj = ArrayUtils.clone(objArray);
        assertArrayEquals(objArray, clonedObj);
        assertTrue(objArray != clonedObj);
    }

    // ---------------------------------------------------------------
    // newInstance / getComponentType
    // ---------------------------------------------------------------

    @Test
    void testNewInstance() {
        final String[] array = ArrayUtils.newInstance(String.class, 3);
        assertEquals(3, array.length);
        assertNull(array[0]);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ArrayUtils.newInstance(null, 3);
            }
        });
    }

    @Test
    void testGetComponentType() {
        assertEquals(String.class, ArrayUtils.getComponentType(new String[0]));
        assertNull(ArrayUtils.getComponentType((Object[]) null));
    }

    // ---------------------------------------------------------------
    // Equality with a custom type
    // ---------------------------------------------------------------

    @Test
    void testContainsWithCustomEquals() {
        final Box[] boxes = { new Box(1), new Box(2) };
        assertTrue(ArrayUtils.contains(boxes, new Box(2)));
        assertFalse(ArrayUtils.contains(boxes, new Box(3)));
    }
}
