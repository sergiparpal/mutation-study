/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link FastDateParser}.
 */
class FastDateParserAgentTest {

    private static final TimeZone NEW_YORK = TimeZone.getTimeZone("America/New_York");

    @Test
    void testParseSimplePattern() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", NEW_YORK, Locale.US);
        final Date date = parser.parse("2021-03-15");
        final Calendar calendar = Calendar.getInstance(NEW_YORK, Locale.US);
        calendar.setTime(date);
        assertEquals(2021, calendar.get(Calendar.YEAR));
        assertEquals(Calendar.MARCH, calendar.get(Calendar.MONTH));
        assertEquals(15, calendar.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testGetPatternLocaleTimeZone() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", NEW_YORK, Locale.US);
        assertEquals("yyyy-MM-dd", parser.getPattern());
        assertEquals(Locale.US, parser.getLocale());
        assertEquals(NEW_YORK, parser.getTimeZone());
    }

    @Test
    void testGetTimeZoneReturnsClone() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", NEW_YORK, Locale.US);
        final TimeZone returned = parser.getTimeZone();
        assertEquals(NEW_YORK, returned);
        assertNotEquals(System.identityHashCode(NEW_YORK), System.identityHashCode(returned));
    }

    @Test
    void testNullPatternThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new FastDateParser(null, NEW_YORK, Locale.US);
            }
        });
    }

    @Test
    void testNullTimeZoneThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new FastDateParser("yyyy-MM-dd", null, Locale.US);
            }
        });
    }

    @Test
    void testNullLocaleFallsBackToDefault() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", NEW_YORK, null);
        assertEquals(Locale.getDefault(), parser.getLocale());
    }

    @Test
    void testUnsupportedPatternLetterThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new FastDateParser("yyyy-qq-dd", NEW_YORK, Locale.US);
            }
        });
        assertTrue(ex.getMessage().contains("not supported"));
    }

    @Test
    void testUnterminatedQuoteThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new FastDateParser("yyyy'bad", NEW_YORK, Locale.US);
            }
        });
        assertEquals("Unterminated quote", ex.getMessage());
    }

    @Test
    void testParseUnparseableStringThrowsParseException() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", NEW_YORK, Locale.US);
        final ParseException ex = assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws ParseException {
                parser.parse("not-a-date");
            }
        });
        assertTrue(ex.getMessage().contains("Unparseable date"));
        assertEquals(0, ex.getErrorOffset());
    }

    @Test
    void testParseWithPositionNullOnFailure() {
        final FastDateParser parser = new FastDateParser("MM/dd/yyyy", NEW_YORK, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("garbage", pos);
        assertNull(date);
        assertEquals(0, pos.getErrorIndex());
    }

    @Test
    void testParsePositionBeyondSourceLength() {
        final FastDateParser parser = new FastDateParser("MM/dd/yyyy", NEW_YORK, Locale.US);
        final ParsePosition pos = new ParsePosition(100);
        final Date date = parser.parse("03/23/1961", pos);
        assertNull(date);
        assertEquals(100, pos.getErrorIndex());
    }

    @Test
    void testParseIntoProvidedCalendar() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", NEW_YORK, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Calendar calendar = Calendar.getInstance(NEW_YORK, Locale.US);
        calendar.clear();
        final boolean result = parser.parse("1999-12-31", pos, calendar);
        assertTrue(result);
        assertEquals(10, pos.getIndex());
        assertEquals(1999, calendar.get(Calendar.YEAR));
        assertEquals(Calendar.DECEMBER, calendar.get(Calendar.MONTH));
        assertEquals(31, calendar.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseObjectString() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", NEW_YORK, Locale.US);
        final Object obj = parser.parseObject("2020-01-02");
        assertTrue(obj instanceof Date);
        final Calendar calendar = Calendar.getInstance(NEW_YORK, Locale.US);
        calendar.setTime((Date) obj);
        assertEquals(2020, calendar.get(Calendar.YEAR));
    }

    @Test
    void testParseObjectWithPosition() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", NEW_YORK, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Object obj = parser.parseObject("2020-01-02", pos);
        assertNotNull(obj);
        assertEquals(10, pos.getIndex());
    }

    @Test
    void testTwoDigitYearAdjustmentWithoutCenturyStart() throws ParseException {
        final FastDateParser parser = new FastDateParser("MM/dd/yy", NEW_YORK, Locale.US);
        final Calendar calendar = Calendar.getInstance(NEW_YORK, Locale.US);
        calendar.setTime(parser.parse("01/01/50"));
        final int yearNow = Calendar.getInstance().get(Calendar.YEAR);
        final int parsedYear = calendar.get(Calendar.YEAR);
        // Two-digit years resolve within the ~100-year window anchored 80 years before now.
        assertTrue(parsedYear >= yearNow - 80 && parsedYear < yearNow + 20);
    }

    @Test
    void testTwoDigitYearAdjustmentWithExplicitCenturyStart() throws ParseException {
        final Calendar centuryStartCal = Calendar.getInstance(NEW_YORK, Locale.US);
        centuryStartCal.clear();
        centuryStartCal.set(1950, Calendar.JANUARY, 1);
        final FastDateParser parser = new FastDateParser("MM/dd/yy", NEW_YORK, Locale.US, centuryStartCal.getTime());

        final Calendar below = Calendar.getInstance(NEW_YORK, Locale.US);
        below.setTime(parser.parse("01/01/49"));
        assertEquals(2049, below.get(Calendar.YEAR));

        final Calendar atOrAbove = Calendar.getInstance(NEW_YORK, Locale.US);
        atOrAbove.setTime(parser.parse("01/01/50"));
        assertEquals(1950, atOrAbove.get(Calendar.YEAR));
    }

    @Test
    void testLiteralFourDigitYearNotAdjusted() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy", NEW_YORK, Locale.US);
        final Calendar calendar = Calendar.getInstance(NEW_YORK, Locale.US);
        calendar.setTime(parser.parse("0099"));
        assertEquals(99, calendar.get(Calendar.YEAR));
    }

    @Test
    void testEqualsAndHashCode() {
        final FastDateParser a = new FastDateParser("yyyy-MM-dd", NEW_YORK, Locale.US);
        final FastDateParser b = new FastDateParser("yyyy-MM-dd", NEW_YORK, Locale.US);
        final FastDateParser diffPattern = new FastDateParser("yyyy/MM/dd", NEW_YORK, Locale.US);
        final FastDateParser diffZone = new FastDateParser("yyyy-MM-dd", TimeZone.getTimeZone("UTC"), Locale.US);

        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
        assertNotEquals(a, diffPattern);
        assertNotEquals(a, diffZone);
        assertFalse(a.equals(null));
        assertFalse(a.equals("yyyy-MM-dd"));
        assertTrue(a.equals(a));
    }

    @Test
    void testToStringContainsPatternLocaleAndZone() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", NEW_YORK, Locale.US);
        final String str = parser.toString();
        assertTrue(str.contains("yyyy-MM-dd"));
        assertTrue(str.contains(NEW_YORK.getID()));
    }

    @Test
    void testToStringAllContainsPattern() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", NEW_YORK, Locale.US);
        final String str = parser.toStringAll();
        assertTrue(str.contains("yyyy-MM-dd"));
        assertTrue(str.contains("pattern="));
    }

    @Test
    void testSerializationRoundTrip() throws Exception {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd'T'HH:mm:ss", NEW_YORK, Locale.US);
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        final ObjectOutputStream oos = new ObjectOutputStream(baos);
        oos.writeObject(parser);
        oos.close();

        final ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(baos.toByteArray()));
        final FastDateParser restored = (FastDateParser) ois.readObject();
        ois.close();

        assertEquals(parser, restored);
        assertEquals(parser.getPattern(), restored.getPattern());
        final Date parsed = restored.parse("2022-07-04T10:20:30");
        final Calendar calendar = Calendar.getInstance(NEW_YORK, Locale.US);
        calendar.setTime(parsed);
        assertEquals(2022, calendar.get(Calendar.YEAR));
        assertEquals(Calendar.JULY, calendar.get(Calendar.MONTH));
        assertEquals(4, calendar.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testDayOfWeekTextStrategy() throws ParseException {
        final FastDateParser parser = new FastDateParser("EEEE, MM/dd/yyyy", NEW_YORK, Locale.US);
        final Date date = parser.parse("Thursday, 03/23/1961");
        final Calendar calendar = Calendar.getInstance(NEW_YORK, Locale.US);
        calendar.setTime(date);
        assertEquals(Calendar.THURSDAY, calendar.get(Calendar.DAY_OF_WEEK));
    }

    @Test
    void testInvalidDayOfWeekNameFails() {
        final FastDateParser parser = new FastDateParser("EEEE, MM/dd/yyyy", NEW_YORK, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("Frogsday, 03/23/1961", pos);
        assertNull(date);
        assertEquals(0, pos.getErrorIndex());
    }

    @Test
    void testIso8601TimeZoneStrategyInvalidWidthThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new FastDateParser("yyyy-MM-dd'T'HH:mm:ssXXXX", NEW_YORK, Locale.US);
            }
        });
        assertEquals("Invalid number of X", ex.getMessage());
    }

    @Test
    void testIso8601TimeZoneStrategyParsesOffset() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd'T'HH:mm:ssXXX", NEW_YORK, Locale.US);
        final Date date = parser.parse("2021-06-01T12:00:00+02:00");
        assertNotNull(date);
    }

    @Test
    void testNumericFieldOverflowFailsGracefully() {
        final FastDateParser parser = new FastDateParser("yyyy", NEW_YORK, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("99999999999999999999", pos);
        assertNull(date);
        assertTrue(pos.getErrorIndex() >= 0);
    }

    @Test
    void testTimeZoneTextStrategy() throws ParseException {
        final FastDateParser parser = new FastDateParser("mm:ss z", NEW_YORK, Locale.US);
        final Date date = parser.parse("11:23 Pacific Standard Time");
        assertNotNull(date);
    }

    @Test
    void testWeekYearPattern() throws ParseException {
        final FastDateParser parser = new FastDateParser("YYYY-'W'ww-u", NEW_YORK, Locale.US);
        final Date date = parser.parse("2021-W05-1");
        final GregorianCalendar calendar = new GregorianCalendar(NEW_YORK, Locale.US);
        calendar.setTime(date);
        assertEquals(2021, calendar.getWeekYear());
        assertEquals(5, calendar.get(Calendar.WEEK_OF_YEAR));
        assertEquals(Calendar.MONDAY, calendar.get(Calendar.DAY_OF_WEEK));
    }

    @Test
    void testLiteralTextMustMatchExactly() {
        final FastDateParser parser = new FastDateParser("yyyy'-literal-'MM", NEW_YORK, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date failure = parser.parse("2020-nomatch-03", pos);
        assertNull(failure);

        final ParsePosition okPos = new ParsePosition(0);
        final Date success = parser.parse("2020-literal-03", okPos);
        assertNotNull(success);
        assertEquals(15, okPos.getIndex());
    }

    @Test
    void testJapaneseImperialLocaleRejectsPreEraDate() {
        final Locale japaneseImperial = new Locale("ja", "JP", "JP");
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", TimeZone.getTimeZone("Asia/Tokyo"), japaneseImperial);
        final ParseException ex = assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws ParseException {
                parser.parse("not-a-date");
            }
        });
        assertTrue(ex.getMessage().contains("does not support dates before 1868-01-01"));
    }

    @Test
    void testAmPmBoundary() throws ParseException {
        final FastDateParser parser = new FastDateParser("hh:mm a", NEW_YORK, Locale.US);
        final Calendar noon = Calendar.getInstance(NEW_YORK, Locale.US);
        noon.setTime(parser.parse("12:00 PM"));
        assertEquals(12, noon.get(Calendar.HOUR_OF_DAY));

        final Calendar midnight = Calendar.getInstance(NEW_YORK, Locale.US);
        midnight.setTime(parser.parse("12:00 AM"));
        assertEquals(0, midnight.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    void testHourInDayBoundaryValue24() throws ParseException {
        final FastDateParser parser = new FastDateParser("kk:mm", NEW_YORK, Locale.US);
        final Calendar calendar = Calendar.getInstance(NEW_YORK, Locale.US);
        calendar.setTime(parser.parse("24:00"));
        assertEquals(0, calendar.get(Calendar.HOUR_OF_DAY));
    }
}
