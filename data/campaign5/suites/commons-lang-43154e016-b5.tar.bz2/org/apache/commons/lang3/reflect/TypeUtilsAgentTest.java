/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.GenericArrayType;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link TypeUtils}.
 */
class TypeUtilsAgentTest {

    private static class Box<T> {
        T item;
    }

    private static class StringBox extends Box<String> {
    }

    private static class NumBox<T extends Number> {
        T value;
    }

    private static class Bounded<T extends Collection<String> & List<String>> {
    }

    private static class Pair<A, B> {
    }

    private static class StringIntPair extends Pair<String, Integer> {
    }

    /**
     * A Type implementation that is none of Class, ParameterizedType, TypeVariable, GenericArrayType or WildcardType.
     */
    private static class UnknownType implements Type {
    }

    @Test
    void testConstructor() throws Exception {
        assertNotNull(TypeUtils.class.getConstructor().newInstance());
    }

    @Test
    void testIsAssignableClass() {
        assertTrue(TypeUtils.isAssignable(Integer.class, Number.class));
        assertFalse(TypeUtils.isAssignable(String.class, Number.class));
        assertTrue(TypeUtils.isAssignable(String.class, String.class));
        assertTrue(TypeUtils.isAssignable((Type) null, Integer.class));
        assertFalse(TypeUtils.isAssignable((Type) null, int.class));
    }

    @Test
    void testIsAssignableParameterizedType() {
        final ParameterizedType boxOfString = (ParameterizedType) StringBox.class.getGenericSuperclass();
        assertTrue(TypeUtils.isAssignable(StringBox.class, boxOfString));
        final ParameterizedType boxOfInteger = TypeUtils.parameterize(Box.class, Integer.class);
        assertFalse(TypeUtils.isAssignable(StringBox.class, boxOfInteger));
        // raw type is always assignable to its own parameterized form of equal args
        assertTrue(TypeUtils.isAssignable(boxOfString, boxOfString));
    }

    @Test
    void testIsAssignableGenericArrayType() {
        final GenericArrayType arrayOfString = TypeUtils.genericArrayType(String.class);
        assertTrue(TypeUtils.isAssignable(String[].class, arrayOfString));
        assertFalse(TypeUtils.isAssignable(Integer[].class, arrayOfString));
        assertFalse(TypeUtils.isAssignable(String.class, arrayOfString));
    }

    @Test
    void testIsAssignableWildcardType() {
        final WildcardType upperNumber = TypeUtils.wildcardType().withUpperBounds(Number.class).build();
        assertTrue(TypeUtils.isAssignable(Integer.class, upperNumber));
        assertFalse(TypeUtils.isAssignable(String.class, upperNumber));
        assertTrue(TypeUtils.isAssignable(Integer.class, TypeUtils.WILDCARD_ALL));
    }

    @Test
    void testIsAssignableTypeVariable() {
        final TypeVariable<?> t = Box.class.getTypeParameters()[0];
        assertFalse(TypeUtils.isAssignable(String.class, t));
        assertTrue(TypeUtils.isAssignable(t, t));
    }

    @Test
    void testGetTypeArgumentsFromSubtype() {
        final Map<TypeVariable<?>, Type> args = TypeUtils.getTypeArguments(StringIntPair.class, Pair.class);
        assertNotNull(args);
        final TypeVariable<?> a = Pair.class.getTypeParameters()[0];
        final TypeVariable<?> b = Pair.class.getTypeParameters()[1];
        assertEquals(String.class, args.get(a));
        assertEquals(Integer.class, args.get(b));
    }

    @Test
    void testGetTypeArgumentsNotAssignableReturnsNull() {
        assertNull(TypeUtils.getTypeArguments(String.class, List.class));
    }

    @Test
    void testGetTypeArgumentsFromParameterizedType() {
        final ParameterizedType boxOfString = (ParameterizedType) StringBox.class.getGenericSuperclass();
        final Map<TypeVariable<?>, Type> args = TypeUtils.getTypeArguments(boxOfString);
        assertEquals(String.class, args.get(Box.class.getTypeParameters()[0]));
    }

    @Test
    void testGetRawTypeClassAndParameterizedType() {
        assertEquals(String.class, TypeUtils.getRawType(String.class, null));
        final ParameterizedType listOfString = TypeUtils.parameterize(List.class, String.class);
        assertEquals(List.class, TypeUtils.getRawType(listOfString, null));
    }

    @Test
    void testGetRawTypeTypeVariable() {
        final TypeVariable<?> t = Box.class.getTypeParameters()[0];
        final ParameterizedType boxOfString = (ParameterizedType) StringBox.class.getGenericSuperclass();
        assertEquals(String.class, TypeUtils.getRawType(t, boxOfString));
        assertNull(TypeUtils.getRawType(t, null));
    }

    @Test
    void testGetRawTypeWildcardIsNull() {
        assertNull(TypeUtils.getRawType(TypeUtils.WILDCARD_ALL, null));
    }

    @Test
    void testGetRawTypeUnknownTypeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                TypeUtils.getRawType(new UnknownType(), null);
            }
        });
    }

    @Test
    void testGetArrayComponentType() {
        assertEquals(String.class, TypeUtils.getArrayComponentType(String[].class));
        assertNull(TypeUtils.getArrayComponentType(String.class));
        assertEquals(String.class, TypeUtils.getArrayComponentType(TypeUtils.genericArrayType(String.class)));
    }

    @Test
    void testIsArrayType() {
        assertTrue(TypeUtils.isArrayType(String[].class));
        assertTrue(TypeUtils.isArrayType(TypeUtils.genericArrayType(String.class)));
        assertFalse(TypeUtils.isArrayType(String.class));
        assertFalse(TypeUtils.isArrayType(List.class));
    }

    @Test
    void testContainsTypeVariables() {
        assertTrue(TypeUtils.containsTypeVariables(Box.class.getTypeParameters()[0]));
        assertTrue(TypeUtils.containsTypeVariables(List.class));
        assertFalse(TypeUtils.containsTypeVariables(String.class));
        final ParameterizedType listOfString = TypeUtils.parameterize(List.class, String.class);
        assertFalse(TypeUtils.containsTypeVariables(listOfString));
        final ParameterizedType listOfT = TypeUtils.parameterize(List.class, Box.class.getTypeParameters()[0]);
        assertTrue(TypeUtils.containsTypeVariables(listOfT));
    }

    @Test
    void testEquals() {
        final ParameterizedType listOfString1 = TypeUtils.parameterize(List.class, String.class);
        final ParameterizedType listOfString2 = TypeUtils.parameterize(List.class, String.class);
        final ParameterizedType listOfInteger = TypeUtils.parameterize(List.class, Integer.class);
        assertTrue(TypeUtils.equals(listOfString1, listOfString2));
        assertFalse(TypeUtils.equals(listOfString1, listOfInteger));
        assertTrue(TypeUtils.equals(String.class, String.class));
        assertFalse(TypeUtils.equals(String.class, Integer.class));
        final GenericArrayType arr1 = TypeUtils.genericArrayType(String.class);
        final GenericArrayType arr2 = TypeUtils.genericArrayType(String.class);
        assertTrue(TypeUtils.equals(arr1, arr2));
    }

    @Test
    void testParameterize() {
        final ParameterizedType listOfString = TypeUtils.parameterize(List.class, String.class);
        assertEquals(List.class, listOfString.getRawType());
        assertEquals(1, listOfString.getActualTypeArguments().length);
        assertEquals(String.class, listOfString.getActualTypeArguments()[0]);
        assertNull(listOfString.getOwnerType());
    }

    @Test
    void testParameterizeWrongArgumentCountThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                TypeUtils.parameterize(List.class, String.class, Integer.class);
            }
        });
    }

    @Test
    void testParameterizeNullElementThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                TypeUtils.parameterize(List.class, (Type) null);
            }
        });
    }

    @Test
    void testParameterizeWithMap() {
        final Map<TypeVariable<?>, Type> map = new HashMap<TypeVariable<?>, Type>();
        map.put(Pair.class.getTypeParameters()[0], String.class);
        map.put(Pair.class.getTypeParameters()[1], Integer.class);
        final ParameterizedType pairType = TypeUtils.parameterize(Pair.class, map);
        assertEquals(String.class, pairType.getActualTypeArguments()[0]);
        assertEquals(Integer.class, pairType.getActualTypeArguments()[1]);
    }

    @Test
    void testParameterizeWithOwnerRejectsOwnerForTopLevelClass() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                TypeUtils.parameterizeWithOwner(String.class, List.class, String.class);
            }
        });
    }

    @Test
    void testToStringClassAndNull() {
        assertEquals("java.lang.String", TypeUtils.toString(String.class));
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                TypeUtils.toString(null);
            }
        });
    }

    @Test
    void testToStringParameterizedAndArray() {
        final ParameterizedType listOfString = TypeUtils.parameterize(List.class, String.class);
        assertEquals("java.util.List<java.lang.String>", TypeUtils.toString(listOfString));
        assertEquals("java.lang.String[]", TypeUtils.toString(String[].class));
        assertEquals("java.lang.String[]", TypeUtils.toString(TypeUtils.genericArrayType(String.class)));
    }

    @Test
    void testToStringWildcard() {
        assertEquals("?", TypeUtils.toString(TypeUtils.WILDCARD_ALL));
        final WildcardType upper = TypeUtils.wildcardType().withUpperBounds(Number.class).build();
        assertEquals("? extends java.lang.Number", TypeUtils.toString(upper));
        final WildcardType lower = TypeUtils.wildcardType().withLowerBounds(Integer.class).build();
        assertEquals("? super java.lang.Integer", TypeUtils.toString(lower));
    }

    @Test
    void testToLongString() {
        final TypeVariable<?> t = Box.class.getTypeParameters()[0];
        final String longString = TypeUtils.toLongString(t);
        assertTrue(longString.endsWith(":T"));
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                TypeUtils.toLongString(null);
            }
        });
    }

    @Test
    void testGetImplicitBoundsNormalized() {
        final TypeVariable<?> t = Bounded.class.getTypeParameters()[0];
        final Type[] bounds = TypeUtils.getImplicitBounds(t);
        assertEquals(1, bounds.length);
        assertEquals(List.class, TypeUtils.getRawType(bounds[0], null));
    }

    @Test
    void testGetImplicitBoundsNoExplicitBoundIsObject() {
        final TypeVariable<?> t = Box.class.getTypeParameters()[0];
        final Type[] bounds = TypeUtils.getImplicitBounds(t);
        assertEquals(1, bounds.length);
        assertEquals(Object.class, bounds[0]);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                TypeUtils.getImplicitBounds(null);
            }
        });
    }

    @Test
    void testGetImplicitLowerAndUpperBoundsOfWildcardAll() {
        final Type[] lower = TypeUtils.getImplicitLowerBounds(TypeUtils.WILDCARD_ALL);
        assertEquals(1, lower.length);
        assertNull(lower[0]);
        final Type[] upper = TypeUtils.getImplicitUpperBounds(TypeUtils.WILDCARD_ALL);
        assertEquals(1, upper.length);
        assertEquals(Object.class, upper[0]);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                TypeUtils.getImplicitLowerBounds(null);
            }
        });
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                TypeUtils.getImplicitUpperBounds(null);
            }
        });
    }

    @Test
    void testNormalizeUpperBounds() {
        final Type[] normalized = TypeUtils.normalizeUpperBounds(new Type[] { Collection.class, List.class });
        assertEquals(1, normalized.length);
        assertEquals(List.class, normalized[0]);
        final Type[] single = TypeUtils.normalizeUpperBounds(new Type[] { Number.class });
        assertEquals(1, single.length);
        assertEquals(Number.class, single[0]);
        final Type[] empty = TypeUtils.normalizeUpperBounds(new Type[0]);
        assertEquals(0, empty.length);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                TypeUtils.normalizeUpperBounds(null);
            }
        });
    }

    @Test
    void testIsInstance() {
        assertTrue(TypeUtils.isInstance("foo", String.class));
        assertFalse(TypeUtils.isInstance("foo", Integer.class));
        assertTrue(TypeUtils.isInstance(null, String.class));
        assertFalse(TypeUtils.isInstance(null, int.class));
        assertFalse(TypeUtils.isInstance("foo", null));
    }

    @Test
    void testTypesSatisfyVariables() {
        final Map<TypeVariable<?>, Type> satisfied = new HashMap<TypeVariable<?>, Type>();
        satisfied.put(NumBox.class.getTypeParameters()[0], Integer.class);
        assertTrue(TypeUtils.typesSatisfyVariables(satisfied));
        final Map<TypeVariable<?>, Type> unsatisfied = new HashMap<TypeVariable<?>, Type>();
        unsatisfied.put(NumBox.class.getTypeParameters()[0], String.class);
        assertFalse(TypeUtils.typesSatisfyVariables(unsatisfied));
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                TypeUtils.typesSatisfyVariables(null);
            }
        });
    }

    @Test
    void testUnrollVariables() {
        final TypeVariable<?> a = Pair.class.getTypeParameters()[0];
        final Map<TypeVariable<?>, Type> map = new HashMap<TypeVariable<?>, Type>();
        map.put(a, String.class);
        assertEquals(String.class, TypeUtils.unrollVariables(map, a));
        assertEquals(String.class, TypeUtils.unrollVariables(null, String.class));
        assertNull(TypeUtils.unrollVariables(Collections.<TypeVariable<?>, Type>emptyMap(), a));
    }

    @Test
    void testWrap() {
        final Typed<String> wrapped = TypeUtils.wrap(String.class);
        assertEquals(String.class, wrapped.getType());
        final ParameterizedType listOfString = TypeUtils.parameterize(List.class, String.class);
        final Typed<List<String>> wrappedGeneric = TypeUtils.wrap((Type) listOfString);
        assertSame(listOfString, wrappedGeneric.getType());
    }

    @Test
    void testGenericArrayType() {
        final GenericArrayType arrayType = TypeUtils.genericArrayType(String.class);
        assertEquals(String.class, arrayType.getGenericComponentType());
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                TypeUtils.genericArrayType(null);
            }
        });
    }

    @Test
    void testDetermineTypeArguments() {
        final ParameterizedType collectionOfString = TypeUtils.parameterize(Collection.class, String.class);
        final Map<TypeVariable<?>, Type> result = TypeUtils.determineTypeArguments(List.class, collectionOfString);
        assertNotNull(result);
        assertEquals(String.class, result.get(List.class.getTypeParameters()[0]));
    }

    @Test
    void testDetermineTypeArgumentsNotAssignableReturnsNull() {
        final ParameterizedType listOfInteger = TypeUtils.parameterize(List.class, Integer.class);
        assertNull(TypeUtils.determineTypeArguments(String.class, listOfInteger));
    }

    @Test
    void testDetermineTypeArgumentsNullArgsThrow() {
        final ParameterizedType listOfInteger = TypeUtils.parameterize(List.class, Integer.class);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                TypeUtils.determineTypeArguments(null, listOfInteger);
            }
        });
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                TypeUtils.determineTypeArguments(List.class, null);
            }
        });
    }
}
