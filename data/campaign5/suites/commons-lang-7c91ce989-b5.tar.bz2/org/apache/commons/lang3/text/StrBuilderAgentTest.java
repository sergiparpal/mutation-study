/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.IOException;
import java.io.Reader;
import java.io.StringWriter;
import java.io.Writer;
import java.nio.CharBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;

@SuppressWarnings("deprecation")
public class StrBuilderAgentTest {

    @Test
    public void testDefaultConstructor() {
        final StrBuilder sb = new StrBuilder();
        assertEquals(0, sb.length());
        assertEquals(32, sb.capacity());
        assertEquals("", sb.toString());
    }

    @Test
    public void testCapacityConstructorZeroOrNegativeUsesDefault() {
        assertEquals(32, new StrBuilder(0).capacity());
        assertEquals(32, new StrBuilder(-5).capacity());
        assertEquals(50, new StrBuilder(50).capacity());
    }

    @Test
    public void testStringConstructorNull() {
        final StrBuilder sb = new StrBuilder((String) null);
        assertEquals(0, sb.length());
        assertEquals("", sb.toString());
    }

    @Test
    public void testStringConstructor() {
        final StrBuilder sb = new StrBuilder("hello");
        assertEquals(5, sb.length());
        assertEquals("hello", sb.toString());
    }

    @Test
    public void testAppendBoolean() {
        final StrBuilder sb = new StrBuilder();
        sb.append(true).append(' ').append(false);
        assertEquals("true false", sb.toString());
    }

    @Test
    public void testAppendChar() {
        final StrBuilder sb = new StrBuilder();
        final StrBuilder result = sb.append('A');
        assertSame(sb, result);
        assertEquals("A", sb.toString());
    }

    @Test
    public void testAppendCharArrayNull() {
        final StrBuilder sb = new StrBuilder();
        sb.append((char[]) null);
        assertEquals(0, sb.length());
    }

    @Test
    public void testAppendCharArray() {
        final StrBuilder sb = new StrBuilder();
        sb.append(new char[] {'a', 'b', 'c'});
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendCharArrayRange() {
        final StrBuilder sb = new StrBuilder();
        sb.append(new char[] {'a', 'b', 'c', 'd'}, 1, 2);
        assertEquals("bc", sb.toString());
    }

    @Test
    public void testAppendCharArrayRangeInvalidStartIndex() {
        final StrBuilder sb = new StrBuilder();
        try {
            sb.append(new char[] {'a', 'b'}, -1, 1);
            fail("Expected StringIndexOutOfBoundsException");
        } catch (final StringIndexOutOfBoundsException expected) {
            // expected
        }
        try {
            sb.append(new char[] {'a', 'b'}, 3, 1);
            fail("Expected StringIndexOutOfBoundsException");
        } catch (final StringIndexOutOfBoundsException expected) {
            // expected
        }
    }

    @Test
    public void testAppendCharArrayRangeInvalidLength() {
        final StrBuilder sb = new StrBuilder();
        try {
            sb.append(new char[] {'a', 'b'}, 0, -1);
            fail("Expected StringIndexOutOfBoundsException");
        } catch (final StringIndexOutOfBoundsException expected) {
            // expected
        }
        try {
            sb.append(new char[] {'a', 'b'}, 0, 3);
            fail("Expected StringIndexOutOfBoundsException");
        } catch (final StringIndexOutOfBoundsException expected) {
            // expected
        }
    }

    @Test
    public void testAppendCharSequenceNull() {
        final StrBuilder sb = new StrBuilder();
        sb.append((CharSequence) null);
        assertEquals(0, sb.length());
    }

    @Test
    public void testAppendCharSequenceStringBuilder() {
        final StrBuilder sb = new StrBuilder();
        sb.append((CharSequence) new StringBuilder("xyz"));
        assertEquals("xyz", sb.toString());
    }

    @Test
    public void testAppendCharSequenceRange() {
        final StrBuilder sb = new StrBuilder();
        sb.append((CharSequence) "abcdef", 2, 3);
        assertEquals("cde", sb.toString());
    }

    @Test
    public void testAppendDoubleFloatIntLong() {
        final StrBuilder sb = new StrBuilder();
        sb.append(1.5d).append(' ').append(2.5f).append(' ').append(3).append(' ').append(4L);
        assertEquals("1.5 2.5 3 4", sb.toString());
    }

    @Test
    public void testAppendObjectNull() {
        final StrBuilder sb = new StrBuilder();
        sb.append((Object) null);
        assertEquals(0, sb.length());
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendObjectWithNullText() {
        final StrBuilder sb = new StrBuilder();
        sb.setNullText("NULL");
        sb.append((Object) null);
        assertEquals("NULL", sb.toString());
    }

    @Test
    public void testAppendObjectCharSequence() {
        final StrBuilder sb = new StrBuilder();
        sb.append((Object) "abc");
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendStrBuilderNull() {
        final StrBuilder sb = new StrBuilder("a");
        sb.append((StrBuilder) null);
        assertEquals("a", sb.toString());
    }

    @Test
    public void testAppendStrBuilder() {
        final StrBuilder sb = new StrBuilder("a");
        sb.append(new StrBuilder("bc"));
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendStrBuilderRangeInvalid() {
        final StrBuilder sb = new StrBuilder();
        final StrBuilder other = new StrBuilder("abc");
        try {
            sb.append(other, -1, 1);
            fail("Expected StringIndexOutOfBoundsException");
        } catch (final StringIndexOutOfBoundsException expected) {
            // expected
        }
        try {
            sb.append(other, 0, 10);
            fail("Expected StringIndexOutOfBoundsException");
        } catch (final StringIndexOutOfBoundsException expected) {
            // expected
        }
    }

    @Test
    public void testAppendStringNull() {
        final StrBuilder sb = new StrBuilder("a");
        sb.append((String) null);
        assertEquals("a", sb.toString());
    }

    @Test
    public void testAppendStringRange() {
        final StrBuilder sb = new StrBuilder();
        sb.append("abcdef", 1, 3);
        assertEquals("bcd", sb.toString());
    }

    @Test
    public void testAppendStringFormat() {
        final StrBuilder sb = new StrBuilder();
        sb.append("%s-%d", "x", 7);
        assertEquals("x-7", sb.toString());
    }

    @Test
    public void testAppendStringBufferAndRange() {
        final StrBuilder sb = new StrBuilder();
        sb.append(new StringBuffer("hello"));
        assertEquals("hello", sb.toString());
        sb.clear();
        sb.append(new StringBuffer("hello"), 1, 3);
        assertEquals("ell", sb.toString());
    }

    @Test
    public void testAppendStringBuilderAndRange() {
        final StrBuilder sb = new StrBuilder();
        sb.append(new StringBuilder("hello"));
        assertEquals("hello", sb.toString());
        sb.clear();
        sb.append(new StringBuilder("hello"), 1, 3);
        assertEquals("ell", sb.toString());
    }

    @Test
    public void testAppendCharBuffer() {
        final StrBuilder sb = new StrBuilder();
        sb.append(CharBuffer.wrap("abcdef".toCharArray()));
        assertEquals("abcdef", sb.toString());
    }

    @Test
    public void testAppendCharBufferRange() {
        final StrBuilder sb = new StrBuilder();
        sb.append(CharBuffer.wrap("abcdef".toCharArray()), 1, 3);
        assertEquals("bcd", sb.toString());
    }

    @Test
    public void testAppendCharBufferRangeInvalid() {
        final StrBuilder sb = new StrBuilder();
        final CharBuffer buf = CharBuffer.wrap("abc".toCharArray());
        try {
            sb.append(buf, -1, 1);
            fail("Expected StringIndexOutOfBoundsException");
        } catch (final StringIndexOutOfBoundsException expected) {
            // expected
        }
        try {
            sb.append(buf, 0, 10);
            fail("Expected StringIndexOutOfBoundsException");
        } catch (final StringIndexOutOfBoundsException expected) {
            // expected
        }
    }

    @Test
    public void testAppendAllIterable() {
        final StrBuilder sb = new StrBuilder();
        final List<String> list = new ArrayList<String>();
        list.add("a");
        list.add("b");
        sb.appendAll((Iterable<?>) list);
        assertEquals("ab", sb.toString());
        sb.appendAll((Iterable<?>) null);
        assertEquals("ab", sb.toString());
    }

    @Test
    public void testAppendAllIterator() {
        final StrBuilder sb = new StrBuilder();
        final List<String> list = Arrays.asList("x", "y");
        sb.appendAll(list.iterator());
        assertEquals("xy", sb.toString());
        sb.appendAll((java.util.Iterator<?>) null);
        assertEquals("xy", sb.toString());
    }

    @Test
    public void testAppendAllArray() {
        final StrBuilder sb = new StrBuilder();
        sb.appendAll("a", "b", "c");
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadLeftInt() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft(1, 5, '0');
        assertEquals("00001", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadLeftTruncate() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft("abcdef", 3, ' ');
        assertEquals("def", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadLeftZeroWidthNoop() {
        final StrBuilder sb = new StrBuilder("x");
        sb.appendFixedWidthPadLeft("abc", 0, ' ');
        assertEquals("x", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadLeftNullObject() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft((Object) null, 4, '*');
        assertEquals("****", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadRightInt() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadRight(1, 5, '0');
        assertEquals("10000", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadRightTruncate() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadRight("abcdef", 3, ' ');
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendln() {
        final StrBuilder sb = new StrBuilder();
        sb.setNewLineText("\n");
        sb.appendln("abc");
        assertEquals("abc\n", sb.toString());
    }

    @Test
    public void testAppendNewLineDefaultsToSystemLineSeparator() {
        final StrBuilder sb = new StrBuilder();
        sb.appendNewLine();
        assertEquals(System.lineSeparator(), sb.toString());
    }

    @Test
    public void testAppendNewLineCustom() {
        final StrBuilder sb = new StrBuilder();
        sb.setNewLineText("<br>");
        assertEquals("<br>", sb.getNewLineText());
        sb.appendNewLine();
        assertEquals("<br>", sb.toString());
        sb.setNewLineText(null);
        assertNull(sb.getNewLineText());
    }

    @Test
    public void testAppendNullDefaultIsNoop() {
        final StrBuilder sb = new StrBuilder();
        assertNull(sb.getNullText());
        sb.appendNull();
        assertEquals("", sb.toString());
    }

    @Test
    public void testSetNullTextEmptyBecomesNull() {
        final StrBuilder sb = new StrBuilder();
        sb.setNullText("");
        assertNull(sb.getNullText());
        sb.setNullText("NULL");
        assertEquals("NULL", sb.getNullText());
    }

    @Test
    public void testAppendPadding() {
        final StrBuilder sb = new StrBuilder("a");
        sb.appendPadding(3, 'x');
        assertEquals("axxx", sb.toString());
        sb.appendPadding(-1, 'x');
        assertEquals("axxx", sb.toString());
    }

    @Test
    public void testAppendSeparatorChar() {
        final StrBuilder sb = new StrBuilder();
        sb.appendSeparator(',');
        assertEquals("", sb.toString());
        sb.append('a');
        sb.appendSeparator(',');
        sb.append('b');
        assertEquals("a,b", sb.toString());
    }

    @Test
    public void testAppendSeparatorCharWithDefault() {
        final StrBuilder sb = new StrBuilder();
        sb.appendSeparator(',', ';');
        assertEquals(";", sb.toString());
        sb.append('a');
        sb.appendSeparator(',', ';');
        assertEquals(";a,", sb.toString());
    }

    @Test
    public void testAppendSeparatorCharLoopIndex() {
        final StrBuilder sb = new StrBuilder();
        for (int i = 0; i < 3; i++) {
            sb.appendSeparator(',', i);
            sb.append(i);
        }
        assertEquals("0,1,2", sb.toString());
    }

    @Test
    public void testAppendSeparatorStringNull() {
        final StrBuilder sb = new StrBuilder("a");
        sb.appendSeparator((String) null);
        assertEquals("a", sb.toString());
    }

    @Test
    public void testAppendSeparatorStringLoopIndex() {
        final StrBuilder sb = new StrBuilder();
        for (int i = 0; i < 3; i++) {
            sb.appendSeparator("-", i);
            sb.append(i);
        }
        assertEquals("0-1-2", sb.toString());
    }

    @Test
    public void testAppendSeparatorStringStandardAndDefault() {
        final StrBuilder sb = new StrBuilder();
        sb.appendSeparator(" and", " where");
        assertEquals(" where", sb.toString());
        sb.append("x=1");
        sb.appendSeparator(" and", " where");
        assertEquals(" wherex=1 and", sb.toString());
    }

    @Test
    public void testAppendToWriter() throws IOException {
        final StrBuilder sb = new StrBuilder("hello");
        final StringWriter writer = new StringWriter();
        sb.appendTo(writer);
        assertEquals("hello", writer.toString());
    }

    @Test
    public void testAppendToStringBuilder() throws IOException {
        final StrBuilder sb = new StrBuilder("hello");
        final StringBuilder target = new StringBuilder();
        sb.appendTo(target);
        assertEquals("hello", target.toString());
    }

    @Test
    public void testAppendWithSeparatorsIterable() {
        final StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators(Arrays.asList("a", "b", "c"), ",");
        assertEquals("a,b,c", sb.toString());
    }

    @Test
    public void testAppendWithSeparatorsIterableNullSeparator() {
        final StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators(Arrays.asList("a", "b"), null);
        assertEquals("ab", sb.toString());
    }

    @Test
    public void testAppendWithSeparatorsIterableNullIterableNoop() {
        final StrBuilder sb = new StrBuilder("z");
        sb.appendWithSeparators((Iterable<?>) null, ",");
        assertEquals("z", sb.toString());
    }

    @Test
    public void testAppendWithSeparatorsArray() {
        final StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators(new Object[] {"a", "b", "c"}, "-");
        assertEquals("a-b-c", sb.toString());
    }

    @Test
    public void testAppendWithSeparatorsArrayEmpty() {
        final StrBuilder sb = new StrBuilder("y");
        sb.appendWithSeparators(new Object[0], "-");
        assertEquals("y", sb.toString());
    }

    @Test
    public void testCharAt() {
        final StrBuilder sb = new StrBuilder("abc");
        assertEquals('a', sb.charAt(0));
        assertEquals('c', sb.charAt(2));
    }

    @Test
    public void testCharAtInvalidIndex() {
        final StrBuilder sb = new StrBuilder("abc");
        try {
            sb.charAt(-1);
            fail("Expected StringIndexOutOfBoundsException");
        } catch (final StringIndexOutOfBoundsException expected) {
            // expected
        }
        try {
            sb.charAt(3);
            fail("Expected StringIndexOutOfBoundsException");
        } catch (final StringIndexOutOfBoundsException expected) {
            // expected
        }
    }

    @Test
    public void testClear() {
        final StrBuilder sb = new StrBuilder("abcdef");
        final StrBuilder result = sb.clear();
        assertSame(sb, result);
        assertEquals(0, sb.length());
        assertEquals("", sb.toString());
    }

    @Test
    public void testContainsChar() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertTrue(sb.contains('c'));
        assertFalse(sb.contains('z'));
    }

    @Test
    public void testContainsString() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertTrue(sb.contains("cde"));
        assertFalse(sb.contains("xyz"));
    }

    @Test
    public void testContainsMatcher() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertTrue(sb.contains(StrMatcher.charMatcher('d')));
        assertFalse(sb.contains((StrMatcher) null));
    }

    @Test
    public void testDelete() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.delete(1, 3);
        assertEquals("adef", sb.toString());
    }

    @Test
    public void testDeleteEndBeyondSizeTreatedAsEnd() {
        final StrBuilder sb = new StrBuilder("abc");
        sb.delete(1, 100);
        assertEquals("a", sb.toString());
    }

    @Test
    public void testDeleteInvalidRange() {
        final StrBuilder sb = new StrBuilder("abc");
        try {
            sb.delete(-1, 2);
            fail("Expected StringIndexOutOfBoundsException");
        } catch (final StringIndexOutOfBoundsException expected) {
            // expected
        }
        try {
            sb.delete(2, 1);
            fail("Expected StringIndexOutOfBoundsException");
        } catch (final StringIndexOutOfBoundsException expected) {
            // expected
        }
    }

    @Test
    public void testDeleteAllChar() {
        final StrBuilder sb = new StrBuilder("abcabcabc");
        sb.deleteAll('a');
        assertEquals("bcbcbc", sb.toString());
    }

    @Test
    public void testDeleteAllString() {
        final StrBuilder sb = new StrBuilder("ab-cd-ef");
        sb.deleteAll("-");
        assertEquals("abcdef", sb.toString());
    }

    @Test
    public void testDeleteAllStringNullNoop() {
        final StrBuilder sb = new StrBuilder("abc");
        sb.deleteAll((String) null);
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testDeleteCharAt() {
        final StrBuilder sb = new StrBuilder("abc");
        sb.deleteCharAt(1);
        assertEquals("ac", sb.toString());
    }

    @Test
    public void testDeleteCharAtInvalid() {
        final StrBuilder sb = new StrBuilder("abc");
        try {
            sb.deleteCharAt(-1);
            fail("Expected StringIndexOutOfBoundsException");
        } catch (final StringIndexOutOfBoundsException expected) {
            // expected
        }
        try {
            sb.deleteCharAt(3);
            fail("Expected StringIndexOutOfBoundsException");
        } catch (final StringIndexOutOfBoundsException expected) {
            // expected
        }
    }

    @Test
    public void testDeleteFirstChar() {
        final StrBuilder sb = new StrBuilder("abcabc");
        sb.deleteFirst('a');
        assertEquals("bcabc", sb.toString());
    }

    @Test
    public void testDeleteFirstString() {
        final StrBuilder sb = new StrBuilder("abcabc");
        sb.deleteFirst("bc");
        assertEquals("aabc", sb.toString());
    }

    @Test
    public void testEndsWith() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertTrue(sb.endsWith("def"));
        assertFalse(sb.endsWith("abc"));
        assertFalse(sb.endsWith(null));
        assertTrue(sb.endsWith(""));
    }

    @Test
    public void testEnsureCapacityGrowsBuffer() {
        final StrBuilder sb = new StrBuilder(2);
        assertEquals(2, sb.capacity());
        sb.ensureCapacity(100);
        assertTrue(sb.capacity() >= 100);
    }

    @Test
    public void testEnsureCapacityNoShrink() {
        final StrBuilder sb = new StrBuilder(50);
        sb.ensureCapacity(5);
        assertEquals(50, sb.capacity());
    }

    @Test
    public void testEqualsObject() {
        final StrBuilder sb1 = new StrBuilder("abc");
        final StrBuilder sb2 = new StrBuilder("abc");
        assertTrue(sb1.equals((Object) sb2));
        assertFalse(sb1.equals((Object) "abc"));
        assertFalse(sb1.equals((Object) null));
    }

    @Test
    public void testEqualsStrBuilder() {
        final StrBuilder sb1 = new StrBuilder("abc");
        assertTrue(sb1.equals(sb1));
        assertFalse(sb1.equals((StrBuilder) null));
        assertFalse(sb1.equals(new StrBuilder("abcd")));
        assertFalse(sb1.equals(new StrBuilder("abd")));
    }

    @Test
    public void testEqualsIgnoreCase() {
        final StrBuilder sb1 = new StrBuilder("AbC");
        final StrBuilder sb2 = new StrBuilder("abc");
        assertTrue(sb1.equalsIgnoreCase(sb2));
        assertTrue(sb1.equalsIgnoreCase(sb1));
        assertFalse(sb1.equalsIgnoreCase(new StrBuilder("abcd")));
    }

    @Test
    public void testGetCharsDestinationNull() {
        final StrBuilder sb = new StrBuilder("abc");
        final char[] result = sb.getChars((char[]) null);
        assertEquals(3, result.length);
        assertEquals('a', result[0]);
        assertEquals('c', result[2]);
    }

    @Test
    public void testGetCharsDestinationTooSmall() {
        final StrBuilder sb = new StrBuilder("abcdef");
        final char[] result = sb.getChars(new char[2]);
        assertEquals(6, result.length);
    }

    @Test
    public void testGetCharsRange() {
        final StrBuilder sb = new StrBuilder("abcdef");
        final char[] destination = new char[6];
        sb.getChars(1, 4, destination, 0);
        assertEquals('b', destination[0]);
        assertEquals('c', destination[1]);
        assertEquals('d', destination[2]);
    }

    @Test
    public void testGetCharsRangeInvalid() {
        final StrBuilder sb = new StrBuilder("abc");
        final char[] destination = new char[3];
        try {
            sb.getChars(-1, 2, destination, 0);
            fail("Expected StringIndexOutOfBoundsException");
        } catch (final StringIndexOutOfBoundsException expected) {
            // expected
        }
        try {
            sb.getChars(0, 10, destination, 0);
            fail("Expected StringIndexOutOfBoundsException");
        } catch (final StringIndexOutOfBoundsException expected) {
            // expected
        }
        try {
            sb.getChars(2, 1, destination, 0);
            fail("Expected StringIndexOutOfBoundsException");
        } catch (final StringIndexOutOfBoundsException expected) {
            // expected
        }
    }

    @Test
    public void testHashCodeConsistentWithEquals() {
        final StrBuilder sb1 = new StrBuilder("abc");
        final StrBuilder sb2 = new StrBuilder("abc");
        assertEquals(sb1.hashCode(), sb2.hashCode());
    }

    @Test
    public void testIndexOfChar() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(1, sb.indexOf('b'));
        assertEquals(-1, sb.indexOf('z'));
    }

    @Test
    public void testIndexOfCharStartIndex() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(4, sb.indexOf('b', 2));
        assertEquals(-1, sb.indexOf('b', 100));
        assertEquals(0, sb.indexOf('a', -5));
    }

    @Test
    public void testIndexOfString() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(1, sb.indexOf("bc"));
        assertEquals(-1, sb.indexOf((String) null));
    }

    @Test
    public void testIndexOfStringStartIndex() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(4, sb.indexOf("bc", 2));
    }

    @Test
    public void testIndexOfMatcher() {
        final StrBuilder sb = new StrBuilder("abc123");
        final StrMatcher digitMatcher = StrMatcher.charSetMatcher("0123456789");
        assertEquals(3, sb.indexOf(digitMatcher));
        assertEquals(-1, sb.indexOf((StrMatcher) null));
    }

    @Test
    public void testInsertBoolean() {
        final StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, true);
        assertEquals("atruec", sb.toString());
    }

    @Test
    public void testInsertChar() {
        final StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, 'b');
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testInsertInvalidIndex() {
        final StrBuilder sb = new StrBuilder("abc");
        try {
            sb.insert(-1, 'x');
            fail("Expected StringIndexOutOfBoundsException");
        } catch (final StringIndexOutOfBoundsException expected) {
            // expected
        }
        try {
            sb.insert(4, 'x');
            fail("Expected StringIndexOutOfBoundsException");
        } catch (final StringIndexOutOfBoundsException expected) {
            // expected
        }
    }

    @Test
    public void testInsertCharArrayNull() {
        final StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, (char[]) null);
        assertEquals("ac", sb.toString());
    }

    @Test
    public void testInsertCharArray() {
        final StrBuilder sb = new StrBuilder("ad");
        sb.insert(1, new char[] {'b', 'c'});
        assertEquals("abcd", sb.toString());
    }

    @Test
    public void testInsertCharArrayRange() {
        final StrBuilder sb = new StrBuilder("ae");
        sb.insert(1, new char[] {'x', 'b', 'c', 'y'}, 1, 2);
        assertEquals("abce", sb.toString());
    }

    @Test
    public void testInsertCharArrayRangeInvalid() {
        final StrBuilder sb = new StrBuilder("abc");
        final char[] chars = new char[] {'x', 'y'};
        try {
            sb.insert(0, chars, -1, 1);
            fail("Expected StringIndexOutOfBoundsException");
        } catch (final StringIndexOutOfBoundsException expected) {
            // expected
        }
        try {
            sb.insert(0, chars, 0, 10);
            fail("Expected StringIndexOutOfBoundsException");
        } catch (final StringIndexOutOfBoundsException expected) {
            // expected
        }
    }

    @Test
    public void testInsertNumericTypes() {
        final StrBuilder sb = new StrBuilder();
        sb.insert(0, 3.5d);
        sb.insert(sb.length(), ' ');
        sb.insert(sb.length(), 2.5f);
        sb.insert(sb.length(), ' ');
        sb.insert(sb.length(), 7);
        sb.insert(sb.length(), ' ');
        sb.insert(sb.length(), 9L);
        assertEquals("3.5 2.5 7 9", sb.toString());
    }

    @Test
    public void testInsertObjectNull() {
        final StrBuilder sb = new StrBuilder("ab");
        sb.insert(1, (Object) null);
        assertEquals("ab", sb.toString());
    }

    @Test
    public void testInsertStringNull() {
        final StrBuilder sb = new StrBuilder("ab");
        sb.insert(1, (String) null);
        assertEquals("ab", sb.toString());
    }

    @Test
    public void testInsertStringWithNullText() {
        final StrBuilder sb = new StrBuilder("ab");
        sb.setNullText("N");
        sb.insert(1, (String) null);
        assertEquals("aNb", sb.toString());
    }

    @Test
    public void testIsEmptyIsNotEmpty() {
        final StrBuilder sb = new StrBuilder();
        assertTrue(sb.isEmpty());
        assertFalse(sb.isNotEmpty());
        sb.append('x');
        assertFalse(sb.isEmpty());
        assertTrue(sb.isNotEmpty());
    }

    @Test
    public void testLastIndexOfChar() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(4, sb.lastIndexOf('b'));
        assertEquals(-1, sb.lastIndexOf('z'));
    }

    @Test
    public void testLastIndexOfCharStartIndex() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(1, sb.lastIndexOf('b', 3));
        assertEquals(-1, new StrBuilder("").lastIndexOf('a', 5));
    }

    @Test
    public void testLastIndexOfString() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(4, sb.lastIndexOf("bc"));
        assertEquals(-1, sb.lastIndexOf((String) null));
    }

    @Test
    public void testLastIndexOfMatcher() {
        final StrBuilder sb = new StrBuilder("1a2b3c");
        final StrMatcher digitMatcher = StrMatcher.charSetMatcher("0123456789");
        assertEquals(4, sb.lastIndexOf(digitMatcher));
        assertEquals(-1, sb.lastIndexOf((StrMatcher) null));
    }

    @Test
    public void testLeftString() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("abc", sb.leftString(3));
        assertEquals("", sb.leftString(0));
        assertEquals("", sb.leftString(-1));
        assertEquals("abcdef", sb.leftString(100));
    }

    @Test
    public void testLength() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertEquals(6, sb.length());
    }

    @Test
    public void testMidString() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("cd", sb.midString(2, 2));
        assertEquals("", sb.midString(2, -1));
        assertEquals("abcdef", sb.midString(-5, 6));
        assertEquals("", sb.midString(100, 2));
        assertEquals("def", sb.midString(3, 10));
    }

    @Test
    public void testMinimizeCapacity() {
        final StrBuilder sb = new StrBuilder(100);
        sb.append("abc");
        assertTrue(sb.capacity() >= 100);
        sb.minimizeCapacity();
        assertEquals(3, sb.capacity());
    }

    @Test
    public void testReadFromReader() throws IOException {
        final StrBuilder sb = new StrBuilder();
        final Reader reader = new java.io.StringReader("hello world");
        final int count = sb.readFrom(reader);
        assertEquals(11, count);
        assertEquals("hello world", sb.toString());
    }

    @Test
    public void testReadFromCharBuffer() throws IOException {
        final StrBuilder sb = new StrBuilder();
        final CharBuffer buf = CharBuffer.wrap("abcdef".toCharArray());
        final int count = sb.readFrom(buf);
        assertEquals(6, count);
        assertEquals("abcdef", sb.toString());
    }

    @Test
    public void testReadFromGenericReadable() throws IOException {
        final StrBuilder sb = new StrBuilder();
        final Readable readable = new Readable() {
            private boolean done;
            @Override
            public int read(final CharBuffer cb) {
                if (done) {
                    return -1;
                }
                done = true;
                cb.put('x').put('y');
                return 2;
            }
        };
        final int count = sb.readFrom(readable);
        assertEquals(2, count);
        assertEquals("xy", sb.toString());
    }

    @Test
    public void testReplaceRange() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.replace(1, 3, "XYZ");
        assertEquals("aXYZdef", sb.toString());
    }

    @Test
    public void testReplaceRangeWithNullDeletes() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.replace(1, 3, null);
        assertEquals("adef", sb.toString());
    }

    @Test
    public void testReplaceRangeInvalid() {
        final StrBuilder sb = new StrBuilder("abc");
        try {
            sb.replace(-1, 2, "x");
            fail("Expected StringIndexOutOfBoundsException");
        } catch (final StringIndexOutOfBoundsException expected) {
            // expected
        }
        try {
            sb.replace(2, 1, "x");
            fail("Expected StringIndexOutOfBoundsException");
        } catch (final StringIndexOutOfBoundsException expected) {
            // expected
        }
    }

    @Test
    public void testReplaceAllChar() {
        final StrBuilder sb = new StrBuilder("aXbXc");
        sb.replaceAll('X', 'Y');
        assertEquals("aYbYc", sb.toString());
    }

    @Test
    public void testReplaceAllCharSameNoop() {
        final StrBuilder sb = new StrBuilder("abc");
        sb.replaceAll('b', 'b');
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testReplaceAllString() {
        final StrBuilder sb = new StrBuilder("one-two-three");
        sb.replaceAll("-", "_");
        assertEquals("one_two_three", sb.toString());
    }

    @Test
    public void testReplaceFirstChar() {
        final StrBuilder sb = new StrBuilder("aXbXc");
        sb.replaceFirst('X', 'Y');
        assertEquals("aYbXc", sb.toString());
    }

    @Test
    public void testReplaceFirstString() {
        final StrBuilder sb = new StrBuilder("one-two-three");
        sb.replaceFirst("-", "_");
        assertEquals("one_two-three", sb.toString());
    }

    @Test
    public void testReplaceFirstMatcher() {
        final StrBuilder sb = new StrBuilder("1a2b3c");
        final StrMatcher digitMatcher = StrMatcher.charSetMatcher("0123456789");
        sb.replaceFirst(digitMatcher, "#");
        assertEquals("#a2b3c", sb.toString());
    }

    @Test
    public void testReplaceAllMatcher() {
        final StrBuilder sb = new StrBuilder("1a2b3c");
        final StrMatcher digitMatcher = StrMatcher.charSetMatcher("0123456789");
        sb.replaceAll(digitMatcher, "#");
        assertEquals("#a#b#c", sb.toString());
    }

    @Test
    public void testReverseEmpty() {
        final StrBuilder sb = new StrBuilder();
        sb.reverse();
        assertEquals("", sb.toString());
    }

    @Test
    public void testReverse() {
        final StrBuilder sb = new StrBuilder("abcde");
        sb.reverse();
        assertEquals("edcba", sb.toString());
        sb.reverse();
        assertEquals("abcde", sb.toString());
    }

    @Test
    public void testReverseWithSurrogatePair() {
        final String withSurrogate = "a" + "😀" + "b";
        final StrBuilder sb = new StrBuilder(withSurrogate);
        sb.reverse();
        assertEquals("b" + "😀" + "a", sb.toString());
    }

    @Test
    public void testRightString() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("def", sb.rightString(3));
        assertEquals("", sb.rightString(0));
        assertEquals("", sb.rightString(-1));
        assertEquals("abcdef", sb.rightString(100));
    }

    @Test
    public void testSetCharAt() {
        final StrBuilder sb = new StrBuilder("abc");
        sb.setCharAt(1, 'X');
        assertEquals("aXc", sb.toString());
    }

    @Test
    public void testSetCharAtInvalid() {
        final StrBuilder sb = new StrBuilder("abc");
        try {
            sb.setCharAt(-1, 'x');
            fail("Expected StringIndexOutOfBoundsException");
        } catch (final StringIndexOutOfBoundsException expected) {
            // expected
        }
        try {
            sb.setCharAt(3, 'x');
            fail("Expected StringIndexOutOfBoundsException");
        } catch (final StringIndexOutOfBoundsException expected) {
            // expected
        }
    }

    @Test
    public void testSetLengthShrink() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.setLength(3);
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testSetLengthGrowPadsWithZeroChar() {
        final StrBuilder sb = new StrBuilder("ab");
        sb.setLength(4);
        assertEquals(4, sb.length());
        assertEquals('\0', sb.charAt(2));
        assertEquals('\0', sb.charAt(3));
    }

    @Test
    public void testSetLengthNegativeThrows() {
        final StrBuilder sb = new StrBuilder("abc");
        try {
            sb.setLength(-1);
            fail("Expected StringIndexOutOfBoundsException");
        } catch (final StringIndexOutOfBoundsException expected) {
            // expected
        }
    }

    @Test
    public void testSizeMatchesLength() {
        final StrBuilder sb = new StrBuilder("abcd");
        assertEquals(4, sb.size());
        assertEquals(sb.length(), sb.size());
    }

    @Test
    public void testStartsWith() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertTrue(sb.startsWith("abc"));
        assertFalse(sb.startsWith("xyz"));
        assertFalse(sb.startsWith(null));
        assertTrue(sb.startsWith(""));
    }

    @Test
    public void testSubSequence() {
        final StrBuilder sb = new StrBuilder("abcdef");
        final CharSequence seq = sb.subSequence(1, 4);
        assertEquals("bcd", seq.toString());
    }

    @Test
    public void testSubSequenceInvalid() {
        final StrBuilder sb = new StrBuilder("abc");
        try {
            sb.subSequence(-1, 2);
            fail("Expected StringIndexOutOfBoundsException");
        } catch (final StringIndexOutOfBoundsException expected) {
            // expected
        }
        try {
            sb.subSequence(0, 10);
            fail("Expected StringIndexOutOfBoundsException");
        } catch (final StringIndexOutOfBoundsException expected) {
            // expected
        }
        try {
            sb.subSequence(2, 1);
            fail("Expected StringIndexOutOfBoundsException");
        } catch (final StringIndexOutOfBoundsException expected) {
            // expected
        }
    }

    @Test
    public void testSubstringFromStart() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("cdef", sb.substring(2));
    }

    @Test
    public void testSubstringRangeBeyondSizeClamped() {
        final StrBuilder sb = new StrBuilder("abc");
        assertEquals("bc", sb.substring(1, 100));
    }

    @Test
    public void testSubstringInvalid() {
        final StrBuilder sb = new StrBuilder("abc");
        try {
            sb.substring(-1, 2);
            fail("Expected StringIndexOutOfBoundsException");
        } catch (final StringIndexOutOfBoundsException expected) {
            // expected
        }
        try {
            sb.substring(2, 1);
            fail("Expected StringIndexOutOfBoundsException");
        } catch (final StringIndexOutOfBoundsException expected) {
            // expected
        }
    }

    @Test
    public void testToCharArrayEmpty() {
        final StrBuilder sb = new StrBuilder();
        final char[] result = sb.toCharArray();
        assertEquals(0, result.length);
    }

    @Test
    public void testToCharArray() {
        final StrBuilder sb = new StrBuilder("abc");
        final char[] result = sb.toCharArray();
        assertEquals(3, result.length);
        assertEquals('a', result[0]);
        assertEquals('b', result[1]);
        assertEquals('c', result[2]);
    }

    @Test
    public void testToCharArrayRange() {
        final StrBuilder sb = new StrBuilder("abcdef");
        final char[] result = sb.toCharArray(1, 3);
        assertEquals(2, result.length);
        assertEquals('b', result[0]);
        assertEquals('c', result[1]);
    }

    @Test
    public void testToCharArrayRangeEmpty() {
        final StrBuilder sb = new StrBuilder("abc");
        final char[] result = sb.toCharArray(1, 1);
        assertEquals(0, result.length);
    }

    @Test
    public void testToStringIndependentOfBuilder() {
        final StrBuilder sb = new StrBuilder("abc");
        final String s = sb.toString();
        sb.append("def");
        assertEquals("abc", s);
        assertEquals("abcdef", sb.toString());
    }

    @Test
    public void testToStringBuffer() {
        final StrBuilder sb = new StrBuilder("abc");
        final StringBuffer buffer = sb.toStringBuffer();
        assertEquals("abc", buffer.toString());
    }

    @Test
    public void testToStringBuilderMethod() {
        final StrBuilder sb = new StrBuilder("abc");
        final StringBuilder builder = sb.toStringBuilder();
        assertEquals("abc", builder.toString());
    }

    @Test
    public void testTrim() {
        final StrBuilder sb = new StrBuilder("  abc  ");
        sb.trim();
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testTrimEmpty() {
        final StrBuilder sb = new StrBuilder();
        sb.trim();
        assertEquals("", sb.toString());
    }

    @Test
    public void testTrimAllWhitespace() {
        final StrBuilder sb = new StrBuilder("   ");
        sb.trim();
        assertEquals("", sb.toString());
    }

    @Test
    public void testBuildReturnsToString() {
        final StrBuilder sb = new StrBuilder("abc");
        assertEquals(sb.toString(), sb.build());
    }

    @Test
    public void testAsReader() throws IOException {
        final StrBuilder sb = new StrBuilder("hello");
        final Reader reader = sb.asReader();
        final char[] buf = new char[5];
        final int read = reader.read(buf, 0, 5);
        assertEquals(5, read);
        assertEquals("hello", new String(buf));
        assertEquals(-1, reader.read());
    }

    @Test
    public void testAsReaderMarkReset() throws IOException {
        final StrBuilder sb = new StrBuilder("abc");
        final Reader reader = sb.asReader();
        assertTrue(reader.markSupported());
        assertEquals('a', (char) reader.read());
        reader.mark(0);
        assertEquals('b', (char) reader.read());
        reader.reset();
        assertEquals('b', (char) reader.read());
    }

    @Test
    public void testAsReaderSkip() throws IOException {
        final StrBuilder sb = new StrBuilder("abcdef");
        final Reader reader = sb.asReader();
        final long skipped = reader.skip(2);
        assertEquals(2, skipped);
        assertEquals('c', (char) reader.read());
    }

    @Test
    public void testAsWriter() throws IOException {
        final StrBuilder sb = new StrBuilder();
        final Writer writer = sb.asWriter();
        writer.write("hello");
        writer.write(' ');
        writer.write(new char[] {'w', 'o', 'r', 'l', 'd'});
        assertEquals("hello world", sb.toString());
    }

    @Test
    public void testAsTokenizer() {
        final StrBuilder sb = new StrBuilder("a b c");
        final StrTokenizer tokenizer = sb.asTokenizer();
        final String[] tokens = tokenizer.getTokenArray();
        assertEquals(3, tokens.length);
        assertEquals("a", tokens[0]);
        assertEquals("b", tokens[1]);
        assertEquals("c", tokens[2]);
    }

    @Test
    public void testChainedAppendsReturnSameInstance() {
        final StrBuilder sb = new StrBuilder();
        final StrBuilder result = sb.append("a").append(1).append(true).append('c');
        assertSame(sb, result);
        assertEquals("a1truec", sb.toString());
    }
}
