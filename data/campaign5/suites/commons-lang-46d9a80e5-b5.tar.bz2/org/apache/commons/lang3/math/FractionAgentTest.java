/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Tests for {@link Fraction}.
 */
public class FractionAgentTest {

    @Test
    public void testGetFractionIntIntBasic() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertEquals(3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionIntIntNegativeDenominatorMovesSignToNumerator() {
        final Fraction f = Fraction.getFraction(3, -7);
        assertEquals(-3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionIntIntZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(1, 0));
    }

    @Test
    public void testGetFractionIntIntOverflowOnNegate() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(Integer.MIN_VALUE, -1));
    }

    @Test
    public void testGetFractionIntIntDoesNotReduce() {
        final Fraction f = Fraction.getFraction(2, 4);
        assertEquals(2, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionWholeNumerDenom() {
        final Fraction f = Fraction.getFraction(1, 3, 7);
        assertEquals(10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionWholeNumerDenomNegativeWhole() {
        final Fraction f = Fraction.getFraction(-1, 3, 7);
        assertEquals(-10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionWholeNumerDenomNegativeDenominatorThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(1, 2, -7));
    }

    @Test
    public void testGetFractionWholeNumerDenomNegativeNumeratorThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(1, -2, 7));
    }

    @Test
    public void testGetFractionWholeNumerDenomZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(1, 2, 0));
    }

    @Test
    public void testGetFractionWholeNumerDenomOverflowThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(Integer.MAX_VALUE, 1, 1));
    }

    @Test
    public void testGetFractionDouble() {
        final Fraction f = Fraction.getFraction(0.5d);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetFractionDoubleNegative() {
        final Fraction f = Fraction.getFraction(-0.25d);
        assertEquals(-1, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionDoubleNaNThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(Double.NaN));
    }

    @Test
    public void testGetFractionDoubleTooLargeThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction((double) Integer.MAX_VALUE + 1d));
    }

    @Test
    public void testGetFractionDoubleZero() {
        final Fraction f = Fraction.getFraction(0.0d);
        assertEquals(0, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    public void testGetFractionStringSimpleWhole() {
        final Fraction f = Fraction.getFraction("5");
        assertEquals(5, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    public void testGetFractionStringYOverZ() {
        final Fraction f = Fraction.getFraction("3/7");
        assertEquals(3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionStringXYOverZ() {
        final Fraction f = Fraction.getFraction("1 3/7");
        assertEquals(10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionStringDoubleFormat() {
        final Fraction f = Fraction.getFraction("0.5");
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetFractionStringMissingSlashThrows() {
        assertThrows(NumberFormatException.class, () -> Fraction.getFraction("1 3 7"));
    }

    @Test
    public void testGetFractionStringNullThrows() {
        assertThrows(NullPointerException.class, () -> Fraction.getFraction((String) null));
    }

    @Test
    public void testGetFractionStringInvalidThrows() {
        assertThrows(NumberFormatException.class, () -> Fraction.getFraction("abc"));
    }

    @Test
    public void testGetReducedFractionBasic() {
        final Fraction f = Fraction.getReducedFraction(2, 4);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetReducedFractionZeroNumeratorNormalizesToZeroOverOne() {
        final Fraction f = Fraction.getReducedFraction(0, 5);
        assertSame(Fraction.ZERO, f);
        assertEquals(1, f.getDenominator());
    }

    @Test
    public void testGetReducedFractionZeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getReducedFraction(1, 0));
    }

    @Test
    public void testGetReducedFractionNegativeDenominator() {
        final Fraction f = Fraction.getReducedFraction(4, -8);
        assertEquals(-1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testConstants() {
        assertEquals(0, Fraction.ZERO.getNumerator());
        assertEquals(1, Fraction.ZERO.getDenominator());
        assertEquals(1, Fraction.ONE.getNumerator());
        assertEquals(1, Fraction.ONE.getDenominator());
        assertEquals(1, Fraction.ONE_HALF.getNumerator());
        assertEquals(2, Fraction.ONE_HALF.getDenominator());
        assertEquals(1, Fraction.ONE_THIRD.getNumerator());
        assertEquals(3, Fraction.ONE_THIRD.getDenominator());
        assertEquals(2, Fraction.TWO_THIRDS.getNumerator());
        assertEquals(3, Fraction.TWO_THIRDS.getDenominator());
        assertEquals(1, Fraction.ONE_QUARTER.getNumerator());
        assertEquals(4, Fraction.ONE_QUARTER.getDenominator());
        assertEquals(2, Fraction.TWO_QUARTERS.getNumerator());
        assertEquals(4, Fraction.TWO_QUARTERS.getDenominator());
        assertEquals(3, Fraction.THREE_QUARTERS.getNumerator());
        assertEquals(4, Fraction.THREE_QUARTERS.getDenominator());
        assertEquals(1, Fraction.ONE_FIFTH.getNumerator());
        assertEquals(5, Fraction.ONE_FIFTH.getDenominator());
        assertEquals(2, Fraction.TWO_FIFTHS.getNumerator());
        assertEquals(5, Fraction.TWO_FIFTHS.getDenominator());
        assertEquals(3, Fraction.THREE_FIFTHS.getNumerator());
        assertEquals(5, Fraction.THREE_FIFTHS.getDenominator());
        assertEquals(4, Fraction.FOUR_FIFTHS.getNumerator());
        assertEquals(5, Fraction.FOUR_FIFTHS.getDenominator());
    }

    @Test
    public void testAbsPositiveReturnsSameInstance() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertSame(f, f.abs());
    }

    @Test
    public void testAbsNegative() {
        final Fraction f = Fraction.getFraction(-3, 7);
        final Fraction abs = f.abs();
        assertEquals(3, abs.getNumerator());
        assertEquals(7, abs.getDenominator());
    }

    @Test
    public void testAbsMinValueOverflowThrows() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, f::abs);
    }

    @Test
    public void testAddBasic() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(1, 3);
        final Fraction sum = a.add(b);
        assertEquals(5, sum.getNumerator());
        assertEquals(6, sum.getDenominator());
    }

    @Test
    public void testAddZeroIdentityReturnsOtherFraction() {
        final Fraction b = Fraction.getFraction(2, 5);
        final Fraction sum = Fraction.ZERO.add(b);
        assertSame(b, sum);
    }

    @Test
    public void testAddToZeroReturnsThis() {
        final Fraction a = Fraction.getFraction(2, 5);
        final Fraction sum = a.add(Fraction.ZERO);
        assertSame(a, sum);
    }

    @Test
    public void testAddNullThrows() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, () -> a.add(null));
    }

    @Test
    public void testAddOverflowThrows() {
        final Fraction a = Fraction.getFraction(Integer.MAX_VALUE - 1, 2);
        final Fraction b = Fraction.getFraction(Integer.MAX_VALUE - 1, 3);
        assertThrows(ArithmeticException.class, () -> a.add(b));
    }

    @Test
    public void testAddSameDenominatorCommonDivisorPath() {
        // denominators share a gcd > 1, exercises BigInteger branch of addSub
        final Fraction a = Fraction.getFraction(1, 6);
        final Fraction b = Fraction.getFraction(1, 4);
        final Fraction sum = a.add(b);
        assertEquals(5, sum.getNumerator());
        assertEquals(12, sum.getDenominator());
    }

    @Test
    public void testSubtractBasic() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(1, 3);
        final Fraction diff = a.subtract(b);
        assertEquals(1, diff.getNumerator());
        assertEquals(6, diff.getDenominator());
    }

    @Test
    public void testSubtractFromZeroNegatesOther() {
        final Fraction b = Fraction.getFraction(2, 5);
        final Fraction diff = Fraction.ZERO.subtract(b);
        assertEquals(-2, diff.getNumerator());
        assertEquals(5, diff.getDenominator());
    }

    @Test
    public void testSubtractNullThrows() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, () -> a.subtract(null));
    }

    @Test
    public void testMultiplyByBasic() {
        final Fraction a = Fraction.getFraction(2, 3);
        final Fraction b = Fraction.getFraction(3, 4);
        final Fraction product = a.multiplyBy(b);
        assertEquals(1, product.getNumerator());
        assertEquals(2, product.getDenominator());
    }

    @Test
    public void testMultiplyByZero() {
        final Fraction a = Fraction.getFraction(2, 3);
        final Fraction product = a.multiplyBy(Fraction.ZERO);
        assertSame(Fraction.ZERO, product);
    }

    @Test
    public void testMultiplyByNullThrows() {
        final Fraction a = Fraction.getFraction(2, 3);
        assertThrows(NullPointerException.class, () -> a.multiplyBy(null));
    }

    @Test
    public void testMultiplyByOverflowThrows() {
        final Fraction a = Fraction.getFraction(Integer.MAX_VALUE, 1);
        final Fraction b = Fraction.getFraction(2, 1);
        assertThrows(ArithmeticException.class, () -> a.multiplyBy(b));
    }

    @Test
    public void testDivideByBasic() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(1, 3);
        final Fraction quotient = a.divideBy(b);
        assertEquals(3, quotient.getNumerator());
        assertEquals(2, quotient.getDenominator());
    }

    @Test
    public void testDivideByZeroThrows() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertThrows(ArithmeticException.class, () -> a.divideBy(Fraction.ZERO));
    }

    @Test
    public void testDivideByNullThrows() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, () -> a.divideBy(null));
    }

    @Test
    public void testInvertBasic() {
        final Fraction f = Fraction.getFraction(2, 5);
        final Fraction inv = f.invert();
        assertEquals(5, inv.getNumerator());
        assertEquals(2, inv.getDenominator());
    }

    @Test
    public void testInvertNegative() {
        final Fraction f = Fraction.getFraction(-2, 5);
        final Fraction inv = f.invert();
        assertEquals(-5, inv.getNumerator());
        assertEquals(2, inv.getDenominator());
    }

    @Test
    public void testInvertZeroThrows() {
        assertThrows(ArithmeticException.class, Fraction.ZERO::invert);
    }

    @Test
    public void testInvertMinValueNumeratorThrows() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, f::invert);
    }

    @Test
    public void testNegateBasic() {
        final Fraction f = Fraction.getFraction(3, 7);
        final Fraction neg = f.negate();
        assertEquals(-3, neg.getNumerator());
        assertEquals(7, neg.getDenominator());
    }

    @Test
    public void testNegateMinValueThrows() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, f::negate);
    }

    @Test
    public void testPowOne() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertSame(f, f.pow(1));
    }

    @Test
    public void testPowZeroReturnsOneEvenForZeroFraction() {
        assertSame(Fraction.ONE, Fraction.ZERO.pow(0));
    }

    @Test
    public void testPowPositive() {
        final Fraction f = Fraction.getFraction(2, 3);
        final Fraction result = f.pow(3);
        assertEquals(8, result.getNumerator());
        assertEquals(27, result.getDenominator());
    }

    @Test
    public void testPowNegative() {
        final Fraction f = Fraction.getFraction(2, 3);
        final Fraction result = f.pow(-2);
        assertEquals(9, result.getNumerator());
        assertEquals(4, result.getDenominator());
    }

    @Test
    public void testPowMinValueOverflowThrows() {
        final Fraction f = Fraction.getFraction(2, 1);
        assertThrows(ArithmeticException.class, () -> f.pow(Integer.MIN_VALUE));
    }

    @Test
    public void testPowMinValueOnOneDoesNotOverflow() {
        final Fraction result = Fraction.ONE.pow(Integer.MIN_VALUE);
        assertEquals(1, result.getNumerator());
        assertEquals(1, result.getDenominator());
    }

    @Test
    public void testReduceAlreadyReducedReturnsThis() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertSame(f, f.reduce());
    }

    @Test
    public void testReduceReducesFraction() {
        final Fraction f = Fraction.getFraction(4, 8);
        final Fraction reduced = f.reduce();
        assertEquals(1, reduced.getNumerator());
        assertEquals(2, reduced.getDenominator());
    }

    @Test
    public void testReduceZeroNumeratorReturnsZeroConstant() {
        final Fraction f = Fraction.getFraction(0, 5);
        assertSame(Fraction.ZERO, f.reduce());
    }

    @Test
    public void testCompareToEqualValuesDifferentRepresentation() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(2, 4);
        assertEquals(0, a.compareTo(b));
    }

    @Test
    public void testCompareToLessAndGreater() {
        final Fraction a = Fraction.getFraction(1, 3);
        final Fraction b = Fraction.getFraction(1, 2);
        assertTrue(a.compareTo(b) < 0);
        assertTrue(b.compareTo(a) > 0);
    }

    @Test
    public void testCompareToSameInstance() {
        final Fraction a = Fraction.getFraction(1, 3);
        assertEquals(0, a.compareTo(a));
    }

    @Test
    public void testCompareToNullThrows() {
        final Fraction a = Fraction.getFraction(1, 3);
        assertThrows(NullPointerException.class, () -> a.compareTo(null));
    }

    @Test
    public void testEqualsSameValueSameRepresentation() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(1, 2);
        assertEquals(a, b);
    }

    @Test
    public void testEqualsDifferentRepresentationNotEqual() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(2, 4);
        assertNotEquals(a, b);
    }

    @Test
    public void testEqualsNullIsFalse() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertFalse(a.equals(null));
    }

    @Test
    public void testEqualsDifferentTypeIsFalse() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertFalse(a.equals("1/2"));
    }

    @Test
    public void testEqualsSameInstance() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertEquals(a, a);
    }

    @Test
    public void testHashCodeConsistentWithEquals() {
        final Fraction a = Fraction.getFraction(3, 7);
        final Fraction b = Fraction.getFraction(3, 7);
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    public void testHashCodeDifferentForDifferentRepresentation() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(2, 4);
        assertNotEquals(a.hashCode(), b.hashCode());
    }

    @Test
    public void testDoubleFloatIntLongValues() {
        final Fraction f = Fraction.getFraction(3, 2);
        assertEquals(1.5d, f.doubleValue(), 0.0000001d);
        assertEquals(1.5f, f.floatValue(), 0.0000001f);
        assertEquals(1, f.intValue());
        assertEquals(1L, f.longValue());
    }

    @Test
    public void testIntValueNegativeTruncatesTowardZero() {
        final Fraction f = Fraction.getFraction(-3, 2);
        assertEquals(-1, f.intValue());
    }

    @Test
    public void testGetProperNumeratorAndWhole() {
        final Fraction f = Fraction.getFraction(7, 4);
        assertEquals(3, f.getProperNumerator());
        assertEquals(1, f.getProperWhole());
    }

    @Test
    public void testGetProperNumeratorAndWholeNegative() {
        final Fraction f = Fraction.getFraction(-7, 4);
        assertEquals(3, f.getProperNumerator());
        assertEquals(-1, f.getProperWhole());
    }

    @Test
    public void testToStringFormat() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertEquals("3/7", f.toString());
    }

    @Test
    public void testToStringCachesResult() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertSame(f.toString(), f.toString());
    }

    @Test
    public void testToProperStringZero() {
        assertEquals("0", Fraction.ZERO.toProperString());
    }

    @Test
    public void testToProperStringOne() {
        final Fraction f = Fraction.getFraction(4, 4);
        assertEquals("1", f.toProperString());
    }

    @Test
    public void testToProperStringMinusOne() {
        final Fraction f = Fraction.getFraction(-4, 4);
        assertEquals("-1", f.toProperString());
    }

    @Test
    public void testToProperStringWholeAndFraction() {
        final Fraction f = Fraction.getFraction(7, 4);
        assertEquals("1 3/4", f.toProperString());
    }

    @Test
    public void testToProperStringNegativeWholeAndFraction() {
        final Fraction f = Fraction.getFraction(-7, 4);
        assertEquals("-1 3/4", f.toProperString());
    }

    @Test
    public void testToProperStringProperFractionNoWhole() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertEquals("3/7", f.toProperString());
    }

    @Test
    public void testToProperStringCachesResult() {
        final Fraction f = Fraction.getFraction(7, 4);
        assertSame(f.toProperString(), f.toProperString());
    }
}
