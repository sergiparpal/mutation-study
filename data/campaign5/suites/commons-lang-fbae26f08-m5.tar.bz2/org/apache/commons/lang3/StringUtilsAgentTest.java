/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link StringUtils}.
 */
class StringUtilsAgentTest {

    @Test
    void testIsEmptyIsBlank() {
        assertTrue(StringUtils.isEmpty(null));
        assertTrue(StringUtils.isEmpty(""));
        assertFalse(StringUtils.isEmpty(" "));
        assertFalse(StringUtils.isEmpty("bob"));

        assertTrue(StringUtils.isBlank(null));
        assertTrue(StringUtils.isBlank(""));
        assertTrue(StringUtils.isBlank("  \t\n"));
        assertFalse(StringUtils.isBlank("bob"));
        assertFalse(StringUtils.isBlank("  bob  "));

        assertTrue(StringUtils.isNotEmpty("bob"));
        assertFalse(StringUtils.isNotEmpty(""));
        assertTrue(StringUtils.isNotBlank("bob"));
        assertFalse(StringUtils.isNotBlank(" "));
    }

    @Test
    void testTrimAndStrip() {
        assertNull(StringUtils.trim(null));
        assertEquals("", StringUtils.trim(""));
        assertEquals("", StringUtils.trim("   "));
        assertEquals("abc", StringUtils.trim("  abc  "));

        assertNull(StringUtils.trimToNull("   "));
        assertNull(StringUtils.trimToNull(null));
        assertEquals("abc", StringUtils.trimToNull("  abc  "));

        assertEquals("", StringUtils.trimToEmpty(null));
        assertEquals("abc", StringUtils.trimToEmpty(" abc "));

        assertNull(StringUtils.strip(null));
        assertEquals("abc", StringUtils.strip("  abc  "));
        assertEquals("abc", StringUtils.strip("xxabcxx", "x"));

        assertNull(StringUtils.stripStart(null, "x"));
        assertEquals("abcxx", StringUtils.stripStart("xxabcxx", "x"));
        assertNull(StringUtils.stripEnd(null, "x"));
        assertEquals("xxabc", StringUtils.stripEnd("xxabcxx", "x"));

        assertEquals("", StringUtils.stripToEmpty(null));
        assertNull(StringUtils.stripToNull("   "));
    }

    @Test
    void testEquals() {
        assertTrue(StringUtils.equals(null, null));
        assertFalse(StringUtils.equals(null, "abc"));
        assertFalse(StringUtils.equals("abc", null));
        assertTrue(StringUtils.equals("abc", "abc"));
        assertFalse(StringUtils.equals("abc", "ABC"));

        assertTrue(StringUtils.equalsIgnoreCase(null, null));
        assertFalse(StringUtils.equalsIgnoreCase(null, "abc"));
        assertTrue(StringUtils.equalsIgnoreCase("abc", "ABC"));
        assertFalse(StringUtils.equalsIgnoreCase("abc", "abd"));

        assertTrue(StringUtils.equalsAny("abc", "xyz", "abc"));
        assertFalse(StringUtils.equalsAny("abc", "xyz", "def"));
        assertFalse(StringUtils.equalsAny(null));

        assertTrue(StringUtils.equalsAnyIgnoreCase("abc", "xyz", "ABC"));
    }

    @Test
    void testCompare() {
        assertEquals(0, StringUtils.compare(null, null));
        assertTrue(StringUtils.compare(null, "a") < 0);
        assertTrue(StringUtils.compare("a", null) > 0);
        assertTrue(StringUtils.compare("a", "b") < 0);

        assertTrue(StringUtils.compare(null, "a", true) < 0);
        assertTrue(StringUtils.compare(null, "a", false) > 0);

        assertEquals(0, StringUtils.compareIgnoreCase("ABC", "abc"));
    }

    @Test
    void testIndexOf() {
        assertEquals(-1, StringUtils.indexOf(null, "a"));
        assertEquals(-1, StringUtils.indexOf("abc", null));
        assertEquals(0, StringUtils.indexOf("", ""));
        assertEquals(2, StringUtils.indexOf("abc", "c"));
        assertEquals(2, StringUtils.indexOf("aabaabaa", "b", 0));
        assertEquals(5, StringUtils.indexOf("aabaabaa", "b", 3));

        assertEquals(-1, StringUtils.indexOf(null, 'a'));
        assertEquals(0, StringUtils.indexOf("aabaabaa", 'a'));
        assertEquals(2, StringUtils.indexOf("aabaabaa", 'b', 0));

        assertEquals(-1, StringUtils.lastIndexOf(null, "a"));
        assertEquals(7, StringUtils.lastIndexOf("aabaabaa", "a"));
        assertEquals(5, StringUtils.lastIndexOf("aabaabaa", "b", 6));

        assertEquals(0, StringUtils.indexOfIgnoreCase("aabaabaa", "A"));
        assertEquals(0, StringUtils.indexOfAny("zzabyycdxx", 'z', 'a'));
        assertEquals(-1, StringUtils.indexOfAny((CharSequence) null, 'a'));

        assertEquals(3, StringUtils.ordinalIndexOf("aabaabaa", "a", 3));
        assertEquals(-1, StringUtils.ordinalIndexOf(null, "a", 1));
    }

    @Test
    void testContains() {
        assertFalse(StringUtils.contains(null, "a"));
        assertFalse(StringUtils.contains("abc", null));
        assertTrue(StringUtils.contains("abc", ""));
        assertTrue(StringUtils.contains("abc", "b"));
        assertFalse(StringUtils.contains("abc", "z"));

        assertFalse(StringUtils.contains(null, 'a'));
        assertTrue(StringUtils.contains("abc", 'a'));

        assertTrue(StringUtils.containsIgnoreCase("abc", "B"));
        assertFalse(StringUtils.containsIgnoreCase(null, "B"));

        assertTrue(StringUtils.containsAny("abc", 'z', 'a'));
        assertFalse(StringUtils.containsAny((CharSequence) null, 'z', 'a'));
        assertTrue(StringUtils.containsAny("abc", "x", "a"));

        assertTrue(StringUtils.containsNone("abab", 'x', 'y', 'z'));
        assertFalse(StringUtils.containsNone("abab", 'x', 'y', 'a'));

        assertTrue(StringUtils.containsOnly("abab", 'a', 'b'));
        assertFalse(StringUtils.containsOnly("abab", 'a'));
        assertFalse(StringUtils.containsOnly(null, 'a'));

        assertTrue(StringUtils.containsWhitespace(" "));
        assertFalse(StringUtils.containsWhitespace("abc"));
    }

    @Test
    void testStartsEndsWith() {
        assertTrue(StringUtils.startsWith("abcdef", "abc"));
        assertFalse(StringUtils.startsWith(null, "abc"));
        assertFalse(StringUtils.startsWith("abc", null));
        assertTrue(StringUtils.startsWith(null, null));

        assertTrue(StringUtils.startsWithIgnoreCase("abcdef", "ABC"));
        assertTrue(StringUtils.startsWithAny("abcxyz", "xyz", "abc"));
        assertFalse(StringUtils.startsWithAny("abcxyz", "xyz", "qq"));

        assertTrue(StringUtils.endsWith("abcdef", "def"));
        assertFalse(StringUtils.endsWith(null, "def"));
        assertTrue(StringUtils.endsWithIgnoreCase("abcdef", "DEF"));
        assertTrue(StringUtils.endsWithAny("abcxyz", "abc", "xyz"));
    }

    @Test
    void testSubstring() {
        assertNull(StringUtils.substring(null, 0));
        assertEquals("", StringUtils.substring("", 0));
        assertEquals("cde", StringUtils.substring("abcde", 2));
        assertEquals("de", StringUtils.substring("abcde", -2));
        assertEquals("", StringUtils.substring("abcde", 10));

        assertNull(StringUtils.substring(null, 0, 1));
        assertEquals("ab", StringUtils.substring("abc", 0, 2));
        assertEquals("abc", StringUtils.substring("abc", 0, 10));
        assertEquals("", StringUtils.substring("abc", 2, 0));

        assertNull(StringUtils.substringAfter(null, "a"));
        assertEquals("", StringUtils.substringAfter("abc", "c"));
        assertEquals("", StringUtils.substringAfter("abc", "d"));
        assertEquals("bc", StringUtils.substringAfter("abc", "a"));
        assertEquals("abc", StringUtils.substringAfter("abc", ""));

        assertEquals("", StringUtils.substringBefore("abc", "a"));
        assertEquals("abc", StringUtils.substringBefore("abc", "d"));
        assertEquals("ab", StringUtils.substringBefore("abc", "c"));

        assertEquals("a", StringUtils.substringAfterLast("aba", "b"));
        assertEquals("", StringUtils.substringAfterLast("abc", "c"));
        assertNull(StringUtils.substringAfterLast(null, "c"));

        assertEquals("abc", StringUtils.substringBeforeLast("abcba", "b"));

        assertEquals("b", StringUtils.substringBetween("wx[b]yz", "[", "]"));
        assertNull(StringUtils.substringBetween(null, "x"));

        assertArrayEquals(new String[] {"a", "b"}, StringUtils.substringsBetween("[a][b]", "[", "]"));
        assertNull(StringUtils.substringsBetween(null, "[", "]"));
    }

    @Test
    void testLeftRightMid() {
        assertNull(StringUtils.left(null, 3));
        assertEquals("", StringUtils.left("abc", -1));
        assertEquals("ab", StringUtils.left("abc", 2));
        assertEquals("abc", StringUtils.left("abc", 10));

        assertNull(StringUtils.right(null, 3));
        assertEquals("", StringUtils.right("abc", -1));
        assertEquals("bc", StringUtils.right("abc", 2));
        assertEquals("abc", StringUtils.right("abc", 10));

        assertNull(StringUtils.mid(null, 0, 2));
        assertEquals("", StringUtils.mid("abc", 0, -1));
        assertEquals("ab", StringUtils.mid("abc", 0, 2));
        assertEquals("bc", StringUtils.mid("abc", 1, 5));
        assertEquals("", StringUtils.mid("abc", 10, 2));
    }

    @Test
    void testPadding() {
        assertNull(StringUtils.leftPad(null, 3));
        assertEquals("abc", StringUtils.leftPad("abc", 2));
        assertEquals("  abc", StringUtils.leftPad("abc", 5));
        assertEquals("xxabc", StringUtils.leftPad("abc", 5, 'x'));
        assertEquals("xxabc", StringUtils.leftPad("abc", 5, "x"));

        assertNull(StringUtils.rightPad(null, 3));
        assertEquals("abc  ", StringUtils.rightPad("abc", 5));
        assertEquals("abcxx", StringUtils.rightPad("abc", 5, 'x'));

        assertNull(StringUtils.center(null, 4));
        assertEquals("abc", StringUtils.center("abc", 2));
        assertEquals(" abc ", StringUtils.center("abc", 5));
        assertEquals("xabcx", StringUtils.center("abc", 5, 'x'));
    }

    @Test
    void testCaseConversion() {
        assertNull(StringUtils.upperCase(null));
        assertEquals("ABC", StringUtils.upperCase("abc"));
        assertNull(StringUtils.lowerCase(null));
        assertEquals("abc", StringUtils.lowerCase("ABC"));

        assertNull(StringUtils.capitalize(null));
        assertEquals("", StringUtils.capitalize(""));
        assertEquals("Cat", StringUtils.capitalize("cat"));
        assertEquals("CAt", StringUtils.capitalize("CAt"));

        assertNull(StringUtils.uncapitalize(null));
        assertEquals("cat", StringUtils.uncapitalize("Cat"));

        assertNull(StringUtils.swapCase(null));
        assertEquals("", StringUtils.swapCase(""));
        assertEquals("tHE DOG HAS A bone", StringUtils.swapCase("The dog has a BONE"));
    }

    @Test
    void testIsAlphaNumeric() {
        assertFalse(StringUtils.isAlpha(null));
        assertFalse(StringUtils.isAlpha(""));
        assertFalse(StringUtils.isAlpha(" "));
        assertTrue(StringUtils.isAlpha("abc"));
        assertFalse(StringUtils.isAlpha("ab2c"));

        assertFalse(StringUtils.isNumeric(null));
        assertFalse(StringUtils.isNumeric(""));
        assertTrue(StringUtils.isNumeric("123"));
        assertFalse(StringUtils.isNumeric("12.3"));
        assertFalse(StringUtils.isNumeric("-123"));

        assertFalse(StringUtils.isAlphanumeric(null));
        assertTrue(StringUtils.isAlphanumeric("ab12"));
        assertFalse(StringUtils.isAlphanumeric("ab 12"));

        assertTrue(StringUtils.isAlphanumericSpace("ab 12"));
        assertFalse(StringUtils.isAlphanumericSpace("ab_12"));

        assertTrue(StringUtils.isNumericSpace("12 3"));
        assertTrue(StringUtils.isWhitespace("   "));
        assertFalse(StringUtils.isWhitespace("a "));

        assertTrue(StringUtils.isAllLowerCase("abc"));
        assertFalse(StringUtils.isAllLowerCase("abC"));
        assertFalse(StringUtils.isAllLowerCase(null));

        assertTrue(StringUtils.isAllUpperCase("ABC"));
        assertFalse(StringUtils.isAllUpperCase(null));

        assertTrue(StringUtils.isMixedCase("aBc"));
        assertFalse(StringUtils.isMixedCase("ABC"));
        assertFalse(StringUtils.isMixedCase(null));
        assertFalse(StringUtils.isMixedCase(""));
    }

    @Test
    void testBlankEmptyHelpers() {
        assertTrue(StringUtils.isAnyEmpty("a", ""));
        assertFalse(StringUtils.isAnyEmpty("a", "b"));
        assertTrue(StringUtils.isAllEmpty("", null));
        assertFalse(StringUtils.isAllEmpty("", "b"));

        assertTrue(StringUtils.isAnyBlank("a", " "));
        assertFalse(StringUtils.isAnyBlank("a", "b"));
        assertTrue(StringUtils.isAllBlank(" ", null));

        assertTrue(StringUtils.isNoneEmpty("a", "b"));
        assertFalse(StringUtils.isNoneEmpty("a", ""));
        assertTrue(StringUtils.isNoneBlank("a", "b"));
        assertFalse(StringUtils.isNoneBlank("a", " "));

        assertEquals("abc", StringUtils.defaultString("abc"));
        assertEquals("", StringUtils.defaultString(null));
        assertEquals("NULL", StringUtils.defaultString(null, "NULL"));

        assertEquals("abc", StringUtils.defaultIfEmpty("abc", "def"));
        assertEquals("def", StringUtils.defaultIfEmpty("", "def"));
        assertEquals("def", StringUtils.defaultIfBlank(" ", "def"));

        assertEquals("abc", StringUtils.firstNonBlank(null, "", " ", "abc"));
        assertNull(StringUtils.firstNonBlank((String) null, (String) null));
        assertEquals("abc", StringUtils.firstNonEmpty(null, "", "abc"));
    }

    @Test
    void testCountMatchesAndRemove() {
        assertEquals(0, StringUtils.countMatches(null, "a"));
        assertEquals(0, StringUtils.countMatches("abba", ""));
        assertEquals(2, StringUtils.countMatches("abba", "a"));
        assertEquals(1, StringUtils.countMatches("abba", "ab"));

        assertEquals(0, StringUtils.countMatches(null, 'a'));
        assertEquals(2, StringUtils.countMatches("abba", 'a'));

        assertNull(StringUtils.remove(null, 'a'));
        assertEquals("bb", StringUtils.remove("abba", 'a'));
        assertNull(StringUtils.remove(null, "a"));
        assertEquals("bb", StringUtils.remove("abba", "a"));

        assertNull(StringUtils.removeStart(null, "a"));
        assertEquals("bba", StringUtils.removeStart("abba", "a"));
        assertEquals("abba", StringUtils.removeStart("abba", "x"));

        assertNull(StringUtils.removeEnd(null, "a"));
        assertEquals("abb", StringUtils.removeEnd("abba", "a"));

        assertEquals("bba", StringUtils.removeStartIgnoreCase("Abba", "a"));
        assertEquals("abb", StringUtils.removeEndIgnoreCase("abbA", "a"));
        assertEquals("bb", StringUtils.removeIgnoreCase("abba", "A"));
    }

    @Test
    void testReplace() {
        assertNull(StringUtils.replace(null, "a", "b"));
        assertEquals("abba", StringUtils.replace("abba", null, "x"));
        assertEquals("fofoo", StringUtils.replace("foofoo", "oo", "o", 1));
        assertEquals("foofoo", StringUtils.replace("foofoo", "foo", "foo", 1));
        assertEquals("zzzzzzzzz", StringUtils.replace("aaa", "a", "zzz", -1));

        assertEquals("zbcz", StringUtils.replaceChars("abca", 'a', 'z'));
        assertNull(StringUtils.replaceChars(null, "a", "z"));

        assertEquals("woo", StringUtils.replaceEach("hello", new String[] {"hello"}, new String[] {"woo"}));
        assertThrows(IllegalStateException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.replaceEachRepeatedly("abc", new String[] {"a"}, new String[] {"ba"});
            }
        });

        assertEquals("foofoo", StringUtils.replaceOnce("foofoo", "foo", "foo"));
        assertEquals("barfoo", StringUtils.replaceOnce("foofoo", "foo", "bar"));
        assertEquals("bar", StringUtils.replaceOnceIgnoreCase("FOO", "foo", "bar"));
    }

    @Test
    void testJoin() {
        assertNull(StringUtils.join((Object[]) null, ','));
        assertEquals("", StringUtils.join(new Object[0], ','));
        assertEquals("a,b,c", StringUtils.join(new Object[] {"a", "b", "c"}, ','));
        assertEquals("a,,c", StringUtils.join(new Object[] {"a", null, "c"}, ','));

        assertEquals("a-b-c", StringUtils.join(new Object[] {"a", "b", "c"}, "-"));
        assertEquals("abc", StringUtils.join(new Object[] {"a", "b", "c"}, (String) null));

        final List<String> list = new ArrayList<String>();
        list.add("a");
        list.add("b");
        assertEquals("a,b", StringUtils.join((Iterable<?>) list, ','));
        assertEquals("a,b", StringUtils.join(list.iterator(), ','));

        assertEquals("1,2,3", StringUtils.join(new int[] {1, 2, 3}, ','));
        assertEquals("1-2", StringUtils.join(new int[] {1, 2, 3}, '-', 0, 2));

        assertEquals("a:b:c", StringUtils.joinWith(":", "a", "b", "c"));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.joinWith(",", (Object[]) null);
            }
        });
    }

    @Test
    void testSplit() {
        assertNull(StringUtils.split(null));
        assertArrayEquals(new String[0], StringUtils.split(""));
        assertArrayEquals(new String[] {"ab", "cd", "ef"}, StringUtils.split("ab cd ef"));
        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.split("a.b.c", '.'));
        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.split("a..b.c", "."));
        assertArrayEquals(new String[] {"a", "b.c"}, StringUtils.split("a.b.c", ".", 2));

        assertArrayEquals(new String[] {"ab", "", "cd"}, StringUtils.splitPreserveAllTokens("ab  cd", ' '));
        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.splitByWholeSeparator("a..b.c", "."));
        assertArrayEquals(new String[] {"a", "", "b", "c"}, StringUtils.splitByWholeSeparatorPreserveAllTokens("a..b.c", "."));

        assertArrayEquals(new String[] {"ab", "DEF", "g"}, StringUtils.splitByCharacterType("abDEFg"));
        assertNull(StringUtils.splitByCharacterType(null));
    }

    @Test
    void testRepeatAndReverse() {
        assertNull(StringUtils.repeat((String) null, 2));
        assertEquals("", StringUtils.repeat("ab", 0));
        assertEquals("", StringUtils.repeat("ab", -1));
        assertEquals("ababab", StringUtils.repeat("ab", 3));
        assertEquals("aaa", StringUtils.repeat('a', 3));
        assertEquals("", StringUtils.repeat('a', 0));
        assertEquals("a,a,a", StringUtils.repeat("a", ",", 3));

        assertNull(StringUtils.reverse(null));
        assertEquals("", StringUtils.reverse(""));
        assertEquals("cba", StringUtils.reverse("abc"));

        assertNull(StringUtils.reverseDelimited(null, '.'));
        assertEquals("c.b.a", StringUtils.reverseDelimited("a.b.c", '.'));
    }

    @Test
    void testAbbreviateAndTruncate() {
        assertNull(StringUtils.abbreviate(null, 4));
        assertEquals("abc", StringUtils.abbreviate("abc", 4));
        assertEquals("abcd...", StringUtils.abbreviate("abcdefgh", 7));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.abbreviate("abcdefg", 3);
            }
        });

        assertEquals("...fg", StringUtils.abbreviate("abcdefg", 5, 5));

        assertNull(StringUtils.truncate(null, 4));
        assertEquals("", StringUtils.truncate("abcdef", 0));
        assertEquals("abcd", StringUtils.truncate("abcdef", 4));
        assertEquals("abcdef", StringUtils.truncate("abcdef", 10));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.truncate("abcdef", -1);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.truncate("abcdef", -1, 2);
            }
        });

        assertEquals("ab...yz", StringUtils.abbreviateMiddle("abcdefghijklmnopqrstuvwxyz", "...", 7));
        assertEquals("abcdefghijklmnopqrstuvwxyz", StringUtils.abbreviateMiddle("abcdefghijklmnopqrstuvwxyz", "...", 100));
    }

    @Test
    void testWrapAndUnwrap() {
        assertNull(StringUtils.wrap(null, 'x'));
        assertEquals("'abc'", StringUtils.wrap("abc", '\''));
        assertEquals("xabcx", StringUtils.wrap("abc", 'x'));

        assertNull(StringUtils.wrap(null, "xyz"));
        assertEquals("xyzabcxyz", StringUtils.wrap("abc", "xyz"));

        assertEquals("xabcx", StringUtils.wrapIfMissing("abcx", 'x'));
        assertEquals("xabcx", StringUtils.wrapIfMissing("xabcx", 'x'));

        assertNull(StringUtils.unwrap(null, 'x'));
        assertEquals("abc", StringUtils.unwrap("xabcx", 'x'));
        assertEquals("xabc", StringUtils.unwrap("xabc", 'x'));

        assertEquals("abc", StringUtils.unwrap("\"abc\"", "\""));
    }

    @Test
    void testGetCommonPrefixAndDistance() {
        assertEquals("", StringUtils.getCommonPrefix());
        assertEquals("", StringUtils.getCommonPrefix((String[]) null));
        assertEquals("", StringUtils.getCommonPrefix("abc", null));
        assertEquals("ab", StringUtils.getCommonPrefix("abc", "abd"));
        assertEquals("", StringUtils.getCommonPrefix("abc", "xyz"));

        assertEquals(0, StringUtils.getLevenshteinDistance("", ""));
        assertEquals(3, StringUtils.getLevenshteinDistance("", "abc"));
        assertEquals(1, StringUtils.getLevenshteinDistance("abc", "abd"));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                StringUtils.getLevenshteinDistance(null, "abc");
            }
        });

        assertEquals(1, StringUtils.getLevenshteinDistance("abc", "abd", 5));
        assertEquals(-1, StringUtils.getLevenshteinDistance("abc", "xyz", 1));

        assertEquals("", StringUtils.difference("abc", "abc"));
        assertEquals("yz", StringUtils.difference("abc", "abyz"));
        assertEquals("abc", StringUtils.difference(null, "abc"));
    }

    @Test
    void testNormalizeSpaceAndDeleteWhitespace() {
        assertNull(StringUtils.normalizeSpace(null));
        assertEquals("", StringUtils.normalizeSpace(""));
        assertEquals("ab c", StringUtils.normalizeSpace(" ab   c "));

        assertNull(StringUtils.deleteWhitespace(null));
        assertEquals("", StringUtils.deleteWhitespace("   "));
        assertEquals("abc", StringUtils.deleteWhitespace(" a b c "));
    }

    @Test
    void testChompChop() {
        assertNull(StringUtils.chomp(null));
        assertEquals("", StringUtils.chomp(""));
        assertEquals("abc", StringUtils.chomp("abc\n"));
        assertEquals("abc", StringUtils.chomp("abc\r\n"));
        assertEquals("abc", StringUtils.chomp("abc"));

        assertNull(StringUtils.chop(null));
        assertEquals("", StringUtils.chop(""));
        assertEquals("abc", StringUtils.chop("abcx"));
        assertEquals("", StringUtils.chop("x"));
    }

    @Test
    void testLengthAndValueOf() {
        assertEquals(0, StringUtils.length(null));
        assertEquals(3, StringUtils.length("abc"));

        assertNull(StringUtils.valueOf(null));
        assertEquals("abc", StringUtils.valueOf(new char[] {'a', 'b', 'c'}));
    }

    @Test
    void testOverlayAndAppendPrepend() {
        assertEquals("abef", StringUtils.overlay("abcdef", "", 2, 4));
        assertEquals("abzzzef", StringUtils.overlay("abcdef", "zzz", 2, 4));
        assertNull(StringUtils.overlay(null, "x", 0, 0));

        assertEquals("abc.txt", StringUtils.appendIfMissing("abc", ".txt"));
        assertEquals("abc.txt", StringUtils.appendIfMissing("abc.txt", ".txt"));
        assertEquals("abc.TXT", StringUtils.appendIfMissingIgnoreCase("abc.TXT", ".txt"));

        assertEquals("/abc", StringUtils.prependIfMissing("abc", "/"));
        assertEquals("/abc", StringUtils.prependIfMissing("/abc", "/"));
    }

    @Test
    void testStripAccentsAndToRootCase() {
        assertNull(StringUtils.stripAccents(null));
        assertEquals("", StringUtils.stripAccents(""));
        assertEquals("eclair", StringUtils.stripAccents("éclair"));

        assertNull(StringUtils.toRootLowerCase(null));
        assertEquals("abc", StringUtils.toRootLowerCase("ABC"));
        assertNull(StringUtils.toRootUpperCase(null));
        assertEquals("ABC", StringUtils.toRootUpperCase("abc"));
    }

    @Test
    void testStripAllAndToCodePoints() {
        assertNull(StringUtils.stripAll((String[]) null));
        assertArrayEquals(new String[] {"abc", "def"}, StringUtils.stripAll(" abc ", " def "));
        assertArrayEquals(new String[] {"abc", "def"}, StringUtils.stripAll(new String[] {"xabcx", "xdefx"}, "x"));

        assertArrayEquals(new int[0], StringUtils.toCodePoints(""));
        assertArrayEquals(new int[] {'a', 'b', 'c'}, StringUtils.toCodePoints("abc"));
        assertNull(StringUtils.toCodePoints(null));
    }

    @Test
    void testIndexOfDifference() {
        assertEquals(-1, StringUtils.indexOfDifference("abc", "abc"));
        assertEquals(0, StringUtils.indexOfDifference("abc", "xbc"));
        assertEquals(2, StringUtils.indexOfDifference("abc", "ab"));
        assertEquals(-1, StringUtils.indexOfDifference((CharSequence[]) null));
        assertEquals(-1, StringUtils.indexOfDifference(new CharSequence[] {"abc"}));
        assertEquals(1, StringUtils.indexOfDifference(new CharSequence[] {"abc", "a"}));
    }

    @Test
    void testRotate() {
        assertNull(StringUtils.rotate(null, 2));
        assertEquals("", StringUtils.rotate("", 2));
        assertEquals("abcde", StringUtils.rotate("abcde", 0));
        assertEquals("deabc", StringUtils.rotate("abcde", 2));
        assertEquals("deabc", StringUtils.rotate("abcde", -3));
    }

    @Test
    void testSplitByCharacterTypeCamelCase() {
        assertArrayEquals(new String[] {"ab", "De", "Fg"}, StringUtils.splitByCharacterTypeCamelCase("abDeFg"));
        assertNull(StringUtils.splitByCharacterTypeCamelCase(null));
    }

    @Test
    void testTrimAsciiControl() {
        assertNull(StringUtils.trimAsciiControl(null));
        assertEquals("abc", StringUtils.trimAsciiControl("\u0001abc\u0002"));
    }
}
