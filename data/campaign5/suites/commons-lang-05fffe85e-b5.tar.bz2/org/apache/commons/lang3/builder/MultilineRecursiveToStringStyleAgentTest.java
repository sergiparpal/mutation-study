/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.builder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link MultilineRecursiveToStringStyle}.
 */
class MultilineRecursiveToStringStyleAgentTest {

    static class Job {
        String title;
    }

    static class Person {
        String name;
        int age;
        boolean smoker;
        Job job;
    }

    private static final String LS = System.lineSeparator();

    private final Object base = new Object();

    private String baseStr() {
        return base.getClass().getName() + "@" + Integer.toHexString(System.identityHashCode(base));
    }

    @Test
    void testReflectionOfNestedObject() {
        final Person p = new Person();
        p.name = "John Doe";
        p.age = 33;
        p.smoker = false;
        p.job = new Job();
        p.job.title = "Manager";

        final ReflectionToStringBuilder builder = new ReflectionToStringBuilder(p, new MultilineRecursiveToStringStyle());
        final String personStr = p.getClass().getName() + "@" + Integer.toHexString(System.identityHashCode(p));
        final String jobStr = p.job.getClass().getName() + "@" + Integer.toHexString(System.identityHashCode(p.job));

        final String actual = builder.toString();
        if (builder.isForceAccessible()) {
            final String expected = personStr + "[" + LS
                    + "  age=33," + LS
                    + "  job=" + jobStr + "[" + LS
                    + "    title=Manager" + LS
                    + "  ]," + LS
                    + "  name=John Doe," + LS
                    + "  smoker=false" + LS
                    + "]";
            assertEquals(expected, actual);
        } else {
            assertTrue(actual.startsWith(personStr + "["), "Expected to start with " + personStr + "[, was: " + actual);
        }
    }

    @Test
    void testIntArrayField() {
        final String actual = new ToStringBuilder(base, new MultilineRecursiveToStringStyle()).append("nums", new int[] {1, 2, 3}).toString();
        final String expected = baseStr() + "[" + LS
                + "  nums={" + LS
                + "    1," + LS
                + "    2," + LS
                + "    3" + LS
                + "  }" + LS
                + "]";
        assertEquals(expected, actual);
    }

    @Test
    void testEmptyArrayField() {
        final String actual = new ToStringBuilder(base, new MultilineRecursiveToStringStyle()).append("nums", new int[0]).toString();
        final String expected = baseStr() + "[" + LS
                + "  nums={" + LS
                + "    " + LS
                + "  }" + LS
                + "]";
        assertEquals(expected, actual);
    }

    @Test
    void testNullObjectField() {
        final String actual = new ToStringBuilder(base, new MultilineRecursiveToStringStyle()).append("x", (Object) null).toString();
        assertEquals(baseStr() + "[" + LS + "  x=<null>" + LS + "]", actual);
    }

    @Test
    void testNullArrayField() {
        final int[] nullArray = null;
        final String actual = new ToStringBuilder(base, new MultilineRecursiveToStringStyle()).append("n", nullArray).toString();
        assertEquals(baseStr() + "[" + LS + "  n=<null>" + LS + "]", actual);
    }

    @Test
    void testPrimitiveWrapperFieldIsNotRecursed() {
        final String actual = new ToStringBuilder(base, new MultilineRecursiveToStringStyle()).append("i", Integer.valueOf(5), true).toString();
        assertEquals(baseStr() + "[" + LS + "  i=5" + LS + "]", actual);
    }

    @Test
    void testStringFieldIsNotRecursed() {
        final String actual = new ToStringBuilder(base, new MultilineRecursiveToStringStyle()).append("s", "hello", true).toString();
        assertEquals(baseStr() + "[" + LS + "  s=hello" + LS + "]", actual);
        assertFalse(actual.contains("char"), "A String must not be reflectively expanded into its internal fields");
    }

    @Test
    void testObjectArrayWithNestedObjectIsDoublyIndented() {
        final Job job = new Job();
        job.title = "Dev";
        final String actual = new ToStringBuilder(base, new MultilineRecursiveToStringStyle()).append("jobs", new Object[] {job}).toString();
        final String jobStr = job.getClass().getName() + "@" + Integer.toHexString(System.identityHashCode(job));
        final String expected = baseStr() + "[" + LS
                + "  jobs={" + LS
                + "    " + jobStr + "[" + LS
                + "      title=Dev" + LS
                + "    ]" + LS
                + "  }" + LS
                + "]";
        assertEquals(expected, actual);
    }

    @Test
    void testTwoDimensionalIntArray() {
        final String actual = new ToStringBuilder(base, new MultilineRecursiveToStringStyle()).append("m", new int[][] {{1, 2}, {3}}).toString();
        final String expected = baseStr() + "[" + LS
                + "  m={" + LS
                + "    {" + LS
                + "      1," + LS
                + "      2" + LS
                + "    }," + LS
                + "    {" + LS
                + "      3" + LS
                + "    }" + LS
                + "  }" + LS
                + "]";
        assertEquals(expected, actual);
    }

    @Test
    void testBooleanArrayField() {
        final String actual = new ToStringBuilder(base, new MultilineRecursiveToStringStyle()).append("b", new boolean[] {true, false}).toString();
        final String expected = baseStr() + "[" + LS
                + "  b={" + LS
                + "    true," + LS
                + "    false" + LS
                + "  }" + LS
                + "]";
        assertEquals(expected, actual);
    }

    @Test
    void testCharArrayField() {
        final String actual = new ToStringBuilder(base, new MultilineRecursiveToStringStyle()).append("c", new char[] {'a', 'b'}).toString();
        final String expected = baseStr() + "[" + LS
                + "  c={" + LS
                + "    a," + LS
                + "    b" + LS
                + "  }" + LS
                + "]";
        assertEquals(expected, actual);
    }

    @Test
    void testByteShortLongFloatDoubleArrayFields() {
        final String actual = new ToStringBuilder(base, new MultilineRecursiveToStringStyle())
                .append("by", new byte[] {1, 2})
                .append("sh", new short[] {3, 4})
                .append("lo", new long[] {5L, 6L})
                .append("fl", new float[] {1.5f})
                .append("do", new double[] {2.5})
                .toString();
        final String expected = baseStr() + "[" + LS
                + "  by={" + LS
                + "    1," + LS
                + "    2" + LS
                + "  }," + LS
                + "  sh={" + LS
                + "    3," + LS
                + "    4" + LS
                + "  }," + LS
                + "  lo={" + LS
                + "    5," + LS
                + "    6" + LS
                + "  }," + LS
                + "  fl={" + LS
                + "    1.5" + LS
                + "  }," + LS
                + "  do={" + LS
                + "    2.5" + LS
                + "  }" + LS
                + "]";
        assertEquals(expected, actual);
    }

    @Test
    void testRawObjectFieldHoldingPrimitiveArrayUsesReflectionAppendArrayDetail() {
        final String actual = new ToStringBuilder(base, new MultilineRecursiveToStringStyle()).append("arr", (Object) new int[] {1, 2}, true).toString();
        final String expected = baseStr() + "[" + LS
                + "  arr={" + LS
                + "    1," + LS
                + "    2" + LS
                + "  }" + LS
                + "]";
        assertEquals(expected, actual);
    }

    @Test
    void testStyleInstanceIsReusableAcrossMultipleToStringCallsWithoutAccumulatingIndent() {
        final MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        final String first = new ToStringBuilder(base, style).append("a", 1).toString();
        final String second = new ToStringBuilder(base, style).append("b", 2).toString();
        assertEquals(baseStr() + "[" + LS + "  a=1" + LS + "]", first);
        assertEquals(baseStr() + "[" + LS + "  b=2" + LS + "]", second);
    }

    @Test
    void testAppendDetailWithNullObjectValueThrowsNullPointerException() {
        final MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                style.appendDetail(buffer, "x", (Object) null);
            }
        });
    }

    @Test
    void testBlank() {
        final String actual = new ToStringBuilder(base, new MultilineRecursiveToStringStyle()).toString();
        assertEquals(baseStr() + "[" + LS + "  " + LS + "]", actual);
    }
}
