/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Tests for {@link Strings}.
 */
public class StringsAgentTest {

    // --- appendIfMissing ---

    @Test
    public void testAppendIfMissing_null() {
        assertNull(Strings.CS.appendIfMissing(null, null));
        assertNull(Strings.CS.appendIfMissing(null, "xyz"));
    }

    @Test
    public void testAppendIfMissing_nullSuffix() {
        assertEquals("abc", Strings.CS.appendIfMissing("abc", null));
    }

    @Test
    public void testAppendIfMissing_appends() {
        assertEquals("xyz", Strings.CS.appendIfMissing("", "xyz"));
        assertEquals("abcxyz", Strings.CS.appendIfMissing("abc", "xyz"));
    }

    @Test
    public void testAppendIfMissing_alreadyPresentCaseSensitive() {
        assertEquals("abcxyz", Strings.CS.appendIfMissing("abcxyz", "xyz"));
        assertEquals("abcXYZxyz", Strings.CS.appendIfMissing("abcXYZ", "xyz"));
    }

    @Test
    public void testAppendIfMissing_caseInsensitive() {
        assertEquals("abcXYZ", Strings.CI.appendIfMissing("abcXYZ", "xyz"));
    }

    @Test
    public void testAppendIfMissing_additionalSuffixes() {
        assertEquals("abc", Strings.CS.appendIfMissing("abc", "xyz", ""));
        assertEquals("abcxyz", Strings.CS.appendIfMissing("abc", "xyz", "mno"));
        assertEquals("abcmno", Strings.CS.appendIfMissing("abcmno", "xyz", "mno"));
        assertEquals("abcMNOxyz", Strings.CS.appendIfMissing("abcMNO", "xyz", "mno"));
        assertEquals("abcMNO", Strings.CI.appendIfMissing("abcMNO", "xyz", "mno"));
    }

    // --- compare ---

    @Test
    public void testCompareCS_bothNull() {
        assertEquals(0, Strings.CS.compare(null, null));
    }

    @Test
    public void testCompareCS_nullIsLessByDefault() {
        assertTrue(Strings.CS.compare(null, "a") < 0);
        assertTrue(Strings.CS.compare("a", null) > 0);
    }

    @Test
    public void testCompareCS_equalAndDifferentCase() {
        assertEquals(0, Strings.CS.compare("abc", "abc"));
        assertTrue(Strings.CS.compare("a", "B") > 0);
        assertTrue(Strings.CS.compare("ab", "abc") < 0);
    }

    @Test
    public void testCompareCI_ignoresCase() {
        assertEquals(0, Strings.CI.compare("abc", "ABC"));
        assertTrue(Strings.CI.compare("a", "B") < 0);
    }

    @Test
    public void testCompareCS_nullIsLessFalse() {
        final Strings nullIsGreater = Strings.builder().setIgnoreCase(false).setNullIsLess(false).get();
        assertTrue(nullIsGreater.compare(null, "a") > 0);
        assertTrue(nullIsGreater.compare("a", null) < 0);
    }

    // --- contains ---

    @Test
    public void testContainsCS_nullInputs() {
        assertFalse(Strings.CS.contains(null, "a"));
        assertFalse(Strings.CS.contains("a", null));
    }

    @Test
    public void testContainsCS_empty() {
        assertTrue(Strings.CS.contains("", ""));
        assertTrue(Strings.CS.contains("abc", ""));
    }

    @Test
    public void testContainsCS_caseSensitive() {
        assertTrue(Strings.CS.contains("abc", "a"));
        assertFalse(Strings.CS.contains("abc", "z"));
        assertFalse(Strings.CS.contains("abc", "A"));
    }

    @Test
    public void testContainsCI_caseInsensitive() {
        assertTrue(Strings.CI.contains("abc", "A"));
        assertFalse(Strings.CI.contains("abc", "Z"));
        assertFalse(Strings.CI.contains(null, "a"));
        assertFalse(Strings.CI.contains("a", null));
    }

    // --- containsAny ---

    @Test
    public void testContainsAnyCS_nullAndEmptyInputs() {
        assertFalse(Strings.CS.containsAny(null, "a"));
        assertFalse(Strings.CS.containsAny("", "a"));
        assertFalse(Strings.CS.containsAny("abc", (CharSequence[]) null));
        assertFalse(Strings.CS.containsAny("abc"));
    }

    @Test
    public void testContainsAnyCS_matches() {
        assertTrue(Strings.CS.containsAny("abcd", "ab", (CharSequence) null));
        assertTrue(Strings.CS.containsAny("abcd", "ab", "cd"));
        assertTrue(Strings.CS.containsAny("abc", "d", "abc"));
    }

    @Test
    public void testContainsAnyCI_matches() {
        assertTrue(Strings.CI.containsAny("abc", "D", "ABC"));
        assertTrue(Strings.CI.containsAny("ABC", "d", "abc"));
    }

    // --- endsWith ---

    @Test
    public void testEndsWithCS_bothNullIsTrue() {
        assertTrue(Strings.CS.endsWith(null, null));
    }

    @Test
    public void testEndsWithCS_oneNullIsFalse() {
        assertFalse(Strings.CS.endsWith(null, "def"));
        assertFalse(Strings.CS.endsWith("abcdef", null));
    }

    @Test
    public void testEndsWithCS_caseSensitive() {
        assertTrue(Strings.CS.endsWith("abcdef", "def"));
        assertFalse(Strings.CS.endsWith("ABCDEF", "def"));
        assertFalse(Strings.CS.endsWith("ABCDEF", "cde"));
        assertTrue(Strings.CS.endsWith("ABCDEF", ""));
    }

    @Test
    public void testEndsWithCS_suffixLongerThanString() {
        assertFalse(Strings.CS.endsWith("ab", "abcdef"));
    }

    @Test
    public void testEndsWithCI_caseInsensitive() {
        assertTrue(Strings.CI.endsWith("ABCDEF", "def"));
        assertFalse(Strings.CI.endsWith("ABCDEF", "cde"));
    }

    // --- endsWithAny ---

    @Test
    public void testEndsWithAnyCS_nullAndEmpty() {
        assertFalse(Strings.CS.endsWithAny(null, (CharSequence[]) null));
        assertFalse(Strings.CS.endsWithAny(null, "abc"));
        assertFalse(Strings.CS.endsWithAny("abcxyz", (CharSequence[]) null));
    }

    @Test
    public void testEndsWithAnyCS_matches() {
        assertTrue(Strings.CS.endsWithAny("abcxyz", ""));
        assertTrue(Strings.CS.endsWithAny("abcxyz", "xyz"));
        assertTrue(Strings.CS.endsWithAny("abcxyz", (CharSequence) null, "xyz", "abc"));
        assertTrue(Strings.CS.endsWithAny("abcXYZ", "def", "XYZ"));
        assertFalse(Strings.CS.endsWithAny("abcXYZ", "def", "xyz"));
    }

    // --- equals ---

    @Test
    public void testEqualsCSCharSequence_nulls() {
        assertTrue(Strings.CS.equals((CharSequence) null, (CharSequence) null));
        assertFalse(Strings.CS.equals((CharSequence) null, "abc"));
        assertFalse(Strings.CS.equals("abc", (CharSequence) null));
    }

    @Test
    public void testEqualsCSCharSequence_caseSensitive() {
        assertTrue(Strings.CS.equals((CharSequence) "abc", (CharSequence) "abc"));
        assertFalse(Strings.CS.equals((CharSequence) "abc", (CharSequence) "ABC"));
    }

    @Test
    public void testEqualsCSCharSequence_nonStringCharSequences() {
        final StringBuilder sb1 = new StringBuilder("abc");
        final StringBuilder sb2 = new StringBuilder("abc");
        assertTrue(Strings.CS.equals((CharSequence) sb1, (CharSequence) sb2));
        final StringBuilder sb3 = new StringBuilder("abd");
        assertFalse(Strings.CS.equals((CharSequence) sb1, (CharSequence) sb3));
    }

    @Test
    public void testEqualsCSString_nulls() {
        assertTrue(Strings.CS.equals((String) null, (String) null));
        assertFalse(Strings.CS.equals("abc", (String) null));
        assertFalse(Strings.CS.equals((String) null, "abc"));
    }

    @Test
    public void testEqualsCIString_ignoresCase() {
        assertTrue(Strings.CI.equals("abc", "ABC"));
        assertTrue(Strings.CI.equals((String) null, (String) null));
    }

    @Test
    public void testEqualsCICharSequence_ignoresCase() {
        assertTrue(Strings.CI.equals((CharSequence) "abc", (CharSequence) "ABC"));
        assertFalse(Strings.CI.equals((CharSequence) "abc", (CharSequence) "ABCD"));
    }

    // --- equalsAny ---

    @Test
    public void testEqualsAnyCS_nullSearchArray() {
        assertFalse(Strings.CS.equalsAny(null, (CharSequence[]) null));
    }

    @Test
    public void testEqualsAnyCS_matchesAndCaseSensitivity() {
        assertTrue(Strings.CS.equalsAny(null, null, null));
        assertFalse(Strings.CS.equalsAny(null, "abc", "def"));
        assertFalse(Strings.CS.equalsAny("abc", null, "def"));
        assertTrue(Strings.CS.equalsAny("abc", "abc", "def"));
        assertFalse(Strings.CS.equalsAny("abc", "ABC", "DEF"));
    }

    @Test
    public void testEqualsAnyCI_caseInsensitive() {
        assertTrue(Strings.CI.equalsAny("abc", "ABC", "DEF"));
    }

    // --- indexOf ---

    @Test
    public void testIndexOfCS_nullInputs() {
        assertEquals(-1, Strings.CS.indexOf(null, "a"));
        assertEquals(-1, Strings.CS.indexOf("a", null));
    }

    @Test
    public void testIndexOfCS_emptySearch() {
        assertEquals(0, Strings.CS.indexOf("", ""));
        assertEquals(-1, Strings.CS.indexOf("", "a"));
        assertEquals(0, Strings.CS.indexOf("aabaabaa", ""));
    }

    @Test
    public void testIndexOfCS_basic() {
        assertEquals(0, Strings.CS.indexOf("aabaabaa", "a"));
        assertEquals(2, Strings.CS.indexOf("aabaabaa", "b"));
        assertEquals(1, Strings.CS.indexOf("aabaabaa", "ab"));
    }

    @Test
    public void testIndexOfCSWithStart_boundaries() {
        assertEquals(5, Strings.CS.indexOf("aabaabaa", "b", 3));
        assertEquals(-1, Strings.CS.indexOf("aabaabaa", "b", 9));
        assertEquals(2, Strings.CS.indexOf("aabaabaa", "b", -1));
        assertEquals(2, Strings.CS.indexOf("aabaabaa", "", 2));
        assertEquals(3, Strings.CS.indexOf("abc", "", 9));
    }

    @Test
    public void testIndexOfCI_caseInsensitiveAndBoundary() {
        assertEquals(0, Strings.CI.indexOf("aabaabaa", "A", 0));
        assertEquals(2, Strings.CI.indexOf("aabaabaa", "B", 0));
        assertEquals(1, Strings.CI.indexOf("aabaabaa", "AB", 0));
        assertEquals(-1, Strings.CI.indexOf("aabaabaa", "B", 9));
        assertEquals(2, Strings.CI.indexOf("aabaabaa", "B", -1));
        assertEquals(-1, Strings.CI.indexOf("abc", "", 9));
    }

    // --- isCaseSensitive ---

    @Test
    public void testIsCaseSensitive() {
        assertTrue(Strings.CS.isCaseSensitive());
        assertFalse(Strings.CI.isCaseSensitive());
    }

    // --- lastIndexOf ---

    @Test
    public void testLastIndexOfCS_nullInputs() {
        assertEquals(-1, Strings.CS.lastIndexOf(null, "a"));
        assertEquals(-1, Strings.CS.lastIndexOf("a", null));
    }

    @Test
    public void testLastIndexOfCS_basic() {
        assertEquals(0, Strings.CS.lastIndexOf("", ""));
        assertEquals(7, Strings.CS.lastIndexOf("aabaabaa", "a"));
        assertEquals(5, Strings.CS.lastIndexOf("aabaabaa", "b"));
        assertEquals(4, Strings.CS.lastIndexOf("aabaabaa", "ab"));
        assertEquals(8, Strings.CS.lastIndexOf("aabaabaa", ""));
    }

    @Test
    public void testLastIndexOfCSWithStart_boundaries() {
        assertEquals(7, Strings.CS.lastIndexOf("aabaabaa", "a", 8));
        assertEquals(5, Strings.CS.lastIndexOf("aabaabaa", "b", 9));
        assertEquals(-1, Strings.CS.lastIndexOf("aabaabaa", "b", -1));
        assertEquals(0, Strings.CS.lastIndexOf("aabaabaa", "a", 0));
        assertEquals(-1, Strings.CS.lastIndexOf("aabaabaa", "b", 0));
        assertEquals(-1, Strings.CS.lastIndexOf("aabaabaa", "b", 1));
        assertEquals(2, Strings.CS.lastIndexOf("aabaabaa", "b", 2));
        assertEquals(2, Strings.CS.lastIndexOf("aabaabaa", "ba", 2));
    }

    @Test
    public void testLastIndexOfCI_caseInsensitive() {
        assertEquals(7, Strings.CI.lastIndexOf("aabaabaa", "A"));
        assertEquals(5, Strings.CI.lastIndexOf("aabaabaa", "B"));
        assertEquals(4, Strings.CI.lastIndexOf("aabaabaa", "AB"));
        assertEquals(5, Strings.CI.lastIndexOf("aabaabaa", "B", 9));
        assertEquals(-1, Strings.CI.lastIndexOf("aabaabaa", "B", -1));
        assertEquals(0, Strings.CI.lastIndexOf("aabaabaa", "A", 0));
        assertEquals(-1, Strings.CI.lastIndexOf("aabaabaa", "B", 0));
    }

    // --- prependIfMissing ---

    @Test
    public void testPrependIfMissingCS_null() {
        assertNull(Strings.CS.prependIfMissing(null, null));
        assertEquals("abc", Strings.CS.prependIfMissing("abc", null));
    }

    @Test
    public void testPrependIfMissingCS_basic() {
        assertEquals("xyz", Strings.CS.prependIfMissing("", "xyz"));
        assertEquals("xyzabc", Strings.CS.prependIfMissing("abc", "xyz"));
        assertEquals("xyzabc", Strings.CS.prependIfMissing("xyzabc", "xyz"));
        assertEquals("xyzXYZabc", Strings.CS.prependIfMissing("XYZabc", "xyz"));
    }

    @Test
    public void testPrependIfMissingCS_additionalPrefixes() {
        assertEquals("abc", Strings.CS.prependIfMissing("abc", "xyz", ""));
        assertEquals("xyzabc", Strings.CS.prependIfMissing("abc", "xyz", "mno"));
        assertEquals("mnoabc", Strings.CS.prependIfMissing("mnoabc", "xyz", "mno"));
    }

    @Test
    public void testPrependIfMissingCI_caseInsensitive() {
        assertEquals("XYZabc", Strings.CI.prependIfMissing("XYZabc", "xyz"));
        assertEquals("MNOabc", Strings.CI.prependIfMissing("MNOabc", "xyz", "mno"));
    }

    // --- remove ---

    @Test
    public void testRemoveCS_nullAndEmpty() {
        assertNull(Strings.CS.remove(null, "a"));
        assertEquals("", Strings.CS.remove("", "a"));
        assertEquals("abc", Strings.CS.remove("abc", null));
        assertEquals("abc", Strings.CS.remove("abc", ""));
    }

    @Test
    public void testRemoveCS_basic() {
        assertEquals("qd", Strings.CS.remove("queued", "ue"));
        assertEquals("queued", Strings.CS.remove("queued", "zz"));
    }

    @Test
    public void testRemoveCI_caseInsensitive() {
        assertEquals("qd", Strings.CI.remove("quEUed", "UE"));
        assertEquals("queued", Strings.CI.remove("queued", "zZ"));
    }

    // --- removeEnd ---

    @Test
    public void testRemoveEndCS_nullAndEmpty() {
        assertNull(Strings.CS.removeEnd(null, "a"));
        assertEquals("", Strings.CS.removeEnd("", "a"));
        assertEquals("abc", Strings.CS.removeEnd("abc", null));
        assertEquals("abc", Strings.CS.removeEnd("abc", ""));
    }

    @Test
    public void testRemoveEndCS_basic() {
        assertEquals("www.domain.com", Strings.CS.removeEnd("www.domain.com", ".com."));
        assertEquals("www.domain", Strings.CS.removeEnd("www.domain.com", ".com"));
        assertEquals("www.domain.com", Strings.CS.removeEnd("www.domain.com", "domain"));
    }

    @Test
    public void testRemoveEndCI_caseInsensitive() {
        assertEquals("www.domain", Strings.CI.removeEnd("www.domain.com", ".COM"));
        assertEquals("www.domain", Strings.CI.removeEnd("www.domain.COM", ".com"));
    }

    // --- removeStart ---

    @Test
    public void testRemoveStartCS_nullAndEmpty() {
        assertNull(Strings.CS.removeStart(null, "a"));
        assertEquals("", Strings.CS.removeStart("", "a"));
        assertEquals("abc", Strings.CS.removeStart("abc", null));
        assertEquals("abc", Strings.CS.removeStart("abc", ""));
    }

    @Test
    public void testRemoveStartCS_basic() {
        assertEquals("domain.com", Strings.CS.removeStart("www.domain.com", "www."));
        assertEquals("domain.com", Strings.CS.removeStart("domain.com", "www."));
        assertEquals("www.domain.com", Strings.CS.removeStart("www.domain.com", "domain"));
    }

    @Test
    public void testRemoveStartCI_caseInsensitive() {
        assertEquals("domain.com", Strings.CI.removeStart("www.domain.com", "WWW."));
    }

    // --- replace ---

    @Test
    public void testReplaceCS_nullAndEmpty() {
        assertNull(Strings.CS.replace(null, "a", "b"));
        assertEquals("", Strings.CS.replace("", "a", "b"));
        assertEquals("any", Strings.CS.replace("any", null, "b"));
        assertEquals("any", Strings.CS.replace("any", "a", null));
        assertEquals("any", Strings.CS.replace("any", "", "b"));
    }

    @Test
    public void testReplaceCS_basic() {
        assertEquals("aba", Strings.CS.replace("aba", "a", null));
        assertEquals("b", Strings.CS.replace("aba", "a", ""));
        assertEquals("zbz", Strings.CS.replace("aba", "a", "z"));
    }

    @Test
    public void testReplaceCI_caseInsensitive() {
        assertEquals("b", Strings.CI.replace("abA", "A", ""));
        assertEquals("zbz", Strings.CI.replace("aba", "A", "z"));
    }

    @Test
    public void testReplaceWithMax_boundaries() {
        assertEquals("abaa", Strings.CS.replace("abaa", "a", "z", 0));
        assertEquals("zbaa", Strings.CS.replace("abaa", "a", "z", 1));
        assertEquals("zbza", Strings.CS.replace("abaa", "a", "z", 2));
        assertEquals("zbzz", Strings.CS.replace("abaa", "a", "z", -1));
    }

    @Test
    public void testReplaceWithMax_noMatch() {
        assertEquals("abc", Strings.CS.replace("abc", "z", "y", -1));
    }

    // --- replaceOnce ---

    @Test
    public void testReplaceOnceCS_basic() {
        assertEquals("ba", Strings.CS.replaceOnce("aba", "a", ""));
        assertEquals("zba", Strings.CS.replaceOnce("aba", "a", "z"));
    }

    @Test
    public void testReplaceOnceCI_caseInsensitive() {
        assertEquals("Foofoo", Strings.CI.replaceOnce("FoOFoofoo", "foo", ""));
    }

    // --- startsWith ---

    @Test
    public void testStartsWithCS_nulls() {
        assertTrue(Strings.CS.startsWith(null, null));
        assertFalse(Strings.CS.startsWith(null, "abc"));
        assertFalse(Strings.CS.startsWith("abcdef", null));
    }

    @Test
    public void testStartsWithCS_caseSensitive() {
        assertTrue(Strings.CS.startsWith("abcdef", "abc"));
        assertFalse(Strings.CS.startsWith("ABCDEF", "abc"));
    }

    @Test
    public void testStartsWithCS_prefixLongerThanString() {
        assertFalse(Strings.CS.startsWith("ab", "abcdef"));
    }

    @Test
    public void testStartsWithCI_caseInsensitive() {
        assertTrue(Strings.CI.startsWith("ABCDEF", "abc"));
    }

    // --- startsWithAny ---

    @Test
    public void testStartsWithAnyCS_nullAndEmpty() {
        assertFalse(Strings.CS.startsWithAny(null, (CharSequence[]) null));
        assertFalse(Strings.CS.startsWithAny(null, "abc"));
        assertFalse(Strings.CS.startsWithAny("abcxyz", (CharSequence[]) null));
    }

    @Test
    public void testStartsWithAnyCS_matches() {
        assertTrue(Strings.CS.startsWithAny("abcxyz", ""));
        assertTrue(Strings.CS.startsWithAny("abcxyz", "abc"));
        assertTrue(Strings.CS.startsWithAny("abcxyz", (CharSequence) null, "xyz", "abc"));
        assertFalse(Strings.CS.startsWithAny("abcxyz", null, "xyz", "ABCX"));
        assertFalse(Strings.CS.startsWithAny("ABCXYZ", null, "xyz", "abc"));
    }

    @Test
    public void testStartsWithAnyCI_matches() {
        assertTrue(Strings.CI.startsWithAny("abcxyz", null, "xyz", "ABCX"));
        assertTrue(Strings.CI.startsWithAny("ABCXYZ", null, "xyz", "abc"));
    }

    // --- Builder ---

    @Test
    public void testBuilder_defaultIsCaseSensitive() {
        final Strings built = Strings.builder().get();
        assertTrue(built.isCaseSensitive());
        assertEquals(0, built.compare("a", "a"));
    }

    @Test
    public void testBuilder_setIgnoreCaseTrueGivesCaseInsensitiveInstance() {
        final Strings built = Strings.builder().setIgnoreCase(true).get();
        assertFalse(built.isCaseSensitive());
        assertTrue(built.equals("abc", "ABC"));
    }

    @Test
    public void testBuilder_setNullIsLessFalseAffectsCompare() {
        final Strings built = Strings.builder().setNullIsLess(false).get();
        assertTrue(built.compare(null, "a") > 0);
    }

    @Test
    public void testBuilder_returnsNewInstanceEachCall() {
        final Strings.Builder builder = Strings.builder();
        assertFalse(builder.get() == builder.get());
    }

    // --- singleton identity ---

    @Test
    public void testSingletons_areStableAndDistinct() {
        assertSame(Strings.CS, Strings.CS);
        assertSame(Strings.CI, Strings.CI);
        assertTrue(Strings.CS != Strings.CI);
        assertTrue(Strings.CS.isCaseSensitive());
        assertFalse(Strings.CI.isCaseSensitive());
    }

}
