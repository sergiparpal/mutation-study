/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Field;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link TypeUtils}.
 */
class TypeUtilsAgentTest {

    static class Box<T> {
        public List<T> list;
        public T[] array;
    }

    static class GenBounded<T extends Number & Comparable<T>> {
        public T value;
    }

    static class StringArrayList extends ArrayList<String> {
        private static final long serialVersionUID = 1L;
    }

    static class Outer<T> {
        class Inner {
            // empty
        }
    }

    private final TypeVariable<?> boxVar = Box.class.getTypeParameters()[0];
    private final TypeVariable<?> genBoundedVar = GenBounded.class.getTypeParameters()[0];

    private Field boxField(final String name) throws NoSuchFieldException {
        return Box.class.getField(name);
    }

    @Test
    void testContainsTypeVariables() throws Exception {
        assertTrue(TypeUtils.containsTypeVariables(genBoundedVar));
        assertFalse(TypeUtils.containsTypeVariables(String.class));
        assertFalse(TypeUtils.containsTypeVariables(String[].class));
        assertTrue(TypeUtils.containsTypeVariables(List.class));
        assertTrue(TypeUtils.containsTypeVariables(boxField("list").getGenericType()));
        assertTrue(TypeUtils.containsTypeVariables(boxField("array").getGenericType()));
        assertFalse(TypeUtils.containsTypeVariables(TypeUtils.parameterize(List.class, String.class)));
    }

    @Test
    void testDetermineTypeArguments() {
        final ParameterizedType listOfString = TypeUtils.parameterize(List.class, String.class);
        final Map<TypeVariable<?>, Type> det = TypeUtils.determineTypeArguments(ArrayList.class, listOfString);
        assertNotNull(det);
        final TypeVariable<?> arrayListVar = ArrayList.class.getTypeParameters()[0];
        assertEquals(String.class, det.get(arrayListVar));

        assertNull(TypeUtils.determineTypeArguments(String.class, listOfString));

        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.determineTypeArguments(null, listOfString);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.determineTypeArguments(ArrayList.class, null);
            }
        });
    }

    @Test
    void testEquals() {
        final Type listString1 = TypeUtils.parameterize(List.class, String.class);
        final Type listString2 = TypeUtils.parameterize(List.class, String.class);
        assertFalse(listString1 == listString2);
        assertTrue(TypeUtils.equals(listString1, listString2));
        assertFalse(TypeUtils.equals(listString1, TypeUtils.parameterize(List.class, Integer.class)));

        assertTrue(TypeUtils.equals(TypeUtils.genericArrayType(String.class), TypeUtils.genericArrayType(String.class)));
        assertFalse(TypeUtils.equals(TypeUtils.genericArrayType(String.class), TypeUtils.genericArrayType(Integer.class)));

        final WildcardType w1 = TypeUtils.wildcardType().withUpperBounds(Number.class).build();
        final WildcardType w2 = TypeUtils.wildcardType().withUpperBounds(Number.class).build();
        assertTrue(TypeUtils.equals(w1, w2));
        assertFalse(TypeUtils.equals(w1, TypeUtils.WILDCARD_ALL));

        assertFalse(TypeUtils.equals(String.class, null));
        assertTrue(TypeUtils.equals(String.class, String.class));
    }

    @Test
    void testGenericArrayType() {
        final GenericArrayType gat = TypeUtils.genericArrayType(String.class);
        assertEquals(String.class, gat.getGenericComponentType());
        assertEquals("java.lang.String[]", TypeUtils.toString(gat));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.genericArrayType(null);
            }
        });
    }

    @Test
    void testGetArrayComponentType() throws Exception {
        assertEquals(String.class, TypeUtils.getArrayComponentType(String[].class));
        assertNull(TypeUtils.getArrayComponentType(String.class));
        final Type arrType = boxField("array").getGenericType();
        assertEquals(boxVar, TypeUtils.getArrayComponentType(arrType));
    }

    @Test
    void testGetImplicitBounds() {
        final Type[] bounds = TypeUtils.getImplicitBounds(genBoundedVar);
        final List<Type> boundsList = Arrays.asList(bounds);
        assertEquals(2, boundsList.size());
        assertTrue(boundsList.contains(Number.class));

        final TypeVariable<?> boxVarLocal = boxVar;
        final Type[] unboundedBounds = TypeUtils.getImplicitBounds(boxVarLocal);
        assertEquals(1, unboundedBounds.length);
        assertEquals(Object.class, unboundedBounds[0]);

        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.getImplicitBounds(null);
            }
        });
    }

    @Test
    void testGetImplicitLowerAndUpperBounds() {
        final WildcardType upperOnly = TypeUtils.wildcardType().withUpperBounds(Number.class).build();
        final WildcardType lowerOnly = TypeUtils.wildcardType().withLowerBounds(Number.class).build();

        assertArrayEquals(new Type[] {null}, TypeUtils.getImplicitLowerBounds(upperOnly));
        assertArrayEquals(new Type[] {Number.class}, TypeUtils.getImplicitUpperBounds(upperOnly));

        assertArrayEquals(new Type[] {Object.class}, TypeUtils.getImplicitUpperBounds(lowerOnly));
        assertArrayEquals(new Type[] {Number.class}, TypeUtils.getImplicitLowerBounds(lowerOnly));

        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.getImplicitLowerBounds(null);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.getImplicitUpperBounds(null);
            }
        });
    }

    private static void assertArrayEquals(final Type[] expected, final Type[] actual) {
        assertEquals(Arrays.asList(expected), Arrays.asList(actual));
    }

    @Test
    void testGetRawTypeTwoArg() throws Exception {
        assertEquals(String.class, TypeUtils.getRawType(String.class, null));
        assertEquals(List.class, TypeUtils.getRawType(TypeUtils.parameterize(List.class, String.class), null));

        final ParameterizedType boxOfString = TypeUtils.parameterize(Box.class, String.class);
        assertEquals(String.class, TypeUtils.getRawType(boxVar, boxOfString));
        assertNull(TypeUtils.getRawType(boxVar, null));
        assertNull(TypeUtils.getRawType(TypeUtils.WILDCARD_ALL, null));

        final Type arrType = boxField("array").getGenericType();
        assertEquals(String[].class, TypeUtils.getRawType(arrType, boxOfString));
    }

    @Test
    void testGetTypeArgumentsParameterizedType() {
        final ParameterizedType mapOfStringInt = TypeUtils.parameterize(Map.class, String.class, Integer.class);
        final Map<TypeVariable<?>, Type> margs = TypeUtils.getTypeArguments(mapOfStringInt);
        final TypeVariable<?> kVar = Map.class.getTypeParameters()[0];
        final TypeVariable<?> vVar = Map.class.getTypeParameters()[1];
        assertEquals(String.class, margs.get(kVar));
        assertEquals(Integer.class, margs.get(vVar));
    }

    @Test
    void testGetTypeArgumentsTypeClass() {
        final Map<TypeVariable<?>, Type> args = TypeUtils.getTypeArguments(StringArrayList.class, List.class);
        assertNotNull(args);
        final TypeVariable<?> listVar = List.class.getTypeParameters()[0];
        assertEquals(String.class, args.get(listVar));

        assertNull(TypeUtils.getTypeArguments(String.class, List.class));

        final WildcardType wildcard = TypeUtils.wildcardType().withUpperBounds(TypeUtils.parameterize(List.class, String.class)).build();
        final Map<TypeVariable<?>, Type> fromWildcard = TypeUtils.getTypeArguments(wildcard, List.class);
        assertNotNull(fromWildcard);
        assertEquals(String.class, fromWildcard.get(listVar));

        final Map<TypeVariable<?>, Type> fromVar = TypeUtils.getTypeArguments(boxVar, Object.class);
        assertNotNull(fromVar);
        assertTrue(fromVar.isEmpty());
    }

    @Test
    void testIsArrayType() throws Exception {
        assertTrue(TypeUtils.isArrayType(String[].class));
        assertFalse(TypeUtils.isArrayType(String.class));
        assertTrue(TypeUtils.isArrayType(boxField("array").getGenericType()));
    }

    @Test
    void testIsAssignable() {
        assertTrue(TypeUtils.isAssignable(String.class, Object.class));
        assertFalse(TypeUtils.isAssignable(Object.class, String.class));
        assertTrue(TypeUtils.isAssignable(StringArrayList.class, TypeUtils.parameterize(List.class, String.class)));
        assertFalse(TypeUtils.isAssignable(StringArrayList.class, TypeUtils.parameterize(List.class, Integer.class)));
        assertTrue(TypeUtils.isAssignable(null, Object.class));
        assertFalse(TypeUtils.isAssignable(String.class, (Type) null));
        assertTrue(TypeUtils.isAssignable((Type) null, (Type) null));
    }

    @Test
    void testIsInstance() {
        assertTrue(TypeUtils.isInstance("x", String.class));
        assertFalse(TypeUtils.isInstance(Integer.valueOf(1), String.class));
        assertTrue(TypeUtils.isInstance(null, String.class));
        assertFalse(TypeUtils.isInstance(null, int.class));
        assertFalse(TypeUtils.isInstance("x", null));
    }

    @Test
    void testNormalizeUpperBounds() {
        final Type[] normalized = TypeUtils.normalizeUpperBounds(new Type[] {java.util.Collection.class, List.class});
        assertEquals(1, normalized.length);
        assertEquals(List.class, normalized[0]);

        final Type[] single = new Type[] {Number.class};
        assertSame(single, TypeUtils.normalizeUpperBounds(single));

        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.normalizeUpperBounds(null);
            }
        });
    }

    @Test
    void testParameterizeWithTypes() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.parameterize(List.class);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.parameterize(List.class, String.class, Integer.class);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.parameterize(List.class, (Type) null);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.parameterize(null, String.class);
            }
        });

        final ParameterizedType pt = TypeUtils.parameterize(List.class, String.class);
        assertEquals(List.class, pt.getRawType());
        assertEquals(1, pt.getActualTypeArguments().length);
        assertEquals(String.class, pt.getActualTypeArguments()[0]);
    }

    @Test
    void testParameterizeWithMap() {
        final Map<TypeVariable<?>, Type> m = new HashMap<TypeVariable<?>, Type>();
        m.put(List.class.getTypeParameters()[0], String.class);
        final ParameterizedType pt = TypeUtils.parameterize(List.class, m);
        assertEquals(String.class, pt.getActualTypeArguments()[0]);

        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.parameterize(List.class, Collections.<TypeVariable<?>, Type>emptyMap());
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.parameterize(List.class, (Map<TypeVariable<?>, Type>) null);
            }
        });
    }

    @Test
    void testParameterizeWithOwner() {
        final Type ownerType = TypeUtils.parameterize(Outer.class, String.class);
        final ParameterizedType innerType = TypeUtils.parameterizeWithOwner(ownerType, Outer.Inner.class);
        assertSame(ownerType, innerType.getOwnerType());
        assertEquals(Outer.Inner.class, innerType.getRawType());
        assertEquals(0, innerType.getActualTypeArguments().length);

        final ParameterizedType innerRaw = TypeUtils.parameterizeWithOwner(null, Outer.Inner.class);
        assertEquals(Outer.class, innerRaw.getOwnerType());

        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.parameterizeWithOwner(String.class, Outer.Inner.class);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.parameterizeWithOwner(null, null);
            }
        });
    }

    @Test
    void testToLongString() {
        final String longStr = TypeUtils.toLongString(boxVar);
        assertTrue(longStr.startsWith(TypeUtilsAgentTest.class.getName() + ".Box:"));
        assertTrue(longStr.endsWith(TypeUtils.toString(boxVar)));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.toLongString(null);
            }
        });
    }

    @Test
    void testToString() {
        assertEquals(String.class.getName(), TypeUtils.toString(String.class));
        assertEquals("java.util.List<java.lang.String>", TypeUtils.toString(TypeUtils.parameterize(List.class, String.class)));
        assertEquals("?", TypeUtils.toString(TypeUtils.WILDCARD_ALL));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.toString(null);
            }
        });
    }

    @Test
    void testTypesSatisfyVariables() {
        final Map<TypeVariable<?>, Type> satisfy = new HashMap<TypeVariable<?>, Type>();
        satisfy.put(genBoundedVar, Integer.class);
        assertTrue(TypeUtils.typesSatisfyVariables(satisfy));

        final Map<TypeVariable<?>, Type> unsatisfy = new HashMap<TypeVariable<?>, Type>();
        unsatisfy.put(genBoundedVar, Object.class);
        assertFalse(TypeUtils.typesSatisfyVariables(unsatisfy));

        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                TypeUtils.typesSatisfyVariables(null);
            }
        });
    }

    @Test
    void testUnrollVariables() throws Exception {
        final Map<TypeVariable<?>, Type> uv = new HashMap<TypeVariable<?>, Type>();
        uv.put(boxVar, String.class);

        final Type listOfT = boxField("list").getGenericType();
        final Type unrolled = TypeUtils.unrollVariables(uv, listOfT);
        assertTrue(TypeUtils.equals(TypeUtils.parameterize(List.class, String.class), unrolled));

        final Type arrOfT = boxField("array").getGenericType();
        final Type unrolledArr = TypeUtils.unrollVariables(uv, arrOfT);
        assertEquals(String[].class, unrolledArr);

        assertEquals(String.class, TypeUtils.unrollVariables(null, String.class));
        assertNull(TypeUtils.unrollVariables(Collections.<TypeVariable<?>, Type>emptyMap(), boxVar));
    }

    @Test
    void testWildcardTypeBuilder() {
        assertEquals(1, TypeUtils.WILDCARD_ALL.getUpperBounds().length);
        assertEquals(Object.class, TypeUtils.WILDCARD_ALL.getUpperBounds()[0]);
        assertEquals(0, TypeUtils.WILDCARD_ALL.getLowerBounds().length);

        final WildcardType built = TypeUtils.wildcardType().withUpperBounds(Number.class).withLowerBounds(Integer.class).build();
        assertEquals(1, built.getUpperBounds().length);
        assertEquals(Number.class, built.getUpperBounds()[0]);
        assertEquals(1, built.getLowerBounds().length);
        assertEquals(Integer.class, built.getLowerBounds()[0]);
    }

    @Test
    void testWrap() {
        final Typed<String> typedClass = TypeUtils.wrap(String.class);
        assertEquals(String.class, typedClass.getType());

        final Type sample = TypeUtils.parameterize(List.class, String.class);
        final Typed<?> typedType = TypeUtils.wrap(sample);
        assertSame(sample, typedType.getType());
    }

    @Test
    @SuppressWarnings("deprecation")
    void testConstructor() {
        final TypeUtils instance = new TypeUtils();
        assertNotNull(instance);
    }
}
