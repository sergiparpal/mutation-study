/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZonedDateTime;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.Locale;
import java.util.NoSuchElementException;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained test for {@link DateUtils}.
 */
class DateUtilsAgentTest {

    private Calendar newCalendar(final int year, final int month, final int day, final int hour, final int minute,
            final int second, final int millis) {
        final Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(year, month, day, hour, minute, second);
        cal.set(Calendar.MILLISECOND, millis);
        return cal;
    }

    // ---- add* methods ----

    @Test
    void testAddDays() {
        final Calendar cal = newCalendar(2000, Calendar.JANUARY, 1, 0, 0, 0, 0);
        final Date result = DateUtils.addDays(cal.getTime(), 1);
        final Calendar resultCal = Calendar.getInstance();
        resultCal.setTime(result);
        assertEquals(2, resultCal.get(Calendar.DAY_OF_MONTH));
        assertEquals(Calendar.JANUARY, resultCal.get(Calendar.MONTH));
        // original date not mutated
        assertEquals(1, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testAddDaysNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.addDays(null, 1);
            }
        });
    }

    @Test
    void testAddHoursRolloverToNextDay() {
        final Calendar cal = newCalendar(2000, Calendar.JANUARY, 1, 23, 0, 0, 0);
        final Date result = DateUtils.addHours(cal.getTime(), 2);
        final Calendar resultCal = Calendar.getInstance();
        resultCal.setTime(result);
        assertEquals(2, resultCal.get(Calendar.DAY_OF_MONTH));
        assertEquals(1, resultCal.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    void testAddMilliseconds() {
        final Date date = new Date(1000L);
        final Date result = DateUtils.addMilliseconds(date, 500);
        assertEquals(1500L, result.getTime());
    }

    @Test
    void testAddMinutesNegative() {
        final Calendar cal = newCalendar(2000, Calendar.JANUARY, 1, 0, 30, 0, 0);
        final Date result = DateUtils.addMinutes(cal.getTime(), -45);
        final Calendar resultCal = Calendar.getInstance();
        resultCal.setTime(result);
        assertEquals(31, resultCal.get(Calendar.DAY_OF_MONTH));
        assertEquals(Calendar.DECEMBER, resultCal.get(Calendar.MONTH));
        assertEquals(1999, resultCal.get(Calendar.YEAR));
        assertEquals(23, resultCal.get(Calendar.HOUR_OF_DAY));
        assertEquals(45, resultCal.get(Calendar.MINUTE));
    }

    @Test
    void testAddMonthsAcrossYear() {
        final Calendar cal = newCalendar(2000, Calendar.DECEMBER, 15, 0, 0, 0, 0);
        final Date result = DateUtils.addMonths(cal.getTime(), 2);
        final Calendar resultCal = Calendar.getInstance();
        resultCal.setTime(result);
        assertEquals(2001, resultCal.get(Calendar.YEAR));
        assertEquals(Calendar.FEBRUARY, resultCal.get(Calendar.MONTH));
    }

    @Test
    void testAddSeconds() {
        final Date date = new Date(0L);
        final Date result = DateUtils.addSeconds(date, 90);
        assertEquals(90000L, result.getTime());
    }

    @Test
    void testAddWeeks() {
        final Calendar cal = newCalendar(2000, Calendar.JANUARY, 1, 0, 0, 0, 0);
        final Date result = DateUtils.addWeeks(cal.getTime(), 1);
        final Calendar resultCal = Calendar.getInstance();
        resultCal.setTime(result);
        assertEquals(8, resultCal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testAddYears() {
        final Calendar cal = newCalendar(2000, Calendar.FEBRUARY, 29, 0, 0, 0, 0);
        final Date result = DateUtils.addYears(cal.getTime(), 1);
        final Calendar resultCal = Calendar.getInstance();
        resultCal.setTime(result);
        assertEquals(2001, resultCal.get(Calendar.YEAR));
        // Feb 29 2000 + 1 year clamps to Feb 28 2001 (non-leap year)
        assertEquals(Calendar.FEBRUARY, resultCal.get(Calendar.MONTH));
        assertEquals(28, resultCal.get(Calendar.DAY_OF_MONTH));
    }

    // ---- ceiling ----

    @Test
    void testCeilingDate() {
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Date result = DateUtils.ceiling(cal.getTime(), Calendar.HOUR_OF_DAY);
        final Calendar resultCal = Calendar.getInstance();
        resultCal.setTime(result);
        assertEquals(14, resultCal.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, resultCal.get(Calendar.MINUTE));
        assertEquals(0, resultCal.get(Calendar.SECOND));
        assertEquals(0, resultCal.get(Calendar.MILLISECOND));
    }

    @Test
    void testCeilingCalendar() {
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Calendar result = DateUtils.ceiling(cal, Calendar.MONTH);
        assertEquals(Calendar.APRIL, result.get(Calendar.MONTH));
        assertEquals(1, result.get(Calendar.DAY_OF_MONTH));
        // original unchanged
        assertEquals(Calendar.MARCH, cal.get(Calendar.MONTH));
    }

    @Test
    void testCeilingObjectDate() {
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Date result = DateUtils.ceiling((Object) cal.getTime(), Calendar.HOUR_OF_DAY);
        assertNotNull(result);
    }

    @Test
    void testCeilingObjectCalendar() {
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Date result = DateUtils.ceiling((Object) cal, Calendar.HOUR_OF_DAY);
        assertNotNull(result);
    }

    @Test
    void testCeilingObjectInvalidType() {
        assertThrows(ClassCastException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.ceiling("not a date", Calendar.HOUR_OF_DAY);
            }
        });
    }

    @Test
    void testCeilingObjectNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.ceiling((Object) null, Calendar.HOUR_OF_DAY);
            }
        });
    }

    @Test
    void testCeilingNullDate() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.ceiling((Date) null, Calendar.HOUR_OF_DAY);
            }
        });
    }

    @Test
    void testCeilingNullCalendar() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.ceiling((Calendar) null, Calendar.HOUR_OF_DAY);
            }
        });
    }

    @Test
    void testCeilingYearTooLarge() {
        final Calendar cal = Calendar.getInstance();
        cal.set(Calendar.YEAR, 280000001);
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.ceiling(cal, Calendar.HOUR_OF_DAY);
            }
        });
    }

    @Test
    void testCeilingUnsupportedField() {
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.ceiling(cal, Calendar.DAY_OF_WEEK);
            }
        });
    }

    // ---- fragments ----

    @Test
    void testGetFragmentInDaysOfMonth() {
        final Calendar cal = newCalendar(2008, Calendar.JANUARY, 28, 0, 0, 0, 0);
        assertEquals(28, DateUtils.getFragmentInDays(cal, Calendar.MONTH));
    }

    @Test
    void testGetFragmentInDaysOfYear() {
        final Calendar cal = newCalendar(2008, Calendar.FEBRUARY, 28, 0, 0, 0, 0);
        assertEquals(59, DateUtils.getFragmentInDays(cal, Calendar.YEAR));
    }

    @Test
    void testGetFragmentInDaysMillisecondAlwaysZero() {
        final Calendar cal = newCalendar(2008, Calendar.JANUARY, 28, 7, 15, 10, 538);
        assertEquals(0, DateUtils.getFragmentInDays(cal, Calendar.MILLISECOND));
    }

    @Test
    void testGetFragmentInHours() {
        final Calendar cal = newCalendar(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(7, DateUtils.getFragmentInHours(cal, Calendar.DAY_OF_YEAR));
        assertEquals(127, DateUtils.getFragmentInHours(cal, Calendar.MONTH));
    }

    @Test
    void testGetFragmentInMinutes() {
        final Calendar cal = newCalendar(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(15, DateUtils.getFragmentInMinutes(cal, Calendar.HOUR_OF_DAY));
        assertEquals(7635, DateUtils.getFragmentInMinutes(cal, Calendar.MONTH));
    }

    @Test
    void testGetFragmentInSeconds() {
        final Calendar cal = newCalendar(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(10, DateUtils.getFragmentInSeconds(cal, Calendar.MINUTE));
        assertEquals(26110, DateUtils.getFragmentInSeconds(cal, Calendar.DAY_OF_YEAR));
    }

    @Test
    void testGetFragmentInMilliseconds() {
        final Calendar cal = newCalendar(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(538, DateUtils.getFragmentInMilliseconds(cal, Calendar.SECOND));
        assertEquals(10538, DateUtils.getFragmentInMilliseconds(cal, Calendar.MINUTE));
    }

    @Test
    void testGetFragmentInDaysWithDate() {
        final Calendar cal = newCalendar(2008, Calendar.JANUARY, 28, 0, 0, 0, 0);
        assertEquals(28, DateUtils.getFragmentInDays(cal.getTime(), Calendar.MONTH));
    }

    @Test
    void testGetFragmentUnsupported() {
        final Calendar cal = newCalendar(2008, Calendar.JANUARY, 28, 0, 0, 0, 0);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.getFragmentInDays(cal, Calendar.DAY_OF_WEEK);
            }
        });
    }

    @Test
    void testGetFragmentNullCalendar() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.getFragmentInDays((Calendar) null, Calendar.YEAR);
            }
        });
    }

    @Test
    void testGetFragmentNullDate() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.getFragmentInDays((Date) null, Calendar.YEAR);
            }
        });
    }

    // ---- isSameDay / isSameInstant / isSameLocalTime ----

    @Test
    void testIsSameDayTrue() {
        final Calendar cal1 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        final Calendar cal2 = newCalendar(2002, Calendar.MARCH, 28, 6, 1, 0, 0);
        assertTrue(DateUtils.isSameDay(cal1, cal2));
        assertTrue(DateUtils.isSameDay(cal1.getTime(), cal2.getTime()));
    }

    @Test
    void testIsSameDayFalse() {
        final Calendar cal1 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        final Calendar cal2 = newCalendar(2002, Calendar.MARCH, 12, 13, 45, 0, 0);
        assertFalse(DateUtils.isSameDay(cal1, cal2));
        assertFalse(DateUtils.isSameDay(cal1.getTime(), cal2.getTime()));
    }

    @Test
    void testIsSameDayNullArgs() {
        final Calendar cal = Calendar.getInstance();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.isSameDay((Calendar) null, cal);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.isSameDay(cal, (Calendar) null);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.isSameDay((Date) null, new Date());
            }
        });
    }

    @Test
    void testIsSameInstant() {
        final Date date1 = new Date(10000L);
        final Date date2 = new Date(10000L);
        final Date date3 = new Date(10001L);
        assertTrue(DateUtils.isSameInstant(date1, date2));
        assertFalse(DateUtils.isSameInstant(date1, date3));
        final Calendar cal1 = Calendar.getInstance();
        cal1.setTime(date1);
        final Calendar cal2 = Calendar.getInstance();
        cal2.setTime(date2);
        assertTrue(DateUtils.isSameInstant(cal1, cal2));
    }

    @Test
    void testIsSameInstantNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.isSameInstant((Date) null, new Date());
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.isSameInstant((Calendar) null, Calendar.getInstance());
            }
        });
    }

    @Test
    void testIsSameLocalTimeTrue() {
        final Calendar cal1 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 10, 500);
        final Calendar cal2 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 10, 500);
        assertTrue(DateUtils.isSameLocalTime(cal1, cal2));
    }

    @Test
    void testIsSameLocalTimeDifferentCalendarClass() {
        final Calendar cal1 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 10, 500);
        final GregorianCalendar cal2 = new GregorianCalendar();
        cal2.setTime(cal1.getTime());
        if (cal1.getClass() == cal2.getClass()) {
            assertTrue(DateUtils.isSameLocalTime(cal1, cal2));
        } else {
            assertFalse(DateUtils.isSameLocalTime(cal1, cal2));
        }
    }

    @Test
    void testIsSameLocalTimeNull() {
        final Calendar cal = Calendar.getInstance();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.isSameLocalTime(null, cal);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.isSameLocalTime(cal, null);
            }
        });
    }

    // ---- iterator ----

    @Test
    void testIteratorWeekSunday() {
        final Calendar focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0); // Thursday
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        int count = 0;
        Calendar last = null;
        while (it.hasNext()) {
            last = it.next();
            count++;
        }
        assertEquals(7, count);
        assertNotNull(last);
    }

    @Test
    void testIteratorMonthSunday() {
        final Calendar focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_MONTH_SUNDAY);
        Calendar first = null;
        Calendar last = null;
        int count = 0;
        while (it.hasNext()) {
            final Calendar c = it.next();
            if (first == null) {
                first = c;
            }
            last = c;
            count++;
        }
        assertNotNull(first);
        assertEquals(Calendar.SUNDAY, first.get(Calendar.DAY_OF_WEEK));
        assertEquals(Calendar.SATURDAY, last.get(Calendar.DAY_OF_WEEK));
        assertTrue(count >= 28);
    }

    @Test
    void testIteratorExhaustedThrowsNoSuchElement() {
        final Calendar focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        while (it.hasNext()) {
            it.next();
        }
        assertThrows(NoSuchElementException.class, new Executable() {
            @Override
            public void execute() {
                it.next();
            }
        });
    }

    @Test
    void testIteratorRemoveUnsupported() {
        final Calendar focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        final Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                it.remove();
            }
        });
    }

    @Test
    void testIteratorWithDateObject() {
        final Calendar focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        final Iterator<?> it = DateUtils.iterator((Object) focus.getTime(), DateUtils.RANGE_WEEK_SUNDAY);
        assertNotNull(it);
        assertTrue(it.hasNext());
    }

    @Test
    void testIteratorWithCalendarObject() {
        final Calendar focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        final Iterator<?> it = DateUtils.iterator((Object) focus, DateUtils.RANGE_WEEK_SUNDAY);
        assertNotNull(it);
        assertTrue(it.hasNext());
    }

    @Test
    void testIteratorInvalidObjectType() {
        assertThrows(ClassCastException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.iterator("not a date", DateUtils.RANGE_WEEK_SUNDAY);
            }
        });
    }

    @Test
    void testIteratorNullCalendar() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.iterator((Calendar) null, DateUtils.RANGE_WEEK_SUNDAY);
            }
        });
    }

    @Test
    void testIteratorInvalidRangeStyle() {
        final Calendar focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.iterator(focus, -999);
            }
        });
    }

    // ---- parseDate / parseDateStrictly ----

    @Test
    void testParseDateSuccess() throws ParseException {
        final Date date = DateUtils.parseDate("2002-03-28", "yyyy-MM-dd");
        final Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        assertEquals(2002, cal.get(Calendar.YEAR));
        assertEquals(Calendar.MARCH, cal.get(Calendar.MONTH));
        assertEquals(28, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseDateWithLocale() throws ParseException {
        final Date date = DateUtils.parseDate("2002-03-28", Locale.US, "yyyy-MM-dd");
        assertNotNull(date);
    }

    @Test
    void testParseDateMultiplePatternsTriesEach() throws ParseException {
        final Date date = DateUtils.parseDate("28-03-2002", "yyyy/MM/dd", "dd-MM-yyyy");
        final Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        assertEquals(2002, cal.get(Calendar.YEAR));
        assertEquals(Calendar.MARCH, cal.get(Calendar.MONTH));
        assertEquals(28, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseDateNoMatchThrowsParseException() {
        assertThrows(ParseException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.parseDate("not-a-date", "yyyy-MM-dd");
            }
        });
    }

    @Test
    void testParseDateNoPatternsThrowsParseException() {
        assertThrows(ParseException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.parseDate("2002-03-28");
            }
        });
    }

    @Test
    void testParseDateNullString() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.parseDate(null, "yyyy-MM-dd");
            }
        });
    }

    @Test
    void testParseDateNullPatterns() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.parseDate("2002-03-28", (String[]) null);
            }
        });
    }

    @Test
    void testParseDateStrictlyRejectsLenientOverflow() {
        // Day 32 of January is not a valid strict date (would roll to Feb 1 under lenient parsing).
        assertThrows(ParseException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.parseDateStrictly("20020132", "yyyyMMdd");
            }
        });
    }

    @Test
    void testParseDateLenientAcceptsOverflow() throws ParseException {
        final Date date = DateUtils.parseDate("20020132", "yyyyMMdd");
        final Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        assertEquals(Calendar.FEBRUARY, cal.get(Calendar.MONTH));
        assertEquals(1, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseDateStrictlySuccess() throws ParseException {
        final Date date = DateUtils.parseDateStrictly("2002-03-28", "yyyy-MM-dd");
        assertNotNull(date);
    }

    @Test
    void testParseDateStrictlyWithLocale() throws ParseException {
        final Date date = DateUtils.parseDateStrictly("2002-03-28", Locale.US, "yyyy-MM-dd");
        assertNotNull(date);
    }

    @Test
    void testParseDateStrictlyNullString() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.parseDateStrictly(null, "yyyy-MM-dd");
            }
        });
    }

    @Test
    void testParseDateDoesNotMatchPartialString() {
        // Pattern must match whole string
        assertThrows(ParseException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                DateUtils.parseDate("2002-03-28extra", "yyyy-MM-dd");
            }
        });
    }

    // ---- round ----

    @Test
    void testRoundDateHour() {
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Date result = DateUtils.round(cal.getTime(), Calendar.HOUR_OF_DAY);
        final Calendar resultCal = Calendar.getInstance();
        resultCal.setTime(result);
        assertEquals(14, resultCal.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, resultCal.get(Calendar.MINUTE));
    }

    @Test
    void testRoundDateHourRoundsDown() {
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 10, 1, 231);
        final Date result = DateUtils.round(cal.getTime(), Calendar.HOUR_OF_DAY);
        final Calendar resultCal = Calendar.getInstance();
        resultCal.setTime(result);
        assertEquals(13, resultCal.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, resultCal.get(Calendar.MINUTE));
    }

    @Test
    void testRoundCalendarMonth() {
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Calendar result = DateUtils.round(cal, Calendar.MONTH);
        assertEquals(Calendar.APRIL, result.get(Calendar.MONTH));
        assertEquals(1, result.get(Calendar.DAY_OF_MONTH));
        // original unchanged
        assertEquals(Calendar.MARCH, cal.get(Calendar.MONTH));
    }

    @Test
    void testRoundObjectDispatch() {
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertNotNull(DateUtils.round((Object) cal, Calendar.HOUR_OF_DAY));
        assertNotNull(DateUtils.round((Object) cal.getTime(), Calendar.HOUR_OF_DAY));
    }

    @Test
    void testRoundObjectInvalidType() {
        assertThrows(ClassCastException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.round("not a date", Calendar.HOUR_OF_DAY);
            }
        });
    }

    @Test
    void testRoundObjectNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.round((Object) null, Calendar.HOUR_OF_DAY);
            }
        });
    }

    @Test
    void testRoundNullDate() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.round((Date) null, Calendar.HOUR_OF_DAY);
            }
        });
    }

    @Test
    void testRoundNullCalendar() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.round((Calendar) null, Calendar.HOUR_OF_DAY);
            }
        });
    }

    @Test
    void testRoundYearTooLarge() {
        final Calendar cal = Calendar.getInstance();
        cal.set(Calendar.YEAR, 280000001);
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.round(cal, Calendar.HOUR_OF_DAY);
            }
        });
    }

    @Test
    void testRoundUnsupportedField() {
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.round(cal, Calendar.DAY_OF_WEEK);
            }
        });
    }

    @Test
    void testRoundSemiMonthRoundsUpPast15() {
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 24, 0, 0, 0, 0);
        final Calendar result = DateUtils.round(cal, DateUtils.SEMI_MONTH);
        assertEquals(Calendar.APRIL, result.get(Calendar.MONTH));
        assertEquals(1, result.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testRoundSemiMonthRoundsDownBelow8() {
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 5, 0, 0, 0, 0);
        final Calendar result = DateUtils.round(cal, DateUtils.SEMI_MONTH);
        assertEquals(Calendar.MARCH, result.get(Calendar.MONTH));
        assertEquals(1, result.get(Calendar.DAY_OF_MONTH));
    }

    // ---- set* ----

    @Test
    void testSetDaysValid() {
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Date result = DateUtils.setDays(cal.getTime(), 1);
        final Calendar resultCal = Calendar.getInstance();
        resultCal.setTime(result);
        assertEquals(1, resultCal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testSetDaysOutOfRangeThrows() {
        final Date date = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231).getTime();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setDays(date, 32);
            }
        });
    }

    @Test
    void testSetHoursValid() {
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Date result = DateUtils.setHours(cal.getTime(), 5);
        final Calendar resultCal = Calendar.getInstance();
        resultCal.setTime(result);
        assertEquals(5, resultCal.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    void testSetHoursOutOfRangeThrows() {
        final Date date = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231).getTime();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setHours(date, 24);
            }
        });
    }

    @Test
    void testSetMillisecondsOutOfRangeThrows() {
        final Date date = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231).getTime();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setMilliseconds(date, 1000);
            }
        });
    }

    @Test
    void testSetMinutesOutOfRangeThrows() {
        final Date date = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231).getTime();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setMinutes(date, 60);
            }
        });
    }

    @Test
    void testSetMonthsValidAndOutOfRange() {
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Date result = DateUtils.setMonths(cal.getTime(), 0);
        final Calendar resultCal = Calendar.getInstance();
        resultCal.setTime(result);
        assertEquals(Calendar.JANUARY, resultCal.get(Calendar.MONTH));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setMonths(cal.getTime(), 12);
            }
        });
    }

    @Test
    void testSetSecondsOutOfRangeThrows() {
        final Date date = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231).getTime();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setSeconds(date, 60);
            }
        });
    }

    @Test
    void testSetYears() {
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Date result = DateUtils.setYears(cal.getTime(), 1999);
        final Calendar resultCal = Calendar.getInstance();
        resultCal.setTime(result);
        assertEquals(1999, resultCal.get(Calendar.YEAR));
    }

    @Test
    void testSetDaysNullDate() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.setDays(null, 1);
            }
        });
    }

    // ---- toCalendar ----

    @Test
    void testToCalendar() {
        final Date date = new Date(123456789L);
        final Calendar cal = DateUtils.toCalendar(date);
        assertEquals(123456789L, cal.getTime().getTime());
    }

    @Test
    void testToCalendarNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.toCalendar(null);
            }
        });
    }

    @Test
    void testToCalendarWithTimeZone() {
        final Date date = new Date(123456789L);
        final TimeZone tz = TimeZone.getTimeZone("UTC");
        final Calendar cal = DateUtils.toCalendar(date, tz);
        assertEquals(tz, cal.getTimeZone());
        assertEquals(123456789L, cal.getTime().getTime());
    }

    @Test
    void testToCalendarWithTimeZoneNullDate() {
        final TimeZone tz = TimeZone.getTimeZone("UTC");
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.toCalendar(null, tz);
            }
        });
    }

    // ---- toLocalDateTime / toOffsetDateTime / toZonedDateTime ----

    @Test
    void testToLocalDateTime() {
        final TimeZone tz = TimeZone.getTimeZone("UTC");
        final Date date = new Date(0L);
        final LocalDateTime ldt = DateUtils.toLocalDateTime(date, tz);
        assertEquals(1970, ldt.getYear());
        assertEquals(1, ldt.getMonthValue());
        assertEquals(1, ldt.getDayOfMonth());
        assertEquals(0, ldt.getHour());
    }

    @Test
    void testToLocalDateTimeDefaultZone() {
        final Date date = new Date(0L);
        final LocalDateTime ldt = DateUtils.toLocalDateTime(date);
        assertNotNull(ldt);
    }

    @Test
    void testToOffsetDateTime() {
        final TimeZone tz = TimeZone.getTimeZone("UTC");
        final Date date = new Date(0L);
        final OffsetDateTime odt = DateUtils.toOffsetDateTime(date, tz);
        assertEquals(1970, odt.getYear());
        assertEquals(0, odt.getOffset().getTotalSeconds());
    }

    @Test
    void testToOffsetDateTimeDefaultZone() {
        final Date date = new Date(0L);
        assertNotNull(DateUtils.toOffsetDateTime(date));
    }

    @Test
    void testToZonedDateTime() {
        final TimeZone tz = TimeZone.getTimeZone("UTC");
        final Date date = new Date(0L);
        final ZonedDateTime zdt = DateUtils.toZonedDateTime(date, tz);
        assertEquals(1970, zdt.getYear());
    }

    @Test
    void testToZonedDateTimeDefaultZone() {
        final Date date = new Date(0L);
        assertNotNull(DateUtils.toZonedDateTime(date));
    }

    // ---- truncate ----

    @Test
    void testTruncateDate() {
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Date result = DateUtils.truncate(cal.getTime(), Calendar.HOUR_OF_DAY);
        final Calendar resultCal = Calendar.getInstance();
        resultCal.setTime(result);
        assertEquals(13, resultCal.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, resultCal.get(Calendar.MINUTE));
        assertEquals(0, resultCal.get(Calendar.SECOND));
        assertEquals(0, resultCal.get(Calendar.MILLISECOND));
    }

    @Test
    void testTruncateCalendarMonth() {
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Calendar result = DateUtils.truncate(cal, Calendar.MONTH);
        assertEquals(Calendar.MARCH, result.get(Calendar.MONTH));
        assertEquals(1, result.get(Calendar.DAY_OF_MONTH));
        assertEquals(0, result.get(Calendar.HOUR_OF_DAY));
        // original unchanged
        assertEquals(28, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testTruncateObjectDispatch() {
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertNotNull(DateUtils.truncate((Object) cal, Calendar.HOUR_OF_DAY));
        assertNotNull(DateUtils.truncate((Object) cal.getTime(), Calendar.HOUR_OF_DAY));
    }

    @Test
    void testTruncateObjectInvalidType() {
        assertThrows(ClassCastException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.truncate(Integer.valueOf(1), Calendar.HOUR_OF_DAY);
            }
        });
    }

    @Test
    void testTruncateObjectNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.truncate((Object) null, Calendar.HOUR_OF_DAY);
            }
        });
    }

    @Test
    void testTruncateNullDate() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.truncate((Date) null, Calendar.HOUR_OF_DAY);
            }
        });
    }

    @Test
    void testTruncateNullCalendar() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.truncate((Calendar) null, Calendar.HOUR_OF_DAY);
            }
        });
    }

    @Test
    void testTruncateYearTooLarge() {
        final Calendar cal = Calendar.getInstance();
        cal.set(Calendar.YEAR, 280000001);
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.truncate(cal, Calendar.HOUR_OF_DAY);
            }
        });
    }

    @Test
    void testTruncateUnsupportedField() {
        final Calendar cal = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.truncate(cal, Calendar.DAY_OF_WEEK);
            }
        });
    }

    // ---- truncatedCompareTo / truncatedEquals ----

    @Test
    void testTruncatedCompareToAndEqualsCalendar() {
        final Calendar cal1 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Calendar cal2 = newCalendar(2002, Calendar.MARCH, 28, 8, 0, 0, 0);
        assertTrue(DateUtils.truncatedEquals(cal1, cal2, Calendar.DAY_OF_MONTH));
        assertEquals(0, DateUtils.truncatedCompareTo(cal1, cal2, Calendar.DAY_OF_MONTH));
        assertFalse(DateUtils.truncatedEquals(cal1, cal2, Calendar.HOUR_OF_DAY));
        assertTrue(DateUtils.truncatedCompareTo(cal1, cal2, Calendar.HOUR_OF_DAY) > 0);
    }

    @Test
    void testTruncatedCompareToAndEqualsDate() {
        final Calendar cal1 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        final Calendar cal2 = newCalendar(2002, Calendar.MARCH, 29, 8, 0, 0, 0);
        assertFalse(DateUtils.truncatedEquals(cal1.getTime(), cal2.getTime(), Calendar.DAY_OF_MONTH));
        assertTrue(DateUtils.truncatedCompareTo(cal1.getTime(), cal2.getTime(), Calendar.DAY_OF_MONTH) < 0);
    }

    @Test
    void testTruncatedCompareToNull() {
        final Calendar cal = Calendar.getInstance();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                DateUtils.truncatedCompareTo((Calendar) null, cal, Calendar.DATE);
            }
        });
    }

    // ---- constants ----

    @Test
    void testMillisConstants() {
        assertEquals(1000L, DateUtils.MILLIS_PER_SECOND);
        assertEquals(60000L, DateUtils.MILLIS_PER_MINUTE);
        assertEquals(3600000L, DateUtils.MILLIS_PER_HOUR);
        assertEquals(86400000L, DateUtils.MILLIS_PER_DAY);
    }

    @Test
    void testRangeConstantsDistinct() {
        final int[] constants = {DateUtils.RANGE_WEEK_SUNDAY, DateUtils.RANGE_WEEK_MONDAY, DateUtils.RANGE_WEEK_RELATIVE,
                DateUtils.RANGE_WEEK_CENTER, DateUtils.RANGE_MONTH_SUNDAY, DateUtils.RANGE_MONTH_MONDAY};
        for (int i = 0; i < constants.length; i++) {
            for (int j = i + 1; j < constants.length; j++) {
                if (constants[i] == constants[j]) {
                    fail("range constants must be distinct: " + constants[i]);
                }
            }
        }
    }

    // ---- constructor ----

    @Test
    void testPublicConstructor() {
        assertNotNull(new DateUtils());
    }
}
