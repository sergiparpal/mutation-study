/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.FieldPosition;
import java.text.Format;
import java.text.ParsePosition;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link ExtendedMessageFormat}.
 */
@Deprecated
class ExtendedMessageFormatAgentTest {

    /**
     * A trivial custom {@link Format} that upper-cases whatever it is given.
     */
    private static final class UpperCaseFormat extends Format {
        private static final long serialVersionUID = 1L;

        @Override
        public StringBuffer format(final Object obj, final StringBuffer toAppendTo, final FieldPosition pos) {
            return toAppendTo.append(String.valueOf(obj).toUpperCase(Locale.ROOT));
        }

        @Override
        public Object parseObject(final String source, final ParsePosition pos) {
            pos.setIndex(source.length());
            return source;
        }
    }

    /**
     * A {@link FormatFactory} that recognizes the name "upper" and records the
     * arguments/locale it was invoked with, so tests can assert on them.
     */
    private static final class RecordingFormatFactory implements FormatFactory {
        private String lastName;
        private String lastArguments;
        private Locale lastLocale;

        @Override
        public Format getFormat(final String name, final String arguments, final Locale locale) {
            lastName = name;
            lastArguments = arguments;
            lastLocale = locale;
            if ("upper".equals(name)) {
                return new UpperCaseFormat();
            }
            return null;
        }
    }

    private Map<String, FormatFactory> registryOf(final String name, final FormatFactory factory) {
        final Map<String, FormatFactory> registry = new HashMap<>();
        registry.put(name, factory);
        return registry;
    }

    @Test
    void testSimplePatternNoRegistryFormat() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0} and {1}");
        assertEquals("foo and bar", emf.format(new Object[] {"foo", "bar"}));
        assertEquals("{0} and {1}", emf.toPattern());
    }

    @Test
    void testConstructorDefaultsToDefaultLocale() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertEquals(Locale.getDefault(), emf.getLocale());
    }

    @Test
    void testConstructorWithExplicitLocale() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number}", Locale.FRENCH);
        assertEquals(Locale.FRENCH, emf.getLocale());
        assertEquals("1,5", emf.format(new Object[] {Double.valueOf(1.5d)}));
    }

    @Test
    void testConstructorWithNullLocaleFallsBackToDefault() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", (Locale) null);
        assertEquals(Locale.getDefault(), emf.getLocale());
    }

    @Test
    void testConstructorWithNullRegistryBehavesLikePlainMessageFormat() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}-{1}", Locale.US, null);
        assertEquals("a-b", emf.format(new Object[] {"a", "b"}));
        assertEquals("{0}-{1}", emf.toPattern());
    }

    @Test
    void testConstructorWithNullPatternThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat(null);
            }
        });
    }

    @Test
    void testCustomFormatViaRegistryIsUsedForFormatting() {
        final RecordingFormatFactory factory = new RecordingFormatFactory();
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", registryOf("upper", factory));
        assertEquals("HELLO", emf.format(new Object[] {"hello"}));
        assertEquals("upper", factory.lastName);
    }

    @Test
    void testCustomFormatPatternRoundTripsInToPattern() {
        final RecordingFormatFactory factory = new RecordingFormatFactory();
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", registryOf("upper", factory));
        assertEquals("{0,upper}", emf.toPattern());
    }

    @Test
    void testCustomFormatStyleArgumentsArePassedToFactory() {
        final RecordingFormatFactory factory = new RecordingFormatFactory();
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper,extra-style}", registryOf("upper", factory));
        emf.format(new Object[] {"hi"});
        assertEquals("extra-style", factory.lastArguments);
        assertEquals(Locale.getDefault(), factory.lastLocale);
    }

    @Test
    void testUnknownFormatNameFallsThroughToStandardMessageFormat() {
        final RecordingFormatFactory factory = new RecordingFormatFactory();
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number,integer}", registryOf("upper", factory));
        assertEquals("42", emf.format(new Object[] {Integer.valueOf(42)}));
        assertEquals(null, factory.lastName);
    }

    @Test
    void testMixedCustomAndStandardFormatsToPattern() {
        final RecordingFormatFactory factory = new RecordingFormatFactory();
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper} {1,number,integer}", registryOf("upper", factory));
        assertEquals("{0,upper} {1,number,integer}", emf.toPattern());
        assertEquals("HI 7", emf.format(new Object[] {"hi", Integer.valueOf(7)}));
    }

    @Test
    void testEqualsAndHashCodeForEquivalentInstances() {
        final ExtendedMessageFormat a = new ExtendedMessageFormat("{0}", Locale.US);
        final ExtendedMessageFormat b = new ExtendedMessageFormat("{0}", Locale.US);
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    void testEqualsForDifferentPatterns() {
        final ExtendedMessageFormat a = new ExtendedMessageFormat("{0}", Locale.US);
        final ExtendedMessageFormat b = new ExtendedMessageFormat("{0}-{1}", Locale.US);
        assertNotEquals(a, b);
    }

    @Test
    void testEqualsAgainstNullAndForeignType() {
        final ExtendedMessageFormat a = new ExtendedMessageFormat("{0}");
        assertFalse(a.equals(null));
        assertFalse(a.equals("{0}"));
        assertTrue(a.equals(a));
    }

    @Test
    void testSetFormatThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormat(0, new UpperCaseFormat());
            }
        });
    }

    @Test
    void testSetFormatByArgumentIndexThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormatByArgumentIndex(0, new UpperCaseFormat());
            }
        });
    }

    @Test
    void testSetFormatsThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormats(new Format[] {new UpperCaseFormat()});
            }
        });
    }

    @Test
    void testSetFormatsByArgumentIndexThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormatsByArgumentIndex(new Format[] {new UpperCaseFormat()});
            }
        });
    }

    @Test
    void testUnterminatedQuotedStringThrows() {
        final RecordingFormatFactory factory = new RecordingFormatFactory();
        final Map<String, FormatFactory> registry = registryOf("upper", factory);
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() {
                        new ExtendedMessageFormat("'unterminated", registry);
                    }
                });
        assertTrue(ex.getMessage().contains("Unterminated quoted string"));
    }

    @Test
    void testInvalidFormatArgumentIndexThrows() {
        final RecordingFormatFactory factory = new RecordingFormatFactory();
        final Map<String, FormatFactory> registry = registryOf("upper", factory);
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() {
                        new ExtendedMessageFormat("{abc}", registry);
                    }
                });
        assertTrue(ex.getMessage().contains("Invalid format argument index"));
    }

    @Test
    void testUnterminatedFormatElementThrows() {
        final RecordingFormatFactory factory = new RecordingFormatFactory();
        final Map<String, FormatFactory> registry = registryOf("upper", factory);
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() {
                        new ExtendedMessageFormat("{0", registry);
                    }
                });
        assertTrue(ex.getMessage().contains("Unterminated format element"));
    }

    @Test
    void testUnterminatedFormatDescriptionThrows() {
        final RecordingFormatFactory factory = new RecordingFormatFactory();
        final Map<String, FormatFactory> registry = registryOf("upper", factory);
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() {
                        new ExtendedMessageFormat("{0,upper", registry);
                    }
                });
        assertTrue(ex.getMessage().contains("Unterminated format element"));
    }

    @Test
    void testChoiceFormatPatternRoundTripsWithoutRegistry() {
        final String pattern = "{0,choice,0#no files|1#one file|1<{0,number} files}";
        final ExtendedMessageFormat emf = new ExtendedMessageFormat(pattern);
        assertNotNull(emf.toPattern());
        assertEquals("no files", emf.format(new Object[] {Integer.valueOf(0)}));
        assertEquals("one file", emf.format(new Object[] {Integer.valueOf(1)}));
        assertEquals("3 files", emf.format(new Object[] {Integer.valueOf(3)}));
    }

    @Test
    void testEmptyPattern() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("");
        assertEquals("", emf.toPattern());
        assertEquals("", emf.format(new Object[0]));
    }
}
