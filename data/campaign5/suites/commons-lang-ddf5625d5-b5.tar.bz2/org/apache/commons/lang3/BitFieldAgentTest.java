/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class BitFieldAgentTest {

    private static final BitField BIT_FIELD_1 = new BitField(0x0001);
    private static final BitField BIT_FIELD_2 = new BitField(0x000E);
    private static final BitField BIT_FIELD_3 = new BitField(0x0070);
    private static final BitField BIT_FIELD_4 = new BitField(0xFF00);

    @Test
    public void testIntConstructorZeroMaskHasZeroShift() {
        final BitField field = new BitField(0);
        assertEquals(0, field.getValue(0xFFFFFFFF));
        assertEquals(0, field.getRawValue(0xFFFFFFFF));
        assertFalse(field.isSet(0xFFFFFFFF));
    }

    @Test
    public void testLongConstructorZeroMaskHasZeroShift() {
        final BitField field = new BitField(0L);
        assertEquals(0L, field.getValue(0xFFFFFFFFFFFFFFFFL));
        assertEquals(0L, field.getRawValue(0xFFFFFFFFFFFFFFFFL));
        assertFalse(field.isSet(0xFFFFFFFFFFFFFFFFL));
    }

    @Test
    public void testClearInt() {
        assertEquals(0x10, BIT_FIELD_2.clear(0x1E));
        assertEquals(0x1E, BIT_FIELD_1.clear(0x1F));
        assertEquals(0xFFFFFFF1, BIT_FIELD_2.clear(0xFFFFFFFF));
    }

    @Test
    public void testClearLong() {
        final BitField field = new BitField(0xFF00000000L);
        final long holder = 0xFFFFFFFFFFL;
        assertEquals(0xFFFFFFFFL, field.clear(holder));
    }

    @Test
    public void testClearByte() {
        final byte clear1 = BIT_FIELD_2.clearByte((byte) 0x1E);
        assertEquals((byte) 0x10, clear1);
        final byte clear2 = BIT_FIELD_1.clearByte((byte) 0x1F);
        assertEquals((byte) 0x1E, clear2);
        final byte clear3 = BIT_FIELD_2.clearByte((byte) 0xFF);
        assertEquals((byte) 0xF1, clear3);
    }

    @Test
    public void testClearShort() {
        final short clear1 = BIT_FIELD_2.clearShort((short) 0x1E);
        assertEquals((short) 0x10, clear1);
        final short clear2 = BIT_FIELD_1.clearShort((short) 0x1F);
        assertEquals((short) 0x1E, clear2);
        final short clear3 = BIT_FIELD_2.clearShort((short) 0xFFFF);
        assertEquals((short) 0xFFF1, clear3);
    }

    @Test
    public void testSetInt() {
        assertEquals(0x1E, BIT_FIELD_2.set(0x10));
        assertEquals(0x1F, BIT_FIELD_1.set(0x1E));
        assertEquals(-1, BIT_FIELD_2.set(0xFFFFFFF1));
    }

    @Test
    public void testSetLong() {
        final BitField field = new BitField(0x0F00000000L);
        assertEquals(0x0F00000000L, field.set(0L));
        assertEquals(0xFFFFFFFFFFL, field.set(0xF0FFFFFFFFL));
    }

    @Test
    public void testSetByte() {
        final byte clear1 = BIT_FIELD_2.setByte((byte) 0x10);
        assertEquals((byte) 0x1E, clear1);
        final byte clear2 = BIT_FIELD_1.setByte((byte) 0x1E);
        assertEquals((byte) 0x1F, clear2);
        final byte clear3 = BIT_FIELD_2.setByte((byte) 0xF1);
        assertEquals((byte) 0xFF, clear3);
    }

    @Test
    public void testSetShort() {
        final short clear1 = BIT_FIELD_2.setShort((short) 0x10);
        assertEquals((short) 0x1E, clear1);
        final short clear2 = BIT_FIELD_1.setShort((short) 0x1E);
        assertEquals((short) 0x1F, clear2);
        final short clear3 = BIT_FIELD_2.setShort((short) 0xFFF1);
        assertEquals((short) 0xFFFF, clear3);
    }

    @Test
    public void testIsSetInt() {
        assertFalse(BIT_FIELD_1.isSet(~0x01));
        for (int i = 0; i < 128; i++) {
            if ((i & 1) != 0) {
                assertTrue(BIT_FIELD_1.isSet(i), "Unexpectedly not set: " + Integer.toHexString(i));
            } else {
                assertFalse(BIT_FIELD_1.isSet(i), "Unexpectedly set: " + Integer.toHexString(i));
            }
        }
    }

    @Test
    public void testIsSetLong() {
        final BitField field = new BitField(0x100000000L);
        assertTrue(field.isSet(0x100000000L));
        assertFalse(field.isSet(0x0FFFFFFFFL));
    }

    @Test
    public void testIsAllSetInt() {
        for (int i = 0; i < 128; i++) {
            if ((i & 0x0E) == 0x0E) {
                assertTrue(BIT_FIELD_2.isAllSet(i), "Unexpectedly not set: " + Integer.toHexString(i));
            } else {
                assertFalse(BIT_FIELD_2.isAllSet(i), "Unexpectedly set: " + Integer.toHexString(i));
            }
        }
    }

    @Test
    public void testIsAllSetLong() {
        final BitField field = new BitField(0x300000000L);
        assertTrue(field.isAllSet(0x300000000L));
        assertFalse(field.isAllSet(0x200000000L));
        assertFalse(field.isAllSet(0L));
    }

    @Test
    public void testGetValueInt() {
        assertEquals(0, BIT_FIELD_2.getValue(0));
        assertEquals(4, BIT_FIELD_2.getValue(0xFFFFFFF9));
        assertEquals(1, BIT_FIELD_2.getValue(0x02));
        assertEquals(1, BIT_FIELD_3.getValue(0x10));
    }

    @Test
    public void testGetValueLong() {
        final BitField field = new BitField(0xFF00000000L);
        assertEquals(0xABL, field.getValue(0xAB00000000L));
        assertEquals(0L, field.getValue(0L));
    }

    @Test
    public void testGetShortValue() {
        assertEquals((short) 0, BIT_FIELD_2.getShortValue((short) 0));
        assertEquals((short) 4, BIT_FIELD_2.getShortValue((short) 0xFFF9));
        assertEquals((short) 1, BIT_FIELD_2.getShortValue((short) 0x02));
        assertEquals((short) 1, BIT_FIELD_3.getShortValue((short) 0x10));
    }

    @Test
    public void testGetRawValueInt() {
        assertEquals(0, BIT_FIELD_2.getRawValue(0));
        assertEquals(8, BIT_FIELD_2.getRawValue(0xFFFFFFF9));
        assertEquals(2, BIT_FIELD_2.getRawValue(0x02));
        assertEquals(0x10, BIT_FIELD_3.getRawValue(0x10));
    }

    @Test
    public void testGetRawValueLong() {
        final BitField field = new BitField(0xFF00000000L);
        assertEquals(0xAB00000000L, field.getRawValue(0xABFF000000L | 0xAB00000000L));
        assertEquals(0L, field.getRawValue(0L));
    }

    @Test
    public void testGetShortRawValue() {
        assertEquals((short) 0, BIT_FIELD_2.getShortRawValue((short) 0));
        assertEquals((short) 8, BIT_FIELD_2.getShortRawValue((short) 0xFFF9));
        assertEquals((short) 2, BIT_FIELD_2.getShortRawValue((short) 0x02));
        assertEquals((short) 0x10, BIT_FIELD_3.getShortRawValue((short) 0x10));
    }

    @Test
    public void testSetValueInt() {
        assertEquals(0x02, BIT_FIELD_2.setValue(0, 1));
        assertEquals(0xFFFFFFF9, BIT_FIELD_2.setValue(0xFFFFFFF9, 4));
        assertEquals(0x03, BIT_FIELD_2.setValue(0x0F, 1));
        assertEquals(0x10, BIT_FIELD_3.setValue(0, 1));
        // value larger than field width is masked away (bits outside the field untouched)
        assertEquals(0x00, BIT_FIELD_2.setValue(0, 8));
    }

    @Test
    public void testSetValueLong() {
        final BitField field = new BitField(0xFF00000000L);
        assertEquals(0xAB00000000L, field.setValue(0L, 0xAB));
        assertEquals(0xAB000000FFL, field.setValue(0xFFL, 0xAB));
    }

    @Test
    public void testSetShortValue() {
        assertEquals((short) 0x02, BIT_FIELD_2.setShortValue((short) 0, (short) 1));
        assertEquals((short) 0xFFF9, BIT_FIELD_2.setShortValue((short) 0xFFF9, (short) 4));
        assertEquals((short) 0x10, BIT_FIELD_3.setShortValue((short) 0, (short) 1));
    }

    @Test
    public void testSetBooleanInt() {
        assertEquals(BIT_FIELD_1.set(0), BIT_FIELD_1.setBoolean(0, true));
        assertEquals(BIT_FIELD_1.clear(0xFF), BIT_FIELD_1.setBoolean(0xFF, false));
        assertTrue(BIT_FIELD_1.isSet(BIT_FIELD_1.setBoolean(0, true)));
        assertFalse(BIT_FIELD_1.isSet(BIT_FIELD_1.setBoolean(0xFF, false)));
    }

    @Test
    public void testSetBooleanLong() {
        final BitField field = new BitField(0x100000000L);
        assertEquals(0x100000000L, field.setBoolean(0L, true));
        assertEquals(0L, field.setBoolean(0x100000000L, false));
    }

    @Test
    public void testSetByteBoolean() {
        final byte set = BIT_FIELD_1.setByteBoolean((byte) 0, true);
        assertEquals((byte) 1, set);
        final byte cleared = BIT_FIELD_1.setByteBoolean((byte) 0xFF, false);
        assertEquals((byte) 0xFE, cleared);
    }

    @Test
    public void testSetShortBoolean() {
        final short set = BIT_FIELD_1.setShortBoolean((short) 0, true);
        assertEquals((short) 1, set);
        final short cleared = BIT_FIELD_1.setShortBoolean((short) 0xFFFF, false);
        assertEquals((short) 0xFFFE, cleared);
    }

    @Test
    public void testNegativeIntMask() {
        final BitField field = new BitField(0x80000000);
        assertTrue(field.isSet(0x80000000));
        assertFalse(field.isSet(0x7FFFFFFF));
        assertEquals(-1, field.getValue(0x80000000));
        assertEquals(0x80000000, field.setValue(0, 1));
    }

    @Test
    public void testFourthBitField() {
        assertFalse(BIT_FIELD_4.isSet(0));
        assertTrue(BIT_FIELD_4.isSet(0x200));
        assertEquals(0x59, BIT_FIELD_4.getValue(0x5900));
        assertEquals(0x5900, BIT_FIELD_4.setValue(0, 0x59));
    }
}
