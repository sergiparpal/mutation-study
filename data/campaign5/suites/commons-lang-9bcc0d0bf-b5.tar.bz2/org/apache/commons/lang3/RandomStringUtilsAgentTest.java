/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Random;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link RandomStringUtils}.
 */
public class RandomStringUtilsAgentTest {

    @Test
    public void testRandomCountZero() {
        assertEquals("", RandomStringUtils.random(0));
    }

    @Test
    public void testRandomCountNegativeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(-1);
            }
        });
    }

    @Test
    public void testRandomLength() {
        final String s = RandomStringUtils.random(50);
        assertEquals(50, s.length());
    }

    @Test
    public void testRandomAlphabeticOnlyLetters() {
        final String s = RandomStringUtils.randomAlphabetic(200);
        assertEquals(200, s.length());
        for (int i = 0; i < s.length(); i++) {
            assertTrue(Character.isLetter(s.charAt(i)), "Expected letter at index " + i + " but got " + s.charAt(i));
        }
    }

    @Test
    public void testRandomAlphabeticRange() {
        for (int i = 0; i < 20; i++) {
            final String s = RandomStringUtils.randomAlphabetic(5, 10);
            assertTrue(s.length() >= 5 && s.length() < 10, "length=" + s.length());
        }
    }

    @Test
    public void testRandomAlphanumericOnlyLettersOrDigits() {
        final String s = RandomStringUtils.randomAlphanumeric(200);
        assertEquals(200, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(Character.isLetterOrDigit(c), "Unexpected char: " + c);
        }
    }

    @Test
    public void testRandomAsciiRange() {
        final String s = RandomStringUtils.randomAscii(500);
        assertEquals(500, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 32 && c <= 126, "char out of ASCII printable range: " + (int) c);
        }
    }

    @Test
    public void testRandomNumericOnlyDigits() {
        final String s = RandomStringUtils.randomNumeric(200);
        assertEquals(200, s.length());
        for (int i = 0; i < s.length(); i++) {
            assertTrue(Character.isDigit(s.charAt(i)), "Expected digit at index " + i);
        }
    }

    @Test
    public void testRandomGraphRange() {
        final String s = RandomStringUtils.randomGraph(500);
        assertEquals(500, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 33 && c < 126, "char out of graph range: " + (int) c);
        }
    }

    @Test
    public void testRandomPrintRange() {
        final String s = RandomStringUtils.randomPrint(500);
        assertEquals(500, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 32 && c < 126, "char out of print range: " + (int) c);
        }
    }

    @Test
    public void testRandomWithCharsArray() {
        final char[] chars = { 'x', 'y', 'z' };
        final String s = RandomStringUtils.random(100, chars);
        assertEquals(100, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c == 'x' || c == 'y' || c == 'z', "Unexpected char: " + c);
        }
    }

    @Test
    public void testRandomWithEmptyCharsArrayThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, new char[0]);
            }
        });
    }

    @Test
    public void testRandomWithNullCharsArrayUsesFullRange() {
        final String s = RandomStringUtils.random(10, (char[]) null);
        assertEquals(10, s.length());
    }

    @Test
    public void testRandomWithString() {
        final String s = RandomStringUtils.random(50, "ab");
        assertEquals(50, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c == 'a' || c == 'b', "Unexpected char: " + c);
        }
    }

    @Test
    public void testRandomWithEmptyStringThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, "");
            }
        });
    }

    @Test
    public void testRandomWithNullStringUsesFullRange() {
        final String s = RandomStringUtils.random(10, (String) null);
        assertEquals(10, s.length());
    }

    @Test
    public void testRandomStartEndLettersNumbers() {
        final String s = RandomStringUtils.random(30, '0', '9' + 1, false, true);
        assertEquals(30, s.length());
        for (int i = 0; i < s.length(); i++) {
            assertTrue(Character.isDigit(s.charAt(i)));
        }
    }

    @Test
    public void testRandomEndBeforeStartThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 10, 5, false, false);
            }
        });
    }

    @Test
    public void testRandomNegativeStartThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, -5, 10, false, false);
            }
        });
    }

    @Test
    public void testRandomFixedSeedIsDeterministic() {
        final Random r1 = new Random(42L);
        final Random r2 = new Random(42L);
        final String s1 = RandomStringUtils.random(20, 0, 0, true, true, null, r1);
        final String s2 = RandomStringUtils.random(20, 0, 0, true, true, null, r2);
        assertEquals(s1, s2);
    }

    @Test
    public void testRandomNoLettersInRangeThrows() {
        // Range [0x30, 0x3A) only contains digits, no letters.
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, '0', '9' + 1, true, false);
            }
        });
    }

    @Test
    public void testRandomNoDigitsInRangeThrows() {
        // Range [0x41, 0x5B) only contains letters, no digits.
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 'A', 'Z' + 1, false, true);
            }
        });
    }

    @Test
    public void testInsecureSingletonNotNullAndStable() {
        final RandomStringUtils a = RandomStringUtils.insecure();
        final RandomStringUtils b = RandomStringUtils.insecure();
        assertNotNull(a);
        assertEquals(a, b);
    }

    @Test
    public void testSecureSingletonNotNullAndStable() {
        final RandomStringUtils a = RandomStringUtils.secure();
        final RandomStringUtils b = RandomStringUtils.secure();
        assertNotNull(a);
        assertEquals(a, b);
    }

    @Test
    public void testSecureStrongSingletonNotNullAndStable() {
        final RandomStringUtils a = RandomStringUtils.secureStrong();
        final RandomStringUtils b = RandomStringUtils.secureStrong();
        assertNotNull(a);
        assertEquals(a, b);
    }

    @Test
    public void testInstanceNextCount() {
        final RandomStringUtils ru = RandomStringUtils.insecure();
        final String s = ru.next(15);
        assertEquals(15, s.length());
    }

    @Test
    public void testInstanceNextZeroCount() {
        final RandomStringUtils ru = RandomStringUtils.insecure();
        assertEquals("", ru.next(0));
    }

    @Test
    public void testInstanceNextNegativeCountThrows() {
        final RandomStringUtils ru = RandomStringUtils.insecure();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ru.next(-3);
            }
        });
    }

    @Test
    public void testInstanceNextAlphabetic() {
        final RandomStringUtils ru = RandomStringUtils.insecure();
        final String s = ru.nextAlphabetic(40);
        assertEquals(40, s.length());
        for (int i = 0; i < s.length(); i++) {
            assertTrue(Character.isLetter(s.charAt(i)));
        }
    }

    @Test
    public void testInstanceNextAlphabeticRange() {
        final RandomStringUtils ru = RandomStringUtils.insecure();
        final String s = ru.nextAlphabetic(3, 4);
        assertEquals(3, s.length());
    }

    @Test
    public void testInstanceNextAlphanumeric() {
        final RandomStringUtils ru = RandomStringUtils.insecure();
        final String s = ru.nextAlphanumeric(60);
        assertEquals(60, s.length());
        for (int i = 0; i < s.length(); i++) {
            assertTrue(Character.isLetterOrDigit(s.charAt(i)));
        }
    }

    @Test
    public void testInstanceNextNumeric() {
        final RandomStringUtils ru = RandomStringUtils.insecure();
        final String s = ru.nextNumeric(25);
        assertEquals(25, s.length());
        for (int i = 0; i < s.length(); i++) {
            assertTrue(Character.isDigit(s.charAt(i)));
        }
    }

    @Test
    public void testInstanceNextAscii() {
        final RandomStringUtils ru = RandomStringUtils.insecure();
        final String s = ru.nextAscii(60);
        assertEquals(60, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 32 && c <= 126);
        }
    }

    @Test
    public void testInstanceNextGraph() {
        final RandomStringUtils ru = RandomStringUtils.insecure();
        final String s = ru.nextGraph(60);
        assertEquals(60, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 33 && c < 126);
        }
    }

    @Test
    public void testInstanceNextPrint() {
        final RandomStringUtils ru = RandomStringUtils.insecure();
        final String s = ru.nextPrint(60);
        assertEquals(60, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 32 && c < 126);
        }
    }

    @Test
    public void testInstanceNextWithCharsVarargs() {
        final RandomStringUtils ru = RandomStringUtils.insecure();
        final String s = ru.next(10, 'a', 'b', 'c');
        assertEquals(10, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c == 'a' || c == 'b' || c == 'c');
        }
    }

    @Test
    public void testInstanceNextWithString() {
        final RandomStringUtils ru = RandomStringUtils.insecure();
        final String s = ru.next(10, "pq");
        assertEquals(10, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c == 'p' || c == 'q');
        }
    }

    @Test
    public void testNoArgConstructorDeprecatedButUsable() {
        final RandomStringUtils ru = new RandomStringUtils();
        assertNotNull(ru);
        final String s = ru.next(5);
        assertEquals(5, s.length());
    }

    @Test
    public void testToStringContainsClassName() {
        final RandomStringUtils ru = RandomStringUtils.insecure();
        final String str = ru.toString();
        assertNotNull(str);
        assertTrue(str.startsWith("RandomStringUtils ["));
    }

    @Test
    public void testDistinctInstancesAreDifferentSingletons() {
        assertFalse(RandomStringUtils.secure() == RandomStringUtils.secureStrong());
        assertFalse(RandomStringUtils.secure() == RandomStringUtils.insecure());
    }
}
