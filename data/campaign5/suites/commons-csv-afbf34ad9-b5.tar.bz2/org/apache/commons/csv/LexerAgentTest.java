/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link Lexer}.
 */
class LexerAgentTest {

    private Lexer createLexer(final String data, final CSVFormat format) {
        return new Lexer(format, new ExtendedBufferedReader(new StringReader(data)));
    }

    @Test
    void testSimpleTokenLexing() throws IOException {
        final Lexer lexer = createLexer("a,b,c\n", CSVFormat.DEFAULT);
        Token token = lexer.nextToken(new Token());
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a", token.content.toString());
        token = lexer.nextToken(new Token());
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("b", token.content.toString());
        token = lexer.nextToken(new Token());
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("c", token.content.toString());
        token = lexer.nextToken(new Token());
        assertEquals(Token.Type.EOF, token.type);
        assertFalse(token.isReady);
        lexer.close();
    }

    @Test
    void testEmptyInputYieldsEof() throws IOException {
        final Lexer lexer = createLexer("", CSVFormat.DEFAULT);
        final Token token = lexer.nextToken(new Token());
        assertEquals(Token.Type.EOF, token.type);
        assertFalse(token.isReady);
        assertEquals("", token.content.toString());
        lexer.close();
    }

    @Test
    void testTrailingEmptyTokenBeforeEndOfRecord() throws IOException {
        final Lexer lexer = createLexer("a,\n", CSVFormat.DEFAULT);
        Token token = lexer.nextToken(new Token());
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a", token.content.toString());
        token = lexer.nextToken(new Token());
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("", token.content.toString());
        lexer.close();
    }

    @Test
    void testTokenWithDataAtEofHasIsReadyTrue() throws IOException {
        final Lexer lexer = createLexer("abc", CSVFormat.DEFAULT);
        final Token token = lexer.nextToken(new Token());
        assertEquals(Token.Type.EOF, token.type);
        assertTrue(token.isReady);
        assertEquals("abc", token.content.toString());
        lexer.close();
    }

    @Test
    void testQuotedTokenSimple() throws IOException {
        final Lexer lexer = createLexer("\"hello\"\n", CSVFormat.DEFAULT);
        final Token token = lexer.nextToken(new Token());
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("hello", token.content.toString());
        assertTrue(token.isQuoted);
        lexer.close();
    }

    @Test
    void testQuotedTokenWithDoubledQuote() throws IOException {
        final Lexer lexer = createLexer("\"a\"\"b\"\n", CSVFormat.DEFAULT);
        final Token token = lexer.nextToken(new Token());
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("a\"b", token.content.toString());
        lexer.close();
    }

    @Test
    void testQuotedTokenFollowedByDelimiter() throws IOException {
        final Lexer lexer = createLexer("\"a\",b\n", CSVFormat.DEFAULT);
        Token token = lexer.nextToken(new Token());
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a", token.content.toString());
        assertTrue(token.isQuoted);
        token = lexer.nextToken(new Token());
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("b", token.content.toString());
        assertFalse(token.isQuoted);
        lexer.close();
    }

    @Test
    void testInvalidCharacterAfterEncapsulatedTokenThrowsWithoutTrailingData() {
        final Lexer lexer = createLexer("\"a\"b,c\n", CSVFormat.DEFAULT);
        final CSVException e = assertThrows(CSVException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                lexer.nextToken(new Token());
            }
        });
        assertTrue(e.getMessage().contains("Invalid character"));
    }

    @Test
    void testTrailingDataAppendsCharactersAfterEncapsulatedToken() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingData(true).get();
        final Lexer lexer = createLexer("\"a\"b,c\n", format);
        final Token token = lexer.nextToken(new Token());
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("ab", token.content.toString());
        lexer.close();
    }

    @Test
    void testLenientEofOnUnterminatedQuote() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setLenientEof(true).get();
        final Lexer lexer = createLexer("\"abc", format);
        final Token token = lexer.nextToken(new Token());
        assertEquals(Token.Type.EOF, token.type);
        assertTrue(token.isReady);
        assertEquals("abc", token.content.toString());
        lexer.close();
    }

    @Test
    void testStrictEofOnUnterminatedQuoteThrows() {
        final Lexer lexer = createLexer("\"abc", CSVFormat.DEFAULT);
        final CSVException e = assertThrows(CSVException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                lexer.nextToken(new Token());
            }
        });
        assertTrue(e.getMessage().contains("EOF reached before encapsulated token finished"));
    }

    @Test
    void testEscapedDelimiterIsLiteral() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer("a\\,b,c\n", format);
        Token token = lexer.nextToken(new Token());
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a,b", token.content.toString());
        token = lexer.nextToken(new Token());
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("c", token.content.toString());
        lexer.close();
    }

    @Test
    void testEscapedControlCharacters() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer("a\\nb\n", format);
        final Token token = lexer.nextToken(new Token());
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("a\nb", token.content.toString());
        lexer.close();
    }

    @Test
    void testEscapeFollowedByUnexpectedCharacterIsKeptLiteral() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer("a\\x,b\n", format);
        final Token token = lexer.nextToken(new Token());
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a\\x", token.content.toString());
        lexer.close();
    }

    @Test
    void testEscapeAtEndOfFileThrows() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer("a\\", format);
        final CSVException e = assertThrows(CSVException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                lexer.nextToken(new Token());
            }
        });
        assertTrue(e.getMessage().contains("EOF while processing escape sequence"));
    }

    @Test
    void testCommentLineIsTrimmedAndTyped() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final Lexer lexer = createLexer("#  comment  \na,b\n", format);
        Token token = lexer.nextToken(new Token());
        assertEquals(Token.Type.COMMENT, token.type);
        assertEquals("comment", token.content.toString());
        token = lexer.nextToken(new Token());
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a", token.content.toString());
        token = lexer.nextToken(new Token());
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("b", token.content.toString());
        lexer.close();
    }

    @Test
    void testCommentAtEndOfFileWithoutNewlineIsStillAComment() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final Lexer lexer = createLexer("#comment", format);
        final Token token = lexer.nextToken(new Token());
        assertEquals(Token.Type.COMMENT, token.type);
        assertEquals("comment", token.content.toString());
        lexer.close();
    }

    @Test
    void testCommentMarkerWithNothingAfterItAtEofYieldsEof() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final Lexer lexer = createLexer("a\n#", format);
        lexer.nextToken(new Token());
        final Token token = lexer.nextToken(new Token());
        assertEquals(Token.Type.EOF, token.type);
        assertFalse(token.isReady);
        lexer.close();
    }

    @Test
    void testIgnoreEmptyLinesSkipsBlankLines() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreEmptyLines(true).get();
        final Lexer lexer = createLexer("\n\na\n", format);
        final Token token = lexer.nextToken(new Token());
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("a", token.content.toString());
        lexer.close();
    }

    @Test
    void testIgnoreEmptyLinesAllBlankYieldsEof() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreEmptyLines(true).get();
        final Lexer lexer = createLexer("\n\n", format);
        final Token token = lexer.nextToken(new Token());
        assertEquals(Token.Type.EOF, token.type);
        assertFalse(token.isReady);
        lexer.close();
    }

    @Test
    void testDoNotIgnoreEmptyLinesKeepsBlankLine() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreEmptyLines(false).get();
        final Lexer lexer = createLexer("\na\n", format);
        final Token token = lexer.nextToken(new Token());
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("", token.content.toString());
        lexer.close();
    }

    @Test
    void testIgnoreSurroundingSpacesTrimsLeadingAndTrailing() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreSurroundingSpaces(true).get();
        final Lexer lexer = createLexer("  a  ,  b  \n", format);
        Token token = lexer.nextToken(new Token());
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a", token.content.toString());
        token = lexer.nextToken(new Token());
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("b", token.content.toString());
        lexer.close();
    }

    @Test
    void testMultiCharacterDelimiterSplitsTokens() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        final Lexer lexer = createLexer("a::b\n", format);
        Token token = lexer.nextToken(new Token());
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a", token.content.toString());
        token = lexer.nextToken(new Token());
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("b", token.content.toString());
        lexer.close();
    }

    @Test
    void testPartialDelimiterMatchIsNotADelimiter() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        final Lexer lexer = createLexer("a:b\n", format);
        final Token token = lexer.nextToken(new Token());
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("a:b", token.content.toString());
        lexer.close();
    }

    @Test
    void testIsDelimiterSingleCharBoundary() throws IOException {
        final Lexer lexer = createLexer("x", CSVFormat.DEFAULT);
        assertFalse(lexer.isDelimiter('a'));
        assertTrue(lexer.isDelimiter(','));
        lexer.close();
    }

    @Test
    void testIsEndOfFile() {
        final Lexer lexer = createLexer("", CSVFormat.DEFAULT);
        assertTrue(lexer.isEndOfFile(-1));
        assertFalse(lexer.isEndOfFile('a'));
        assertFalse(lexer.isEndOfFile(0));
    }

    @Test
    void testIsStartOfLine() {
        final Lexer lexer = createLexer("", CSVFormat.DEFAULT);
        assertTrue(lexer.isStartOfLine('\n'));
        assertTrue(lexer.isStartOfLine('\r'));
        assertTrue(lexer.isStartOfLine(Constants.UNDEFINED));
        assertFalse(lexer.isStartOfLine('a'));
    }

    @Test
    void testIsCommentStartQuoteAndEscape() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').setEscape('\\').get();
        final Lexer lexer = createLexer("", format);
        assertTrue(lexer.isCommentStart('#'));
        assertFalse(lexer.isCommentStart('a'));
        assertTrue(lexer.isQuoteChar('"'));
        assertFalse(lexer.isQuoteChar('a'));
        assertTrue(lexer.isEscape('\\'));
        assertFalse(lexer.isEscape('a'));
    }

    @Test
    void testIsCommentQuoteEscapeDisabledByDefault() {
        final Lexer lexer = createLexer("", CSVFormat.DEFAULT);
        assertFalse(lexer.isCommentStart('#'));
        assertFalse(lexer.isEscape('\\'));
        assertTrue(lexer.isQuoteChar('"'));
    }

    @Test
    void testReadEndOfLineCrLf() throws IOException {
        final Lexer lexer = createLexer("a\r\nb\n", CSVFormat.DEFAULT);
        assertNull(lexer.getFirstEol());
        final Token token = lexer.nextToken(new Token());
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("a", token.content.toString());
        assertEquals("\r\n", lexer.getFirstEol());
    }

    @Test
    void testReadEndOfLineLfOnly() throws IOException {
        final Lexer lexer = createLexer("a\nb\n", CSVFormat.DEFAULT);
        lexer.nextToken(new Token());
        assertEquals("\n", lexer.getFirstEol());
    }

    @Test
    void testReadEndOfLineCrOnly() throws IOException {
        final Lexer lexer = createLexer("a\rb\n", CSVFormat.DEFAULT);
        lexer.nextToken(new Token());
        assertEquals("\r", lexer.getFirstEol());
    }

    @Test
    void testTrimTrailingSpaces() {
        final Lexer lexer = createLexer("", CSVFormat.DEFAULT);
        final StringBuilder withTrailingSpaces = new StringBuilder("hello   ");
        lexer.trimTrailingSpaces(withTrailingSpaces);
        assertEquals("hello", withTrailingSpaces.toString());

        final StringBuilder noTrailingSpaces = new StringBuilder("hello");
        lexer.trimTrailingSpaces(noTrailingSpaces);
        assertEquals("hello", noTrailingSpaces.toString());

        final StringBuilder allSpaces = new StringBuilder("   ");
        lexer.trimTrailingSpaces(allSpaces);
        assertEquals("", allSpaces.toString());

        final StringBuilder empty = new StringBuilder();
        lexer.trimTrailingSpaces(empty);
        assertEquals("", empty.toString());
    }

    @Test
    void testReadEscapeMappingsForKnownLetters() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer("rntbf", format);
        assertEquals(Constants.CR, lexer.readEscape());
        assertEquals(Constants.LF, lexer.readEscape());
        assertEquals(Constants.TAB, lexer.readEscape());
        assertEquals(Constants.BACKSPACE, lexer.readEscape());
        assertEquals(Constants.FF, lexer.readEscape());
        lexer.close();
    }

    @Test
    void testReadEscapeReturnsEofForUnknownChar() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer("z", format);
        assertEquals(-1, lexer.readEscape());
        lexer.close();
    }

    @Test
    void testGetBytesReadCharacterPositionAndLineNumber() throws IOException {
        final Lexer lexer = createLexer("ab\ncd\n", CSVFormat.DEFAULT);
        assertEquals(0, lexer.getCharacterPosition());
        assertEquals(0, lexer.getCurrentLineNumber());
        assertEquals(0, lexer.getBytesRead());
        lexer.nextToken(new Token());
        assertEquals(3, lexer.getCharacterPosition());
        assertEquals(1, lexer.getCurrentLineNumber());
        assertEquals(0, lexer.getBytesRead());
        lexer.close();
    }

    @Test
    void testCloseAndIsClosed() throws IOException {
        final Lexer lexer = createLexer("a,b\n", CSVFormat.DEFAULT);
        assertFalse(lexer.isClosed());
        lexer.close();
        assertTrue(lexer.isClosed());
    }
}
