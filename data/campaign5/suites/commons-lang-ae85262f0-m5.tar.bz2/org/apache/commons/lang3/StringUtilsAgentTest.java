/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Arrays;
import java.util.Locale;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link StringUtils}.
 */
class StringUtilsAgentTest {

    @Test
    void testIsEmptyIsBlank() {
        assertTrue(StringUtils.isEmpty(null));
        assertTrue(StringUtils.isEmpty(""));
        assertFalse(StringUtils.isEmpty(" "));
        assertFalse(StringUtils.isEmpty("bob"));

        assertTrue(StringUtils.isBlank(null));
        assertTrue(StringUtils.isBlank(""));
        assertTrue(StringUtils.isBlank(" "));
        assertTrue(StringUtils.isBlank("\t\n\r"));
        assertFalse(StringUtils.isBlank("bob"));
        assertFalse(StringUtils.isBlank("  bob  "));

        assertFalse(StringUtils.isNotEmpty(null));
        assertTrue(StringUtils.isNotEmpty("bob"));

        assertFalse(StringUtils.isNotBlank(null));
        assertFalse(StringUtils.isNotBlank(" "));
        assertTrue(StringUtils.isNotBlank("bob"));
    }

    @Test
    void testIsAnyAllNoneBlankEmpty() {
        assertFalse(StringUtils.isAnyBlank((String[]) null));
        assertTrue(StringUtils.isAnyBlank("a", "", "b"));
        assertFalse(StringUtils.isAnyBlank("a", "b"));
        assertFalse(StringUtils.isAnyBlank());

        assertTrue(StringUtils.isAllBlank());
        assertTrue(StringUtils.isAllBlank((String[]) null));
        assertTrue(StringUtils.isAllBlank(null, "", " "));
        assertFalse(StringUtils.isAllBlank(null, "a"));

        assertTrue(StringUtils.isNoneBlank("a", "b"));
        assertFalse(StringUtils.isNoneBlank("a", ""));

        assertTrue(StringUtils.isAnyEmpty("a", ""));
        assertFalse(StringUtils.isAnyEmpty("a", "b"));

        assertTrue(StringUtils.isAllEmpty("", null));
        assertFalse(StringUtils.isAllEmpty("", "a"));

        assertTrue(StringUtils.isNoneEmpty("a", "b"));
        assertFalse(StringUtils.isNoneEmpty("a", ""));
    }

    @Test
    void testTrimAndStrip() {
        assertNull(StringUtils.trim(null));
        assertEquals("", StringUtils.trim("   "));
        assertEquals("abc", StringUtils.trim("  abc  "));

        assertEquals("", StringUtils.trimToEmpty(null));
        assertEquals("abc", StringUtils.trimToEmpty("  abc  "));

        assertNull(StringUtils.trimToNull("   "));
        assertEquals("abc", StringUtils.trimToNull("  abc  "));

        assertNull(StringUtils.strip(null));
        assertEquals("abc", StringUtils.strip(" abc "));
        assertEquals("abc", StringUtils.strip("xxabcyy", "xy"));

        assertNull(StringUtils.stripStart(null, "x"));
        assertEquals("abcxx", StringUtils.stripStart("xxabcxx", "x"));

        assertNull(StringUtils.stripEnd(null, "x"));
        assertEquals("xxabc", StringUtils.stripEnd("xxabcxx", "x"));

        assertEquals("", StringUtils.stripToEmpty(null));
        assertEquals("abc", StringUtils.stripToEmpty("  abc  "));

        assertNull(StringUtils.stripToNull("   "));
        assertEquals("abc", StringUtils.stripToNull("  abc  "));
    }

    @Test
    void testEqualsAndCompare() {
        assertTrue(StringUtils.equals(null, null));
        assertFalse(StringUtils.equals(null, "abc"));
        assertFalse(StringUtils.equals("abc", null));
        assertTrue(StringUtils.equals("abc", "abc"));
        assertFalse(StringUtils.equals("abc", "abd"));

        assertTrue(StringUtils.equalsIgnoreCase("abc", "ABC"));
        assertTrue(StringUtils.equalsIgnoreCase(null, null));
        assertFalse(StringUtils.equalsIgnoreCase(null, "abc"));

        assertTrue(StringUtils.equalsAny("abc", "xyz", "abc"));
        assertFalse(StringUtils.equalsAny("abc", "xyz", "def"));

        assertTrue(StringUtils.equalsAnyIgnoreCase("abc", "xyz", "ABC"));

        assertEquals(0, StringUtils.compare(null, null));
        assertTrue(StringUtils.compare(null, "a") < 0);
        assertTrue(StringUtils.compare("a", null) > 0);
        assertTrue(StringUtils.compare("a", "b") < 0);

        assertTrue(StringUtils.compare(null, "a", true) < 0);
        assertTrue(StringUtils.compare(null, "a", false) > 0);

        assertEquals(0, StringUtils.compareIgnoreCase("ABC", "abc"));
    }

    @Test
    void testIndexOfAndContains() {
        assertEquals(-1, StringUtils.indexOf(null, "a"));
        assertEquals(-1, StringUtils.indexOf("abc", null));
        assertEquals(0, StringUtils.indexOf("", ""));
        assertEquals(1, StringUtils.indexOf("abc", "bc"));

        assertEquals(-1, StringUtils.indexOf(null, 'a'));
        assertEquals(1, StringUtils.indexOf("abc", 'b'));

        assertFalse(StringUtils.contains(null, "a"));
        assertFalse(StringUtils.contains("abc", null));
        assertTrue(StringUtils.contains("abc", "b"));
        assertTrue(StringUtils.contains("abc", ""));

        assertFalse(StringUtils.contains(null, 'a'));
        assertTrue(StringUtils.contains("abc", 'a'));

        assertTrue(StringUtils.containsIgnoreCase("abc", "B"));
        assertFalse(StringUtils.containsIgnoreCase(null, "a"));

        assertFalse(StringUtils.containsAny(null, 'a'));
        assertTrue(StringUtils.containsAny("abc", 'z', 'a'));

        assertTrue(StringUtils.containsNone("abc", 'x', 'y'));
        assertFalse(StringUtils.containsNone("abc", 'x', 'y', 'a'));
        assertTrue(StringUtils.containsNone(null, 'x'));

        assertFalse(StringUtils.containsWhitespace(null));
        assertFalse(StringUtils.containsWhitespace("abc"));
        assertTrue(StringUtils.containsWhitespace("a c"));

        assertEquals(-1, StringUtils.lastIndexOf(null, "a"));
        assertEquals(2, StringUtils.lastIndexOf("aba", "a"));
    }

    @Test
    void testSubstringBoundaries() {
        assertNull(StringUtils.substring(null, 0));
        assertEquals("", StringUtils.substring("", 5));
        assertEquals("abc", StringUtils.substring("abc", 0));
        assertEquals("bc", StringUtils.substring("abc", 1));
        assertEquals("c", StringUtils.substring("abc", -1));
        assertEquals("", StringUtils.substring("abc", 10));

        assertNull(StringUtils.substring(null, 0, 2));
        assertEquals("", StringUtils.substring("abc", 2, 1));
        assertEquals("ab", StringUtils.substring("abc", 0, 2));
        assertEquals("abc", StringUtils.substring("abc", 0, 100));
        assertEquals("c", StringUtils.substring("abc", -1, 100));

        assertNull(StringUtils.substringBefore(null, "a"));
        assertEquals("", StringUtils.substringBefore("", "a"));
        assertEquals("abc", StringUtils.substringBefore("abc", "d"));
        assertEquals("ab", StringUtils.substringBefore("abc", "c"));
        assertEquals("", StringUtils.substringBefore("abc", "a"));

        assertNull(StringUtils.substringAfter(null, "a"));
        assertEquals("", StringUtils.substringAfter("", "a"));
        assertEquals("", StringUtils.substringAfter("abc", "d"));
        assertEquals("bc", StringUtils.substringAfter("abc", "a"));

        assertNull(StringUtils.substringAfterLast(null, "a"));
        assertEquals("", StringUtils.substringAfterLast("abc", "d"));
        assertEquals("c", StringUtils.substringAfterLast("abcbc", "b"));

        assertNull(StringUtils.substringBetween(null, "tag"));
        assertEquals("b", StringUtils.substringBetween("atagbtag", "tag"));
        assertEquals("b", StringUtils.substringBetween("axbz", "x", "z"));
        assertNull(StringUtils.substringBetween("axbz", "x", "y"));
    }

    @Test
    void testLeftRightMidPad() {
        assertNull(StringUtils.left(null, 3));
        assertEquals("", StringUtils.left("abc", -1));
        assertEquals("ab", StringUtils.left("abc", 2));
        assertEquals("abc", StringUtils.left("abc", 100));

        assertNull(StringUtils.right(null, 3));
        assertEquals("", StringUtils.right("abc", -1));
        assertEquals("bc", StringUtils.right("abc", 2));
        assertEquals("abc", StringUtils.right("abc", 100));

        assertNull(StringUtils.mid(null, 0, 2));
        assertEquals("", StringUtils.mid("abc", 0, -1));
        assertEquals("", StringUtils.mid("abc", 10, 2));
        assertEquals("bc", StringUtils.mid("abc", 1, 2));
        assertEquals("ab", StringUtils.mid("abc", -1, 2));

        assertNull(StringUtils.leftPad(null, 3));
        assertEquals("  ab", StringUtils.leftPad("ab", 4));
        assertEquals("ab", StringUtils.leftPad("ab", -1));
        assertEquals("xxab", StringUtils.leftPad("ab", 4, 'x'));
        assertEquals("ab", StringUtils.leftPad("ab", 1, 'x'));

        assertNull(StringUtils.rightPad(null, 3));
        assertEquals("ab  ", StringUtils.rightPad("ab", 4));
        assertEquals("abxx", StringUtils.rightPad("ab", 4, 'x'));

        assertNull(StringUtils.center(null, 4));
        assertEquals("abc", StringUtils.center("abc", 2));
        assertEquals(" ab ", StringUtils.center("ab", 4));
        assertEquals("xabx", StringUtils.center("ab", 4, 'x'));
    }

    @Test
    void testJoinVariants() {
        assertNull(StringUtils.join((Object[]) null, ','));
        assertEquals("", StringUtils.join(new Object[0], ','));
        assertEquals("a,b,c", StringUtils.join(new Object[] {"a", "b", "c"}, ','));
        assertEquals("a,,c", StringUtils.join(new Object[] {"a", null, "c"}, ','));

        assertEquals("a-b-c", StringUtils.join(new Object[] {"a", "b", "c"}, "-"));
        assertNull(StringUtils.join((Object[]) null, "-"));

        assertEquals("1,2,3", StringUtils.join(new int[] {1, 2, 3}, ','));
        assertNull(StringUtils.join((int[]) null, ','));

        assertEquals("abc", StringUtils.join(Arrays.asList("a", "b", "c").iterator(), ""));
        assertEquals("a,b,c", StringUtils.join(Arrays.asList("a", "b", "c").iterator(), ","));
        assertNull(StringUtils.join((java.util.Iterator<?>) null, ","));

        assertEquals("a,b,c", StringUtils.join(Arrays.asList("a", "b", "c"), ','));
        assertEquals("abc", StringUtils.join("a", "b", "c"));
    }

    @Test
    void testJoinEndIndexPastArrayEndIsClamped() {
        assertEquals("a,b", StringUtils.join(new Object[] {"a", "b"}, ',', 0, 5));
    }

    @Test
    void testSplitVariants() {
        assertNull(StringUtils.split(null));
        assertArrayEquals(new String[0], StringUtils.split(""));
        assertArrayEquals(new String[] {"ab", "cd", "ef"}, StringUtils.split("ab cd ef"));
        assertArrayEquals(new String[] {"ab", "cd"}, StringUtils.split("ab  cd"));

        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.split("a.b.c", '.'));
        assertArrayEquals(new String[] {"a", "", "c"}, StringUtils.splitPreserveAllTokens("a..c", '.'));

        assertArrayEquals(new String[] {"a", "b.c"}, StringUtils.split("a.b.c", ".", 2));

        assertNull(StringUtils.splitByWholeSeparator(null, "-"));
        assertArrayEquals(new String[] {"ab", "cd", "ef"}, StringUtils.splitByWholeSeparator("ab-!-cd-!-ef", "-!-"));
        assertArrayEquals(new String[] {"ab", "de", "fg"}, StringUtils.splitByWholeSeparator("ab de fg", null));
    }

    @Test
    void testUpperLowerCaseAndCapitalize() {
        assertNull(StringUtils.upperCase(null));
        assertEquals("ABC", StringUtils.upperCase("abc"));
        assertEquals("ABC", StringUtils.upperCase("abc", Locale.ROOT));

        assertNull(StringUtils.lowerCase(null));
        assertEquals("abc", StringUtils.lowerCase("ABC"));
        assertEquals("abc", StringUtils.lowerCase("ABC", Locale.ROOT));

        assertNull(StringUtils.capitalize(null));
        assertEquals("", StringUtils.capitalize(""));
        assertEquals("Abc", StringUtils.capitalize("abc"));
        assertEquals("ABC", StringUtils.capitalize("ABC"));

        assertNull(StringUtils.uncapitalize(null));
        assertEquals("", StringUtils.uncapitalize(""));
        assertEquals("abc", StringUtils.uncapitalize("Abc"));

        assertNull(StringUtils.swapCase(null));
        assertEquals("", StringUtils.swapCase(""));
        assertEquals("ABcd", StringUtils.swapCase("abCD"));
    }

    @Test
    void testRepeatReverseRemoveReplace() {
        assertNull(StringUtils.repeat(null, 2));
        assertEquals("", StringUtils.repeat("ab", 0));
        assertEquals("", StringUtils.repeat("ab", -1));
        assertEquals("ababab", StringUtils.repeat("ab", 3));
        assertEquals("", StringUtils.repeat('x', 0));
        assertEquals("xxx", StringUtils.repeat('x', 3));

        assertNull(StringUtils.reverse(null));
        assertEquals("", StringUtils.reverse(""));
        assertEquals("cba", StringUtils.reverse("abc"));

        assertNull(StringUtils.remove(null, "a"));
        assertEquals("bc", StringUtils.remove("abc", "a"));
        assertEquals("bc", StringUtils.remove("abc", 'a'));

        assertNull(StringUtils.removeStart(null, "a"));
        assertEquals("bcd", StringUtils.removeStart("abcd", "a"));
        assertEquals("abcd", StringUtils.removeStart("abcd", "x"));

        assertNull(StringUtils.removeEnd(null, "d"));
        assertEquals("abc", StringUtils.removeEnd("abcd", "d"));
        assertEquals("abcd", StringUtils.removeEnd("abcd", "x"));

        assertNull(StringUtils.replace(null, "a", "b"));
        assertEquals("abc", StringUtils.replace("abc", null, "x"));
        assertEquals("xbc", StringUtils.replace("abc", "a", "x"));
        assertEquals("xbx", StringUtils.replace("aba", "a", "x"));
        assertEquals("xba", StringUtils.replace("aba", "a", "x", 1));
    }

    @Test
    void testIsAlphaNumericChecks() {
        assertFalse(StringUtils.isAlpha(null));
        assertFalse(StringUtils.isAlpha(""));
        assertTrue(StringUtils.isAlpha("abc"));
        assertFalse(StringUtils.isAlpha("ab1"));
        assertFalse(StringUtils.isAlpha("ab c"));

        assertFalse(StringUtils.isNumeric(null));
        assertFalse(StringUtils.isNumeric(""));
        assertTrue(StringUtils.isNumeric("123"));
        assertFalse(StringUtils.isNumeric("12.3"));
        assertFalse(StringUtils.isNumeric("-123"));

        assertFalse(StringUtils.isAlphanumeric(null));
        assertTrue(StringUtils.isAlphanumeric("ab12"));
        assertFalse(StringUtils.isAlphanumeric("ab 12"));

        assertFalse(StringUtils.isWhitespace(null));
        assertTrue(StringUtils.isWhitespace(""));
        assertTrue(StringUtils.isWhitespace("  \t"));
        assertFalse(StringUtils.isWhitespace(" a "));

        assertFalse(StringUtils.isAllLowerCase(null));
        assertFalse(StringUtils.isAllLowerCase(""));
        assertTrue(StringUtils.isAllLowerCase("abc"));
        assertFalse(StringUtils.isAllLowerCase("abC"));

        assertFalse(StringUtils.isAllUpperCase(null));
        assertTrue(StringUtils.isAllUpperCase("ABC"));

        assertFalse(StringUtils.isMixedCase(null));
        assertFalse(StringUtils.isMixedCase(""));
        assertFalse(StringUtils.isMixedCase("abc"));
        assertTrue(StringUtils.isMixedCase("aBc"));
    }

    @Test
    void testDefaultIfValues() {
        assertEquals("abc", StringUtils.defaultString("abc"));
        assertEquals("", StringUtils.defaultString(null));
        assertEquals("NULL", StringUtils.defaultString(null, "NULL"));
        assertEquals("abc", StringUtils.defaultString("abc", "NULL"));

        assertEquals("x", StringUtils.defaultIfEmpty("", "x"));
        assertEquals("abc", StringUtils.defaultIfEmpty("abc", "x"));

        assertEquals("x", StringUtils.defaultIfBlank("  ", "x"));
        assertEquals("abc", StringUtils.defaultIfBlank("abc", "x"));
    }

    @Test
    void testAbbreviateBoundaries() {
        assertNull(StringUtils.abbreviate(null, 4));
        assertEquals("", StringUtils.abbreviate("", 4));
        assertEquals("abcd", StringUtils.abbreviate("abcd", 4));
        assertEquals("a...", StringUtils.abbreviate("abcdefg", 4));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                StringUtils.abbreviate("abcdefg", 3);
            }
        });
    }

    @Test
    void testStartsWithEndsWith() {
        assertTrue(StringUtils.startsWith(null, null));
        assertFalse(StringUtils.startsWith(null, "a"));
        assertFalse(StringUtils.startsWith("a", null));
        assertTrue(StringUtils.startsWith("abc", "ab"));
        assertFalse(StringUtils.startsWith("ABC", "ab"));
        assertTrue(StringUtils.startsWithIgnoreCase("ABC", "ab"));

        assertTrue(StringUtils.endsWith(null, null));
        assertTrue(StringUtils.endsWith("abc", "bc"));
        assertFalse(StringUtils.endsWith("ABC", "bc"));
        assertTrue(StringUtils.endsWithIgnoreCase("ABC", "bc"));

        assertFalse(StringUtils.startsWithAny(null, "a"));
        assertTrue(StringUtils.startsWithAny("abc", "x", "ab"));

        assertFalse(StringUtils.endsWithAny(null, "a"));
        assertTrue(StringUtils.endsWithAny("abc", "x", "bc"));
    }

    @Test
    void testCountMatchesAndLength() {
        assertEquals(0, StringUtils.countMatches(null, 'a'));
        assertEquals(0, StringUtils.countMatches("", 'a'));
        assertEquals(4, StringUtils.countMatches("aabaa", 'a'));
        assertEquals(0, StringUtils.countMatches(null, "ab"));
        assertEquals(2, StringUtils.countMatches("abcabc", "abc"));
        assertEquals(0, StringUtils.countMatches("abc", ""));

        assertEquals(0, StringUtils.length(null));
        assertEquals(3, StringUtils.length("abc"));
    }

    @Test
    void testDeleteWhitespaceAndNormalizeSpace() {
        assertNull(StringUtils.deleteWhitespace(null));
        assertEquals("", StringUtils.deleteWhitespace(""));
        assertEquals("abc", StringUtils.deleteWhitespace(" a b\tc\n"));

        assertNull(StringUtils.normalizeSpace(null));
        assertEquals("", StringUtils.normalizeSpace("   "));
        assertEquals("a b c", StringUtils.normalizeSpace("  a   b  c  "));
    }

    @Test
    void testChompAndChop() {
        assertNull(StringUtils.chomp(null));
        assertEquals("", StringUtils.chomp(""));
        assertEquals("abc", StringUtils.chomp("abc\n"));
        assertEquals("abc", StringUtils.chomp("abc\r\n"));
        assertEquals("abc", StringUtils.chomp("abc"));

        assertNull(StringUtils.chop(null));
        assertEquals("", StringUtils.chop(""));
        assertEquals("", StringUtils.chop("a"));
        assertEquals("abc", StringUtils.chop("abcd"));
        assertEquals("abc", StringUtils.chop("abc\r\n"));
    }

    @Test
    void testGetBytesInvalidCharsetThrows() {
        assertThrows(java.io.UnsupportedEncodingException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                StringUtils.getBytes("abc", "not-a-real-charset");
            }
        });
    }

    @Test
    void testToCodePoints() {
        assertNull(StringUtils.toCodePoints(null));
        assertArrayEquals(new int[0], StringUtils.toCodePoints(""));
        assertArrayEquals(new int[] {'a', 'b'}, StringUtils.toCodePoints("ab"));
    }

    @Test
    void testTruncate() {
        assertNull(StringUtils.truncate(null, 3));
        assertEquals("", StringUtils.truncate("", 3));
        assertEquals("abc", StringUtils.truncate("abcdef", 3));
        assertEquals("abcdef", StringUtils.truncate("abcdef", 10));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                StringUtils.truncate("abcdef", -1);
            }
        });
    }

    @Test
    void testGetLevenshteinDistance() {
        assertEquals(0, StringUtils.getLevenshteinDistance("", ""));
        assertEquals(3, StringUtils.getLevenshteinDistance("", "abc"));
        assertEquals(1, StringUtils.getLevenshteinDistance("abc", "abd"));
        assertEquals(0, StringUtils.getLevenshteinDistance("frog", "frog"));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                StringUtils.getLevenshteinDistance(null, "abc");
            }
        });
    }

}
