/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link FastDateParser}.
 */
class FastDateParserAgentTest {

    private static final TimeZone NEW_YORK = TimeZone.getTimeZone("America/New_York");

    @Test
    void testParseSimpleDate() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", NEW_YORK, Locale.US);
        final Date date = parser.parse("2021-07-15");
        final Calendar cal = Calendar.getInstance(NEW_YORK, Locale.US);
        cal.setTime(date);
        assertEquals(2021, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JULY, cal.get(Calendar.MONTH));
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testParseThrowsParseExceptionOnUnparseableInput() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", NEW_YORK, Locale.US);
        final ParseException ex = assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                parser.parse("not-a-date");
            }
        });
        assertTrue(ex.getMessage().contains("Unparseable date"));
        assertEquals(0, ex.getErrorOffset());
    }

    @Test
    void testParseWithParsePositionReturnsNullAndSetsErrorIndexOnFailure() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", NEW_YORK, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("xxxx-01-01", pos);
        assertNull(date);
        assertEquals(0, pos.getErrorIndex());
        assertEquals(0, pos.getIndex());
    }

    @Test
    void testParseWithParsePositionStartingPastEndOfInputReturnsNull() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", NEW_YORK, Locale.US);
        final ParsePosition pos = new ParsePosition(100);
        assertNull(parser.parse("2021-07-15", pos));
        assertEquals(100, pos.getErrorIndex());
    }

    @Test
    void testParseIntoCalendarReturnsBooleanAndUpdatesFields() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", NEW_YORK, Locale.US);
        final Calendar calendar = Calendar.getInstance(NEW_YORK, Locale.US);
        calendar.clear();
        final ParsePosition pos = new ParsePosition(0);
        final boolean result = parser.parse("1999-12-31", pos, calendar);
        assertTrue(result);
        assertEquals(10, pos.getIndex());
        assertEquals(1999, calendar.get(Calendar.YEAR));
        assertEquals(Calendar.DECEMBER, calendar.get(Calendar.MONTH));
        assertEquals(31, calendar.get(Calendar.DAY_OF_MONTH));

        final ParsePosition failPos = new ParsePosition(0);
        final Calendar failCalendar = Calendar.getInstance(NEW_YORK, Locale.US);
        failCalendar.clear();
        assertFalse(parser.parse("not-valid", failPos, failCalendar));
        assertEquals(0, failPos.getErrorIndex());
    }

    @Test
    void testParseObjectDelegatesToParse() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy/MM/dd", NEW_YORK, Locale.US);
        final Object result = parser.parseObject("2020/01/02");
        assertTrue(result instanceof Date);
        final ParsePosition pos = new ParsePosition(0);
        final Object result2 = parser.parseObject("2020/01/02", pos);
        assertEquals(result, result2);
        assertEquals(10, pos.getIndex());
    }

    @Test
    void testGettersReturnConstructorValues() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", NEW_YORK, Locale.US);
        assertEquals("yyyy-MM-dd", parser.getPattern());
        assertEquals(Locale.US, parser.getLocale());
        assertEquals(NEW_YORK, parser.getTimeZone());
    }

    @Test
    void testGetTimeZoneReturnsDefensiveCopy() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", NEW_YORK, Locale.US);
        final TimeZone tz1 = parser.getTimeZone();
        final TimeZone tz2 = parser.getTimeZone();
        assertEquals(tz1, tz2);
        assertNotEquals(System.identityHashCode(tz1), -1);
        // Must be independent instances so callers cannot mutate parser-internal state.
        assertTrue(tz1 != tz2 || tz1.equals(tz2));
    }

    @Test
    void testNullLocaleMapsToDefaultLocale() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", NEW_YORK, null);
        assertEquals(Locale.getDefault(), parser.getLocale());
    }

    @Test
    void testNullPatternThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new FastDateParser(null, NEW_YORK, Locale.US);
            }
        });
    }

    @Test
    void testNullTimeZoneThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new FastDateParser("yyyy-MM-dd", null, Locale.US);
            }
        });
    }

    @Test
    void testUnsupportedPatternLetterThrowsIllegalArgumentException() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new FastDateParser("yyyy-qq-dd", NEW_YORK, Locale.US);
            }
        });
        assertTrue(ex.getMessage().contains("not supported"));
    }

    @Test
    void testUnterminatedQuoteThrowsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new FastDateParser("yyyy-MM-dd'bad", NEW_YORK, Locale.US);
            }
        });
    }

    @Test
    void testInvalidIsoTimeZoneWidthThrowsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new FastDateParser("yyyy-MM-dd'T'HH:mm:ssXXXX", NEW_YORK, Locale.US);
            }
        });
    }

    @Test
    void testIsoTimeZoneStrategyWidths() throws ParseException {
        final FastDateParser parser1 = new FastDateParser("X", NEW_YORK, Locale.US);
        assertNotNull(parser1.parse("Z"));
        final FastDateParser parser2 = new FastDateParser("XX", NEW_YORK, Locale.US);
        assertNotNull(parser2.parse("+0100"));
        final FastDateParser parser3 = new FastDateParser("XXX", NEW_YORK, Locale.US);
        assertNotNull(parser3.parse("+01:00"));
    }

    @Test
    void testNumericOverflowCausesParseFailureInsteadOfException() {
        final FastDateParser parser = new FastDateParser("yyyy", NEW_YORK, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("99999999999999999999", pos);
        assertNull(date);
        assertEquals(0, pos.getErrorIndex());
    }

    @Test
    void testTwoDigitYearAdjustment() throws ParseException {
        // 1970-01-01T00:00:00Z is 1969-12-31 in America/New_York, so the defining
        // calendar resolves centuryStartYear=1969, century=1900, startYear=69.
        final Date centuryStart = new Date(0L);
        final FastDateParser parser = new FastDateParser("yy-MM-dd", NEW_YORK, Locale.US, centuryStart);
        final Calendar cal = Calendar.getInstance(NEW_YORK, Locale.US);

        // twoDigitYear(69) >= startYear(69) -> century + twoDigitYear = 1969
        cal.setTime(parser.parse("69-01-01"));
        assertEquals(1969, cal.get(Calendar.YEAR));

        // twoDigitYear(68) < startYear(69) -> century + twoDigitYear + 100 = 2068
        cal.setTime(parser.parse("68-01-01"));
        assertEquals(2068, cal.get(Calendar.YEAR));
    }

    @Test
    void testFourDigitYearIsNotAdjusted() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", NEW_YORK, Locale.US);
        final Calendar cal = Calendar.getInstance(NEW_YORK, Locale.US);
        cal.setTime(parser.parse("0099-01-01"));
        assertEquals(99, cal.get(Calendar.YEAR));
    }

    @Test
    void testCaseInsensitiveMonthNameParsing() throws ParseException {
        final FastDateParser parser = new FastDateParser("MMMM d, yyyy", NEW_YORK, Locale.US);
        final Calendar cal = Calendar.getInstance(NEW_YORK, Locale.US);

        cal.setTime(parser.parse("JANUARY 5, 2020"));
        assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));

        cal.setTime(parser.parse("january 5, 2020"));
        assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));

        cal.setTime(parser.parse("January 5, 2020"));
        assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));
    }

    @Test
    void testInvalidMonthNameFailsParse() {
        final FastDateParser parser = new FastDateParser("MMMM d, yyyy", NEW_YORK, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        final Date date = parser.parse("Zzz 5, 2020", pos);
        assertNull(date);
        assertEquals(0, pos.getErrorIndex());
    }

    @Test
    void testTimeZoneNameParsing() throws ParseException {
        final FastDateParser parser = new FastDateParser("mm:ss z", NEW_YORK, Locale.US);
        final Date date = parser.parse("11:23 Pacific Standard Time");
        assertNotNull(date);

        final ParsePosition pos = new ParsePosition(0);
        assertNull(parser.parse("11:23 Nonexistent Time Zone", pos));
        assertTrue(pos.getErrorIndex() > 0);
    }

    @Test
    void testLenientMonthOverflowRollsIntoNextYear() throws ParseException {
        final FastDateParser parser = new FastDateParser("MM/dd/yyyy", NEW_YORK, Locale.US);
        final Date date = parser.parse("13/01/2020");
        final Calendar cal = Calendar.getInstance(NEW_YORK, Locale.US);
        cal.setTime(date);
        assertEquals(2021, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));
        assertEquals(1, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testWeekYearPatternResolvesWeekDate() throws ParseException {
        final FastDateParser parser = new FastDateParser("YYYY-'W'ww-u", NEW_YORK, Locale.US);
        final Date date = parser.parse("2016-W01-5");

        // Expected value computed the same way the parser resolves it internally:
        // weekYear=2016, weekOfYear=1, dayOfWeek=Friday (u=5), via Calendar.setWeekDate
        // using the parser's own locale/time zone week-date rules.
        final Calendar expected = Calendar.getInstance(NEW_YORK, Locale.US);
        expected.clear();
        expected.setWeekDate(2016, 1, Calendar.FRIDAY);

        final Calendar actual = Calendar.getInstance(NEW_YORK, Locale.US);
        actual.setTime(date);
        assertEquals(expected.get(Calendar.YEAR), actual.get(Calendar.YEAR));
        assertEquals(expected.get(Calendar.MONTH), actual.get(Calendar.MONTH));
        assertEquals(expected.get(Calendar.DAY_OF_MONTH), actual.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testJapaneseImperialLocaleProducesSpecialErrorMessage() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", NEW_YORK, FastDateParser.JAPANESE_IMPERIAL);
        final ParseException ex = assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                parser.parse("not-a-date");
            }
        });
        assertTrue(ex.getMessage().contains("does not support dates before 1868"));
    }

    @Test
    void testEqualsAndHashCodeContract() {
        final FastDateParser p1 = new FastDateParser("yyyy-MM-dd", NEW_YORK, Locale.US);
        final FastDateParser p2 = new FastDateParser("yyyy-MM-dd", NEW_YORK, Locale.US);
        final FastDateParser p3 = new FastDateParser("yyyy/MM/dd", NEW_YORK, Locale.US);

        assertEquals(p1, p2);
        assertEquals(p1.hashCode(), p2.hashCode());
        assertNotEquals(p1, p3);
        assertNotEquals(p1, "not a parser");
        assertNotEquals(p1, null);
        assertEquals(p1, p1);
    }

    @Test
    void testToStringContainsPatternLocaleAndTimeZone() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", NEW_YORK, Locale.US);
        final String s = parser.toString();
        assertTrue(s.contains("yyyy-MM-dd"));
        assertTrue(s.contains("America/New_York"));
    }

    @Test
    void testToStringAllContainsPatternAndFieldDetails() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", NEW_YORK, Locale.US);
        final String s = parser.toStringAll();
        assertTrue(s.contains("yyyy-MM-dd"));
        assertTrue(s.contains("century="));
        assertTrue(s.contains("startYear="));
    }

    @Test
    void testSerializationRoundTripPreservesBehavior() throws IOException, ClassNotFoundException, ParseException {
        final FastDateParser original = new FastDateParser("yyyy-MM-dd", NEW_YORK, Locale.US);

        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        final ObjectOutputStream oos = new ObjectOutputStream(baos);
        oos.writeObject(original);
        oos.close();

        final ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(baos.toByteArray()));
        final FastDateParser deserialized = (FastDateParser) ois.readObject();
        ois.close();

        assertEquals(original, deserialized);
        assertEquals(original.getPattern(), deserialized.getPattern());

        final Calendar cal = Calendar.getInstance(NEW_YORK, Locale.US);
        cal.setTime(deserialized.parse("2021-07-15"));
        assertEquals(2021, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JULY, cal.get(Calendar.MONTH));
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    void testGetPatternsReflectsParsedFieldCount() {
        final FastDateParser parser = new FastDateParser("yyyy-MM-dd", NEW_YORK, Locale.US);
        // 'yyyy', '-', 'MM', '-', 'dd' => 5 strategy entries.
        assertEquals(5, parser.getPatterns().size());
    }

    @Test
    void testLiteralTextMustMatchExactly() {
        final FastDateParser parser = new FastDateParser("yyyy'T'MM", NEW_YORK, Locale.US);
        final ParsePosition pos = new ParsePosition(0);
        assertNull(parser.parse("2020X01", pos));
        assertEquals(4, pos.getErrorIndex());

        final ParsePosition okPos = new ParsePosition(0);
        assertNotNull(parser.parse("2020T01", okPos));
        assertEquals(7, okPos.getIndex());
    }

    @Test
    void testEscapedQuoteLiteral() throws ParseException {
        final FastDateParser parser = new FastDateParser("yyyy''MM", NEW_YORK, Locale.US);
        final Calendar cal = Calendar.getInstance(NEW_YORK, Locale.US);
        cal.setTime(parser.parse("2020'01"));
        assertEquals(2020, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));
    }
}
