/*
  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      https://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
 */
package org.apache.commons.cli.help;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class TextStyleAgentTest {

    @Test
    void testUnsetMaxWidthIsIntegerMaxValue() {
        assertEquals(Integer.MAX_VALUE, TextStyle.UNSET_MAX_WIDTH);
    }

    @Test
    void testBuilderDefaults() {
        final TextStyle.Builder builder = TextStyle.builder();
        assertEquals(TextStyle.Alignment.LEFT, builder.get().getAlignment());
        assertEquals(0, builder.getLeftPad());
        assertEquals(0, builder.getIndent());
        assertTrue(builder.isScalable());
        assertEquals(0, builder.getMinWidth());
        assertEquals(TextStyle.UNSET_MAX_WIDTH, builder.getMaxWidth());
    }

    @Test
    void testDefaultConstantMatchesBuilderDefaults() {
        final TextStyle defaultStyle = TextStyle.DEFAULT;
        assertEquals(TextStyle.Alignment.LEFT, defaultStyle.getAlignment());
        assertEquals(0, defaultStyle.getLeftPad());
        assertEquals(0, defaultStyle.getIndent());
        assertTrue(defaultStyle.isScalable());
        assertEquals(0, defaultStyle.getMinWidth());
        assertEquals(TextStyle.UNSET_MAX_WIDTH, defaultStyle.getMaxWidth());
    }

    @Test
    void testBuilderSettersAreFluentAndUpdateState() {
        final TextStyle.Builder builder = TextStyle.builder();
        assertSame(builder, builder.setAlignment(TextStyle.Alignment.RIGHT));
        assertSame(builder, builder.setLeftPad(3));
        assertSame(builder, builder.setIndent(2));
        assertSame(builder, builder.setScalable(false));
        assertSame(builder, builder.setMinWidth(5));
        assertSame(builder, builder.setMaxWidth(20));

        assertEquals(3, builder.getLeftPad());
        assertEquals(2, builder.getIndent());
        assertFalse(builder.isScalable());
        assertEquals(5, builder.getMinWidth());
        assertEquals(20, builder.getMaxWidth());

        final TextStyle style = builder.get();
        assertEquals(TextStyle.Alignment.RIGHT, style.getAlignment());
        assertEquals(3, style.getLeftPad());
        assertEquals(2, style.getIndent());
        assertFalse(style.isScalable());
        assertEquals(5, style.getMinWidth());
        assertEquals(20, style.getMaxWidth());
    }

    @Test
    void testBuilderSetTextStyleCopiesAllFields() {
        final TextStyle source = TextStyle.builder().setAlignment(TextStyle.Alignment.CENTER).setLeftPad(7).setIndent(4).setScalable(false).setMinWidth(1)
                .setMaxWidth(99).get();

        final TextStyle.Builder target = TextStyle.builder();
        assertSame(target, target.setTextStyle(source));

        assertEquals(TextStyle.Alignment.CENTER, target.get().getAlignment());
        assertEquals(7, target.getLeftPad());
        assertEquals(4, target.getIndent());
        assertFalse(target.isScalable());
        assertEquals(1, target.getMinWidth());
        assertEquals(99, target.getMaxWidth());
    }

    @Test
    void testBuilderIsReusableAfterGet() {
        final TextStyle.Builder builder = TextStyle.builder().setLeftPad(1);
        final TextStyle first = builder.get();
        builder.setLeftPad(9);
        final TextStyle second = builder.get();
        assertEquals(1, first.getLeftPad());
        assertEquals(9, second.getLeftPad());
    }

    @Test
    void testPadReturnsOriginalWhenTextLengthEqualsMaxWidth() {
        final TextStyle style = TextStyle.builder().setMaxWidth(4).get();
        final CharSequence text = "abcd";
        assertSame(text, style.pad(false, text));
    }

    @Test
    void testPadReturnsOriginalWhenTextLongerThanMaxWidth() {
        final TextStyle style = TextStyle.builder().setMaxWidth(2).get();
        final CharSequence text = "abcdef";
        assertSame(text, style.pad(true, text));
    }

    @Test
    void testPadLeftAlignmentUnsetMaxWidthNoIndent() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.LEFT).setIndent(5).get();
        assertEquals("ab", style.pad(false, "ab").toString());
    }

    @Test
    void testPadLeftAlignmentUnsetMaxWidthWithIndent() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.LEFT).setIndent(3).get();
        assertEquals("   ab", style.pad(true, "ab").toString());
    }

    @Test
    void testPadRightAlignmentUnsetMaxWidthWithIndent() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.RIGHT).setIndent(3).get();
        assertEquals("   ab", style.pad(true, "ab").toString());
        assertEquals("ab", style.pad(false, "ab").toString());
    }

    @Test
    void testPadLeftAlignmentWithMaxWidthIndentFitsInRemainder() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.LEFT).setMaxWidth(5).setIndent(1).get();
        final String padded = style.pad(true, "ab").toString();
        assertEquals(" ab  ", padded);
        assertEquals(5, padded.length());
    }

    @Test
    void testPadLeftAlignmentWithMaxWidthIndentExceedsRemainder() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.LEFT).setMaxWidth(5).setIndent(10).get();
        final String padded = style.pad(true, "ab").toString();
        assertEquals("ab   ", padded);
        assertEquals(5, padded.length());
    }

    @Test
    void testPadLeftAlignmentWithMaxWidthNoIndentRequested() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.LEFT).setMaxWidth(5).setIndent(2).get();
        final String padded = style.pad(false, "ab").toString();
        assertEquals("ab   ", padded);
        assertEquals(5, padded.length());
    }

    @Test
    void testPadRightAlignmentWithMaxWidthIndentFitsInRemainder() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.RIGHT).setMaxWidth(5).setIndent(1).get();
        final String padded = style.pad(true, "ab").toString();
        assertEquals("   ab", padded);
        assertEquals(5, padded.length());
    }

    @Test
    void testPadRightAlignmentWithMaxWidthIndentExceedsRemainder() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.RIGHT).setMaxWidth(5).setIndent(10).get();
        final String padded = style.pad(true, "ab").toString();
        assertEquals("   ab", padded);
        assertEquals(5, padded.length());
    }

    @Test
    void testPadCenterAlignmentUnsetMaxWidthNoIndent() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.CENTER).setIndent(5).get();
        assertEquals("ab", style.pad(false, "ab").toString());
    }

    @Test
    void testPadCenterAlignmentUnsetMaxWidthWithIndentEvenSplit() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.CENTER).setIndent(4).get();
        final String padded = style.pad(true, "ab").toString();
        assertEquals("  ab  ", padded);
        assertEquals(6, padded.length());
    }

    @Test
    void testPadCenterAlignmentUnsetMaxWidthWithIndentOddSplit() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.CENTER).setIndent(5).get();
        final String padded = style.pad(true, "ab").toString();
        assertEquals("  ab   ", padded);
        assertEquals(7, padded.length());
    }

    @Test
    void testPadCenterAlignmentWithMaxWidthEvenSplit() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.CENTER).setMaxWidth(6).get();
        final String padded = style.pad(true, "ab").toString();
        assertEquals("  ab  ", padded);
        assertEquals(6, padded.length());
    }

    @Test
    void testPadCenterAlignmentWithMaxWidthOddSplit() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.CENTER).setMaxWidth(7).get();
        final String padded = style.pad(true, "ab").toString();
        assertEquals("  ab   ", padded);
        assertEquals(7, padded.length());
    }

    @Test
    void testPadEmptyText() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.LEFT).setMaxWidth(3).get();
        final String padded = style.pad(false, "").toString();
        assertEquals("   ", padded);
        assertEquals(3, padded.length());
    }

    @Test
    void testToStringUnsetMaxWidth() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.LEFT).setLeftPad(1).setIndent(2).setScalable(true).setMinWidth(3).get();
        assertEquals("TextStyle{LEFT, l:1, i:2, true, min:3, max:unset}", style.toString());
    }

    @Test
    void testToStringSetMaxWidth() {
        final TextStyle style = TextStyle.builder().setAlignment(TextStyle.Alignment.RIGHT).setLeftPad(0).setIndent(0).setScalable(false).setMinWidth(0)
                .setMaxWidth(42).get();
        assertEquals("TextStyle{RIGHT, l:0, i:0, false, min:0, max:42}", style.toString());
    }

    @Test
    void testAlignmentEnumValues() {
        final TextStyle.Alignment[] values = TextStyle.Alignment.values();
        assertEquals(3, values.length);
        assertEquals(TextStyle.Alignment.LEFT, TextStyle.Alignment.valueOf("LEFT"));
        assertEquals(TextStyle.Alignment.CENTER, TextStyle.Alignment.valueOf("CENTER"));
        assertEquals(TextStyle.Alignment.RIGHT, TextStyle.Alignment.valueOf("RIGHT"));
    }
}
