/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Calendar;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link DurationFormatUtils}.
 */
class DurationFormatUtilsAgentTest {

    @Test
    void testFormatDurationZero() {
        assertEquals("0", DurationFormatUtils.formatDuration(0, "d"));
        assertEquals("000", DurationFormatUtils.formatDuration(0, "ddd"));
    }

    @Test
    void testFormatDurationBasic() {
        final long millis = ((1L * 60 + 2) * 60 + 3) * 1000 + 4;
        assertEquals("01:02:03.004", DurationFormatUtils.formatDuration(millis, "HH:mm:ss.SSS"));
    }

    @Test
    void testFormatDurationDaysHoursMinutesSeconds() {
        final long oneDay = 24L * 60 * 60 * 1000;
        assertEquals("1", DurationFormatUtils.formatDuration(oneDay, "d"));
        assertEquals("1 day 0 hours 0 minutes 0 seconds",
                DurationFormatUtils.formatDurationWords(oneDay, false, false));
    }

    @Test
    void testFormatDurationNoPadding() {
        assertEquals("1:2:3", DurationFormatUtils.formatDuration(3723000L, "H:m:s", false));
        assertEquals("01:02:03", DurationFormatUtils.formatDuration(3723000L, "HH:mm:ss", true));
    }

    @Test
    void testFormatDurationNegativeThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatDuration(-1, "HH:mm:ss");
            }
        });
        assertTrue(ex.getMessage().contains("durationMillis"));
    }

    @Test
    void testFormatDurationHMS() {
        assertEquals("00:00:00.000", DurationFormatUtils.formatDurationHMS(0));
        assertEquals("01:01:01.001", DurationFormatUtils.formatDurationHMS(3661001L));
    }

    @Test
    void testFormatDurationHMSMillisecondsPaddedToThreeDigits() {
        // Milliseconds following seconds must always use at least 3 digits even without padding requested elsewhere.
        assertEquals("00:00:00.005", DurationFormatUtils.formatDuration(5L, "HH:mm:ss.S"));
    }

    @Test
    void testFormatDurationISO() {
        assertEquals("P0Y0M0DT0H0M0.000S", DurationFormatUtils.formatDurationISO(0));
        assertEquals("P0Y0M1DT2H3M4.005S",
                DurationFormatUtils.formatDurationISO(((((1L * 24 + 2) * 60 + 3) * 60 + 4) * 1000) + 5));
    }

    @Test
    void testFormatDurationWordsPlurals() {
        assertEquals("1 day 1 hour 1 minute 1 second",
                DurationFormatUtils.formatDurationWords(((24L * 60 + 60 + 1) * 60 + 1) * 1000 + 0 + 0, false, false));
    }

    @Test
    void testFormatDurationWordsSuppressLeadingZeroElements() {
        // 5 seconds only: suppressing leading zero elements should drop "0 days 0 hours 0 minutes"
        final String result = DurationFormatUtils.formatDurationWords(5000L, true, false);
        assertEquals("5 seconds", result);
    }

    @Test
    void testFormatDurationWordsSuppressTrailingZeroElements() {
        // exactly 1 day, suppressing trailing zero elements should drop "0 hours 0 minutes 0 seconds"
        final long oneDay = 24L * 60 * 60 * 1000;
        final String result = DurationFormatUtils.formatDurationWords(oneDay, false, true);
        assertEquals("1 day", result);
    }

    @Test
    void testFormatDurationWordsSuppressBothAllZero() {
        // Leading suppression collapses "0 days 0 hours 0 minutes" but trailing suppression
        // no longer finds a match once the leading space has already been consumed.
        final String result = DurationFormatUtils.formatDurationWords(0L, true, true);
        assertEquals("0 seconds", result);
    }

    @Test
    void testFormatPeriodBasic() {
        final TimeZone utc = TimeZone.getTimeZone("GMT");
        final Calendar start = Calendar.getInstance(utc);
        start.clear();
        start.set(2000, Calendar.JANUARY, 1, 0, 0, 0);
        final Calendar end = Calendar.getInstance(utc);
        end.clear();
        end.set(2000, Calendar.JANUARY, 2, 1, 2, 3);
        final String result = DurationFormatUtils.formatPeriod(start.getTimeInMillis(), end.getTimeInMillis(),
                "d'd' H'h' m'm' s's'", true, utc);
        assertEquals("1d 1h 2m 3s", result);
    }

    @Test
    void testFormatPeriodWithYearsAndMonths() {
        final TimeZone utc = TimeZone.getTimeZone("GMT");
        final Calendar start = Calendar.getInstance(utc);
        start.clear();
        start.set(2000, Calendar.JANUARY, 15, 0, 0, 0);
        final Calendar end = Calendar.getInstance(utc);
        end.clear();
        end.set(2001, Calendar.MARCH, 10, 0, 0, 0);
        final String result = DurationFormatUtils.formatPeriod(start.getTimeInMillis(), end.getTimeInMillis(),
                "y'y' M'M' d'd'", true, utc);
        assertEquals("1y 1M 26d", result);
    }

    @Test
    void testFormatPeriodSameInstant() {
        final TimeZone utc = TimeZone.getTimeZone("GMT");
        final long now = 123456789L;
        assertEquals("00:00:00", DurationFormatUtils.formatPeriod(now, now, "HH:mm:ss", true, utc));
    }

    @Test
    void testFormatPeriodStartAfterEndThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.formatPeriod(1000L, 0L, "HH:mm:ss");
            }
        });
    }

    @Test
    void testFormatPeriodISO() {
        final long start = 0L;
        final long oneDayMillis = 24L * 60 * 60 * 1000;
        final String result = DurationFormatUtils.formatPeriodISO(start, start + oneDayMillis);
        assertTrue(result.startsWith("P"));
        assertTrue(result.contains("D"));
    }

    @Test
    void testFormatOptionalBlockAllZeroProducesEmptyLiteral() {
        assertEquals("", DurationFormatUtils.formatDuration(0L, "[dHms]", true));
    }

    @Test
    void testFormatOptionalBlockNonZero() {
        assertEquals("1", DurationFormatUtils.formatDuration(24L * 60 * 60 * 1000, "[dHms]", true));
    }

    @Test
    void testFormatOptionalBlockWithLeadingLiteral() {
        final long oneDay = 24L * 60 * 60 * 1000;
        final long withDay = oneDay + 2L * 3600000 + 3L * 60000;
        assertEquals("{01}02:03", DurationFormatUtils.formatDuration(withDay, "['{'dd'}']HH':'mm", true));
        // days is zero, so the whole optional block (including its literal braces) is suppressed
        assertEquals("00:00", DurationFormatUtils.formatDuration(0L, "['{'dd'}']HH':'mm", true));
    }

    @Test
    void testLiteralEscapedQuote() {
        // '' inside a literal represents a single literal apostrophe
        assertEquals("1'", DurationFormatUtils.formatDuration(24L * 60 * 60 * 1000, "d''", true));
    }

    @Test
    void testLexxNestedOptionalThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.lexx("[d[H]]");
            }
        });
        assertTrue(ex.getMessage().contains("Nested optional"));
    }

    @Test
    void testLexxUnopenedOptionalThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.lexx("d]");
            }
        });
        assertTrue(ex.getMessage().contains("unopened optional"));
    }

    @Test
    void testLexxUnmatchedQuoteThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.lexx("d'text");
            }
        });
        assertTrue(ex.getMessage().contains("Unmatched quote"));
    }

    @Test
    void testLexxUnmatchedOptionalThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                DurationFormatUtils.lexx("[d");
            }
        });
        assertTrue(ex.getMessage().contains("Unmatched optional"));
    }

    @Test
    void testLexxTokenRepeatCountsCollapseConsecutiveChars() {
        final DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("yyyyMMdd");
        assertEquals(3, tokens.length);
        assertEquals(4, tokens[0].getCount());
        assertEquals(2, tokens[1].getCount());
        assertEquals(2, tokens[2].getCount());
    }

    @Test
    void testIsoExtendedFormatPatternConstant() {
        assertEquals("'P'yyyy'Y'M'M'd'DT'H'H'm'M's.SSS'S'", DurationFormatUtils.ISO_EXTENDED_FORMAT_PATTERN);
    }

    @Test
    void testDeprecatedPublicConstructor() {
        assertTrue(new DurationFormatUtils() instanceof DurationFormatUtils);
    }
}
