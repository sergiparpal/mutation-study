/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text.translate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link NumericEntityUnescaper}.
 */
@Deprecated
class NumericEntityUnescaperAgentTest {

    @Test
    void testDefaultOptionIsSemiColonRequired() {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        assertTrue(unescaper.isSet(NumericEntityUnescaper.OPTION.semiColonRequired));
        assertFalse(unescaper.isSet(NumericEntityUnescaper.OPTION.semiColonOptional));
        assertFalse(unescaper.isSet(NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
    }

    @Test
    void testIsSetWithExplicitOptions() {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.semiColonOptional);
        assertTrue(unescaper.isSet(NumericEntityUnescaper.OPTION.semiColonOptional));
        assertFalse(unescaper.isSet(NumericEntityUnescaper.OPTION.semiColonRequired));
        assertFalse(unescaper.isSet(NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
    }

    @Test
    void testDecimalWithSemiColon() {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        assertEquals("A", unescaper.translate("&#65;"));
    }

    @Test
    void testHexWithSemiColonLowerX() {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        assertEquals("A", unescaper.translate("&#x41;"));
    }

    @Test
    void testHexWithSemiColonUpperX() {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        assertEquals("A", unescaper.translate("&#X41;"));
    }

    @Test
    void testDefaultRequiresSemiColonSoMissingSemiColonIsIgnored() {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        assertEquals("&#65", unescaper.translate("&#65"));
    }

    @Test
    void testSemiColonOptionalWithSemiColon() {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.semiColonOptional);
        assertEquals("A", unescaper.translate("&#65;"));
    }

    @Test
    void testSemiColonOptionalWithoutSemiColon() {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.semiColonOptional);
        assertEquals("A", unescaper.translate("&#65"));
    }

    @Test
    void testErrorIfNoSemiColonThrowsWhenMissing() {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.errorIfNoSemiColon);
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                unescaper.translate("&#65");
            }
        });
    }

    @Test
    void testErrorIfNoSemiColonDoesNotThrowWhenPresent() {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.errorIfNoSemiColon);
        assertEquals("A", unescaper.translate("&#65;"));
    }

    @Test
    void testTrailingTextAfterEntityIsPreserved() {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        assertEquals("A and B", unescaper.translate("&#65; and &#66;"));
    }

    @Test
    void testNonEntityTextIsUnchanged() {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        assertEquals("plain text", unescaper.translate("plain text"));
    }

    @Test
    void testSupplementaryCodePoint() {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        final String result = unescaper.translate("&#x1D400;");
        assertEquals(2, result.length());
        assertEquals(0x1D400, result.codePointAt(0));
    }

    @Test
    void testOutOfRangeCodePointIsIgnored() throws IOException {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        final StringWriter out = new StringWriter();
        final String input = "&#x110000;";
        final int consumed = unescaper.translate(input, 0, out);
        assertEquals(0, consumed);
        assertEquals("", out.toString());
    }

    @Test
    void testInvalidNumberFormatIsIgnored() throws IOException {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.semiColonOptional);
        final StringWriter out = new StringWriter();
        final String input = "&#;";
        final int consumed = unescaper.translate(input, 0, out);
        assertEquals(0, consumed);
        assertEquals("", out.toString());
    }

    @Test
    void testHexMarkerWithNothingAfterIsIgnored() throws IOException {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        final StringWriter out = new StringWriter();
        final String input = "&#x";
        final int consumed = unescaper.translate(input, 0, out);
        assertEquals(0, consumed);
        assertEquals("", out.toString());
    }

    @Test
    void testNotAnEntityAtAllReturnsZero() throws IOException {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        final StringWriter out = new StringWriter();
        final int consumed = unescaper.translate("abc", 0, out);
        assertEquals(0, consumed);
        assertEquals("", out.toString());
    }

    @Test
    void testTooShortToBeEntityReturnsZero() throws IOException {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        final StringWriter out = new StringWriter();
        final int consumed = unescaper.translate("&#", 0, out);
        assertEquals(0, consumed);
        assertEquals("", out.toString());
    }

    @Test
    void testTranslateAtNonZeroIndex() throws IOException {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        final StringWriter out = new StringWriter();
        final String input = "x&#65;y";
        final int consumed = unescaper.translate(input, 1, out);
        assertEquals(5, consumed);
        assertEquals("A", out.toString());
    }

    @Test
    void testReturnedConsumedLengthDecimalWithSemiColon() throws IOException {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        final StringWriter out = new StringWriter();
        final String input = "&#65;";
        final int consumed = unescaper.translate(input, 0, out);
        assertEquals(input.length(), consumed);
        assertEquals("A", out.toString());
    }

    @Test
    void testReturnedConsumedLengthHexWithSemiColon() throws IOException {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        final StringWriter out = new StringWriter();
        final String input = "&#x41;";
        final int consumed = unescaper.translate(input, 0, out);
        assertEquals(input.length(), consumed);
        assertEquals("A", out.toString());
    }

    @Test
    void testIOExceptionFromWriterPropagates() {
        final NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
        final Writer throwingWriter = new Writer() {
            @Override
            public void write(final char[] cbuf, final int off, final int len) throws IOException {
                throw new IOException("boom");
            }

            @Override
            public void flush() throws IOException {
                // no-op
            }

            @Override
            public void close() throws IOException {
                // no-op
            }
        };
        assertThrows(IOException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                unescaper.translate("&#65;", 0, throwingWriter);
            }
        });
    }
}
