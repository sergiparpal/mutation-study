/*
  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      https://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
 */

package org.apache.commons.cli;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.io.FileInputStream;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.URL;
import java.nio.file.Path;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.junit.jupiter.api.Test;

class TypeHandlerAgentTest {

    /** Public no-arg constructor fixture used by createObject()/createValue(String, Object.class). */
    public static class Fixture {
        public Fixture() {
            // no-arg constructor required for reflective instantiation
        }
    }

    @Test
    void testCreateClassValid() throws Exception {
        final Class<?> clazz = TypeHandler.createClass("java.lang.String");
        assertEquals(String.class, clazz);
    }

    @Test
    void testCreateClassInvalid() {
        final ParseException e = assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                TypeHandler.createClass("does.not.Exist");
            }
        });
        assertTrue(e.getCause() instanceof ClassNotFoundException);
    }

    @Test
    void testCreateDateValid() {
        final String pattern = "EEE MMM dd HH:mm:ss zzz yyyy";
        final Date now = new Date(0);
        final String formatted = new SimpleDateFormat(pattern, Locale.ENGLISH).format(now);
        final Date parsed = TypeHandler.createDate(formatted);
        assertNotNull(parsed);
        assertEquals(formatted, new SimpleDateFormat(pattern, Locale.ENGLISH).format(parsed));
    }

    @Test
    void testCreateDateInvalid() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                TypeHandler.createDate("not a date");
            }
        });
    }

    @Test
    void testCreateDefaultMapContainsExpectedEntries() {
        final Map<Class<?>, Converter<?, ? extends Throwable>> map = TypeHandler.createDefaultMap();
        assertTrue(map.containsKey(Object.class));
        assertTrue(map.containsKey(Class.class));
        assertTrue(map.containsKey(Date.class));
        assertTrue(map.containsKey(File.class));
        assertTrue(map.containsKey(Path.class));
        assertTrue(map.containsKey(Number.class));
        assertTrue(map.containsKey(URL.class));
        assertTrue(map.containsKey(FileInputStream.class));
        assertTrue(map.containsKey(Long.class));
        assertTrue(map.containsKey(Integer.class));
        assertTrue(map.containsKey(Short.class));
        assertTrue(map.containsKey(Byte.class));
        assertTrue(map.containsKey(Character.class));
        assertTrue(map.containsKey(Double.class));
        assertTrue(map.containsKey(Float.class));
        assertTrue(map.containsKey(BigInteger.class));
        assertTrue(map.containsKey(BigDecimal.class));
        assertEquals(17, map.size());
    }

    @Test
    void testCreateDefaultMapIsMutableAndIndependent() {
        final Map<Class<?>, Converter<?, ? extends Throwable>> map1 = TypeHandler.createDefaultMap();
        map1.remove(Object.class);
        final Map<Class<?>, Converter<?, ? extends Throwable>> map2 = TypeHandler.createDefaultMap();
        assertFalse(map1.containsKey(Object.class));
        assertTrue(map2.containsKey(Object.class));
    }

    @Test
    void testCreateFile() {
        final File file = TypeHandler.createFile("some-file.txt");
        assertNotNull(file);
        assertEquals("some-file.txt", file.getName());
    }

    @Test
    void testCreateFilesAlwaysThrows() {
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                TypeHandler.createFiles("a,b,c");
            }
        });
    }

    @Test
    void testCreateNumberLong() throws Exception {
        final Number n = TypeHandler.createNumber("42");
        assertEquals(Long.valueOf(42L), n);
    }

    @Test
    void testCreateNumberDouble() throws Exception {
        final Number n = TypeHandler.createNumber("42.5");
        assertEquals(Double.valueOf(42.5), n);
    }

    @Test
    void testCreateNumberInvalid() {
        final ParseException e = assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                TypeHandler.createNumber("not-a-number");
            }
        });
        assertTrue(e.getCause() instanceof NumberFormatException);
    }

    @Test
    void testCreateObjectValid() throws Exception {
        final Object obj = TypeHandler.createObject(Fixture.class.getName());
        assertNotNull(obj);
        assertTrue(obj instanceof Fixture);
    }

    @Test
    void testCreateObjectInvalidClassName() {
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                TypeHandler.createObject("does.not.Exist");
            }
        });
    }

    @Test
    void testCreateURLValid() throws Exception {
        final URL url = TypeHandler.createURL("https://example.com/path");
        assertNotNull(url);
        assertEquals("https://example.com/path", url.toString());
    }

    @Test
    void testCreateURLInvalid() {
        final ParseException e = assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                TypeHandler.createURL("not a url");
            }
        });
        assertNotNull(e.getCause());
    }

    @Test
    void testCreateValueByClass() throws Exception {
        final Integer value = TypeHandler.createValue("123", Integer.class);
        assertEquals(Integer.valueOf(123), value);
    }

    @Test
    void testCreateValueByClassInvalid() {
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                TypeHandler.createValue("abc", Integer.class);
            }
        });
    }

    @Test
    void testCreateValueUnregisteredClassUsesDefaultIdentityConverter() throws Exception {
        final Object value = TypeHandler.createValue("raw-string", (Class<?>) Fixture.class);
        assertEquals("raw-string", value);
    }

    @Test
    @SuppressWarnings("deprecation")
    void testCreateValueByObject() throws Exception {
        final Object value = TypeHandler.createValue("77", (Object) Long.class);
        assertEquals(Long.valueOf(77L), value);
    }

    @Test
    void testCreateValueCharacterPlain() throws Exception {
        final Character c = TypeHandler.createValue("A", Character.class);
        assertEquals(Character.valueOf('A'), c);
    }

    @Test
    void testCreateValueCharacterHexEscape() throws Exception {
        final Character c = TypeHandler.createValue("\\u0041", Character.class);
        assertEquals(Character.valueOf('A'), c);
    }

    @Test
    void testCreateValueBigIntegerAndBigDecimal() throws Exception {
        final BigInteger bi = TypeHandler.createValue("123456789012345678901234567890", BigInteger.class);
        assertEquals(new BigInteger("123456789012345678901234567890"), bi);
        final BigDecimal bd = TypeHandler.createValue("3.14159", BigDecimal.class);
        assertEquals(new BigDecimal("3.14159"), bd);
    }

    @Test
    void testCreateValueFileInputStreamValid() throws Exception {
        final File temp = File.createTempFile("TypeHandlerAgentTest", ".tmp");
        temp.deleteOnExit();
        FileInputStream fis = null;
        try {
            fis = TypeHandler.createValue(temp.getAbsolutePath(), FileInputStream.class);
            assertNotNull(fis);
        } finally {
            if (fis != null) {
                fis.close();
            }
            temp.delete();
        }
    }

    @Test
    void testCreateValueFileInputStreamMissingFile() {
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                TypeHandler.createValue("/no/such/file/at/all.tmp", FileInputStream.class);
            }
        });
    }

    @Test
    @SuppressWarnings("deprecation")
    void testOpenFileValid() throws Exception {
        final File temp = File.createTempFile("TypeHandlerAgentTest", ".tmp");
        temp.deleteOnExit();
        FileInputStream fis = null;
        try {
            fis = TypeHandler.openFile(temp.getAbsolutePath());
            assertNotNull(fis);
        } finally {
            if (fis != null) {
                fis.close();
            }
            temp.delete();
        }
    }

    @Test
    @SuppressWarnings("deprecation")
    void testOpenFileMissing() {
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                TypeHandler.openFile("/no/such/file/at/all.tmp");
            }
        });
    }

    @Test
    void testGetDefaultReturnsSingleton() {
        final TypeHandler first = TypeHandler.getDefault();
        final TypeHandler second = TypeHandler.getDefault();
        assertSame(first, second);
    }

    @Test
    void testDefaultConstructorHasStandardConverters() throws Exception {
        final TypeHandler handler = new TypeHandler();
        final Converter<Long, ?> converter = handler.getConverter(Long.class);
        assertNotNull(converter);
        assertEquals(Long.valueOf(5L), converter.apply("5"));
    }

    @Test
    void testCustomMapConstructorUsesSuppliedMap() throws Exception {
        final Map<Class<?>, Converter<?, ? extends Throwable>> map = new HashMap<Class<?>, Converter<?, ? extends Throwable>>();
        final Converter<String, RuntimeException> upperCaseConverter = new Converter<String, RuntimeException>() {
            @Override
            public String apply(final String string) {
                return string.toUpperCase(Locale.ROOT);
            }
        };
        map.put(String.class, upperCaseConverter);
        final TypeHandler handler = new TypeHandler(map);
        final Converter<String, ?> converter = handler.getConverter(String.class);
        assertEquals("HELLO", converter.apply("hello"));
    }

    @Test
    void testConstructorRejectsNullMap() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                new TypeHandler(null);
            }
        });
    }

    @Test
    void testGetConverterFallsBackToDefaultForUnregisteredClass() throws Exception {
        final TypeHandler handler = new TypeHandler(new HashMap<Class<?>, Converter<?, ? extends Throwable>>());
        final Converter<Fixture, ?> converter = handler.getConverter(Fixture.class);
        assertSame(Converter.DEFAULT, converter);
        assertEquals("unchanged", converter.apply("unchanged"));
    }

    @Test
    void testGetConverterReturnsRegisteredConverterForKnownClass() {
        final TypeHandler handler = TypeHandler.getDefault();
        final Converter<URL, ?> converter = handler.getConverter(URL.class);
        assertSame(Converter.URL, converter);
    }

    @Test
    void testCreateDateReturnsNullIsNotTheCase() {
        // createDate never returns null for a parseable string; this documents the actual contract.
        final String pattern = "EEE MMM dd HH:mm:ss zzz yyyy";
        final String formatted = new SimpleDateFormat(pattern, Locale.ENGLISH).format(new Date(1000000L));
        assertNotNull(TypeHandler.createDate(formatted));
    }
}
