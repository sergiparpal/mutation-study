/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.builder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link RecursiveToStringStyle}.
 */
class RecursiveToStringStyleAgentTest {

    static class Inner {
        String label;

        Inner(final String label) {
            this.label = label;
        }
    }

    static class Outer {
        Inner inner;
        int number;

        Outer(final Inner inner, final int number) {
            this.inner = inner;
            this.number = number;
        }
    }

    /** A subclass that excludes a given class from recursion, to test {@code accept()}. */
    static class ExcludingRecursiveToStringStyle extends RecursiveToStringStyle {
        private static final long serialVersionUID = 1L;
        private final Class<?> excluded;

        ExcludingRecursiveToStringStyle(final Class<?> excluded) {
            this.excluded = excluded;
        }

        @Override
        protected boolean accept(final Class<?> clazz) {
            return !excluded.equals(clazz);
        }
    }

    private String getClassPrefix(final Object object) {
        return object.getClass().getName() + "@" + Integer.toHexString(System.identityHashCode(object));
    }

    @Test
    void testAcceptDefaultsToTrueForAnyClass() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        // accept() is protected; exercise it indirectly via appendDetail recursion.
        final Inner inner = new Inner("x");
        final StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "inner", inner);
        // Recursed: contains the nested class name/hash prefix, not merely Object#toString().
        assertTrue(buffer.toString().startsWith(getClassPrefix(inner)));
        assertTrue(buffer.toString().contains("label=x"));
    }

    @Test
    void testAppendDetailWithNullValueThrowsNullPointerException() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                style.appendDetail(buffer, "field", (Object) null);
            }
        });
    }

    @Test
    void testAppendDetailWithIntegerUsesSimpleValueNotRecursion() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "field", Integer.valueOf(42));
        assertEquals("42", buffer.toString());
    }

    @Test
    void testAppendDetailWithBooleanWrapperUsesSimpleValue() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "field", Boolean.TRUE);
        assertEquals("true", buffer.toString());
    }

    @Test
    void testAppendDetailWithStringUsesSimpleValueNotRecursion() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "field", "hello");
        assertEquals("hello", buffer.toString());
    }

    @Test
    void testAppendDetailWithCustomObjectRecursesUsingReflectionToStringBuilder() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        final Inner inner = new Inner("value1");
        final StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "field", inner);
        final String expected = getClassPrefix(inner) + "[label=value1]";
        assertEquals(expected, buffer.toString());
    }

    @Test
    void testAppendDetailWithCollectionRecursesIntoEachElement() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        final List<Inner> list = new ArrayList<Inner>();
        list.add(new Inner("a"));
        list.add(new Inner("b"));
        final StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "field", (java.util.Collection<?>) list);
        final String result = buffer.toString();
        // Starts with the list's own class name/identity hash code prefix.
        assertTrue(result.startsWith(getClassPrefix(list)));
        // Each element is recursively expanded, not just Object#toString().
        assertTrue(result.contains(getClassPrefix(list.get(0)) + "[label=a]"));
        assertTrue(result.contains(getClassPrefix(list.get(1)) + "[label=b]"));
    }

    @Test
    void testAppendDetailWithEmptyCollectionProducesEmptyArray() {
        final RecursiveToStringStyle style = new RecursiveToStringStyle();
        final List<Inner> list = new ArrayList<Inner>();
        final StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "field", (java.util.Collection<?>) list);
        final String expected = getClassPrefix(list) + "{}";
        assertEquals(expected, buffer.toString());
    }

    @Test
    void testFullToStringWithNestedObjectViaReflectionToStringBuilder() {
        final Inner inner = new Inner("deep");
        final Outer outer = new Outer(inner, 7);
        final String result = new ReflectionToStringBuilder(outer, new RecursiveToStringStyle()).toString();
        final String expected = getClassPrefix(outer) + "[inner=" + getClassPrefix(inner) + "[label=deep],number=7]";
        assertEquals(expected, result);
    }

    @Test
    void testFullToStringWithNullFieldDoesNotRecurse() {
        final Outer outer = new Outer(null, 3);
        final String result = new ReflectionToStringBuilder(outer, new RecursiveToStringStyle()).toString();
        final String expected = getClassPrefix(outer) + "[inner=<null>,number=3]";
        assertEquals(expected, result);
    }

    @Test
    void testAcceptOverrideExcludesSpecificClassFromRecursion() {
        final Inner inner = new Inner("excluded");
        final RecursiveToStringStyle excludingStyle = new ExcludingRecursiveToStringStyle(Inner.class);
        final StringBuffer buffer = new StringBuffer();
        excludingStyle.appendDetail(buffer, "field", inner);
        // Falls back to super.appendDetail(), i.e. plain Object#toString(), not reflective expansion.
        assertEquals(inner.toString(), buffer.toString());
        assertFalse(buffer.toString().contains("label=excluded"));
    }

    @Test
    void testAcceptOverrideStillRecursesForNonExcludedClass() {
        final Outer outer = new Outer(new Inner("kept"), 1);
        final RecursiveToStringStyle excludingStyle = new ExcludingRecursiveToStringStyle(String.class);
        final StringBuffer buffer = new StringBuffer();
        excludingStyle.appendDetail(buffer, "field", outer);
        assertTrue(buffer.toString().contains("label=kept"));
    }

    @Test
    void testIsSerializable() {
        assertTrue(java.io.Serializable.class.isInstance(new RecursiveToStringStyle()));
    }
}
