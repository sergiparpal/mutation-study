/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.BitSet;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link ArrayUtils}.
 */
public class ArrayUtilsAgentTest {

    // ---------------------------------------------------------------
    // constants
    // ---------------------------------------------------------------

    @Test
    public void testEmptyConstants() {
        assertEquals(0, ArrayUtils.EMPTY_OBJECT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_STRING_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_INT_ARRAY.length);
        assertEquals(0, ArrayUtils.EMPTY_BOOLEAN_ARRAY.length);
        assertEquals(-1, ArrayUtils.INDEX_NOT_FOUND);
    }

    // ---------------------------------------------------------------
    // isEmpty / isNotEmpty
    // ---------------------------------------------------------------

    @Test
    public void testIsEmptyObjectArray() {
        assertTrue(ArrayUtils.isEmpty((Object[]) null));
        assertTrue(ArrayUtils.isEmpty(new Object[0]));
        assertFalse(ArrayUtils.isEmpty(new Object[] {"a"}));
    }

    @Test
    public void testIsNotEmptyObjectArray() {
        assertFalse(ArrayUtils.isNotEmpty((Object[]) null));
        assertFalse(ArrayUtils.isNotEmpty(new Object[0]));
        assertTrue(ArrayUtils.isNotEmpty(new Object[] {"a"}));
    }

    @Test
    public void testIsEmptyPrimitiveArrays() {
        assertTrue(ArrayUtils.isEmpty((int[]) null));
        assertTrue(ArrayUtils.isEmpty(new int[0]));
        assertFalse(ArrayUtils.isEmpty(new int[] {1}));

        assertTrue(ArrayUtils.isEmpty((boolean[]) null));
        assertTrue(ArrayUtils.isEmpty(new boolean[0]));
        assertFalse(ArrayUtils.isEmpty(new boolean[] {true}));

        assertTrue(ArrayUtils.isEmpty((double[]) null));
        assertFalse(ArrayUtils.isEmpty(new double[] {1.0}));
    }

    // ---------------------------------------------------------------
    // getLength / getDimensions / getComponentType
    // ---------------------------------------------------------------

    @Test
    public void testGetLength() {
        assertEquals(0, ArrayUtils.getLength(null));
        assertEquals(0, ArrayUtils.getLength(new Object[0]));
        assertEquals(3, ArrayUtils.getLength(new int[] {1, 2, 3}));
        assertEquals(1, ArrayUtils.getLength(new Object[] {null}));
    }

    @Test
    public void testGetLengthNotAnArrayThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                ArrayUtils.getLength("not an array");
            }
        });
    }

    @Test
    public void testGetDimensions() {
        assertEquals(0, ArrayUtils.getDimensions(null));
        assertEquals(1, ArrayUtils.getDimensions(new int[] {1}));
        assertEquals(2, ArrayUtils.getDimensions(new int[2][2]));
        assertEquals(3, ArrayUtils.getDimensions(new int[1][1][1]));
    }

    @Test
    public void testGetComponentType() {
        final String[] array = new String[0];
        assertSame(String.class, ArrayUtils.getComponentType(array));
        assertNull(ArrayUtils.getComponentType(null));
    }

    // ---------------------------------------------------------------
    // isArrayIndexValid / get
    // ---------------------------------------------------------------

    @Test
    public void testIsArrayIndexValid() {
        assertFalse(ArrayUtils.isArrayIndexValid(null, 0));
        assertFalse(ArrayUtils.isArrayIndexValid(new String[0], 0));
        assertTrue(ArrayUtils.isArrayIndexValid(new String[] {"a"}, 0));
        assertFalse(ArrayUtils.isArrayIndexValid(new String[] {"a"}, 1));
        assertFalse(ArrayUtils.isArrayIndexValid(new String[] {"a"}, -1));
    }

    @Test
    public void testGet() {
        final String[] array = {"a", "b", "c"};
        assertEquals("b", ArrayUtils.get(array, 1));
        assertNull(ArrayUtils.get(array, 5));
        assertNull(ArrayUtils.get((String[]) null, 0));
        assertEquals("default", ArrayUtils.get(array, 10, "default"));
        assertEquals("a", ArrayUtils.get(array, 0, "default"));
    }

    // ---------------------------------------------------------------
    // add
    // ---------------------------------------------------------------

    @Test
    public void testAddElementToNullArray() {
        final int[] result = ArrayUtils.add((int[]) null, 42);
        assertArrayEquals(new int[] {42}, result);
    }

    @Test
    public void testAddElementAppends() {
        final int[] result = ArrayUtils.add(new int[] {1, 2}, 3);
        assertArrayEquals(new int[] {1, 2, 3}, result);
    }

    @Test
    public void testAddGenericArray() {
        final String[] base = {"a", "b"};
        final String[] result = ArrayUtils.add(base, "c");
        assertArrayEquals(new String[] {"a", "b", "c"}, result);
        assertEquals(2, base.length);
    }

    @Test
    public void testAddAtIndex() {
        final int[] result = ArrayUtils.add(new int[] {1, 3}, 1, 2);
        assertArrayEquals(new int[] {1, 2, 3}, result);
    }

    @Test
    public void testAddAtIndexOutOfBoundsThrows() {
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                ArrayUtils.add(new int[] {1, 2}, 5, 3);
            }
        });
    }

    @Test
    public void testAddAtIndexNegativeThrows() {
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                ArrayUtils.add(new int[] {1, 2}, -1, 3);
            }
        });
    }

    // ---------------------------------------------------------------
    // addAll / addFirst
    // ---------------------------------------------------------------

    @Test
    public void testAddAllIntArrays() {
        final int[] result = ArrayUtils.addAll(new int[] {1, 2}, 3, 4);
        assertArrayEquals(new int[] {1, 2, 3, 4}, result);
    }

    @Test
    public void testAddAllNullFirstArray() {
        final int[] result = ArrayUtils.addAll((int[]) null, 1, 2);
        assertArrayEquals(new int[] {1, 2}, result);
    }

    @Test
    public void testAddAllBothNullReturnsNull() {
        assertNull(ArrayUtils.addAll((Object[]) null, (Object[]) null));
    }

    @Test
    public void testAddFirst() {
        final int[] result = ArrayUtils.addFirst(new int[] {2, 3}, 1);
        assertArrayEquals(new int[] {1, 2, 3}, result);
    }

    @Test
    public void testAddFirstToNullArray() {
        final int[] result = ArrayUtils.addFirst((int[]) null, 9);
        assertArrayEquals(new int[] {9}, result);
    }

    // ---------------------------------------------------------------
    // clone
    // ---------------------------------------------------------------

    @Test
    public void testCloneNull() {
        assertNull(ArrayUtils.clone((int[]) null));
        assertNull(ArrayUtils.clone((Object[]) null));
    }

    @Test
    public void testCloneCreatesEqualButDistinctArray() {
        final int[] original = {1, 2, 3};
        final int[] cloned = ArrayUtils.clone(original);
        assertArrayEquals(original, cloned);
        assertNotSame(original, cloned);
    }

    @Test
    public void testCloneObjectArray() {
        final String[] original = {"a", "b"};
        final String[] cloned = ArrayUtils.clone(original);
        assertArrayEquals(original, cloned);
        assertNotSame(original, cloned);
    }

    // ---------------------------------------------------------------
    // concat
    // ---------------------------------------------------------------

    @Test
    public void testConcatIntArrays() {
        final int[] result = ArrayUtils.concat(new int[] {1, 2}, new int[] {3}, new int[] {4, 5});
        assertArrayEquals(new int[] {1, 2, 3, 4, 5}, result);
    }

    @Test
    public void testConcatNoArgsReturnsEmpty() {
        final int[] result = ArrayUtils.concat(new int[0][]);
        assertArrayEquals(new int[0], result);
    }

    // ---------------------------------------------------------------
    // contains / containsAny
    // ---------------------------------------------------------------

    @Test
    public void testContainsIntArray() {
        final int[] array = {1, 2, 3};
        assertTrue(ArrayUtils.contains(array, 2));
        assertFalse(ArrayUtils.contains(array, 5));
        assertFalse(ArrayUtils.contains((int[]) null, 1));
    }

    @Test
    public void testContainsObjectArrayWithNull() {
        final Object[] array = {"a", null, "b"};
        assertTrue(ArrayUtils.contains(array, null));
        assertTrue(ArrayUtils.contains(array, "b"));
        assertFalse(ArrayUtils.contains(array, "z"));
    }

    @Test
    public void testContainsDoubleWithTolerance() {
        final double[] array = {1.0, 2.0, 3.0};
        assertTrue(ArrayUtils.contains(array, 2.05, 0.1));
        assertFalse(ArrayUtils.contains(array, 2.5, 0.1));
    }

    @Test
    public void testContainsAny() {
        final Object[] array = {"a", "b", "c"};
        assertTrue(ArrayUtils.containsAny(array, "x", "b"));
        assertFalse(ArrayUtils.containsAny(array, "x", "y"));
        assertFalse(ArrayUtils.containsAny((Object[]) null, "a"));
    }

    // ---------------------------------------------------------------
    // indexOf / lastIndexOf / indexesOf
    // ---------------------------------------------------------------

    @Test
    public void testIndexOf() {
        final int[] array = {1, 2, 3, 2};
        assertEquals(1, ArrayUtils.indexOf(array, 2));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf(array, 9));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf((int[]) null, 1));
        assertEquals(3, ArrayUtils.indexOf(array, 2, 2));
    }

    @Test
    public void testLastIndexOf() {
        final int[] array = {1, 2, 3, 2};
        assertEquals(3, ArrayUtils.lastIndexOf(array, 2));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.lastIndexOf(array, 9));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.lastIndexOf((int[]) null, 1));
    }

    @Test
    public void testIndexesOf() {
        final int[] array = {1, 2, 1, 3, 1};
        final BitSet bits = ArrayUtils.indexesOf(array, 1);
        assertEquals(3, bits.cardinality());
        assertTrue(bits.get(0));
        assertTrue(bits.get(2));
        assertTrue(bits.get(4));
        assertFalse(bits.get(1));

        final BitSet emptyForNull = ArrayUtils.indexesOf((int[]) null, 1);
        assertTrue(emptyForNull.isEmpty());
    }

    // ---------------------------------------------------------------
    // insert
    // ---------------------------------------------------------------

    @Test
    public void testInsertNullArrayReturnsNull() {
        assertNull(ArrayUtils.insert(0, (int[]) null, 1, 2));
    }

    @Test
    public void testInsertAtIndex() {
        final int[] result = ArrayUtils.insert(1, new int[] {1, 4}, 2, 3);
        assertArrayEquals(new int[] {1, 2, 3, 4}, result);
    }

    @Test
    public void testInsertOutOfBoundsThrows() {
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                ArrayUtils.insert(5, new int[] {1, 2}, 9);
            }
        });
    }

    // ---------------------------------------------------------------
    // isSameLength / isSameType
    // ---------------------------------------------------------------

    @Test
    public void testIsSameLength() {
        assertTrue(ArrayUtils.isSameLength(new int[] {1, 2}, new int[] {3, 4}));
        assertFalse(ArrayUtils.isSameLength(new int[] {1, 2}, new int[] {3}));
        assertTrue(ArrayUtils.isSameLength((int[]) null, (int[]) null));
        assertFalse(ArrayUtils.isSameLength(new int[] {1}, (int[]) null));
    }

    @Test
    public void testIsSameType() {
        assertTrue(ArrayUtils.isSameType(new int[0], new int[0]));
        assertFalse(ArrayUtils.isSameType(new int[0], new long[0]));
    }

    @Test
    public void testIsSameTypeNullThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            public void execute() {
                ArrayUtils.isSameType(null, new int[0]);
            }
        });
    }

    // ---------------------------------------------------------------
    // isSorted
    // ---------------------------------------------------------------

    @Test
    public void testIsSorted() {
        assertTrue(ArrayUtils.isSorted(new int[] {1, 2, 3}));
        assertFalse(ArrayUtils.isSorted(new int[] {3, 1, 2}));
        assertTrue(ArrayUtils.isSorted(new int[0]));
        assertTrue(ArrayUtils.isSorted((int[]) null));
    }

    // ---------------------------------------------------------------
    // isEquals (deprecated) / hashCode
    // ---------------------------------------------------------------

    @Test
    public void testIsEqualsDeprecated() {
        assertTrue(ArrayUtils.isEquals(new int[] {1, 2}, new int[] {1, 2}));
        assertFalse(ArrayUtils.isEquals(new int[] {1, 2}, new int[] {1, 3}));
        assertTrue(ArrayUtils.isEquals(null, null));
    }

    @Test
    public void testHashCode() {
        assertEquals(ArrayUtils.hashCode(null), ArrayUtils.hashCode(null));
        assertEquals(ArrayUtils.hashCode(new int[] {1, 2, 3}), ArrayUtils.hashCode(new int[] {1, 2, 3}));
        assertTrue(ArrayUtils.hashCode(new int[] {1, 2, 3}) != ArrayUtils.hashCode(new int[] {3, 2, 1}));
    }

    // ---------------------------------------------------------------
    // nullToEmpty
    // ---------------------------------------------------------------

    @Test
    public void testNullToEmptyIntArray() {
        final int[] result = ArrayUtils.nullToEmpty((int[]) null);
        assertArrayEquals(new int[0], result);
        final int[] array = {1, 2};
        assertSame(array, ArrayUtils.nullToEmpty(array));
    }

    @Test
    public void testNullToEmptyObjectArray() {
        assertSame(ArrayUtils.EMPTY_OBJECT_ARRAY, ArrayUtils.nullToEmpty((Object[]) null));
    }

    // ---------------------------------------------------------------
    // remove
    // ---------------------------------------------------------------

    @Test
    public void testRemoveByIndex() {
        final int[] result = ArrayUtils.remove(new int[] {1, 0, 1}, 1);
        assertArrayEquals(new int[] {1, 1}, result);
    }

    @Test
    public void testRemoveNegativeIndexThrows() {
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                ArrayUtils.remove(new int[] {1, 2}, -1);
            }
        });
    }

    @Test
    public void testRemoveIndexTooLargeThrows() {
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                ArrayUtils.remove(new int[] {1, 2}, 2);
            }
        });
    }

    @Test
    public void testRemoveFromNullArrayThrows() {
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            public void execute() {
                ArrayUtils.remove((int[]) null, 0);
            }
        });
    }

    @Test
    public void testRemoveGenericArray() {
        final String[] result = ArrayUtils.remove(new String[] {"a", "b", "c"}, 1);
        assertArrayEquals(new String[] {"a", "c"}, result);
    }

    // ---------------------------------------------------------------
    // removeElement / removeAllOccurrences
    // ---------------------------------------------------------------

    @Test
    public void testRemoveElement() {
        final int[] result = ArrayUtils.removeElement(new int[] {1, 2, 3, 2}, 2);
        assertArrayEquals(new int[] {1, 3, 2}, result);
    }

    @Test
    public void testRemoveElementNotFoundReturnsCopy() {
        final int[] original = {1, 2, 3};
        final int[] result = ArrayUtils.removeElement(original, 9);
        assertArrayEquals(original, result);
        assertNotSame(original, result);
    }

    @Test
    public void testRemoveAllOccurrences() {
        final int[] result = ArrayUtils.removeAllOccurrences(new int[] {1, 2, 1, 3, 1}, 1);
        assertArrayEquals(new int[] {2, 3}, result);
    }

    // ---------------------------------------------------------------
    // reverse
    // ---------------------------------------------------------------

    @Test
    public void testReverseFullArray() {
        final int[] array = {1, 2, 3, 4};
        ArrayUtils.reverse(array);
        assertArrayEquals(new int[] {4, 3, 2, 1}, array);
    }

    @Test
    public void testReverseNullArrayNoOp() {
        ArrayUtils.reverse((int[]) null);
    }

    @Test
    public void testReverseRange() {
        final int[] array = {1, 2, 3, 4, 5};
        ArrayUtils.reverse(array, 1, 4);
        assertArrayEquals(new int[] {1, 4, 3, 2, 5}, array);
    }

    @Test
    public void testReverseRangeOutOfBoundsClips() {
        final int[] array = {1, 2, 3};
        ArrayUtils.reverse(array, -5, 100);
        assertArrayEquals(new int[] {3, 2, 1}, array);
    }

    // ---------------------------------------------------------------
    // shift
    // ---------------------------------------------------------------

    @Test
    public void testShift() {
        final int[] array = {1, 2, 3, 4, 5};
        ArrayUtils.shift(array, 2);
        assertArrayEquals(new int[] {4, 5, 1, 2, 3}, array);
    }

    @Test
    public void testShiftNullNoOp() {
        ArrayUtils.shift((int[]) null, 1);
    }

    @Test
    public void testShiftOffsetLargerThanLengthWrapsModulo() {
        final int[] array = {1, 2, 3};
        ArrayUtils.shift(array, 4);
        assertArrayEquals(new int[] {3, 1, 2}, array);
    }

    // ---------------------------------------------------------------
    // subarray
    // ---------------------------------------------------------------

    @Test
    public void testSubarray() {
        final int[] array = {1, 2, 3, 4, 5};
        assertArrayEquals(new int[] {2, 3, 4}, ArrayUtils.subarray(array, 1, 4));
    }

    @Test
    public void testSubarrayNullReturnsNull() {
        assertNull(ArrayUtils.subarray((int[]) null, 0, 1));
    }

    @Test
    public void testSubarrayNegativeStartPromotedToZero() {
        final int[] array = {1, 2, 3};
        assertArrayEquals(new int[] {1, 2}, ArrayUtils.subarray(array, -2, 2));
    }

    @Test
    public void testSubarrayEndBeyondLengthDemoted() {
        final int[] array = {1, 2, 3};
        assertArrayEquals(new int[] {2, 3}, ArrayUtils.subarray(array, 1, 100));
    }

    @Test
    public void testSubarrayEndBeforeStartReturnsEmpty() {
        final int[] array = {1, 2, 3};
        assertArrayEquals(new int[0], ArrayUtils.subarray(array, 2, 1));
    }

    // ---------------------------------------------------------------
    // swap
    // ---------------------------------------------------------------

    @Test
    public void testSwap() {
        final int[] array = {1, 2, 3, 4};
        ArrayUtils.swap(array, 0, 2);
        assertArrayEquals(new int[] {3, 2, 1, 4}, array);
    }

    @Test
    public void testSwapNegativeIndexPromotedToZero() {
        final int[] array = {1, 2, 3, 4};
        ArrayUtils.swap(array, -3, 2, 2);
        assertArrayEquals(new int[] {3, 4, 1, 2}, array);
    }

    @Test
    public void testSwapOutOfBoundsIsNoOp() {
        final int[] array = {1, 2, 3};
        ArrayUtils.swap(array, 0, 5);
        assertArrayEquals(new int[] {1, 2, 3}, array);
    }

    @Test
    public void testSwapNullArrayNoOp() {
        ArrayUtils.swap((int[]) null, 0, 1);
    }

    // ---------------------------------------------------------------
    // toArray / toObject / toPrimitive
    // ---------------------------------------------------------------

    @Test
    public void testToArray() {
        final String[] result = ArrayUtils.toArray("a", "b");
        assertArrayEquals(new String[] {"a", "b"}, result);
    }

    @Test
    public void testToObjectIntArray() {
        final Integer[] result = ArrayUtils.toObject(new int[] {1, 2, 3});
        assertArrayEquals(new Integer[] {1, 2, 3}, result);
    }

    @Test
    public void testToObjectEmptyIntArray() {
        assertArrayEquals(new Integer[0], ArrayUtils.toObject(new int[0]));
    }

    @Test
    public void testToPrimitiveIntegerArray() {
        final int[] result = ArrayUtils.toPrimitive(new Integer[] {1, 2, 3});
        assertArrayEquals(new int[] {1, 2, 3}, result);
    }

    @Test
    public void testToPrimitiveNullElementThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            public void execute() {
                ArrayUtils.toPrimitive(new Integer[] {1, null});
            }
        });
    }

    @Test
    public void testToPrimitiveWithValueForNull() {
        final int[] result = ArrayUtils.toPrimitive(new Integer[] {1, null, 3}, -1);
        assertArrayEquals(new int[] {1, -1, 3}, result);
    }

    @Test
    public void testToPrimitiveNullArrayReturnsNull() {
        assertNull(ArrayUtils.toPrimitive((Integer[]) null));
    }

    @Test
    public void testToPrimitiveObjectDispatch() {
        final Object result = ArrayUtils.toPrimitive((Object) new Integer[] {1, 2});
        assertTrue(result instanceof int[]);
        assertArrayEquals(new int[] {1, 2}, (int[]) result);
    }

    @Test
    public void testToPrimitiveObjectNullReturnsNull() {
        assertNull(ArrayUtils.toPrimitive((Object) null));
    }

    // ---------------------------------------------------------------
    // toString / toStringArray
    // ---------------------------------------------------------------

    @Test
    public void testToString() {
        assertEquals("{}", ArrayUtils.toString(new Object[0]));
        assertEquals("{}", ArrayUtils.toString(null));
        assertEquals("fallback", ArrayUtils.toString(null, "fallback"));
        assertEquals("{1,2}", ArrayUtils.toString(new int[] {1, 2}));
    }

    @Test
    public void testToStringArray() {
        final String[] result = ArrayUtils.toStringArray(new Object[] {1, "b", null});
        assertEquals("1", result[0]);
        assertEquals("b", result[1]);
        assertEquals("null", result[2]);
    }

    @Test
    public void testToStringArrayWithNullReplacement() {
        final String[] result = ArrayUtils.toStringArray(new Object[] {null, "b"}, "N/A");
        assertEquals("N/A", result[0]);
        assertEquals("b", result[1]);
    }

    // ---------------------------------------------------------------
    // startsWith
    // ---------------------------------------------------------------

    @Test
    public void testStartsWith() {
        assertTrue(ArrayUtils.startsWith(new byte[] {1, 2, 3}, new byte[] {1, 2}));
        assertFalse(ArrayUtils.startsWith(new byte[] {1, 2, 3}, new byte[] {2, 3}));
        assertTrue(ArrayUtils.startsWith(new byte[] {1, 2}, new byte[0]));
        assertFalse(ArrayUtils.startsWith(new byte[] {1}, new byte[] {1, 2}));
    }

    // ---------------------------------------------------------------
    // setAll
    // ---------------------------------------------------------------

    @Test
    public void testSetAllWithSupplier() {
        final String[] array = new String[3];
        ArrayUtils.setAll(array, new java.util.function.Supplier<String>() {
            public String get() {
                return "x";
            }
        });
        assertArrayEquals(new String[] {"x", "x", "x"}, array);
    }

    @Test
    public void testSetAllWithIntFunction() {
        final Integer[] array = new Integer[4];
        ArrayUtils.setAll(array, new java.util.function.IntFunction<Integer>() {
            public Integer apply(int i) {
                return i * i;
            }
        });
        assertArrayEquals(new Integer[] {0, 1, 4, 9}, array);
    }

    // ---------------------------------------------------------------
    // newInstance
    // ---------------------------------------------------------------

    @Test
    public void testNewInstance() {
        final String[] result = ArrayUtils.newInstance(String.class, 3);
        assertEquals(3, result.length);
        assertSame(String[].class, result.getClass());
    }
}
