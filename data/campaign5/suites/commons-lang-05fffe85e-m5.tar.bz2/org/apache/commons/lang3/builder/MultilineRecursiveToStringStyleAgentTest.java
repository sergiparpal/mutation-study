/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.builder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link MultilineRecursiveToStringStyle}.
 */
class MultilineRecursiveToStringStyleAgentTest {

    static class Job {
        String title;
    }

    static class Person {
        String name;
        int age;
        boolean smoker;
        Job job;
        int[] nums;
    }

    private static final String LS = System.lineSeparator();

    private final Integer base = Integer.valueOf(5);

    private final String baseStr = base.getClass().getName() + "@" + Integer.toHexString(System.identityHashCode(base));

    @Test
    void testBlank() {
        final String result = new ToStringBuilder(base, new MultilineRecursiveToStringStyle()).toString();
        assertEquals(baseStr + "[" + LS + "  " + LS + "]", result);
    }

    @Test
    void testSingleField() {
        final String result = new ToStringBuilder(base, new MultilineRecursiveToStringStyle()).append("a", 3).toString();
        assertEquals(baseStr + "[" + LS + "  a=3" + LS + "]", result);
    }

    @Test
    void testMultipleFields() {
        final String result = new ToStringBuilder(base, new MultilineRecursiveToStringStyle()).append("a", 3).append("b", 4).toString();
        assertEquals(baseStr + "[" + LS + "  a=3," + LS + "  b=4" + LS + "]", result);
    }

    @Test
    void testNullValue() {
        final String result = new ToStringBuilder(base, new MultilineRecursiveToStringStyle()).append("n", (Object) null).toString();
        assertEquals(baseStr + "[" + LS + "  n=<null>" + LS + "]", result);
    }

    @Test
    void testStringValueIsNotRecursed() {
        final String result = new ToStringBuilder(base, new MultilineRecursiveToStringStyle()).append("s", "hello").toString();
        assertEquals(baseStr + "[" + LS + "  s=hello" + LS + "]", result);
    }

    @Test
    void testPrimitiveWrapperValueIsNotRecursed() {
        final String result = new ToStringBuilder(base, new MultilineRecursiveToStringStyle()).append("w", Integer.valueOf(9)).toString();
        assertEquals(baseStr + "[" + LS + "  w=9" + LS + "]", result);
    }

    @Test
    void testIntArray() {
        final int[] array = {1, 2, 3};
        final String result = new ToStringBuilder(base, new MultilineRecursiveToStringStyle()).append("arr", array).toString();
        assertEquals(baseStr + "[" + LS + "  arr={" + LS + "    1," + LS + "    2," + LS + "    3" + LS + "  }" + LS + "]", result);
    }

    @Test
    void testEmptyIntArray() {
        final String result = new ToStringBuilder(base, new MultilineRecursiveToStringStyle()).append("arr", new int[0]).toString();
        assertEquals(baseStr + "[" + LS + "  arr={" + LS + "    " + LS + "  }" + LS + "]", result);
    }

    @Test
    void testNullIntArray() {
        final int[] array = null;
        final String result = new ToStringBuilder(base, new MultilineRecursiveToStringStyle()).append("arr", array).toString();
        assertEquals(baseStr + "[" + LS + "  arr=<null>" + LS + "]", result);
    }

    @Test
    void testObjectArrayWithNull() {
        final Object[] array = {null, "x"};
        final String result = new ToStringBuilder(base, new MultilineRecursiveToStringStyle()).append("oarr", array).toString();
        assertEquals(baseStr + "[" + LS + "  oarr={" + LS + "    <null>," + LS + "    x" + LS + "  }" + LS + "]", result);
    }

    @Test
    void testNestedReflectionObject() {
        final Job job = new Job();
        job.title = "Manager";
        final String jobStr = job.getClass().getName() + "@" + Integer.toHexString(System.identityHashCode(job));
        final String result = new ToStringBuilder(base, new MultilineRecursiveToStringStyle()).append("job", job).toString();
        assertEquals(baseStr + "[" + LS + "  job=" + jobStr + "[" + LS + "    title=Manager" + LS + "  ]" + LS + "]", result);
    }

    @Test
    void testDeeplyNestedReflectionObject() {
        final Person p = new Person();
        p.name = "John";
        p.age = 33;
        p.smoker = false;
        p.job = new Job();
        p.job.title = "Manager";
        p.nums = new int[] {7, 8};

        final ReflectionToStringBuilder builder = new ReflectionToStringBuilder(p, new MultilineRecursiveToStringStyle());
        final String actual = builder.toString();
        final String baseStrP = p.getClass().getName() + "@" + Integer.toHexString(System.identityHashCode(p));

        if (builder.isForceAccessible()) {
            final String jobStr = p.job.getClass().getName() + "@" + Integer.toHexString(System.identityHashCode(p.job));
            final String expected = baseStrP + "[" + LS
                    + "  age=33," + LS
                    + "  job=" + jobStr + "[" + LS
                    + "    title=Manager" + LS
                    + "  ]," + LS
                    + "  name=John," + LS
                    + "  nums={" + LS
                    + "    7," + LS
                    + "    8" + LS
                    + "  }," + LS
                    + "  smoker=false" + LS
                    + "]";
            assertEquals(expected, actual);
        } else {
            final String expected = baseStrP + "[" + LS
                    + "  age=<null>," + LS
                    + "  job=<null>," + LS
                    + "  name=<null>," + LS
                    + "  nums=<null>," + LS
                    + "  smoker=<null>" + LS
                    + "]";
            assertEquals(expected, actual);
        }
    }

    @Test
    void testAppendDetailObjectDirectCall() {
        final Job job = new Job();
        job.title = "Manager";
        final String jobStr = job.getClass().getName() + "@" + Integer.toHexString(System.identityHashCode(job));
        final MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();

        final StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "job", (Object) job);
        assertEquals(jobStr + "[" + LS + "    title=Manager" + LS + "  ]", buffer.toString());

        // A second, independent call on the same style instance must produce the same
        // indentation, proving the internal indent counter is restored after each call.
        final StringBuffer buffer2 = new StringBuffer();
        style.appendDetail(buffer2, "job", (Object) job);
        assertEquals(buffer.toString(), buffer2.toString());
    }

    @Test
    void testAppendDetailNullObjectDirectCall() {
        // appendDetail(Object) is a low-level hook invoked only for non-null values by the
        // higher-level append() methods (which render null as "<null>" themselves); called
        // directly with null it falls through to the superclass's raw StringBuffer.append(Object).
        final MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "x", (Object) null);
        assertEquals("null", buffer.toString());
    }

    @Test
    void testAppendDetailStringDirectCallIsNotRecursed() {
        final MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        final StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "x", (Object) "hello");
        assertEquals("hello", buffer.toString());
    }

    @Test
    void testIndentStateDoesNotDriftAcrossCalls() {
        final MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        final int[] array = {1, 2, 3};

        // Appending a value that temporarily increases indentation (an array) must not leave
        // the style's indentation state altered for subsequent, unrelated calls.
        new ToStringBuilder(base, style).append("arr", array).toString();
        final String afterArray = new ToStringBuilder(base, style).append("a", 3).toString();
        assertEquals(baseStr + "[" + LS + "  a=3" + LS + "]", afterArray);

        final Job job = new Job();
        job.title = "Manager";
        new ToStringBuilder(base, style).append("job", job).toString();
        final String afterObject = new ToStringBuilder(base, style).append("b", 4).toString();
        assertEquals(baseStr + "[" + LS + "  b=4" + LS + "]", afterObject);
    }

    @Test
    void testIndependentInstancesDoNotShareState() {
        final MultilineRecursiveToStringStyle style1 = new MultilineRecursiveToStringStyle();
        final MultilineRecursiveToStringStyle style2 = new MultilineRecursiveToStringStyle();
        assertNotSame(style1, style2);

        final int[] array = {1, 2};
        new ToStringBuilder(base, style1).append("arr", array).toString();
        final String result2 = new ToStringBuilder(base, style2).append("a", 3).toString();
        assertEquals(baseStr + "[" + LS + "  a=3" + LS + "]", result2);
    }

    @Test
    void testAppendSuper() {
        final MultilineRecursiveToStringStyle style = new MultilineRecursiveToStringStyle();
        final String result = new ToStringBuilder(base, style).appendSuper(null).append("a", "hello").toString();
        assertEquals(baseStr + "[" + LS + "  a=hello" + LS + "]", result);
    }

    @Test
    void testEqualsAndHashCodeAreObjectIdentity() {
        final MultilineRecursiveToStringStyle style1 = new MultilineRecursiveToStringStyle();
        final MultilineRecursiveToStringStyle style2 = new MultilineRecursiveToStringStyle();
        assertFalse(style1.equals(style2));
        assertTrue(style1.equals(style1));
    }
}
