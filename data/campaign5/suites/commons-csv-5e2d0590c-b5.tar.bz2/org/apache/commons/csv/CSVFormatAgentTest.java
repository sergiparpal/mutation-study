/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link CSVFormat}.
 */
class CSVFormatAgentTest {

    private enum Header {
        NAME, EMAIL
    }

    @Test
    void testNewFormatDefaults() {
        final CSVFormat format = CSVFormat.newFormat(';');
        assertEquals(";", format.getDelimiterString());
        assertNull(format.getQuoteCharacter());
        assertNull(format.getCommentMarker());
        assertNull(format.getEscapeCharacter());
        assertNull(format.getHeader());
        assertFalse(format.getIgnoreEmptyLines());
        assertFalse(format.getSkipHeaderRecord());
        assertFalse(format.getAllowMissingColumnNames());
        assertEquals(0, format.getMaxRows());
        assertFalse(format.useMaxRows());
    }

    @Test
    void testNewFormatRejectsLineBreakDelimiter() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                CSVFormat.newFormat('\n');
            }
        });
    }

    @Test
    void testDefaultFormat() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertTrue(format.getIgnoreEmptyLines());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
    }

    @Test
    void testExcelFormatDiffersFromDefault() {
        final CSVFormat excel = CSVFormat.EXCEL;
        assertFalse(excel.getIgnoreEmptyLines());
        assertTrue(excel.getAllowMissingColumnNames());
        assertTrue(excel.getTrailingData());
        assertTrue(excel.getLenientEof());
        assertNotEquals(CSVFormat.DEFAULT, excel);
    }

    @Test
    void testRfc4180DiffersFromDefaultOnlyByIgnoreEmptyLines() {
        final CSVFormat rfc4180 = CSVFormat.RFC4180;
        assertFalse(rfc4180.getIgnoreEmptyLines());
        final CSVFormat expected = CSVFormat.DEFAULT.builder().setIgnoreEmptyLines(false).get();
        assertEquals(expected, rfc4180);
    }

    @Test
    void testTdfFormat() {
        final CSVFormat tdf = CSVFormat.TDF;
        assertEquals("\t", tdf.getDelimiterString());
        assertTrue(tdf.getIgnoreSurroundingSpaces());
    }

    @Test
    void testMySqlFormat() {
        final CSVFormat mysql = CSVFormat.MYSQL;
        assertEquals("\t", mysql.getDelimiterString());
        assertNull(mysql.getQuoteCharacter());
        assertEquals("\\N", mysql.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, mysql.getQuoteMode());
        assertEquals(Character.valueOf('\\'), mysql.getEscapeCharacter());
    }

    @Test
    void testValueOfPredefined() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.valueOf("Default"));
        assertEquals(CSVFormat.EXCEL, CSVFormat.valueOf("Excel"));
        assertEquals(CSVFormat.TDF, CSVFormat.valueOf("TDF"));
    }

    @Test
    void testValueOfUnknownThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                CSVFormat.valueOf("DoesNotExist");
            }
        });
    }

    @Test
    void testBuilderRoundTripPreservesSettings() {
        final CSVFormat format = CSVFormat.DEFAULT.builder()
                .setDelimiter('|')
                .setQuote('\'')
                .setEscape('\\')
                .setCommentMarker('#')
                .setNullString("NULL")
                .setRecordSeparator('\n')
                .setSkipHeaderRecord(true)
                .setIgnoreHeaderCase(true)
                .setIgnoreSurroundingSpaces(true)
                .setTrailingDelimiter(true)
                .setTrim(true)
                .setAutoFlush(true)
                .setAllowMissingColumnNames(true)
                .setMaxRows(5)
                .setHeader("a", "b")
                .setHeaderComments("comment1")
                .get();

        assertEquals("|", format.getDelimiterString());
        assertEquals(Character.valueOf('\''), format.getQuoteCharacter());
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
        assertEquals(Character.valueOf('#'), format.getCommentMarker());
        assertEquals("NULL", format.getNullString());
        assertEquals("\n", format.getRecordSeparator());
        assertTrue(format.getSkipHeaderRecord());
        assertTrue(format.getIgnoreHeaderCase());
        assertTrue(format.getIgnoreSurroundingSpaces());
        assertTrue(format.getTrailingDelimiter());
        assertTrue(format.getTrim());
        assertTrue(format.getAutoFlush());
        assertTrue(format.getAllowMissingColumnNames());
        assertEquals(5, format.getMaxRows());
        assertTrue(format.useMaxRows());
        assertArrayEquals(format.getHeader(), new String[] {"a", "b"});
        assertArrayEquals(format.getHeaderComments(), new String[] {"comment1"});
        assertTrue(format.isCommentMarkerSet());
        assertTrue(format.isEscapeCharacterSet());
        assertTrue(format.isNullStringSet());
        assertTrue(format.isQuoteCharacterSet());
    }

    private static void assertArrayEquals(final String[] actual, final String[] expected) {
        assertEquals(expected.length, actual.length);
        for (int i = 0; i < expected.length; i++) {
            assertEquals(expected[i], actual[i]);
        }
    }

    @Test
    void testGetHeaderReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "b").get();
        final String[] header1 = format.getHeader();
        header1[0] = "mutated";
        final String[] header2 = format.getHeader();
        assertEquals("a", header2[0]);
        assertNotSame(header1, header2);
    }

    @Test
    void testGetHeaderNullWhenDisabled() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertNull(format.getHeader());
    }

    @Test
    void testSetHeaderFromEnum() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(Header.class).get();
        assertArrayEquals(format.getHeader(), new String[] {"NAME", "EMAIL"});
    }

    @Test
    void testSetDelimiterEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDelimiter("");
            }
        });
    }

    @Test
    void testSetDelimiterLineBreakThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDelimiter("\r");
            }
        });
    }

    @Test
    void testSetCommentMarkerLineBreakThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setCommentMarker('\n');
            }
        });
    }

    @Test
    void testSetEscapeLineBreakThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setEscape('\n');
            }
        });
    }

    @Test
    void testSetQuoteLineBreakThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setQuote('\r');
            }
        });
    }

    @Test
    void testValidateQuoteCharEqualsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDelimiter(',').setQuote(',').get();
            }
        });
    }

    @Test
    void testValidateEscapeCharEqualsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDelimiter(',').setEscape(',').get();
            }
        });
    }

    @Test
    void testValidateCommentMarkerEqualsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDelimiter(',').setCommentMarker(',').get();
            }
        });
    }

    @Test
    void testValidateQuoteCharEqualsCommentMarkerThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setQuote('#').setCommentMarker('#').get();
            }
        });
    }

    @Test
    void testValidateEscapeCharEqualsCommentMarkerThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setEscape('#').setCommentMarker('#').get();
            }
        });
    }

    @Test
    void testValidateQuoteModeNoneWithoutEscapeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setQuoteMode(QuoteMode.NONE).get();
            }
        });
    }

    @Test
    void testValidateQuoteModeNoneWithEscapeSucceeds() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').setQuoteMode(QuoteMode.NONE).get();
        assertEquals(QuoteMode.NONE, format.getQuoteMode());
    }

    @Test
    void testValidateDuplicateHeadersDisallowThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).setHeader("a", "a").get();
            }
        });
    }

    @Test
    void testValidateDuplicateHeadersAllowAllSucceeds() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_ALL).setHeader("a", "a").get();
        assertArrayEquals(format.getHeader(), new String[] {"a", "a"});
    }

    @Test
    void testValidateDuplicateHeadersAllowEmptySucceeds() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("a", "", "").get();
        assertArrayEquals(format.getHeader(), new String[] {"a", "", ""});
    }

    @Test
    void testValidateDuplicateHeadersAllowEmptyRejectsNonEmptyDuplicate() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("a", "a").get();
            }
        });
    }

    @Test
    void testEqualsAndHashCode() {
        final CSVFormat format1 = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        final CSVFormat format2 = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        assertEquals(format1, format2);
        assertEquals(format1.hashCode(), format2.hashCode());
        assertNotEquals(CSVFormat.DEFAULT, format1);
        assertFalse(format1.equals(null));
        assertFalse(format1.equals("not a format"));
        assertTrue(format1.equals(format1));
    }

    @Test
    void testFormatMethod() throws IOException {
        final String result = CSVFormat.DEFAULT.format("a", "b", "c");
        assertEquals("a,b,c", result);
    }

    @Test
    void testFormatMethodWithQuotingNeeded() {
        final String result = CSVFormat.DEFAULT.format("a,b", "c");
        assertEquals("\"a,b\",c", result);
    }

    @Test
    void testPrintRecord() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.printRecord(writer, "x", "y");
        assertEquals("x,y\r\n", writer.toString());
    }

    @Test
    void testPrintSingleValue() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.print("hello", writer, true);
        assertEquals("hello", writer.toString());
    }

    @Test
    void testPrintlnWithTrailingDelimiter() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get();
        final StringWriter writer = new StringWriter();
        format.println(writer);
        assertEquals(",\r\n", writer.toString());
    }

    @Test
    void testParseReturnsNonNullParser() throws IOException {
        final Reader reader = new StringReader("a,b\n1,2\n");
        final CSVParser parser = CSVFormat.DEFAULT.parse(reader);
        assertNotNull(parser);
        parser.close();
    }

    @Test
    void testToStringContainsDelimiter() {
        final String str = CSVFormat.DEFAULT.toString();
        assertTrue(str.contains("Delimiter=<,>"));
    }

    @Test
    void testToStringReflectsQuoteAndComment() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuote('\'').setCommentMarker('#').setNullString("NULL").get();
        final String str = format.toString();
        assertTrue(str.contains("QuoteChar=<'>"));
        assertTrue(str.contains("CommentStart=<#>"));
        assertTrue(str.contains("NullString=<NULL>"));
    }

    @Test
    void testBuilderCopyIsIndependent() {
        final CSVFormat base = CSVFormat.DEFAULT;
        final CSVFormat modified = base.builder().setDelimiter(';').get();
        assertEquals(",", base.getDelimiterString());
        assertEquals(";", modified.getDelimiterString());
    }

    @Test
    void testDeprecatedWithDelimiter() {
        final CSVFormat format = CSVFormat.DEFAULT.withDelimiter(';');
        assertEquals(";", format.getDelimiterString());
    }

    @Test
    void testDeprecatedWithHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("x", "y");
        assertArrayEquals(format.getHeader(), new String[] {"x", "y"});
    }

    @Test
    void testDeprecatedWithFirstRecordAsHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.withFirstRecordAsHeader();
        assertTrue(format.getSkipHeaderRecord());
        assertArrayEquals(format.getHeader(), new String[] {});
    }

    @Test
    void testDeprecatedWithNullString() {
        final CSVFormat format = CSVFormat.DEFAULT.withNullString("NULL");
        assertEquals("NULL", format.getNullString());
        assertTrue(format.isNullStringSet());
    }

    @Test
    void testDeprecatedWithQuoteMode() {
        final CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL);
        assertEquals(QuoteMode.ALL, format.getQuoteMode());
    }

    @Test
    void testDeprecatedWithTrim() {
        final CSVFormat format = CSVFormat.DEFAULT.withTrim();
        assertTrue(format.getTrim());
        final CSVFormat format2 = format.withTrim(false);
        assertFalse(format2.getTrim());
    }

    @Test
    void testDeprecatedWithSkipHeaderRecord() {
        final CSVFormat format = CSVFormat.DEFAULT.withSkipHeaderRecord();
        assertTrue(format.getSkipHeaderRecord());
    }

    @Test
    void testDeprecatedWithIgnoreEmptyLines() {
        final CSVFormat format = CSVFormat.RFC4180.withIgnoreEmptyLines();
        assertTrue(format.getIgnoreEmptyLines());
        final CSVFormat format2 = format.withIgnoreEmptyLines(false);
        assertFalse(format2.getIgnoreEmptyLines());
    }

    @Test
    void testDeprecatedWithAllowDuplicateHeaderNames() {
        final CSVFormat format = CSVFormat.DEFAULT.withAllowDuplicateHeaderNames(false);
        assertEquals(DuplicateHeaderMode.ALLOW_EMPTY, format.getDuplicateHeaderMode());
        assertFalse(format.getAllowDuplicateHeaderNames());
    }

    @Test
    void testDeprecatedGetDelimiterChar() {
        assertEquals(',', CSVFormat.DEFAULT.getDelimiter());
    }

    @Test
    void testPredefinedEnumGetFormat() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.Predefined.Default.getFormat());
        assertEquals(CSVFormat.MYSQL, CSVFormat.Predefined.MySQL.getFormat());
    }

    @Test
    void testMaxRowsBoundary() {
        final CSVFormat zero = CSVFormat.DEFAULT.builder().setMaxRows(0).get();
        assertFalse(zero.useMaxRows());
        final CSVFormat negative = CSVFormat.DEFAULT.builder().setMaxRows(-1).get();
        assertFalse(negative.useMaxRows());
        final CSVFormat one = CSVFormat.DEFAULT.builder().setMaxRows(1).get();
        assertTrue(one.useMaxRows());
        assertTrue(one.useRow(1));
        assertFalse(one.useRow(2));
    }

    @Test
    void testBuilderStaticCreateDefaults() {
        final CSVFormat format = CSVFormat.Builder.create().get();
        assertEquals(CSVFormat.DEFAULT, format);
    }

    @Test
    void testBuilderCreateFromFormat() {
        final CSVFormat source = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        final CSVFormat.Builder builder = CSVFormat.Builder.create(source);
        final CSVFormat copyFormat = builder.get();
        assertEquals(source, copyFormat);
    }

    @Test
    void testGetDuplicateHeaderModeDefault() {
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, CSVFormat.DEFAULT.getDuplicateHeaderMode());
    }
}
