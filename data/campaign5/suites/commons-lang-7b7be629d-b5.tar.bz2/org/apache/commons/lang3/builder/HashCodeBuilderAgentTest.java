/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3.builder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link HashCodeBuilder}.
 */
public class HashCodeBuilderAgentTest {

    /** Simple fixture class with several field types for reflection based tests. */
    static class AgentFixture {
        private final int intField;
        private final String stringField;
        private transient int transientField;
        @HashCodeExclude
        private int excludedField;
        private static int staticField = 42;

        AgentFixture(final int intField, final String stringField) {
            this.intField = intField;
            this.stringField = stringField;
        }
    }

    /** Fixture with a field that references itself, to exercise cycle detection. */
    static class AgentCyclicFixture {
        private AgentCyclicFixture other;
        private final int value;

        AgentCyclicFixture(final int value) {
            this.value = value;
        }
    }

    static class AgentSubFixture extends AgentFixture {
        private final int subField;

        AgentSubFixture(final int intField, final String stringField, final int subField) {
            super(intField, stringField);
            this.subField = subField;
        }
    }

    // ---------------------------------------------------------------
    // Constructors
    // ---------------------------------------------------------------

    @Test
    public void testDefaultConstructor() {
        final HashCodeBuilder builder = new HashCodeBuilder();
        assertEquals(17, builder.toHashCode());
    }

    @Test
    public void testConstructorWithValidOddNumbers() {
        final HashCodeBuilder builder = new HashCodeBuilder(3, 5);
        assertEquals(3, builder.toHashCode());
        builder.append(2);
        assertEquals(3 * 5 + 2, builder.toHashCode());
    }

    @Test
    public void testConstructorWithEvenInitialThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new HashCodeBuilder(4, 5);
            }
        });
    }

    @Test
    public void testConstructorWithEvenMultiplierThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new HashCodeBuilder(3, 4);
            }
        });
    }

    @Test
    public void testBuilderFactory() {
        final HashCodeBuilder.Builder builder = HashCodeBuilder.builder();
        final HashCodeBuilder hashCodeBuilder = builder.setInitialOddNumber(9).setMultiplierOddNumber(7).get();
        assertEquals(9, hashCodeBuilder.toHashCode());
    }

    // ---------------------------------------------------------------
    // append(primitive) and toHashCode()
    // ---------------------------------------------------------------

    @Test
    public void testAppendBoolean() {
        final HashCodeBuilder trueBuilder = new HashCodeBuilder(17, 37).append(true);
        final HashCodeBuilder falseBuilder = new HashCodeBuilder(17, 37).append(false);
        assertEquals(17 * 37 + 0, trueBuilder.toHashCode());
        assertEquals(17 * 37 + 1, falseBuilder.toHashCode());
        assertNotEquals(trueBuilder.toHashCode(), falseBuilder.toHashCode());
    }

    @Test
    public void testAppendBooleanArrayNullAndValues() {
        final HashCodeBuilder nullArrayBuilder = new HashCodeBuilder(17, 37).append((boolean[]) null);
        assertEquals(17 * 37, nullArrayBuilder.toHashCode());

        final HashCodeBuilder valuesBuilder = new HashCodeBuilder(17, 37).append(new boolean[] {true, false});
        final HashCodeBuilder manualBuilder = new HashCodeBuilder(17, 37).append(true).append(false);
        assertEquals(manualBuilder.toHashCode(), valuesBuilder.toHashCode());
    }

    @Test
    public void testAppendByteAndArray() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37).append((byte) 5);
        assertEquals(17 * 37 + 5, builder.toHashCode());

        final HashCodeBuilder nullArray = new HashCodeBuilder(17, 37).append((byte[]) null);
        assertEquals(17 * 37, nullArray.toHashCode());

        final HashCodeBuilder arrayBuilder = new HashCodeBuilder(17, 37).append(new byte[] {1, 2, 3});
        final HashCodeBuilder manualBuilder = new HashCodeBuilder(17, 37).append((byte) 1).append((byte) 2).append((byte) 3);
        assertEquals(manualBuilder.toHashCode(), arrayBuilder.toHashCode());
    }

    @Test
    public void testAppendCharAndArray() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37).append('a');
        assertEquals(17 * 37 + 'a', builder.toHashCode());

        final HashCodeBuilder nullArray = new HashCodeBuilder(17, 37).append((char[]) null);
        assertEquals(17 * 37, nullArray.toHashCode());

        final HashCodeBuilder arrayBuilder = new HashCodeBuilder(17, 37).append(new char[] {'a', 'b'});
        final HashCodeBuilder manualBuilder = new HashCodeBuilder(17, 37).append('a').append('b');
        assertEquals(manualBuilder.toHashCode(), arrayBuilder.toHashCode());
    }

    @Test
    public void testAppendDoubleAndArray() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37).append(1.5d);
        final HashCodeBuilder manual = new HashCodeBuilder(17, 37).append(Double.doubleToLongBits(1.5d));
        assertEquals(manual.toHashCode(), builder.toHashCode());

        final HashCodeBuilder nullArray = new HashCodeBuilder(17, 37).append((double[]) null);
        assertEquals(17 * 37, nullArray.toHashCode());

        final HashCodeBuilder arrayBuilder = new HashCodeBuilder(17, 37).append(new double[] {1.5d, 2.5d});
        final HashCodeBuilder manualArray = new HashCodeBuilder(17, 37).append(1.5d).append(2.5d);
        assertEquals(manualArray.toHashCode(), arrayBuilder.toHashCode());
    }

    @Test
    public void testAppendFloatAndArray() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37).append(2.5f);
        assertEquals(17 * 37 + Float.floatToIntBits(2.5f), builder.toHashCode());

        final HashCodeBuilder nullArray = new HashCodeBuilder(17, 37).append((float[]) null);
        assertEquals(17 * 37, nullArray.toHashCode());

        final HashCodeBuilder arrayBuilder = new HashCodeBuilder(17, 37).append(new float[] {1.0f, 2.0f});
        final HashCodeBuilder manualArray = new HashCodeBuilder(17, 37).append(1.0f).append(2.0f);
        assertEquals(manualArray.toHashCode(), arrayBuilder.toHashCode());
    }

    @Test
    public void testAppendIntAndArray() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37).append(100);
        assertEquals(17 * 37 + 100, builder.toHashCode());

        final HashCodeBuilder nullArray = new HashCodeBuilder(17, 37).append((int[]) null);
        assertEquals(17 * 37, nullArray.toHashCode());

        final HashCodeBuilder arrayBuilder = new HashCodeBuilder(17, 37).append(new int[] {1, 2, 3});
        final HashCodeBuilder manualArray = new HashCodeBuilder(17, 37).append(1).append(2).append(3);
        assertEquals(manualArray.toHashCode(), arrayBuilder.toHashCode());
    }

    @Test
    public void testAppendLongAndArray() {
        final long value = 123456789012L;
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37).append(value);
        assertEquals(17 * 37 + (int) (value ^ value >> 32), builder.toHashCode());

        final HashCodeBuilder nullArray = new HashCodeBuilder(17, 37).append((long[]) null);
        assertEquals(17 * 37, nullArray.toHashCode());

        final HashCodeBuilder arrayBuilder = new HashCodeBuilder(17, 37).append(new long[] {1L, 2L});
        final HashCodeBuilder manualArray = new HashCodeBuilder(17, 37).append(1L).append(2L);
        assertEquals(manualArray.toHashCode(), arrayBuilder.toHashCode());
    }

    @Test
    public void testAppendShortAndArray() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37).append((short) 7);
        assertEquals(17 * 37 + 7, builder.toHashCode());

        final HashCodeBuilder nullArray = new HashCodeBuilder(17, 37).append((short[]) null);
        assertEquals(17 * 37, nullArray.toHashCode());

        final HashCodeBuilder arrayBuilder = new HashCodeBuilder(17, 37).append(new short[] {1, 2});
        final HashCodeBuilder manualArray = new HashCodeBuilder(17, 37).append((short) 1).append((short) 2);
        assertEquals(manualArray.toHashCode(), arrayBuilder.toHashCode());
    }

    @Test
    public void testAppendObjectNullAndValue() {
        final HashCodeBuilder nullBuilder = new HashCodeBuilder(17, 37).append((Object) null);
        assertEquals(17 * 37, nullBuilder.toHashCode());

        final String str = "hello";
        final HashCodeBuilder objBuilder = new HashCodeBuilder(17, 37).append((Object) str);
        assertEquals(17 * 37 + str.hashCode(), objBuilder.toHashCode());
    }

    @Test
    public void testAppendObjectArrayNullAndValues() {
        final HashCodeBuilder nullArray = new HashCodeBuilder(17, 37).append((Object[]) null);
        assertEquals(17 * 37, nullArray.toHashCode());

        final Object[] array = {"a", "b", null};
        final HashCodeBuilder arrayBuilder = new HashCodeBuilder(17, 37).append(array);
        final HashCodeBuilder manual = new HashCodeBuilder(17, 37).append((Object) "a").append((Object) "b").append((Object) null);
        assertEquals(manual.toHashCode(), arrayBuilder.toHashCode());
    }

    @Test
    public void testAppendObjectDispatchesArrayOfObjectsThroughGenericAppend() {
        // append(Object) with an Object[] argument must route through appendArray.
        final Object array = new String[] {"x", "y"};
        final HashCodeBuilder viaObject = new HashCodeBuilder(17, 37).append(array);
        final HashCodeBuilder viaTypedArray = new HashCodeBuilder(17, 37).append(new String[] {"x", "y"});
        assertEquals(viaTypedArray.toHashCode(), viaObject.toHashCode());
    }

    @Test
    public void testAppendObjectDispatchesPrimitiveArrayTypes() {
        assertEquals(new HashCodeBuilder(17, 37).append(new int[] {1, 2}).toHashCode(),
                new HashCodeBuilder(17, 37).append((Object) new int[] {1, 2}).toHashCode());
        assertEquals(new HashCodeBuilder(17, 37).append(new long[] {1L, 2L}).toHashCode(),
                new HashCodeBuilder(17, 37).append((Object) new long[] {1L, 2L}).toHashCode());
        assertEquals(new HashCodeBuilder(17, 37).append(new short[] {1, 2}).toHashCode(),
                new HashCodeBuilder(17, 37).append((Object) new short[] {1, 2}).toHashCode());
        assertEquals(new HashCodeBuilder(17, 37).append(new char[] {'a', 'b'}).toHashCode(),
                new HashCodeBuilder(17, 37).append((Object) new char[] {'a', 'b'}).toHashCode());
        assertEquals(new HashCodeBuilder(17, 37).append(new byte[] {1, 2}).toHashCode(),
                new HashCodeBuilder(17, 37).append((Object) new byte[] {1, 2}).toHashCode());
        assertEquals(new HashCodeBuilder(17, 37).append(new double[] {1.0, 2.0}).toHashCode(),
                new HashCodeBuilder(17, 37).append((Object) new double[] {1.0, 2.0}).toHashCode());
        assertEquals(new HashCodeBuilder(17, 37).append(new float[] {1.0f, 2.0f}).toHashCode(),
                new HashCodeBuilder(17, 37).append((Object) new float[] {1.0f, 2.0f}).toHashCode());
        assertEquals(new HashCodeBuilder(17, 37).append(new boolean[] {true, false}).toHashCode(),
                new HashCodeBuilder(17, 37).append((Object) new boolean[] {true, false}).toHashCode());
    }

    @Test
    public void testAppendObjectWithSelfReferencingArrayDoesNotStackOverflow() {
        final Object[] cyclicArray = new Object[1];
        cyclicArray[0] = cyclicArray;
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        // Must terminate rather than recurse infinitely / overflow the stack.
        builder.append((Object) cyclicArray);
        assertEquals(17 * 37, builder.toHashCode());
    }

    @Test
    public void testAppendSuper() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37).appendSuper(99);
        assertEquals(17 * 37 + 99, builder.toHashCode());
    }

    @Test
    public void testChainingReturnsThis() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37);
        assertSame(builder, builder.append(1));
        assertSame(builder, builder.append(true));
        assertSame(builder, builder.appendSuper(1));
    }

    // ---------------------------------------------------------------
    // build(), equals(), hashCode()
    // ---------------------------------------------------------------

    @Test
    public void testBuildReturnsBoxedToHashCode() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37).append(5);
        assertEquals(Integer.valueOf(builder.toHashCode()), builder.build());
    }

    @Test
    public void testEqualsSameInstance() {
        final HashCodeBuilder builder = new HashCodeBuilder();
        assertTrue(builder.equals(builder));
    }

    @Test
    public void testEqualsDifferentTypeOrNull() {
        final HashCodeBuilder builder = new HashCodeBuilder();
        assertFalse(builder.equals(null));
        assertFalse(builder.equals("not a builder"));
    }

    @Test
    public void testEqualsBasedOnTotal() {
        final HashCodeBuilder builder1 = new HashCodeBuilder(17, 37).append(5);
        final HashCodeBuilder builder2 = new HashCodeBuilder(17, 37).append(5);
        final HashCodeBuilder builder3 = new HashCodeBuilder(17, 37).append(6);
        assertTrue(builder1.equals(builder2));
        assertFalse(builder1.equals(builder3));
    }

    @Test
    public void testHashCodeMatchesToHashCode() {
        final HashCodeBuilder builder = new HashCodeBuilder(17, 37).append(42);
        assertEquals(builder.toHashCode(), builder.hashCode());
    }

    // ---------------------------------------------------------------
    // reflectionHashCode
    // ---------------------------------------------------------------

    @Test
    public void testReflectionHashCodeNullObjectThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                HashCodeBuilder.reflectionHashCode(null);
            }
        });
    }

    @Test
    public void testReflectionHashCodeWithEvenInitialThrows() {
        final AgentFixture fixture = new AgentFixture(1, "a");
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                HashCodeBuilder.reflectionHashCode(4, 5, fixture);
            }
        });
    }

    @Test
    public void testReflectionHashCodeConsistentForEqualFields() {
        final AgentFixture one = new AgentFixture(10, "same");
        final AgentFixture two = new AgentFixture(10, "same");
        assertEquals(HashCodeBuilder.reflectionHashCode(one), HashCodeBuilder.reflectionHashCode(two));
    }

    @Test
    public void testReflectionHashCodeDiffersForDifferentFields() {
        final AgentFixture one = new AgentFixture(10, "same");
        final AgentFixture two = new AgentFixture(11, "same");
        assertNotEquals(HashCodeBuilder.reflectionHashCode(one), HashCodeBuilder.reflectionHashCode(two));
    }

    @Test
    public void testReflectionHashCodeExcludesTransientFieldsByDefault() {
        final AgentFixture one = new AgentFixture(10, "same");
        one.transientField = 1;
        final AgentFixture two = new AgentFixture(10, "same");
        two.transientField = 2;
        assertEquals(HashCodeBuilder.reflectionHashCode(one), HashCodeBuilder.reflectionHashCode(two));
    }

    @Test
    public void testReflectionHashCodeIncludesTransientFieldsWhenRequested() {
        final AgentFixture one = new AgentFixture(10, "same");
        one.transientField = 1;
        final AgentFixture two = new AgentFixture(10, "same");
        two.transientField = 2;
        final int hashOne = HashCodeBuilder.reflectionHashCode(17, 37, one, true);
        final int hashTwo = HashCodeBuilder.reflectionHashCode(17, 37, two, true);
        assertNotEquals(hashOne, hashTwo);
    }

    @Test
    public void testReflectionHashCodeExcludesAnnotatedField() {
        final AgentFixture one = new AgentFixture(10, "same");
        one.excludedField = 1;
        final AgentFixture two = new AgentFixture(10, "same");
        two.excludedField = 2;
        assertEquals(HashCodeBuilder.reflectionHashCode(one), HashCodeBuilder.reflectionHashCode(two));
    }

    @Test
    public void testReflectionHashCodeExcludeFieldsByNameArray() {
        final AgentFixture one = new AgentFixture(10, "same");
        final AgentFixture two = new AgentFixture(99, "same");
        final int hashOne = HashCodeBuilder.reflectionHashCode(one, "intField");
        final int hashTwo = HashCodeBuilder.reflectionHashCode(two, "intField");
        assertEquals(hashOne, hashTwo);
    }

    @Test
    public void testReflectionHashCodeExcludeFieldsByCollection() {
        final AgentFixture one = new AgentFixture(10, "same");
        final AgentFixture two = new AgentFixture(99, "same");
        final List<String> excludes = Collections.singletonList("intField");
        final int hashOne = HashCodeBuilder.reflectionHashCode(one, excludes);
        final int hashTwo = HashCodeBuilder.reflectionHashCode(two, excludes);
        assertEquals(hashOne, hashTwo);
    }

    @Test
    public void testReflectionHashCodeExcludeFieldsByCollectionWithNullEntriesIgnored() {
        final List<String> excludesWithNull = new ArrayList<String>(Arrays.asList("intField", null));
        final AgentFixture fixture = new AgentFixture(10, "same");
        // Should not throw despite the null entry in the exclude collection.
        final int hash = HashCodeBuilder.reflectionHashCode(fixture, excludesWithNull);
        assertEquals(HashCodeBuilder.reflectionHashCode(new AgentFixture(5, "same"), excludesWithNull), hash);
    }

    @Test
    public void testReflectionHashCodeStaticFieldsNotUsed() {
        AgentFixture.staticField = 1;
        final int hashA = HashCodeBuilder.reflectionHashCode(new AgentFixture(10, "same"));
        AgentFixture.staticField = 2;
        final int hashB = HashCodeBuilder.reflectionHashCode(new AgentFixture(10, "same"));
        assertEquals(hashA, hashB);
    }

    @Test
    public void testReflectionHashCodeDetectsCyclesWithoutStackOverflow() {
        final AgentCyclicFixture fixture = new AgentCyclicFixture(5);
        fixture.other = fixture;
        // Must not throw StackOverflowError due to cycle detection via the registry.
        final int hash = HashCodeBuilder.reflectionHashCode(fixture);
        assertEquals(hash, HashCodeBuilder.reflectionHashCode(fixture));
    }

    @Test
    public void testReflectionHashCodeIncludesSuperclassFieldsByDefault() {
        final AgentSubFixture one = new AgentSubFixture(1, "a", 100);
        final AgentSubFixture two = new AgentSubFixture(1, "a", 200);
        assertNotEquals(HashCodeBuilder.reflectionHashCode(one), HashCodeBuilder.reflectionHashCode(two));
    }

    @Test
    public void testReflectionHashCodeUpToOwnClassExcludesSuperclassFields() {
        final AgentSubFixture one = new AgentSubFixture(1, "a", 100);
        final AgentSubFixture two = new AgentSubFixture(2, "b", 100);
        final int hashOne = HashCodeBuilder.reflectionHashCode(17, 37, one, false, AgentSubFixture.class);
        final int hashTwo = HashCodeBuilder.reflectionHashCode(17, 37, two, false, AgentSubFixture.class);
        assertEquals(hashOne, hashTwo);
    }

    @Test
    public void testReflectionHashCodeConstantWhenNoFields() {
        final Object plain = new Object() {
            // no fields
        };
        final int hash = HashCodeBuilder.reflectionHashCode(17, 37, plain, false, Object.class);
        assertEquals(17, hash);
    }
}
