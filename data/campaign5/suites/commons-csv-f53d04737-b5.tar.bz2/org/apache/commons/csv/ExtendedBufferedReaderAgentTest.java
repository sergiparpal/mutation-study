/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.apache.commons.csv.Constants.UNDEFINED;
import static org.apache.commons.io.IOUtils.EOF;
import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests for {@link ExtendedBufferedReader} that are not already covered by {@code ExtendedBufferedReaderTest}.
 */
class ExtendedBufferedReaderAgentTest {

    private ExtendedBufferedReader createReader(final String s) {
        return new ExtendedBufferedReader(new StringReader(s));
    }

    private ExtendedBufferedReader createReaderWithByteTracking(final String s) {
        return new ExtendedBufferedReader(new StringReader(s), StandardCharsets.UTF_8, true);
    }

    @Test
    void testInitialState() throws IOException {
        final ExtendedBufferedReader br = createReader("abc");
        try {
            assertEquals(UNDEFINED, br.getLastChar());
            assertEquals(0, br.getLineNumber());
            assertEquals(0, br.getPosition());
            assertEquals(0, br.getBytesRead());
        } finally {
            br.close();
        }
    }

    @Test
    void testCloseSetsLastCharToEofAndBlocksFurtherReads() throws IOException {
        final ExtendedBufferedReader br = createReader("abc");
        br.read();
        br.close();
        assertEquals(EOF, br.getLastChar());
        assertThrows(IOException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                br.read();
            }
        });
    }

    @Test
    void testGetPositionTracksSingleCharReads() throws IOException {
        final ExtendedBufferedReader br = createReader("abc");
        try {
            assertEquals(0, br.getPosition());
            br.read();
            assertEquals(1, br.getPosition());
            br.read();
            assertEquals(2, br.getPosition());
            br.read();
            assertEquals(3, br.getPosition());
            // Reading past EOF still advances position by one per call.
            assertEquals(EOF, br.read());
            assertEquals(4, br.getPosition());
        } finally {
            br.close();
        }
    }

    @Test
    void testGetPositionTracksBulkReads() throws IOException {
        final ExtendedBufferedReader br = createReader("abcdef");
        try {
            final char[] buf = new char[4];
            assertEquals(4, br.read(buf, 0, 4));
            assertEquals(4, br.getPosition());
            assertEquals(2, br.read(buf, 0, 4));
            assertEquals(6, br.getPosition());
            assertEquals(EOF, br.read(buf, 0, 4));
            // EOF (-1) is added to position by the bulk read, matching the single-char read behavior.
            assertEquals(5, br.getPosition());
        } finally {
            br.close();
        }
    }

    @Test
    void testReadZeroLengthDoesNotAdvanceStateAndReturnsZeroEvenAtEof() throws IOException {
        final ExtendedBufferedReader br = createReader("");
        try {
            assertEquals(0, br.read(new char[5], 0, 0));
            assertEquals(UNDEFINED, br.getLastChar());
            assertEquals(0, br.getPosition());
        } finally {
            br.close();
        }
    }

    @Test
    void testMarkAndResetRestoreAllTrackedState() throws IOException {
        final ExtendedBufferedReader br = createReader("ab\ncd");
        try {
            br.read(); // 'a'
            br.read(); // 'b'
            br.mark(10);
            final long markedLine = br.getLineNumber();
            final long markedPosition = br.getPosition();
            final int markedLastChar = br.getLastChar();

            br.read(); // '\n'
            br.read(); // 'c'
            assertTrue(br.getLineNumber() != markedLine || br.getPosition() != markedPosition);

            br.reset();
            assertEquals(markedLine, br.getLineNumber());
            assertEquals(markedPosition, br.getPosition());
            assertEquals(markedLastChar, br.getLastChar());

            // Reading after reset reproduces the same characters.
            assertEquals('\n', br.read());
            assertEquals('c', br.read());
        } finally {
            br.close();
        }
    }

    @Test
    void testMarkAndResetRestoreBytesRead() throws IOException {
        final ExtendedBufferedReader br = createReaderWithByteTracking("abécd");
        try {
            br.read(); // 'a' -> 1 byte
            br.read(); // 'b' -> 1 byte
            br.mark(10);
            final long markedBytes = br.getBytesRead();
            assertEquals(2, markedBytes);

            br.read(); // 'é' -> 2 bytes in UTF-8
            assertEquals(4, br.getBytesRead());

            br.reset();
            assertEquals(markedBytes, br.getBytesRead());
        } finally {
            br.close();
        }
    }

    @Test
    void testBytesReadTracksAsciiOneBytePerChar() throws IOException {
        final String input = "hello";
        final ExtendedBufferedReader br = createReaderWithByteTracking(input);
        try {
            final char[] buf = new char[input.length()];
            final int n = br.read(buf, 0, buf.length);
            assertEquals(input.length(), n);
            assertArrayEquals(input.toCharArray(), buf);
            assertEquals(input.getBytes(StandardCharsets.UTF_8).length, br.getBytesRead());
        } finally {
            br.close();
        }
    }

    @Test
    void testBytesReadStaysZeroWithoutByteTracking() throws IOException {
        final ExtendedBufferedReader br = createReader("hello world");
        try {
            while (br.read() != EOF) {
                // consume all
            }
            assertEquals(0, br.getBytesRead());
        } finally {
            br.close();
        }
    }

    @Test
    void testLoneLowSurrogateThrowsCharacterCodingExceptionOnRead() throws IOException {
        // A lone low surrogate at the very start of the stream cannot be paired with a
        // preceding high surrogate, so the encoder must fail with a CharacterCodingException.
        final ExtendedBufferedReader br = createReaderWithByteTracking("\udc00");
        try {
            assertThrows(java.nio.charset.CharacterCodingException.class, new Executable() {
                @Override
                public void execute() throws Throwable {
                    br.read();
                }
            });
        } finally {
            br.close();
        }
    }

    @Test
    void testTrailingHighSurrogateDoesNotThrowAndContributesZeroBytes() throws IOException {
        // A lone high surrogate at end of stream is deferred (0 bytes) waiting for its pair,
        // which never arrives; reading it must not throw.
        final ExtendedBufferedReader br = createReaderWithByteTracking("a\ud800");
        try {
            assertEquals('a', br.read());
            assertEquals(1, br.getBytesRead());
            assertEquals('\ud800', br.read());
            assertEquals(1, br.getBytesRead());
            assertEquals(EOF, br.read());
        } finally {
            br.close();
        }
    }

    @Test
    void testReadLineWithLoneTrailingCarriageReturn() throws IOException {
        final ExtendedBufferedReader br = createReader("a\rb");
        try {
            assertEquals("a", br.readLine());
            assertEquals(1, br.getLineNumber());
            assertEquals("b", br.readLine());
            assertNull(br.readLine());
        } finally {
            br.close();
        }
    }

    @Test
    void testPeekDoesNotAdvancePositionOrLastChar() throws IOException {
        final ExtendedBufferedReader br = createReader("xy");
        try {
            assertEquals(UNDEFINED, br.getLastChar());
            assertEquals(0, br.getPosition());
            assertEquals('x', br.peek());
            assertEquals(UNDEFINED, br.getLastChar());
            assertEquals(0, br.getPosition());
            assertEquals('x', br.peek());
            assertEquals(0, br.getPosition());
        } finally {
            br.close();
        }
    }

    @Test
    void testPeekBetweenMarkAndResetMovesMarkToPeekPoint() throws IOException {
        // peek() is implemented in terms of this class's own overridden mark()/read()/reset(),
        // so calling it after an explicit mark() overwrites the previously saved mark state.
        final ExtendedBufferedReader br = createReader("abcdef");
        try {
            br.mark(10); // mark at position 0, lastChar UNDEFINED
            br.read(); // 'a' -> position 1
            br.read(); // 'b' -> position 2
            assertEquals('c', br.peek());
            assertEquals('b', br.getLastChar());
            assertEquals(2, br.getPosition());

            // reset() now restores to the point captured by peek(), not the original mark().
            br.reset();
            assertEquals('b', br.getLastChar());
            assertEquals(2, br.getPosition());
            assertEquals('c', br.read());
        } finally {
            br.close();
        }
    }

    @Test
    void testGetLineNumberAccountsForPartialLineBeforeTerminator() throws IOException {
        final ExtendedBufferedReader br = createReader("ab\ncd");
        try {
            assertEquals(0, br.getLineNumber());
            br.read(); // 'a'
            assertEquals(1, br.getLineNumber()); // mid-line: counter + 1
            br.read(); // 'b'
            assertEquals(1, br.getLineNumber());
            br.read(); // '\n'
            assertEquals(1, br.getLineNumber()); // right at EOL: counter is accurate
            br.read(); // 'c'
            assertEquals(2, br.getLineNumber());
        } finally {
            br.close();
        }
    }
}
