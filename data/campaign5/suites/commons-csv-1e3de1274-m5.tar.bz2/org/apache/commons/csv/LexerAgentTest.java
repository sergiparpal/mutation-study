/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.apache.commons.io.IOUtils.EOF;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link Lexer}.
 */
class LexerAgentTest {

    private static Lexer createLexer(final String input, final CSVFormat format) {
        return new Lexer(format, new ExtendedBufferedReader(new StringReader(input)));
    }

    @Test
    void testSimpleTokensAndEof() throws IOException {
        final Lexer lexer = createLexer("a,b,c\n", CSVFormat.DEFAULT);
        try {
            Token token = lexer.nextToken(new Token());
            assertEquals(Token.Type.TOKEN, token.type);
            assertEquals("a", token.content.toString());

            token = lexer.nextToken(new Token());
            assertEquals(Token.Type.TOKEN, token.type);
            assertEquals("b", token.content.toString());

            token = lexer.nextToken(new Token());
            assertEquals(Token.Type.EORECORD, token.type);
            assertEquals("c", token.content.toString());

            token = lexer.nextToken(new Token());
            assertEquals(Token.Type.EOF, token.type);
            assertFalse(token.isReady);
        } finally {
            lexer.close();
        }
    }

    @Test
    void testEmptyInputReturnsEofImmediately() throws IOException {
        final Lexer lexer = createLexer("", CSVFormat.DEFAULT);
        try {
            final Token token = lexer.nextToken(new Token());
            assertEquals(Token.Type.EOF, token.type);
            assertEquals(0, token.content.length());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testLastTokenAtEofWithoutTrailingNewlineIsReady() throws IOException {
        final Lexer lexer = createLexer("a,b", CSVFormat.DEFAULT);
        try {
            lexer.nextToken(new Token()); // "a"
            final Token token = lexer.nextToken(new Token()); // "b" then EOF
            assertEquals(Token.Type.EOF, token.type);
            assertEquals("b", token.content.toString());
            assertTrue(token.isReady);
        } finally {
            lexer.close();
        }
    }

    @Test
    void testQuotedTokenWithDoubledQuote() throws IOException {
        final Lexer lexer = createLexer("\"a\"\"b\",c\n", CSVFormat.DEFAULT);
        try {
            final Token token = lexer.nextToken(new Token());
            assertEquals(Token.Type.TOKEN, token.type);
            assertEquals("a\"b", token.content.toString());
            assertTrue(token.isQuoted);
        } finally {
            lexer.close();
        }
    }

    @Test
    void testUnterminatedQuoteThrowsCsvException() throws IOException {
        final Lexer lexer = createLexer("\"a,b", CSVFormat.DEFAULT);
        try {
            assertThrows(CSVException.class, new org.junit.jupiter.api.function.Executable() {
                @Override
                public void execute() throws Throwable {
                    lexer.nextToken(new Token());
                }
            });
        } finally {
            lexer.close();
        }
    }

    @Test
    void testUnterminatedQuoteWithLenientEofReturnsEof() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setLenientEof(true).get();
        final Lexer lexer = createLexer("\"a,b", format);
        try {
            final Token token = lexer.nextToken(new Token());
            assertEquals(Token.Type.EOF, token.type);
            assertTrue(token.isReady);
            assertEquals("a,b", token.content.toString());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testInvalidCharAfterEncapsulatedTokenThrowsCsvException() throws IOException {
        final Lexer lexer = createLexer("\"a\"b,c\n", CSVFormat.DEFAULT);
        try {
            assertThrows(CSVException.class, new org.junit.jupiter.api.function.Executable() {
                @Override
                public void execute() throws Throwable {
                    lexer.nextToken(new Token());
                }
            });
        } finally {
            lexer.close();
        }
    }

    @Test
    void testTrailingDataAllowedAfterEncapsulatedToken() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingData(true).get();
        final Lexer lexer = createLexer("\"a\"bc,d\n", format);
        try {
            final Token token = lexer.nextToken(new Token());
            assertEquals(Token.Type.TOKEN, token.type);
            assertEquals("abc", token.content.toString());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testCommentLineIsTrimmedAndTyped() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final Lexer lexer = createLexer("#  a comment  \na,b\n", format);
        try {
            final Token token = lexer.nextToken(new Token());
            assertEquals(Token.Type.COMMENT, token.type);
            assertEquals("a comment", token.content.toString());

            final Token next = lexer.nextToken(new Token());
            assertEquals(Token.Type.TOKEN, next.type);
            assertEquals("a", next.content.toString());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testCommentAtEofReturnsEof() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final Lexer lexer = createLexer("#", format);
        try {
            final Token token = lexer.nextToken(new Token());
            assertEquals(Token.Type.EOF, token.type);
        } finally {
            lexer.close();
        }
    }

    @Test
    void testIgnoreEmptyLinesSkipsBlankLines() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreEmptyLines(true).get();
        final Lexer lexer = createLexer("\n\n\na,b\n", format);
        try {
            final Token token = lexer.nextToken(new Token());
            assertEquals(Token.Type.TOKEN, token.type);
            assertEquals("a", token.content.toString());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testIgnoreEmptyLinesAllBlankReturnsEof() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreEmptyLines(true).get();
        final Lexer lexer = createLexer("\n\n\n", format);
        try {
            final Token token = lexer.nextToken(new Token());
            assertEquals(Token.Type.EOF, token.type);
        } finally {
            lexer.close();
        }
    }

    @Test
    void testNotIgnoringEmptyLinesProducesEmptyRecords() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreEmptyLines(false).get();
        final Lexer lexer = createLexer("\na\n", format);
        try {
            final Token token = lexer.nextToken(new Token());
            assertEquals(Token.Type.EORECORD, token.type);
            assertEquals(0, token.content.length());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testIgnoreSurroundingSpacesTrimsToken() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreSurroundingSpaces(true).get();
        final Lexer lexer = createLexer("  a  ,b\n", format);
        try {
            final Token token = lexer.nextToken(new Token());
            assertEquals(Token.Type.TOKEN, token.type);
            assertEquals("a", token.content.toString());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testEscapeHandlingInSimpleToken() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').setQuote(null).get();
        final Lexer lexer = createLexer("a\\,b,c\n", format);
        try {
            final Token token = lexer.nextToken(new Token());
            assertEquals(Token.Type.TOKEN, token.type);
            assertEquals("a,b", token.content.toString());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testReadEscapeKnownSequences() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        Lexer lexer = createLexer("r", format);
        try {
            assertEquals(Constants.CR, lexer.readEscape());
        } finally {
            lexer.close();
        }
        lexer = createLexer("n", format);
        try {
            assertEquals(Constants.LF, lexer.readEscape());
        } finally {
            lexer.close();
        }
        lexer = createLexer("t", format);
        try {
            assertEquals(Constants.TAB, lexer.readEscape());
        } finally {
            lexer.close();
        }
        lexer = createLexer("b", format);
        try {
            assertEquals(Constants.BACKSPACE, lexer.readEscape());
        } finally {
            lexer.close();
        }
        lexer = createLexer("f", format);
        try {
            assertEquals(Constants.FF, lexer.readEscape());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testReadEscapeMetaCharReturnsItself() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').setQuote('"').get();
        final Lexer lexer = createLexer("\"", format);
        try {
            assertEquals('"', lexer.readEscape());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testReadEscapeUnexpectedCharReturnsEof() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').setQuote('"').get();
        final Lexer lexer = createLexer("x", format);
        try {
            assertEquals(EOF, lexer.readEscape());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testReadEscapeAtEofThrowsCsvException() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer("", format);
        try {
            assertThrows(CSVException.class, new org.junit.jupiter.api.function.Executable() {
                @Override
                public void execute() throws Throwable {
                    lexer.readEscape();
                }
            });
        } finally {
            lexer.close();
        }
    }

    @Test
    void testIsDelimiterSingleChar() throws IOException {
        final Lexer lexer = createLexer(",x", CSVFormat.DEFAULT);
        try {
            assertTrue(lexer.isDelimiter(','));
            assertFalse(lexer.isDelimiter('x'));
        } finally {
            lexer.close();
        }
    }

    @Test
    void testIsDelimiterMultiCharMatches() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        final Lexer lexer = createLexer(":rest", format);
        try {
            assertTrue(lexer.isDelimiter(':'));
        } finally {
            lexer.close();
        }
    }

    @Test
    void testIsDelimiterMultiCharNoMatch() throws IOException {
        // The first delimiter char is passed in as already consumed; the stream holds what follows it.
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        final Lexer lexer = createLexer("x", format);
        try {
            assertFalse(lexer.isDelimiter(':'));
        } finally {
            lexer.close();
        }
    }

    @Test
    void testIsEscapeDelimiter() throws IOException {
        // For delimiter "[|]" and escape '!', the escaped form is "![!|!]"; the leading '!' is
        // already consumed by the caller, so the stream here holds "[!|!]".
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("[|]").setEscape('!').get();
        final Lexer lexer = createLexer("[!|!]rest", format);
        try {
            assertTrue(lexer.isEscapeDelimiter());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testIsEscapeDelimiterFalseWhenNoMatch() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("[|]").setEscape('!').get();
        final Lexer lexer = createLexer("abcde", format);
        try {
            assertFalse(lexer.isEscapeDelimiter());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testIsEndOfFile() {
        final Lexer lexer = createLexer("x", CSVFormat.DEFAULT);
        try {
            assertTrue(lexer.isEndOfFile(EOF));
            assertFalse(lexer.isEndOfFile('x'));
        } finally {
            closeQuietly(lexer);
        }
    }

    @Test
    void testIsEscapeDefaultDisabled() {
        final Lexer lexer = createLexer("x", CSVFormat.DEFAULT);
        try {
            assertFalse(lexer.isEscape('\\'));
        } finally {
            closeQuietly(lexer);
        }
    }

    @Test
    void testIsQuoteChar() {
        final Lexer lexer = createLexer("x", CSVFormat.DEFAULT);
        try {
            assertTrue(lexer.isQuoteChar('"'));
            assertFalse(lexer.isQuoteChar('\''));
        } finally {
            closeQuietly(lexer);
        }
    }

    @Test
    void testIsCommentStartDefaultDisabled() {
        final Lexer lexer = createLexer("x", CSVFormat.DEFAULT);
        try {
            assertFalse(lexer.isCommentStart('#'));
        } finally {
            closeQuietly(lexer);
        }
    }

    @Test
    void testIsStartOfLine() {
        final Lexer lexer = createLexer("x", CSVFormat.DEFAULT);
        try {
            assertTrue(lexer.isStartOfLine(Constants.LF));
            assertTrue(lexer.isStartOfLine(Constants.CR));
            assertTrue(lexer.isStartOfLine(Constants.UNDEFINED));
            assertFalse(lexer.isStartOfLine('a'));
        } finally {
            closeQuietly(lexer);
        }
    }

    @Test
    void testReadEndOfLineLf() throws IOException {
        final Lexer lexer = createLexer("\n", CSVFormat.DEFAULT);
        try {
            assertNull(lexer.getFirstEol());
            assertTrue(lexer.readEndOfLine(Constants.LF));
            assertEquals("\n", lexer.getFirstEol());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testReadEndOfLineCr() throws IOException {
        final Lexer lexer = createLexer("x", CSVFormat.DEFAULT);
        try {
            assertTrue(lexer.readEndOfLine(Constants.CR));
            assertEquals("\r", lexer.getFirstEol());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testReadEndOfLineCrLfCollapsesToOneEol() throws IOException {
        final Lexer lexer = createLexer("\n", CSVFormat.DEFAULT);
        try {
            assertTrue(lexer.readEndOfLine(Constants.CR));
            assertEquals("\r\n", lexer.getFirstEol());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testReadEndOfLineFalseForOrdinaryChar() throws IOException {
        final Lexer lexer = createLexer("x", CSVFormat.DEFAULT);
        try {
            assertFalse(lexer.readEndOfLine('a'));
            assertNull(lexer.getFirstEol());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testTrimTrailingSpaces() {
        final Lexer lexer = createLexer("x", CSVFormat.DEFAULT);
        try {
            final StringBuilder sb = new StringBuilder("abc   ");
            lexer.trimTrailingSpaces(sb);
            assertEquals("abc", sb.toString());

            final StringBuilder noTrailing = new StringBuilder("abc");
            lexer.trimTrailingSpaces(noTrailing);
            assertEquals("abc", noTrailing.toString());

            final StringBuilder allSpaces = new StringBuilder("   ");
            lexer.trimTrailingSpaces(allSpaces);
            assertEquals("", allSpaces.toString());
        } finally {
            closeQuietly(lexer);
        }
    }

    @Test
    void testCloseAndIsClosed() throws IOException {
        final Lexer lexer = createLexer("a,b\n", CSVFormat.DEFAULT);
        assertFalse(lexer.isClosed());
        lexer.close();
        assertTrue(lexer.isClosed());
    }

    @Test
    void testPositionAndLineNumberTracking() throws IOException {
        final Lexer lexer = createLexer("ab,cd\nef\n", CSVFormat.DEFAULT);
        try {
            assertEquals(0, lexer.getCharacterPosition());
            lexer.nextToken(new Token());
            assertTrue(lexer.getCharacterPosition() > 0);
            lexer.nextToken(new Token());
            assertEquals(1, lexer.getCurrentLineNumber());
        } finally {
            lexer.close();
        }
    }

    @Test
    void testBytesReadWithoutCharsetTrackingIsZero() throws IOException {
        final Lexer lexer = createLexer("abc\n", CSVFormat.DEFAULT);
        try {
            lexer.nextToken(new Token());
            assertEquals(0, lexer.getBytesRead());
        } finally {
            lexer.close();
        }
    }

    private static void closeQuietly(final Lexer lexer) {
        try {
            lexer.close();
        } catch (final IOException e) {
            // ignore for cleanup in tests that do not exercise reading
        }
    }
}
