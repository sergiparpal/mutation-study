/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.ClassUtils.Interfaces;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link MethodUtils}.
 */
class MethodUtilsAgentTest {

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    private @interface Marker {
    }

    public interface PublicInterface {
        String greet();
    }

    static class PackagePrivateImpl implements PublicInterface {
        @Override
        public String greet() {
            return "impl";
        }
    }

    public static class AnnotatedParent {
        @Marker
        public void annotated() {
            // empty
        }

        public void plain() {
            // empty
        }
    }

    public static class AnnotatedChild extends AnnotatedParent {
        @Override
        public void annotated() {
            // empty
        }
    }

    public static class AnnotatedWithPrivate {
        @Marker
        private void hidden() {
            // empty
        }

        @Marker
        public void visible() {
            // empty
        }
    }

    public static class AmbiguousOverloads {
        public String ambig(final Number n, final Integer i) {
            return "NumberInteger";
        }

        public String ambig(final Integer i, final Number n) {
            return "IntegerNumber";
        }
    }

    public static class OverloadHolder {
        public String call(final Number n) {
            return "Number:" + n;
        }
    }

    public static class HierarchyParent {
        public String foo(final String s) {
            return "parent:" + s;
        }
    }

    public static class HierarchyChild extends HierarchyParent {
        @Override
        public String foo(final String s) {
            return "child:" + s;
        }
    }

    public static class InvokeTarget {
        public String greetingPublic(final String name) {
            return "Hello " + name;
        }

        @SuppressWarnings("unused")
        private String greetingPrivate(final String name) {
            return "Hi " + name;
        }

        public static String staticGreeting(final String name) {
            return "StaticHello " + name;
        }

        public String requireName(final String name) {
            return name.toUpperCase();
        }

        public String join(final String sep, final String... parts) {
            final StringBuilder sb = new StringBuilder();
            for (int i = 0; i < parts.length; i++) {
                if (i > 0) {
                    sb.append(sep);
                }
                sb.append(parts[i]);
            }
            return sb.toString();
        }
    }

    @Test
    void testGetAccessibleMethod_ClassMethod() throws Exception {
        final Method implMethod = PackagePrivateImpl.class.getMethod("greet");
        final Method accessible = MethodUtils.getAccessibleMethod(PackagePrivateImpl.class, implMethod);
        assertNotNull(accessible);
        assertEquals(PublicInterface.class, accessible.getDeclaringClass());
        assertNull(MethodUtils.getAccessibleMethod(PackagePrivateImpl.class, (Method) null));
    }

    @Test
    void testGetAccessibleMethod_ClassNameParams() throws Exception {
        final Method accessible = MethodUtils.getAccessibleMethod(PackagePrivateImpl.class, "greet");
        assertNotNull(accessible);
        assertEquals(PublicInterface.class, accessible.getDeclaringClass());
        assertNull(MethodUtils.getAccessibleMethod(PackagePrivateImpl.class, "doesNotExist"));
    }

    @Test
    void testGetAccessibleMethod_MethodOnly() throws Exception {
        assertNull(MethodUtils.getAccessibleMethod((Method) null));
        final Method publicMethod = InvokeTarget.class.getMethod("greetingPublic", String.class);
        final Method accessible = MethodUtils.getAccessibleMethod(publicMethod);
        assertEquals(publicMethod, accessible);
    }

    @Test
    void testGetAnnotation() throws Exception {
        final Method childMethod = AnnotatedChild.class.getMethod("annotated");
        assertNull(MethodUtils.getAnnotation(childMethod, Marker.class, false, false));
        final Marker found = MethodUtils.getAnnotation(childMethod, Marker.class, true, false);
        assertNotNull(found);
        final Method plainMethod = AnnotatedChild.class.getMethod("plain");
        assertNull(MethodUtils.getAnnotation(plainMethod, Marker.class, true, false));
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.getAnnotation(null, Marker.class, true, false);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.getAnnotation(childMethod, null, true, false);
            }
        });
    }

    @Test
    void testGetMatchingAccessibleMethod() {
        final Method matched = MethodUtils.getMatchingAccessibleMethod(OverloadHolder.class, "call", Integer.class);
        assertNotNull(matched);
        assertEquals("call", matched.getName());
        assertEquals(Number.class, matched.getParameterTypes()[0]);
        assertNull(MethodUtils.getMatchingAccessibleMethod(OverloadHolder.class, "doesNotExist"));
    }

    @Test
    void testGetMatchingMethod_ExactAndAssignable() {
        final Method exact = MethodUtils.getMatchingMethod(OverloadHolder.class, "call", Number.class);
        assertNotNull(exact);
        assertEquals(Number.class, exact.getParameterTypes()[0]);
        final Method assignable = MethodUtils.getMatchingMethod(OverloadHolder.class, "call", Integer.class);
        assertNotNull(assignable);
        assertEquals(Number.class, assignable.getParameterTypes()[0]);
    }

    @Test
    void testGetMatchingMethod_NoMatch() {
        assertNull(MethodUtils.getMatchingMethod(OverloadHolder.class, "call", String.class));
    }

    @Test
    void testGetMatchingMethod_NullClassThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.getMatchingMethod(null, "call", Number.class);
            }
        });
    }

    @Test
    void testGetMatchingMethod_EmptyNameThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.getMatchingMethod(OverloadHolder.class, "", Number.class);
            }
        });
    }

    @Test
    void testGetMatchingMethod_AmbiguousThrows() {
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.getMatchingMethod(AmbiguousOverloads.class, "ambig", Integer.class, Integer.class);
            }
        });
    }

    @Test
    void testGetMethodObject() {
        assertNull(MethodUtils.getMethodObject(null, "greet"));
        assertNull(MethodUtils.getMethodObject(PackagePrivateImpl.class, null));
        assertNull(MethodUtils.getMethodObject(PackagePrivateImpl.class, "doesNotExist"));
        final Method method = MethodUtils.getMethodObject(PackagePrivateImpl.class, "greet");
        assertNotNull(method);
        assertEquals("greet", method.getName());
    }

    @Test
    void testGetMethodsListWithAnnotation() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.getMethodsListWithAnnotation(null, Marker.class);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.getMethodsListWithAnnotation(AnnotatedParent.class, null);
            }
        });
        final List<Method> noSupers = MethodUtils.getMethodsListWithAnnotation(AnnotatedChild.class, Marker.class);
        assertTrue(noSupers.isEmpty());
        final List<Method> withSupers = MethodUtils.getMethodsListWithAnnotation(AnnotatedChild.class, Marker.class, true, false);
        assertEquals(1, withSupers.size());
        assertEquals(AnnotatedParent.class, withSupers.get(0).getDeclaringClass());
        final List<Method> publicOnly = MethodUtils.getMethodsListWithAnnotation(AnnotatedWithPrivate.class, Marker.class, false, false);
        assertEquals(1, publicOnly.size());
        assertEquals("visible", publicOnly.get(0).getName());
        final List<Method> includingPrivate = MethodUtils.getMethodsListWithAnnotation(AnnotatedWithPrivate.class, Marker.class, false, true);
        assertEquals(2, includingPrivate.size());
    }

    @Test
    void testGetMethodsWithAnnotation() {
        final Method[] methods = MethodUtils.getMethodsWithAnnotation(AnnotatedWithPrivate.class, Marker.class, false, true);
        assertEquals(2, methods.length);
    }

    @Test
    void testGetOverrideHierarchy() throws Exception {
        final Method childMethod = HierarchyChild.class.getMethod("foo", String.class);
        final Set<Method> hierarchy = MethodUtils.getOverrideHierarchy(childMethod, Interfaces.EXCLUDE);
        assertEquals(2, hierarchy.size());
        final Iterator<Method> iterator = hierarchy.iterator();
        assertEquals(HierarchyChild.class, iterator.next().getDeclaringClass());
        assertEquals(HierarchyParent.class, iterator.next().getDeclaringClass());
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.getOverrideHierarchy(null, Interfaces.EXCLUDE);
            }
        });
    }

    @Test
    void testInvokeExactMethod() throws Exception {
        final InvokeTarget target = new InvokeTarget();
        assertEquals("Hello World", MethodUtils.invokeExactMethod(target, "greetingPublic", "World"));
        assertEquals("Hello X", MethodUtils.invokeExactMethod(target, "greetingPublic", new Object[] {"X"}, new Class<?>[] {String.class}));
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeExactMethod(target, "greetingPublic", Integer.valueOf(1));
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeExactMethod(null, "greetingPublic", "World");
            }
        });
    }

    @Test
    void testInvokeExactStaticMethod() throws Exception {
        assertEquals("StaticHello Static", MethodUtils.invokeExactStaticMethod(InvokeTarget.class, "staticGreeting", "Static"));
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeExactStaticMethod(InvokeTarget.class, "doesNotExist", "Static");
            }
        });
    }

    @Test
    void testInvokeMethod_ForceAccess() throws Exception {
        final InvokeTarget target = new InvokeTarget();
        assertEquals("Hi Secret", MethodUtils.invokeMethod(target, true, "greetingPrivate", "Secret"));
        assertEquals("Hello Open", MethodUtils.invokeMethod(target, false, "greetingPublic", "Open"));
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeMethod(target, false, "greetingPrivate", "Secret");
            }
        });
    }

    @Test
    void testInvokeMethod_NoArgs() throws Exception {
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeMethod(new InvokeTarget(), "doesNotExist");
            }
        });
    }

    @Test
    void testInvokeMethod_Varargs() throws Exception {
        final InvokeTarget target = new InvokeTarget();
        final Object result = MethodUtils.invokeMethod(target, "join", new Object[] {"-", "a", "b", "c"});
        assertEquals("a-b-c", result);
    }

    @Test
    void testInvokeMethod_InvocationTargetException() {
        final InvokeTarget target = new InvokeTarget();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                try {
                    MethodUtils.invokeMethod(target, "requireName", (Object) null);
                } catch (final InvocationTargetException e) {
                    throw e.getTargetException();
                }
            }
        });
    }

    @Test
    void testInvokeStaticMethod() throws Exception {
        assertEquals("StaticHello Via", MethodUtils.invokeStaticMethod(InvokeTarget.class, "staticGreeting", "Via"));
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                MethodUtils.invokeStaticMethod(InvokeTarget.class, "doesNotExist", "Via");
            }
        });
    }

    @Test
    void testConstructorIsPublic() {
        assertNotNull(new MethodUtils());
    }
}
