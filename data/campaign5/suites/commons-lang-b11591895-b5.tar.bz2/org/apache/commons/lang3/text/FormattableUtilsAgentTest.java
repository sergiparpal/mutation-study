/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Formattable;
import java.util.FormattableFlags;
import java.util.Formatter;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link FormattableUtils}.
 */
@Deprecated
public class FormattableUtilsAgentTest {

    /**
     * A minimal {@link Formattable} that records the arguments it receives
     * and delegates to {@link FormattableUtils#append} for the actual output.
     */
    private static final class RecordingFormattable implements Formattable {
        private final String value;
        private int capturedFlags;
        private int capturedWidth;
        private int capturedPrecision;
        private boolean called;

        RecordingFormattable(final String value) {
            this.value = value;
        }

        @Override
        public void formatTo(final Formatter formatter, final int flags, final int width, final int precision) {
            this.called = true;
            this.capturedFlags = flags;
            this.capturedWidth = width;
            this.capturedPrecision = precision;
            FormattableUtils.append(value, formatter, flags, width, precision);
        }
    }

    @Test
    public void testAppendNoWidthNoPrecisionReturnsUnchangedText() {
        final Formatter formatter = new Formatter(new StringBuilder());
        final Formatter result = FormattableUtils.append("abc", formatter, 0, -1, -1);
        assertSame(formatter, result);
        assertEquals("abc", result.toString());
    }

    @Test
    public void testAppendRightJustifyPadsWithSpacesOnLeft() {
        final Formatter formatter = new Formatter(new StringBuilder());
        final Formatter result = FormattableUtils.append("ab", formatter, 0, 5, -1);
        assertEquals("   ab", result.toString());
    }

    @Test
    public void testAppendLeftJustifyPadsWithSpacesOnRight() {
        final Formatter formatter = new Formatter(new StringBuilder());
        final Formatter result = FormattableUtils.append("ab", formatter, FormattableFlags.LEFT_JUSTIFY, 5, -1);
        assertEquals("ab   ", result.toString());
    }

    @Test
    public void testAppendCustomPadChar() {
        final Formatter formatter = new Formatter(new StringBuilder());
        final Formatter result = FormattableUtils.append("ab", formatter, FormattableFlags.LEFT_JUSTIFY, 5, -1, '*');
        assertEquals("ab***", result.toString());
    }

    @Test
    public void testAppendWidthSmallerThanSeqLengthDoesNoPadding() {
        final Formatter formatter = new Formatter(new StringBuilder());
        final Formatter result = FormattableUtils.append("hello world", formatter, 0, 3, -1);
        assertEquals("hello world", result.toString());
    }

    @Test
    public void testAppendWidthEqualToSeqLengthDoesNoPadding() {
        final Formatter formatter = new Formatter(new StringBuilder());
        final Formatter result = FormattableUtils.append("abcde", formatter, 0, 5, -1);
        assertEquals("abcde", result.toString());
    }

    @Test
    public void testAppendPrecisionTruncatesWithoutEllipsis() {
        final Formatter formatter = new Formatter(new StringBuilder());
        final Formatter result = FormattableUtils.append("hello world", formatter, 0, -1, 5);
        assertEquals("hello", result.toString());
    }

    @Test
    public void testAppendPrecisionGreaterThanLengthLeavesTextUnchanged() {
        final Formatter formatter = new Formatter(new StringBuilder());
        final Formatter result = FormattableUtils.append("abc", formatter, 0, -1, 100);
        assertEquals("abc", result.toString());
    }

    @Test
    public void testAppendPrecisionEqualToLengthLeavesTextUnchanged() {
        final Formatter formatter = new Formatter(new StringBuilder());
        final Formatter result = FormattableUtils.append("abc", formatter, 0, -1, 3);
        assertEquals("abc", result.toString());
    }

    @Test
    public void testAppendNegativePrecisionBypassesTruncation() {
        final Formatter formatter = new Formatter(new StringBuilder());
        final Formatter result = FormattableUtils.append("hello world", formatter, 0, -1, -1, "...");
        assertEquals("hello world", result.toString());
    }

    @Test
    public void testAppendWithEllipsisTruncation() {
        final Formatter formatter = new Formatter(new StringBuilder());
        final Formatter result = FormattableUtils.append("Hello World", formatter, 0, -1, 5, "...");
        assertEquals("He...", result.toString());
    }

    @Test
    public void testAppendWithNullEllipsisHardTruncates() {
        final Formatter formatter = new Formatter(new StringBuilder());
        final Formatter result = FormattableUtils.append("Hello World", formatter, 0, -1, 5, (CharSequence) null);
        assertEquals("Hello", result.toString());
    }

    @Test
    public void testAppendEllipsisExactlyEqualToPrecisionIsAllowed() {
        final Formatter formatter = new Formatter(new StringBuilder());
        final Formatter result = FormattableUtils.append("Hello World", formatter, 0, -1, 3, "...");
        assertEquals("...", result.toString());
    }

    @Test
    public void testAppendEllipsisLongerThanPrecisionThrows() {
        final Formatter formatter = new Formatter(new StringBuilder());
        assertThrows(IllegalArgumentException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() {
                        FormattableUtils.append("Hello World", formatter, 0, -1, 2, "...");
                    }
                });
    }

    @Test
    public void testAppendPrecisionZeroWithNoEllipsisProducesEmptyBeforePadding() {
        final Formatter formatter = new Formatter(new StringBuilder());
        final Formatter result = FormattableUtils.append("abc", formatter, 0, 4, 0);
        assertEquals("    ", result.toString());
    }

    @Test
    public void testAppendAndPadWithEllipsisCombined() {
        final Formatter formatter = new Formatter(new StringBuilder());
        final Formatter result = FormattableUtils.append("Hello World", formatter, FormattableFlags.LEFT_JUSTIFY, 8, 5, '-', "...");
        assertEquals("He...---", result.toString());
    }

    @Test
    public void testToStringUsesFormatToWithDefaultFlagsWidthAndPrecision() {
        final RecordingFormattable formattable = new RecordingFormattable("value");
        final String result = FormattableUtils.toString(formattable);
        assertEquals("value", result);
        assertTrueCalled(formattable);
        assertEquals(0, formattable.capturedFlags);
        assertEquals(-1, formattable.capturedWidth);
        assertEquals(-1, formattable.capturedPrecision);
    }

    private static void assertTrueCalled(final RecordingFormattable formattable) {
        if (!formattable.called) {
            throw new AssertionError("formatTo was never invoked");
        }
    }

    @Test
    public void testConstructorIsPublicAndUsable() {
        final FormattableUtils instance = new FormattableUtils();
        assertNotNull(instance);
    }
}
