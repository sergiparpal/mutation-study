/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

/**
 * Self-contained tests for {@link CSVParser}.
 */
public class CSVParserAgentTest {

    @TempDir
    public Path tempDir;

    @Test
    public void testParseStringBasicRecords() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b,c\n1,2,3\n", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("b", records.get(0).get(1));
            assertEquals("c", records.get(0).get(2));
            assertEquals(3, records.get(1).size());
            assertEquals("3", records.get(1).get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetRecordNumberIncreasesPerRecord() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n2\n3\n", CSVFormat.DEFAULT);
        try {
            assertEquals(0, parser.getRecordNumber());
            final Iterator<CSVRecord> it = parser.iterator();
            assertEquals(1, it.next().getRecordNumber());
            assertEquals(1, parser.getRecordNumber());
            assertEquals(2, it.next().getRecordNumber());
            assertEquals(3, it.next().getRecordNumber());
            assertFalse(it.hasNext());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testHeaderMapAndNamesWithExplicitHeader() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("X", "Y", "Z").build();
        final CSVParser parser = CSVParser.parse("1,2,3\n4,5,6\n", format);
        try {
            final Map<String, Integer> headerMap = parser.getHeaderMap();
            assertEquals(Integer.valueOf(0), headerMap.get("X"));
            assertEquals(Integer.valueOf(1), headerMap.get("Y"));
            assertEquals(Integer.valueOf(2), headerMap.get("Z"));
            assertEquals(3, headerMap.size());
            assertEquals(3, parser.getHeaderNames().size());
            assertEquals("X", parser.getHeaderNames().get(0));
            // Since header is explicit and skipHeaderRecord defaults to false, the first data line
            // "1,2,3" is still a record (not consumed as header).
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("1", records.get(0).get("X"));
            assertEquals("6", records.get(1).get("Z"));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testHeaderFromFirstLineWhenHeaderArrayEmpty() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(new String[0]).build();
        final CSVParser parser = CSVParser.parse("name,age\nbob,42\n", format);
        try {
            assertEquals(2, parser.getHeaderNames().size());
            assertEquals("name", parser.getHeaderNames().get(0));
            assertEquals("age", parser.getHeaderNames().get(1));
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("bob", records.get(0).get("name"));
            assertEquals("42", records.get(0).get("age"));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetHeaderMapReturnsNullWhenNoHeaderDefined() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n", CSVFormat.DEFAULT);
        try {
            assertNull(parser.getHeaderMap());
            assertTrue(parser.getHeaderNames().isEmpty());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testDuplicateHeaderNameFromFirstLineThrowsWhenDisallowed() {
        // Reading the header from the first data line bypasses CSVFormat's own build-time
        // duplicate check, so CSVParser.createHeaders() must enforce it itself.
        final CSVFormat format = CSVFormat.DEFAULT.builder()
                .setHeader(new String[0])
                .setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW)
                .build();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse("A,A\n1,2\n", format);
            }
        });
    }

    @Test
    public void testMissingHeaderNameThrowsByDefault() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("A", "").setSkipHeaderRecord(true).build();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse("1,2\n", format);
            }
        });
    }

    @Test
    public void testMissingHeaderNameAllowedWhenConfigured() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder()
                .setHeader("A", "")
                .setAllowMissingColumnNames(true)
                .setSkipHeaderRecord(true)
                .build();
        final CSVParser parser = CSVParser.parse("A,\n1,2\n", format);
        try {
            // The blank header name is still recorded in the header names/map; only validation is relaxed.
            assertEquals(2, parser.getHeaderNames().size());
            assertEquals("A", parser.getHeaderNames().get(0));
            assertEquals("", parser.getHeaderNames().get(1));
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("1", records.get(0).get("A"));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testIteratorNextThrowsWhenExhausted() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            assertTrue(it.hasNext());
            it.next();
            assertFalse(it.hasNext());
            assertThrows(NoSuchElementException.class, new org.junit.jupiter.api.function.Executable() {
                @Override
                public void execute() {
                    it.next();
                }
            });
        } finally {
            parser.close();
        }
    }

    @Test
    public void testIteratorRemoveUnsupported() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
                @Override
                public void execute() {
                    it.remove();
                }
            });
        } finally {
            parser.close();
        }
    }

    @Test
    public void testCloseMakesParserReportClosedAndIteratorEmpty() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n2\n", CSVFormat.DEFAULT);
        assertFalse(parser.isClosed());
        parser.close();
        assertTrue(parser.isClosed());
        final Iterator<CSVRecord> it = parser.iterator();
        assertFalse(it.hasNext());
        assertThrows(NoSuchElementException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                it.next();
            }
        });
    }

    @Test
    public void testEmptyInputProducesNoRecords() throws IOException {
        final CSVParser parser = CSVParser.parse("", CSVFormat.DEFAULT);
        try {
            assertTrue(parser.getRecords().isEmpty());
            assertEquals(0, parser.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testTrailingDelimiterDropsEmptyLastField() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).build();
        final CSVParser parser = CSVParser.parse("a,b,\n", format);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals(2, records.get(0).size());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testQuotedEmptyFieldKeptEvenWithTrailingDelimiter() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).build();
        final CSVParser parser = CSVParser.parse("a,b,\"\"\n", format);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            // Quoted empty field is a real value, must not be dropped as a trailing delimiter artifact.
            assertEquals(3, records.get(0).size());
            assertEquals("", records.get(0).get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testNullStringMapping() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").build();
        final CSVParser parser = CSVParser.parse("a,NULL,c\n", format);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertNull(records.get(0).get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testInvalidQuotedInputThrowsCSVException() {
        // A quoted field followed directly by more characters before the delimiter is invalid.
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuote('"').build();
        final CSVParser parser;
        try {
            parser = CSVParser.parse("\"a\"b,c\n", format);
        } catch (final IOException e) {
            throw new AssertionError(e);
        }
        try {
            final java.io.UncheckedIOException thrown = assertThrows(java.io.UncheckedIOException.class,
                    new org.junit.jupiter.api.function.Executable() {
                @Override
                public void execute() throws Throwable {
                    parser.getRecords();
                }
            });
            assertTrue(thrown.getCause() instanceof CSVException);
        } finally {
            try {
                parser.close();
            } catch (final IOException ignored) {
                // ignore close failure in test cleanup
            }
        }
    }

    @Test
    public void testParseNullFileThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse((File) null, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    public void testParseNullPathThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse((Path) null, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    public void testParseNullStringThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse((String) null, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    public void testParseFileRoundTrip() throws IOException {
        final File file = tempDir.resolve("data.csv").toFile();
        Files.write(file.toPath(), "h1,h2\nv1,v2\n".getBytes(StandardCharsets.UTF_8));
        final CSVParser parser = CSVParser.parse(file, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("v1", records.get(1).get(0));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testDeprecatedConstructorWithOffsetsAssignsRecordNumbers() throws IOException {
        @SuppressWarnings("deprecation")
        final CSVParser parser = new CSVParser(new StringReader("a\nb\n"), CSVFormat.DEFAULT, 100L, 5L);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            final CSVRecord first = it.next();
            assertEquals(5, first.getRecordNumber());
            assertEquals(100, first.getCharacterPosition());
            final CSVRecord second = it.next();
            assertEquals(6, second.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testDeprecatedConstructorNullFormatThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                @SuppressWarnings("deprecation")
                final CSVParser unused = new CSVParser(new StringReader("a\n"), null);
            }
        });
    }

    @Test
    public void testBuilderGetProducesWorkingParser() throws IOException {
        final CSVParser parser = CSVParser.builder()
                .setReader(new StringReader("x,y\n1,2\n"))
                .setFormat(CSVFormat.DEFAULT)
                .get();
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testBuilderNullFormatMapsToDefault() throws IOException {
        final CSVParser parser = CSVParser.builder()
                .setReader(new StringReader("1,2\n"))
                .setFormat(null)
                .get();
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals(2, records.get(0).size());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testStreamProducesSameRecordsAsIterator() throws IOException {
        final CSVParser parser = CSVParser.parse("1,2\n3,4\n", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.stream().collect(java.util.stream.Collectors.toList());
            assertEquals(2, records.size());
            assertEquals("1", records.get(0).get(0));
            assertEquals("4", records.get(1).get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testCommentHandlingSkipsCommentLinesButRecordsHeaderComment() throws IOException {
        // A header comment is only captured when the header itself is read as a record
        // (i.e. the format defines a header that is read from the first line).
        final CSVFormat format = CSVFormat.DEFAULT.builder()
                .setCommentMarker('#')
                .setHeader(new String[0])
                .build();
        final CSVParser parser = CSVParser.parse("# leading comment\na,b\n1,2\n", format);
        try {
            assertTrue(parser.hasHeaderComment());
            assertEquals("leading comment", parser.getHeaderComment());
            assertEquals("a", parser.getHeaderNames().get(0));
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("1", records.get(0).get(0));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testNoTrailerCommentByDefault() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n", CSVFormat.DEFAULT);
        try {
            parser.getRecords();
            assertFalse(parser.hasTrailerComment());
            assertNull(parser.getTrailerComment());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testMaxRowsLimitsIteration() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(1).build();
        final CSVParser parser = CSVParser.parse("1\n2\n3\n", format);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("1", records.get(0).get(0));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetCurrentLineNumberAdvances() throws IOException {
        final CSVParser parser = CSVParser.parse("a\nb\nc\n", CSVFormat.DEFAULT);
        try {
            assertEquals(0, parser.getCurrentLineNumber());
            final Iterator<CSVRecord> it = parser.iterator();
            it.next();
            assertEquals(1, parser.getCurrentLineNumber());
            it.next();
            assertEquals(2, parser.getCurrentLineNumber());
        } finally {
            parser.close();
        }
    }
}
