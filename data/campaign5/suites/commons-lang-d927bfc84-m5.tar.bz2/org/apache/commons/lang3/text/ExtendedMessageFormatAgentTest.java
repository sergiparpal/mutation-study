/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.Format;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.junit.jupiter.api.Test;

@Deprecated
class ExtendedMessageFormatAgentTest {

    /**
     * Simple upper-casing format used to exercise the custom registry path.
     */
    static final class UpperFormat extends Format {
        private static final long serialVersionUID = 1L;

        @Override
        public StringBuffer format(final Object obj, final StringBuffer toAppendTo, final java.text.FieldPosition pos) {
            return toAppendTo.append(String.valueOf(obj).toUpperCase(Locale.ENGLISH));
        }

        @Override
        public Object parseObject(final String source, final java.text.ParsePosition pos) {
            pos.setIndex(source.length());
            return source;
        }

        @Override
        public boolean equals(final Object obj) {
            return obj instanceof UpperFormat;
        }

        @Override
        public int hashCode() {
            return UpperFormat.class.hashCode();
        }
    }

    static final class UpperFormatFactory implements FormatFactory {
        @Override
        public Format getFormat(final String name, final String arguments, final Locale locale) {
            return "upper".equals(name) ? new UpperFormat() : null;
        }
    }

    private Map<String, FormatFactory> upperRegistry() {
        final Map<String, FormatFactory> registry = new HashMap<>();
        registry.put("upper", new UpperFormatFactory());
        return registry;
    }

    @Test
    void testBasicFormatNoRegistry() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello, {0}!");
        assertEquals("Hello, world!", emf.format(new Object[] {"world"}));
        assertEquals("Hello, {0}!", emf.toPattern());
    }

    @Test
    void testDefaultLocaleConstructorUsesDefaultLocale() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertEquals(Locale.getDefault(), emf.getLocale());
    }

    @Test
    void testLocaleConstructorStoresLocale() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number}", Locale.GERMAN);
        assertEquals(Locale.GERMAN, emf.getLocale());
    }

    @Test
    void testNullLocaleFallsBackToDefault() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", (Locale) null, null);
        assertEquals(Locale.getDefault(), emf.getLocale());
    }

    @Test
    void testCustomFormatViaRegistry() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("Name: {0,upper}", upperRegistry());
        assertEquals("Name: ALICE", emf.format(new Object[] {"alice"}));
    }

    @Test
    void testCustomFormatWithStyleArguments() {
        final Map<String, FormatFactory> registry = new HashMap<>();
        registry.put("upper", new FormatFactory() {
            @Override
            public Format getFormat(final String name, final String arguments, final Locale locale) {
                assertEquals("someArg", arguments);
                return new UpperFormat();
            }
        });
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper,someArg}", registry);
        assertEquals("BOB", emf.format(new Object[] {"bob"}));
    }

    @Test
    void testUnknownFormatNameFallsThroughToStandardFormat() {
        // registry is non-null, but doesn't know "upper" -- no custom Format applied,
        // the plain MessageFormat semantics still work for the literal text.
        final Map<String, FormatFactory> registry = new HashMap<>();
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("Value: {0}", registry);
        assertEquals("Value: 42", emf.format(new Object[] {42}));
    }

    @Test
    void testToPatternRoundTripsCustomFormat() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", upperRegistry());
        assertEquals("{0,upper}", emf.toPattern());
    }

    @Test
    void testApplyPatternReplacesExistingPattern() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", upperRegistry());
        emf.applyPattern("plain {0}");
        assertEquals("plain {0}", emf.toPattern());
        assertEquals("plain hi", emf.format(new Object[] {"hi"}));
    }

    @Test
    void testQuotedLiteralTextPreservedInPattern() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("it''s {0}", upperRegistry());
        assertEquals("it's World", emf.format(new Object[] {"World"}));
    }

    @Test
    void testQuotedBracesAreNotTreatedAsFormatElements() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("'{0}' literal {0}", upperRegistry());
        assertEquals("{0} literal X", emf.format(new Object[] {"X"}));
    }

    @Test
    void testUnterminatedQuoteThrows() {
        assertThrows(IllegalArgumentException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() {
                        new ExtendedMessageFormat("it's {0}", upperRegistry());
                    }
                });
    }

    @Test
    void testUnterminatedFormatElementThrows() {
        assertThrows(IllegalArgumentException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() {
                        new ExtendedMessageFormat("{0", upperRegistry());
                    }
                });
    }

    @Test
    void testInvalidArgumentIndexThrows() {
        assertThrows(IllegalArgumentException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() {
                        new ExtendedMessageFormat("{abc}", upperRegistry());
                    }
                });
    }

    @Test
    void testNoRegistryIgnoresInvalidArgumentIndexHandlingDelegatesToSuper() {
        // with a null registry, applyPattern just delegates directly to MessageFormat,
        // which also rejects a non-numeric argument index.
        assertThrows(IllegalArgumentException.class,
                new org.junit.jupiter.api.function.Executable() {
                    @Override
                    public void execute() {
                        new ExtendedMessageFormat("{abc}");
                    }
                });
    }

    @Test
    void testSetFormatThrowsUnsupported() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormat(0, java.text.NumberFormat.getInstance());
            }
        });
    }

    @Test
    void testSetFormatByArgumentIndexThrowsUnsupported() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormatByArgumentIndex(0, java.text.NumberFormat.getInstance());
            }
        });
    }

    @Test
    void testSetFormatsThrowsUnsupported() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormats(new Format[] {java.text.NumberFormat.getInstance()});
            }
        });
    }

    @Test
    void testSetFormatsByArgumentIndexThrowsUnsupported() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormatsByArgumentIndex(new Format[] {java.text.NumberFormat.getInstance()});
            }
        });
    }

    @Test
    void testEqualsReflexiveAndWithNull() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", upperRegistry());
        assertTrue(emf.equals(emf));
        assertFalse(emf.equals(null));
        assertFalse(emf.equals("not a format"));
    }

    @Test
    void testEqualsSamePatternAndRegistryAreEqual() {
        final Map<String, FormatFactory> registry = upperRegistry();
        final ExtendedMessageFormat a = new ExtendedMessageFormat("{0,upper}", Locale.US, registry);
        final ExtendedMessageFormat b = new ExtendedMessageFormat("{0,upper}", Locale.US, registry);
        assertTrue(a.equals(b));
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    void testEqualsDifferentPatternsAreNotEqual() {
        final Map<String, FormatFactory> registry = upperRegistry();
        final ExtendedMessageFormat a = new ExtendedMessageFormat("{0,upper}", Locale.US, registry);
        final ExtendedMessageFormat b = new ExtendedMessageFormat("plain {0}", Locale.US, registry);
        assertNotEquals(a, b);
    }

    @Test
    void testEqualsDifferentRegistryAreNotEqual() {
        final ExtendedMessageFormat a = new ExtendedMessageFormat("{0}", Locale.US, upperRegistry());
        final ExtendedMessageFormat b = new ExtendedMessageFormat("{0}", Locale.US, new HashMap<String, FormatFactory>());
        assertNotEquals(a, b);
    }

    @Test
    void testParseDelegatesToUnderlyingMessageFormat() throws java.text.ParseException {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello, {0}!");
        final Object[] parsed = emf.parse("Hello, world!");
        assertEquals(1, parsed.length);
        assertEquals("world", parsed[0]);
    }

    @Test
    void testChoiceFormatPattern() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat(
                "{0,choice,0#no files|1#one file|1<{0,number} files}");
        assertEquals("no files", emf.format(new Object[] {0}));
        assertEquals("one file", emf.format(new Object[] {1}));
        assertEquals("3 files", emf.format(new Object[] {3}));
    }

    @Test
    void testNestedBracesInChoiceAreNotMisparsed() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat(
                "{0,choice,0#none|1#{0} item}", upperRegistry());
        assertEquals("1 item", emf.format(new Object[] {1}));
    }
}
