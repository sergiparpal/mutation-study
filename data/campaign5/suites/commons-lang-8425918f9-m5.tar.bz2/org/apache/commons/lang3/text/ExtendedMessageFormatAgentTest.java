/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.Format;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.junit.jupiter.api.Test;

public class ExtendedMessageFormatAgentTest {

    /**
     * Simple format that upper-cases its argument's String representation.
     */
    private static final class UpperFormat extends Format {
        private static final long serialVersionUID = 1L;

        @Override
        public StringBuffer format(final Object obj, final StringBuffer toAppendTo, final java.text.FieldPosition pos) {
            return toAppendTo.append(String.valueOf(obj).toUpperCase());
        }

        @Override
        public Object parseObject(final String source, final java.text.ParsePosition pos) {
            pos.setIndex(source.length());
            return source;
        }
    }

    private static final class UpperFormatFactory implements FormatFactory {
        // single shared instance so that two ExtendedMessageFormat objects built from the
        // same registry hold equal (in fact identical) custom Format instances
        private static final UpperFormat INSTANCE = new UpperFormat();

        @Override
        public Format getFormat(final String name, final String arguments, final Locale locale) {
            if ("upper".equals(name)) {
                return INSTANCE;
            }
            return null;
        }
    }

    private Map<String, FormatFactory> upperRegistry() {
        final Map<String, FormatFactory> registry = new HashMap<>();
        registry.put("upper", new UpperFormatFactory());
        return registry;
    }

    @Test
    public void testSimplePatternNoRegistry() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello, {0}!");
        assertEquals("Hello, {0}!", emf.toPattern());
        assertEquals("Hello, World!", emf.format(new Object[] { "World" }));
    }

    @Test
    public void testConstructorWithLocale() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number}", Locale.US);
        assertEquals(Locale.US, emf.getLocale());
        assertEquals("1,234", emf.format(new Object[] { Integer.valueOf(1234) }));
    }

    @Test
    public void testConstructorWithRegistryDefaultLocale() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", upperRegistry());
        assertEquals(Locale.getDefault(), emf.getLocale());
        assertEquals("ABC", emf.format(new Object[] { "abc" }));
    }

    @Test
    public void testCustomFormatRegistryAppliedAndToPatternRoundTrip() {
        final Map<String, FormatFactory> registry = upperRegistry();
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("Value: {0,upper}", Locale.US, registry);
        assertEquals("Value: ABC", emf.format(new Object[] { "abc" }));
        assertEquals("Value: {0,upper}", emf.toPattern());
    }

    @Test
    public void testUnknownCustomFormatFallsThroughToSuperAndFailsOnBadName() {
        final Map<String, FormatFactory> registry = upperRegistry();
        // "unknownformat" is not in the registry, nor a built-in MessageFormat type,
        // so applying this pattern must fail validation in the base MessageFormat.
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{0,unknownformat}", registry);
            }
        });
    }

    @Test
    public void testNullPatternThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat(null);
            }
        });
    }

    @Test
    public void testUnterminatedFormatElementThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{0");
            }
        });
    }

    @Test
    public void testUnterminatedQuotedStringThrows() {
        // the custom quote-parsing path (which detects the unterminated quote) is only
        // exercised when a registry is supplied; without one the base MessageFormat is used
        final Map<String, FormatFactory> registry = upperRegistry();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("'unterminated", registry);
            }
        });
    }

    @Test
    public void testInvalidArgumentIndexThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{abc}");
            }
        });
    }

    @Test
    public void testQuotedLiteralIsPreservedAndNotParsedAsFormatElement() {
        // the quoted "{0}" is a literal, so only the second, unquoted {0} is substituted
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("'{0}' {0}");
        assertEquals("'{'0} {0}", emf.toPattern());
        assertEquals("{0} World", emf.format(new Object[] { "World" }));
    }

    @Test
    public void testEqualsAndHashCode() {
        final Map<String, FormatFactory> registry = upperRegistry();
        final ExtendedMessageFormat emf1 = new ExtendedMessageFormat("Value: {0,upper}", Locale.US, registry);
        final ExtendedMessageFormat emf2 = new ExtendedMessageFormat("Value: {0,upper}", Locale.US, registry);
        assertTrue(emf1.equals(emf2));
        assertEquals(emf1.hashCode(), emf2.hashCode());

        final ExtendedMessageFormat emf3 = new ExtendedMessageFormat("Other: {0,upper}", Locale.US, registry);
        assertFalse(emf1.equals(emf3));

        assertFalse(emf1.equals(null));
        assertFalse(emf1.equals("not an emf"));
        assertTrue(emf1.equals(emf1));
    }

    @Test
    public void testEqualsDiffersWhenRegistryDiffers() {
        final ExtendedMessageFormat emfNoRegistry = new ExtendedMessageFormat("{0}", Locale.US);
        final ExtendedMessageFormat emfWithRegistry = new ExtendedMessageFormat("{0}", Locale.US, upperRegistry());
        assertNotEquals(emfNoRegistry, emfWithRegistry);
    }

    @Test
    public void testSetFormatThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormat(0, new UpperFormat());
            }
        });
    }

    @Test
    public void testSetFormatByArgumentIndexThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormatByArgumentIndex(0, new UpperFormat());
            }
        });
    }

    @Test
    public void testSetFormatsThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormats(new Format[] { new UpperFormat() });
            }
        });
    }

    @Test
    public void testSetFormatsByArgumentIndexThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                emf.setFormatsByArgumentIndex(new Format[] { new UpperFormat() });
            }
        });
    }

    @Test
    public void testParseRoundTrip() throws ParseException {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}-{1}");
        final Object[] parsed = emf.parse("foo-bar");
        assertEquals(2, parsed.length);
        assertEquals("foo", parsed[0]);
        assertEquals("bar", parsed[1]);
    }

    @Test
    public void testMultipleFormatElementsWithMixedCustomAndBuiltin() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat(
                "{0,upper} has {1,number} items", Locale.US, upperRegistry());
        final String result = emf.format(new Object[] { "box", Integer.valueOf(5) });
        assertEquals("BOX has 5 items", result);
        assertEquals("{0,upper} has {1,number} items", emf.toPattern());
    }

    @Test
    public void testEmptyPattern() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("");
        assertEquals("", emf.toPattern());
        assertEquals("", emf.format(new Object[0]));
    }
}
