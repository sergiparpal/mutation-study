/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link StringEscapeUtils}.
 */
class StringEscapeUtilsAgentTest {

    @Test
    void testEscapeCsvNull() {
        assertNull(StringEscapeUtils.escapeCsv(null));
    }

    @Test
    void testEscapeCsvEmpty() {
        assertEquals("", StringEscapeUtils.escapeCsv(""));
    }

    @Test
    void testEscapeCsvUnchanged() {
        assertEquals("abc", StringEscapeUtils.escapeCsv("abc"));
    }

    @Test
    void testEscapeCsvComma() {
        assertEquals("\"a,b\"", StringEscapeUtils.escapeCsv("a,b"));
    }

    @Test
    void testEscapeCsvQuote() {
        assertEquals("\"a\"\"b\"", StringEscapeUtils.escapeCsv("a\"b"));
    }

    @Test
    void testEscapeCsvNewlineAndCr() {
        assertEquals("\"a\nb\"", StringEscapeUtils.escapeCsv("a\nb"));
        assertEquals("\"a\rb\"", StringEscapeUtils.escapeCsv("a\rb"));
    }

    @Test
    void testUnescapeCsvNull() {
        assertNull(StringEscapeUtils.unescapeCsv(null));
    }

    @Test
    void testUnescapeCsvUnchanged() {
        assertEquals("abc", StringEscapeUtils.unescapeCsv("abc"));
    }

    @Test
    void testUnescapeCsvQuoted() {
        assertEquals("a,b", StringEscapeUtils.unescapeCsv("\"a,b\""));
    }

    @Test
    void testUnescapeCsvEscapedQuotes() {
        assertEquals("a\"b", StringEscapeUtils.unescapeCsv("\"a\"\"b\""));
    }

    @Test
    void testUnescapeCsvNotEnclosedWhenNoSpecialChars() {
        assertEquals("\"abc\"", StringEscapeUtils.unescapeCsv("\"abc\""));
    }

    @Test
    void testUnescapeCsvTooShortToBeQuoted() {
        assertEquals("\"", StringEscapeUtils.unescapeCsv("\""));
    }

    @Test
    void testEscapeJavaNull() {
        assertNull(StringEscapeUtils.escapeJava(null));
    }

    @Test
    void testEscapeJavaEmpty() {
        assertEquals("", StringEscapeUtils.escapeJava(""));
    }

    @Test
    void testEscapeJavaQuotesAndBackslash() {
        assertEquals("He didn't say, \\\"Stop!\\\"", StringEscapeUtils.escapeJava("He didn't say, \"Stop!\""));
        assertEquals("a\\\\b", StringEscapeUtils.escapeJava("a\\b"));
    }

    @Test
    void testEscapeJavaControlChars() {
        assertEquals("a\\tb\\nc", StringEscapeUtils.escapeJava("a\tb\nc"));
    }

    @Test
    void testEscapeJavaDoesNotEscapeSlashOrSingleQuote() {
        assertEquals("a/b", StringEscapeUtils.escapeJava("a/b"));
        assertEquals("a'b", StringEscapeUtils.escapeJava("a'b"));
    }

    @Test
    void testUnescapeJavaNull() {
        assertNull(StringEscapeUtils.unescapeJava(null));
    }

    @Test
    void testUnescapeJavaBasic() {
        assertEquals("He didn't say, \"Stop!\"", StringEscapeUtils.unescapeJava("He didn't say, \\\"Stop!\\\""));
        assertEquals("a\tb\nc", StringEscapeUtils.unescapeJava("a\\tb\\nc"));
    }

    @Test
    void testUnescapeJavaOctal() {
        assertEquals("A", StringEscapeUtils.unescapeJava("\\101"));
    }

    @Test
    void testUnescapeJavaUnicode() {
        assertEquals("A", StringEscapeUtils.unescapeJava("\\u0041"));
    }

    @Test
    void testUnescapeJavaTrailingBackslashRemoved() {
        assertEquals("a", StringEscapeUtils.unescapeJava("a\\"));
    }

    @Test
    void testEscapeEcmaScript() {
        assertNull(StringEscapeUtils.escapeEcmaScript(null));
        assertEquals("He didn\\'t say, \\\"Stop!\\\"", StringEscapeUtils.escapeEcmaScript("He didn't say, \"Stop!\""));
        assertEquals("a\\/b", StringEscapeUtils.escapeEcmaScript("a/b"));
    }

    @Test
    void testUnescapeEcmaScript() {
        assertNull(StringEscapeUtils.unescapeEcmaScript(null));
        assertEquals("a\tb", StringEscapeUtils.unescapeEcmaScript("a\\tb"));
    }

    @Test
    void testEscapeJson() {
        assertNull(StringEscapeUtils.escapeJson(null));
        assertEquals("He didn't say, \\\"Stop!\\\"", StringEscapeUtils.escapeJson("He didn't say, \"Stop!\""));
        assertEquals("a\\/b", StringEscapeUtils.escapeJson("a/b"));
        assertEquals("a'b", StringEscapeUtils.escapeJson("a'b"));
    }

    @Test
    void testUnescapeJson() {
        assertNull(StringEscapeUtils.unescapeJson(null));
        assertEquals("a\tb", StringEscapeUtils.unescapeJson("a\\tb"));
    }

    @Test
    void testEscapeHtml3Null() {
        assertNull(StringEscapeUtils.escapeHtml3(null));
    }

    @Test
    void testEscapeHtml3Basic() {
        assertEquals("&quot;bread&quot; &amp; &quot;butter&quot;", StringEscapeUtils.escapeHtml3("\"bread\" & \"butter\""));
        assertEquals("&lt;b&gt;", StringEscapeUtils.escapeHtml3("<b>"));
    }

    @Test
    void testEscapeHtml3DoesNotEscapeApostrophe() {
        assertEquals("it's", StringEscapeUtils.escapeHtml3("it's"));
    }

    @Test
    void testUnescapeHtml3Null() {
        assertNull(StringEscapeUtils.unescapeHtml3(null));
    }

    @Test
    void testUnescapeHtml3Basic() {
        assertEquals("<b>", StringEscapeUtils.unescapeHtml3("&lt;b&gt;"));
    }

    @Test
    void testUnescapeHtml3UnknownEntityLeftAlone() {
        assertEquals(">&zzzz;x", StringEscapeUtils.unescapeHtml3("&gt;&zzzz;x"));
    }

    @Test
    void testEscapeHtml4Null() {
        assertNull(StringEscapeUtils.escapeHtml4(null));
    }

    @Test
    void testEscapeHtml4Basic() {
        assertEquals("&quot;bread&quot; &amp; &quot;butter&quot;", StringEscapeUtils.escapeHtml4("\"bread\" & \"butter\""));
    }

    @Test
    void testEscapeHtml4ExtendedEntity() {
        assertEquals("&euro;", StringEscapeUtils.escapeHtml4("€"));
    }

    @Test
    void testUnescapeHtml4Null() {
        assertNull(StringEscapeUtils.unescapeHtml4(null));
    }

    @Test
    void testUnescapeHtml4Basic() {
        assertEquals("<Français>", StringEscapeUtils.unescapeHtml4("&lt;Fran&ccedil;ais&gt;"));
    }

    @Test
    void testUnescapeHtml4UnknownEntityLeftAlone() {
        assertEquals(">&zzzz;x", StringEscapeUtils.unescapeHtml4("&gt;&zzzz;x"));
    }

    @Test
    void testUnescapeHtml4NumericEntity() {
        assertEquals("A", StringEscapeUtils.unescapeHtml4("&#65;"));
        assertEquals("A", StringEscapeUtils.unescapeHtml4("&#x41;"));
    }

    @SuppressWarnings("deprecation")
    @Test
    void testEscapeXmlNull() {
        assertNull(StringEscapeUtils.escapeXml(null));
    }

    @SuppressWarnings("deprecation")
    @Test
    void testEscapeXmlBasic() {
        assertEquals("&quot;bread&quot; &amp; &quot;butter&quot;", StringEscapeUtils.escapeXml("\"bread\" & \"butter\""));
        assertEquals("&apos;", StringEscapeUtils.escapeXml("'"));
    }

    @SuppressWarnings("deprecation")
    @Test
    void testEscapeXmlDoesNotEscapeNonAscii() {
        assertEquals("à", StringEscapeUtils.escapeXml("à"));
    }

    @Test
    void testEscapeXml10Null() {
        assertNull(StringEscapeUtils.escapeXml10(null));
    }

    @Test
    void testEscapeXml10RemovesNulAndControlChars() {
        assertEquals("ab", StringEscapeUtils.escapeXml10("a\u0000b"));
        assertEquals("ab", StringEscapeUtils.escapeXml10("a\u0001b"));
    }

    @Test
    void testEscapeXml10KeepsTabNewlineCr() {
        assertEquals("a\tb\nc\rd", StringEscapeUtils.escapeXml10("a\tb\nc\rd"));
    }

    @Test
    void testEscapeXml10EscapesHighControlRange() {
        assertEquals("a&#127;b", StringEscapeUtils.escapeXml10("a\u007fb"));
    }

    @Test
    void testEscapeXml11Null() {
        assertNull(StringEscapeUtils.escapeXml11(null));
    }

    @Test
    void testEscapeXml11RemovesNulButKeepsLowControlAsEntity() {
        assertEquals("ab", StringEscapeUtils.escapeXml11("a\u0000b"));
        assertEquals("a&#1;b", StringEscapeUtils.escapeXml11("a\u0001b"));
    }

    @Test
    void testEscapeXml11KeepsVerticalTabAsNamedEntity() {
        assertEquals("a&#11;b", StringEscapeUtils.escapeXml11("a\u000bb"));
    }

    @Test
    void testUnescapeXmlNull() {
        assertNull(StringEscapeUtils.unescapeXml(null));
    }

    @Test
    void testUnescapeXmlBasic() {
        assertEquals("\"bread\" & \"butter\"", StringEscapeUtils.unescapeXml("&quot;bread&quot; &amp; &quot;butter&quot;"));
        assertEquals("'", StringEscapeUtils.unescapeXml("&apos;"));
    }

    @Test
    void testUnescapeXmlNumericEntity() {
        assertEquals("A", StringEscapeUtils.unescapeXml("&#65;"));
        assertEquals("A", StringEscapeUtils.unescapeXml("&#x41;"));
    }

    @SuppressWarnings("deprecation")
    @Test
    void testConstructorIsPublic() {
        final StringEscapeUtils instance = new StringEscapeUtils();
        assertEquals(StringEscapeUtils.class, instance.getClass());
    }
}
