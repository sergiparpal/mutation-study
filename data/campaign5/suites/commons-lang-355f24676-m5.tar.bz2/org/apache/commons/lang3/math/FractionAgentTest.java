/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link Fraction}.
 */
public class FractionAgentTest {

    @Test
    public void testAbs() {
        assertSame(Fraction.ONE, Fraction.ONE.abs());
        assertEquals(Fraction.getFraction(1, 2), Fraction.getFraction(-1, 2).abs());
        assertEquals(Fraction.ZERO, Fraction.ZERO.abs());
    }

    @Test
    public void testAbsOverflow() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, f::abs);
    }

    @Test
    public void testAddBasic() {
        final Fraction result = Fraction.getFraction(1, 2).add(Fraction.getFraction(1, 3));
        assertEquals(Fraction.getFraction(5, 6), result);
    }

    @Test
    public void testAddNullThrows() {
        assertThrows(NullPointerException.class, () -> Fraction.ONE.add(null));
    }

    @Test
    public void testAddOverflow() {
        final Fraction f1 = Fraction.getFraction(Integer.MAX_VALUE, 1);
        assertThrows(ArithmeticException.class, () -> f1.add(Fraction.ONE));
    }

    @Test
    public void testAddWithZero() {
        assertEquals(Fraction.getFraction(1, 2), Fraction.ZERO.add(Fraction.getFraction(1, 2)));
        assertEquals(Fraction.getFraction(1, 2), Fraction.getFraction(1, 2).add(Fraction.ZERO));
    }

    @Test
    public void testCompareTo() {
        final Fraction oneHalf = Fraction.getFraction(1, 2);
        final Fraction twoQuarters = Fraction.getFraction(2, 4);
        assertEquals(0, oneHalf.compareTo(twoQuarters));
        assertEquals(0, oneHalf.compareTo(oneHalf));
        assertTrue(Fraction.getFraction(1, 3).compareTo(Fraction.getFraction(1, 2)) < 0);
        assertTrue(Fraction.getFraction(2, 3).compareTo(Fraction.getFraction(1, 2)) > 0);
    }

    @Test
    public void testCompareToNullThrows() {
        assertThrows(NullPointerException.class, () -> Fraction.ONE.compareTo(null));
    }

    @Test
    public void testDivideByBasic() {
        final Fraction result = Fraction.getFraction(1, 2).divideBy(Fraction.getFraction(1, 3));
        assertEquals(Fraction.getFraction(3, 2), result);
    }

    @Test
    public void testDivideByNullThrows() {
        assertThrows(NullPointerException.class, () -> Fraction.ONE.divideBy(null));
    }

    @Test
    public void testDivideByZeroFraction() {
        assertThrows(ArithmeticException.class, () -> Fraction.ONE.divideBy(Fraction.ZERO));
    }

    @Test
    public void testDivideZeroByFraction() {
        assertEquals(Fraction.ZERO, Fraction.ZERO.divideBy(Fraction.getFraction(1, 2)));
    }

    @Test
    public void testDoubleValue() {
        assertEquals(0.5d, Fraction.getFraction(1, 2).doubleValue(), 0.0d);
        assertEquals(-0.25d, Fraction.getFraction(-1, 4).doubleValue(), 0.0d);
    }

    @Test
    public void testEqualsDistinguishesUnreducedValues() {
        final Fraction oneHalf = Fraction.getFraction(1, 2);
        final Fraction twoQuarters = Fraction.getFraction(2, 4);
        assertNotEquals(oneHalf, twoQuarters);
        assertEquals(oneHalf, oneHalf);
        assertFalse(oneHalf.equals(null));
        assertFalse(oneHalf.equals("1/2"));
    }

    @Test
    public void testFloatValue() {
        assertEquals(0.5f, Fraction.getFraction(1, 2).floatValue(), 0.0f);
    }

    @Test
    public void testGetDenominatorAndNumerator() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertEquals(3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionDoubleBoundary() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(Double.NaN));
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction((double) Integer.MAX_VALUE + 1.0d));
        final Fraction f = Fraction.getFraction(0.5d);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetFractionDoubleNegative() {
        final Fraction f = Fraction.getFraction(-0.25d);
        assertEquals(-1, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionIntIntDenominatorZeroThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(1, 0));
    }

    @Test
    public void testGetFractionIntIntNegativeDenominatorMovesSignToNumerator() {
        final Fraction f = Fraction.getFraction(1, -2);
        assertEquals(-1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetFractionIntIntIntBasic() {
        final Fraction f = Fraction.getFraction(1, 3, 4);
        assertEquals(7, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionIntIntIntNegativeNumeratorThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(1, -3, 4));
    }

    @Test
    public void testGetFractionIntIntIntNegativeDenominatorThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(1, 3, -4));
    }

    @Test
    public void testGetFractionIntIntIntNegativeWhole() {
        final Fraction f = Fraction.getFraction(-1, 3, 4);
        assertEquals(-7, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionIntIntIntOverflowThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getFraction(Integer.MAX_VALUE, 1, 1));
    }

    @Test
    public void testGetFractionStringNullThrows() {
        assertThrows(NullPointerException.class, () -> Fraction.getFraction((String) null));
    }

    @Test
    public void testGetFractionStringDouble() {
        final Fraction f = Fraction.getFraction("1.5");
        assertEquals(3, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetFractionStringMixed() {
        final Fraction f = Fraction.getFraction("1 3/4");
        assertEquals(7, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionStringMixedMissingSlashThrows() {
        assertThrows(NumberFormatException.class, () -> Fraction.getFraction("1 34"));
    }

    @Test
    public void testGetFractionStringFraction() {
        final Fraction f = Fraction.getFraction("3/7");
        assertEquals(3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionStringWholeNumber() {
        final Fraction f = Fraction.getFraction("5");
        assertEquals(5, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    public void testGetFractionStringZeroDenominatorWrapsArithmeticException() {
        final NumberFormatException ex = assertThrows(NumberFormatException.class, () -> Fraction.getFraction("1/0"));
        assertTrue(ex.getCause() instanceof ArithmeticException);
    }

    @Test
    public void testGetFractionStringInvalidThrows() {
        assertThrows(NumberFormatException.class, () -> Fraction.getFraction("abc"));
    }

    @Test
    public void testGetReducedFractionBasic() {
        final Fraction f = Fraction.getReducedFraction(2, 4);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetReducedFractionZeroNumerator() {
        assertSame(Fraction.ZERO, Fraction.getReducedFraction(0, 5));
    }

    @Test
    public void testGetReducedFractionDenominatorZeroThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.getReducedFraction(1, 0));
    }

    @Test
    public void testGetProperNumeratorAndWhole() {
        final Fraction f = Fraction.getFraction(7, 4);
        assertEquals(1, f.getProperWhole());
        assertEquals(3, f.getProperNumerator());
        final Fraction negative = Fraction.getFraction(-7, 4);
        assertEquals(-1, negative.getProperWhole());
        assertEquals(3, negative.getProperNumerator());
    }

    @Test
    public void testHashCodeConsistentWithEquals() {
        final Fraction a = Fraction.getFraction(3, 7);
        final Fraction b = Fraction.getFraction(3, 7);
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    public void testIntValue() {
        assertEquals(1, Fraction.getFraction(7, 4).intValue());
        assertEquals(-1, Fraction.getFraction(-7, 4).intValue());
    }

    @Test
    public void testInvertBasic() {
        final Fraction f = Fraction.getFraction(3, 7).invert();
        assertEquals(7, f.getNumerator());
        assertEquals(3, f.getDenominator());
    }

    @Test
    public void testInvertNegative() {
        final Fraction f = Fraction.getFraction(-3, 7).invert();
        assertEquals(-7, f.getNumerator());
        assertEquals(3, f.getDenominator());
    }

    @Test
    public void testInvertZeroThrows() {
        assertThrows(ArithmeticException.class, () -> Fraction.ZERO.invert());
    }

    @Test
    public void testInvertMinValueThrows() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, f::invert);
    }

    @Test
    public void testLongValue() {
        assertEquals(1L, Fraction.getFraction(7, 4).longValue());
    }

    @Test
    public void testMultiplyByBasic() {
        final Fraction result = Fraction.getFraction(2, 3).multiplyBy(Fraction.getFraction(3, 4));
        assertEquals(Fraction.getFraction(1, 2), result);
    }

    @Test
    public void testMultiplyByZero() {
        assertSame(Fraction.ZERO, Fraction.getFraction(2, 3).multiplyBy(Fraction.ZERO));
    }

    @Test
    public void testMultiplyByNullThrows() {
        assertThrows(NullPointerException.class, () -> Fraction.ONE.multiplyBy(null));
    }

    @Test
    public void testMultiplyByOverflow() {
        final Fraction f = Fraction.getFraction(Integer.MAX_VALUE, 1);
        assertThrows(ArithmeticException.class, () -> f.multiplyBy(Fraction.getFraction(2, 1)));
    }

    @Test
    public void testNegate() {
        final Fraction f = Fraction.getFraction(3, 7).negate();
        assertEquals(-3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testNegateMinValueThrows() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, f::negate);
    }

    @Test
    public void testPowPositive() {
        final Fraction f = Fraction.getFraction(2, 3).pow(3);
        assertEquals(Fraction.getFraction(8, 27), f);
    }

    @Test
    public void testPowZero() {
        assertSame(Fraction.ONE, Fraction.getFraction(2, 3).pow(0));
        assertSame(Fraction.ONE, Fraction.ZERO.pow(0));
    }

    @Test
    public void testPowOne() {
        final Fraction f = Fraction.getFraction(2, 3);
        assertSame(f, f.pow(1));
    }

    @Test
    public void testPowNegative() {
        final Fraction f = Fraction.getFraction(2, 3).pow(-2);
        assertEquals(Fraction.getFraction(9, 4), f);
    }

    @Test
    public void testPowMinValue() {
        final Fraction f = Fraction.getFraction(1, 1).pow(Integer.MIN_VALUE);
        assertEquals(Fraction.ONE, f);
    }

    @Test
    public void testReduceAlreadyReduced() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertSame(f, f.reduce());
    }

    @Test
    public void testReduceSimplifies() {
        final Fraction f = Fraction.getFraction(2, 4);
        final Fraction reduced = f.reduce();
        assertEquals(1, reduced.getNumerator());
        assertEquals(2, reduced.getDenominator());
    }

    @Test
    public void testReduceZeroNumerator() {
        final Fraction f = Fraction.getFraction(0, 5);
        assertEquals(Fraction.ZERO, f.reduce());
    }

    @Test
    public void testSubtractBasic() {
        final Fraction result = Fraction.getFraction(1, 2).subtract(Fraction.getFraction(1, 3));
        assertEquals(Fraction.getFraction(1, 6), result);
    }

    @Test
    public void testSubtractNullThrows() {
        assertThrows(NullPointerException.class, () -> Fraction.ONE.subtract(null));
    }

    @Test
    public void testSubtractResultingInZero() {
        final Fraction result = Fraction.getFraction(1, 2).subtract(Fraction.getFraction(1, 2));
        assertEquals(Fraction.ZERO, result);
    }

    @Test
    public void testToProperStringZero() {
        assertEquals("0", Fraction.ZERO.toProperString());
    }

    @Test
    public void testToProperStringOne() {
        assertEquals("1", Fraction.getFraction(4, 4).toProperString());
    }

    @Test
    public void testToProperStringNegativeOne() {
        assertEquals("-1", Fraction.getFraction(-4, 4).toProperString());
    }

    @Test
    public void testToProperStringImproperFraction() {
        assertEquals("1 3/4", Fraction.getFraction(7, 4).toProperString());
        assertEquals("-1 3/4", Fraction.getFraction(-7, 4).toProperString());
    }

    @Test
    public void testToProperStringWholeNumber() {
        assertEquals("2", Fraction.getFraction(8, 4).toProperString());
    }

    @Test
    public void testToProperStringProperFraction() {
        assertEquals("3/7", Fraction.getFraction(3, 7).toProperString());
    }

    @Test
    public void testToProperStringIsCached() {
        final Fraction f = Fraction.getFraction(7, 4);
        assertSame(f.toProperString(), f.toProperString());
    }

    @Test
    public void testToString() {
        assertEquals("3/7", Fraction.getFraction(3, 7).toString());
        assertEquals("-3/7", Fraction.getFraction(-3, 7).toString());
    }

    @Test
    public void testToStringIsCached() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertSame(f.toString(), f.toString());
    }

    @Test
    public void testConstants() {
        assertEquals(Fraction.getFraction(0, 1), Fraction.ZERO);
        assertEquals(Fraction.getFraction(1, 1), Fraction.ONE);
        assertEquals(Fraction.getFraction(1, 2), Fraction.ONE_HALF);
        assertEquals(Fraction.getFraction(1, 3), Fraction.ONE_THIRD);
        assertEquals(Fraction.getFraction(2, 3), Fraction.TWO_THIRDS);
        assertEquals(Fraction.getFraction(1, 4), Fraction.ONE_QUARTER);
        assertEquals(Fraction.getFraction(2, 4), Fraction.TWO_QUARTERS);
        assertEquals(Fraction.getFraction(3, 4), Fraction.THREE_QUARTERS);
        assertEquals(Fraction.getFraction(1, 5), Fraction.ONE_FIFTH);
        assertEquals(Fraction.getFraction(2, 5), Fraction.TWO_FIFTHS);
        assertEquals(Fraction.getFraction(3, 5), Fraction.THREE_FIFTHS);
        assertEquals(Fraction.getFraction(4, 5), Fraction.FOUR_FIFTHS);
    }
}
