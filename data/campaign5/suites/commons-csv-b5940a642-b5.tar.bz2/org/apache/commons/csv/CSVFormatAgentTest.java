/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

class CSVFormatAgentTest {

    private enum FixtureHeader {
        NAME, EMAIL, PHONE
    }

    @Test
    void testDefaultFormatProperties() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertTrue(format.getIgnoreEmptyLines());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
        assertFalse(format.getAllowMissingColumnNames());
        assertFalse(format.getTrim());
        assertNull(format.getCommentMarker());
        assertNull(format.getEscapeCharacter());
        assertNull(format.getHeader());
        assertEquals(0L, format.getMaxRows());
    }

    @Test
    void testExcelFormatProperties() {
        final CSVFormat format = CSVFormat.EXCEL;
        assertFalse(format.getIgnoreEmptyLines());
        assertTrue(format.getAllowMissingColumnNames());
        assertTrue(format.getTrailingData());
        assertTrue(format.getLenientEof());
        assertEquals(",", format.getDelimiterString());
    }

    @Test
    void testTdfFormatProperties() {
        final CSVFormat format = CSVFormat.TDF;
        assertEquals("\t", format.getDelimiterString());
        assertTrue(format.getIgnoreSurroundingSpaces());
    }

    @Test
    void testMySqlFormatProperties() {
        final CSVFormat format = CSVFormat.MYSQL;
        assertEquals("\t", format.getDelimiterString());
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
        assertNull(format.getQuoteCharacter());
        assertEquals("\\N", format.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, format.getQuoteMode());
        assertEquals("\n", format.getRecordSeparator());
    }

    @Test
    void testNewFormatBasic() {
        final CSVFormat format = CSVFormat.newFormat(';');
        assertEquals(";", format.getDelimiterString());
        assertNull(format.getQuoteCharacter());
        assertNull(format.getCommentMarker());
        assertNull(format.getEscapeCharacter());
        assertFalse(format.getIgnoreEmptyLines());
        assertFalse(format.getSkipHeaderRecord());
        assertNull(format.getRecordSeparator());
    }

    @Test
    void testValueOfPredefined() {
        assertSame(CSVFormat.DEFAULT, CSVFormat.valueOf("Default"));
        assertSame(CSVFormat.EXCEL, CSVFormat.valueOf("Excel"));
        assertSame(CSVFormat.MYSQL, CSVFormat.Predefined.MySQL.getFormat());
    }

    @Test
    void testValueOfUnknownThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                CSVFormat.valueOf("NotARealFormat");
            }
        });
    }

    @Test
    void testBuilderSetDelimiterChar() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        assertEquals(";", format.getDelimiterString());
    }

    @Test
    void testBuilderSetDelimiterEmptyThrows() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                builder.setDelimiter("");
            }
        });
    }

    @Test
    void testBuilderSetDelimiterLineBreakThrows() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                builder.setDelimiter("\n");
            }
        });
    }

    @Test
    void testBuilderSetCommentMarkerLineBreakThrows() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                builder.setCommentMarker('\r');
            }
        });
    }

    @Test
    void testBuilderSetEscapeLineBreakThrows() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                builder.setEscape('\n');
            }
        });
    }

    @Test
    void testBuilderSetQuoteLineBreakThrows() {
        final CSVFormat.Builder builder = CSVFormat.DEFAULT.builder();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                builder.setQuote('\n');
            }
        });
    }

    @Test
    void testQuoteCharEqualsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                CSVFormat.DEFAULT.builder().setDelimiter(',').setQuote('"').setDelimiter(',').setQuote(',').get();
            }
        });
    }

    @Test
    void testEscapeCharEqualsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                CSVFormat.DEFAULT.builder().setDelimiter(';').setEscape(';').get();
            }
        });
    }

    @Test
    void testCommentMarkerEqualsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                CSVFormat.DEFAULT.builder().setDelimiter('#').setCommentMarker('#').get();
            }
        });
    }

    @Test
    void testCommentMarkerEqualsQuoteCharThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                CSVFormat.DEFAULT.builder().setQuote('#').setCommentMarker('#').get();
            }
        });
    }

    @Test
    void testCommentMarkerEqualsEscapeCharThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                CSVFormat.DEFAULT.builder().setEscape('#').setCommentMarker('#').get();
            }
        });
    }

    @Test
    void testQuoteModeNoneWithoutEscapeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                CSVFormat.DEFAULT.builder().setEscape(null).setQuoteMode(QuoteMode.NONE).get();
            }
        });
    }

    @Test
    void testQuoteModeNoneWithEscapeAllowed() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').setQuoteMode(QuoteMode.NONE).get();
        assertEquals(QuoteMode.NONE, format.getQuoteMode());
    }

    @Test
    void testDuplicateHeaderDisallowedThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).setHeader("a", "b", "a").get();
            }
        });
    }

    @Test
    void testDuplicateHeaderAllowAllPermitsDuplicates() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_ALL).setHeader("a", "b", "a").get();
        assertArrayEquals(new String[] { "a", "b", "a" }, format.getHeader());
    }

    @Test
    void testDuplicateHeaderAllowEmptyPermitsBlankDuplicates() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("a", "", "").get();
        assertArrayEquals(new String[] { "a", "", "" }, format.getHeader());
    }

    @Test
    void testDuplicateHeaderAllowEmptyDisallowsNonBlankDuplicates() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("a", "a").get();
            }
        });
    }

    @Test
    void testGetHeaderReturnsDefensiveCopy() {
        final String[] headerArray = { "x", "y" };
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(headerArray).get();
        final String[] firstCall = format.getHeader();
        assertArrayEquals(headerArray, firstCall);
        assertNotSame(headerArray, firstCall);
        firstCall[0] = "mutated";
        assertArrayEquals(headerArray, format.getHeader());
    }

    @Test
    void testSetHeaderFromEnumClass() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(FixtureHeader.class).get();
        assertArrayEquals(new String[] { "NAME", "EMAIL", "PHONE" }, format.getHeader());
    }

    @Test
    void testSetHeaderNullDisablesHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader((String[]) null).get();
        assertNull(format.getHeader());
    }

    @Test
    void testSetHeaderEmptyMeansAutoDetect() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().get();
        assertNotNull(format.getHeader());
        assertEquals(0, format.getHeader().length);
    }

    @Test
    void testGetHeaderCommentsReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeaderComments("line1", "line2").get();
        final String[] comments = format.getHeaderComments();
        assertArrayEquals(new String[] { "line1", "line2" }, comments);
        comments[0] = "mutated";
        assertArrayEquals(new String[] { "line1", "line2" }, format.getHeaderComments());
    }

    @Test
    void testGetHeaderCommentsNullWhenUnset() {
        assertNull(CSVFormat.DEFAULT.getHeaderComments());
    }

    @Test
    void testIsSetPredicates() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').setEscape('\\').setQuote('"').setNullString("NULL").get();
        assertTrue(format.isCommentMarkerSet());
        assertTrue(format.isEscapeCharacterSet());
        assertTrue(format.isQuoteCharacterSet());
        assertTrue(format.isNullStringSet());
    }

    @Test
    void testIsSetPredicatesFalseByDefaultOnNewFormat() {
        final CSVFormat format = CSVFormat.newFormat(',');
        assertFalse(format.isCommentMarkerSet());
        assertFalse(format.isEscapeCharacterSet());
        assertFalse(format.isQuoteCharacterSet());
        assertFalse(format.isNullStringSet());
    }

    @Test
    void testMaxRowsDefaultIsUnlimited() {
        assertEquals(0L, CSVFormat.DEFAULT.getMaxRows());
    }

    @Test
    void testMaxRowsSet() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(5L).get();
        assertEquals(5L, format.getMaxRows());
    }

    @Test
    void testEqualsAndHashCodeForEqualFormats() {
        final CSVFormat a = CSVFormat.DEFAULT.builder().setHeader("a", "b").get();
        final CSVFormat b = CSVFormat.DEFAULT.builder().setHeader("a", "b").get();
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    void testEqualsReflexiveAndTypeChecks() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertEquals(format, format);
        assertNotEquals(format, null);
        assertNotEquals(format, "not a CSVFormat");
    }

    @Test
    void testEqualsDiffersOnDelimiter() {
        final CSVFormat a = CSVFormat.DEFAULT.builder().setDelimiter(',').get();
        final CSVFormat b = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        assertNotEquals(a, b);
    }

    @Test
    void testToStringContainsDelimiter() {
        final CSVFormat format = CSVFormat.DEFAULT;
        final String str = format.toString();
        assertTrue(str.contains("Delimiter=<,>"));
        assertTrue(str.contains("SkipHeaderRecord:false"));
    }

    @Test
    void testToStringIncludesOptionalSettingsWhenSet() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').setEscape('\\').setNullString("NULL").setHeader("a", "b").get();
        final String str = format.toString();
        assertTrue(str.contains("CommentStart=<#>"));
        assertTrue(str.contains("Escape=<\\>"));
        assertTrue(str.contains("NullString=<NULL>"));
        assertTrue(str.contains("Header:[a, b]"));
    }

    @Test
    void testFormatSimpleValues() {
        final String result = CSVFormat.DEFAULT.format("a", "b", "c");
        assertEquals("a,b,c", result);
    }

    @Test
    void testFormatWithQuotingNeeded() {
        final String result = CSVFormat.DEFAULT.format("a,b", "c");
        assertEquals("\"a,b\",c", result);
    }

    @Test
    void testCopyProducesEqualButDistinctInstance() {
        final CSVFormat original = CSVFormat.DEFAULT.builder().setHeader("a").get();
        final CSVFormat copy = CSVFormat.copy(original);
        assertEquals(original, copy);
        assertNotSame(original, copy);
    }

    @Test
    void testCopyOfNullReturnsNull() {
        assertNull(CSVFormat.copy(null));
    }

    @Test
    void testBuilderPreservesSettingsFromSourceFormat() {
        final CSVFormat source = CSVFormat.DEFAULT.builder().setDelimiter(';').setNullString("N/A").setIgnoreSurroundingSpaces(true).get();
        final CSVFormat rebuilt = source.builder().get();
        assertEquals(source, rebuilt);
        assertEquals(";", rebuilt.getDelimiterString());
        assertEquals("N/A", rebuilt.getNullString());
        assertTrue(rebuilt.getIgnoreSurroundingSpaces());
    }

    @Test
    void testParseReturnsNonNullParserAndReadsRecords() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("col1", "col2").get();
        final CSVParser parser = format.parse(new StringReader("1,2\r\n3,4\r\n"));
        assertNotNull(parser);
        final java.util.List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        assertEquals("1", records.get(0).get("col1"));
        assertEquals("4", records.get(1).get("col2"));
        parser.close();
    }

    @Test
    void testPrintAppendableReturnsWorkingPrinter() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = CSVFormat.DEFAULT.print(writer);
        printer.printRecord("x", "y");
        printer.close();
        assertEquals("x,y\r\n", writer.toString());
    }

    @Test
    void testPrintRecordAppendsRecordSeparator() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.printRecord(writer, "a", "b", "c");
        assertEquals("a,b,c\r\n", writer.toString());
    }

    @Test
    void testPrintlnWithTrailingDelimiter() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get();
        format.println(writer);
        assertEquals(",\r\n", writer.toString());
    }

    @Test
    void testPrintNullValueUsesEmptyStringByDefault() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.print(null, writer, true);
        assertEquals("", writer.toString());
    }

    @Test
    void testPrintNullValueUsesNullStringWhenSet() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        format.print(null, writer, true);
        assertEquals("NULL", writer.toString());
    }

    @Test
    void testDeprecatedWithHeaderMatchesBuilderSetHeader() {
        final CSVFormat viaWith = CSVFormat.DEFAULT.withHeader("a", "b");
        final CSVFormat viaBuilder = CSVFormat.DEFAULT.builder().setHeader("a", "b").get();
        assertEquals(viaBuilder, viaWith);
    }

    @Test
    void testDeprecatedGetDelimiterReturnsFirstChar() {
        assertEquals(',', CSVFormat.DEFAULT.getDelimiter());
    }

    @Test
    void testDeprecatedWithDelimiterLineBreakThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                CSVFormat.DEFAULT.withDelimiter('\n');
            }
        });
    }

    @Test
    void testDeprecatedWithAllowDuplicateHeaderNamesTrue() {
        final CSVFormat format = CSVFormat.DEFAULT.withAllowDuplicateHeaderNames(false);
        assertEquals(DuplicateHeaderMode.ALLOW_EMPTY, format.getDuplicateHeaderMode());
        assertFalse(format.getAllowDuplicateHeaderNames());
    }

    @Test
    void testDeprecatedWithSystemRecordSeparator() {
        final CSVFormat format = CSVFormat.DEFAULT.withSystemRecordSeparator();
        assertEquals(System.lineSeparator(), format.getRecordSeparator());
    }

    @Test
    void testDeprecatedWithTrim() {
        assertTrue(CSVFormat.DEFAULT.withTrim().getTrim());
        assertFalse(CSVFormat.DEFAULT.withTrim(false).getTrim());
    }

    @Test
    void testMultiCharDelimiterRoundTrip() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        final StringWriter writer = new StringWriter();
        format.printRecord(writer, "a", "b");
        assertEquals("a::b\r\n", writer.toString());
    }

    @Test
    void testSerialVersionStable() throws IOException, ClassNotFoundException {
        final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
        final java.io.ObjectOutputStream oos = new java.io.ObjectOutputStream(baos);
        oos.writeObject(CSVFormat.DEFAULT.builder().setHeader("a", "b").get());
        oos.close();
        final java.io.ObjectInputStream ois = new java.io.ObjectInputStream(new java.io.ByteArrayInputStream(baos.toByteArray()));
        final CSVFormat deserialized = (CSVFormat) ois.readObject();
        ois.close();
        assertEquals(CSVFormat.DEFAULT.builder().setHeader("a", "b").get(), deserialized);
    }
}
