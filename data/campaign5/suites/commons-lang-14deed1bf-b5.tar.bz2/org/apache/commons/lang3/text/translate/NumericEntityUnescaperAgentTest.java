/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text.translate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringWriter;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link NumericEntityUnescaper}.
 */
@Deprecated
class NumericEntityUnescaperAgentTest {

    @Test
    void testIsSetDefaultOption() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertTrue(neu.isSet(NumericEntityUnescaper.OPTION.semiColonRequired));
        assertFalse(neu.isSet(NumericEntityUnescaper.OPTION.semiColonOptional));
        assertFalse(neu.isSet(NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
    }

    @Test
    void testIsSetExplicitOptions() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.semiColonOptional,
                NumericEntityUnescaper.OPTION.errorIfNoSemiColon);
        assertTrue(neu.isSet(NumericEntityUnescaper.OPTION.semiColonOptional));
        assertTrue(neu.isSet(NumericEntityUnescaper.OPTION.errorIfNoSemiColon));
        assertFalse(neu.isSet(NumericEntityUnescaper.OPTION.semiColonRequired));
    }

    @Test
    void testDecimalEntityWithSemicolon() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("Test A test", neu.translate("Test &#65; test"));
    }

    @Test
    void testHexEntityLowerXWithSemicolon() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("A", neu.translate("&#x41;"));
    }

    @Test
    void testHexEntityUpperXWithSemicolon() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        assertEquals("A", neu.translate("&#X41;"));
    }

    @Test
    void testOutOfBounds() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();

        assertEquals("Test &", neu.translate("Test &"));
        assertEquals("Test &#", neu.translate("Test &#"));
        assertEquals("Test &#x", neu.translate("Test &#x"));
        assertEquals("Test &#X", neu.translate("Test &#X"));
    }

    @Test
    void testSupplementaryUnescaping() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final String input = "&#68642;";
        final String expected = "𐰢";

        assertEquals(expected, neu.translate(input));
    }

    @Test
    void testUnfinishedEntityOptional() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.semiColonOptional);
        final String input = "Test &#x30 not test";
        final String expected = "Test 0 not test";

        assertEquals(expected, neu.translate(input));
    }

    @Test
    void testUnfinishedEntityIgnoredByDefault() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final String input = "Test &#x30 not test";

        assertEquals(input, neu.translate(input));
    }

    @Test
    void testUnfinishedEntityErrors() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper(NumericEntityUnescaper.OPTION.errorIfNoSemiColon);
        final String input = "Test &#x30 not test";

        final IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                neu.translate(input);
            }
        });
        assertEquals("Semi-colon required at end of numeric entity", thrown.getMessage());
    }

    @Test
    void testNonNumericEntityReturnsZeroAndWritesNothing() throws IOException {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final StringWriter writer = new StringWriter();

        final int consumed = neu.translate("&#abc;", 0, writer);

        assertEquals(0, consumed);
        assertEquals("", writer.toString());
    }

    @Test
    void testNonAmpersandCharacterReturnsZero() throws IOException {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final StringWriter writer = new StringWriter();

        final int consumed = neu.translate("Test", 0, writer);

        assertEquals(0, consumed);
        assertEquals("", writer.toString());
    }

    @Test
    void testLoneHexMarkerAtEndReturnsZero() throws IOException {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final StringWriter writer = new StringWriter();

        // "&#x" with nothing following the 'x' hits the start == seqEnd branch.
        final int consumed = neu.translate("&#x", 0, writer);

        assertEquals(0, consumed);
        assertEquals("", writer.toString());
    }

    @Test
    void testTranslateAtNonZeroIndex() throws IOException {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final StringWriter writer = new StringWriter();
        final String input = "xx&#65;yy";

        final int consumed = neu.translate(input, 2, writer);

        assertEquals(5, consumed);
        assertEquals("A", writer.toString());
    }

    @Test
    void testZeroEntityValueWritesNulCharacter() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final String result = neu.translate("&#0;");

        assertEquals(1, result.length());
        assertEquals('\u0000', result.charAt(0));
    }

    @Test
    void testMaxBmpCodePointDoesNotProduceSurrogatePair() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final String result = neu.translate("&#65535;");

        assertEquals(1, result.length());
        assertEquals(0xFFFF, result.charAt(0));
    }

    @Test
    void testJustAboveBmpProducesSurrogatePair() {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final String result = neu.translate("&#65536;");

        assertEquals(2, result.length());
        assertTrue(Character.isHighSurrogate(result.charAt(0)));
        assertTrue(Character.isLowSurrogate(result.charAt(1)));
        assertEquals(65536, Character.toCodePoint(result.charAt(0), result.charAt(1)));
    }

    @Test
    void testReturnedConsumedLengthIncludesSemicolonAndHexMarker() throws IOException {
        final NumericEntityUnescaper neu = new NumericEntityUnescaper();
        final StringWriter writer = new StringWriter();

        // "&#x41;" => consumed = 2 ("&#") + 1 ("x") + 2 (digits "41") + 1 (";") = 6
        final int consumed = neu.translate("&#x41;", 0, writer);

        assertEquals(6, consumed);
        assertEquals("A", writer.toString());
    }
}
