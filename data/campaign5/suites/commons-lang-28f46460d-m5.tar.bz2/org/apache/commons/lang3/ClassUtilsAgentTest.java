/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link ClassUtils}.
 */
class ClassUtilsAgentTest {

    interface Alpha {
        // marker interface
    }

    interface Beta extends Alpha {
        // marker interface
    }

    static class Parent implements Beta {
        // empty
    }

    static class Child extends Parent {
        // empty
    }

    static class Inner {
        // used to test nested class name handling
    }

    private static class PrivateInner {
        // used to test isPublic == false
    }

    private static String buildString(final int length, final char c) {
        final StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            sb.append(c);
        }
        return sb.toString();
    }

    // -- comparator() --

    @Test
    void testComparator() {
        final Comparator<Class<?>> comparator = ClassUtils.comparator();
        assertNotNull(comparator);
        final List<Class<?>> list = new ArrayList<Class<?>>();
        list.add(String.class);
        list.add(Integer.class);
        list.add(Boolean.class);
        Collections.sort(list, comparator);
        assertEquals(Boolean.class, list.get(0));
        assertEquals(Integer.class, list.get(1));
        assertEquals(String.class, list.get(2));
    }

    // -- convertClassesToClassNames / convertClassNamesToClasses --

    @Test
    void testConvertClassesToClassNames() {
        assertNull(ClassUtils.convertClassesToClassNames(null));
        final List<Class<?>> input = new ArrayList<Class<?>>();
        input.add(String.class);
        input.add(null);
        final List<String> names = ClassUtils.convertClassesToClassNames(input);
        assertEquals(2, names.size());
        assertEquals("java.lang.String", names.get(0));
        assertNull(names.get(1));
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Test
    void testConvertClassesToClassNamesInvalidEntry() {
        final List rawList = new ArrayList();
        rawList.add("not a class");
        final List<Class<?>> badList = rawList;
        assertThrows(ClassCastException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ClassUtils.convertClassesToClassNames(badList);
            }
        });
    }

    @Test
    void testConvertClassNamesToClasses() {
        assertNull(ClassUtils.convertClassNamesToClasses(null));
        final List<String> names = new ArrayList<String>();
        names.add("java.lang.String");
        names.add("org.apache.commons.lang3.DoesNotExistAtAll");
        names.add(null);
        final List<Class<?>> classes = ClassUtils.convertClassNamesToClasses(names);
        assertEquals(3, classes.size());
        assertEquals(String.class, classes.get(0));
        assertNull(classes.get(1));
        assertNull(classes.get(2));
    }

    // -- getAbbreviatedName --

    @Test
    void testGetAbbreviatedNameClass() {
        assertEquals("", ClassUtils.getAbbreviatedName((Class<?>) null, 1));
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName(String.class, 5));
        assertEquals("j.lang.String", ClassUtils.getAbbreviatedName(String.class, 15));
        assertEquals("java.lang.String", ClassUtils.getAbbreviatedName(String.class, 30));
    }

    @Test
    void testGetAbbreviatedNameString() {
        assertEquals("", ClassUtils.getAbbreviatedName((String) null, 1));
        assertEquals("java.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 30));
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName("java.lang.String", 5));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ClassUtils.getAbbreviatedName("java.lang.String", 0);
            }
        });
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ClassUtils.getAbbreviatedName("java.lang.String", -1);
            }
        });
    }

    // -- getAllInterfaces / getAllSuperclasses --

    @Test
    void testGetAllInterfacesNull() {
        assertNull(ClassUtils.getAllInterfaces(null));
    }

    @Test
    void testGetAllInterfaces() {
        final List<Class<?>> interfaces = ClassUtils.getAllInterfaces(Child.class);
        assertEquals(2, interfaces.size());
        assertEquals(Beta.class, interfaces.get(0));
        assertEquals(Alpha.class, interfaces.get(1));
    }

    @Test
    void testGetAllSuperclassesNull() {
        assertNull(ClassUtils.getAllSuperclasses(null));
    }

    @Test
    void testGetAllSuperclasses() {
        final List<Class<?>> superclasses = ClassUtils.getAllSuperclasses(Child.class);
        assertEquals(2, superclasses.size());
        assertEquals(Parent.class, superclasses.get(0));
        assertEquals(Object.class, superclasses.get(1));
    }

    // -- getCanonicalName --

    @Test
    void testGetCanonicalNameClass() {
        assertEquals("", ClassUtils.getCanonicalName((Class<?>) null));
        assertEquals("fallback", ClassUtils.getCanonicalName((Class<?>) null, "fallback"));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName(String.class));
        assertEquals("java.lang.String[]", ClassUtils.getCanonicalName(String[].class));
    }

    @Test
    void testGetCanonicalNameObject() {
        assertEquals("", ClassUtils.getCanonicalName((Object) null));
        assertEquals("fallback", ClassUtils.getCanonicalName((Object) null, "fallback"));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName("hello"));
    }

    // -- getClass --

    @Test
    void testGetClassStringPrimitiveArray() throws ClassNotFoundException {
        assertEquals(int[].class, ClassUtils.getClass("[I"));
        assertEquals(String[].class, ClassUtils.getClass("java.lang.String[]"));
        assertEquals(String.class, ClassUtils.getClass("java.lang.String"));
    }

    @Test
    void testGetClassStringInnerClass() throws ClassNotFoundException {
        final Class<?> cls = ClassUtils.getClass("java.util.Map.Entry");
        assertEquals(java.util.Map.Entry.class, cls);
    }

    @Test
    void testGetClassNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws ClassNotFoundException {
                ClassUtils.getClass((String) null);
            }
        });
    }

    @Test
    void testGetClassNotFound() {
        assertThrows(ClassNotFoundException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws ClassNotFoundException {
                ClassUtils.getClass("org.apache.commons.lang3.DoesNotExistAtAll");
            }
        });
    }

    @Test
    void testGetClassTooManyArrayDimensions() {
        final StringBuilder sb = new StringBuilder("java.lang.String");
        for (int i = 0; i < 256; i++) {
            sb.append("[]");
        }
        final String className = sb.toString();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws ClassNotFoundException {
                ClassUtils.getClass(className);
            }
        });
    }

    @Test
    void testGetClassNameTooLong() {
        final String className = buildString(70000, 'a');
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws ClassNotFoundException {
                ClassUtils.getClass(className);
            }
        });
    }

    @Test
    void testGetClassWithClassLoader() throws ClassNotFoundException {
        final ClassLoader loader = ClassUtilsAgentTest.class.getClassLoader();
        assertEquals(String.class, ClassUtils.getClass(loader, "java.lang.String"));
        assertEquals(String.class, ClassUtils.getClass(loader, "java.lang.String", true));
    }

    // -- getComponentType --

    @Test
    void testGetComponentType() {
        assertNull(ClassUtils.getComponentType(null));
        assertEquals(String.class, ClassUtils.getComponentType(String[].class));
    }

    // -- getName --

    @Test
    void testGetNameClass() {
        assertEquals("", ClassUtils.getName((Class<?>) null));
        assertEquals("fallback", ClassUtils.getName((Class<?>) null, "fallback"));
        assertEquals("java.lang.String", ClassUtils.getName(String.class));
        assertEquals("java.lang.String", ClassUtils.getName(String.class, "fallback"));
    }

    @Test
    void testGetNameObject() {
        assertEquals("", ClassUtils.getName((Object) null));
        assertEquals("fallback", ClassUtils.getName((Object) null, "fallback"));
        assertEquals("java.lang.String", ClassUtils.getName("hi"));
        assertEquals("java.lang.String", ClassUtils.getName("hi", "fallback"));
    }

    // -- getPackageCanonicalName --

    @Test
    void testGetPackageCanonicalNameClass() {
        assertEquals("", ClassUtils.getPackageCanonicalName((Class<?>) null));
        assertEquals("", ClassUtils.getPackageCanonicalName(int[].class));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName(String[].class));
    }

    @Test
    void testGetPackageCanonicalNameObject() {
        assertEquals("fallback", ClassUtils.getPackageCanonicalName(null, "fallback"));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName("hi", "fallback"));
    }

    @Test
    void testGetPackageCanonicalNameString() {
        assertEquals("", ClassUtils.getPackageCanonicalName((String) null));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName("java.lang.String"));
    }

    // -- getPackageName --

    @Test
    void testGetPackageNameClass() {
        assertEquals("", ClassUtils.getPackageName((Class<?>) null));
        assertEquals("java.lang", ClassUtils.getPackageName(String.class));
        assertEquals("", ClassUtils.getPackageName(int[].class));
    }

    @Test
    void testGetPackageNameObject() {
        assertEquals("fallback", ClassUtils.getPackageName(null, "fallback"));
        assertEquals("java.lang", ClassUtils.getPackageName("hi", "fallback"));
    }

    @Test
    void testGetPackageNameString() {
        assertEquals("", ClassUtils.getPackageName((String) null));
        assertEquals("", ClassUtils.getPackageName(""));
        assertEquals("java.lang", ClassUtils.getPackageName("java.lang.String"));
        assertEquals("java.lang", ClassUtils.getPackageName("[Ljava.lang.String;"));
    }

    // -- getPublicMethod --

    @Test
    void testGetPublicMethod() throws Exception {
        final Set<String> set = Collections.unmodifiableSet(new HashSet<String>());
        final Method method = ClassUtils.getPublicMethod(set.getClass(), "isEmpty");
        assertTrue(Modifier.isPublic(method.getDeclaringClass().getModifiers()));
        final Object result = method.invoke(set);
        assertEquals(Boolean.TRUE, result);
    }

    @Test
    void testGetPublicMethodNoSuchMethod() {
        assertThrows(NoSuchMethodException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Exception {
                ClassUtils.getPublicMethod(String.class, "noSuchMethodAtAll");
            }
        });
    }

    @Test
    void testGetPublicMethodNullClass() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Exception {
                ClassUtils.getPublicMethod(null, "toString");
            }
        });
    }

    // -- getShortCanonicalName --

    @Test
    void testGetShortCanonicalNameClass() {
        assertEquals("", ClassUtils.getShortCanonicalName((Class<?>) null));
        assertEquals("int[]", ClassUtils.getShortCanonicalName(int[].class));
        assertEquals("String[]", ClassUtils.getShortCanonicalName(String[].class));
        assertEquals("String", ClassUtils.getShortCanonicalName(String.class));
    }

    @Test
    void testGetShortCanonicalNameObject() {
        assertEquals("fallback", ClassUtils.getShortCanonicalName(null, "fallback"));
        assertEquals("String", ClassUtils.getShortCanonicalName("hi", "fallback"));
    }

    @Test
    void testGetShortCanonicalNameString() {
        assertEquals("int[]", ClassUtils.getShortCanonicalName("[I"));
        assertEquals("Entry", ClassUtils.getShortCanonicalName("java.util.Map.Entry"));
    }

    // -- getShortClassName --

    @Test
    void testGetShortClassNameClass() {
        assertEquals("", ClassUtils.getShortClassName((Class<?>) null));
        assertEquals("int[]", ClassUtils.getShortClassName(int[].class));
        assertEquals("String", ClassUtils.getShortClassName(String.class));
        assertEquals("ClassUtilsAgentTest.Inner", ClassUtils.getShortClassName(Inner.class));
    }

    @Test
    void testGetShortClassNameAnonymous() {
        final Runnable anon = new Runnable() {
            @Override
            public void run() {
                // no-op
            }
        };
        final String expected = ClassUtils.getShortClassName(anon.getClass().getName());
        assertEquals(expected, ClassUtils.getShortClassName(anon.getClass()));
        assertTrue(ClassUtils.getShortClassName(anon.getClass()).startsWith("ClassUtilsAgentTest."));
    }

    @Test
    void testGetShortClassNameObject() {
        assertEquals("fallback", ClassUtils.getShortClassName(null, "fallback"));
        assertEquals("String", ClassUtils.getShortClassName("hi", "fallback"));
    }

    @Test
    void testGetShortClassNameString() {
        assertEquals("", ClassUtils.getShortClassName((String) null));
        assertEquals("", ClassUtils.getShortClassName(""));
        assertEquals("int[]", ClassUtils.getShortClassName("[I"));
        assertEquals("String[]", ClassUtils.getShortClassName("[Ljava.lang.String;"));
        assertEquals("Map.Entry", ClassUtils.getShortClassName("java.util.Map$Entry"));
        assertEquals("ClassUtils", ClassUtils.getShortClassName("org.apache.commons.lang3.ClassUtils"));
    }

    // -- getSimpleName --

    @Test
    void testGetSimpleNameClass() {
        assertEquals("", ClassUtils.getSimpleName((Class<?>) null));
        assertEquals("fallback", ClassUtils.getSimpleName((Class<?>) null, "fallback"));
        assertEquals("String", ClassUtils.getSimpleName(String.class));
    }

    @Test
    void testGetSimpleNameObject() {
        assertEquals("", ClassUtils.getSimpleName((Object) null));
        assertEquals("fallback", ClassUtils.getSimpleName((Object) null, "fallback"));
        assertEquals("String", ClassUtils.getSimpleName("hi"));
    }

    // -- hierarchy --

    @Test
    void testHierarchyExcludeInterfaces() {
        final Iterable<Class<?>> hierarchy = ClassUtils.hierarchy(Child.class);
        final List<Class<?>> list = new ArrayList<Class<?>>();
        final Iterator<Class<?>> it = hierarchy.iterator();
        while (it.hasNext()) {
            list.add(it.next());
        }
        assertEquals(3, list.size());
        assertEquals(Child.class, list.get(0));
        assertEquals(Parent.class, list.get(1));
        assertEquals(Object.class, list.get(2));
    }

    @Test
    void testHierarchyIncludeInterfaces() {
        final Iterable<Class<?>> hierarchy = ClassUtils.hierarchy(Child.class, ClassUtils.Interfaces.INCLUDE);
        final List<Class<?>> list = new ArrayList<Class<?>>();
        final Iterator<Class<?>> it = hierarchy.iterator();
        while (it.hasNext()) {
            list.add(it.next());
        }
        assertEquals(5, list.size());
        assertEquals(Child.class, list.get(0));
        assertEquals(Parent.class, list.get(1));
        assertEquals(Beta.class, list.get(2));
        assertEquals(Alpha.class, list.get(3));
        assertEquals(Object.class, list.get(4));
    }

    @Test
    void testHierarchyIteratorRemoveUnsupported() {
        final Iterator<Class<?>> it = ClassUtils.hierarchy(Child.class).iterator();
        assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                it.remove();
            }
        });
    }

    // -- isAssignable --

    @Test
    void testIsAssignable() {
        assertTrue(ClassUtils.isAssignable(Integer.TYPE, Long.TYPE));
        assertFalse(ClassUtils.isAssignable(Long.TYPE, Integer.TYPE));
        assertTrue(ClassUtils.isAssignable(null, String.class));
        assertFalse(ClassUtils.isAssignable(null, Integer.TYPE));
        assertFalse(ClassUtils.isAssignable(String.class, null));
        assertFalse(ClassUtils.isAssignable((Class<?>) null, (Class<?>) null));
        assertTrue(ClassUtils.isAssignable(Integer.class, Integer.TYPE));
        assertFalse(ClassUtils.isAssignable(Integer.class, Integer.TYPE, false));
    }

    @Test
    void testIsAssignableArray() {
        assertTrue(ClassUtils.isAssignable((Class<?>[]) null, (Class<?>[]) null));
        assertTrue(ClassUtils.isAssignable(new Class<?>[] { String.class }, new Class<?>[] { Object.class }));
        assertFalse(ClassUtils.isAssignable(new Class<?>[] { String.class }, new Class<?>[] { String.class, Integer.class }));
    }

    // -- isInnerClass --

    @Test
    void testIsInnerClass() {
        assertFalse(ClassUtils.isInnerClass(null));
        assertFalse(ClassUtils.isInnerClass(ClassUtilsAgentTest.class));
        assertTrue(ClassUtils.isInnerClass(Inner.class));
    }

    // -- isPrimitiveOrWrapper / isPrimitiveWrapper --

    @Test
    void testIsPrimitiveOrWrapper() {
        assertFalse(ClassUtils.isPrimitiveOrWrapper(null));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(Integer.TYPE));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(Integer.class));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(Void.TYPE));
        assertFalse(ClassUtils.isPrimitiveOrWrapper(String.class));
    }

    @Test
    void testIsPrimitiveWrapper() {
        assertFalse(ClassUtils.isPrimitiveWrapper(null));
        assertTrue(ClassUtils.isPrimitiveWrapper(Integer.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(Integer.TYPE));
        assertFalse(ClassUtils.isPrimitiveWrapper(String.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(Void.class));
    }

    // -- isPublic --

    @Test
    void testIsPublic() {
        assertTrue(ClassUtils.isPublic(String.class));
        assertFalse(ClassUtils.isPublic(PrivateInner.class));
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ClassUtils.isPublic(null);
            }
        });
    }

    // -- primitivesToWrappers / primitiveToWrapper --

    @Test
    void testPrimitivesToWrappers() {
        assertNull(ClassUtils.primitivesToWrappers((Class<?>[]) null));
        assertEquals(0, ClassUtils.primitivesToWrappers().length);
        final Class<?>[] result = ClassUtils.primitivesToWrappers(Integer.TYPE, Boolean.TYPE, String.class, null);
        assertEquals(4, result.length);
        assertEquals(Integer.class, result[0]);
        assertEquals(Boolean.class, result[1]);
        assertEquals(String.class, result[2]);
        assertNull(result[3]);
    }

    @Test
    void testPrimitiveToWrapper() {
        assertNull(ClassUtils.primitiveToWrapper(null));
        assertEquals(Integer.class, ClassUtils.primitiveToWrapper(Integer.TYPE));
        assertEquals(String.class, ClassUtils.primitiveToWrapper(String.class));
        assertSame(Void.TYPE, ClassUtils.primitiveToWrapper(Void.TYPE));
    }

    // -- toClass --

    @Test
    void testToClass() {
        assertNull(ClassUtils.toClass((Object[]) null));
        assertEquals(0, ClassUtils.toClass().length);
        final Class<?>[] result = ClassUtils.toClass("hi", Integer.valueOf(1), null);
        assertEquals(3, result.length);
        assertEquals(String.class, result[0]);
        assertEquals(Integer.class, result[1]);
        assertNull(result[2]);
    }

    // -- wrappersToPrimitives / wrapperToPrimitive --

    @Test
    void testWrappersToPrimitives() {
        assertNull(ClassUtils.wrappersToPrimitives((Class<?>[]) null));
        assertEquals(0, ClassUtils.wrappersToPrimitives().length);
        final Class<?>[] result = ClassUtils.wrappersToPrimitives(Integer.class, String.class, null);
        assertEquals(3, result.length);
        assertEquals(Integer.TYPE, result[0]);
        assertNull(result[1]);
        assertNull(result[2]);
    }

    @Test
    void testWrapperToPrimitive() {
        assertNull(ClassUtils.wrapperToPrimitive(null));
        assertEquals(Integer.TYPE, ClassUtils.wrapperToPrimitive(Integer.class));
        assertNull(ClassUtils.wrapperToPrimitive(String.class));
    }

    // -- constructor --

    @Test
    void testConstructor() {
        assertNotNull(new ClassUtils());
    }
}
