/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.StringWriter;

import org.apache.commons.csv.CSVFormat.Builder;
import org.apache.commons.csv.CSVFormat.Predefined;
import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link CSVFormat}.
 */
class CSVFormatAgentTest {

    private enum HeaderEnum {
        Name, Email, Phone
    }

    @Test
    void testNewFormatDefaults() {
        final CSVFormat format = CSVFormat.newFormat(';');
        assertEquals(";", format.getDelimiterString());
        assertNull(format.getQuoteCharacter());
        assertNull(format.getCommentMarker());
        assertNull(format.getEscapeCharacter());
        assertFalse(format.getIgnoreEmptyLines());
        assertFalse(format.getSkipHeaderRecord());
        assertNull(format.getRecordSeparator());
        assertNull(format.getHeader());
    }

    @Test
    void testDefaultFormat() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertTrue(format.getIgnoreEmptyLines());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, format.getDuplicateHeaderMode());
    }

    @Test
    void testExcelFormat() {
        final CSVFormat format = CSVFormat.EXCEL;
        assertFalse(format.getIgnoreEmptyLines());
        assertTrue(format.getAllowMissingColumnNames());
        assertTrue(format.getTrailingData());
        assertTrue(format.getLenientEof());
    }

    @Test
    void testRfc4180Format() {
        assertFalse(CSVFormat.RFC4180.getIgnoreEmptyLines());
    }

    @Test
    void testTdfFormat() {
        assertEquals("\t", CSVFormat.TDF.getDelimiterString());
        assertTrue(CSVFormat.TDF.getIgnoreSurroundingSpaces());
    }

    @Test
    void testMySqlFormat() {
        final CSVFormat format = CSVFormat.MYSQL;
        assertEquals("\t", format.getDelimiterString());
        assertNull(format.getQuoteCharacter());
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
        assertEquals("\\N", format.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, format.getQuoteMode());
    }

    @Test
    void testValueOf() {
        assertSame(CSVFormat.DEFAULT, CSVFormat.valueOf("Default"));
        assertSame(CSVFormat.EXCEL, CSVFormat.valueOf("Excel"));
        assertSame(CSVFormat.MYSQL, CSVFormat.valueOf("MySQL"));
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.valueOf("DoesNotExist"));
    }

    @Test
    void testPredefinedGetFormat() {
        assertSame(CSVFormat.RFC4180, Predefined.RFC4180.getFormat());
        assertSame(CSVFormat.TDF, Predefined.TDF.getFormat());
    }

    @Test
    void testBuilderDelimiterCannotBeLineBreakChar() {
        assertThrows(IllegalArgumentException.class, () -> Builder.create().setDelimiter('\n').get());
        assertThrows(IllegalArgumentException.class, () -> Builder.create().setDelimiter('\r').get());
    }

    @Test
    void testBuilderDelimiterCannotBeEmptyString() {
        assertThrows(IllegalArgumentException.class, () -> Builder.create().setDelimiter("").get());
    }

    @Test
    void testBuilderDelimiterStringContainingLineBreakThrows() {
        assertThrows(IllegalArgumentException.class, () -> Builder.create().setDelimiter("a\nb").get());
    }

    @Test
    void testBuilderMultiCharDelimiter() {
        final CSVFormat format = Builder.create().setDelimiter("||").get();
        assertEquals("||", format.getDelimiterString());
        assertArrayEquals(new char[] {'|', '|'}, format.getDelimiterCharArray());
    }

    @Test
    void testBuilderCommentMarkerCannotBeLineBreak() {
        assertThrows(IllegalArgumentException.class, () -> Builder.create().setCommentMarker('\n').get());
    }

    @Test
    void testBuilderEscapeCannotBeLineBreak() {
        assertThrows(IllegalArgumentException.class, () -> Builder.create().setEscape('\r').get());
    }

    @Test
    void testBuilderQuoteCannotBeLineBreak() {
        assertThrows(IllegalArgumentException.class, () -> Builder.create().setQuote('\n').get());
    }

    @Test
    void testQuoteCharacterSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, () -> Builder.create().setDelimiter(',').setQuote(',').get());
    }

    @Test
    void testEscapeCharacterSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, () -> Builder.create().setDelimiter(',').setEscape(',').get());
    }

    @Test
    void testCommentMarkerSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, () -> Builder.create().setDelimiter(',').setCommentMarker(',').get());
    }

    @Test
    void testQuoteCharacterSameAsCommentMarkerThrows() {
        assertThrows(IllegalArgumentException.class, () -> Builder.create().setCommentMarker('#').setQuote('#').get());
    }

    @Test
    void testEscapeCharacterSameAsCommentMarkerThrows() {
        assertThrows(IllegalArgumentException.class, () -> Builder.create().setCommentMarker('#').setEscape('#').get());
    }

    @Test
    void testQuoteModeNoneWithoutEscapeThrows() {
        assertThrows(IllegalArgumentException.class, () -> Builder.create().setQuote(null).setQuoteMode(QuoteMode.NONE).get());
    }

    @Test
    void testQuoteModeNoneWithEscapeIsAllowed() {
        final CSVFormat format = Builder.create().setEscape('\\').setQuoteMode(QuoteMode.NONE).get();
        assertEquals(QuoteMode.NONE, format.getQuoteMode());
    }

    @Test
    void testDuplicateHeaderNamesDisallowedByDefaultBehavior() {
        assertThrows(IllegalArgumentException.class,
                () -> Builder.create().setHeader("A", "B", "A").setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).get());
    }

    @Test
    void testDuplicateHeaderNamesAllowedAll() {
        final CSVFormat format = Builder.create().setHeader("A", "B", "A").setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_ALL).get();
        assertArrayEquals(new String[] {"A", "B", "A"}, format.getHeader());
    }

    @Test
    void testDuplicateEmptyHeaderNamesAllowedWithAllowEmpty() {
        final CSVFormat format = Builder.create().setHeader("A", "", "").setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).get();
        assertArrayEquals(new String[] {"A", "", ""}, format.getHeader());
    }

    @Test
    void testDuplicateNonEmptyHeaderNamesDisallowedWithAllowEmpty() {
        assertThrows(IllegalArgumentException.class,
                () -> Builder.create().setHeader("A", "A").setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).get());
    }

    @Test
    void testGetHeaderReturnsDefensiveCopy() {
        final CSVFormat format = Builder.create().setHeader("A", "B").get();
        final String[] header1 = format.getHeader();
        header1[0] = "mutated";
        final String[] header2 = format.getHeader();
        assertEquals("A", header2[0]);
    }

    @Test
    void testSetHeaderNullDisablesHeader() {
        final CSVFormat format = Builder.create().setHeader("A", "B").get().builder().setHeader((String[]) null).get();
        assertNull(format.getHeader());
    }

    @Test
    void testSetHeaderFromEnum() {
        final CSVFormat format = Builder.create().setHeader(HeaderEnum.class).get();
        assertArrayEquals(new String[] {"Name", "Email", "Phone"}, format.getHeader());
    }

    @Test
    void testSetHeaderFromNullEnum() {
        final CSVFormat format = Builder.create().setHeader((Class<? extends Enum<?>>) null).get();
        assertNull(format.getHeader());
    }

    @Test
    void testGetHeaderCommentsReturnsDefensiveCopy() {
        final CSVFormat format = Builder.create().setHeaderComments("a", "b").get();
        final String[] comments1 = format.getHeaderComments();
        comments1[0] = "mutated";
        final String[] comments2 = format.getHeaderComments();
        assertEquals("a", comments2[0]);
    }

    @Test
    void testSetHeaderCommentsFromObjects() {
        final CSVFormat format = Builder.create().setHeaderComments((Object) "x", (Object) 42).get();
        assertArrayEquals(new String[] {"x", "42"}, format.getHeaderComments());
    }

    @Test
    void testNullStringSetsQuotedNullString() {
        final CSVFormat format = Builder.create().setQuote('"').setNullString("NULL").get();
        assertTrue(format.isNullStringSet());
        assertEquals("NULL", format.getNullString());
    }

    @Test
    void testIsQuoteCharacterSet() {
        assertTrue(Builder.create().setQuote('"').get().isQuoteCharacterSet());
        assertFalse(Builder.create().setQuote(null).get().isQuoteCharacterSet());
    }

    @Test
    void testIsEscapeCharacterSet() {
        assertTrue(Builder.create().setEscape('\\').get().isEscapeCharacterSet());
        assertFalse(CSVFormat.newFormat(',').isEscapeCharacterSet());
    }

    @Test
    void testIsCommentMarkerSet() {
        assertTrue(Builder.create().setCommentMarker('#').get().isCommentMarkerSet());
        assertFalse(CSVFormat.newFormat(',').isCommentMarkerSet());
    }

    @Test
    void testMaxRowsDefaultIsZeroAndUnused() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertEquals(0L, format.getMaxRows());
        assertFalse(format.useMaxRows());
        assertTrue(format.useRow(1000L));
    }

    @Test
    void testMaxRowsLimitsUse() {
        final CSVFormat format = Builder.create().setMaxRows(2).get();
        assertTrue(format.useMaxRows());
        assertTrue(format.useRow(1));
        assertTrue(format.useRow(2));
        assertFalse(format.useRow(3));
    }

    @Test
    void testEqualsAndHashCode() {
        final CSVFormat a = CSVFormat.DEFAULT;
        final CSVFormat b = Builder.create(CSVFormat.DEFAULT).get();
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
        final CSVFormat c = a.builder().setDelimiter(';').get();
        assertNotEquals(a, c);
    }

    @Test
    void testEqualsReflexiveAndAgainstOtherTypes() {
        final CSVFormat a = CSVFormat.DEFAULT;
        assertEquals(a, a);
        assertNotEquals(a, null);
        assertNotEquals(a, "not a format");
    }

    @Test
    void testToStringContainsDelimiter() {
        final String s = CSVFormat.DEFAULT.toString();
        assertTrue(s.contains("Delimiter=<,>"));
    }

    @Test
    void testBuilderRoundTripPreservesSettings() {
        final CSVFormat original = Builder.create()
                .setDelimiter(';')
                .setQuote('\'')
                .setEscape('\\')
                .setCommentMarker('#')
                .setRecordSeparator("\n")
                .setSkipHeaderRecord(true)
                .setTrim(true)
                .setTrailingDelimiter(true)
                .setIgnoreHeaderCase(true)
                .setIgnoreSurroundingSpaces(true)
                .setAllowMissingColumnNames(true)
                .setAutoFlush(true)
                .setLenientEof(true)
                .setTrailingData(true)
                .get();
        final CSVFormat copy = original.builder().get();
        assertEquals(original, copy);
        assertEquals(';', copy.getDelimiter());
        assertEquals(Character.valueOf('\''), copy.getQuoteCharacter());
        assertEquals(Character.valueOf('\\'), copy.getEscapeCharacter());
        assertEquals(Character.valueOf('#'), copy.getCommentMarker());
        assertEquals("\n", copy.getRecordSeparator());
        assertTrue(copy.getSkipHeaderRecord());
        assertTrue(copy.getTrim());
        assertTrue(copy.getTrailingDelimiter());
        assertTrue(copy.getIgnoreHeaderCase());
        assertTrue(copy.getIgnoreSurroundingSpaces());
        assertTrue(copy.getAllowMissingColumnNames());
        assertTrue(copy.getAutoFlush());
        assertTrue(copy.getLenientEof());
        assertTrue(copy.getTrailingData());
    }

    @Test
    void testFormatSimpleValues() {
        final String result = CSVFormat.DEFAULT.format("a", "b", "c");
        assertEquals("a,b,c", result);
    }

    @Test
    void testFormatQuotesValueContainingDelimiter() {
        final String result = CSVFormat.DEFAULT.format("a,b", "c");
        assertEquals("\"a,b\",c", result);
    }

    @Test
    void testFormatNullValueWithoutNullString() {
        final String result = CSVFormat.DEFAULT.format((Object) null);
        assertEquals("", result);
    }

    @Test
    void testFormatNullValueWithNullString() {
        final CSVFormat format = Builder.create().setNullString("NULL").get();
        assertEquals("NULL", format.format((Object) null));
    }

    @Test
    void testPrintRecordAppendsRecordSeparator() throws Exception {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.printRecord(writer, "x", "y");
        assertEquals("x,y\r\n", writer.toString());
    }

    @Test
    void testPrintSingleValueWithQuotingWhenNeeded() throws Exception {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.print("hello", writer, true);
        assertEquals("hello", writer.toString());
    }

    @Test
    void testPrintSingleValueAddsDelimiterWhenNotNewRecord() throws Exception {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.print("hello", writer, false);
        assertEquals(",hello", writer.toString());
    }

    @Test
    void testPrintlnWithTrailingDelimiterAndRecordSeparator() throws Exception {
        final StringWriter writer = new StringWriter();
        final CSVFormat format = Builder.create().setDelimiter(',').setRecordSeparator("\n").setTrailingDelimiter(true).get();
        format.println(writer);
        assertEquals(",\n", writer.toString());
    }

    @Test
    void testPrintTrimsValueWhenTrimEnabled() throws Exception {
        final StringWriter writer = new StringWriter();
        final CSVFormat format = Builder.create().setTrim(true).get();
        format.print("  hello  ", writer, true);
        assertEquals("hello", writer.toString());
    }

    @Test
    void testParseReturnsNonNullParser() throws Exception {
        final CSVParser parser = CSVFormat.DEFAULT.parse(new java.io.StringReader("a,b\n1,2\n"));
        assertNotNull(parser);
        parser.close();
    }

    @Test
    void testPrintReturnsNonNullPrinter() throws Exception {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = CSVFormat.DEFAULT.print(writer);
        assertNotNull(printer);
        printer.close();
    }

    @Test
    void testBuilderGetReturnsNewFormatEachTime() {
        final Builder builder = Builder.create();
        final CSVFormat first = builder.get();
        final CSVFormat second = builder.get();
        assertEquals(first, second);
        assertNotEquals(System.identityHashCode(first), 0);
    }

    @Test
    void testDeprecatedGetDelimiterReturnsFirstChar() {
        assertEquals(',', CSVFormat.DEFAULT.getDelimiter());
    }

    @Test
    void testDeprecatedAllowDuplicateHeaderNamesGetter() {
        assertTrue(CSVFormat.DEFAULT.getAllowDuplicateHeaderNames());
        final CSVFormat format = Builder.create().setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).get();
        assertFalse(format.getAllowDuplicateHeaderNames());
    }

    @Test
    void testWithAllowMissingColumnNamesDeprecated() {
        final CSVFormat format = CSVFormat.DEFAULT.withAllowMissingColumnNames();
        assertTrue(format.getAllowMissingColumnNames());
    }

    @Test
    void testWithAutoFlushDeprecated() {
        final CSVFormat format = CSVFormat.DEFAULT.withAutoFlush(true);
        assertTrue(format.getAutoFlush());
    }

    @Test
    void testSetHeaderDefensiveCopyOfInputArray() {
        final String[] input = {"A", "B"};
        final CSVFormat format = Builder.create().setHeader(input).get();
        input[0] = "mutated";
        assertEquals("A", format.getHeader()[0]);
    }
}
