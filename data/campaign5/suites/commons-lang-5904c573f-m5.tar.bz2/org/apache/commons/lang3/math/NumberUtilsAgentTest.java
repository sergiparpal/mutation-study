/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link NumberUtils}.
 */
class NumberUtilsAgentTest {

    @Test
    void testConstructor() {
        assertTrue(new NumberUtils() instanceof NumberUtils);
    }

    @Test
    void testConstants() {
        assertEquals(Long.valueOf(0L), NumberUtils.LONG_ZERO);
        assertEquals(Long.valueOf(1L), NumberUtils.LONG_ONE);
        assertEquals(Long.valueOf(-1L), NumberUtils.LONG_MINUS_ONE);
        assertEquals(Integer.valueOf(0), NumberUtils.INTEGER_ZERO);
        assertEquals(Integer.valueOf(1), NumberUtils.INTEGER_ONE);
        assertEquals(Integer.valueOf(2), NumberUtils.INTEGER_TWO);
        assertEquals(Integer.valueOf(-1), NumberUtils.INTEGER_MINUS_ONE);
        assertEquals(Short.valueOf((short) 0), NumberUtils.SHORT_ZERO);
        assertEquals(Short.valueOf((short) 1), NumberUtils.SHORT_ONE);
        assertEquals(Short.valueOf((short) -1), NumberUtils.SHORT_MINUS_ONE);
        assertEquals(Byte.valueOf((byte) 0), NumberUtils.BYTE_ZERO);
        assertEquals(Byte.valueOf((byte) 1), NumberUtils.BYTE_ONE);
        assertEquals(Byte.valueOf((byte) -1), NumberUtils.BYTE_MINUS_ONE);
        assertEquals(Double.valueOf(0.0d), NumberUtils.DOUBLE_ZERO);
        assertEquals(Double.valueOf(1.0d), NumberUtils.DOUBLE_ONE);
        assertEquals(Double.valueOf(-1.0d), NumberUtils.DOUBLE_MINUS_ONE);
        assertEquals(Float.valueOf(0.0f), NumberUtils.FLOAT_ZERO);
        assertEquals(Float.valueOf(1.0f), NumberUtils.FLOAT_ONE);
        assertEquals(Float.valueOf(-1.0f), NumberUtils.FLOAT_MINUS_ONE);
        assertEquals(Long.valueOf(Integer.MAX_VALUE), NumberUtils.LONG_INT_MAX_VALUE);
        assertEquals(Long.valueOf(Integer.MIN_VALUE), NumberUtils.LONG_INT_MIN_VALUE);
    }

    // -------------------- compare --------------------

    @Test
    void testCompareByte() {
        assertEquals(0, NumberUtils.compare((byte) 5, (byte) 5));
        assertTrue(NumberUtils.compare((byte) 1, (byte) 2) < 0);
        assertTrue(NumberUtils.compare((byte) 2, (byte) 1) > 0);
    }

    @Test
    void testCompareInt() {
        assertEquals(0, NumberUtils.compare(5, 5));
        assertTrue(NumberUtils.compare(1, 2) < 0);
        assertTrue(NumberUtils.compare(2, 1) > 0);
    }

    @Test
    void testCompareLong() {
        assertEquals(0, NumberUtils.compare(5L, 5L));
        assertTrue(NumberUtils.compare(1L, 2L) < 0);
        assertTrue(NumberUtils.compare(2L, 1L) > 0);
    }

    @Test
    void testCompareShort() {
        assertEquals(0, NumberUtils.compare((short) 5, (short) 5));
        assertTrue(NumberUtils.compare((short) 1, (short) 2) < 0);
        assertTrue(NumberUtils.compare((short) 2, (short) 1) > 0);
    }

    // -------------------- createBigDecimal --------------------

    @Test
    void testCreateBigDecimal() {
        assertNull(NumberUtils.createBigDecimal(null));
        assertEquals(new BigDecimal("1.5"), NumberUtils.createBigDecimal("1.5"));
        assertEquals(BigDecimal.ZERO, NumberUtils.createBigDecimal("0"));
    }

    @Test
    void testCreateBigDecimalBlankThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigDecimal("");
            }
        });
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigDecimal("   ");
            }
        });
    }

    @Test
    void testCreateBigDecimalInvalidThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigDecimal("not a number");
            }
        });
    }

    // -------------------- createBigInteger --------------------

    @Test
    void testCreateBigInteger() {
        assertNull(NumberUtils.createBigInteger(null));
        assertEquals(new BigInteger("255"), NumberUtils.createBigInteger("255"));
        assertEquals(new BigInteger("255"), NumberUtils.createBigInteger("0xFF"));
        assertEquals(new BigInteger("255"), NumberUtils.createBigInteger("#FF"));
        assertEquals(new BigInteger("8"), NumberUtils.createBigInteger("010"));
        assertEquals(new BigInteger("-255"), NumberUtils.createBigInteger("-0xFF"));
        assertEquals(new BigInteger("255"), NumberUtils.createBigInteger("+0xFF"));
    }

    @Test
    void testCreateBigIntegerEmptyThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigInteger("");
            }
        });
    }

    // -------------------- createDouble / createFloat --------------------

    @Test
    void testCreateDouble() {
        assertNull(NumberUtils.createDouble(null));
        assertEquals(Double.valueOf(1.5d), NumberUtils.createDouble("1.5"));
    }

    @Test
    void testCreateDoubleInvalidThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createDouble("not a number");
            }
        });
    }

    @Test
    void testCreateFloat() {
        assertNull(NumberUtils.createFloat(null));
        assertEquals(Float.valueOf(1.5f), NumberUtils.createFloat("1.5"));
    }

    @Test
    void testCreateFloatInvalidThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createFloat("not a number");
            }
        });
    }

    // -------------------- createInteger / createLong --------------------

    @Test
    void testCreateInteger() {
        assertNull(NumberUtils.createInteger(null));
        assertEquals(Integer.valueOf(12), NumberUtils.createInteger("12"));
        assertEquals(Integer.valueOf(255), NumberUtils.createInteger("0xFF"));
        assertEquals(Integer.valueOf(8), NumberUtils.createInteger("010"));
    }

    @Test
    void testCreateIntegerInvalidThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createInteger("not a number");
            }
        });
    }

    @Test
    void testCreateLong() {
        assertNull(NumberUtils.createLong(null));
        assertEquals(Long.valueOf(12L), NumberUtils.createLong("12"));
        assertEquals(Long.valueOf(255L), NumberUtils.createLong("0xFF"));
    }

    @Test
    void testCreateLongInvalidThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createLong("not a number");
            }
        });
    }

    // -------------------- createNumber --------------------

    @Test
    void testCreateNumberNull() {
        assertNull(NumberUtils.createNumber(null));
    }

    @Test
    void testCreateNumberBlankThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("");
            }
        });
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("   ");
            }
        });
    }

    @Test
    void testCreateNumberIntegerDefaults() {
        assertEquals(Integer.valueOf(12345), NumberUtils.createNumber("12345"));
        assertTrue(NumberUtils.createNumber("12345") instanceof Integer);
    }

    @Test
    void testCreateNumberLongWhenTooBigForInt() {
        final String s = String.valueOf((long) Integer.MAX_VALUE + 1L);
        final Number n = NumberUtils.createNumber(s);
        assertTrue(n instanceof Long);
        assertEquals(Long.valueOf(s), n);
    }

    @Test
    void testCreateNumberBigIntegerWhenTooBigForLong() {
        final String s = "123456789012345678901234567890";
        final Number n = NumberUtils.createNumber(s);
        assertTrue(n instanceof BigInteger);
        assertEquals(new BigInteger(s), n);
    }

    @Test
    void testCreateNumberFloatSuffix() {
        final Number n = NumberUtils.createNumber("1.5f");
        assertTrue(n instanceof Float);
        assertEquals(Float.valueOf(1.5f), n);
    }

    @Test
    void testCreateNumberDoubleSuffix() {
        final Number n = NumberUtils.createNumber("1.5d");
        assertTrue(n instanceof Double);
        assertEquals(Double.valueOf(1.5d), n);
    }

    @Test
    void testCreateNumberLongSuffix() {
        final Number n = NumberUtils.createNumber("123L");
        assertTrue(n instanceof Long);
        assertEquals(Long.valueOf(123L), n);
    }

    @Test
    void testCreateNumberLongSuffixOnDecimalThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("1.5L");
            }
        });
    }

    @Test
    void testCreateNumberHexInteger() {
        final Number n = NumberUtils.createNumber("0xFF");
        assertTrue(n instanceof Integer);
        assertEquals(Integer.valueOf(255), n);
    }

    @Test
    void testCreateNumberHexLong() {
        final Number n = NumberUtils.createNumber("0xFFFFFFFFF");
        assertTrue(n instanceof Long);
    }

    @Test
    void testCreateNumberDecimalWithExponent() {
        final Number n = NumberUtils.createNumber("1.2e3");
        assertEquals(1200.0d, n.doubleValue(), 0.0001d);
    }

    @Test
    void testCreateNumberMalformedDoubleExponentThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("1e2e3");
            }
        });
    }

    @Test
    void testCreateNumberBigDecimalForVeryPreciseDecimal() {
        final String s = "1.23456789012345678901234567890123456789";
        final Number n = NumberUtils.createNumber(s);
        assertTrue(n instanceof BigDecimal);
    }

    // -------------------- isCreatable / isNumber --------------------

    @Test
    void testIsCreatable() {
        assertFalse(NumberUtils.isCreatable(null));
        assertFalse(NumberUtils.isCreatable(""));
        assertTrue(NumberUtils.isCreatable("12345"));
        assertTrue(NumberUtils.isCreatable("-12345"));
        assertTrue(NumberUtils.isCreatable("0xFF"));
        assertFalse(NumberUtils.isCreatable("12.34.56"));
        assertFalse(NumberUtils.isCreatable("abc"));
    }

    @Test
    void testIsNumberDeprecatedDelegates() {
        assertTrue(NumberUtils.isNumber("12345"));
        assertFalse(NumberUtils.isNumber("abc"));
        assertEquals(NumberUtils.isCreatable("1.5"), NumberUtils.isNumber("1.5"));
    }

    // -------------------- isDigits --------------------

    @Test
    void testIsDigits() {
        assertFalse(NumberUtils.isDigits(null));
        assertFalse(NumberUtils.isDigits(""));
        assertTrue(NumberUtils.isDigits("12345"));
        assertFalse(NumberUtils.isDigits("12.345"));
        assertFalse(NumberUtils.isDigits("-12345"));
        assertFalse(NumberUtils.isDigits("abc"));
    }

    // -------------------- isParsable --------------------

    @Test
    void testIsParsable() {
        assertFalse(NumberUtils.isParsable(null));
        assertFalse(NumberUtils.isParsable(""));
        assertTrue(NumberUtils.isParsable("1.5"));
        assertTrue(NumberUtils.isParsable("123"));
        assertTrue(NumberUtils.isParsable("-123"));
        assertFalse(NumberUtils.isParsable("1.5L"));
        assertFalse(NumberUtils.isParsable("--1"));
        assertTrue(NumberUtils.isParsable("1.5f"));
    }

    @Test
    void testIsParsableHex() {
        assertFalse(NumberUtils.isParsable("0xFF"));
    }

    // -------------------- max/min arrays --------------------

    @Test
    void testMaxByteArray() {
        assertEquals((byte) 5, NumberUtils.max((byte) 1, (byte) 5, (byte) 3));
        assertEquals((byte) 5, NumberUtils.max(new byte[] {5}));
    }

    @Test
    void testMaxByteArrayNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max((byte[]) null);
            }
        });
    }

    @Test
    void testMaxByteArrayEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new byte[0]);
            }
        });
    }

    @Test
    void testMaxByteThreeParam() {
        assertEquals((byte) 5, NumberUtils.max((byte) 1, (byte) 5, (byte) 3));
        assertEquals((byte) 5, NumberUtils.max((byte) 5, (byte) 1, (byte) 3));
        assertEquals((byte) 5, NumberUtils.max((byte) 1, (byte) 3, (byte) 5));
    }

    @Test
    void testMaxDoubleArray() {
        assertEquals(5.0d, NumberUtils.max(1.0d, 5.0d, 3.0d), 0.0d);
    }

    @Test
    void testMaxDoubleArrayNaN() {
        assertTrue(Double.isNaN(NumberUtils.max(1.0d, Double.NaN, 3.0d)));
    }

    @Test
    void testMaxDoubleThreeParam() {
        assertEquals(5.0d, NumberUtils.max(1.0d, 5.0d, 3.0d), 0.0d);
        assertTrue(Double.isNaN(NumberUtils.max(1.0d, Double.NaN, 3.0d)));
    }

    @Test
    void testMaxFloatArray() {
        assertEquals(5.0f, NumberUtils.max(1.0f, 5.0f, 3.0f), 0.0f);
    }

    @Test
    void testMaxFloatArrayNaN() {
        assertTrue(Float.isNaN(NumberUtils.max(1.0f, Float.NaN, 3.0f)));
    }

    @Test
    void testMaxFloatThreeParam() {
        assertEquals(5.0f, NumberUtils.max(1.0f, 5.0f, 3.0f), 0.0f);
    }

    @Test
    void testMaxIntArray() {
        assertEquals(5, NumberUtils.max(1, 5, 3));
        assertEquals(5, NumberUtils.max(new int[] {1, 2, 3, 4, 5}));
    }

    @Test
    void testMaxIntArrayNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max((int[]) null);
            }
        });
    }

    @Test
    void testMaxIntArrayEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new int[0]);
            }
        });
    }

    @Test
    void testMaxIntThreeParam() {
        assertEquals(5, NumberUtils.max(1, 5, 3));
        assertEquals(5, NumberUtils.max(5, 1, 3));
        assertEquals(5, NumberUtils.max(1, 3, 5));
    }

    @Test
    void testMaxLongArray() {
        assertEquals(5L, NumberUtils.max(1L, 5L, 3L));
        assertEquals(5L, NumberUtils.max(new long[] {1L, 5L, 3L}));
    }

    @Test
    void testMaxLongThreeParam() {
        assertEquals(5L, NumberUtils.max(1L, 5L, 3L));
        assertEquals(5L, NumberUtils.max(5L, 1L, 3L));
        assertEquals(5L, NumberUtils.max(1L, 3L, 5L));
    }

    @Test
    void testMaxShortArray() {
        assertEquals((short) 5, NumberUtils.max(new short[] {1, 5, 3}));
    }

    @Test
    void testMaxShortThreeParam() {
        assertEquals((short) 5, NumberUtils.max((short) 1, (short) 5, (short) 3));
        assertEquals((short) 5, NumberUtils.max((short) 5, (short) 1, (short) 3));
        assertEquals((short) 5, NumberUtils.max((short) 1, (short) 3, (short) 5));
    }

    @Test
    void testMinByteArray() {
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 5, (byte) 3));
    }

    @Test
    void testMinByteArrayNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min((byte[]) null);
            }
        });
    }

    @Test
    void testMinByteArrayEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new byte[0]);
            }
        });
    }

    @Test
    void testMinByteThreeParam() {
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 5, (byte) 3));
        assertEquals((byte) 1, NumberUtils.min((byte) 5, (byte) 1, (byte) 3));
        assertEquals((byte) 1, NumberUtils.min((byte) 5, (byte) 3, (byte) 1));
    }

    @Test
    void testMinDoubleArray() {
        assertEquals(1.0d, NumberUtils.min(1.0d, 5.0d, 3.0d), 0.0d);
    }

    @Test
    void testMinDoubleArrayNaN() {
        assertTrue(Double.isNaN(NumberUtils.min(1.0d, Double.NaN, 3.0d)));
    }

    @Test
    void testMinDoubleThreeParam() {
        assertEquals(1.0d, NumberUtils.min(1.0d, 5.0d, 3.0d), 0.0d);
        assertTrue(Double.isNaN(NumberUtils.min(1.0d, Double.NaN, 3.0d)));
    }

    @Test
    void testMinFloatArray() {
        assertEquals(1.0f, NumberUtils.min(1.0f, 5.0f, 3.0f), 0.0f);
    }

    @Test
    void testMinFloatArrayNaN() {
        assertTrue(Float.isNaN(NumberUtils.min(1.0f, Float.NaN, 3.0f)));
    }

    @Test
    void testMinFloatThreeParam() {
        assertEquals(1.0f, NumberUtils.min(1.0f, 5.0f, 3.0f), 0.0f);
    }

    @Test
    void testMinIntArray() {
        assertEquals(1, NumberUtils.min(1, 5, 3));
        assertEquals(1, NumberUtils.min(new int[] {5, 1, 3}));
    }

    @Test
    void testMinIntArrayNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min((int[]) null);
            }
        });
    }

    @Test
    void testMinIntArrayEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new int[0]);
            }
        });
    }

    @Test
    void testMinIntThreeParam() {
        assertEquals(1, NumberUtils.min(1, 5, 3));
        assertEquals(1, NumberUtils.min(5, 1, 3));
        assertEquals(1, NumberUtils.min(5, 3, 1));
    }

    @Test
    void testMinLongArray() {
        assertEquals(1L, NumberUtils.min(1L, 5L, 3L));
    }

    @Test
    void testMinLongThreeParam() {
        assertEquals(1L, NumberUtils.min(1L, 5L, 3L));
        assertEquals(1L, NumberUtils.min(5L, 1L, 3L));
        assertEquals(1L, NumberUtils.min(5L, 3L, 1L));
    }

    @Test
    void testMinShortArray() {
        assertEquals((short) 1, NumberUtils.min(new short[] {5, 1, 3}));
    }

    @Test
    void testMinShortThreeParam() {
        assertEquals((short) 1, NumberUtils.min((short) 1, (short) 5, (short) 3));
        assertEquals((short) 1, NumberUtils.min((short) 5, (short) 1, (short) 3));
        assertEquals((short) 1, NumberUtils.min((short) 5, (short) 3, (short) 1));
    }

    // -------------------- toByte --------------------

    @Test
    void testToByte() {
        assertEquals((byte) 0, NumberUtils.toByte(null));
        assertEquals((byte) 0, NumberUtils.toByte(""));
        assertEquals((byte) 1, NumberUtils.toByte("1"));
    }

    @Test
    void testToByteWithDefault() {
        assertEquals((byte) 1, NumberUtils.toByte(null, (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("", (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("1", (byte) 0));
        assertEquals((byte) 9, NumberUtils.toByte("not a byte", (byte) 9));
    }

    // -------------------- toDouble --------------------

    @Test
    void testToDoubleBigDecimal() {
        assertEquals(0.0d, NumberUtils.toDouble((BigDecimal) null), 0.0d);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d)), 0.0d);
    }

    @Test
    void testToDoubleBigDecimalWithDefault() {
        assertEquals(1.1d, NumberUtils.toDouble((BigDecimal) null, 1.1d), 0.0d);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d), 1.1d), 0.0d);
    }

    @Test
    void testToDoubleString() {
        assertEquals(0.0d, NumberUtils.toDouble((String) null), 0.0d);
        assertEquals(0.0d, NumberUtils.toDouble(""), 0.0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5"), 0.0d);
    }

    @Test
    void testToDoubleStringWithDefault() {
        assertEquals(1.1d, NumberUtils.toDouble((String) null, 1.1d), 0.0d);
        assertEquals(1.1d, NumberUtils.toDouble("", 1.1d), 0.0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5", 0.0d), 0.0d);
        assertEquals(9.9d, NumberUtils.toDouble("not a double", 9.9d), 0.0d);
    }

    // -------------------- toFloat --------------------

    @Test
    void testToFloatString() {
        assertEquals(0.0f, NumberUtils.toFloat(null), 0.0f);
        assertEquals(0.0f, NumberUtils.toFloat(""), 0.0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5"), 0.0f);
    }

    @Test
    void testToFloatStringWithDefault() {
        assertEquals(1.1f, NumberUtils.toFloat(null, 1.1f), 0.0f);
        assertEquals(1.1f, NumberUtils.toFloat("", 1.1f), 0.0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5", 0.0f), 0.0f);
        assertEquals(9.9f, NumberUtils.toFloat("not a float", 9.9f), 0.0f);
    }

    // -------------------- toInt --------------------

    @Test
    void testToInt() {
        assertEquals(0, NumberUtils.toInt(null));
        assertEquals(0, NumberUtils.toInt(""));
        assertEquals(1, NumberUtils.toInt("1"));
    }

    @Test
    void testToIntWithDefault() {
        assertEquals(1, NumberUtils.toInt(null, 1));
        assertEquals(1, NumberUtils.toInt("", 1));
        assertEquals(1, NumberUtils.toInt("1", 0));
        assertEquals(9, NumberUtils.toInt("not an int", 9));
    }

    // -------------------- toLong --------------------

    @Test
    void testToLong() {
        assertEquals(0L, NumberUtils.toLong(null));
        assertEquals(0L, NumberUtils.toLong(""));
        assertEquals(1L, NumberUtils.toLong("1"));
    }

    @Test
    void testToLongWithDefault() {
        assertEquals(1L, NumberUtils.toLong(null, 1L));
        assertEquals(1L, NumberUtils.toLong("", 1L));
        assertEquals(1L, NumberUtils.toLong("1", 0L));
        assertEquals(9L, NumberUtils.toLong("not a long", 9L));
    }

    // -------------------- toShort --------------------

    @Test
    void testToShort() {
        assertEquals((short) 0, NumberUtils.toShort(null));
        assertEquals((short) 0, NumberUtils.toShort(""));
        assertEquals((short) 1, NumberUtils.toShort("1"));
    }

    @Test
    void testToShortWithDefault() {
        assertEquals((short) 1, NumberUtils.toShort(null, (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("", (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("1", (short) 0));
        assertEquals((short) 9, NumberUtils.toShort("not a short", (short) 9));
    }

    // -------------------- toScaledBigDecimal --------------------

    @Test
    void testToScaledBigDecimalBigDecimal() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null));
        assertEquals(new BigDecimal("1.23"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.2345")));
    }

    @Test
    void testToScaledBigDecimalBigDecimalWithScaleAndRounding() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null, 3, RoundingMode.HALF_UP));
        assertEquals(new BigDecimal("1.235"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.2345"), 3, RoundingMode.HALF_UP));
        assertEquals(new BigDecimal("1.234"), NumberUtils.toScaledBigDecimal(new BigDecimal("1.2345"), 3, null));
    }

    @Test
    void testToScaledBigDecimalDouble() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null));
        assertEquals(new BigDecimal("1.23"), NumberUtils.toScaledBigDecimal(Double.valueOf(1.2345d)));
    }

    @Test
    void testToScaledBigDecimalFloat() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null));
        assertEquals(new BigDecimal("1.23"), NumberUtils.toScaledBigDecimal(Float.valueOf(1.2345f)));
    }

    @Test
    void testToScaledBigDecimalString() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null));
        assertEquals(new BigDecimal("1.23"), NumberUtils.toScaledBigDecimal("1.2345"));
    }

    @Test
    void testToScaledBigDecimalStringWithScaleAndRounding() {
        assertEquals(new BigDecimal("1.235"), NumberUtils.toScaledBigDecimal("1.2345", 3, RoundingMode.HALF_UP));
    }

}
