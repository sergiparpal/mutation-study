/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link FastDatePrinter}.
 */
class FastDatePrinterAgentTest {

    private static final TimeZone UTC = TimeZone.getTimeZone("UTC");

    private static Calendar newUtcCalendar(final int year, final int month, final int day,
            final int hour, final int minute, final int second, final int millis) {
        final Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.clear();
        cal.set(year, month, day, hour, minute, second);
        cal.set(Calendar.MILLISECOND, millis);
        return cal;
    }

    @Test
    void testConstructorRejectsNullPatternAndTimeZone() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                new FastDatePrinter(null, UTC, Locale.US);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                new FastDatePrinter("yyyy", null, Locale.US);
            }
        });
    }

    @Test
    void testConstructorFallsBackToDefaultLocaleWhenNull() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy", UTC, null);
        assertEquals(Locale.getDefault(), printer.getLocale());
    }

    @Test
    void testGetters() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.US);
        assertEquals("yyyy-MM-dd", printer.getPattern());
        assertEquals(Locale.US, printer.getLocale());
        assertEquals(UTC, printer.getTimeZone());
    }

    @Test
    void testGetTimeZoneReturnsIndependentClone() {
        final TimeZone mutable = TimeZone.getTimeZone("UTC");
        final FastDatePrinter printer = new FastDatePrinter("yyyy", mutable, Locale.US);
        final TimeZone returned = printer.getTimeZone();
        assertEquals(mutable, returned);
        assertNotSame(mutable, returned);
        // Mutating the zone passed to the constructor must not affect the printer.
        mutable.setRawOffset(123000);
        assertEquals(UTC, printer.getTimeZone());
    }

    @Test
    void testFormatDateBasic() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd HH:mm:ss", UTC, Locale.US);
        final Calendar cal = newUtcCalendar(2024, Calendar.MARCH, 5, 13, 30, 45, 0);
        assertEquals("2024-03-05 13:30:45", printer.format(cal.getTime()));
    }

    @Test
    void testFormatLong() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd HH:mm:ss", UTC, Locale.US);
        final Calendar cal = newUtcCalendar(2024, Calendar.MARCH, 5, 13, 30, 45, 0);
        assertEquals("2024-03-05 13:30:45", printer.format(cal.getTimeInMillis()));
    }

    @Test
    void testFormatCalendarClonesWhenTimeZoneDiffers() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd HH:mm:ss", UTC, Locale.US);
        final TimeZone newYork = TimeZone.getTimeZone("America/New_York");
        final Calendar cal = Calendar.getInstance(newYork, Locale.US);
        cal.clear();
        // January: EST, UTC-5, no DST in effect.
        cal.set(2024, Calendar.JANUARY, 15, 10, 0, 0);
        // Materialize the instant (in the New York zone) before the printer re-zones a clone.
        cal.getTime();

        final String result = printer.format(cal);

        assertEquals("2024-01-15 15:00:00", result);
        // The original calendar must not have been mutated.
        assertEquals(newYork, cal.getTimeZone());
    }

    @Test
    void testFormatCalendarSameTimeZone() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd HH:mm:ss", UTC, Locale.US);
        final Calendar cal = newUtcCalendar(2024, Calendar.MARCH, 5, 13, 30, 45, 0);
        assertEquals("2024-03-05 13:30:45", printer.format(cal));
        assertEquals(UTC, cal.getTimeZone());
    }

    @Test
    void testFormatAppendableOverloadsAppendRatherThanReplace() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy", UTC, Locale.US);
        final Calendar cal = newUtcCalendar(2024, Calendar.MARCH, 5, 0, 0, 0, 0);
        final Date date = cal.getTime();

        final StringBuilder sb = new StringBuilder("prefix-");
        final StringBuilder returnedSb = printer.format(date, sb);
        assertEquals("prefix-2024", returnedSb.toString());
        assertEquals("prefix-2024", sb.toString());

        final StringBuffer buf = new StringBuffer("prefix-");
        final StringBuffer returnedBuf = printer.format(date, buf);
        assertEquals("prefix-2024", returnedBuf.toString());
        assertTrue(returnedBuf == buf);

        final StringBuffer bufCal = new StringBuffer("cal-");
        assertEquals("cal-2024", printer.format(cal, bufCal).toString());

        final StringBuffer bufMillis = new StringBuffer("ms-");
        assertEquals("ms-2024", printer.format(cal.getTimeInMillis(), bufMillis).toString());
    }

    @Test
    void testFormatObjectPackagePrivate() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy", UTC, Locale.US);
        final Calendar cal = newUtcCalendar(2024, Calendar.MARCH, 5, 0, 0, 0, 0);
        assertEquals("2024", printer.format((Object) cal.getTime()));
        assertEquals("2024", printer.format((Object) cal));
        assertEquals("2024", printer.format((Object) Long.valueOf(cal.getTimeInMillis())));
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                printer.format((Object) "not a date");
            }
        });
        assertTrue(ex.getMessage().contains("Unknown class"));
    }

    @SuppressWarnings("deprecation")
    @Test
    void testDeprecatedFormatObjectWithFieldPosition() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy", UTC, Locale.US);
        final Calendar cal = newUtcCalendar(2024, Calendar.MARCH, 5, 0, 0, 0, 0);
        final java.text.FieldPosition pos = new java.text.FieldPosition(0);

        assertEquals("2024", printer.format((Object) cal.getTime(), new StringBuffer(), pos).toString());
        assertEquals("2024", printer.format((Object) cal, new StringBuffer(), pos).toString());
        assertEquals("2024", printer.format((Object) Long.valueOf(cal.getTimeInMillis()), new StringBuffer(), pos).toString());

        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                printer.format((Object) "nope", new StringBuffer(), pos);
            }
        });
    }

    @SuppressWarnings("deprecation")
    @Test
    void testDeprecatedApplyRules() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy", UTC, Locale.US);
        final Calendar cal = newUtcCalendar(2024, Calendar.MARCH, 5, 0, 0, 0, 0);
        final StringBuffer buf = new StringBuffer();
        final StringBuffer returned = printer.applyRules(cal, buf);
        assertTrue(returned == buf);
        assertEquals("2024", buf.toString());
    }

    @Test
    void testYearPatterns() {
        final Calendar cal = newUtcCalendar(2003, Calendar.JUNE, 8, 10, 11, 12, 0);
        assertEquals("2003", new FastDatePrinter("y", UTC, Locale.US).format(cal));
        assertEquals("03", new FastDatePrinter("yy", UTC, Locale.US).format(cal));
        assertEquals("2003", new FastDatePrinter("yyy", UTC, Locale.US).format(cal));
        assertEquals("2003", new FastDatePrinter("yyyy", UTC, Locale.US).format(cal));
    }

    @Test
    void testMonthPatterns() {
        final Calendar cal = newUtcCalendar(2024, Calendar.JANUARY, 5, 0, 0, 0, 0);
        assertEquals("1", new FastDatePrinter("M", UTC, Locale.US).format(cal));
        assertEquals("01", new FastDatePrinter("MM", UTC, Locale.US).format(cal));
        assertEquals("Jan", new FastDatePrinter("MMM", UTC, Locale.US).format(cal));
        assertEquals("January", new FastDatePrinter("MMMM", UTC, Locale.US).format(cal));
    }

    @Test
    void testStandaloneMonthPatterns() {
        final Calendar cal = newUtcCalendar(2024, Calendar.MARCH, 5, 0, 0, 0, 0);
        assertEquals("3", new FastDatePrinter("L", UTC, Locale.US).format(cal));
        assertEquals("03", new FastDatePrinter("LL", UTC, Locale.US).format(cal));
        assertEquals("Mar", new FastDatePrinter("LLL", UTC, Locale.US).format(cal));
        assertEquals("March", new FastDatePrinter("LLLL", UTC, Locale.US).format(cal));
    }

    @Test
    void testWeekdayPatterns() {
        // 2024-03-05 is a Tuesday.
        final Calendar cal = newUtcCalendar(2024, Calendar.MARCH, 5, 0, 0, 0, 0);
        assertEquals(Calendar.TUESDAY, cal.get(Calendar.DAY_OF_WEEK));
        assertEquals("Tue", new FastDatePrinter("E", UTC, Locale.US).format(cal));
        assertEquals("Tuesday", new FastDatePrinter("EEEE", UTC, Locale.US).format(cal));
        // ISO day-of-week number: Monday=1 .. Sunday=7.
        assertEquals("2", new FastDatePrinter("u", UTC, Locale.US).format(cal));
    }

    @Test
    void testHourPatternsAtMidnight() {
        final Calendar cal = newUtcCalendar(2024, Calendar.MARCH, 5, 0, 0, 0, 0);
        assertEquals("12", new FastDatePrinter("h", UTC, Locale.US).format(cal));
        assertEquals("0", new FastDatePrinter("H", UTC, Locale.US).format(cal));
        assertEquals("24", new FastDatePrinter("k", UTC, Locale.US).format(cal));
        assertEquals("0", new FastDatePrinter("K", UTC, Locale.US).format(cal));
        assertEquals("AM", new FastDatePrinter("a", UTC, Locale.US).format(cal));
    }

    @Test
    void testHourPatternsAfternoon() {
        final Calendar cal = newUtcCalendar(2024, Calendar.MARCH, 5, 13, 0, 0, 0);
        assertEquals("1", new FastDatePrinter("h", UTC, Locale.US).format(cal));
        assertEquals("13", new FastDatePrinter("H", UTC, Locale.US).format(cal));
        assertEquals("13", new FastDatePrinter("k", UTC, Locale.US).format(cal));
        assertEquals("1", new FastDatePrinter("K", UTC, Locale.US).format(cal));
        assertEquals("PM", new FastDatePrinter("a", UTC, Locale.US).format(cal));
    }

    @Test
    void testMillisecondPattern() {
        final Calendar cal = newUtcCalendar(2024, Calendar.MARCH, 5, 0, 0, 0, 7);
        assertEquals("7", new FastDatePrinter("S", UTC, Locale.US).format(cal));
        assertEquals("007", new FastDatePrinter("SSS", UTC, Locale.US).format(cal));
    }

    @Test
    void testEraPattern() {
        final GregorianCalendar adCal = new GregorianCalendar(UTC, Locale.US);
        adCal.clear();
        adCal.set(2024, Calendar.MARCH, 5);
        assertEquals("AD", new FastDatePrinter("G", UTC, Locale.US).format(adCal));

        final GregorianCalendar bcCal = new GregorianCalendar(UTC, Locale.US);
        bcCal.clear();
        bcCal.set(100, Calendar.MARCH, 5);
        bcCal.set(Calendar.ERA, GregorianCalendar.BC);
        assertEquals("BC", new FastDatePrinter("G", UTC, Locale.US).format(bcCal));
    }

    @Test
    void testTimeZoneNamePattern() {
        final TimeZone newYork = TimeZone.getTimeZone("America/New_York");
        final Calendar cal = Calendar.getInstance(newYork, Locale.US);
        cal.clear();
        cal.set(2024, Calendar.JANUARY, 15, 10, 0, 0); // no DST in January

        final String expectedLong = newYork.getDisplayName(false, TimeZone.LONG, Locale.US);
        final String expectedShort = newYork.getDisplayName(false, TimeZone.SHORT, Locale.US);

        assertEquals(expectedLong, new FastDatePrinter("zzzz", newYork, Locale.US).format(cal));
        assertEquals(expectedShort, new FastDatePrinter("z", newYork, Locale.US).format(cal));
    }

    @Test
    void testTimeZoneNumberPatternZ() {
        final Calendar cal = newUtcCalendar(2024, Calendar.MARCH, 5, 0, 0, 0, 0);
        assertEquals("+0000", new FastDatePrinter("Z", UTC, Locale.US).format(cal));
        assertEquals("Z", new FastDatePrinter("ZZ", UTC, Locale.US).format(cal));
        assertEquals("+00:00", new FastDatePrinter("ZZZ", UTC, Locale.US).format(cal));
    }

    @Test
    void testIso8601PatternXAtUtc() {
        final Calendar cal = newUtcCalendar(2024, Calendar.MARCH, 5, 0, 0, 0, 0);
        assertEquals("Z", new FastDatePrinter("X", UTC, Locale.US).format(cal));
        assertEquals("Z", new FastDatePrinter("XX", UTC, Locale.US).format(cal));
        assertEquals("Z", new FastDatePrinter("XXX", UTC, Locale.US).format(cal));
    }

    @Test
    void testIso8601PatternXWithOffset() {
        final TimeZone indiaTz = TimeZone.getTimeZone("GMT+05:30");
        final Calendar cal = Calendar.getInstance(indiaTz, Locale.US);
        cal.clear();
        cal.set(2024, Calendar.MARCH, 5, 0, 0, 0);

        assertEquals("+05", new FastDatePrinter("X", indiaTz, Locale.US).format(cal));
        assertEquals("+0530", new FastDatePrinter("XX", indiaTz, Locale.US).format(cal));
        assertEquals("+05:30", new FastDatePrinter("XXX", indiaTz, Locale.US).format(cal));
    }

    @Test
    void testIso8601PatternXXXXIsInvalid() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new FastDatePrinter("XXXX", UTC, Locale.US);
            }
        });
    }

    @Test
    void testQuotedLiteralPattern() {
        final Calendar cal = newUtcCalendar(2024, Calendar.MARCH, 5, 13, 0, 0, 0);
        assertEquals("2024-03-05T13", new FastDatePrinter("yyyy-MM-dd'T'HH", UTC, Locale.US).format(cal));
        // '' inside a quoted literal is an escaped apostrophe.
        assertEquals("2024it's", new FastDatePrinter("yyyy'it''s'", UTC, Locale.US).format(cal));
    }

    @Test
    void testIllegalPatternComponentThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new FastDatePrinter("yyyy-qq", UTC, Locale.US);
            }
        });
        assertTrue(ex.getMessage().contains("Illegal pattern component"));
    }

    @Test
    void testEqualsAndHashCode() {
        final FastDatePrinter a = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.US);
        final FastDatePrinter sameConfig = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.US);
        final FastDatePrinter differentPattern = new FastDatePrinter("yyyy/MM/dd", UTC, Locale.US);
        final FastDatePrinter differentZone = new FastDatePrinter("yyyy-MM-dd", TimeZone.getTimeZone("America/New_York"), Locale.US);
        final FastDatePrinter differentLocale = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.FRANCE);

        assertTrue(a.equals(a));
        assertTrue(a.equals(sameConfig));
        assertEquals(a.hashCode(), sameConfig.hashCode());
        assertFalse(a.equals(differentPattern));
        assertFalse(a.equals(differentZone));
        assertFalse(a.equals(differentLocale));
        assertFalse(a.equals(null));
        assertFalse(a.equals("yyyy-MM-dd"));
        assertNotEquals(a, differentPattern);
    }

    @Test
    void testToString() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.US);
        assertEquals("FastDatePrinter[yyyy-MM-dd,en_US,UTC]", printer.toString());
    }

    @Test
    void testMaxLengthEstimate() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.US);
        assertEquals(10, printer.getMaxLengthEstimate());
        final Calendar cal = newUtcCalendar(2024, Calendar.MARCH, 5, 0, 0, 0, 0);
        assertTrue(printer.format(cal).length() <= printer.getMaxLengthEstimate());
    }

    @Test
    void testSerializationRoundTrip() throws Exception {
        final FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd HH:mm:ss.SSS 'at' zzzz", UTC, Locale.US);
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        final ObjectOutputStream oos = new ObjectOutputStream(baos);
        oos.writeObject(printer);
        oos.close();

        final ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(baos.toByteArray()));
        final FastDatePrinter copy = (FastDatePrinter) ois.readObject();
        ois.close();

        assertNotSame(printer, copy);
        assertEquals(printer, copy);
        assertEquals(printer.getPattern(), copy.getPattern());
        assertEquals(printer.getMaxLengthEstimate(), copy.getMaxLengthEstimate());

        final Calendar cal = newUtcCalendar(2024, Calendar.MARCH, 5, 13, 30, 45, 7);
        assertEquals(printer.format(cal), copy.format(cal));
    }

    @Test
    void testGetTimeZoneDisplayStaticHelper() {
        final TimeZone tz = TimeZone.getTimeZone("America/New_York");
        final String standard = FastDatePrinter.getTimeZoneDisplay(tz, false, TimeZone.LONG, Locale.US);
        final String daylight = FastDatePrinter.getTimeZoneDisplay(tz, true, TimeZone.LONG, Locale.US);
        assertEquals(tz.getDisplayName(false, TimeZone.LONG, Locale.US), standard);
        assertEquals(tz.getDisplayName(true, TimeZone.LONG, Locale.US), daylight);
        assertNotEquals(standard, daylight);
    }

    @Test
    void testClearStaticCacheDoesNotBreakFormatting() {
        final TimeZone newYork = TimeZone.getTimeZone("America/New_York");
        final FastDatePrinter printer = new FastDatePrinter("zzzz", newYork, Locale.US);
        final Calendar cal = Calendar.getInstance(newYork, Locale.US);
        cal.clear();
        cal.set(2024, Calendar.JANUARY, 15, 10, 0, 0);

        final String before = printer.format(cal);
        FastDatePrinter.clear();
        final String after = printer.format(cal);

        assertEquals(before, after);
        assertNotNull(after);
    }

    @Test
    void testParseTokenAlphaRun() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy", UTC, Locale.US);
        final int[] indexRef = { 0 };
        final String token = printer.parseToken("yyyyMM", indexRef);
        assertEquals("yyyy", token);
        assertEquals(3, indexRef[0]);
    }

    @Test
    void testParseTokenLiteral() {
        final FastDatePrinter printer = new FastDatePrinter("yyyy", UTC, Locale.US);
        final int[] indexRef = { 0 };
        final String token = printer.parseToken("'abc'MM", indexRef);
        // Token is marked with a leading quote; the real content starts at index 1.
        assertEquals("'", token.substring(0, 1));
        assertEquals("abc", token.substring(1));
        assertEquals('M', "'abc'MM".charAt(indexRef[0] + 1));
    }
}
