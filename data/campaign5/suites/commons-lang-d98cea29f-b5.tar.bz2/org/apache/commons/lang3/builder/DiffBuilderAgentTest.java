/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.builder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link DiffBuilder}.
 */
public class DiffBuilderAgentTest {

    private static final class SimpleClass {
        private boolean booleanField;
        private boolean[] booleanArrayField;
        private byte byteField;
        private byte[] byteArrayField;
        private char charField;
        private char[] charArrayField;
        private double doubleField;
        private double[] doubleArrayField;
        private float floatField;
        private float[] floatArrayField;
        private int intField;
        private int[] intArrayField;
        private long longField;
        private long[] longArrayField;
        private short shortField;
        private short[] shortArrayField;
        private String stringField;
        private Object[] objectArrayField;

        SimpleClass() {
            // empty default instance
        }
    }

    @Test
    public void testConstructorNullLeftThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new DiffBuilder<SimpleClass>(null, new SimpleClass(), ToStringStyle.DEFAULT_STYLE);
            }
        });
    }

    @Test
    public void testConstructorNullRightThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                new DiffBuilder<SimpleClass>(new SimpleClass(), null, ToStringStyle.DEFAULT_STYLE);
            }
        });
    }

    @Test
    public void testSameInstanceProducesNoDiffs() {
        final SimpleClass o = new SimpleClass();
        o.intField = 5;
        final DiffBuilder<SimpleClass> builder = new DiffBuilder<SimpleClass>(o, o, ToStringStyle.DEFAULT_STYLE);
        final DiffResult<SimpleClass> result = builder.append("intField", o.intField, 999).build();
        assertEquals(0, result.getNumberOfDiffs());
    }

    @Test
    public void testEqualObjectsProducesNoDiffsEvenIfAppended() {
        final SimpleClass left = new SimpleClass();
        final SimpleClass right = new SimpleClass();
        // left.equals(right) is true (default Object identity is false, so use same reference semantics)
        // Here left != right but neither overrides equals, so Objects.equals(left, right) is false.
        // So testObjectsEquals will not short-circuit; verify the diff is recorded instead.
        final DiffBuilder<SimpleClass> builder = new DiffBuilder<SimpleClass>(left, right, ToStringStyle.DEFAULT_STYLE);
        left.intField = 1;
        right.intField = 2;
        final DiffResult<SimpleClass> result = builder.append("intField", left.intField, right.intField).build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testTestObjectsEqualsFalseAlwaysEvaluates() {
        final SimpleClass o = new SimpleClass();
        final DiffBuilder<SimpleClass> builder = new DiffBuilder<SimpleClass>(o, o, ToStringStyle.DEFAULT_STYLE, false);
        final DiffResult<SimpleClass> result = builder.append("intField", 1, 1).build();
        // Even though values are equal, the builder itself still functions and returns no diff for equal ints.
        assertEquals(0, result.getNumberOfDiffs());
        final DiffBuilder<SimpleClass> builder2 = new DiffBuilder<SimpleClass>(o, o, ToStringStyle.DEFAULT_STYLE, false);
        final DiffResult<SimpleClass> result2 = builder2.append("intField", 1, 2).build();
        assertEquals(1, result2.getNumberOfDiffs());
    }

    @Test
    public void testAppendBooleanEqual() {
        final SimpleClass left = new SimpleClass();
        final SimpleClass right = new SimpleClass();
        left.booleanField = true;
        right.booleanField = true;
        final DiffBuilder<SimpleClass> builder = DiffBuilder.<SimpleClass>builder().setLeft(left).setRight(right)
                .setTestObjectsEquals(false).build();
        final DiffResult<SimpleClass> result = builder.append("booleanField", left.booleanField, right.booleanField).build();
        assertEquals(0, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendBooleanDiffer() {
        final SimpleClass left = new SimpleClass();
        final SimpleClass right = new SimpleClass();
        left.booleanField = true;
        right.booleanField = false;
        final DiffBuilder<SimpleClass> builder = DiffBuilder.<SimpleClass>builder().setLeft(left).setRight(right)
                .setTestObjectsEquals(false).build();
        final DiffResult<SimpleClass> result = builder.append("booleanField", left.booleanField, right.booleanField).build();
        assertEquals(1, result.getNumberOfDiffs());
        final Diff<?> diff = result.getDiffs().get(0);
        assertEquals("booleanField", diff.getFieldName());
        assertEquals(Boolean.TRUE, diff.getLeft());
        assertEquals(Boolean.FALSE, diff.getRight());
    }

    @Test
    public void testAppendBooleanArray() {
        final SimpleClass left = new SimpleClass();
        final SimpleClass right = new SimpleClass();
        left.booleanArrayField = new boolean[] {true, false};
        right.booleanArrayField = new boolean[] {true, true};
        final DiffBuilder<SimpleClass> builder = DiffBuilder.<SimpleClass>builder().setLeft(left).setRight(right)
                .setTestObjectsEquals(false).build();
        final DiffResult<SimpleClass> result = builder.append("booleanArrayField", left.booleanArrayField, right.booleanArrayField).build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendBooleanArrayEqual() {
        final SimpleClass left = new SimpleClass();
        final SimpleClass right = new SimpleClass();
        left.booleanArrayField = new boolean[] {true, false};
        right.booleanArrayField = new boolean[] {true, false};
        final DiffBuilder<SimpleClass> builder = DiffBuilder.<SimpleClass>builder().setLeft(left).setRight(right)
                .setTestObjectsEquals(false).build();
        final DiffResult<SimpleClass> result = builder.append("booleanArrayField", left.booleanArrayField, right.booleanArrayField).build();
        assertEquals(0, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendByte() {
        final SimpleClass left = new SimpleClass();
        final SimpleClass right = new SimpleClass();
        left.byteField = (byte) 1;
        right.byteField = (byte) 2;
        final DiffBuilder<SimpleClass> builder = DiffBuilder.<SimpleClass>builder().setLeft(left).setRight(right)
                .setTestObjectsEquals(false).build();
        final DiffResult<SimpleClass> result = builder.append("byteField", left.byteField, right.byteField).build();
        assertEquals(1, result.getNumberOfDiffs());
        assertEquals(Byte.valueOf((byte) 1), result.getDiffs().get(0).getLeft());
        assertEquals(Byte.valueOf((byte) 2), result.getDiffs().get(0).getRight());
    }

    @Test
    public void testAppendByteArray() {
        final SimpleClass left = new SimpleClass();
        final SimpleClass right = new SimpleClass();
        left.byteArrayField = new byte[] {1, 2};
        right.byteArrayField = new byte[] {1, 3};
        final DiffBuilder<SimpleClass> builder = DiffBuilder.<SimpleClass>builder().setLeft(left).setRight(right)
                .setTestObjectsEquals(false).build();
        final DiffResult<SimpleClass> result = builder.append("byteArrayField", left.byteArrayField, right.byteArrayField).build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendChar() {
        final SimpleClass left = new SimpleClass();
        final SimpleClass right = new SimpleClass();
        left.charField = 'a';
        right.charField = 'b';
        final DiffBuilder<SimpleClass> builder = DiffBuilder.<SimpleClass>builder().setLeft(left).setRight(right)
                .setTestObjectsEquals(false).build();
        final DiffResult<SimpleClass> result = builder.append("charField", left.charField, right.charField).build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendCharArray() {
        final SimpleClass left = new SimpleClass();
        final SimpleClass right = new SimpleClass();
        left.charArrayField = new char[] {'a', 'b'};
        right.charArrayField = new char[] {'a', 'c'};
        final DiffBuilder<SimpleClass> builder = DiffBuilder.<SimpleClass>builder().setLeft(left).setRight(right)
                .setTestObjectsEquals(false).build();
        final DiffResult<SimpleClass> result = builder.append("charArrayField", left.charArrayField, right.charArrayField).build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendDoubleEqualNaN() {
        final SimpleClass left = new SimpleClass();
        final SimpleClass right = new SimpleClass();
        left.doubleField = Double.NaN;
        right.doubleField = Double.NaN;
        final DiffBuilder<SimpleClass> builder = DiffBuilder.<SimpleClass>builder().setLeft(left).setRight(right)
                .setTestObjectsEquals(false).build();
        final DiffResult<SimpleClass> result = builder.append("doubleField", left.doubleField, right.doubleField).build();
        // Double.doubleToLongBits(NaN) == Double.doubleToLongBits(NaN), so this should NOT register a diff,
        // unlike a direct == comparison on NaN which would always be false.
        assertEquals(0, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendDoubleDiffer() {
        final SimpleClass left = new SimpleClass();
        final SimpleClass right = new SimpleClass();
        left.doubleField = 1.0;
        right.doubleField = 2.0;
        final DiffBuilder<SimpleClass> builder = DiffBuilder.<SimpleClass>builder().setLeft(left).setRight(right)
                .setTestObjectsEquals(false).build();
        final DiffResult<SimpleClass> result = builder.append("doubleField", left.doubleField, right.doubleField).build();
        assertEquals(1, result.getNumberOfDiffs());
        assertEquals(Double.valueOf(1.0), result.getDiffs().get(0).getLeft());
        assertEquals(Double.valueOf(2.0), result.getDiffs().get(0).getRight());
    }

    @Test
    public void testAppendDoubleArray() {
        final SimpleClass left = new SimpleClass();
        final SimpleClass right = new SimpleClass();
        left.doubleArrayField = new double[] {1.0, 2.0};
        right.doubleArrayField = new double[] {1.0, 3.0};
        final DiffBuilder<SimpleClass> builder = DiffBuilder.<SimpleClass>builder().setLeft(left).setRight(right)
                .setTestObjectsEquals(false).build();
        final DiffResult<SimpleClass> result = builder.append("doubleArrayField", left.doubleArrayField, right.doubleArrayField).build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendFloatEqualNaN() {
        final SimpleClass left = new SimpleClass();
        final SimpleClass right = new SimpleClass();
        left.floatField = Float.NaN;
        right.floatField = Float.NaN;
        final DiffBuilder<SimpleClass> builder = DiffBuilder.<SimpleClass>builder().setLeft(left).setRight(right)
                .setTestObjectsEquals(false).build();
        final DiffResult<SimpleClass> result = builder.append("floatField", left.floatField, right.floatField).build();
        assertEquals(0, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendFloatDiffer() {
        final SimpleClass left = new SimpleClass();
        final SimpleClass right = new SimpleClass();
        left.floatField = 1.0f;
        right.floatField = 2.0f;
        final DiffBuilder<SimpleClass> builder = DiffBuilder.<SimpleClass>builder().setLeft(left).setRight(right)
                .setTestObjectsEquals(false).build();
        final DiffResult<SimpleClass> result = builder.append("floatField", left.floatField, right.floatField).build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendFloatArray() {
        final SimpleClass left = new SimpleClass();
        final SimpleClass right = new SimpleClass();
        left.floatArrayField = new float[] {1.0f, 2.0f};
        right.floatArrayField = new float[] {1.0f, 9.0f};
        final DiffBuilder<SimpleClass> builder = DiffBuilder.<SimpleClass>builder().setLeft(left).setRight(right)
                .setTestObjectsEquals(false).build();
        final DiffResult<SimpleClass> result = builder.append("floatArrayField", left.floatArrayField, right.floatArrayField).build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendIntEqual() {
        final SimpleClass left = new SimpleClass();
        final SimpleClass right = new SimpleClass();
        left.intField = 42;
        right.intField = 42;
        final DiffBuilder<SimpleClass> builder = DiffBuilder.<SimpleClass>builder().setLeft(left).setRight(right)
                .setTestObjectsEquals(false).build();
        final DiffResult<SimpleClass> result = builder.append("intField", left.intField, right.intField).build();
        assertEquals(0, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendIntArray() {
        final SimpleClass left = new SimpleClass();
        final SimpleClass right = new SimpleClass();
        left.intArrayField = new int[] {1, 2, 3};
        right.intArrayField = new int[] {1, 2, 4};
        final DiffBuilder<SimpleClass> builder = DiffBuilder.<SimpleClass>builder().setLeft(left).setRight(right)
                .setTestObjectsEquals(false).build();
        final DiffResult<SimpleClass> result = builder.append("intArrayField", left.intArrayField, right.intArrayField).build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendLong() {
        final SimpleClass left = new SimpleClass();
        final SimpleClass right = new SimpleClass();
        left.longField = 1L;
        right.longField = 2L;
        final DiffBuilder<SimpleClass> builder = DiffBuilder.<SimpleClass>builder().setLeft(left).setRight(right)
                .setTestObjectsEquals(false).build();
        final DiffResult<SimpleClass> result = builder.append("longField", left.longField, right.longField).build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendLongArray() {
        final SimpleClass left = new SimpleClass();
        final SimpleClass right = new SimpleClass();
        left.longArrayField = new long[] {1L, 2L};
        right.longArrayField = new long[] {1L, 2L};
        final DiffBuilder<SimpleClass> builder = DiffBuilder.<SimpleClass>builder().setLeft(left).setRight(right)
                .setTestObjectsEquals(false).build();
        final DiffResult<SimpleClass> result = builder.append("longArrayField", left.longArrayField, right.longArrayField).build();
        assertEquals(0, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendShort() {
        final SimpleClass left = new SimpleClass();
        final SimpleClass right = new SimpleClass();
        left.shortField = (short) 1;
        right.shortField = (short) 2;
        final DiffBuilder<SimpleClass> builder = DiffBuilder.<SimpleClass>builder().setLeft(left).setRight(right)
                .setTestObjectsEquals(false).build();
        final DiffResult<SimpleClass> result = builder.append("shortField", left.shortField, right.shortField).build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendShortArray() {
        final SimpleClass left = new SimpleClass();
        final SimpleClass right = new SimpleClass();
        left.shortArrayField = new short[] {1, 2};
        right.shortArrayField = new short[] {1, 2};
        final DiffBuilder<SimpleClass> builder = DiffBuilder.<SimpleClass>builder().setLeft(left).setRight(right)
                .setTestObjectsEquals(false).build();
        final DiffResult<SimpleClass> result = builder.append("shortArrayField", left.shortArrayField, right.shortArrayField).build();
        assertEquals(0, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendObjectEqual() {
        final SimpleClass left = new SimpleClass();
        final SimpleClass right = new SimpleClass();
        left.stringField = "same";
        right.stringField = "same";
        final DiffBuilder<SimpleClass> builder = DiffBuilder.<SimpleClass>builder().setLeft(left).setRight(right)
                .setTestObjectsEquals(false).build();
        final DiffResult<SimpleClass> result = builder.append("stringField", (Object) left.stringField, (Object) right.stringField).build();
        assertEquals(0, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendObjectDiffer() {
        final SimpleClass left = new SimpleClass();
        final SimpleClass right = new SimpleClass();
        left.stringField = "left";
        right.stringField = "right";
        final DiffBuilder<SimpleClass> builder = DiffBuilder.<SimpleClass>builder().setLeft(left).setRight(right)
                .setTestObjectsEquals(false).build();
        final DiffResult<SimpleClass> result = builder.append("stringField", (Object) left.stringField, (Object) right.stringField).build();
        assertEquals(1, result.getNumberOfDiffs());
        assertEquals("left", result.getDiffs().get(0).getLeft());
        assertEquals("right", result.getDiffs().get(0).getRight());
    }

    @Test
    public void testAppendObjectSameReference() {
        final SimpleClass left = new SimpleClass();
        final SimpleClass right = new SimpleClass();
        final Object shared = new Object();
        final DiffBuilder<SimpleClass> builder = DiffBuilder.<SimpleClass>builder().setLeft(left).setRight(right)
                .setTestObjectsEquals(false).build();
        final DiffResult<SimpleClass> result = builder.append("field", shared, shared).build();
        assertEquals(0, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendObjectOneNull() {
        final SimpleClass left = new SimpleClass();
        final SimpleClass right = new SimpleClass();
        final DiffBuilder<SimpleClass> builder = DiffBuilder.<SimpleClass>builder().setLeft(left).setRight(right)
                .setTestObjectsEquals(false).build();
        final DiffResult<SimpleClass> result = builder.append("field", (Object) null, "value").build();
        assertEquals(1, result.getNumberOfDiffs());
        assertEquals(null, result.getDiffs().get(0).getLeft());
        assertEquals("value", result.getDiffs().get(0).getRight());
    }

    @Test
    public void testAppendObjectDispatchesToPrimitiveArrayVariants() {
        final SimpleClass left = new SimpleClass();
        final SimpleClass right = new SimpleClass();
        final DiffBuilder<SimpleClass> builder = DiffBuilder.<SimpleClass>builder().setLeft(left).setRight(right)
                .setTestObjectsEquals(false).build();
        final int[] leftArray = {1, 2};
        final int[] rightArray = {1, 3};
        final DiffResult<SimpleClass> result = builder.append("intArrayField", (Object) leftArray, (Object) rightArray).build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendObjectArray() {
        final SimpleClass left = new SimpleClass();
        final SimpleClass right = new SimpleClass();
        left.objectArrayField = new Object[] {"a", "b"};
        right.objectArrayField = new Object[] {"a", "c"};
        final DiffBuilder<SimpleClass> builder = DiffBuilder.<SimpleClass>builder().setLeft(left).setRight(right)
                .setTestObjectsEquals(false).build();
        final DiffResult<SimpleClass> result = builder.append("objectArrayField", left.objectArrayField, right.objectArrayField).build();
        assertEquals(1, result.getNumberOfDiffs());
    }

    @Test
    public void testAppendDiffResult() {
        final SimpleClass left = new SimpleClass();
        final SimpleClass right = new SimpleClass();
        left.intField = 1;
        right.intField = 2;
        final DiffBuilder<SimpleClass> innerBuilder = DiffBuilder.<SimpleClass>builder().setLeft(left).setRight(right)
                .setTestObjectsEquals(false).build();
        final DiffResult<SimpleClass> innerResult = innerBuilder.append("intField", left.intField, right.intField).build();
        assertEquals(1, innerResult.getNumberOfDiffs());

        final DiffBuilder<SimpleClass> outerBuilder = DiffBuilder.<SimpleClass>builder().setLeft(left).setRight(right)
                .setTestObjectsEquals(false).build();
        final DiffResult<SimpleClass> outerResult = outerBuilder.append("nested", innerResult).build();
        assertEquals(1, outerResult.getNumberOfDiffs());
        assertEquals("nested.intField", outerResult.getDiffs().get(0).getFieldName());
    }

    @Test
    public void testAppendDiffResultNullThrows() {
        final SimpleClass left = new SimpleClass();
        final SimpleClass right = new SimpleClass();
        final DiffBuilder<SimpleClass> builder = DiffBuilder.<SimpleClass>builder().setLeft(left).setRight(right)
                .setTestObjectsEquals(false).build();
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                builder.append("nested", (DiffResult<?>) null);
            }
        });
    }

    @Test
    public void testAppendFieldNameNullThrows() {
        final SimpleClass left = new SimpleClass();
        final SimpleClass right = new SimpleClass();
        final DiffBuilder<SimpleClass> builder = DiffBuilder.<SimpleClass>builder().setLeft(left).setRight(right)
                .setTestObjectsEquals(false).build();
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                builder.append(null, 1, 2);
            }
        });
    }

    @Test
    public void testBuildReturnsCorrectLeftAndRight() {
        final SimpleClass left = new SimpleClass();
        final SimpleClass right = new SimpleClass();
        final DiffBuilder<SimpleClass> builder = DiffBuilder.<SimpleClass>builder().setLeft(left).setRight(right)
                .setTestObjectsEquals(false).build();
        final DiffResult<SimpleClass> result = builder.append("intField", 1, 2).build();
        assertSame(left, result.getLeft());
        assertSame(right, result.getRight());
    }

    @Test
    public void testFluentChainReturnsSameInstance() {
        final SimpleClass left = new SimpleClass();
        final SimpleClass right = new SimpleClass();
        final DiffBuilder<SimpleClass> builder = DiffBuilder.<SimpleClass>builder().setLeft(left).setRight(right)
                .setTestObjectsEquals(false).build();
        final DiffBuilder<SimpleClass> returned = builder.append("intField", 1, 2);
        assertSame(builder, returned);
    }

    @Test
    public void testMultipleAppendsAccumulate() {
        final SimpleClass left = new SimpleClass();
        final SimpleClass right = new SimpleClass();
        final DiffBuilder<SimpleClass> builder = DiffBuilder.<SimpleClass>builder().setLeft(left).setRight(right)
                .setTestObjectsEquals(false).build();
        final DiffResult<SimpleClass> result = builder
                .append("a", 1, 2)
                .append("b", "x", "y")
                .append("c", 3, 3)
                .build();
        assertEquals(2, result.getNumberOfDiffs());
        final List<Diff<?>> diffs = result.getDiffs();
        assertEquals("a", diffs.get(0).getFieldName());
        assertEquals("b", diffs.get(1).getFieldName());
    }

    @Test
    public void testStyleDefaultsWhenNull() {
        final SimpleClass left = new SimpleClass();
        final SimpleClass right = new SimpleClass();
        final DiffBuilder<SimpleClass> builder = DiffBuilder.<SimpleClass>builder().setLeft(left).setRight(right)
                .setStyle(null).setTestObjectsEquals(false).build();
        final DiffResult<SimpleClass> result = builder.build();
        assertEquals(ToStringStyle.DEFAULT_STYLE, result.getToStringStyle());
    }

    @Test
    public void testCustomStylePreserved() {
        final SimpleClass left = new SimpleClass();
        final SimpleClass right = new SimpleClass();
        final DiffBuilder<SimpleClass> builder = DiffBuilder.<SimpleClass>builder().setLeft(left).setRight(right)
                .setStyle(ToStringStyle.SHORT_PREFIX_STYLE).setTestObjectsEquals(false).build();
        final DiffResult<SimpleClass> result = builder.build();
        assertEquals(ToStringStyle.SHORT_PREFIX_STYLE, result.getToStringStyle());
    }

    @Test
    public void testCustomToStringFormat() {
        final SimpleClass left = new SimpleClass();
        final SimpleClass right = new SimpleClass();
        left.intField = 1;
        right.intField = 2;
        final DiffBuilder<SimpleClass> builder = DiffBuilder.<SimpleClass>builder().setLeft(left).setRight(right)
                .setToStringFormat("%s vs %s").setTestObjectsEquals(false).build();
        final DiffResult<SimpleClass> result = builder.append("intField", left.intField, right.intField).build();
        assertTrue(result.toString().contains(" vs "));
    }

    @Test
    public void testToStringFormatNullDefaults() {
        final SimpleClass left = new SimpleClass();
        final SimpleClass right = new SimpleClass();
        left.intField = 1;
        right.intField = 2;
        final DiffBuilder<SimpleClass> builder = DiffBuilder.<SimpleClass>builder().setLeft(left).setRight(right)
                .setToStringFormat(null).setTestObjectsEquals(false).build();
        final DiffResult<SimpleClass> result = builder.append("intField", left.intField, right.intField).build();
        assertTrue(result.toString().contains("differs from"));
    }

    @Test
    public void testNoDiffsProducesEmptyToString() {
        final SimpleClass left = new SimpleClass();
        final SimpleClass right = new SimpleClass();
        final DiffBuilder<SimpleClass> builder = DiffBuilder.<SimpleClass>builder().setLeft(left).setRight(right)
                .setTestObjectsEquals(false).build();
        final DiffResult<SimpleClass> result = builder.build();
        assertEquals(DiffResult.OBJECTS_SAME_STRING, result.toString());
        assertFalse(result.iterator().hasNext());
    }

    @Test
    public void testBuilderHelperConstructsNonNullBuilder() {
        final DiffBuilder.Builder<SimpleClass> helper = DiffBuilder.builder();
        assertNotNull(helper);
        final SimpleClass left = new SimpleClass();
        final SimpleClass right = new SimpleClass();
        final DiffBuilder<SimpleClass> built = helper.setLeft(left).setRight(right).setTestObjectsEquals(false).build();
        assertNotNull(built);
        assertNotNull(built.build());
    }

    @Test
    public void testEqualPrimitivesViaTestObjectsEqualsShortCircuits() {
        // When left and right are the very same reference, the trivial-equal check
        // short circuits regardless of what is appended afterwards.
        final SimpleClass shared = new SimpleClass();
        final DiffBuilder<SimpleClass> builder = new DiffBuilder<SimpleClass>(shared, shared, ToStringStyle.DEFAULT_STYLE, true);
        final DiffResult<SimpleClass> result = builder.append("intField", 1, 2).append("stringField", "a", "b").build();
        assertEquals(0, result.getNumberOfDiffs());
    }
}
