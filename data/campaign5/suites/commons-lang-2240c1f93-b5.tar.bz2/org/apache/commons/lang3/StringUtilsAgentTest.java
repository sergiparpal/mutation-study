/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Arrays;
import java.util.Locale;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link StringUtils}.
 */
@SuppressWarnings("deprecation")
class StringUtilsAgentTest {

    @Test
    void testIsEmptyIsBlank() {
        assertTrue(StringUtils.isEmpty(null));
        assertTrue(StringUtils.isEmpty(""));
        assertFalse(StringUtils.isEmpty(" "));
        assertFalse(StringUtils.isEmpty("abc"));

        assertTrue(StringUtils.isBlank(null));
        assertTrue(StringUtils.isBlank(""));
        assertTrue(StringUtils.isBlank(" \t\n"));
        assertFalse(StringUtils.isBlank("abc"));
        assertFalse(StringUtils.isBlank(" abc "));

        assertFalse(StringUtils.isNotEmpty(null));
        assertTrue(StringUtils.isNotEmpty("abc"));
        assertFalse(StringUtils.isNotBlank(" "));
        assertTrue(StringUtils.isNotBlank("abc"));
    }

    @Test
    void testIsAnyAllEmptyBlank() {
        assertTrue(StringUtils.isAnyEmpty("abc", ""));
        assertFalse(StringUtils.isAnyEmpty("abc", "def"));
        assertFalse(StringUtils.isAnyEmpty());
        assertTrue(StringUtils.isAnyEmpty((CharSequence) null));

        assertTrue(StringUtils.isAllEmpty("", null));
        assertFalse(StringUtils.isAllEmpty("", "x"));
        assertTrue(StringUtils.isAllEmpty());

        assertTrue(StringUtils.isAnyBlank("abc", " "));
        assertFalse(StringUtils.isAnyBlank("abc", "def"));

        assertTrue(StringUtils.isAllBlank(" ", null, ""));
        assertFalse(StringUtils.isAllBlank(" ", "x"));

        assertTrue(StringUtils.isNoneEmpty("a", "b"));
        assertFalse(StringUtils.isNoneEmpty("a", ""));
        assertTrue(StringUtils.isNoneBlank("a", "b"));
        assertFalse(StringUtils.isNoneBlank("a", " "));
    }

    @Test
    void testTrimStrip() {
        assertNull(StringUtils.trim(null));
        assertEquals("", StringUtils.trim("   "));
        assertEquals("abc", StringUtils.trim("  abc  "));

        assertEquals("", StringUtils.trimToEmpty(null));
        assertEquals("", StringUtils.trimToEmpty("   "));
        assertNull(StringUtils.trimToNull("   "));
        assertEquals("abc", StringUtils.trimToNull("  abc  "));

        assertNull(StringUtils.strip(null));
        assertEquals("abc", StringUtils.strip(" abc "));
        assertEquals("abc", StringUtils.strip("xxabcyy", "xy"));
        assertNull(StringUtils.strip(null, "xy"));

        assertEquals("", StringUtils.stripToEmpty(null));
        assertNull(StringUtils.stripToNull("   "));

        assertEquals("abc  ", StringUtils.stripStart("  abc  ", null));
        assertEquals("  abc", StringUtils.stripEnd("  abc  ", null));
        assertNull(StringUtils.stripStart(null, "x"));
        assertNull(StringUtils.stripEnd(null, "x"));
    }

    @Test
    void testStripAll() {
        assertArrayEquals(new String[] {"abc", "x"}, StringUtils.stripAll(" abc ", "x "));
        assertNull(StringUtils.stripAll((String[]) null));
        assertArrayEquals(new String[] {"abc", null}, StringUtils.stripAll(" abc ", null));
    }

    @Test
    void testEqualsAndCompare() {
        assertTrue(StringUtils.equals(null, null));
        assertFalse(StringUtils.equals(null, "abc"));
        assertFalse(StringUtils.equals("abc", null));
        assertTrue(StringUtils.equals("abc", "abc"));
        assertFalse(StringUtils.equals("abc", "ABC"));

        assertTrue(StringUtils.equalsIgnoreCase("abc", "ABC"));
        assertTrue(StringUtils.equalsIgnoreCase(null, null));
        assertFalse(StringUtils.equalsIgnoreCase(null, "ABC"));

        assertTrue(StringUtils.equalsAny("abc", "xyz", "abc"));
        assertFalse(StringUtils.equalsAny("abc", "xyz", "def"));
        assertTrue(StringUtils.equalsAnyIgnoreCase("abc", "xyz", "ABC"));

        assertEquals(0, StringUtils.compare(null, null));
        assertTrue(StringUtils.compare(null, "a") < 0);
        assertTrue(StringUtils.compare("a", null) > 0);
        assertTrue(StringUtils.compare(null, "a", true) < 0);
        assertTrue(StringUtils.compare(null, "a", false) > 0);
        assertEquals(0, StringUtils.compareIgnoreCase("abc", "ABC"));
    }

    @Test
    void testContainsFamily() {
        assertTrue(StringUtils.contains("abc", "b"));
        assertFalse(StringUtils.contains("abc", "z"));
        assertFalse(StringUtils.contains(null, "a"));
        assertFalse(StringUtils.contains("abc", (CharSequence) null));

        assertTrue(StringUtils.contains("abc", (int) 'b'));
        assertFalse(StringUtils.contains(null, (int) 'b'));

        assertTrue(StringUtils.containsAny("abc", 'z', 'a'));
        assertFalse(StringUtils.containsAny("abc", 'x', 'y'));
        assertFalse(StringUtils.containsAny((CharSequence) null, 'a'));

        assertTrue(StringUtils.containsIgnoreCase("abc", "B"));
        assertFalse(StringUtils.containsIgnoreCase(null, "B"));

        assertTrue(StringUtils.containsNone("abc", 'x', 'y'));
        assertFalse(StringUtils.containsNone("abc", 'a'));

        assertTrue(StringUtils.containsOnly("aabbcc", 'a', 'b', 'c'));
        assertFalse(StringUtils.containsOnly("aabbccd", 'a', 'b', 'c'));
        assertFalse(StringUtils.containsOnly(null, 'a'));

        assertTrue(StringUtils.containsWhitespace("a b"));
        assertFalse(StringUtils.containsWhitespace("ab"));
        assertFalse(StringUtils.containsWhitespace(null));
    }

    @Test
    void testIndexOfLastIndexOf() {
        assertEquals(1, StringUtils.indexOf("abc", "b"));
        assertEquals(-1, StringUtils.indexOf(null, "b"));
        assertEquals(-1, StringUtils.indexOf("abc", "z"));
        assertEquals(1, StringUtils.indexOf("abc", (int) 'b'));

        assertEquals(5, StringUtils.lastIndexOf("abcabc", "c"));
        assertEquals(-1, StringUtils.lastIndexOf(null, "c"));

        assertEquals(1, StringUtils.indexOfAny("abc", 'b', 'z'));
        assertEquals(-1, StringUtils.indexOfAny((CharSequence) null, 'b'));
        assertEquals(0, StringUtils.indexOfAnyBut("abc", 'z'));

        assertEquals(1, StringUtils.indexOfIgnoreCase("abc", "B"));
        assertEquals(1, StringUtils.lastIndexOfIgnoreCase("abc", "B"));

        assertEquals(0, StringUtils.ordinalIndexOf("aabaabaa", "a", 1));
        assertEquals(1, StringUtils.ordinalIndexOf("aabaabaa", "a", 2));
        assertEquals(-1, StringUtils.ordinalIndexOf(null, "a", 1));
        assertEquals(6, StringUtils.lastOrdinalIndexOf("aabaabaa", "a", 2));
    }

    @Test
    void testStartsEndsWith() {
        assertTrue(StringUtils.startsWith("abcdef", "abc"));
        assertFalse(StringUtils.startsWith(null, "abc"));
        assertFalse(StringUtils.startsWith("abc", null));
        assertTrue(StringUtils.startsWithIgnoreCase("ABCdef", "abc"));
        assertTrue(StringUtils.startsWithAny("abc", "xyz", "ab"));

        assertTrue(StringUtils.endsWith("abcdef", "def"));
        assertFalse(StringUtils.endsWith(null, "def"));
        assertTrue(StringUtils.endsWithIgnoreCase("abcDEF", "def"));
        assertTrue(StringUtils.endsWithAny("abc", "xyz", "bc"));
    }

    @Test
    void testSubstringBoundaries() {
        assertNull(StringUtils.substring(null, 0));
        assertEquals("c", StringUtils.substring("abc", 2));
        assertEquals("", StringUtils.substring("abc", 4));
        assertEquals("bc", StringUtils.substring("abc", -2));
        assertEquals("abc", StringUtils.substring("abc", -4));

        assertNull(StringUtils.substring(null, 0, 2));
        assertEquals("ab", StringUtils.substring("abc", 0, 2));
        assertEquals("", StringUtils.substring("abc", 2, 0));
        assertEquals("c", StringUtils.substring("abc", 2, 4));
        assertEquals("", StringUtils.substring("abc", 4, 6));
        assertEquals("b", StringUtils.substring("abc", -2, -1));
        assertEquals("ab", StringUtils.substring("abc", -4, 2));
    }

    @Test
    void testSubstringBeforeAfter() {
        assertNull(StringUtils.substringAfter(null, "a"));
        assertEquals("", StringUtils.substringAfter("", "a"));
        assertEquals("bc", StringUtils.substringAfter("abc", "a"));
        assertEquals("", StringUtils.substringAfter("abc", "x"));
        assertEquals("", StringUtils.substringAfter("abc", (String) null));

        assertNull(StringUtils.substringBefore(null, "a"));
        assertEquals("", StringUtils.substringBefore("abc", "a"));
        assertEquals("abc", StringUtils.substringBefore("abc", "x"));
        assertEquals("abc", StringUtils.substringBefore("abc", (String) null));

        assertEquals("ba", StringUtils.substringAfterLast("abcba", "c"));
        assertEquals("", StringUtils.substringAfterLast("abc", (String) null));

        assertEquals("ab", StringUtils.substringBeforeLast("abcba", "c"));
        assertEquals("", StringUtils.substringBeforeLast("", "a"));

        assertEquals("b", StringUtils.substringBetween("yabcz", "a", "c"));
        assertNull(StringUtils.substringBetween("yabcz", "x"));
        assertArrayEquals(new String[] {"b", "e"}, StringUtils.substringsBetween("[b][e]", "[", "]"));
    }

    @Test
    void testPadding() {
        assertNull(StringUtils.leftPad(null, 3));
        assertEquals("  ab", StringUtils.leftPad("ab", 4));
        assertEquals("ab", StringUtils.leftPad("ab", 1));
        assertEquals("xxab", StringUtils.leftPad("ab", 4, 'x'));
        assertEquals("xyxyab", StringUtils.leftPad("ab", 6, "xy"));

        assertEquals("ab  ", StringUtils.rightPad("ab", 4));
        assertEquals("abxx", StringUtils.rightPad("ab", 4, 'x'));
        assertEquals("abxyxy", StringUtils.rightPad("ab", 6, "xy"));

        assertEquals(" ab ", StringUtils.center("ab", 4));
        assertEquals("ab", StringUtils.center("ab", 1));
        assertEquals("xxabxx", StringUtils.center("ab", 6, 'x'));
        assertEquals("xyabxy", StringUtils.center("ab", 6, "xy"));
    }

    @Test
    void testCaseConversion() {
        assertNull(StringUtils.upperCase(null));
        assertEquals("ABC", StringUtils.upperCase("abc"));
        assertEquals("ABC", StringUtils.upperCase("abc", Locale.ENGLISH));

        assertNull(StringUtils.lowerCase(null));
        assertEquals("abc", StringUtils.lowerCase("ABC"));
        assertEquals("abc", StringUtils.lowerCase("ABC", Locale.ENGLISH));

        assertNull(StringUtils.capitalize(null));
        assertEquals("Cat", StringUtils.capitalize("cat"));
        assertEquals("", StringUtils.capitalize(""));

        assertNull(StringUtils.uncapitalize(null));
        assertEquals("cat", StringUtils.uncapitalize("Cat"));

        assertNull(StringUtils.swapCase(null));
        assertEquals("ABcd", StringUtils.swapCase("abCD"));

        assertTrue(StringUtils.isAllLowerCase("abc"));
        assertFalse(StringUtils.isAllLowerCase("abC"));
        assertFalse(StringUtils.isAllLowerCase(null));
        assertTrue(StringUtils.isAllUpperCase("ABC"));
        assertFalse(StringUtils.isAllUpperCase(""));
        assertTrue(StringUtils.isMixedCase("aB"));
        assertFalse(StringUtils.isMixedCase("ab"));
        assertFalse(StringUtils.isMixedCase(null));
    }

    @Test
    void testIsAlphaNumericFamily() {
        assertTrue(StringUtils.isAlpha("abc"));
        assertFalse(StringUtils.isAlpha("abc1"));
        assertFalse(StringUtils.isAlpha(""));
        assertFalse(StringUtils.isAlpha(null));

        assertTrue(StringUtils.isAlphanumeric("abc123"));
        assertFalse(StringUtils.isAlphanumeric("abc 123"));

        assertTrue(StringUtils.isAlphanumericSpace("abc 123"));
        assertTrue(StringUtils.isAlphaSpace("abc def"));

        assertTrue(StringUtils.isNumeric("12345"));
        assertFalse(StringUtils.isNumeric("12.3"));
        assertFalse(StringUtils.isNumeric(""));
        assertTrue(StringUtils.isNumericSpace("123 456"));

        assertTrue(StringUtils.isWhitespace("  \t"));
        assertFalse(StringUtils.isWhitespace("a "));
        assertFalse(StringUtils.isWhitespace(null));

        assertTrue(StringUtils.isAsciiPrintable("abc 123!"));
        assertFalse(StringUtils.isAsciiPrintable("abc\u0001"));
        assertFalse(StringUtils.isAsciiPrintable(null));
    }

    @Test
    void testJoin() {
        assertEquals("a,b,c", StringUtils.join(new Object[] {"a", "b", "c"}, ','));
        assertNull(StringUtils.join((Object[]) null, ','));
        assertEquals("abc", StringUtils.join(new Object[] {"a", "b", "c"}, (String) null));
        assertEquals("a-b-c", StringUtils.join(Arrays.asList("a", "b", "c"), "-"));
        assertEquals("a-b-c", StringUtils.join(Arrays.asList("a", "b", "c").iterator(), "-"));
        assertEquals("1,2,3", StringUtils.join(new int[] {1, 2, 3}, ','));
        assertEquals("true,false", StringUtils.join(new boolean[] {true, false}, ','));
        assertEquals("abc", StringUtils.join("a", "b", "c"));
        assertEquals("a-b", StringUtils.joinWith("-", "a", "b"));
        assertThrows(IllegalArgumentException.class, () -> StringUtils.joinWith("-", (Object[]) null));
    }

    @Test
    void testSplit() {
        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.split("a b  c"));
        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.split("a.b.c", '.'));
        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.split("a..b.c", "."));
        assertArrayEquals(new String[] {"a", "", "b", "c"}, StringUtils.splitPreserveAllTokens("a..b.c", "."));
        assertNull(StringUtils.split(null));
        assertArrayEquals(new String[0], StringUtils.split(""));

        assertArrayEquals(new String[] {"a", "b"}, StringUtils.splitByWholeSeparator("a::b", "::"));
        assertArrayEquals(new String[] {"a", "", "b"}, StringUtils.splitByWholeSeparatorPreserveAllTokens("a::::b", "::"));
    }

    @Test
    void testReplaceRemove() {
        assertEquals("foo", StringUtils.replace("foo", "bar", "baz"));
        assertEquals("bazbaz", StringUtils.replace("foofoo", "foo", "baz"));
        assertEquals("bazfoo", StringUtils.replace("foofoo", "foo", "baz", 1));
        assertNull(StringUtils.replace(null, "a", "b"));

        assertEquals("ac", StringUtils.remove("abc", "b"));
        assertEquals("ac", StringUtils.remove("abc", 'b'));
        assertNull(StringUtils.remove(null, "b"));

        assertEquals("domain.com", StringUtils.removeStart("www.domain.com", "www."));
        assertEquals("www.domain.com", StringUtils.removeStart("www.domain.com", "xyz"));
        assertEquals("abc", StringUtils.removeStart("abc", 'z'));
        assertEquals("bz", StringUtils.removeStart("abz", 'a'));

        assertEquals("www.domain", StringUtils.removeEnd("www.domain.com", ".com"));
        assertEquals("foo", StringUtils.removeEndIgnoreCase("fooBAR", "bar"));
        assertEquals("", StringUtils.removeIgnoreCase("fooBAR", "FOOBAR"));

        assertEquals("zbab", StringUtils.replaceOnce("abab", "a", "z"));
        assertNull(StringUtils.replaceOnce(null, "a", "z"));
        assertEquals("zbAb", StringUtils.replaceOnceIgnoreCase("abAb", "a", "z"));
    }

    @Test
    void testReplaceEachAndChars() {
        assertEquals("foo_bar", StringUtils.replaceEach("foo bar", new String[] {" "}, new String[] {"_"}));
        assertNull(StringUtils.replaceEach(null, new String[] {"a"}, new String[] {"b"}));
        assertEquals("bar_foo", StringUtils.replaceEachRepeatedly("foo bar", new String[] {"foo bar", " "}, new String[] {"bar foo", "_"}));

        assertEquals("xyzzx", StringUtils.replaceChars("abcca", "abc", "xyz"));
        assertEquals("ayca", StringUtils.replaceChars("abca", 'b', 'y'));
    }

    @Test
    void testAbbreviate() {
        assertNull(StringUtils.abbreviate(null, 4));
        assertEquals("abc...", StringUtils.abbreviate("abcdefg", 6));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", 7));
        assertThrows(IllegalArgumentException.class, () -> StringUtils.abbreviate("abcdefg", 3));

        assertEquals("...fg", StringUtils.abbreviate("abcdefg", 5, 5));
        assertEquals("ab", StringUtils.abbreviateMiddle("ab", "...", 0));
        assertEquals("ab...yz", StringUtils.abbreviateMiddle("abcdefghiyz", "...", 7));
    }

    @Test
    void testTruncate() {
        assertNull(StringUtils.truncate(null, 0));
        assertEquals("abcdef", StringUtils.truncate("abcdefg", 6));
        assertEquals("abcdefg", StringUtils.truncate("abcdefg", 7));
        assertThrows(IllegalArgumentException.class, () -> StringUtils.truncate("abcdefg", -1));
        assertThrows(IllegalArgumentException.class, () -> StringUtils.truncate("abcdefg", -1, 10));
        assertThrows(IllegalArgumentException.class, () -> StringUtils.truncate("abcdefg", 2, -1));
        assertEquals("fghij", StringUtils.truncate("abcdefghijklmno", 5, 5));
    }

    @Test
    void testRepeat() {
        assertNull(StringUtils.repeat(null, 2));
        assertEquals("", StringUtils.repeat("", 2));
        assertEquals("aaa", StringUtils.repeat("a", 3));
        assertEquals("abab", StringUtils.repeat("ab", 2));
        assertEquals("", StringUtils.repeat("a", -2));

        assertEquals("", StringUtils.repeat('x', 0));
        assertEquals("xxx", StringUtils.repeat('x', 3));

        assertNull(StringUtils.repeat(null, "x", 2));
        assertEquals("?, ?, ?", StringUtils.repeat("?", ", ", 3));
    }

    @Test
    void testReverse() {
        assertNull(StringUtils.reverse(null));
        assertEquals("cba", StringUtils.reverse("abc"));
        assertEquals("", StringUtils.reverse(""));

        assertEquals("a.c.b", StringUtils.reverseDelimited("b.c.a", '.'));
    }

    @Test
    void testDefaultStringFamily() {
        assertEquals("", StringUtils.defaultString(null));
        assertEquals("abc", StringUtils.defaultString("abc"));
        assertEquals("NULL", StringUtils.defaultString(null, "NULL"));

        assertEquals("NULL", StringUtils.defaultIfEmpty("", "NULL"));
        assertEquals("abc", StringUtils.defaultIfEmpty("abc", "NULL"));
        assertEquals("NULL", StringUtils.defaultIfBlank("   ", "NULL"));

        assertEquals("NULL", StringUtils.getIfEmpty("", () -> "NULL"));
        assertEquals("NULL", StringUtils.getIfBlank(" ", () -> "NULL"));
    }

    @Test
    void testFirstNonEmptyAndBlank() {
        assertEquals("abc", StringUtils.firstNonEmpty(null, "", "abc"));
        assertNull(StringUtils.firstNonEmpty((String[]) null));
        assertEquals("abc", StringUtils.firstNonBlank(null, " ", "abc"));
        assertNull(StringUtils.firstNonBlank());
    }

    @Test
    void testCountMatches() {
        assertEquals(0, StringUtils.countMatches(null, 'a'));
        assertEquals(3, StringUtils.countMatches("banana", 'a'));
        assertEquals(2, StringUtils.countMatches("banana", "an"));
        assertEquals(0, StringUtils.countMatches("banana", ""));
    }

    @Test
    void testGetCommonPrefix() {
        assertEquals("", StringUtils.getCommonPrefix((String[]) null));
        assertEquals("", StringUtils.getCommonPrefix());
        assertEquals("ab", StringUtils.getCommonPrefix("abc", "abd"));
        assertEquals("", StringUtils.getCommonPrefix("abc", "xyz"));
        assertEquals("i am a ", StringUtils.getCommonPrefix("i am a machine", "i am a robot"));
    }

    @Test
    void testDifference() {
        assertEquals("", StringUtils.difference("abc", "abc"));
        assertEquals("yz", StringUtils.difference("abc", "abyz"));
        assertNull(StringUtils.difference(null, null));
        assertEquals("", StringUtils.difference(null, ""));
    }

    @Test
    void testLevenshteinAndFuzzyDistance() {
        assertEquals(1, StringUtils.getLevenshteinDistance("frog", "fog"));
        assertEquals(0, StringUtils.getLevenshteinDistance("", ""));
        assertThrows(IllegalArgumentException.class, () -> StringUtils.getLevenshteinDistance(null, "a"));

        assertEquals(7, StringUtils.getLevenshteinDistance("elephant", "hippo", 7));
        assertEquals(-1, StringUtils.getLevenshteinDistance("elephant", "hippo", 6));
        assertThrows(IllegalArgumentException.class, () -> StringUtils.getLevenshteinDistance("a", "b", -1));

        assertEquals(1, StringUtils.getFuzzyDistance("Workshop", "w", Locale.ENGLISH));
        assertThrows(IllegalArgumentException.class, () -> StringUtils.getFuzzyDistance(null, "a", Locale.ENGLISH));
        assertThrows(IllegalArgumentException.class, () -> StringUtils.getFuzzyDistance("a", "b", null));

        assertTrue(StringUtils.getJaroWinklerDistance("frog", "fog") > 0.0);
        assertThrows(IllegalArgumentException.class, () -> StringUtils.getJaroWinklerDistance(null, "a"));
    }

    @Test
    void testWrapUnwrap() {
        assertNull(StringUtils.wrap(null, '"'));
        assertEquals("\"abc\"", StringUtils.wrap("abc", '"'));
        assertEquals("", StringUtils.wrap("", '"'));

        assertEquals("abc", StringUtils.unwrap("\"abc\"", '"'));
        assertEquals("abc", StringUtils.unwrap("abc", '"'));
        assertNull(StringUtils.unwrap(null, '"'));

        assertEquals("\"abc\"", StringUtils.wrapIfMissing("abc", '"'));
        assertEquals("\"abc\"", StringUtils.wrapIfMissing("\"abc\"", '"'));
    }

    @Test
    void testOverlayAndRotate() {
        assertEquals("abef", StringUtils.overlay("abcdef", "", 2, 4));
        assertEquals("abzzzzef", StringUtils.overlay("abcdef", "zzzz", 2, 4));
        assertNull(StringUtils.overlay(null, "x", 0, 0));

        assertEquals("defabc", StringUtils.rotate("abcdef", 3));
        assertEquals("abcdef", StringUtils.rotate("abcdef", 0));
        assertEquals("bcdefa", StringUtils.rotate("abcdef", -1));
        assertEquals("", StringUtils.rotate("", 5));
        assertNull(StringUtils.rotate(null, 5));
    }

    @Test
    void testNormalizeSpaceAndDeleteWhitespace() {
        assertEquals("ab c", StringUtils.normalizeSpace(" ab   c "));
        assertNull(StringUtils.normalizeSpace(null));

        assertEquals("abc", StringUtils.deleteWhitespace(" a b\tc\n"));
        assertNull(StringUtils.deleteWhitespace(null));
    }

    @Test
    void testAppendPrependIfMissing() {
        assertEquals("abcxyz", StringUtils.appendIfMissing("abc", "xyz"));
        assertEquals("abcxyz", StringUtils.appendIfMissing("abcxyz", "xyz"));
        assertEquals("abcXYZ", StringUtils.appendIfMissingIgnoreCase("abcXYZ", "xyz"));

        assertEquals("xyzabc", StringUtils.prependIfMissing("abc", "xyz"));
        assertEquals("xyzabc", StringUtils.prependIfMissing("xyzabc", "xyz"));
        assertEquals("XYZabc", StringUtils.prependIfMissingIgnoreCase("XYZabc", "xyz"));
    }

    @Test
    void testMidLeftRight() {
        assertNull(StringUtils.mid(null, 0, 2));
        assertEquals("", StringUtils.mid("abc", 0, -1));
        assertEquals("abc", StringUtils.mid("abc", 0, 10));
        assertEquals("b", StringUtils.mid("abc", 1, 1));
        assertEquals("abc", StringUtils.mid("abc", -1, 10));

        assertNull(StringUtils.left(null, 2));
        assertEquals("ab", StringUtils.left("abc", 2));
        assertEquals("", StringUtils.left("abc", -1));
        assertEquals("abc", StringUtils.left("abc", 10));

        assertNull(StringUtils.right(null, 2));
        assertEquals("bc", StringUtils.right("abc", 2));
        assertEquals("", StringUtils.right("abc", -1));
        assertEquals("abc", StringUtils.right("abc", 10));
    }

    @Test
    void testChompChop() {
        assertNull(StringUtils.chomp(null));
        assertEquals("abc", StringUtils.chomp("abc\n"));
        assertEquals("abc", StringUtils.chomp("abc\r\n"));
        assertEquals("abc", StringUtils.chomp("abc"));
        assertEquals("abc", StringUtils.chomp("abcdef", "def"));

        assertNull(StringUtils.chop(null));
        assertEquals("", StringUtils.chop(""));
        assertEquals("ab", StringUtils.chop("abc"));
        assertEquals("abc", StringUtils.chop("abc\r\n"));
    }

    @Test
    void testLength() {
        assertEquals(0, StringUtils.length(null));
        assertEquals(3, StringUtils.length("abc"));
    }

    @Test
    void testToCodePointsAndValueOf() {
        final int[] codePoints = StringUtils.toCodePoints("ab");
        assertArrayEquals(new int[] {'a', 'b'}, codePoints);
        assertNull(StringUtils.toCodePoints(null));
        assertArrayEquals(ArrayUtils.EMPTY_INT_ARRAY, StringUtils.toCodePoints(""));

        assertEquals("abc", StringUtils.valueOf(new char[] {'a', 'b', 'c'}));
        assertNull(StringUtils.valueOf(null));
    }

    @Test
    void testGetDigitsAndStripAccents() {
        assertEquals("123", StringUtils.getDigits("a1b2c3"));
        assertNull(StringUtils.getDigits(null));
        assertEquals("", StringUtils.getDigits(""));

        assertEquals("eclair", StringUtils.stripAccents("éclair"));
        assertNull(StringUtils.stripAccents(null));
    }

    @Test
    void testIndexOfDifference() {
        assertEquals(-1, StringUtils.indexOfDifference("abc", "abc"));
        assertEquals(1, StringUtils.indexOfDifference("abc", "aXc"));
        assertEquals(-1, StringUtils.indexOfDifference((CharSequence[]) null));
        assertEquals(0, StringUtils.indexOfDifference("abc", "xyz"));
    }

    @Test
    void testSplitByCharacterType() {
        assertArrayEquals(new String[] {"ab", "D", "e", "123"}, StringUtils.splitByCharacterType("abDe123"));
        assertNull(StringUtils.splitByCharacterType(null));

        assertArrayEquals(new String[] {"ab", "Camel", "Case"}, StringUtils.splitByCharacterTypeCamelCase("abCamelCase"));
    }

    @Test
    void testToRootCase() {
        assertEquals("abc", StringUtils.toRootLowerCase("ABC"));
        assertNull(StringUtils.toRootLowerCase(null));
        assertEquals("ABC", StringUtils.toRootUpperCase("abc"));
        assertNull(StringUtils.toRootUpperCase(null));
    }

    @Test
    void testConstants() {
        assertEquals("", StringUtils.EMPTY);
        assertEquals(" ", StringUtils.SPACE);
        assertEquals(-1, StringUtils.INDEX_NOT_FOUND);
        assertSame(StringUtils.EMPTY, StringUtils.defaultString(null));
    }
}
