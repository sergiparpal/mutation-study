/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.util.Arrays;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link StrBuilder}.
 */
@SuppressWarnings("deprecation")
class StrBuilderAgentTest {

    @Test
    void testConstructors() {
        final StrBuilder empty = new StrBuilder();
        assertEquals(0, empty.length());
        assertEquals(32, empty.capacity());

        final StrBuilder zeroCapacity = new StrBuilder(0);
        assertEquals(32, zeroCapacity.capacity());

        final StrBuilder negativeCapacity = new StrBuilder(-5);
        assertEquals(32, negativeCapacity.capacity());

        final StrBuilder sized = new StrBuilder(10);
        assertEquals(10, sized.capacity());

        final StrBuilder fromString = new StrBuilder("abc");
        assertEquals("abc", fromString.toString());
        assertEquals(3 + 32, fromString.capacity());

        final StrBuilder fromNull = new StrBuilder((String) null);
        assertEquals("", fromNull.toString());
        assertEquals(0, fromNull.length());
    }

    @Test
    void testAppendPrimitives() {
        final StrBuilder sb = new StrBuilder();
        sb.append(true).append(false).append('!').append(1).append(2L).append(1.5f).append(2.5d);
        assertEquals("truefalse!12" + String.valueOf(1.5f) + String.valueOf(2.5d), sb.toString());
    }

    @Test
    void testAppendCharArray() {
        final StrBuilder sb = new StrBuilder();
        sb.append((char[]) null);
        assertEquals("", sb.toString());

        sb.append(new char[0]);
        assertEquals("", sb.toString());

        sb.append(new char[] {'a', 'b', 'c'});
        assertEquals("abc", sb.toString());

        sb.append(new char[] {'x', 'y', 'z'}, 1, 2);
        assertEquals("abcyz", sb.toString());

        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append(new char[] {'a'}, -1, 1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append(new char[] {'a'}, 0, 2));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append(new char[] {'a'}, 2, 0));
    }

    @Test
    void testAppendCharSequenceAndObject() {
        final StrBuilder sb = new StrBuilder();
        sb.append((CharSequence) null);
        assertEquals("", sb.toString());

        sb.append((CharSequence) "abc");
        assertEquals("abc", sb.toString());

        sb.append((Object) null);
        assertEquals("abc", sb.toString());

        final Object fooObj = new Object() {
            @Override
            public String toString() {
                return "foo";
            }
        };
        sb.append(fooObj);
        assertEquals("abcfoo", sb.toString());

        sb.clear();
        sb.append("abcdef", 1, 3);
        assertEquals("bcd", sb.toString());
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append("abc", -1, 1));
    }

    @Test
    void testAppendNullTextDefault() {
        final StrBuilder sb = new StrBuilder();
        sb.append((String) null);
        assertEquals("", sb.toString());

        sb.setNullText("NULL");
        sb.append((Object) null);
        assertEquals("NULL", sb.toString());

        sb.setNullText("");
        assertNull(sb.getNullText());
    }

    @Test
    void testAppendStringRangeBounds() {
        final StrBuilder sb = new StrBuilder();
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append("abc", -1, 1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append("abc", 0, 10));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.append("abc", 4, 1));
    }

    @Test
    void testAppendFormatted() {
        final StrBuilder sb = new StrBuilder();
        sb.append("%s-%d", "x", 5);
        assertEquals("x-5", sb.toString());
    }

    @Test
    void testAppendStringBufferAndBuilder() {
        final StrBuilder sb = new StrBuilder();
        sb.append(new StringBuffer("abc"));
        assertEquals("abc", sb.toString());
        sb.append((StringBuffer) null);
        assertEquals("abc", sb.toString());

        sb.append(new StringBuilder("def"), 1, 2);
        assertEquals("abcef", sb.toString());
    }

    @Test
    void testAppendAllIterableIteratorArray() {
        final StrBuilder sb = new StrBuilder();
        sb.appendAll(Arrays.asList("a", "b", "c"));
        assertEquals("abc", sb.toString());

        sb.clear();
        sb.appendAll(Arrays.asList("a", "b").iterator());
        assertEquals("ab", sb.toString());

        sb.clear();
        sb.appendAll("x", "y", "z");
        assertEquals("xyz", sb.toString());

        sb.clear();
        sb.appendAll((Iterable<?>) null);
        sb.appendAll((java.util.Iterator<?>) null);
        assertEquals("", sb.toString());
    }

    @Test
    void testAppendFixedWidthPad() {
        final StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft(5, 4, '0');
        assertEquals("0005", sb.toString());

        sb.clear();
        sb.appendFixedWidthPadLeft(123456, 4, '0');
        assertEquals("3456", sb.toString());

        sb.clear();
        sb.appendFixedWidthPadRight(5, 4, '0');
        assertEquals("5000", sb.toString());

        sb.clear();
        sb.appendFixedWidthPadRight(123456, 4, '0');
        assertEquals("1234", sb.toString());

        sb.clear();
        sb.appendFixedWidthPadLeft("ab", 0, 'x');
        assertEquals("", sb.toString());
    }

    @Test
    void testAppendNewLineAndNull() {
        final StrBuilder sb = new StrBuilder("a");
        sb.appendNewLine();
        assertEquals("a" + System.lineSeparator(), sb.toString());

        sb.setNewLineText("|");
        sb.appendNewLine();
        assertEquals("a" + System.lineSeparator() + "|", sb.toString());
        assertEquals("|", sb.getNewLineText());

        final StrBuilder sb2 = new StrBuilder();
        sb2.appendNull();
        assertEquals("", sb2.toString());
    }

    @Test
    void testAppendPadding() {
        final StrBuilder sb = new StrBuilder();
        sb.appendPadding(3, '*');
        assertEquals("***", sb.toString());

        sb.appendPadding(-1, '*');
        assertEquals("***", sb.toString());
    }

    @Test
    void testAppendSeparators() {
        final StrBuilder sb = new StrBuilder();
        sb.appendSeparator(',');
        assertEquals("", sb.toString());
        sb.append("a");
        sb.appendSeparator(',');
        sb.append("b");
        assertEquals("a,b", sb.toString());

        final StrBuilder sb2 = new StrBuilder();
        sb2.appendSeparator(',', ';');
        assertEquals(";", sb2.toString());
        sb2.append("x");
        sb2.appendSeparator(',', ';');
        assertEquals(";x,", sb2.toString());

        final StrBuilder sb3 = new StrBuilder();
        for (int i = 0; i < 3; i++) {
            sb3.appendSeparator(",", i);
            sb3.append(i);
        }
        assertEquals("0,1,2", sb3.toString());

        final StrBuilder sb4 = new StrBuilder();
        sb4.appendSeparator((String) null);
        assertEquals("", sb4.toString());
        sb4.append("a");
        sb4.appendSeparator((String) null);
        sb4.append("b");
        assertEquals("ab", sb4.toString());

        final StrBuilder sb5 = new StrBuilder();
        sb5.appendSeparator("and", "where");
        assertEquals("where", sb5.toString());
        sb5.append("x = 1");
        sb5.appendSeparator("and", "where");
        assertEquals("wherex = 1and", sb5.toString());
    }

    @Test
    void testAppendToAppendable() throws IOException {
        final StrBuilder sb = new StrBuilder("hello");
        final StringBuilder dest = new StringBuilder();
        sb.appendTo(dest);
        assertEquals("hello", dest.toString());

        final StringBuffer destBuf = new StringBuffer();
        sb.appendTo(destBuf);
        assertEquals("hello", destBuf.toString());
    }

    @Test
    void testAppendWithSeparatorsIterableIteratorArray() {
        final StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators(Arrays.asList("a", "b", "c"), ",");
        assertEquals("a,b,c", sb.toString());

        sb.clear();
        sb.appendWithSeparators(Arrays.asList("a", "b").iterator(), "-");
        assertEquals("a-b", sb.toString());

        sb.clear();
        sb.appendWithSeparators(new Object[] {"x", "y"}, null);
        assertEquals("xy", sb.toString());

        sb.clear();
        sb.appendWithSeparators((Iterable<?>) null, ",");
        assertEquals("", sb.toString());
    }

    @Test
    void testCapacityEnsureCapacityMinimize() {
        final StrBuilder sb = new StrBuilder(5);
        assertEquals(5, sb.capacity());
        sb.ensureCapacity(20);
        assertTrue(sb.capacity() >= 20);

        sb.ensureCapacity(1);
        assertTrue(sb.capacity() >= 20);

        sb.append("ab");
        sb.minimizeCapacity();
        assertEquals(2, sb.capacity());
    }

    @Test
    void testCharAtAndSetCharAtAndDeleteCharAt() {
        final StrBuilder sb = new StrBuilder("abc");
        assertEquals('a', sb.charAt(0));
        assertEquals('c', sb.charAt(2));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.charAt(-1));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.charAt(3));

        sb.setCharAt(1, 'X');
        assertEquals("aXc", sb.toString());
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.setCharAt(-1, 'z'));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.setCharAt(3, 'z'));

        sb.deleteCharAt(1);
        assertEquals("ac", sb.toString());
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.deleteCharAt(5));
    }

    @Test
    void testClearIsEmptyIsNotEmptySize() {
        final StrBuilder sb = new StrBuilder("abc");
        assertFalse(sb.isEmpty());
        assertTrue(sb.isNotEmpty());
        assertEquals(3, sb.size());

        sb.clear();
        assertTrue(sb.isEmpty());
        assertFalse(sb.isNotEmpty());
        assertEquals(0, sb.size());
        assertEquals(0, sb.length());
    }

    @Test
    void testContains() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertTrue(sb.contains('b'));
        assertFalse(sb.contains('z'));
        assertTrue(sb.contains("bc"));
        assertFalse(sb.contains("zz"));
        assertTrue(sb.contains(StrMatcher.charMatcher('a')));
        assertFalse(sb.contains((StrMatcher) null));
    }

    @Test
    void testDeleteRangeAndValidation() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.delete(1, 3);
        assertEquals("adef", sb.toString());

        sb.delete(2, 100);
        assertEquals("ad", sb.toString());

        assertThrows(StringIndexOutOfBoundsException.class, () -> new StrBuilder("abc").delete(-1, 2));
        assertThrows(StringIndexOutOfBoundsException.class, () -> new StrBuilder("abc").delete(2, 1));

        final StrBuilder noop = new StrBuilder("abc");
        noop.delete(1, 1);
        assertEquals("abc", noop.toString());
    }

    @Test
    void testDeleteAllAndFirst() {
        final StrBuilder sb = new StrBuilder("abcabc");
        sb.deleteAll('a');
        assertEquals("bcbc", sb.toString());

        final StrBuilder sb2 = new StrBuilder("abcabc");
        sb2.deleteFirst('a');
        assertEquals("bcabc", sb2.toString());
        sb2.deleteFirst('z');
        assertEquals("bcabc", sb2.toString());

        final StrBuilder sb3 = new StrBuilder("abcabc");
        sb3.deleteAll("bc");
        assertEquals("aa", sb3.toString());
        sb3.deleteAll((String) null);
        assertEquals("aa", sb3.toString());

        final StrBuilder sb4 = new StrBuilder("abcabc");
        sb4.deleteFirst("bc");
        assertEquals("aabc", sb4.toString());
    }

    @Test
    void testEndsWithStartsWith() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertTrue(sb.endsWith("def"));
        assertFalse(sb.endsWith("abc"));
        assertFalse(sb.endsWith((String) null));
        assertTrue(sb.endsWith(""));

        assertTrue(sb.startsWith("abc"));
        assertFalse(sb.startsWith("def"));
        assertFalse(sb.startsWith((String) null));
        assertTrue(sb.startsWith(""));
    }

    @Test
    void testEqualsAndHashCode() {
        final StrBuilder sb1 = new StrBuilder("abc");
        final StrBuilder sb2 = new StrBuilder("abc");
        final StrBuilder sb3 = new StrBuilder("abd");

        assertTrue(sb1.equals(sb2));
        assertTrue(sb1.equals((Object) sb2));
        assertFalse(sb1.equals(sb3));
        assertFalse(sb1.equals((StrBuilder) null));
        assertFalse(sb1.equals((Object) "abc"));
        assertEquals(sb1.hashCode(), sb2.hashCode());

        assertTrue(sb1.equalsIgnoreCase(new StrBuilder("ABC")));
        assertFalse(sb1.equalsIgnoreCase(sb3));
        assertTrue(sb1.equalsIgnoreCase(sb1));
    }

    @Test
    void testGetChars() {
        final StrBuilder sb = new StrBuilder("abcdef");
        final char[] all = sb.getChars((char[]) null);
        assertArrayEquals(new char[] {'a', 'b', 'c', 'd', 'e', 'f'}, all);

        final char[] dest = new char[6];
        final char[] result = sb.getChars(dest);
        assertSame(dest, result);

        final char[] small = new char[2];
        final char[] replaced = sb.getChars(small);
        assertEquals(6, replaced.length);

        final char[] partial = new char[3];
        sb.getChars(1, 4, partial, 0);
        assertArrayEquals(new char[] {'b', 'c', 'd'}, partial);

        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.getChars(-1, 2, new char[3], 0));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.getChars(0, 100, new char[3], 0));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.getChars(3, 1, new char[3], 0));
    }

    @Test
    void testIndexOfChar() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(0, sb.indexOf('a'));
        assertEquals(3, sb.indexOf('a', 1));
        assertEquals(-1, sb.indexOf('z'));
        assertEquals(-1, sb.indexOf('a', 100));
        assertEquals(0, sb.indexOf('a', -5));
    }

    @Test
    void testIndexOfString() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(1, sb.indexOf("bc"));
        assertEquals(4, sb.indexOf("bc", 2));
        assertEquals(-1, sb.indexOf((String) null));
        assertEquals(-1, sb.indexOf("zz"));
    }

    @Test
    void testIndexOfMatcher() {
        final StrBuilder sb = new StrBuilder("ab12cd");
        final StrMatcher digitMatcher = StrMatcher.charSetMatcher("0123456789");
        assertEquals(2, sb.indexOf(digitMatcher));
        assertEquals(3, sb.indexOf(digitMatcher, 3));
        assertEquals(-1, sb.indexOf((StrMatcher) null));
    }

    @Test
    void testInsertVariants() {
        StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, true);
        assertEquals("atruec", sb.toString());

        sb = new StrBuilder("ac");
        sb.insert(1, false);
        assertEquals("afalsec", sb.toString());

        sb = new StrBuilder("ac");
        sb.insert(1, 'b');
        assertEquals("abc", sb.toString());

        sb = new StrBuilder("ac");
        sb.insert(1, new char[] {'b', 'b'});
        assertEquals("abbc", sb.toString());

        sb = new StrBuilder("ac");
        sb.insert(1, (char[]) null);
        assertEquals("ac", sb.toString());

        sb = new StrBuilder("ac");
        sb.insert(1, new char[] {'x', 'b', 'y'}, 1, 1);
        assertEquals("abc", sb.toString());

        sb = new StrBuilder("ac");
        sb.insert(1, 5);
        assertEquals("a5c", sb.toString());

        sb = new StrBuilder("ac");
        sb.insert(1, 5L);
        assertEquals("a5c", sb.toString());

        sb = new StrBuilder("ac");
        sb.insert(1, 5.0f);
        assertEquals("a5.0c", sb.toString());

        sb = new StrBuilder("ac");
        sb.insert(1, 5.0d);
        assertEquals("a5.0c", sb.toString());

        sb = new StrBuilder("ac");
        sb.insert(1, (Object) null);
        assertEquals("ac", sb.toString());

        sb = new StrBuilder("ac");
        sb.insert(1, "b");
        assertEquals("abc", sb.toString());

        sb = new StrBuilder("ac");
        sb.insert(1, (String) null);
        assertEquals("ac", sb.toString());

        final StrBuilder invalid = new StrBuilder("ac");
        assertThrows(StringIndexOutOfBoundsException.class, () -> invalid.insert(-1, "x"));
        assertThrows(StringIndexOutOfBoundsException.class, () -> invalid.insert(5, "x"));
    }

    @Test
    void testIsEmptyNotEmptyAfterOps() {
        final StrBuilder sb = new StrBuilder();
        assertTrue(sb.isEmpty());
        sb.append('a');
        assertFalse(sb.isEmpty());
    }

    @Test
    void testLastIndexOfChar() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(3, sb.lastIndexOf('a'));
        assertEquals(0, sb.lastIndexOf('a', 2));
        assertEquals(-1, sb.lastIndexOf('z'));
        assertEquals(-1, sb.lastIndexOf('a', -1));
        assertEquals(3, sb.lastIndexOf('a', 100));
    }

    @Test
    void testLastIndexOfString() {
        final StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(4, sb.lastIndexOf("bc"));
        assertEquals(1, sb.lastIndexOf("bc", 2));
        assertEquals(-1, sb.lastIndexOf((String) null));
    }

    @Test
    void testLastIndexOfMatcher() {
        final StrBuilder sb = new StrBuilder("ab12cd34");
        final StrMatcher digitMatcher = StrMatcher.charSetMatcher("0123456789");
        assertEquals(7, sb.lastIndexOf(digitMatcher));
        assertEquals(3, sb.lastIndexOf(digitMatcher, 3));
        assertEquals(-1, sb.lastIndexOf((StrMatcher) null));
    }

    @Test
    void testLeftRightMidString() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("", sb.leftString(-1));
        assertEquals("abc", sb.leftString(3));
        assertEquals("abcdef", sb.leftString(100));

        assertEquals("", sb.rightString(-1));
        assertEquals("def", sb.rightString(3));
        assertEquals("abcdef", sb.rightString(100));

        assertEquals("", sb.midString(0, -1));
        assertEquals("cde", sb.midString(2, 3));
        assertEquals("abcdef", sb.midString(-5, 100));
        assertEquals("", sb.midString(100, 3));
    }

    @Test
    void testReplaceRange() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.replace(1, 3, "XYZ");
        assertEquals("aXYZdef", sb.toString());

        sb.replace(0, 0, "Q");
        assertEquals("QaXYZdef", sb.toString());

        final StrBuilder sb2 = new StrBuilder("abcdef");
        sb2.replace(1, 3, null);
        assertEquals("adef", sb2.toString());

        assertThrows(StringIndexOutOfBoundsException.class, () -> new StrBuilder("abc").replace(-1, 1, "x"));
    }

    @Test
    void testReplaceAllAndFirstCharAndString() {
        final StrBuilder sb = new StrBuilder("abcabc");
        sb.replaceAll('a', 'z');
        assertEquals("zbczbc", sb.toString());

        final StrBuilder sb2 = new StrBuilder("abcabc");
        sb2.replaceFirst('a', 'z');
        assertEquals("zbcabc", sb2.toString());

        final StrBuilder sb3 = new StrBuilder("abcabc");
        sb3.replaceAll("bc", "X");
        assertEquals("aXaX", sb3.toString());
        sb3.replaceAll((String) null, "y");
        assertEquals("aXaX", sb3.toString());

        final StrBuilder sb4 = new StrBuilder("abcabc");
        sb4.replaceFirst("bc", "X");
        assertEquals("aXabc", sb4.toString());
    }

    @Test
    void testReplaceAllFirstMatcherAndDeleteAllMatcher() {
        final StrMatcher digitMatcher = StrMatcher.charSetMatcher("0123456789");
        final StrBuilder sb = new StrBuilder("a1b2c3");
        sb.replaceAll(digitMatcher, "#");
        assertEquals("a#b#c#", sb.toString());

        final StrBuilder sb2 = new StrBuilder("a1b2c3");
        sb2.replaceFirst(digitMatcher, "#");
        assertEquals("a#b2c3", sb2.toString());

        final StrBuilder sb3 = new StrBuilder("a1b2c3");
        sb3.deleteAll(digitMatcher);
        assertEquals("abc", sb3.toString());

        final StrBuilder sb4 = new StrBuilder("a1b2c3");
        sb4.deleteFirst(digitMatcher);
        assertEquals("ab2c3", sb4.toString());
    }

    @Test
    void testReverse() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.reverse();
        assertEquals("fedcba", sb.toString());

        final StrBuilder empty = new StrBuilder();
        empty.reverse();
        assertEquals("", empty.toString());

        final StrBuilder single = new StrBuilder("x");
        single.reverse();
        assertEquals("x", single.toString());
    }

    @Test
    void testSetLength() {
        final StrBuilder sb = new StrBuilder("abcdef");
        sb.setLength(3);
        assertEquals("abc", sb.toString());

        sb.setLength(5);
        assertEquals(5, sb.length());
        assertEquals('a', sb.charAt(0));
        assertEquals('\u0000', sb.charAt(4));

        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.setLength(-1));
    }

    @Test
    void testSubSequenceAndSubstring() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("bcd", sb.subSequence(1, 4));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.subSequence(-1, 3));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.subSequence(0, 100));
        assertThrows(StringIndexOutOfBoundsException.class, () -> sb.subSequence(3, 1));

        assertEquals("cdef", sb.substring(2));
        assertEquals("cd", sb.substring(2, 4));
        assertEquals("cdef", sb.substring(2, 100));
    }

    @Test
    void testToCharArray() {
        final StrBuilder sb = new StrBuilder("abcdef");
        assertArrayEquals(new char[] {'a', 'b', 'c', 'd', 'e', 'f'}, sb.toCharArray());
        assertArrayEquals(new char[] {'b', 'c'}, sb.toCharArray(1, 3));
        assertArrayEquals(new char[0], sb.toCharArray(1, 1));
        assertArrayEquals(new char[0], new StrBuilder().toCharArray());
    }

    @Test
    void testToStringBufferAndBuilder() {
        final StrBuilder sb = new StrBuilder("abc");
        assertEquals("abc", sb.toStringBuffer().toString());
        assertEquals("abc", sb.toStringBuilder().toString());
        assertEquals("abc", sb.build());
    }

    @Test
    void testTrim() {
        final StrBuilder sb = new StrBuilder("  abc  ");
        sb.trim();
        assertEquals("abc", sb.toString());

        final StrBuilder allSpace = new StrBuilder("   ");
        allSpace.trim();
        assertEquals("", allSpace.toString());

        final StrBuilder empty = new StrBuilder();
        empty.trim();
        assertEquals("", empty.toString());
    }

    @Test
    void testAsReader() throws IOException {
        final StrBuilder sb = new StrBuilder("abc");
        final Reader reader = sb.asReader();
        assertEquals('a', reader.read());
        assertEquals('b', reader.read());
        reader.mark(0);
        assertEquals('c', reader.read());
        assertEquals(-1, reader.read());
        reader.reset();
        assertEquals('c', reader.read());
        reader.close();

        final char[] buf = new char[5];
        final StrBuilder sb2 = new StrBuilder("hello");
        final Reader reader2 = sb2.asReader();
        final int n = reader2.read(buf, 0, 5);
        assertEquals(5, n);
        assertArrayEquals(new char[] {'h', 'e', 'l', 'l', 'o'}, buf);
        assertEquals(-1, reader2.read(buf, 0, 1));
        assertEquals(0, reader2.read(buf, 0, 0));
    }

    @Test
    void testAsWriter() throws IOException {
        final StrBuilder sb = new StrBuilder();
        final Writer writer = sb.asWriter();
        writer.write('a');
        writer.write(new char[] {'b', 'c'});
        writer.write(new char[] {'x', 'd', 'y'}, 1, 1);
        writer.write("ef");
        writer.write("ghij", 1, 2);
        writer.flush();
        writer.close();
        assertEquals("abcdefhi", sb.toString());
    }

    @Test
    void testAsTokenizer() {
        final StrBuilder sb = new StrBuilder("a b c");
        final StrTokenizer tokenizer = sb.asTokenizer();
        assertArrayEquals(new String[] {"a", "b", "c"}, tokenizer.getTokenArray());
    }

    @Test
    void testReadFromReader() throws IOException {
        final StrBuilder sb = new StrBuilder();
        final Reader source = new java.io.StringReader("hello world");
        final int count = sb.readFrom(source);
        assertEquals(11, count);
        assertEquals("hello world", sb.toString());
    }
}
