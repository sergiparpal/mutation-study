/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link CSVParser}.
 */
class CSVParserAgentTest {

    @Test
    void testParseStringSimpleRecords() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b,c\n1,2,3\n", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertArrayEquals(new String[] { "a", "b", "c" }, records.get(0).values());
            assertArrayEquals(new String[] { "1", "2", "3" }, records.get(1).values());
            assertEquals(2, parser.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    void testParseNullStringThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse((String) null, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    void testEmptyInputProducesNoRecords() throws IOException {
        final CSVParser parser = CSVParser.parse("", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertTrue(records.isEmpty());
            assertEquals(0, parser.getRecordNumber());
            final Iterator<CSVRecord> it = parser.iterator();
            assertFalse(it.hasNext());
            assertThrows(NoSuchElementException.class, new org.junit.jupiter.api.function.Executable() {
                @Override
                public void execute() throws Throwable {
                    it.next();
                }
            });
        } finally {
            parser.close();
        }
    }

    @Test
    void testHeaderMapAndNames() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().setSkipHeaderRecord(true).get();
        final CSVParser parser = CSVParser.parse("name,age\nJohn,30\n", format);
        try {
            final Map<String, Integer> headerMap = parser.getHeaderMap();
            assertEquals(2, headerMap.size());
            assertEquals(Integer.valueOf(0), headerMap.get("name"));
            assertEquals(Integer.valueOf(1), headerMap.get("age"));
            assertEquals(java.util.Arrays.asList("name", "age"), parser.getHeaderNames());
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("John", records.get(0).get("name"));
            assertEquals("30", records.get(0).get("age"));
        } finally {
            parser.close();
        }
    }

    @Test
    void testHeaderMapNullWhenNoHeaderDefined() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n", CSVFormat.DEFAULT);
        try {
            assertNull(parser.getHeaderMap());
            assertTrue(parser.getHeaderNames().isEmpty());
        } finally {
            parser.close();
        }
    }

    @Test
    void testDuplicateHeaderNameThrowsIllegalArgumentException() {
        final CSVFormat format = CSVFormat.DEFAULT.builder()
                .setHeader()
                .setSkipHeaderRecord(true)
                .setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW)
                .get();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse("a,a\n1,2\n", format);
            }
        });
    }

    @Test
    void testMissingHeaderNameThrowsIllegalArgumentExceptionByDefault() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().setSkipHeaderRecord(true).get();
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse("a,,c\n1,2,3\n", format);
            }
        });
    }

    @Test
    void testAllowMissingColumnNames() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder()
                .setHeader()
                .setSkipHeaderRecord(true)
                .setAllowMissingColumnNames(true)
                .get();
        final CSVParser parser = CSVParser.parse("a,,c\n1,2,3\n", format);
        try {
            final Map<String, Integer> headerMap = parser.getHeaderMap();
            assertEquals(3, headerMap.size());
            assertEquals(Integer.valueOf(1), headerMap.get(""));
        } finally {
            parser.close();
        }
    }

    @Test
    void testIteratorNextWithoutHasNextThrowsAtEnd() throws IOException {
        final CSVParser parser = CSVParser.parse("1,2\n", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            final CSVRecord record = it.next();
            assertArrayEquals(new String[] { "1", "2" }, record.values());
            assertThrows(NoSuchElementException.class, new org.junit.jupiter.api.function.Executable() {
                @Override
                public void execute() throws Throwable {
                    it.next();
                }
            });
        } finally {
            parser.close();
        }
    }

    @Test
    void testIteratorRemoveThrowsUnsupportedOperationException() throws IOException {
        final CSVParser parser = CSVParser.parse("1,2\n", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            assertThrows(UnsupportedOperationException.class, new org.junit.jupiter.api.function.Executable() {
                @Override
                public void execute() throws Throwable {
                    it.remove();
                }
            });
        } finally {
            parser.close();
        }
    }

    @Test
    void testCloseMakesIteratorEmptyAndNextThrows() throws IOException {
        final CSVParser parser = CSVParser.parse("1,2\n3,4\n", CSVFormat.DEFAULT);
        parser.close();
        assertTrue(parser.isClosed());
        final Iterator<CSVRecord> it = parser.iterator();
        assertFalse(it.hasNext());
        assertThrows(NoSuchElementException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                it.next();
            }
        });
    }

    @Test
    void testNotClosedInitially() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n", CSVFormat.DEFAULT);
        try {
            assertFalse(parser.isClosed());
        } finally {
            parser.close();
        }
    }

    @Test
    void testInvalidParseSequenceThrowsCSVException() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuote('"').get();
        final CSVParser parser;
        try {
            parser = CSVParser.parse("\"unterminated", format);
        } catch (final IOException e) {
            throw new AssertionError(e);
        }
        try {
            assertThrows(CSVException.class, new org.junit.jupiter.api.function.Executable() {
                @Override
                public void execute() throws Throwable {
                    parser.nextRecord();
                }
            });
        } finally {
            try {
                parser.close();
            } catch (final IOException e) {
                // ignore for cleanup
            }
        }
    }

    @Test
    void testNullStringHandling() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        final CSVParser parser = CSVParser.parse("a,NULL,c\n", format);
        try {
            final CSVRecord record = parser.iterator().next();
            assertEquals("a", record.get(0));
            assertNull(record.get(1));
            assertEquals("c", record.get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    void testTrailingDelimiterIgnoresLastEmptyValue() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get();
        final CSVParser parser = CSVParser.parse("a,b,\n", format);
        try {
            final CSVRecord record = parser.iterator().next();
            assertEquals(2, record.size());
            assertArrayEquals(new String[] { "a", "b" }, record.values());
        } finally {
            parser.close();
        }
    }

    @Test
    void testHeaderAndTrailerComments() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder()
                .setCommentMarker('#')
                .setHeader()
                .setSkipHeaderRecord(true)
                .get();
        final CSVParser parser = CSVParser.parse("# header comment\na,b\n1,2\n# trailer comment\n", format);
        try {
            assertTrue(parser.hasHeaderComment());
            assertEquals("header comment", parser.getHeaderComment());
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertTrue(parser.hasTrailerComment());
            assertEquals("trailer comment", parser.getTrailerComment());
        } finally {
            parser.close();
        }
    }

    @Test
    void testNoHeaderCommentByDefault() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n", CSVFormat.DEFAULT);
        try {
            assertFalse(parser.hasHeaderComment());
            assertNull(parser.getHeaderComment());
            assertFalse(parser.hasTrailerComment());
            assertNull(parser.getTrailerComment());
        } finally {
            parser.close();
        }
    }

    @Test
    void testGetCurrentLineNumber() throws IOException {
        final CSVParser parser = CSVParser.parse("a\nb\nc\n", CSVFormat.DEFAULT);
        try {
            assertEquals(0, parser.getCurrentLineNumber());
            parser.nextRecord();
            assertEquals(1, parser.getCurrentLineNumber());
            parser.nextRecord();
            assertEquals(2, parser.getCurrentLineNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    void testStreamCollectsAllRecords() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n2\n3\n", CSVFormat.DEFAULT);
        try {
            final long count = parser.stream().count();
            assertEquals(3, count);
        } finally {
            parser.close();
        }
    }

    @Test
    void testMaxRowsLimitsIterator() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(2).get();
        final CSVParser parser = CSVParser.parse("1\n2\n3\n4\n", format);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
        } finally {
            parser.close();
        }
    }

    @Test
    void testBuilderWithRecordNumberOffset() throws IOException {
        final CSVParser parser = CSVParser.builder()
                .setReader(new StringReader("a\nb\n"))
                .setFormat(CSVFormat.DEFAULT)
                .setRecordNumber(5)
                .get();
        try {
            final CSVRecord record = parser.iterator().next();
            assertEquals(5, record.getRecordNumber());
            assertEquals(5, parser.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    void testDeprecatedConstructorWithReaderAndFormat() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("x,y\n"), CSVFormat.DEFAULT);
        try {
            final CSVRecord record = parser.iterator().next();
            assertArrayEquals(new String[] { "x", "y" }, record.values());
        } finally {
            parser.close();
        }
    }

    @Test
    void testParseFileNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse((java.io.File) null, java.nio.charset.StandardCharsets.UTF_8, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    void testParsePathNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse((java.nio.file.Path) null, java.nio.charset.StandardCharsets.UTF_8, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    void testParseUrlNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                CSVParser.parse((java.net.URL) null, java.nio.charset.StandardCharsets.UTF_8, CSVFormat.DEFAULT);
            }
        });
    }

    @Test
    void testQuotedValueWithEmbeddedDelimiter() throws IOException {
        final CSVParser parser = CSVParser.parse("\"a,b\",c\n", CSVFormat.DEFAULT);
        try {
            final CSVRecord record = parser.iterator().next();
            assertEquals(2, record.size());
            assertEquals("a,b", record.get(0));
            assertEquals("c", record.get(1));
        } finally {
            parser.close();
        }
    }
}
