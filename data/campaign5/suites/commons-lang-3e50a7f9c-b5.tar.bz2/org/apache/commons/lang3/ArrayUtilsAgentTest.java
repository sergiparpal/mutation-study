/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.BitSet;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link ArrayUtils} not already covered by the other
 * dedicated test classes in this package (add/insert/remove/concat/getDimensions/set).
 */
class ArrayUtilsAgentTest {

    // ---------------------------------------------------------------
    // isEmpty / isNotEmpty
    // ---------------------------------------------------------------

    @Test
    void testIsEmptyPrimitiveArrays() {
        assertTrue(ArrayUtils.isEmpty((int[]) null));
        assertTrue(ArrayUtils.isEmpty(new int[0]));
        assertFalse(ArrayUtils.isEmpty(new int[] { 1 }));

        assertTrue(ArrayUtils.isEmpty((Object[]) null));
        assertTrue(ArrayUtils.isEmpty(new Object[0]));
        assertFalse(ArrayUtils.isEmpty(new Object[] { "a" }));
    }

    @Test
    void testIsNotEmpty() {
        assertFalse(ArrayUtils.isNotEmpty((int[]) null));
        assertFalse(ArrayUtils.isNotEmpty(new int[0]));
        assertTrue(ArrayUtils.isNotEmpty(new int[] { 1 }));

        assertFalse(ArrayUtils.isNotEmpty((String[]) null));
        assertTrue(ArrayUtils.isNotEmpty(new String[] { "a" }));
    }

    // ---------------------------------------------------------------
    // contains / containsAny
    // ---------------------------------------------------------------

    @Test
    void testContainsIntArray() {
        final int[] array = { 1, 2, 3 };
        assertTrue(ArrayUtils.contains(array, 2));
        assertFalse(ArrayUtils.contains(array, 4));
        assertFalse(ArrayUtils.contains((int[]) null, 1));
    }

    @Test
    void testContainsObjectArray() {
        final Object[] array = { "a", "b", null };
        assertTrue(ArrayUtils.contains(array, "a"));
        assertTrue(ArrayUtils.contains(array, null));
        assertFalse(ArrayUtils.contains(array, "z"));
        assertFalse(ArrayUtils.contains((Object[]) null, "a"));
    }

    @Test
    void testContainsDoubleWithTolerance() {
        final double[] array = { 1.0, 2.0, 3.0 };
        assertTrue(ArrayUtils.contains(array, 2.05, 0.1));
        assertFalse(ArrayUtils.contains(array, 2.5, 0.1));
    }

    @Test
    void testContainsAnyIntArray() {
        final int[] array = { 1, 2, 3 };
        assertTrue(ArrayUtils.containsAny(array, 9, 2));
        assertFalse(ArrayUtils.containsAny(array, 9, 10));
        assertFalse(ArrayUtils.containsAny((int[]) null, 1));
    }

    @Test
    void testContainsAnyObjectArray() {
        final Object[] array = { "a", "b" };
        assertTrue(ArrayUtils.containsAny(array, "z", "b"));
        assertFalse(ArrayUtils.containsAny(array, "y", "z"));
    }

    // ---------------------------------------------------------------
    // indexOf / lastIndexOf / indexesOf
    // ---------------------------------------------------------------

    @Test
    void testIndexOfIntArray() {
        final int[] array = { 1, 2, 3, 2 };
        assertEquals(1, ArrayUtils.indexOf(array, 2));
        assertEquals(3, ArrayUtils.indexOf(array, 2, 2));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf(array, 9));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf((int[]) null, 1));
        // negative startIndex is clamped to 0
        assertEquals(1, ArrayUtils.indexOf(array, 2, -5));
        // startIndex beyond length yields not found
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf(array, 2, 10));
    }

    @Test
    void testLastIndexOfIntArray() {
        final int[] array = { 1, 2, 3, 2 };
        assertEquals(3, ArrayUtils.lastIndexOf(array, 2));
        assertEquals(1, ArrayUtils.lastIndexOf(array, 2, 2));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.lastIndexOf(array, 9));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.lastIndexOf((int[]) null, 1));
        // startIndex beyond length is clamped to length - 1
        assertEquals(3, ArrayUtils.lastIndexOf(array, 2, 100));
        // negative startIndex yields not found
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.lastIndexOf(array, 2, -1));
    }

    @Test
    void testIndexOfObjectArray() {
        final Object[] array = { "a", null, "b", null };
        assertEquals(1, ArrayUtils.indexOf(array, null));
        assertEquals(0, ArrayUtils.indexOf(array, "a"));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf(array, "z"));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf((Object[]) null, "a"));
    }

    @Test
    void testLastIndexOfObjectArray() {
        final Object[] array = { "a", null, "b", null };
        assertEquals(3, ArrayUtils.lastIndexOf(array, null));
        assertEquals(2, ArrayUtils.lastIndexOf(array, "b"));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.lastIndexOf(array, "z"));
    }

    @Test
    void testIndexesOfIntArray() {
        final int[] array = { 1, 2, 1, 3, 1 };
        final BitSet indexes = ArrayUtils.indexesOf(array, 1);
        assertEquals(3, indexes.cardinality());
        assertTrue(indexes.get(0));
        assertTrue(indexes.get(2));
        assertTrue(indexes.get(4));
        assertFalse(indexes.get(1));

        final BitSet none = ArrayUtils.indexesOf(array, 9);
        assertTrue(none.isEmpty());

        final BitSet fromIndex = ArrayUtils.indexesOf(array, 1, 1);
        assertEquals(2, fromIndex.cardinality());
        assertFalse(fromIndex.get(0));
    }

    // ---------------------------------------------------------------
    // isSameLength / isSameType / isSorted
    // ---------------------------------------------------------------

    @Test
    void testIsSameLength() {
        assertTrue(ArrayUtils.isSameLength(new int[] { 1, 2 }, new int[] { 3, 4 }));
        assertFalse(ArrayUtils.isSameLength(new int[] { 1, 2 }, new int[] { 3 }));
        assertTrue(ArrayUtils.isSameLength((int[]) null, (int[]) null));
        assertFalse(ArrayUtils.isSameLength(null, new int[] { 1 }));

        assertTrue(ArrayUtils.isSameLength(new Object[] { "a" }, new Object[] { "b" }));
        assertFalse(ArrayUtils.isSameLength(new Object[] { "a" }, new Object[] { "b", "c" }));
    }

    @Test
    void testIsSameType() {
        assertTrue(ArrayUtils.isSameType(new int[0], new int[0]));
        assertFalse(ArrayUtils.isSameType(new int[0], new long[0]));
        assertFalse(ArrayUtils.isSameType(new Object[0], new String[0]));
    }

    @Test
    void testIsSameTypeNullThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ArrayUtils.isSameType(null, new int[0]);
            }
        });
    }

    @Test
    void testIsSortedIntArray() {
        assertTrue(ArrayUtils.isSorted(new int[] { 1, 2, 3 }));
        assertTrue(ArrayUtils.isSorted(new int[0]));
        assertTrue(ArrayUtils.isSorted((int[]) null));
        assertFalse(ArrayUtils.isSorted(new int[] { 3, 2, 1 }));
    }

    @Test
    void testIsSortedComparableArray() {
        assertTrue(ArrayUtils.isSorted(new String[] { "a", "b", "c" }));
        assertFalse(ArrayUtils.isSorted(new String[] { "c", "a" }));
    }

    // ---------------------------------------------------------------
    // get / getComponentType / getLength / hashCode / isEquals
    // ---------------------------------------------------------------

    @Test
    void testGet() {
        final String[] array = { "a", "b" };
        assertEquals("a", ArrayUtils.get(array, 0));
        assertNull(ArrayUtils.get(array, 5));
        assertEquals("default", ArrayUtils.get(array, 5, "default"));
        assertEquals("b", ArrayUtils.get(array, 1, "default"));
    }

    @Test
    void testGetComponentType() {
        assertEquals(String.class, ArrayUtils.getComponentType(new String[0]));
        assertNull(ArrayUtils.getComponentType((String[]) null));
    }

    @Test
    void testGetLength() {
        assertEquals(0, ArrayUtils.getLength(null));
        assertEquals(3, ArrayUtils.getLength(new int[] { 1, 2, 3 }));
        assertEquals(1, ArrayUtils.getLength(new Object[] { null }));
    }

    @Test
    void testGetLengthNonArrayThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ArrayUtils.getLength("not an array");
            }
        });
    }

    @Test
    void testHashCode() {
        // null hashCode is deterministic and distinct from a non-empty array's hashCode
        assertEquals(ArrayUtils.hashCode(null), ArrayUtils.hashCode(null));
        final int[] array = { 1, 2, 3 };
        assertEquals(ArrayUtils.hashCode(array), ArrayUtils.hashCode(array.clone()));
        assertFalse(ArrayUtils.hashCode(array) == ArrayUtils.hashCode(null));
        assertFalse(ArrayUtils.hashCode(array) == ArrayUtils.hashCode(new int[] { 3, 2, 1 }));
    }

    @Test
    void testIsEquals() {
        assertTrue(ArrayUtils.isEquals(new int[] { 1, 2 }, new int[] { 1, 2 }));
        assertFalse(ArrayUtils.isEquals(new int[] { 1, 2 }, new int[] { 1, 3 }));
        assertTrue(ArrayUtils.isEquals(null, null));
        assertFalse(ArrayUtils.isEquals(null, new int[] { 1 }));
    }

    @Test
    void testIsArrayIndexValid() {
        final String[] array = { "a" };
        assertFalse(ArrayUtils.isArrayIndexValid(new String[0], 0));
        assertTrue(ArrayUtils.isArrayIndexValid(array, 0));
        assertFalse(ArrayUtils.isArrayIndexValid(array, 1));
        assertFalse(ArrayUtils.isArrayIndexValid(array, -1));
        assertFalse(ArrayUtils.isArrayIndexValid((String[]) null, 0));
    }

    // ---------------------------------------------------------------
    // clone
    // ---------------------------------------------------------------

    @Test
    void testCloneIntArray() {
        final int[] array = { 1, 2, 3 };
        final int[] cloned = ArrayUtils.clone(array);
        assertArrayEquals(array, cloned);
        assertNotSame(array, cloned);
        assertNull(ArrayUtils.clone((int[]) null));
    }

    @Test
    void testCloneObjectArray() {
        final String[] array = { "a", "b" };
        final String[] cloned = ArrayUtils.clone(array);
        assertArrayEquals(array, cloned);
        assertNotSame(array, cloned);
        assertNull(ArrayUtils.clone((Object[]) null));
    }

    // ---------------------------------------------------------------
    // nullToEmpty
    // ---------------------------------------------------------------

    @Test
    void testNullToEmptyIntArray() {
        assertSame(ArrayUtils.EMPTY_INT_ARRAY, ArrayUtils.nullToEmpty((int[]) null));
        final int[] array = { 1, 2 };
        assertSame(array, ArrayUtils.nullToEmpty(array));
    }

    @Test
    void testNullToEmptyObjectArray() {
        assertSame(ArrayUtils.EMPTY_OBJECT_ARRAY, ArrayUtils.nullToEmpty((Object[]) null));
        final Object[] array = { "a" };
        assertSame(array, ArrayUtils.nullToEmpty(array));
    }

    @Test
    void testNullToEmptyStringArray() {
        assertSame(ArrayUtils.EMPTY_STRING_ARRAY, ArrayUtils.nullToEmpty((String[]) null));
        final String[] array = { "a" };
        assertSame(array, ArrayUtils.nullToEmpty(array));
    }

    // ---------------------------------------------------------------
    // removeElement / removeAllOccurrences / removeElements
    // ---------------------------------------------------------------

    @Test
    void testRemoveElementIntArray() {
        final int[] array = { 1, 2, 3, 2 };
        assertArrayEquals(new int[] { 1, 3, 2 }, ArrayUtils.removeElement(array, 2));
        assertArrayEquals(array, ArrayUtils.removeElement(array, 9));
        assertNull(ArrayUtils.removeElement((int[]) null, 1));
    }

    @Test
    void testRemoveAllOccurrencesIntArray() {
        final int[] array = { 1, 2, 3, 2, 2 };
        assertArrayEquals(new int[] { 1, 3 }, ArrayUtils.removeAllOccurrences(array, 2));
        assertArrayEquals(array, ArrayUtils.removeAllOccurrences(array, 9));
    }

    @Test
    void testRemoveElementsIntArray() {
        final int[] array = { 1, 2, 3, 2, 4 };
        assertArrayEquals(new int[] { 1, 3, 4 }, ArrayUtils.removeElements(array, 2, 2));
        // only one occurrence removed when only one requested
        assertArrayEquals(new int[] { 1, 3, 2, 4 }, ArrayUtils.removeElements(array, 2));
        assertArrayEquals(array, ArrayUtils.removeElements(array));
    }

    // ---------------------------------------------------------------
    // reverse
    // ---------------------------------------------------------------

    @Test
    void testReverseIntArray() {
        final int[] array = { 1, 2, 3, 4 };
        ArrayUtils.reverse(array);
        assertArrayEquals(new int[] { 4, 3, 2, 1 }, array);

        // null is a no-op, must not throw
        ArrayUtils.reverse((int[]) null);
    }

    @Test
    void testReverseIntArrayRange() {
        final int[] array = { 1, 2, 3, 4, 5 };
        ArrayUtils.reverse(array, 1, 4);
        assertArrayEquals(new int[] { 1, 4, 3, 2, 5 }, array);

        // out of range start/end are clamped and this must not throw
        final int[] array2 = { 1, 2, 3 };
        ArrayUtils.reverse(array2, -5, 100);
        assertArrayEquals(new int[] { 3, 2, 1 }, array2);
    }

    @Test
    void testReverseObjectArray() {
        final String[] array = { "a", "b", "c" };
        ArrayUtils.reverse(array);
        assertArrayEquals(new String[] { "c", "b", "a" }, array);
    }

    // ---------------------------------------------------------------
    // shift
    // ---------------------------------------------------------------

    @Test
    void testShiftIntArray() {
        final int[] array = { 1, 2, 3, 4, 5 };
        ArrayUtils.shift(array, 2);
        assertArrayEquals(new int[] { 4, 5, 1, 2, 3 }, array);

        // null is a no-op, must not throw
        ArrayUtils.shift((int[]) null, 1);
    }

    @Test
    void testShiftIntArrayNegativeOffset() {
        final int[] array = { 1, 2, 3, 4, 5 };
        ArrayUtils.shift(array, -2);
        assertArrayEquals(new int[] { 3, 4, 5, 1, 2 }, array);
    }

    @Test
    void testShiftIntArrayOffsetLargerThanLength() {
        final int[] array = { 1, 2, 3 };
        // offset of 4 on 3 elements is equivalent to offset of 1
        ArrayUtils.shift(array, 4);
        assertArrayEquals(new int[] { 3, 1, 2 }, array);
    }

    // ---------------------------------------------------------------
    // swap
    // ---------------------------------------------------------------

    @Test
    void testSwapIntArray() {
        final int[] array = { 1, 2, 3 };
        ArrayUtils.swap(array, 0, 2);
        assertArrayEquals(new int[] { 3, 2, 1 }, array);

        // null is a no-op, must not throw
        ArrayUtils.swap((int[]) null, 0, 1);
    }

    @Test
    void testSwapIntArrayWithLength() {
        final int[] array = { 1, 2, 3, 4, 5, 6 };
        ArrayUtils.swap(array, 0, 3, 2);
        assertArrayEquals(new int[] { 4, 5, 3, 1, 2, 6 }, array);
    }

    @Test
    void testSwapIntArrayOutOfBoundsClamped() {
        final int[] array = { 1, 2, 3 };
        // overlength swap offsets are clamped so this must not throw
        ArrayUtils.swap(array, 0, 1, 10);
        assertArrayEquals(new int[] { 2, 3, 1 }, array);
    }

    // ---------------------------------------------------------------
    // subarray
    // ---------------------------------------------------------------

    @Test
    void testSubarrayIntArray() {
        final int[] array = { 1, 2, 3, 4, 5 };
        assertArrayEquals(new int[] { 2, 3 }, ArrayUtils.subarray(array, 1, 3));
        assertArrayEquals(ArrayUtils.EMPTY_INT_ARRAY, ArrayUtils.subarray(array, 3, 1));
        assertNull(ArrayUtils.subarray((int[]) null, 0, 1));
        // excess end index clamped to length
        assertArrayEquals(new int[] { 4, 5 }, ArrayUtils.subarray(array, 3, 100));
        // negative start clamped to 0
        assertArrayEquals(new int[] { 1, 2 }, ArrayUtils.subarray(array, -5, 2));
    }

    @Test
    void testSubarrayObjectArray() {
        final String[] array = { "a", "b", "c" };
        final String[] sub = ArrayUtils.subarray(array, 0, 2);
        assertArrayEquals(new String[] { "a", "b" }, sub);
        assertEquals(String.class, sub.getClass().getComponentType());
    }

    // ---------------------------------------------------------------
    // startsWith
    // ---------------------------------------------------------------

    @Test
    void testStartsWith() {
        final byte[] data = { 1, 2, 3, 4 };
        assertTrue(ArrayUtils.startsWith(data, new byte[] { 1, 2 }));
        assertFalse(ArrayUtils.startsWith(data, new byte[] { 2, 3 }));
        assertTrue(ArrayUtils.startsWith(data, data));
        assertTrue(ArrayUtils.startsWith(null, null));
        assertFalse(ArrayUtils.startsWith(data, null));
        assertFalse(ArrayUtils.startsWith(null, data));
        // expected longer than data
        assertFalse(ArrayUtils.startsWith(new byte[] { 1 }, data));
        assertTrue(ArrayUtils.startsWith(data, ArrayUtils.EMPTY_BYTE_ARRAY));
    }

    // ---------------------------------------------------------------
    // toArray / toMap
    // ---------------------------------------------------------------

    @Test
    void testToArray() {
        final String[] array = ArrayUtils.toArray("a", "b", "c");
        assertArrayEquals(new String[] { "a", "b", "c" }, array);
    }

    @Test
    void testToMap() {
        final Map<Object, Object> map = ArrayUtils.toMap(new String[][] { { "k1", "v1" }, { "k2", "v2" } });
        assertEquals(2, map.size());
        assertEquals("v1", map.get("k1"));
        assertEquals("v2", map.get("k2"));
        assertNull(ArrayUtils.toMap(null));
    }

    @Test
    void testToMapEntryTooShortThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ArrayUtils.toMap(new Object[] { new String[] { "onlyOne" } });
            }
        });
    }

    @Test
    void testToMapInvalidElementThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ArrayUtils.toMap(new Object[] { "not a pair" });
            }
        });
    }

    // ---------------------------------------------------------------
    // toObject / toPrimitive
    // ---------------------------------------------------------------

    @Test
    void testToObjectIntArray() {
        final Integer[] boxed = ArrayUtils.toObject(new int[] { 1, 2, 3 });
        assertArrayEquals(new Integer[] { 1, 2, 3 }, boxed);
        assertNull(ArrayUtils.toObject((int[]) null));
        assertArrayEquals(new Integer[0], ArrayUtils.toObject(new int[0]));
    }

    @Test
    void testToPrimitiveIntArray() {
        final int[] primitives = ArrayUtils.toPrimitive(new Integer[] { 1, 2, 3 });
        assertArrayEquals(new int[] { 1, 2, 3 }, primitives);
        assertNull(ArrayUtils.toPrimitive((Integer[]) null));
    }

    @Test
    void testToPrimitiveIntArrayNullElementThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ArrayUtils.toPrimitive(new Integer[] { 1, null });
            }
        });
    }

    @Test
    void testToPrimitiveIntArrayWithDefaultForNull() {
        final int[] primitives = ArrayUtils.toPrimitive(new Integer[] { 1, null, 3 }, -1);
        assertArrayEquals(new int[] { 1, -1, 3 }, primitives);
    }

    // ---------------------------------------------------------------
    // toString / toStringArray
    // ---------------------------------------------------------------

    @Test
    void testToString() {
        assertEquals("{}", ArrayUtils.toString(null));
        assertEquals("<empty>", ArrayUtils.toString(null, "<empty>"));
        assertEquals("{1,2,3}", ArrayUtils.toString(new int[] { 1, 2, 3 }));
    }

    @Test
    void testToStringArray() {
        final String[] result = ArrayUtils.toStringArray(new Object[] { "a", 1, null });
        assertArrayEquals(new String[] { "a", "1", "null" }, result);
        assertNull(ArrayUtils.toStringArray(null));
    }

    @Test
    void testToStringArrayWithValueForNull() {
        final String[] result = ArrayUtils.toStringArray(new Object[] { "a", null }, "N/A");
        assertArrayEquals(new String[] { "a", "N/A" }, result);
    }

    // ---------------------------------------------------------------
    // newInstance / arraycopy
    // ---------------------------------------------------------------

    @Test
    void testNewInstance() {
        final String[] array = ArrayUtils.newInstance(String.class, 3);
        assertEquals(3, array.length);
        assertEquals(String.class, array.getClass().getComponentType());
    }

    @Test
    void testArraycopy() {
        final int[] source = { 1, 2, 3, 4, 5 };
        final int[] dest = new int[5];
        final int[] result = ArrayUtils.arraycopy(source, 1, dest, 0, 3);
        assertSame(dest, result);
        assertArrayEquals(new int[] { 2, 3, 4, 0, 0 }, result);
    }

    @Test
    void testArraycopyOutOfBoundsThrows() {
        final int[] source = { 1, 2, 3 };
        final int[] dest = new int[3];
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ArrayUtils.arraycopy(source, 0, dest, 0, 10);
            }
        });
    }

}
