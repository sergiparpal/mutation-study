/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.apache.commons.csv.Constants.UNDEFINED;
import static org.apache.commons.io.IOUtils.EOF;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.StandardCharsets;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link ExtendedBufferedReader}.
 */
class ExtendedBufferedReaderAgentTest {

    private ExtendedBufferedReader create(final String s) {
        return new ExtendedBufferedReader(new StringReader(s));
    }

    private ExtendedBufferedReader createTrackingBytes(final String s) {
        return new ExtendedBufferedReader(new StringReader(s), StandardCharsets.UTF_8, true);
    }

    @Test
    void testInitialState() throws IOException {
        final ExtendedBufferedReader br = create("abc");
        assertEquals(UNDEFINED, br.getLastChar());
        assertEquals(0, br.getLineNumber());
        assertEquals(0, br.getPosition());
        assertEquals(0, br.getBytesRead());
        br.close();
    }

    @Test
    void testReadAdvancesPositionAndLastChar() throws IOException {
        final ExtendedBufferedReader br = create("AB");
        assertEquals('A', br.read());
        assertEquals('A', br.getLastChar());
        assertEquals(1, br.getPosition());
        assertEquals('B', br.read());
        assertEquals('B', br.getLastChar());
        assertEquals(2, br.getPosition());
        assertEquals(EOF, br.read());
        assertEquals(EOF, br.getLastChar());
        br.close();
    }

    @Test
    void testPeekDoesNotAdvanceButReadDoes() throws IOException {
        final ExtendedBufferedReader br = create("XY");
        assertEquals('X', br.peek());
        assertEquals('X', br.peek());
        assertEquals(UNDEFINED, br.getLastChar());
        assertEquals(0, br.getPosition());
        assertEquals('X', br.read());
        assertEquals('X', br.getLastChar());
        assertEquals(1, br.getPosition());
        br.close();
    }

    @Test
    void testPeekAtEndOfStream() throws IOException {
        final ExtendedBufferedReader br = create("");
        assertEquals(EOF, br.peek());
        assertEquals(UNDEFINED, br.getLastChar());
        assertEquals(EOF, br.read());
        assertEquals(EOF, br.getLastChar());
        br.close();
    }

    @Test
    void testReadBufferZeroLengthReturnsZeroWithoutConsuming() throws IOException {
        final ExtendedBufferedReader br = create("abc");
        final char[] buf = new char[5];
        assertEquals(0, br.read(buf, 0, 0));
        assertEquals(UNDEFINED, br.getLastChar());
        assertEquals(0, br.getPosition());
        assertEquals('a', br.peek());
        br.close();
    }

    @Test
    void testReadBufferAtEndOfStreamReturnsEofAndSetsLastChar() throws IOException {
        final ExtendedBufferedReader br = create("");
        final char[] buf = new char[5];
        assertEquals(EOF, br.read(buf, 0, 5));
        assertEquals(EOF, br.getLastChar());
        br.close();
    }

    @Test
    void testReadBufferFillsArrayAndUpdatesLastChar() throws IOException {
        final ExtendedBufferedReader br = create("abcdef");
        final char[] buf = new char[6];
        final int n = br.read(buf, 0, 6);
        assertEquals(6, n);
        assertEquals('f', br.getLastChar());
        assertEquals(6, br.getPosition());
        assertEquals('a', buf[0]);
        assertEquals('f', buf[5]);
        br.close();
    }

    @Test
    void testReadLineAtEndOfStreamReturnsNull() throws IOException {
        final ExtendedBufferedReader br = create("");
        assertNull(br.readLine());
        br.close();
    }

    @Test
    void testReadLineSingleBlankLine() throws IOException {
        final ExtendedBufferedReader br = create("\n");
        assertEquals("", br.readLine());
        assertEquals(1, br.getLineNumber());
        assertNull(br.readLine());
        br.close();
    }

    @Test
    void testReadLineNoTrailingTerminator() throws IOException {
        final ExtendedBufferedReader br = create("lastline");
        assertEquals("lastline", br.readLine());
        assertNull(br.readLine());
        br.close();
    }

    @Test
    void testGetLineNumberMidLineVsAtEol() throws IOException {
        final ExtendedBufferedReader br = create("ab\ncd");
        assertEquals(0, br.getLineNumber());
        br.read(); // 'a', mid line
        assertEquals(1, br.getLineNumber());
        br.read(); // 'b', mid line
        assertEquals(1, br.getLineNumber());
        br.read(); // '\n', at EOL
        assertEquals(1, br.getLineNumber());
        br.read(); // 'c', mid next line
        assertEquals(2, br.getLineNumber());
        br.close();
    }

    @Test
    void testCrLfCountsAsSingleLineBreak() throws IOException {
        final ExtendedBufferedReader br = create("a\r\nb");
        br.read(); // 'a'
        br.read(); // '\r'
        assertEquals(1, br.getLineNumber());
        br.read(); // '\n'
        assertEquals(1, br.getLineNumber());
        br.read(); // 'b'
        assertEquals(2, br.getLineNumber());
        br.close();
    }

    @Test
    void testConsecutiveCrEachCountAsLineBreak() throws IOException {
        final ExtendedBufferedReader br = create("\r\r");
        assertEquals('\r', br.read());
        assertEquals(1, br.getLineNumber());
        assertEquals('\r', br.read());
        assertEquals(2, br.getLineNumber());
        assertEquals(EOF, br.read());
        assertEquals(2, br.getLineNumber());
        br.close();
    }

    @Test
    void testMarkAndResetRestoreState() throws IOException {
        final ExtendedBufferedReader br = create("abc\ndef");
        br.read(); // 'a'
        br.mark(10);
        final long markedPosition = br.getPosition();
        final long markedLineNumber = br.getLineNumber();
        final int markedLastChar = br.getLastChar();
        br.read();
        br.read();
        br.read();
        assertTrue(br.getPosition() > markedPosition);
        br.reset();
        assertEquals(markedPosition, br.getPosition());
        assertEquals(markedLineNumber, br.getLineNumber());
        assertEquals(markedLastChar, br.getLastChar());
        assertEquals('b', br.read());
        br.close();
    }

    @Test
    void testCloseSetsLastCharToEofAndPreventsFurtherReads() throws IOException {
        final ExtendedBufferedReader br = create("abc");
        br.close();
        assertEquals(EOF, br.getLastChar());
        assertThrows(IOException.class, br::read);
    }

    @Test
    void testBytesReadZeroWhenTrackingDisabled() throws IOException {
        final ExtendedBufferedReader br = create("hello");
        br.read();
        br.read();
        assertEquals(0, br.getBytesRead());
        br.close();
    }

    @Test
    void testBytesReadZeroWhenCharsetNullEvenIfTrackRequested() throws IOException {
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("hello"), null, true);
        br.read();
        br.read();
        assertEquals(0, br.getBytesRead());
        br.close();
    }

    @Test
    void testBytesReadAsciiOneBytePerChar() throws IOException {
        final ExtendedBufferedReader br = createTrackingBytes("AB");
        br.read();
        assertEquals(1, br.getBytesRead());
        br.read();
        assertEquals(2, br.getBytesRead());
        br.close();
    }

    @Test
    void testBytesReadSupplementaryCharacterSurrogatePair() throws IOException {
        // U+1F600 GRINNING FACE, encodes to 4 bytes in UTF-8, represented as a surrogate pair of chars.
        final String emoji = "😀";
        final ExtendedBufferedReader br = createTrackingBytes(emoji);
        br.read(); // high surrogate: deferred, contributes 0 bytes on its own
        assertEquals(0, br.getBytesRead());
        br.read(); // low surrogate: completes the pair
        assertEquals(4, br.getBytesRead());
        assertEquals(EOF, br.read());
        br.close();
    }

    @Test
    void testUnpairedLowSurrogateThrowsCharacterCodingException() {
        final ExtendedBufferedReader br = createTrackingBytes("\uDE00");
        assertThrows(CharacterCodingException.class, br::read);
    }

    @Test
    void testMarkAndResetRestoreBytesRead() throws IOException {
        final ExtendedBufferedReader br = createTrackingBytes("ABC");
        br.read();
        br.mark(10);
        final long markedBytes = br.getBytesRead();
        br.read();
        br.read();
        assertTrue(br.getBytesRead() > markedBytes);
        br.reset();
        assertEquals(markedBytes, br.getBytesRead());
        br.close();
    }

    @Test
    void testReadFromDifferentOffsetsAccumulatesLineNumber() throws IOException {
        final char[] tmp1 = new char[2];
        final char[] tmp2 = new char[4];
        final ExtendedBufferedReader br = create("1\r\n2\r\n");
        br.read(tmp1, 0, 2);
        br.read(tmp2, 2, 2);
        assertEquals(2, br.getLineNumber());
        br.close();
    }

    @Test
    void testIsClosedFalseInitiallyAndAfterClose() throws IOException {
        final ExtendedBufferedReader br = create("abc");
        assertFalse(br.isClosed());
        br.close();
        assertTrue(br.isClosed());
    }
}
