/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests {@link Conversion}.
 */
class ConversionAgentTest {

    @Test
    void testBinaryBeMsb0ToHexDigit() {
        assertEquals('8', Conversion.binaryBeMsb0ToHexDigit(new boolean[] { true, false, false, false }));
        assertEquals('8', Conversion.binaryBeMsb0ToHexDigit(new boolean[] { true, false, false, false }, 0));
        final boolean[] big = { true, false, false, false, false, false, false, false, false, false, false, true, false, true, false, false };
        assertEquals('5', Conversion.binaryBeMsb0ToHexDigit(big, 2));
    }

    @Test
    void testBinaryBeMsb0ToHexDigit_errors() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.binaryBeMsb0ToHexDigit(new boolean[0]);
            }
        });
        assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.binaryBeMsb0ToHexDigit(new boolean[] { true, false, false, false }, 4);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.binaryBeMsb0ToHexDigit(null);
            }
        });
    }

    @Test
    void testBinaryToByte() {
        assertEquals((byte) 13, Conversion.binaryToByte(new boolean[] { true, false, true, true }, 0, (byte) 0, 0, 4));
        assertEquals((byte) 0xFE, Conversion.binaryToByte(new boolean[] { false, true }, 0, (byte) 0xFF, 0, 2));
        assertEquals((byte) 8, Conversion.binaryToByte(new boolean[] { true }, 0, (byte) 0, 3, 1));
        assertEquals((byte) 5, Conversion.binaryToByte(new boolean[0], 0, (byte) 5, 0, 0));
    }

    @Test
    void testBinaryToByte_errors() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.binaryToByte(new boolean[] { true, true }, 0, (byte) 0, 7, 2);
            }
        });
        assertThrows(ArrayIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.binaryToByte(new boolean[] { true }, 0, (byte) 0, 0, 2);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.binaryToByte(null, 0, (byte) 0, 0, 1);
            }
        });
    }

    @Test
    void testBinaryToHexDigit() {
        assertEquals('1', Conversion.binaryToHexDigit(new boolean[] { true, false, false, false }));
        assertEquals('1', Conversion.binaryToHexDigit(new boolean[] { false, true, false, false, false }, 1));
    }

    @Test
    void testBinaryToHexDigit_empty() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.binaryToHexDigit(new boolean[0]);
            }
        });
    }

    @Test
    void testBinaryToHexDigitMsb0_4bits() {
        assertEquals('8', Conversion.binaryToHexDigitMsb0_4bits(new boolean[] { true, false, false, false }));
        final boolean[] src = { true, false, false, true, true, false, true, false };
        assertEquals('d', Conversion.binaryToHexDigitMsb0_4bits(src, 3));
    }

    @Test
    void testBinaryToHexDigitMsb0_4bits_errors() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.binaryToHexDigitMsb0_4bits(new boolean[9]);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.binaryToHexDigitMsb0_4bits(new boolean[3], 0);
            }
        });
    }

    @Test
    void testBinaryToInt() {
        assertEquals(21, Conversion.binaryToInt(new boolean[] { true, false, true, false, true }, 0, 0, 0, 5));
    }

    @Test
    void testBinaryToInt_boundary() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.binaryToInt(new boolean[32], 0, 0, 1, 32);
            }
        });
    }

    @Test
    void testBinaryToLong() {
        assertEquals(21L, Conversion.binaryToLong(new boolean[] { true, false, true, false, true }, 0, 0L, 0, 5));
    }

    @Test
    void testBinaryToLong_boundary() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.binaryToLong(new boolean[64], 0, 0L, 1, 64);
            }
        });
    }

    @Test
    void testBinaryToShort() {
        assertEquals((short) 21, Conversion.binaryToShort(new boolean[] { true, false, true, false, true }, 0, (short) 0, 0, 5));
    }

    @Test
    void testBinaryToShort_boundary() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.binaryToShort(new boolean[16], 0, (short) 0, 1, 16);
            }
        });
    }

    @Test
    void testByteArrayToInt() {
        assertEquals(0x0201, Conversion.byteArrayToInt(new byte[] { 0x01, 0x02 }, 0, 0, 0, 2));
    }

    @Test
    void testByteArrayToInt_errors() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.byteArrayToInt(new byte[5], 0, 0, 0, 5);
            }
        });
        assertThrows(ArrayIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.byteArrayToInt(new byte[] { 1 }, 0, 0, 0, 2);
            }
        });
    }

    @Test
    void testByteArrayToLong() {
        assertEquals(0x0201L, Conversion.byteArrayToLong(new byte[] { 0x01, 0x02 }, 0, 0L, 0, 2));
    }

    @Test
    void testByteArrayToLong_boundary() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.byteArrayToLong(new byte[9], 0, 0L, 0, 9);
            }
        });
    }

    @Test
    void testByteArrayToShort() {
        assertEquals((short) 0x0201, Conversion.byteArrayToShort(new byte[] { 0x01, 0x02 }, 0, (short) 0, 0, 2));
    }

    @Test
    void testByteArrayToShort_boundary() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.byteArrayToShort(new byte[3], 0, (short) 0, 0, 3);
            }
        });
    }

    @Test
    void testByteArrayToUuid_roundTrip() {
        final UUID uuid = new UUID(0x1122334455667788L, 0x99AABBCCDDEEFF00L);
        final byte[] arr = Conversion.uuidToByteArray(uuid, new byte[16], 0, 16);
        final UUID result = Conversion.byteArrayToUuid(arr, 0);
        assertEquals(uuid, result);
    }

    @Test
    void testByteArrayToUuid_withOffset() {
        final UUID uuid = UUID.randomUUID();
        final byte[] arr = new byte[20];
        Conversion.uuidToByteArray(uuid, arr, 4, 16);
        assertEquals(uuid, Conversion.byteArrayToUuid(arr, 4));
    }

    @Test
    void testByteArrayToUuid_tooShort() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.byteArrayToUuid(new byte[15], 0);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.byteArrayToUuid(new byte[20], 10);
            }
        });
    }

    @Test
    void testByteToBinary() {
        final boolean[] dst = new boolean[8];
        final boolean[] result = Conversion.byteToBinary((byte) 5, 0, dst, 0, 8);
        assertSame(dst, result);
        assertArrayEquals(new boolean[] { true, false, true, false, false, false, false, false }, result);
    }

    @Test
    void testByteToBinary_noOp() {
        final boolean[] dst = new boolean[3];
        assertSame(dst, Conversion.byteToBinary((byte) 1, 0, dst, 0, 0));
    }

    @Test
    void testByteToBinary_boundary() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.byteToBinary((byte) 0, 1, new boolean[8], 0, 8);
            }
        });
    }

    @Test
    void testByteToHex() {
        assertEquals("ba", Conversion.byteToHex((byte) 0xAB, 0, "", 0, 2));
        assertEquals("fY", Conversion.byteToHex((byte) 0x0F, 0, "XY", 0, 1));
    }

    @Test
    void testByteToHex_boundary() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.byteToHex((byte) 0, 0, "", 0, 3);
            }
        });
        assertThrows(StringIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.byteToHex((byte) 0, 0, "", 5, 1);
            }
        });
    }

    @Test
    void testHexDigitMsb0ToBinary() {
        assertArrayEquals(new boolean[] { false, false, false, true }, Conversion.hexDigitMsb0ToBinary('1'));
        assertArrayEquals(new boolean[] { true, true, true, true }, Conversion.hexDigitMsb0ToBinary('f'));
        assertArrayEquals(new boolean[] { true, true, true, true }, Conversion.hexDigitMsb0ToBinary('F'));
    }

    @Test
    void testHexDigitMsb0ToBinary_invalid() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.hexDigitMsb0ToBinary('g');
            }
        });
    }

    @Test
    void testHexDigitMsb0ToInt() {
        assertEquals(0x8, Conversion.hexDigitMsb0ToInt('1'));
        assertEquals(0x0, Conversion.hexDigitMsb0ToInt('0'));
        assertEquals(0xF, Conversion.hexDigitMsb0ToInt('f'));
    }

    @Test
    void testHexDigitMsb0ToInt_invalid() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.hexDigitMsb0ToInt('z');
            }
        });
    }

    @Test
    void testHexDigitToBinary() {
        assertArrayEquals(new boolean[] { true, false, false, false }, Conversion.hexDigitToBinary('1'));
        assertArrayEquals(new boolean[] { true, true, true, true }, Conversion.hexDigitToBinary('f'));
        assertArrayEquals(new boolean[] { true, true, true, true }, Conversion.hexDigitToBinary('F'));
    }

    @Test
    void testHexDigitToBinary_invalid() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.hexDigitToBinary('x');
            }
        });
    }

    @Test
    void testHexDigitToInt() {
        assertEquals(0, Conversion.hexDigitToInt('0'));
        assertEquals(10, Conversion.hexDigitToInt('a'));
        assertEquals(10, Conversion.hexDigitToInt('A'));
        assertEquals(15, Conversion.hexDigitToInt('f'));
    }

    @Test
    void testHexDigitToInt_invalid() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.hexDigitToInt('!');
            }
        });
    }

    @Test
    void testHexToByte() {
        assertEquals((byte) 0xA1, Conversion.hexToByte("1A", 0, (byte) 0, 0, 2));
        assertEquals((byte) 7, Conversion.hexToByte("ff", 0, (byte) 7, 0, 0));
    }

    @Test
    void testHexToByte_errors() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.hexToByte("AAA", 0, (byte) 0, 0, 3);
            }
        });
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.hexToByte(null, 0, (byte) 0, 0, 2);
            }
        });
    }

    @Test
    void testHexToInt() {
        assertEquals(0xA000, Conversion.hexToInt("000A", 0, 0, 0, 4));
    }

    @Test
    void testHexToInt_boundary() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.hexToInt("x", 0, 0, 0, 9);
            }
        });
    }

    @Test
    void testHexToLong() {
        assertEquals(160L, Conversion.hexToLong("0A", 0, 0L, 0, 2));
    }

    @Test
    void testHexToLong_boundary() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.hexToLong("x", 0, 0L, 0, 17);
            }
        });
    }

    @Test
    void testHexToShort() {
        assertEquals((short) 160, Conversion.hexToShort("0A", 0, (short) 0, 0, 2));
    }

    @Test
    void testHexToShort_boundary() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.hexToShort("x", 0, (short) 0, 0, 5);
            }
        });
    }

    @Test
    void testIntArrayToLong() {
        assertEquals(0x200000001L, Conversion.intArrayToLong(new int[] { 1, 2 }, 0, 0L, 0, 2));
        assertEquals(42L, Conversion.intArrayToLong(new int[0], 0, 42L, 0, 0));
    }

    @Test
    void testIntArrayToLong_boundary() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.intArrayToLong(new int[3], 0, 0L, 0, 3);
            }
        });
    }

    @Test
    void testIntToBinary() {
        final boolean[] dst = new boolean[8];
        Conversion.intToBinary(5, 0, dst, 0, 3);
        assertArrayEquals(new boolean[] { true, false, true, false, false, false, false, false }, dst);
    }

    @Test
    void testIntToBinary_noOp() {
        final boolean[] dst = new boolean[1];
        assertSame(dst, Conversion.intToBinary(1, 0, dst, 0, 0));
    }

    @Test
    void testIntToBinary_boundary() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.intToBinary(0, 1, new boolean[1], 0, 32);
            }
        });
    }

    @Test
    void testIntToByteArray() {
        final byte[] dst = new byte[2];
        Conversion.intToByteArray(0x1234, 0, dst, 0, 2);
        assertArrayEquals(new byte[] { 0x34, 0x12 }, dst);
    }

    @Test
    void testIntToByteArray_boundary() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.intToByteArray(0, 0, new byte[1], 0, 5);
            }
        });
    }

    @Test
    void testIntToHex() {
        assertEquals("ba", Conversion.intToHex(0xAB, 0, "", 0, 2));
    }

    @Test
    void testIntToHex_boundary() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.intToHex(0, 0, "", 0, 9);
            }
        });
    }

    @Test
    void testIntToHexDigit() {
        assertEquals('0', Conversion.intToHexDigit(0));
        assertEquals('a', Conversion.intToHexDigit(10));
        assertEquals('f', Conversion.intToHexDigit(15));
    }

    @Test
    void testIntToHexDigit_invalid() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.intToHexDigit(16);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.intToHexDigit(-1);
            }
        });
    }

    @Test
    void testIntToHexDigitMsb0() {
        assertEquals('0', Conversion.intToHexDigitMsb0(0x0));
        assertEquals('8', Conversion.intToHexDigitMsb0(0x1));
        assertEquals('f', Conversion.intToHexDigitMsb0(0xF));
    }

    @Test
    void testIntToHexDigitMsb0_invalid() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.intToHexDigitMsb0(16);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.intToHexDigitMsb0(-1);
            }
        });
    }

    @Test
    void testIntToShortArray() {
        final short[] dst = new short[2];
        Conversion.intToShortArray(0x12345678, 0, dst, 0, 2);
        assertArrayEquals(new short[] { (short) 0x5678, (short) 0x1234 }, dst);
    }

    @Test
    void testIntToShortArray_boundary() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.intToShortArray(0, 0, new short[1], 0, 3);
            }
        });
    }

    @Test
    void testLongToBinary() {
        final boolean[] dst = new boolean[8];
        Conversion.longToBinary(5L, 0, dst, 0, 3);
        assertArrayEquals(new boolean[] { true, false, true, false, false, false, false, false }, dst);
    }

    @Test
    void testLongToBinary_boundary() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.longToBinary(0L, 1, new boolean[1], 0, 64);
            }
        });
    }

    @Test
    void testLongToByteArray() {
        final byte[] dst = new byte[8];
        Conversion.longToByteArray(0x1122334455667788L, 0, dst, 0, 8);
        assertArrayEquals(new byte[] { (byte) 0x88, (byte) 0x77, (byte) 0x66, (byte) 0x55, (byte) 0x44, (byte) 0x33, (byte) 0x22, (byte) 0x11 }, dst);
    }

    @Test
    void testLongToByteArray_boundary() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.longToByteArray(0L, 0, new byte[1], 0, 9);
            }
        });
    }

    @Test
    void testLongToHex() {
        assertEquals("ba", Conversion.longToHex(0xABL, 0, "", 0, 2));
    }

    @Test
    void testLongToHex_boundary() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.longToHex(0L, 0, "", 0, 17);
            }
        });
    }

    @Test
    void testLongToIntArray() {
        final int[] dst = new int[2];
        Conversion.longToIntArray(0x1234567890ABCDEFL, 0, dst, 0, 2);
        assertArrayEquals(new int[] { 0x90ABCDEF, 0x12345678 }, dst);
    }

    @Test
    void testLongToIntArray_boundary() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.longToIntArray(0L, 0, new int[1], 0, 3);
            }
        });
    }

    @Test
    void testLongToShortArray() {
        final short[] dst = new short[4];
        Conversion.longToShortArray(0x1111222233334444L, 0, dst, 0, 4);
        assertArrayEquals(new short[] { (short) 0x4444, (short) 0x3333, (short) 0x2222, (short) 0x1111 }, dst);
    }

    @Test
    void testLongToShortArray_boundary() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.longToShortArray(0L, 0, new short[1], 0, 5);
            }
        });
    }

    @Test
    void testShortArrayToInt() {
        assertEquals(0x20001, Conversion.shortArrayToInt(new short[] { (short) 1, (short) 2 }, 0, 0, 0, 2));
        assertEquals(9, Conversion.shortArrayToInt(new short[0], 0, 9, 0, 0));
    }

    @Test
    void testShortArrayToInt_boundary() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.shortArrayToInt(new short[3], 0, 0, 0, 3);
            }
        });
    }

    @Test
    void testShortArrayToLong() {
        assertEquals(0x20001L, Conversion.shortArrayToLong(new short[] { (short) 1, (short) 2 }, 0, 0L, 0, 2));
    }

    @Test
    void testShortArrayToLong_boundary() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.shortArrayToLong(new short[5], 0, 0L, 0, 5);
            }
        });
    }

    @Test
    void testShortToBinary() {
        final boolean[] dst = new boolean[8];
        Conversion.shortToBinary((short) 5, 0, dst, 0, 3);
        assertArrayEquals(new boolean[] { true, false, true, false, false, false, false, false }, dst);
    }

    @Test
    void testShortToBinary_boundary() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.shortToBinary((short) 0, 1, new boolean[1], 0, 16);
            }
        });
    }

    @Test
    void testShortToByteArray() {
        final byte[] dst = new byte[2];
        Conversion.shortToByteArray((short) 0x1234, 0, dst, 0, 2);
        assertArrayEquals(new byte[] { 0x34, 0x12 }, dst);
    }

    @Test
    void testShortToByteArray_boundary() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.shortToByteArray((short) 0, 0, new byte[1], 0, 3);
            }
        });
    }

    @Test
    void testShortToHex() {
        assertEquals("ba", Conversion.shortToHex((short) 0xAB, 0, "", 0, 2));
    }

    @Test
    void testShortToHex_boundary() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.shortToHex((short) 0, 0, "", 0, 5);
            }
        });
    }

    @Test
    void testUuidToByteArray_noOp() {
        final byte[] dst = new byte[4];
        assertSame(dst, Conversion.uuidToByteArray(UUID.randomUUID(), dst, 0, 0));
    }

    @Test
    void testUuidToByteArray_partial() {
        final UUID uuid = new UUID(0x1122334455667788L, 0x99AABBCCDDEEFF00L);
        final byte[] dst = new byte[] { -1, -1, -1, -1, -1, -1, -1, -1 };
        Conversion.uuidToByteArray(uuid, dst, 0, 4);
        assertArrayEquals(new byte[] { (byte) 0x88, (byte) 0x77, (byte) 0x66, (byte) 0x55, -1, -1, -1, -1 }, dst);
    }

    @Test
    void testUuidToByteArray_tooManyBytes() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Conversion.uuidToByteArray(UUID.randomUUID(), new byte[20], 0, 17);
            }
        });
    }

    @Test
    void testConstructor() {
        assertNotNull(new Conversion());
    }

}
