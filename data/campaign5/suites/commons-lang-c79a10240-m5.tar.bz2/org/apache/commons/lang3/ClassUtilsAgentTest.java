/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.Serializable;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.ClassUtils.Interfaces;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link ClassUtils}.
 */
class ClassUtilsAgentTest {

    private interface FixtureIA {
        // empty
    }

    private interface FixtureIB {
        // empty
    }

    private interface FixtureIC extends FixtureID, FixtureIE {
        // empty
    }

    private interface FixtureID {
        // empty
    }

    private interface FixtureIE extends FixtureIF {
        // empty
    }

    private interface FixtureIF {
        // empty
    }

    private static class FixtureCX implements FixtureIB, FixtureIA, FixtureIE {
        // empty
    }

    private static final class FixtureCY extends FixtureCX implements FixtureIB, FixtureIC {
        // empty
    }

    private static final class FixtureInner {
        private static final class FixtureDeeplyNested {
            // empty
        }
    }

    @Test
    void testConstants() {
        assertEquals('.', ClassUtils.PACKAGE_SEPARATOR_CHAR);
        assertEquals(".", ClassUtils.PACKAGE_SEPARATOR);
        assertEquals('$', ClassUtils.INNER_CLASS_SEPARATOR_CHAR);
        assertEquals("$", ClassUtils.INNER_CLASS_SEPARATOR);
    }

    @Test
    void testInterfacesEnum() {
        final Interfaces[] values = Interfaces.values();
        assertEquals(2, values.length);
        assertEquals(Interfaces.INCLUDE, Interfaces.valueOf("INCLUDE"));
        assertEquals(Interfaces.EXCLUDE, Interfaces.valueOf("EXCLUDE"));
    }

    @Test
    void testPublicConstructor() {
        assertNotNull(new ClassUtils());
    }

    @Test
    void testComparator() {
        final List<Class<?>> list = new ArrayList<Class<?>>();
        list.add(String.class);
        list.add(Object.class);
        list.add(Integer.class);
        list.sort(ClassUtils.comparator());
        assertEquals(Integer.class, list.get(0));
        assertEquals(Object.class, list.get(1));
        assertEquals(String.class, list.get(2));
    }

    @Test
    void testConvertClassesToClassNames() {
        final List<Class<?>> list = new ArrayList<Class<?>>();
        assertEquals(0, ClassUtils.convertClassesToClassNames(list).size());

        list.add(String.class);
        list.add(null);
        list.add(Object.class);
        final List<String> result = ClassUtils.convertClassesToClassNames(list);
        assertEquals(3, result.size());
        assertEquals("java.lang.String", result.get(0));
        assertNull(result.get(1));
        assertEquals("java.lang.Object", result.get(2));

        assertNull(ClassUtils.convertClassesToClassNames(null));
    }

    @Test
    void testConvertClassesToClassNamesClassCastException() {
        final List<Class<?>> list = new ArrayList<Class<?>>();
        @SuppressWarnings("unchecked")
        final List<Object> olist = (List<Object>) (List<?>) list;
        olist.add(new Object());
        assertThrows(ClassCastException.class, new Executable() {
            @Override
            public void execute() {
                ClassUtils.convertClassesToClassNames(list);
            }
        });
    }

    @Test
    void testConvertClassNamesToClasses() {
        final List<String> list = new ArrayList<String>();
        assertEquals(0, ClassUtils.convertClassNamesToClasses(list).size());

        list.add("java.lang.String");
        list.add("java.lang.xxx");
        list.add("java.lang.Object");
        final List<Class<?>> result = ClassUtils.convertClassNamesToClasses(list);
        assertEquals(3, result.size());
        assertEquals(String.class, result.get(0));
        assertNull(result.get(1));
        assertEquals(Object.class, result.get(2));

        assertNull(ClassUtils.convertClassNamesToClasses(null));
    }

    @Test
    void testGetAbbreviatedNameClass() {
        assertEquals("", ClassUtils.getAbbreviatedName((Class<?>) null, 1));
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName(String.class, 1));
        assertEquals("java.lang.String", ClassUtils.getAbbreviatedName(String.class, 20));
    }

    @Test
    void testGetAbbreviatedNameClassNegativeLength() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ClassUtils.getAbbreviatedName(String.class, -10);
            }
        });
    }

    @Test
    void testGetAbbreviatedNameClassZeroLength() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ClassUtils.getAbbreviatedName(String.class, 0);
            }
        });
    }

    @Test
    void testGetAbbreviatedNameString() {
        assertEquals("", ClassUtils.getAbbreviatedName((String) null, 1));
        assertEquals("", ClassUtils.getAbbreviatedName("", 1));
        assertEquals("WithoutPackage", ClassUtils.getAbbreviatedName("WithoutPackage", 1));
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName("java.lang.String", 1));
        assertEquals("java.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", Integer.MAX_VALUE));
    }

    @Test
    void testGetAbbreviatedNameTooLongHintReturnsSameInstance() {
        final String className = "java.lang.String";
        assertSame(className, ClassUtils.getAbbreviatedName(className, className.length() + 1));
        assertSame(className, ClassUtils.getAbbreviatedName(className, className.length()));
    }

    @Test
    void testGetAllInterfaces() {
        final List<Class<?>> list = ClassUtils.getAllInterfaces(FixtureCY.class);
        assertEquals(6, list.size());
        assertEquals(FixtureIB.class, list.get(0));
        assertEquals(FixtureIC.class, list.get(1));
        assertEquals(FixtureID.class, list.get(2));
        assertEquals(FixtureIE.class, list.get(3));
        assertEquals(FixtureIF.class, list.get(4));
        assertEquals(FixtureIA.class, list.get(5));

        assertNull(ClassUtils.getAllInterfaces(null));
        assertTrue(ClassUtils.getAllInterfaces(Object.class).isEmpty());
    }

    @Test
    void testGetAllSuperclasses() {
        final List<Class<?>> list = ClassUtils.getAllSuperclasses(FixtureCY.class);
        assertEquals(2, list.size());
        assertEquals(FixtureCX.class, list.get(0));
        assertEquals(Object.class, list.get(1));

        assertNull(ClassUtils.getAllSuperclasses(null));
        assertTrue(ClassUtils.getAllSuperclasses(Object.class).isEmpty());
    }

    @Test
    void testGetCanonicalNameClass() {
        assertEquals("org.apache.commons.lang3.ClassUtils", ClassUtils.getCanonicalName(ClassUtils.class));
        assertEquals("java.util.Map.Entry", ClassUtils.getCanonicalName(Map.Entry.class));
        assertEquals("", ClassUtils.getCanonicalName((Class<?>) null));
        assertEquals("java.lang.String[]", ClassUtils.getCanonicalName(String[].class));
        assertEquals("int", ClassUtils.getCanonicalName(int.class));
        assertEquals("int[]", ClassUtils.getCanonicalName(int[].class));
    }

    @Test
    void testGetCanonicalNameClassWithDefault() {
        assertEquals("X", ClassUtils.getCanonicalName((Class<?>) null, "X"));
        assertEquals("org.apache.commons.lang3.ClassUtils", ClassUtils.getCanonicalName(ClassUtils.class, "X"));
    }

    @Test
    void testGetCanonicalNameObject() {
        assertEquals("java.lang.Object", ClassUtils.getCanonicalName(new Object()));
        assertEquals("X", ClassUtils.getCanonicalName((Object) null, "X"));
        assertEquals("java.lang.String", ClassUtils.getCanonicalName("hello", "X"));
    }

    @Test
    void testGetClassString() throws ClassNotFoundException {
        assertEquals(ClassUtils.class, ClassUtils.getClass("org.apache.commons.lang3.ClassUtils"));
        assertEquals(int.class, ClassUtils.getClass("int"));
        assertEquals(String[].class, ClassUtils.getClass("[Ljava.lang.String;"));
        assertEquals(Map.Entry.class, ClassUtils.getClass("java.util.Map.Entry"));
    }

    @Test
    void testGetClassStringNotFound() {
        assertThrows(ClassNotFoundException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass("this.class.does.not.Exist");
            }
        });
    }

    @Test
    void testGetClassStringNull() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass((String) null);
            }
        });
    }

    @Test
    void testGetClassLoaderStringInitialize() throws ClassNotFoundException {
        final ClassLoader loader = ClassUtilsAgentTest.class.getClassLoader();
        assertEquals(ClassUtils.class, ClassUtils.getClass(loader, "org.apache.commons.lang3.ClassUtils", false));
    }

    @Test
    void testGetComponentType() {
        assertEquals(String.class, ClassUtils.getComponentType(String[].class));
        assertNull(ClassUtils.getComponentType(null));
    }

    @Test
    void testGetNameClass() {
        assertEquals("org.apache.commons.lang3.ClassUtils", ClassUtils.getName(ClassUtils.class));
        assertEquals("java.util.Map$Entry", ClassUtils.getName(Map.Entry.class));
        assertEquals("", ClassUtils.getName((Class<?>) null));
        assertEquals("[Ljava.lang.String;", ClassUtils.getName(String[].class));
        assertEquals("[I", ClassUtils.getName(int[].class));
    }

    @Test
    void testGetNameObject() {
        assertEquals("java.lang.String", ClassUtils.getName("hello", "<null>"));
        assertEquals("<null>", ClassUtils.getName(null, "<null>"));
    }

    @Test
    void testGetPackageCanonicalNameClass() {
        assertEquals("org.apache.commons.lang3", ClassUtils.getPackageCanonicalName(ClassUtils.class));
        assertEquals("", ClassUtils.getPackageCanonicalName(int[].class));
        assertEquals("", ClassUtils.getPackageCanonicalName((Class<?>) null));
    }

    @Test
    void testGetPackageCanonicalNameObject() {
        assertEquals("<null>", ClassUtils.getPackageCanonicalName(null, "<null>"));
        assertEquals("org.apache.commons.lang3", ClassUtils.getPackageCanonicalName(new ClassUtils(), "<null>"));
    }

    @Test
    void testGetPackageCanonicalNameString() {
        assertEquals("org.apache.commons.lang3", ClassUtils.getPackageCanonicalName("org.apache.commons.lang3.ClassUtils"));
        assertEquals("", ClassUtils.getPackageCanonicalName("[I"));
    }

    @Test
    void testGetPackageNameClass() {
        assertEquals("java.lang", ClassUtils.getPackageName(String.class));
        assertEquals("", ClassUtils.getPackageName((Class<?>) null));
        assertEquals("java.lang", ClassUtils.getPackageName(String[].class));
        assertEquals("", ClassUtils.getPackageName(int[].class));
    }

    @Test
    void testGetPackageNameObject() {
        assertEquals("org.apache.commons.lang3", ClassUtils.getPackageName(new ClassUtils(), "<null>"));
        assertEquals("<null>", ClassUtils.getPackageName(null, "<null>"));
    }

    @Test
    void testGetPackageNameString() {
        assertEquals("org.apache.commons.lang3", ClassUtils.getPackageName(ClassUtils.class.getName()));
        assertEquals("", ClassUtils.getPackageName((String) null));
        assertEquals("", ClassUtils.getPackageName(""));
    }

    @Test
    void testGetPublicMethod() throws Exception {
        final Method method = ClassUtils.getPublicMethod(String.class, "charAt", int.class);
        assertNotNull(method);
        assertEquals("charAt", method.getName());
        assertTrue(Modifier.isPublic(method.getDeclaringClass().getModifiers()));
    }

    @Test
    void testGetPublicMethodNoSuchMethod() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getPublicMethod(String.class, "thisMethodDoesNotExist");
            }
        });
    }

    @Test
    void testGetPublicMethodNullClass() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getPublicMethod(null, "hashCode");
            }
        });
    }

    @Test
    void testGetShortCanonicalNameClass() {
        assertEquals("ClassUtils", ClassUtils.getShortCanonicalName(ClassUtils.class));
        assertEquals("int[]", ClassUtils.getShortCanonicalName(int[].class));
        assertEquals("", ClassUtils.getShortCanonicalName((Class<?>) null));
    }

    @Test
    void testGetShortCanonicalNameString() {
        assertEquals("", ClassUtils.getShortCanonicalName((String) null));
        assertEquals("Map.Entry", ClassUtils.getShortCanonicalName(Map.Entry.class.getName()));
        assertEquals("ClassUtils[]", ClassUtils.getShortCanonicalName("[Lorg.apache.commons.lang3.ClassUtils;"));
    }

    @Test
    void testGetShortCanonicalNameStringInvalidInputs() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ClassUtils.getShortCanonicalName("");
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ClassUtils.getShortCanonicalName("[");
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ClassUtils.getShortCanonicalName("[[");
            }
        });
    }

    @Test
    void testGetShortClassNameClass() {
        assertEquals("ClassUtils", ClassUtils.getShortClassName(ClassUtils.class));
        assertEquals("Map.Entry", ClassUtils.getShortClassName(Map.Entry.class));
        assertEquals("", ClassUtils.getShortClassName((Class<?>) null));
        assertEquals("String[]", ClassUtils.getShortClassName(String[].class));
    }

    @Test
    void testGetShortClassNameObject() {
        assertEquals("ClassUtils", ClassUtils.getShortClassName(new ClassUtils(), "<null>"));
        assertEquals("<null>", ClassUtils.getShortClassName(null, "<null>"));
    }

    @Test
    void testGetShortClassNameString() {
        assertEquals("ClassUtils", ClassUtils.getShortClassName(ClassUtils.class.getName()));
        assertEquals("", ClassUtils.getShortClassName((String) null));
        assertEquals("", ClassUtils.getShortClassName(""));
    }

    @Test
    void testGetSimpleNameClass() {
        assertEquals("ClassUtils", ClassUtils.getSimpleName(ClassUtils.class));
        assertEquals("", ClassUtils.getSimpleName((Class<?>) null));
        assertEquals("String[]", ClassUtils.getSimpleName(String[].class));
    }

    @Test
    void testGetSimpleNameObject() {
        assertEquals("ClassUtils", ClassUtils.getSimpleName(new ClassUtils()));
        assertEquals("", ClassUtils.getSimpleName((Object) null));
    }

    @Test
    void testGetSimpleNameObjectWithDefault() {
        assertEquals("ClassUtils", ClassUtils.getSimpleName(new ClassUtils(), "<null>"));
        assertEquals("<null>", ClassUtils.getSimpleName(null, "<null>"));
        assertNull(ClassUtils.getSimpleName(null, null));
    }

    @Test
    void testHierarchyExcludeInterfaces() {
        final Iterable<Class<?>> hierarchy = ClassUtils.hierarchy(FixtureCY.class);
        final Iterator<Class<?>> it = hierarchy.iterator();
        assertEquals(FixtureCY.class, it.next());
        assertEquals(FixtureCX.class, it.next());
        assertEquals(Object.class, it.next());
        assertFalse(it.hasNext());
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                hierarchy.iterator().remove();
            }
        });
    }

    @Test
    void testHierarchyIncludeInterfaces() {
        final Iterable<Class<?>> hierarchy = ClassUtils.hierarchy(FixtureCY.class, Interfaces.INCLUDE);
        final List<Class<?>> collected = new ArrayList<Class<?>>();
        final Iterator<Class<?>> it = hierarchy.iterator();
        while (it.hasNext()) {
            collected.add(it.next());
        }
        assertTrue(collected.contains(FixtureCY.class));
        assertTrue(collected.contains(FixtureCX.class));
        assertTrue(collected.contains(Object.class));
        assertTrue(collected.contains(FixtureIB.class));
        assertTrue(collected.contains(FixtureIC.class));
        assertTrue(collected.indexOf(FixtureCY.class) < collected.indexOf(FixtureCX.class));
    }

    @Test
    void testIsAssignable() {
        assertFalse(ClassUtils.isAssignable((Class<?>) null, null));
        assertFalse(ClassUtils.isAssignable(String.class, null));
        assertTrue(ClassUtils.isAssignable(null, Object.class));
        assertFalse(ClassUtils.isAssignable(null, Integer.TYPE));
        assertTrue(ClassUtils.isAssignable(String.class, Object.class));
        assertFalse(ClassUtils.isAssignable(Object.class, String.class));
        assertTrue(ClassUtils.isAssignable(Integer.TYPE, Long.TYPE));
        assertFalse(ClassUtils.isAssignable(Long.TYPE, Integer.TYPE));
        assertTrue(ClassUtils.isAssignable(Integer.TYPE, Integer.class));
    }

    @Test
    void testIsAssignableNoAutoboxing() {
        assertFalse(ClassUtils.isAssignable(Integer.TYPE, Integer.class, false));
        assertFalse(ClassUtils.isAssignable(Integer.class, Integer.TYPE, false));
        assertTrue(ClassUtils.isAssignable(Integer.TYPE, Integer.TYPE, false));
        assertTrue(ClassUtils.isAssignable(Integer.TYPE, Long.TYPE, false));
    }

    @Test
    void testIsAssignableClassArray() {
        final Class<?>[] array2 = new Class<?>[] {Object.class, Object.class};
        final Class<?>[] array1 = new Class<?>[] {Object.class};
        final Class<?>[] array0 = new Class<?>[] {};

        assertFalse(ClassUtils.isAssignable(array1, array2));
        assertFalse(ClassUtils.isAssignable(null, array2));
        assertTrue(ClassUtils.isAssignable(null, array0));
        assertTrue(ClassUtils.isAssignable(array0, array0));
        assertTrue(ClassUtils.isAssignable(array0, (Class<?>[]) null));
        assertTrue(ClassUtils.isAssignable(null, (Class<?>[]) null));

        final Class<?>[] primitives = {Integer.TYPE, Boolean.TYPE};
        final Class<?>[] wrappers = {Integer.class, Boolean.class};
        assertTrue(ClassUtils.isAssignable(primitives, wrappers));
        assertFalse(ClassUtils.isAssignable(primitives, wrappers, false));
    }

    @Test
    void testIsInnerClass() {
        assertTrue(ClassUtils.isInnerClass(FixtureInner.class));
        assertTrue(ClassUtils.isInnerClass(FixtureInner.FixtureDeeplyNested.class));
        assertFalse(ClassUtils.isInnerClass(ClassUtils.class));
        assertFalse(ClassUtils.isInnerClass(null));
    }

    @Test
    void testIsPrimitiveOrWrapper() {
        assertTrue(ClassUtils.isPrimitiveOrWrapper(int.class));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(Integer.class));
        assertFalse(ClassUtils.isPrimitiveOrWrapper(String.class));
        assertFalse(ClassUtils.isPrimitiveOrWrapper(null));
    }

    @Test
    void testIsPrimitiveWrapper() {
        assertTrue(ClassUtils.isPrimitiveWrapper(Integer.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(int.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(String.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(null));
    }

    @Test
    void testIsPublic() {
        assertTrue(ClassUtils.isPublic(ClassUtils.class));
        assertFalse(ClassUtils.isPublic(FixtureCX.class));
    }

    @Test
    void testIsPublicNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ClassUtils.isPublic(null);
            }
        });
    }

    @Test
    void testPrimitivesToWrappers() {
        assertNull(ClassUtils.primitivesToWrappers((Class<?>[]) null));
        assertEquals(0, ClassUtils.primitivesToWrappers().length);
        assertArrayEquals(new Class<?>[] {Integer.class, String.class, Double.class},
            ClassUtils.primitivesToWrappers(Integer.TYPE, String.class, Double.TYPE));
    }

    @Test
    void testPrimitiveToWrapper() {
        assertEquals(Integer.class, ClassUtils.primitiveToWrapper(Integer.TYPE));
        assertEquals(Void.TYPE, ClassUtils.primitiveToWrapper(Void.TYPE));
        assertEquals(String.class, ClassUtils.primitiveToWrapper(String.class));
        assertNull(ClassUtils.primitiveToWrapper(null));
    }

    @Test
    void testToClass() {
        assertNull(ClassUtils.toClass((Object[]) null));
        assertEquals(0, ClassUtils.toClass().length);
        assertArrayEquals(new Class<?>[] {String.class, null, Integer.class}, ClassUtils.toClass("hello", null, 1));
    }

    @Test
    void testWrappersToPrimitives() {
        assertNull(ClassUtils.wrappersToPrimitives((Class<?>[]) null));
        assertEquals(0, ClassUtils.wrappersToPrimitives().length);
        assertArrayEquals(new Class<?>[] {Integer.TYPE, null, null},
            ClassUtils.wrappersToPrimitives(Integer.class, String.class, String.class));
    }

    @Test
    void testWrapperToPrimitive() {
        assertEquals(Integer.TYPE, ClassUtils.wrapperToPrimitive(Integer.class));
        assertNull(ClassUtils.wrapperToPrimitive(String.class));
        assertNull(ClassUtils.wrapperToPrimitive(null));
    }
}
