/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link StringUtils}.
 */
class StringUtilsAgentTest {

    @Test
    void testAbbreviate() {
        assertNull(StringUtils.abbreviate(null, 4));
        assertEquals("", StringUtils.abbreviate("", 4));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", 7));
        assertEquals("abcd...", StringUtils.abbreviate("abcdefghij", 7));
        assertThrows(IllegalArgumentException.class, () -> StringUtils.abbreviate("abcdefghij", 3));
    }

    @Test
    void testAbbreviateWithOffset() {
        assertEquals("...ijklmno", StringUtils.abbreviate("abcdefghijklmno", 10, 10));
        assertThrows(IllegalArgumentException.class, () -> StringUtils.abbreviate("abcdefghij", 5, 6));
    }

    @Test
    void testCapitalizeAndUncapitalize() {
        assertNull(StringUtils.capitalize(null));
        assertEquals("", StringUtils.capitalize(""));
        assertEquals("Cat", StringUtils.capitalize("cat"));
        assertEquals("CAt", StringUtils.capitalize("CAt"));
        assertNull(StringUtils.uncapitalize(null));
        assertEquals("", StringUtils.uncapitalize(""));
        assertEquals("cat", StringUtils.uncapitalize("Cat"));
        assertEquals("cAT", StringUtils.uncapitalize("CAT"));
    }

    @Test
    void testCenter() {
        assertNull(StringUtils.center(null, 4));
        assertEquals("    ", StringUtils.center("", 4));
        assertEquals("ab", StringUtils.center("ab", 0));
        assertEquals("ab", StringUtils.center("ab", -1));
        assertEquals(" ab ", StringUtils.center("ab", 4));
        assertEquals("abcd", StringUtils.center("abcd", 2));
        assertEquals("yayz", StringUtils.center("a", 4, "yz"));
    }

    @Test
    void testChompAndChop() {
        assertNull(StringUtils.chomp(null));
        assertEquals("", StringUtils.chomp(""));
        assertEquals("abc", StringUtils.chomp("abc\r\n"));
        assertEquals("abc", StringUtils.chomp("abc\n"));
        assertEquals("abc", StringUtils.chomp("abc\r"));

        assertNull(StringUtils.chop(null));
        assertEquals("", StringUtils.chop(""));
        assertEquals("", StringUtils.chop("x"));
        assertEquals("abc", StringUtils.chop("abc\r\n"));
        assertEquals("ab", StringUtils.chop("abc"));
    }

    @Test
    void testCompareAndCompareIgnoreCase() {
        assertEquals(0, StringUtils.compare(null, null));
        assertTrue(StringUtils.compare(null, "a") < 0);
        assertTrue(StringUtils.compare("a", null) > 0);
        assertTrue(StringUtils.compare("a", "b") < 0);

        assertTrue(StringUtils.compare(null, "a", true) < 0);
        assertTrue(StringUtils.compare(null, "a", false) > 0);

        assertEquals(0, StringUtils.compareIgnoreCase("ABC", "abc"));
    }

    @Test
    void testContainsFamily() {
        assertFalse(StringUtils.contains(null, "a"));
        assertFalse(StringUtils.contains("abc", null));
        assertTrue(StringUtils.contains("abc", "b"));
        assertTrue(StringUtils.contains("abc", 'b'));
        assertFalse(StringUtils.contains("abc", 'z'));

        assertTrue(StringUtils.containsAny("abc", 'z', 'a'));
        assertFalse(StringUtils.containsAny((CharSequence) null, 'a'));
        assertFalse(StringUtils.containsAny("abc", new char[0]));

        assertTrue(StringUtils.containsIgnoreCase("ABC", "b"));
        assertFalse(StringUtils.containsIgnoreCase(null, "b"));

        assertTrue(StringUtils.containsNone("abc", 'x', 'y'));
        assertFalse(StringUtils.containsNone("abc", 'a'));

        assertTrue(StringUtils.containsOnly("abab", 'a', 'b'));
        assertFalse(StringUtils.containsOnly("abcab", 'a', 'b'));
        assertFalse(StringUtils.containsOnly(null, 'a'));

        assertTrue(StringUtils.containsWhitespace("a b"));
        assertFalse(StringUtils.containsWhitespace("ab"));
    }

    @Test
    void testCountMatches() {
        assertEquals(0, StringUtils.countMatches(null, "a"));
        assertEquals(0, StringUtils.countMatches("abcabc", ""));
        assertEquals(2, StringUtils.countMatches("abcabc", "a"));
        assertEquals(2, StringUtils.countMatches("abcabc", 'a'));
        assertEquals(0, StringUtils.countMatches(null, 'a'));
    }

    @Test
    void testDefaultStringFamily() {
        assertEquals("", StringUtils.defaultString(null));
        assertEquals("abc", StringUtils.defaultString("abc"));
        assertEquals("NULL", StringUtils.defaultString(null, "NULL"));

        assertEquals("def", StringUtils.defaultIfEmpty("", "def"));
        assertEquals("abc", StringUtils.defaultIfEmpty("abc", "def"));
        assertEquals("def", StringUtils.defaultIfBlank("  ", "def"));
        assertEquals("abc", StringUtils.defaultIfBlank("abc", "def"));
    }

    @Test
    void testDeleteWhitespace() {
        assertNull(StringUtils.deleteWhitespace(null));
        assertEquals("", StringUtils.deleteWhitespace(""));
        assertEquals("abc", StringUtils.deleteWhitespace("  a b  c "));
    }

    @Test
    void testDifference() {
        assertNull(StringUtils.difference(null, null));
        assertEquals("", StringUtils.difference("", ""));
        assertEquals("abc", StringUtils.difference(null, "abc"));
        assertEquals("abc", StringUtils.difference("abc", null));
        assertEquals("ty", StringUtils.difference("abcde", "abcty"));
    }

    @Test
    void testEndsWithFamily() {
        assertTrue(StringUtils.endsWith(null, null));
        assertFalse(StringUtils.endsWith("abcdef", null));
        assertTrue(StringUtils.endsWith("abcdef", "def"));
        assertFalse(StringUtils.endsWith("ABCDEF", "def"));
        assertTrue(StringUtils.endsWithIgnoreCase("ABCDEF", "def"));
        assertTrue(StringUtils.endsWithAny("abcxyz", "xyz", "123"));
        assertFalse(StringUtils.endsWithAny("abcxyz", "123"));
    }

    @Test
    void testEqualsFamily() {
        assertTrue(StringUtils.equals(null, null));
        assertFalse(StringUtils.equals(null, "abc"));
        assertFalse(StringUtils.equals("abc", null));
        assertTrue(StringUtils.equals("abc", "abc"));
        assertFalse(StringUtils.equals("abc", "abcd"));

        assertTrue(StringUtils.equalsIgnoreCase("abc", "ABC"));
        assertTrue(StringUtils.equalsIgnoreCase(null, null));
        assertFalse(StringUtils.equalsIgnoreCase(null, "ABC"));

        assertTrue(StringUtils.equalsAny("abc", "xyz", "abc"));
        assertFalse(StringUtils.equalsAny("abc", "xyz", "123"));
        assertTrue(StringUtils.equalsAnyIgnoreCase("abc", "xyz", "ABC"));
    }

    @Test
    void testGetCommonPrefix() {
        assertEquals("", StringUtils.getCommonPrefix((String[]) null));
        assertEquals("", StringUtils.getCommonPrefix());
        assertEquals("abc", StringUtils.getCommonPrefix("abc"));
        assertEquals("ab", StringUtils.getCommonPrefix("abc", "abd"));
        assertEquals("", StringUtils.getCommonPrefix("abc", "xyz"));
        assertEquals("", StringUtils.getCommonPrefix("abc", null));
    }

    @Test
    void testGetDigits() {
        assertNull(StringUtils.getDigits(null));
        assertEquals("", StringUtils.getDigits(""));
        assertEquals("1234", StringUtils.getDigits("ab1 2c3.4"));
    }

    @Test
    void testGetLevenshteinDistance() {
        assertEquals(0, StringUtils.getLevenshteinDistance("", ""));
        assertEquals(3, StringUtils.getLevenshteinDistance("", "abc"));
        assertEquals(1, StringUtils.getLevenshteinDistance("frog", "fog"));
        assertThrows(IllegalArgumentException.class, () -> StringUtils.getLevenshteinDistance(null, "a"));

        assertEquals(1, StringUtils.getLevenshteinDistance("frog", "fog", 4));
        assertEquals(-1, StringUtils.getLevenshteinDistance("hippo", "elephant", 2));
        assertThrows(IllegalArgumentException.class, () -> StringUtils.getLevenshteinDistance("a", "b", -1));
        assertThrows(IllegalArgumentException.class, () -> StringUtils.getLevenshteinDistance(null, "a", 1));
    }

    @Test
    void testIndexOfFamily() {
        assertEquals(-1, StringUtils.indexOf(null, "a"));
        assertEquals(-1, StringUtils.indexOf("abc", null));
        assertEquals(1, StringUtils.indexOf("abc", "b"));
        assertEquals(1, StringUtils.indexOf("abc", 'b'));
        assertEquals(-1, StringUtils.indexOf("abc", 'b', 2));

        assertEquals(1, StringUtils.indexOfAny("abc", 'b', 'z'));
        assertEquals(-1, StringUtils.indexOfAny((CharSequence) null, 'b'));
        assertEquals(2, StringUtils.indexOfAnyBut("abc", 'a', 'b'));

        assertEquals(1, StringUtils.indexOfIgnoreCase("aBc", "bc"));
        assertEquals(-1, StringUtils.indexOfIgnoreCase(null, "bc"));

        assertEquals(1, StringUtils.lastIndexOf("abcbc", "b", 2));
        assertEquals(3, StringUtils.lastIndexOf("abcbc", "b"));
        assertEquals(-1, StringUtils.lastIndexOf(null, "b"));

        assertEquals(3, StringUtils.lastIndexOfIgnoreCase("aBcBc", "bc"));
        assertEquals(3, StringUtils.lastIndexOfAny("abcbc", "b", "z"));

        assertEquals(3, StringUtils.ordinalIndexOf("aabaabaa", "a", 4));
        assertEquals(5, StringUtils.lastOrdinalIndexOf("aabaabaa", "a", 2));
    }

    @Test
    void testIndexOfDifference() {
        assertEquals(-1, StringUtils.indexOfDifference("abc", "abc"));
        assertEquals(2, StringUtils.indexOfDifference("abc", "abd"));
        assertEquals(0, StringUtils.indexOfDifference(null, "abc"));
        assertEquals(-1, StringUtils.indexOfDifference((CharSequence[]) null));
        assertEquals(-1, StringUtils.indexOfDifference("abc"));
    }

    @Test
    void testIsBlankIsEmpty() {
        assertTrue(StringUtils.isEmpty(null));
        assertTrue(StringUtils.isEmpty(""));
        assertFalse(StringUtils.isEmpty(" "));
        assertFalse(StringUtils.isEmpty("abc"));

        assertTrue(StringUtils.isBlank(null));
        assertTrue(StringUtils.isBlank(""));
        assertTrue(StringUtils.isBlank("  \t\n"));
        assertFalse(StringUtils.isBlank("abc"));

        assertTrue(StringUtils.isNotEmpty("abc"));
        assertFalse(StringUtils.isNotEmpty(""));
        assertTrue(StringUtils.isNotBlank("abc"));
        assertFalse(StringUtils.isNotBlank(" "));
    }

    @Test
    void testAllAnyNoneEmptyBlank() {
        assertTrue(StringUtils.isAllEmpty(null, ""));
        assertFalse(StringUtils.isAllEmpty(null, "a"));
        assertTrue(StringUtils.isAllBlank(null, " ", ""));
        assertFalse(StringUtils.isAllBlank(null, "a"));

        assertTrue(StringUtils.isAnyEmpty("a", ""));
        assertFalse(StringUtils.isAnyEmpty("a", "b"));
        assertTrue(StringUtils.isAnyBlank("a", " "));
        assertFalse(StringUtils.isAnyBlank("a", "b"));

        assertTrue(StringUtils.isNoneEmpty("a", "b"));
        assertFalse(StringUtils.isNoneEmpty("a", ""));
        assertTrue(StringUtils.isNoneBlank("a", "b"));
        assertFalse(StringUtils.isNoneBlank("a", " "));
    }

    @Test
    void testIsMixedAndCaseChecks() {
        assertFalse(StringUtils.isMixedCase(null));
        assertFalse(StringUtils.isMixedCase(""));
        assertFalse(StringUtils.isMixedCase("ABC"));
        assertFalse(StringUtils.isMixedCase("abc"));
        assertTrue(StringUtils.isMixedCase("aBc"));

        assertFalse(StringUtils.isAllLowerCase(null));
        assertTrue(StringUtils.isAllLowerCase("abc"));
        assertFalse(StringUtils.isAllLowerCase("abC"));

        assertFalse(StringUtils.isAllUpperCase(null));
        assertTrue(StringUtils.isAllUpperCase("ABC"));
        assertFalse(StringUtils.isAllUpperCase("ABc"));
    }

    @Test
    void testJoinArrays() {
        assertNull(StringUtils.join((Object[]) null, ','));
        assertEquals("", StringUtils.join(new Object[0], ','));
        assertEquals("a,b,c", StringUtils.join(new Object[] {"a", "b", "c"}, ','));
        assertEquals("a,,c", StringUtils.join(new Object[] {"a", null, "c"}, ','));

        assertEquals("1,2,3", StringUtils.join(new int[] {1, 2, 3}, ','));
        assertEquals("", StringUtils.join(new int[0], ','));

        assertEquals("b,c", StringUtils.join(new Object[] {"a", "b", "c", "d"}, ',', 1, 3));

        assertEquals("a-b-c", StringUtils.join(new Object[] {"a", "b", "c"}, "-"));
        assertNull(StringUtils.join((Object[]) null, "-"));
    }

    @Test
    void testJoinIterable() {
        java.util.List<String> list = java.util.Arrays.asList("a", "b", "c");
        assertEquals("a,b,c", StringUtils.join((Iterable<?>) list, ','));
        assertEquals("a-b-c", StringUtils.join((Iterable<?>) list, "-"));
        assertEquals("a,b,c", StringUtils.join(list.iterator(), ','));
        assertNull(StringUtils.join((Iterable<?>) null, ','));
        assertNull(StringUtils.join((java.util.Iterator<?>) null, ','));
    }

    @Test
    void testJoinWith() {
        assertEquals("a-b-c", StringUtils.joinWith("-", "a", "b", "c"));
        assertEquals("", StringUtils.joinWith("-"));
        assertEquals("ab", StringUtils.joinWith(null, "a", "b"));
        assertThrows(IllegalArgumentException.class, () -> StringUtils.joinWith("-", (Object[]) null));
    }

    @Test
    void testLeftRightMid() {
        assertNull(StringUtils.left(null, 3));
        assertEquals("", StringUtils.left("abc", -1));
        assertEquals("ab", StringUtils.left("abc", 2));
        assertEquals("abc", StringUtils.left("abc", 10));

        assertNull(StringUtils.right(null, 3));
        assertEquals("", StringUtils.right("abc", -1));
        assertEquals("bc", StringUtils.right("abc", 2));
        assertEquals("abc", StringUtils.right("abc", 10));

        assertNull(StringUtils.mid(null, 0, 3));
        assertEquals("", StringUtils.mid("abc", 0, -1));
        assertEquals("ab", StringUtils.mid("abc", 0, 2));
        assertEquals("bc", StringUtils.mid("abc", 1, 2));
        assertEquals("", StringUtils.mid("abc", 10, 2));
    }

    @Test
    void testPadFunctions() {
        assertNull(StringUtils.leftPad(null, 3));
        assertEquals("  ab", StringUtils.leftPad("ab", 4));
        assertEquals("ab", StringUtils.leftPad("ab", 1));
        assertEquals("xxab", StringUtils.leftPad("ab", 4, 'x'));
        assertEquals("xyxyab", StringUtils.leftPad("ab", 6, "xy"));

        assertNull(StringUtils.rightPad(null, 3));
        assertEquals("ab  ", StringUtils.rightPad("ab", 4));
        assertEquals("ab", StringUtils.rightPad("ab", 1));
        assertEquals("abxx", StringUtils.rightPad("ab", 4, 'x'));
        assertEquals("abxyxy", StringUtils.rightPad("ab", 6, "xy"));
    }

    @Test
    void testLength() {
        assertEquals(0, StringUtils.length(null));
        assertEquals(0, StringUtils.length(""));
        assertEquals(3, StringUtils.length("abc"));
    }

    @Test
    void testLowerUpperCase() {
        assertNull(StringUtils.lowerCase(null));
        assertEquals("abc", StringUtils.lowerCase("ABC"));
        assertNull(StringUtils.upperCase(null));
        assertEquals("ABC", StringUtils.upperCase("abc"));
        assertEquals("abc", StringUtils.lowerCase("ABC", java.util.Locale.ROOT));
        assertEquals("ABC", StringUtils.upperCase("abc", java.util.Locale.ROOT));
    }

    @Test
    void testNormalizeSpace() {
        assertNull(StringUtils.normalizeSpace(null));
        assertEquals("", StringUtils.normalizeSpace(""));
        assertEquals("ab c", StringUtils.normalizeSpace("  ab   c  "));
    }

    @Test
    void testOverlay() {
        assertNull(StringUtils.overlay(null, "x", 0, 0));
        assertEquals("xyz", StringUtils.overlay("abc", "xyz", 0, 3));
        assertEquals("axyzc", StringUtils.overlay("abc", "xyz", 1, 2));
        // out-of-range indices are clamped rather than throwing
        assertEquals("xyzabc", StringUtils.overlay("abc", "xyz", -1, 0));
        assertEquals("abcxyz", StringUtils.overlay("abc", "xyz", 10, 20));
        // reversed start/end are swapped
        assertEquals("axyzc", StringUtils.overlay("abc", "xyz", 2, 1));
    }

    @Test
    void testRemoveFamily() {
        assertNull(StringUtils.remove(null, 'a'));
        assertEquals("bc", StringUtils.remove("abcabc".substring(0, 3), 'a'));
        assertEquals("bcbc", StringUtils.remove("abcabc", 'a'));
        assertNull(StringUtils.remove(null, "a"));
        assertEquals("bc", StringUtils.remove("abc", "a"));
        assertEquals("", StringUtils.remove("abc", "abc"));

        assertEquals("www.domain", StringUtils.removeEnd("www.domain.com", ".com"));
        assertEquals("www.domain.com", StringUtils.removeEnd("www.domain.com", "domain"));
        assertEquals("www.domain", StringUtils.removeEndIgnoreCase("www.domain.COM", ".com"));

        assertEquals("domain.com", StringUtils.removeStart("www.domain.com", "www."));
        assertEquals("www.domain.com", StringUtils.removeStart("www.domain.com", "web."));
        assertEquals("domain.com", StringUtils.removeStartIgnoreCase("WWW.domain.com", "www."));

        assertEquals("bc", StringUtils.removeIgnoreCase("Abc", "A"));
    }

    @Test
    void testRepeat() {
        assertNull(StringUtils.repeat(null, 2));
        assertEquals("", StringUtils.repeat("", 2));
        assertEquals("", StringUtils.repeat("a", 0));
        assertEquals("", StringUtils.repeat("a", -2));
        assertEquals("aaa", StringUtils.repeat("a", 3));
        assertEquals("abab", StringUtils.repeat("ab", 2));
        assertEquals("", StringUtils.repeat('x', -1));
        assertEquals("xxx", StringUtils.repeat('x', 3));
        assertEquals("a-a-a", StringUtils.repeat("a", "-", 3));
    }

    @Test
    void testReplaceFamily() {
        assertNull(StringUtils.replace(null, "a", "b"));
        assertEquals("foobar", StringUtils.replace("fooXbar", "X", ""));
        assertEquals("f.o.o", StringUtils.replace("f.o.o", "X", ""));
        assertEquals("XexXXexXXexXXexX", StringUtils.replace("texttexttexttext", "t", "X"));
        assertEquals("XexXtexttexttext", StringUtils.replace("texttexttexttext", "t", "X", 2));
        assertEquals("texttexttexttext", StringUtils.replace("texttexttexttext", "t", "X", 0));
        assertEquals("texttexttexttext", StringUtils.replace("texttexttexttext", "t", "X", -5));

        assertEquals("bc", StringUtils.replaceOnce("abc", "a", ""));
        assertEquals("aba", StringUtils.replaceOnce("aAa", "A", "b"));
        assertEquals("bc", StringUtils.replaceOnceIgnoreCase("Abc", "a", ""));

        assertEquals("foo", StringUtils.replaceChars("foo", "x", "y"));
        assertEquals("foo", StringUtils.replaceChars("fao", 'a', 'o'));

        assertThrows(IllegalArgumentException.class,
                () -> StringUtils.replaceEach("abcde", new String[] {"ab"}, new String[] {"w", "t"}));
        assertEquals("wcte", StringUtils.replaceEach("abcde", new String[] {"ab", "d"}, new String[] {"w", "t"}));
        assertEquals("b", StringUtils.replaceEachRepeatedly("aba", new String[] {"a"}, new String[] {""}));
    }

    @Test
    void testReverse() {
        assertNull(StringUtils.reverse(null));
        assertEquals("", StringUtils.reverse(""));
        assertEquals("cba", StringUtils.reverse("abc"));
        assertEquals("c.b.a", StringUtils.reverseDelimited("a.b.c", '.'));
    }

    @Test
    void testRotate() {
        assertNull(StringUtils.rotate(null, 1));
        assertEquals("", StringUtils.rotate("", 1));
        assertEquals("abcdefg", StringUtils.rotate("abcdefg", 0));
        assertEquals("fgabcde", StringUtils.rotate("abcdefg", 2));
        assertEquals("cdefgab", StringUtils.rotate("abcdefg", -2));
        assertEquals("abcdefg", StringUtils.rotate("abcdefg", 7));
    }

    @Test
    void testSplit() {
        assertNull(StringUtils.split(null));
        assertArrayEquals(new String[0], StringUtils.split(""));
        assertArrayEquals(new String[] {"abc", "def"}, StringUtils.split("abc def"));
        assertArrayEquals(new String[] {"abc", "def"}, StringUtils.split("abc  def"));
        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.split("a.b.c", '.'));
        assertArrayEquals(new String[] {"a", "b.c"}, StringUtils.split("a.b.c", ".", 2));
        assertArrayEquals(new String[] {"", "a", "", "b", "c", ""}, StringUtils.splitPreserveAllTokens(".a..b.c.", "."));
    }

    @Test
    void testSplitByWholeSeparator() {
        assertNull(StringUtils.splitByWholeSeparator(null, "-"));
        assertArrayEquals(new String[0], StringUtils.splitByWholeSeparator("", "-"));
        assertArrayEquals(new String[] {"ab", "cd", "ef"}, StringUtils.splitByWholeSeparator("ab-!-cd-!-ef", "-!-"));
        assertArrayEquals(new String[] {"ab", "cd-!-ef"}, StringUtils.splitByWholeSeparator("ab-!-cd-!-ef", "-!-", 2));
    }

    @Test
    void testStartsWithFamily() {
        assertTrue(StringUtils.startsWith(null, null));
        assertFalse(StringUtils.startsWith("abcdef", null));
        assertTrue(StringUtils.startsWith("abcdef", "abc"));
        assertFalse(StringUtils.startsWith("ABCDEF", "abc"));
        assertTrue(StringUtils.startsWithIgnoreCase("ABCDEF", "abc"));
        assertTrue(StringUtils.startsWithAny("abcxyz", "xyz", "abc"));
        assertFalse(StringUtils.startsWithAny("abcxyz", "xyz"));
    }

    @Test
    void testStrip() {
        assertNull(StringUtils.strip(null));
        assertEquals("", StringUtils.strip("   "));
        assertEquals("abc", StringUtils.strip("  abc  "));
        assertEquals("abc", StringUtils.strip("xxabcxx", "x"));

        assertEquals("abc  ", StringUtils.stripStart("  abc  ", null));
        assertEquals("  abc", StringUtils.stripEnd("  abc  ", null));

        assertEquals("", StringUtils.stripToEmpty(null));
        assertEquals("abc", StringUtils.stripToEmpty("  abc  "));
        assertNull(StringUtils.stripToNull("   "));
        assertEquals("abc", StringUtils.stripToNull("  abc  "));
    }

    @Test
    void testSubstring() {
        assertNull(StringUtils.substring(null, 0));
        assertEquals("", StringUtils.substring("", 2));
        assertEquals("cde", StringUtils.substring("abcde", 2));
        assertEquals("cde", StringUtils.substring("abcde", -3));
        assertEquals("", StringUtils.substring("abcde", 10));

        assertEquals("bc", StringUtils.substring("abcde", 1, 3));
        assertEquals("abc", StringUtils.substring("abcde", 0, -2));
        assertEquals("", StringUtils.substring("abcde", 4, 2));
    }

    @Test
    void testSubstringAroundFamily() {
        assertNull(StringUtils.substringAfter(null, "a"));
        assertEquals("", StringUtils.substringAfter("", "a"));
        assertEquals("bc", StringUtils.substringAfter("abc", "a"));
        assertEquals("", StringUtils.substringAfter("abc", "z"));
        assertEquals("", StringUtils.substringAfter("abc", (String) null));

        assertEquals("bc", StringUtils.substringAfterLast("abcbc", "a"));
        assertEquals("", StringUtils.substringAfterLast("abc", "c"));

        assertEquals("a", StringUtils.substringBefore("abc", "b"));
        assertEquals("abc", StringUtils.substringBefore("abc", "z"));
        assertNull(StringUtils.substringBefore(null, "a"));

        assertEquals("a", StringUtils.substringBeforeLast("abcbc", "b"));
        assertEquals("", StringUtils.substringBeforeLast("", "a"));

        assertEquals("abc", StringUtils.substringBetween("tagabctag", "tag"));
        assertNull(StringUtils.substringBetween("abc", "x"));
        assertEquals("abc", StringUtils.substringBetween("yabcz", "y", "z"));
        assertNull(StringUtils.substringBetween(null, "x", "y"));

        assertArrayEquals(new String[] {"1", "2"}, StringUtils.substringsBetween("[1][2]", "[", "]"));
        assertNull(StringUtils.substringsBetween("abc", "[", "]"));
    }

    @Test
    void testSwapCase() {
        assertNull(StringUtils.swapCase(null));
        assertEquals("", StringUtils.swapCase(""));
        assertEquals("LOWER", StringUtils.swapCase("lower"));
        assertEquals("upper", StringUtils.swapCase("UPPER"));
        assertEquals("hELLO.wORLD", StringUtils.swapCase("Hello.World"));
    }

    @Test
    void testTrimFamily() {
        assertNull(StringUtils.trim(null));
        assertEquals("", StringUtils.trim("   "));
        assertEquals("abc", StringUtils.trim("  abc  "));

        assertEquals("", StringUtils.trimToEmpty(null));
        assertEquals("abc", StringUtils.trimToEmpty("  abc  "));

        assertNull(StringUtils.trimToNull("   "));
        assertEquals("abc", StringUtils.trimToNull("  abc  "));
    }

    @Test
    void testTruncate() {
        assertNull(StringUtils.truncate(null, 0, 0));
        assertEquals("", StringUtils.truncate("", 0, 10));
        assertEquals("abc", StringUtils.truncate("abcdefghij", 0, 3));
        assertEquals("fghij", StringUtils.truncate("abcdefghij", 5, 6));
        assertEquals("abcdefghij", StringUtils.truncate("abcdefghij", 0, Integer.MAX_VALUE));

        assertThrows(IllegalArgumentException.class, () -> StringUtils.truncate("abcdefghijklmno", -1, 10));
        assertThrows(IllegalArgumentException.class, () -> StringUtils.truncate("abcdefghij", 3, -1));
        assertThrows(IllegalArgumentException.class, () -> StringUtils.truncate("abcdefghij", -2, 4));
    }

    @Test
    void testUnwrapAndWrap() {
        assertNull(StringUtils.unwrap(null, 'x'));
        assertEquals("abc", StringUtils.unwrap("'abc'", '\''));
        assertEquals("abc", StringUtils.unwrap("abc", '\''));
        assertEquals("'abc", StringUtils.unwrap("'abc", '\''));

        assertNull(StringUtils.unwrap(null, "AA"));
        assertEquals("abc", StringUtils.unwrap("AAabcAA", "AA"));
        assertEquals("A", StringUtils.unwrap("A", "#"));

        assertNull(StringUtils.wrap(null, 'x'));
        assertEquals("'abc'", StringUtils.wrap("abc", '\''));
        assertEquals("", StringUtils.wrap("", 'x'));

        assertNull(StringUtils.wrapIfMissing(null, 'x'));
        assertEquals("xabcx", StringUtils.wrapIfMissing("abc", 'x'));
        assertEquals("xabcx", StringUtils.wrapIfMissing("xabcx", 'x'));
    }

    @Test
    void testValueOf() {
        assertNull(StringUtils.valueOf(null));
        assertEquals("abc", StringUtils.valueOf(new char[] {'a', 'b', 'c'}));
        assertEquals("", StringUtils.valueOf(new char[0]));
    }

    @Test
    void testToCodePoints() {
        assertArrayEquals(new int[] {'a', 'b', 'c'}, StringUtils.toCodePoints("abc"));
        assertArrayEquals(new int[0], StringUtils.toCodePoints(""));
        assertNull(StringUtils.toCodePoints(null));
    }

    @Test
    void testAppendPrependIfMissing() {
        assertNull(StringUtils.appendIfMissing(null, "xyz"));
        assertEquals("abcxyz", StringUtils.appendIfMissing("abc", "xyz"));
        assertEquals("abcxyz", StringUtils.appendIfMissing("abcxyz", "xyz"));
        assertEquals("abcXYZ", StringUtils.appendIfMissingIgnoreCase("abcXYZ", "xyz"));

        assertNull(StringUtils.prependIfMissing(null, "xyz"));
        assertEquals("xyzabc", StringUtils.prependIfMissing("abc", "xyz"));
        assertEquals("xyzabc", StringUtils.prependIfMissing("xyzabc", "xyz"));
    }

    @Test
    void testFirstNonBlankEmpty() {
        assertNull(StringUtils.firstNonBlank());
        assertEquals("abc", StringUtils.firstNonBlank(null, "", "  ", "abc"));
        assertNull(StringUtils.firstNonEmpty((String[]) null));
        assertEquals("abc", StringUtils.firstNonEmpty(null, "", "abc"));
    }

    @Test
    void testGetIfBlankEmpty() {
        assertEquals("def", StringUtils.getIfBlank("  ", () -> "def"));
        assertSame("abc", StringUtils.getIfBlank("abc", () -> "def"));
        assertEquals("def", StringUtils.getIfEmpty("", () -> "def"));
        assertSame("abc", StringUtils.getIfEmpty("abc", () -> "def"));
    }
}
