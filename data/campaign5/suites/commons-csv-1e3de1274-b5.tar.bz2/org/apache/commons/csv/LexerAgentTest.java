/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.apache.commons.io.IOUtils.EOF;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link Lexer}.
 */
class LexerAgentTest {

    private Lexer createLexer(final String input, final CSVFormat format) {
        return new Lexer(format, new ExtendedBufferedReader(new StringReader(input)));
    }

    private Token nextToken(final Lexer lexer) throws IOException {
        final Token token = new Token();
        return lexer.nextToken(token);
    }

    @Test
    void testSimpleTokensWithFinalEorecordAtEof() throws IOException {
        final Lexer lexer = createLexer("a,b,c\nd,e,f", CSVFormat.DEFAULT);
        Token token = nextToken(lexer);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a", token.content.toString());

        token = nextToken(lexer);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("b", token.content.toString());

        token = nextToken(lexer);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("c", token.content.toString());

        token = nextToken(lexer);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("d", token.content.toString());

        token = nextToken(lexer);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("e", token.content.toString());

        token = nextToken(lexer);
        assertEquals(Token.Type.EOF, token.type);
        assertEquals("f", token.content.toString());
        assertTrue(token.isReady);

        token = nextToken(lexer);
        assertEquals(Token.Type.EOF, token.type);
        assertEquals("", token.content.toString());
        assertFalse(token.isReady);
        lexer.close();
    }

    @Test
    void testEmptyInputYieldsImmediateEof() throws IOException {
        final Lexer lexer = createLexer("", CSVFormat.DEFAULT);
        final Token token = nextToken(lexer);
        assertEquals(Token.Type.EOF, token.type);
        assertEquals("", token.content.toString());
        assertFalse(token.isReady);
        lexer.close();
    }

    @Test
    void testQuotedTokenWithDoubledQuoteAndDelimiter() throws IOException {
        final Lexer lexer = createLexer("\"ab\"\"cd\",ef", CSVFormat.DEFAULT);
        Token token = nextToken(lexer);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("ab\"cd", token.content.toString());
        assertTrue(token.isQuoted);

        token = nextToken(lexer);
        assertEquals(Token.Type.EOF, token.type);
        assertEquals("ef", token.content.toString());
        assertFalse(token.isQuoted);
        lexer.close();
    }

    @Test
    void testQuotedTokenFollowedByEorecord() throws IOException {
        final Lexer lexer = createLexer("\"hello\"\n", CSVFormat.DEFAULT);
        final Token token = nextToken(lexer);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("hello", token.content.toString());
        lexer.close();
    }

    @Test
    void testUnclosedQuoteNonLenientThrows() throws IOException {
        final Lexer lexer = createLexer("\"abc", CSVFormat.DEFAULT);
        final Token token = new Token();
        final CSVException e = assertThrows(CSVException.class, () -> lexer.nextToken(token));
        assertTrue(e.getMessage().contains("EOF reached before encapsulated token finished"));
        lexer.close();
    }

    @Test
    void testUnclosedQuoteLenientEofReturnsPartialContent() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setLenientEof(true).get();
        final Lexer lexer = createLexer("\"abc", format);
        final Token token = nextToken(lexer);
        assertEquals(Token.Type.EOF, token.type);
        assertEquals("abc", token.content.toString());
        assertTrue(token.isReady);
        lexer.close();
    }

    @Test
    void testInvalidCharAfterEncapsulatedTokenThrowsWithoutTrailingData() throws IOException {
        final Lexer lexer = createLexer("\"abc\"x,d", CSVFormat.DEFAULT);
        final Token token = new Token();
        final CSVException e = assertThrows(CSVException.class, () -> lexer.nextToken(token));
        assertTrue(e.getMessage().contains("Invalid character between encapsulated token and delimiter"));
        lexer.close();
    }

    @Test
    void testTrailingDataAppendsInsteadOfThrowing() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingData(true).get();
        final Lexer lexer = createLexer("\"abc\"x,d", format);
        final Token token = nextToken(lexer);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("abcx", token.content.toString());
        lexer.close();
    }

    @Test
    void testEscapeDelimiterInsideSimpleToken() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer("a\\,b,c", format);
        Token token = nextToken(lexer);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a,b", token.content.toString());

        token = nextToken(lexer);
        assertEquals(Token.Type.EOF, token.type);
        assertEquals("c", token.content.toString());
        lexer.close();
    }

    @Test
    void testEscapeTranslatesControlCharacter() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer("x\\ny", format);
        final Token token = nextToken(lexer);
        assertEquals(Token.Type.EOF, token.type);
        assertEquals("x\ny", token.content.toString());
        lexer.close();
    }

    @Test
    void testEscapeOfUnexpectedCharacterKeepsBothCharacters() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer("a\\zb", format);
        final Token token = nextToken(lexer);
        assertEquals(Token.Type.EOF, token.type);
        assertEquals("a\\zb", token.content.toString());
        lexer.close();
    }

    @Test
    void testEscapeAtEndOfStreamThrows() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer("a\\", format);
        final Token token = new Token();
        final CSVException e = assertThrows(CSVException.class, () -> lexer.nextToken(token));
        assertTrue(e.getMessage().contains("EOF while processing escape sequence"));
        lexer.close();
    }

    @Test
    void testReadEscapeReturnsEofSentinelForUnknownChar() throws IOException {
        // readEscape() assumes the escape character has already been consumed,
        // so the lexer input is just the character following the escape.
        final Lexer lexer = createLexer("z", CSVFormat.DEFAULT);
        final int result = lexer.readEscape();
        assertEquals(EOF, result);
        lexer.close();
    }

    @Test
    void testReadEscapeTranslatesKnownEscapes() throws IOException {
        assertEquals(Constants.CR, createLexer("r", CSVFormat.DEFAULT).readEscape());
        assertEquals(Constants.LF, createLexer("n", CSVFormat.DEFAULT).readEscape());
        assertEquals(Constants.TAB, createLexer("t", CSVFormat.DEFAULT).readEscape());
        assertEquals(Constants.BACKSPACE, createLexer("b", CSVFormat.DEFAULT).readEscape());
        assertEquals(Constants.FF, createLexer("f", CSVFormat.DEFAULT).readEscape());
    }

    @Test
    void testReadEscapeAtEndOfStreamThrowsDirectly() {
        final Lexer lexer = createLexer("", CSVFormat.DEFAULT);
        final CSVException e = assertThrows(CSVException.class, lexer::readEscape);
        assertTrue(e.getMessage().contains("EOF while processing escape sequence"));
    }

    @Test
    void testReadEscapeOfMetaCharacterReturnsItself() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        // The quote char '"' is a meta character and is returned as-is.
        assertEquals('"', createLexer("\"", format).readEscape());
    }

    @Test
    void testCommentLineIsTrimmedAndTyped() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final Lexer lexer = createLexer("a,b\n#  a comment  \nc,d", format);
        Token token = nextToken(lexer);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a", token.content.toString());

        token = nextToken(lexer);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("b", token.content.toString());

        token = nextToken(lexer);
        assertEquals(Token.Type.COMMENT, token.type);
        assertEquals("a comment", token.content.toString());

        token = nextToken(lexer);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("c", token.content.toString());
        lexer.close();
    }

    @Test
    void testCommentAtEofWithContentYieldsComment() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final Lexer lexer = createLexer("#comment", format);
        final Token token = nextToken(lexer);
        assertEquals(Token.Type.COMMENT, token.type);
        assertEquals("comment", token.content.toString());

        final Token next = nextToken(lexer);
        assertEquals(Token.Type.EOF, next.type);
        assertEquals("", next.content.toString());
        lexer.close();
    }

    @Test
    void testIgnoreEmptyLinesSkipsBlankRecords() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreEmptyLines(true).get();
        final Lexer lexer = createLexer("a,b\n\n\nc,d\n", format);
        Token token = nextToken(lexer);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a", token.content.toString());

        token = nextToken(lexer);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("b", token.content.toString());

        token = nextToken(lexer);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("c", token.content.toString());

        token = nextToken(lexer);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("d", token.content.toString());

        token = nextToken(lexer);
        assertEquals(Token.Type.EOF, token.type);
        lexer.close();
    }

    @Test
    void testEmptyLineWithIgnoreEmptyLinesAtVeryEndYieldsEof() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreEmptyLines(true).get();
        final Lexer lexer = createLexer("\n\n", format);
        final Token token = nextToken(lexer);
        assertEquals(Token.Type.EOF, token.type);
        assertEquals("", token.content.toString());
        lexer.close();
    }

    @Test
    void testNotIgnoringEmptyLinesKeepsBlankRecords() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreEmptyLines(false).get();
        final Lexer lexer = createLexer("a\n\nb\n", format);
        Token token = nextToken(lexer);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("a", token.content.toString());

        token = nextToken(lexer);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("", token.content.toString());

        token = nextToken(lexer);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("b", token.content.toString());
        lexer.close();
    }

    @Test
    void testIgnoreSurroundingSpacesTrimsToken() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setIgnoreSurroundingSpaces(true).get();
        final Lexer lexer = createLexer(" a , b \n", format);
        Token token = nextToken(lexer);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a", token.content.toString());

        token = nextToken(lexer);
        assertEquals(Token.Type.EORECORD, token.type);
        assertEquals("b", token.content.toString());
        lexer.close();
    }

    @Test
    void testWithoutIgnoreSurroundingSpacesKeepsSpaces() throws IOException {
        final Lexer lexer = createLexer(" a , b \n", CSVFormat.DEFAULT);
        final Token token = nextToken(lexer);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals(" a ", token.content.toString());
        lexer.close();
    }

    @Test
    void testTrimTrailingSpacesDirectly() {
        final Lexer lexer = createLexer("", CSVFormat.DEFAULT);
        final StringBuilder sb = new StringBuilder("abc   ");
        lexer.trimTrailingSpaces(sb);
        assertEquals("abc", sb.toString());

        final StringBuilder allSpaces = new StringBuilder("   ");
        lexer.trimTrailingSpaces(allSpaces);
        assertEquals("", allSpaces.toString());

        final StringBuilder noTrailing = new StringBuilder("abc");
        lexer.trimTrailingSpaces(noTrailing);
        assertEquals("abc", noTrailing.toString());
    }

    @Test
    void testMultiCharDelimiterIsRecognized() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        final Lexer lexer = createLexer("a::b::c", format);
        Token token = nextToken(lexer);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a", token.content.toString());

        token = nextToken(lexer);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("b", token.content.toString());

        token = nextToken(lexer);
        assertEquals(Token.Type.EOF, token.type);
        assertEquals("c", token.content.toString());
        lexer.close();
    }

    @Test
    void testMultiCharDelimiterPartialMatchIsNotDelimiter() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        final Lexer lexer = createLexer("a:b", format);
        final Token token = nextToken(lexer);
        assertEquals(Token.Type.EOF, token.type);
        assertEquals("a:b", token.content.toString());
        lexer.close();
    }

    @Test
    void testIsDelimiterDirect() throws IOException {
        final Lexer lexer = createLexer(",x", CSVFormat.DEFAULT);
        assertTrue(lexer.isDelimiter(','));
        assertFalse(lexer.isDelimiter('x'));
    }

    @Test
    void testIsEscapeDirect() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get();
        final Lexer lexer = createLexer("", format);
        assertTrue(lexer.isEscape('\\'));
        assertFalse(lexer.isEscape('a'));
        assertFalse(lexer.isEscape(EOF));
    }

    @Test
    void testIsEscapeDisabledByDefault() {
        final Lexer lexer = createLexer("", CSVFormat.DEFAULT);
        assertFalse(lexer.isEscape('\\'));
    }

    @Test
    void testIsQuoteCharDirect() {
        final Lexer lexer = createLexer("", CSVFormat.DEFAULT);
        assertTrue(lexer.isQuoteChar('"'));
        assertFalse(lexer.isQuoteChar('\''));
    }

    @Test
    void testIsCommentStartDirect() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setCommentMarker('#').get();
        final Lexer lexer = createLexer("", format);
        assertTrue(lexer.isCommentStart('#'));
        assertFalse(lexer.isCommentStart('a'));
    }

    @Test
    void testIsCommentStartDisabledByDefault() {
        final Lexer lexer = createLexer("", CSVFormat.DEFAULT);
        assertFalse(lexer.isCommentStart('#'));
    }

    @Test
    void testIsEndOfFileDirect() {
        final Lexer lexer = createLexer("", CSVFormat.DEFAULT);
        assertTrue(lexer.isEndOfFile(EOF));
        assertFalse(lexer.isEndOfFile('a'));
    }

    @Test
    void testIsStartOfLineDirect() {
        final Lexer lexer = createLexer("", CSVFormat.DEFAULT);
        assertTrue(lexer.isStartOfLine(Constants.LF));
        assertTrue(lexer.isStartOfLine(Constants.CR));
        assertTrue(lexer.isStartOfLine(Constants.UNDEFINED));
        assertFalse(lexer.isStartOfLine('a'));
        assertFalse(lexer.isStartOfLine(EOF));
    }

    @Test
    void testReadEndOfLineLfOnly() throws IOException {
        final Lexer lexer = createLexer("\n", CSVFormat.DEFAULT);
        assertTrue(lexer.readEndOfLine(Constants.LF));
        assertEquals("\n", lexer.getFirstEol());
    }

    @Test
    void testReadEndOfLineCrOnly() throws IOException {
        final Lexer lexer = createLexer("x", CSVFormat.DEFAULT);
        assertTrue(lexer.readEndOfLine(Constants.CR));
        assertEquals("\r", lexer.getFirstEol());
    }

    @Test
    void testReadEndOfLineCrLfIsRecordedAsCrLf() throws IOException {
        // The LF immediately following CR in the stream makes this a CRLF line ending.
        final Lexer lexer = createLexer("\n", CSVFormat.DEFAULT);
        assertTrue(lexer.readEndOfLine(Constants.CR));
        assertEquals("\r\n", lexer.getFirstEol());
    }

    @Test
    void testGetFirstEolNullBeforeAnyEol() {
        final Lexer lexer = createLexer("abc", CSVFormat.DEFAULT);
        assertNull(lexer.getFirstEol());
    }

    @Test
    void testCloseAndIsClosed() throws IOException {
        final Lexer lexer = createLexer("abc", CSVFormat.DEFAULT);
        assertFalse(lexer.isClosed());
        lexer.close();
        assertTrue(lexer.isClosed());
    }

    @Test
    void testPositionAndLineNumberAdvance() throws IOException {
        final Lexer lexer = createLexer("a,b\nc,d", CSVFormat.DEFAULT);
        assertEquals(0, lexer.getCurrentLineNumber());
        assertEquals(0, lexer.getCharacterPosition());
        nextToken(lexer); // "a"
        nextToken(lexer); // "b" EORECORD
        assertEquals(1, lexer.getCurrentLineNumber());
        assertTrue(lexer.getCharacterPosition() > 0);
        lexer.close();
    }

    @Test
    void testBytesReadIsZeroWithoutCharsetTracking() throws IOException {
        final Lexer lexer = createLexer("abc", CSVFormat.DEFAULT);
        assertEquals(0, lexer.getBytesRead());
        nextToken(lexer);
        assertEquals(0, lexer.getBytesRead());
        lexer.close();
    }

    @Test
    void testEofWithLastTokenDelimiterYieldsEmptyFinalToken() throws IOException {
        // Input ends with a delimiter: the final field is empty.
        final Lexer lexer = createLexer("a,", CSVFormat.DEFAULT);
        Token token = nextToken(lexer);
        assertEquals(Token.Type.TOKEN, token.type);
        assertEquals("a", token.content.toString());

        token = nextToken(lexer);
        assertEquals(Token.Type.EOF, token.type);
        assertEquals("", token.content.toString());
        lexer.close();
    }
}
