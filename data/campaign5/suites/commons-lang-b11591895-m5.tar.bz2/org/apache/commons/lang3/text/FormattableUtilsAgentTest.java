/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Formattable;
import java.util.FormattableFlags;
import java.util.Formatter;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests for {@link FormattableUtils}.
 */
@Deprecated
class FormattableUtilsAgentTest {

    private static final class SimpleFormattable implements Formattable {
        private final String value;

        SimpleFormattable(final String value) {
            this.value = value;
        }

        @Override
        public void formatTo(final Formatter formatter, final int flags, final int width, final int precision) {
            FormattableUtils.append(value, formatter, flags, width, precision);
        }
    }

    @Test
    void testConstructor() {
        assertEquals(FormattableUtils.class, new FormattableUtils().getClass());
    }

    @Test
    void testAppendNoWidthNoPrecision() {
        final Formatter formatter = new Formatter();
        final Formatter result = FormattableUtils.append("abc", formatter, 0, -1, -1);
        assertSame(formatter, result);
        assertEquals("abc", formatter.toString());
    }

    @Test
    void testAppendPadsWithSpacesByDefault() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("ab", formatter, 0, 5, -1);
        assertEquals("   ab", formatter.toString());
    }

    @Test
    void testAppendLeftJustify() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("ab", formatter, FormattableFlags.LEFT_JUSTIFY, 5, -1);
        assertEquals("ab   ", formatter.toString());
    }

    @Test
    void testAppendCustomPadChar() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("ab", formatter, 0, 5, -1, '*');
        assertEquals("***ab", formatter.toString());
    }

    @Test
    void testAppendCustomPadCharLeftJustify() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("ab", formatter, FormattableFlags.LEFT_JUSTIFY, 5, -1, '*');
        assertEquals("ab***", formatter.toString());
    }

    @Test
    void testAppendWidthSmallerThanLengthDoesNoPadding() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("abcdef", formatter, 0, 3, -1);
        assertEquals("abcdef", formatter.toString());
    }

    @Test
    void testAppendPrecisionTruncatesHard() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("abcdef", formatter, 0, -1, 3);
        assertEquals("abc", formatter.toString());
    }

    @Test
    void testAppendPrecisionEqualToLengthDoesNotTruncate() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("abc", formatter, 0, -1, 3);
        assertEquals("abc", formatter.toString());
    }

    @Test
    void testAppendPrecisionGreaterThanLengthDoesNotTruncate() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("abc", formatter, 0, -1, 10);
        assertEquals("abc", formatter.toString());
    }

    @Test
    void testAppendNegativePrecisionDoesNotTruncate() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("abcdef", formatter, 0, -1, -1);
        assertEquals("abcdef", formatter.toString());
    }

    @Test
    void testAppendWithEllipsis() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("abcdef", formatter, 0, -1, 4, "...");
        assertEquals("a...", formatter.toString());
    }

    @Test
    void testAppendWithEllipsisExactPrecision() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("abcdef", formatter, 0, -1, 3, "...");
        assertEquals("...", formatter.toString());
    }

    @Test
    void testAppendWithNullEllipsisIsHardTruncation() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("abcdef", formatter, 0, -1, 3, (CharSequence) null);
        assertEquals("abc", formatter.toString());
    }

    @Test
    void testAppendEllipsisExceedingPrecisionThrows() {
        final Formatter formatter = new Formatter();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                FormattableUtils.append("abcdef", formatter, 0, -1, 2, "...");
            }
        });
    }

    @Test
    void testAppendEllipsisEqualToPrecisionDoesNotThrow() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("abcdef", formatter, 0, -1, 3, "...");
        assertEquals("...", formatter.toString());
    }

    @Test
    void testAppendFullSignatureWithEllipsisAndPadding() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("abcdef", formatter, FormattableFlags.LEFT_JUSTIFY, 8, 4, '-', "...");
        assertEquals("a...----", formatter.toString());
    }

    @Test
    void testAppendFullSignatureRightJustifyWithEllipsis() {
        final Formatter formatter = new Formatter();
        FormattableUtils.append("abcdef", formatter, 0, 8, 4, '-', "...");
        assertEquals("----a...", formatter.toString());
    }

    @Test
    void testToStringUsesFormattableImplementation() {
        final Formattable formattable = new SimpleFormattable("hello");
        assertEquals("hello", FormattableUtils.toString(formattable));
    }

    @Test
    void testToStringEmptyValue() {
        final Formattable formattable = new SimpleFormattable("");
        assertEquals("", FormattableUtils.toString(formattable));
    }

}
