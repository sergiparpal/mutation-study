/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringWriter;

import org.apache.commons.csv.CSVFormat.Builder;
import org.junit.jupiter.api.Test;

/**
 * Tests {@link CSVFormat}.
 */
class CSVFormatAgentTest {

    public enum AgentHeader {
        Col1, Col2, Col3
    }

    @Test
    void testDefaultFormatDefaults() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertEquals(",", format.getDelimiterString());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertTrue(format.getIgnoreEmptyLines());
        assertFalse(format.getTrim());
        assertFalse(format.isCommentMarkerSet());
        assertFalse(format.isEscapeCharacterSet());
        assertNull(format.getHeader());
    }

    @Test
    void testNewFormatMinimalState() {
        final CSVFormat format = CSVFormat.newFormat(';');
        assertEquals(";", format.getDelimiterString());
        assertNull(format.getQuoteCharacter());
        assertNull(format.getRecordSeparator());
        assertFalse(format.getIgnoreEmptyLines());
        assertFalse(format.isQuoteCharacterSet());
    }

    @Test
    void testBuilderSetDelimiterCharAndString() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDelimiter('|').get();
        assertEquals("|", format.getDelimiterString());
        assertEquals('|', format.getDelimiter());

        final CSVFormat multi = CSVFormat.DEFAULT.builder().setDelimiter("::").get();
        assertEquals("::", multi.getDelimiterString());
    }

    @Test
    void testBuilderSetDelimiterRejectsEmptyAndLineBreak() {
        final Builder builder = CSVFormat.DEFAULT.builder();
        assertThrows(IllegalArgumentException.class, () -> builder.setDelimiter(""));
        assertThrows(IllegalArgumentException.class, () -> builder.setDelimiter("\n"));
        assertThrows(IllegalArgumentException.class, () -> builder.setDelimiter('\r'));
    }

    @Test
    void testBuilderSetCommentMarkerRejectsLineBreak() {
        final Builder builder = CSVFormat.DEFAULT.builder();
        assertThrows(IllegalArgumentException.class, () -> builder.setCommentMarker('\n'));
        assertThrows(IllegalArgumentException.class, () -> builder.setCommentMarker('\r'));
    }

    @Test
    void testBuilderSetEscapeRejectsLineBreak() {
        final Builder builder = CSVFormat.DEFAULT.builder();
        assertThrows(IllegalArgumentException.class, () -> builder.setEscape('\n'));
    }

    @Test
    void testBuilderSetQuoteRejectsLineBreak() {
        final Builder builder = CSVFormat.DEFAULT.builder();
        assertThrows(IllegalArgumentException.class, () -> builder.setQuote('\r'));
    }

    @Test
    void testValidateQuoteCharSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setDelimiter(',').setQuote(',').get());
    }

    @Test
    void testValidateEscapeSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setDelimiter(',').setEscape(',').get());
    }

    @Test
    void testValidateCommentMarkerSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setDelimiter(',').setCommentMarker(',').get());
    }

    @Test
    void testValidateQuoteSameAsCommentMarkerThrows() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setQuote('#').setCommentMarker('#').get());
    }

    @Test
    void testValidateEscapeSameAsCommentMarkerThrows() {
        assertThrows(IllegalArgumentException.class,
                () -> CSVFormat.DEFAULT.builder().setQuote(null).setEscape('#').setCommentMarker('#').get());
    }

    @Test
    void testValidateQuoteModeNoneRequiresEscape() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.DEFAULT.builder().setQuoteMode(QuoteMode.NONE).get());
        // With escape set, it is allowed.
        final CSVFormat ok = CSVFormat.DEFAULT.builder().setEscape('\\').setQuoteMode(QuoteMode.NONE).get();
        assertEquals(QuoteMode.NONE, ok.getQuoteMode());
    }

    @Test
    void testValidateDuplicateHeaderNamesDisallowed() {
        assertThrows(IllegalArgumentException.class,
                () -> CSVFormat.DEFAULT.builder().setHeader("a", "b", "a").setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).get());
        // Allowed when mode is ALLOW_ALL (the default created by Builder.create()).
        final CSVFormat ok = CSVFormat.DEFAULT.builder().setHeader("a", "b", "a").get();
        assertArrayEquals(new String[] {"a", "b", "a"}, ok.getHeader());
    }

    @Test
    void testValidateDuplicateEmptyHeadersAllowedWithAllowEmptyMode() {
        final CSVFormat ok = CSVFormat.DEFAULT.builder().setHeader("a", "", "").setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).get();
        assertArrayEquals(new String[] {"a", "", ""}, ok.getHeader());
        assertThrows(IllegalArgumentException.class,
                () -> CSVFormat.DEFAULT.builder().setHeader("a", "a").setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).get());
    }

    @Test
    void testGetHeaderReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "b").get();
        final String[] header1 = format.getHeader();
        header1[0] = "mutated";
        final String[] header2 = format.getHeader();
        assertEquals("a", header2[0]);
    }

    @Test
    void testGetHeaderCommentsReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeaderComments("c1", "c2").get();
        final String[] comments1 = format.getHeaderComments();
        comments1[0] = "mutated";
        final String[] comments2 = format.getHeaderComments();
        assertEquals("c1", comments2[0]);
    }

    @Test
    void testSetHeaderFromEnum() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(AgentHeader.class).get();
        assertArrayEquals(new String[] {"Col1", "Col2", "Col3"}, format.getHeader());
    }

    @Test
    void testSetHeaderFromNullEnumDisablesHeader() {
        final Class<? extends Enum<?>> nullClass = null;
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(nullClass).get();
        assertNull(format.getHeader());
    }

    @Test
    void testSetHeaderEmptyMeansParseFromFile() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().get();
        assertNotNull(format.getHeader());
        assertEquals(0, format.getHeader().length);
    }

    @Test
    void testFormatValues() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertEquals("a,b,c", format.format("a", "b", "c"));
    }

    @Test
    void testFormatValuesWithQuoting() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertEquals("a,\"b,c\",d", format.format("a", "b,c", "d"));
    }

    @Test
    void testFormatNullValueUsesEmptyStringByDefault() {
        assertEquals(",a", CSVFormat.DEFAULT.format(null, "a"));
    }

    @Test
    void testFormatNullValueUsesNullStringWhenSet() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        assertEquals("NULL,a", format.format(null, "a"));
    }

    @Test
    void testPrintRecordAndPrintlnTrailingDelimiter() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).setRecordSeparator("\n").get();
        final StringWriter writer = new StringWriter();
        format.printRecord(writer, "a", "b");
        assertEquals("a,b,\n", writer.toString());
    }

    @Test
    void testPrintSingleValueNotNewRecordAddsDelimiter() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT;
        final StringWriter writer = new StringWriter();
        format.print("x", writer, false);
        assertEquals(",x", writer.toString());
    }

    @Test
    void testPrintTrimsValueWhenTrimEnabled() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrim(true).get();
        final StringWriter writer = new StringWriter();
        format.print("  spaced  ", writer, true);
        assertEquals("spaced", writer.toString());
    }

    @Test
    void testPrintlnWithNoRecordSeparatorWritesNothing() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setRecordSeparator((String) null).get();
        final StringWriter writer = new StringWriter();
        format.println(writer);
        assertEquals("", writer.toString());
    }

    @Test
    void testEqualsAndHashCode() {
        final CSVFormat format1 = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        final CSVFormat format2 = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        final CSVFormat format3 = CSVFormat.DEFAULT.builder().setDelimiter(',').get();
        assertEquals(format1, format2);
        assertEquals(format1.hashCode(), format2.hashCode());
        assertNotEquals(format1, format3);
        assertNotEquals(format1, null);
        assertNotEquals(format1, "not a CSVFormat");
        assertEquals(format1, format1);
    }

    @Test
    void testBuilderCopiesExistingFormat() {
        final CSVFormat original = CSVFormat.DEFAULT.builder().setDelimiter(';').setQuote('\'').setTrim(true).get();
        final CSVFormat copy = original.builder().get();
        assertEquals(original, copy);
        assertNotEquals(original.getClass(), null);
    }

    @Test
    void testToStringContainsConfiguredAttributes() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').setCommentMarker('#').setNullString("NULL").get();
        final String str = format.toString();
        assertTrue(str.contains("Delimiter=<,>"));
        assertTrue(str.contains("Escape=<\\>"));
        assertTrue(str.contains("QuoteChar=<\">"));
        assertTrue(str.contains("CommentStart=<#>"));
        assertTrue(str.contains("NullString=<NULL>"));
    }

    @Test
    void testValueOfPredefinedFormats() {
        assertEquals(CSVFormat.EXCEL, CSVFormat.valueOf("Excel"));
        assertEquals(CSVFormat.RFC4180, CSVFormat.valueOf("RFC4180"));
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.valueOf("DoesNotExist"));
    }

    @Test
    void testPredefinedEnumGetFormat() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.Predefined.Default.getFormat());
        assertEquals(CSVFormat.TDF, CSVFormat.Predefined.TDF.getFormat());
    }

    @Test
    void testExcelFormatSettings() {
        final CSVFormat format = CSVFormat.EXCEL;
        assertFalse(format.getIgnoreEmptyLines());
        assertTrue(format.getAllowMissingColumnNames());
        assertTrue(format.getTrailingData());
        assertTrue(format.getLenientEof());
    }

    @Test
    void testMySqlFormatSettings() {
        final CSVFormat format = CSVFormat.MYSQL;
        assertEquals("\t", format.getDelimiterString());
        assertNull(format.getQuoteCharacter());
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
        assertEquals("\\N", format.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, format.getQuoteMode());
    }

    @Test
    void testGetMaxRowsDefaultAndUseMaxRows() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertEquals(0, format.getMaxRows());
        final CSVFormat limited = format.builder().setMaxRows(5).get();
        assertEquals(5, limited.getMaxRows());
    }

    @Test
    void testIsQuoteCharacterSetAndEscapeCharacterSet() {
        final CSVFormat quoted = CSVFormat.DEFAULT;
        assertTrue(quoted.isQuoteCharacterSet());
        assertFalse(quoted.isEscapeCharacterSet());

        final CSVFormat unquoted = CSVFormat.DEFAULT.builder().setQuote((Character) null).get();
        assertFalse(unquoted.isQuoteCharacterSet());
    }

    @Test
    void testIsNullStringSet() {
        assertFalse(CSVFormat.DEFAULT.isNullStringSet());
        assertTrue(CSVFormat.DEFAULT.builder().setNullString("N/A").get().isNullStringSet());
    }

    @Test
    void testGetAllowDuplicateHeaderNamesDeprecatedMapsToMode() {
        final CSVFormat allowAll = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_ALL).get();
        assertTrue(allowAll.getAllowDuplicateHeaderNames());
        final CSVFormat disallow = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).get();
        assertFalse(disallow.getAllowDuplicateHeaderNames());
    }

    @Test
    void testWithDelimiterDeprecatedMethod() {
        final CSVFormat format = CSVFormat.DEFAULT.withDelimiter('|');
        assertEquals("|", format.getDelimiterString());
    }

    @Test
    void testSetDuplicateHeaderModeRejectsNull() {
        assertThrows(NullPointerException.class, () -> CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(null));
    }

    @Test
    void testNewFormatRejectsLineBreakDelimiter() {
        assertThrows(IllegalArgumentException.class, () -> CSVFormat.newFormat('\n'));
    }
}
