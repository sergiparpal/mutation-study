/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.text.FieldPosition;
import java.text.Format;
import java.text.MessageFormat;
import java.text.ParsePosition;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests {@link ExtendedMessageFormat}.
 */
@Deprecated
class ExtendedMessageFormatAgentTest {

    /**
     * Format that upper-cases the argument and optionally appends a suffix
     * supplied as the "format style" argument.
     */
    private static final class UpperCaseFormat extends Format {
        private static final long serialVersionUID = 1L;
        private final String suffix;

        UpperCaseFormat(final String suffix) {
            this.suffix = suffix;
        }

        @Override
        public StringBuffer format(final Object obj, final StringBuffer toAppendTo, final FieldPosition pos) {
            toAppendTo.append(String.valueOf(obj).toUpperCase(Locale.ROOT));
            if (suffix != null) {
                toAppendTo.append(suffix);
            }
            return toAppendTo;
        }

        @Override
        public Object parseObject(final String source, final ParsePosition pos) {
            return source;
        }

        @Override
        public boolean equals(final Object obj) {
            return obj instanceof UpperCaseFormat
                    && java.util.Objects.equals(suffix, ((UpperCaseFormat) obj).suffix);
        }

        @Override
        public int hashCode() {
            return java.util.Objects.hashCode(suffix);
        }
    }

    /**
     * Format that ignores its input and always emits the same fixed text.
     * Used to demonstrate overriding a built-in format name such as "date".
     */
    private static final class FixedTextFormat extends Format {
        private static final long serialVersionUID = 1L;
        private final String text;

        FixedTextFormat(final String text) {
            this.text = text;
        }

        @Override
        public StringBuffer format(final Object obj, final StringBuffer toAppendTo, final FieldPosition pos) {
            return toAppendTo.append(text);
        }

        @Override
        public Object parseObject(final String source, final ParsePosition pos) {
            return text;
        }

        @Override
        public boolean equals(final Object obj) {
            return obj instanceof FixedTextFormat
                    && java.util.Objects.equals(text, ((FixedTextFormat) obj).text);
        }

        @Override
        public int hashCode() {
            return java.util.Objects.hashCode(text);
        }
    }

    private static final class UpperCaseFormatFactory implements FormatFactory {
        @Override
        public Format getFormat(final String name, final String arguments, final Locale locale) {
            if ("upper".equals(name)) {
                return new UpperCaseFormat(arguments);
            }
            return null;
        }
    }

    private static final class FixedDateFormatFactory implements FormatFactory {
        @Override
        public Format getFormat(final String name, final String arguments, final Locale locale) {
            if ("date".equals(name)) {
                return new FixedTextFormat("CUSTOMDATE");
            }
            return null;
        }
    }

    private static void assertThrowsWithMessageContaining(final Class<? extends Throwable> expectedType,
            final Executable executable, final String expectedSubstring) {
        final Throwable t = assertThrows(expectedType, executable);
        assertNotNull(t.getMessage());
        assertTrue(t.getMessage().contains(expectedSubstring),
                "Expected message to contain [" + expectedSubstring + "] but was [" + t.getMessage() + "]");
    }

    @Test
    void testFormatWithoutRegistry() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0} and {1}", Locale.US);
        assertEquals("foo and bar", emf.format(new Object[] {"foo", "bar"}));
        assertEquals("{0} and {1}", emf.toPattern());
    }

    @Test
    void testDefaultLocaleConstructor() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertEquals(Locale.getDefault(), emf.getLocale());
        assertEquals("abc", emf.format(new Object[] {"abc"}));
    }

    @Test
    void testNullLocaleDefaultsToSystemDefault() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", (Locale) null, null);
        assertEquals(Locale.getDefault(), emf.getLocale());
    }

    @Test
    void testRegistryCustomFormatWithArguments() {
        final Map<String, FormatFactory> registry = new HashMap<String, FormatFactory>();
        registry.put("upper", new UpperCaseFormatFactory());
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper,!}", registry);
        assertEquals("ABC!", emf.format(new Object[] {"abc"}));
        assertEquals("{0,upper,!}", emf.toPattern());
    }

    @Test
    void testRegistryCustomFormatWithoutArguments() {
        final Map<String, FormatFactory> registry = new HashMap<String, FormatFactory>();
        registry.put("upper", new UpperCaseFormatFactory());
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", registry);
        assertEquals("ABC", emf.format(new Object[] {"abc"}));
        assertEquals("{0,upper}", emf.toPattern());
    }

    @Test
    void testRegistryOverridesBuiltInFormatName() {
        final Map<String, FormatFactory> registry = new HashMap<String, FormatFactory>();
        registry.put("date", new FixedDateFormatFactory());
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,date}", registry);
        assertEquals("CUSTOMDATE", emf.format(new Object[] {"ignored"}));
    }

    @Test
    void testUnregisteredFormatNameNotMatchingBuiltInThrowsIllegalArgumentException() {
        final Map<String, FormatFactory> registry = new HashMap<String, FormatFactory>();
        registry.put("upper", new UpperCaseFormatFactory());
        // "unknown" is in neither the registry nor the set of built-in MessageFormat
        // type names ("number", "date", "time", "choice"), so parsing delegates to
        // java.text.MessageFormat, which rejects it.
        assertThrowsWithMessageContaining(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{0,unknown}", registry);
            }
        }, "unknown format type");
    }

    @Test
    void testQuotedLiteralBracesAreNotTreatedAsFormatElements() {
        final Map<String, FormatFactory> registry = new HashMap<String, FormatFactory>();
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("'{0}'", registry);
        assertEquals("{0}", emf.format(new Object[] {"ignored"}));
    }

    @Test
    void testMultipleArgumentsMixedCustomAndPlain() {
        final Map<String, FormatFactory> registry = new HashMap<String, FormatFactory>();
        registry.put("upper", new UpperCaseFormatFactory());
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper} - {1}", registry);
        assertEquals("ABC - xyz", emf.format(new Object[] {"abc", "xyz"}));
    }

    @Test
    void testEqualsAndHashCodeForEquivalentInstances() {
        final ExtendedMessageFormat a = new ExtendedMessageFormat("{0} and {1}", Locale.US);
        final ExtendedMessageFormat b = new ExtendedMessageFormat("{0} and {1}", Locale.US);
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    void testEqualsForEquivalentRegistries() {
        final FormatFactory factory = new UpperCaseFormatFactory();
        final Map<String, FormatFactory> registry1 = new HashMap<String, FormatFactory>();
        registry1.put("upper", factory);
        final Map<String, FormatFactory> registry2 = new HashMap<String, FormatFactory>();
        registry2.put("upper", factory);
        final ExtendedMessageFormat a = new ExtendedMessageFormat("{0,upper}", registry1);
        final ExtendedMessageFormat b = new ExtendedMessageFormat("{0,upper}", registry2);
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    void testEqualsFalseForDifferentPattern() {
        final ExtendedMessageFormat a = new ExtendedMessageFormat("{0} and {1}", Locale.US);
        final ExtendedMessageFormat c = new ExtendedMessageFormat("{0} or {1}", Locale.US);
        assertNotEquals(a, c);
    }

    @Test
    void testEqualsFalseForPlainMessageFormat() {
        final ExtendedMessageFormat a = new ExtendedMessageFormat("{0} and {1}", Locale.US);
        final MessageFormat plain = new MessageFormat("{0} and {1}", Locale.US);
        assertFalse(a.equals(plain));
    }

    @Test
    void testEqualsFalseForNull() {
        final ExtendedMessageFormat a = new ExtendedMessageFormat("{0}", Locale.US);
        assertFalse(a.equals(null));
    }

    @Test
    void testEqualsReflexive() {
        final ExtendedMessageFormat a = new ExtendedMessageFormat("{0}", Locale.US);
        assertTrue(a.equals(a));
    }

    @Test
    void testSetFormatThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                emf.setFormat(0, null);
            }
        });
    }

    @Test
    void testSetFormatByArgumentIndexThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                emf.setFormatByArgumentIndex(0, null);
            }
        });
    }

    @Test
    void testSetFormatsThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                emf.setFormats(new Format[0]);
            }
        });
    }

    @Test
    void testSetFormatsByArgumentIndexThrowsUnsupportedOperationException() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() {
                emf.setFormatsByArgumentIndex(new Format[0]);
            }
        });
    }

    @Test
    void testUnterminatedQuotedStringThrowsIllegalArgumentException() {
        final Map<String, FormatFactory> registry = new HashMap<String, FormatFactory>();
        assertThrowsWithMessageContaining(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("'abc", registry);
            }
        }, "Unterminated quoted string");
    }

    @Test
    void testUnterminatedFormatElementThrowsIllegalArgumentException() {
        final Map<String, FormatFactory> registry = new HashMap<String, FormatFactory>();
        assertThrowsWithMessageContaining(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{0", registry);
            }
        }, "Unterminated format element");
    }

    @Test
    void testInvalidArgumentIndexThrowsIllegalArgumentException() {
        final Map<String, FormatFactory> registry = new HashMap<String, FormatFactory>();
        assertThrowsWithMessageContaining(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat("{0a}", registry);
            }
        }, "Invalid format argument index");
    }

    @Test
    void testNullPatternThrowsNullPointerExceptionWithoutRegistry() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat(null, Locale.US);
            }
        });
    }

    @Test
    void testNullPatternThrowsNullPointerExceptionWithRegistry() {
        final Map<String, FormatFactory> registry = new HashMap<String, FormatFactory>();
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                new ExtendedMessageFormat(null, Locale.US, registry);
            }
        });
    }

    @Test
    void testEmptyPatternProducesEmptyOutput() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("");
        assertEquals("", emf.format(new Object[0]));
        assertEquals("", emf.toPattern());
    }

    @Test
    void testToPatternWithoutCustomFormatsMatchesNormalizedPattern() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{1} then {0}", Locale.US);
        assertEquals("{1} then {0}", emf.toPattern());
        assertEquals("bar then foo", emf.format(new Object[] {"foo", "bar"}));
    }

    @Test
    void testRegistryConstructorDefaultLocale() {
        final Map<String, FormatFactory> registry = new HashMap<String, FormatFactory>();
        registry.put("upper", new UpperCaseFormatFactory());
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", registry);
        assertEquals(Locale.getDefault(), emf.getLocale());
    }

    @Test
    void testDoubleApplyPatternReplacesPreviousPattern() {
        final Map<String, FormatFactory> registry = new HashMap<String, FormatFactory>();
        registry.put("upper", new UpperCaseFormatFactory());
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", registry);
        emf.applyPattern("{0}");
        assertEquals("{0}", emf.toPattern());
        assertEquals("abc", emf.format(new Object[] {"abc"}));
    }

    @Test
    void testUnsupportedSettersDoNotThrowOtherExceptionTypes() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        try {
            emf.setFormat(0, null);
            fail("Expected UnsupportedOperationException");
        } catch (final UnsupportedOperationException expected) {
            // expected
        }
    }
}
