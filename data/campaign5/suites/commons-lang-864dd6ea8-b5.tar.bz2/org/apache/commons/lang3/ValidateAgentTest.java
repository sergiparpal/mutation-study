/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Constructor;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests {@link Validate}.
 */
class ValidateAgentTest {

    // exclusiveBetween

    @Test
    void exclusiveBetweenDoubleWithinRangeDoesNotThrow() {
        Validate.exclusiveBetween(0.1, 2.1, 1.1);
    }

    @Test
    void exclusiveBetweenDoubleAtLowerBoundThrowsWithDefaultMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.exclusiveBetween(0.1, 2.1, 0.1);
            }
        });
        assertEquals("The value 0.1 is not in the specified exclusive range of 0.1 to 2.1", ex.getMessage());
    }

    @Test
    void exclusiveBetweenDoubleAtUpperBoundThrowsWithGivenMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.exclusiveBetween(0.1, 2.1, 2.1, "MSG");
            }
        });
        assertEquals("MSG", ex.getMessage());
    }

    @Test
    void exclusiveBetweenLongWithinRangeDoesNotThrow() {
        Validate.exclusiveBetween(0L, 2L, 1L);
    }

    @Test
    void exclusiveBetweenLongOutOfRangeThrowsWithDefaultMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.exclusiveBetween(0L, 2L, 3L);
            }
        });
        assertEquals("The value 3 is not in the specified exclusive range of 0 to 2", ex.getMessage());
    }

    @Test
    void exclusiveBetweenLongOutOfRangeThrowsWithGivenMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.exclusiveBetween(0L, 2L, -1L, "MSG");
            }
        });
        assertEquals("MSG", ex.getMessage());
    }

    @Test
    void exclusiveBetweenComparableWithinRangeDoesNotThrow() {
        Validate.exclusiveBetween("a", "c", "b");
    }

    @Test
    void exclusiveBetweenComparableAtBoundThrowsWithDefaultMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.exclusiveBetween("a", "c", "a");
            }
        });
        assertEquals("The value a is not in the specified exclusive range of a to c", ex.getMessage());
    }

    @Test
    void exclusiveBetweenComparableOutOfRangeThrowsWithFormattedMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.exclusiveBetween("a", "c", "d", "Error %s", "X");
            }
        });
        assertEquals("Error X", ex.getMessage());
    }

    // finite

    @Test
    void finiteValueDoesNotThrow() {
        Validate.finite(1.0);
    }

    @Test
    void finiteNaNThrowsWithDefaultMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.finite(Double.NaN);
            }
        });
        assertEquals("The value is invalid: NaN", ex.getMessage());
    }

    @Test
    void finitePositiveInfinityThrowsWithGivenMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.finite(Double.POSITIVE_INFINITY, "MSG");
            }
        });
        assertEquals("MSG", ex.getMessage());
    }

    @Test
    void finiteNegativeInfinityThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.finite(Double.NEGATIVE_INFINITY);
            }
        });
    }

    // inclusiveBetween

    @Test
    void inclusiveBetweenDoubleAtBoundsDoesNotThrow() {
        Validate.inclusiveBetween(0.1, 2.1, 0.1);
        Validate.inclusiveBetween(0.1, 2.1, 2.1);
    }

    @Test
    void inclusiveBetweenDoubleOutOfRangeThrowsWithDefaultMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.inclusiveBetween(0.1, 2.1, 2.2);
            }
        });
        assertEquals("The value 2.2 is not in the specified inclusive range of 0.1 to 2.1", ex.getMessage());
    }

    @Test
    void inclusiveBetweenLongAtBoundsDoesNotThrow() {
        Validate.inclusiveBetween(1L, 3L, 1L);
        Validate.inclusiveBetween(1L, 3L, 3L);
    }

    @Test
    void inclusiveBetweenLongOutOfRangeThrowsWithGivenMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.inclusiveBetween(1L, 3L, 4L, "MSG");
            }
        });
        assertEquals("MSG", ex.getMessage());
    }

    @Test
    void inclusiveBetweenComparableAtBoundsDoesNotThrow() {
        Validate.inclusiveBetween("a", "c", "a");
        Validate.inclusiveBetween("a", "c", "c");
    }

    @Test
    void inclusiveBetweenComparableOutOfRangeThrowsWithDefaultMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.inclusiveBetween("a", "c", "d");
            }
        });
        assertEquals("The value d is not in the specified inclusive range of a to c", ex.getMessage());
    }

    // isAssignableFrom

    @Test
    void isAssignableFromValidDoesNotThrow() {
        Validate.isAssignableFrom(CharSequence.class, String.class);
    }

    @Test
    void isAssignableFromInvalidThrowsWithDefaultMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.isAssignableFrom(List.class, String.class);
            }
        });
        assertEquals("Cannot assign a java.lang.String to a java.util.List", ex.getMessage());
    }

    @Test
    void isAssignableFromNullTypeThrowsWithDefaultMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.isAssignableFrom(List.class, null);
            }
        });
        assertEquals("Cannot assign a null type to a java.util.List", ex.getMessage());
    }

    @Test
    void isAssignableFromInvalidThrowsWithGivenMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.isAssignableFrom(List.class, String.class, "MSG");
            }
        });
        assertEquals("MSG", ex.getMessage());
    }

    // isInstanceOf

    @Test
    void isInstanceOfValidDoesNotThrow() {
        Validate.isInstanceOf(String.class, "hi");
    }

    @Test
    void isInstanceOfInvalidThrowsWithDefaultMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.isInstanceOf(List.class, "hi");
            }
        });
        assertEquals("Expected type: java.util.List, actual: java.lang.String", ex.getMessage());
    }

    @Test
    void isInstanceOfInvalidThrowsWithFormattedMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.isInstanceOf(List.class, "hi", "Error %s=%s", "Name", "Value");
            }
        });
        assertEquals("Error Name=Value", ex.getMessage());
    }

    // isTrue

    @Test
    void isTrueForTrueExpressionDoesNotThrow() {
        Validate.isTrue(true);
    }

    @Test
    void isTrueForFalseExpressionThrowsWithDefaultMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.isTrue(false);
            }
        });
        assertEquals("The validated expression is false", ex.getMessage());
    }

    @Test
    void isTrueWithDoubleTemplateInsertsValueWhenFalse() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.isTrue(false, "MSG %s", 7.4d);
            }
        });
        assertEquals("MSG 7.4", ex.getMessage());
    }

    @Test
    void isTrueWithLongTemplateInsertsValueWhenFalse() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.isTrue(false, "MSG %s", 6L);
            }
        });
        assertEquals("MSG 6", ex.getMessage());
    }

    @Test
    void isTrueWithObjectVarargsInsertsValuesWhenFalse() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.isTrue(false, "MSG %s %s", "Object 1", "Object 2");
            }
        });
        assertEquals("MSG Object 1 Object 2", ex.getMessage());
    }

    @Test
    void isTrueWithMessageSupplierUsesSuppliedMessageWhenFalse() {
        final Supplier<String> supplier = new Supplier<String>() {
            @Override
            public String get() {
                return "SUPPLIED";
            }
        };
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.isTrue(false, supplier);
            }
        });
        assertEquals("SUPPLIED", ex.getMessage());
    }

    @Test
    void isTrueWithMessageSupplierForTrueExpressionDoesNotThrow() {
        final Supplier<String> supplier = new Supplier<String>() {
            @Override
            public String get() {
                return "SUPPLIED";
            }
        };
        Validate.isTrue(true, supplier);
    }

    // matchesPattern

    @Test
    void matchesPatternValidDoesNotThrow() {
        Validate.matchesPattern("hi", "[a-z]*");
    }

    @Test
    void matchesPatternInvalidThrowsWithDefaultMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.matchesPattern("hi", "[0-9]*");
            }
        });
        assertEquals("The string hi does not match the pattern [0-9]*", ex.getMessage());
    }

    @Test
    void matchesPatternInvalidThrowsWithGivenMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.matchesPattern("hi", "[0-9]*", "MSG");
            }
        });
        assertEquals("MSG", ex.getMessage());
    }

    // noNullElements (array)

    @Test
    void noNullElementsArrayReturnsSameInstance() {
        final String[] array = {"a", "b"};
        assertSame(array, Validate.noNullElements(array));
    }

    @Test
    void noNullElementsArrayWithNullElementThrowsWithDefaultMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.noNullElements(new String[] {"a", null});
            }
        });
        assertEquals("The validated array contains null element at index: 1", ex.getMessage());
    }

    @Test
    void noNullElementsNullArrayThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Validate.noNullElements((Object[]) null);
            }
        });
    }

    @Test
    void noNullElementsArrayWithNullElementThrowsWithGivenMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.noNullElements(new String[] {"a", null}, "MSG");
            }
        });
        assertEquals("MSG", ex.getMessage());
    }

    // noNullElements (iterable)

    @Test
    void noNullElementsIterableReturnsSameInstance() {
        final List<String> list = new ArrayList<String>();
        list.add("a");
        assertSame(list, Validate.noNullElements(list));
    }

    @Test
    void noNullElementsIterableWithNullElementThrowsWithDefaultMessage() {
        final List<String> list = new ArrayList<String>();
        list.add("a");
        list.add(null);
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.noNullElements(list);
            }
        });
        assertEquals("The validated collection contains null element at index: 0", ex.getMessage());
    }

    @Test
    void noNullElementsNullIterableThrowsNullPointerException() {
        final NullPointerException ex = assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Validate.noNullElements((List<?>) null, "MSG");
            }
        });
        assertEquals("iterable", ex.getMessage());
    }

    // notBlank

    @Test
    void notBlankReturnsSameInstance() {
        assertSame("abc", Validate.notBlank("abc"));
    }

    @Test
    void notBlankEmptyStringThrowsIllegalArgumentExceptionWithDefaultMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notBlank("");
            }
        });
        assertEquals("The validated character sequence is blank", ex.getMessage());
    }

    @Test
    void notBlankWhitespaceOnlyThrowsIllegalArgumentExceptionWithGivenMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notBlank("   ", "MSG");
            }
        });
        assertEquals("MSG", ex.getMessage());
    }

    @Test
    void notBlankNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notBlank(null);
            }
        });
    }

    // notEmpty (array)

    @Test
    void notEmptyArrayReturnsSameInstance() {
        final String[] array = {"hi"};
        assertSame(array, Validate.notEmpty(array));
    }

    @Test
    void notEmptyArrayEmptyThrowsWithDefaultMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notEmpty(new Object[0]);
            }
        });
        assertEquals("The validated array is empty", ex.getMessage());
    }

    @Test
    void notEmptyArrayNullThrowsNullPointerExceptionWithGivenMessage() {
        final NullPointerException ex = assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notEmpty((Object[]) null, "MSG");
            }
        });
        assertEquals("MSG", ex.getMessage());
    }

    // notEmpty (CharSequence)

    @Test
    void notEmptyCharSequenceReturnsSameInstance() {
        assertSame("Hi", Validate.notEmpty("Hi"));
    }

    @Test
    void notEmptyCharSequenceEmptyThrowsWithDefaultMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notEmpty("");
            }
        });
        assertEquals("The validated character sequence is empty", ex.getMessage());
    }

    @Test
    void notEmptyCharSequenceNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notEmpty((CharSequence) null);
            }
        });
    }

    // notEmpty (Collection)

    @Test
    void notEmptyCollectionReturnsSameInstance() {
        final List<String> list = new ArrayList<String>();
        list.add("a");
        assertSame(list, Validate.notEmpty(list));
    }

    @Test
    void notEmptyCollectionEmptyThrowsWithGivenMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notEmpty(Collections.emptyList(), "MSG");
            }
        });
        assertEquals("MSG", ex.getMessage());
    }

    @Test
    void notEmptyCollectionNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notEmpty((List<?>) null);
            }
        });
    }

    // notEmpty (Map)

    @Test
    void notEmptyMapReturnsSameInstance() {
        final Map<String, String> map = new HashMap<String, String>();
        map.put("key", "value");
        assertSame(map, Validate.notEmpty(map));
    }

    @Test
    void notEmptyMapEmptyThrowsWithDefaultMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notEmpty(Collections.emptyMap());
            }
        });
        assertEquals("The validated map is empty", ex.getMessage());
    }

    @Test
    void notEmptyMapNullThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notEmpty((Map<?, ?>) null);
            }
        });
    }

    // notNaN

    @Test
    void notNaNForNumberDoesNotThrow() {
        Validate.notNaN(0.0);
    }

    @Test
    void notNaNForInfinityDoesNotThrow() {
        Validate.notNaN(Double.POSITIVE_INFINITY);
        Validate.notNaN(Double.NEGATIVE_INFINITY);
    }

    @Test
    void notNaNForNaNThrowsWithDefaultMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notNaN(Double.NaN);
            }
        });
        assertEquals("The validated value is not a number", ex.getMessage());
    }

    @Test
    void notNaNForNaNThrowsWithGivenMessage() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notNaN(Double.NaN, "MSG");
            }
        });
        assertEquals("MSG", ex.getMessage());
    }

    // notNull

    @Test
    void notNullReturnsSameInstance() {
        assertSame("Hi", Validate.notNull("Hi", "MSG"));
    }

    @Test
    void notNullForNullThrowsWithGivenMessage() {
        final NullPointerException ex = assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notNull(null, "MSG");
            }
        });
        assertEquals("MSG", ex.getMessage());
    }

    @Test
    @SuppressWarnings("deprecation")
    void notNullDeprecatedOverloadForNullThrowsWithDefaultMessage() {
        final NullPointerException ex = assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Validate.notNull(null);
            }
        });
        assertEquals("The validated object is null", ex.getMessage());
    }

    // validIndex (array)

    @Test
    void validIndexArrayValidReturnsSameInstance() {
        final String[] array = {"a"};
        assertSame(array, Validate.validIndex(array, 0));
    }

    @Test
    void validIndexArrayNegativeThrowsWithDefaultMessage() {
        final IndexOutOfBoundsException ex = assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                Validate.validIndex(new String[] {"a"}, -1);
            }
        });
        assertEquals("The validated array index is invalid: -1", ex.getMessage());
    }

    @Test
    void validIndexArrayTooLargeThrowsWithGivenMessage() {
        final IndexOutOfBoundsException ex = assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                Validate.validIndex(new String[] {"a"}, 1, "MSG");
            }
        });
        assertEquals("MSG", ex.getMessage());
    }

    @Test
    void validIndexArrayNullThrowsNullPointerException() {
        final NullPointerException ex = assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Validate.validIndex((Object[]) null, 0);
            }
        });
        assertEquals("array", ex.getMessage());
    }

    // validIndex (CharSequence)

    @Test
    void validIndexCharSequenceValidReturnsSameInstance() {
        final String str = "a";
        assertSame(str, Validate.validIndex(str, 0));
    }

    @Test
    void validIndexCharSequenceOutOfBoundsThrowsWithDefaultMessage() {
        final IndexOutOfBoundsException ex = assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                Validate.validIndex("a", 1);
            }
        });
        assertEquals("The validated character sequence index is invalid: 1", ex.getMessage());
    }

    @Test
    void validIndexCharSequenceNullThrowsNullPointerException() {
        final NullPointerException ex = assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Validate.validIndex((String) null, 0, "MSG");
            }
        });
        assertEquals("chars", ex.getMessage());
    }

    // validIndex (Collection)

    @Test
    void validIndexCollectionValidReturnsSameInstance() {
        final List<String> list = new ArrayList<String>();
        list.add("a");
        assertSame(list, Validate.validIndex(list, 0));
    }

    @Test
    void validIndexCollectionOutOfBoundsThrowsWithGivenMessage() {
        final List<String> list = new ArrayList<String>();
        list.add("a");
        final IndexOutOfBoundsException ex = assertThrows(IndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                Validate.validIndex(list, 1, "MSG");
            }
        });
        assertEquals("MSG", ex.getMessage());
    }

    @Test
    void validIndexCollectionNullThrowsNullPointerException() {
        final NullPointerException ex = assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                Validate.validIndex((List<?>) null, 0);
            }
        });
        assertEquals("collection", ex.getMessage());
    }

    // validState

    @Test
    void validStateForTrueDoesNotThrow() {
        Validate.validState(true);
    }

    @Test
    void validStateForFalseThrowsWithDefaultMessage() {
        final IllegalStateException ex = assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                Validate.validState(false);
            }
        });
        assertEquals("The validated state is false", ex.getMessage());
    }

    @Test
    void validStateForFalseThrowsWithGivenMessage() {
        final IllegalStateException ex = assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                Validate.validState(false, "MSG %s", "x");
            }
        });
        assertEquals("MSG x", ex.getMessage());
    }

    // utility class conventions

    @Test
    @SuppressWarnings("deprecation")
    void instancesCanBeConstructed() {
        assertNotNull(new Validate());
    }

    @Test
    void hasOnlyOnePublicConstructor() {
        final Constructor<?>[] constructors = Validate.class.getDeclaredConstructors();
        assertEquals(1, constructors.length);
    }

    @Test
    void isPublicNonFinalClass() {
        assertTrue(Modifier.isPublic(Validate.class.getModifiers()));
        assertFalse(Modifier.isFinal(Validate.class.getModifiers()));
    }
}
