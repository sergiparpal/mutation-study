/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link NumberUtils}.
 */
public class NumberUtilsAgentTest {

    // --- compare ---

    @Test
    public void testCompareByte() {
        assertTrue(NumberUtils.compare((byte) 1, (byte) 2) < 0);
        assertEquals(0, NumberUtils.compare((byte) 5, (byte) 5));
        assertTrue(NumberUtils.compare((byte) 2, (byte) 1) > 0);
    }

    @Test
    public void testCompareInt() {
        assertTrue(NumberUtils.compare(1, 2) < 0);
        assertEquals(0, NumberUtils.compare(5, 5));
        assertTrue(NumberUtils.compare(2, 1) > 0);
    }

    @Test
    public void testCompareLong() {
        assertTrue(NumberUtils.compare(1L, 2L) < 0);
        assertEquals(0, NumberUtils.compare(5L, 5L));
        assertTrue(NumberUtils.compare(2L, 1L) > 0);
    }

    @Test
    public void testCompareShort() {
        assertTrue(NumberUtils.compare((short) 1, (short) 2) < 0);
        assertEquals(0, NumberUtils.compare((short) 5, (short) 5));
        assertTrue(NumberUtils.compare((short) 2, (short) 1) > 0);
    }

    // --- createBigDecimal ---

    @Test
    public void testCreateBigDecimalNull() {
        assertNull(NumberUtils.createBigDecimal(null));
    }

    @Test
    public void testCreateBigDecimalValid() {
        assertEquals(new BigDecimal("1.23"), NumberUtils.createBigDecimal("1.23"));
    }

    @Test
    public void testCreateBigDecimalBlankThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigDecimal("  ");
            }
        });
    }

    @Test
    public void testCreateBigDecimalEmptyThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigDecimal("");
            }
        });
    }

    @Test
    public void testCreateBigDecimalInvalidThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigDecimal("not a number");
            }
        });
    }

    // --- createBigInteger ---

    @Test
    public void testCreateBigIntegerNull() {
        assertNull(NumberUtils.createBigInteger(null));
    }

    @Test
    public void testCreateBigIntegerDecimal() {
        assertEquals(new BigInteger("123"), NumberUtils.createBigInteger("123"));
    }

    @Test
    public void testCreateBigIntegerNegativeDecimal() {
        assertEquals(new BigInteger("-123"), NumberUtils.createBigInteger("-123"));
    }

    @Test
    public void testCreateBigIntegerHex() {
        assertEquals(BigInteger.valueOf(255), NumberUtils.createBigInteger("0xFF"));
        assertEquals(BigInteger.valueOf(255), NumberUtils.createBigInteger("#FF"));
        assertEquals(BigInteger.valueOf(-255), NumberUtils.createBigInteger("-0xFF"));
    }

    @Test
    public void testCreateBigIntegerOctal() {
        assertEquals(BigInteger.valueOf(8), NumberUtils.createBigInteger("010"));
    }

    @Test
    public void testCreateBigIntegerEmptyThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigInteger("");
            }
        });
    }

    @Test
    public void testCreateBigIntegerDoubleSignThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createBigInteger("--1");
            }
        });
    }

    // --- createDouble ---

    @Test
    public void testCreateDoubleNull() {
        assertNull(NumberUtils.createDouble(null));
    }

    @Test
    public void testCreateDoubleValid() {
        assertEquals(Double.valueOf(1.5), NumberUtils.createDouble("1.5"));
    }

    @Test
    public void testCreateDoubleInvalidThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createDouble("abc");
            }
        });
    }

    // --- createFloat ---

    @Test
    public void testCreateFloatNull() {
        assertNull(NumberUtils.createFloat(null));
    }

    @Test
    public void testCreateFloatValid() {
        assertEquals(Float.valueOf(1.5f), NumberUtils.createFloat("1.5"));
    }

    @Test
    public void testCreateFloatInvalidThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createFloat("abc");
            }
        });
    }

    // --- createInteger ---

    @Test
    public void testCreateIntegerNull() {
        assertNull(NumberUtils.createInteger(null));
    }

    @Test
    public void testCreateIntegerDecimal() {
        assertEquals(Integer.valueOf(123), NumberUtils.createInteger("123"));
    }

    @Test
    public void testCreateIntegerHex() {
        assertEquals(Integer.valueOf(255), NumberUtils.createInteger("0xFF"));
    }

    @Test
    public void testCreateIntegerOctal() {
        assertEquals(Integer.valueOf(8), NumberUtils.createInteger("010"));
    }

    @Test
    public void testCreateIntegerInvalidThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createInteger("abc");
            }
        });
    }

    // --- createLong ---

    @Test
    public void testCreateLongNull() {
        assertNull(NumberUtils.createLong(null));
    }

    @Test
    public void testCreateLongDecimal() {
        assertEquals(Long.valueOf(123L), NumberUtils.createLong("123"));
    }

    @Test
    public void testCreateLongHex() {
        assertEquals(Long.valueOf(255L), NumberUtils.createLong("0xFF"));
    }

    @Test
    public void testCreateLongInvalidThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createLong("abc");
            }
        });
    }

    // --- createNumber ---

    @Test
    public void testCreateNumberNull() {
        assertNull(NumberUtils.createNumber(null));
    }

    @Test
    public void testCreateNumberBlankThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("   ");
            }
        });
    }

    @Test
    public void testCreateNumberPlainInt() {
        final Number n = NumberUtils.createNumber("123");
        assertTrue(n instanceof Integer);
        assertEquals(123, n.intValue());
    }

    @Test
    public void testCreateNumberTooBigForIntBecomesLong() {
        final Number n = NumberUtils.createNumber("12345678901");
        assertTrue(n instanceof Long);
        assertEquals(12345678901L, n.longValue());
    }

    @Test
    public void testCreateNumberTooBigForLongBecomesBigInteger() {
        final Number n = NumberUtils.createNumber("123456789012345678901234567890");
        assertTrue(n instanceof BigInteger);
        assertEquals(new BigInteger("123456789012345678901234567890"), n);
    }

    @Test
    public void testCreateNumberLongSuffix() {
        final Number n = NumberUtils.createNumber("123L");
        assertTrue(n instanceof Long);
        assertEquals(123L, n.longValue());
    }

    @Test
    public void testCreateNumberFloatSuffix() {
        final Number n = NumberUtils.createNumber("1.5f");
        assertTrue(n instanceof Float);
        assertEquals(1.5f, n.floatValue(), 0.0f);
    }

    @Test
    public void testCreateNumberDoubleSuffix() {
        final Number n = NumberUtils.createNumber("1.5d");
        assertTrue(n instanceof Double);
        assertEquals(1.5d, n.doubleValue(), 0.0d);
    }

    @Test
    public void testCreateNumberDecimalWithoutSuffix() {
        final Number n = NumberUtils.createNumber("1.5");
        assertTrue(n instanceof Float);
        assertEquals(1.5f, n.floatValue(), 0.0f);
    }

    @Test
    public void testCreateNumberHex() {
        final Number n = NumberUtils.createNumber("0xFF");
        assertTrue(n instanceof Integer);
        assertEquals(255, n.intValue());
    }

    @Test
    public void testCreateNumberInvalidLetterSuffixThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("123X");
            }
        });
    }

    @Test
    public void testCreateNumberBadDoubleExponentThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.createNumber("1.2.3");
            }
        });
    }

    // --- isCreatable / isNumber ---

    @Test
    public void testIsCreatableNullAndEmpty() {
        assertFalse(NumberUtils.isCreatable(null));
        assertFalse(NumberUtils.isCreatable(""));
    }

    @Test
    public void testIsCreatableValid() {
        assertTrue(NumberUtils.isCreatable("123"));
        assertTrue(NumberUtils.isCreatable("1.5e10"));
        assertTrue(NumberUtils.isCreatable("0xFF"));
    }

    @Test
    public void testIsCreatableInvalid() {
        assertFalse(NumberUtils.isCreatable("abc"));
        assertFalse(NumberUtils.isCreatable("09"));
    }

    @SuppressWarnings("deprecation")
    @Test
    public void testIsNumberDelegatesToIsCreatable() {
        assertTrue(NumberUtils.isNumber("123"));
        assertFalse(NumberUtils.isNumber("abc"));
    }

    // --- isDigits ---

    @Test
    public void testIsDigits() {
        assertTrue(NumberUtils.isDigits("12345"));
        assertFalse(NumberUtils.isDigits("12.45"));
        assertFalse(NumberUtils.isDigits(""));
        assertFalse(NumberUtils.isDigits(null));
        assertFalse(NumberUtils.isDigits("-123"));
    }

    // --- isParsable ---

    @Test
    public void testIsParsable() {
        assertTrue(NumberUtils.isParsable("123"));
        assertTrue(NumberUtils.isParsable("1.5"));
        assertTrue(NumberUtils.isParsable("NaN"));
        assertFalse(NumberUtils.isParsable(null));
        assertFalse(NumberUtils.isParsable(""));
        assertFalse(NumberUtils.isParsable("abc"));
    }

    // --- max/min arrays ---

    @Test
    public void testMaxByteArray() {
        assertEquals((byte) 5, NumberUtils.max((byte) 1, (byte) 5, (byte) 3));
    }

    @Test
    public void testMaxByteArraySingleElement() {
        assertEquals((byte) 7, NumberUtils.max((byte) 7));
    }

    @Test
    public void testMaxByteArrayNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max((byte[]) null);
            }
        });
    }

    @Test
    public void testMaxByteArrayEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new byte[0]);
            }
        });
    }

    @Test
    public void testMaxByteThreeArgs() {
        assertEquals((byte) 9, NumberUtils.max((byte) 1, (byte) 9, (byte) 5));
    }

    @Test
    public void testMaxDoubleArray() {
        assertEquals(5.0d, NumberUtils.max(1.0d, 5.0d, 3.0d), 0.0d);
    }

    @Test
    public void testMaxDoubleArrayWithNaN() {
        assertTrue(Double.isNaN(NumberUtils.max(1.0d, Double.NaN, 3.0d)));
    }

    @Test
    public void testMaxDoubleArrayEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new double[0]);
            }
        });
    }

    @Test
    public void testMaxDoubleThreeArgs() {
        assertEquals(9.0d, NumberUtils.max(1.0d, 9.0d, 5.0d), 0.0d);
    }

    @Test
    public void testMaxFloatArray() {
        assertEquals(5.0f, NumberUtils.max(1.0f, 5.0f, 3.0f), 0.0f);
    }

    @Test
    public void testMaxFloatArrayWithNaN() {
        assertTrue(Float.isNaN(NumberUtils.max(1.0f, Float.NaN, 3.0f)));
    }

    @Test
    public void testMaxFloatThreeArgs() {
        assertEquals(9.0f, NumberUtils.max(1.0f, 9.0f, 5.0f), 0.0f);
    }

    @Test
    public void testMaxIntArray() {
        assertEquals(5, NumberUtils.max(1, 5, 3));
    }

    @Test
    public void testMaxIntArrayEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.max(new int[0]);
            }
        });
    }

    @Test
    public void testMaxIntThreeArgs() {
        assertEquals(9, NumberUtils.max(1, 9, 5));
    }

    @Test
    public void testMaxLongArray() {
        assertEquals(5L, NumberUtils.max(1L, 5L, 3L));
    }

    @Test
    public void testMaxLongThreeArgs() {
        assertEquals(9L, NumberUtils.max(1L, 9L, 5L));
    }

    @Test
    public void testMaxShortArray() {
        assertEquals((short) 5, NumberUtils.max((short) 1, (short) 5, (short) 3));
    }

    @Test
    public void testMaxShortThreeArgs() {
        assertEquals((short) 9, NumberUtils.max((short) 1, (short) 9, (short) 5));
    }

    @Test
    public void testMinByteArray() {
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 5, (byte) 3));
    }

    @Test
    public void testMinByteArrayNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min((byte[]) null);
            }
        });
    }

    @Test
    public void testMinByteArrayEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new byte[0]);
            }
        });
    }

    @Test
    public void testMinByteThreeArgs() {
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 9, (byte) 5));
    }

    @Test
    public void testMinDoubleArray() {
        assertEquals(1.0d, NumberUtils.min(1.0d, 5.0d, 3.0d), 0.0d);
    }

    @Test
    public void testMinDoubleArrayWithNaN() {
        assertTrue(Double.isNaN(NumberUtils.min(1.0d, Double.NaN, 3.0d)));
    }

    @Test
    public void testMinDoubleThreeArgs() {
        assertEquals(1.0d, NumberUtils.min(1.0d, 9.0d, 5.0d), 0.0d);
    }

    @Test
    public void testMinFloatArray() {
        assertEquals(1.0f, NumberUtils.min(1.0f, 5.0f, 3.0f), 0.0f);
    }

    @Test
    public void testMinFloatArrayWithNaN() {
        assertTrue(Float.isNaN(NumberUtils.min(1.0f, Float.NaN, 3.0f)));
    }

    @Test
    public void testMinFloatThreeArgs() {
        assertEquals(1.0f, NumberUtils.min(1.0f, 9.0f, 5.0f), 0.0f);
    }

    @Test
    public void testMinIntArray() {
        assertEquals(1, NumberUtils.min(1, 5, 3));
    }

    @Test
    public void testMinIntArrayEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                NumberUtils.min(new int[0]);
            }
        });
    }

    @Test
    public void testMinIntThreeArgs() {
        assertEquals(1, NumberUtils.min(1, 9, 5));
    }

    @Test
    public void testMinLongArray() {
        assertEquals(1L, NumberUtils.min(1L, 5L, 3L));
    }

    @Test
    public void testMinLongThreeArgs() {
        assertEquals(1L, NumberUtils.min(1L, 9L, 5L));
    }

    @Test
    public void testMinShortArray() {
        assertEquals((short) 1, NumberUtils.min((short) 1, (short) 5, (short) 3));
    }

    @Test
    public void testMinShortThreeArgs() {
        assertEquals((short) 1, NumberUtils.min((short) 1, (short) 9, (short) 5));
    }

    // --- toByte ---

    @Test
    public void testToByteNullReturnsZero() {
        assertEquals((byte) 0, NumberUtils.toByte(null));
    }

    @Test
    public void testToByteEmptyReturnsZero() {
        assertEquals((byte) 0, NumberUtils.toByte(""));
    }

    @Test
    public void testToByteValid() {
        assertEquals((byte) 1, NumberUtils.toByte("1"));
    }

    @Test
    public void testToByteWithDefault() {
        assertEquals((byte) 1, NumberUtils.toByte(null, (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("not a byte", (byte) 1));
        assertEquals((byte) 2, NumberUtils.toByte("2", (byte) 1));
    }

    // --- toDouble ---

    @Test
    public void testToDoubleBigDecimalNull() {
        assertEquals(0.0d, NumberUtils.toDouble((BigDecimal) null), 0.0d);
    }

    @Test
    public void testToDoubleBigDecimalValid() {
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d)), 0.0d);
    }

    @Test
    public void testToDoubleBigDecimalWithDefault() {
        assertEquals(1.1d, NumberUtils.toDouble((BigDecimal) null, 1.1d), 0.0d);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d), 1.1d), 0.0d);
    }

    @Test
    public void testToDoubleStringNullReturnsZero() {
        assertEquals(0.0d, NumberUtils.toDouble((String) null), 0.0d);
    }

    @Test
    public void testToDoubleStringEmptyReturnsZero() {
        assertEquals(0.0d, NumberUtils.toDouble(""), 0.0d);
    }

    @Test
    public void testToDoubleStringValid() {
        assertEquals(1.5d, NumberUtils.toDouble("1.5"), 0.0d);
    }

    @Test
    public void testToDoubleStringWithDefault() {
        assertEquals(1.1d, NumberUtils.toDouble((String) null, 1.1d), 0.0d);
        assertEquals(1.1d, NumberUtils.toDouble("not a double", 1.1d), 0.0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5", 0.0d), 0.0d);
    }

    // --- toFloat ---

    @Test
    public void testToFloatNullReturnsZero() {
        assertEquals(0.0f, NumberUtils.toFloat(null), 0.0f);
    }

    @Test
    public void testToFloatValid() {
        assertEquals(1.5f, NumberUtils.toFloat("1.5"), 0.0f);
    }

    @Test
    public void testToFloatWithDefault() {
        assertEquals(1.1f, NumberUtils.toFloat(null, 1.1f), 0.0f);
        assertEquals(1.1f, NumberUtils.toFloat("not a float", 1.1f), 0.0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5", 0.0f), 0.0f);
    }

    // --- toInt ---

    @Test
    public void testToIntNullReturnsZero() {
        assertEquals(0, NumberUtils.toInt(null));
    }

    @Test
    public void testToIntEmptyReturnsZero() {
        assertEquals(0, NumberUtils.toInt(""));
    }

    @Test
    public void testToIntValid() {
        assertEquals(1, NumberUtils.toInt("1"));
    }

    @Test
    public void testToIntWithDefault() {
        assertEquals(1, NumberUtils.toInt(null, 1));
        assertEquals(1, NumberUtils.toInt("not an int", 1));
        assertEquals(1, NumberUtils.toInt("1", 0));
    }

    // --- toLong ---

    @Test
    public void testToLongNullReturnsZero() {
        assertEquals(0L, NumberUtils.toLong(null));
    }

    @Test
    public void testToLongValid() {
        assertEquals(1L, NumberUtils.toLong("1"));
    }

    @Test
    public void testToLongWithDefault() {
        assertEquals(1L, NumberUtils.toLong(null, 1L));
        assertEquals(1L, NumberUtils.toLong("not a long", 1L));
        assertEquals(1L, NumberUtils.toLong("1", 0L));
    }

    // --- toScaledBigDecimal ---

    @Test
    public void testToScaledBigDecimalBigDecimalNull() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null));
    }

    @Test
    public void testToScaledBigDecimalBigDecimalDefaultScale() {
        final BigDecimal result = NumberUtils.toScaledBigDecimal(BigDecimal.valueOf(2.255d));
        assertEquals(2, result.scale());
    }

    @Test
    public void testToScaledBigDecimalBigDecimalWithScaleAndMode() {
        final BigDecimal result = NumberUtils.toScaledBigDecimal(new BigDecimal("2.125"), 2, RoundingMode.HALF_UP);
        assertEquals(new BigDecimal("2.13"), result);
    }

    @Test
    public void testToScaledBigDecimalBigDecimalNullRoundingModeDefaultsToHalfEven() {
        final BigDecimal result = NumberUtils.toScaledBigDecimal(new BigDecimal("2.125"), 2, null);
        assertEquals(new BigDecimal("2.12"), result);
    }

    @Test
    public void testToScaledBigDecimalDoubleNull() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null));
    }

    @Test
    public void testToScaledBigDecimalDoubleValid() {
        final BigDecimal result = NumberUtils.toScaledBigDecimal(Double.valueOf(2.125d), 2, RoundingMode.HALF_UP);
        assertEquals(new BigDecimal("2.13"), result);
    }

    @Test
    public void testToScaledBigDecimalFloatNull() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null));
    }

    @Test
    public void testToScaledBigDecimalFloatValid() {
        final BigDecimal result = NumberUtils.toScaledBigDecimal(Float.valueOf(2.125f), 2, RoundingMode.HALF_UP);
        assertEquals(new BigDecimal("2.13"), result);
    }

    @Test
    public void testToScaledBigDecimalStringNull() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null));
    }

    @Test
    public void testToScaledBigDecimalStringValid() {
        final BigDecimal result = NumberUtils.toScaledBigDecimal("2.125", 2, RoundingMode.HALF_UP);
        assertEquals(new BigDecimal("2.13"), result);
    }

    // --- toShort ---

    @Test
    public void testToShortNullReturnsZero() {
        assertEquals((short) 0, NumberUtils.toShort(null));
    }

    @Test
    public void testToShortEmptyReturnsZero() {
        assertEquals((short) 0, NumberUtils.toShort(""));
    }

    @Test
    public void testToShortValid() {
        assertEquals((short) 1, NumberUtils.toShort("1"));
    }

    @Test
    public void testToShortWithDefault() {
        assertEquals((short) 1, NumberUtils.toShort(null, (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("not a short", (short) 1));
        assertEquals((short) 2, NumberUtils.toShort("2", (short) 1));
    }

    // --- constants ---

    @Test
    public void testConstants() {
        assertEquals(Long.valueOf(0L), NumberUtils.LONG_ZERO);
        assertEquals(Long.valueOf(1L), NumberUtils.LONG_ONE);
        assertEquals(Long.valueOf(-1L), NumberUtils.LONG_MINUS_ONE);
        assertEquals(Integer.valueOf(0), NumberUtils.INTEGER_ZERO);
        assertEquals(Integer.valueOf(1), NumberUtils.INTEGER_ONE);
        assertEquals(Integer.valueOf(2), NumberUtils.INTEGER_TWO);
        assertEquals(Integer.valueOf(-1), NumberUtils.INTEGER_MINUS_ONE);
        assertEquals(Short.valueOf((short) 0), NumberUtils.SHORT_ZERO);
        assertEquals(Short.valueOf((short) 1), NumberUtils.SHORT_ONE);
        assertEquals(Short.valueOf((short) -1), NumberUtils.SHORT_MINUS_ONE);
        assertEquals(Byte.valueOf((byte) 0), NumberUtils.BYTE_ZERO);
        assertEquals(Byte.valueOf((byte) 1), NumberUtils.BYTE_ONE);
        assertEquals(Byte.valueOf((byte) -1), NumberUtils.BYTE_MINUS_ONE);
        assertEquals(Double.valueOf(0.0d), NumberUtils.DOUBLE_ZERO);
        assertEquals(Double.valueOf(1.0d), NumberUtils.DOUBLE_ONE);
        assertEquals(Double.valueOf(-1.0d), NumberUtils.DOUBLE_MINUS_ONE);
        assertEquals(Float.valueOf(0.0f), NumberUtils.FLOAT_ZERO);
        assertEquals(Float.valueOf(1.0f), NumberUtils.FLOAT_ONE);
        assertEquals(Float.valueOf(-1.0f), NumberUtils.FLOAT_MINUS_ONE);
        assertEquals(Long.valueOf(Integer.MAX_VALUE), NumberUtils.LONG_INT_MAX_VALUE);
        assertEquals(Long.valueOf(Integer.MIN_VALUE), NumberUtils.LONG_INT_MIN_VALUE);
    }

    @Test
    public void testPublicConstructor() {
        assertTrue(new NumberUtils() instanceof NumberUtils);
    }
}
