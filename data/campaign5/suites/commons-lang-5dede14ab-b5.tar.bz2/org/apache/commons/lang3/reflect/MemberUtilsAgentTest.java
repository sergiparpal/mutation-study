/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link MemberUtils}.
 */
class MemberUtilsAgentTest {

    interface Shape {
    }

    static class Circle implements Shape {
    }

    static class AccessFixture {
        public void publicMethod() {
        }

        private void privateMethod() {
        }

        public static void staticMethod() {
        }

        public void instanceMethod() {
        }
    }

    static class Overloads {
        public Overloads(final Object o) {
        }

        public Overloads(final String s) {
        }

        public Overloads(final String s, final Object... extras) {
        }

        public void take(final Object o) {
        }

        public void take(final String s) {
        }

        public void take(final CharSequence s) {
        }

        public void take(final Shape s) {
        }

        public void takeInt(final int i) {
        }

        public void takeLong(final long l) {
        }

        public void takeDouble(final double d) {
        }

        public void varArgs(final String... values) {
        }
    }

    static class PackagePrivateHolder {
        public void publicMethod() {
        }
    }

    public static class PublicHolder {
        public void publicMethod() {
        }
    }

    @Test
    void testConstructorIsPackagePrivateAndInstantiable() throws Exception {
        final Constructor<?> constructor = MemberUtils.class.getDeclaredConstructor();
        assertFalse(Modifier.isPublic(constructor.getModifiers()));
        constructor.setAccessible(true);
        assertNotNull(constructor.newInstance());
    }

    @Test
    void testIsPublicNull() {
        assertFalse(MemberUtils.isPublic(null));
    }

    @Test
    void testIsPublicTrueForPublicMember() throws Exception {
        final Method m = AccessFixture.class.getMethod("publicMethod");
        assertTrue(MemberUtils.isPublic(m));
    }

    @Test
    void testIsPublicFalseForPrivateMember() throws Exception {
        final Method m = AccessFixture.class.getDeclaredMethod("privateMethod");
        assertFalse(MemberUtils.isPublic(m));
    }

    @Test
    void testIsStaticNull() {
        assertFalse(MemberUtils.isStatic(null));
    }

    @Test
    void testIsStaticTrueForStaticMember() throws Exception {
        final Method m = AccessFixture.class.getMethod("staticMethod");
        assertTrue(MemberUtils.isStatic(m));
    }

    @Test
    void testIsStaticFalseForInstanceMember() throws Exception {
        final Method m = AccessFixture.class.getMethod("instanceMethod");
        assertFalse(MemberUtils.isStatic(m));
    }

    @Test
    void testIsPackageForPlainModifiers() {
        assertTrue(MemberUtils.isPackage(0));
        assertTrue(MemberUtils.isPackage(Modifier.STATIC));
        assertTrue(MemberUtils.isPackage(Modifier.FINAL));
    }

    @Test
    void testIsPackageFalseForAccessModifiers() {
        assertFalse(MemberUtils.isPackage(Modifier.PUBLIC));
        assertFalse(MemberUtils.isPackage(Modifier.PROTECTED));
        assertFalse(MemberUtils.isPackage(Modifier.PRIVATE));
        assertFalse(MemberUtils.isPackage(Modifier.PUBLIC | Modifier.STATIC));
    }

    @Test
    void testIsAccessibleNull() {
        assertFalse(MemberUtils.isAccessible(null));
    }

    @Test
    void testIsAccessibleTrueForPublicMethod() throws Exception {
        final Method m = AccessFixture.class.getMethod("publicMethod");
        assertTrue(MemberUtils.isAccessible(m));
    }

    @Test
    void testIsAccessibleFalseForPrivateMethod() throws Exception {
        final Method m = AccessFixture.class.getDeclaredMethod("privateMethod");
        assertFalse(MemberUtils.isAccessible(m));
    }

    @Test
    void testIsMatchingMethodExactMatch() throws Exception {
        final Method m = Overloads.class.getMethod("take", String.class);
        assertTrue(MemberUtils.isMatchingMethod(m, new Class<?>[] { String.class }));
    }

    @Test
    void testIsMatchingMethodSupertypeArgumentRejected() throws Exception {
        final Method m = Overloads.class.getMethod("take", String.class);
        // CharSequence is a supertype of String, not assignable the other way.
        assertFalse(MemberUtils.isMatchingMethod(m, new Class<?>[] { CharSequence.class }));
    }

    @Test
    void testIsMatchingMethodWrongArgCount() throws Exception {
        final Method m = Overloads.class.getMethod("take", String.class);
        assertFalse(MemberUtils.isMatchingMethod(m, new Class<?>[] { String.class, String.class }));
    }

    @Test
    void testIsMatchingMethodVarArgsNoArgsSupplied() throws Exception {
        final Method m = Overloads.class.getMethod("varArgs", String[].class);
        assertTrue(MemberUtils.isMatchingMethod(m, new Class<?>[0]));
    }

    @Test
    void testIsMatchingMethodVarArgsMultipleArgs() throws Exception {
        final Method m = Overloads.class.getMethod("varArgs", String[].class);
        assertTrue(MemberUtils.isMatchingMethod(m, new Class<?>[] { String.class, String.class, String.class }));
    }

    @Test
    void testIsMatchingMethodVarArgsExplicitArray() throws Exception {
        final Method m = Overloads.class.getMethod("varArgs", String[].class);
        assertTrue(MemberUtils.isMatchingMethod(m, new Class<?>[] { String[].class }));
    }

    @Test
    void testIsMatchingMethodVarArgsWrongType() throws Exception {
        final Method m = Overloads.class.getMethod("varArgs", String[].class);
        assertFalse(MemberUtils.isMatchingMethod(m, new Class<?>[] { Integer.class }));
    }

    @Test
    void testIsMatchingConstructorExactMatch() throws Exception {
        final Constructor<?> c = Overloads.class.getConstructor(String.class);
        assertTrue(MemberUtils.isMatchingConstructor(c, new Class<?>[] { String.class }));
    }

    @Test
    void testIsMatchingConstructorVarArgsZeroExtras() throws Exception {
        final Constructor<?> c = Overloads.class.getConstructor(String.class, Object[].class);
        assertTrue(MemberUtils.isMatchingConstructor(c, new Class<?>[] { String.class }));
    }

    @Test
    void testIsMatchingConstructorVarArgsMultipleExtras() throws Exception {
        final Constructor<?> c = Overloads.class.getConstructor(String.class, Object[].class);
        assertTrue(MemberUtils.isMatchingConstructor(c, new Class<?>[] { String.class, Integer.class, Double.class }));
    }

    @Test
    void testIsMatchingConstructorNonVarArgsRejectsExtraArg() throws Exception {
        final Constructor<?> c = Overloads.class.getConstructor(String.class);
        assertFalse(MemberUtils.isMatchingConstructor(c, new Class<?>[] { String.class, String.class }));
    }

    @Test
    void testCompareMethodFitPrefersExactTypeOverSuperclass() throws Exception {
        final Method exact = Overloads.class.getMethod("take", String.class);
        final Method general = Overloads.class.getMethod("take", Object.class);
        final Class<?>[] actual = { String.class };
        assertTrue(MemberUtils.compareMethodFit(exact, general, actual) < 0);
        assertTrue(MemberUtils.compareMethodFit(general, exact, actual) > 0);
    }

    @Test
    void testCompareMethodFitSameMethodIsTie() throws Exception {
        final Method m = Overloads.class.getMethod("take", String.class);
        final Class<?>[] actual = { String.class };
        assertEquals(0, MemberUtils.compareMethodFit(m, m, actual));
    }

    @Test
    void testCompareMethodFitInterfacePenaltyBeatsObjectMatch() throws Exception {
        final Method viaInterface = Overloads.class.getMethod("take", Shape.class);
        final Method viaObject = Overloads.class.getMethod("take", Object.class);
        final Class<?>[] actual = { Circle.class };
        // Interface match (cost 0.25) is cheaper than climbing to Object (cost 1.0).
        assertTrue(MemberUtils.compareMethodFit(viaInterface, viaObject, actual) < 0);
    }

    @Test
    void testCompareMethodFitPrimitiveWideningOrdering() throws Exception {
        final Method takeInt = Overloads.class.getMethod("takeInt", int.class);
        final Method takeLong = Overloads.class.getMethod("takeLong", long.class);
        final Method takeDouble = Overloads.class.getMethod("takeDouble", double.class);
        final Class<?>[] actual = { int.class };
        assertTrue(MemberUtils.compareMethodFit(takeInt, takeLong, actual) < 0);
        assertTrue(MemberUtils.compareMethodFit(takeLong, takeDouble, actual) < 0);
        assertTrue(MemberUtils.compareMethodFit(takeInt, takeDouble, actual) < 0);
    }

    @Test
    void testCompareMethodFitUnboxingPenaltyStillPrefersNarrowerPrimitive() throws Exception {
        final Method takeInt = Overloads.class.getMethod("takeInt", int.class);
        final Method takeLong = Overloads.class.getMethod("takeLong", long.class);
        final Class<?>[] actual = { Integer.class };
        assertTrue(MemberUtils.compareMethodFit(takeInt, takeLong, actual) < 0);
    }

    @Test
    void testCompareMethodFitNullActualArgIsTieRegardlessOfTargetType() throws Exception {
        final Method exact = Overloads.class.getMethod("take", String.class);
        final Method general = Overloads.class.getMethod("take", Object.class);
        final Class<?>[] actual = { null };
        assertEquals(0, MemberUtils.compareMethodFit(exact, general, actual));
    }

    @Test
    void testCompareConstructorFitPrefersExactTypeOverSuperclass() throws Exception {
        final Constructor<?> exact = Overloads.class.getConstructor(String.class);
        final Constructor<?> general = Overloads.class.getConstructor(Object.class);
        final Class<?>[] actual = { String.class };
        assertTrue(MemberUtils.compareConstructorFit(exact, general, actual) < 0);
        assertTrue(MemberUtils.compareConstructorFit(general, exact, actual) > 0);
    }

    @Test
    void testSetAccessibleWorkaroundNullIsNoOp() {
        assertNull(MemberUtils.setAccessibleWorkaround(null));
    }

    @Test
    void testSetAccessibleWorkaroundPublicMemberOfPackagePrivateClassBecomesAccessible() throws Exception {
        final Method m = PackagePrivateHolder.class.getMethod("publicMethod");
        assertFalse(m.isAccessible());
        final Method result = MemberUtils.setAccessibleWorkaround(m);
        assertSame(m, result);
        assertTrue(result.isAccessible());
    }

    @Test
    void testSetAccessibleWorkaroundPublicMemberOfPublicClassIsUntouched() throws Exception {
        final Method m = PublicHolder.class.getMethod("publicMethod");
        assertFalse(m.isAccessible());
        final Method result = MemberUtils.setAccessibleWorkaround(m);
        assertSame(m, result);
        assertFalse(result.isAccessible());
    }

    @Test
    void testSetAccessibleWorkaroundAlreadyAccessibleIsReturnedUnchanged() throws Exception {
        final Method m = PublicHolder.class.getMethod("publicMethod");
        m.setAccessible(true);
        final Method result = MemberUtils.setAccessibleWorkaround(m);
        assertSame(m, result);
        assertTrue(result.isAccessible());
    }
}
