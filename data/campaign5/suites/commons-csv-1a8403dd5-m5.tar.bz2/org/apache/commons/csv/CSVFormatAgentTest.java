/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link CSVFormat}.
 */
class CSVFormatAgentTest {

    private enum Header {
        NAME, EMAIL, PHONE
    }

    // ---------------------------------------------------------------
    // Predefined formats
    // ---------------------------------------------------------------

    @Test
    void testDefaultFormatProperties() {
        assertEquals(',', CSVFormat.DEFAULT.getDelimiter());
        assertEquals(",", CSVFormat.DEFAULT.getDelimiterString());
        assertEquals(Character.valueOf('"'), CSVFormat.DEFAULT.getQuoteCharacter());
        assertEquals("\r\n", CSVFormat.DEFAULT.getRecordSeparator());
        assertTrue(CSVFormat.DEFAULT.getIgnoreEmptyLines());
        assertEquals(DuplicateHeaderMode.ALLOW_ALL, CSVFormat.DEFAULT.getDuplicateHeaderMode());
        assertNull(CSVFormat.DEFAULT.getCommentMarker());
        assertNull(CSVFormat.DEFAULT.getEscapeCharacter());
        assertFalse(CSVFormat.DEFAULT.isCommentMarkerSet());
        assertFalse(CSVFormat.DEFAULT.isEscapeCharacterSet());
        assertFalse(CSVFormat.DEFAULT.isNullStringSet());
        assertTrue(CSVFormat.DEFAULT.isQuoteCharacterSet());
        assertEquals(0L, CSVFormat.DEFAULT.getMaxRows());
    }

    @Test
    void testRfc4180DiffersFromDefaultOnEmptyLines() {
        assertFalse(CSVFormat.RFC4180.getIgnoreEmptyLines());
        assertTrue(CSVFormat.DEFAULT.getIgnoreEmptyLines());
    }

    @Test
    void testExcelFormatProperties() {
        assertFalse(CSVFormat.EXCEL.getIgnoreEmptyLines());
        assertTrue(CSVFormat.EXCEL.getAllowMissingColumnNames());
        assertTrue(CSVFormat.EXCEL.getTrailingData());
        assertTrue(CSVFormat.EXCEL.getLenientEof());
    }

    @Test
    void testMySqlFormatProperties() {
        assertEquals('\t', CSVFormat.MYSQL.getDelimiter());
        assertNull(CSVFormat.MYSQL.getQuoteCharacter());
        assertEquals(Character.valueOf('\\'), CSVFormat.MYSQL.getEscapeCharacter());
        assertEquals("\\N", CSVFormat.MYSQL.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, CSVFormat.MYSQL.getQuoteMode());
        assertFalse(CSVFormat.MYSQL.getIgnoreEmptyLines());
    }

    @Test
    void testValueOfReturnsPredefinedFormat() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.valueOf("Default"));
        assertEquals(CSVFormat.EXCEL, CSVFormat.valueOf("Excel"));
        assertEquals(CSVFormat.MYSQL, CSVFormat.valueOf("MySQL"));
    }

    @Test
    void testValueOfUnknownNameThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void run() {
                CSVFormat.valueOf("NoSuchFormat");
            }
        });
    }

    @Test
    void testPredefinedEnumGetFormat() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.Predefined.Default.getFormat());
        assertEquals(CSVFormat.TDF, CSVFormat.Predefined.TDF.getFormat());
    }

    // ---------------------------------------------------------------
    // newFormat
    // ---------------------------------------------------------------

    @Test
    void testNewFormatSetsOnlyDelimiter() {
        final CSVFormat format = CSVFormat.newFormat(';');
        assertEquals(';', format.getDelimiter());
        assertNull(format.getQuoteCharacter());
        assertNull(format.getCommentMarker());
        assertNull(format.getRecordSeparator());
        assertFalse(format.getIgnoreEmptyLines());
        assertNull(format.getHeader());
    }

    @Test
    void testNewFormatWithLineBreakDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void run() {
                CSVFormat.newFormat('\n');
            }
        });
    }

    // ---------------------------------------------------------------
    // Builder validation
    // ---------------------------------------------------------------

    @Test
    void testBuilderSetDelimiterEmptyStringThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void run() {
                CSVFormat.DEFAULT.builder().setDelimiter("").get();
            }
        });
    }

    @Test
    void testBuilderSetDelimiterLineBreakThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void run() {
                CSVFormat.DEFAULT.builder().setDelimiter("a\nb").get();
            }
        });
    }

    @Test
    void testBuilderSetCommentMarkerLineBreakThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void run() {
                CSVFormat.DEFAULT.builder().setCommentMarker('\r').get();
            }
        });
    }

    @Test
    void testBuilderSetEscapeLineBreakThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void run() {
                CSVFormat.DEFAULT.builder().setEscape('\n').get();
            }
        });
    }

    @Test
    void testBuilderSetQuoteLineBreakThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void run() {
                CSVFormat.DEFAULT.builder().setQuote('\r').get();
            }
        });
    }

    @Test
    void testBuilderSetDuplicateHeaderModeNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void run() {
                CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(null);
            }
        });
    }

    @Test
    void testValidateQuoteSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void run() {
                CSVFormat.DEFAULT.builder().setDelimiter(',').setQuote(',').get();
            }
        });
    }

    @Test
    void testValidateEscapeSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void run() {
                CSVFormat.DEFAULT.builder().setDelimiter(';').setEscape(';').get();
            }
        });
    }

    @Test
    void testValidateCommentMarkerSameAsDelimiterThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void run() {
                CSVFormat.DEFAULT.builder().setDelimiter('#').setCommentMarker('#').get();
            }
        });
    }

    @Test
    void testValidateQuoteSameAsCommentMarkerThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void run() {
                CSVFormat.DEFAULT.builder().setQuote('#').setCommentMarker('#').get();
            }
        });
    }

    @Test
    void testValidateEscapeSameAsCommentMarkerThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void run() {
                CSVFormat.DEFAULT.builder().setEscape('#').setCommentMarker('#').get();
            }
        });
    }

    @Test
    void testValidateQuoteModeNoneWithoutEscapeThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void run() {
                CSVFormat.DEFAULT.builder().setQuoteMode(QuoteMode.NONE).get();
            }
        });
    }

    @Test
    void testValidateQuoteModeNoneWithEscapeSucceeds() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').setQuoteMode(QuoteMode.NONE).get();
        assertEquals(QuoteMode.NONE, format.getQuoteMode());
    }

    @Test
    void testValidateDuplicateHeaderDisallowThrows() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void run() {
                CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.DISALLOW).setHeader("a", "b", "a").get();
            }
        });
    }

    @Test
    void testValidateDuplicateHeaderAllowAllSucceeds() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_ALL).setHeader("a", "b", "a").get();
        assertArrayEquals(new String[] {"a", "b", "a"}, format.getHeader());
    }

    @Test
    void testValidateDuplicateHeaderAllowEmptyAllowsBlankDuplicates() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("a", "", "").get();
        assertArrayEquals(new String[] {"a", "", ""}, format.getHeader());
    }

    @Test
    void testValidateDuplicateHeaderAllowEmptyRejectsNonBlankDuplicates() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void run() {
                CSVFormat.DEFAULT.builder().setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_EMPTY).setHeader("a", "a").get();
            }
        });
    }

    // ---------------------------------------------------------------
    // Builder getters / setHeader variants
    // ---------------------------------------------------------------

    @Test
    void testBuilderCreateDefaults() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create();
        final CSVFormat format = builder.get();
        assertEquals(',', format.getDelimiter());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertTrue(format.getIgnoreEmptyLines());
    }

    @Test
    void testBuilderCreateFromFormatCopiesSettings() {
        final CSVFormat original = CSVFormat.DEFAULT.builder().setHeader("a", "b").setNullString("NULL").get();
        final CSVFormat.Builder copyBuilder = CSVFormat.Builder.create(original);
        final CSVFormat copy = copyBuilder.get();
        assertEquals(original, copy);
    }

    @Test
    void testSetHeaderWithEnumClass() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(Header.class).get();
        assertArrayEquals(new String[] {"NAME", "EMAIL", "PHONE"}, format.getHeader());
    }

    @Test
    void testSetHeaderWithNullEnumClassDisablesHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader((Class<? extends Enum<?>>) null).get();
        assertNull(format.getHeader());
    }

    @Test
    void testSetHeaderCopiesInputArrayDefensively() {
        final String[] original = {"a", "b"};
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(original).get();
        original[0] = "mutated";
        assertArrayEquals(new String[] {"a", "b"}, format.getHeader());
    }

    @Test
    void testGetHeaderReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "b").get();
        final String[] gotten = format.getHeader();
        gotten[0] = "mutated";
        assertArrayEquals(new String[] {"a", "b"}, format.getHeader());
    }

    @Test
    void testGetHeaderComments() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeaderComments("line1", "line2").get();
        assertArrayEquals(new String[] {"line1", "line2"}, format.getHeaderComments());
    }

    @Test
    void testSetHeaderNullDisablesHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a").get();
        final CSVFormat cleared = format.builder().setHeader((String[]) null).get();
        assertNull(cleared.getHeader());
    }

    @Test
    void testSetMaxRowsAndGetMaxRows() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setMaxRows(5L).get();
        assertEquals(5L, format.getMaxRows());
    }

    @Test
    void testSetNullStringAffectsIsNullStringSet() {
        assertFalse(CSVFormat.DEFAULT.isNullStringSet());
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        assertTrue(format.isNullStringSet());
        assertEquals("NULL", format.getNullString());
    }

    @Test
    void testSetQuoteNullDisablesQuoting() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setQuote((Character) null).get();
        assertFalse(format.isQuoteCharacterSet());
        assertNull(format.getQuoteCharacter());
    }

    // ---------------------------------------------------------------
    // equals / hashCode / toString
    // ---------------------------------------------------------------

    @Test
    void testEqualsReflexiveAndNullSafe() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.DEFAULT);
        assertNotEquals(null, CSVFormat.DEFAULT);
        assertNotEquals("not a format", CSVFormat.DEFAULT);
    }

    @Test
    void testEqualsAndHashCodeForEquivalentFormats() {
        final CSVFormat first = CSVFormat.DEFAULT.builder().setHeader("a", "b").get();
        final CSVFormat second = CSVFormat.DEFAULT.builder().setHeader("a", "b").get();
        assertEquals(first, second);
        assertEquals(first.hashCode(), second.hashCode());
    }

    @Test
    void testEqualsFalseForDifferentDelimiter() {
        final CSVFormat first = CSVFormat.DEFAULT;
        final CSVFormat second = CSVFormat.DEFAULT.builder().setDelimiter(';').get();
        assertNotEquals(first, second);
    }

    @Test
    void testToStringContainsDelimiterAndHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader("a", "b").get();
        final String text = format.toString();
        assertTrue(text.contains("Delimiter=<,>"));
        assertTrue(text.contains("Header:"));
        assertTrue(text.contains("[a, b]"));
    }

    @Test
    void testToStringOmitsUnsetOptionalFields() {
        final String text = CSVFormat.newFormat('|').toString();
        assertFalse(text.contains("Escape="));
        assertFalse(text.contains("QuoteChar="));
        assertFalse(text.contains("CommentStart="));
        assertFalse(text.contains("NullString="));
    }

    // ---------------------------------------------------------------
    // format(Object...)
    // ---------------------------------------------------------------

    @Test
    void testFormatSimpleValues() {
        assertEquals("a,b,c", CSVFormat.DEFAULT.format("a", "b", "c"));
    }

    @Test
    void testFormatQuotesValueContainingDelimiter() {
        assertEquals("\"a,b\",c", CSVFormat.DEFAULT.format("a,b", "c"));
    }

    @Test
    void testFormatWithNoRecordSeparatorKeepsFullOutput() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setRecordSeparator(null).get();
        assertEquals("a,b", format.format("a", "b"));
    }

    // ---------------------------------------------------------------
    // print / println / printRecord
    // ---------------------------------------------------------------

    @Test
    void testPrintObjectAppendableNewRecordNoLeadingDelimiter() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.print("hello", writer, true);
        assertEquals("hello", writer.toString());
    }

    @Test
    void testPrintObjectAppendableNotNewRecordAddsLeadingDelimiter() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.print("hello", writer, false);
        assertEquals(",hello", writer.toString());
    }

    @Test
    void testPrintNullValueWithNullStringUsesNullString() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setNullString("NULL").get();
        final StringWriter writer = new StringWriter();
        format.print(null, writer, true);
        assertEquals("NULL", writer.toString());
    }

    @Test
    void testPrintNullValueWithoutNullStringWritesEmpty() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.print(null, writer, true);
        assertEquals("", writer.toString());
    }

    @Test
    void testPrintlnWithoutTrailingDelimiterWritesOnlyRecordSeparator() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.println(writer);
        assertEquals("\r\n", writer.toString());
    }

    @Test
    void testPrintlnWithTrailingDelimiterWritesDelimiterThenSeparator() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setTrailingDelimiter(true).get();
        final StringWriter writer = new StringWriter();
        format.println(writer);
        assertEquals(",\r\n", writer.toString());
    }

    @Test
    void testPrintRecordWritesDelimitedValuesAndSeparator() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.printRecord(writer, "x", "y", "z");
        assertEquals("x,y,z\r\n", writer.toString());
    }

    @Test
    void testPrintReturnsWorkingCsvPrinter() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = CSVFormat.DEFAULT.print(writer);
        printer.printRecord("1", "2");
        printer.flush();
        assertEquals("1,2\r\n", writer.toString());
    }

    // ---------------------------------------------------------------
    // parse
    // ---------------------------------------------------------------

    @Test
    void testParseReturnsRecordsMatchingInput() throws IOException {
        final CSVParser parser = CSVFormat.DEFAULT.parse(new StringReader("a,b,c\r\n1,2,3\r\n"));
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        assertEquals("a", records.get(0).get(0));
        assertEquals("3", records.get(1).get(2));
        parser.close();
    }

    @Test
    void testParseWithHeaderAllowsNamedAccess() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setHeader().setSkipHeaderRecord(true).get();
        final CSVParser parser = format.parse(new StringReader("name,age\r\nBob,42\r\n"));
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(1, records.size());
        assertEquals("Bob", records.get(0).get("name"));
        assertEquals("42", records.get(0).get("age"));
        parser.close();
    }

    // ---------------------------------------------------------------
    // deprecated with* methods (still part of the public API)
    // ---------------------------------------------------------------

    @Test
    @SuppressWarnings("deprecation")
    void testWithDelimiterCreatesNewFormatWithChangedDelimiter() {
        final CSVFormat format = CSVFormat.DEFAULT.withDelimiter(';');
        assertEquals(';', format.getDelimiter());
        assertEquals(',', CSVFormat.DEFAULT.getDelimiter());
    }

    @Test
    @SuppressWarnings("deprecation")
    void testWithHeaderSetsHeaderArray() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("x", "y");
        assertArrayEquals(new String[] {"x", "y"}, format.getHeader());
    }

    @Test
    @SuppressWarnings("deprecation")
    void testWithFirstRecordAsHeaderParsesAutomatically() {
        final CSVFormat format = CSVFormat.DEFAULT.withFirstRecordAsHeader();
        assertArrayEquals(new String[] {}, format.getHeader());
        assertTrue(format.getSkipHeaderRecord());
    }

    @Test
    @SuppressWarnings("deprecation")
    void testWithIgnoreEmptyLinesNoArgSetsTrue() {
        final CSVFormat format = CSVFormat.RFC4180.withIgnoreEmptyLines();
        assertTrue(format.getIgnoreEmptyLines());
    }

    @Test
    @SuppressWarnings("deprecation")
    void testWithAllowDuplicateHeaderNamesFalseSetsAllowEmpty() {
        final CSVFormat format = CSVFormat.DEFAULT.withAllowDuplicateHeaderNames(false);
        assertEquals(DuplicateHeaderMode.ALLOW_EMPTY, format.getDuplicateHeaderMode());
        assertFalse(format.getAllowDuplicateHeaderNames());
    }

    @Test
    @SuppressWarnings("deprecation")
    void testWithTrailingDelimiterNoArgSetsTrue() {
        final CSVFormat format = CSVFormat.DEFAULT.withTrailingDelimiter();
        assertTrue(format.getTrailingDelimiter());
    }

    @Test
    @SuppressWarnings("deprecation")
    void testWithQuoteModeSetsMode() {
        final CSVFormat format = CSVFormat.DEFAULT.builder().setEscape('\\').get().withQuoteMode(QuoteMode.NONE);
        assertEquals(QuoteMode.NONE, format.getQuoteMode());
    }

    @Test
    @SuppressWarnings("deprecation")
    void testBuildDeprecatedAliasForGet() {
        final CSVFormat.Builder builder = CSVFormat.Builder.create().setDelimiter('|');
        assertEquals(builder.get(), builder.build());
    }

    // ---------------------------------------------------------------
    // immutability of builder() copies
    // ---------------------------------------------------------------

    @Test
    void testBuilderProducesIndependentCopy() {
        final CSVFormat original = CSVFormat.DEFAULT;
        final CSVFormat modified = original.builder().setDelimiter('|').get();
        assertEquals(',', original.getDelimiter());
        assertEquals('|', modified.getDelimiter());
        assertNotEquals(original, modified);
    }

    /**
     * Minimal stand-in for {@code org.junit.jupiter.api.function.Executable} so this file stays
     * self-contained without importing it.
     */
    private interface Executable {
        void run();
    }

    private static void assertThrows(final Class<? extends Throwable> expectedType, final Executable executable) {
        try {
            executable.run();
        } catch (final Throwable actual) {
            if (expectedType.isInstance(actual)) {
                return;
            }
            throw new AssertionError("Expected " + expectedType.getName() + " but got " + actual.getClass().getName(), actual);
        }
        throw new AssertionError("Expected " + expectedType.getName() + " to be thrown, but nothing was thrown");
    }
}
