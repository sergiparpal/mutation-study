/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.BitSet;
import java.util.Map;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link ArrayUtils}.
 */
public class ArrayUtilsAgentTest {

    @Test
    public void testAddBoolean() {
        final boolean[] result = ArrayUtils.add(new boolean[] {true}, false);
        assertArrayEquals(new boolean[] {true, false}, result);
        final boolean[] fromNull = ArrayUtils.add((boolean[]) null, true);
        assertArrayEquals(new boolean[] {true}, fromNull);
    }

    @Test
    public void testAddIntAtIndex() {
        final int[] result = ArrayUtils.add(new int[] {1, 2, 3}, 1, 99);
        assertArrayEquals(new int[] {1, 99, 2, 3}, result);
        assertThrows(IndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ArrayUtils.add(new int[] {1, 2, 3}, 5, 99);
            }
        });
    }

    @Test
    public void testAddGenericObject() {
        final String[] base = {"a", "b"};
        final String[] result = ArrayUtils.add(base, "c");
        assertArrayEquals(new String[] {"a", "b", "c"}, result);
        assertEquals(2, base.length);
    }

    @Test
    public void testAddAllPrimitive() {
        final int[] result = ArrayUtils.addAll(new int[] {1, 2}, 3, 4);
        assertArrayEquals(new int[] {1, 2, 3, 4}, result);
        assertArrayEquals(new int[] {1, 2}, ArrayUtils.addAll(new int[] {1, 2}, (int[]) null));
        assertArrayEquals(new int[] {1, 2}, ArrayUtils.addAll((int[]) null, 1, 2));
    }

    @Test
    public void testAddFirst() {
        final int[] result = ArrayUtils.addFirst(new int[] {2, 3}, 1);
        assertArrayEquals(new int[] {1, 2, 3}, result);
        assertArrayEquals(new int[] {1}, ArrayUtils.addFirst((int[]) null, 1));
    }

    @Test
    public void testArraycopyObject() {
        final Integer[] src = {1, 2, 3, 4, 5};
        final Integer[] dest = ArrayUtils.arraycopy(src, 1, 0, 3, new java.util.function.Function<Integer, Integer[]>() {
            @Override
            public Integer[] apply(final Integer value) {
                return new Integer[value];
            }
        });
        assertArrayEquals(new Integer[] {2, 3, 4}, dest);
    }

    @Test
    public void testClone() {
        final int[] original = {1, 2, 3};
        final int[] cloned = ArrayUtils.clone(original);
        assertArrayEquals(original, cloned);
        assertTrue(original != cloned);
        assertNull(ArrayUtils.clone((int[]) null));
    }

    @Test
    public void testConcat() {
        final int[] result = ArrayUtils.concat(new int[] {1, 2}, new int[] {3}, new int[] {4, 5});
        assertArrayEquals(new int[] {1, 2, 3, 4, 5}, result);
    }

    @Test
    public void testContains() {
        final int[] array = {1, 2, 3};
        assertTrue(ArrayUtils.contains(array, 2));
        assertFalse(ArrayUtils.contains(array, 99));
        assertFalse(ArrayUtils.contains((int[]) null, 1));
        assertTrue(ArrayUtils.contains(new double[] {1.0, 2.0}, 1.0005, 0.01));
    }

    @Test
    public void testContainsAny() {
        final Object[] array = {"a", "b", "c"};
        assertTrue(ArrayUtils.containsAny(array, "x", "b"));
        assertFalse(ArrayUtils.containsAny(array, "x", "y"));
        assertFalse(ArrayUtils.containsAny((Object[]) null, "a"));
    }

    @Test
    public void testGetComponentType() {
        final String[] strings = {"a"};
        assertEquals(String.class, ArrayUtils.getComponentType(strings));
    }

    @Test
    public void testGetLength() {
        assertEquals(0, ArrayUtils.getLength(null));
        assertEquals(0, ArrayUtils.getLength(new Object[0]));
        assertEquals(1, ArrayUtils.getLength(new Object[] {null}));
        assertEquals(2, ArrayUtils.getLength(new boolean[] {true, false}));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ArrayUtils.getLength("not an array");
            }
        });
    }

    @Test
    public void testGetDimensions() {
        assertEquals(0, ArrayUtils.getDimensions(null));
        assertEquals(0, ArrayUtils.getDimensions("not an array"));
        assertEquals(1, ArrayUtils.getDimensions(new int[] {1, 2}));
        assertEquals(2, ArrayUtils.getDimensions(new int[1][1]));
    }

    @Test
    public void testHashCode() {
        assertEquals(ArrayUtils.hashCode(new int[] {1, 2, 3}), ArrayUtils.hashCode(new int[] {1, 2, 3}));
    }

    @Test
    public void testIndexesOf() {
        final int[] array = {1, 2, 1, 3, 1};
        final BitSet bits = ArrayUtils.indexesOf(array, 1);
        assertTrue(bits.get(0));
        assertTrue(bits.get(2));
        assertTrue(bits.get(4));
        assertFalse(bits.get(1));
        assertEquals(3, bits.cardinality());
        assertTrue(ArrayUtils.indexesOf((int[]) null, 1).isEmpty());
    }

    @Test
    public void testIndexOfAndLastIndexOf() {
        final int[] array = {1, 2, 3, 2, 1};
        assertEquals(1, ArrayUtils.indexOf(array, 2));
        assertEquals(3, ArrayUtils.lastIndexOf(array, 2));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf(array, 99));
        assertEquals(ArrayUtils.INDEX_NOT_FOUND, ArrayUtils.indexOf((int[]) null, 1));
    }

    @Test
    public void testInsert() {
        final int[] result = ArrayUtils.insert(1, new int[] {1, 2, 3}, 99);
        assertArrayEquals(new int[] {1, 99, 2, 3}, result);
        assertNull(ArrayUtils.insert(0, (int[]) null, 1));
        assertThrows(IndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ArrayUtils.insert(-1, new int[] {1, 2, 3}, 99);
            }
        });
        assertThrows(IndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ArrayUtils.insert(4, new int[] {1, 2, 3}, 99);
            }
        });
    }

    @Test
    public void testIsArrayIndexValid() {
        assertFalse(ArrayUtils.isArrayIndexValid((Object[]) null, 0));
        assertFalse(ArrayUtils.isArrayIndexValid(new Object[0], 0));
        assertTrue(ArrayUtils.isArrayIndexValid(new Object[] {"a"}, 0));
        assertFalse(ArrayUtils.isArrayIndexValid(new Object[] {"a"}, 1));
        assertFalse(ArrayUtils.isArrayIndexValid(new Object[] {"a"}, -1));
    }

    @Test
    public void testIsEmptyAndIsNotEmpty() {
        assertTrue(ArrayUtils.isEmpty((int[]) null));
        assertTrue(ArrayUtils.isEmpty(new int[0]));
        assertFalse(ArrayUtils.isEmpty(new int[] {1}));
        assertFalse(ArrayUtils.isNotEmpty((Object[]) null));
        assertTrue(ArrayUtils.isNotEmpty(new Object[] {"a"}));
    }

    @Test
    public void testIsEquals() {
        assertTrue(ArrayUtils.isEquals(new int[] {1, 2}, new int[] {1, 2}));
        assertFalse(ArrayUtils.isEquals(new int[] {1, 2}, new int[] {1, 3}));
        assertTrue(ArrayUtils.isEquals(null, null));
        assertFalse(ArrayUtils.isEquals(null, new int[] {1}));
    }

    @Test
    public void testIsSameLength() {
        assertTrue(ArrayUtils.isSameLength(new int[] {1, 2}, new int[] {3, 4}));
        assertFalse(ArrayUtils.isSameLength(new int[] {1}, new int[] {1, 2}));
        assertTrue(ArrayUtils.isSameLength((Object[]) null, null));
    }

    @Test
    public void testIsSameType() {
        assertTrue(ArrayUtils.isSameType(new int[0], new int[0]));
        assertFalse(ArrayUtils.isSameType(new int[0], new long[0]));
        assertFalse(ArrayUtils.isSameType(new int[0], "not an array"));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ArrayUtils.isSameType(null, new int[0]);
            }
        });
    }

    @Test
    public void testIsSorted() {
        assertTrue(ArrayUtils.isSorted(new int[] {1, 2, 3}));
        assertFalse(ArrayUtils.isSorted(new int[] {3, 2, 1}));
        assertTrue(ArrayUtils.isSorted(new int[0]));
        assertTrue(ArrayUtils.isSorted((int[]) null));
    }

    @Test
    public void testNullToEmpty() {
        assertSame(ArrayUtils.EMPTY_INT_ARRAY, ArrayUtils.nullToEmpty((int[]) null));
        final int[] nonNull = {1, 2};
        assertSame(nonNull, ArrayUtils.nullToEmpty(nonNull));
        assertSame(ArrayUtils.EMPTY_STRING_ARRAY, ArrayUtils.nullToEmpty((String[]) null));
    }

    @Test
    public void testRemove() {
        final int[] result = ArrayUtils.remove(new int[] {1, 2, 3}, 1);
        assertArrayEquals(new int[] {1, 3}, result);
        assertThrows(IndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ArrayUtils.remove(new int[] {1, 2, 3}, 3);
            }
        });
        assertThrows(IndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ArrayUtils.remove((int[]) null, 0);
            }
        });
    }

    @Test
    public void testRemoveElement() {
        final int[] result = ArrayUtils.removeElement(new int[] {1, 2, 3}, 2);
        assertArrayEquals(new int[] {1, 3}, result);
        final int[] noMatch = ArrayUtils.removeElement(new int[] {1, 2, 3}, 99);
        assertArrayEquals(new int[] {1, 2, 3}, noMatch);
    }

    @Test
    public void testRemoveAllOccurrences() {
        final int[] result = ArrayUtils.removeAllOccurrences(new int[] {1, 2, 1, 3, 1}, 1);
        assertArrayEquals(new int[] {2, 3}, result);
    }

    @Test
    public void testRemoveAll() {
        final int[] result = ArrayUtils.removeAll(new int[] {1, 2, 3, 4, 5}, 1, 3);
        assertArrayEquals(new int[] {1, 3, 5}, result);
    }

    @Test
    public void testReverse() {
        final int[] array = {1, 2, 3, 4, 5};
        ArrayUtils.reverse(array);
        assertArrayEquals(new int[] {5, 4, 3, 2, 1}, array);
    }

    @Test
    public void testReverseRange() {
        final int[] array = {1, 2, 3, 4, 5};
        ArrayUtils.reverse(array, 1, 4);
        assertArrayEquals(new int[] {1, 4, 3, 2, 5}, array);
    }

    @Test
    public void testReverseNullDoesNothing() {
        ArrayUtils.reverse((int[]) null);
    }

    @Test
    public void testSetAll() {
        final Integer[] array = new Integer[5];
        final Integer[] result = ArrayUtils.setAll(array, new java.util.function.IntFunction<Integer>() {
            @Override
            public Integer apply(final int index) {
                return index * 2;
            }
        });
        assertArrayEquals(new Integer[] {0, 2, 4, 6, 8}, result);
        assertSame(array, result);
    }

    @Test
    public void testShift() {
        final int[] array = {1, 2, 3, 4, 5};
        ArrayUtils.shift(array, 2);
        assertArrayEquals(new int[] {4, 5, 1, 2, 3}, array);
    }

    @Test
    public void testShiftNullOrEmptyDoesNothing() {
        ArrayUtils.shift((int[]) null, 1);
        final int[] empty = {};
        ArrayUtils.shift(empty, 1);
        assertEquals(0, empty.length);
    }

    @Test
    public void testStartsWith() {
        assertTrue(ArrayUtils.startsWith(new byte[] {1, 2, 3}, new byte[] {1, 2}));
        assertFalse(ArrayUtils.startsWith(new byte[] {1, 2, 3}, new byte[] {2, 3}));
        assertTrue(ArrayUtils.startsWith((byte[]) null, null));
        assertFalse(ArrayUtils.startsWith(new byte[] {1}, null));
        assertFalse(ArrayUtils.startsWith(new byte[] {1}, new byte[] {1, 2}));
    }

    @Test
    public void testSubarray() {
        final int[] array = {1, 2, 3, 4, 5};
        assertArrayEquals(new int[] {2, 3, 4}, ArrayUtils.subarray(array, 1, 4));
        assertArrayEquals(new int[0], ArrayUtils.subarray(array, 3, 1));
        assertArrayEquals(array, ArrayUtils.subarray(array, -5, 100));
        assertNull(ArrayUtils.subarray((int[]) null, 0, 1));
    }

    @Test
    public void testSwap() {
        final int[] array = {1, 2, 3};
        ArrayUtils.swap(array, 0, 2);
        assertArrayEquals(new int[] {3, 2, 1}, array);
        ArrayUtils.swap(array, 0, 10);
        assertArrayEquals(new int[] {3, 2, 1}, array);
    }

    @Test
    public void testSwapRange() {
        final int[] array = {1, 2, 3, 4};
        ArrayUtils.swap(array, 0, 2, 2);
        assertArrayEquals(new int[] {3, 4, 1, 2}, array);
    }

    @Test
    public void testToArray() {
        final String[] array = ArrayUtils.toArray("1", "2");
        assertArrayEquals(new String[] {"1", "2"}, array);
    }

    @Test
    public void testToMap() {
        final Map<Object, Object> map = ArrayUtils.toMap(new String[][] {{"RED", "#FF0000"}, {"GREEN", "#00FF00"}});
        assertEquals("#FF0000", map.get("RED"));
        assertEquals("#00FF00", map.get("GREEN"));
        assertNull(ArrayUtils.toMap(null));
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ArrayUtils.toMap(new Object[] {new Object[] {"onlyone"}});
            }
        });
    }

    @Test
    public void testToObjectAndToPrimitive() {
        final int[] primitive = {1, 2, 3};
        final Integer[] boxed = ArrayUtils.toObject(primitive);
        assertArrayEquals(new Integer[] {1, 2, 3}, boxed);
        final int[] backToPrimitive = ArrayUtils.toPrimitive(boxed);
        assertArrayEquals(primitive, backToPrimitive);
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                ArrayUtils.toPrimitive(new Integer[] {1, null, 3});
            }
        });
        assertArrayEquals(new int[] {1, 0, 3}, ArrayUtils.toPrimitive(new Integer[] {1, null, 3}, 0));
    }

    @Test
    public void testToPrimitiveObjectDispatch() {
        final Object result = ArrayUtils.toPrimitive(new Integer[] {1, 2, 3});
        assertTrue(result instanceof int[]);
        assertArrayEquals(new int[] {1, 2, 3}, (int[]) result);
        assertNull(ArrayUtils.toPrimitive((Object) null));
        final String[] strings = {"a", "b"};
        assertSame(strings, ArrayUtils.toPrimitive((Object) strings));
    }

    @Test
    public void testToString() {
        assertEquals("{}", ArrayUtils.toString(new Object[0]));
        assertEquals("{}", ArrayUtils.toString(null));
        assertEquals("<empty>", ArrayUtils.toString(null, "<empty>"));
        assertEquals("{1,2}", ArrayUtils.toString(new int[] {1, 2}));
    }

    @Test
    public void testToStringArray() {
        final String[] result = ArrayUtils.toStringArray(new Object[] {1, "a", null});
        assertEquals("1", result[0]);
        assertEquals("a", result[1]);
        assertEquals("null", result[2]);
        final String[] withDefault = ArrayUtils.toStringArray(new Object[] {null}, "N/A");
        assertEquals("N/A", withDefault[0]);
    }

    @Test
    public void testGet() {
        final String[] array = {"a", "b"};
        assertEquals("a", ArrayUtils.get(array, 0));
        assertNull(ArrayUtils.get(array, 5));
        assertEquals("default", ArrayUtils.get(array, 5, "default"));
    }

    @Test
    public void testNewInstance() {
        final String[] array = ArrayUtils.newInstance(String.class, 3);
        assertEquals(3, array.length);
        assertNotNull(array);
    }

    @Test
    public void testIsSortedWithComparator() {
        final Integer[] array = {3, 2, 1};
        assertTrue(ArrayUtils.isSorted(array, new java.util.Comparator<Integer>() {
            @Override
            public int compare(final Integer a, final Integer b) {
                return b - a;
            }
        }));
    }
}
