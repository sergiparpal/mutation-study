/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.ClassUtils.Interfaces;
import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link MethodUtils}.
 */
public class MethodUtilsAgentTest {

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    public @interface Marker {
    }

    public interface Greeter {
        String greet(String name);
    }

    public static class GreeterImpl implements Greeter {
        @Override
        public String greet(final String name) {
            return "Hello, " + name;
        }

        @Marker
        public String greetMarked(final String name) {
            return "Hi, " + name;
        }

        public String shout() {
            return "shout";
        }

        @SuppressWarnings("unused")
        private String secret() {
            return "secret";
        }
    }

    private static class PrivateClass {
        @SuppressWarnings("unused")
        public static class PublicInnerClass {
            public PublicInnerClass() {
            }

            public String identify() {
                return "inner";
            }
        }

        public String publicMethodOnPrivateClass() {
            return "value";
        }
    }

    public static class StaticHolder {
        public static String add(final int a, final int b) {
            return "sum:" + (a + b);
        }

        public static String fail() {
            throw new IllegalStateException("boom");
        }

        private StaticHolder() {
        }
    }

    public static class VarArgsBean {
        private final String[] rest;

        public VarArgsBean(final String first, final String... rest) {
            this.rest = rest;
        }

        public String[] getRest() {
            return rest;
        }

        public String join(final String first, final String... rest) {
            final StringBuilder sb = new StringBuilder(first);
            for (final String s : rest) {
                sb.append(',').append(s);
            }
            return sb.toString();
        }

        public String sumInts(final Integer first, final int... values) {
            int total = first;
            for (final int v : values) {
                total += v;
            }
            return String.valueOf(total);
        }
    }

    public static class Overloaded {
        public String call(final int i) {
            return "int:" + i;
        }

        public String call(final Object o) {
            return "object:" + o;
        }

        public String call(final String s) {
            return "string:" + s;
        }
    }

    @Test
    void testConstructorDeprecatedButUsable() {
        assertNotNull(new MethodUtils());
    }

    @Test
    void testGetAccessibleMethodFound() throws NoSuchMethodException {
        final Method method = Greeter.class.getMethod("greet", String.class);
        final Method accessible = MethodUtils.getAccessibleMethod(GreeterImpl.class, method);
        assertNotNull(accessible);
        assertEquals("greet", accessible.getName());
    }

    @Test
    void testGetAccessibleMethodByNameAndParams() {
        final Method method = MethodUtils.getAccessibleMethod(GreeterImpl.class, "greet", String.class);
        assertNotNull(method);
        assertEquals(GreeterImpl.class, method.getDeclaringClass());
    }

    @Test
    void testGetAccessibleMethodNonPublicNotFound() {
        final Method method = MethodUtils.getAccessibleMethod(GreeterImpl.class, "secret");
        assertNull(method);
    }

    @Test
    void testGetAccessibleMethodNullMethod() {
        assertNull(MethodUtils.getAccessibleMethod((Method) null));
    }

    @Test
    void testGetAccessibleMethodFromPublicInnerOfPrivateClass() throws NoSuchMethodException {
        final Method method = PrivateClass.PublicInnerClass.class.getMethod("identify");
        // Declaring class chain is public (PublicInnerClass itself is public static), so returned as-is.
        final Method accessible = MethodUtils.getAccessibleMethod(method);
        assertNotNull(accessible);
    }

    @Test
    void testGetAnnotationDirect() throws NoSuchMethodException {
        final Method method = GreeterImpl.class.getMethod("greetMarked", String.class);
        final Marker marker = MethodUtils.getAnnotation(method, Marker.class, false, false);
        assertNotNull(marker);
    }

    @Test
    void testGetAnnotationNotPresent() throws NoSuchMethodException {
        final Method method = GreeterImpl.class.getMethod("greet", String.class);
        assertNull(MethodUtils.getAnnotation(method, Marker.class, true, true));
    }

    @Test
    void testGetAnnotationNullMethodThrows() {
        assertThrows(NullPointerException.class, () -> MethodUtils.getAnnotation(null, Marker.class, true, true));
    }

    @Test
    void testGetAnnotationNullAnnotationClassThrows() throws NoSuchMethodException {
        final Method method = GreeterImpl.class.getMethod("greet", String.class);
        assertThrows(NullPointerException.class, () -> MethodUtils.getAnnotation(method, null, true, true));
    }

    @Test
    void testGetMatchingAccessibleMethodExact() {
        final Method method = MethodUtils.getMatchingAccessibleMethod(Overloaded.class, "call", String.class);
        assertNotNull(method);
        assertEquals(String.class, method.getParameterTypes()[0]);
    }

    @Test
    void testGetMatchingAccessibleMethodWidening() {
        final Method method = MethodUtils.getMatchingAccessibleMethod(Overloaded.class, "call", Byte.class);
        assertNotNull(method);
        assertEquals(Integer.TYPE, method.getParameterTypes()[0]);
    }

    @Test
    void testGetMatchingAccessibleMethodNoMatch() {
        assertNull(MethodUtils.getMatchingAccessibleMethod(Overloaded.class, "noSuchMethod", String.class));
    }

    @Test
    void testGetMatchingMethodNullClassThrows() {
        assertThrows(NullPointerException.class, () -> MethodUtils.getMatchingMethod(null, "call", String.class));
    }

    @Test
    void testGetMatchingMethodEmptyNameThrows() {
        assertThrows(IllegalArgumentException.class, () -> MethodUtils.getMatchingMethod(Overloaded.class, "", String.class));
    }

    @Test
    void testGetMatchingMethodExactMatch() {
        final Method method = MethodUtils.getMatchingMethod(Overloaded.class, "call", Integer.TYPE);
        assertNotNull(method);
        assertEquals(Integer.TYPE, method.getParameterTypes()[0]);
    }

    @Test
    void testGetMatchingMethodNoCandidates() {
        assertNull(MethodUtils.getMatchingMethod(StaticHolder.class, "doesNotExist"));
    }

    @Test
    void testGetMethodObjectFound() {
        final Method method = MethodUtils.getMethodObject(GreeterImpl.class, "greet", String.class);
        assertNotNull(method);
    }

    @Test
    void testGetMethodObjectNotFoundReturnsNull() {
        assertNull(MethodUtils.getMethodObject(GreeterImpl.class, "doesNotExist"));
    }

    @Test
    void testGetMethodObjectNullArgsReturnsNull() {
        assertNull(MethodUtils.getMethodObject(null, "greet"));
        assertNull(MethodUtils.getMethodObject(GreeterImpl.class, null));
    }

    @Test
    void testGetMethodsListWithAnnotation() {
        final List<Method> methods = MethodUtils.getMethodsListWithAnnotation(GreeterImpl.class, Marker.class);
        assertEquals(1, methods.size());
        assertEquals("greetMarked", methods.get(0).getName());
    }

    @Test
    void testGetMethodsListWithAnnotationNullClassThrows() {
        assertThrows(NullPointerException.class, () -> MethodUtils.getMethodsListWithAnnotation(null, Marker.class));
    }

    @Test
    void testGetMethodsListWithAnnotationNullAnnotationThrows() {
        assertThrows(NullPointerException.class, () -> MethodUtils.getMethodsListWithAnnotation(GreeterImpl.class, null));
    }

    @Test
    void testGetMethodsWithAnnotationEmptyWhenNoneMatch() {
        final Method[] methods = MethodUtils.getMethodsWithAnnotation(StaticHolder.class, Marker.class);
        assertEquals(0, methods.length);
    }

    @Test
    void testGetMethodsWithAnnotationArray() {
        final Method[] methods = MethodUtils.getMethodsWithAnnotation(GreeterImpl.class, Marker.class);
        assertEquals(1, methods.length);
    }

    @Test
    void testGetOverrideHierarchy() throws NoSuchMethodException {
        final Method method = GreeterImpl.class.getMethod("greet", String.class);
        final Set<Method> hierarchy = MethodUtils.getOverrideHierarchy(method, Interfaces.INCLUDE);
        assertTrue(hierarchy.contains(method));
        assertTrue(hierarchy.size() >= 2);
    }

    @Test
    void testGetOverrideHierarchyExcludeInterfaces() throws NoSuchMethodException {
        final Method method = GreeterImpl.class.getMethod("greet", String.class);
        final Set<Method> hierarchy = MethodUtils.getOverrideHierarchy(method, Interfaces.EXCLUDE);
        assertEquals(1, hierarchy.size());
    }

    @Test
    void testGetOverrideHierarchyNullThrows() {
        assertThrows(NullPointerException.class, () -> MethodUtils.getOverrideHierarchy(null, Interfaces.INCLUDE));
    }

    @Test
    void testInvokeExactMethodNoArgs() throws Exception {
        final Object result = MethodUtils.invokeExactMethod(new GreeterImpl(), "shout");
        assertEquals("shout", result);
    }

    @Test
    void testInvokeExactMethodWithArgs() throws Exception {
        final Object result = MethodUtils.invokeExactMethod(new GreeterImpl(), "greet", "World");
        assertEquals("Hello, World", result);
    }

    @Test
    void testInvokeExactMethodWrongTypeThrows() {
        assertThrows(NoSuchMethodException.class, () -> MethodUtils.invokeExactMethod(new GreeterImpl(), "greet", Integer.valueOf(1)));
    }

    @Test
    void testInvokeExactMethodWithParameterTypes() throws Exception {
        final Object result = MethodUtils.invokeExactMethod(new GreeterImpl(), "greet", new Object[] { "Bob" }, new Class<?>[] { String.class });
        assertEquals("Hello, Bob", result);
    }

    @Test
    void testInvokeExactStaticMethod() throws Exception {
        final Object result = MethodUtils.invokeExactStaticMethod(StaticHolder.class, "add", new Object[] { 2, 3 }, new Class<?>[] { Integer.TYPE, Integer.TYPE });
        assertEquals("sum:5", result);
    }

    @Test
    void testInvokeExactStaticMethodWrapsTargetException() {
        final InvocationTargetException ex = assertThrows(InvocationTargetException.class,
                () -> MethodUtils.invokeExactStaticMethod(StaticHolder.class, "fail"));
        assertTrue(ex.getCause() instanceof IllegalStateException);
    }

    @Test
    void testInvokeMethodNoArgs() throws Exception {
        final Object result = MethodUtils.invokeMethod(new GreeterImpl(), "shout", (Object[]) null);
        assertEquals("shout", result);
    }

    @Test
    void testInvokeMethodNoArgsConvenience() throws Exception {
        final Object result = MethodUtils.invokeMethod(new GreeterImpl(), "shout");
        assertEquals("shout", result);
    }

    @Test
    void testInvokeMethodForceAccessPrivate() throws Exception {
        final Object result = MethodUtils.invokeMethod(new GreeterImpl(), true, "secret");
        assertEquals("secret", result);
    }

    @Test
    void testInvokeMethodWithoutForceAccessOnPrivateThrows() {
        assertThrows(NoSuchMethodException.class, () -> MethodUtils.invokeMethod(new GreeterImpl(), false, "secret"));
    }

    @Test
    void testInvokeMethodVarArgs() throws Exception {
        final VarArgsBean bean = new VarArgsBean("first");
        final Object result = MethodUtils.invokeMethod(bean, "join", "a", "b", "c");
        assertEquals("a,b,c", result);
    }

    @Test
    void testInvokeMethodVarArgsPrimitiveUnboxing() throws Exception {
        final VarArgsBean bean = new VarArgsBean("first");
        final Object result = MethodUtils.invokeMethod(bean, "sumInts", Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(3));
        assertEquals("6", result);
    }

    @Test
    void testInvokeMethodNullObjectThrows() {
        assertThrows(NullPointerException.class, () -> MethodUtils.invokeMethod(null, "greet", "x"));
    }

    @Test
    void testInvokeMethodNoSuchMethodThrows() {
        assertThrows(NoSuchMethodException.class, () -> MethodUtils.invokeMethod(new GreeterImpl(), "doesNotExist"));
    }

    @Test
    void testInvokeStaticMethod() throws Exception {
        final Object result = MethodUtils.invokeStaticMethod(StaticHolder.class, "add", Integer.valueOf(4), Integer.valueOf(5));
        assertEquals("sum:9", result);
    }

    @Test
    void testInvokeStaticMethodNoSuchMethodThrows() {
        assertThrows(NoSuchMethodException.class, () -> MethodUtils.invokeStaticMethod(StaticHolder.class, "doesNotExist"));
    }

    @Test
    void testInvokeStaticMethodWithParameterTypes() throws Exception {
        final Object result = MethodUtils.invokeStaticMethod(StaticHolder.class, "add", new Object[] { 1, 2 }, new Class<?>[] { Integer.TYPE, Integer.TYPE });
        assertEquals("sum:3", result);
    }

    @Test
    void testInvokeConstructorViaVarArgsConstructor() throws Exception {
        final VarArgsBean bean = new VarArgsBean("first");
        assertArrayEquals(new String[0], bean.getRest());
    }

    @Test
    void testGetMatchingAccessibleMethodOnNonPublicDeclaringClassFallsBackToCandidate() {
        // The declaring class is not public, but no accessible override exists on a public super type,
        // so the method falls back to the raw candidate (whose accessibility is forced via setAccessible).
        final Method method = MethodUtils.getMatchingAccessibleMethod(PrivateClass.class, "publicMethodOnPrivateClass");
        assertNotNull(method);
        assertEquals(PrivateClass.class, method.getDeclaringClass());
    }

    @Test
    void testGetAccessibleMethodReturnsSameForPublicDeclaringClass() throws NoSuchMethodException {
        final Method method = Object.class.getMethod("toString");
        final Method accessible = MethodUtils.getAccessibleMethod(Object.class, method);
        assertSame(method, accessible);
    }

    @Test
    void testGetAccessibleMethodNonPublicMethodReturnsNull() throws NoSuchMethodException {
        final Method method = GreeterImpl.class.getDeclaredMethod("secret");
        assertNull(MethodUtils.getAccessibleMethod(GreeterImpl.class, method));
    }

    @Test
    void testInvokeMethodBooleanMatchesPrimitive() throws Exception {
        final Overloaded overloaded = new Overloaded();
        final Object result = MethodUtils.invokeMethod(overloaded, "call", Integer.valueOf(7));
        assertEquals("int:7", result);
        assertFalse(result.toString().startsWith("object"));
    }
}
