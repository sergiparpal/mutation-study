/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InvalidObjectException;
import java.io.NotSerializableException;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link SerializationUtils}.
 */
public class SerializationUtilsAgentTest {

    static final class Box implements Serializable {
        private static final long serialVersionUID = 1L;
        private final int value;
        private final String label;

        Box(final int value, final String label) {
            this.value = value;
            this.label = label;
        }

        @Override
        public boolean equals(final Object obj) {
            if (!(obj instanceof Box)) {
                return false;
            }
            final Box other = (Box) obj;
            return value == other.value && (label == null ? other.label == null : label.equals(other.label));
        }

        @Override
        public int hashCode() {
            return value;
        }
    }

    static final class NotActuallySerializable implements Serializable {
        private static final long serialVersionUID = 1L;
        @SuppressWarnings("unused")
        private final Object notSerializable = new Object();
    }

    static final class ThrowingOutputStream extends OutputStream {
        @Override
        public void write(final int b) throws IOException {
            throw new IOException("boom");
        }
    }

    @Test
    public void testCloneNull() {
        assertNull(SerializationUtils.clone(null));
    }

    @Test
    public void testCloneProducesEqualButDistinctObject() {
        final Box original = new Box(42, "hello");
        final Box cloned = SerializationUtils.clone(original);
        assertEquals(original, cloned);
        assertNotSame(original, cloned);
    }

    @Test
    public void testCloneOfNonSerializableFieldThrows() {
        assertThrows(SerializationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                SerializationUtils.clone(new NotActuallySerializable());
            }
        });
    }

    @Test
    public void testCloneArrayList() {
        final ArrayList<String> list = new ArrayList<String>();
        list.add("a");
        list.add("b");
        final ArrayList<String> cloned = SerializationUtils.clone(list);
        assertEquals(list, cloned);
        assertNotSame(list, cloned);
    }

    @Test
    public void testSerializeAndDeserializeRoundTrip() {
        final Box original = new Box(7, "roundtrip");
        final byte[] bytes = SerializationUtils.serialize(original);
        final Box result = SerializationUtils.deserialize(bytes);
        assertEquals(original, result);
    }

    @Test
    public void testSerializeNullObject() {
        final byte[] bytes = SerializationUtils.serialize(null);
        final Object result = SerializationUtils.deserialize(bytes);
        assertNull(result);
        assertTrue(bytes.length > 0);
    }

    @Test
    public void testSerializeNullOutputStreamThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                SerializationUtils.serialize(new Box(1, "x"), null);
            }
        });
    }

    @Test
    public void testSerializeNonSerializableThrowsSerializationException() {
        assertThrows(SerializationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                SerializationUtils.serialize(new NotActuallySerializable());
            }
        });
    }

    @Test
    public void testSerializeIoErrorWrapsIntoSerializationException() {
        final SerializationException ex = assertThrows(SerializationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                SerializationUtils.serialize(new Box(1, "x"), new ThrowingOutputStream());
            }
        });
        assertTrue(ex.getCause() instanceof IOException);
    }

    @Test
    public void testDeserializeNullByteArrayThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                SerializationUtils.deserialize((byte[]) null);
            }
        });
    }

    @Test
    public void testDeserializeNullInputStreamThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                SerializationUtils.deserialize((java.io.InputStream) null);
            }
        });
    }

    @Test
    public void testDeserializeGarbageBytesThrowsSerializationException() {
        assertThrows(SerializationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                SerializationUtils.deserialize(new byte[] {1, 2, 3, 4, 5});
            }
        });
    }

    @Test
    public void testDeserializeEmptyByteArrayThrowsSerializationException() {
        assertThrows(SerializationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                SerializationUtils.deserialize(new byte[0]);
            }
        });
    }

    @Test
    public void testDeserializeFromStreamAndStreamIsClosed() throws IOException {
        final byte[] bytes = SerializationUtils.serialize(new Box(9, "stream"));
        final boolean[] closed = {false};
        final ByteArrayInputStream delegate = new ByteArrayInputStream(bytes);
        final java.io.InputStream in = new java.io.InputStream() {
            @Override
            public int read() throws IOException {
                return delegate.read();
            }

            @Override
            public int read(final byte[] b, final int off, final int len) throws IOException {
                return delegate.read(b, off, len);
            }

            @Override
            public void close() throws IOException {
                closed[0] = true;
                super.close();
            }
        };
        final Box result = SerializationUtils.deserialize(in);
        assertEquals(new Box(9, "stream"), result);
        assertTrue(closed[0]);
    }

    @Test
    public void testRoundtrip() {
        final HashMap<String, Integer> original = new HashMap<String, Integer>();
        original.put("one", 1);
        original.put("two", 2);
        final HashMap<String, Integer> result = SerializationUtils.roundtrip(original);
        assertEquals(original, result);
        assertNotSame(original, result);
    }

    @Test
    public void testRequireNonNullReturnsSameInstance() throws InvalidObjectException {
        final Box box = new Box(3, "z");
        assertEquals(box, SerializationUtils.requireNonNull(box, "must not be null"));
    }

    @Test
    public void testRequireNonNullThrowsInvalidObjectExceptionWithMessage() {
        final InvalidObjectException ex = assertThrows(InvalidObjectException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                SerializationUtils.requireNonNull(null, "custom message");
            }
        });
        assertEquals("custom message", ex.getMessage());
    }

    @Test
    public void testSerializeByteArrayMatchesStreamVariant() throws IOException {
        final Box box = new Box(11, "compare");
        final byte[] viaArray = SerializationUtils.serialize(box);
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        SerializationUtils.serialize(box, baos);
        assertArrayEquals(viaArray, baos.toByteArray());
    }

    @Test
    public void testConstructorIsPublic() {
        final SerializationUtils instance = new SerializationUtils();
        assertFalse(instance == null);
    }

    @Test
    public void testDeserializeNotSerializableWrapsNotSerializableException() {
        final byte[] bytes = {(byte) 0xAC, (byte) 0xED, 0x00, 0x05};
        final SerializationException ex = assertThrows(SerializationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                SerializationUtils.deserialize(bytes);
            }
        });
        assertTrue(ex.getCause() instanceof IOException || ex.getCause() instanceof NotSerializableException);
    }
}
