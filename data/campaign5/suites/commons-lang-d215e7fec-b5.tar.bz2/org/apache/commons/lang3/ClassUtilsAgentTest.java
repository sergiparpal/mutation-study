/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

public class ClassUtilsAgentTest {

    interface AgentSampleInterface {
    }

    static class AgentSampleParent implements AgentSampleInterface {
    }

    static class AgentSampleChild extends AgentSampleParent {
    }

    public static class AgentPublicBase {

        public void publicMethod() {
        }
    }

    private static class AgentPrivateSub extends AgentPublicBase {
    }

    class AgentInnerNonStatic {
    }

    @Test
    void testComparator() {
        final List<Class<?>> list = new ArrayList<Class<?>>();
        list.add(String.class);
        list.add(Integer.class);
        list.add(Boolean.class);
        list.sort(ClassUtils.comparator());
        assertEquals(Boolean.class, list.get(0));
        assertEquals(Integer.class, list.get(1));
        assertEquals(String.class, list.get(2));
    }

    @Test
    void testConvertClassesToClassNames() {
        final List<Class<?>> classes = new ArrayList<Class<?>>();
        classes.add(String.class);
        classes.add(null);
        final List<String> names = ClassUtils.convertClassesToClassNames(classes);
        assertEquals(2, names.size());
        assertEquals("java.lang.String", names.get(0));
        assertNull(names.get(1));
        assertNull(ClassUtils.convertClassesToClassNames(null));
    }

    @Test
    void testConvertClassNamesToClasses() {
        final List<String> names = new ArrayList<String>();
        names.add("java.lang.String");
        names.add("does.not.Exist");
        names.add(null);
        final List<Class<?>> classes = ClassUtils.convertClassNamesToClasses(names);
        assertEquals(3, classes.size());
        assertEquals(String.class, classes.get(0));
        assertNull(classes.get(1));
        assertNull(classes.get(2));
        assertNull(ClassUtils.convertClassNamesToClasses(null));
    }

    @Test
    void testGetAbbreviatedNameClassNull() {
        assertEquals("", ClassUtils.getAbbreviatedName((Class<?>) null, 10));
    }

    @Test
    void testGetAbbreviatedNameClass() {
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName(String.class, 5));
    }

    @Test
    void testGetAbbreviatedNameStringNull() {
        assertEquals("", ClassUtils.getAbbreviatedName((String) null, 10));
    }

    @Test
    void testGetAbbreviatedNameLengths() {
        assertEquals("j.l.String", ClassUtils.getAbbreviatedName("java.lang.String", 5));
        assertEquals("j.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 15));
        assertEquals("java.lang.String", ClassUtils.getAbbreviatedName("java.lang.String", 30));
        assertEquals("o.a.c.l.ClassUtils", ClassUtils.getAbbreviatedName("org.apache.commons.lang3.ClassUtils", 18));
    }

    @Test
    void testGetAbbreviatedNameInvalidLength() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ClassUtils.getAbbreviatedName("java.lang.String", 0);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                ClassUtils.getAbbreviatedName("java.lang.String", -1);
            }
        });
    }

    @Test
    void testGetAllInterfacesNull() {
        assertNull(ClassUtils.getAllInterfaces(null));
    }

    @Test
    void testGetAllInterfaces() {
        final List<Class<?>> interfaces = ClassUtils.getAllInterfaces(AgentSampleChild.class);
        assertTrue(interfaces.contains(AgentSampleInterface.class));
        assertEquals(1, interfaces.size());
    }

    @Test
    void testGetAllSuperclassesNull() {
        assertNull(ClassUtils.getAllSuperclasses(null));
    }

    @Test
    void testGetAllSuperclasses() {
        final List<Class<?>> superclasses = ClassUtils.getAllSuperclasses(AgentSampleChild.class);
        assertEquals(2, superclasses.size());
        assertEquals(AgentSampleParent.class, superclasses.get(0));
        assertEquals(Object.class, superclasses.get(1));
    }

    @Test
    void testGetCanonicalNameClass() {
        assertEquals("java.lang.String", ClassUtils.getCanonicalName(String.class));
        assertEquals("", ClassUtils.getCanonicalName((Class<?>) null));
        assertEquals("N/A", ClassUtils.getCanonicalName((Class<?>) null, "N/A"));
    }

    @Test
    void testGetCanonicalNameObject() {
        assertEquals("java.lang.String", ClassUtils.getCanonicalName("hello"));
        assertEquals("", ClassUtils.getCanonicalName((Object) null));
        assertEquals("N/A", ClassUtils.getCanonicalName((Object) null, "N/A"));
    }

    @Test
    void testGetClassFound() throws ClassNotFoundException {
        assertEquals(String.class, ClassUtils.getClass("java.lang.String"));
        assertEquals(int.class, ClassUtils.getClass("int"));
    }

    @Test
    void testGetClassNotFound() {
        assertThrows(ClassNotFoundException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass("does.not.Exist");
            }
        });
    }

    @Test
    void testGetClassNullName() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass((String) null);
            }
        });
    }

    @Test
    void testGetClassInnerWithDot() throws ClassNotFoundException {
        final Class<?> cls = ClassUtils.getClass("org.apache.commons.lang3.ClassUtilsAgentTest.AgentSampleChild");
        assertEquals(AgentSampleChild.class, cls);
    }

    @Test
    void testGetClassStrictWhitespaceFails() {
        assertThrows(ClassNotFoundException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClassStrict("java. lang.String");
            }
        });
    }

    @Test
    void testGetClassWhitespaceNormalized() throws ClassNotFoundException {
        assertEquals(String.class, ClassUtils.getClass("java. lang.String"));
    }

    @Test
    void testGetClassArrayDimensionTooLarge() {
        final StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 300; i++) {
            sb.append('[');
        }
        sb.append("Ljava.lang.String;");
        final String tooManyDimensions = sb.toString();
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getClass(tooManyDimensions);
            }
        });
    }

    @Test
    void testGetComponentType() {
        assertEquals(String.class, ClassUtils.getComponentType(String[].class));
        assertNull(ClassUtils.getComponentType(null));
    }

    @Test
    void testGetName() {
        assertEquals("java.lang.String", ClassUtils.getName(String.class));
        assertEquals("", ClassUtils.getName((Class<?>) null));
        assertEquals("N/A", ClassUtils.getName((Class<?>) null, "N/A"));
        assertEquals("java.lang.String", ClassUtils.getName("hello"));
        assertEquals("", ClassUtils.getName((Object) null));
        assertEquals("N/A", ClassUtils.getName((Object) null, "N/A"));
    }

    @Test
    void testGetPackageCanonicalName() {
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName(String.class));
        assertEquals("", ClassUtils.getPackageCanonicalName((Class<?>) null));
        assertEquals("java.lang", ClassUtils.getPackageCanonicalName("hello", "N/A"));
        assertEquals("N/A", ClassUtils.getPackageCanonicalName((Object) null, "N/A"));
    }

    @Test
    void testGetPackageName() {
        assertEquals("java.lang", ClassUtils.getPackageName(String.class));
        assertEquals("", ClassUtils.getPackageName((Class<?>) null));
        assertEquals("", ClassUtils.getPackageName(int[].class));
        assertEquals("java.lang", ClassUtils.getPackageName("hello", "N/A"));
        assertEquals("N/A", ClassUtils.getPackageName((Object) null, "N/A"));
        assertEquals("", ClassUtils.getPackageName((String) null));
        assertEquals("", ClassUtils.getPackageName(""));
    }

    @Test
    void testGetPublicMethod() throws Exception {
        final Method m = ClassUtils.getPublicMethod(AgentPrivateSub.class, "publicMethod");
        assertNotNull(m);
        assertEquals(AgentPublicBase.class, m.getDeclaringClass());
    }

    @Test
    void testGetPublicMethodNotFound() {
        assertThrows(NoSuchMethodException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                ClassUtils.getPublicMethod(String.class, "doesNotExist");
            }
        });
    }

    @Test
    void testGetShortCanonicalName() {
        assertEquals("String", ClassUtils.getShortCanonicalName(String.class));
        assertEquals("", ClassUtils.getShortCanonicalName((Object) null, ""));
        assertEquals("String[]", ClassUtils.getShortCanonicalName("[Ljava.lang.String;"));
    }

    @Test
    void testGetShortClassNameClass() {
        assertEquals("", ClassUtils.getShortClassName((Class<?>) null));
        assertEquals("String", ClassUtils.getShortClassName(String.class));
        assertEquals("String[]", ClassUtils.getShortClassName(String[].class));
    }

    @Test
    void testGetShortClassNameString() {
        assertEquals("", ClassUtils.getShortClassName((String) null));
        assertEquals("", ClassUtils.getShortClassName(""));
        assertEquals("String", ClassUtils.getShortClassName("java.lang.String"));
        assertEquals("int[]", ClassUtils.getShortClassName("[I"));
    }

    @Test
    void testGetShortClassNameObjectValueIfNull() {
        assertEquals("N/A", ClassUtils.getShortClassName(null, "N/A"));
        assertEquals("String", ClassUtils.getShortClassName("hello", "N/A"));
    }

    @Test
    void testGetSimpleName() {
        assertEquals("String", ClassUtils.getSimpleName(String.class));
        assertEquals("", ClassUtils.getSimpleName((Class<?>) null));
        assertEquals("N/A", ClassUtils.getSimpleName((Class<?>) null, "N/A"));
        assertEquals("String", ClassUtils.getSimpleName("hello"));
        assertEquals("", ClassUtils.getSimpleName((Object) null));
        assertEquals("N/A", ClassUtils.getSimpleName((Object) null, "N/A"));
    }

    @Test
    void testHierarchyExcludeInterfaces() {
        final Iterator<Class<?>> it = ClassUtils.hierarchy(AgentSampleChild.class).iterator();
        assertEquals(AgentSampleChild.class, it.next());
        assertEquals(AgentSampleParent.class, it.next());
        assertEquals(Object.class, it.next());
        assertFalse(it.hasNext());
    }

    @Test
    void testHierarchyIncludeInterfaces() {
        final Iterator<Class<?>> it = ClassUtils.hierarchy(AgentSampleChild.class, ClassUtils.Interfaces.INCLUDE).iterator();
        assertEquals(AgentSampleChild.class, it.next());
        assertEquals(AgentSampleParent.class, it.next());
        assertEquals(AgentSampleInterface.class, it.next());
        assertEquals(Object.class, it.next());
        assertFalse(it.hasNext());
    }

    @Test
    void testIsAssignable() {
        assertTrue(ClassUtils.isAssignable(Integer.class, Integer.class));
        assertTrue(ClassUtils.isAssignable(Integer.TYPE, Integer.class));
        assertTrue(ClassUtils.isAssignable(null, Object.class));
        assertFalse(ClassUtils.isAssignable(null, int.class));
        assertFalse(ClassUtils.isAssignable(Integer.TYPE, Object.class, false));
        assertFalse(ClassUtils.isAssignable(String.class, (Class<?>) null));
        assertTrue(ClassUtils.isAssignable(Integer.TYPE, Long.TYPE));
        assertFalse(ClassUtils.isAssignable(Long.TYPE, Integer.TYPE));
    }

    @Test
    void testIsAssignableArray() {
        assertTrue(ClassUtils.isAssignable(new Class<?>[] {String.class}, new Class<?>[] {Object.class}));
        assertFalse(ClassUtils.isAssignable(new Class<?>[] {String.class}, new Class<?>[] {Object.class, Object.class}));
        assertTrue(ClassUtils.isAssignable((Class<?>[]) null, (Class<?>[]) null));
    }

    @Test
    void testIsInnerClass() {
        assertTrue(ClassUtils.isInnerClass(AgentInnerNonStatic.class));
        assertTrue(ClassUtils.isInnerClass(AgentSampleParent.class));
        assertFalse(ClassUtils.isInnerClass(String.class));
        assertFalse(ClassUtils.isInnerClass(null));
    }

    @Test
    void testIsPrimitiveOrWrapper() {
        assertTrue(ClassUtils.isPrimitiveOrWrapper(int.class));
        assertTrue(ClassUtils.isPrimitiveOrWrapper(Integer.class));
        assertFalse(ClassUtils.isPrimitiveOrWrapper(String.class));
        assertFalse(ClassUtils.isPrimitiveOrWrapper(null));
    }

    @Test
    void testIsPrimitiveWrapper() {
        assertTrue(ClassUtils.isPrimitiveWrapper(Integer.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(int.class));
        assertFalse(ClassUtils.isPrimitiveWrapper(null));
    }

    @Test
    void testIsPublic() {
        assertTrue(ClassUtils.isPublic(String.class));
        assertFalse(ClassUtils.isPublic(AgentPrivateSub.class));
    }

    @Test
    void testIsPublicNullThrows() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() {
                ClassUtils.isPublic(null);
            }
        });
    }

    @Test
    void testPrimitivesToWrappers() {
        final Class<?>[] result = ClassUtils.primitivesToWrappers(int.class, String.class, null);
        assertEquals(Integer.class, result[0]);
        assertEquals(String.class, result[1]);
        assertNull(result[2]);
        assertNull(ClassUtils.primitivesToWrappers((Class<?>[]) null));
        assertArrayEquals(new Class<?>[0], ClassUtils.primitivesToWrappers());
    }

    @Test
    void testPrimitiveToWrapper() {
        assertEquals(Integer.class, ClassUtils.primitiveToWrapper(int.class));
        assertEquals(String.class, ClassUtils.primitiveToWrapper(String.class));
        assertNull(ClassUtils.primitiveToWrapper(null));
    }

    @Test
    void testToClass() {
        final Class<?>[] result = ClassUtils.toClass("hello", 1, null);
        assertEquals(String.class, result[0]);
        assertEquals(Integer.class, result[1]);
        assertNull(result[2]);
        assertNull(ClassUtils.toClass((Object[]) null));
        assertArrayEquals(new Class<?>[0], ClassUtils.toClass());
    }

    @Test
    void testWrappersToPrimitives() {
        final Class<?>[] result = ClassUtils.wrappersToPrimitives(Integer.class, String.class, null);
        assertEquals(int.class, result[0]);
        assertNull(result[1]);
        assertNull(result[2]);
        assertNull(ClassUtils.wrappersToPrimitives((Class<?>[]) null));
        assertArrayEquals(new Class<?>[0], ClassUtils.wrappersToPrimitives());
    }

    @Test
    void testWrapperToPrimitive() {
        assertEquals(int.class, ClassUtils.wrapperToPrimitive(Integer.class));
        assertNull(ClassUtils.wrapperToPrimitive(String.class));
        assertNull(ClassUtils.wrapperToPrimitive(null));
    }

    @Test
    void testDeprecatedConstructor() {
        assertNotNull(new ClassUtils());
    }
}
