/*
  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      https://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
 */
package org.apache.commons.cli;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link Converter}.
 */
class ConverterAgentTest {

    /** A custom functional-interface implementation used to verify the interface contract itself. */
    private static final Converter<Integer, NumberFormatException> PARSE_INT = new Converter<Integer, NumberFormatException>() {
        @Override
        public Integer apply(final String string) throws NumberFormatException {
            return Integer.valueOf(string);
        }
    };

    @Test
    void testCustomImplementationHappyPath() throws NumberFormatException {
        assertEquals(Integer.valueOf(42), PARSE_INT.apply("42"));
    }

    @Test
    void testCustomImplementationError() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                PARSE_INT.apply("not-a-number");
            }
        });
    }

    @Test
    void testDefaultIsIdentity() throws Exception {
        assertEquals("hello", Converter.DEFAULT.apply("hello"));
        assertEquals("", Converter.DEFAULT.apply(""));
    }

    @Test
    void testDefaultWithNullReturnsNull() throws Exception {
        assertNull(Converter.DEFAULT.apply(null));
    }

    @Test
    void testClassHappyPath() throws Exception {
        final Class<?> clazz = Converter.CLASS.apply("org.apache.commons.cli.Converter");
        assertEquals(Converter.class, clazz);
    }

    @Test
    void testClassNotFound() {
        assertThrows(ClassNotFoundException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.CLASS.apply("no.such.package.NoSuchClassAtAll");
            }
        });
    }

    @Test
    void testFileHappyPath() throws Exception {
        final File file = Converter.FILE.apply("some-file.txt");
        assertEquals("some-file.txt", file.getName());
    }

    @Test
    void testFileWithNullThrowsNpe() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.FILE.apply(null);
            }
        });
    }

    @Test
    void testPathHappyPath() throws Exception {
        final Path path = Converter.PATH.apply("some-path.txt");
        assertEquals("some-path.txt", path.getFileName().toString());
    }

    @Test
    void testPathWithEmbeddedNulThrowsInvalidPathException() {
        assertThrows(InvalidPathException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.PATH.apply("a\u0000b");
            }
        });
    }

    @Test
    void testNumberWithInteger() throws Exception {
        final Number number = Converter.NUMBER.apply("123");
        assertTrue(number instanceof Long);
        assertEquals(123L, number.longValue());
    }

    @Test
    void testNumberWithDecimal() throws Exception {
        final Number number = Converter.NUMBER.apply("123.5");
        assertTrue(number instanceof Double);
        assertEquals(123.5d, number.doubleValue(), 0.0001d);
    }

    @Test
    void testNumberWithInvalidInput() {
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.NUMBER.apply("not-a-number");
            }
        });
    }

    @Test
    void testObjectHappyPath() throws Exception {
        final Object object = Converter.OBJECT.apply("java.lang.Object");
        assertEquals(Object.class, object.getClass());
    }

    @Test
    void testObjectWithNoNoArgConstructorThrows() {
        assertThrows(ReflectiveOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                // java.lang.Integer has no public no-arg constructor.
                Converter.OBJECT.apply("java.lang.Integer");
            }
        });
    }

    @Test
    void testObjectWithUnknownClassThrows() {
        assertThrows(ReflectiveOperationException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.OBJECT.apply("no.such.package.NoSuchClassAtAll");
            }
        });
    }

    @Test
    void testUrlHappyPath() throws Exception {
        final URL url = Converter.URL.apply("https://example.com/path");
        assertEquals("https", url.getProtocol());
        assertEquals("example.com", url.getHost());
        assertEquals("/path", url.getPath());
    }

    @Test
    void testUrlWithMalformedInputThrows() {
        assertThrows(MalformedURLException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.URL.apply("not a url");
            }
        });
    }

    @Test
    void testDateHappyPathRoundTrips() throws Exception {
        final SimpleDateFormat format = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy");
        final String formatted = format.format(new Date(0));
        final Date parsed = Converter.DATE.apply(formatted);
        assertEquals(formatted, format.format(parsed));
    }

    @Test
    void testDateWithInvalidInputThrows() {
        assertThrows(ParseException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Throwable {
                Converter.DATE.apply("this is not a date");
            }
        });
    }
}
