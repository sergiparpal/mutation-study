/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import java.util.Locale;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Tests {@link LocaleUtils}.
 */
public class LocaleUtilsAgentTest {

    @Test
    public void testAvailableLocaleListNotEmptyAndUnmodifiable() {
        final List<Locale> list = LocaleUtils.availableLocaleList();
        assertNotNull(list);
        assertFalse(list.isEmpty());
        assertTrue(list.contains(Locale.US));
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                list.add(Locale.US);
            }
        });
    }

    @Test
    public void testAvailableLocaleListIsCached() {
        final List<Locale> list1 = LocaleUtils.availableLocaleList();
        final List<Locale> list2 = LocaleUtils.availableLocaleList();
        assertSame(list1, list2);
    }

    @Test
    public void testAvailableLocaleSetNotEmptyAndUnmodifiable() {
        final Set<Locale> set = LocaleUtils.availableLocaleSet();
        assertNotNull(set);
        assertFalse(set.isEmpty());
        assertTrue(set.contains(Locale.US));
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                set.add(Locale.CANADA_FRENCH);
            }
        });
    }

    @Test
    public void testIsAvailableLocaleTrue() {
        assertTrue(LocaleUtils.isAvailableLocale(Locale.US));
    }

    @Test
    public void testIsAvailableLocaleFalseForUnknownLocale() {
        assertFalse(LocaleUtils.isAvailableLocale(new Locale("xx", "XX", "myvariant")));
    }

    @Test
    public void testIsAvailableLocaleNull() {
        assertFalse(LocaleUtils.isAvailableLocale(null));
    }

    @Test
    public void testCountriesByLanguageNull() {
        final List<Locale> list = LocaleUtils.countriesByLanguage(null);
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    public void testCountriesByLanguageUnknown() {
        final List<Locale> list = LocaleUtils.countriesByLanguage("zz");
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    public void testCountriesByLanguageEnglish() {
        final List<Locale> list = LocaleUtils.countriesByLanguage("en");
        assertNotNull(list);
        assertFalse(list.isEmpty());
        for (final Locale locale : list) {
            assertEquals("en", locale.getLanguage());
        }
        assertTrue(list.contains(new Locale("en", "US")));
    }

    @Test
    public void testCountriesByLanguageIsCached() {
        final List<Locale> list1 = LocaleUtils.countriesByLanguage("en");
        final List<Locale> list2 = LocaleUtils.countriesByLanguage("en");
        assertSame(list1, list2);
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                list1.add(Locale.US);
            }
        });
    }

    @Test
    public void testLanguagesByCountryNull() {
        final List<Locale> list = LocaleUtils.languagesByCountry(null);
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    public void testLanguagesByCountryUnknown() {
        final List<Locale> list = LocaleUtils.languagesByCountry("ZZ");
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    public void testLanguagesByCountryUS() {
        final List<Locale> list = LocaleUtils.languagesByCountry("US");
        assertNotNull(list);
        assertFalse(list.isEmpty());
        for (final Locale locale : list) {
            assertEquals("US", locale.getCountry());
        }
        assertTrue(list.contains(new Locale("en", "US")));
    }

    @Test
    public void testLanguagesByCountryIsCached() {
        final List<Locale> list1 = LocaleUtils.languagesByCountry("US");
        final List<Locale> list2 = LocaleUtils.languagesByCountry("US");
        assertSame(list1, list2);
    }

    @Test
    public void testIsLanguageUndeterminedNullLocale() {
        assertTrue(LocaleUtils.isLanguageUndetermined(null));
    }

    @Test
    public void testIsLanguageUndeterminedKnownLanguage() {
        assertFalse(LocaleUtils.isLanguageUndetermined(Locale.ENGLISH));
    }

    @Test
    public void testIsLanguageUndeterminedEmptyLanguage() {
        assertTrue(LocaleUtils.isLanguageUndetermined(new Locale("")));
    }

    @Test
    public void testLocaleLookupListNullLocale() {
        final List<Locale> list = LocaleUtils.localeLookupList(null);
        assertNotNull(list);
        assertTrue(list.isEmpty());
    }

    @Test
    public void testLocaleLookupListLanguageOnly() {
        final List<Locale> list = LocaleUtils.localeLookupList(new Locale("fr"));
        assertEquals(1, list.size());
        assertEquals(new Locale("fr"), list.get(0));
    }

    @Test
    public void testLocaleLookupListLanguageAndCountry() {
        final List<Locale> list = LocaleUtils.localeLookupList(new Locale("fr", "CA"));
        assertEquals(2, list.size());
        assertEquals(new Locale("fr", "CA"), list.get(0));
        assertEquals(new Locale("fr"), list.get(1));
    }

    @Test
    public void testLocaleLookupListFull() {
        final List<Locale> list = LocaleUtils.localeLookupList(new Locale("fr", "CA", "xxx"));
        assertEquals(3, list.size());
        assertEquals(new Locale("fr", "CA", "xxx"), list.get(0));
        assertEquals(new Locale("fr", "CA"), list.get(1));
        assertEquals(new Locale("fr"), list.get(2));
    }

    @Test
    public void testLocaleLookupListFullWithDefault() {
        final List<Locale> list = LocaleUtils.localeLookupList(new Locale("fr", "CA", "xxx"), new Locale("en"));
        assertEquals(4, list.size());
        assertEquals(new Locale("fr", "CA", "xxx"), list.get(0));
        assertEquals(new Locale("fr", "CA"), list.get(1));
        assertEquals(new Locale("fr"), list.get(2));
        assertEquals(new Locale("en"), list.get(3));
    }

    @Test
    public void testLocaleLookupListDefaultAlreadyInList() {
        final List<Locale> list = LocaleUtils.localeLookupList(new Locale("fr", "CA"), new Locale("fr"));
        assertEquals(2, list.size());
        assertEquals(new Locale("fr", "CA"), list.get(0));
        assertEquals(new Locale("fr"), list.get(1));
    }

    @Test
    public void testLocaleLookupListIsUnmodifiable() {
        final List<Locale> list = LocaleUtils.localeLookupList(new Locale("fr"));
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                list.add(Locale.US);
            }
        });
    }

    @Test
    public void testToLocaleFromLocaleNull() {
        final Locale result = LocaleUtils.toLocale((Locale) null);
        assertEquals(Locale.getDefault(), result);
    }

    @Test
    public void testToLocaleFromLocaleNonNull() {
        assertSame(Locale.JAPAN, LocaleUtils.toLocale(Locale.JAPAN));
    }

    @Test
    public void testToLocaleStringNull() {
        assertNull(LocaleUtils.toLocale((String) null));
    }

    @Test
    public void testToLocaleStringEmpty() {
        assertEquals(new Locale("", ""), LocaleUtils.toLocale(""));
    }

    @Test
    public void testToLocaleStringLanguageOnly() {
        assertEquals(new Locale("en"), LocaleUtils.toLocale("en"));
    }

    @Test
    public void testToLocaleStringLanguageAndCountryUnderscore() {
        assertEquals(new Locale("en", "GB"), LocaleUtils.toLocale("en_GB"));
    }

    @Test
    public void testToLocaleStringLanguageAndCountryDash() {
        assertEquals(new Locale("en", "GB"), LocaleUtils.toLocale("en-GB"));
    }

    @Test
    public void testToLocaleStringNumericArea() {
        assertEquals(new Locale("en", "001"), LocaleUtils.toLocale("en_001"));
    }

    @Test
    public void testToLocaleStringWithVariant() {
        assertEquals(new Locale("en", "GB", "xxx"), LocaleUtils.toLocale("en_GB_xxx"));
    }

    @Test
    public void testToLocaleStringCountryOnly() {
        assertEquals(new Locale("", "US"), LocaleUtils.toLocale("US"));
    }

    @Test
    public void testToLocaleStringUnderscorePrefixedCountry() {
        assertEquals(new Locale("", "FR"), LocaleUtils.toLocale("_FR"));
    }

    @Test
    public void testToLocaleStringUnderscorePrefixedCountryWithVariant() {
        assertEquals(new Locale("", "FR", "xxx"), LocaleUtils.toLocale("_FR_xxx"));
    }

    @Test
    public void testToLocaleStringTooShort() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                LocaleUtils.toLocale("a");
            }
        });
    }

    @Test
    public void testToLocaleStringUnderscoreTooShort() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                LocaleUtils.toLocale("_A");
            }
        });
    }

    @Test
    public void testToLocaleStringUnderscoreLowercaseCountry() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                LocaleUtils.toLocale("_fr");
            }
        });
    }

    @Test
    public void testToLocaleStringUnderscoreMissingSeparatorBeforeVariant() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                LocaleUtils.toLocale("_FRxx");
            }
        });
    }

    @Test
    public void testToLocaleStringUnderscoreWrongSeparatorBeforeVariant() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                LocaleUtils.toLocale("_FR-xxx");
            }
        });
    }

    @Test
    public void testToLocaleStringInvalidLanguageUppercase() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                LocaleUtils.toLocale("EN");
            }
        });
    }

    @Test
    public void testToLocaleStringInvalidFormat() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                LocaleUtils.toLocale("en_G");
            }
        });
    }

    @Test
    public void testToLocaleStringInvalidCountryLowercase() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                LocaleUtils.toLocale("en_gb");
            }
        });
    }

    @Test
    public void testToLocaleStringSpecialCaseThaiJP() {
        assertEquals(new Locale("th", "TH", "TH"), LocaleUtils.toLocale("th_TH_TH_#u-nu-thai"));
    }

    @Test
    public void testToLocaleStringSpecialCaseJapaneseJP() {
        assertEquals(new Locale("ja", "JP", "JP"), LocaleUtils.toLocale("ja_JP_JP_#u-ca-japanese"));
    }

    @Test
    public void testConstructorIsPublic() {
        assertNotNull(new LocaleUtils());
    }
}
