/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link NumberUtils}.
 */
class NumberUtilsAgentTest {

    @Test
    void testConstants() {
        assertEquals(0L, NumberUtils.LONG_ZERO.longValue());
        assertEquals(1L, NumberUtils.LONG_ONE.longValue());
        assertEquals(-1L, NumberUtils.LONG_MINUS_ONE.longValue());
        assertEquals(0, NumberUtils.INTEGER_ZERO.intValue());
        assertEquals(1, NumberUtils.INTEGER_ONE.intValue());
        assertEquals(2, NumberUtils.INTEGER_TWO.intValue());
        assertEquals(-1, NumberUtils.INTEGER_MINUS_ONE.intValue());
        assertEquals((short) 0, NumberUtils.SHORT_ZERO.shortValue());
        assertEquals((short) 1, NumberUtils.SHORT_ONE.shortValue());
        assertEquals((short) -1, NumberUtils.SHORT_MINUS_ONE.shortValue());
        assertEquals((byte) 0, NumberUtils.BYTE_ZERO.byteValue());
        assertEquals((byte) 1, NumberUtils.BYTE_ONE.byteValue());
        assertEquals((byte) -1, NumberUtils.BYTE_MINUS_ONE.byteValue());
        assertEquals(0.0d, NumberUtils.DOUBLE_ZERO.doubleValue(), 0d);
        assertEquals(1.0d, NumberUtils.DOUBLE_ONE.doubleValue(), 0d);
        assertEquals(-1.0d, NumberUtils.DOUBLE_MINUS_ONE.doubleValue(), 0d);
        assertEquals(0.0f, NumberUtils.FLOAT_ZERO.floatValue(), 0f);
        assertEquals(1.0f, NumberUtils.FLOAT_ONE.floatValue(), 0f);
        assertEquals(-1.0f, NumberUtils.FLOAT_MINUS_ONE.floatValue(), 0f);
        assertEquals((long) Integer.MAX_VALUE, NumberUtils.LONG_INT_MAX_VALUE.longValue());
        assertEquals((long) Integer.MIN_VALUE, NumberUtils.LONG_INT_MIN_VALUE.longValue());
    }

    @Test
    void testConstructorExists() {
        final NumberUtils instance = new NumberUtils();
        assertTrue(instance instanceof NumberUtils);
    }

    @Test
    void testCompare() {
        assertEquals(0, NumberUtils.compare((byte) 1, (byte) 1));
        assertTrue(NumberUtils.compare((byte) 1, (byte) 2) < 0);
        assertTrue(NumberUtils.compare((byte) 2, (byte) 1) > 0);

        assertEquals(0, NumberUtils.compare(1, 1));
        assertTrue(NumberUtils.compare(1, 2) < 0);
        assertTrue(NumberUtils.compare(2, 1) > 0);

        assertEquals(0, NumberUtils.compare(1L, 1L));
        assertTrue(NumberUtils.compare(1L, 2L) < 0);
        assertTrue(NumberUtils.compare(2L, 1L) > 0);

        assertEquals(0, NumberUtils.compare((short) 1, (short) 1));
        assertTrue(NumberUtils.compare((short) 1, (short) 2) < 0);
        assertTrue(NumberUtils.compare((short) 2, (short) 1) > 0);
    }

    @Test
    void testCreateBigDecimal() {
        assertNull(NumberUtils.createBigDecimal(null));
        assertEquals(new BigDecimal("1234.5"), NumberUtils.createBigDecimal("1234.5"));
        try {
            NumberUtils.createBigDecimal("   ");
            fail("Expected NumberFormatException for blank string");
        } catch (final NumberFormatException expected) {
            // expected
        }
        try {
            NumberUtils.createBigDecimal("not a number");
            fail("Expected NumberFormatException for invalid string");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    @Test
    void testCreateBigInteger() {
        assertNull(NumberUtils.createBigInteger(null));
        assertEquals(new BigInteger("123"), NumberUtils.createBigInteger("123"));
        assertEquals(new BigInteger("-123"), NumberUtils.createBigInteger("-123"));
        assertEquals(new BigInteger("5"), NumberUtils.createBigInteger("+5"));
        assertEquals(BigInteger.valueOf(26), NumberUtils.createBigInteger("0x1A"));
        assertEquals(BigInteger.valueOf(-16), NumberUtils.createBigInteger("-0x10"));
        assertEquals(BigInteger.valueOf(26), NumberUtils.createBigInteger("#1A"));
        assertEquals(BigInteger.valueOf(8), NumberUtils.createBigInteger("010"));
        assertEquals(BigInteger.ZERO, NumberUtils.createBigInteger("0"));
        try {
            NumberUtils.createBigInteger("");
            fail("Expected NumberFormatException for empty string");
        } catch (final NumberFormatException expected) {
            // expected
        }
        try {
            NumberUtils.createBigInteger("019");
            fail("Expected NumberFormatException for invalid octal digits");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    @Test
    void testCreateDouble() {
        assertNull(NumberUtils.createDouble(null));
        assertEquals(1.5d, NumberUtils.createDouble("1.5").doubleValue(), 0d);
        try {
            NumberUtils.createDouble("not a number");
            fail("Expected NumberFormatException for invalid string");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    @Test
    void testCreateFloat() {
        assertNull(NumberUtils.createFloat(null));
        assertEquals(1.5f, NumberUtils.createFloat("1.5").floatValue(), 0f);
        try {
            NumberUtils.createFloat("not a number");
            fail("Expected NumberFormatException for invalid string");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    @Test
    void testCreateInteger() {
        assertNull(NumberUtils.createInteger(null));
        assertEquals(Integer.valueOf(26), NumberUtils.createInteger("0x1A"));
        assertEquals(Integer.valueOf(8), NumberUtils.createInteger("010"));
        assertEquals(Integer.valueOf(-5), NumberUtils.createInteger("-5"));
        try {
            NumberUtils.createInteger("not a number");
            fail("Expected NumberFormatException for invalid string");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    @Test
    void testCreateLong() {
        assertNull(NumberUtils.createLong(null));
        assertEquals(Long.valueOf(255L), NumberUtils.createLong("0xFF"));
        assertEquals(Long.valueOf(-5L), NumberUtils.createLong("-5"));
        try {
            NumberUtils.createLong("not a number");
            fail("Expected NumberFormatException for invalid string");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    @Test
    void testCreateNumberNullAndBlank() {
        assertNull(NumberUtils.createNumber(null));
        try {
            NumberUtils.createNumber("");
            fail("Expected NumberFormatException for empty string");
        } catch (final NumberFormatException expected) {
            // expected
        }
        try {
            NumberUtils.createNumber("   ");
            fail("Expected NumberFormatException for blank string");
        } catch (final NumberFormatException expected) {
            // expected
        }
        try {
            NumberUtils.createNumber("not a number");
            fail("Expected NumberFormatException for garbage string");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    @Test
    void testCreateNumberIntegral() {
        final Number n1 = NumberUtils.createNumber("123");
        assertTrue(n1 instanceof Integer);
        assertEquals(123, n1.intValue());

        final Number n2 = NumberUtils.createNumber(String.valueOf(((long) Integer.MAX_VALUE) + 1L));
        assertTrue(n2 instanceof Long);
        assertEquals(((long) Integer.MAX_VALUE) + 1L, n2.longValue());

        final Number n3 = NumberUtils.createNumber("123456789012345678901234567890");
        assertTrue(n3 instanceof BigInteger);
        assertEquals(new BigInteger("123456789012345678901234567890"), n3);
    }

    @Test
    void testCreateNumberHex() {
        final Number hexInt = NumberUtils.createNumber("0x1A");
        assertTrue(hexInt instanceof Integer);
        assertEquals(26, hexInt.intValue());

        final Number hexLong = NumberUtils.createNumber("0xFFFFFFFF");
        assertTrue(hexLong instanceof Long);
        assertEquals(4294967295L, hexLong.longValue());

        final Number hexBig = NumberUtils.createNumber("0x1FFFFFFFFFFFFFFFF");
        assertTrue(hexBig instanceof BigInteger);
    }

    @Test
    void testCreateNumberWithTypeQualifiers() {
        final Number longValue = NumberUtils.createNumber("123L");
        assertTrue(longValue instanceof Long);
        assertEquals(123L, longValue.longValue());

        final Number floatValue = NumberUtils.createNumber("1.2F");
        assertTrue(floatValue instanceof Float);
        assertEquals(1.2f, floatValue.floatValue(), 0f);

        final Number doubleValue = NumberUtils.createNumber("1.2D");
        assertTrue(doubleValue instanceof Double);
        assertEquals(1.2d, doubleValue.doubleValue(), 0d);

        try {
            NumberUtils.createNumber("1.2L");
            fail("Expected NumberFormatException for decimal with L qualifier");
        } catch (final NumberFormatException expected) {
            // expected
        }
    }

    @Test
    void testCreateNumberFloatingPoint() {
        final Number decimal = NumberUtils.createNumber("1.2");
        assertEquals(1.2d, decimal.doubleValue(), 0.0001d);

        final Number scientific = NumberUtils.createNumber("1.2e3");
        assertEquals(1200d, scientific.doubleValue(), 0.0001d);

        final Number bigDecimalExplicit = NumberUtils.createNumber("123.45678901234567890123456789");
        assertTrue(bigDecimalExplicit instanceof BigDecimal);
    }

    @Test
    void testIsCreatable() {
        assertFalse(NumberUtils.isCreatable(null));
        assertFalse(NumberUtils.isCreatable(""));
        assertFalse(NumberUtils.isCreatable("09"));
        assertFalse(NumberUtils.isCreatable("abc"));
        assertTrue(NumberUtils.isCreatable("123"));
        assertTrue(NumberUtils.isCreatable("-123.45"));
        assertTrue(NumberUtils.isCreatable("0x1A"));
        assertTrue(NumberUtils.isCreatable("1.2e3"));
    }

    @Test
    void testIsNumberDeprecatedDelegation() {
        assertEquals(NumberUtils.isCreatable("123"), NumberUtils.isNumber("123"));
        assertEquals(NumberUtils.isCreatable("abc"), NumberUtils.isNumber("abc"));
        assertFalse(NumberUtils.isNumber(""));
        assertTrue(NumberUtils.isNumber("42"));
    }

    @Test
    void testIsDigits() {
        assertFalse(NumberUtils.isDigits(null));
        assertFalse(NumberUtils.isDigits(""));
        assertTrue(NumberUtils.isDigits("12345"));
        assertFalse(NumberUtils.isDigits("12.3"));
        assertFalse(NumberUtils.isDigits("-123"));
        assertFalse(NumberUtils.isDigits("12a3"));
    }

    @Test
    void testIsParsable() {
        assertFalse(NumberUtils.isParsable(null));
        assertFalse(NumberUtils.isParsable(""));
        assertTrue(NumberUtils.isParsable("123"));
        assertTrue(NumberUtils.isParsable("-123"));
        assertTrue(NumberUtils.isParsable("1.5e10"));
        assertFalse(NumberUtils.isParsable("12.3.45"));
        assertFalse(NumberUtils.isParsable("abc"));
    }

    @Test
    void testMaxByteArray() {
        assertEquals((byte) 5, NumberUtils.max((byte) 1, (byte) 5, (byte) 3));
        try {
            NumberUtils.max((byte[]) null);
            fail("Expected NullPointerException for null array");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.max(new byte[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMaxMinByteThreeArgs() {
        assertEquals((byte) 5, NumberUtils.max((byte) 1, (byte) 5, (byte) 3));
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 5, (byte) 3));
    }

    @Test
    void testMaxMinIntArrayAndThreeArgs() {
        assertEquals(9, NumberUtils.max(new int[] {3, 9, 1}));
        assertEquals(1, NumberUtils.min(new int[] {3, 9, 1}));
        assertEquals(9, NumberUtils.max(3, 9, 1));
        assertEquals(1, NumberUtils.min(3, 9, 1));
        try {
            NumberUtils.max((int[]) null);
            fail("Expected NullPointerException for null array");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.min(new int[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMaxMinLongArrayAndThreeArgs() {
        assertEquals(9L, NumberUtils.max(new long[] {3L, 9L, 1L}));
        assertEquals(1L, NumberUtils.min(new long[] {3L, 9L, 1L}));
        assertEquals(9L, NumberUtils.max(3L, 9L, 1L));
        assertEquals(1L, NumberUtils.min(3L, 9L, 1L));
        try {
            NumberUtils.min((long[]) null);
            fail("Expected NullPointerException for null array");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.max(new long[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMaxMinShortArrayAndThreeArgs() {
        assertEquals((short) 9, NumberUtils.max(new short[] {(short) 3, (short) 9, (short) 1}));
        assertEquals((short) 1, NumberUtils.min(new short[] {(short) 3, (short) 9, (short) 1}));
        assertEquals((short) 9, NumberUtils.max((short) 3, (short) 9, (short) 1));
        assertEquals((short) 1, NumberUtils.min((short) 3, (short) 9, (short) 1));
    }

    @Test
    void testMaxMinDoubleArrayAndThreeArgs() {
        assertEquals(9.5d, NumberUtils.max(new double[] {3.1d, 9.5d, 1.2d}), 0d);
        assertEquals(1.2d, NumberUtils.min(new double[] {3.1d, 9.5d, 1.2d}), 0d);
        assertEquals(9.5d, NumberUtils.max(3.1d, 9.5d, 1.2d), 0d);
        assertEquals(1.2d, NumberUtils.min(3.1d, 9.5d, 1.2d), 0d);
        assertTrue(Double.isNaN(NumberUtils.max(new double[] {1d, Double.NaN, 2d})));
        assertTrue(Double.isNaN(NumberUtils.min(new double[] {1d, Double.NaN, 2d})));
        assertTrue(Double.isNaN(NumberUtils.max(1d, Double.NaN, 2d)));
        assertTrue(Double.isNaN(NumberUtils.min(1d, Double.NaN, 2d)));
        try {
            NumberUtils.max((double[]) null);
            fail("Expected NullPointerException for null array");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.min(new double[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testMaxMinFloatArrayAndThreeArgs() {
        assertEquals(9.5f, NumberUtils.max(new float[] {3.1f, 9.5f, 1.2f}), 0f);
        assertEquals(1.2f, NumberUtils.min(new float[] {3.1f, 9.5f, 1.2f}), 0f);
        assertEquals(9.5f, NumberUtils.max(3.1f, 9.5f, 1.2f), 0f);
        assertEquals(1.2f, NumberUtils.min(3.1f, 9.5f, 1.2f), 0f);
        assertTrue(Float.isNaN(NumberUtils.max(new float[] {1f, Float.NaN, 2f})));
        assertTrue(Float.isNaN(NumberUtils.min(new float[] {1f, Float.NaN, 2f})));
        assertTrue(Float.isNaN(NumberUtils.max(1f, Float.NaN, 2f)));
        assertTrue(Float.isNaN(NumberUtils.min(1f, Float.NaN, 2f)));
        try {
            NumberUtils.max((float[]) null);
            fail("Expected NullPointerException for null array");
        } catch (final NullPointerException expected) {
            // expected
        }
        try {
            NumberUtils.min(new float[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    void testToByte() {
        assertEquals((byte) 0, NumberUtils.toByte(null));
        assertEquals((byte) 0, NumberUtils.toByte(""));
        assertEquals((byte) 1, NumberUtils.toByte("1"));
        assertEquals((byte) 1, NumberUtils.toByte(null, (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("", (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("1", (byte) 0));
        assertEquals((byte) 9, NumberUtils.toByte("not a number", (byte) 9));
    }

    @Test
    void testToShort() {
        assertEquals((short) 0, NumberUtils.toShort(null));
        assertEquals((short) 0, NumberUtils.toShort(""));
        assertEquals((short) 1, NumberUtils.toShort("1"));
        assertEquals((short) 1, NumberUtils.toShort(null, (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("", (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("1", (short) 0));
        assertEquals((short) 9, NumberUtils.toShort("not a number", (short) 9));
    }

    @Test
    void testToInt() {
        assertEquals(0, NumberUtils.toInt(null));
        assertEquals(0, NumberUtils.toInt(""));
        assertEquals(1, NumberUtils.toInt("1"));
        assertEquals(1, NumberUtils.toInt(null, 1));
        assertEquals(1, NumberUtils.toInt("", 1));
        assertEquals(1, NumberUtils.toInt("1", 0));
        assertEquals(9, NumberUtils.toInt("not a number", 9));
    }

    @Test
    void testToLong() {
        assertEquals(0L, NumberUtils.toLong(null));
        assertEquals(0L, NumberUtils.toLong(""));
        assertEquals(1L, NumberUtils.toLong("1"));
        assertEquals(1L, NumberUtils.toLong(null, 1L));
        assertEquals(1L, NumberUtils.toLong("", 1L));
        assertEquals(1L, NumberUtils.toLong("1", 0L));
        assertEquals(9L, NumberUtils.toLong("not a number", 9L));
    }

    @Test
    void testToFloat() {
        assertEquals(0.0f, NumberUtils.toFloat(null), 0f);
        assertEquals(0.0f, NumberUtils.toFloat(""), 0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5"), 0f);
        assertEquals(1.1f, NumberUtils.toFloat(null, 1.1f), 0f);
        assertEquals(1.1f, NumberUtils.toFloat("", 1.1f), 0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5", 0.0f), 0f);
        assertEquals(9.9f, NumberUtils.toFloat("not a number", 9.9f), 0f);
    }

    @Test
    void testToDoubleString() {
        assertEquals(0.0d, NumberUtils.toDouble((String) null), 0d);
        assertEquals(0.0d, NumberUtils.toDouble(""), 0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5"), 0d);
        assertEquals(1.1d, NumberUtils.toDouble((String) null, 1.1d), 0d);
        assertEquals(1.1d, NumberUtils.toDouble("", 1.1d), 0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5", 0.0d), 0d);
        assertEquals(9.9d, NumberUtils.toDouble("not a number", 9.9d), 0d);
    }

    @Test
    void testToDoubleBigDecimal() {
        assertEquals(0.0d, NumberUtils.toDouble((BigDecimal) null), 0d);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d)), 0d);
        assertEquals(1.1d, NumberUtils.toDouble((BigDecimal) null, 1.1d), 0d);
        assertEquals(8.5d, NumberUtils.toDouble(BigDecimal.valueOf(8.5d), 1.1d), 0d);
    }

    @Test
    void testToScaledBigDecimalBigDecimal() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null));
        assertEquals(new BigDecimal("5.25"), NumberUtils.toScaledBigDecimal(new BigDecimal("5.25")));
        assertEquals(new BigDecimal("2"), NumberUtils.toScaledBigDecimal(new BigDecimal("2.5"), 0, RoundingMode.HALF_EVEN));
        assertEquals(new BigDecimal("4"), NumberUtils.toScaledBigDecimal(new BigDecimal("3.5"), 0, RoundingMode.HALF_EVEN));
        assertEquals(new BigDecimal("2"), NumberUtils.toScaledBigDecimal(new BigDecimal("2.5"), 0, null));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((BigDecimal) null, 2, RoundingMode.HALF_UP));
    }

    @Test
    void testToScaledBigDecimalDouble() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null));
        assertEquals(new BigDecimal("5.25"), NumberUtils.toScaledBigDecimal(Double.valueOf(5.25d)));
        assertEquals(new BigDecimal("3"), NumberUtils.toScaledBigDecimal(Double.valueOf(2.5d), 0, RoundingMode.HALF_UP));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Double) null, 2, RoundingMode.HALF_UP));
    }

    @Test
    void testToScaledBigDecimalFloat() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null));
        assertEquals(new BigDecimal("5.25"), NumberUtils.toScaledBigDecimal(Float.valueOf(5.25f)));
        assertEquals(new BigDecimal("3"), NumberUtils.toScaledBigDecimal(Float.valueOf(2.5f), 0, RoundingMode.HALF_UP));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((Float) null, 2, RoundingMode.HALF_UP));
    }

    @Test
    void testToScaledBigDecimalString() {
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null));
        assertEquals(new BigDecimal("5.25"), NumberUtils.toScaledBigDecimal("5.25"));
        assertEquals(new BigDecimal("3"), NumberUtils.toScaledBigDecimal("2.5", 0, RoundingMode.HALF_UP));
        assertEquals(BigDecimal.ZERO, NumberUtils.toScaledBigDecimal((String) null, 2, RoundingMode.HALF_UP));
    }
}
