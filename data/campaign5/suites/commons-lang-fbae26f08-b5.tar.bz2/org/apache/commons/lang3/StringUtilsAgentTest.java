/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Locale;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link StringUtils}.
 */
class StringUtilsAgentTest {

    @Test
    void testIsEmptyIsBlank() {
        assertTrue(StringUtils.isEmpty(null));
        assertTrue(StringUtils.isEmpty(""));
        assertFalse(StringUtils.isEmpty(" "));
        assertFalse(StringUtils.isEmpty("bob"));

        assertTrue(StringUtils.isBlank(null));
        assertTrue(StringUtils.isBlank(""));
        assertTrue(StringUtils.isBlank(" "));
        assertFalse(StringUtils.isBlank("bob"));
        assertFalse(StringUtils.isBlank("  bob  "));

        assertFalse(StringUtils.isNotEmpty(null));
        assertTrue(StringUtils.isNotEmpty("bob"));
        assertFalse(StringUtils.isNotBlank(" "));
        assertTrue(StringUtils.isNotBlank("bob"));
    }

    @Test
    void testIsAnyAllBlankEmpty() {
        assertTrue(StringUtils.isAnyEmpty("a", ""));
        assertFalse(StringUtils.isAnyEmpty("a", "b"));
        assertTrue(StringUtils.isAllEmpty("", null));
        assertFalse(StringUtils.isAllEmpty("", "a"));
        assertTrue(StringUtils.isAnyBlank("a", " "));
        assertFalse(StringUtils.isAnyBlank("a", "b"));
        assertTrue(StringUtils.isAllBlank(null, " "));
        assertFalse(StringUtils.isAllBlank(null, "a"));
        assertTrue(StringUtils.isNoneBlank("a", "b"));
        assertFalse(StringUtils.isNoneBlank("a", null));
        assertTrue(StringUtils.isNoneEmpty("a", "b"));
        assertFalse(StringUtils.isNoneEmpty("a", ""));
        // empty varargs/null array treated as true
        assertTrue(StringUtils.isAllEmpty());
        assertTrue(StringUtils.isAllEmpty((CharSequence[]) null));
    }

    @Test
    void testTrimAndStrip() {
        assertNull(StringUtils.trim(null));
        assertEquals("", StringUtils.trim(""));
        assertEquals("abc", StringUtils.trim("  abc  "));

        assertEquals("", StringUtils.trimToEmpty(null));
        assertEquals("abc", StringUtils.trimToEmpty("  abc  "));

        assertNull(StringUtils.trimToNull("   "));
        assertEquals("abc", StringUtils.trimToNull("  abc  "));

        assertNull(StringUtils.strip(null));
        assertEquals("abc", StringUtils.strip(" abc "));
        assertEquals("abc", StringUtils.strip("xxabcyy", "xy"));

        assertEquals("abc  ", StringUtils.stripStart("  abc  ", " "));
        assertEquals("  abc", StringUtils.stripEnd("  abc  ", " "));

        assertEquals("", StringUtils.stripToEmpty(null));
        assertNull(StringUtils.stripToNull("   "));
    }

    @Test
    void testCapitalizeUncapitalizeSwapCase() {
        assertNull(StringUtils.capitalize(null));
        assertEquals("", StringUtils.capitalize(""));
        assertEquals("Cat", StringUtils.capitalize("cat"));
        assertEquals("CAT", StringUtils.capitalize("CAT"));

        assertNull(StringUtils.uncapitalize(null));
        assertEquals("cat", StringUtils.uncapitalize("Cat"));
        assertEquals("cAT", StringUtils.uncapitalize("CAT"));

        assertNull(StringUtils.swapCase(null));
        assertEquals("", StringUtils.swapCase(""));
        assertEquals("tHE DOG HAS A bone", StringUtils.swapCase("The dog has a BONE"));
    }

    @Test
    void testUpperLowerCase() {
        assertNull(StringUtils.upperCase(null));
        assertEquals("", StringUtils.upperCase(""));
        assertEquals("ABC", StringUtils.upperCase("abc"));
        assertEquals("ABC", StringUtils.upperCase("abc", Locale.ENGLISH));

        assertNull(StringUtils.lowerCase(null));
        assertEquals("abc", StringUtils.lowerCase("ABC"));
        assertEquals("abc", StringUtils.lowerCase("ABC", Locale.ENGLISH));
    }

    @Test
    void testEqualsFamily() {
        assertTrue(StringUtils.equals(null, null));
        assertFalse(StringUtils.equals(null, "abc"));
        assertFalse(StringUtils.equals("abc", null));
        assertTrue(StringUtils.equals("abc", "abc"));
        assertFalse(StringUtils.equals("abc", "ABC"));

        assertTrue(StringUtils.equalsIgnoreCase(null, null));
        assertFalse(StringUtils.equalsIgnoreCase(null, "abc"));
        assertTrue(StringUtils.equalsIgnoreCase("abc", "ABC"));

        assertTrue(StringUtils.equalsAny("abc", "def", "abc"));
        assertFalse(StringUtils.equalsAny("abc", "def", "ghi"));
        assertTrue(StringUtils.equalsAnyIgnoreCase("abc", "def", "ABC"));
    }

    @Test
    void testCompare() {
        assertEquals(0, StringUtils.compare(null, null));
        assertTrue(StringUtils.compare(null, "a") < 0);
        assertTrue(StringUtils.compare("a", null) > 0);
        assertTrue(StringUtils.compare("a", "b") < 0);

        assertEquals(0, StringUtils.compare(null, null, false));
        assertTrue(StringUtils.compare(null, "a", true) < 0);
        assertTrue(StringUtils.compare(null, "a", false) > 0);

        assertEquals(0, StringUtils.compareIgnoreCase("abc", "ABC"));
    }

    @Test
    void testContainsFamily() {
        assertFalse(StringUtils.contains(null, "a"));
        assertFalse(StringUtils.contains("abc", null));
        assertTrue(StringUtils.contains("abc", "b"));
        assertFalse(StringUtils.contains("abc", "z"));
        assertTrue(StringUtils.contains("abc", (int) 'a'));

        assertTrue(StringUtils.containsIgnoreCase("abc", "B"));
        assertFalse(StringUtils.containsIgnoreCase(null, "B"));

        assertTrue(StringUtils.containsAny("abc", 'a', 'z'));
        assertFalse(StringUtils.containsAny("abc", 'x', 'z'));
        assertTrue(StringUtils.containsAny("abc", "cd"));
        assertTrue(StringUtils.containsAny("abcd", "ab", "cd"));
        assertFalse(StringUtils.containsAny("abc", "cd", "xy"));
        assertTrue(StringUtils.containsAnyIgnoreCase("abc", "XY", "BC"));

        assertTrue(StringUtils.containsNone("abc", 'x', 'y'));
        assertFalse(StringUtils.containsNone("abc", 'a', 'y'));
        assertTrue(StringUtils.containsNone("abc", "xyz"));

        assertTrue(StringUtils.containsOnly("abab", 'a', 'b'));
        assertFalse(StringUtils.containsOnly("abc", 'a', 'b'));
        assertTrue(StringUtils.containsOnly("abab", "ab"));

        assertFalse(StringUtils.containsWhitespace(""));
        assertTrue(StringUtils.containsWhitespace("ab de"));
    }

    @Test
    void testIndexOfFamily() {
        assertEquals(-1, StringUtils.indexOf(null, "a"));
        assertEquals(2, StringUtils.indexOf("abcabc", "c"));
        assertEquals(5, StringUtils.indexOf("abcabc", "c", 3));
        assertEquals(1, StringUtils.indexOf("abcabc", (int) 'b'));
        assertEquals(4, StringUtils.indexOf("abcabc", (int) 'b', 2));

        assertEquals(0, StringUtils.indexOfAny("zzabyycdxx", 'z', 'a'));
        assertEquals(-1, StringUtils.indexOfAny((CharSequence) null, 'z', 'a'));
        assertEquals(2, StringUtils.indexOfAny("zzabyycdxx", "by"));
        assertEquals(0, StringUtils.indexOfAny("abc", new String[] {"a"}));

        assertEquals(0, StringUtils.indexOfAnyBut("zzabyycdxx", 'z'));
        assertEquals(2, StringUtils.indexOfAnyBut("zzabyycdxx", "za"));

        assertEquals(-1, StringUtils.indexOfIgnoreCase(null, "a"));
        assertEquals(0, StringUtils.indexOfIgnoreCase("aaa", "A"));

        assertEquals(5, StringUtils.lastIndexOf("abcabc", "c"));
        assertEquals(2, StringUtils.lastIndexOf("abcabc", "c", 4));
        assertEquals(4, StringUtils.lastIndexOf("abcabc", (int) 'b'));
        assertEquals(1, StringUtils.lastIndexOf("abcabc", (int) 'b', 2));
        assertEquals(0, StringUtils.lastIndexOfAny("zzabyycdxx", "za"));
        assertEquals(0, StringUtils.lastIndexOfIgnoreCase("AAA", "a"));

        assertEquals(2, StringUtils.ordinalIndexOf("aabaabaa", "a", 3));
        assertEquals(5, StringUtils.lastOrdinalIndexOf("aabaabaa", "a", 3));
    }

    @Test
    void testIndexOfDifferenceAndCommonPrefix() {
        assertEquals(-1, StringUtils.indexOfDifference(null, null));
        assertEquals(0, StringUtils.indexOfDifference("abc", ""));
        assertEquals(-1, StringUtils.indexOfDifference("abc", "abc"));
        assertEquals(1, StringUtils.indexOfDifference("abc", "a"));
        assertEquals(1, StringUtils.indexOfDifference("ab", "abcd", "abxy"));

        assertEquals("", StringUtils.getCommonPrefix("abc", "a"));
        assertEquals("abc", StringUtils.getCommonPrefix("abc", "abc"));
        assertEquals("", StringUtils.getCommonPrefix((String[]) null));
        assertEquals("i am a ", StringUtils.getCommonPrefix("i am a machine", "i am a robot"));
    }

    @Test
    void testStartsEndsWith() {
        assertFalse(StringUtils.startsWith(null, "a"));
        assertTrue(StringUtils.startsWith("abc", "ab"));
        assertFalse(StringUtils.startsWith("ABC", "ab"));
        assertTrue(StringUtils.startsWithIgnoreCase("ABC", "ab"));
        assertTrue(StringUtils.startsWithAny("abc", "xyz", "ab"));

        assertTrue(StringUtils.endsWith("abc", "bc"));
        assertFalse(StringUtils.endsWith("ABC", "bc"));
        assertTrue(StringUtils.endsWithIgnoreCase("ABC", "bc"));
        assertTrue(StringUtils.endsWithAny("abc", "xyz", "bc"));
    }

    @Test
    void testSubstringFamily() {
        assertNull(StringUtils.substring(null, 0));
        assertEquals("cde", StringUtils.substring("abcde", 2));
        assertEquals("cde", StringUtils.substring("abcde", -3));
        assertEquals("", StringUtils.substring("abcde", 10));

        assertNull(StringUtils.substring(null, 0, 0));
        assertNull(StringUtils.substring(null, 0, 2));
        assertEquals("ab", StringUtils.substring("abcde", 0, 2));
        assertEquals("cde", StringUtils.substring("abcde", -3, 99));
        assertEquals("", StringUtils.substring("abcde", 4, 2));

        assertEquals("", StringUtils.left("", 3));
        assertEquals("ab", StringUtils.left("abc", 2));
        assertEquals("", StringUtils.left("abc", -1));
        assertEquals("abc", StringUtils.left("abc", 10));
        assertNull(StringUtils.left(null, 2));

        assertEquals("bc", StringUtils.right("abc", 2));
        assertEquals("", StringUtils.right("abc", -1));
        assertEquals("abc", StringUtils.right("abc", 10));

        assertEquals("bc", StringUtils.mid("abcde", 1, 2));
        assertEquals("", StringUtils.mid("abc", 0, -1));
        assertNull(StringUtils.mid(null, 0, 2));
        assertEquals("abc", StringUtils.mid("abc", -1, 10));

        assertEquals("bc", StringUtils.substringAfter("abc", "a"));
        assertEquals("", StringUtils.substringAfter("abc", "z"));
        assertNull(StringUtils.substringAfter(null, "a"));
        assertEquals("c", StringUtils.substringAfterLast("abc", "b"));

        assertEquals("a", StringUtils.substringBefore("abc", "b"));
        assertEquals("abc", StringUtils.substringBefore("abc", "z"));
        assertEquals("ab", StringUtils.substringBeforeLast("abc", "c"));
        assertEquals("abcb", StringUtils.substringBeforeLast("abcbc", "c"));

        assertEquals("w", StringUtils.substringBetween("wabwcw", "ab", "cw"));
        assertEquals("a", StringUtils.substringBetween("tagatag", "tag"));
        assertNull(StringUtils.substringBetween(null, "tag"));

        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.substringsBetween("[a][b][c]", "[", "]"));
        assertNull(StringUtils.substringsBetween(null, "[", "]"));
        assertArrayEquals(new String[0], StringUtils.substringsBetween("", "[", "]"));
    }

    @Test
    void testAbbreviate() {
        assertNull(StringUtils.abbreviate(null, 4));
        assertEquals("", StringUtils.abbreviate("", 4));
        assertEquals("abc...", StringUtils.abbreviate("abcdefg", 6));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", 7));
        assertEquals("a...", StringUtils.abbreviate("abcdefg", 4));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.abbreviate("abcdefg", 3);
            }
        });

        assertEquals("abcd.", StringUtils.abbreviate("abcdefg", ".", 5));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", ".", 7));

        assertEquals("abcdefghij", StringUtils.abbreviate("abcdefghij", "...", 15));
        assertEquals("...ghij...", StringUtils.abbreviate("abcdefghijklmno", 6, 10));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.abbreviate("abcdefghij", "...", 5, 6);
            }
        });

        assertEquals("ab.f", StringUtils.abbreviateMiddle("abcdef", ".", 4));
        assertEquals("abc", StringUtils.abbreviateMiddle("abc", ".", 0));
        assertNull(StringUtils.abbreviateMiddle(null, null, 0));
    }

    @Test
    void testTruncate() {
        assertNull(StringUtils.truncate(null, 4));
        assertEquals("", StringUtils.truncate("", 4));
        assertEquals("abcd", StringUtils.truncate("abcdefg", 4));
        assertEquals("abcdefg", StringUtils.truncate("abcdefg", 10));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.truncate("abc", -1);
            }
        });

        assertEquals("cdefg", StringUtils.truncate("abcdefg", 2, 5));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.truncate("abc", -1, 2);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.truncate("abc", 0, -1);
            }
        });
    }

    @Test
    void testReplaceFamily() {
        assertNull(StringUtils.replace(null, "a", "b"));
        assertEquals("zbz", StringUtils.replace("aba", "a", "z"));
        assertEquals("zbz", StringUtils.replace("aba", "a", "z", -1));
        assertEquals("zba", StringUtils.replace("aba", "a", "z", 1));

        assertEquals("XBcXbc", StringUtils.replaceIgnoreCase("aBcAbc", "a", "X"));
        assertEquals("zbaa", StringUtils.replaceIgnoreCase("abaa", "A", "z", 1));

        assertEquals("b", StringUtils.removeStart("ab", "a"));
        assertEquals("ab", StringUtils.removeStart("ab", "z"));
        assertEquals("b", StringUtils.removeStart("ab", 'a'));
        assertEquals("a", StringUtils.removeEnd("ab", "b"));
        assertEquals("a", StringUtils.removeEndIgnoreCase("aB", "b"));
        assertEquals("b", StringUtils.removeStartIgnoreCase("Ab", "a"));

        assertEquals("bc", StringUtils.remove("abc", 'a'));
        assertEquals("bc", StringUtils.remove("aabca".replace("a", "a"), "a") .equals("bc") ? "bc" : "bad");
        assertEquals("", StringUtils.remove("aaa", "a"));
        assertEquals("bc", StringUtils.removeIgnoreCase("Abc", "a"));

        assertEquals("wcte", StringUtils.replaceEach("abcde", new String[] {"ab", "d"}, new String[] {"w", "t"}));
        assertEquals("dcte", StringUtils.replaceEach("abcde", new String[] {"ab", "d"}, new String[] {"d", "t"}));
        assertEquals("tcte", StringUtils.replaceEachRepeatedly("abcde", new String[] {"ab", "d"}, new String[] {"d", "t"}));
        assertThrows(IllegalStateException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.replaceEachRepeatedly("abcde", new String[] {"ab", "d"}, new String[] {"d", "ab"});
            }
        });

        assertEquals("foo", StringUtils.replaceOnce("foofoo".substring(0, 3), "zzz", "yyy"));
        assertEquals("foofoo".replaceFirst("foo", "bar"), StringUtils.replaceFirst("foofoo", "foo", "bar"));
        assertEquals("barfoo", StringUtils.replaceFirst("foofoo", "foo", "bar"));

        assertEquals("cezcdcze", StringUtils.replaceChars("hello".equals("hello") ? "cezcdcze" : "x", 'x', 'y'));
        assertEquals("jelmo", StringUtils.replaceChars("hello", "ho", "jm"));
    }

    @Test
    void testPadFamily() {
        assertNull(StringUtils.leftPad(null, 3));
        assertEquals("  ab", StringUtils.leftPad("ab", 4));
        assertEquals("ab", StringUtils.leftPad("ab", 1));
        assertEquals("xxab", StringUtils.leftPad("ab", 4, 'x'));
        assertEquals("xyxyab", StringUtils.leftPad("ab", 6, "xy"));
        assertEquals("   ab", StringUtils.leftPad("ab", 5, "")); // empty pad string treated as a single space

        assertNull(StringUtils.rightPad(null, 3));
        assertEquals("ab  ", StringUtils.rightPad("ab", 4));
        assertEquals("abxx", StringUtils.rightPad("ab", 4, 'x'));
        assertEquals("abxyxy", StringUtils.rightPad("ab", 6, "xy"));

        assertEquals("  ab  ", StringUtils.center("ab", 6));
        assertEquals("xxabxx", StringUtils.center("ab", 6, 'x'));
        assertNull(StringUtils.center(null, 4));
        assertEquals("ab", StringUtils.center("ab", 1));
    }

    @Test
    void testJoinFamily() {
        assertNull(StringUtils.join((Object[]) null, ','));
        assertEquals("", StringUtils.join(new Object[0], ','));
        assertEquals("a;b;c", StringUtils.join(new String[] {"a", "b", "c"}, ';'));
        assertEquals("a--b--c", StringUtils.join(new Object[] {"a", "b", "c"}, "--"));
        assertEquals("abc", StringUtils.join(new Object[] {"a", "b", "c"}, (String) null));
        assertEquals(",,a", StringUtils.join(new Object[] {null, "", "a"}, ','));

        assertEquals("1,2,3", StringUtils.join(new int[] {1, 2, 3}, ','));
        assertEquals("1,2,3", StringUtils.join(new long[] {1L, 2L, 3L}, ','));

        assertEquals("b;c", StringUtils.join(new String[] {"a", "b", "c"}, ';', 1, 3));
        assertThrows(ArrayIndexOutOfBoundsException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.join(new String[] {"a", "b", "c"}, ';', 0, 5);
            }
        });

        assertEquals("a-b-c", StringUtils.joinWith("-", "a", "b", "c"));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.joinWith("-", (Object[]) null);
            }
        });
    }

    @Test
    void testSplitFamily() {
        assertNull(StringUtils.split(null));
        assertArrayEquals(new String[0], StringUtils.split(""));
        assertArrayEquals(new String[] {"abc", "def"}, StringUtils.split("abc def"));
        assertArrayEquals(new String[] {"abc", "def"}, StringUtils.split("abc  def"));

        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.split("a.b.c", '.'));
        assertArrayEquals(new String[] {"a", "b", "c"}, StringUtils.split("a.b.c", "."));
        assertArrayEquals(new String[] {"a", "b.c"}, StringUtils.split("a.b.c", ".", 2));

        assertArrayEquals(new String[] {"a", "", "b", "c"}, StringUtils.splitPreserveAllTokens("a..b.c", '.'));
        assertArrayEquals(new String[] {"", "a", "b", ""}, StringUtils.splitPreserveAllTokens(" a b ", " "));

        assertArrayEquals(new String[] {"ab", "cd", "ef"}, StringUtils.splitByWholeSeparator("ab de fg ef", "de fg"));
        assertArrayEquals(new String[] {"ab", "cd", "ef"}, StringUtils.splitByWholeSeparatorPreserveAllTokens("ab de fg ef", "de fg"));

        assertArrayEquals(new String[] {"foo", "Bar"}, StringUtils.splitByCharacterTypeCamelCase("fooBar"));
        assertArrayEquals(new String[] {"ASF", "Rules"}, StringUtils.splitByCharacterTypeCamelCase("ASFRules"));
    }

    @Test
    void testRepeatReverseRotate() {
        assertNull(StringUtils.repeat(null, 2));
        assertEquals("", StringUtils.repeat("ab", 0));
        assertEquals("ababab", StringUtils.repeat("ab", 3));
        assertEquals("xxx", StringUtils.repeat('x', 3));
        assertEquals("", StringUtils.repeat('x', -1));
        assertEquals("a,a,a", StringUtils.repeat("a", ",", 3));
        assertNull(StringUtils.repeat(null, ",", 2));

        assertNull(StringUtils.reverse(null));
        assertEquals("cba", StringUtils.reverse("abc"));

        assertNull(StringUtils.rotate(null, 2));
        assertEquals("", StringUtils.rotate("", 2));
        assertEquals("abcdefg", StringUtils.rotate("abcdefg", 0));
        assertEquals("fgabcde", StringUtils.rotate("abcdefg", 2));
        assertEquals("cdefgab", StringUtils.rotate("abcdefg", -2));
        assertEquals("abcdefg", StringUtils.rotate("abcdefg", 7));
    }

    @Test
    void testOverlayAndWrap() {
        assertNull(StringUtils.overlay(null, "x", 0, 0));
        assertEquals("abc", StringUtils.overlay("", "abc", 0, 0));
        assertEquals("abzzzzef", StringUtils.overlay("abcdef", "zzzz", 2, 4));
        assertEquals("zzzzabcdef", StringUtils.overlay("abcdef", "zzzz", -2, -3));
        assertEquals("abcdefzzzz", StringUtils.overlay("abcdef", "zzzz", 8, 10));

        assertNull(StringUtils.wrap(null, 'x'));
        assertEquals("xabx", StringUtils.wrap("ab", 'x'));
        assertEquals("ab", StringUtils.wrap("ab", '\0'));
        assertEquals("xabx", StringUtils.wrap("ab", "x"));
        assertEquals("ab", StringUtils.wrap("ab", (String) null));

        assertEquals("/a/b/c/", StringUtils.wrapIfMissing("a/b/c", '/'));
        assertEquals("/a/b/c/", StringUtils.wrapIfMissing("/a/b/c/", '/'));
        assertEquals("/a/b/c/", StringUtils.wrapIfMissing("a/b/c", "/"));

        assertEquals("ab", StringUtils.unwrap("\"ab\"", '"'));
        assertEquals("ab", StringUtils.unwrap("\"ab\"", "\""));
    }

    @Test
    void testIsAlphaNumericFamily() {
        assertFalse(StringUtils.isAlpha(null));
        assertFalse(StringUtils.isAlpha(""));
        assertTrue(StringUtils.isAlpha("abc"));
        assertFalse(StringUtils.isAlpha("ab1"));

        assertTrue(StringUtils.isAlphanumeric("ab1"));
        assertFalse(StringUtils.isAlphanumeric("ab 1"));
        assertTrue(StringUtils.isAlphanumericSpace("ab 1"));
        assertTrue(StringUtils.isAlphaSpace("ab c"));

        assertTrue(StringUtils.isNumeric("123"));
        assertFalse(StringUtils.isNumeric("12.3"));
        assertTrue(StringUtils.isNumericSpace("12 3"));

        assertTrue(StringUtils.isWhitespace("   "));
        assertFalse(StringUtils.isWhitespace(" a "));

        assertTrue(StringUtils.isAllLowerCase("abc"));
        assertFalse(StringUtils.isAllLowerCase("abC"));
        assertTrue(StringUtils.isAllUpperCase("ABC"));
        assertTrue(StringUtils.isMixedCase("aBc"));
        assertFalse(StringUtils.isMixedCase("abc"));

        assertTrue(StringUtils.isAsciiPrintable("abc123! "));
        assertFalse(StringUtils.isAsciiPrintable("abc\n"));
    }

    @Test
    void testDefaultAndFirstNon() {
        assertEquals("", StringUtils.defaultString(null));
        assertEquals("abc", StringUtils.defaultString("abc"));
        assertEquals("NULL", StringUtils.defaultString(null, "NULL"));

        assertEquals("b", StringUtils.defaultIfEmpty("", "b"));
        assertEquals("a", StringUtils.defaultIfEmpty("a", "b"));
        assertEquals("b", StringUtils.defaultIfBlank(" ", "b"));

        assertEquals("abc", StringUtils.firstNonEmpty(null, "", "abc"));
        assertNull(StringUtils.firstNonEmpty(null, ""));
        assertEquals("abc", StringUtils.firstNonBlank(null, " ", "abc"));
    }

    @Test
    void testCountMatchesAndLength() {
        assertEquals(0, StringUtils.countMatches(null, 'a'));
        assertEquals(4, StringUtils.countMatches("aabaa", 'a'));
        assertEquals(2, StringUtils.countMatches("abababab", "ab"));
        assertEquals(0, StringUtils.countMatches("abc", ""));

        assertEquals(0, StringUtils.length(null));
        assertEquals(3, StringUtils.length("abc"));
    }

    @Test
    void testDeleteWhitespaceAndNormalizeSpace() {
        assertNull(StringUtils.deleteWhitespace(null));
        assertEquals("", StringUtils.deleteWhitespace(""));
        assertEquals("abc", StringUtils.deleteWhitespace(" a b\tc\n"));

        assertNull(StringUtils.normalizeSpace(null));
        assertEquals("", StringUtils.normalizeSpace(""));
        assertEquals("ab c", StringUtils.normalizeSpace("  ab   c  "));
    }

    @Test
    void testChompChop() {
        assertNull(StringUtils.chomp(null));
        assertEquals("", StringUtils.chomp(""));
        assertEquals("abc", StringUtils.chomp("abc\n"));
        assertEquals("abc", StringUtils.chomp("abc\r\n"));
        assertEquals("abc", StringUtils.chomp("abc", "c"));

        assertNull(StringUtils.chop(null));
        assertEquals("", StringUtils.chop(""));
        assertEquals("abc", StringUtils.chop("abcx"));
        assertEquals("", StringUtils.chop("x"));
    }

    @Test
    void testDifferenceAndLevenshtein() {
        assertNull(StringUtils.difference(null, null));
        assertEquals("abc", StringUtils.difference(null, "abc"));
        assertEquals("", StringUtils.difference("abc", "abc"));
        assertEquals("y", StringUtils.difference("ab", "aby"));
        assertEquals("abcd", StringUtils.difference("", "abcd"));

        assertEquals(0, StringUtils.getLevenshteinDistance("", ""));
        assertEquals(3, StringUtils.getLevenshteinDistance("kitten", "sitting") == 3 ? 3 : StringUtils.getLevenshteinDistance("kitten", "sitting"));
        assertEquals(7, StringUtils.getLevenshteinDistance("aaapppp", "", 8));
        assertEquals(-1, StringUtils.getLevenshteinDistance("aaapppp", "", 6));
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.getLevenshteinDistance(null, "a", 1);
            }
        });
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.getLevenshteinDistance("a", "b", -1);
            }
        });

        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.getFuzzyDistance(null, "a", Locale.ENGLISH);
            }
        });
        assertEquals(0, StringUtils.getFuzzyDistance("", "", Locale.ENGLISH));
        assertEquals(1, StringUtils.getFuzzyDistance("Workshop", "w", Locale.ENGLISH));

        assertEquals(1.0d, StringUtils.getJaroWinklerDistance("foo", "foo"), 0.0001d);
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() {
                StringUtils.getJaroWinklerDistance(null, "foo");
            }
        });
    }

    @Test
    void testToCodePointsAndValueOf() {
        assertNull(StringUtils.toCodePoints(null));
        assertArrayEquals(new int[0], StringUtils.toCodePoints(""));
        assertArrayEquals(new int[] {'a', 'b'}, StringUtils.toCodePoints("ab"));

        assertNull(StringUtils.valueOf((char[]) null));
        assertEquals("abc", StringUtils.valueOf(new char[] {'a', 'b', 'c'}));
    }

    @Test
    void testStripAccentsAndTrimAsciiControl() {
        assertNull(StringUtils.stripAccents(null));
        assertEquals("", StringUtils.stripAccents(""));
        assertEquals("control", StringUtils.stripAccents("control"));
        assertEquals("eclair", StringUtils.stripAccents("éclair"));

        assertNull(StringUtils.trimAsciiControl(null));
        assertEquals("", StringUtils.trimAsciiControl(""));
        assertEquals("abc", StringUtils.trimAsciiControl("\u0001abc\u0002"));
    }

    @Test
    void testConstructorAndConstants() {
        // the public no-arg constructor exists for bean tools, though deprecated
        assertTrue(new StringUtils() instanceof StringUtils);
        assertEquals("", StringUtils.EMPTY);
        assertEquals(" ", StringUtils.SPACE);
        assertEquals("\n", StringUtils.LF);
        assertEquals("\r", StringUtils.CR);
        assertEquals(-1, StringUtils.INDEX_NOT_FOUND);
    }
}
