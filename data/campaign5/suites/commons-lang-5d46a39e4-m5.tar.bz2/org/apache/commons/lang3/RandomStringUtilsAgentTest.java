/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Self-contained tests for {@link RandomStringUtils}.
 */
class RandomStringUtilsAgentTest {

    @SuppressWarnings("deprecation")
    @Test
    void testConstructorDeprecated() {
        final RandomStringUtils instance = new RandomStringUtils();
        assertNotNull(instance);
        assertNotNull(instance.next(5));
    }

    @Test
    void testSingletonsAreStableAndDistinct() {
        assertSame(RandomStringUtils.secure(), RandomStringUtils.secure());
        assertSame(RandomStringUtils.secureStrong(), RandomStringUtils.secureStrong());
        assertSame(RandomStringUtils.insecure(), RandomStringUtils.insecure());
        assertTrue(RandomStringUtils.secure() != RandomStringUtils.insecure());
        assertTrue(RandomStringUtils.secure() != RandomStringUtils.secureStrong());
    }

    @Test
    void testToString() {
        assertTrue(RandomStringUtils.secure().toString().contains("RandomStringUtils"));
    }

    // --- random(int) ---

    @SuppressWarnings("deprecation")
    @Test
    void testRandomCountZero() {
        assertEquals("", RandomStringUtils.random(0));
    }

    @SuppressWarnings("deprecation")
    @Test
    void testRandomCountNegative() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(-1);
            }
        });
    }

    @SuppressWarnings("deprecation")
    @Test
    void testRandomCountPositive() {
        final String s = RandomStringUtils.random(10);
        assertEquals(10, s.length());
    }

    // --- random(count, letters, numbers) ---

    @SuppressWarnings("deprecation")
    @Test
    void testRandomLettersNumbers() {
        final String s = RandomStringUtils.random(50, true, true);
        assertEquals(50, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(Character.isLetterOrDigit(c), "unexpected char: " + c);
        }
    }

    // --- random(count, chars...) ---

    @SuppressWarnings("deprecation")
    @Test
    void testRandomCharsArrayNull() {
        final String s = RandomStringUtils.random(5, (char[]) null);
        assertEquals(5, s.length());
    }

    @SuppressWarnings("deprecation")
    @Test
    void testRandomCharsArrayEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, new char[0]);
            }
        });
    }

    @SuppressWarnings("deprecation")
    @Test
    void testRandomCharsArrayRestrictedSet() {
        final char[] chars = { 'x', 'y', 'z' };
        final String s = RandomStringUtils.random(20, chars);
        assertEquals(20, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c == 'x' || c == 'y' || c == 'z', "unexpected char: " + c);
        }
    }

    // --- random(count, start, end, letters, numbers) ---

    @SuppressWarnings("deprecation")
    @Test
    void testRandomStartEndInvalidRange() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, 10, 5, false, false);
            }
        });
    }

    @SuppressWarnings("deprecation")
    @Test
    void testRandomStartEndNegative() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, -5, -1, false, false);
            }
        });
    }

    // --- random(count, start, end, letters, numbers, chars) full signature ---

    @Test
    void testRandomFullSignatureCountZero() {
        assertEquals("", RandomStringUtils.random(0, 0, 0, true, true, null, new java.util.Random()));
    }

    @Test
    void testRandomFullSignatureCountNegative() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(-1, 0, 0, true, true, null, new java.util.Random());
            }
        });
    }

    @Test
    void testRandomFullSignatureArrayIndexOutOfBounds() {
        // chars has only 3 entries but the requested range [0,10) allows indices up to 9;
        // with enough draws, hitting an out-of-range index is a near certainty.
        final char[] chars = { 'a', 'b', 'c' };
        assertThrows(ArrayIndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(500, 0, 10, false, false, chars, new java.util.Random());
            }
        });
    }

    @Test
    void testRandomFullSignatureNoLettersInRangeThrows() {
        final char[] chars = { '0', '1', '2' };
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(1, 0, 3, true, false, chars, new java.util.Random());
            }
        });
        assertTrue(ex.getMessage().contains("No letters exist"));
    }

    @Test
    void testRandomFullSignatureNoDigitsInRangeThrows() {
        final char[] chars = { 'a', 'b', 'c' };
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(1, 0, 3, false, true, chars, new java.util.Random());
            }
        });
        assertTrue(ex.getMessage().contains("No digits exist"));
    }

    @Test
    void testRandomFullSignatureAsciiLettersBoundaryThrows() {
        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(1, 1, 58, true, false, null, new java.util.Random());
            }
        });
        assertTrue(ex.getMessage().contains("must be greater than"));
    }

    @Test
    void testRandomFullSignatureDeterministicWithSeededRandom() {
        final char[] chars = { 'a', 'b', 'c', 'd' };
        final java.util.Random r1 = new java.util.Random(42L);
        final java.util.Random r2 = new java.util.Random(42L);
        final String s1 = RandomStringUtils.random(100, 0, chars.length, false, false, chars, r1);
        final String s2 = RandomStringUtils.random(100, 0, chars.length, false, false, chars, r2);
        assertEquals(s1, s2);
        assertEquals(100, s1.length());
    }

    // --- random(count, String) ---

    @SuppressWarnings("deprecation")
    @Test
    void testRandomStringCharsNull() {
        final String s = RandomStringUtils.random(5, (String) null);
        assertEquals(5, s.length());
    }

    @SuppressWarnings("deprecation")
    @Test
    void testRandomStringCharsEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.random(5, "");
            }
        });
    }

    @SuppressWarnings("deprecation")
    @Test
    void testRandomStringCharsRestrictedSet() {
        final String s = RandomStringUtils.random(15, "Q");
        assertEquals(15, s.length());
        for (int i = 0; i < s.length(); i++) {
            assertEquals('Q', s.charAt(i));
        }
    }

    // --- randomAlphabetic / randomAlphanumeric / randomAscii / randomGraph / randomNumeric / randomPrint (deprecated statics) ---

    @SuppressWarnings("deprecation")
    @Test
    void testRandomAlphabetic() {
        final String s = RandomStringUtils.randomAlphabetic(30);
        assertEquals(30, s.length());
        for (int i = 0; i < s.length(); i++) {
            assertTrue(Character.isLetter(s.charAt(i)));
        }
    }

    @SuppressWarnings("deprecation")
    @Test
    void testRandomAlphabeticNegativeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.randomAlphabetic(-3);
            }
        });
    }

    @SuppressWarnings("deprecation")
    @Test
    void testRandomAlphabeticRange() {
        for (int i = 0; i < 20; i++) {
            final String s = RandomStringUtils.randomAlphabetic(3, 8);
            assertTrue(s.length() >= 3 && s.length() < 8, "len=" + s.length());
        }
    }

    @SuppressWarnings("deprecation")
    @Test
    void testRandomAlphabeticRangeFixed() {
        final String s = RandomStringUtils.randomAlphabetic(4, 5);
        assertEquals(4, s.length());
    }

    @SuppressWarnings("deprecation")
    @Test
    void testRandomAlphabeticRangeInvalidThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.randomAlphabetic(8, 3);
            }
        });
    }

    @SuppressWarnings("deprecation")
    @Test
    void testRandomAlphanumeric() {
        final String s = RandomStringUtils.randomAlphanumeric(30);
        assertEquals(30, s.length());
        for (int i = 0; i < s.length(); i++) {
            assertTrue(Character.isLetterOrDigit(s.charAt(i)));
        }
    }

    @SuppressWarnings("deprecation")
    @Test
    void testRandomAlphanumericRange() {
        for (int i = 0; i < 20; i++) {
            final String s = RandomStringUtils.randomAlphanumeric(2, 9);
            assertTrue(s.length() >= 2 && s.length() < 9, "len=" + s.length());
        }
    }

    @SuppressWarnings("deprecation")
    @Test
    void testRandomAscii() {
        final String s = RandomStringUtils.randomAscii(30);
        assertEquals(30, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 32 && c <= 126, "unexpected char: " + (int) c);
        }
    }

    @SuppressWarnings("deprecation")
    @Test
    void testRandomAsciiRange() {
        for (int i = 0; i < 20; i++) {
            final String s = RandomStringUtils.randomAscii(1, 6);
            assertTrue(s.length() >= 1 && s.length() < 6, "len=" + s.length());
        }
    }

    @SuppressWarnings("deprecation")
    @Test
    void testRandomGraph() {
        final String s = RandomStringUtils.randomGraph(30);
        assertEquals(30, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 33 && c <= 126, "unexpected char: " + (int) c);
        }
    }

    @SuppressWarnings("deprecation")
    @Test
    void testRandomGraphRange() {
        for (int i = 0; i < 20; i++) {
            final String s = RandomStringUtils.randomGraph(2, 7);
            assertTrue(s.length() >= 2 && s.length() < 7, "len=" + s.length());
        }
    }

    @SuppressWarnings("deprecation")
    @Test
    void testRandomNumeric() {
        final String s = RandomStringUtils.randomNumeric(30);
        assertEquals(30, s.length());
        for (int i = 0; i < s.length(); i++) {
            assertTrue(Character.isDigit(s.charAt(i)));
        }
    }

    @SuppressWarnings("deprecation")
    @Test
    void testRandomNumericRange() {
        for (int i = 0; i < 20; i++) {
            final String s = RandomStringUtils.randomNumeric(2, 9);
            assertTrue(s.length() >= 2 && s.length() < 9, "len=" + s.length());
        }
    }

    @SuppressWarnings("deprecation")
    @Test
    void testRandomPrint() {
        final String s = RandomStringUtils.randomPrint(30);
        assertEquals(30, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 32 && c <= 126, "unexpected char: " + (int) c);
        }
    }

    @SuppressWarnings("deprecation")
    @Test
    void testRandomPrintRange() {
        for (int i = 0; i < 20; i++) {
            final String s = RandomStringUtils.randomPrint(2, 9);
            assertTrue(s.length() >= 2 && s.length() < 9, "len=" + s.length());
        }
    }

    // --- instance methods: next(...) family, exercised across all three singletons ---

    @Test
    void testNextCountZero() {
        assertEquals("", RandomStringUtils.secure().next(0));
        assertEquals("", RandomStringUtils.secureStrong().next(0));
        assertEquals("", RandomStringUtils.insecure().next(0));
    }

    @Test
    void testNextCountNegativeThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.secure().next(-1);
            }
        });
    }

    @Test
    void testNextCountPositive() {
        assertEquals(12, RandomStringUtils.secure().next(12).length());
        assertEquals(12, RandomStringUtils.secureStrong().next(12).length());
        assertEquals(12, RandomStringUtils.insecure().next(12).length());
    }

    @Test
    void testNextLettersNumbers() {
        final String s = RandomStringUtils.insecure().next(40, true, true);
        assertEquals(40, s.length());
        for (int i = 0; i < s.length(); i++) {
            assertTrue(Character.isLetterOrDigit(s.charAt(i)));
        }
    }

    @Test
    void testNextCharsArrayNull() {
        final char[] nullChars = null;
        final String s = RandomStringUtils.insecure().next(6, nullChars);
        assertEquals(6, s.length());
    }

    @Test
    void testNextCharsArrayRestricted() {
        final char[] chars = { '1', '2' };
        final String s = RandomStringUtils.insecure().next(25, chars);
        assertEquals(25, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c == '1' || c == '2');
        }
    }

    @Test
    void testNextStartEndLettersNumbers() {
        final String s = RandomStringUtils.insecure().next(10, 0, 0, true, true);
        assertEquals(10, s.length());
    }

    @Test
    void testNextStartEndInvalidThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.insecure().next(5, 10, 10, false, false);
            }
        });
    }

    @Test
    void testNextFullCharsVarargsArrayIndexOutOfBounds() {
        // only 2 chars provided but range [0,5) allows indices up to 4;
        // with enough draws, hitting an out-of-range index is a near certainty.
        assertThrows(ArrayIndexOutOfBoundsException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.insecure().next(500, 0, 5, false, false, 'a', 'b');
            }
        });
    }

    @Test
    void testNextStringNull() {
        final String s = RandomStringUtils.insecure().next(7, (String) null);
        assertEquals(7, s.length());
    }

    @Test
    void testNextStringEmptyThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.insecure().next(5, "");
            }
        });
    }

    @Test
    void testNextStringRestricted() {
        final String s = RandomStringUtils.insecure().next(9, "Z");
        assertEquals(9, s.length());
        for (int i = 0; i < s.length(); i++) {
            assertEquals('Z', s.charAt(i));
        }
    }

    @Test
    void testNextAlphabetic() {
        final String s = RandomStringUtils.secure().nextAlphabetic(25);
        assertEquals(25, s.length());
        for (int i = 0; i < s.length(); i++) {
            assertTrue(Character.isLetter(s.charAt(i)));
        }
    }

    @Test
    void testNextAlphabeticZero() {
        assertEquals("", RandomStringUtils.secure().nextAlphabetic(0));
    }

    @Test
    void testNextAlphabeticRange() {
        for (int i = 0; i < 20; i++) {
            final String s = RandomStringUtils.secure().nextAlphabetic(3, 6);
            assertTrue(s.length() >= 3 && s.length() < 6);
        }
    }

    @Test
    void testNextAlphabeticRangeFixedLength() {
        final String s = RandomStringUtils.secure().nextAlphabetic(5, 5);
        assertEquals(5, s.length());
    }

    @Test
    void testNextAlphabeticRangeInvertedThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                RandomStringUtils.secure().nextAlphabetic(9, 2);
            }
        });
    }

    @Test
    void testNextAlphanumeric() {
        final String s = RandomStringUtils.secure().nextAlphanumeric(25);
        assertEquals(25, s.length());
        for (int i = 0; i < s.length(); i++) {
            assertTrue(Character.isLetterOrDigit(s.charAt(i)));
        }
    }

    @Test
    void testNextAlphanumericRange() {
        for (int i = 0; i < 20; i++) {
            final String s = RandomStringUtils.secure().nextAlphanumeric(4, 10);
            assertTrue(s.length() >= 4 && s.length() < 10);
        }
    }

    @Test
    void testNextAscii() {
        final String s = RandomStringUtils.secure().nextAscii(25);
        assertEquals(25, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 32 && c <= 126);
        }
    }

    @Test
    void testNextAsciiRange() {
        for (int i = 0; i < 20; i++) {
            final String s = RandomStringUtils.secure().nextAscii(1, 5);
            assertTrue(s.length() >= 1 && s.length() < 5);
        }
    }

    @Test
    void testNextGraph() {
        final String s = RandomStringUtils.secure().nextGraph(25);
        assertEquals(25, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 33 && c <= 126);
        }
    }

    @Test
    void testNextGraphRange() {
        for (int i = 0; i < 20; i++) {
            final String s = RandomStringUtils.secure().nextGraph(2, 6);
            assertTrue(s.length() >= 2 && s.length() < 6);
        }
    }

    @Test
    void testNextNumeric() {
        final String s = RandomStringUtils.secure().nextNumeric(25);
        assertEquals(25, s.length());
        for (int i = 0; i < s.length(); i++) {
            assertTrue(Character.isDigit(s.charAt(i)));
        }
    }

    @Test
    void testNextNumericRange() {
        for (int i = 0; i < 20; i++) {
            final String s = RandomStringUtils.secure().nextNumeric(3, 8);
            assertTrue(s.length() >= 3 && s.length() < 8);
        }
    }

    @Test
    void testNextPrint() {
        final String s = RandomStringUtils.secure().nextPrint(25);
        assertEquals(25, s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            assertTrue(c >= 32 && c <= 126);
        }
    }

    @Test
    void testNextPrintRange() {
        for (int i = 0; i < 20; i++) {
            final String s = RandomStringUtils.secure().nextPrint(2, 9);
            assertTrue(s.length() >= 2 && s.length() < 9);
        }
    }
}
