/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.nio.file.Path;
import java.nio.file.Paths;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

public class SystemPropertiesAgentTest {

    private static final String TEST_KEY = "org.apache.commons.lang3.SystemPropertiesAgentTest.testKey";

    @AfterEach
    public void tearDown() {
        System.clearProperty(TEST_KEY);
    }

    @Test
    public void testGetPropertyKnown() {
        assertEquals(System.getProperty(SystemProperties.JAVA_VERSION), SystemProperties.getProperty(SystemProperties.JAVA_VERSION));
        assertNotNull(SystemProperties.getProperty(SystemProperties.JAVA_VERSION));
    }

    @Test
    public void testGetPropertyAbsentReturnsNull() {
        System.clearProperty(TEST_KEY);
        assertNull(SystemProperties.getProperty(TEST_KEY));
    }

    @Test
    public void testGetPropertyEmptyName() {
        assertNull(SystemProperties.getProperty(""));
        assertNull(SystemProperties.getProperty((String) null));
    }

    @Test
    public void testGetPropertyWithStringDefault() {
        System.clearProperty(TEST_KEY);
        assertEquals("fallback", SystemProperties.getProperty(TEST_KEY, "fallback"));
        System.setProperty(TEST_KEY, "actual");
        assertEquals("actual", SystemProperties.getProperty(TEST_KEY, "fallback"));
    }

    @Test
    public void testGetPropertyWithSupplierDefault() {
        System.clearProperty(TEST_KEY);
        assertEquals("sup", SystemProperties.getProperty(TEST_KEY, new java.util.function.Supplier<String>() {
            @Override
            public String get() {
                return "sup";
            }
        }));
    }

    @Test
    public void testIsPropertySet() {
        System.clearProperty(TEST_KEY);
        assertFalse(SystemProperties.isPropertySet(TEST_KEY));
        System.setProperty(TEST_KEY, "x");
        assertTrue(SystemProperties.isPropertySet(TEST_KEY));
    }

    @Test
    public void testGetBooleanAbsentUsesDefaultSupplier() {
        System.clearProperty(TEST_KEY);
        assertTrue(SystemProperties.getBoolean(TEST_KEY, new java.util.function.BooleanSupplier() {
            @Override
            public boolean getAsBoolean() {
                return true;
            }
        }));
    }

    @Test
    public void testGetBooleanAbsentNullSupplierReturnsFalse() {
        System.clearProperty(TEST_KEY);
        assertFalse(SystemProperties.getBoolean(TEST_KEY, null));
    }

    @Test
    public void testGetBooleanPresentIgnoresDefault() {
        System.setProperty(TEST_KEY, "true");
        assertTrue(SystemProperties.getBoolean(TEST_KEY, new java.util.function.BooleanSupplier() {
            @Override
            public boolean getAsBoolean() {
                return false;
            }
        }));
        System.setProperty(TEST_KEY, "false");
        assertFalse(SystemProperties.getBoolean(TEST_KEY, new java.util.function.BooleanSupplier() {
            @Override
            public boolean getAsBoolean() {
                return true;
            }
        }));
    }

    @Test
    public void testGetBooleanInvalidValueIsFalse() {
        System.setProperty(TEST_KEY, "notABoolean");
        assertFalse(SystemProperties.getBoolean(TEST_KEY, new java.util.function.BooleanSupplier() {
            @Override
            public boolean getAsBoolean() {
                return true;
            }
        }));
    }

    @Test
    public void testGetBooleanWithClassKey() {
        final String key = "key1";
        final String fullKey = getClass().getSimpleName() + "." + key;
        System.clearProperty(fullKey);
        try {
            System.setProperty(fullKey, "true");
            assertTrue(SystemProperties.getBoolean(getClass(), key, new java.util.function.BooleanSupplier() {
                @Override
                public boolean getAsBoolean() {
                    return false;
                }
            }));
        } finally {
            System.clearProperty(fullKey);
        }
    }

    @Test
    public void testGetIntAbsentUsesDefaultSupplier() {
        System.clearProperty(TEST_KEY);
        assertEquals(42, SystemProperties.getInt(TEST_KEY, new java.util.function.IntSupplier() {
            @Override
            public int getAsInt() {
                return 42;
            }
        }));
    }

    @Test
    public void testGetIntAbsentNullSupplierReturnsZero() {
        System.clearProperty(TEST_KEY);
        assertEquals(0, SystemProperties.getInt(TEST_KEY, null));
    }

    @Test
    public void testGetIntPresent() {
        System.setProperty(TEST_KEY, "123");
        assertEquals(123, SystemProperties.getInt(TEST_KEY, new java.util.function.IntSupplier() {
            @Override
            public int getAsInt() {
                return -1;
            }
        }));
    }

    @Test
    public void testGetIntInvalidValueThrows() {
        System.setProperty(TEST_KEY, "notAnInt");
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                SystemProperties.getInt(TEST_KEY, new java.util.function.IntSupplier() {
                    @Override
                    public int getAsInt() {
                        return 0;
                    }
                });
            }
        });
    }

    @Test
    public void testGetIntWithClassKey() {
        final String key = "intKey";
        final String fullKey = getClass().getSimpleName() + "." + key;
        try {
            System.setProperty(fullKey, "7");
            assertEquals(7, SystemProperties.getInt(getClass(), key, new java.util.function.IntSupplier() {
                @Override
                public int getAsInt() {
                    return -1;
                }
            }));
        } finally {
            System.clearProperty(fullKey);
        }
    }

    @Test
    public void testGetLongAbsentUsesDefaultSupplier() {
        System.clearProperty(TEST_KEY);
        assertEquals(99L, SystemProperties.getLong(TEST_KEY, new java.util.function.LongSupplier() {
            @Override
            public long getAsLong() {
                return 99L;
            }
        }));
    }

    @Test
    public void testGetLongAbsentNullSupplierReturnsZero() {
        System.clearProperty(TEST_KEY);
        assertEquals(0L, SystemProperties.getLong(TEST_KEY, null));
    }

    @Test
    public void testGetLongPresent() {
        System.setProperty(TEST_KEY, "123456789012");
        assertEquals(123456789012L, SystemProperties.getLong(TEST_KEY, new java.util.function.LongSupplier() {
            @Override
            public long getAsLong() {
                return -1L;
            }
        }));
    }

    @Test
    public void testGetLongInvalidValueThrows() {
        System.setProperty(TEST_KEY, "notALong");
        assertThrows(NumberFormatException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                SystemProperties.getLong(TEST_KEY, new java.util.function.LongSupplier() {
                    @Override
                    public long getAsLong() {
                        return 0L;
                    }
                });
            }
        });
    }

    @Test
    public void testGetLongWithClassKey() {
        final String key = "longKey";
        final String fullKey = getClass().getSimpleName() + "." + key;
        try {
            System.setProperty(fullKey, "55");
            assertEquals(55L, SystemProperties.getLong(getClass(), key, new java.util.function.LongSupplier() {
                @Override
                public long getAsLong() {
                    return -1L;
                }
            }));
        } finally {
            System.clearProperty(fullKey);
        }
    }

    @Test
    public void testGetPathAbsentUsesDefaultSupplier() {
        System.clearProperty(TEST_KEY);
        final Path fallback = Paths.get("fallback");
        assertEquals(fallback, SystemProperties.getPath(TEST_KEY, new java.util.function.Supplier<Path>() {
            @Override
            public Path get() {
                return fallback;
            }
        }));
    }

    @Test
    public void testGetPathAbsentNullSupplierReturnsNull() {
        System.clearProperty(TEST_KEY);
        assertNull(SystemProperties.getPath(TEST_KEY, null));
    }

    @Test
    public void testGetPathPresent() {
        System.setProperty(TEST_KEY, "some/path");
        assertEquals(Paths.get("some/path"), SystemProperties.getPath(TEST_KEY, new java.util.function.Supplier<Path>() {
            @Override
            public Path get() {
                return Paths.get("other");
            }
        }));
    }

    @Test
    public void testGetLineSeparatorNoArg() {
        assertEquals(System.getProperty(SystemProperties.LINE_SEPARATOR), SystemProperties.getLineSeparator());
    }

    @Test
    public void testGetLineSeparatorWithSupplierPresentIgnoresDefault() {
        final String original = System.getProperty(SystemProperties.LINE_SEPARATOR);
        try {
            System.setProperty(SystemProperties.LINE_SEPARATOR, "\n");
            assertEquals("\n", SystemProperties.getLineSeparator(new java.util.function.Supplier<String>() {
                @Override
                public String get() {
                    return "DEFAULT";
                }
            }));
        } finally {
            if (original != null) {
                System.setProperty(SystemProperties.LINE_SEPARATOR, original);
            }
        }
    }

    @Test
    public void testGetUserNameWithDefault() {
        final String original = System.getProperty(SystemProperties.USER_NAME);
        try {
            System.clearProperty(SystemProperties.USER_NAME);
            assertEquals("defaultUser", SystemProperties.getUserName("defaultUser"));
            System.setProperty(SystemProperties.USER_NAME, "bob");
            assertEquals("bob", SystemProperties.getUserName("defaultUser"));
        } finally {
            if (original != null) {
                System.setProperty(SystemProperties.USER_NAME, original);
            } else {
                System.clearProperty(SystemProperties.USER_NAME);
            }
        }
    }

    @Test
    public void testGetJavaSpecificationVersionWithDefault() {
        final String original = System.getProperty(SystemProperties.JAVA_SPECIFICATION_VERSION);
        try {
            System.clearProperty(SystemProperties.JAVA_SPECIFICATION_VERSION);
            assertEquals("99", SystemProperties.getJavaSpecificationVersion("99"));
        } finally {
            if (original != null) {
                System.setProperty(SystemProperties.JAVA_SPECIFICATION_VERSION, original);
            }
        }
    }

    @Test
    public void testSimpleStringGettersMatchSystemProperty() {
        assertEquals(System.getProperty(SystemProperties.JAVA_HOME), SystemProperties.getJavaHome());
        assertEquals(System.getProperty(SystemProperties.JAVA_VERSION), SystemProperties.getJavaVersion());
        assertEquals(System.getProperty(SystemProperties.OS_NAME), SystemProperties.getOsName());
        assertEquals(System.getProperty(SystemProperties.USER_HOME), SystemProperties.getUserHome());
        assertEquals(System.getProperty(SystemProperties.USER_DIR), SystemProperties.getUserDir());
        assertEquals(System.getProperty(SystemProperties.FILE_SEPARATOR), SystemProperties.getFileSeparator());
        assertEquals(System.getProperty(SystemProperties.PATH_SEPARATOR), SystemProperties.getPathSeparator());
    }

    @Test
    public void testGetterForUnsetPropertyReturnsNull() {
        final String original = System.getProperty(SystemProperties.AWT_TOOLKIT);
        try {
            System.clearProperty(SystemProperties.AWT_TOOLKIT);
            assertNull(SystemProperties.getAwtToolkit());
        } finally {
            if (original != null) {
                System.setProperty(SystemProperties.AWT_TOOLKIT, original);
            }
        }
    }

    @Test
    public void testConstructorIsDeprecatedButUsable() {
        assertNotNull(new SystemProperties());
    }
}
