/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.ClassUtils.Interfaces;
import org.junit.jupiter.api.Test;

/**
 * Tests {@link MethodUtils}.
 */
public class MethodUtilsAgentTest {

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    private @interface AgentAnnotation {
    }

    private interface AgentInterface {
        String interfaceMethod();
    }

    private static class AgentBase {
        public String baseMethod() {
            return "base";
        }

        @AgentAnnotation
        public void annotatedBase() {
            // no-op
        }
    }

    public static class AgentChild extends AgentBase implements AgentInterface {
        private int calls;

        @Override
        public String interfaceMethod() {
            return "impl";
        }

        public String overloaded(final Object o) {
            return "Object";
        }

        public String overloaded(final String s) {
            return "String";
        }

        @AgentAnnotation
        public void annotatedChild() {
            calls++;
        }

        public int getCalls() {
            return calls;
        }

        public static String staticMethod(final String s) {
            return "static:" + s;
        }

        public String varArgsMethod(final String first, final String... rest) {
            return first + ":" + rest.length;
        }

        public String throwing() {
            throw new IllegalStateException("boom");
        }

        private String privateMethod() {
            return "private";
        }
    }

    @Test
    void testConstructorIsPublicAndUsable() throws Exception {
        final Object instance = MethodUtils.class.getConstructor().newInstance();
        assertNotNull(instance);
        assertTrue(instance instanceof MethodUtils);
    }

    @Test
    void testGetAccessibleMethodFound() throws Exception {
        final Method method = AgentChild.class.getMethod("baseMethod");
        final Method accessible = MethodUtils.getAccessibleMethod(method);
        assertNotNull(accessible);
        assertEquals("baseMethod", accessible.getName());
    }

    @Test
    void testGetAccessibleMethodNullMethodReturnsNull() {
        assertNull(MethodUtils.getAccessibleMethod((Method) null));
    }

    @Test
    void testGetAccessibleMethodByNameAndParams() {
        final Method method = MethodUtils.getAccessibleMethod(AgentChild.class, "baseMethod");
        assertNotNull(method);
        assertEquals("baseMethod", method.getName());
    }

    @Test
    void testGetAccessibleMethodByNameNotFound() {
        assertNull(MethodUtils.getAccessibleMethod(AgentChild.class, "doesNotExist"));
    }

    @Test
    void testGetMatchingAccessibleMethodOverloadResolution() {
        final Method stringMethod = MethodUtils.getMatchingAccessibleMethod(AgentChild.class, "overloaded", String.class);
        assertNotNull(stringMethod);
        assertEquals(String.class, stringMethod.getParameterTypes()[0]);

        final Method objectMethod = MethodUtils.getMatchingAccessibleMethod(AgentChild.class, "overloaded", Object.class);
        assertNotNull(objectMethod);
        assertEquals(Object.class, objectMethod.getParameterTypes()[0]);
    }

    @Test
    void testGetMatchingAccessibleMethodNoMatch() {
        assertNull(MethodUtils.getMatchingAccessibleMethod(AgentChild.class, "overloaded", Integer.class, Integer.class));
    }

    @Test
    void testGetMatchingMethodExactMatch() {
        final Method method = MethodUtils.getMatchingMethod(AgentChild.class, "privateMethod");
        assertNotNull(method);
        assertEquals("privateMethod", method.getName());
    }

    @Test
    void testGetMatchingMethodNoSuchMethodReturnsNull() {
        assertNull(MethodUtils.getMatchingMethod(AgentChild.class, "noSuchMethodAtAll"));
    }

    @Test
    void testGetMatchingMethodNullClassThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                MethodUtils.getMatchingMethod(null, "foo");
            }
        });
    }

    @Test
    void testGetMatchingMethodEmptyNameThrows() {
        assertThrows(IllegalArgumentException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                MethodUtils.getMatchingMethod(AgentChild.class, "");
            }
        });
    }

    @Test
    void testGetMethodObjectFound() {
        final Method method = MethodUtils.getMethodObject(AgentChild.class, "baseMethod");
        assertNotNull(method);
        assertEquals("baseMethod", method.getName());
    }

    @Test
    void testGetMethodObjectNotFoundReturnsNull() {
        assertNull(MethodUtils.getMethodObject(AgentChild.class, "missingMethod"));
    }

    @Test
    void testGetMethodObjectNullClassOrNameReturnsNull() {
        assertNull(MethodUtils.getMethodObject(null, "baseMethod"));
        assertNull(MethodUtils.getMethodObject(AgentChild.class, null));
    }

    @Test
    void testGetAnnotationDirect() throws Exception {
        final Method method = AgentChild.class.getMethod("annotatedChild");
        final AgentAnnotation annotation = MethodUtils.getAnnotation(method, AgentAnnotation.class, true, true);
        assertNotNull(annotation);
    }

    @Test
    void testGetAnnotationFromSuperWhenSearchSupersTrue() throws Exception {
        final Method inherited = AgentChild.class.getMethod("annotatedBase");
        final AgentAnnotation annotation = MethodUtils.getAnnotation(inherited, AgentAnnotation.class, true, true);
        assertNotNull(annotation);
    }

    @Test
    void testGetAnnotationNullMethodThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Exception {
                final Method m = null;
                MethodUtils.getAnnotation(m, AgentAnnotation.class, true, true);
            }
        });
    }

    @Test
    void testGetAnnotationNullAnnotationClassThrows() throws Exception {
        final Method method = AgentChild.class.getMethod("annotatedChild");
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                MethodUtils.getAnnotation(method, null, true, true);
            }
        });
    }

    @Test
    void testGetMethodsListWithAnnotation() {
        final List<Method> methods = MethodUtils.getMethodsListWithAnnotation(AgentChild.class, AgentAnnotation.class);
        assertTrue(methods.size() >= 1);
        assertTrue(containsMethodNamed(methods, "annotatedChild"));
    }

    @Test
    void testGetMethodsListWithAnnotationSearchSupers() {
        final List<Method> withoutSupers = MethodUtils.getMethodsListWithAnnotation(AgentChild.class, AgentAnnotation.class);
        final List<Method> withSupers = MethodUtils.getMethodsListWithAnnotation(AgentChild.class, AgentAnnotation.class, true, true);
        assertTrue(withSupers.size() > withoutSupers.size());
        boolean foundBaseDeclared = false;
        for (final Method m : withSupers) {
            if (m.getDeclaringClass() == AgentBase.class) {
                foundBaseDeclared = true;
            }
        }
        assertTrue(foundBaseDeclared);
    }

    private static boolean containsMethodNamed(final List<Method> methods, final String name) {
        for (final Method m : methods) {
            if (m.getName().equals(name)) {
                return true;
            }
        }
        return false;
    }

    @Test
    void testGetMethodsListWithAnnotationNullClassThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                MethodUtils.getMethodsListWithAnnotation(null, AgentAnnotation.class);
            }
        });
    }

    @Test
    void testGetMethodsWithAnnotationArray() {
        final Method[] methods = MethodUtils.getMethodsWithAnnotation(AgentChild.class, AgentAnnotation.class);
        assertEquals(2, methods.length);
    }

    @Test
    void testGetOverrideHierarchy() throws Exception {
        final Method method = AgentChild.class.getMethod("interfaceMethod");
        final Set<Method> hierarchy = MethodUtils.getOverrideHierarchy(method, Interfaces.INCLUDE);
        assertTrue(hierarchy.contains(method));
        assertTrue(hierarchy.size() >= 2);
    }

    @Test
    void testGetOverrideHierarchyExcludeInterfaces() throws Exception {
        final Method method = AgentChild.class.getMethod("interfaceMethod");
        final Set<Method> hierarchy = MethodUtils.getOverrideHierarchy(method, Interfaces.EXCLUDE);
        assertEquals(1, hierarchy.size());
    }

    @Test
    void testGetOverrideHierarchyNullThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() {
                MethodUtils.getOverrideHierarchy(null, Interfaces.INCLUDE);
            }
        });
    }

    @Test
    void testInvokeMethodNoArgs() throws Exception {
        final AgentChild child = new AgentChild();
        final Object result = MethodUtils.invokeMethod(child, "baseMethod");
        assertEquals("base", result);
    }

    @Test
    void testInvokeMethodWithArgs() throws Exception {
        final AgentChild child = new AgentChild();
        final Object result = MethodUtils.invokeMethod(child, "overloaded", "hello");
        assertEquals("String", result);
    }

    @Test
    void testInvokeMethodVarArgs() throws Exception {
        final AgentChild child = new AgentChild();
        final Object result = MethodUtils.invokeMethod(child, "varArgsMethod", "a", "b", "c");
        assertEquals("a:2", result);
    }

    @Test
    void testInvokeMethodForceAccessPrivate() throws Exception {
        final AgentChild child = new AgentChild();
        final Object result = MethodUtils.invokeMethod(child, true, "privateMethod");
        assertEquals("private", result);
    }

    @Test
    void testInvokeMethodNoSuchMethodThrows() {
        final AgentChild child = new AgentChild();
        assertThrows(NoSuchMethodException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Exception {
                MethodUtils.invokeMethod(child, "noSuchMethod");
            }
        });
    }

    @Test
    void testInvokeMethodNullObjectThrows() {
        assertThrows(NullPointerException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Exception {
                MethodUtils.invokeMethod(null, "baseMethod");
            }
        });
    }

    @Test
    void testInvokeMethodWrapsTargetException() {
        final AgentChild child = new AgentChild();
        final InvocationTargetException thrown = assertThrows(InvocationTargetException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Exception {
                MethodUtils.invokeMethod(child, "throwing");
            }
        });
        assertTrue(thrown.getCause() instanceof IllegalStateException);
    }

    @Test
    void testInvokeExactMethodMatch() throws Exception {
        final AgentChild child = new AgentChild();
        final Object result = MethodUtils.invokeExactMethod(child, "overloaded", new Object[] { "x" }, new Class[] { String.class });
        assertEquals("String", result);
    }

    @Test
    void testInvokeExactMethodNoMatchThrows() {
        final AgentChild child = new AgentChild();
        assertThrows(NoSuchMethodException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Exception {
                // overloaded(Object) exists, but exact match for Integer does not.
                MethodUtils.invokeExactMethod(child, "overloaded", Integer.valueOf(1));
            }
        });
    }

    @Test
    void testInvokeStaticMethod() throws Exception {
        final Object result = MethodUtils.invokeStaticMethod(AgentChild.class, "staticMethod", "x");
        assertEquals("static:x", result);
    }

    @Test
    void testInvokeStaticMethodNoSuchMethodThrows() {
        assertThrows(NoSuchMethodException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Exception {
                MethodUtils.invokeStaticMethod(AgentChild.class, "noSuchStaticMethod");
            }
        });
    }

    @Test
    void testInvokeExactStaticMethod() throws Exception {
        final Object result = MethodUtils.invokeExactStaticMethod(AgentChild.class, "staticMethod",
                new Object[] { "y" }, new Class[] { String.class });
        assertEquals("static:y", result);
    }

    @Test
    void testInvokeExactStaticMethodNoMatchThrows() {
        assertThrows(NoSuchMethodException.class, new org.junit.jupiter.api.function.Executable() {
            @Override
            public void execute() throws Exception {
                MethodUtils.invokeExactStaticMethod(AgentChild.class, "staticMethod", Integer.valueOf(1));
            }
        });
    }

    @Test
    void testInvokeMethodWithNullArgsTreatedAsEmpty() throws Exception {
        final AgentChild child = new AgentChild();
        final Object result = MethodUtils.invokeMethod(child, "baseMethod", (Object[]) null, (Class<?>[]) null);
        assertEquals("base", result);
    }

    @Test
    void testStateChangeAfterInvoke() throws Exception {
        final AgentChild child = new AgentChild();
        assertEquals(0, child.getCalls());
        MethodUtils.invokeMethod(child, "annotatedChild");
        assertEquals(1, child.getCalls());
        MethodUtils.invokeMethod(child, "annotatedChild");
        assertEquals(2, child.getCalls());
    }

    @Test
    void testGetMethodsWithAnnotationNoneFound() {
        final Method[] methods = MethodUtils.getMethodsWithAnnotation(Object.class, AgentAnnotation.class);
        assertEquals(0, methods.length);
        assertFalse(methods.length > 0);
    }

    @Test
    void testGetAccessibleMethodOnInterfaceMethod() throws Exception {
        final Method method = AgentChild.class.getMethod("interfaceMethod");
        final Method accessible = MethodUtils.getAccessibleMethod(method);
        assertNotNull(accessible);
        assertArrayEquals(new Class<?>[0], accessible.getParameterTypes());
    }
}
