/*
  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      https://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
 */

package org.apache.commons.cli;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

@SuppressWarnings("deprecation") // this test exercises deprecated methods on purpose
class TypeHandlerAgentTest {

    private File tempFile;

    @AfterEach
    public void tearDown() {
        if (tempFile != null) {
            tempFile.delete();
        }
    }

    private File newTempFileInSandbox(final byte[] content) throws IOException {
        final String dir = System.getenv("TMPDIR");
        final File directory = dir != null ? new File(dir) : null;
        final File file = File.createTempFile("TypeHandlerAgentTest", ".tmp", directory);
        final FileOutputStream out = new FileOutputStream(file);
        try {
            out.write(content);
        } finally {
            out.close();
        }
        return file;
    }

    // --- createClass ---

    @Test
    public void testCreateClassValid() throws Exception {
        final Class<?> clazz = TypeHandler.createClass("java.lang.String");
        assertEquals(String.class, clazz);
    }

    @Test
    public void testCreateClassUnknownThrowsParseException() {
        final ParseException e = assertThrows(ParseException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                TypeHandler.createClass("no.such.ClassName");
            }
        });
        assertTrue(e.getCause() instanceof ClassNotFoundException);
    }

    // --- createDate ---

    @Test
    public void testCreateDateValid() {
        final Date date = TypeHandler.createDate("Wed Apr 17 15:13:13 GMT 2024");
        assertNotNull(date);
    }

    @Test
    public void testCreateDateInvalidThrowsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                TypeHandler.createDate("not a date at all");
            }
        });
    }

    // --- createDefaultMap ---

    @Test
    public void testCreateDefaultMapContainsExpectedEntries() {
        final Map<Class<?>, Converter<?, ? extends Throwable>> map = TypeHandler.createDefaultMap();
        assertTrue(map.containsKey(Long.class));
        assertTrue(map.containsKey(Integer.class));
        assertTrue(map.containsKey(Date.class));
        assertTrue(map.containsKey(File.class));
        assertTrue(map.containsKey(URL.class));
        assertTrue(map.containsKey(Number.class));
        assertFalse(map.containsKey(String.class));
    }

    @Test
    public void testCreateDefaultMapReturnsFreshMutableInstanceEachCall() {
        final Map<Class<?>, Converter<?, ? extends Throwable>> map1 = TypeHandler.createDefaultMap();
        final Map<Class<?>, Converter<?, ? extends Throwable>> map2 = TypeHandler.createDefaultMap();
        assertNotSame(map1, map2);
        map1.remove(Long.class);
        assertTrue(map2.containsKey(Long.class));
    }

    // --- createFile ---

    @Test
    public void testCreateFileReturnsFileForExistingPath() throws IOException {
        tempFile = newTempFileInSandbox(new byte[] {1, 2, 3});
        final File result = TypeHandler.createFile(tempFile.getAbsolutePath());
        assertEquals(tempFile.getAbsolutePath(), result.getAbsolutePath());
        assertTrue(result.exists());
    }

    @Test
    public void testCreateFileReturnsFileEvenForNonExistentPath() {
        final File result = TypeHandler.createFile("/no/such/path/definitely-not-there.txt");
        assertNotNull(result);
        assertFalse(result.exists());
    }

    // --- createFiles ---

    @Test
    public void testCreateFilesAlwaysThrowsUnsupportedOperationException() {
        assertThrows(UnsupportedOperationException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                TypeHandler.createFiles("anything");
            }
        });
    }

    // --- createNumber ---

    @Test
    public void testCreateNumberLongWhenNoDecimalPoint() throws Exception {
        final Number number = TypeHandler.createNumber("42");
        assertEquals(Long.valueOf(42L), number);
    }

    @Test
    public void testCreateNumberDoubleWhenDecimalPoint() throws Exception {
        final Number number = TypeHandler.createNumber("3.14");
        assertEquals(Double.valueOf(3.14), number);
    }

    @Test
    public void testCreateNumberInvalidThrowsParseException() {
        final ParseException e = assertThrows(ParseException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                TypeHandler.createNumber("not-a-number");
            }
        });
        assertTrue(e.getCause() instanceof NumberFormatException);
    }

    @Test
    public void testCreateNumberEmptyStringThrowsParseException() {
        assertThrows(ParseException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                TypeHandler.createNumber("");
            }
        });
    }

    // --- createObject ---

    @Test
    public void testCreateObjectWithDefaultConstructor() throws Exception {
        final Object obj = TypeHandler.createObject("java.util.ArrayList");
        assertTrue(obj instanceof List);
        assertTrue(((List<?>) obj).isEmpty());
    }

    @Test
    public void testCreateObjectWithoutDefaultConstructorThrowsParseException() {
        final ParseException e = assertThrows(ParseException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                // java.lang.Integer has no public no-arg constructor
                TypeHandler.createObject("java.lang.Integer");
            }
        });
        assertTrue(e.getCause() instanceof ReflectiveOperationException);
    }

    @Test
    public void testCreateObjectUnknownClassThrowsParseException() {
        assertThrows(ParseException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                TypeHandler.createObject("no.such.ClassName");
            }
        });
    }

    // --- createURL ---

    @Test
    public void testCreateURLValid() throws Exception {
        final URL url = TypeHandler.createURL("https://example.com/path");
        assertEquals("https://example.com/path", url.toString());
    }

    @Test
    public void testCreateURLInvalidThrowsParseException() {
        final ParseException e = assertThrows(ParseException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                TypeHandler.createURL("not a url");
            }
        });
        assertTrue(e.getCause() instanceof java.net.MalformedURLException);
    }

    // --- createValue(String, Class) ---

    @Test
    public void testCreateValueWithUnregisteredClassUsesIdentityDefaultConverter() throws Exception {
        final String result = TypeHandler.createValue("hello", String.class);
        assertEquals("hello", result);
    }

    @Test
    public void testCreateValueBigIntegerConverter() throws Exception {
        final BigInteger result = TypeHandler.createValue("123456789012345678901234567890", BigInteger.class);
        assertEquals(new BigInteger("123456789012345678901234567890"), result);
    }

    @Test
    public void testCreateValueBigDecimalConverter() throws Exception {
        final BigDecimal result = TypeHandler.createValue("1.5", BigDecimal.class);
        assertEquals(new BigDecimal("1.5"), result);
    }

    @Test
    public void testCreateValueShortAndByteConverters() throws Exception {
        assertEquals(Short.valueOf((short) 7), TypeHandler.createValue("7", Short.class));
        assertEquals(Byte.valueOf((byte) 7), TypeHandler.createValue("7", Byte.class));
    }

    // --- Character converter edge cases ---

    @Test
    public void testCharacterConverterPlainChar() throws Exception {
        final Character c = TypeHandler.createValue("A", Character.class);
        assertEquals(Character.valueOf('A'), c);
    }

    @Test
    public void testCharacterConverterUnicodeEscape() throws Exception {
        final Character c = TypeHandler.createValue("\\u0041", Character.class);
        assertEquals(Character.valueOf('A'), c);
    }

    @Test
    public void testCharacterConverterBmpBoundaryPasses() throws Exception {
        final Character c = TypeHandler.createValue("\\uFFFF", Character.class);
        assertEquals(Character.valueOf('￿'), c);
    }

    @Test
    public void testCharacterConverterNonBmpThrowsParseException() {
        final ParseException e = assertThrows(ParseException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                // U+1F600 is outside the Basic Multilingual Plane
                TypeHandler.createValue("\\u1F600", Character.class);
            }
        });
        assertTrue(e.getCause() instanceof IllegalArgumentException);
    }

    // --- createValue(String, Object) deprecated overload ---

    @Test
    public void testCreateValueObjectOverloadDelegatesToClassOverload() throws Exception {
        final Object result = TypeHandler.createValue("99", (Object) Long.class);
        assertEquals(Long.valueOf(99L), result);
    }

    @Test
    public void testCreateValueObjectOverloadWithNonClassArgumentThrowsClassCastException() {
        assertThrows(ClassCastException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                TypeHandler.createValue("99", (Object) "not-a-class");
            }
        });
    }

    // --- openFile ---

    @Test
    public void testOpenFileExistingReadableFile() throws Exception {
        tempFile = newTempFileInSandbox(new byte[] {9, 8, 7});
        FileInputStream in = null;
        try {
            in = TypeHandler.openFile(tempFile.getAbsolutePath());
            final int first = in.read();
            assertEquals(9, first);
        } finally {
            if (in != null) {
                in.close();
            }
        }
    }

    @Test
    public void testOpenFileMissingFileThrowsParseException() {
        final ParseException e = assertThrows(ParseException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                TypeHandler.openFile("/no/such/path/definitely-not-there.txt");
            }
        });
        assertNotNull(e.getCause());
    }

    // --- getDefault / singleton behavior ---

    @Test
    public void testGetDefaultReturnsSameSingletonInstanceEachTime() {
        final TypeHandler d1 = TypeHandler.getDefault();
        final TypeHandler d2 = TypeHandler.getDefault();
        assertNotNull(d1);
        assertSame(d1, d2);
    }

    // --- instance constructors ---

    @Test
    public void testDefaultConstructorUsesDefaultConverters() throws Exception {
        final TypeHandler handler = new TypeHandler();
        final Converter<Long, ?> converter = handler.getConverter(Long.class);
        assertEquals(Long.valueOf(5L), converter.apply("5"));
    }

    @Test
    public void testConstructorWithNullMapThrowsNullPointerException() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                new TypeHandler(null);
            }
        });
    }

    @Test
    public void testConstructorWithCustomMapUsesCustomConverter() throws Exception {
        final Map<Class<?>, Converter<?, ? extends Throwable>> customMap = new HashMap<Class<?>, Converter<?, ? extends Throwable>>();
        customMap.put(String.class, new Converter<String, RuntimeException>() {
            @Override
            public String apply(final String string) {
                return string.toUpperCase();
            }
        });
        final TypeHandler handler = new TypeHandler(customMap);
        final Converter<String, ?> converter = handler.getConverter(String.class);
        assertEquals("ABC", converter.apply("abc"));
    }

    @Test
    public void testCustomConverterMapDoesNotContainDefaultEntries() throws Exception {
        final Map<Class<?>, Converter<?, ? extends Throwable>> customMap = new HashMap<Class<?>, Converter<?, ? extends Throwable>>();
        final TypeHandler handler = new TypeHandler(customMap);
        // Long is not registered in this empty custom map, so the identity DEFAULT converter is used.
        final Converter<Long, ?> converter = handler.getConverter(Long.class);
        final Object result = converter.apply("5");
        assertEquals("5", result);
    }

    // --- getConverter ---

    @Test
    public void testGetConverterReturnsDefaultForUnregisteredClass() throws Exception {
        final TypeHandler handler = TypeHandler.getDefault();
        final Converter<String, ?> converter = handler.getConverter(String.class);
        assertEquals("unchanged", converter.apply("unchanged"));
    }

    @Test
    public void testGetConverterReturnsRegisteredConverterForFile() throws Exception {
        final TypeHandler handler = TypeHandler.getDefault();
        final Converter<File, ?> converter = handler.getConverter(File.class);
        final File file = converter.apply("some-path.txt");
        assertEquals("some-path.txt", file.getName());
    }
}
