/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link Fraction}.
 */
public class FractionAgentTest {

    @Test
    public void testGetFractionIntInt_basic() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertEquals(3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionIntInt_notReduced() {
        final Fraction f = Fraction.getFraction(2, 4);
        assertEquals(2, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionIntInt_negativeDenominatorMovesSignToNumerator() {
        final Fraction f = Fraction.getFraction(3, -7);
        assertEquals(-3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionIntInt_zeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                Fraction.getFraction(1, 0);
            }
        });
    }

    @Test
    public void testGetFractionIntInt_overflowOnNegate() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                Fraction.getFraction(Integer.MIN_VALUE, -1);
            }
        });
    }

    @Test
    public void testGetFractionWholeNumDenom_basic() {
        final Fraction f = Fraction.getFraction(1, 3, 7);
        // 1 and 3/7 => numerator = 1*7 + 3 = 10
        assertEquals(10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionWholeNumDenom_negativeWhole() {
        final Fraction f = Fraction.getFraction(-1, 3, 7);
        // -1 and 3/7 => numerator = -1*7 - 3 = -10
        assertEquals(-10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionWholeNumDenom_zeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                Fraction.getFraction(1, 1, 0);
            }
        });
    }

    @Test
    public void testGetFractionWholeNumDenom_negativeDenominatorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                Fraction.getFraction(1, 1, -7);
            }
        });
    }

    @Test
    public void testGetFractionWholeNumDenom_negativeNumeratorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                Fraction.getFraction(1, -1, 7);
            }
        });
    }

    @Test
    public void testGetFractionWholeNumDenom_numeratorOverflowThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                Fraction.getFraction(Integer.MAX_VALUE, 5, 2);
            }
        });
    }

    @Test
    public void testGetFractionDouble_basic() {
        final Fraction f = Fraction.getFraction(0.5d);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetFractionDouble_negative() {
        final Fraction f = Fraction.getFraction(-0.25d);
        assertEquals(-1, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionDouble_wholeNumber() {
        final Fraction f = Fraction.getFraction(5.0d);
        assertEquals(5, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    public void testGetFractionDouble_nanThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                Fraction.getFraction(Double.NaN);
            }
        });
    }

    @Test
    public void testGetFractionDouble_tooLargeThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                Fraction.getFraction(Integer.MAX_VALUE + 10.0d);
            }
        });
    }

    @Test
    public void testGetFractionString_doubleFormat() {
        final Fraction f = Fraction.getFraction("0.25");
        assertEquals(1, f.getNumerator());
        assertEquals(4, f.getDenominator());
    }

    @Test
    public void testGetFractionString_wholeAndFraction() {
        final Fraction f = Fraction.getFraction("1 3/7");
        assertEquals(10, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionString_simpleFraction() {
        final Fraction f = Fraction.getFraction("3/7");
        assertEquals(3, f.getNumerator());
        assertEquals(7, f.getDenominator());
    }

    @Test
    public void testGetFractionString_wholeNumber() {
        final Fraction f = Fraction.getFraction("5");
        assertEquals(5, f.getNumerator());
        assertEquals(1, f.getDenominator());
    }

    @Test
    public void testGetFractionString_nullThrowsNpe() {
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                Fraction.getFraction((String) null);
            }
        });
    }

    @Test
    public void testGetFractionString_malformedWholeNumeratorThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                Fraction.getFraction("1 3-7");
            }
        });
    }

    @Test
    public void testGetFractionString_invalidNumberThrows() {
        assertThrows(NumberFormatException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                Fraction.getFraction("abc");
            }
        });
    }

    @Test
    public void testGetReducedFraction_reducesToLowestTerms() {
        final Fraction f = Fraction.getReducedFraction(2, 4);
        assertEquals(1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetReducedFraction_zeroNumeratorNormalizes() {
        final Fraction f = Fraction.getReducedFraction(0, 5);
        assertEquals(0, f.getNumerator());
        assertEquals(1, f.getDenominator());
        assertEquals(Fraction.ZERO, f);
    }

    @Test
    public void testGetReducedFraction_negativeDenominatorNormalized() {
        final Fraction f = Fraction.getReducedFraction(4, -8);
        assertEquals(-1, f.getNumerator());
        assertEquals(2, f.getDenominator());
    }

    @Test
    public void testGetReducedFraction_zeroDenominatorThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                Fraction.getReducedFraction(1, 0);
            }
        });
    }

    @Test
    public void testAbs_positiveReturnsSame() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertEquals(f, f.abs());
    }

    @Test
    public void testAbs_negativeReturnsPositive() {
        final Fraction f = Fraction.getFraction(-3, 7);
        final Fraction abs = f.abs();
        assertEquals(3, abs.getNumerator());
        assertEquals(7, abs.getDenominator());
    }

    @Test
    public void testAdd_basic() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(1, 3);
        final Fraction sum = a.add(b);
        assertEquals(5, sum.getNumerator());
        assertEquals(6, sum.getDenominator());
    }

    @Test
    public void testAdd_zeroIdentity() {
        final Fraction a = Fraction.getFraction(3, 7);
        assertEquals(a, a.add(Fraction.ZERO));
        assertEquals(a, Fraction.ZERO.add(a));
    }

    @Test
    public void testAdd_nullThrows() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                a.add(null);
            }
        });
    }

    @Test
    public void testAdd_overflowThrows() {
        final Fraction a = Fraction.getFraction(Integer.MAX_VALUE - 1, Integer.MAX_VALUE);
        final Fraction b = Fraction.getFraction(Integer.MAX_VALUE - 2, Integer.MAX_VALUE - 1);
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                a.add(b);
            }
        });
    }

    @Test
    public void testCompareTo_sameInstance() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertEquals(0, a.compareTo(a));
    }

    @Test
    public void testCompareTo_equalValues() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(2, 4);
        assertEquals(0, a.compareTo(b));
    }

    @Test
    public void testCompareTo_lessAndGreater() {
        final Fraction a = Fraction.getFraction(1, 3);
        final Fraction b = Fraction.getFraction(1, 2);
        assertTrue(a.compareTo(b) < 0);
        assertTrue(b.compareTo(a) > 0);
    }

    @Test
    public void testCompareTo_nullThrows() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                a.compareTo(null);
            }
        });
    }

    @Test
    public void testDivideBy_basic() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(1, 3);
        final Fraction result = a.divideBy(b);
        assertEquals(3, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    @Test
    public void testDivideBy_zeroDivisorThrows() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                a.divideBy(Fraction.ZERO);
            }
        });
    }

    @Test
    public void testDivideBy_nullThrows() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                a.divideBy(null);
            }
        });
    }

    @Test
    public void testDoubleValue() {
        final Fraction f = Fraction.getFraction(1, 4);
        assertEquals(0.25d, f.doubleValue(), 0.0d);
    }

    @Test
    public void testEquals_sameValueDifferentDenominatorAreNotEqual() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(2, 4);
        assertNotEquals(a, b);
    }

    @Test
    public void testEquals_identicalValuesAreEqual() {
        final Fraction a = Fraction.getFraction(3, 7);
        final Fraction b = Fraction.getFraction(3, 7);
        assertEquals(a, b);
    }

    @Test
    public void testEquals_nullAndOtherTypesAreNotEqual() {
        final Fraction a = Fraction.getFraction(3, 7);
        assertFalse(a.equals(null));
        assertFalse(a.equals("3/7"));
    }

    @Test
    public void testEquals_sameInstance() {
        final Fraction a = Fraction.getFraction(3, 7);
        assertTrue(a.equals(a));
    }

    @Test
    public void testFloatValue() {
        final Fraction f = Fraction.getFraction(1, 4);
        assertEquals(0.25f, f.floatValue(), 0.0f);
    }

    @Test
    public void testGetDenominatorAndNumerator() {
        final Fraction f = Fraction.getFraction(-5, 9);
        assertEquals(-5, f.getNumerator());
        assertEquals(9, f.getDenominator());
    }

    @Test
    public void testGetProperNumerator_positiveImproperFraction() {
        final Fraction f = Fraction.getFraction(7, 4);
        assertEquals(3, f.getProperNumerator());
    }

    @Test
    public void testGetProperNumerator_negativeImproperFraction() {
        final Fraction f = Fraction.getFraction(-7, 4);
        assertEquals(3, f.getProperNumerator());
    }

    @Test
    public void testGetProperWhole_positiveAndNegative() {
        final Fraction positive = Fraction.getFraction(7, 4);
        final Fraction negative = Fraction.getFraction(-7, 4);
        assertEquals(1, positive.getProperWhole());
        assertEquals(-1, negative.getProperWhole());
    }

    @Test
    public void testHashCode_equalObjectsHaveEqualHashCode() {
        final Fraction a = Fraction.getFraction(3, 7);
        final Fraction b = Fraction.getFraction(3, 7);
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    public void testHashCode_isConsistentAcrossCalls() {
        final Fraction a = Fraction.getFraction(3, 7);
        assertEquals(a.hashCode(), a.hashCode());
    }

    @Test
    public void testIntValue_truncatesTowardZero() {
        final Fraction positive = Fraction.getFraction(7, 4);
        final Fraction negative = Fraction.getFraction(-7, 4);
        assertEquals(1, positive.intValue());
        assertEquals(-1, negative.intValue());
    }

    @Test
    public void testInvert_basic() {
        final Fraction f = Fraction.getFraction(3, 7);
        final Fraction inverted = f.invert();
        assertEquals(7, inverted.getNumerator());
        assertEquals(3, inverted.getDenominator());
    }

    @Test
    public void testInvert_negativeFractionKeepsSignOnNumerator() {
        final Fraction f = Fraction.getFraction(-3, 7);
        final Fraction inverted = f.invert();
        assertEquals(-7, inverted.getNumerator());
        assertEquals(3, inverted.getDenominator());
    }

    @Test
    public void testInvert_zeroThrows() {
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                Fraction.ZERO.invert();
            }
        });
    }

    @Test
    public void testInvert_minValueNumeratorThrows() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                f.invert();
            }
        });
    }

    @Test
    public void testLongValue_truncatesTowardZero() {
        final Fraction positive = Fraction.getFraction(7, 4);
        final Fraction negative = Fraction.getFraction(-7, 4);
        assertEquals(1L, positive.longValue());
        assertEquals(-1L, negative.longValue());
    }

    @Test
    public void testMultiplyBy_basic() {
        final Fraction a = Fraction.getFraction(2, 3);
        final Fraction b = Fraction.getFraction(3, 4);
        final Fraction result = a.multiplyBy(b);
        assertEquals(1, result.getNumerator());
        assertEquals(2, result.getDenominator());
    }

    @Test
    public void testMultiplyBy_zeroYieldsZero() {
        final Fraction a = Fraction.getFraction(2, 3);
        assertEquals(Fraction.ZERO, a.multiplyBy(Fraction.ZERO));
    }

    @Test
    public void testMultiplyBy_nullThrows() {
        final Fraction a = Fraction.getFraction(2, 3);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                a.multiplyBy(null);
            }
        });
    }

    @Test
    public void testNegate_basic() {
        final Fraction f = Fraction.getFraction(3, 7);
        final Fraction negated = f.negate();
        assertEquals(-3, negated.getNumerator());
        assertEquals(7, negated.getDenominator());
    }

    @Test
    public void testNegate_minValueThrows() {
        final Fraction f = Fraction.getFraction(Integer.MIN_VALUE, 1);
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                f.negate();
            }
        });
    }

    @Test
    public void testPow_zeroPowerAlwaysReturnsOne() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertEquals(Fraction.ONE, f.pow(0));
        assertEquals(Fraction.ONE, Fraction.ZERO.pow(0));
    }

    @Test
    public void testPow_onePowerReturnsSameInstance() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertTrue(f == f.pow(1));
    }

    @Test
    public void testPow_positivePower() {
        final Fraction f = Fraction.getFraction(2, 3);
        final Fraction result = f.pow(3);
        assertEquals(8, result.getNumerator());
        assertEquals(27, result.getDenominator());
    }

    @Test
    public void testPow_negativePowerInverts() {
        final Fraction f = Fraction.getFraction(2, 3);
        final Fraction result = f.pow(-2);
        assertEquals(9, result.getNumerator());
        assertEquals(4, result.getDenominator());
    }

    @Test
    public void testPow_minValuePowerOnOneStaysOne() {
        final Fraction result = Fraction.ONE.pow(Integer.MIN_VALUE);
        assertEquals(Fraction.ONE, result);
    }

    @Test
    public void testPow_minValuePowerOverflowsForNonUnitFraction() {
        final Fraction f = Fraction.getFraction(1, 2);
        assertThrows(ArithmeticException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                f.pow(Integer.MIN_VALUE);
            }
        });
    }

    @Test
    public void testReduce_reducesToLowestTerms() {
        final Fraction f = Fraction.getFraction(4, 8);
        final Fraction reduced = f.reduce();
        assertEquals(1, reduced.getNumerator());
        assertEquals(2, reduced.getDenominator());
    }

    @Test
    public void testReduce_alreadyReducedReturnsSameInstance() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertTrue(f == f.reduce());
    }

    @Test
    public void testReduce_zeroNumeratorReturnsZeroConstant() {
        final Fraction f = Fraction.getFraction(0, 5);
        assertEquals(Fraction.ZERO, f.reduce());
    }

    @Test
    public void testSubtract_basic() {
        final Fraction a = Fraction.getFraction(1, 2);
        final Fraction b = Fraction.getFraction(1, 3);
        final Fraction result = a.subtract(b);
        assertEquals(1, result.getNumerator());
        assertEquals(6, result.getDenominator());
    }

    @Test
    public void testSubtract_nullThrows() {
        final Fraction a = Fraction.getFraction(1, 2);
        assertThrows(NullPointerException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                a.subtract(null);
            }
        });
    }

    @Test
    public void testToProperString_wholeAndFraction() {
        final Fraction f = Fraction.getFraction(7, 4);
        assertEquals("1 3/4", f.toProperString());
    }

    @Test
    public void testToProperString_negativeWholeAndFraction() {
        final Fraction f = Fraction.getFraction(-7, 4);
        assertEquals("-1 3/4", f.toProperString());
    }

    @Test
    public void testToProperString_zero() {
        assertEquals("0", Fraction.ZERO.toProperString());
    }

    @Test
    public void testToProperString_simpleProperFraction() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertEquals("3/7", f.toProperString());
    }

    @Test
    public void testToString_basic() {
        final Fraction f = Fraction.getFraction(3, 7);
        assertEquals("3/7", f.toString());
    }

    @Test
    public void testToString_negativeNumerator() {
        final Fraction f = Fraction.getFraction(-3, 7);
        assertEquals("-3/7", f.toString());
    }

    @Test
    public void testConstants() {
        assertEquals(0, Fraction.ZERO.getNumerator());
        assertEquals(1, Fraction.ZERO.getDenominator());
        assertEquals(1, Fraction.ONE.getNumerator());
        assertEquals(1, Fraction.ONE.getDenominator());
        assertEquals(1, Fraction.ONE_HALF.getNumerator());
        assertEquals(2, Fraction.ONE_HALF.getDenominator());
        assertEquals(1, Fraction.ONE_THIRD.getNumerator());
        assertEquals(3, Fraction.ONE_THIRD.getDenominator());
        assertEquals(2, Fraction.TWO_THIRDS.getNumerator());
        assertEquals(3, Fraction.TWO_THIRDS.getDenominator());
        assertEquals(1, Fraction.ONE_QUARTER.getNumerator());
        assertEquals(4, Fraction.ONE_QUARTER.getDenominator());
        assertEquals(2, Fraction.TWO_QUARTERS.getNumerator());
        assertEquals(4, Fraction.TWO_QUARTERS.getDenominator());
        assertEquals(3, Fraction.THREE_QUARTERS.getNumerator());
        assertEquals(4, Fraction.THREE_QUARTERS.getDenominator());
        assertEquals(1, Fraction.ONE_FIFTH.getNumerator());
        assertEquals(5, Fraction.ONE_FIFTH.getDenominator());
        assertEquals(2, Fraction.TWO_FIFTHS.getNumerator());
        assertEquals(5, Fraction.TWO_FIFTHS.getDenominator());
        assertEquals(3, Fraction.THREE_FIFTHS.getNumerator());
        assertEquals(5, Fraction.THREE_FIFTHS.getDenominator());
        assertEquals(4, Fraction.FOUR_FIFTHS.getNumerator());
        assertEquals(5, Fraction.FOUR_FIFTHS.getDenominator());
    }

}
