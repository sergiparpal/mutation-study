/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.csv;

import static org.apache.commons.csv.Constants.UNDEFINED;
import static org.apache.commons.io.IOUtils.EOF;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.StandardCharsets;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Self-contained tests for {@link ExtendedBufferedReader}.
 */
class ExtendedBufferedReaderAgentTest {

    private static ExtendedBufferedReader create(final String s) {
        return new ExtendedBufferedReader(new StringReader(s));
    }

    @Test
    void testInitialStateBeforeAnyRead() throws IOException {
        final ExtendedBufferedReader br = create("abc");
        try {
            assertEquals(UNDEFINED, br.getLastChar());
            assertEquals(0, br.getLineNumber());
            assertEquals(0, br.getPosition());
            assertEquals(0, br.getBytesRead());
        } finally {
            br.close();
        }
    }

    @Test
    void testReadSingleCharAdvancesPositionAndLastChar() throws IOException {
        final ExtendedBufferedReader br = create("ab");
        try {
            assertEquals('a', br.read());
            assertEquals('a', br.getLastChar());
            assertEquals(1, br.getPosition());
            assertEquals('b', br.read());
            assertEquals('b', br.getLastChar());
            assertEquals(2, br.getPosition());
            assertEquals(EOF, br.read());
            assertEquals(EOF, br.getLastChar());
            assertEquals(3, br.getPosition());
        } finally {
            br.close();
        }
    }

    @Test
    void testEmptyInputBehavior() throws IOException {
        final ExtendedBufferedReader br = create("");
        try {
            assertEquals(0, br.getLineNumber());
            assertEquals(EOF, br.peek());
            assertEquals(EOF, br.read());
            assertEquals(EOF, br.getLastChar());
            // Reading the EOF sentinel itself counts as an EOL for line-counting purposes.
            assertEquals(1, br.getLineNumber());
            assertNull(br.readLine());
            assertEquals(0, br.read(new char[10], 0, 0));
        } finally {
            br.close();
        }
    }

    @Test
    void testBulkReadZeroLengthDoesNotAdvanceOrThrow() throws IOException {
        final ExtendedBufferedReader br = create("hello");
        try {
            final char[] buf = new char[5];
            assertEquals(0, br.read(buf, 0, 0));
            assertEquals(UNDEFINED, br.getLastChar());
            assertEquals(0, br.getPosition());
            assertEquals('h', br.read());
        } finally {
            br.close();
        }
    }

    @Test
    void testBulkReadAtEofReturnsEofAndSetsLastChar() throws IOException {
        final ExtendedBufferedReader br = create("");
        try {
            final char[] buf = new char[4];
            assertEquals(EOF, br.read(buf, 0, 4));
            assertEquals(EOF, br.getLastChar());
        } finally {
            br.close();
        }
    }

    @Test
    void testBulkReadPopulatesBufferAndLastChar() throws IOException {
        final ExtendedBufferedReader br = create("abcdef");
        try {
            final char[] buf = new char[6];
            final int n = br.read(buf, 1, 4);
            assertEquals(4, n);
            assertEquals('a', buf[1]);
            assertEquals('b', buf[2]);
            assertEquals('c', buf[3]);
            assertEquals('d', buf[4]);
            assertEquals('d', br.getLastChar());
            assertEquals(4, br.getPosition());
        } finally {
            br.close();
        }
    }

    @Test
    void testLineNumberWithCrLfLfCr() throws IOException {
        // a\n b\r c\n\n d\r\r e (EOF): EOLs at each \n, each \r, and the trailing EOF itself.
        final String test = "a\nb\rc\n\nd\r\re";
        final int eolCount = 7;
        final ExtendedBufferedReader br = create(test);
        try {
            assertEquals(0, br.getLineNumber());
            int readCount = 0;
            while (br.read() != EOF) {
                readCount++;
            }
            assertEquals(test.length(), readCount);
            assertEquals(eolCount, br.getLineNumber());
        } finally {
            br.close();
        }
    }

    @Test
    void testGetLineNumberAccountsForPendingLineBeforeEol() throws IOException {
        final ExtendedBufferedReader br = create("ab\ncd");
        try {
            assertEquals(0, br.getLineNumber());
            br.read(); // 'a'
            // Not yet at EOL/EOF, counter was not incremented, but one line is in progress.
            assertEquals(1, br.getLineNumber());
            br.read(); // 'b'
            assertEquals(1, br.getLineNumber());
            br.read(); // '\n'
            assertEquals(1, br.getLineNumber());
            br.read(); // 'c'
            assertEquals(2, br.getLineNumber());
        } finally {
            br.close();
        }
    }

    @Test
    void testReadLineDropsTerminatorsAndHandlesCrLf() throws IOException {
        final ExtendedBufferedReader br = create("foo\r\n\nbar\rbaz");
        try {
            assertEquals("foo", br.readLine());
            assertEquals(1, br.getLineNumber());
            assertEquals("", br.readLine());
            assertEquals(2, br.getLineNumber());
            assertEquals("bar", br.readLine());
            assertEquals(3, br.getLineNumber());
            assertEquals("baz", br.readLine());
            assertNull(br.readLine());
        } finally {
            br.close();
        }
    }

    @Test
    void testReadLineOnEmptyReturnsNull() throws IOException {
        final ExtendedBufferedReader br = create("");
        try {
            assertNull(br.readLine());
            assertNull(br.readLine());
        } finally {
            br.close();
        }
    }

    @Test
    void testPeekDoesNotAdvancePositionOrLastChar() throws IOException {
        final ExtendedBufferedReader br = create("xy");
        try {
            assertEquals('x', br.peek());
            assertEquals('x', br.peek());
            assertEquals(UNDEFINED, br.getLastChar());
            assertEquals(0, br.getPosition());
            assertEquals('x', br.read());
            assertEquals('y', br.peek());
            assertEquals('x', br.getLastChar());
        } finally {
            br.close();
        }
    }

    @Test
    void testMarkAndResetRestoreAllTrackedState() throws IOException {
        final ExtendedBufferedReader br = create("ab\ncd");
        try {
            br.read(); // 'a'
            br.read(); // 'b'
            br.mark(10);
            final long markedPosition = br.getPosition();
            final long markedLineNumber = br.getLineNumber();
            final int markedLastChar = br.getLastChar();

            br.read(); // '\n'
            br.read(); // 'c'
            assertTrue(br.getPosition() > markedPosition);

            br.reset();
            assertEquals(markedPosition, br.getPosition());
            assertEquals(markedLineNumber, br.getLineNumber());
            assertEquals(markedLastChar, br.getLastChar());
            assertEquals('\n', br.read());
        } finally {
            br.close();
        }
    }

    @Test
    void testCloseSetsLastCharToEofAndBlocksFurtherReads() throws IOException {
        final ExtendedBufferedReader br = create("abc");
        br.read();
        br.close();
        assertEquals(EOF, br.getLastChar());
        assertThrows(IOException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                br.read();
            }
        });
    }

    @Test
    void testMarkSupported() throws IOException {
        final ExtendedBufferedReader br = create("abc");
        try {
            assertTrue(br.markSupported());
        } finally {
            br.close();
        }
    }

    @Test
    void testBytesReadWithoutTrackingStaysZero() throws IOException {
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("hello"), StandardCharsets.UTF_8, false);
        try {
            while (br.read() != EOF) {
                // consume
            }
            assertEquals(0, br.getBytesRead());
        } finally {
            br.close();
        }
    }

    @Test
    void testBytesReadWithoutCharsetStaysZero() throws IOException {
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("hello"), null, true);
        try {
            while (br.read() != EOF) {
                // consume
            }
            assertEquals(0, br.getBytesRead());
        } finally {
            br.close();
        }
    }

    @Test
    void testBytesReadAsciiOneBytePerChar() throws IOException {
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader("abc"), StandardCharsets.UTF_8, true);
        try {
            br.read();
            assertEquals(1, br.getBytesRead());
            br.read();
            assertEquals(2, br.getBytesRead());
            br.read();
            assertEquals(3, br.getBytesRead());
        } finally {
            br.close();
        }
    }

    @Test
    void testBytesReadMultiByteUtf8Characters() throws IOException {
        // U+00E9 (e acute) = 2 bytes in UTF-8, U+4E2D (CJK) = 3 bytes in UTF-8.
        final String s = "é中";
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader(s), StandardCharsets.UTF_8, true);
        try {
            br.read();
            assertEquals(2, br.getBytesRead());
            br.read();
            assertEquals(5, br.getBytesRead());
        } finally {
            br.close();
        }
    }

    @Test
    void testBytesReadSurrogatePairFourByteUtf8Character() throws IOException {
        // U+1F600 (grinning face emoji) = 4 bytes in UTF-8, encoded as a surrogate pair.
        final String s = new StringBuilder().appendCodePoint(0x1F600).toString();
        assertEquals(2, s.length());
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader(s), StandardCharsets.UTF_8, true);
        try {
            // High surrogate contributes 0 bytes on its own.
            br.read();
            assertEquals(0, br.getBytesRead());
            // Low surrogate completes the pair, contributing all 4 bytes.
            br.read();
            assertEquals(4, br.getBytesRead());
        } finally {
            br.close();
        }
    }

    @Test
    void testBytesReadUnpairedLowSurrogateThrows() throws IOException {
        final String s = "\udc00"; // lone low surrogate, no preceding high surrogate
        final ExtendedBufferedReader br = new ExtendedBufferedReader(new StringReader(s), StandardCharsets.UTF_8, true);
        try {
            assertThrows(CharacterCodingException.class, new Executable() {
                @Override
                public void execute() throws Throwable {
                    br.read();
                }
            });
        } finally {
            br.close();
        }
    }

    @Test
    void testBulkReadTracksLineNumberAcrossSplitCrLf() throws IOException {
        final char[] tmp1 = new char[2];
        final char[] tmp2 = new char[4];
        final ExtendedBufferedReader br = create("1\r\n2\r\n");
        try {
            final int n1 = br.read(tmp1, 0, 2);
            assertEquals(2, n1);
            final int n2 = br.read(tmp2, 2, 2);
            assertEquals(2, n2);
            assertEquals(2, br.getLineNumber());
        } finally {
            br.close();
        }
    }

    @Test
    void testReadyThrowsAfterClose() throws IOException {
        final ExtendedBufferedReader br = create("a");
        assertTrue(br.ready());
        br.close();
        assertThrows(IOException.class, new Executable() {
            @Override
            public void execute() throws Throwable {
                br.ready();
            }
        });
    }
}
