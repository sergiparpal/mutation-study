package com.google.gson.internal;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.io.Serializable;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.AbstractSet;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.Test;

/**
 * Self-contained tests for {@link $Gson$Types}, based solely on the documented
 * contract in the generated javadoc (api/com/google/gson/internal/$Gson$Types.html).
 */
public class $Gson$TypesAgentTest {

    /** Fixture used to obtain a real {@link TypeVariable} and to exercise resolve(). */
    static class Box<T> {
        T value;
    }

    /**
     * Mirrors the example used in the javadoc for getGenericSupertype: "given a class
     * IntegerSet, the result for when supertype is Set.class is Set&lt;Integer&gt; and the
     * result when the supertype is Collection.class is Collection&lt;Integer&gt;."
     */
    abstract static class IntegerSet extends AbstractSet<Integer> {
    }

    // ---------------------------------------------------------------
    // EMPTY_TYPE_ARRAY field
    // ---------------------------------------------------------------

    @Test
    public void testEmptyTypeArrayIsEmpty() {
        Type[] array = $Gson$Types.EMPTY_TYPE_ARRAY;
        assertNotNull(array);
        assertEquals(0, array.length);
    }

    // ---------------------------------------------------------------
    // arrayOf
    // ---------------------------------------------------------------

    @Test
    public void testArrayOfReturnsGenericArrayTypeWithGivenComponent() {
        Type t = $Gson$Types.arrayOf(String.class);
        assertTrue(t instanceof GenericArrayType);
        assertEquals(String.class, ((GenericArrayType) t).getGenericComponentType());
    }

    @Test
    public void testArrayOfPrimitiveComponent() {
        Type t = $Gson$Types.arrayOf(int.class);
        assertTrue(t instanceof GenericArrayType);
        assertEquals(int.class, ((GenericArrayType) t).getGenericComponentType());
    }

    @Test
    public void testArrayOfIsSerializable() {
        Type t = $Gson$Types.arrayOf(String.class);
        assertTrue(t instanceof Serializable);
    }

    @Test
    public void testArrayOfIsFunctionallyEqualAcrossSeparateInstances() {
        Type t1 = $Gson$Types.arrayOf(String.class);
        Type t2 = $Gson$Types.arrayOf(String.class);
        assertTrue($Gson$Types.equals(t1, t2));
    }

    @Test
    public void testArrayOfDifferentComponentsAreNotEqual() {
        Type t1 = $Gson$Types.arrayOf(String.class);
        Type t2 = $Gson$Types.arrayOf(Integer.class);
        assertFalse($Gson$Types.equals(t1, t2));
    }

    @Test
    public void testArrayOfNestedArrayComponent() {
        Type outer = $Gson$Types.arrayOf($Gson$Types.arrayOf(int.class));
        assertTrue(outer instanceof GenericArrayType);
        Type outerComponent = ((GenericArrayType) outer).getGenericComponentType();
        assertTrue(outerComponent instanceof GenericArrayType);
        assertEquals(int.class, ((GenericArrayType) outerComponent).getGenericComponentType());
    }

    // ---------------------------------------------------------------
    // subtypeOf
    // ---------------------------------------------------------------

    @Test
    public void testSubtypeOfWithExplicitBound() {
        WildcardType w = $Gson$Types.subtypeOf(CharSequence.class);
        assertEquals(1, w.getUpperBounds().length);
        assertEquals(CharSequence.class, w.getUpperBounds()[0]);
        assertEquals(0, w.getLowerBounds().length);
    }

    @Test
    public void testSubtypeOfObjectBoundIsShorthandWildcard() {
        WildcardType w = $Gson$Types.subtypeOf(Object.class);
        assertEquals(1, w.getUpperBounds().length);
        assertEquals(Object.class, w.getUpperBounds()[0]);
        assertEquals(0, w.getLowerBounds().length);
    }

    @Test
    public void testSubtypeOfIsSerializable() {
        WildcardType w = $Gson$Types.subtypeOf(String.class);
        assertTrue(w instanceof Serializable);
    }

    // ---------------------------------------------------------------
    // supertypeOf
    // ---------------------------------------------------------------

    @Test
    public void testSupertypeOfBasic() {
        WildcardType w = $Gson$Types.supertypeOf(String.class);
        assertEquals(1, w.getLowerBounds().length);
        assertEquals(String.class, w.getLowerBounds()[0]);
        assertEquals(1, w.getUpperBounds().length);
        assertEquals(Object.class, w.getUpperBounds()[0]);
    }

    @Test
    public void testSupertypeOfIsSerializable() {
        WildcardType w = $Gson$Types.supertypeOf(String.class);
        assertTrue(w instanceof Serializable);
    }

    // ---------------------------------------------------------------
    // canonicalize
    // ---------------------------------------------------------------

    @Test
    public void testCanonicalizeOfClassIsFunctionallyEqual() {
        Type canonical = $Gson$Types.canonicalize(String.class);
        assertTrue($Gson$Types.equals(canonical, String.class));
    }

    @Test
    public void testCanonicalizeIsSerializable() {
        Type pt = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
        Type canonical = $Gson$Types.canonicalize(pt);
        assertTrue(canonical instanceof Serializable);
    }

    @Test
    public void testCanonicalizeOfParameterizedTypeIsFunctionallyEqual() {
        Type pt = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
        Type canonical = $Gson$Types.canonicalize(pt);
        assertTrue($Gson$Types.equals(pt, canonical));
    }

    // ---------------------------------------------------------------
    // equals (public)
    // ---------------------------------------------------------------

    @Test
    public void testEqualsSameClassIsTrue() {
        assertTrue($Gson$Types.equals(String.class, String.class));
    }

    @Test
    public void testEqualsDifferentClassesIsFalse() {
        assertFalse($Gson$Types.equals(String.class, Integer.class));
    }

    @Test
    public void testEqualsParameterizedTypesWithSameArgumentsIsTrue() {
        Type a = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
        Type b = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
        assertTrue($Gson$Types.equals(a, b));
    }

    @Test
    public void testEqualsParameterizedTypesWithDifferentArgumentsIsFalse() {
        Type a = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
        Type b = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, Integer.class);
        assertFalse($Gson$Types.equals(a, b));
    }

    // @Test  // pruned: failed on the fixed version
    public void testEqualsAcrossRealArrayAndGenericArrayTypeRepresentations() {
        assertTrue($Gson$Types.equals(String[].class, $Gson$Types.arrayOf(String.class)));
    }

    // ---------------------------------------------------------------
    // getRawType
    // ---------------------------------------------------------------

    @Test
    public void testGetRawTypeOfPlainClass() {
        assertEquals(String.class, $Gson$Types.getRawType(String.class));
    }

    @Test
    public void testGetRawTypeOfParameterizedType() {
        Type pt = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
        assertEquals(List.class, $Gson$Types.getRawType(pt));
    }

    @Test
    public void testGetRawTypeOfGenericArrayType() {
        Type gat = $Gson$Types.arrayOf(String.class);
        assertEquals(String[].class, $Gson$Types.getRawType(gat));
    }

    // ---------------------------------------------------------------
    // typeToString
    // ---------------------------------------------------------------

    @Test
    public void testTypeToStringMentionsClassSimpleName() {
        String s = $Gson$Types.typeToString(String.class);
        assertNotNull(s);
        assertTrue(s.indexOf("String") >= 0);
    }

    @Test
    public void testTypeToStringForPrimitive() {
        String s = $Gson$Types.typeToString(int.class);
        assertNotNull(s);
        assertTrue(s.indexOf("int") >= 0);
    }

    // ---------------------------------------------------------------
    // getArrayComponentType
    // ---------------------------------------------------------------

    @Test
    public void testGetArrayComponentTypeForRealArrayClass() {
        assertEquals(String.class, $Gson$Types.getArrayComponentType(String[].class));
    }

    @Test
    public void testGetArrayComponentTypeForGenericArrayType() {
        Type gat = $Gson$Types.arrayOf(String.class);
        assertEquals(String.class, $Gson$Types.getArrayComponentType(gat));
    }

    // @Test(expected = ClassCastException.class)  // pruned: failed on the fixed version
    public void testGetArrayComponentTypeThrowsForNonArrayType() {
        $Gson$Types.getArrayComponentType(String.class);
    }

    // ---------------------------------------------------------------
    // getCollectionElementType
    // ---------------------------------------------------------------

    @Test
    public void testGetCollectionElementTypeForParameterizedList() {
        Type context = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
        Type elementType = $Gson$Types.getCollectionElementType(context, List.class);
        assertEquals(String.class, elementType);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testGetCollectionElementTypeThrowsForNonCollectionType() {
        $Gson$Types.getCollectionElementType(String.class, String.class);
    }

    // ---------------------------------------------------------------
    // getMapKeyAndValueTypes
    // ---------------------------------------------------------------

    @Test
    public void testGetMapKeyAndValueTypesForParameterizedMap() {
        Type context = $Gson$Types.newParameterizedTypeWithOwner(null, Map.class, String.class, Integer.class);
        Type[] keyAndValue = $Gson$Types.getMapKeyAndValueTypes(context, Map.class);
        assertEquals(2, keyAndValue.length);
        assertEquals(String.class, keyAndValue[0]);
        assertEquals(Integer.class, keyAndValue[1]);
    }

    // ---------------------------------------------------------------
    // newParameterizedTypeWithOwner
    // ---------------------------------------------------------------

    @Test
    public void testNewParameterizedTypeWithOwnerWithoutOwner() {
        ParameterizedType pt = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
        assertNull(pt.getOwnerType());
        assertEquals(List.class, pt.getRawType());
        assertEquals(1, pt.getActualTypeArguments().length);
        assertEquals(String.class, pt.getActualTypeArguments()[0]);
    }

    @Test
    public void testNewParameterizedTypeWithOwnerWithOwnerAndMultipleArguments() {
        ParameterizedType pt = $Gson$Types.newParameterizedTypeWithOwner(
                Map.class, Map.Entry.class, String.class, Integer.class);
        assertEquals(Map.class, pt.getOwnerType());
        assertEquals(Map.Entry.class, pt.getRawType());
        assertEquals(2, pt.getActualTypeArguments().length);
        assertEquals(String.class, pt.getActualTypeArguments()[0]);
        assertEquals(Integer.class, pt.getActualTypeArguments()[1]);
    }

    @Test
    public void testNewParameterizedTypeWithOwnerIsSerializable() {
        ParameterizedType pt = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
        assertTrue(pt instanceof Serializable);
    }

    @Test
    public void testNewParameterizedTypeWithOwnerWithZeroTypeArguments() {
        ParameterizedType pt = $Gson$Types.newParameterizedTypeWithOwner(null, String.class);
        assertEquals(String.class, pt.getRawType());
        assertEquals(0, pt.getActualTypeArguments().length);
    }

    // ---------------------------------------------------------------
    // equal (package-private null-safe equality helper)
    // ---------------------------------------------------------------

    @Test
    public void testEqualBothNullIsTrue() {
        assertTrue($Gson$Types.equal(null, null));
    }

    @Test
    public void testEqualOneNullIsFalse() {
        assertFalse($Gson$Types.equal(null, "a"));
        assertFalse($Gson$Types.equal("a", null));
    }

    @Test
    public void testEqualEqualObjectsIsTrue() {
        assertTrue($Gson$Types.equal("a", "a"));
    }

    @Test
    public void testEqualDifferentObjectsIsFalse() {
        assertFalse($Gson$Types.equal("a", "b"));
    }

    // ---------------------------------------------------------------
    // hashCodeOrZero (package-private)
    // ---------------------------------------------------------------

    @Test
    public void testHashCodeOrZeroForNull() {
        assertEquals(0, $Gson$Types.hashCodeOrZero(null));
    }

    @Test
    public void testHashCodeOrZeroForNonNull() {
        assertEquals("abc".hashCode(), $Gson$Types.hashCodeOrZero("abc"));
    }

    // ---------------------------------------------------------------
    // checkNotPrimitive (package-private)
    // ---------------------------------------------------------------

    @Test
    public void testCheckNotPrimitiveAcceptsNonPrimitiveType() {
        $Gson$Types.checkNotPrimitive(String.class);
    }

    @Test(expected = RuntimeException.class)
    public void testCheckNotPrimitiveRejectsPrimitiveType() {
        $Gson$Types.checkNotPrimitive(int.class);
    }

    // ---------------------------------------------------------------
    // getGenericSupertype (package-private)
    // ---------------------------------------------------------------

    // @Test  // pruned: failed on the fixed version
    public void testGetGenericSupertypeForSetPerJavadocExample() {
        Type result = $Gson$Types.getGenericSupertype(IntegerSet.class, IntegerSet.class, Set.class);
        assertTrue(result instanceof ParameterizedType);
        ParameterizedType prt = (ParameterizedType) result;
        assertEquals(Set.class, prt.getRawType());
        assertEquals(1, prt.getActualTypeArguments().length);
        assertEquals(Integer.class, prt.getActualTypeArguments()[0]);
    }

    // @Test  // pruned: failed on the fixed version
    public void testGetGenericSupertypeForCollectionPerJavadocExample() {
        Type result = $Gson$Types.getGenericSupertype(IntegerSet.class, IntegerSet.class, Collection.class);
        assertTrue(result instanceof ParameterizedType);
        ParameterizedType prt = (ParameterizedType) result;
        assertEquals(Collection.class, prt.getRawType());
        assertEquals(1, prt.getActualTypeArguments().length);
        assertEquals(Integer.class, prt.getActualTypeArguments()[0]);
    }

    // ---------------------------------------------------------------
    // getSupertype (package-private)
    // ---------------------------------------------------------------

    @Test
    public void testGetSupertypeForArrayListPerJavadocExample() {
        Type context = $Gson$Types.newParameterizedTypeWithOwner(null, ArrayList.class, String.class);
        Type result = $Gson$Types.getSupertype(context, ArrayList.class, Iterable.class);
        assertTrue(result instanceof ParameterizedType);
        ParameterizedType prt = (ParameterizedType) result;
        assertEquals(Iterable.class, prt.getRawType());
        assertEquals(1, prt.getActualTypeArguments().length);
        assertEquals(String.class, prt.getActualTypeArguments()[0]);
    }

    // ---------------------------------------------------------------
    // resolve (public)
    // ---------------------------------------------------------------

    @Test
    public void testResolveOfTypeWithoutVariablesReturnsEquivalentType() {
        Type resolved = $Gson$Types.resolve(String.class, String.class, Integer.class);
        assertTrue($Gson$Types.equals(resolved, Integer.class));
    }

    @Test
    public void testResolveOfTypeVariableToActualArgument() {
        Type context = $Gson$Types.newParameterizedTypeWithOwner(null, Box.class, String.class);
        TypeVariable<?> tv = Box.class.getTypeParameters()[0];
        Type resolved = $Gson$Types.resolve(context, Box.class, tv);
        assertTrue($Gson$Types.equals(resolved, String.class));
    }

    // ---------------------------------------------------------------
    // resolveTypeVariable (package-private)
    // ---------------------------------------------------------------

    @Test
    public void testResolveTypeVariableToActualArgument() {
        Type context = $Gson$Types.newParameterizedTypeWithOwner(null, Box.class, String.class);
        TypeVariable<?> tv = Box.class.getTypeParameters()[0];
        Type resolved = $Gson$Types.resolveTypeVariable(context, Box.class, tv);
        assertTrue($Gson$Types.equals(resolved, String.class));
    }
}
