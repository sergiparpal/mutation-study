/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.cli2.commandline;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.apache.commons.cli2.Argument;
import org.apache.commons.cli2.CLITestCase;
import org.apache.commons.cli2.Group;
import org.apache.commons.cli2.Option;
import org.apache.commons.cli2.builder.ArgumentBuilder;
import org.apache.commons.cli2.builder.DefaultOptionBuilder;
import org.apache.commons.cli2.builder.GroupBuilder;
import org.apache.commons.cli2.option.PropertyOption;

/**
 * Exercises the public API of {@link WriteableCommandLineImpl}: option/value/
 * switch/property storage, default handling, the unmodifiable views it hands
 * out and its {@code toString()} / {@code getNormalised()} contract.
 */
public class WriteableCommandLineImplAgentTest extends CLITestCase {

    private Option root;
    private WriteableCommandLineImpl cl;

    public void setUp() throws Exception {
        super.setUp();
        root = new PropertyOption();
        cl = new WriteableCommandLineImpl(root, new ArrayList());
    }

    private static Option option(final String longName) {
        return new DefaultOptionBuilder().withLongName(longName).create();
    }

    public void testCurrentOptionDefaultsToConstructorRoot() {
        assertSame(root, cl.getCurrentOption());
    }

    public void testSetCurrentOptionRoundTrips() {
        final Option other = option("other");
        cl.setCurrentOption(other);
        assertSame(other, cl.getCurrentOption());

        cl.setCurrentOption(null);
        assertNull(cl.getCurrentOption());
    }

    public void testAddOptionMakesItPresentAndResolvableByTrigger() {
        final Option o =
            new DefaultOptionBuilder().withShortName("a").withLongName("alpha").create();

        assertFalse(cl.hasOption(o));
        cl.addOption(o);

        assertTrue(cl.hasOption(o));
        assertSame(o, cl.getOption("-a"));
        assertSame(o, cl.getOption("--alpha"));
        assertNull(cl.getOption("--unknown"));
    }

    public void testAddOptionAlsoRegistersParentChain() {
        final Option child = option("child");
        final Group parent =
            (Group) new GroupBuilder().withName("parent").withOption(child).create();

        cl.addOption(child);

        assertTrue(cl.hasOption(child));
        assertTrue("parent group should be registered automatically", cl.hasOption(parent));
        assertEquals(2, cl.getOptions().size());
    }

    public void testGetOptionsIsUnmodifiable() {
        cl.addOption(option("a"));

        final List options = cl.getOptions();
        assertEquals(1, options.size());

        try {
            options.add(option("b"));
            fail("expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
    }

    public void testGetOptionTriggersContainsEveryTriggerAndIsUnmodifiable() {
        cl.addOption(new DefaultOptionBuilder().withShortName("a").withLongName("alpha").create());

        final Set triggers = cl.getOptionTriggers();
        assertTrue(triggers.contains("-a"));
        assertTrue(triggers.contains("--alpha"));

        try {
            triggers.add("-z");
            fail("expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
    }

    public void testAddValueRecordsValuesButDoesNotAddPlainOption() {
        final Option o = option("v");
        assertTrue(cl.getValues(o).isEmpty());

        cl.addValue(o, "one");
        cl.addValue(o, "two");

        assertEquals(list("one", "two"), cl.getValues(o));
        assertEquals(list("one", "two"), cl.getUndefaultedValues(o));
        assertFalse("a plain option must not become present just by adding values",
                    cl.hasOption(o));
    }

    public void testAddValueForArgumentForcesOptionPresent() {
        final Argument arg = new ArgumentBuilder().withName("files").create();

        assertFalse(cl.hasOption(arg));
        cl.addValue(arg, "f1");

        assertTrue(cl.hasOption(arg));
        assertEquals(list("f1"), cl.getValues(arg));
    }

    public void testGetUndefaultedValuesIsEmptyListNotNullForUnknownOption() {
        final List values = cl.getUndefaultedValues(option("z"));
        assertNotNull(values);
        assertTrue(values.isEmpty());
    }

    public void testSetDefaultValuesShowUpInGetValuesOnlyAndCanBeCleared() {
        final Option o = option("d");

        cl.setDefaultValues(o, list("d1", "d2"));
        assertEquals(list("d1", "d2"), cl.getValues(o));
        assertTrue("defaults must not appear as undefaulted values",
                   cl.getUndefaultedValues(o).isEmpty());

        cl.setDefaultValues(o, null);
        assertTrue(cl.getValues(o).isEmpty());
    }

    public void testGetValuesAppendsTrailingDefaultsAfterRealValues() {
        final Option o = option("m");

        cl.setDefaultValues(o, list("d1", "d2"));
        cl.addValue(o, "a1");

        assertEquals(list("a1", "d2"), cl.getValues(o));
        assertEquals(list("a1"), cl.getUndefaultedValues(o));
    }

    public void testAddSwitchStoresStateAndMakesOptionPresent() {
        final Option o = option("s");
        assertNull(cl.getSwitch(o));

        cl.addSwitch(o, true);

        assertSame(Boolean.TRUE, cl.getSwitch(o));
        assertTrue(cl.hasOption(o));
    }

    public void testAddSwitchTwiceThrowsAndLeavesStateUnchanged() {
        final Option o = option("s");
        cl.addSwitch(o, true);

        try {
            cl.addSwitch(o, false);
            fail("expected IllegalStateException");
        } catch (IllegalStateException expected) {
            // expected
        }

        assertSame(Boolean.TRUE, cl.getSwitch(o));
    }

    public void testAddSwitchFalseStoresFalseNotNull() {
        final Option o = option("s");
        cl.addSwitch(o, false);
        assertSame(Boolean.FALSE, cl.getSwitch(o));
    }

    public void testSetDefaultSwitchAppliesOnlyWhenNoRealSwitchAndCanBeCleared() {
        final Option o = option("ds");
        assertNull(cl.getSwitch(o));

        cl.setDefaultSwitch(o, Boolean.TRUE);
        assertSame(Boolean.TRUE, cl.getSwitch(o));

        cl.setDefaultSwitch(o, null);
        assertNull(cl.getSwitch(o));
    }

    public void testGetSwitchPrecedence() {
        final Option o = option("p");

        cl.setDefaultSwitch(o, Boolean.FALSE);
        assertSame("option default is used when nothing else is set",
                   Boolean.FALSE, cl.getSwitch(o));
        assertSame("method default beats the option default",
                   Boolean.TRUE, cl.getSwitch(o, Boolean.TRUE));

        cl.addSwitch(o, true);
        assertSame("an explicit switch beats every default",
                   Boolean.TRUE, cl.getSwitch(o, Boolean.FALSE));
    }

    public void testAddPropertyForOptionStoresAndReplaces() {
        final Option d = new PropertyOption();

        assertNull(cl.getProperty(d, "k"));
        assertEquals("fallback", cl.getProperty(d, "k", "fallback"));

        cl.addProperty(d, "k", "v1");
        assertEquals("v1", cl.getProperty(d, "k"));
        assertEquals(1, cl.getProperties(d).size());

        cl.addProperty(d, "k", "v2");
        assertEquals("v2", cl.getProperty(d, "k"));
        assertEquals(1, cl.getProperties(d).size());
    }

    public void testGetPropertiesEmptyByDefaultAndUnmodifiableOncePopulated() {
        assertTrue(cl.getProperties(new PropertyOption()).isEmpty());

        final Option d = new PropertyOption();
        cl.addProperty(d, "k", "v");

        try {
            cl.getProperties(d).add("k2");
            fail("expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
    }

    public void testAddPropertyToDefaultPropertySet() {
        assertNull(cl.getProperty("host"));

        cl.addProperty("host", "localhost");

        assertEquals("localhost", cl.getProperty("host"));
        assertTrue(cl.getProperties().contains("host"));
        assertNull(cl.getProperty("missing"));
    }

    public void testToStringJoinsNormalisedArgumentsAndQuotesSpaces() {
        final WriteableCommandLineImpl c =
            new WriteableCommandLineImpl(root, list("--foo", "bar baz", "qux"));
        assertEquals("--foo \"bar baz\" qux", c.toString());
    }

    public void testToStringOfEmptyCommandLine() {
        assertEquals("", new WriteableCommandLineImpl(root, new ArrayList()).toString());
    }

    public void testGetNormalisedReflectsArgumentsAndIsUnmodifiable() {
        final List args = list("a", "b");
        final WriteableCommandLineImpl c = new WriteableCommandLineImpl(root, args);

        assertEquals(args, c.getNormalised());

        try {
            c.getNormalised().add("c");
            fail("expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
    }

    public void testLooksLikeOption() {
        final Option help =
            new DefaultOptionBuilder().withShortName("h").withLongName("help").create();
        final Group g = (Group) new GroupBuilder().withName("g").withOption(help).create();
        final WriteableCommandLineImpl c = new WriteableCommandLineImpl(g, new ArrayList());

        assertTrue(c.looksLikeOption("--help"));
        assertFalse("prefixed but unknown does not look like an option",
                    c.looksLikeOption("--nosuch"));
        assertFalse("an unprefixed token never looks like an option",
                    c.looksLikeOption("plainvalue"));
    }
}
