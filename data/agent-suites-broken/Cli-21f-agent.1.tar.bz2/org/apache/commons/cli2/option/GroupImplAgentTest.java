/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.cli2.option;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;

import org.apache.commons.cli2.CLITestCase;
import org.apache.commons.cli2.DisplaySetting;
import org.apache.commons.cli2.HelpLine;
import org.apache.commons.cli2.Option;
import org.apache.commons.cli2.OptionException;
import org.apache.commons.cli2.WriteableCommandLine;
import org.apache.commons.cli2.builder.ArgumentBuilder;
import org.apache.commons.cli2.builder.DefaultOptionBuilder;
import org.apache.commons.cli2.commandline.WriteableCommandLineImpl;

/**
 * Exercises the public API of {@link GroupImpl}: how the constructor splits
 * members from anonymous arguments, trigger/prefix exposure, the
 * {@code canProcess} / {@code process} / {@code validate} state machine, the
 * unmodifiable views it returns and its help rendering.
 */
public class GroupImplAgentTest extends CLITestCase {

    /** A required, expanded group of four sibling commands (min 1, max 1). */
    private static GroupImpl httpdGroup() {
        final List options = new ArrayList();
        options.add(new Command("graceful", "restart gracefully", null, false, null, null, 0));
        options.add(new Command("restart", "restart", null, false, null, null, 0));
        options.add(new Command("start", "start", null, false, null, null, 0));
        options.add(new Command("stop", "stop", null, false, null, null, 0));

        return new GroupImpl(options, "httpd", "the command to pass", 1, 1, true);
    }

    /** A group with one member option and one anonymous argument. */
    private static GroupImpl helpAndTargetGroup() {
        final List options = new ArrayList();
        options.add(new DefaultOptionBuilder().withShortName("h").withLongName("help").create());
        options.add(new ArgumentBuilder().withName("target").create());

        return new GroupImpl(options, "ant", "the options for ant", 0, Integer.MAX_VALUE, true);
    }

    private static WriteableCommandLine commandLine(final Option rootOption) {
        return new WriteableCommandLineImpl(rootOption, new ArrayList());
    }

    private static GroupImpl childGroupOf(final boolean required, final int minimum) {
        final GroupImpl child =
            new GroupImpl(new ArrayList(), "child", null, minimum, Integer.MAX_VALUE, required);
        final List parentOptions = new ArrayList();
        parentOptions.add(child);
        // constructing the parent group wires up child.getParent()
        new GroupImpl(parentOptions, "parent", null, 0, Integer.MAX_VALUE, false);

        return child;
    }

    public void testConstructorMovesArgumentsIntoAnonymousList() {
        final Option help =
            new DefaultOptionBuilder().withShortName("h").withLongName("help").create();
        final Option target = new ArgumentBuilder().withName("target").create();
        final List options = new ArrayList();
        options.add(help);
        options.add(target);

        final GroupImpl group = new GroupImpl(options, "g", "d", 0, Integer.MAX_VALUE, true);

        assertEquals(1, group.getOptions().size());
        assertSame(help, group.getOptions().get(0));
        assertEquals(1, group.getAnonymous().size());
        assertSame(target, group.getAnonymous().get(0));
    }

    public void testConstructorSetsItselfAsParentOfEveryMember() {
        final Option help =
            new DefaultOptionBuilder().withShortName("h").withLongName("help").create();
        final Option target = new ArgumentBuilder().withName("target").create();
        final List options = new ArrayList();
        options.add(help);
        options.add(target);

        final GroupImpl group = new GroupImpl(options, "g", "d", 0, Integer.MAX_VALUE, true);

        assertSame(group, help.getParent());
        assertSame(group, target.getParent());
    }

    public void testGetMinimumAndMaximum() {
        final GroupImpl group = new GroupImpl(new ArrayList(), "g", "d", 2, 5, true);
        assertEquals(2, group.getMinimum());
        assertEquals(5, group.getMaximum());
    }

    public void testGetPreferredNameAndDescription() {
        final GroupImpl named = new GroupImpl(new ArrayList(), "the-name", "the-desc", 0, 1, true);
        assertEquals("the-name", named.getPreferredName());
        assertEquals("the-desc", named.getDescription());

        final GroupImpl anon = new GroupImpl(new ArrayList(), null, null, 0, 1, true);
        assertNull(anon.getPreferredName());
        assertNull(anon.getDescription());
    }

    public void testGetTriggersAndPrefixesComeFromMemberOptions() {
        final GroupImpl group = helpAndTargetGroup();
        assertContentsEqual(list("-h", "--help"), group.getTriggers());
        assertContentsEqual(list("-", "--"), group.getPrefixes());
    }

    public void testArgumentOnlyGroupExposesNoTriggersOrPrefixes() {
        final List options = new ArrayList();
        options.add(new ArgumentBuilder().withName("t").create());

        final GroupImpl group = new GroupImpl(options, "g", "d", 0, 1, true);

        assertTrue(group.getTriggers().isEmpty());
        assertTrue(group.getPrefixes().isEmpty());
        assertEquals(1, group.getAnonymous().size());
    }

    public void testCanProcessNullArgumentReturnsFalse() {
        final GroupImpl group = httpdGroup();
        assertFalse(group.canProcess(commandLine(group), (String) null));
    }

    public void testCanProcessKnownTrigger() {
        final GroupImpl group = httpdGroup();
        assertTrue(group.canProcess(commandLine(group), "start"));
        assertTrue(group.canProcess(commandLine(group), "graceful"));
    }

    public void testCanProcessUnknownArgumentWithoutAnonymousReturnsFalse() {
        final GroupImpl group = httpdGroup();
        assertFalse(group.canProcess(commandLine(group), "bogus"));
    }

    public void testCanProcessArbitraryValueWhenGroupHasAnonymousArgument() {
        final GroupImpl group = helpAndTargetGroup();
        assertTrue(group.canProcess(commandLine(group), "somevalue"));
    }

    public void testCanProcessRejectsUnknownOptionLookAlike() {
        final GroupImpl group = helpAndTargetGroup();
        assertFalse(group.canProcess(commandLine(group), "--unknown"));
    }

    public void testProcessConsumesMemberOptionAndAnonymousValues()
        throws OptionException {
        final GroupImpl group = helpAndTargetGroup();
        final List args = list("--help", "t1", "t2");
        final WriteableCommandLine cl = new WriteableCommandLineImpl(group, args);
        final ListIterator i = args.listIterator();

        group.process(cl, i);

        assertFalse(i.hasNext());
        assertTrue(cl.hasOption("--help"));
        assertListContentsEqual(list("t1", "t2"), cl.getValues("target"));
    }

    public void testProcessSplitsContractedAnonymousValues()
        throws OptionException {
        final List options = new ArrayList();
        options.add(new DefaultOptionBuilder().withShortName("h").withLongName("help").create());
        options.add(new ArgumentBuilder().withName("target").withSubsequentSeparator(',').create());

        final GroupImpl group = new GroupImpl(options, "ant", "d", 0, Integer.MAX_VALUE, true);
        final List args = list("compile,test", "dist");
        final WriteableCommandLine cl = new WriteableCommandLineImpl(group, args);

        group.process(cl, args.listIterator());

        assertListContentsEqual(list("compile", "test", "dist"), cl.getValues("target"));
    }

    public void testProcessLeavesUnrecognisedArgumentUnconsumed()
        throws OptionException {
        final GroupImpl group = httpdGroup();
        final List args = list("bogus");
        final WriteableCommandLine cl = new WriteableCommandLineImpl(group, args);
        final ListIterator i = args.listIterator();

        group.process(cl, i);

        assertTrue(i.hasNext());
        assertEquals("bogus", i.next());
        assertTrue(cl.getOptions().isEmpty());
    }

    public void testValidateAcceptsCommandLineWithinBounds()
        throws OptionException {
        final GroupImpl group = helpAndTargetGroup();
        final WriteableCommandLine cl = commandLine(group);

        // optional group, optional argument -> nothing is required
        group.validate(cl);

        assertTrue(cl.getOptions().isEmpty());
    }

    public void testValidateRejectsCommandLineBelowMinimum() {
        final GroupImpl group = httpdGroup();
        final WriteableCommandLine cl = commandLine(group);

        try {
            group.validate(cl);
            fail("expected OptionException for a missing option");
        } catch (OptionException e) {
            assertSame(group, e.getOption());
        }
    }

    public void testValidateRejectsCommandLineAboveMaximum() {
        final GroupImpl group = httpdGroup();
        final WriteableCommandLine cl = commandLine(group);
        cl.addOption((Option) group.getOptions().get(1));
        cl.addOption((Option) group.getOptions().get(2));

        try {
            group.validate(cl);
            fail("expected OptionException for too many options");
        } catch (OptionException e) {
            assertSame(group, e.getOption());
        }
    }

    public void testValidatePropagatesAnonymousArgumentFailure() {
        final List options = new ArrayList();
        final Option username =
            new ArgumentBuilder().withName("username").withMinimum(1).withMaximum(1).create();
        options.add(username);

        final GroupImpl group = new GroupImpl(options, "creds", "d", 0, Integer.MAX_VALUE, true);
        final WriteableCommandLine cl = commandLine(group);

        try {
            group.validate(cl);
            fail("expected OptionException for a missing argument value");
        } catch (OptionException e) {
            assertSame(username, e.getOption());
        }
    }

    public void testGetOptionsIsUnmodifiable() {
        final GroupImpl group = httpdGroup();

        try {
            group.getOptions().add(new Command("x", "d", null, false, null, null, 0));
            fail("expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
    }

    public void testGetAnonymousIsUnmodifiable() {
        final GroupImpl group = helpAndTargetGroup();
        assertEquals(1, group.getAnonymous().size());

        try {
            group.getAnonymous().clear();
            fail("expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
    }

    public void testFindOptionMatchesMemberByAnyTrigger() {
        final GroupImpl group = helpAndTargetGroup();
        final Option help = (Option) group.getOptions().get(0);

        assertSame(help, group.findOption("--help"));
        assertSame(help, group.findOption("-h"));
        assertNull(group.findOption("--nosuch"));
    }

    public void testFindOptionIgnoresAnonymousArguments() {
        final GroupImpl group = helpAndTargetGroup();
        assertNull(group.findOption("target"));
    }

    public void testIsRequiredForRootGroupDependsOnMinimum() {
        assertFalse(new GroupImpl(new ArrayList(), "g", "d", 0, 1, true).isRequired());
        assertTrue(new GroupImpl(new ArrayList(), "g", "d", 1, 1, true).isRequired());
    }

    public void testIsRequiredForChildGroupDependsOnFlagAndMinimum() {
        assertFalse("flag not set -> not required", childGroupOf(false, 5).isRequired());
        assertTrue("flag set and minimum > 0 -> required", childGroupOf(true, 5).isRequired());
        assertFalse("flag set but minimum 0 -> not required", childGroupOf(true, 0).isRequired());
    }

    public void testGetParentIsSetByTheEnclosingGroup() {
        final GroupImpl child = new GroupImpl(new ArrayList(), "c", null, 0, 1, true);
        assertNull(child.getParent());

        final List parentOptions = new ArrayList();
        parentOptions.add(child);
        final GroupImpl parent = new GroupImpl(parentOptions, "p", null, 0, 1, true);

        assertSame(parent, child.getParent());
    }

    public void testAppendUsageExpandsMembersWithDefaultSeparator() {
        final GroupImpl group = httpdGroup();
        final StringBuffer buffer = new StringBuffer();

        group.appendUsage(buffer, DisplaySetting.ALL, null);

        assertEquals("httpd (graceful|restart|start|stop)", buffer.toString());
    }

    public void testAppendUsageHonoursCustomSeparator() {
        final GroupImpl group = httpdGroup();
        final StringBuffer buffer = new StringBuffer();

        group.appendUsage(buffer, DisplaySetting.ALL, null, " ! ");

        assertEquals("httpd (graceful ! restart ! start ! stop)", buffer.toString());
    }

    public void testAppendUsageWithoutGroupNameSetting() {
        final GroupImpl group = httpdGroup();
        final StringBuffer buffer = new StringBuffer();
        final Set settings = new HashSet(DisplaySetting.ALL);
        settings.remove(DisplaySetting.DISPLAY_GROUP_NAME);

        group.appendUsage(buffer, settings, null);

        assertEquals("graceful|restart|start|stop", buffer.toString());
    }

    public void testHelpLinesExpandedListsGroupThenMembers() {
        final GroupImpl group = httpdGroup();
        final List lines = group.helpLines(0, DisplaySetting.ALL, null);

        assertEquals(5, lines.size());

        final HelpLine first = (HelpLine) lines.get(0);
        assertEquals(0, first.getIndent());
        assertSame(group, first.getOption());

        final HelpLine second = (HelpLine) lines.get(1);
        assertEquals(1, second.getIndent());
    }

    public void testHelpLinesEmptyWithoutDisplaySettings() {
        final GroupImpl group = httpdGroup();
        assertTrue(group.helpLines(0, DisplaySetting.NONE, null).isEmpty());
    }

    public void testDefaultsPopulatesAnonymousArgumentDefaultValues() {
        final List options = new ArrayList();
        final Option size =
            new ArgumentBuilder().withName("size").withMinimum(1).withMaximum(1)
                                 .withDefault("10").create();
        options.add(size);

        final GroupImpl group = new GroupImpl(options, "g", "d", 0, Integer.MAX_VALUE, true);
        final WriteableCommandLine cl = commandLine(group);

        assertTrue(cl.getValues(size).isEmpty());

        group.defaults(cl);

        assertEquals(list("10"), cl.getValues(size));
        assertTrue(cl.getUndefaultedValues(size).isEmpty());
    }
}
