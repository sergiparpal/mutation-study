/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.cli2;

import java.util.ArrayList;

import org.apache.commons.cli2.builder.DefaultOptionBuilder;
import org.apache.commons.cli2.builder.GroupBuilder;
import org.apache.commons.cli2.commandline.WriteableCommandLineImpl;
import org.apache.commons.cli2.option.PropertyOption;

/**
 * Verifies the {@link WriteableCommandLine} contract through its production
 * implementation: every write method must be observable through the read side
 * of {@link CommandLine}, defaults must only be used as a fall back and the
 * documented error conditions must be signalled.
 */
public class WriteableCommandLineAgentTest extends CLITestCase {

    private Option root;
    private WriteableCommandLine writeable;

    public void setUp() throws Exception {
        super.setUp();
        root = new PropertyOption();
        writeable = new WriteableCommandLineImpl(root, new ArrayList());
    }

    private static Option option(final String longName) {
        return new DefaultOptionBuilder().withLongName(longName).create();
    }

    public void testGetCurrentOptionIsTheConstructorRoot() {
        assertSame(root, writeable.getCurrentOption());
    }

    public void testSetCurrentOptionTracksTheSuppliedOption() {
        final Option other = option("other");
        writeable.setCurrentOption(other);
        assertSame(other, writeable.getCurrentOption());

        writeable.setCurrentOption(null);
        assertNull(writeable.getCurrentOption());
    }

    public void testAddOptionIsObservableThroughHasOption() {
        final Option o = option("verbose");

        assertFalse(writeable.hasOption(o));
        writeable.addOption(o);

        assertTrue(writeable.hasOption(o));
        assertTrue(writeable.hasOption("--verbose"));
    }

    public void testAddValueIsObservableThroughGetValues() {
        final Option o = option("file");

        writeable.addValue(o, "a.txt");
        writeable.addValue(o, "b.txt");

        assertEquals(list("a.txt", "b.txt"), writeable.getValues(o));
    }

    public void testGetUndefaultedValuesNeverNullAndExcludesDefaults() {
        final Option o = option("x");

        assertNotNull(writeable.getUndefaultedValues(o));
        assertTrue(writeable.getUndefaultedValues(o).isEmpty());

        writeable.setDefaultValues(o, list("d"));
        assertTrue("default values must not leak into the undefaulted values",
                   writeable.getUndefaultedValues(o).isEmpty());

        writeable.addValue(o, "real");
        assertEquals(list("real"), writeable.getUndefaultedValues(o));
    }

    public void testSetDefaultValuesUsedOnlyWhenNoRealValuesAndRemovable() {
        final Option o = option("y");

        writeable.setDefaultValues(o, list("d1"));
        assertEquals(list("d1"), writeable.getValues(o));

        writeable.setDefaultValues(o, null);
        assertTrue(writeable.getValues(o).isEmpty());
    }

    public void testAddSwitchStoresBooleanStateAndMarksOptionPresent() {
        final Option o = option("flag");

        writeable.addSwitch(o, true);

        assertEquals(Boolean.TRUE, writeable.getSwitch(o));
        assertTrue(writeable.hasOption(o));
    }

    public void testAddSwitchFalseIsDistinctFromUnset() {
        final Option o = option("flag");

        assertNull(writeable.getSwitch(o));
        writeable.addSwitch(o, false);
        assertEquals(Boolean.FALSE, writeable.getSwitch(o));
    }

    public void testAddSwitchTwiceThrowsIllegalStateException() {
        final Option o = option("flag");
        writeable.addSwitch(o, true);

        try {
            writeable.addSwitch(o, false);
            fail("expected IllegalStateException");
        } catch (IllegalStateException expected) {
            // expected
        }

        assertEquals(Boolean.TRUE, writeable.getSwitch(o));
    }

    public void testSetDefaultSwitchAppliesWhenNoRealSwitchAndRemovable() {
        final Option o = option("dsw");

        assertNull(writeable.getSwitch(o));

        writeable.setDefaultSwitch(o, Boolean.TRUE);
        assertEquals(Boolean.TRUE, writeable.getSwitch(o));

        writeable.setDefaultSwitch(o, null);
        assertNull(writeable.getSwitch(o));
    }

    public void testRealSwitchOverridesDefaultSwitch() {
        final Option o = option("dsw");

        writeable.setDefaultSwitch(o, Boolean.FALSE);
        writeable.addSwitch(o, true);

        assertEquals(Boolean.TRUE, writeable.getSwitch(o));
    }

    public void testAddPropertyForOptionStoresAndReplacesValue() {
        final Option d = new PropertyOption();

        assertNull(writeable.getProperty(d, "k"));

        writeable.addProperty(d, "k", "v1");
        assertEquals("v1", writeable.getProperty(d, "k"));

        writeable.addProperty(d, "k", "v2");
        assertEquals("v2", writeable.getProperty(d, "k"));
    }

    public void testAddPropertyToDefaultPropertySet() {
        writeable.addProperty("name", "value");

        assertEquals("value", writeable.getProperty("name"));
        assertTrue(writeable.getProperties().contains("name"));
    }

    public void testLooksLikeOptionDistinguishesKnownTriggers() {
        final Option help =
            new DefaultOptionBuilder().withShortName("h").withLongName("help").create();
        final Group grp = (Group) new GroupBuilder().withName("main").withOption(help).create();
        final WriteableCommandLine wcl = new WriteableCommandLineImpl(grp, new ArrayList());

        assertTrue(wcl.looksLikeOption("--help"));
        assertFalse(wcl.looksLikeOption("--bogus"));
        assertFalse(wcl.looksLikeOption("filename"));
    }
}
