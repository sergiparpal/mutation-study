/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.NoSuchElementException;

import junit.framework.TestCase;

public class DateUtilsAgentTest extends TestCase {

    private static Calendar newCalendar(int year, int month, int day, int hour, int minute, int second, int millis) {
        Calendar cal = Calendar.getInstance();
        cal.set(year, month, day, hour, minute, second);
        cal.set(Calendar.MILLISECOND, millis);
        return cal;
    }

    private static Date newDate(int year, int month, int day, int hour, int minute, int second, int millis) {
        return newCalendar(year, month, day, hour, minute, second, millis).getTime();
    }

    //-----------------------------------------------------------------------
    // isSameDay
    //-----------------------------------------------------------------------

    public void testIsSameDayDate() {
        Date d1 = newDate(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        Date d2 = newDate(2002, Calendar.MARCH, 28, 6, 1, 0, 0);
        Date d3 = newDate(2002, Calendar.MARCH, 12, 13, 45, 0, 0);
        assertTrue(DateUtils.isSameDay(d1, d2));
        assertFalse(DateUtils.isSameDay(d1, d3));
    }

    public void testIsSameDayDateNull() {
        Date d = new Date();
        try {
            DateUtils.isSameDay((Date) null, d);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
        try {
            DateUtils.isSameDay(d, (Date) null);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testIsSameDayCalendar() {
        Calendar c1 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        Calendar c2 = newCalendar(2002, Calendar.MARCH, 28, 6, 1, 0, 0);
        Calendar c3 = newCalendar(2002, Calendar.MARCH, 12, 13, 45, 0, 0);
        assertTrue(DateUtils.isSameDay(c1, c2));
        assertFalse(DateUtils.isSameDay(c1, c3));
    }

    public void testIsSameDayCalendarNull() {
        Calendar c = Calendar.getInstance();
        try {
            DateUtils.isSameDay((Calendar) null, c);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // isSameInstant
    //-----------------------------------------------------------------------

    public void testIsSameInstantDate() {
        Date d1 = new Date(1000L);
        Date d2 = new Date(1000L);
        Date d3 = new Date(2000L);
        assertTrue(DateUtils.isSameInstant(d1, d2));
        assertFalse(DateUtils.isSameInstant(d1, d3));
    }

    public void testIsSameInstantDateNull() {
        try {
            DateUtils.isSameInstant((Date) null, new Date());
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testIsSameInstantCalendar() {
        Calendar c1 = Calendar.getInstance();
        c1.setTimeInMillis(1000L);
        Calendar c2 = Calendar.getInstance();
        c2.setTimeInMillis(1000L);
        Calendar c3 = Calendar.getInstance();
        c3.setTimeInMillis(2000L);
        assertTrue(DateUtils.isSameInstant(c1, c2));
        assertFalse(DateUtils.isSameInstant(c1, c3));
    }

    public void testIsSameInstantCalendarNull() {
        try {
            DateUtils.isSameInstant((Calendar) null, Calendar.getInstance());
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // isSameLocalTime
    //-----------------------------------------------------------------------

    public void testIsSameLocalTime() {
        Calendar c1 = newCalendar(2008, Calendar.JANUARY, 1, 10, 30, 15, 0);
        Calendar c2 = (Calendar) c1.clone();
        assertTrue(DateUtils.isSameLocalTime(c1, c2));
        Calendar c3 = newCalendar(2008, Calendar.JANUARY, 1, 10, 30, 16, 0);
        assertFalse(DateUtils.isSameLocalTime(c1, c3));
    }

    public void testIsSameLocalTimeNull() {
        try {
            DateUtils.isSameLocalTime(null, Calendar.getInstance());
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // parseDate / parseDateStrictly
    //-----------------------------------------------------------------------

    public void testParseDateSuccess() throws Exception {
        Date d = DateUtils.parseDate("2008-01-02", new String[] { "yyyy-MM-dd" });
        Calendar cal = DateUtils.toCalendar(d);
        assertEquals(2008, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));
        assertEquals(2, cal.get(Calendar.DAY_OF_MONTH));
    }

    public void testParseDateTriesEachPattern() throws Exception {
        Date d = DateUtils.parseDate("02/01/2008", new String[] { "yyyy-MM-dd", "MM/dd/yyyy" });
        Calendar cal = DateUtils.toCalendar(d);
        assertEquals(2008, cal.get(Calendar.YEAR));
        assertEquals(Calendar.FEBRUARY, cal.get(Calendar.MONTH));
        assertEquals(1, cal.get(Calendar.DAY_OF_MONTH));
    }

    public void testParseDateNoMatchThrowsParseException() {
        try {
            DateUtils.parseDate("not a date", new String[] { "yyyy-MM-dd" });
            fail("expected ParseException");
        } catch (ParseException e) {
            // expected
        }
    }

    public void testParseDateNullArgs() {
        try {
            DateUtils.parseDate(null, new String[] { "yyyy-MM-dd" });
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        } catch (ParseException e) {
            fail("expected IllegalArgumentException, not ParseException");
        }
        try {
            DateUtils.parseDate("2008-01-02", (String[]) null);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        } catch (ParseException e) {
            fail("expected IllegalArgumentException, not ParseException");
        }
    }

    public void testParseDateLenientAllowsOverflow() throws Exception {
        // lenient parsing rolls Feb 30 over into March 1
        Date d = DateUtils.parseDate("02/30/2008", new String[] { "MM/dd/yyyy" });
        Calendar cal = DateUtils.toCalendar(d);
        assertEquals(Calendar.MARCH, cal.get(Calendar.MONTH));
        assertEquals(1, cal.get(Calendar.DAY_OF_MONTH));
    }

    public void testParseDateStrictlyRejectsOverflow() {
        try {
            DateUtils.parseDateStrictly("02/30/2008", new String[] { "MM/dd/yyyy" });
            fail("expected ParseException");
        } catch (ParseException e) {
            // expected
        }
    }

    public void testParseDateStrictlySuccess() throws Exception {
        Date d = DateUtils.parseDateStrictly("2008-02-15", new String[] { "yyyy-MM-dd" });
        Calendar cal = DateUtils.toCalendar(d);
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
    }

    //-----------------------------------------------------------------------
    // add*
    //-----------------------------------------------------------------------

    public void testAddYears() {
        Date base = newDate(2000, Calendar.JANUARY, 1, 0, 0, 0, 0);
        Date result = DateUtils.addYears(base, 2);
        assertEquals(2002, DateUtils.toCalendar(result).get(Calendar.YEAR));
        // original unchanged
        assertEquals(2000, DateUtils.toCalendar(base).get(Calendar.YEAR));
        Date back = DateUtils.addYears(base, -1);
        assertEquals(1999, DateUtils.toCalendar(back).get(Calendar.YEAR));
    }

    public void testAddMonths() {
        Date base = newDate(2000, Calendar.JANUARY, 1, 0, 0, 0, 0);
        Date result = DateUtils.addMonths(base, 13);
        Calendar cal = DateUtils.toCalendar(result);
        assertEquals(2001, cal.get(Calendar.YEAR));
        assertEquals(Calendar.FEBRUARY, cal.get(Calendar.MONTH));
    }

    public void testAddWeeks() {
        Date base = newDate(2000, Calendar.JANUARY, 1, 0, 0, 0, 0);
        Date result = DateUtils.addWeeks(base, 1);
        assertEquals(base.getTime() + 7L * DateUtils.MILLIS_PER_DAY, result.getTime());
    }

    public void testAddDays() {
        Date base = newDate(2000, Calendar.JANUARY, 1, 0, 0, 0, 0);
        Date result = DateUtils.addDays(base, -1);
        assertEquals(1999, DateUtils.toCalendar(result).get(Calendar.YEAR));
        assertEquals(Calendar.DECEMBER, DateUtils.toCalendar(result).get(Calendar.MONTH));
        assertEquals(31, DateUtils.toCalendar(result).get(Calendar.DAY_OF_MONTH));
    }

    public void testAddHoursMinutesSecondsMilliseconds() {
        Date base = new Date(0L);
        assertEquals(DateUtils.MILLIS_PER_HOUR, DateUtils.addHours(base, 1).getTime());
        assertEquals(DateUtils.MILLIS_PER_MINUTE, DateUtils.addMinutes(base, 1).getTime());
        assertEquals(DateUtils.MILLIS_PER_SECOND, DateUtils.addSeconds(base, 1).getTime());
        assertEquals(5L, DateUtils.addMilliseconds(base, 5).getTime());
    }

    public void testAddMethodsNullDate() {
        try {
            DateUtils.addYears(null, 1);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
        try {
            DateUtils.addDays(null, 1);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // set*
    //-----------------------------------------------------------------------

    public void testSetYearsMonthsDays() {
        Date base = newDate(2000, Calendar.MARCH, 15, 10, 20, 30, 0);
        Calendar result = DateUtils.toCalendar(DateUtils.setYears(base, 2010));
        assertEquals(2010, result.get(Calendar.YEAR));

        Calendar monthResult = DateUtils.toCalendar(DateUtils.setMonths(base, Calendar.JUNE));
        assertEquals(Calendar.JUNE, monthResult.get(Calendar.MONTH));

        Calendar dayResult = DateUtils.toCalendar(DateUtils.setDays(base, 20));
        assertEquals(20, dayResult.get(Calendar.DAY_OF_MONTH));
    }

    public void testSetHoursMinutesSecondsMilliseconds() {
        Date base = newDate(2000, Calendar.MARCH, 15, 10, 20, 30, 40);
        assertEquals(5, DateUtils.toCalendar(DateUtils.setHours(base, 5)).get(Calendar.HOUR_OF_DAY));
        assertEquals(6, DateUtils.toCalendar(DateUtils.setMinutes(base, 6)).get(Calendar.MINUTE));
        assertEquals(7, DateUtils.toCalendar(DateUtils.setSeconds(base, 7)).get(Calendar.SECOND));
        assertEquals(8, DateUtils.toCalendar(DateUtils.setMilliseconds(base, 8)).get(Calendar.MILLISECOND));
    }

    public void testSetDaysInvalidThrowsIllegalArgumentException() {
        // February never has 31 days: setDays uses a non-lenient Calendar
        Date feb = newDate(2008, Calendar.FEBRUARY, 1, 0, 0, 0, 0);
        try {
            DateUtils.setDays(feb, 31);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testSetMethodsNullDate() {
        try {
            DateUtils.setYears(null, 2000);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // toCalendar
    //-----------------------------------------------------------------------

    public void testToCalendar() {
        Date d = new Date(123456789L);
        Calendar cal = DateUtils.toCalendar(d);
        assertEquals(d.getTime(), cal.getTime().getTime());
    }

    public void testToCalendarNull() {
        try {
            DateUtils.toCalendar(null);
            fail("expected NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // round
    //-----------------------------------------------------------------------

    public void testRoundDateHour() {
        Date d = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date rounded = DateUtils.round(d, Calendar.HOUR_OF_DAY);
        Calendar cal = DateUtils.toCalendar(rounded);
        assertEquals(14, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, cal.get(Calendar.MINUTE));
        assertEquals(0, cal.get(Calendar.SECOND));
        assertEquals(0, cal.get(Calendar.MILLISECOND));
    }

    public void testRoundDateMonth() {
        Date d = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date rounded = DateUtils.round(d, Calendar.MONTH);
        Calendar cal = DateUtils.toCalendar(rounded);
        assertEquals(Calendar.APRIL, cal.get(Calendar.MONTH));
        assertEquals(1, cal.get(Calendar.DAY_OF_MONTH));
    }

    public void testRoundCalendarReturnsNewObject() {
        Calendar original = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar rounded = DateUtils.round(original, Calendar.HOUR_OF_DAY);
        assertNotSame(original, rounded);
        // original must be unchanged
        assertEquals(13, original.get(Calendar.HOUR_OF_DAY));
        assertEquals(45, original.get(Calendar.MINUTE));
        assertEquals(14, rounded.get(Calendar.HOUR_OF_DAY));
    }

    public void testRoundObjectDispatchesToDateAndCalendar() {
        Date d = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar c = DateUtils.toCalendar(d);
        Date fromDate = DateUtils.round((Object) d, Calendar.HOUR_OF_DAY);
        Date fromCalendar = DateUtils.round((Object) c, Calendar.HOUR_OF_DAY);
        assertEquals(fromDate.getTime(), fromCalendar.getTime());
    }

    public void testRoundObjectInvalidTypeThrowsClassCastException() {
        try {
            DateUtils.round("not a date", Calendar.HOUR_OF_DAY);
            fail("expected ClassCastException");
        } catch (ClassCastException e) {
            // expected
        }
    }

    public void testRoundNullThrowsIllegalArgumentException() {
        try {
            DateUtils.round((Date) null, Calendar.HOUR_OF_DAY);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
        try {
            DateUtils.round((Calendar) null, Calendar.HOUR_OF_DAY);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
        try {
            DateUtils.round((Object) null, Calendar.HOUR_OF_DAY);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testRoundSemiMonth() {
        // day 1 at midnight: no sub-day remainder, so no round up expected
        Date day1 = newDate(2002, Calendar.MARCH, 1, 0, 0, 0, 0);
        Calendar roundedDay1 = DateUtils.toCalendar(DateUtils.round(day1, DateUtils.SEMI_MONTH));
        assertEquals(1, roundedDay1.get(Calendar.DAY_OF_MONTH));

        // day 20 is less than half-way into the second half (offset 4 of 15), rounds down to 16
        Date day20 = newDate(2002, Calendar.MARCH, 20, 0, 0, 0, 0);
        Calendar roundedDay20 = DateUtils.toCalendar(DateUtils.round(day20, DateUtils.SEMI_MONTH));
        assertEquals(Calendar.MARCH, roundedDay20.get(Calendar.MONTH));
        assertEquals(16, roundedDay20.get(Calendar.DAY_OF_MONTH));
    }

    public void testRoundAmPm() {
        Date tenAm = newDate(2002, Calendar.MARCH, 28, 10, 0, 0, 0);
        Calendar rounded = DateUtils.toCalendar(DateUtils.round(tenAm, Calendar.AM_PM));
        assertEquals(Calendar.MARCH, rounded.get(Calendar.MONTH));
        assertEquals(28, rounded.get(Calendar.DAY_OF_MONTH));
        assertEquals(12, rounded.get(Calendar.HOUR_OF_DAY));
    }

    public void testRoundArithmeticExceptionForHugeYear() {
        Calendar huge = Calendar.getInstance();
        huge.set(Calendar.YEAR, 280000001);
        try {
            DateUtils.round(huge.getTime(), Calendar.HOUR_OF_DAY);
            fail("expected ArithmeticException");
        } catch (ArithmeticException e) {
            // expected
        }
    }

    public void testRoundUnsupportedFieldThrowsIllegalArgumentException() {
        Date d = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        try {
            DateUtils.round(d, Calendar.DAY_OF_WEEK);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // truncate
    //-----------------------------------------------------------------------

    public void testTruncateDateHour() {
        Date d = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar truncated = DateUtils.toCalendar(DateUtils.truncate(d, Calendar.HOUR_OF_DAY));
        assertEquals(13, truncated.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, truncated.get(Calendar.MINUTE));
        assertEquals(0, truncated.get(Calendar.SECOND));
        assertEquals(0, truncated.get(Calendar.MILLISECOND));
    }

    public void testTruncateDateMonth() {
        Date d = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar truncated = DateUtils.toCalendar(DateUtils.truncate(d, Calendar.MONTH));
        assertEquals(Calendar.MARCH, truncated.get(Calendar.MONTH));
        assertEquals(1, truncated.get(Calendar.DAY_OF_MONTH));
        assertEquals(0, truncated.get(Calendar.HOUR_OF_DAY));
    }

    public void testTruncateCalendarReturnsNewObject() {
        Calendar original = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar truncated = DateUtils.truncate(original, Calendar.HOUR_OF_DAY);
        assertNotSame(original, truncated);
        assertEquals(45, original.get(Calendar.MINUTE));
        assertEquals(0, truncated.get(Calendar.MINUTE));
    }

    public void testTruncateObjectDispatch() {
        Date d = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar c = DateUtils.toCalendar(d);
        Date fromDate = DateUtils.truncate((Object) d, Calendar.HOUR_OF_DAY);
        Date fromCalendar = DateUtils.truncate((Object) c, Calendar.HOUR_OF_DAY);
        assertEquals(fromDate.getTime(), fromCalendar.getTime());
    }

    public void testTruncateObjectInvalidTypeThrowsClassCastException() {
        try {
            DateUtils.truncate(Integer.valueOf(1), Calendar.HOUR_OF_DAY);
            fail("expected ClassCastException");
        } catch (ClassCastException e) {
            // expected
        }
    }

    public void testTruncateNullThrowsIllegalArgumentException() {
        try {
            DateUtils.truncate((Date) null, Calendar.HOUR_OF_DAY);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // ceiling
    //-----------------------------------------------------------------------

    public void testCeilingDateHour() {
        Date d = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar ceiled = DateUtils.toCalendar(DateUtils.ceiling(d, Calendar.HOUR_OF_DAY));
        assertEquals(14, ceiled.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, ceiled.get(Calendar.MINUTE));
    }

    public void testCeilingDateExactBoundaryStillAdvances() {
        // the ceiling of a value that is exactly on the boundary still moves to the next unit
        Date onHour = newDate(2002, Calendar.MARCH, 28, 13, 0, 0, 0);
        Calendar ceiled = DateUtils.toCalendar(DateUtils.ceiling(onHour, Calendar.HOUR_OF_DAY));
        assertEquals(14, ceiled.get(Calendar.HOUR_OF_DAY));
    }

    public void testCeilingCalendarReturnsNewObject() {
        Calendar original = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar ceiled = DateUtils.ceiling(original, Calendar.HOUR_OF_DAY);
        assertNotSame(original, ceiled);
        assertEquals(13, original.get(Calendar.HOUR_OF_DAY));
        assertEquals(14, ceiled.get(Calendar.HOUR_OF_DAY));
    }

    public void testCeilingObjectDispatch() {
        Date d = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar c = DateUtils.toCalendar(d);
        Date fromDate = DateUtils.ceiling((Object) d, Calendar.HOUR_OF_DAY);
        Date fromCalendar = DateUtils.ceiling((Object) c, Calendar.HOUR_OF_DAY);
        assertEquals(fromDate.getTime(), fromCalendar.getTime());
    }

    public void testCeilingObjectInvalidTypeThrowsClassCastException() {
        try {
            DateUtils.ceiling(Integer.valueOf(1), Calendar.HOUR_OF_DAY);
            fail("expected ClassCastException");
        } catch (ClassCastException e) {
            // expected
        }
    }

    public void testCeilingNullThrowsIllegalArgumentException() {
        try {
            DateUtils.ceiling((Date) null, Calendar.HOUR_OF_DAY);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // iterator
    //-----------------------------------------------------------------------

    public void testIteratorWeekSunday() {
        Calendar focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0); // a Thursday
        Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        int count = 0;
        Calendar first = null;
        Calendar last = null;
        while (it.hasNext()) {
            Calendar cur = it.next();
            if (first == null) {
                first = cur;
            }
            last = cur;
            count++;
        }
        assertEquals(7, count);
        assertEquals(Calendar.SUNDAY, first.get(Calendar.DAY_OF_WEEK));
        assertEquals(Calendar.SATURDAY, last.get(Calendar.DAY_OF_WEEK));
    }

    public void testIteratorExhaustedThrowsNoSuchElementException() {
        Calendar focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        while (it.hasNext()) {
            it.next();
        }
        try {
            it.next();
            fail("expected NoSuchElementException");
        } catch (NoSuchElementException e) {
            // expected
        }
    }

    public void testIteratorRemoveUnsupported() {
        Calendar focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        try {
            it.remove();
            fail("expected UnsupportedOperationException");
        } catch (UnsupportedOperationException e) {
            // expected
        }
    }

    public void testIteratorDateOverload() {
        Date focus = newDate(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        int count = 0;
        while (it.hasNext()) {
            it.next();
            count++;
        }
        assertEquals(7, count);
    }

    public void testIteratorObjectDispatchAndInvalidType() {
        Date focusDate = newDate(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        Iterator<?> it = DateUtils.iterator((Object) focusDate, DateUtils.RANGE_WEEK_SUNDAY);
        assertNotNull(it);
        try {
            DateUtils.iterator((Object) "not a date", DateUtils.RANGE_WEEK_SUNDAY);
            fail("expected ClassCastException");
        } catch (ClassCastException e) {
            // expected
        }
    }

    public void testIteratorInvalidRangeStyleThrowsIllegalArgumentException() {
        Calendar focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        try {
            DateUtils.iterator(focus, 999);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testIteratorNullFocusThrowsIllegalArgumentException() {
        try {
            DateUtils.iterator((Date) null, DateUtils.RANGE_WEEK_SUNDAY);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
        try {
            DateUtils.iterator((Calendar) null, DateUtils.RANGE_WEEK_SUNDAY);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
        try {
            DateUtils.iterator((Object) null, DateUtils.RANGE_WEEK_SUNDAY);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testIteratorMonthSunday() {
        Calendar focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_MONTH_SUNDAY);
        Calendar first = null;
        Calendar last = null;
        while (it.hasNext()) {
            Calendar cur = it.next();
            if (first == null) {
                first = cur;
            }
            last = cur;
        }
        assertEquals(Calendar.SUNDAY, first.get(Calendar.DAY_OF_WEEK));
        assertEquals(Calendar.SATURDAY, last.get(Calendar.DAY_OF_WEEK));
        assertTrue(first.getTime().before(focus.getTime()) || first.get(Calendar.DAY_OF_MONTH) == 1);
    }

    //-----------------------------------------------------------------------
    // getFragmentIn*(Date, ...)
    //-----------------------------------------------------------------------

    public void testGetFragmentInMillisecondsDate() {
        Date d = newDate(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        assertEquals(538L, DateUtils.getFragmentInMilliseconds(d, Calendar.SECOND));
        assertEquals(0L, DateUtils.getFragmentInMilliseconds(d, Calendar.MILLISECOND));
    }

    public void testGetFragmentInSecondsDate() {
        Date d = newDate(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        assertEquals(10L, DateUtils.getFragmentInSeconds(d, Calendar.MINUTE));
    }

    public void testGetFragmentInMinutesDate() {
        Date d = newDate(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        assertEquals(15L, DateUtils.getFragmentInMinutes(d, Calendar.HOUR_OF_DAY));
    }

    public void testGetFragmentInHoursDate() {
        Date d = newDate(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        assertEquals(7L, DateUtils.getFragmentInHours(d, Calendar.DAY_OF_YEAR));
    }

    public void testGetFragmentInDaysDate() {
        Date d = newDate(2008, Calendar.JANUARY, 28, 0, 0, 0, 0);
        assertEquals(28L, DateUtils.getFragmentInDays(d, Calendar.MONTH));
    }

    public void testGetFragmentInDaysCalendarYear() {
        // Feb 28, 2008 is the 59th day of the leap year 2008
        Calendar cal = newCalendar(2008, Calendar.FEBRUARY, 28, 0, 0, 0, 0);
        assertEquals(59L, DateUtils.getFragmentInDays(cal, Calendar.YEAR));
    }

    public void testGetFragmentNullThrowsIllegalArgumentException() {
        try {
            DateUtils.getFragmentInSeconds((Date) null, Calendar.MINUTE);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
        try {
            DateUtils.getFragmentInSeconds((Calendar) null, Calendar.MINUTE);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testGetFragmentUnsupportedFieldThrowsIllegalArgumentException() {
        Date d = newDate(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        try {
            DateUtils.getFragmentInDays(d, Calendar.DAY_OF_WEEK);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // truncatedEquals / truncatedCompareTo
    //-----------------------------------------------------------------------

    public void testTruncatedEqualsDate() {
        Date d1 = newDate(2008, Calendar.JANUARY, 1, 10, 0, 0, 0);
        Date d2 = newDate(2008, Calendar.JANUARY, 1, 23, 0, 0, 0);
        assertTrue(DateUtils.truncatedEquals(d1, d2, Calendar.DATE));
        assertFalse(DateUtils.truncatedEquals(d1, d2, Calendar.HOUR_OF_DAY));
    }

    public void testTruncatedEqualsCalendar() {
        Calendar c1 = newCalendar(2008, Calendar.JANUARY, 1, 10, 0, 0, 0);
        Calendar c2 = newCalendar(2008, Calendar.JANUARY, 1, 23, 0, 0, 0);
        assertTrue(DateUtils.truncatedEquals(c1, c2, Calendar.DATE));
        assertFalse(DateUtils.truncatedEquals(c1, c2, Calendar.HOUR_OF_DAY));
    }

    public void testTruncatedCompareToDate() {
        Date earlier = newDate(2008, Calendar.JANUARY, 1, 10, 0, 0, 0);
        Date later = newDate(2008, Calendar.JANUARY, 1, 23, 0, 0, 0);
        assertTrue(DateUtils.truncatedCompareTo(earlier, later, Calendar.HOUR_OF_DAY) < 0);
        assertTrue(DateUtils.truncatedCompareTo(later, earlier, Calendar.HOUR_OF_DAY) > 0);
        assertEquals(0, DateUtils.truncatedCompareTo(earlier, later, Calendar.DATE));
    }

    public void testTruncatedCompareToCalendar() {
        Calendar earlier = newCalendar(2008, Calendar.JANUARY, 1, 10, 0, 0, 0);
        Calendar later = newCalendar(2008, Calendar.JANUARY, 1, 23, 0, 0, 0);
        assertTrue(DateUtils.truncatedCompareTo(earlier, later, Calendar.HOUR_OF_DAY) < 0);
        assertEquals(0, DateUtils.truncatedCompareTo(earlier, later, Calendar.DATE));
    }

    //-----------------------------------------------------------------------
    // constants and constructor
    //-----------------------------------------------------------------------

    public void testMillisecondConstants() {
        assertEquals(1000L, DateUtils.MILLIS_PER_SECOND);
        assertEquals(60000L, DateUtils.MILLIS_PER_MINUTE);
        assertEquals(3600000L, DateUtils.MILLIS_PER_HOUR);
        assertEquals(86400000L, DateUtils.MILLIS_PER_DAY);
    }

    public void testConstructor() {
        // public constructor exists for frameworks requiring a JavaBean instance
        assertNotNull(new DateUtils());
    }
}
