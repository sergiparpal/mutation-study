/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.csv;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;

public class CSVPrinterAgentTest {

    @Test
    public void testPrintSingleValue() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("a");
        printer.close();
        assertEquals("a", sb.toString());
    }

    @Test
    public void testPrintNullValueUsesEmptyString() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print(null);
        printer.print("a");
        printer.close();
        // The empty value is quoted because MINIMAL quoting always quotes an
        // empty token that is first on the line.
        assertEquals("\"\",a", sb.toString());
    }

    @Test
    public void testPrintNullValueUsesNullString() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat format = CSVFormat.DEFAULT.withNullString("NULL");
        CSVPrinter printer = new CSVPrinter(sb, format);
        printer.print(null);
        printer.close();
        assertEquals("NULL", sb.toString());
    }

    @Test
    public void testPrintRecordVarargs() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord("a", "b", "c");
        printer.close();
        assertEquals("a,b,c" + CSVFormat.DEFAULT.getRecordSeparator(), sb.toString());
    }

    @Test
    public void testPrintRecordIterable() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        List<String> values = new ArrayList<String>();
        values.add("x");
        values.add("y");
        printer.printRecord(values);
        printer.close();
        assertEquals("x,y" + CSVFormat.DEFAULT.getRecordSeparator(), sb.toString());
    }

    @Test
    public void testMultipleRecordsAccumulate() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord("1", "2");
        printer.printRecord("3", "4");
        printer.close();
        String sep = CSVFormat.DEFAULT.getRecordSeparator();
        assertEquals("1,2" + sep + "3,4" + sep, sb.toString());
    }

    @Test
    public void testPrintRecordsOfArrayOfArrays() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        Object[] records = new Object[] {
            new String[] { "a", "b" },
            new String[] { "c", "d" }
        };
        printer.printRecords(records);
        printer.close();
        String sep = CSVFormat.DEFAULT.getRecordSeparator();
        assertEquals("a,b" + sep + "c,d" + sep, sb.toString());
    }

    @Test
    public void testPrintRecordsOfIterableOfIterables() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        List<List<String>> records = new ArrayList<List<String>>();
        records.add(Arrays.asList("a", "b"));
        records.add(Arrays.asList("c", "d"));
        printer.printRecords(records);
        printer.close();
        String sep = CSVFormat.DEFAULT.getRecordSeparator();
        assertEquals("a,b" + sep + "c,d" + sep, sb.toString());
    }

    @Test
    public void testPrintRecordsOfPlainValues() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        List<String> records = new ArrayList<String>();
        records.add("a");
        records.add("b");
        printer.printRecords(records);
        printer.close();
        String sep = CSVFormat.DEFAULT.getRecordSeparator();
        assertEquals("a" + sep + "b" + sep, sb.toString());
    }

    @Test
    public void testQuotingOfValueContainingDelimiter() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("a,b");
        printer.close();
        assertEquals("\"a,b\"", sb.toString());
    }

    @Test
    public void testQuotingOfValueContainingQuoteCharIsDoubled() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("a\"b");
        printer.close();
        assertEquals("\"a\"\"b\"", sb.toString());
    }

    @Test
    public void testQuotingOfValueContainingNewline() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("a\nb");
        printer.close();
        assertEquals("\"a\nb\"", sb.toString());
    }

    @Test
    public void testEmptyFirstValueOnLineIsQuoted() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("");
        printer.close();
        assertEquals("\"\"", sb.toString());
    }

    @Test
    public void testPlainValueIsNotQuoted() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("abc");
        printer.close();
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testQuoteAllPolicy() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat format = CSVFormat.DEFAULT.withQuotePolicy(Quote.ALL);
        CSVPrinter printer = new CSVPrinter(sb, format);
        printer.printRecord("a", "b");
        printer.close();
        assertEquals("\"a\",\"b\"" + format.getRecordSeparator(), sb.toString());
    }

    @Test
    public void testQuoteNonNumericPolicy() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat format = CSVFormat.DEFAULT.withQuotePolicy(Quote.NON_NUMERIC);
        CSVPrinter printer = new CSVPrinter(sb, format);
        printer.printRecord(Integer.valueOf(1), "a");
        printer.close();
        assertEquals("1,\"a\"" + format.getRecordSeparator(), sb.toString());
    }

    @Test
    public void testQuoteNonePolicyEscapesInsteadOfQuoting() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat format = CSVFormat.DEFAULT.withEscape('\\').withQuotePolicy(Quote.NONE);
        CSVPrinter printer = new CSVPrinter(sb, format);
        printer.print("a,b");
        printer.close();
        assertEquals("a\\,b", sb.toString());
    }

    @Test
    public void testEscapingWithoutQuoting() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat format = CSVFormat.newFormat(',').withEscape('\\');
        CSVPrinter printer = new CSVPrinter(sb, format);
        printer.print("a,b");
        printer.close();
        assertEquals("a\\,b", sb.toString());
    }

    @Test
    public void testEscapingOfNewlineAndCarriageReturn() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat format = CSVFormat.newFormat(',').withEscape('\\');
        CSVPrinter printer = new CSVPrinter(sb, format);
        printer.print("a\nb\rc");
        printer.close();
        assertEquals("a\\nb\\rc", sb.toString());
    }

    @Test
    public void testPrintln() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("a");
        printer.println();
        printer.print("b");
        printer.close();
        assertEquals("a" + CSVFormat.DEFAULT.getRecordSeparator() + "b", sb.toString());
    }

    @Test
    public void testPrintComment() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat format = CSVFormat.DEFAULT.withCommentStart('#');
        CSVPrinter printer = new CSVPrinter(sb, format);
        printer.printComment("my comment");
        printer.close();
        assertEquals("# my comment" + format.getRecordSeparator(), sb.toString());
    }

    @Test
    public void testPrintCommentWithEmbeddedNewline() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat format = CSVFormat.DEFAULT.withCommentStart('#');
        CSVPrinter printer = new CSVPrinter(sb, format);
        printer.printComment("line1\nline2");
        printer.close();
        String sep = format.getRecordSeparator();
        assertEquals("# line1" + sep + "# line2" + sep, sb.toString());
    }

    @Test
    public void testPrintCommentDoesNothingWhenCommentsDisabled() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printComment("ignored");
        printer.close();
        assertEquals("", sb.toString());
    }

    @Test
    public void testPrintCommentStartsOnNewLineIfMidRecord() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat format = CSVFormat.DEFAULT.withCommentStart('#');
        CSVPrinter printer = new CSVPrinter(sb, format);
        printer.print("a");
        printer.printComment("c");
        printer.close();
        String sep = format.getRecordSeparator();
        assertEquals("a" + sep + "# c" + sep, sb.toString());
    }

    @Test
    public void testHeaderIsPrintedOnConstruction() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat format = CSVFormat.DEFAULT.withHeader("col1", "col2");
        CSVPrinter printer = new CSVPrinter(sb, format);
        printer.close();
        assertEquals("col1,col2" + format.getRecordSeparator(), sb.toString());
    }

    @Test
    public void testHeaderThenRecord() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat format = CSVFormat.DEFAULT.withHeader("col1", "col2");
        CSVPrinter printer = new CSVPrinter(sb, format);
        printer.printRecord("a", "b");
        printer.close();
        String sep = format.getRecordSeparator();
        assertEquals("col1,col2" + sep + "a,b" + sep, sb.toString());
    }

    @Test
    public void testGetOutReturnsSameAppendable() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        assertNotNull(printer.getOut());
        assertTrue(printer.getOut() == sb);
    }

    @Test
    public void testConstructorNullOutThrowsIllegalArgumentException() throws IOException {
        try {
            new CSVPrinter(null, CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().contains("out"));
        }
    }

    @Test
    public void testConstructorNullFormatThrowsIllegalArgumentException() throws IOException {
        try {
            new CSVPrinter(new StringBuilder(), null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().contains("format"));
        }
    }

    @Test
    public void testConstructorInvalidFormatThrowsIllegalStateException() throws IOException {
        CSVFormat invalid = CSVFormat.DEFAULT.withDelimiter(',').withQuoteChar(',');
        try {
            new CSVPrinter(new StringBuilder(), invalid);
            fail("Expected IllegalStateException");
        } catch (IllegalStateException e) {
            assertTrue(e.getMessage().contains("delimiter"));
        }
    }

    @Test
    public void testCloseClosesUnderlyingCloseable() throws IOException {
        StringWriterCloseable writer = new StringWriterCloseable();
        CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT);
        printer.print("a");
        printer.close();
        assertTrue(writer.closed);
        assertEquals("a", writer.sb.toString());
    }

    @Test
    public void testCloseOnNonCloseableAppendableDoesNotThrow() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.close();
        assertEquals("", sb.toString());
    }

    @Test
    public void testFlushFlushesUnderlyingFlushable() throws IOException {
        FlushableAppendable fa = new FlushableAppendable();
        CSVPrinter printer = new CSVPrinter(fa, CSVFormat.DEFAULT);
        printer.print("a");
        assertFalse(fa.flushed);
        printer.flush();
        assertTrue(fa.flushed);
    }

    @Test
    public void testFlushOnNonFlushableAppendableDoesNotThrow() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("a");
        printer.flush();
        assertEquals("a", sb.toString());
    }

    @Test
    public void testPrintRecordsOfResultSet() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        FakeResultSet resultSet = new FakeResultSet(new String[][] {
            { "1", "foo" },
            { "2", "bar" }
        });
        printer.printRecords(resultSet);
        printer.close();
        String sep = CSVFormat.DEFAULT.getRecordSeparator();
        assertEquals("1,foo" + sep + "2,bar" + sep, sb.toString());
    }

    @Test
    public void testPrintRecordsOfEmptyResultSetProducesNoOutput() throws Exception {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        FakeResultSet resultSet = new FakeResultSet(new String[][] {});
        printer.printRecords(resultSet);
        printer.close();
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendableThrowingIOExceptionPropagates() throws IOException {
        ThrowingAppendable throwing = new ThrowingAppendable();
        CSVPrinter printer = new CSVPrinter(throwing, CSVFormat.DEFAULT);
        try {
            printer.print("a");
            fail("Expected IOException");
        } catch (IOException e) {
            assertEquals("boom", e.getMessage());
        }
    }

    // ======================================================
    // Self-contained fixtures
    // ======================================================

    private static class StringWriterCloseable implements Appendable, java.io.Closeable {
        final StringBuilder sb = new StringBuilder();
        boolean closed = false;

        public Appendable append(CharSequence csq) throws IOException {
            sb.append(csq);
            return this;
        }

        public Appendable append(CharSequence csq, int start, int end) throws IOException {
            sb.append(csq, start, end);
            return this;
        }

        public Appendable append(char c) throws IOException {
            sb.append(c);
            return this;
        }

        public void close() throws IOException {
            closed = true;
        }
    }

    private static class FlushableAppendable implements Appendable, java.io.Flushable {
        final StringBuilder sb = new StringBuilder();
        boolean flushed = false;

        public Appendable append(CharSequence csq) throws IOException {
            sb.append(csq);
            return this;
        }

        public Appendable append(CharSequence csq, int start, int end) throws IOException {
            sb.append(csq, start, end);
            return this;
        }

        public Appendable append(char c) throws IOException {
            sb.append(c);
            return this;
        }

        public void flush() throws IOException {
            flushed = true;
        }
    }

    private static class ThrowingAppendable implements Appendable {
        public Appendable append(CharSequence csq) throws IOException {
            throw new IOException("boom");
        }

        public Appendable append(CharSequence csq, int start, int end) throws IOException {
            throw new IOException("boom");
        }

        public Appendable append(char c) throws IOException {
            throw new IOException("boom");
        }
    }

    /**
     * Minimal JDBC ResultSet fake that supports only the methods CSVPrinter.printRecords uses.
     */
    private static class FakeResultSet implements java.sql.ResultSet {
        private final String[][] rows;
        private int index = -1;

        FakeResultSet(String[][] rows) {
            this.rows = rows;
        }

        public boolean next() throws java.sql.SQLException {
            index++;
            return index < rows.length;
        }

        public String getString(int columnIndex) throws java.sql.SQLException {
            return rows[index][columnIndex - 1];
        }

        public java.sql.ResultSetMetaData getMetaData() throws java.sql.SQLException {
            final int columnCount = rows.length == 0 ? 0 : rows[0].length;
            return new FakeResultSetMetaData(columnCount);
        }

        // ---- Unused ResultSet methods ----

        private UnsupportedOperationException unsupported() {
            return new UnsupportedOperationException();
        }

        public boolean absolute(int row) { throw unsupported(); }
        public void afterLast() { throw unsupported(); }
        public void beforeFirst() { throw unsupported(); }
        public void cancelRowUpdates() { throw unsupported(); }
        public void clearWarnings() { throw unsupported(); }
        public void close() { }
        public void deleteRow() { throw unsupported(); }
        public int findColumn(String columnLabel) { throw unsupported(); }
        public boolean first() { throw unsupported(); }
        public java.sql.Array getArray(int columnIndex) { throw unsupported(); }
        public java.sql.Array getArray(String columnLabel) { throw unsupported(); }
        public java.io.InputStream getAsciiStream(int columnIndex) { throw unsupported(); }
        public java.io.InputStream getAsciiStream(String columnLabel) { throw unsupported(); }
        public java.math.BigDecimal getBigDecimal(int columnIndex) { throw unsupported(); }
        public java.math.BigDecimal getBigDecimal(String columnLabel) { throw unsupported(); }
        public java.math.BigDecimal getBigDecimal(int columnIndex, int scale) { throw unsupported(); }
        public java.math.BigDecimal getBigDecimal(String columnLabel, int scale) { throw unsupported(); }
        public java.io.InputStream getBinaryStream(int columnIndex) { throw unsupported(); }
        public java.io.InputStream getBinaryStream(String columnLabel) { throw unsupported(); }
        public java.sql.Blob getBlob(int columnIndex) { throw unsupported(); }
        public java.sql.Blob getBlob(String columnLabel) { throw unsupported(); }
        public boolean getBoolean(int columnIndex) { throw unsupported(); }
        public boolean getBoolean(String columnLabel) { throw unsupported(); }
        public byte getByte(int columnIndex) { throw unsupported(); }
        public byte getByte(String columnLabel) { throw unsupported(); }
        public byte[] getBytes(int columnIndex) { throw unsupported(); }
        public byte[] getBytes(String columnLabel) { throw unsupported(); }
        public java.io.Reader getCharacterStream(int columnIndex) { throw unsupported(); }
        public java.io.Reader getCharacterStream(String columnLabel) { throw unsupported(); }
        public java.sql.Clob getClob(int columnIndex) { throw unsupported(); }
        public java.sql.Clob getClob(String columnLabel) { throw unsupported(); }
        public int getConcurrency() { throw unsupported(); }
        public String getCursorName() { throw unsupported(); }
        public java.sql.Date getDate(int columnIndex) { throw unsupported(); }
        public java.sql.Date getDate(String columnLabel) { throw unsupported(); }
        public java.sql.Date getDate(int columnIndex, java.util.Calendar cal) { throw unsupported(); }
        public java.sql.Date getDate(String columnLabel, java.util.Calendar cal) { throw unsupported(); }
        public double getDouble(int columnIndex) { throw unsupported(); }
        public double getDouble(String columnLabel) { throw unsupported(); }
        public int getFetchDirection() { throw unsupported(); }
        public int getFetchSize() { throw unsupported(); }
        public float getFloat(int columnIndex) { throw unsupported(); }
        public float getFloat(String columnLabel) { throw unsupported(); }
        public int getHoldability() { throw unsupported(); }
        public int getInt(int columnIndex) { throw unsupported(); }
        public int getInt(String columnLabel) { throw unsupported(); }
        public long getLong(int columnIndex) { throw unsupported(); }
        public long getLong(String columnLabel) { throw unsupported(); }
        public java.io.Reader getNCharacterStream(int columnIndex) { throw unsupported(); }
        public java.io.Reader getNCharacterStream(String columnLabel) { throw unsupported(); }
        public java.sql.NClob getNClob(int columnIndex) { throw unsupported(); }
        public java.sql.NClob getNClob(String columnLabel) { throw unsupported(); }
        public String getNString(int columnIndex) { throw unsupported(); }
        public String getNString(String columnLabel) { throw unsupported(); }
        public Object getObject(int columnIndex) { throw unsupported(); }
        public Object getObject(String columnLabel) { throw unsupported(); }
        public Object getObject(int columnIndex, java.util.Map<String, Class<?>> map) { throw unsupported(); }
        public Object getObject(String columnLabel, java.util.Map<String, Class<?>> map) { throw unsupported(); }
        public <T> T getObject(int columnIndex, Class<T> type) { throw unsupported(); }
        public <T> T getObject(String columnLabel, Class<T> type) { throw unsupported(); }
        public java.sql.Ref getRef(int columnIndex) { throw unsupported(); }
        public java.sql.Ref getRef(String columnLabel) { throw unsupported(); }
        public int getRow() { throw unsupported(); }
        public java.sql.RowId getRowId(int columnIndex) { throw unsupported(); }
        public java.sql.RowId getRowId(String columnLabel) { throw unsupported(); }
        public java.sql.SQLXML getSQLXML(int columnIndex) { throw unsupported(); }
        public java.sql.SQLXML getSQLXML(String columnLabel) { throw unsupported(); }
        public short getShort(int columnIndex) { throw unsupported(); }
        public short getShort(String columnLabel) { throw unsupported(); }
        public java.sql.Statement getStatement() { throw unsupported(); }
        public String getString(String columnLabel) { throw unsupported(); }
        public java.sql.Time getTime(int columnIndex) { throw unsupported(); }
        public java.sql.Time getTime(String columnLabel) { throw unsupported(); }
        public java.sql.Time getTime(int columnIndex, java.util.Calendar cal) { throw unsupported(); }
        public java.sql.Time getTime(String columnLabel, java.util.Calendar cal) { throw unsupported(); }
        public java.sql.Timestamp getTimestamp(int columnIndex) { throw unsupported(); }
        public java.sql.Timestamp getTimestamp(String columnLabel) { throw unsupported(); }
        public java.sql.Timestamp getTimestamp(int columnIndex, java.util.Calendar cal) { throw unsupported(); }
        public java.sql.Timestamp getTimestamp(String columnLabel, java.util.Calendar cal) { throw unsupported(); }
        public int getType() { throw unsupported(); }
        public java.net.URL getURL(int columnIndex) { throw unsupported(); }
        public java.net.URL getURL(String columnLabel) { throw unsupported(); }
        public java.io.InputStream getUnicodeStream(int columnIndex) { throw unsupported(); }
        public java.io.InputStream getUnicodeStream(String columnLabel) { throw unsupported(); }
        public java.sql.SQLWarning getWarnings() { throw unsupported(); }
        public void insertRow() { throw unsupported(); }
        public boolean isAfterLast() { throw unsupported(); }
        public boolean isBeforeFirst() { throw unsupported(); }
        public boolean isClosed() { throw unsupported(); }
        public boolean isFirst() { throw unsupported(); }
        public boolean isLast() { throw unsupported(); }
        public boolean last() { throw unsupported(); }
        public void moveToCurrentRow() { throw unsupported(); }
        public void moveToInsertRow() { throw unsupported(); }
        public boolean previous() { throw unsupported(); }
        public void refreshRow() { throw unsupported(); }
        public boolean relative(int rows) { throw unsupported(); }
        public boolean rowDeleted() { throw unsupported(); }
        public boolean rowInserted() { throw unsupported(); }
        public boolean rowUpdated() { throw unsupported(); }
        public void setFetchDirection(int direction) { throw unsupported(); }
        public void setFetchSize(int rows) { throw unsupported(); }
        public void updateArray(int columnIndex, java.sql.Array x) { throw unsupported(); }
        public void updateArray(String columnLabel, java.sql.Array x) { throw unsupported(); }
        public void updateAsciiStream(int columnIndex, java.io.InputStream x) { throw unsupported(); }
        public void updateAsciiStream(String columnLabel, java.io.InputStream x) { throw unsupported(); }
        public void updateAsciiStream(int columnIndex, java.io.InputStream x, int length) { throw unsupported(); }
        public void updateAsciiStream(String columnLabel, java.io.InputStream x, int length) { throw unsupported(); }
        public void updateAsciiStream(int columnIndex, java.io.InputStream x, long length) { throw unsupported(); }
        public void updateAsciiStream(String columnLabel, java.io.InputStream x, long length) { throw unsupported(); }
        public void updateBigDecimal(int columnIndex, java.math.BigDecimal x) { throw unsupported(); }
        public void updateBigDecimal(String columnLabel, java.math.BigDecimal x) { throw unsupported(); }
        public void updateBinaryStream(int columnIndex, java.io.InputStream x) { throw unsupported(); }
        public void updateBinaryStream(String columnLabel, java.io.InputStream x) { throw unsupported(); }
        public void updateBinaryStream(int columnIndex, java.io.InputStream x, int length) { throw unsupported(); }
        public void updateBinaryStream(String columnLabel, java.io.InputStream x, int length) { throw unsupported(); }
        public void updateBinaryStream(int columnIndex, java.io.InputStream x, long length) { throw unsupported(); }
        public void updateBinaryStream(String columnLabel, java.io.InputStream x, long length) { throw unsupported(); }
        public void updateBlob(int columnIndex, java.sql.Blob x) { throw unsupported(); }
        public void updateBlob(String columnLabel, java.sql.Blob x) { throw unsupported(); }
        public void updateBlob(int columnIndex, java.io.InputStream inputStream) { throw unsupported(); }
        public void updateBlob(String columnLabel, java.io.InputStream inputStream) { throw unsupported(); }
        public void updateBlob(int columnIndex, java.io.InputStream inputStream, long length) { throw unsupported(); }
        public void updateBlob(String columnLabel, java.io.InputStream inputStream, long length) { throw unsupported(); }
        public void updateBoolean(int columnIndex, boolean x) { throw unsupported(); }
        public void updateBoolean(String columnLabel, boolean x) { throw unsupported(); }
        public void updateByte(int columnIndex, byte x) { throw unsupported(); }
        public void updateByte(String columnLabel, byte x) { throw unsupported(); }
        public void updateBytes(int columnIndex, byte[] x) { throw unsupported(); }
        public void updateBytes(String columnLabel, byte[] x) { throw unsupported(); }
        public void updateCharacterStream(int columnIndex, java.io.Reader x) { throw unsupported(); }
        public void updateCharacterStream(String columnLabel, java.io.Reader reader) { throw unsupported(); }
        public void updateCharacterStream(int columnIndex, java.io.Reader x, int length) { throw unsupported(); }
        public void updateCharacterStream(String columnLabel, java.io.Reader reader, int length) { throw unsupported(); }
        public void updateCharacterStream(int columnIndex, java.io.Reader x, long length) { throw unsupported(); }
        public void updateCharacterStream(String columnLabel, java.io.Reader reader, long length) { throw unsupported(); }
        public void updateClob(int columnIndex, java.sql.Clob x) { throw unsupported(); }
        public void updateClob(String columnLabel, java.sql.Clob x) { throw unsupported(); }
        public void updateClob(int columnIndex, java.io.Reader reader) { throw unsupported(); }
        public void updateClob(String columnLabel, java.io.Reader reader) { throw unsupported(); }
        public void updateClob(int columnIndex, java.io.Reader reader, long length) { throw unsupported(); }
        public void updateClob(String columnLabel, java.io.Reader reader, long length) { throw unsupported(); }
        public void updateDate(int columnIndex, java.sql.Date x) { throw unsupported(); }
        public void updateDate(String columnLabel, java.sql.Date x) { throw unsupported(); }
        public void updateDouble(int columnIndex, double x) { throw unsupported(); }
        public void updateDouble(String columnLabel, double x) { throw unsupported(); }
        public void updateFloat(int columnIndex, float x) { throw unsupported(); }
        public void updateFloat(String columnLabel, float x) { throw unsupported(); }
        public void updateInt(int columnIndex, int x) { throw unsupported(); }
        public void updateInt(String columnLabel, int x) { throw unsupported(); }
        public void updateLong(int columnIndex, long x) { throw unsupported(); }
        public void updateLong(String columnLabel, long x) { throw unsupported(); }
        public void updateNCharacterStream(int columnIndex, java.io.Reader x) { throw unsupported(); }
        public void updateNCharacterStream(String columnLabel, java.io.Reader reader) { throw unsupported(); }
        public void updateNCharacterStream(int columnIndex, java.io.Reader x, long length) { throw unsupported(); }
        public void updateNCharacterStream(String columnLabel, java.io.Reader reader, long length) { throw unsupported(); }
        public void updateNClob(int columnIndex, java.sql.NClob nClob) { throw unsupported(); }
        public void updateNClob(String columnLabel, java.sql.NClob nClob) { throw unsupported(); }
        public void updateNClob(int columnIndex, java.io.Reader reader) { throw unsupported(); }
        public void updateNClob(String columnLabel, java.io.Reader reader) { throw unsupported(); }
        public void updateNClob(int columnIndex, java.io.Reader reader, long length) { throw unsupported(); }
        public void updateNClob(String columnLabel, java.io.Reader reader, long length) { throw unsupported(); }
        public void updateNString(int columnIndex, String nString) { throw unsupported(); }
        public void updateNString(String columnLabel, String nString) { throw unsupported(); }
        public void updateNull(int columnIndex) { throw unsupported(); }
        public void updateNull(String columnLabel) { throw unsupported(); }
        public void updateObject(int columnIndex, Object x) { throw unsupported(); }
        public void updateObject(String columnLabel, Object x) { throw unsupported(); }
        public void updateObject(int columnIndex, Object x, int scaleOrLength) { throw unsupported(); }
        public void updateObject(String columnLabel, Object x, int scaleOrLength) { throw unsupported(); }
        public void updateRef(int columnIndex, java.sql.Ref x) { throw unsupported(); }
        public void updateRef(String columnLabel, java.sql.Ref x) { throw unsupported(); }
        public void updateRow() { throw unsupported(); }
        public void updateRowId(int columnIndex, java.sql.RowId x) { throw unsupported(); }
        public void updateRowId(String columnLabel, java.sql.RowId x) { throw unsupported(); }
        public void updateSQLXML(int columnIndex, java.sql.SQLXML x) { throw unsupported(); }
        public void updateSQLXML(String columnLabel, java.sql.SQLXML x) { throw unsupported(); }
        public void updateShort(int columnIndex, short x) { throw unsupported(); }
        public void updateShort(String columnLabel, short x) { throw unsupported(); }
        public void updateString(int columnIndex, String x) { throw unsupported(); }
        public void updateString(String columnLabel, String x) { throw unsupported(); }
        public void updateTime(int columnIndex, java.sql.Time x) { throw unsupported(); }
        public void updateTime(String columnLabel, java.sql.Time x) { throw unsupported(); }
        public void updateTimestamp(int columnIndex, java.sql.Timestamp x) { throw unsupported(); }
        public void updateTimestamp(String columnLabel, java.sql.Timestamp x) { throw unsupported(); }
        public boolean wasNull() { throw unsupported(); }
        public boolean isWrapperFor(Class<?> iface) { throw unsupported(); }
        public <T> T unwrap(Class<T> iface) { throw unsupported(); }
    }

    private static class FakeResultSetMetaData implements java.sql.ResultSetMetaData {
        private final int columnCount;

        FakeResultSetMetaData(int columnCount) {
            this.columnCount = columnCount;
        }

        public int getColumnCount() { return columnCount; }

        private UnsupportedOperationException unsupported() {
            return new UnsupportedOperationException();
        }

        public String getCatalogName(int column) { throw unsupported(); }
        public String getColumnClassName(int column) { throw unsupported(); }
        public int getColumnDisplaySize(int column) { throw unsupported(); }
        public String getColumnLabel(int column) { throw unsupported(); }
        public String getColumnName(int column) { throw unsupported(); }
        public int getColumnType(int column) { throw unsupported(); }
        public String getColumnTypeName(int column) { throw unsupported(); }
        public int getPrecision(int column) { throw unsupported(); }
        public int getScale(int column) { throw unsupported(); }
        public String getSchemaName(int column) { throw unsupported(); }
        public String getTableName(int column) { throw unsupported(); }
        public boolean isAutoIncrement(int column) { throw unsupported(); }
        public boolean isCaseSensitive(int column) { throw unsupported(); }
        public boolean isCurrency(int column) { throw unsupported(); }
        public boolean isDefinitelyWritable(int column) { throw unsupported(); }
        public int isNullable(int column) { throw unsupported(); }
        public boolean isReadOnly(int column) { throw unsupported(); }
        public boolean isSearchable(int column) { throw unsupported(); }
        public boolean isSigned(int column) { throw unsupported(); }
        public boolean isWritable(int column) { throw unsupported(); }
        public boolean isWrapperFor(Class<?> iface) { throw unsupported(); }
        public <T> T unwrap(Class<T> iface) { throw unsupported(); }
    }
}
