/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.csv;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.StringReader;
import java.io.Writer;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.junit.Test;

/**
 * Self-contained tests for {@link CSVParser}.
 */
public class CSVParserAgentTest {

    @Test
    public void testParseSimpleString() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b,c\n1,2,3\n", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("b", records.get(0).get(1));
            assertEquals("c", records.get(0).get(2));
            assertEquals("1", records.get(1).get(0));
            assertEquals("2", records.get(1).get(1));
            assertEquals("3", records.get(1).get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testConstructorWithReader() throws IOException {
        final Reader in = new StringReader("x,y\n1,2\n");
        final CSVParser parser = new CSVParser(in, CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("x", records.get(0).get(0));
            assertEquals("1", records.get(1).get(0));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetRecordsEmptyInput() throws IOException {
        final CSVParser parser = CSVParser.parse("", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertTrue(records.isEmpty());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testNextRecordReturnsNullAtEof() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n", CSVFormat.DEFAULT);
        try {
            final CSVRecord first = parser.nextRecord();
            assertEquals("a", first.get(0));
            final CSVRecord second = parser.nextRecord();
            assertNull(second);
        } finally {
            parser.close();
        }
    }

    @Test
    public void testHeaderMapFromFirstRecordAsHeader() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withFirstRecordAsHeader();
        final CSVParser parser = CSVParser.parse("name,age\nJohn,22\nJane,32\n", format);
        try {
            final Map<String, Integer> headerMap = parser.getHeaderMap();
            assertEquals(Integer.valueOf(0), headerMap.get("name"));
            assertEquals(Integer.valueOf(1), headerMap.get("age"));

            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("John", records.get(0).get("name"));
            assertEquals("22", records.get(0).get("age"));
            assertEquals("Jane", records.get(1).get("name"));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testHeaderMapIsACopy() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("a", "b");
        final CSVParser parser = CSVParser.parse("1,2\n", format);
        try {
            final Map<String, Integer> headerMap1 = parser.getHeaderMap();
            headerMap1.put("c", Integer.valueOf(99));
            final Map<String, Integer> headerMap2 = parser.getHeaderMap();
            assertFalse(headerMap2.containsKey("c"));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetHeaderMapNullWhenNoHeader() throws IOException {
        final CSVParser parser = CSVParser.parse("1,2\n", CSVFormat.DEFAULT);
        try {
            assertNull(parser.getHeaderMap());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testDuplicateHeaderNamesThrows() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader();
        try {
            final CSVParser parser = CSVParser.parse("a,a\n1,2\n", format);
            parser.close();
            fail("Expected IllegalArgumentException for duplicate header names");
        } catch (final IllegalArgumentException expected) {
            assertTrue(expected.getMessage().contains("duplicate"));
        }
    }

    @Test
    public void testGetRecordNumberIncrements() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n2\n3\n", CSVFormat.DEFAULT);
        try {
            assertEquals(0, parser.getRecordNumber());
            final CSVRecord r1 = parser.nextRecord();
            assertEquals(1, r1.getRecordNumber());
            assertEquals(1, parser.getRecordNumber());
            final CSVRecord r2 = parser.nextRecord();
            assertEquals(2, r2.getRecordNumber());
            assertEquals(2, parser.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetCurrentLineNumber() throws IOException {
        final CSVParser parser = CSVParser.parse("a\nb\nc\n", CSVFormat.DEFAULT);
        try {
            assertEquals(0, parser.getCurrentLineNumber());
            parser.nextRecord();
            assertEquals(1, parser.getCurrentLineNumber());
            parser.nextRecord();
            assertEquals(2, parser.getCurrentLineNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testCloseAndIsClosed() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n", CSVFormat.DEFAULT);
        assertFalse(parser.isClosed());
        parser.close();
        assertTrue(parser.isClosed());
    }

    @Test
    public void testIteratorHasNextFalseAfterClose() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\nc,d\n", CSVFormat.DEFAULT);
        final Iterator<CSVRecord> iterator = parser.iterator();
        parser.close();
        assertFalse(iterator.hasNext());
    }

    @Test
    public void testIteratorNextThrowsAfterClose() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\nc,d\n", CSVFormat.DEFAULT);
        final Iterator<CSVRecord> iterator = parser.iterator();
        parser.close();
        try {
            iterator.next();
            fail("Expected NoSuchElementException");
        } catch (final NoSuchElementException expected) {
            // expected
        }
    }

    @Test
    public void testIteratorNextThrowsWhenExhausted() throws IOException {
        final CSVParser parser = CSVParser.parse("a\n", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> iterator = parser.iterator();
            assertTrue(iterator.hasNext());
            final CSVRecord record = iterator.next();
            assertEquals("a", record.get(0));
            assertFalse(iterator.hasNext());
            try {
                iterator.next();
                fail("Expected NoSuchElementException");
            } catch (final NoSuchElementException expected) {
                // expected
            }
        } finally {
            parser.close();
        }
    }

    @Test
    public void testIteratorRemoveUnsupported() throws IOException {
        final CSVParser parser = CSVParser.parse("a\n", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> iterator = parser.iterator();
            try {
                iterator.remove();
                fail("Expected UnsupportedOperationException");
            } catch (final UnsupportedOperationException expected) {
                // expected
            }
        } finally {
            parser.close();
        }
    }

    @Test
    public void testIteratorNextWithoutHasNextCall() throws IOException {
        final CSVParser parser = CSVParser.parse("a\nb\n", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> iterator = parser.iterator();
            final CSVRecord first = iterator.next();
            assertEquals("a", first.get(0));
            final CSVRecord second = iterator.next();
            assertEquals("b", second.get(0));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetFirstEndOfLine() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\r\nc,d\r\n", CSVFormat.DEFAULT);
        try {
            parser.getRecords();
            assertEquals("\r\n", parser.getFirstEndOfLine());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testSkipHeaderRecordWithExplicitHeader() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("a", "b").withSkipHeaderRecord(true);
        final CSVParser parser = CSVParser.parse("a,b\n1,2\n", format);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("1", records.get(0).get("a"));
            assertEquals("2", records.get(0).get("b"));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testCommentsAreAttachedToRecord() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withCommentMarker('#');
        final CSVParser parser = CSVParser.parse("# comment line\na,b\n", format);
        try {
            final CSVRecord record = parser.nextRecord();
            assertTrue(record.hasComment());
            assertEquals("comment line", record.getComment());
            assertEquals("a", record.get(0));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testNullStringIsMappedToNullValue() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withNullString("NULL");
        final CSVParser parser = CSVParser.parse("a,NULL,c\n", format);
        try {
            final CSVRecord record = parser.nextRecord();
            assertEquals("a", record.get(0));
            assertNull(record.get(1));
            assertEquals("c", record.get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testTrimValues() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withTrim(true).withDelimiter(';');
        final CSVParser parser = CSVParser.parse(" a ; b \n", format);
        try {
            final CSVRecord record = parser.nextRecord();
            assertEquals("a", record.get(0));
            assertEquals("b", record.get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testInvalidTokenThrowsIOException() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withQuote('"');
        final CSVParser parser = CSVParser.parse("\"a\"b,c\n", format);
        try {
            try {
                parser.nextRecord();
                fail("Expected IOException for malformed quoted token");
            } catch (final IOException expected) {
                assertTrue(expected.getMessage().contains("invalid char between encapsulated token and delimiter"));
            }
        } finally {
            parser.close();
        }
    }

    @Test(expected = IllegalArgumentException.class)
    public void testParseStringNullThrows() throws IOException {
        CSVParser.parse((String) null, CSVFormat.DEFAULT);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testParseStringNullFormatThrows() throws IOException {
        CSVParser.parse("a,b", null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testConstructorNullReaderThrows() throws IOException {
        new CSVParser((Reader) null, CSVFormat.DEFAULT);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testConstructorNullFormatThrows() throws IOException {
        new CSVParser(new StringReader("a,b"), null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testParseFileNullThrows() throws IOException {
        CSVParser.parse((File) null, Charset.forName("UTF-8"), CSVFormat.DEFAULT);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testParseUrlNullThrows() throws IOException {
        CSVParser.parse((URL) null, Charset.forName("UTF-8"), CSVFormat.DEFAULT);
    }

    @Test
    public void testParseFile() throws IOException {
        final File file = File.createTempFile("csvparseragenttest", ".csv");
        file.deleteOnExit();
        final Writer writer = new OutputStreamWriter(new FileOutputStream(file), "UTF-8");
        try {
            writer.write("one,two\nthree,four\n");
        } finally {
            writer.close();
        }
        final CSVParser parser = CSVParser.parse(file, Charset.forName("UTF-8"), CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("one", records.get(0).get(0));
            assertEquals("four", records.get(1).get(1));
        } finally {
            parser.close();
            file.delete();
        }
    }

    @Test
    public void testCharacterOffsetConstructor() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a,b\n"), CSVFormat.DEFAULT, 100, 5);
        try {
            final CSVRecord record = parser.nextRecord();
            assertEquals(5, record.getRecordNumber());
            assertEquals(100, record.getCharacterPosition());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testIgnoreEmptyLinesFalseKeepsEmptyRecord() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withIgnoreEmptyLines(false);
        final CSVParser parser = CSVParser.parse("a,b\n\nc,d\n", format);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(3, records.size());
            assertEquals(1, records.get(1).size());
            assertEquals("", records.get(1).get(0));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testSingleLineNoTrailingNewline() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b,c", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals(3, records.get(0).size());
            assertEquals("c", records.get(0).get(2));
        } finally {
            parser.close();
        }
    }
}
