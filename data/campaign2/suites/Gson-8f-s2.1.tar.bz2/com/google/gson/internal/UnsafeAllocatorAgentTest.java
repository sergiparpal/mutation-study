package com.google.gson.internal;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.junit.Test;

/**
 * Tests for {@link UnsafeAllocator} based on the documented contract:
 * {@code create()} returns an allocator, and {@code newInstance(Class)}
 * allocates an object of the given class without invoking its constructor,
 * throwing {@code Exception} when that is not possible.
 */
public class UnsafeAllocatorAgentTest {

    /** Field initializers are compiled into constructors, so if the
     * constructor is bypassed this field keeps its JVM default value. */
    public static class PlainClass {
        int marker = 42;

        public PlainClass() {
            marker = 99;
        }
    }

    public static class ThrowingConstructor {
        public ThrowingConstructor() {
            throw new RuntimeException("constructor should not run");
        }
    }

    private static class PrivateConstructor {
        boolean touched = false;

        private PrivateConstructor() {
            touched = true;
        }
    }

    public abstract static class AbstractClass {
        public AbstractClass() {
        }
    }

    public interface SomeInterface {
    }

    public static final class FinalClass {
        final int value;

        public FinalClass() {
            value = 7;
        }
    }

    public static class NoDefaultConstructor {
        final String label;

        public NoDefaultConstructor(String label) {
            this.label = label;
        }
    }

    @Test
    public void createReturnsNonNullAllocator() {
        UnsafeAllocator allocator = UnsafeAllocator.create();
        assertNotNull(allocator);
    }

    @Test
    public void createReturnsUsableAllocatorEachTime() throws Exception {
        UnsafeAllocator first = UnsafeAllocator.create();
        UnsafeAllocator second = UnsafeAllocator.create();
        assertNotNull(first);
        assertNotNull(second);
        Object firstInstance = first.newInstance(PlainClass.class);
        Object secondInstance = second.newInstance(PlainClass.class);
        assertNotNull(firstInstance);
        assertNotNull(secondInstance);
    }

    @Test
    public void newInstanceReturnsInstanceOfRequestedClass() throws Exception {
        UnsafeAllocator allocator = UnsafeAllocator.create();
        PlainClass instance = allocator.newInstance(PlainClass.class);
        assertNotNull(instance);
        assertTrue(instance instanceof PlainClass);
    }

    @Test
    public void newInstanceDoesNotInvokeConstructor() throws Exception {
        UnsafeAllocator allocator = UnsafeAllocator.create();
        PlainClass instance = allocator.newInstance(PlainClass.class);
        // The constructor sets marker to 99; bypassing it leaves the
        // pre-constructor default value of the field's declaration-time
        // assignment unexecuted, i.e. the JVM default 0.
        assertEquals(0, instance.marker);
    }

    @Test
    public void newInstanceDoesNotRunThrowingConstructor() throws Exception {
        UnsafeAllocator allocator = UnsafeAllocator.create();
        ThrowingConstructor instance = allocator.newInstance(ThrowingConstructor.class);
        assertNotNull(instance);
    }

    @Test
    public void newInstanceBypassesPrivateConstructor() throws Exception {
        UnsafeAllocator allocator = UnsafeAllocator.create();
        PrivateConstructor instance = allocator.newInstance(PrivateConstructor.class);
        assertNotNull(instance);
        assertFalse(instance.touched);
    }

    @Test
    public void newInstanceWorksForFinalClass() throws Exception {
        UnsafeAllocator allocator = UnsafeAllocator.create();
        FinalClass instance = allocator.newInstance(FinalClass.class);
        assertNotNull(instance);
        assertEquals(0, instance.value);
    }

    @Test
    public void newInstanceWorksForClassWithoutDefaultConstructor() throws Exception {
        UnsafeAllocator allocator = UnsafeAllocator.create();
        NoDefaultConstructor instance = allocator.newInstance(NoDefaultConstructor.class);
        assertNotNull(instance);
        assertEquals(null, instance.label);
    }

    @Test
    public void newInstanceProducesDistinctObjectsOnEachCall() throws Exception {
        UnsafeAllocator allocator = UnsafeAllocator.create();
        PlainClass first = allocator.newInstance(PlainClass.class);
        PlainClass second = allocator.newInstance(PlainClass.class);
        assertNotSame(first, second);
    }

    @Test(expected = Exception.class)
    public void newInstanceRejectsNullClass() throws Exception {
        UnsafeAllocator allocator = UnsafeAllocator.create();
        allocator.newInstance(null);
    }

    @Test
    public void newInstanceFailsForAbstractClass() throws Exception {
        UnsafeAllocator allocator = UnsafeAllocator.create();
        try {
            AbstractClass instance = allocator.newInstance(AbstractClass.class);
            fail("Expected an Exception when allocating an abstract class, got instance: " + instance);
        } catch (Exception expected) {
            // An abstract class cannot be instantiated, by any mechanism.
        }
    }

    @Test
    public void newInstanceFailsForInterface() throws Exception {
        UnsafeAllocator allocator = UnsafeAllocator.create();
        try {
            SomeInterface instance = allocator.newInstance(SomeInterface.class);
            fail("Expected an Exception when allocating an interface, got instance: " + instance);
        } catch (Exception expected) {
            // An interface cannot be instantiated, by any mechanism.
        }
    }

    @Test
    public void newInstanceFailsForPrimitiveType() throws Exception {
        UnsafeAllocator allocator = UnsafeAllocator.create();
        try {
            Object instance = allocator.newInstance(int.class);
            fail("Expected an Exception when allocating a primitive type, got instance: " + instance);
        } catch (Exception expected) {
            // A primitive type is not an object type and cannot be allocated.
        }
    }

    @Test
    public void newInstanceFailsForArrayType() throws Exception {
        UnsafeAllocator allocator = UnsafeAllocator.create();
        try {
            Object instance = allocator.newInstance(int[].class);
            fail("Expected an Exception when allocating an array type, got instance: " + instance);
        } catch (Exception expected) {
            // Array instances must be created via array-specific allocation,
            // not plain object allocation.
        }
    }
}
