/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.builder;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import junit.framework.TestCase;

/**
 * Self-contained test case for {@link ToStringStyle}.
 */
public class ToStringStyleAgentTest extends TestCase {

    public ToStringStyleAgentTest(String name) {
        super(name);
    }

    private static final class StyleImpl extends ToStringStyle {
        private static final long serialVersionUID = 1L;
    }

    //-----------------------------------------------------------------------
    // append(Object) with full detail true/false/null
    //-----------------------------------------------------------------------

    public void testAppendObjectFullDetailTrue() {
        ToStringStyle style = new StyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "name", "value", Boolean.TRUE);
        assertEquals("name=value,", buffer.toString());
    }

    public void testAppendObjectFullDetailFalse() {
        ToStringStyle style = new StyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "name", "value", Boolean.FALSE);
        assertEquals("name=<String>,", buffer.toString());
    }

    public void testAppendObjectFullDetailNullUsesDefault() {
        ToStringStyle style = new StyleImpl();
        style.setDefaultFullDetail(false);
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "name", "value", null);
        assertEquals("name=<String>,", buffer.toString());
    }

    public void testAppendObjectNullValue() {
        ToStringStyle style = new StyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "name", (Object) null, Boolean.TRUE);
        assertEquals("name=<null>,", buffer.toString());
    }

    public void testAppendObjectNoFieldName() {
        ToStringStyle style = new StyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, null, "value", Boolean.TRUE);
        assertEquals("value,", buffer.toString());
    }

    public void testAppendObjectFieldNamesDisabled() {
        ToStringStyle style = new StyleImpl();
        style.setUseFieldNames(false);
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "name", "value", Boolean.TRUE);
        assertEquals("value,", buffer.toString());
    }

    //-----------------------------------------------------------------------
    // Primitive append methods
    //-----------------------------------------------------------------------

    public void testAppendLong() {
        ToStringStyle style = new StyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "l", Long.MAX_VALUE);
        assertEquals("l=9223372036854775807,", buffer.toString());
    }

    public void testAppendInt() {
        ToStringStyle style = new StyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "i", Integer.MIN_VALUE);
        assertEquals("i=-2147483648,", buffer.toString());
    }

    public void testAppendShort() {
        ToStringStyle style = new StyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "s", (short) 7);
        assertEquals("s=7,", buffer.toString());
    }

    public void testAppendByte() {
        ToStringStyle style = new StyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "b", (byte) -1);
        assertEquals("b=-1,", buffer.toString());
    }

    public void testAppendChar() {
        ToStringStyle style = new StyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "c", 'x');
        assertEquals("c=x,", buffer.toString());
    }

    public void testAppendDouble() {
        ToStringStyle style = new StyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "d", 1.5d);
        assertEquals("d=1.5,", buffer.toString());
    }

    public void testAppendFloat() {
        ToStringStyle style = new StyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "f", 2.5f);
        assertEquals("f=2.5,", buffer.toString());
    }

    public void testAppendBoolean() {
        ToStringStyle style = new StyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "bool", true);
        assertEquals("bool=true,", buffer.toString());
    }

    //-----------------------------------------------------------------------
    // Array append methods
    //-----------------------------------------------------------------------

    public void testAppendObjectArrayDetail() {
        ToStringStyle style = new StyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", new String[] {"a", "b"}, Boolean.TRUE);
        assertEquals("arr={a,b},", buffer.toString());
    }

    public void testAppendObjectArraySummary() {
        ToStringStyle style = new StyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", new String[] {"a", "b", "c"}, Boolean.FALSE);
        assertEquals("arr=<size=3>,", buffer.toString());
    }

    public void testAppendObjectArrayNull() {
        ToStringStyle style = new StyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", (Object[]) null, Boolean.TRUE);
        assertEquals("arr=<null>,", buffer.toString());
    }

    public void testAppendIntArrayDetail() {
        ToStringStyle style = new StyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", new int[] {1, 2, 3}, Boolean.TRUE);
        assertEquals("arr={1,2,3},", buffer.toString());
    }

    public void testAppendIntArraySummary() {
        ToStringStyle style = new StyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", new int[] {1, 2, 3}, Boolean.FALSE);
        assertEquals("arr=<size=3>,", buffer.toString());
    }

    public void testAppendIntArrayNull() {
        ToStringStyle style = new StyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", (int[]) null, Boolean.TRUE);
        assertEquals("arr=<null>,", buffer.toString());
    }

    public void testAppendLongArrayDetail() {
        ToStringStyle style = new StyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", new long[] {1L, 2L}, Boolean.TRUE);
        assertEquals("arr={1,2},", buffer.toString());
    }

    public void testAppendShortArrayDetail() {
        ToStringStyle style = new StyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", new short[] {1, 2}, Boolean.TRUE);
        assertEquals("arr={1,2},", buffer.toString());
    }

    public void testAppendByteArrayDetail() {
        ToStringStyle style = new StyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", new byte[] {1, 2}, Boolean.TRUE);
        assertEquals("arr={1,2},", buffer.toString());
    }

    public void testAppendCharArrayDetail() {
        ToStringStyle style = new StyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", new char[] {'x', 'y'}, Boolean.TRUE);
        assertEquals("arr={x,y},", buffer.toString());
    }

    public void testAppendDoubleArrayDetail() {
        ToStringStyle style = new StyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", new double[] {1.0, 2.0}, Boolean.TRUE);
        assertEquals("arr={1.0,2.0},", buffer.toString());
    }

    public void testAppendFloatArrayDetail() {
        ToStringStyle style = new StyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", new float[] {1.0f, 2.0f}, Boolean.TRUE);
        assertEquals("arr={1.0,2.0},", buffer.toString());
    }

    public void testAppendBooleanArrayDetail() {
        ToStringStyle style = new StyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", new boolean[] {true, false}, Boolean.TRUE);
        assertEquals("arr={true,false},", buffer.toString());
    }

    public void testAppendEmptyArrayDetail() {
        ToStringStyle style = new StyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", new int[0], Boolean.TRUE);
        assertEquals("arr={},", buffer.toString());
    }

    //-----------------------------------------------------------------------
    // appendInternal routing for Collection and Map via the generic Object append
    //-----------------------------------------------------------------------

    public void testAppendCollectionDetail() {
        ToStringStyle style = new StyleImpl();
        StringBuffer buffer = new StringBuffer();
        List<String> list = new ArrayList<String>();
        list.add("a");
        list.add("b");
        style.append(buffer, "coll", list, Boolean.TRUE);
        assertEquals("coll=[a, b],", buffer.toString());
    }

    public void testAppendCollectionSummary() {
        ToStringStyle style = new StyleImpl();
        StringBuffer buffer = new StringBuffer();
        List<String> list = new ArrayList<String>();
        list.add("a");
        list.add("b");
        list.add("c");
        style.append(buffer, "coll", list, Boolean.FALSE);
        assertEquals("coll=<size=3>,", buffer.toString());
    }

    //-----------------------------------------------------------------------
    // appendStart / appendEnd / appendToString / appendSuper
    //-----------------------------------------------------------------------

    public void testAppendStartAndEnd() {
        ToStringStyle style = new StyleImpl();
        StringBuffer buffer = new StringBuffer();
        String value = "someObject";
        style.appendStart(buffer, value);
        String afterStart = buffer.toString();
        assertTrue(afterStart.startsWith(value.getClass().getName() + "@"));
        assertTrue(afterStart.endsWith("["));
        style.append(buffer, "f", "v", Boolean.TRUE);
        style.appendEnd(buffer, value);
        String result = buffer.toString();
        assertTrue(result.endsWith("]"));
        assertFalse(result.endsWith(",]"));
        assertTrue(result.indexOf("f=v") >= 0);
    }

    public void testAppendStartNullObject() {
        ToStringStyle style = new StyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.appendStart(buffer, null);
        assertEquals("", buffer.toString());
    }

    public void testAppendEndRemovesTrailingSeparator() {
        ToStringStyle style = new StyleImpl();
        StringBuffer buffer = new StringBuffer();
        buffer.append("abc,");
        style.appendEnd(buffer, "x");
        assertEquals("abc]", buffer.toString());
    }

    public void testAppendEndFieldSeparatorAtEnd() {
        ToStringStyle style = new StyleImpl();
        style.setFieldSeparatorAtEnd(true);
        StringBuffer buffer = new StringBuffer();
        buffer.append("abc,");
        style.appendEnd(buffer, "x");
        assertEquals("abc,]", buffer.toString());
    }

    public void testAppendToStringMergesContent() {
        ToStringStyle style = new StyleImpl();
        StringBuffer buffer = new StringBuffer();
        buffer.append("Outer@1[outerField=1,");
        style.appendToString(buffer, "Inner@2[innerField=2]");
        assertEquals("Outer@1[outerField=1,innerField=2,", buffer.toString());
    }

    public void testAppendToStringNullIgnored() {
        ToStringStyle style = new StyleImpl();
        StringBuffer buffer = new StringBuffer();
        buffer.append("existing");
        style.appendToString(buffer, null);
        assertEquals("existing", buffer.toString());
    }

    public void testAppendToStringMalformedIgnored() {
        ToStringStyle style = new StyleImpl();
        StringBuffer buffer = new StringBuffer();
        buffer.append("existing");
        style.appendToString(buffer, "no brackets here");
        assertEquals("existing", buffer.toString());
    }

    public void testAppendSuperNullIgnored() {
        ToStringStyle style = new StyleImpl();
        StringBuffer buffer = new StringBuffer();
        buffer.append("existing");
        style.appendSuper(buffer, null);
        assertEquals("existing", buffer.toString());
    }

    public void testAppendSuperDelegatesToAppendToString() {
        ToStringStyle style = new StyleImpl();
        StringBuffer buffer = new StringBuffer();
        buffer.append("Outer@1[");
        style.appendSuper(buffer, "Super@2[superField=9]");
        assertEquals("Outer@1[superField=9,", buffer.toString());
    }

    //-----------------------------------------------------------------------
    // Cyclic reference detection
    //-----------------------------------------------------------------------

    public void testSelfReferencingArrayDoesNotRecurseInfinitely() {
        ToStringStyle style = new StyleImpl();
        StringBuffer buffer = new StringBuffer();
        Object[] array = new Object[1];
        array[0] = array;
        style.append(buffer, "cyclic", array, Boolean.TRUE);
        String result = buffer.toString();
        assertTrue(result.startsWith("cyclic={"));
        assertTrue(result.indexOf('@') >= 0);
        assertTrue(result.endsWith("},"));
    }

    public void testRegisterIsRegisteredUnregister() {
        Object value = new Object();
        assertFalse(ToStringStyle.isRegistered(value));
        ToStringStyle.register(value);
        assertTrue(ToStringStyle.isRegistered(value));
        ToStringStyle.unregister(value);
        assertFalse(ToStringStyle.isRegistered(value));
    }

    public void testRegisterNullIsNoOp() {
        ToStringStyle.register(null);
        assertFalse(ToStringStyle.isRegistered(null));
        ToStringStyle.unregister(null);
    }

    //-----------------------------------------------------------------------
    // Getters/setters for flags
    //-----------------------------------------------------------------------

    public void testUseClassNameFlag() {
        ToStringStyle style = new StyleImpl();
        style.setUseClassName(false);
        assertFalse(style.isUseClassName());
        StringBuffer buffer = new StringBuffer();
        style.appendClassName(buffer, "value");
        assertEquals("", buffer.toString());
    }

    public void testUseShortClassNameFlag() {
        ToStringStyle style = new StyleImpl();
        style.setUseShortClassName(true);
        assertTrue(style.isUseShortClassName());
        StringBuffer buffer = new StringBuffer();
        Object marker = new Object();
        style.appendClassName(buffer, marker);
        assertEquals("Object", buffer.toString());
        ToStringStyle.unregister(marker);
    }

    public void testUseIdentityHashCodeFlagDisabled() {
        ToStringStyle style = new StyleImpl();
        style.setUseIdentityHashCode(false);
        assertFalse(style.isUseIdentityHashCode());
        StringBuffer buffer = new StringBuffer();
        style.appendIdentityHashCode(buffer, "value");
        assertEquals("", buffer.toString());
    }

    public void testUseIdentityHashCodeFlagEnabled() {
        ToStringStyle style = new StyleImpl();
        Object value = new Object();
        StringBuffer buffer = new StringBuffer();
        style.appendIdentityHashCode(buffer, value);
        assertEquals("@" + Integer.toHexString(System.identityHashCode(value)), buffer.toString());
        ToStringStyle.unregister(value);
    }

    public void testArrayContentDetailFlag() {
        ToStringStyle style = new StyleImpl();
        assertTrue(style.isArrayContentDetail());
        style.setArrayContentDetail(false);
        assertFalse(style.isArrayContentDetail());
    }

    public void testDefaultFullDetailFlag() {
        ToStringStyle style = new StyleImpl();
        assertTrue(style.isDefaultFullDetail());
        style.setDefaultFullDetail(false);
        assertFalse(style.isDefaultFullDetail());
    }

    public void testFieldSeparatorAtStartFlag() {
        ToStringStyle style = new StyleImpl();
        assertFalse(style.isFieldSeparatorAtStart());
        style.setFieldSeparatorAtStart(true);
        assertTrue(style.isFieldSeparatorAtStart());
    }

    public void testFieldSeparatorAtEndFlag() {
        ToStringStyle style = new StyleImpl();
        assertFalse(style.isFieldSeparatorAtEnd());
        style.setFieldSeparatorAtEnd(true);
        assertTrue(style.isFieldSeparatorAtEnd());
    }

    public void testIsFullDetailNullUsesDefault() {
        ToStringStyle style = new StyleImpl();
        assertTrue(style.isFullDetail(null));
        style.setDefaultFullDetail(false);
        assertFalse(style.isFullDetail(null));
    }

    public void testIsFullDetailExplicit() {
        ToStringStyle style = new StyleImpl();
        style.setDefaultFullDetail(false);
        assertTrue(style.isFullDetail(Boolean.TRUE));
        style.setDefaultFullDetail(true);
        assertFalse(style.isFullDetail(Boolean.FALSE));
    }

    public void testGetShortClassName() {
        ToStringStyle style = new StyleImpl();
        assertEquals("String", style.getShortClassName(String.class));
    }

    //-----------------------------------------------------------------------
    // Static singleton styles
    //-----------------------------------------------------------------------

    public void testSingletonStylesAreNotNullAndDistinct() {
        assertNotNull(ToStringStyle.DEFAULT_STYLE);
        assertNotNull(ToStringStyle.MULTI_LINE_STYLE);
        assertNotNull(ToStringStyle.NO_FIELD_NAMES_STYLE);
        assertNotNull(ToStringStyle.SHORT_PREFIX_STYLE);
        assertNotNull(ToStringStyle.SIMPLE_STYLE);
        assertNotSame(ToStringStyle.DEFAULT_STYLE, ToStringStyle.MULTI_LINE_STYLE);
        assertNotSame(ToStringStyle.NO_FIELD_NAMES_STYLE, ToStringStyle.SHORT_PREFIX_STYLE);
    }

    public void testDefaultStyleSerializationResolvesToSingleton() throws Exception {
        ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
        ObjectOutputStream out = new ObjectOutputStream(byteOut);
        out.writeObject(ToStringStyle.DEFAULT_STYLE);
        out.close();
        ObjectInputStream in = new ObjectInputStream(new ByteArrayInputStream(byteOut.toByteArray()));
        Object result = in.readObject();
        in.close();
        assertSame(ToStringStyle.DEFAULT_STYLE, result);
    }

    public void testNoFieldNamesStyleBehavior() {
        StringBuffer buffer = new StringBuffer();
        ToStringStyle.NO_FIELD_NAMES_STYLE.append(buffer, "name", "value", Boolean.TRUE);
        assertEquals("value,", buffer.toString());
    }

    public void testSimpleStyleBehavior() {
        StringBuffer buffer = new StringBuffer();
        ToStringStyle.SIMPLE_STYLE.appendStart(buffer, "obj");
        ToStringStyle.SIMPLE_STYLE.append(buffer, "name", "value", Boolean.TRUE);
        ToStringStyle.SIMPLE_STYLE.appendEnd(buffer, "obj");
        assertEquals("value", buffer.toString());
    }
}
