package com.google.gson.stream;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;

import org.junit.Test;

/**
 * Self-contained tests for {@link JsonReader} based solely on the documented
 * contract in the generated javadoc under api/.
 */
public class JsonReaderAgentTest {

    private static JsonReader reader(String json) {
        return new JsonReader(new StringReader(json));
    }

    // ---- structural tokens: empty array / object ----

    @Test
    public void testEmptyArray() throws IOException {
        JsonReader r = reader("[]");
        r.beginArray();
        assertFalse(r.hasNext());
        assertEquals(JsonToken.END_ARRAY, r.peek());
        r.endArray();
        r.close();
    }

    @Test
    public void testEmptyObject() throws IOException {
        JsonReader r = reader("{}");
        r.beginObject();
        assertFalse(r.hasNext());
        assertEquals(JsonToken.END_OBJECT, r.peek());
        r.endObject();
        r.close();
    }

    // ---- primitive values inside an array, including peek() typing ----

    @Test
    public void testArrayOfPrimitives() throws IOException {
        JsonReader r = reader("[true,false,null,\"hello\",42,3.14]");
        r.beginArray();

        assertEquals(JsonToken.BOOLEAN, r.peek());
        assertTrue(r.nextBoolean());

        assertEquals(JsonToken.BOOLEAN, r.peek());
        assertFalse(r.nextBoolean());

        assertEquals(JsonToken.NULL, r.peek());
        r.nextNull();

        assertEquals(JsonToken.STRING, r.peek());
        assertEquals("hello", r.nextString());

        assertEquals(JsonToken.NUMBER, r.peek());
        assertEquals(42, r.nextInt());

        assertEquals(JsonToken.NUMBER, r.peek());
        assertEquals(3.14, r.nextDouble(), 0.0001);

        assertFalse(r.hasNext());
        r.endArray();
        r.close();
    }

    // ---- object with name/value pairs ----

    @Test
    public void testObjectNameValuePairs() throws IOException {
        JsonReader r = reader("{\"a\":1,\"b\":\"two\"}");
        r.beginObject();

        assertTrue(r.hasNext());
        assertEquals(JsonToken.NAME, r.peek());
        assertEquals("a", r.nextName());
        assertEquals(1, r.nextInt());

        assertTrue(r.hasNext());
        assertEquals("b", r.nextName());
        assertEquals("two", r.nextString());

        assertFalse(r.hasNext());
        r.endObject();
        r.close();
    }

    @Test
    public void testNestedArrayInsideObject() throws IOException {
        JsonReader r = reader("{\"items\":[1,2,3]}");
        r.beginObject();
        assertEquals("items", r.nextName());

        r.beginArray();
        assertEquals(1, r.nextInt());
        assertEquals(2, r.nextInt());
        assertEquals(3, r.nextInt());
        r.endArray();

        r.endObject();
        r.close();
    }

    // ---- number/string interchangeability, per class-level documentation ----

    @Test
    public void testNumberTokenReadAsString() throws IOException {
        JsonReader r = reader("[123]");
        r.beginArray();
        assertEquals("123", r.nextString());
        r.endArray();
    }

    @Test
    public void testStringTokenReadAsInt() throws IOException {
        JsonReader r = reader("[\"42\"]");
        r.beginArray();
        assertEquals(42, r.nextInt());
        r.endArray();
    }

    @Test
    public void testStringTokenReadAsDouble() throws IOException {
        JsonReader r = reader("[\"3.14\"]");
        r.beginArray();
        assertEquals(3.14, r.nextDouble(), 0.0001);
        r.endArray();
    }

    @Test
    public void testNextLong_maxValue() throws IOException {
        JsonReader r = reader("[9223372036854775807]");
        r.beginArray();
        assertEquals(Long.MAX_VALUE, r.nextLong());
        r.endArray();
    }

    @Test
    public void testNextInt_negativeValue() throws IOException {
        JsonReader r = reader("[-5]");
        r.beginArray();
        assertEquals(-5, r.nextInt());
        r.endArray();
    }

    // ---- NumberFormatException cases, documented on nextInt/nextLong/nextDouble ----

    @Test
    public void testNextInt_valueOutOfIntRange_throwsNumberFormatException() throws IOException {
        JsonReader r = reader("[99999999999]");
        r.beginArray();
        try {
            r.nextInt();
            fail("Expected NumberFormatException");
        } catch (NumberFormatException expected) {
            // documented: thrown when the value cannot be exactly represented as an int
        }
    }

    @Test
    public void testNextLong_nonIntegerValue_throwsNumberFormatException() throws IOException {
        JsonReader r = reader("[1.5]");
        r.beginArray();
        try {
            r.nextLong();
            fail("Expected NumberFormatException");
        } catch (NumberFormatException expected) {
            // documented: thrown when the value cannot be exactly represented as a long
        }
    }

    // @Test  // pruned: failed on the fixed version
    public void testNextDouble_nonFiniteString_throwsNumberFormatException() throws IOException {
        JsonReader r = reader("[\"NaN\"]");
        r.beginArray();
        try {
            r.nextDouble();
            fail("Expected NumberFormatException");
        } catch (NumberFormatException expected) {
            // documented: thrown when the literal value is non-finite
        }
    }

    @Test
    public void testNextDouble_malformedString_throwsNumberFormatException() throws IOException {
        JsonReader r = reader("[\"notANumber\"]");
        r.beginArray();
        try {
            r.nextDouble();
            fail("Expected NumberFormatException");
        } catch (NumberFormatException expected) {
            // documented: thrown when the literal value cannot be parsed as a double
        }
    }

    // ---- IllegalStateException cases, documented on next* accessors ----

    @Test
    public void testNextString_wrongType_throwsIllegalStateException() throws IOException {
        JsonReader r = reader("[true]");
        r.beginArray();
        try {
            r.nextString();
            fail("Expected IllegalStateException");
        } catch (IllegalStateException expected) {
            // documented: thrown when the next token is not a string
        }
    }

    @Test
    public void testNextBoolean_wrongType_throwsIllegalStateException() throws IOException {
        JsonReader r = reader("[\"x\"]");
        r.beginArray();
        try {
            r.nextBoolean();
            fail("Expected IllegalStateException");
        } catch (IllegalStateException expected) {
            // documented: thrown when the next token is not a boolean
        }
    }

    @Test
    public void testNextNull_wrongType_throwsIllegalStateException() throws IOException {
        JsonReader r = reader("[1]");
        r.beginArray();
        try {
            r.nextNull();
            fail("Expected IllegalStateException");
        } catch (IllegalStateException expected) {
            // documented: thrown when the next token is not null
        }
    }

    @Test
    public void testNextDouble_wrongType_throwsIllegalStateException() throws IOException {
        JsonReader r = reader("[{}]");
        r.beginArray();
        try {
            r.nextDouble();
            fail("Expected IllegalStateException");
        } catch (IllegalStateException expected) {
            // documented: thrown when the next token is not a literal value
        }
    }

    @Test
    public void testNextLong_wrongType_throwsIllegalStateException() throws IOException {
        JsonReader r = reader("[[]]");
        r.beginArray();
        try {
            r.nextLong();
            fail("Expected IllegalStateException");
        } catch (IllegalStateException expected) {
            // documented: thrown when the next token is not a literal value
        }
    }

    @Test
    public void testNextString_afterClose_throwsIllegalStateException() throws IOException {
        JsonReader r = reader("[\"x\"]");
        r.close();
        try {
            r.nextString();
            fail("Expected IllegalStateException");
        } catch (IllegalStateException expected) {
            // documented: thrown when this reader is closed
        }
    }

    @Test
    public void testNextBoolean_afterClose_throwsIllegalStateException() throws IOException {
        JsonReader r = reader("[true]");
        r.close();
        try {
            r.nextBoolean();
            fail("Expected IllegalStateException");
        } catch (IllegalStateException expected) {
            // documented: thrown when this reader is closed
        }
    }

    // ---- nextName() contract ----

    // @Test  // pruned: failed on the fixed version
    public void testNextName_notAPropertyName_throwsIOException() throws IOException {
        JsonReader r = reader("[1]");
        r.beginArray();
        try {
            r.nextName();
            fail("Expected IOException");
        } catch (IOException expected) {
            // documented: thrown if the next token in the stream is not a property name
        }
    }

    // ---- structural mismatch: begin/end assert the expected delimiter ----

    @Test(expected = Exception.class)
    public void testBeginObject_onArray_throwsException() throws IOException {
        JsonReader r = reader("[]");
        r.beginObject();
    }

    @Test(expected = Exception.class)
    public void testBeginArray_onObject_throwsException() throws IOException {
        JsonReader r = reader("{}");
        r.beginArray();
    }

    @Test(expected = Exception.class)
    public void testEndArray_beforeArrayExhausted_throwsException() throws IOException {
        JsonReader r = reader("[1,2]");
        r.beginArray();
        r.endArray();
    }

    @Test(expected = Exception.class)
    public void testEndObject_onNonEmptyObject_throwsException() throws IOException {
        JsonReader r = reader("{\"a\":1}");
        r.beginObject();
        r.endObject();
    }

    // ---- lenient mode, per setLenient()/isLenient() documentation ----

    @Test
    public void testIsLenient_defaultsToFalse() throws IOException {
        JsonReader r = reader("[]");
        assertFalse(r.isLenient());
    }

    @Test
    public void testSetLenient_togglesIsLenient() throws IOException {
        JsonReader r = reader("[]");
        r.setLenient(true);
        assertTrue(r.isLenient());
        r.setLenient(false);
        assertFalse(r.isLenient());
    }

    // @Test  // pruned: failed on the fixed version
    public void testTopLevelStringValue_strict_throwsIOException() throws IOException {
        JsonReader r = reader("\"hello\"");
        try {
            r.nextString();
            fail("Expected IOException because top level value is not an object or array");
        } catch (IOException expected) {
            // documented: strict parsing requires the top-level value to be an object or array
        }
    }

    @Test
    public void testTopLevelStringValue_lenient_isAllowed() throws IOException {
        JsonReader r = reader("\"hello\"");
        r.setLenient(true);
        assertEquals("hello", r.nextString());
    }

    @Test
    public void testNonExecutePrefix_strict_throwsIOException() throws IOException {
        JsonReader r = reader(")]}'\n[1,2,3]");
        try {
            r.beginArray();
            fail("Expected IOException because the non-execute prefix is malformed JSON");
        } catch (IOException expected) {
            // documented: strict parsing fails when the non-execute prefix is encountered
        }
    }

    @Test
    public void testNonExecutePrefix_lenient_isSkipped() throws IOException {
        JsonReader r = reader(")]}'\n[1,2,3]");
        r.setLenient(true);
        r.beginArray();
        assertEquals(1, r.nextInt());
        assertEquals(2, r.nextInt());
        assertEquals(3, r.nextInt());
        r.endArray();
    }

    // ---- skipValue() ----

    @Test
    public void testSkipValue_skipsNestedArray() throws IOException {
        JsonReader r = reader("[1,2,[3,4],5]");
        r.beginArray();
        assertEquals(1, r.nextInt());
        assertEquals(2, r.nextInt());
        r.skipValue();
        assertEquals(5, r.nextInt());
        r.endArray();
    }

    @Test
    public void testSkipValue_skipsNestedObject() throws IOException {
        JsonReader r = reader("[\"a\",{\"x\":1,\"y\":[1,2,3]},\"b\"]");
        r.beginArray();
        assertEquals("a", r.nextString());
        r.skipValue();
        assertEquals("b", r.nextString());
        r.endArray();
    }

    // ---- end of document ----

    @Test
    public void testPeek_atEndOfDocument_returnsEndDocument() throws IOException {
        JsonReader r = reader("[]");
        r.beginArray();
        r.endArray();
        assertEquals(JsonToken.END_DOCUMENT, r.peek());
    }

    // ---- close() documented to close the underlying Reader ----

    @Test
    public void testClose_closesUnderlyingReader() throws IOException {
        final boolean[] closed = {false};
        Reader underlying = new StringReader("[]") {
            public void close() {
                closed[0] = true;
                super.close();
            }
        };
        JsonReader r = new JsonReader(underlying);
        r.close();
        assertTrue(closed[0]);
    }

    // ---- getPath() / toString() : no format is specified, only non-null is implied ----

    @Test
    public void testGetPath_isNeverNull() throws IOException {
        JsonReader r = reader("{\"a\":[1,2]}");
        assertNotNull(r.getPath());
        r.beginObject();
        r.nextName();
        r.beginArray();
        r.nextInt();
        assertNotNull(r.getPath());
        r.nextInt();
        r.endArray();
        r.endObject();
    }

    @Test
    public void testToString_isNeverNull() throws IOException {
        JsonReader r = reader("[]");
        assertNotNull(r.toString());
    }
}
