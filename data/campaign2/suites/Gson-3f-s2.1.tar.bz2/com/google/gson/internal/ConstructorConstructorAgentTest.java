package com.google.gson.internal;

import com.google.gson.InstanceCreator;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import junit.framework.TestCase;

/**
 * Self-contained JUnit 3 test for {@link ConstructorConstructor}.
 */
public class ConstructorConstructorAgentTest extends TestCase {

    // ---- fixtures ----------------------------------------------------

    public static class SimplePojo {
        public SimplePojo() {
        }
    }

    public static class PrivateCtorPojo {
        public int marker = 0;

        private PrivateCtorPojo() {
            marker = 42;
        }
    }

    public interface NoImplInterface {
        void doSomething();
    }

    private static Map<Type, InstanceCreator<?>> emptyCreators() {
        return new HashMap<Type, InstanceCreator<?>>();
    }

    // ---- basic reflection construction --------------------------------

    public void testGetReturnsNonNullConstructorForSimpleClass() {
        ConstructorConstructor cc = new ConstructorConstructor(emptyCreators());
        ObjectConstructor<SimplePojo> ctor = cc.get(TypeToken.get(SimplePojo.class));
        assertNotNull(ctor);
    }

    public void testConstructProducesInstanceOfRequestedType() {
        ConstructorConstructor cc = new ConstructorConstructor(emptyCreators());
        ObjectConstructor<SimplePojo> ctor = cc.get(TypeToken.get(SimplePojo.class));
        SimplePojo instance = ctor.construct();
        assertNotNull(instance);
        assertEquals(SimplePojo.class, instance.getClass());
    }

    public void testConstructCalledTwiceReturnsDistinctInstances() {
        ConstructorConstructor cc = new ConstructorConstructor(emptyCreators());
        ObjectConstructor<SimplePojo> ctor = cc.get(TypeToken.get(SimplePojo.class));
        SimplePojo first = ctor.construct();
        SimplePojo second = ctor.construct();
        assertNotNull(first);
        assertNotNull(second);
        assertNotSame(first, second);
    }

    public void testConstructInvokesPrivateNoArgConstructor() {
        ConstructorConstructor cc = new ConstructorConstructor(emptyCreators());
        ObjectConstructor<PrivateCtorPojo> ctor = cc.get(TypeToken.get(PrivateCtorPojo.class));
        PrivateCtorPojo instance = ctor.construct();
        assertNotNull(instance);
        // marker is only set inside the constructor body, so observing 42
        // proves the declared (private) constructor actually ran.
        assertEquals(42, instance.marker);
    }

    // ---- default implementations for common interfaces -----------------

    public void testListInterfaceGetsWorkingDefaultImplementation() {
        ConstructorConstructor cc = new ConstructorConstructor(emptyCreators());
        ObjectConstructor<List> ctor = cc.get(TypeToken.get(List.class));
        List list = ctor.construct();
        assertNotNull(list);
        assertTrue(list.isEmpty());
        list.add("value");
        assertEquals(1, list.size());
        assertEquals("value", list.get(0));
    }

    public void testMapInterfaceGetsWorkingDefaultImplementation() {
        ConstructorConstructor cc = new ConstructorConstructor(emptyCreators());
        ObjectConstructor<Map> ctor = cc.get(TypeToken.get(Map.class));
        Map map = ctor.construct();
        assertNotNull(map);
        assertTrue(map.isEmpty());
        map.put("key", "value");
        assertEquals("value", map.get("key"));
    }

    public void testSetInterfaceGetsWorkingDefaultImplementation() {
        ConstructorConstructor cc = new ConstructorConstructor(emptyCreators());
        ObjectConstructor<Set> ctor = cc.get(TypeToken.get(Set.class));
        Set set = ctor.construct();
        assertNotNull(set);
        assertTrue(set.isEmpty());
        set.add("value");
        assertTrue(set.contains("value"));
    }

    // ---- registered InstanceCreator overrides reflection ----------------

    public void testRegisteredInstanceCreatorIsUsedInsteadOfReflection() {
        final SimplePojo marker = new SimplePojo();
        Map<Type, InstanceCreator<?>> creators = emptyCreators();
        creators.put(SimplePojo.class, new InstanceCreator<SimplePojo>() {
            public SimplePojo createInstance(Type type) {
                return marker;
            }
        });

        ConstructorConstructor cc = new ConstructorConstructor(creators);
        ObjectConstructor<SimplePojo> ctor = cc.get(TypeToken.get(SimplePojo.class));
        SimplePojo result = ctor.construct();

        assertSame(marker, result);
    }

    public void testRegisteredInstanceCreatorMayReturnNull() {
        Map<Type, InstanceCreator<?>> creators = emptyCreators();
        creators.put(SimplePojo.class, new InstanceCreator<SimplePojo>() {
            public SimplePojo createInstance(Type type) {
                return null;
            }
        });

        ConstructorConstructor cc = new ConstructorConstructor(creators);
        ObjectConstructor<SimplePojo> ctor = cc.get(TypeToken.get(SimplePojo.class));

        assertNull(ctor.construct());
    }

    public void testInstanceCreatorForUnrelatedTypeDoesNotAffectOtherTypes() {
        Map<Type, InstanceCreator<?>> creators = emptyCreators();
        creators.put(PrivateCtorPojo.class, new InstanceCreator<PrivateCtorPojo>() {
            public PrivateCtorPojo createInstance(Type type) {
                fail("creator for an unrelated type must not be invoked");
                return null;
            }
        });

        ConstructorConstructor cc = new ConstructorConstructor(creators);
        ObjectConstructor<SimplePojo> ctor = cc.get(TypeToken.get(SimplePojo.class));
        SimplePojo result = ctor.construct();

        assertNotNull(result);
        assertEquals(SimplePojo.class, result.getClass());
    }

    // ---- error / boundary cases -----------------------------------------

    public void testGetDoesNotThrowForUnconstructableInterface() {
        ConstructorConstructor cc = new ConstructorConstructor(emptyCreators());
        // get() only hands back a factory; it must not eagerly fail even
        // though the type can never actually be instantiated.
        ObjectConstructor<NoImplInterface> ctor = cc.get(TypeToken.get(NoImplInterface.class));
        assertNotNull(ctor);
    }

    public void testConstructFailsForInterfaceWithoutKnownImplementationOrCreator() {
        ConstructorConstructor cc = new ConstructorConstructor(emptyCreators());
        ObjectConstructor<NoImplInterface> ctor = cc.get(TypeToken.get(NoImplInterface.class));
        try {
            ctor.construct();
            fail("expected a RuntimeException since no interface implementation is known");
        } catch (RuntimeException expected) {
            // a Java interface has no instantiable form, so the only way the
            // class can honor "construct an instance of a requested type" is
            // to signal failure instead of returning an instance
        }
    }

    public void testEmptyInstanceCreatorsMapIsAccepted() {
        ConstructorConstructor cc = new ConstructorConstructor(new HashMap<Type, InstanceCreator<?>>());
        ObjectConstructor<SimplePojo> ctor = cc.get(TypeToken.get(SimplePojo.class));
        assertNotNull(ctor.construct());
    }

    // ---- toString --------------------------------------------------------

    public void testToStringReturnsNonNullString() {
        ConstructorConstructor cc = new ConstructorConstructor(emptyCreators());
        String s = cc.toString();
        assertNotNull(s);
    }

    public void testToStringIsConsistentAcrossCalls() {
        ConstructorConstructor cc = new ConstructorConstructor(emptyCreators());
        assertEquals(cc.toString(), cc.toString());
    }
}
