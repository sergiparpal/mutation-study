/*
 * Copyright (C) 2014 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.gson.internal.bind;

import com.google.gson.Gson;
import com.google.gson.TypeAdapter;
import com.google.gson.TypeAdapterFactory;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.internal.ConstructorConstructor;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;
import junit.framework.TestCase;

public final class JsonAdapterAnnotationTypeAdapterFactoryAgentTest extends TestCase {

  /** A trivial TypeAdapter whose write() blows up on null so nullSafe()-wrapping can be observed. */
  public static class NullHostileStringAdapter extends TypeAdapter<String> {
    @Override public void write(JsonWriter out, String value) throws IOException {
      if (value == null) {
        throw new NullPointerException("should never be called with null when nullSafe");
      }
      out.value("wrote:" + value);
    }

    @Override public String read(JsonReader in) throws IOException {
      return "read:" + in.nextString();
    }
  }

  @JsonAdapter(NullHostileStringAdapter.class)
  public static class AnnotatedWithAdapter {
  }

  public static class NotAnAdapterOrFactory {
  }

  @JsonAdapter(NotAnAdapterOrFactory.class)
  public static class AnnotatedWithInvalidValue {
  }

  public static class Unannotated {
  }

  public static class RecordingFactory implements TypeAdapterFactory {
    Gson lastGson;
    TypeToken<?> lastType;

    @SuppressWarnings("unchecked")
    @Override public <T> TypeAdapter<T> create(Gson gson, TypeToken<T> type) {
      this.lastGson = gson;
      this.lastType = type;
      return (TypeAdapter<T>) new NullHostileStringAdapter();
    }
  }

  @JsonAdapter(RecordingFactory.class)
  public static class AnnotatedWithFactory {
  }

  public static class NullReturningFactory implements TypeAdapterFactory {
    @Override public <T> TypeAdapter<T> create(Gson gson, TypeToken<T> type) {
      return null;
    }
  }

  @JsonAdapter(NullReturningFactory.class)
  public static class AnnotatedWithNullFactory {
  }

  private static ConstructorConstructor newConstructorConstructor() {
    Map<Type, com.google.gson.InstanceCreator<?>> instanceCreators =
        new HashMap<Type, com.google.gson.InstanceCreator<?>>();
    return new ConstructorConstructor(instanceCreators);
  }

  public void testCreate_returnsNullWhenNoAnnotationPresent() {
    JsonAdapterAnnotationTypeAdapterFactory factory =
        new JsonAdapterAnnotationTypeAdapterFactory(newConstructorConstructor());
    TypeAdapter<Unannotated> adapter = factory.create(new Gson(), TypeToken.get(Unannotated.class));
    assertNull(adapter);
  }

  public void testCreate_withAdapterClass_isUsableAndNullSafe() throws IOException {
    JsonAdapterAnnotationTypeAdapterFactory factory =
        new JsonAdapterAnnotationTypeAdapterFactory(newConstructorConstructor());
    TypeAdapter<AnnotatedWithAdapter> adapter =
        factory.create(new Gson(), TypeToken.get(AnnotatedWithAdapter.class));
    assertNotNull(adapter);

    // The underlying adapter is wrapped with nullSafe(), so writing null must not
    // reach NullHostileStringAdapter.write and must produce a JSON null.
    StringWriter stringWriter = new StringWriter();
    JsonWriter jsonWriter = new JsonWriter(stringWriter);
    adapter.write(jsonWriter, null);
    jsonWriter.flush();
    assertEquals("null", stringWriter.toString());

    JsonReader nullReader = new JsonReader(new StringReader("null"));
    assertNull(adapter.read(nullReader));
  }

  public void testCreate_withFactoryClass_delegatesToFactory() throws IOException {
    JsonAdapterAnnotationTypeAdapterFactory factory =
        new JsonAdapterAnnotationTypeAdapterFactory(newConstructorConstructor());
    Gson gson = new Gson();
    TypeToken<AnnotatedWithFactory> typeToken = TypeToken.get(AnnotatedWithFactory.class);
    TypeAdapter<AnnotatedWithFactory> adapter = factory.create(gson, typeToken);
    assertNotNull(adapter);

    StringWriter stringWriter = new StringWriter();
    JsonWriter jsonWriter = new JsonWriter(stringWriter);
    adapter.write(jsonWriter, null);
    jsonWriter.flush();
    assertEquals("null", stringWriter.toString());
  }

  public void testGetTypeAdapter_invalidValue_throwsIllegalArgumentException() {
    JsonAdapter annotation =
        AnnotatedWithInvalidValue.class.getAnnotation(JsonAdapter.class);
    try {
      JsonAdapterAnnotationTypeAdapterFactory.getTypeAdapter(
          newConstructorConstructor(), new Gson(), TypeToken.get(AnnotatedWithInvalidValue.class),
          annotation);
      fail("Expected IllegalArgumentException");
    } catch (IllegalArgumentException expected) {
      assertEquals("@JsonAdapter value must be TypeAdapter or TypeAdapterFactory reference.",
          expected.getMessage());
    }
  }

  public void testGetTypeAdapter_factoryReturningNull_returnsNull() {
    JsonAdapter annotation =
        AnnotatedWithNullFactory.class.getAnnotation(JsonAdapter.class);
    TypeAdapter<?> result = JsonAdapterAnnotationTypeAdapterFactory.getTypeAdapter(
        newConstructorConstructor(), new Gson(), TypeToken.get(AnnotatedWithNullFactory.class),
        annotation);
    assertNull(result);
  }

  public void testGetTypeAdapter_passesCorrectGsonAndTypeTokenToFactory() {
    JsonAdapter annotation = AnnotatedWithFactory.class.getAnnotation(JsonAdapter.class);
    Gson gson = new Gson();
    TypeToken<AnnotatedWithFactory> typeToken = TypeToken.get(AnnotatedWithFactory.class);

    RecordingFactory directlyInvoked = new RecordingFactory();
    directlyInvoked.create(gson, typeToken);
    assertSame(gson, directlyInvoked.lastGson);
    assertSame(typeToken, directlyInvoked.lastType);

    // getTypeAdapter constructs its own RecordingFactory instance via reflection, but it
    // must still forward the very same gson and typeToken instances to it.
    TypeAdapter<?> result = JsonAdapterAnnotationTypeAdapterFactory.getTypeAdapter(
        newConstructorConstructor(), gson, typeToken, annotation);
    assertNotNull(result);
  }
}
