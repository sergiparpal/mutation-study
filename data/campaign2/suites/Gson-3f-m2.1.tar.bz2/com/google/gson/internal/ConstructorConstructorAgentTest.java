/*
 * Copyright (C) 2024 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.google.gson.internal;

import com.google.gson.InstanceCreator;
import com.google.gson.JsonIOException;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.Collection;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ConcurrentNavigableMap;
import java.util.concurrent.ConcurrentSkipListMap;

import junit.framework.TestCase;

public class ConstructorConstructorAgentTest extends TestCase {

  private static ConstructorConstructor newEmpty() {
    return new ConstructorConstructor(new HashMap<Type, InstanceCreator<?>>());
  }

  private static ConstructorConstructor newWithCreators(
      Map<Type, InstanceCreator<?>> instanceCreators) {
    return new ConstructorConstructor(instanceCreators);
  }

  // --- Fixtures -------------------------------------------------------

  public static class PublicNoArg {
    boolean marker = true;
  }

  public static class PrivateNoArg {
    private PrivateNoArg() {
    }
  }

  public static class IntArgOnly {
    final int value;

    public IntArgOnly(int value) {
      this.value = value;
    }
  }

  abstract static class AbstractNoArg {
  }

  static class ThrowingNoArgCtor {
    ThrowingNoArgCtor() {
      throw new IllegalStateException("boom");
    }
  }

  interface SomeInterface {
  }

  enum Color {
    RED, GREEN, BLUE
  }

  static class CustomCollection<T> extends java.util.ArrayList<T> {
  }

  // --- InstanceCreator tests -------------------------------------------

  public void testInstanceCreator_exactTypeMatch() {
    final Object fixedInstance = "fixed-list-instance";
    Map<Type, InstanceCreator<?>> creators = new HashMap<Type, InstanceCreator<?>>();
    Type exactType = new TypeToken<List<String>>() {
    }.getType();
    creators.put(exactType, new InstanceCreator<Object>() {
      @Override public Object createInstance(Type type) {
        return fixedInstance;
      }
    });

    ConstructorConstructor cc = newWithCreators(creators);
    Object result = cc.get(new TypeToken<List<String>>() {
    }).construct();

    assertSame(fixedInstance, result);
  }

  public void testInstanceCreator_rawTypeFallback() {
    final Object fixedInstance = new java.util.ArrayList<Object>();
    Map<Type, InstanceCreator<?>> creators = new HashMap<Type, InstanceCreator<?>>();
    creators.put(java.util.ArrayList.class, new InstanceCreator<Object>() {
      @Override public Object createInstance(Type type) {
        return fixedInstance;
      }
    });

    ConstructorConstructor cc = newWithCreators(creators);
    // Exact parameterized type is not registered, only the raw type is.
    Object result = cc.get(new TypeToken<java.util.ArrayList<String>>() {
    }).construct();

    assertSame(fixedInstance, result);
  }

  public void testInstanceCreator_exactTypeTakesPrecedenceOverRawType() {
    final Object exactInstance = new Object();
    final Object rawInstance = new Object();
    Map<Type, InstanceCreator<?>> creators = new HashMap<Type, InstanceCreator<?>>();
    Type exactType = new TypeToken<List<String>>() {
    }.getType();
    creators.put(exactType, new InstanceCreator<Object>() {
      @Override public Object createInstance(Type type) {
        return exactInstance;
      }
    });
    creators.put(List.class, new InstanceCreator<Object>() {
      @Override public Object createInstance(Type type) {
        return rawInstance;
      }
    });

    ConstructorConstructor cc = newWithCreators(creators);
    Object result = cc.get(new TypeToken<List<String>>() {
    }).construct();

    assertSame(exactInstance, result);
  }

  public void testInstanceCreator_receivesRequestedType() {
    Map<Type, InstanceCreator<?>> creators = new HashMap<Type, InstanceCreator<?>>();
    final Type[] capturedType = new Type[1];
    Type exactType = new TypeToken<List<String>>() {
    }.getType();
    creators.put(exactType, new InstanceCreator<Object>() {
      @Override public Object createInstance(Type type) {
        capturedType[0] = type;
        return new java.util.ArrayList<Object>();
      }
    });

    ConstructorConstructor cc = newWithCreators(creators);
    cc.get(new TypeToken<List<String>>() {
    }).construct();

    assertEquals(exactType, capturedType[0]);
  }

  // --- Default no-arg constructor tests --------------------------------

  public void testDefaultConstructor_publicNoArg() {
    ConstructorConstructor cc = newEmpty();
    PublicNoArg instance = cc.get(TypeToken.get(PublicNoArg.class)).construct();

    assertNotNull(instance);
    assertTrue(instance.marker);
  }

  public void testDefaultConstructor_privateNoArgIsMadeAccessible() {
    ConstructorConstructor cc = newEmpty();
    PrivateNoArg instance = cc.get(TypeToken.get(PrivateNoArg.class)).construct();

    assertNotNull(instance);
    assertEquals(PrivateNoArg.class, instance.getClass());
  }

  public void testDefaultConstructor_eachCallCreatesNewInstance() {
    ConstructorConstructor cc = newEmpty();
    ObjectConstructor<PublicNoArg> constructor = cc.get(TypeToken.get(PublicNoArg.class));

    PublicNoArg first = constructor.construct();
    PublicNoArg second = constructor.construct();

    assertNotSame(first, second);
  }

  public void testDefaultConstructor_throwingConstructorWrapsCause() {
    ConstructorConstructor cc = newEmpty();
    ObjectConstructor<ThrowingNoArgCtor> constructor =
        cc.get(TypeToken.get(ThrowingNoArgCtor.class));

    try {
      constructor.construct();
      fail("Expected RuntimeException");
    } catch (RuntimeException expected) {
      assertTrue(expected.getCause() instanceof IllegalStateException);
      assertEquals("boom", expected.getCause().getMessage());
    }
  }

  public void testAbstractClass_constructThrowsRuntimeException() {
    ConstructorConstructor cc = newEmpty();
    ObjectConstructor<AbstractNoArg> constructor = cc.get(TypeToken.get(AbstractNoArg.class));

    try {
      constructor.construct();
      fail("Expected RuntimeException for abstract class instantiation");
    } catch (RuntimeException expected) {
      assertTrue(expected.getCause() instanceof InstantiationException);
    }
  }

  // --- Unsafe allocator fallback tests -----------------------------------

  public void testNoNoArgConstructor_fallsBackToUnsafeAllocator() {
    ConstructorConstructor cc = newEmpty();
    IntArgOnly instance = cc.get(TypeToken.get(IntArgOnly.class)).construct();

    assertNotNull(instance);
    assertEquals(IntArgOnly.class, instance.getClass());
    // Allocated without running the constructor, so the final field keeps the JVM default.
    assertEquals(0, instance.value);
  }

  public void testInterfaceType_constructThrows() {
    ConstructorConstructor cc = newEmpty();
    ObjectConstructor<SomeInterface> constructor = cc.get(TypeToken.get(SomeInterface.class));

    assertNotNull(constructor);
    try {
      constructor.construct();
      fail("Expected an exception when instantiating an interface");
    } catch (RuntimeException expected) {
      // expected: interfaces cannot be allocated
    }
  }

  // --- Collection defaults -----------------------------------------------

  public void testCollectionDefaults_plainCollectionUsesArrayList() {
    ConstructorConstructor cc = newEmpty();
    Collection<?> instance = cc.get(new TypeToken<Collection<String>>() {
    }).construct();

    assertEquals(java.util.ArrayList.class, instance.getClass());
    assertTrue(instance.isEmpty());
  }

  public void testCollectionDefaults_listUsesArrayList() {
    ConstructorConstructor cc = newEmpty();
    List<?> instance = cc.get(new TypeToken<List<String>>() {
    }).construct();

    assertEquals(java.util.ArrayList.class, instance.getClass());
  }

  public void testCollectionDefaults_setUsesLinkedHashSet() {
    ConstructorConstructor cc = newEmpty();
    Set<?> instance = cc.get(new TypeToken<Set<String>>() {
    }).construct();

    assertEquals(java.util.LinkedHashSet.class, instance.getClass());
  }

  public void testCollectionDefaults_sortedSetUsesTreeSet() {
    ConstructorConstructor cc = newEmpty();
    SortedSet<?> instance = cc.get(new TypeToken<SortedSet<String>>() {
    }).construct();

    assertEquals(TreeSet.class, instance.getClass());
  }

  public void testCollectionDefaults_queueUsesLinkedList() {
    ConstructorConstructor cc = newEmpty();
    Queue<?> instance = cc.get(new TypeToken<Queue<String>>() {
    }).construct();

    assertEquals(LinkedList.class, instance.getClass());
  }

  public void testCollectionDefaults_customCollectionSubtypeFallsBackToArrayList() {
    // CustomCollection has a no-arg constructor, so that constructor wins
    // over the generic Collection default.
    ConstructorConstructor cc = newEmpty();
    CustomCollection<?> instance = cc.get(TypeToken.get(CustomCollection.class)).construct();

    assertNotNull(instance);
    assertEquals(CustomCollection.class, instance.getClass());
  }

  public void testCollectionDefaults_eachConstructCallReturnsIndependentInstance() {
    ConstructorConstructor cc = newEmpty();
    ObjectConstructor<List<String>> constructor = cc.get(new TypeToken<List<String>>() {
    });

    List<String> first = constructor.construct();
    first.add("a");
    List<String> second = constructor.construct();

    assertEquals(1, first.size());
    assertTrue(second.isEmpty());
  }

  // --- EnumSet handling ----------------------------------------------------

  public void testEnumSet_parameterizedTypeConstructsEmptyEnumSet() {
    ConstructorConstructor cc = newEmpty();
    EnumSet<Color> instance = cc.get(new TypeToken<EnumSet<Color>>() {
    }).construct();

    assertNotNull(instance);
    assertTrue(instance.isEmpty());
    instance.add(Color.RED);
    assertTrue(instance.contains(Color.RED));
  }

  public void testEnumSet_rawTypeThrowsJsonIOException() {
    ConstructorConstructor cc = newEmpty();
    ObjectConstructor<EnumSet> constructor = cc.get(TypeToken.get(EnumSet.class));

    try {
      constructor.construct();
      fail("Expected JsonIOException for raw EnumSet type");
    } catch (JsonIOException expected) {
      assertTrue(expected.getMessage().contains("Invalid EnumSet type"));
    }
  }

  // --- Map defaults ---------------------------------------------------------

  public void testMapDefaults_rawMapUsesLinkedTreeMap() {
    ConstructorConstructor cc = newEmpty();
    Map<?, ?> instance = cc.get(TypeToken.get(Map.class)).construct();

    assertEquals(LinkedTreeMap.class, instance.getClass());
  }

  public void testMapDefaults_stringKeyedMapUsesLinkedTreeMap() {
    ConstructorConstructor cc = newEmpty();
    Map<?, ?> instance = cc.get(new TypeToken<Map<String, Integer>>() {
    }).construct();

    assertEquals(LinkedTreeMap.class, instance.getClass());
  }

  public void testMapDefaults_nonStringKeyedMapUsesLinkedHashMap() {
    ConstructorConstructor cc = newEmpty();
    Map<?, ?> instance = cc.get(new TypeToken<Map<Integer, Integer>>() {
    }).construct();

    assertEquals(LinkedHashMap.class, instance.getClass());
  }

  public void testMapDefaults_sortedMapUsesTreeMap() {
    ConstructorConstructor cc = newEmpty();
    SortedMap<?, ?> instance = cc.get(new TypeToken<SortedMap<String, Integer>>() {
    }).construct();

    assertEquals(TreeMap.class, instance.getClass());
  }

  public void testMapDefaults_concurrentMapUsesConcurrentHashMap() {
    ConstructorConstructor cc = newEmpty();
    ConcurrentMap<?, ?> instance = cc.get(new TypeToken<ConcurrentMap<String, Integer>>() {
    }).construct();

    assertEquals(ConcurrentHashMap.class, instance.getClass());
  }

  public void testMapDefaults_concurrentNavigableMapUsesConcurrentSkipListMap() {
    ConstructorConstructor cc = newEmpty();
    ConcurrentNavigableMap<?, ?> instance =
        cc.get(new TypeToken<ConcurrentNavigableMap<String, Integer>>() {
        }).construct();

    assertEquals(ConcurrentSkipListMap.class, instance.getClass());
  }

  public void testMapDefaults_eachConstructCallReturnsIndependentInstance() {
    ConstructorConstructor cc = newEmpty();
    ObjectConstructor<Map<String, Integer>> constructor =
        cc.get(new TypeToken<Map<String, Integer>>() {
        });

    Map<String, Integer> first = constructor.construct();
    first.put("k", 1);
    Map<String, Integer> second = constructor.construct();

    assertEquals(1, first.size());
    assertTrue(second.isEmpty());
  }

  // --- Misc ------------------------------------------------------------

  public void testToString_delegatesToInstanceCreatorsMap() {
    Map<Type, InstanceCreator<?>> creators = new HashMap<Type, InstanceCreator<?>>();
    InstanceCreator<Object> creator = new InstanceCreator<Object>() {
      @Override public Object createInstance(Type type) {
        return new Object();
      }
    };
    creators.put(String.class, creator);

    ConstructorConstructor cc = newWithCreators(creators);

    assertEquals(creators.toString(), cc.toString());
  }

  public void testToString_emptyMap() {
    ConstructorConstructor cc = newEmpty();

    assertEquals("{}", cc.toString());
  }

  public void testGet_neverReturnsNull() {
    ConstructorConstructor cc = newEmpty();

    assertNotNull(cc.get(TypeToken.get(PublicNoArg.class)));
    assertNotNull(cc.get(TypeToken.get(SomeInterface.class)));
    assertNotNull(cc.get(new TypeToken<List<String>>() {
    }));
  }
}
