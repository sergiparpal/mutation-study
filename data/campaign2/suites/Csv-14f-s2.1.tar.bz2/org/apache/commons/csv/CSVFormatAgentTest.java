package org.apache.commons.csv;

import junit.framework.TestCase;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Arrays;

/**
 * Self-contained JUnit 3 tests for {@link CSVFormat}, based solely on the
 * documented contract in the generated javadoc.
 */
public class CSVFormatAgentTest extends TestCase {

    public enum Header {
        Name, Email, Phone
    }

    /** Minimal ResultSetMetaData stub returning two columns: ID, NAME. */
    private static class StubResultSetMetaData implements ResultSetMetaData {
        public int getColumnCount() {
            return 2;
        }

        public String getColumnLabel(int column) {
            return column == 1 ? "ID" : "NAME";
        }

        public String getColumnName(int column) {
            return getColumnLabel(column);
        }

        public boolean isAutoIncrement(int column) {
            return false;
        }

        public boolean isCaseSensitive(int column) {
            return false;
        }

        public boolean isSearchable(int column) {
            return false;
        }

        public boolean isCurrency(int column) {
            return false;
        }

        public int isNullable(int column) {
            return 0;
        }

        public boolean isSigned(int column) {
            return false;
        }

        public int getColumnDisplaySize(int column) {
            return 0;
        }

        public String getSchemaName(int column) {
            return "";
        }

        public int getPrecision(int column) {
            return 0;
        }

        public int getScale(int column) {
            return 0;
        }

        public String getTableName(int column) {
            return "";
        }

        public String getCatalogName(int column) {
            return "";
        }

        public int getColumnType(int column) {
            return 0;
        }

        public String getColumnTypeName(int column) {
            return "";
        }

        public boolean isReadOnly(int column) {
            return false;
        }

        public boolean isWritable(int column) {
            return false;
        }

        public boolean isDefinitelyWritable(int column) {
            return false;
        }

        public String getColumnClassName(int column) {
            return "";
        }

        public <T> T unwrap(Class<T> iface) {
            return null;
        }

        public boolean isWrapperFor(Class<?> iface) {
            return false;
        }
    }

    // ---- Predefined formats ----

    public void testDefaultFormatSettings() {
        CSVFormat fmt = CSVFormat.DEFAULT;
        assertEquals(',', fmt.getDelimiter());
        assertEquals(Character.valueOf('"'), fmt.getQuoteCharacter());
        assertEquals("\r\n", fmt.getRecordSeparator());
        assertTrue(fmt.getIgnoreEmptyLines());
    }

    public void testExcelFormatSettings() {
        CSVFormat fmt = CSVFormat.EXCEL;
        assertEquals(',', fmt.getDelimiter());
        assertEquals(Character.valueOf('"'), fmt.getQuoteCharacter());
        assertEquals("\r\n", fmt.getRecordSeparator());
        assertFalse(fmt.getIgnoreEmptyLines());
        assertTrue(fmt.getAllowMissingColumnNames());
    }

    public void testRfc4180FormatSettings() {
        CSVFormat fmt = CSVFormat.RFC4180;
        assertEquals(',', fmt.getDelimiter());
        assertEquals(Character.valueOf('"'), fmt.getQuoteCharacter());
        assertEquals("\r\n", fmt.getRecordSeparator());
        assertFalse(fmt.getIgnoreEmptyLines());
    }

    public void testTdfFormatSettings() {
        CSVFormat fmt = CSVFormat.TDF;
        assertEquals('\t', fmt.getDelimiter());
        assertEquals(Character.valueOf('"'), fmt.getQuoteCharacter());
        assertEquals("\r\n", fmt.getRecordSeparator());
        assertTrue(fmt.getIgnoreSurroundingSpaces());
    }

    public void testMySqlFormatSettings() {
        CSVFormat fmt = CSVFormat.MYSQL;
        assertEquals('\t', fmt.getDelimiter());
        assertFalse(fmt.isQuoteCharacterSet());
        assertEquals("\n", fmt.getRecordSeparator());
        assertFalse(fmt.getIgnoreEmptyLines());
        assertEquals(Character.valueOf('\\'), fmt.getEscapeCharacter());
        assertEquals("\\N", fmt.getNullString());
        assertTrue(fmt.isNullStringSet());
    }

    public void pruned_testInformixUnloadFormatSettings() {
        CSVFormat fmt = CSVFormat.INFORMIX_UNLOAD;
        assertEquals(',', fmt.getDelimiter());
        assertEquals("\n", fmt.getRecordSeparator());
        assertEquals(Character.valueOf('\\'), fmt.getEscapeCharacter());
    }

    public void testInformixUnloadCsvFormatSettings() {
        CSVFormat fmt = CSVFormat.INFORMIX_UNLOAD_CSV;
        assertEquals(',', fmt.getDelimiter());
        assertEquals("\n", fmt.getRecordSeparator());
    }

    // ---- newFormat ----

    public void testNewFormatInitializesOnlyDelimiter() {
        CSVFormat fmt = CSVFormat.newFormat(';');
        assertEquals(';', fmt.getDelimiter());
        assertNull(fmt.getQuoteCharacter());
        assertFalse(fmt.isQuoteCharacterSet());
        assertNull(fmt.getCommentMarker());
        assertFalse(fmt.isCommentMarkerSet());
        assertNull(fmt.getEscapeCharacter());
        assertFalse(fmt.isEscapeCharacterSet());
        assertNull(fmt.getNullString());
        assertFalse(fmt.isNullStringSet());
        assertNull(fmt.getHeader());
        assertNull(fmt.getHeaderComments());
        assertNull(fmt.getQuoteMode());
        assertFalse(fmt.getIgnoreEmptyLines());
        assertFalse(fmt.getIgnoreSurroundingSpaces());
        assertFalse(fmt.getIgnoreHeaderCase());
        assertFalse(fmt.getAllowMissingColumnNames());
        assertFalse(fmt.getSkipHeaderRecord());
        assertFalse(fmt.getTrailingDelimiter());
        assertFalse(fmt.getTrim());
    }

    public void testNewFormatRejectsLineBreakDelimiter() {
        try {
            CSVFormat.newFormat('\n');
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented
        }
        try {
            CSVFormat.newFormat('\r');
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented
        }
    }

    // ---- valueOf ----

    public void testValueOfReturnsPredefinedFormats() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.valueOf("Default"));
        assertEquals(CSVFormat.EXCEL, CSVFormat.valueOf("Excel"));
        assertEquals(CSVFormat.MYSQL, CSVFormat.valueOf("MySQL"));
        assertEquals(CSVFormat.RFC4180, CSVFormat.valueOf("RFC4180"));
        assertEquals(CSVFormat.TDF, CSVFormat.valueOf("TDF"));
    }

    public void testValueOfRejectsUnknownName() {
        try {
            CSVFormat.valueOf("NotAPredefinedFormat");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented via underlying enum lookup
        }
    }

    // ---- withDelimiter ----

    public void testWithDelimiter() {
        CSVFormat fmt = CSVFormat.newFormat(',').withDelimiter(';');
        assertEquals(';', fmt.getDelimiter());
    }

    public void testWithDelimiterRejectsLineBreak() {
        try {
            CSVFormat.DEFAULT.withDelimiter('\n');
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented
        }
        try {
            CSVFormat.DEFAULT.withDelimiter('\r');
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented
        }
    }

    // ---- withEscape ----

    public void testWithEscapeChar() {
        CSVFormat fmt = CSVFormat.newFormat(',').withEscape('\\');
        assertEquals(Character.valueOf('\\'), fmt.getEscapeCharacter());
        assertTrue(fmt.isEscapeCharacterSet());
    }

    public void testWithEscapeCharacterObjectNullDisables() {
        CSVFormat fmt = CSVFormat.newFormat(',').withEscape('\\').withEscape((Character) null);
        assertNull(fmt.getEscapeCharacter());
        assertFalse(fmt.isEscapeCharacterSet());
    }

    public void testWithEscapeRejectsLineBreak() {
        try {
            CSVFormat.DEFAULT.withEscape('\n');
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented
        }
    }

    // ---- withCommentMarker ----

    public void testWithCommentMarkerChar() {
        CSVFormat fmt = CSVFormat.newFormat(',').withCommentMarker('#');
        assertEquals(Character.valueOf('#'), fmt.getCommentMarker());
        assertTrue(fmt.isCommentMarkerSet());
    }

    public void testWithCommentMarkerObjectNullDisables() {
        CSVFormat fmt = CSVFormat.newFormat(',').withCommentMarker('#').withCommentMarker((Character) null);
        assertNull(fmt.getCommentMarker());
        assertFalse(fmt.isCommentMarkerSet());
    }

    public void testWithCommentMarkerRejectsLineBreak() {
        try {
            CSVFormat.DEFAULT.withCommentMarker('\n');
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented
        }
    }

    // ---- withQuote ----

    public void testWithQuoteChar() {
        CSVFormat fmt = CSVFormat.newFormat(',').withQuote('\'');
        assertEquals(Character.valueOf('\''), fmt.getQuoteCharacter());
        assertTrue(fmt.isQuoteCharacterSet());
    }

    public void testWithQuoteObjectNullDisables() {
        CSVFormat fmt = CSVFormat.DEFAULT.withQuote((Character) null);
        assertNull(fmt.getQuoteCharacter());
        assertFalse(fmt.isQuoteCharacterSet());
    }

    public void testWithQuoteRejectsLineBreak() {
        try {
            CSVFormat.DEFAULT.withQuote('\r');
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented
        }
    }

    // ---- withQuoteMode ----

    public void testWithQuoteMode() {
        QuoteMode mode = QuoteMode.values()[0];
        CSVFormat fmt = CSVFormat.DEFAULT.withQuoteMode(mode);
        assertEquals(mode, fmt.getQuoteMode());
    }

    // ---- withRecordSeparator ----

    public void testWithRecordSeparatorChar() {
        CSVFormat fmt = CSVFormat.newFormat(',').withRecordSeparator('\n');
        assertEquals("\n", fmt.getRecordSeparator());
    }

    public void testWithRecordSeparatorStringAcceptsCrLfVariants() {
        assertEquals("\n", CSVFormat.newFormat(',').withRecordSeparator("\n").getRecordSeparator());
        assertEquals("\r", CSVFormat.newFormat(',').withRecordSeparator("\r").getRecordSeparator());
        assertEquals("\r\n", CSVFormat.newFormat(',').withRecordSeparator("\r\n").getRecordSeparator());
    }

    public void pruned_testWithRecordSeparatorStringRejectsInvalidValue() {
        try {
            CSVFormat.newFormat(',').withRecordSeparator("not-a-valid-separator");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented
        }
    }

    // ---- withNullString ----

    public void testWithNullString() {
        CSVFormat fmt = CSVFormat.newFormat(',').withNullString("N/A");
        assertEquals("N/A", fmt.getNullString());
        assertTrue(fmt.isNullStringSet());
    }

    public void testWithNullStringNullMeansUnset() {
        CSVFormat fmt = CSVFormat.newFormat(',').withNullString("N/A").withNullString(null);
        assertNull(fmt.getNullString());
        assertFalse(fmt.isNullStringSet());
    }

    // ---- boolean toggles with no-arg and explicit-arg overloads ----

    public void testWithIgnoreEmptyLines() {
        CSVFormat base = CSVFormat.newFormat(',');
        assertFalse(base.getIgnoreEmptyLines());
        assertTrue(base.withIgnoreEmptyLines().getIgnoreEmptyLines());
        assertTrue(base.withIgnoreEmptyLines(true).getIgnoreEmptyLines());
        assertFalse(base.withIgnoreEmptyLines(false).getIgnoreEmptyLines());
    }

    public void testWithIgnoreHeaderCase() {
        CSVFormat base = CSVFormat.newFormat(',');
        assertFalse(base.getIgnoreHeaderCase());
        assertTrue(base.withIgnoreHeaderCase().getIgnoreHeaderCase());
        assertTrue(base.withIgnoreHeaderCase(true).getIgnoreHeaderCase());
        assertFalse(base.withIgnoreHeaderCase(false).getIgnoreHeaderCase());
    }

    public void testWithIgnoreSurroundingSpaces() {
        CSVFormat base = CSVFormat.newFormat(',');
        assertFalse(base.getIgnoreSurroundingSpaces());
        assertTrue(base.withIgnoreSurroundingSpaces().getIgnoreSurroundingSpaces());
        assertTrue(base.withIgnoreSurroundingSpaces(true).getIgnoreSurroundingSpaces());
        assertFalse(base.withIgnoreSurroundingSpaces(false).getIgnoreSurroundingSpaces());
    }

    public void testWithAllowMissingColumnNames() {
        CSVFormat base = CSVFormat.newFormat(',');
        assertFalse(base.getAllowMissingColumnNames());
        assertTrue(base.withAllowMissingColumnNames().getAllowMissingColumnNames());
        assertTrue(base.withAllowMissingColumnNames(true).getAllowMissingColumnNames());
        assertFalse(base.withAllowMissingColumnNames(false).getAllowMissingColumnNames());
    }

    public void testWithSkipHeaderRecord() {
        CSVFormat base = CSVFormat.newFormat(',');
        assertFalse(base.getSkipHeaderRecord());
        assertTrue(base.withSkipHeaderRecord().getSkipHeaderRecord());
        assertTrue(base.withSkipHeaderRecord(true).getSkipHeaderRecord());
        assertFalse(base.withSkipHeaderRecord(false).getSkipHeaderRecord());
    }

    public void testWithTrailingDelimiter() {
        CSVFormat base = CSVFormat.newFormat(',');
        assertFalse(base.getTrailingDelimiter());
        assertTrue(base.withTrailingDelimiter().getTrailingDelimiter());
        assertTrue(base.withTrailingDelimiter(true).getTrailingDelimiter());
        assertFalse(base.withTrailingDelimiter(false).getTrailingDelimiter());
    }

    public void testWithTrim() {
        CSVFormat base = CSVFormat.newFormat(',');
        assertFalse(base.getTrim());
        assertTrue(base.withTrim().getTrim());
        assertTrue(base.withTrim(true).getTrim());
        assertFalse(base.withTrim(false).getTrim());
    }

    // ---- withFirstRecordAsHeader ----

    public void testWithFirstRecordAsHeaderEquivalence() {
        CSVFormat expected = CSVFormat.DEFAULT.withHeader().withSkipHeaderRecord();
        CSVFormat actual = CSVFormat.DEFAULT.withFirstRecordAsHeader();
        assertEquals(expected, actual);
        assertTrue(actual.getSkipHeaderRecord());
        assertNotNull(actual.getHeader());
        assertEquals(0, actual.getHeader().length);
    }

    // ---- withHeader(String...) ----

    public void testWithHeaderStringArray() {
        CSVFormat fmt = CSVFormat.DEFAULT.withHeader("name", "email", "phone");
        assertTrue(Arrays.equals(new String[] { "name", "email", "phone" }, fmt.getHeader()));
    }

    public void testWithHeaderNoArgsMeansParseAutomatically() {
        CSVFormat fmt = CSVFormat.DEFAULT.withHeader();
        assertNotNull(fmt.getHeader());
        assertEquals(0, fmt.getHeader().length);
    }

    public void testWithHeaderNullDisables() {
        CSVFormat fmt = CSVFormat.DEFAULT.withHeader((String[]) null);
        assertNull(fmt.getHeader());
    }

    public void testGetHeaderReturnsCopy() {
        CSVFormat fmt = CSVFormat.DEFAULT.withHeader("a", "b");
        String[] first = fmt.getHeader();
        first[0] = "mutated";
        String[] second = fmt.getHeader();
        assertEquals("a", second[0]);
    }

    // ---- withHeader(Class) ----

    public void testWithHeaderEnumClass() {
        CSVFormat fmt = CSVFormat.DEFAULT.withHeader(Header.class);
        assertTrue(Arrays.equals(new String[] { "Name", "Email", "Phone" }, fmt.getHeader()));
    }

    public void testWithHeaderEnumClassNullDisables() {
        CSVFormat fmt = CSVFormat.DEFAULT.withHeader((Class<? extends Enum<?>>) null);
        assertNull(fmt.getHeader());
    }

    // ---- withHeader(ResultSetMetaData) ----

    public void testWithHeaderFromResultSetMetaData() throws SQLException {
        CSVFormat fmt = CSVFormat.DEFAULT.withHeader(new StubResultSetMetaData());
        assertTrue(Arrays.equals(new String[] { "ID", "NAME" }, fmt.getHeader()));
    }

    // ---- withHeaderComments ----

    public void testWithHeaderComments() {
        CSVFormat fmt = CSVFormat.DEFAULT.withHeaderComments("Generated", "today");
        assertTrue(Arrays.equals(new String[] { "Generated", "today" }, fmt.getHeaderComments()));
    }

    public void testGetHeaderCommentsDefaultNull() {
        assertNull(CSVFormat.newFormat(',').getHeaderComments());
    }

    public void testGetHeaderCommentsReturnsCopy() {
        CSVFormat fmt = CSVFormat.DEFAULT.withHeaderComments("a", "b");
        String[] first = fmt.getHeaderComments();
        first[0] = "mutated";
        String[] second = fmt.getHeaderComments();
        assertEquals("a", second[0]);
    }

    // ---- immutability ----

    public void testWithMethodsReturnNewImmutableInstances() {
        CSVFormat original = CSVFormat.DEFAULT;
        CSVFormat changed = original.withDelimiter(';');
        assertNotSame(original, changed);
        assertEquals(',', original.getDelimiter());
        assertEquals(';', changed.getDelimiter());
    }

    // ---- equals / hashCode / toString ----

    public void testEqualsReflexiveAndAgainstEquivalentlyBuiltFormat() {
        CSVFormat replica = CSVFormat.newFormat(',').withQuote('"').withRecordSeparator("\r\n")
                .withIgnoreEmptyLines(true);
        assertEquals(CSVFormat.DEFAULT, replica);
        assertEquals(CSVFormat.DEFAULT.hashCode(), replica.hashCode());
        assertTrue(CSVFormat.DEFAULT.equals(CSVFormat.DEFAULT));
    }

    public void testEqualsDistinguishesDifferentFormats() {
        assertFalse(CSVFormat.DEFAULT.equals(CSVFormat.EXCEL));
    }

    public void testEqualsAgainstNullAndOtherType() {
        assertFalse(CSVFormat.DEFAULT.equals(null));
        assertFalse(CSVFormat.DEFAULT.equals("not a CSVFormat"));
    }

    public void testToStringIsNonNullAndStable() {
        String first = CSVFormat.DEFAULT.toString();
        String second = CSVFormat.DEFAULT.toString();
        assertNotNull(first);
        assertEquals(first, second);
    }

    // ---- format ----

    public void testFormatJoinsValuesWithDelimiter() {
        assertEquals("a,b,c", CSVFormat.DEFAULT.format("a", "b", "c"));
    }

    public void testFormatUsesCustomDelimiter() {
        CSVFormat fmt = CSVFormat.DEFAULT.withDelimiter(';');
        assertEquals("a;b", fmt.format("a", "b"));
    }

    public void testFormatQuotesValueContainingDelimiter() {
        String result = CSVFormat.DEFAULT.format("a,b", "c");
        assertEquals("\"a,b\",c", result);
    }

    // ---- print(Appendable) / println / print(value,...) / printRecord ----

    public void testPrintAppendableWritesRecord() throws IOException {
        StringWriter out = new StringWriter();
        CSVPrinter printer = CSVFormat.DEFAULT.print(out);
        assertNotNull(printer);
        printer.printRecord("a", "b");
        printer.close();
        assertEquals("a,b" + CSVFormat.DEFAULT.getRecordSeparator(), out.toString());
    }

    public void testPrintlnWritesRecordSeparator() throws IOException {
        StringWriter out = new StringWriter();
        CSVFormat.DEFAULT.println(out);
        assertEquals(CSVFormat.DEFAULT.getRecordSeparator(), out.toString());
    }

    public void testPrintValueAppendsDelimiterWhenNotNewRecord() throws IOException {
        StringWriter out = new StringWriter();
        CSVFormat.DEFAULT.print("a", out, true);
        CSVFormat.DEFAULT.print("b", out, false);
        assertEquals("a,b", out.toString());
    }

    public void testPrintRecordAppendsRecordSeparator() throws IOException {
        StringWriter out = new StringWriter();
        CSVFormat.DEFAULT.printRecord(out, "a", "b", "c");
        assertEquals("a,b,c" + CSVFormat.DEFAULT.getRecordSeparator(), out.toString());
    }

    // ---- print(File, Charset) / print(Path, Charset) ----

    public void testPrintToFile() throws IOException {
        File file = File.createTempFile("CSVFormatAgentTest", ".csv");
        file.deleteOnExit();
        CSVPrinter printer = CSVFormat.DEFAULT.print(file, StandardCharsets.UTF_8);
        assertNotNull(printer);
        printer.printRecord("x", "y");
        printer.close();
        StringBuilder content = new StringBuilder();
        FileReader reader = new FileReader(file);
        int ch;
        while ((ch = reader.read()) != -1) {
            content.append((char) ch);
        }
        reader.close();
        assertEquals("x,y" + CSVFormat.DEFAULT.getRecordSeparator(), content.toString());
    }

    public void testPrintToPath() throws IOException {
        File file = File.createTempFile("CSVFormatAgentTest", ".csv");
        file.deleteOnExit();
        CSVPrinter printer = CSVFormat.DEFAULT.print(file.toPath(), StandardCharsets.UTF_8);
        assertNotNull(printer);
        printer.printRecord("x", "y");
        printer.close();
        byte[] bytes = Files.readAllBytes(file.toPath());
        String content = new String(bytes, StandardCharsets.UTF_8);
        assertEquals("x,y" + CSVFormat.DEFAULT.getRecordSeparator(), content);
    }

    // ---- parse(Reader) ----

    public void testParseReturnsNonNullParser() throws IOException {
        CSVParser parser = CSVFormat.DEFAULT.parse(new java.io.StringReader("a,b,c\r\n"));
        assertNotNull(parser);
        parser.close();
    }
}
