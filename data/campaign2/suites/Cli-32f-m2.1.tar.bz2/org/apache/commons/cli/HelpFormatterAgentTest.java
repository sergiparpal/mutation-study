/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.cli;

import java.io.ByteArrayOutputStream;
import java.io.PrintWriter;
import java.util.Comparator;

import junit.framework.TestCase;

public class HelpFormatterAgentTest extends TestCase
{
    public void testDefaultConstants()
    {
        HelpFormatter formatter = new HelpFormatter();
        assertEquals(HelpFormatter.DEFAULT_WIDTH, formatter.getWidth());
        assertEquals(HelpFormatter.DEFAULT_LEFT_PAD, formatter.getLeftPadding());
        assertEquals(HelpFormatter.DEFAULT_DESC_PAD, formatter.getDescPadding());
        assertEquals(HelpFormatter.DEFAULT_SYNTAX_PREFIX, formatter.getSyntaxPrefix());
        assertEquals(HelpFormatter.DEFAULT_OPT_PREFIX, formatter.getOptPrefix());
        assertEquals(HelpFormatter.DEFAULT_LONG_OPT_PREFIX, formatter.getLongOptPrefix());
        assertEquals(HelpFormatter.DEFAULT_LONG_OPT_SEPARATOR, formatter.getLongOptSeparator());
        assertEquals(HelpFormatter.DEFAULT_ARG_NAME, formatter.getArgName());
        assertEquals(System.getProperty("line.separator"), formatter.getNewLine());
    }

    public void testSettersAndGetters()
    {
        HelpFormatter formatter = new HelpFormatter();

        formatter.setWidth(100);
        assertEquals(100, formatter.getWidth());

        formatter.setLeftPadding(5);
        assertEquals(5, formatter.getLeftPadding());

        formatter.setDescPadding(7);
        assertEquals(7, formatter.getDescPadding());

        formatter.setSyntaxPrefix("call: ");
        assertEquals("call: ", formatter.getSyntaxPrefix());

        formatter.setNewLine("\n");
        assertEquals("\n", formatter.getNewLine());

        formatter.setOptPrefix("+");
        assertEquals("+", formatter.getOptPrefix());

        formatter.setLongOptPrefix("++");
        assertEquals("++", formatter.getLongOptPrefix());

        formatter.setLongOptSeparator("=");
        assertEquals("=", formatter.getLongOptSeparator());

        formatter.setArgName("value");
        assertEquals("value", formatter.getArgName());
    }

    public void testOptionComparatorDefaultsAndNullResetsToDefault() throws Exception
    {
        HelpFormatter formatter = new HelpFormatter();
        Comparator defaultComparator = formatter.getOptionComparator();
        assertNotNull(defaultComparator);

        Option a = new Option("a", "aaa", false, "first");
        Option b = new Option("b", "bbb", false, "second");
        assertTrue(defaultComparator.compare(a, b) < 0);
        assertTrue(defaultComparator.compare(b, a) > 0);
        assertEquals(0, defaultComparator.compare(a, a));

        Comparator reverse = new Comparator()
        {
            public int compare(Object o1, Object o2)
            {
                return -((Option) o1).getKey().compareToIgnoreCase(((Option) o2).getKey());
            }
        };
        formatter.setOptionComparator(reverse);
        assertSame(reverse, formatter.getOptionComparator());

        formatter.setOptionComparator(null);
        Comparator afterNull = formatter.getOptionComparator();
        assertNotNull(afterNull);
        assertNotSame(reverse, afterNull);
        assertTrue(afterNull.compare(a, b) < 0);
    }

    public void testPrintHelpThrowsOnNullSyntax()
    {
        HelpFormatter formatter = new HelpFormatter();
        Options options = new Options();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PrintWriter pw = new PrintWriter(out);
        try
        {
            formatter.printHelp(pw, 80, null, null, options, 1, 3, null, false);
            fail("Expected IllegalArgumentException for null cmdLineSyntax");
        }
        catch (IllegalArgumentException e)
        {
            assertEquals("cmdLineSyntax not provided", e.getMessage());
        }
    }

    public void testPrintHelpThrowsOnEmptySyntax()
    {
        HelpFormatter formatter = new HelpFormatter();
        Options options = new Options();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PrintWriter pw = new PrintWriter(out);
        try
        {
            formatter.printHelp(pw, 80, "", null, options, 1, 3, null, false);
            fail("Expected IllegalArgumentException for empty cmdLineSyntax");
        }
        catch (IllegalArgumentException e)
        {
            assertEquals("cmdLineSyntax not provided", e.getMessage());
        }
    }

    public void testPrintHelpWithHeaderAndFooter()
    {
        HelpFormatter formatter = new HelpFormatter();
        Options options = new Options();
        options.addOption("a", "all", false, "list all");

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PrintWriter pw = new PrintWriter(out);
        formatter.printHelp(pw, 80, "myapp", "Header text", options, 1, 3, "Footer text", false);
        pw.flush();

        String result = out.toString();
        assertTrue(result.indexOf("usage: myapp") != -1);
        assertTrue(result.indexOf("Header text") != -1);
        assertTrue(result.indexOf("Footer text") != -1);
        assertTrue(result.indexOf("-a,--all") != -1);
        assertTrue(result.indexOf("list all") != -1);
    }

    public void testPrintHelpWithoutHeaderAndFooterOmitsBlankLines()
    {
        HelpFormatter formatter = new HelpFormatter();
        Options options = new Options();
        options.addOption("a", "all", false, "list all");

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PrintWriter pw = new PrintWriter(out);
        formatter.printHelp(pw, 80, "myapp", null, options, 1, 3, null, false);
        pw.flush();

        String result = out.toString();
        assertTrue(result.indexOf("usage: myapp") != -1);
        assertTrue(result.indexOf("-a,--all") != -1);
    }

    public void testPrintHelpWithAutoUsage()
    {
        HelpFormatter formatter = new HelpFormatter();
        Options options = new Options();
        options.addOption(OptionBuilder.isRequired().create("r"));
        options.addOption("o", false, "optional flag");

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PrintWriter pw = new PrintWriter(out);
        formatter.printHelp(pw, 80, "myapp", null, options, 1, 3, null, true);
        pw.flush();

        String result = out.toString();
        assertTrue(result.indexOf("usage: myapp") != -1);
        assertTrue(result.indexOf("-r") != -1);
        assertTrue(result.indexOf("[-o]") != -1);
    }

    public void testPrintUsageWithSingleOption()
    {
        HelpFormatter formatter = new HelpFormatter();
        Options options = new Options();
        options.addOption("a", false, "a flag");

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PrintWriter pw = new PrintWriter(out);
        formatter.printUsage(pw, 80, "app", options);
        pw.flush();

        assertEquals("usage: app [-a]" + formatter.getNewLine(), out.toString());
    }

    public void testPrintUsageWithNoOptions()
    {
        HelpFormatter formatter = new HelpFormatter();
        Options options = new Options();

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PrintWriter pw = new PrintWriter(out);
        formatter.printUsage(pw, 80, "app", options);
        pw.flush();

        assertEquals("usage: app" + formatter.getNewLine(), out.toString());
    }

    public void testPrintUsageWithRequiredOptionGroup() throws Exception
    {
        HelpFormatter formatter = new HelpFormatter();
        OptionGroup group = new OptionGroup();
        group.addOption(new Option("a", "first"));
        group.addOption(new Option("b", "second"));
        group.setRequired(true);

        Options options = new Options();
        options.addOptionGroup(group);

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PrintWriter pw = new PrintWriter(out);
        formatter.printUsage(pw, 80, "app", options);
        pw.flush();

        assertEquals("usage: app -a | -b" + formatter.getNewLine(), out.toString());
    }

    public void testPrintUsageWithOptionalOptionGroup() throws Exception
    {
        HelpFormatter formatter = new HelpFormatter();
        OptionGroup group = new OptionGroup();
        group.addOption(new Option("a", "first"));
        group.addOption(new Option("b", "second"));

        Options options = new Options();
        options.addOptionGroup(group);

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PrintWriter pw = new PrintWriter(out);
        formatter.printUsage(pw, 80, "app", options);
        pw.flush();

        assertEquals("usage: app [-a | -b]" + formatter.getNewLine(), out.toString());
    }

    public void testPrintUsageSimpleSyntax()
    {
        HelpFormatter formatter = new HelpFormatter();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PrintWriter pw = new PrintWriter(out);
        formatter.printUsage(pw, 80, "app arg1 arg2");
        pw.flush();

        assertEquals("usage: app arg1 arg2" + formatter.getNewLine(), out.toString());
    }

    public void testPrintOptionsRendersArgNameAndDescription() throws Exception
    {
        HelpFormatter formatter = new HelpFormatter();
        Options options = new Options();
        Option opt = OptionBuilder.withArgName("num").hasArg().withDescription("count value").create('c');
        options.addOption(opt);

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PrintWriter pw = new PrintWriter(out);
        formatter.printOptions(pw, 80, options, 1, 3);
        pw.flush();

        String result = out.toString();
        assertTrue(result.indexOf("-c <num>") != -1);
        assertTrue(result.indexOf("count value") != -1);
    }

    public void testPrintOptionsWithBlankArgName() throws Exception
    {
        HelpFormatter formatter = new HelpFormatter();
        Options options = new Options();
        Option opt = OptionBuilder.withArgName("").hasArg().withDescription("desc").create('c');
        options.addOption(opt);

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PrintWriter pw = new PrintWriter(out);
        formatter.printOptions(pw, 80, options, 1, 3);
        pw.flush();

        String result = out.toString();
        assertTrue(result.indexOf("-c") != -1);
        assertTrue(result.indexOf("<") == -1);
    }

    public void testPrintOptionsAlignsMultipleOptions() throws Exception
    {
        HelpFormatter formatter = new HelpFormatter();
        Options options = new Options();
        options.addOption("a", false, "short");
        options.addOption("bb", "bigger", false, "bigger option");

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PrintWriter pw = new PrintWriter(out);
        formatter.printOptions(pw, 80, options, 1, 3);
        pw.flush();

        String[] lines = out.toString().split(formatter.getNewLine());
        assertEquals(2, lines.length);
        assertTrue(lines[0].indexOf("short") != -1);
        assertTrue(lines[1].indexOf("bigger option") != -1);
        int indexOfShort = lines[0].indexOf("short");
        int indexOfBigger = lines[1].indexOf("bigger option");
        assertEquals(indexOfShort, indexOfBigger);
    }

    public void testPrintWrappedShortTextUnmodified()
    {
        HelpFormatter formatter = new HelpFormatter();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PrintWriter pw = new PrintWriter(out);
        formatter.printWrapped(pw, 80, "a short line");
        pw.flush();

        assertEquals("a short line" + formatter.getNewLine(), out.toString());
    }

    public void testPrintWrappedLongTextWraps()
    {
        HelpFormatter formatter = new HelpFormatter();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PrintWriter pw = new PrintWriter(out);
        String text = "aaaa aaaa aaaa aaaa aaaa";
        formatter.printWrapped(pw, 10, 0, text);
        pw.flush();

        String[] lines = out.toString().split(formatter.getNewLine());
        assertTrue(lines.length > 1);
        for (int i = 0; i < lines.length; i++)
        {
            assertTrue("line too long: [" + lines[i] + "]", lines[i].length() <= 10);
        }
    }

    public void testRenderWrappedTextHandlesNewlineWithinText()
    {
        HelpFormatter formatter = new HelpFormatter();
        StringBuffer sb = new StringBuffer();
        formatter.renderWrappedText(sb, 80, 0, "line one\nline two");

        String result = sb.toString();
        assertTrue(result.indexOf("line one") != -1);
        assertTrue(result.indexOf("line two") != -1);
    }

    public void testFindWrapPosReturnsMinusOneWhenTextFits()
    {
        HelpFormatter formatter = new HelpFormatter();
        int pos = formatter.findWrapPos("short", 80, 0);
        assertEquals(-1, pos);
    }

    public void testFindWrapPosBreaksAtWhitespace()
    {
        HelpFormatter formatter = new HelpFormatter();
        String text = "1234567890 1234567890";
        int pos = formatter.findWrapPos(text, 15, 0);
        assertEquals(10, pos);
    }

    public void testFindWrapPosNoWhitespaceChopsAtWidth()
    {
        HelpFormatter formatter = new HelpFormatter();
        String text = "1234567890123456789012345";
        int pos = formatter.findWrapPos(text, 10, 0);
        assertEquals(10, pos);
    }

    public void testFindWrapPosNewlineBeforeWidth()
    {
        HelpFormatter formatter = new HelpFormatter();
        String text = "abc\ndef";
        int pos = formatter.findWrapPos(text, 80, 0);
        assertEquals(4, pos);
    }

    public void testCreatePaddingProducesSpaces()
    {
        HelpFormatter formatter = new HelpFormatter();
        String padding = formatter.createPadding(4);
        assertEquals("    ", padding);
        assertEquals(4, padding.length());
    }

    public void testCreatePaddingZeroLength()
    {
        HelpFormatter formatter = new HelpFormatter();
        String padding = formatter.createPadding(0);
        assertEquals("", padding);
    }

    public void testRtrimRemovesTrailingWhitespace()
    {
        HelpFormatter formatter = new HelpFormatter();
        assertEquals("hello", formatter.rtrim("hello   "));
        assertEquals("hello\tworld", formatter.rtrim("hello\tworld  \n"));
    }

    public void testRtrimWithNullAndEmpty()
    {
        HelpFormatter formatter = new HelpFormatter();
        assertNull(formatter.rtrim(null));
        assertEquals("", formatter.rtrim(""));
    }

    public void testRtrimAllWhitespaceReturnsEmpty()
    {
        HelpFormatter formatter = new HelpFormatter();
        assertEquals("", formatter.rtrim("    "));
    }

    public void testPrintHelpTwoArgConvenienceMethod()
    {
        HelpFormatter formatter = new HelpFormatter();
        Options options = new Options();
        options.addOption("x", false, "desc x");

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        java.io.PrintStream originalOut = System.out;
        System.setOut(new java.io.PrintStream(out));
        try
        {
            formatter.printHelp("app", options);
        }
        finally
        {
            System.setOut(originalOut);
        }

        String result = out.toString();
        assertTrue(result.indexOf("usage: app") != -1);
        assertTrue(result.indexOf("-x") != -1);
        assertTrue(result.indexOf("desc x") != -1);
    }
}
