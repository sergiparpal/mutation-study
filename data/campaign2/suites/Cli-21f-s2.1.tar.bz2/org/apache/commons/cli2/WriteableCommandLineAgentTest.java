package org.apache.commons.cli2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import junit.framework.TestCase;

import org.apache.commons.cli2.commandline.WriteableCommandLineImpl;
import org.apache.commons.cli2.option.GroupImpl;

/**
 * Tests for the documented contract of the {@link WriteableCommandLine}
 * interface. Since the interface cannot be instantiated directly, its only
 * known implementing class ({@link WriteableCommandLineImpl}) is used as the
 * vehicle to exercise the behaviour that the interface's javadoc specifies.
 */
public class WriteableCommandLineAgentTest extends TestCase {

    private static Option newOption(String name) {
        return new GroupImpl(new ArrayList(), name, "description of " + name, 0, 0, false);
    }

    private static WriteableCommandLine newCommandLine() {
        Option root = newOption("root");
        return new WriteableCommandLineImpl(root, new ArrayList());
    }

    public void testAddOptionMakesOptionPresent() {
        WriteableCommandLine cl = newCommandLine();
        Option opt = newOption("-a");

        assertFalse(cl.hasOption(opt));

        cl.addOption(opt);

        assertTrue(cl.hasOption(opt));
        assertTrue(cl.getOptions().contains(opt));
    }

    public void testAddValueAccumulatesInOrder() {
        WriteableCommandLine cl = newCommandLine();
        Option opt = newOption("-a");

        cl.addValue(opt, "v1");
        cl.addValue(opt, "v2");

        List values = cl.getUndefaultedValues(opt);
        assertEquals(2, values.size());
        assertEquals("v1", values.get(0));
        assertEquals("v2", values.get(1));
    }

    public void testGetUndefaultedValuesIsEmptyWhenNoneAdded() {
        WriteableCommandLine cl = newCommandLine();
        Option opt = newOption("-a");

        List values = cl.getUndefaultedValues(opt);

        assertNotNull(values);
        assertTrue(values.isEmpty());
    }

    public void testSetDefaultValuesDoesNotLeakIntoUndefaultedValues() {
        WriteableCommandLine cl = newCommandLine();
        Option opt = newOption("-a");
        List defaults = Arrays.asList(new Object[] {"d1", "d2"});

        cl.setDefaultValues(opt, defaults);

        assertTrue(cl.getUndefaultedValues(opt).isEmpty());
        assertEquals(defaults, cl.getValues(opt, Collections.EMPTY_LIST));

        cl.addValue(opt, "real");

        List undefaulted = cl.getUndefaultedValues(opt);
        assertEquals(1, undefaulted.size());
        assertEquals("real", undefaulted.get(0));
    }

    public void testAddSwitchIsRetrievableViaGetSwitch() {
        WriteableCommandLine cl = newCommandLine();
        Option opt = newOption("-s");

        cl.addSwitch(opt, true);

        assertEquals(Boolean.TRUE, cl.getSwitch(opt, null));
    }

    public void testAddSwitchTwiceThrowsIllegalStateException() {
        WriteableCommandLine cl = newCommandLine();
        Option opt = newOption("-s");

        cl.addSwitch(opt, true);

        try {
            cl.addSwitch(opt, false);
            fail("Expected IllegalStateException when the switch has already been added");
        } catch (IllegalStateException expected) {
            // documented behaviour
        }
    }

    public void testGetSwitchFallsBackToSuppliedDefaultWhenNothingConfigured() {
        WriteableCommandLine cl = newCommandLine();
        Option opt = newOption("-s");

        assertEquals(Boolean.FALSE, cl.getSwitch(opt, Boolean.FALSE));
        assertNull(cl.getSwitch(opt, null));
    }

    public void pruned_testSetDefaultSwitchIsUsedWhenNoExplicitSwitchAdded() {
        WriteableCommandLine cl = newCommandLine();
        Option opt = newOption("-s");

        cl.setDefaultSwitch(opt, Boolean.TRUE);

        assertEquals(Boolean.TRUE, cl.getSwitch(opt, Boolean.FALSE));
    }

    public void testAddPropertyOnDefaultSetReplacesExistingValue() {
        WriteableCommandLine cl = newCommandLine();

        assertNull(cl.getProperty("key"));

        cl.addProperty("key", "val1");
        assertEquals("val1", cl.getProperty("key"));

        cl.addProperty("key", "val2");
        assertEquals("val2", cl.getProperty("key"));
    }

    public void testAddPropertyForOptionIsIsolatedFromDefaultSet() {
        WriteableCommandLine cl = newCommandLine();
        Option opt = newOption("-p");

        cl.addProperty(opt, "key", "val");

        assertEquals("val", cl.getProperty(opt, "key", "fallback"));
        assertEquals("fallback", cl.getProperty(opt, "otherKey", "fallback"));
        assertNull(cl.getProperty("key"));
    }

    public void testLooksLikeOptionFalseWhenRootHasNoOptions() {
        Option root = newOption("root");
        WriteableCommandLine cl = new WriteableCommandLineImpl(root, new ArrayList());

        assertFalse(cl.looksLikeOption("-a"));
        assertFalse(cl.looksLikeOption("anything"));
    }

    public void pruned_testCurrentOptionDefaultsToNullAndIsSettable() {
        WriteableCommandLine cl = newCommandLine();
        Option opt = newOption("-c");

        assertNull(cl.getCurrentOption());

        cl.setCurrentOption(opt);
        assertSame(opt, cl.getCurrentOption());

        cl.setCurrentOption(null);
        assertNull(cl.getCurrentOption());
    }
}
