package org.apache.commons.cli2.commandline;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import junit.framework.TestCase;

import org.apache.commons.cli2.Option;
import org.apache.commons.cli2.option.GroupImpl;

public class WriteableCommandLineImplAgentTest extends TestCase {

    private static Option newOption(String name) {
        return new GroupImpl(new ArrayList(), name, "description of " + name, 0, 0, false);
    }

    private static WriteableCommandLineImpl newCommandLine(Option root) {
        return new WriteableCommandLineImpl(root, new ArrayList());
    }

    public void testConstructorAcceptsRootOptionAndArguments() {
        Option root = newOption("root");
        List arguments = Arrays.asList(new Object[] {"--foo", "bar"});

        WriteableCommandLineImpl cl = new WriteableCommandLineImpl(root, arguments);

        assertNotNull(cl.getNormalised());
    }

    public void testHasOptionFalseThenTrueAfterAddOption() {
        Option root = newOption("root");
        WriteableCommandLineImpl cl = newCommandLine(root);
        Option opt = newOption("-a");

        assertFalse(cl.hasOption(opt));

        cl.addOption(opt);

        assertTrue(cl.hasOption(opt));
    }

    public void testGetOptionsIsNeverNullAndGrowsWithAddOption() {
        Option root = newOption("root");
        WriteableCommandLineImpl cl = newCommandLine(root);

        assertNotNull(cl.getOptions());
        assertTrue(cl.getOptions().isEmpty());

        Option optA = newOption("-a");
        Option optB = newOption("-b");
        cl.addOption(optA);
        cl.addOption(optB);

        List options = cl.getOptions();
        assertEquals(2, options.size());
        assertTrue(options.contains(optA));
        assertTrue(options.contains(optB));
    }

    public void testGetOptionTriggersIsNeverNull() {
        Option root = newOption("root");
        WriteableCommandLineImpl cl = newCommandLine(root);

        Set triggers = cl.getOptionTriggers();
        assertNotNull(triggers);
    }

    public void testGetOptionReturnsNullWhenRootHasNoMatchingOption() {
        Option root = newOption("root");
        WriteableCommandLineImpl cl = newCommandLine(root);

        assertNull(cl.getOption("-does-not-exist"));
    }

    public void testGetValuesReturnsSuppliedDefaultsWhenNoneFound() {
        Option root = newOption("root");
        WriteableCommandLineImpl cl = newCommandLine(root);
        Option opt = newOption("-a");
        List defaultValues = Arrays.asList(new Object[] {"fallback"});

        List result = cl.getValues(opt, defaultValues);

        assertEquals(defaultValues, result);
    }

    public void testGetValuesReturnsAddedValuesOverDefaults() {
        Option root = newOption("root");
        WriteableCommandLineImpl cl = newCommandLine(root);
        Option opt = newOption("-a");
        List defaultValues = Arrays.asList(new Object[] {"fallback"});

        cl.addValue(opt, "real");

        List result = cl.getValues(opt, defaultValues);
        assertEquals(1, result.size());
        assertEquals("real", result.get(0));
    }

    public void testGetSwitchReturnsSuppliedDefaultWhenNoneConfigured() {
        Option root = newOption("root");
        WriteableCommandLineImpl cl = newCommandLine(root);
        Option opt = newOption("-s");

        assertEquals(Boolean.FALSE, cl.getSwitch(opt, Boolean.FALSE));
    }

    public void testGetSwitchReturnsAddedSwitchValue() {
        Option root = newOption("root");
        WriteableCommandLineImpl cl = newCommandLine(root);
        Option opt = newOption("-s");

        cl.addSwitch(opt, true);

        assertEquals(Boolean.TRUE, cl.getSwitch(opt, Boolean.FALSE));
    }

    public void testGetPropertyDefaultSetReturnsNullThenValue() {
        Option root = newOption("root");
        WriteableCommandLineImpl cl = newCommandLine(root);

        assertNull(cl.getProperty("key"));

        cl.addProperty("key", "value");

        assertEquals("value", cl.getProperty("key"));
    }

    public void testGetPropertyWithOptionReturnsDefaultValueWhenMissing() {
        Option root = newOption("root");
        WriteableCommandLineImpl cl = newCommandLine(root);
        Option opt = newOption("-p");

        assertEquals("fallback", cl.getProperty(opt, "key", "fallback"));

        cl.addProperty(opt, "key", "actual");

        assertEquals("actual", cl.getProperty(opt, "key", "fallback"));
    }

    public void testGetPropertiesForOptionIsNeverNullAndContainsAddedNames() {
        Option root = newOption("root");
        WriteableCommandLineImpl cl = newCommandLine(root);
        Option opt = newOption("-p");

        Set properties = cl.getProperties(opt);
        assertNotNull(properties);
        assertTrue(properties.isEmpty());

        cl.addProperty(opt, "key", "value");

        properties = cl.getProperties(opt);
        assertTrue(properties.contains("key"));
    }

    public void testGetPropertiesForDefaultSetIsNeverNullAndContainsAddedNames() {
        Option root = newOption("root");
        WriteableCommandLineImpl cl = newCommandLine(root);

        Set properties = cl.getProperties();
        assertNotNull(properties);
        assertTrue(properties.isEmpty());

        cl.addProperty("key", "value");

        properties = cl.getProperties();
        assertTrue(properties.contains("key"));
    }

    public void testLooksLikeOptionFalseWhenRootHasNoOptions() {
        Option root = newOption("root");
        WriteableCommandLineImpl cl = newCommandLine(root);

        assertFalse(cl.looksLikeOption("-a"));
    }

    public void testToStringIsNotNull() {
        Option root = newOption("root");
        WriteableCommandLineImpl cl = newCommandLine(root);

        assertNotNull(cl.toString());
    }

    public void pruned_testCurrentOptionDefaultsToNullAndIsSettable() {
        Option root = newOption("root");
        WriteableCommandLineImpl cl = newCommandLine(root);
        Option opt = newOption("-c");

        assertNull(cl.getCurrentOption());

        cl.setCurrentOption(opt);
        assertSame(opt, cl.getCurrentOption());
    }

    public void testSetDefaultValuesDoesNotLeakIntoUndefaultedValues() {
        Option root = newOption("root");
        WriteableCommandLineImpl cl = newCommandLine(root);
        Option opt = newOption("-a");
        List defaults = Arrays.asList(new Object[] {"d1"});

        cl.setDefaultValues(opt, defaults);

        assertTrue(cl.getUndefaultedValues(opt).isEmpty());
        assertEquals(defaults, cl.getValues(opt, Collections.EMPTY_LIST));
    }
}
