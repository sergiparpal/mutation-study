package org.apache.commons.cli2.option;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import junit.framework.TestCase;

import org.apache.commons.cli2.Option;
import org.apache.commons.cli2.OptionException;
import org.apache.commons.cli2.WriteableCommandLine;
import org.apache.commons.cli2.commandline.WriteableCommandLineImpl;

public class GroupImplAgentTest extends TestCase {

    private static GroupImpl leaf(String name) {
        return new GroupImpl(new ArrayList(), name, "description of " + name, 0, 0, false);
    }

    private static WriteableCommandLine newCommandLine(Option root) {
        return new WriteableCommandLineImpl(root, new ArrayList());
    }

    public void testConstructorStoresDescription() {
        GroupImpl group = new GroupImpl(new ArrayList(), "grp", "a description", 0, 0, false);

        assertEquals("a description", group.getDescription());
    }

    public void testConstructorStoresPreferredNameWhenNameProvided() {
        GroupImpl group = new GroupImpl(new ArrayList(), "-group", "desc", 0, 0, false);

        assertEquals("-group", group.getPreferredName());
    }

    public void testConstructorAllowsNullName() {
        GroupImpl group = new GroupImpl(new ArrayList(), null, "desc", 0, 0, false);

        assertEquals("desc", group.getDescription());
    }

    public void testGetMinimumAndGetMaximumReturnConstructorValues() {
        GroupImpl group = new GroupImpl(new ArrayList(), "g", "d", 2, 5, false);

        assertEquals(2, group.getMinimum());
        assertEquals(5, group.getMaximum());
    }

    public void pruned_testIsRequiredTrueWhenRequiredFlagSet() {
        GroupImpl group = new GroupImpl(new ArrayList(), "g", "d", 0, 0, true);

        assertTrue(group.isRequired());
    }

    public void testIsRequiredFalseWhenNotRequiredAndNoMinimum() {
        GroupImpl group = new GroupImpl(new ArrayList(), "g", "d", 0, 0, false);

        assertFalse(group.isRequired());
    }

    public void testIsRequiredTrueWhenMinimumPositiveEvenIfFlagFalse() {
        GroupImpl group = new GroupImpl(new ArrayList(), "g", "d", 1, 5, false);

        assertTrue(group.isRequired());
    }

    public void testGetOptionsReturnsSuppliedOptions() {
        GroupImpl childA = leaf("-a");
        GroupImpl childB = leaf("-b");
        List options = new ArrayList();
        options.add(childA);
        options.add(childB);

        GroupImpl group = new GroupImpl(options, "g", "d", 0, 2, false);

        List result = group.getOptions();
        assertNotNull(result);
        assertEquals(2, result.size());
        assertTrue(result.contains(childA));
        assertTrue(result.contains(childB));
    }

    public void testGetOptionsEmptyWhenNoneSupplied() {
        GroupImpl group = new GroupImpl(new ArrayList(), "g", "d", 0, 0, false);

        assertNotNull(group.getOptions());
        assertTrue(group.getOptions().isEmpty());
    }

    public void testGetAnonymousEmptyWhenNoArgumentsSupplied() {
        GroupImpl child = leaf("-a");
        List options = new ArrayList();
        options.add(child);

        GroupImpl group = new GroupImpl(options, "g", "d", 0, 1, false);

        assertNotNull(group.getAnonymous());
        assertTrue(group.getAnonymous().isEmpty());
    }

    public void testGetPrefixesIsNeverNull() {
        GroupImpl group = new GroupImpl(new ArrayList(), "g", "d", 0, 0, false);

        Set prefixes = group.getPrefixes();
        assertNotNull(prefixes);
    }

    public void testGetTriggersIsNeverNull() {
        GroupImpl group = new GroupImpl(new ArrayList(), "g", "d", 0, 0, false);

        Set triggers = group.getTriggers();
        assertNotNull(triggers);
    }

    public void testFindOptionReturnsNullWhenGroupHasNoOptions() {
        GroupImpl group = new GroupImpl(new ArrayList(), "g", "d", 0, 0, false);

        assertNull(group.findOption("-x"));
    }

    public void testFindOptionReturnsNullWhenNoChildMatchesTrigger() {
        GroupImpl child = leaf("-a");
        List options = new ArrayList();
        options.add(child);

        GroupImpl group = new GroupImpl(options, "g", "d", 0, 1, false);

        assertNull(group.findOption("-does-not-exist"));
    }

    public void testCanProcessFalseWhenGroupHasNoOptions() {
        GroupImpl group = new GroupImpl(new ArrayList(), "g", "d", 0, 0, false);
        WriteableCommandLine cl = newCommandLine(group);

        assertFalse(group.canProcess(cl, "-a"));
    }

    public void testValidateSucceedsWhenPresentCountSatisfiesMinimum() throws OptionException {
        GroupImpl group = new GroupImpl(new ArrayList(), "g", "d", 0, 0, false);
        WriteableCommandLine cl = newCommandLine(group);

        group.validate(cl);
    }

    public void testValidateThrowsWhenPresentCountBelowMinimum() {
        GroupImpl group = new GroupImpl(new ArrayList(), "g", "d", 1, 5, false);
        WriteableCommandLine cl = newCommandLine(group);

        try {
            group.validate(cl);
            fail("Expected OptionException when fewer than the minimum number of options are present");
        } catch (OptionException expected) {
            // documented behaviour
        }
    }

    public void testValidateThrowsWhenPresentCountAboveMaximum() {
        GroupImpl childA = leaf("-a");
        GroupImpl childB = leaf("-b");
        List options = new ArrayList();
        options.add(childA);
        options.add(childB);

        GroupImpl group = new GroupImpl(options, "g", "d", 0, 1, false);
        WriteableCommandLine cl = newCommandLine(group);
        cl.addOption(childA);
        cl.addOption(childB);

        try {
            group.validate(cl);
            fail("Expected OptionException when more than the maximum number of options are present");
        } catch (OptionException expected) {
            // documented behaviour
        }
    }

    public void testDefaultsDoesNotThrowForEmptyGroup() {
        GroupImpl group = new GroupImpl(new ArrayList(), "g", "d", 0, 0, false);
        WriteableCommandLine cl = newCommandLine(group);

        group.defaults(cl);
    }

    public void testAppendUsageAppendsSomethingToBuffer() {
        GroupImpl child = leaf("-a");
        List options = new ArrayList();
        options.add(child);

        GroupImpl group = new GroupImpl(options, "g", "d", 0, 1, false);
        StringBuffer buffer = new StringBuffer();

        group.appendUsage(buffer, new HashSet(), ReverseStringComparator.getInstance());

        assertTrue(buffer.length() > 0);
    }

    public void testAppendUsageWithSeparatorAppendsSomethingToBuffer() {
        GroupImpl child = leaf("-a");
        List options = new ArrayList();
        options.add(child);

        GroupImpl group = new GroupImpl(options, "g", "d", 0, 1, false);
        StringBuffer buffer = new StringBuffer();

        group.appendUsage(buffer, new HashSet(), ReverseStringComparator.getInstance(), "|");

        assertTrue(buffer.length() > 0);
    }

    public void testHelpLinesIsNeverNull() {
        GroupImpl group = new GroupImpl(new ArrayList(), "g", "d", 0, 0, false);

        List lines = group.helpLines(0, new HashSet(), ReverseStringComparator.getInstance());

        assertNotNull(lines);
    }
}
