package org.apache.commons.lang3.builder;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.Map;

import org.junit.Test;

/**
 * Tests for {@link ToStringStyle}, driven entirely by the documented contract.
 */
public class ToStringStyleAgentTest {

    /**
     * Minimal concrete subclass that overrides nothing, used to exercise the
     * base class behavior of the (otherwise protected) instance methods.
     */
    static class SimpleStyle extends ToStringStyle {
        private static final long serialVersionUID = 1L;
    }

    private SimpleStyle newStyle() {
        return new SimpleStyle();
    }

    private String renderPerson(ToStringStyle style, Person p) {
        StringBuffer sb = new StringBuffer();
        style.appendStart(sb, p);
        style.append(sb, "name", p.name, Boolean.TRUE);
        style.append(sb, "age", p.age);
        style.append(sb, "smoker", p.smoker);
        style.appendEnd(sb, p);
        return sb.toString();
    }

    // ------------------------------------------------------------------
    // Predefined singleton styles
    // ------------------------------------------------------------------

    @Test
    public void testPredefinedStylesAreNonNull() {
        assertNotNull(ToStringStyle.DEFAULT_STYLE);
        assertNotNull(ToStringStyle.MULTI_LINE_STYLE);
        assertNotNull(ToStringStyle.NO_FIELD_NAMES_STYLE);
        assertNotNull(ToStringStyle.SHORT_PREFIX_STYLE);
        assertNotNull(ToStringStyle.SIMPLE_STYLE);
    }

    // @Test  // pruned: failed on the fixed version
    public void testDefaultStyleMatchesDocumentedExample() {
        Person p = new Person("John Doe", 33, false);
        String result = renderPerson(ToStringStyle.DEFAULT_STYLE, p);
        assertTrue(result, result.matches("Person@[0-9a-fA-F]+\\[name=John Doe,age=33,smoker=false\\]"));
    }

    // @Test  // pruned: failed on the fixed version
    public void testMultiLineStyleMatchesDocumentedExample() {
        Person p = new Person("John Doe", 33, false);
        String result = renderPerson(ToStringStyle.MULTI_LINE_STYLE, p);
        assertTrue(result, result.matches(
                "Person@[0-9a-fA-F]+\\[\\r?\\n  name=John Doe\\r?\\n  age=33\\r?\\n  smoker=false\\r?\\n\\]"));
    }

    // @Test  // pruned: failed on the fixed version
    public void testNoFieldNamesStyleMatchesDocumentedExample() {
        Person p = new Person("John Doe", 33, false);
        String result = renderPerson(ToStringStyle.NO_FIELD_NAMES_STYLE, p);
        assertTrue(result, result.matches("Person@[0-9a-fA-F]+\\[John Doe,33,false\\]"));
    }

    @Test
    public void testShortPrefixStyleMatchesDocumentedExample() {
        Person p = new Person("John Doe", 33, false);
        String result = renderPerson(ToStringStyle.SHORT_PREFIX_STYLE, p);
        assertEquals("Person[name=John Doe,age=33,smoker=false]", result);
    }

    @Test
    public void testSimpleStyleMatchesDocumentedExample() {
        Person p = new Person("John Doe", 33, false);
        String result = renderPerson(ToStringStyle.SIMPLE_STYLE, p);
        assertEquals("John Doe,33,false", result);
    }

    // ------------------------------------------------------------------
    // Registry: register / unregister / isRegistered / getRegistry
    // ------------------------------------------------------------------

    @Test
    public void testIsRegisteredFalseForUnregisteredObject() {
        Object value = new Object();
        assertFalse(ToStringStyle.isRegistered(value));
    }

    @Test
    public void testRegisterMakesObjectVisibleInRegistryAndUnregisterRemovesIt() {
        Object value = new Object();
        assertFalse(ToStringStyle.isRegistered(value));
        ToStringStyle.register(value);
        try {
            assertTrue(ToStringStyle.isRegistered(value));
            Map<Object, Object> registry = ToStringStyle.getRegistry();
            assertNotNull(registry);
            assertTrue(registry.containsKey(value));
        } finally {
            ToStringStyle.unregister(value);
        }
        assertFalse(ToStringStyle.isRegistered(value));
    }

    // ------------------------------------------------------------------
    // Documented default texts
    // ------------------------------------------------------------------

    @Test
    public void testAppendNullTextDefaultIndicator() {
        ToStringStyle style = newStyle();
        StringBuffer sb = new StringBuffer();
        style.appendNullText(sb, "field");
        assertEquals("<null>", sb.toString());
    }

    @Test
    public void testAppendSummarySizeDefaultFormat() {
        ToStringStyle style = newStyle();
        StringBuffer sb = new StringBuffer();
        style.appendSummarySize(sb, "field", 5);
        assertEquals("<size=5>", sb.toString());
    }

    @Test
    public void testAppendSummarySizeDefaultFormatZero() {
        ToStringStyle style = newStyle();
        StringBuffer sb = new StringBuffer();
        style.appendSummarySize(sb, "field", 0);
        assertEquals("<size=0>", sb.toString());
    }

    // ------------------------------------------------------------------
    // Boolean property round trips
    // ------------------------------------------------------------------

    @Test
    public void testBooleanPropertyRoundTrips() {
        SimpleStyle style = newStyle();

        style.setUseClassName(true);
        assertTrue(style.isUseClassName());
        style.setUseClassName(false);
        assertFalse(style.isUseClassName());

        style.setUseShortClassName(true);
        assertTrue(style.isUseShortClassName());
        style.setUseShortClassName(false);
        assertFalse(style.isUseShortClassName());

        style.setUseIdentityHashCode(true);
        assertTrue(style.isUseIdentityHashCode());
        style.setUseIdentityHashCode(false);
        assertFalse(style.isUseIdentityHashCode());

        style.setUseFieldNames(true);
        assertTrue(style.isUseFieldNames());
        style.setUseFieldNames(false);
        assertFalse(style.isUseFieldNames());

        style.setDefaultFullDetail(true);
        assertTrue(style.isDefaultFullDetail());
        style.setDefaultFullDetail(false);
        assertFalse(style.isDefaultFullDetail());

        style.setArrayContentDetail(true);
        assertTrue(style.isArrayContentDetail());
        style.setArrayContentDetail(false);
        assertFalse(style.isArrayContentDetail());

        style.setFieldSeparatorAtStart(true);
        assertTrue(style.isFieldSeparatorAtStart());
        style.setFieldSeparatorAtStart(false);
        assertFalse(style.isFieldSeparatorAtStart());

        style.setFieldSeparatorAtEnd(true);
        assertTrue(style.isFieldSeparatorAtEnd());
        style.setFieldSeparatorAtEnd(false);
        assertFalse(style.isFieldSeparatorAtEnd());
    }

    // ------------------------------------------------------------------
    // String property round trips, including null -> "" conversion
    // ------------------------------------------------------------------

    @Test
    public void testStringPropertyRoundTripsAndNullBecomesEmpty() {
        SimpleStyle style = newStyle();

        style.setArrayStart("<<");
        assertEquals("<<", style.getArrayStart());
        style.setArrayStart(null);
        assertEquals("", style.getArrayStart());

        style.setArrayEnd(">>");
        assertEquals(">>", style.getArrayEnd());
        style.setArrayEnd(null);
        assertEquals("", style.getArrayEnd());

        style.setArraySeparator(";");
        assertEquals(";", style.getArraySeparator());
        style.setArraySeparator(null);
        assertEquals("", style.getArraySeparator());

        style.setContentStart("{{");
        assertEquals("{{", style.getContentStart());
        style.setContentStart(null);
        assertEquals("", style.getContentStart());

        style.setContentEnd("}}");
        assertEquals("}}", style.getContentEnd());
        style.setContentEnd(null);
        assertEquals("", style.getContentEnd());

        style.setFieldNameValueSeparator(":");
        assertEquals(":", style.getFieldNameValueSeparator());
        style.setFieldNameValueSeparator(null);
        assertEquals("", style.getFieldNameValueSeparator());

        style.setFieldSeparator("|");
        assertEquals("|", style.getFieldSeparator());
        style.setFieldSeparator(null);
        assertEquals("", style.getFieldSeparator());

        style.setNullText("NULL");
        assertEquals("NULL", style.getNullText());
        style.setNullText(null);
        assertEquals("", style.getNullText());

        style.setSizeStartText("(");
        assertEquals("(", style.getSizeStartText());
        style.setSizeStartText(null);
        assertEquals("", style.getSizeStartText());

        style.setSizeEndText(")");
        assertEquals(")", style.getSizeEndText());
        style.setSizeEndText(null);
        assertEquals("", style.getSizeEndText());

        style.setSummaryObjectStartText("<obj>");
        assertEquals("<obj>", style.getSummaryObjectStartText());
        style.setSummaryObjectStartText(null);
        assertEquals("", style.getSummaryObjectStartText());

        style.setSummaryObjectEndText("</obj>");
        assertEquals("</obj>", style.getSummaryObjectEndText());
        style.setSummaryObjectEndText(null);
        assertEquals("", style.getSummaryObjectEndText());
    }

    // ------------------------------------------------------------------
    // isFullDetail(Boolean)
    // ------------------------------------------------------------------

    @Test
    public void testIsFullDetailHonorsExplicitRequest() {
        SimpleStyle style = newStyle();
        assertTrue(style.isFullDetail(Boolean.TRUE));
        assertFalse(style.isFullDetail(Boolean.FALSE));
    }

    @Test
    public void testIsFullDetailFallsBackToDefaultWhenNull() {
        SimpleStyle style = newStyle();
        style.setDefaultFullDetail(true);
        assertTrue(style.isFullDetail(null));
        style.setDefaultFullDetail(false);
        assertFalse(style.isFullDetail(null));
    }

    // ------------------------------------------------------------------
    // getShortClassName
    // ------------------------------------------------------------------

    @Test
    public void testGetShortClassNameStripsPackage() {
        SimpleStyle style = newStyle();
        assertEquals("String", style.getShortClassName(String.class));
        assertEquals("Integer", style.getShortClassName(Integer.class));
    }

    // ------------------------------------------------------------------
    // appendClassName
    // ------------------------------------------------------------------

    @Test
    public void testAppendClassNameOmittedWhenUseClassNameDisabled() {
        SimpleStyle style = newStyle();
        style.setUseClassName(false);
        StringBuffer sb = new StringBuffer();
        style.appendClassName(sb, "hello");
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendClassNameFullWhenShortDisabled() {
        SimpleStyle style = newStyle();
        style.setUseClassName(true);
        style.setUseShortClassName(false);
        StringBuffer sb = new StringBuffer();
        style.appendClassName(sb, "hello");
        assertEquals("java.lang.String", sb.toString());
    }

    @Test
    public void testAppendClassNameShortWhenEnabled() {
        SimpleStyle style = newStyle();
        style.setUseClassName(true);
        style.setUseShortClassName(true);
        StringBuffer sb = new StringBuffer();
        style.appendClassName(sb, "hello");
        assertEquals("String", sb.toString());
    }

    // ------------------------------------------------------------------
    // appendIdentityHashCode
    // ------------------------------------------------------------------

    @Test
    public void testAppendIdentityHashCodeContainsHexOfIdentityHashCode() {
        SimpleStyle style = newStyle();
        Object obj = new Object();
        StringBuffer sb = new StringBuffer();
        style.appendIdentityHashCode(sb, obj);
        String expectedHex = Integer.toHexString(System.identityHashCode(obj));
        assertTrue(sb.toString(), sb.toString().contains(expectedHex));
    }

    // ------------------------------------------------------------------
    // appendFieldSeparator / appendFieldStart
    // ------------------------------------------------------------------

    @Test
    public void testAppendFieldSeparatorUsesConfiguredText() {
        SimpleStyle style = newStyle();
        style.setFieldSeparator(" | ");
        StringBuffer sb = new StringBuffer();
        style.appendFieldSeparator(sb);
        assertEquals(" | ", sb.toString());
    }

    @Test
    public void testAppendFieldStartUsesFieldNameWhenEnabled() {
        SimpleStyle style = newStyle();
        style.setUseFieldNames(true);
        style.setFieldNameValueSeparator("=");
        StringBuffer sb = new StringBuffer();
        style.appendFieldStart(sb, "age");
        assertEquals("age=", sb.toString());
    }

    @Test
    public void testAppendFieldStartOmitsFieldNameWhenDisabled() {
        SimpleStyle style = newStyle();
        style.setUseFieldNames(false);
        StringBuffer sb = new StringBuffer();
        style.appendFieldStart(sb, "age");
        assertEquals("", sb.toString());
    }

    // ------------------------------------------------------------------
    // appendContentStart / appendContentEnd
    // ------------------------------------------------------------------

    @Test
    public void testAppendContentStartAndEndUseConfiguredText() {
        SimpleStyle style = newStyle();
        style.setContentStart("{{");
        style.setContentEnd("}}");
        StringBuffer sb = new StringBuffer();
        style.appendContentStart(sb);
        assertEquals("{{", sb.toString());
        style.appendContentEnd(sb);
        assertEquals("{{}}", sb.toString());
    }

    // ------------------------------------------------------------------
    // appendSuper / appendToString: null is ignored
    // ------------------------------------------------------------------

    @Test
    public void testAppendSuperIgnoresNull() {
        SimpleStyle style = newStyle();
        StringBuffer sb = new StringBuffer();
        style.appendSuper(sb, null);
        assertEquals("", sb.toString());
    }

    @Test
    public void testAppendToStringIgnoresNull() {
        SimpleStyle style = newStyle();
        StringBuffer sb = new StringBuffer();
        style.appendToString(sb, null);
        assertEquals("", sb.toString());
    }

    // ------------------------------------------------------------------
    // append(Object,Boolean) with a null value falls back to the null text
    // ------------------------------------------------------------------

    @Test
    public void testAppendObjectNullValueUsesNullText() {
        SimpleStyle style = newStyle();
        style.setUseFieldNames(false);
        StringBuffer sb = new StringBuffer();
        style.append(sb, "field", (Object) null, Boolean.TRUE);
        assertTrue(sb.toString(), sb.toString().contains(style.getNullText()));
    }

    // ------------------------------------------------------------------
    // Typed append(int) and removeLastFieldSeparator
    // ------------------------------------------------------------------

    @Test
    public void testAppendIntProducesDecimalValueFollowedByFieldSeparator() {
        SimpleStyle style = newStyle();
        style.setUseFieldNames(true);
        style.setFieldNameValueSeparator("=");
        style.setFieldSeparator(",");
        StringBuffer sb = new StringBuffer();
        style.append(sb, "age", 42);
        assertEquals("age=42,", sb.toString());
    }

    @Test
    public void testRemoveLastFieldSeparatorStripsTrailingSeparator() {
        SimpleStyle style = newStyle();
        style.setFieldSeparator(",");
        StringBuffer sb = new StringBuffer("abc,");
        style.removeLastFieldSeparator(sb);
        assertEquals("abc", sb.toString());
    }
}

/**
 * Fixture type mirroring the "Person" example used throughout the
 * {@link ToStringStyle} field documentation (name, age, smoker).
 */
class Person {
    final String name;
    final int age;
    final boolean smoker;

    Person(String name, int age, boolean smoker) {
        this.name = name;
        this.age = age;
        this.smoker = smoker;
    }
}
