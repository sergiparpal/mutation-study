/*
 * Copyright (C) 2024 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.gson.internal.bind;

import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.internal.ConstructorConstructor;
import com.google.gson.internal.Excluder;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

import junit.framework.TestCase;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;

/**
 * Self-contained unit tests for {@link ReflectiveTypeAdapterFactory}.
 */
public class ReflectiveTypeAdapterFactoryAgentTest extends TestCase {

  private ReflectiveTypeAdapterFactory factory;
  private Gson gson;

  @Override protected void setUp() {
    Map<java.lang.reflect.Type, com.google.gson.InstanceCreator<?>> emptyCreators =
        new HashMap<java.lang.reflect.Type, com.google.gson.InstanceCreator<?>>();
    ConstructorConstructor constructorConstructor = new ConstructorConstructor(emptyCreators);
    factory = new ReflectiveTypeAdapterFactory(
        constructorConstructor, FieldNamingPolicy.IDENTITY, Excluder.DEFAULT);
    gson = new Gson();
  }

  // Fixtures

  static class Simple {
    String name;
    int age;
  }

  static class WithTransientAndStatic {
    String visible;
    transient String hiddenTransient = "t";
    static String hiddenStatic = "s";
  }

  static class WithSerializedName {
    @SerializedName("real_name")
    String name;
  }

  static class WithAlternateNames {
    @SerializedName(value = "real_name", alternate = {"alt1", "alt2"})
    String name;
  }

  static class DuplicateNames {
    @SerializedName("same")
    String a;
    @SerializedName("same")
    String b;
  }

  static class WithPrimitive {
    int value;
  }

  static class Empty {
  }

  // Helpers

  private <T> ReflectiveTypeAdapterFactory.Adapter<T> createAdapter(Class<T> clazz) {
    TypeAdapter<T> adapter = factory.create(gson, TypeToken.get(clazz));
    return (ReflectiveTypeAdapterFactory.Adapter<T>) adapter;
  }

  private String write(TypeAdapter<Object> adapter, Object value) throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter jsonWriter = new JsonWriter(stringWriter);
    adapter.write(jsonWriter, value);
    jsonWriter.close();
    return stringWriter.toString();
  }

  // create()

  public void testCreate_returnsNullForPrimitiveType() {
    TypeAdapter<Integer> adapter = factory.create(gson, TypeToken.get(int.class));
    assertNull(adapter);
  }

  public void testCreate_returnsAdapterForObjectType() {
    TypeAdapter<Simple> adapter = factory.create(gson, TypeToken.get(Simple.class));
    assertNotNull(adapter);
    assertTrue(adapter instanceof ReflectiveTypeAdapterFactory.Adapter);
  }

  public void testCreate_duplicateSerializedNameThrows() {
    try {
      factory.create(gson, TypeToken.get(DuplicateNames.class));
      fail("Expected IllegalArgumentException for duplicate field names");
    } catch (IllegalArgumentException expected) {
      assertTrue(expected.getMessage().contains("same"));
    }
  }

  // round trip / write+read behavior

  public void testWriteThenRead_roundTrip() throws IOException {
    ReflectiveTypeAdapterFactory.Adapter<Simple> adapter = createAdapter(Simple.class);
    Simple original = new Simple();
    original.name = "Alice";
    original.age = 30;

    StringWriter stringWriter = new StringWriter();
    JsonWriter jsonWriter = new JsonWriter(stringWriter);
    adapter.write(jsonWriter, original);
    jsonWriter.close();
    String json = stringWriter.toString();
    assertTrue(json.contains("\"name\":\"Alice\""));
    assertTrue(json.contains("\"age\":30"));

    JsonReader jsonReader = new JsonReader(new StringReader(json));
    Simple result = adapter.read(jsonReader);
    assertEquals("Alice", result.name);
    assertEquals(30, result.age);
  }

  public void testWrite_nullValueWritesJsonNull() throws IOException {
    ReflectiveTypeAdapterFactory.Adapter<Simple> adapter = createAdapter(Simple.class);
    StringWriter stringWriter = new StringWriter();
    JsonWriter jsonWriter = new JsonWriter(stringWriter);
    jsonWriter.setLenient(true);
    adapter.write(jsonWriter, null);
    jsonWriter.close();
    assertEquals("null", stringWriter.toString());
  }

  public void testRead_jsonNullReturnsNull() throws IOException {
    ReflectiveTypeAdapterFactory.Adapter<Simple> adapter = createAdapter(Simple.class);
    JsonReader jsonReader = new JsonReader(new StringReader("null"));
    jsonReader.setLenient(true);
    Simple result = adapter.read(jsonReader);
    assertNull(result);
  }

  public void testRead_unknownFieldIsSkipped() throws IOException {
    ReflectiveTypeAdapterFactory.Adapter<Simple> adapter = createAdapter(Simple.class);
    JsonReader jsonReader = new JsonReader(
        new StringReader("{\"name\":\"Bob\",\"unknownField\":{\"nested\":[1,2,3]},\"age\":5}"));
    Simple result = adapter.read(jsonReader);
    assertEquals("Bob", result.name);
    assertEquals(5, result.age);
  }

  public void testRead_nullValueForPrimitiveFieldKeepsDefault() throws IOException {
    ReflectiveTypeAdapterFactory.Adapter<WithPrimitive> adapter = createAdapter(WithPrimitive.class);
    JsonReader jsonReader = new JsonReader(new StringReader("{\"value\":null}"));
    WithPrimitive result = adapter.read(jsonReader);
    assertEquals(0, result.value);
  }

  public void testRead_emptyObjectProducesDefaultInstance() throws IOException {
    ReflectiveTypeAdapterFactory.Adapter<Empty> adapter = createAdapter(Empty.class);
    JsonReader jsonReader = new JsonReader(new StringReader("{}"));
    Empty result = adapter.read(jsonReader);
    assertNotNull(result);
  }

  // field exclusion

  public void testWrite_excludesTransientAndStaticFields() throws IOException {
    ReflectiveTypeAdapterFactory.Adapter<WithTransientAndStatic> adapter =
        createAdapter(WithTransientAndStatic.class);
    WithTransientAndStatic instance = new WithTransientAndStatic();
    instance.visible = "v";

    StringWriter stringWriter = new StringWriter();
    JsonWriter jsonWriter = new JsonWriter(stringWriter);
    adapter.write(jsonWriter, instance);
    jsonWriter.close();
    String json = stringWriter.toString();
    assertTrue(json.contains("visible"));
    assertFalse(json.contains("hiddenTransient"));
    assertFalse(json.contains("hiddenStatic"));
  }

  public void testRead_transientFieldIsNotPopulatedFromJson() throws IOException {
    ReflectiveTypeAdapterFactory.Adapter<WithTransientAndStatic> adapter =
        createAdapter(WithTransientAndStatic.class);
    JsonReader jsonReader = new JsonReader(
        new StringReader("{\"visible\":\"v\",\"hiddenTransient\":\"changed\"}"));
    WithTransientAndStatic result = adapter.read(jsonReader);
    assertEquals("v", result.visible);
    assertEquals("t", result.hiddenTransient);
  }

  // @SerializedName handling

  public void testSerializedName_usedForWriteAndRead() throws IOException {
    ReflectiveTypeAdapterFactory.Adapter<WithSerializedName> adapter =
        createAdapter(WithSerializedName.class);
    WithSerializedName instance = new WithSerializedName();
    instance.name = "x";

    StringWriter stringWriter = new StringWriter();
    JsonWriter jsonWriter = new JsonWriter(stringWriter);
    adapter.write(jsonWriter, instance);
    jsonWriter.close();
    assertEquals("{\"real_name\":\"x\"}", stringWriter.toString());

    JsonReader jsonReader = new JsonReader(new StringReader("{\"real_name\":\"y\"}"));
    WithSerializedName result = adapter.read(jsonReader);
    assertEquals("y", result.name);
  }

  public void testSerializedName_alternatesAreReadButNotWritten() throws IOException {
    ReflectiveTypeAdapterFactory.Adapter<WithAlternateNames> adapter =
        createAdapter(WithAlternateNames.class);

    JsonReader jsonReader = new JsonReader(new StringReader("{\"alt1\":\"z\"}"));
    WithAlternateNames result = adapter.read(jsonReader);
    assertEquals("z", result.name);

    WithAlternateNames instance = new WithAlternateNames();
    instance.name = "w";
    StringWriter stringWriter = new StringWriter();
    JsonWriter jsonWriter = new JsonWriter(stringWriter);
    adapter.write(jsonWriter, instance);
    jsonWriter.close();
    assertEquals("{\"real_name\":\"w\"}", stringWriter.toString());
  }

  // excludeField() / static helper

  // Note: despite its name, excludeField() returns true when the field
  // should be INCLUDED (i.e. is not excluded), matching its usage in
  // getBoundFields() where the result is assigned to a "serialize" flag.
  public void testExcludeField_instanceMethodDelegatesToExcluder() throws NoSuchFieldException {
    java.lang.reflect.Field visibleField = WithTransientAndStatic.class.getDeclaredField("visible");
    java.lang.reflect.Field transientField =
        WithTransientAndStatic.class.getDeclaredField("hiddenTransient");
    assertTrue(factory.excludeField(visibleField, true));
    assertFalse(factory.excludeField(transientField, true));
  }

  public void testExcludeField_staticHelperMatchesInstanceMethod() throws NoSuchFieldException {
    java.lang.reflect.Field staticField = WithTransientAndStatic.class.getDeclaredField("hiddenStatic");
    assertFalse(ReflectiveTypeAdapterFactory.excludeField(staticField, true, Excluder.DEFAULT));
    assertFalse(ReflectiveTypeAdapterFactory.excludeField(staticField, false, Excluder.DEFAULT));
  }
}
