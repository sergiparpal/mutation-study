/*
 * Copyright (C) 2014 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.gson.internal;

import java.lang.reflect.Field;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;

import junit.framework.TestCase;

public final class $Gson$TypesAgentTest extends TestCase {

  // ---- fixtures ----

  private static class Box<T> {
    T value;
  }

  private static final class StringBox extends Box<String> {
  }

  private static final class StringList extends ArrayList<String> {
  }

  private static final class StringIntMap extends HashMap<String, Integer> {
  }

  private static final class GenericMethodHolder {
    <T> T identity(T t) {
      return t;
    }
  }

  // A Type implementation that is neither Class, ParameterizedType,
  // GenericArrayType, TypeVariable nor WildcardType.
  private static final class UnsupportedType implements Type {
    @Override public String toString() {
      return "unsupported";
    }
  }

  // ---- newParameterizedTypeWithOwner ----

  public void testNewParameterizedTypeWithOwner_topLevelClassNeedsNoOwner() {
    ParameterizedType type = $Gson$Types.newParameterizedTypeWithOwner(
        null, ArrayList.class, String.class);
    assertNull(type.getOwnerType());
    assertEquals(ArrayList.class, type.getRawType());
    assertEquals(1, type.getActualTypeArguments().length);
    assertEquals(String.class, type.getActualTypeArguments()[0]);
  }

  public void testNewParameterizedTypeWithOwner_staticInnerClassNeedsNoOwner() {
    ParameterizedType type = $Gson$Types.newParameterizedTypeWithOwner(
        null, Box.class, String.class);
    assertNull(type.getOwnerType());
    assertEquals(String.class, type.getActualTypeArguments()[0]);
  }

  public void testNewParameterizedTypeWithOwner_nonStaticInnerClassRequiresOwner() {
    class Local {
    }
    try {
      $Gson$Types.newParameterizedTypeWithOwner(null, Local.class, String.class);
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  public void testNewParameterizedTypeWithOwner_rejectsPrimitiveTypeArgument() {
    try {
      $Gson$Types.newParameterizedTypeWithOwner(null, ArrayList.class, int.class);
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  public void testNewParameterizedTypeWithOwner_rejectsNullTypeArgument() {
    try {
      $Gson$Types.newParameterizedTypeWithOwner(null, ArrayList.class, (Type) null);
      fail();
    } catch (NullPointerException expected) {
    }
  }

  public void testNewParameterizedTypeWithOwner_toStringAndEquals() {
    ParameterizedType a = $Gson$Types.newParameterizedTypeWithOwner(
        null, ArrayList.class, String.class);
    ParameterizedType b = $Gson$Types.newParameterizedTypeWithOwner(
        null, ArrayList.class, String.class);
    assertEquals("java.util.ArrayList<java.lang.String>", a.toString());
    assertTrue(a.equals(b));
    assertEquals(a.hashCode(), b.hashCode());
  }

  public void testNewParameterizedTypeWithOwner_noTypeArguments() {
    ParameterizedType type = $Gson$Types.newParameterizedTypeWithOwner(
        null, ArrayList.class);
    assertEquals("java.util.ArrayList", type.toString());
    assertEquals(0, type.getActualTypeArguments().length);
  }

  // ---- arrayOf ----

  public void testArrayOf() {
    GenericArrayType arrayType = $Gson$Types.arrayOf(String.class);
    assertEquals(String.class, arrayType.getGenericComponentType());
    assertEquals("java.lang.String[]", arrayType.toString());
  }

  // ---- subtypeOf / supertypeOf ----

  public void testSubtypeOfObject() {
    WildcardType type = $Gson$Types.subtypeOf(Object.class);
    assertEquals(Object.class, type.getUpperBounds()[0]);
    assertEquals(0, type.getLowerBounds().length);
    assertEquals("?", type.toString());
  }

  public void testSubtypeOfSpecificClass() {
    WildcardType type = $Gson$Types.subtypeOf(CharSequence.class);
    assertEquals(CharSequence.class, type.getUpperBounds()[0]);
    assertEquals("? extends java.lang.CharSequence", type.toString());
  }

  public void testSubtypeOfWildcardBound() {
    WildcardType bound = $Gson$Types.subtypeOf(Number.class);
    WildcardType type = $Gson$Types.subtypeOf(bound);
    assertEquals(Number.class, type.getUpperBounds()[0]);
  }

  public void testSubtypeOfRejectsPrimitive() {
    try {
      $Gson$Types.subtypeOf(int.class);
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  public void testSupertypeOf() {
    WildcardType type = $Gson$Types.supertypeOf(String.class);
    assertEquals(Object.class, type.getUpperBounds()[0]);
    assertEquals(String.class, type.getLowerBounds()[0]);
    assertEquals("? super java.lang.String", type.toString());
  }

  public void testSupertypeOfWildcardBound() {
    WildcardType bound = $Gson$Types.supertypeOf(Integer.class);
    WildcardType type = $Gson$Types.supertypeOf(bound);
    assertEquals(Integer.class, type.getLowerBounds()[0]);
  }

  // ---- canonicalize ----

  public void testCanonicalizeNonArrayClassReturnsSameInstance() {
    assertSame(String.class, $Gson$Types.canonicalize(String.class));
  }

  public void testCanonicalizeArrayClassBecomesGenericArrayType() {
    Type canonical = $Gson$Types.canonicalize(String[].class);
    assertTrue(canonical instanceof GenericArrayType);
    assertEquals(String.class, ((GenericArrayType) canonical).getGenericComponentType());
  }

  public void testCanonicalizeParameterizedType() {
    ParameterizedType original = $Gson$Types.newParameterizedTypeWithOwner(
        null, ArrayList.class, String.class);
    Type canonical = $Gson$Types.canonicalize(original);
    assertTrue(canonical instanceof ParameterizedType);
    assertTrue($Gson$Types.equals(original, canonical));
  }

  public void testCanonicalizeUnsupportedTypeReturnsSameInstance() {
    Type unsupported = new UnsupportedType();
    assertSame(unsupported, $Gson$Types.canonicalize(unsupported));
  }

  // ---- getRawType ----

  public void testGetRawTypeOfClass() {
    assertEquals(String.class, $Gson$Types.getRawType(String.class));
  }

  public void testGetRawTypeOfParameterizedType() {
    ParameterizedType type = $Gson$Types.newParameterizedTypeWithOwner(
        null, ArrayList.class, String.class);
    assertEquals(ArrayList.class, $Gson$Types.getRawType(type));
  }

  public void testGetRawTypeOfGenericArrayType() {
    GenericArrayType type = $Gson$Types.arrayOf(String.class);
    assertEquals(String[].class, $Gson$Types.getRawType(type));
  }

  public void testGetRawTypeOfTypeVariable() {
    TypeVariable<?> typeVariable = Box.class.getTypeParameters()[0];
    assertEquals(Object.class, $Gson$Types.getRawType(typeVariable));
  }

  public void testGetRawTypeOfWildcardType() {
    WildcardType type = $Gson$Types.subtypeOf(Number.class);
    assertEquals(Number.class, $Gson$Types.getRawType(type));
  }

  public void testGetRawTypeOfNullThrows() {
    try {
      $Gson$Types.getRawType(null);
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  public void testGetRawTypeOfUnsupportedTypeThrows() {
    try {
      $Gson$Types.getRawType(new UnsupportedType());
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  // ---- equals ----

  public void testEqualsSameInstance() {
    assertTrue($Gson$Types.equals(String.class, String.class));
  }

  public void testEqualsNullAndNull() {
    assertTrue($Gson$Types.equals(null, null));
  }

  public void testEqualsClassVersusDifferentClass() {
    assertFalse($Gson$Types.equals(String.class, Integer.class));
  }

  public void testEqualsParameterizedTypes() {
    ParameterizedType a = $Gson$Types.newParameterizedTypeWithOwner(
        null, ArrayList.class, String.class);
    ParameterizedType b = $Gson$Types.newParameterizedTypeWithOwner(
        null, ArrayList.class, String.class);
    ParameterizedType c = $Gson$Types.newParameterizedTypeWithOwner(
        null, ArrayList.class, Integer.class);
    assertTrue($Gson$Types.equals(a, b));
    assertFalse($Gson$Types.equals(a, c));
    assertFalse($Gson$Types.equals(a, String.class));
  }

  public void testEqualsGenericArrayTypes() {
    GenericArrayType a = $Gson$Types.arrayOf(String.class);
    GenericArrayType b = $Gson$Types.arrayOf(String.class);
    GenericArrayType c = $Gson$Types.arrayOf(Integer.class);
    assertTrue($Gson$Types.equals(a, b));
    assertFalse($Gson$Types.equals(a, c));
    assertFalse($Gson$Types.equals(a, String.class));
  }

  public void testEqualsWildcardTypes() {
    WildcardType a = $Gson$Types.subtypeOf(Number.class);
    WildcardType b = $Gson$Types.subtypeOf(Number.class);
    WildcardType c = $Gson$Types.supertypeOf(Number.class);
    assertTrue($Gson$Types.equals(a, b));
    assertFalse($Gson$Types.equals(a, c));
    assertFalse($Gson$Types.equals(a, String.class));
  }

  public void testEqualsTypeVariables() throws NoSuchMethodException {
    TypeVariable<?> fromBox = Box.class.getTypeParameters()[0];
    TypeVariable<?> alsoFromBox = Box.class.getTypeParameters()[0];
    Method identity = GenericMethodHolder.class.getDeclaredMethod("identity", Object.class);
    TypeVariable<?> fromMethod = (TypeVariable<?>) identity.getGenericParameterTypes()[0];

    assertTrue($Gson$Types.equals(fromBox, alsoFromBox));
    // Same name ("T") but declared by a different GenericDeclaration.
    assertFalse($Gson$Types.equals(fromBox, fromMethod));
    assertFalse($Gson$Types.equals(fromBox, String.class));
  }

  public void testEqualsUnsupportedTypeIsNeverEqual() {
    assertFalse($Gson$Types.equals(new UnsupportedType(), new UnsupportedType()));
  }

  // ---- typeToString ----

  public void testTypeToStringOfClass() {
    assertEquals("java.lang.String", $Gson$Types.typeToString(String.class));
  }

  public void testTypeToStringOfNonClassType() {
    GenericArrayType type = $Gson$Types.arrayOf(String.class);
    assertEquals(type.toString(), $Gson$Types.typeToString(type));
  }

  // ---- getArrayComponentType ----

  public void testGetArrayComponentTypeOfClassArray() {
    assertEquals(String.class, $Gson$Types.getArrayComponentType(String[].class));
  }

  public void testGetArrayComponentTypeOfGenericArrayType() {
    GenericArrayType type = $Gson$Types.arrayOf(String.class);
    assertEquals(String.class, $Gson$Types.getArrayComponentType(type));
  }

  // ---- getCollectionElementType ----

  public void testGetCollectionElementTypeResolvesTypeArgument() {
    Type elementType = $Gson$Types.getCollectionElementType(StringList.class, StringList.class);
    assertEquals(String.class, elementType);
  }

  public void testGetCollectionElementTypeOfRawCollectionIsObject() {
    // When the context *is* the raw Collection interface (no generic signature
    // to resolve against), the element type falls back to Object.
    Type elementType = $Gson$Types.getCollectionElementType(
        java.util.Collection.class, java.util.Collection.class);
    assertEquals(Object.class, elementType);
  }

  // ---- getMapKeyAndValueTypes ----

  public void testGetMapKeyAndValueTypesResolvesTypeArguments() {
    Type[] types = $Gson$Types.getMapKeyAndValueTypes(StringIntMap.class, StringIntMap.class);
    assertEquals(2, types.length);
    assertEquals(String.class, types[0]);
    assertEquals(Integer.class, types[1]);
  }

  public void testGetMapKeyAndValueTypesOfRawMapIsObjectObject() {
    // When the context *is* the raw Map interface (no generic signature to
    // resolve against), the key/value types fall back to Object.
    Type[] types = $Gson$Types.getMapKeyAndValueTypes(
        java.util.Map.class, java.util.Map.class);
    assertEquals(Object.class, types[0]);
    assertEquals(Object.class, types[1]);
  }

  public void testGetMapKeyAndValueTypesOfPropertiesIsSpecialCased() {
    Type[] types = $Gson$Types.getMapKeyAndValueTypes(Properties.class, Properties.class);
    assertEquals(String.class, types[0]);
    assertEquals(String.class, types[1]);
  }

  // ---- getSupertype ----

  public void testGetSupertypeRejectsUnrelatedSupertype() {
    try {
      $Gson$Types.getSupertype(String.class, String.class, java.util.List.class);
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  // ---- resolve ----

  public void testResolveTypeVariableFromFieldDeclaration() throws NoSuchFieldException {
    Field valueField = Box.class.getDeclaredField("value");
    Type fieldType = valueField.getGenericType();
    assertTrue(fieldType instanceof TypeVariable);

    Type resolved = $Gson$Types.resolve(StringBox.class, StringBox.class, fieldType);
    assertEquals(String.class, resolved);
  }

  public void testResolveNonVariableTypeIsUnchanged() {
    Type resolved = $Gson$Types.resolve(StringBox.class, StringBox.class, Integer.class);
    assertEquals(Integer.class, resolved);
  }

  public void testResolveUnboundTypeVariableIsUnchanged() {
    TypeVariable<?> methodTypeVariable;
    try {
      methodTypeVariable = (TypeVariable<?>) GenericMethodHolder.class
          .getDeclaredMethod("identity", Object.class).getGenericParameterTypes()[0];
    } catch (NoSuchMethodException e) {
      throw new AssertionError(e);
    }
    // Declared by a Method, not a Class, so it cannot be resolved further.
    Type resolved = $Gson$Types.resolve(
        GenericMethodHolder.class, GenericMethodHolder.class, methodTypeVariable);
    assertSame(methodTypeVariable, resolved);
  }

  // ---- package-private helpers ----

  public void testEqualHelper() {
    assertTrue($Gson$Types.equal(null, null));
    assertTrue($Gson$Types.equal("a", "a"));
    assertFalse($Gson$Types.equal("a", "b"));
    assertFalse($Gson$Types.equal("a", null));
    assertFalse($Gson$Types.equal(null, "b"));
  }

  public void testHashCodeOrZero() {
    assertEquals(0, $Gson$Types.hashCodeOrZero(null));
    assertEquals("x".hashCode(), $Gson$Types.hashCodeOrZero("x"));
  }

  public void testCheckNotPrimitiveAcceptsNonPrimitive() {
    // Should not throw for a non-primitive type.
    $Gson$Types.checkNotPrimitive(String.class);
  }

  public void testCheckNotPrimitiveRejectsPrimitive() {
    try {
      $Gson$Types.checkNotPrimitive(int.class);
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }
}
