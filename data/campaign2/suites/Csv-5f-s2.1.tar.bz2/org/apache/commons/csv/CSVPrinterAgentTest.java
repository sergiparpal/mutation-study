package org.apache.commons.csv;

import junit.framework.TestCase;

import java.io.Flushable;
import java.io.StringWriter;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Self-contained tests for {@link CSVPrinter}, based purely on the documented
 * contract in CSVPrinter.html and the package description of
 * org.apache.commons.csv.
 */
public class CSVPrinterAgentTest extends TestCase {

    // ---- fixtures -------------------------------------------------------

    /** An Appendable that also tracks flush() calls, like many real streams do. */
    private static class TrackingAppendable implements Appendable, Flushable {
        final StringBuilder sb = new StringBuilder();
        boolean flushed = false;

        public Appendable append(CharSequence csq) {
            sb.append(csq);
            return this;
        }

        public Appendable append(CharSequence csq, int start, int end) {
            sb.append(csq, start, end);
            return this;
        }

        public Appendable append(char c) {
            sb.append(c);
            return this;
        }

        public void flush() {
            flushed = true;
        }

        public String toString() {
            return sb.toString();
        }
    }

    /**
     * Builds a minimal java.sql.ResultSet backed by the given column names and
     * row data, sufficient for CSVPrinter.printRecords(ResultSet) to consume:
     * getMetaData().getColumnCount(), next() and getObject(int).
     */
    private static ResultSet newResultSet(final String[] columnNames, final Object[][] rows) {
        final ResultSetMetaData metaData = (ResultSetMetaData) Proxy.newProxyInstance(
                CSVPrinterAgentTest.class.getClassLoader(),
                new Class[] {ResultSetMetaData.class},
                new InvocationHandler() {
                    public Object invoke(Object proxy, Method method, Object[] args) {
                        if ("getColumnCount".equals(method.getName())) {
                            return Integer.valueOf(columnNames.length);
                        }
                        throw new UnsupportedOperationException(method.getName());
                    }
                });

        return (ResultSet) Proxy.newProxyInstance(
                CSVPrinterAgentTest.class.getClassLoader(),
                new Class[] {ResultSet.class},
                new InvocationHandler() {
                    private int rowIndex = -1;

                    public Object invoke(Object proxy, Method method, Object[] args) {
                        String name = method.getName();
                        if ("getMetaData".equals(name)) {
                            return metaData;
                        }
                        if ("next".equals(name)) {
                            rowIndex++;
                            return Boolean.valueOf(rowIndex < rows.length);
                        }
                        if ("getObject".equals(name)) {
                            int columnIndex = ((Integer) args[0]).intValue();
                            return rows[rowIndex][columnIndex - 1];
                        }
                        throw new UnsupportedOperationException(name);
                    }
                });
    }

    /** A ResultSet whose getMetaData() call fails with SQLException. */
    private static ResultSet newFailingResultSet() {
        return (ResultSet) Proxy.newProxyInstance(
                CSVPrinterAgentTest.class.getClassLoader(),
                new Class[] {ResultSet.class},
                new InvocationHandler() {
                    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
                        if ("getMetaData".equals(method.getName())) {
                            throw new SQLException("boom");
                        }
                        throw new UnsupportedOperationException(method.getName());
                    }
                });
    }

    // ---- constructor ------------------------------------------------------

    public void testConstructorNullOutThrowsIllegalArgumentException() {
        try {
            new CSVPrinter(null, CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented
        }
    }

    public void testConstructorNullFormatThrowsIllegalArgumentException() {
        try {
            new CSVPrinter(new StringWriter(), null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented
        }
    }

    public void pruned_testConstructorRejectsInconsistentHybridFormat() {
        CSVFormat hybrid = CSVFormat.DEFAULT.withQuoteChar('"').withEscape('\\');
        try {
            new CSVPrinter(new StringWriter(), hybrid);
            fail("Expected IllegalArgumentException for hybrid encapsulation/escaping format");
        } catch (IllegalArgumentException expected) {
            // documented: "Hybrid formats ... are not supported"
        }
    }

    public void testGetOutReturnsTheAppendableGivenToConstructor() throws Exception {
        StringWriter sw = new StringWriter();
        CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        assertSame(sw, printer.getOut());
    }

    // ---- print --------------------------------------------------------

    public void testPrintSimpleValueIsNotQuoted() throws Exception {
        StringWriter sw = new StringWriter();
        CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("a");
        assertEquals("a", sw.toString());
    }

    public void testPrintSecondValueOnSameLineInsertsDelimiter() throws Exception {
        StringWriter sw = new StringWriter();
        CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("a");
        printer.print("b");
        assertEquals("a,b", sw.toString());
    }

    public void testPrintValueContainingDelimiterIsEncapsulated() throws Exception {
        StringWriter sw = new StringWriter();
        CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("a,b");
        assertEquals("\"a,b\"", sw.toString());
    }

    public void testPrintValueContainingQuoteCharDoublesIt() throws Exception {
        StringWriter sw = new StringWriter();
        CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("a\"b");
        assertEquals("\"a\"\"b\"", sw.toString());
    }

    public void testPrintStartsNewLineWithoutLeadingDelimiter() throws Exception {
        StringWriter sw = new StringWriter();
        CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("\n");
        CSVPrinter printer = new CSVPrinter(sw, format);
        printer.print("a");
        printer.println();
        printer.print("b");
        assertEquals("a\nb", sw.toString());
    }

    // ---- println --------------------------------------------------------

    public void testPrintlnOutputsExactlyTheRecordSeparator() throws Exception {
        StringWriter sw = new StringWriter();
        CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("\n");
        CSVPrinter printer = new CSVPrinter(sw, format);
        printer.println();
        assertEquals("\n", sw.toString());
    }

    public void testPrintlnWithCarriageReturnLineFeedSeparator() throws Exception {
        StringWriter sw = new StringWriter();
        CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("\r\n");
        CSVPrinter printer = new CSVPrinter(sw, format);
        printer.println();
        assertEquals("\r\n", sw.toString());
    }

    // ---- printComment ---------------------------------------------------

    public void testPrintCommentDoesNothingWhenCommentsDisabled() throws Exception {
        StringWriter sw = new StringWriter();
        CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printComment("a comment");
        assertEquals("", sw.toString());
    }

    public void testPrintCommentOnFreshLine() throws Exception {
        StringWriter sw = new StringWriter();
        CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("\n").withCommentStart('#');
        CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printComment("hello");
        assertEquals("# hello\n", sw.toString());
    }

    public void testPrintCommentStartsNewLineWhenMidRecord() throws Exception {
        StringWriter sw = new StringWriter();
        CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("\n").withCommentStart('#');
        CSVPrinter printer = new CSVPrinter(sw, format);
        printer.print("a");
        printer.printComment("hello");
        assertEquals("a\n# hello\n", sw.toString());
    }

    public void testPrintCommentWithMultipleLinesPrefixesEachLine() throws Exception {
        StringWriter sw = new StringWriter();
        CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("\n").withCommentStart('#');
        CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printComment("line1\nline2");
        assertEquals("# line1\n# line2\n", sw.toString());
    }

    // ---- printRecord ------------------------------------------------------

    public void testPrintRecordVarargsJoinsWithDelimiterAndEndsLine() throws Exception {
        StringWriter sw = new StringWriter();
        CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("\n");
        CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printRecord("a", "b", "c");
        assertEquals("a,b,c\n", sw.toString());
    }

    public void testPrintRecordIterableJoinsWithDelimiterAndEndsLine() throws Exception {
        StringWriter sw = new StringWriter();
        CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("\n");
        CSVPrinter printer = new CSVPrinter(sw, format);
        List<String> values = new ArrayList<String>();
        values.add("a");
        values.add("b");
        printer.printRecord(values);
        assertEquals("a,b\n", sw.toString());
    }

    public void testPrintRecordWithNoValuesStillEndsLine() throws Exception {
        StringWriter sw = new StringWriter();
        CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("\n");
        CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printRecord(new Object[0]);
        assertEquals("\n", sw.toString());
    }

    public void testPrintRecordEscapesEmbeddedNewline() throws Exception {
        StringWriter sw = new StringWriter();
        CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("\n");
        CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printRecord("a\nb", "c");
        assertEquals("\"a\nb\",c\n", sw.toString());
    }

    public void testTwoSuccessivePrintRecordCallsProduceTwoLines() throws Exception {
        StringWriter sw = new StringWriter();
        CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("\n");
        CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printRecord("a", "b");
        printer.printRecord("c", "d");
        assertEquals("a,b\nc,d\n", sw.toString());
    }

    // ---- printRecords(Iterable) / printRecords(Object[]) -----------------

    public void testPrintRecordsIterableOfArraysPrintsOneLinePerElement() throws Exception {
        StringWriter sw = new StringWriter();
        CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("\n");
        CSVPrinter printer = new CSVPrinter(sw, format);
        List<String[]> records = new ArrayList<String[]>();
        records.add(new String[] {"a", "b"});
        records.add(new String[] {"c", "d"});
        printer.printRecords(records);
        assertEquals("a,b\nc,d\n", sw.toString());
    }

    public void testPrintRecordsObjectArrayOfArraysPrintsOneLinePerElement() throws Exception {
        StringWriter sw = new StringWriter();
        CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("\n");
        CSVPrinter printer = new CSVPrinter(sw, format);
        Object[] records = new Object[] {new String[] {"a", "b"}, new String[] {"c", "d"}};
        printer.printRecords(records);
        assertEquals("a,b\nc,d\n", sw.toString());
    }

    public void testPrintRecordsWithEmptyArrayProducesNoOutput() throws Exception {
        StringWriter sw = new StringWriter();
        CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("\n");
        CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printRecords(new Object[0]);
        assertEquals("", sw.toString());
    }

    public void testPrintRecordsWithEmptyIterableProducesNoOutput() throws Exception {
        StringWriter sw = new StringWriter();
        CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("\n");
        CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printRecords(new ArrayList<Object>());
        assertEquals("", sw.toString());
    }

    // ---- printRecords(ResultSet) -------------------------------------------

    public void pruned_testPrintRecordsResultSetPrintsOneLinePerRow() throws Exception {
        StringWriter sw = new StringWriter();
        CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("\n");
        CSVPrinter printer = new CSVPrinter(sw, format);
        ResultSet rs = newResultSet(new String[] {"c1", "c2"}, new Object[][] {
                {"a", "b"},
                {"c", "d"}
        });
        printer.printRecords(rs);
        assertEquals("a,b\nc,d\n", sw.toString());
    }

    public void testPrintRecordsResultSetWithNoRowsProducesNoOutput() throws Exception {
        StringWriter sw = new StringWriter();
        CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("\n");
        CSVPrinter printer = new CSVPrinter(sw, format);
        ResultSet rs = newResultSet(new String[] {"c1"}, new Object[0][0]);
        printer.printRecords(rs);
        assertEquals("", sw.toString());
    }

    public void testPrintRecordsResultSetPropagatesSQLException() throws Exception {
        StringWriter sw = new StringWriter();
        CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        ResultSet rs = newFailingResultSet();
        try {
            printer.printRecords(rs);
            fail("Expected SQLException");
        } catch (SQLException expected) {
            // documented: "SQLException - if a database access error occurs"
        }
    }

    // ---- flush / close ------------------------------------------------------

    public void testFlushDelegatesToUnderlyingFlushableStream() throws Exception {
        TrackingAppendable out = new TrackingAppendable();
        CSVPrinter printer = new CSVPrinter(out, CSVFormat.DEFAULT);
        assertFalse(out.flushed);
        printer.flush();
        assertTrue(out.flushed);
    }

    public void testCloseDoesNotThrowOnPlainWriter() throws Exception {
        StringWriter sw = new StringWriter();
        CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("a");
        printer.close();
        assertEquals("a", sw.toString());
    }
}
