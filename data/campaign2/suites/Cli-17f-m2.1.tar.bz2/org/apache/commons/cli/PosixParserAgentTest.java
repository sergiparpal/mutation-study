/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.cli;

import java.util.Arrays;
import java.util.List;

import junit.framework.TestCase;

public class PosixParserAgentTest extends TestCase
{
    public void testFlattenSimpleShortOption()
    {
        Options options = new Options().addOption("a", false, "turn [a] on");

        PosixParser parser = new PosixParser();
        String[] flattened = parser.flatten(options, new String[] { "-a" }, false);

        assertEquals(1, flattened.length);
        assertEquals("-a", flattened[0]);
    }

    public void testFlattenLongOptionWithEquals()
    {
        Options options = new Options().addOption("b", "bfile", true, "set [b]");

        PosixParser parser = new PosixParser();
        String[] flattened = parser.flatten(options, new String[] { "--bfile=toast" }, false);

        assertEquals(Arrays.asList(new String[] { "--bfile", "toast" }), Arrays.asList(flattened));
    }

    public void testFlattenLongOptionWithoutEquals()
    {
        Options options = new Options().addOption("a", "enable-a", false, "turn [a] on");

        PosixParser parser = new PosixParser();
        String[] flattened = parser.flatten(options, new String[] { "--enable-a" }, false);

        assertEquals(1, flattened.length);
        assertEquals("--enable-a", flattened[0]);
    }

    public void testFlattenSingleHyphen()
    {
        Options options = new Options();

        PosixParser parser = new PosixParser();
        String[] flattened = parser.flatten(options, new String[] { "-" }, false);

        assertEquals(1, flattened.length);
        assertEquals("-", flattened[0]);
    }

    public void testFlattenDoubleDashFollowedByOption()
    {
        Options options = new Options().addOption("a", false, "turn [a] on");

        PosixParser parser = new PosixParser();
        String[] flattened = parser.flatten(options, new String[] { "--", "-a" }, false);

        assertEquals(Arrays.asList(new String[] { "--", "-a" }), Arrays.asList(flattened));
    }

    public void testFlattenBurstingMultipleFlags()
    {
        Options options = new Options()
            .addOption("a", false, "turn [a] on")
            .addOption("c", false, "turn [c] on");

        PosixParser parser = new PosixParser();
        String[] flattened = parser.flatten(options, new String[] { "-ac" }, false);

        assertEquals(Arrays.asList(new String[] { "-a", "-c" }), Arrays.asList(flattened));
    }

    public void testFlattenBurstingWithArgOption()
    {
        Options options = new Options().addOption("b", true, "set [b]");

        PosixParser parser = new PosixParser();
        String[] flattened = parser.flatten(options, new String[] { "-bvalue" }, false);

        assertEquals(Arrays.asList(new String[] { "-b", "value" }), Arrays.asList(flattened));
    }

    public void testFlattenUnknownTwoCharOptionIgnoredWithoutStop()
    {
        Options options = new Options().addOption("a", false, "turn [a] on");

        PosixParser parser = new PosixParser();
        String[] flattened = parser.flatten(options, new String[] { "-z" }, false);

        assertEquals(0, flattened.length);
    }

    public void testFlattenUnknownTwoCharOptionStopsAndGobbles()
    {
        Options options = new Options().addOption("a", false, "turn [a] on");

        PosixParser parser = new PosixParser();
        String[] flattened = parser.flatten(options, new String[] { "-z", "-a" }, true);

        assertEquals(Arrays.asList(new String[] { "-a" }), Arrays.asList(flattened));
    }

    public void testFlattenNonOptionArgumentStopAtNonOption()
    {
        Options options = new Options().addOption("a", false, "turn [a] on");

        PosixParser parser = new PosixParser();
        String[] flattened = parser.flatten(options, new String[] { "foo", "-a" }, true);

        assertEquals(Arrays.asList(new String[] { "--", "foo", "-a" }), Arrays.asList(flattened));
    }

    public void testFlattenNonOptionArgumentWithoutStop()
    {
        Options options = new Options().addOption("a", false, "turn [a] on");

        PosixParser parser = new PosixParser();
        String[] flattened = parser.flatten(options, new String[] { "foo", "-a" }, false);

        assertEquals(Arrays.asList(new String[] { "foo", "-a" }), Arrays.asList(flattened));
    }

    public void testFlattenBurstTokenUnknownCharWithoutStop()
    {
        Options options = new Options().addOption("a", false, "turn [a] on");

        PosixParser parser = new PosixParser();
        String[] flattened = parser.flatten(options, new String[] { "-ax" }, false);

        assertEquals(Arrays.asList(new String[] { "-a", "-ax" }), Arrays.asList(flattened));
    }

    public void testFlattenBurstTokenUnknownCharWithStop()
    {
        Options options = new Options().addOption("a", false, "turn [a] on");

        PosixParser parser = new PosixParser();
        String[] flattened = parser.flatten(options, new String[] { "-ax", "trailing" }, true);

        assertEquals(Arrays.asList(new String[] { "-a", "--", "x", "trailing" }), Arrays.asList(flattened));
    }

    public void testFlattenEmptyArguments()
    {
        Options options = new Options();

        PosixParser parser = new PosixParser();
        String[] flattened = parser.flatten(options, new String[0], false);

        assertEquals(0, flattened.length);
    }

    public void testParseSimpleShortAndLong() throws Exception
    {
        Options options = new Options()
            .addOption("a", "enable-a", false, "turn [a] on or off")
            .addOption("b", "bfile", true, "set the value of [b]");

        PosixParser parser = new PosixParser();
        CommandLine cl = parser.parse(options, new String[] { "-a", "-b", "toast", "foo", "bar" });

        assertTrue("Confirm -a is set", cl.hasOption("a"));
        assertTrue("Confirm -b is set", cl.hasOption("b"));
        assertEquals("toast", cl.getOptionValue("b"));
        assertEquals(2, cl.getArgList().size());
    }

    public void testParseNullArgumentsTreatedAsEmpty() throws Exception
    {
        Options options = new Options().addOption("a", false, "turn [a] on");

        PosixParser parser = new PosixParser();
        CommandLine cl = parser.parse(options, null);

        assertFalse(cl.hasOption("a"));
        assertEquals(0, cl.getArgList().size());
    }

    public void testParseMissingArgumentThrows()
    {
        Options options = new Options().addOption("b", true, "set [b]");

        PosixParser parser = new PosixParser();
        try
        {
            parser.parse(options, new String[] { "-b" });
            fail("MissingArgumentException wasn't thrown");
        }
        catch (MissingArgumentException e)
        {
            assertEquals("b", e.getOption().getOpt());
        }
        catch (ParseException e)
        {
            fail("Wrong exception type thrown: " + e);
        }
    }

    public void testParseUnrecognizedOptionThrows()
    {
        Options options = new Options().addOption("a", false, "turn [a] on");

        PosixParser parser = new PosixParser();
        try
        {
            parser.parse(options, new String[] { "-xy" });
            fail("UnrecognizedOptionException wasn't thrown");
        }
        catch (UnrecognizedOptionException e)
        {
            assertEquals("-xy", e.getOption());
        }
        catch (ParseException e)
        {
            fail("Wrong exception type thrown: " + e);
        }
    }

    public void testParseStopAtNonOption() throws Exception
    {
        Options options = new Options()
            .addOption("c", false, "turn [c] on or off")
            .addOption("b", true, "set the value of [b]");

        PosixParser parser = new PosixParser();
        CommandLine cl = parser.parse(options, new String[] { "-c", "foober", "-b", "toast" }, true);

        assertTrue("Confirm -c is set", cl.hasOption("c"));
        assertFalse("Confirm -b is not set", cl.hasOption("b"));

        List args = cl.getArgList();
        assertEquals(3, args.size());
        assertEquals("foober", args.get(0));
        assertEquals("-b", args.get(1));
        assertEquals("toast", args.get(2));
    }

    public void testParseRequiredOptionMissingThrows()
    {
        Options options = new Options();
        options.addOption(OptionBuilder.isRequired().create('r'));

        PosixParser parser = new PosixParser();
        try
        {
            parser.parse(options, new String[0]);
            fail("MissingOptionException wasn't thrown");
        }
        catch (MissingOptionException e)
        {
            assertTrue(e.getMissingOptions().contains("r"));
        }
        catch (ParseException e)
        {
            fail("Wrong exception type thrown: " + e);
        }
    }
}
