/*
 * Copyright (C) 2024 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.gson.internal;

import java.lang.reflect.GenericArrayType;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import junit.framework.TestCase;

public final class $Gson$TypesAgentTest extends TestCase {

  // -------- fixtures --------

  private static class Box<T> {
  }

  private static final class StringBox extends Box<String> {
  }

  private static final class StringArrayList extends ArrayList<String> {
  }

  private static final class RawArrayList extends ArrayList {
  }

  private static final class StringIntMap extends HashMap<String, Integer> {
  }

  private static final class RawMap extends HashMap {
  }

  private static final class Owner {
  }

  // -------- newParameterizedTypeWithOwner --------

  public void testNewParameterizedTypeWithOwner_basic() {
    ParameterizedType type =
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    assertNull(type.getOwnerType());
    assertEquals(List.class, type.getRawType());
    assertEquals(1, type.getActualTypeArguments().length);
    assertEquals(String.class, type.getActualTypeArguments()[0]);
    assertEquals("java.util.List<java.lang.String>", type.toString());
  }

  public void testNewParameterizedTypeWithOwner_noTypeArguments() {
    ParameterizedType type = $Gson$Types.newParameterizedTypeWithOwner(null, List.class);
    assertEquals(0, type.getActualTypeArguments().length);
    assertEquals("java.util.List", type.toString());
  }

  public void testNewParameterizedTypeWithOwner_defensiveCopies() {
    Type[] args = new Type[] { String.class };
    ParameterizedType type = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, args);
    args[0] = Integer.class;
    // mutating the array passed in must not affect the created type
    assertEquals(String.class, type.getActualTypeArguments()[0]);

    Type[] returned1 = type.getActualTypeArguments();
    Type[] returned2 = type.getActualTypeArguments();
    assertNotSame(returned1, returned2);
    assertEquals(returned1[0], returned2[0]);
  }

  public void testNewParameterizedTypeWithOwner_nullTypeArgumentRejected() {
    try {
      $Gson$Types.newParameterizedTypeWithOwner(null, List.class, (Type) null);
      fail();
    } catch (NullPointerException expected) {
    }
  }

  public void testNewParameterizedTypeWithOwner_primitiveTypeArgumentRejected() {
    try {
      $Gson$Types.newParameterizedTypeWithOwner(null, List.class, int.class);
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  public void testNewParameterizedTypeWithOwner_requiresOwnerForInnerClass() {
    class Local {
    }
    try {
      $Gson$Types.newParameterizedTypeWithOwner(null, Local.class, String.class);
      fail();
    } catch (IllegalArgumentException expected) {
    }

    // providing an owner makes it legal
    ParameterizedType type =
        $Gson$Types.newParameterizedTypeWithOwner(Owner.class, Local.class, String.class);
    assertEquals(Owner.class, type.getOwnerType());
  }

  public void testNewParameterizedTypeWithOwner_equalsAndHashCode() {
    ParameterizedType a =
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    ParameterizedType b =
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    assertTrue($Gson$Types.equals(a, b));
    assertEquals(a.hashCode(), b.hashCode());

    ParameterizedType c =
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, Integer.class);
    assertFalse($Gson$Types.equals(a, c));
  }

  // -------- arrayOf --------

  public void testArrayOf() {
    GenericArrayType type = $Gson$Types.arrayOf(String.class);
    assertEquals(String.class, type.getGenericComponentType());
    assertEquals("java.lang.String[]", type.toString());
  }

  // -------- subtypeOf / supertypeOf --------

  public void testSubtypeOf_objectBoundRendersAsBareWildcard() {
    WildcardType type = $Gson$Types.subtypeOf(Object.class);
    assertEquals(Object.class, type.getUpperBounds()[0]);
    assertEquals(0, type.getLowerBounds().length);
    assertEquals("?", type.toString());
  }

  public void testSubtypeOf_concreteBound() {
    WildcardType type = $Gson$Types.subtypeOf(String.class);
    assertEquals(String.class, type.getUpperBounds()[0]);
    assertEquals("? extends java.lang.String", type.toString());
  }

  public void testSubtypeOf_unwrapsExistingWildcard() {
    WildcardType inner = $Gson$Types.subtypeOf(String.class);
    WildcardType outer = $Gson$Types.subtypeOf(inner);
    assertEquals(String.class, outer.getUpperBounds()[0]);
  }

  public void testSupertypeOf_basic() {
    WildcardType type = $Gson$Types.supertypeOf(String.class);
    assertEquals(String.class, type.getLowerBounds()[0]);
    assertEquals(Object.class, type.getUpperBounds()[0]);
    assertEquals("? super java.lang.String", type.toString());
  }

  public void testSupertypeOf_unwrapsExistingWildcard() {
    WildcardType inner = $Gson$Types.supertypeOf(String.class);
    WildcardType outer = $Gson$Types.supertypeOf(inner);
    assertEquals(String.class, outer.getLowerBounds()[0]);
  }

  // -------- canonicalize --------

  public void testCanonicalize_plainClassIsUnchanged() {
    assertSame(String.class, $Gson$Types.canonicalize(String.class));
  }

  public void testCanonicalize_arrayClassBecomesGenericArrayType() {
    Type canonical = $Gson$Types.canonicalize(String[].class);
    assertTrue(canonical instanceof GenericArrayType);
    assertTrue($Gson$Types.equals(canonical, $Gson$Types.arrayOf(String.class)));
  }

  public void testCanonicalize_parameterizedTypeProducesEqualButDistinctInstance() {
    ParameterizedType original =
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    Type canonical = $Gson$Types.canonicalize(original);
    assertNotSame(original, canonical);
    assertTrue($Gson$Types.equals(original, canonical));
  }

  public void testCanonicalize_genericArrayTypeProducesEqualButDistinctInstance() {
    GenericArrayType original = $Gson$Types.arrayOf(String.class);
    Type canonical = $Gson$Types.canonicalize(original);
    assertNotSame(original, canonical);
    assertTrue($Gson$Types.equals(original, canonical));
  }

  public void testCanonicalize_wildcardTypeProducesEqualButDistinctInstance() {
    WildcardType original = $Gson$Types.subtypeOf(String.class);
    Type canonical = $Gson$Types.canonicalize(original);
    assertNotSame(original, canonical);
    assertTrue($Gson$Types.equals(original, canonical));
  }

  public void testCanonicalize_unsupportedTypeIsReturnedAsIs() {
    TypeVariable<?> typeVariable = Box.class.getTypeParameters()[0];
    assertSame(typeVariable, $Gson$Types.canonicalize(typeVariable));
  }

  // -------- getRawType --------

  public void testGetRawType_class() {
    assertEquals(String.class, $Gson$Types.getRawType(String.class));
  }

  public void testGetRawType_parameterizedType() {
    ParameterizedType type =
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    assertEquals(List.class, $Gson$Types.getRawType(type));
  }

  public void testGetRawType_genericArrayType() {
    GenericArrayType type = $Gson$Types.arrayOf(String.class);
    assertEquals(String[].class, $Gson$Types.getRawType(type));
  }

  public void testGetRawType_typeVariableFallsBackToObject() {
    TypeVariable<?> typeVariable = Box.class.getTypeParameters()[0];
    assertEquals(Object.class, $Gson$Types.getRawType(typeVariable));
  }

  public void testGetRawType_wildcardUsesUpperBound() {
    WildcardType type = $Gson$Types.subtypeOf(String.class);
    assertEquals(String.class, $Gson$Types.getRawType(type));
  }

  public void testGetRawType_unsupportedTypeThrows() {
    Type bogus = new Type() {
      @Override public String toString() {
        return "bogus";
      }
    };
    try {
      $Gson$Types.getRawType(bogus);
      fail();
    } catch (IllegalArgumentException expected) {
      assertTrue(expected.getMessage().contains("bogus"));
    }
  }

  public void testGetRawType_nullThrows() {
    try {
      $Gson$Types.getRawType(null);
      fail();
    } catch (IllegalArgumentException expected) {
      assertTrue(expected.getMessage().contains("null"));
    }
  }

  // -------- equals --------

  public void testEquals_identicalReference() {
    assertTrue($Gson$Types.equals(String.class, String.class));
  }

  public void testEquals_bothNull() {
    assertTrue($Gson$Types.equals(null, null));
  }

  public void testEquals_classVsClass() {
    assertTrue($Gson$Types.equals(String.class, String.class));
    assertFalse($Gson$Types.equals(String.class, Integer.class));
  }

  public void testEquals_parameterizedTypes() {
    ParameterizedType a =
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    ParameterizedType b =
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    ParameterizedType c =
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, Integer.class);
    assertTrue($Gson$Types.equals(a, b));
    assertFalse($Gson$Types.equals(a, c));
    assertFalse($Gson$Types.equals(a, String.class));
  }

  public void testEquals_genericArrayTypes() {
    GenericArrayType a = $Gson$Types.arrayOf(String.class);
    GenericArrayType b = $Gson$Types.arrayOf(String.class);
    GenericArrayType c = $Gson$Types.arrayOf(Integer.class);
    assertTrue($Gson$Types.equals(a, b));
    assertFalse($Gson$Types.equals(a, c));
    assertFalse($Gson$Types.equals(a, String.class));
  }

  public void testEquals_wildcardTypes() {
    WildcardType a = $Gson$Types.subtypeOf(String.class);
    WildcardType b = $Gson$Types.subtypeOf(String.class);
    WildcardType c = $Gson$Types.supertypeOf(String.class);
    assertTrue($Gson$Types.equals(a, b));
    assertFalse($Gson$Types.equals(a, c));
  }

  public void testEquals_typeVariables() {
    TypeVariable<?> a = Box.class.getTypeParameters()[0];
    TypeVariable<?> b = Box.class.getTypeParameters()[0];
    assertTrue($Gson$Types.equals(a, b));
    assertFalse($Gson$Types.equals(a, String.class));
  }

  // -------- typeToString --------

  public void testTypeToString_class() {
    assertEquals("java.lang.String", $Gson$Types.typeToString(String.class));
  }

  public void testTypeToString_nonClassUsesToString() {
    GenericArrayType type = $Gson$Types.arrayOf(String.class);
    assertEquals(type.toString(), $Gson$Types.typeToString(type));
  }

  // -------- getArrayComponentType --------

  public void testGetArrayComponentType_class() {
    assertEquals(String.class, $Gson$Types.getArrayComponentType(String[].class));
  }

  public void testGetArrayComponentType_twoDimensionalClass() {
    assertEquals(String[].class, $Gson$Types.getArrayComponentType(String[][].class));
  }

  public void testGetArrayComponentType_genericArrayType() {
    GenericArrayType type = $Gson$Types.arrayOf(String.class);
    assertEquals(String.class, $Gson$Types.getArrayComponentType(type));
  }

  // -------- getCollectionElementType --------

  public void testGetCollectionElementType_parameterized() {
    Type elementType =
        $Gson$Types.getCollectionElementType(StringArrayList.class, StringArrayList.class);
    assertEquals(String.class, elementType);
  }

  public void testGetCollectionElementType_rawTypeYieldsUnresolvedTypeVariable() {
    // Raw (non-generic) use of a generic supertype cannot be resolved to a concrete type;
    // the element type comes back as the unresolved type variable itself.
    Type elementType =
        $Gson$Types.getCollectionElementType(RawArrayList.class, RawArrayList.class);
    assertTrue(elementType instanceof TypeVariable);
    assertEquals("E", ((TypeVariable<?>) elementType).getName());
  }

  // -------- getMapKeyAndValueTypes --------

  public void testGetMapKeyAndValueTypes_propertiesSpecialCase() {
    Type[] types = $Gson$Types.getMapKeyAndValueTypes(Properties.class, Properties.class);
    assertEquals(2, types.length);
    assertEquals(String.class, types[0]);
    assertEquals(String.class, types[1]);
  }

  public void testGetMapKeyAndValueTypes_parameterized() {
    Type[] types = $Gson$Types.getMapKeyAndValueTypes(StringIntMap.class, StringIntMap.class);
    assertEquals(String.class, types[0]);
    assertEquals(Integer.class, types[1]);
  }

  public void testGetMapKeyAndValueTypes_rawTypeYieldsUnresolvedTypeVariables() {
    // Raw (non-generic) use of a generic supertype cannot be resolved to a concrete type;
    // the key/value types come back as the unresolved type variables themselves.
    Type[] types = $Gson$Types.getMapKeyAndValueTypes(RawMap.class, RawMap.class);
    assertTrue(types[0] instanceof TypeVariable);
    assertTrue(types[1] instanceof TypeVariable);
  }

  // -------- resolve / getSupertype / getGenericSupertype (package-private) --------

  public void testResolve_typeVariableResolvedThroughSubclass() {
    TypeVariable<?> typeVariable = Box.class.getTypeParameters()[0];
    Type resolved = $Gson$Types.resolve(StringBox.class, StringBox.class, typeVariable);
    assertEquals(String.class, resolved);
  }

  public void testResolve_nonVariableTypeIsUnchanged() {
    Type resolved = $Gson$Types.resolve(StringBox.class, StringBox.class, Integer.class);
    assertSame(Integer.class, resolved);
  }

  public void testGetGenericSupertype_directSupertype() {
    Type supertype = $Gson$Types.getGenericSupertype(StringBox.class, StringBox.class, Box.class);
    assertTrue(supertype instanceof ParameterizedType);
    assertEquals(String.class, ((ParameterizedType) supertype).getActualTypeArguments()[0]);
  }

  public void testGetGenericSupertype_sameTypeReturnsContextUnchanged() {
    Type supertype =
        $Gson$Types.getGenericSupertype(StringBox.class, StringBox.class, StringBox.class);
    assertSame(StringBox.class, supertype);
  }

  public void testGetSupertype_rejectsUnrelatedType() {
    try {
      $Gson$Types.getSupertype(String.class, String.class, List.class);
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  public void testGetSupertype_resolvesParameterizedSupertype() {
    Type supertype = $Gson$Types.getSupertype(StringBox.class, StringBox.class, Box.class);
    assertTrue(supertype instanceof ParameterizedType);
    assertEquals(String.class, ((ParameterizedType) supertype).getActualTypeArguments()[0]);
  }

  // -------- small package-private helpers --------

  public void testEqual_helper() {
    assertTrue($Gson$Types.equal(null, null));
    assertTrue($Gson$Types.equal("x", "x"));
    assertFalse($Gson$Types.equal("x", "y"));
    assertFalse($Gson$Types.equal("x", null));
    assertFalse($Gson$Types.equal(null, "x"));
  }

  public void testHashCodeOrZero_helper() {
    assertEquals(0, $Gson$Types.hashCodeOrZero(null));
    assertEquals("abc".hashCode(), $Gson$Types.hashCodeOrZero("abc"));
  }

  public void testCheckNotPrimitive_helper() {
    $Gson$Types.checkNotPrimitive(Integer.class);
    $Gson$Types.checkNotPrimitive(String.class);
    $Gson$Types.checkNotPrimitive(null);
    try {
      $Gson$Types.checkNotPrimitive(int.class);
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }
}
