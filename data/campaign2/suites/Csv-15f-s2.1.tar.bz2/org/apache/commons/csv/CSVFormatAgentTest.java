package org.apache.commons.csv;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.io.Reader;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;

import org.junit.Test;

public class CSVFormatAgentTest {

    private enum TestHeader {
        Name, Email, Phone
    }

    // ---- Predefined formats ----

    @Test
    public void testDefaultSettings() {
        assertEquals(',', CSVFormat.DEFAULT.getDelimiter());
        assertEquals(Character.valueOf('"'), CSVFormat.DEFAULT.getQuoteCharacter());
        assertEquals("\r\n", CSVFormat.DEFAULT.getRecordSeparator());
        assertTrue(CSVFormat.DEFAULT.getIgnoreEmptyLines());
        assertNull(CSVFormat.DEFAULT.getHeader());
        assertNull(CSVFormat.DEFAULT.getHeaderComments());
        assertNull(CSVFormat.DEFAULT.getNullString());
        assertFalse(CSVFormat.DEFAULT.isNullStringSet());
        assertNull(CSVFormat.DEFAULT.getCommentMarker());
        assertFalse(CSVFormat.DEFAULT.isCommentMarkerSet());
        assertNull(CSVFormat.DEFAULT.getEscapeCharacter());
        assertFalse(CSVFormat.DEFAULT.isEscapeCharacterSet());
        assertFalse(CSVFormat.DEFAULT.getAllowMissingColumnNames());
        assertFalse(CSVFormat.DEFAULT.getAutoFlush());
        assertFalse(CSVFormat.DEFAULT.getSkipHeaderRecord());
        assertFalse(CSVFormat.DEFAULT.getTrailingDelimiter());
        assertFalse(CSVFormat.DEFAULT.getTrim());
        assertFalse(CSVFormat.DEFAULT.getIgnoreHeaderCase());
        assertFalse(CSVFormat.DEFAULT.getIgnoreSurroundingSpaces());
        assertNull(CSVFormat.DEFAULT.getQuoteMode());
    }

    @Test
    public void testExcelSettings() {
        assertEquals(',', CSVFormat.EXCEL.getDelimiter());
        assertEquals(Character.valueOf('"'), CSVFormat.EXCEL.getQuoteCharacter());
        assertEquals("\r\n", CSVFormat.EXCEL.getRecordSeparator());
        assertFalse(CSVFormat.EXCEL.getIgnoreEmptyLines());
        assertTrue(CSVFormat.EXCEL.getAllowMissingColumnNames());
    }

    @Test
    public void testRfc4180Settings() {
        assertEquals(',', CSVFormat.RFC4180.getDelimiter());
        assertEquals(Character.valueOf('"'), CSVFormat.RFC4180.getQuoteCharacter());
        assertEquals("\r\n", CSVFormat.RFC4180.getRecordSeparator());
        assertFalse(CSVFormat.RFC4180.getIgnoreEmptyLines());
    }

    @Test
    public void testTdfSettings() {
        assertEquals('\t', CSVFormat.TDF.getDelimiter());
        assertEquals(Character.valueOf('"'), CSVFormat.TDF.getQuoteCharacter());
        assertEquals("\r\n", CSVFormat.TDF.getRecordSeparator());
        assertTrue(CSVFormat.TDF.getIgnoreSurroundingSpaces());
    }

    @Test
    public void testMySqlSettings() {
        assertEquals('\t', CSVFormat.MYSQL.getDelimiter());
        assertNull(CSVFormat.MYSQL.getQuoteCharacter());
        assertFalse(CSVFormat.MYSQL.isQuoteCharacterSet());
        assertEquals("\n", CSVFormat.MYSQL.getRecordSeparator());
        assertFalse(CSVFormat.MYSQL.getIgnoreEmptyLines());
        assertEquals(Character.valueOf('\\'), CSVFormat.MYSQL.getEscapeCharacter());
        assertEquals("\\N", CSVFormat.MYSQL.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, CSVFormat.MYSQL.getQuoteMode());
    }

    // @Test  // pruned: failed on the fixed version
    public void testInformixUnloadSettings() {
        assertEquals(',', CSVFormat.INFORMIX_UNLOAD.getDelimiter());
        assertEquals(Character.valueOf('"'), CSVFormat.INFORMIX_UNLOAD.getQuoteCharacter());
        assertEquals("\n", CSVFormat.INFORMIX_UNLOAD.getRecordSeparator());
        assertEquals(Character.valueOf('\\'), CSVFormat.INFORMIX_UNLOAD.getEscapeCharacter());
        assertTrue(CSVFormat.INFORMIX_UNLOAD.isEscapeCharacterSet());
    }

    @Test
    public void testInformixUnloadCsvSettings() {
        assertEquals(',', CSVFormat.INFORMIX_UNLOAD_CSV.getDelimiter());
        assertEquals(Character.valueOf('"'), CSVFormat.INFORMIX_UNLOAD_CSV.getQuoteCharacter());
        assertEquals("\n", CSVFormat.INFORMIX_UNLOAD_CSV.getRecordSeparator());
        assertFalse(CSVFormat.INFORMIX_UNLOAD_CSV.isEscapeCharacterSet());
        assertNull(CSVFormat.INFORMIX_UNLOAD_CSV.getEscapeCharacter());
    }

    // @Test  // pruned: failed on the fixed version
    public void testPostgresqlCsvSettings() {
        assertEquals(',', CSVFormat.POSTGRESQL_CSV.getDelimiter());
        assertEquals(Character.valueOf('"'), CSVFormat.POSTGRESQL_CSV.getQuoteCharacter());
        assertEquals("\n", CSVFormat.POSTGRESQL_CSV.getRecordSeparator());
        assertFalse(CSVFormat.POSTGRESQL_CSV.getIgnoreEmptyLines());
        assertEquals(Character.valueOf('\\'), CSVFormat.POSTGRESQL_CSV.getEscapeCharacter());
        assertEquals("", CSVFormat.POSTGRESQL_CSV.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, CSVFormat.POSTGRESQL_CSV.getQuoteMode());
    }

    // @Test  // pruned: failed on the fixed version
    public void testPostgresqlTextSettings() {
        assertEquals('\t', CSVFormat.POSTGRESQL_TEXT.getDelimiter());
        assertEquals(Character.valueOf('"'), CSVFormat.POSTGRESQL_TEXT.getQuoteCharacter());
        assertEquals("\n", CSVFormat.POSTGRESQL_TEXT.getRecordSeparator());
        assertFalse(CSVFormat.POSTGRESQL_TEXT.getIgnoreEmptyLines());
        assertEquals(Character.valueOf('\\'), CSVFormat.POSTGRESQL_TEXT.getEscapeCharacter());
        assertEquals("\\N", CSVFormat.POSTGRESQL_TEXT.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, CSVFormat.POSTGRESQL_TEXT.getQuoteMode());
    }

    // ---- newFormat ----

    @Test
    public void testNewFormat() {
        CSVFormat fmt = CSVFormat.newFormat(';');
        assertEquals(';', fmt.getDelimiter());
        assertNull(fmt.getQuoteCharacter());
        assertFalse(fmt.isQuoteCharacterSet());
        assertNull(fmt.getCommentMarker());
        assertFalse(fmt.isCommentMarkerSet());
        assertNull(fmt.getEscapeCharacter());
        assertFalse(fmt.isEscapeCharacterSet());
        assertNull(fmt.getHeader());
        assertNull(fmt.getHeaderComments());
        assertNull(fmt.getNullString());
        assertFalse(fmt.isNullStringSet());
        assertFalse(fmt.getIgnoreEmptyLines());
        assertFalse(fmt.getIgnoreHeaderCase());
        assertFalse(fmt.getIgnoreSurroundingSpaces());
        assertFalse(fmt.getSkipHeaderRecord());
        assertFalse(fmt.getTrailingDelimiter());
        assertFalse(fmt.getTrim());
        assertFalse(fmt.getAllowMissingColumnNames());
        assertFalse(fmt.getAutoFlush());
        assertNull(fmt.getQuoteMode());
    }

    @Test
    public void testNewFormatRejectsLineBreakDelimiter() {
        try {
            CSVFormat.newFormat('\n');
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
        try {
            CSVFormat.newFormat('\r');
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    // ---- valueOf ----

    @Test
    public void testValueOfKnownNames() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.valueOf("Default"));
        assertEquals(CSVFormat.EXCEL, CSVFormat.valueOf("Excel"));
        assertEquals(CSVFormat.RFC4180, CSVFormat.valueOf("RFC4180"));
        assertEquals(CSVFormat.TDF, CSVFormat.valueOf("TDF"));
        assertEquals(CSVFormat.MYSQL, CSVFormat.valueOf("MySQL"));
    }

    @Test
    public void testValueOfUnknownNameFails() {
        try {
            CSVFormat.valueOf("NoSuchFormatXYZ");
            fail("Expected a RuntimeException for an unknown predefined format name");
        } catch (RuntimeException expected) {
            // expected: name does not match any CSVFormat.Predefined constant
        }
    }

    // ---- equals / hashCode ----

    @Test
    public void testEqualsReflexiveAndByValue() {
        assertTrue(CSVFormat.DEFAULT.equals(CSVFormat.DEFAULT));

        CSVFormat builtDefault = CSVFormat.newFormat(',').withQuote('"').withRecordSeparator("\r\n")
                .withIgnoreEmptyLines(true);
        assertTrue(builtDefault.equals(CSVFormat.DEFAULT));
        assertTrue(CSVFormat.DEFAULT.equals(builtDefault));
        assertEquals(CSVFormat.DEFAULT.hashCode(), builtDefault.hashCode());
    }

    @Test
    public void testEqualsDistinguishesDifferentSettings() {
        assertFalse(CSVFormat.DEFAULT.equals(CSVFormat.EXCEL));
    }

    @Test
    public void testEqualsAgainstNullAndOtherType() {
        assertFalse(CSVFormat.DEFAULT.equals(null));
        assertFalse(CSVFormat.DEFAULT.equals("not a CSVFormat"));
    }

    // ---- toString ----

    @Test
    public void testToStringIsNonNullAndStable() {
        String first = CSVFormat.DEFAULT.toString();
        String second = CSVFormat.DEFAULT.toString();
        assertNotNull(first);
        assertEquals(first, second);
    }

    // ---- Serializable marker ----

    @Test
    public void testIsSerializable() {
        assertTrue(CSVFormat.DEFAULT instanceof java.io.Serializable);
    }

    // ---- Immutability of with* methods ----

    @Test
    public void testWithMethodsReturnNewImmutableInstances() {
        CSVFormat base = CSVFormat.DEFAULT;
        CSVFormat changed = base.withDelimiter(';');
        assertNotSame(base, changed);
        assertEquals(',', base.getDelimiter());
        assertEquals(';', changed.getDelimiter());
    }

    // ---- withDelimiter ----

    @Test
    public void testWithDelimiter() {
        CSVFormat fmt = CSVFormat.DEFAULT.withDelimiter(';');
        assertEquals(';', fmt.getDelimiter());
    }

    @Test
    public void testWithDelimiterRejectsLineBreak() {
        try {
            CSVFormat.DEFAULT.withDelimiter('\n');
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    // ---- withQuote ----

    @Test
    public void testWithQuoteChar() {
        CSVFormat fmt = CSVFormat.newFormat(',').withQuote('\'');
        assertTrue(fmt.isQuoteCharacterSet());
        assertEquals(Character.valueOf('\''), fmt.getQuoteCharacter());
    }

    @Test
    public void testWithQuoteCharacterObjectNullDisables() {
        CSVFormat fmt = CSVFormat.DEFAULT.withQuote((Character) null);
        assertFalse(fmt.isQuoteCharacterSet());
        assertNull(fmt.getQuoteCharacter());
    }

    @Test
    public void testWithQuoteRejectsLineBreak() {
        try {
            CSVFormat.DEFAULT.withQuote('\n');
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    // ---- withEscape ----

    @Test
    public void testWithEscapeChar() {
        CSVFormat fmt = CSVFormat.newFormat(',').withEscape('\\');
        assertTrue(fmt.isEscapeCharacterSet());
        assertEquals(Character.valueOf('\\'), fmt.getEscapeCharacter());
    }

    @Test
    public void testWithEscapeCharacterObjectNullDisables() {
        CSVFormat fmt = CSVFormat.MYSQL.withEscape((Character) null);
        assertFalse(fmt.isEscapeCharacterSet());
        assertNull(fmt.getEscapeCharacter());
    }

    @Test
    public void testWithEscapeRejectsLineBreak() {
        try {
            CSVFormat.DEFAULT.withEscape('\r');
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    // ---- withCommentMarker ----

    @Test
    public void testWithCommentMarkerChar() {
        CSVFormat fmt = CSVFormat.newFormat(',').withCommentMarker('#');
        assertTrue(fmt.isCommentMarkerSet());
        assertEquals(Character.valueOf('#'), fmt.getCommentMarker());
    }

    @Test
    public void testWithCommentMarkerCharacterObjectNullDisables() {
        CSVFormat fmt = CSVFormat.newFormat(',').withCommentMarker('#').withCommentMarker((Character) null);
        assertFalse(fmt.isCommentMarkerSet());
        assertNull(fmt.getCommentMarker());
    }

    @Test
    public void testWithCommentMarkerRejectsLineBreak() {
        try {
            CSVFormat.DEFAULT.withCommentMarker('\n');
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    // ---- withRecordSeparator ----

    @Test
    public void testWithRecordSeparatorChar() {
        CSVFormat fmt = CSVFormat.DEFAULT.withRecordSeparator('\n');
        assertEquals("\n", fmt.getRecordSeparator());
    }

    @Test
    public void testWithRecordSeparatorStringValidValues() {
        assertEquals("\r", CSVFormat.DEFAULT.withRecordSeparator("\r").getRecordSeparator());
        assertEquals("\n", CSVFormat.DEFAULT.withRecordSeparator("\n").getRecordSeparator());
        assertEquals("\r\n", CSVFormat.DEFAULT.withRecordSeparator("\r\n").getRecordSeparator());
    }

    // @Test  // pruned: failed on the fixed version
    public void testWithRecordSeparatorStringRejectsInvalidValue() {
        try {
            CSVFormat.DEFAULT.withRecordSeparator("not-a-valid-separator");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    // ---- withNullString ----

    @Test
    public void testWithNullString() {
        CSVFormat fmt = CSVFormat.DEFAULT.withNullString("N/A");
        assertTrue(fmt.isNullStringSet());
        assertEquals("N/A", fmt.getNullString());
    }

    @Test
    public void testWithNullStringNull() {
        CSVFormat fmt = CSVFormat.DEFAULT.withNullString("N/A").withNullString(null);
        assertFalse(fmt.isNullStringSet());
        assertNull(fmt.getNullString());
    }

    // ---- withHeader ----

    @Test
    public void testWithHeaderStringsReturnsCopy() {
        CSVFormat fmt = CSVFormat.DEFAULT.withHeader("A", "B");
        String[] header1 = fmt.getHeader();
        assertArrayEquals(new String[] { "A", "B" }, header1);
        header1[0] = "MUTATED";
        String[] header2 = fmt.getHeader();
        assertEquals("A", header2[0]);
    }

    @Test
    public void testWithHeaderNoArgsIsEmptyArray() {
        CSVFormat fmt = CSVFormat.DEFAULT.withHeader();
        assertNotNull(fmt.getHeader());
        assertEquals(0, fmt.getHeader().length);
    }

    @Test
    public void testWithHeaderNullDisables() {
        CSVFormat fmt = CSVFormat.DEFAULT.withHeader("A", "B").withHeader((String[]) null);
        assertNull(fmt.getHeader());
    }

    @Test
    public void testWithHeaderEnumClass() {
        CSVFormat fmt = CSVFormat.DEFAULT.withHeader(TestHeader.class);
        assertArrayEquals(new String[] { "Name", "Email", "Phone" }, fmt.getHeader());
    }

    @Test
    public void testWithFirstRecordAsHeader() {
        CSVFormat fmt = CSVFormat.DEFAULT.withFirstRecordAsHeader();
        assertNotNull(fmt.getHeader());
        assertEquals(0, fmt.getHeader().length);
        assertTrue(fmt.getSkipHeaderRecord());
    }

    // ---- withHeaderComments ----

    @Test
    public void testWithHeaderCommentsReturnsCopy() {
        CSVFormat fmt = CSVFormat.DEFAULT.withHeaderComments("first comment", "second comment");
        String[] comments1 = fmt.getHeaderComments();
        assertArrayEquals(new String[] { "first comment", "second comment" }, comments1);
        comments1[0] = "MUTATED";
        String[] comments2 = fmt.getHeaderComments();
        assertEquals("first comment", comments2[0]);
    }

    @Test
    public void testWithHeaderCommentsNullDisables() {
        CSVFormat fmt = CSVFormat.DEFAULT.withHeaderComments("x").withHeaderComments((Object[]) null);
        assertNull(fmt.getHeaderComments());
    }

    // ---- simple boolean with* toggles ----

    @Test
    public void testWithIgnoreEmptyLines() {
        assertTrue(CSVFormat.RFC4180.withIgnoreEmptyLines().getIgnoreEmptyLines());
        assertTrue(CSVFormat.DEFAULT.withIgnoreEmptyLines(true).getIgnoreEmptyLines());
        assertFalse(CSVFormat.DEFAULT.withIgnoreEmptyLines(false).getIgnoreEmptyLines());
    }

    @Test
    public void testWithIgnoreHeaderCase() {
        assertTrue(CSVFormat.DEFAULT.withIgnoreHeaderCase().getIgnoreHeaderCase());
        assertTrue(CSVFormat.DEFAULT.withIgnoreHeaderCase(true).getIgnoreHeaderCase());
        assertFalse(CSVFormat.DEFAULT.withIgnoreHeaderCase(false).getIgnoreHeaderCase());
    }

    @Test
    public void testWithIgnoreSurroundingSpaces() {
        assertTrue(CSVFormat.DEFAULT.withIgnoreSurroundingSpaces().getIgnoreSurroundingSpaces());
        assertTrue(CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(true).getIgnoreSurroundingSpaces());
        assertFalse(CSVFormat.TDF.withIgnoreSurroundingSpaces(false).getIgnoreSurroundingSpaces());
    }

    @Test
    public void testWithSkipHeaderRecord() {
        assertTrue(CSVFormat.DEFAULT.withSkipHeaderRecord().getSkipHeaderRecord());
        assertTrue(CSVFormat.DEFAULT.withSkipHeaderRecord(true).getSkipHeaderRecord());
        assertFalse(CSVFormat.DEFAULT.withSkipHeaderRecord(false).getSkipHeaderRecord());
    }

    @Test
    public void testWithTrailingDelimiter() {
        assertTrue(CSVFormat.DEFAULT.withTrailingDelimiter().getTrailingDelimiter());
        assertTrue(CSVFormat.DEFAULT.withTrailingDelimiter(true).getTrailingDelimiter());
        assertFalse(CSVFormat.DEFAULT.withTrailingDelimiter(false).getTrailingDelimiter());
    }

    @Test
    public void testWithTrim() {
        assertTrue(CSVFormat.DEFAULT.withTrim().getTrim());
        assertTrue(CSVFormat.DEFAULT.withTrim(true).getTrim());
        assertFalse(CSVFormat.DEFAULT.withTrim(false).getTrim());
    }

    @Test
    public void testWithAllowMissingColumnNames() {
        assertTrue(CSVFormat.DEFAULT.withAllowMissingColumnNames().getAllowMissingColumnNames());
        assertTrue(CSVFormat.DEFAULT.withAllowMissingColumnNames(true).getAllowMissingColumnNames());
        assertFalse(CSVFormat.EXCEL.withAllowMissingColumnNames(false).getAllowMissingColumnNames());
    }

    @Test
    public void testWithAutoFlush() {
        assertTrue(CSVFormat.DEFAULT.withAutoFlush(true).getAutoFlush());
        assertFalse(CSVFormat.DEFAULT.withAutoFlush(false).getAutoFlush());
    }

    @Test
    public void testWithQuoteMode() {
        CSVFormat fmt = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL_NON_NULL);
        assertEquals(QuoteMode.ALL_NON_NULL, fmt.getQuoteMode());
    }

    // ---- format ----

    @Test
    public void testFormatNoValues() {
        assertEquals("", CSVFormat.DEFAULT.format());
    }

    @Test
    public void testFormatSimpleValues() {
        assertEquals("a,b,c", CSVFormat.DEFAULT.format("a", "b", "c"));
    }

    @Test
    public void testFormatQuotesValueContainingDelimiter() {
        assertEquals("\"a,b\",c", CSVFormat.DEFAULT.format("a,b", "c"));
    }

    @Test
    public void testFormatNullValueBecomesEmptyWhenNoNullStringSet() {
        assertEquals("", CSVFormat.DEFAULT.format(new Object[] { null }));
    }

    // ---- printRecord / println / print(value, out, newRecord) ----

    @Test
    public void testPrintRecord() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.printRecord(sb, "a", "b");
        assertEquals("a,b\r\n", sb.toString());
    }

    @Test
    public void testPrintRecordQuotesWhenNeeded() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.printRecord(sb, "a,b", "c");
        assertEquals("\"a,b\",c\r\n", sb.toString());
    }

    @Test
    public void testPrintlnWithoutTrailingDelimiter() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.println(sb);
        assertEquals("\r\n", sb.toString());
    }

    @Test
    public void testPrintlnWithTrailingDelimiter() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.withTrailingDelimiter(true).println(sb);
        assertEquals(",\r\n", sb.toString());
    }

    @Test
    public void testPrintValueQuotesWhenNeeded() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.print("a,b", sb, true);
        assertEquals("\"a,b\"", sb.toString());
    }

    @Test
    public void testPrintValueNoQuotingNeeded() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVFormat.DEFAULT.print("hello", sb, true);
        assertEquals("hello", sb.toString());
    }

    // ---- print(Appendable) / printer() ----

    @Test
    public void testPrintAppendableWritesHeaderImmediately() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = CSVFormat.DEFAULT.withHeader("A", "B").print(sb);
        assertNotNull(printer);
        assertEquals("A,B\r\n", sb.toString());
    }

    @Test
    public void testPrintAppendableNoHeaderWritesNothingImmediately() throws IOException {
        StringBuilder sb = new StringBuilder();
        CSVPrinter printer = CSVFormat.DEFAULT.print(sb);
        assertNotNull(printer);
        assertEquals("", sb.toString());
    }

    @Test
    public void testPrinterWritesToSystemOut() throws IOException {
        PrintStream originalOut = System.out;
        ByteArrayOutputStream captured = new ByteArrayOutputStream();
        System.setOut(new PrintStream(captured));
        try {
            CSVPrinter printer = CSVFormat.DEFAULT.withHeader("A", "B").printer();
            assertNotNull(printer);
        } finally {
            System.setOut(originalOut);
        }
        assertEquals("A,B\r\n", captured.toString());
    }

    // ---- print(File, Charset) / print(Path, Charset) ----

    @Test
    public void testPrintToFileReturnsPrinterAndCreatesFile() throws IOException {
        File file = File.createTempFile("csvformatagenttest", ".csv");
        file.deleteOnExit();
        try {
            CSVPrinter printer = CSVFormat.DEFAULT.print(file, StandardCharsets.UTF_8);
            assertNotNull(printer);
            assertTrue(file.exists());
        } finally {
            file.delete();
        }
    }

    @Test
    public void testPrintToPathReturnsPrinterAndCreatesFile() throws IOException {
        File file = File.createTempFile("csvformatagenttest", ".csv");
        file.deleteOnExit();
        try {
            CSVPrinter printer = CSVFormat.DEFAULT.print(file.toPath(), StandardCharsets.UTF_8);
            assertNotNull(printer);
            assertTrue(file.exists());
        } finally {
            file.delete();
        }
    }

    // ---- parse ----

    @Test
    public void testParseReturnsNonNullParser() throws IOException {
        Reader reader = new StringReader("a,b\r\nc,d\r\n");
        CSVParser parser = CSVFormat.DEFAULT.parse(reader);
        assertNotNull(parser);
    }
}
