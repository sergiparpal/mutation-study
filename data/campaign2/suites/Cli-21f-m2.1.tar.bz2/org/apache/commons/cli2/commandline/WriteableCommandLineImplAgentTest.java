/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.cli2.commandline;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;

import junit.framework.TestCase;

import org.apache.commons.cli2.Group;
import org.apache.commons.cli2.Option;
import org.apache.commons.cli2.OptionException;
import org.apache.commons.cli2.WriteableCommandLine;
import org.apache.commons.cli2.builder.ArgumentBuilder;
import org.apache.commons.cli2.builder.DefaultOptionBuilder;
import org.apache.commons.cli2.builder.GroupBuilder;
import org.apache.commons.cli2.option.OptionImpl;

public class WriteableCommandLineImplAgentTest extends TestCase {

    public void testConstructor_setsRootAsCurrentOption() {
        final Option root = new DefaultOptionBuilder().withLongName("root").create();
        final WriteableCommandLine cl = new WriteableCommandLineImpl(root, new ArrayList());

        assertSame(root, cl.getCurrentOption());
    }

    public void testAddOption_addsAncestorChainOfParents() {
        final Option child = new DefaultOptionBuilder().withLongName("child").create();
        final Group parent = new GroupBuilder().withName("parent").withOption(child).create();
        final WriteableCommandLine cl = new WriteableCommandLineImpl(parent, new ArrayList());

        cl.addOption(child);

        assertTrue(cl.hasOption(child));
        assertTrue(cl.hasOption(parent));
        assertEquals(2, cl.getOptions().size());
    }

    public void testAddOption_registersAllTriggers() {
        final Option option =
            new DefaultOptionBuilder().withShortName("v").withLongName("verbose").create();
        final Option root = new DefaultOptionBuilder().withLongName("root").create();
        final WriteableCommandLine cl = new WriteableCommandLineImpl(root, new ArrayList());

        cl.addOption(option);

        assertSame(option, cl.getOption("-v"));
        assertSame(option, cl.getOption("--verbose"));
        assertNull(cl.getOption("--unknown"));
    }

    public void testGetValues_augmentsWithExtraDefaultValues() {
        final Option option = new DefaultOptionBuilder().withLongName("name").create();
        final Option root = new DefaultOptionBuilder().withLongName("root").create();
        final WriteableCommandLine cl = new WriteableCommandLineImpl(root, new ArrayList());

        cl.addValue(option, "one");
        final List result =
            cl.getValues(option, Arrays.asList(new String[] {"d1", "d2", "d3"}));

        assertEquals(Arrays.asList(new String[] {"one", "d2", "d3"}), result);
    }

    public void testGetValues_suppliedDefaultsOverrideStoredDefaults() {
        final Option option = new DefaultOptionBuilder().withLongName("name").create();
        final Option root = new DefaultOptionBuilder().withLongName("root").create();
        final WriteableCommandLine cl = new WriteableCommandLineImpl(root, new ArrayList());

        cl.setDefaultValues(option, Arrays.asList(new String[] {"stored"}));
        final List result = cl.getValues(option, Arrays.asList(new String[] {"supplied"}));

        assertEquals(Arrays.asList(new String[] {"supplied"}), result);
    }

    public void testGetSwitch_fallsBackThroughDefaultOrder() {
        final Option option = new DefaultOptionBuilder().withLongName("flag").create();
        final Option root = new DefaultOptionBuilder().withLongName("root").create();
        final WriteableCommandLine cl = new WriteableCommandLineImpl(root, new ArrayList());

        // nothing set at all
        assertNull(cl.getSwitch(option, null));

        // option's stored default is used when no method-supplied default given
        cl.setDefaultSwitch(option, Boolean.FALSE);
        assertEquals(Boolean.FALSE, cl.getSwitch(option, null));

        // method-supplied default takes priority over the stored default
        assertEquals(Boolean.TRUE, cl.getSwitch(option, Boolean.TRUE));

        // an actual recorded switch value takes priority over everything
        cl.addSwitch(option, true);
        assertEquals(Boolean.TRUE, cl.getSwitch(option, Boolean.FALSE));
    }

    public void testGetProperty_withDefaultValueFallback() {
        final Option option = new DefaultOptionBuilder().withLongName("root").create();
        final WriteableCommandLine cl = new WriteableCommandLineImpl(option, new ArrayList());

        assertEquals("def", cl.getProperty(option, "missing", "def"));

        cl.addProperty(option, "key", "value");
        assertEquals("value", cl.getProperty(option, "key", "def"));
    }

    public void testGetProperties_emptyWhenOptionUnknown() {
        final Option option = new DefaultOptionBuilder().withLongName("root").create();
        final Option other = new DefaultOptionBuilder().withLongName("other").create();
        final WriteableCommandLine cl = new WriteableCommandLineImpl(option, new ArrayList());

        assertTrue(cl.getProperties(other).isEmpty());
    }

    public void testToString_quotesArgumentsContainingSpaces() {
        final Option root = new DefaultOptionBuilder().withLongName("root").create();
        final List args = Arrays.asList(new String[] {"--name", "hello world", "plain"});
        final WriteableCommandLine cl = new WriteableCommandLineImpl(root, args);

        assertEquals("--name \"hello world\" plain", cl.toString());
    }

    public void testGetOptions_isUnmodifiable() {
        final Option root = new DefaultOptionBuilder().withLongName("root").create();
        final WriteableCommandLine cl = new WriteableCommandLineImpl(root, new ArrayList());

        try {
            cl.getOptions().add(root);
            fail("expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
    }

    public void testGetNormalised_isUnmodifiableAndReflectsConstructorArgument() {
        final Option root = new DefaultOptionBuilder().withLongName("root").create();
        final List args = Arrays.asList(new String[] {"a", "b"});
        final WriteableCommandLineImpl cl = new WriteableCommandLineImpl(root, args);

        assertEquals(args, cl.getNormalised());
        try {
            cl.getNormalised().add("c");
            fail("expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
    }

    public void testGetOptionTriggers_containsRegisteredTriggers() {
        final Option option =
            new DefaultOptionBuilder().withShortName("v").withLongName("verbose").create();
        final Option root = new DefaultOptionBuilder().withLongName("root").create();
        final WriteableCommandLine cl = new WriteableCommandLineImpl(root, new ArrayList());

        cl.addOption(option);

        assertTrue(cl.getOptionTriggers().contains("-v"));
        assertTrue(cl.getOptionTriggers().contains("--verbose"));
    }

    public void testSetDefaultValues_nullClearsPreviouslySetDefaults() {
        final Option option = new DefaultOptionBuilder().withLongName("name").create();
        final Option root = new DefaultOptionBuilder().withLongName("root").create();
        final WriteableCommandLine cl = new WriteableCommandLineImpl(root, new ArrayList());

        cl.setDefaultValues(option, Arrays.asList(new String[] {"x"}));
        assertFalse(cl.getValues(option).isEmpty());

        cl.setDefaultValues(option, null);
        assertTrue(cl.getValues(option).isEmpty());
    }

    public void testLooksLikeOption_reentrantCallForSameTriggerReturnsFalse() {
        final ReentrantProbe probe =
            new ReentrantProbe(Collections.singleton("-"), Collections.singleton("-x"));
        final WriteableCommandLineImpl cl = new WriteableCommandLineImpl(probe, new ArrayList());
        cl.setCurrentOption(probe);

        final boolean outerResult = cl.looksLikeOption("-x");

        // the outer call delegates to probe.canProcess, which itself re-enters
        // looksLikeOption for the very same trigger; that nested call must
        // short-circuit to false to avoid infinite recursion
        assertTrue(probe.nestedCalled);
        assertFalse(probe.nestedResult);
        assertTrue(outerResult);
    }

    /**
     * A minimal Option whose canProcess re-enters
     * WriteableCommandLine.looksLikeOption with the same trigger, to exercise
     * WriteableCommandLineImpl's reentrant guard.
     */
    private static class ReentrantProbe extends OptionImpl {
        private final Set prefixes;
        private final Set triggers;
        boolean nestedCalled;
        boolean nestedResult;

        ReentrantProbe(final Set prefixes, final Set triggers) {
            super(0, false);
            this.prefixes = prefixes;
            this.triggers = triggers;
        }

        public boolean canProcess(final WriteableCommandLine commandLine, final String argument) {
            nestedCalled = true;
            nestedResult = commandLine.looksLikeOption(argument);
            return true;
        }

        public Set getTriggers() {
            return triggers;
        }

        public Set getPrefixes() {
            return prefixes;
        }

        public void process(final WriteableCommandLine commandLine, final ListIterator args)
            throws OptionException {
        }

        public void validate(final WriteableCommandLine commandLine) throws OptionException {
        }

        public List helpLines(final int depth, final Set helpSettings, final Comparator comp) {
            return Collections.EMPTY_LIST;
        }

        public void appendUsage(final StringBuffer buffer, final Set helpSettings,
                                 final Comparator comp) {
        }

        public String getPreferredName() {
            return "probe";
        }

        public String getDescription() {
            return "probe";
        }
    }

    public void testGetUndefaultedValues_emptyWhenNothingAdded() {
        final Option option = new DefaultOptionBuilder().withLongName("name").create();
        final Option root = new DefaultOptionBuilder().withLongName("root").create();
        final WriteableCommandLine cl = new WriteableCommandLineImpl(root, new ArrayList());

        assertTrue(cl.getUndefaultedValues(option).isEmpty());
    }

    public void testAddValue_onArgumentAutomaticallyAddsOption() {
        final org.apache.commons.cli2.Argument argument =
            new ArgumentBuilder().withName("target").create();
        final Option root = new DefaultOptionBuilder().withLongName("root").create();
        final WriteableCommandLine cl = new WriteableCommandLineImpl(root, new ArrayList());

        assertFalse(cl.hasOption(argument));
        cl.addValue(argument, "value");
        assertTrue(cl.hasOption(argument));
    }
}
