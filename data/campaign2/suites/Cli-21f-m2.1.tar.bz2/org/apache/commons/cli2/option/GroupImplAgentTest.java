/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.cli2.option;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;

import junit.framework.TestCase;

import org.apache.commons.cli2.Argument;
import org.apache.commons.cli2.DisplaySetting;
import org.apache.commons.cli2.Group;
import org.apache.commons.cli2.Option;
import org.apache.commons.cli2.OptionException;
import org.apache.commons.cli2.WriteableCommandLine;
import org.apache.commons.cli2.builder.ArgumentBuilder;
import org.apache.commons.cli2.builder.DefaultOptionBuilder;
import org.apache.commons.cli2.commandline.WriteableCommandLineImpl;

public class GroupImplAgentTest extends TestCase {

    private static Option longOption(final String name, final boolean required) {
        return new DefaultOptionBuilder().withLongName(name).withRequired(required).create();
    }

    private WriteableCommandLine commandLine(final Option root, final List args) {
        return new WriteableCommandLineImpl(root, args);
    }

    public void testConstructor_separatesArgumentsFromOptions() {
        final Argument argument = new ArgumentBuilder().withName("target").create();
        final Option option = longOption("verbose", false);
        final List options = new ArrayList();
        options.add(argument);
        options.add(option);

        final GroupImpl group = new GroupImpl(options, "grp", "desc", 0, 2, false);

        assertEquals(Arrays.asList(new Object[] {option}), group.getOptions());
        assertEquals(Arrays.asList(new Object[] {argument}), group.getAnonymous());
    }

    public void testConstructor_setsParentOnChildren() {
        final Option option = longOption("verbose", false);
        final List options = new ArrayList();
        options.add(option);

        final GroupImpl group = new GroupImpl(options, "grp", "desc", 0, 1, false);

        assertSame(group, option.getParent());
    }

    public void testGetPreferredNameAndDescription() {
        final GroupImpl group = new GroupImpl(new ArrayList(), "name", "description", 0, 1, false);

        assertEquals("name", group.getPreferredName());
        assertEquals("description", group.getDescription());
    }

    public void testGetMinimumAndMaximum() {
        final GroupImpl group = new GroupImpl(new ArrayList(), "name", null, 1, 5, false);

        assertEquals(1, group.getMinimum());
        assertEquals(5, group.getMaximum());
    }

    public void testGetTriggers_collectsAllChildTriggers() {
        final List options = new ArrayList();
        options.add(longOption("alpha", false));
        options.add(longOption("beta", false));

        final GroupImpl group = new GroupImpl(options, "grp", null, 0, 2, false);

        final Set triggers = group.getTriggers();
        assertTrue(triggers.contains("--alpha"));
        assertTrue(triggers.contains("--beta"));
        assertEquals(2, triggers.size());
    }

    public void testGetPrefixes_collectsAllChildPrefixes() {
        final List options = new ArrayList();
        options.add(new DefaultOptionBuilder("-", "++", true).withLongName("alpha").create());

        final GroupImpl group = new GroupImpl(options, "grp", null, 0, 1, false);

        assertTrue(group.getPrefixes().contains("++"));
    }

    public void testCanProcess_nullArgumentReturnsFalse() {
        final GroupImpl group = new GroupImpl(new ArrayList(), "grp", null, 0, 1, false);
        final WriteableCommandLine cl = commandLine(group, new ArrayList());

        assertFalse(group.canProcess(cl, (String) null));
    }

    public void testCanProcess_knownTriggerReturnsTrue() {
        final List options = new ArrayList();
        options.add(longOption("alpha", false));
        final GroupImpl group = new GroupImpl(options, "grp", null, 0, 1, false);
        final WriteableCommandLine cl = commandLine(group, new ArrayList());

        assertTrue(group.canProcess(cl, "--alpha"));
    }

    public void testCanProcess_unknownTriggerWithoutAnonymousReturnsFalse() {
        final List options = new ArrayList();
        options.add(longOption("alpha", false));
        final GroupImpl group = new GroupImpl(options, "grp", null, 0, 1, false);
        final WriteableCommandLine cl = commandLine(group, new ArrayList());

        assertFalse(group.canProcess(cl, "--unknown"));
    }

    public void testCanProcess_plainValueWithAnonymousArgumentReturnsTrue() {
        final List options = new ArrayList();
        options.add(new ArgumentBuilder().withName("target").create());
        final GroupImpl group = new GroupImpl(options, "grp", null, 0, 1, false);
        final WriteableCommandLine cl = commandLine(group, new ArrayList());

        assertTrue(group.canProcess(cl, "somevalue"));
    }

    public void testFindOption_locatesNestedOption() {
        final Option option = longOption("alpha", false);
        final List options = new ArrayList();
        options.add(option);
        final GroupImpl group = new GroupImpl(options, "grp", null, 0, 1, false);

        assertSame(option, group.findOption("--alpha"));
        assertNull(group.findOption("--missing"));
    }

    public void testProcess_recognisedOptionIsAdded() throws OptionException {
        final List options = new ArrayList();
        options.add(longOption("alpha", false));
        final GroupImpl group = new GroupImpl(options, "grp", null, 0, 1, false);

        final List args = new ArrayList(Arrays.asList(new String[] {"--alpha"}));
        final WriteableCommandLine cl = commandLine(group, args);
        final ListIterator iterator = args.listIterator();

        group.process(cl, iterator);

        assertTrue(cl.hasOption("--alpha"));
        assertFalse(iterator.hasNext());
    }

    public void testProcess_unrecognisedTokenIsLeftForCaller() throws OptionException {
        final List options = new ArrayList();
        options.add(longOption("alpha", false));
        final GroupImpl group = new GroupImpl(options, "grp", null, 0, 1, false);

        final List args = new ArrayList(Arrays.asList(new String[] {"--unknown"}));
        final WriteableCommandLine cl = commandLine(group, args);
        final ListIterator iterator = args.listIterator();

        group.process(cl, iterator);

        // the group could not process the unrecognised option, so it must
        // rewind the iterator rather than consuming the token
        assertTrue(iterator.hasNext());
        assertEquals("--unknown", iterator.next());
    }

    public void testValidate_succeedsWithinBounds() throws OptionException {
        final Option alpha = longOption("alpha", false);
        final List options = new ArrayList();
        options.add(alpha);
        final GroupImpl group = new GroupImpl(options, "grp", null, 0, 1, false);
        final WriteableCommandLine cl = commandLine(group, new ArrayList());

        cl.addOption(alpha);

        group.validate(cl);
    }

    public void testValidate_tooFewOptionsThrows() {
        final Option alpha = longOption("alpha", false);
        final List options = new ArrayList();
        options.add(alpha);
        final GroupImpl group = new GroupImpl(options, "grp", null, 1, 1, false);
        final WriteableCommandLine cl = commandLine(group, new ArrayList());

        try {
            group.validate(cl);
            fail("expected OptionException for missing required option");
        } catch (OptionException expected) {
            assertSame(group, expected.getOption());
        }
    }

    public void testValidate_tooManyOptionsThrows() {
        final Option alpha = longOption("alpha", false);
        final Option beta = longOption("beta", false);
        final List options = new ArrayList();
        options.add(alpha);
        options.add(beta);
        final GroupImpl group = new GroupImpl(options, "grp", null, 0, 1, false);
        final WriteableCommandLine cl = commandLine(group, new ArrayList());

        cl.addOption(alpha);
        cl.addOption(beta);

        try {
            group.validate(cl);
            fail("expected OptionException for too many present options");
        } catch (OptionException expected) {
            assertSame(group, expected.getOption());
        }
    }

    public void testValidate_requiredChildMustBePresent() {
        final Option required = longOption("required", true);
        final Option optional = longOption("optional", false);
        final List options = new ArrayList();
        options.add(required);
        options.add(optional);
        final GroupImpl group = new GroupImpl(options, "grp", null, 0, 2, false);
        final WriteableCommandLine cl = commandLine(group, new ArrayList());

        cl.addOption(optional);

        try {
            group.validate(cl);
            fail("expected OptionException because required child is missing");
        } catch (OptionException expected) {
            assertSame(required, expected.getOption());
        }
    }

    public void testIsRequired_falseWithoutFlagOrMinimum() {
        final GroupImpl group = new GroupImpl(new ArrayList(), "grp", null, 0, 1, false);
        assertFalse(group.isRequired());
    }

    public void testIsRequired_falseWithMinimumButNoFlag() {
        final GroupImpl group = new GroupImpl(new ArrayList(), "grp", null, 2, 5, false);
        final List outerOptions = new ArrayList();
        outerOptions.add(group);
        new GroupImpl(outerOptions, "outer", null, 0, 1, false);

        assertFalse(group.isRequired());
    }

    public void testIsRequired_trueWithFlagAndMinimum() {
        final GroupImpl group = new GroupImpl(new ArrayList(), "grp", null, 2, 5, true);
        final List outerOptions = new ArrayList();
        outerOptions.add(group);
        new GroupImpl(outerOptions, "outer", null, 0, 1, false);

        assertTrue(group.isRequired());
    }

    public void testIsRequired_rootGroupIgnoresRequiredFlag() {
        // a group without a parent is treated as required purely based on
        // its minimum constraint
        final GroupImpl root = new GroupImpl(new ArrayList(), "grp", null, 1, 5, false);
        assertTrue(root.isRequired());

        final GroupImpl rootNoMinimum = new GroupImpl(new ArrayList(), "grp", null, 0, 5, false);
        assertFalse(rootNoMinimum.isRequired());
    }

    public void testAppendUsage_expandedWithOptionalMarkers() {
        final List options = new ArrayList();
        options.add(longOption("alpha", false));
        options.add(longOption("beta", false));
        final GroupImpl group = new GroupImpl(options, "grp", null, 0, 2, false);

        final StringBuffer buffer = new StringBuffer();
        group.appendUsage(buffer, new HashSet(DisplaySetting.ALL), null);

        assertEquals("[grp (--alpha|--beta)]", buffer.toString());
    }

    public void testAppendUsage_noNameShowsOnlyChildren() {
        final List options = new ArrayList();
        options.add(longOption("alpha", false));
        options.add(longOption("beta", false));
        // minimum > 0 and required=true make the group itself non-optional,
        // so no brackets are added around its usage string
        final GroupImpl group = new GroupImpl(options, "grp", null, 1, 2, true);

        final Set settings = new HashSet(DisplaySetting.ALL);
        settings.remove(DisplaySetting.DISPLAY_GROUP_NAME);

        final StringBuffer buffer = new StringBuffer();
        group.appendUsage(buffer, settings, null);

        assertEquals("--alpha|--beta", buffer.toString());
    }

    public void testAppendUsage_noExpandShowsOnlyName() {
        final List options = new ArrayList();
        options.add(longOption("alpha", false));
        options.add(longOption("beta", false));
        final GroupImpl group = new GroupImpl(options, "grp", null, 1, 2, true);

        final Set settings = new HashSet(DisplaySetting.ALL);
        settings.remove(DisplaySetting.DISPLAY_GROUP_EXPANDED);

        final StringBuffer buffer = new StringBuffer();
        group.appendUsage(buffer, settings, null);

        assertEquals("grp", buffer.toString());
    }

    public void testHelpLines_includesHeaderAndChildren() {
        final Option alpha = longOption("alpha", false);
        final List options = new ArrayList();
        options.add(alpha);
        final GroupImpl group = new GroupImpl(options, "grp", null, 0, 1, false);

        final List lines = group.helpLines(0, DisplaySetting.ALL, null);

        assertEquals(2, lines.size());
    }

    public void testDefaults_appliesToChildrenAndAnonymous() {
        final Argument argument =
            new ArgumentBuilder().withName("target").withDefault("fallback").create();
        final Option alpha = longOption("alpha", false);
        final List options = new ArrayList();
        options.add(alpha);
        options.add(argument);
        final GroupImpl group = new GroupImpl(options, "grp", null, 0, 2, false);
        final WriteableCommandLine cl = commandLine(group, new ArrayList());

        group.defaults(cl);

        assertEquals(Arrays.asList(new String[] {"fallback"}), cl.getValues(argument));
    }
}
