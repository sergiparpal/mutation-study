/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.cli2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import junit.framework.TestCase;

import org.apache.commons.cli2.builder.ArgumentBuilder;
import org.apache.commons.cli2.builder.DefaultOptionBuilder;
import org.apache.commons.cli2.builder.GroupBuilder;
import org.apache.commons.cli2.commandline.WriteableCommandLineImpl;
import org.apache.commons.cli2.option.PropertyOption;

/**
 * Exercises the {@link WriteableCommandLine} contract using
 * {@link WriteableCommandLineImpl} as the concrete implementation under
 * test.
 */
public class WriteableCommandLineAgentTest extends TestCase {

    private WriteableCommandLine newCommandLine() {
        final Option root = new DefaultOptionBuilder().withLongName("root").create();
        return new WriteableCommandLineImpl(root, new ArrayList());
    }

    public void testAddOption_makesOptionPresent() {
        final WriteableCommandLine cl = newCommandLine();
        final Option option = new DefaultOptionBuilder().withLongName("verbose").create();

        assertFalse(cl.hasOption(option));
        cl.addOption(option);
        assertTrue(cl.hasOption(option));
        assertTrue(cl.getOptions().contains(option));
    }

    public void testAddValue_onNonArgumentDoesNotMarkPresent() {
        final WriteableCommandLine cl = newCommandLine();
        final Option option = new DefaultOptionBuilder().withLongName("name").create();

        cl.addValue(option, "value");

        assertFalse(cl.hasOption(option));
        assertEquals(Arrays.asList(new String[] {"value"}), cl.getValues(option));
    }

    public void testAddValue_onArgumentMarksPresent() {
        final WriteableCommandLine cl = newCommandLine();
        final Argument argument = new ArgumentBuilder().withName("target").create();

        assertFalse(cl.hasOption(argument));
        cl.addValue(argument, "value");
        assertTrue(cl.hasOption(argument));
    }

    public void testGetUndefaultedValues_excludesDefaults() {
        final WriteableCommandLine cl = newCommandLine();
        final Option option = new DefaultOptionBuilder().withLongName("name").create();
        final List defaults = Arrays.asList(new String[] {"default"});

        cl.setDefaultValues(option, defaults);

        // getValues augments with defaults
        assertEquals(defaults, cl.getValues(option));
        // getUndefaultedValues ignores defaults entirely
        assertTrue(cl.getUndefaultedValues(option).isEmpty());

        cl.addValue(option, "real");
        assertEquals(Arrays.asList(new String[] {"real"}), cl.getUndefaultedValues(option));
    }

    public void testSetDefaultValues_nullRemovesDefaults() {
        final WriteableCommandLine cl = newCommandLine();
        final Option option = new DefaultOptionBuilder().withLongName("name").create();

        cl.setDefaultValues(option, Arrays.asList(new String[] {"default"}));
        assertFalse(cl.getValues(option).isEmpty());

        cl.setDefaultValues(option, null);
        assertTrue(cl.getValues(option).isEmpty());
    }

    public void testAddSwitch_setsValueAndMarksPresent() {
        final WriteableCommandLine cl = newCommandLine();
        final Option option = new DefaultOptionBuilder().withLongName("flag").create();

        assertNull(cl.getSwitch(option));
        cl.addSwitch(option, true);
        assertEquals(Boolean.TRUE, cl.getSwitch(option));
        assertTrue(cl.hasOption(option));
    }

    public void testAddSwitch_calledTwiceThrows() {
        final WriteableCommandLine cl = newCommandLine();
        final Option option = new DefaultOptionBuilder().withLongName("flag").create();

        cl.addSwitch(option, true);
        try {
            cl.addSwitch(option, false);
            fail("expected IllegalStateException on duplicate addSwitch");
        } catch (IllegalStateException expected) {
            // expected
        }
    }

    public void testSetDefaultSwitch_nullRemovesDefault() {
        final WriteableCommandLine cl = newCommandLine();
        final Option option = new DefaultOptionBuilder().withLongName("flag").create();

        cl.setDefaultSwitch(option, Boolean.TRUE);
        assertEquals(Boolean.TRUE, cl.getSwitch(option));

        cl.setDefaultSwitch(option, null);
        assertNull(cl.getSwitch(option));
    }

    public void testAddProperty_optionScoped() {
        final WriteableCommandLine cl = newCommandLine();
        final Option option = new PropertyOption();

        assertNull(cl.getProperty(option, "key"));
        cl.addProperty(option, "key", "value");
        assertEquals("value", cl.getProperty(option, "key"));
        assertTrue(cl.getProperties(option).contains("key"));
    }

    public void testAddProperty_defaultPropertySet() {
        final WriteableCommandLine cl = newCommandLine();

        assertNull(cl.getProperty("key"));
        cl.addProperty("key", "value");
        assertEquals("value", cl.getProperty("key"));
    }

    public void testAddProperty_replacesExistingValue() {
        final WriteableCommandLine cl = newCommandLine();
        final Option option = new PropertyOption();

        cl.addProperty(option, "key", "first");
        cl.addProperty(option, "key", "second");
        assertEquals("second", cl.getProperty(option, "key"));
    }

    public void testLooksLikeOption_matchesKnownTrigger() {
        final Option child = new DefaultOptionBuilder().withLongName("child").create();
        final Group root = new GroupBuilder().withOption(child).create();
        final WriteableCommandLine cl = new WriteableCommandLineImpl(root, new ArrayList());
        cl.setCurrentOption(root);

        assertTrue(cl.looksLikeOption("--child"));
        assertFalse(cl.looksLikeOption("plainvalue"));
    }

    public void testGetCurrentOption_setAndGet() {
        final WriteableCommandLine cl = newCommandLine();
        final Option option = new DefaultOptionBuilder().withLongName("name").create();

        assertNotNull(cl.getCurrentOption());
        cl.setCurrentOption(option);
        assertSame(option, cl.getCurrentOption());

        cl.setCurrentOption(null);
        assertNull(cl.getCurrentOption());
    }
}
