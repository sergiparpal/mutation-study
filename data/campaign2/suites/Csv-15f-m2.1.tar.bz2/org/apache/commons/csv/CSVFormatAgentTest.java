/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.csv;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.StringWriter;

import org.junit.Test;

public class CSVFormatAgentTest {

    private enum Header {
        Name, Email, Phone
    }

    @Test
    public void testNewFormatBasicDefaults() {
        final CSVFormat format = CSVFormat.newFormat(';');
        assertEquals(';', format.getDelimiter());
        assertNull(format.getQuoteCharacter());
        assertNull(format.getQuoteMode());
        assertNull(format.getCommentMarker());
        assertNull(format.getEscapeCharacter());
        assertFalse(format.getIgnoreSurroundingSpaces());
        assertFalse(format.getIgnoreEmptyLines());
        assertNull(format.getRecordSeparator());
        assertNull(format.getNullString());
        assertNull(format.getHeaderComments());
        assertNull(format.getHeader());
        assertFalse(format.getSkipHeaderRecord());
        assertFalse(format.getAllowMissingColumnNames());
        assertFalse(format.getIgnoreHeaderCase());
        assertFalse(format.getTrim());
        assertFalse(format.getTrailingDelimiter());
        assertFalse(format.getAutoFlush());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testNewFormatRejectsLineBreakDelimiter() {
        CSVFormat.newFormat('\n');
    }

    @Test
    public void testDefaultPredefinedSettings() {
        assertEquals(',', CSVFormat.DEFAULT.getDelimiter());
        assertEquals(Character.valueOf('"'), CSVFormat.DEFAULT.getQuoteCharacter());
        assertEquals("\r\n", CSVFormat.DEFAULT.getRecordSeparator());
        assertTrue(CSVFormat.DEFAULT.getIgnoreEmptyLines());
    }

    @Test
    public void testExcelPredefinedSettings() {
        assertFalse(CSVFormat.EXCEL.getIgnoreEmptyLines());
        assertTrue(CSVFormat.EXCEL.getAllowMissingColumnNames());
    }

    @Test
    public void testRfc4180PredefinedSettings() {
        assertFalse(CSVFormat.RFC4180.getIgnoreEmptyLines());
        assertEquals(CSVFormat.DEFAULT.getDelimiter(), CSVFormat.RFC4180.getDelimiter());
    }

    @Test
    public void testMySqlPredefinedSettings() {
        assertEquals('\t', CSVFormat.MYSQL.getDelimiter());
        assertNull(CSVFormat.MYSQL.getQuoteCharacter());
        assertEquals(Character.valueOf('\\'), CSVFormat.MYSQL.getEscapeCharacter());
        assertEquals("\\N", CSVFormat.MYSQL.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, CSVFormat.MYSQL.getQuoteMode());
    }

    @Test
    public void testTdfPredefinedSettings() {
        assertEquals('\t', CSVFormat.TDF.getDelimiter());
        assertTrue(CSVFormat.TDF.getIgnoreSurroundingSpaces());
    }

    @Test
    public void testValueOfReturnsPredefinedFormat() {
        assertEquals(CSVFormat.EXCEL, CSVFormat.valueOf("Excel"));
        assertEquals(CSVFormat.DEFAULT, CSVFormat.valueOf("Default"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testValueOfUnknownNameThrows() {
        CSVFormat.valueOf("NotARealFormat");
    }

    @Test
    public void testWithDelimiter() {
        final CSVFormat format = CSVFormat.DEFAULT.withDelimiter('|');
        assertEquals('|', format.getDelimiter());
        // original is unchanged (immutability)
        assertEquals(',', CSVFormat.DEFAULT.getDelimiter());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithDelimiterRejectsLineBreak() {
        CSVFormat.DEFAULT.withDelimiter('\r');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithQuoteRejectsLineBreak() {
        CSVFormat.DEFAULT.withQuote('\n');
    }

    @Test
    public void testWithQuoteNullDisables() {
        final CSVFormat format = CSVFormat.DEFAULT.withQuote((Character) null);
        assertNull(format.getQuoteCharacter());
        assertFalse(format.isQuoteCharacterSet());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithEscapeRejectsLineBreak() {
        CSVFormat.DEFAULT.withEscape('\n');
    }

    @Test
    public void testWithEscapeSetsCharacter() {
        final CSVFormat format = CSVFormat.DEFAULT.withEscape('\\');
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
        assertTrue(format.isEscapeCharacterSet());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithCommentMarkerRejectsLineBreak() {
        CSVFormat.DEFAULT.withCommentMarker('\n');
    }

    @Test
    public void testWithCommentMarkerSetsCharacter() {
        final CSVFormat format = CSVFormat.DEFAULT.withCommentMarker('#');
        assertEquals(Character.valueOf('#'), format.getCommentMarker());
        assertTrue(format.isCommentMarkerSet());
    }

    @Test
    public void testWithNullString() {
        final CSVFormat format = CSVFormat.DEFAULT.withNullString("N/A");
        assertEquals("N/A", format.getNullString());
        assertTrue(format.isNullStringSet());
    }

    @Test
    public void testWithoutNullStringIsNotSet() {
        assertFalse(CSVFormat.DEFAULT.isNullStringSet());
        assertNull(CSVFormat.DEFAULT.getNullString());
    }

    @Test
    public void testWithHeaderStrings() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("a", "b", "c");
        assertArrayEquals(new String[] { "a", "b", "c" }, format.getHeader());
    }

    @Test
    public void testGetHeaderReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("a", "b");
        final String[] header1 = format.getHeader();
        header1[0] = "mutated";
        final String[] header2 = format.getHeader();
        assertEquals("a", header2[0]);
    }

    @Test
    public void testWithHeaderNullDisablesHeader() {
        final CSVFormat withHeader = CSVFormat.DEFAULT.withHeader("a", "b");
        final CSVFormat withoutHeader = withHeader.withHeader((String[]) null);
        assertNull(withoutHeader.getHeader());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithHeaderDuplicateThrows() {
        CSVFormat.DEFAULT.withHeader("a", "b", "a");
    }

    @Test
    public void testWithHeaderEnum() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader(Header.class);
        assertArrayEquals(new String[] { "Name", "Email", "Phone" }, format.getHeader());
    }

    @Test
    public void testWithHeaderEnumNullDisablesHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader((Class<? extends Enum<?>>) null);
        assertNull(format.getHeader());
    }

    @Test
    public void testWithFirstRecordAsHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.withFirstRecordAsHeader();
        assertTrue(format.getSkipHeaderRecord());
        assertNotNull(format.getHeader());
        assertEquals(0, format.getHeader().length);
    }

    @Test
    public void testWithHeaderComments() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeaderComments("line1", "line2");
        assertArrayEquals(new String[] { "line1", "line2" }, format.getHeaderComments());
    }

    @Test
    public void testGetHeaderCommentsReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeaderComments("line1");
        final String[] comments1 = format.getHeaderComments();
        comments1[0] = "mutated";
        final String[] comments2 = format.getHeaderComments();
        assertEquals("line1", comments2[0]);
    }

    @Test
    public void testWithIgnoreEmptyLinesNoArgSetsTrue() {
        final CSVFormat format = CSVFormat.RFC4180.withIgnoreEmptyLines();
        assertTrue(format.getIgnoreEmptyLines());
    }

    @Test
    public void testWithIgnoreHeaderCaseNoArgSetsTrue() {
        final CSVFormat format = CSVFormat.DEFAULT.withIgnoreHeaderCase();
        assertTrue(format.getIgnoreHeaderCase());
    }

    @Test
    public void testWithIgnoreSurroundingSpacesNoArgSetsTrue() {
        final CSVFormat format = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces();
        assertTrue(format.getIgnoreSurroundingSpaces());
    }

    @Test
    public void testWithAllowMissingColumnNamesNoArgSetsTrue() {
        final CSVFormat format = CSVFormat.DEFAULT.withAllowMissingColumnNames();
        assertTrue(format.getAllowMissingColumnNames());
    }

    @Test
    public void testWithSkipHeaderRecordNoArgSetsTrue() {
        final CSVFormat format = CSVFormat.DEFAULT.withSkipHeaderRecord();
        assertTrue(format.getSkipHeaderRecord());
    }

    @Test
    public void testWithTrailingDelimiterNoArgSetsTrue() {
        final CSVFormat format = CSVFormat.DEFAULT.withTrailingDelimiter();
        assertTrue(format.getTrailingDelimiter());
    }

    @Test
    public void testWithTrimNoArgSetsTrue() {
        final CSVFormat format = CSVFormat.DEFAULT.withTrim();
        assertTrue(format.getTrim());
    }

    @Test
    public void testWithAutoFlush() {
        final CSVFormat format = CSVFormat.DEFAULT.withAutoFlush(true);
        assertTrue(format.getAutoFlush());
        assertFalse(CSVFormat.DEFAULT.getAutoFlush());
    }

    @Test
    public void testWithRecordSeparatorChar() {
        final CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator('\n');
        assertEquals("\n", format.getRecordSeparator());
    }

    @Test
    public void testWithRecordSeparatorString() {
        final CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("\r\n");
        assertEquals("\r\n", format.getRecordSeparator());
    }

    @Test
    public void testWithQuoteMode() {
        final CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL);
        assertEquals(QuoteMode.ALL, format.getQuoteMode());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testValidateQuoteModeNoneWithoutEscapeThrows() {
        CSVFormat.DEFAULT.withEscape((Character) null).withQuoteMode(QuoteMode.NONE);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testValidateQuoteAndDelimiterSameThrows() {
        CSVFormat.newFormat(',').withQuote(',');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testValidateEscapeAndDelimiterSameThrows() {
        CSVFormat.newFormat(',').withEscape(',');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testValidateCommentAndDelimiterSameThrows() {
        CSVFormat.newFormat(',').withCommentMarker(',');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testValidateCommentAndQuoteSameThrows() {
        CSVFormat.newFormat(';').withQuote('#').withCommentMarker('#');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testValidateCommentAndEscapeSameThrows() {
        CSVFormat.newFormat(';').withEscape('#').withCommentMarker('#');
    }

    @Test
    public void testEqualsReflexiveAndDistinct() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertTrue(format.equals(format));
        assertFalse(format.equals(null));
        assertFalse(format.equals("not a CSVFormat"));
        assertNotEquals(CSVFormat.DEFAULT, CSVFormat.EXCEL);
    }

    @Test
    public void testEqualsSameSettingsAreEqual() {
        final CSVFormat a = CSVFormat.newFormat(',').withQuote('"').withRecordSeparator("\r\n");
        final CSVFormat b = CSVFormat.newFormat(',').withQuote('"').withRecordSeparator("\r\n");
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    public void testHashCodeConsistentAcrossCalls() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertEquals(format.hashCode(), format.hashCode());
    }

    @Test
    public void testToStringContainsDelimiter() {
        final String str = CSVFormat.DEFAULT.toString();
        assertTrue(str.contains("Delimiter=<,>"));
    }

    @Test
    public void testToStringIncludesHeaderWhenSet() {
        final String str = CSVFormat.DEFAULT.withHeader("a", "b").toString();
        assertTrue(str.contains("Header:"));
        assertTrue(str.contains("a"));
    }

    @Test
    public void testFormatSimpleValues() {
        final String formatted = CSVFormat.DEFAULT.format("a", "b", "c");
        assertEquals("a,b,c", formatted);
    }

    @Test
    public void testFormatQuotesValueContainingDelimiter() {
        final String formatted = CSVFormat.DEFAULT.format("a,b", "c");
        assertEquals("\"a,b\",c", formatted);
    }

    @Test
    public void testPrintRecordWritesSeparatedValuesAndRecordSeparator() throws IOException {
        final StringWriter out = new StringWriter();
        CSVFormat.DEFAULT.printRecord(out, "x", "y", "z");
        assertEquals("x,y,z\r\n", out.toString());
    }

    @Test
    public void testPrintlnWithTrailingDelimiter() throws IOException {
        final StringWriter out = new StringWriter();
        CSVFormat.DEFAULT.withTrailingDelimiter().println(out);
        assertEquals(",\r\n", out.toString());
    }

    @Test
    public void testPrintlnWithoutRecordSeparator() throws IOException {
        final StringWriter out = new StringWriter();
        CSVFormat.newFormat(',').println(out);
        assertEquals("", out.toString());
    }

    @Test
    public void testPrintNullValueWithoutNullString() throws IOException {
        final StringWriter out = new StringWriter();
        CSVFormat.DEFAULT.print(null, out, true);
        assertEquals("", out.toString());
    }

    @Test
    public void testPrintNullValueWithNullString() throws IOException {
        final StringWriter out = new StringWriter();
        CSVFormat.DEFAULT.withNullString("NULL").print(null, out, true);
        assertEquals("NULL", out.toString());
    }

    @Test
    public void testPrintEscapesSpecialCharacters() throws IOException {
        final StringWriter out = new StringWriter();
        final CSVFormat format = CSVFormat.newFormat(',').withEscape('\\');
        format.print("a,b", out, true);
        assertEquals("a\\,b", out.toString());
    }

    @Test
    public void testParseProducesExpectedRecord() throws IOException {
        final java.io.StringReader reader = new java.io.StringReader("a,b,c\n");
        final CSVParser parser = CSVFormat.DEFAULT.parse(reader);
        final CSVRecord record = parser.iterator().next();
        assertEquals("a", record.get(0));
        assertEquals("b", record.get(1));
        assertEquals("c", record.get(2));
        parser.close();
    }

    @Test
    public void testPrintToAppendableReturnsWorkingPrinter() throws IOException {
        final StringWriter out = new StringWriter();
        final CSVPrinter printer = CSVFormat.DEFAULT.print(out);
        printer.printRecord("1", "2");
        printer.close();
        assertEquals("1,2\r\n", out.toString());
    }

    @Test
    public void testSerialization() throws IOException, ClassNotFoundException {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("a", "b").withNullString("NULL");
        final ByteArrayOutputStream bos = new ByteArrayOutputStream();
        final ObjectOutputStream oos = new ObjectOutputStream(bos);
        oos.writeObject(format);
        oos.close();
        final ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(bos.toByteArray()));
        final CSVFormat deserialized = (CSVFormat) ois.readObject();
        ois.close();
        assertEquals(format, deserialized);
        assertArrayEquals(format.getHeader(), deserialized.getHeader());
    }

    @Test
    public void testImmutabilityOfWithMethods() {
        final CSVFormat base = CSVFormat.DEFAULT;
        base.withDelimiter(';');
        base.withQuote('\'');
        base.withHeader("x");
        // base must remain unchanged after calling with* methods
        assertEquals(',', base.getDelimiter());
        assertEquals(Character.valueOf('"'), base.getQuoteCharacter());
        assertNull(base.getHeader());
    }

    @Test
    public void testPredefinedEnumGetFormat() {
        assertEquals(CSVFormat.EXCEL, CSVFormat.Predefined.Excel.getFormat());
        assertEquals(CSVFormat.DEFAULT, CSVFormat.Predefined.Default.getFormat());
    }

    @Test
    public void testWithHeaderResultSetNullProducesNullHeader() throws java.sql.SQLException {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader((java.sql.ResultSet) null);
        assertNull(format.getHeader());
    }

    @Test
    public void testNewFormatValidatesOnConstructionWithLineBreakFails() {
        try {
            CSVFormat.newFormat('\r');
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }
}
