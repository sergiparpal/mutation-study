package com.google.gson.stream;

import junit.framework.TestCase;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

/**
 * Self-contained tests for {@link JsonWriter} based solely on its documented
 * contract (api/com/google/gson/stream/JsonWriter.html).
 */
public class JsonWriterAgentTest extends TestCase {

    /** Writer that counts flush() invocations, used to observe flush()/close() delegation. */
    private static final class FlushTrackingWriter extends Writer {
        private final StringWriter delegate = new StringWriter();
        int flushCount = 0;
        boolean closed = false;

        public void write(char[] cbuf, int off, int len) throws IOException {
            delegate.write(cbuf, off, len);
        }

        public void flush() throws IOException {
            flushCount++;
            delegate.flush();
        }

        public void close() throws IOException {
            closed = true;
            delegate.close();
        }

        public String toString() {
            return delegate.toString();
        }
    }

    public void testBeginEndArrayEmptyProducesBrackets() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        writer.beginArray();
        writer.endArray();
        assertEquals("[]", sw.toString());
    }

    public void testBeginEndObjectEmptyProducesBraces() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        writer.beginObject();
        writer.endObject();
        assertEquals("{}", sw.toString());
    }

    public void testNestedStructureMatchesCallOrder() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        writer.beginObject();
        writer.name("id").value(912345678901L);
        writer.name("text").value("How do I stream JSON in Java?");
        writer.name("geo").nullValue();
        writer.name("user");
        writer.beginObject();
        writer.name("name").value("json_newb");
        writer.name("followers_count").value(41);
        writer.endObject();
        writer.endObject();
        writer.close();

        String expected = "{\"id\":912345678901,\"text\":\"How do I stream JSON in Java?\","
                + "\"geo\":null,\"user\":{\"name\":\"json_newb\",\"followers_count\":41}}";
        assertEquals(expected, sw.toString());
    }

    public void testValueStringQuotesAndEscapes() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        writer.beginArray();
        writer.value("a\"b\\c");
        writer.endArray();
        assertEquals("[\"a\\\"b\\\\c\"]", sw.toString());
    }

    public void testValueBooleanTrueFalse() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        writer.beginArray();
        writer.value(true);
        writer.value(false);
        writer.endArray();
        assertEquals("[true,false]", sw.toString());
    }

    public void testValueLong() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        writer.beginArray();
        writer.value(123456789012345L);
        writer.endArray();
        assertEquals("[123456789012345]", sw.toString());
    }

    public void testValueDouble() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        writer.beginArray();
        writer.value(3.14);
        writer.endArray();
        assertEquals("[3.14]", sw.toString());
    }

    public void testValueNumber() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        writer.beginArray();
        writer.value(Integer.valueOf(5));
        writer.endArray();
        assertEquals("[5]", sw.toString());
    }

    public void testGetSerializeNullsDefaultTrue() {
        JsonWriter writer = new JsonWriter(new StringWriter());
        assertTrue(writer.getSerializeNulls());
    }

    public void testNullValueWrittenByDefaultInObject() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        writer.beginObject();
        writer.name("a");
        writer.nullValue();
        writer.endObject();
        assertEquals("{\"a\":null}", sw.toString());
    }

    public void testSetSerializeNullsFalseOmitsNullObjectMember() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        writer.setSerializeNulls(false);
        assertFalse(writer.getSerializeNulls());
        writer.beginObject();
        writer.name("a");
        writer.nullValue();
        writer.name("b").value(1);
        writer.endObject();
        assertEquals("{\"b\":1}", sw.toString());
    }

    public void testNullValueAlwaysWrittenInArrayRegardlessOfSerializeNulls() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        writer.setSerializeNulls(false);
        writer.beginArray();
        writer.nullValue();
        writer.endArray();
        assertEquals("[null]", sw.toString());
    }

    public void testFluentMethodsReturnThisWriter() throws IOException {
        JsonWriter writer = new JsonWriter(new StringWriter());
        assertSame(writer, writer.beginObject());
        assertSame(writer, writer.name("a"));
        assertSame(writer, writer.value("x"));
        assertSame(writer, writer.name("b"));
        assertSame(writer, writer.value(true));
        assertSame(writer, writer.name("c"));
        assertSame(writer, writer.value(1L));
        assertSame(writer, writer.name("d"));
        assertSame(writer, writer.value(1.5));
        assertSame(writer, writer.name("e"));
        assertSame(writer, writer.value(Integer.valueOf(2)));
        assertSame(writer, writer.name("f"));
        assertSame(writer, writer.nullValue());
        assertSame(writer, writer.name("g"));
        assertSame(writer, writer.jsonValue("1"));
        assertSame(writer, writer.name("h"));
        assertSame(writer, writer.beginArray());
        assertSame(writer, writer.endArray());
        assertSame(writer, writer.endObject());
    }

    public void testIsLenientDefaultFalse() {
        JsonWriter writer = new JsonWriter(new StringWriter());
        assertFalse(writer.isLenient());
    }

    public void testSetLenientAllowsTopLevelScalar() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        writer.setLenient(true);
        assertTrue(writer.isLenient());
        writer.value("hello");
        assertEquals("\"hello\"", sw.toString());
    }

    public void pruned_testStrictTopLevelScalarThrowsIllegalStateException() {
        JsonWriter writer = new JsonWriter(new StringWriter());
        try {
            writer.value("hello");
            fail("Expected IllegalStateException for malformed top-level scalar in strict mode");
        } catch (IllegalStateException expected) {
            // documented class-level contract: malformed JSON fails with IllegalStateException
        } catch (IOException unexpected) {
            fail("Expected IllegalStateException, not IOException");
        }
    }

    public void pruned_testStrictNonFiniteDoubleThrowsIllegalStateException() throws IOException {
        JsonWriter writer = new JsonWriter(new StringWriter());
        writer.beginArray();
        try {
            writer.value(Double.NaN);
            fail("Expected IllegalStateException for non-finite value in strict mode");
        } catch (IllegalStateException expected) {
            // documented class-level contract: malformed JSON fails with IllegalStateException
        }
    }

    public void pruned_testLenientAllowsNonFiniteDouble() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        writer.setLenient(true);
        writer.beginArray();
        writer.value(Double.NaN);
        writer.endArray();
        assertEquals("[NaN]", sw.toString());
    }

    public void testValueStringNullEncodesNullLiteral() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        writer.beginArray();
        writer.value((String) null);
        writer.endArray();
        assertEquals("[null]", sw.toString());
    }

    public void testJsonValueWritesRawUnescapedContent() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        writer.beginObject();
        writer.name("a");
        writer.jsonValue("{\"b\":1}");
        writer.endObject();
        assertEquals("{\"a\":{\"b\":1}}", sw.toString());
    }

    public void testNameRequiresNonNull() throws IOException {
        JsonWriter writer = new JsonWriter(new StringWriter());
        writer.beginObject();
        try {
            writer.name(null);
            fail("Expected a RuntimeException because name may not be null");
        } catch (RuntimeException expected) {
            // documented precondition: name may not be null
        }
    }

    public void testSetHtmlSafeEscapesSpecialCharacters() throws IOException {
        StringWriter plainOut = new StringWriter();
        JsonWriter plainWriter = new JsonWriter(plainOut);
        plainWriter.beginArray();
        plainWriter.value("<<&>>=");
        plainWriter.endArray();
        assertTrue(plainOut.toString().indexOf('<') >= 0);

        StringWriter safeOut = new StringWriter();
        JsonWriter safeWriter = new JsonWriter(safeOut);
        safeWriter.setHtmlSafe(true);
        assertTrue(safeWriter.isHtmlSafe());
        safeWriter.beginArray();
        safeWriter.value("<<&>>=");
        safeWriter.endArray();
        assertTrue(safeOut.toString().indexOf('<') < 0);
        assertTrue(safeOut.toString().indexOf('>') < 0);
        assertTrue(safeOut.toString().indexOf('&') < 0);
    }

    public void testIsHtmlSafeDefaultFalse() {
        JsonWriter writer = new JsonWriter(new StringWriter());
        assertFalse(writer.isHtmlSafe());
    }

    public void testFlushDelegatesToUnderlyingWriter() throws IOException {
        FlushTrackingWriter tracking = new FlushTrackingWriter();
        JsonWriter writer = new JsonWriter(tracking);
        writer.beginArray();
        writer.endArray();
        assertEquals(0, tracking.flushCount);
        writer.flush();
        assertTrue(tracking.flushCount >= 1);
    }

    public void testCloseFlushesAndClosesUnderlyingWriter() throws IOException {
        FlushTrackingWriter tracking = new FlushTrackingWriter();
        JsonWriter writer = new JsonWriter(tracking);
        writer.beginArray();
        writer.endArray();
        writer.close();
        assertTrue(tracking.closed);
        assertEquals("[]", tracking.toString());
    }

    public void testCloseThrowsIOExceptionWhenDocumentIncomplete() throws IOException {
        JsonWriter writer = new JsonWriter(new StringWriter());
        writer.beginObject();
        try {
            writer.close();
            fail("Expected IOException because the JSON document is incomplete");
        } catch (IOException expected) {
            // documented behavior
        }
    }

    public void testCloseSucceedsWhenDocumentComplete() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        writer.beginArray();
        writer.endArray();
        writer.close();
        assertEquals("[]", sw.toString());
    }

    public void testEndArrayWithoutBeginThrowsIllegalStateException() throws IOException {
        JsonWriter writer = new JsonWriter(new StringWriter());
        try {
            writer.endArray();
            fail("Expected IllegalStateException");
        } catch (IllegalStateException expected) {
            // documented class-level contract: malformed JSON fails with IllegalStateException
        }
    }

    public void pruned_testNameOutsideObjectThrowsIllegalStateException() throws IOException {
        JsonWriter writer = new JsonWriter(new StringWriter());
        writer.beginArray();
        try {
            writer.name("x");
            fail("Expected IllegalStateException because name() is only valid inside an object");
        } catch (IllegalStateException expected) {
            // documented class-level contract: malformed JSON fails with IllegalStateException
        }
    }

    public void testSetIndentPrettyPrintsNestedStructure() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        writer.setIndent("  ");
        writer.beginObject();
        writer.name("a");
        writer.beginArray();
        writer.value(1);
        writer.value(2);
        writer.endArray();
        writer.endObject();
        String out = sw.toString();
        assertTrue(out.indexOf('\n') >= 0);
        assertTrue(out.indexOf("  ") >= 0);
    }
}
