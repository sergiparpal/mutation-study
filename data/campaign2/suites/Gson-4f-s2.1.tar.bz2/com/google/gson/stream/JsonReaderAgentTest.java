package com.google.gson.stream;

import junit.framework.TestCase;

import java.io.IOException;
import java.io.StringReader;

/**
 * Self-contained tests for {@link JsonReader} based solely on its documented
 * contract (api/com/google/gson/stream/JsonReader.html).
 */
public class JsonReaderAgentTest extends TestCase {

    public void testBeginEndArrayEmpty() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[]"));
        reader.beginArray();
        assertFalse(reader.hasNext());
        reader.endArray();
        reader.close();
    }

    public void testBeginEndObjectEmpty() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("{}"));
        reader.beginObject();
        assertFalse(reader.hasNext());
        reader.endObject();
        reader.close();
    }

    public void testNestedObjectsAndArrays() throws IOException {
        String json = "{\"id\":123,\"text\":\"hi\",\"geo\":[1.5,-2.5],"
                + "\"user\":{\"name\":\"bob\",\"count\":7}}";
        JsonReader reader = new JsonReader(new StringReader(json));
        reader.beginObject();
        assertEquals("id", reader.nextName());
        assertEquals(123L, reader.nextLong());
        assertEquals("text", reader.nextName());
        assertEquals("hi", reader.nextString());
        assertEquals("geo", reader.nextName());
        reader.beginArray();
        assertEquals(1.5, reader.nextDouble(), 0.0);
        assertEquals(-2.5, reader.nextDouble(), 0.0);
        assertFalse(reader.hasNext());
        reader.endArray();
        assertEquals("user", reader.nextName());
        reader.beginObject();
        assertEquals("name", reader.nextName());
        assertEquals("bob", reader.nextString());
        assertEquals("count", reader.nextName());
        assertEquals(7, reader.nextInt());
        reader.endObject();
        assertFalse(reader.hasNext());
        reader.endObject();
        reader.close();
    }

    public void testNextStringReadsNumberAsString() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[1]"));
        reader.beginArray();
        assertEquals("1", reader.nextString());
        reader.endArray();
    }

    public void testNextIntReadsStringAsNumber() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[\"123\"]"));
        reader.beginArray();
        assertEquals(123, reader.nextInt());
        reader.endArray();
    }

    public void testNextBooleanTrueFalse() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[true,false]"));
        reader.beginArray();
        assertTrue(reader.nextBoolean());
        assertFalse(reader.nextBoolean());
        reader.endArray();
    }

    public void testNextNull() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[null]"));
        reader.beginArray();
        assertEquals(JsonToken.NULL, reader.peek());
        reader.nextNull();
        reader.endArray();
    }

    public void testPeekDoesNotConsumeToken() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[42]"));
        reader.beginArray();
        assertEquals(JsonToken.NUMBER, reader.peek());
        assertEquals(JsonToken.NUMBER, reader.peek());
        assertEquals(42, reader.nextInt());
        reader.endArray();
    }

    public void testHasNextFalseWhenArrayEmpty() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[]"));
        reader.beginArray();
        assertFalse(reader.hasNext());
    }

    public void testHasNextFalseWhenObjectEmpty() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("{}"));
        reader.beginObject();
        assertFalse(reader.hasNext());
    }

    public void testSkipValueSkipsNestedStructure() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[{\"a\":[1,2,3]},true]"));
        reader.beginArray();
        reader.skipValue();
        assertTrue(reader.nextBoolean());
        reader.endArray();
    }

    public void testIsLenientDefaultFalse() {
        JsonReader reader = new JsonReader(new StringReader("[]"));
        assertFalse(reader.isLenient());
    }

    public void testSetLenientTrue() {
        JsonReader reader = new JsonReader(new StringReader("[]"));
        reader.setLenient(true);
        assertTrue(reader.isLenient());
    }

    public void pruned_testStrictTopLevelScalarThrowsIOException() {
        JsonReader reader = new JsonReader(new StringReader("\"hello\""));
        try {
            reader.peek();
            fail("Expected IOException for strict top-level scalar");
        } catch (IOException expected) {
            // documented behavior
        }
    }

    public void testLenientAllowsTopLevelScalar() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("\"hello\""));
        reader.setLenient(true);
        assertEquals("hello", reader.nextString());
    }

    public void testStrictRejectsNonExecutePrefix() {
        JsonReader reader = new JsonReader(new StringReader(")]}'\n[]"));
        try {
            reader.beginArray();
            fail("Expected IOException for non-execute prefix in strict mode");
        } catch (IOException expected) {
            // documented behavior
        }
    }

    public void testLenientAcceptsNonExecutePrefix() throws IOException {
        JsonReader reader = new JsonReader(new StringReader(")]}'\n[1,2]"));
        reader.setLenient(true);
        reader.beginArray();
        assertEquals(1, reader.nextInt());
        assertEquals(2, reader.nextInt());
        reader.endArray();
    }

    public void testStrictRejectsMultipleTopLevelValues() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[][]"));
        reader.beginArray();
        reader.endArray();
        try {
            reader.peek();
            fail("Expected IOException for multiple top-level values in strict mode");
        } catch (IOException expected) {
            // documented behavior
        }
    }

    public void testLenientAllowsMultipleTopLevelValues() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[][]"));
        reader.setLenient(true);
        reader.beginArray();
        reader.endArray();
        reader.beginArray();
        reader.endArray();
    }

    public void testNextIntThrowsNumberFormatExceptionOnOverflow() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[99999999999]"));
        reader.beginArray();
        try {
            reader.nextInt();
            fail("Expected NumberFormatException");
        } catch (NumberFormatException expected) {
            // documented behavior
        }
    }

    public void testNextLongThrowsNumberFormatExceptionWhenNotExact() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[1.5]"));
        reader.beginArray();
        try {
            reader.nextLong();
            fail("Expected NumberFormatException");
        } catch (NumberFormatException expected) {
            // documented behavior
        }
    }

    public void pruned_testNextDoubleThrowsNumberFormatExceptionWhenNonFinite() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[NaN]"));
        reader.setLenient(true);
        reader.beginArray();
        try {
            reader.nextDouble();
            fail("Expected NumberFormatException for non-finite value");
        } catch (NumberFormatException expected) {
            // documented behavior
        }
    }

    public void testNextStringThrowsIllegalStateExceptionOnWrongType() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[[]]"));
        reader.beginArray();
        try {
            reader.nextString();
            fail("Expected IllegalStateException");
        } catch (IllegalStateException expected) {
            // documented behavior
        }
    }

    public void testNextBooleanThrowsIllegalStateExceptionOnWrongType() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[1]"));
        reader.beginArray();
        try {
            reader.nextBoolean();
            fail("Expected IllegalStateException");
        } catch (IllegalStateException expected) {
            // documented behavior
        }
    }

    public void testNextNullThrowsIllegalStateExceptionOnWrongType() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[1]"));
        reader.beginArray();
        try {
            reader.nextNull();
            fail("Expected IllegalStateException");
        } catch (IllegalStateException expected) {
            // documented behavior
        }
    }

    public void testCloseThenNextStringThrowsIllegalStateException() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[]"));
        reader.close();
        try {
            reader.nextString();
            fail("Expected IllegalStateException after close");
        } catch (IllegalStateException expected) {
            // documented behavior
        }
    }

    public void testGetPathNotNull() {
        JsonReader reader = new JsonReader(new StringReader("[1,2]"));
        assertNotNull(reader.getPath());
    }

    public void testGetPathChangesAfterConsumingTokens() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[1,2]"));
        String before = reader.getPath();
        reader.beginArray();
        reader.nextInt();
        String after = reader.getPath();
        assertFalse(before.equals(after));
    }

    public void testToStringNotNull() {
        JsonReader reader = new JsonReader(new StringReader("[]"));
        assertNotNull(reader.toString());
    }

    public void pruned_testEndArrayThrowsWhenArrayNotFinished() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[1,2]"));
        reader.beginArray();
        reader.nextInt();
        try {
            reader.endArray();
            fail("Expected IOException because the array has another element");
        } catch (IOException expected) {
            // documented behavior
        }
    }

    public void pruned_testBeginArrayThrowsOnWrongTokenType() {
        JsonReader reader = new JsonReader(new StringReader("{}"));
        try {
            reader.beginArray();
            fail("Expected IOException");
        } catch (IOException expected) {
            // documented behavior
        }
    }

    public void pruned_testNextNameThrowsWhenNotInObject() throws IOException {
        JsonReader reader = new JsonReader(new StringReader("[1]"));
        reader.beginArray();
        try {
            reader.nextName();
            fail("Expected IOException because the next token is not a property name");
        } catch (IOException expected) {
            // documented behavior
        }
    }
}
