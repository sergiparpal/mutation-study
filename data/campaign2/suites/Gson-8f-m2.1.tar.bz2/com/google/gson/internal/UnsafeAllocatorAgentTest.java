/*
 * Copyright (C) 2011 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.google.gson.internal;

import junit.framework.TestCase;

public class UnsafeAllocatorAgentTest extends TestCase {

  public static class NoArgConstructor {
    int value = 42;
  }

  public static class ThrowingConstructor {
    int value;
    public ThrowingConstructor() {
      value = -1;
      throw new RuntimeException("constructor should never run via UnsafeAllocator");
    }
  }

  public static class PrivateConstructor {
    private PrivateConstructor() {
    }
  }

  public abstract static class AbstractClass {
    public abstract void doSomething();
  }

  public interface SomeInterface {
    void doSomething();
  }

  public static class Base {
  }

  public static class Derived extends Base {
    String name = "derived";
  }

  public void testCreateReturnsNonNullAllocator() {
    UnsafeAllocator allocator = UnsafeAllocator.create();
    assertNotNull(allocator);
  }

  public void testNewInstanceWithNoArgConstructorDoesNotRunConstructor() throws Exception {
    UnsafeAllocator allocator = UnsafeAllocator.create();
    NoArgConstructor instance = allocator.newInstance(NoArgConstructor.class);
    assertNotNull(instance);
    assertEquals(NoArgConstructor.class, instance.getClass());
    // Unsafe allocation bypasses the constructor, so field initializers never run.
    assertEquals(0, instance.value);
  }

  public void testNewInstanceBypassesThrowingConstructor() throws Exception {
    UnsafeAllocator allocator = UnsafeAllocator.create();
    ThrowingConstructor instance = allocator.newInstance(ThrowingConstructor.class);
    assertNotNull(instance);
    assertEquals(0, instance.value);
  }

  public void testNewInstanceWithPrivateConstructor() throws Exception {
    UnsafeAllocator allocator = UnsafeAllocator.create();
    PrivateConstructor instance = allocator.newInstance(PrivateConstructor.class);
    assertNotNull(instance);
    assertEquals(PrivateConstructor.class, instance.getClass());
  }

  public void testNewInstanceWithDerivedClass() throws Exception {
    UnsafeAllocator allocator = UnsafeAllocator.create();
    Derived instance = allocator.newInstance(Derived.class);
    assertNotNull(instance);
    assertTrue(instance instanceof Base);
    assertNull(instance.name);
  }

  public void testNewInstanceWithAbstractClassThrows() throws Exception {
    UnsafeAllocator allocator = UnsafeAllocator.create();
    try {
      allocator.newInstance(AbstractClass.class);
      fail("Expected UnsupportedOperationException for abstract class");
    } catch (UnsupportedOperationException expected) {
      assertTrue(expected.getMessage().contains("Abstract class"));
    }
  }

  public void testNewInstanceWithInterfaceThrows() throws Exception {
    UnsafeAllocator allocator = UnsafeAllocator.create();
    try {
      allocator.newInstance(SomeInterface.class);
      fail("Expected UnsupportedOperationException for interface");
    } catch (UnsupportedOperationException expected) {
      assertTrue(expected.getMessage().contains("Interface"));
    }
  }

  public void testMultipleInstancesAreDistinct() throws Exception {
    UnsafeAllocator allocator = UnsafeAllocator.create();
    NoArgConstructor first = allocator.newInstance(NoArgConstructor.class);
    NoArgConstructor second = allocator.newInstance(NoArgConstructor.class);
    assertNotNull(first);
    assertNotNull(second);
    assertNotSame(first, second);
  }

  public void testCreateCalledTwiceBothWork() throws Exception {
    UnsafeAllocator allocator1 = UnsafeAllocator.create();
    UnsafeAllocator allocator2 = UnsafeAllocator.create();
    assertNotNull(allocator1.newInstance(NoArgConstructor.class));
    assertNotNull(allocator2.newInstance(NoArgConstructor.class));
  }
}
