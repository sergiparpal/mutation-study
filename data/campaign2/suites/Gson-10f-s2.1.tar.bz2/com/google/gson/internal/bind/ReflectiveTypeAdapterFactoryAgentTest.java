package com.google.gson.internal.bind;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.TypeAdapter;
import com.google.gson.TypeAdapterFactory;
import com.google.gson.internal.ConstructorConstructor;
import com.google.gson.internal.Excluder;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;

/**
 * Tests for {@link ReflectiveTypeAdapterFactory} based on the documented contract in api/.
 */
public class ReflectiveTypeAdapterFactoryAgentTest {

    /** A plain fixture class with an ordinary, a transient and a static field. */
    static class SimplePojo {
        String name;
        int age;
        transient String secret = "hidden";
        static String sharedStatic = "static-value";
    }

    /** A fixture class with no fields at all. */
    static class EmptyPojo {
    }

    private static ConstructorConstructor newConstructorConstructor() {
        try {
            Constructor<?>[] ctors = ConstructorConstructor.class.getDeclaredConstructors();
            for (int i = 0; i < ctors.length; i++) {
                Constructor<?> ctor = ctors[i];
                Class<?>[] paramTypes = ctor.getParameterTypes();
                Object[] args = new Object[paramTypes.length];
                boolean ok = true;
                for (int j = 0; j < paramTypes.length; j++) {
                    Class<?> pt = paramTypes[j];
                    if (pt == Map.class) {
                        args[j] = new HashMap<Object, Object>();
                    } else if (pt == boolean.class) {
                        args[j] = Boolean.FALSE;
                    } else if (pt == List.class) {
                        args[j] = new ArrayList<Object>();
                    } else {
                        ok = false;
                        break;
                    }
                }
                if (ok) {
                    ctor.setAccessible(true);
                    return (ConstructorConstructor) ctor.newInstance(args);
                }
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        throw new IllegalStateException("No usable ConstructorConstructor constructor found");
    }

    private static ReflectiveTypeAdapterFactory newFactory() {
        return new ReflectiveTypeAdapterFactory(
                newConstructorConstructor(), FieldNamingPolicy.IDENTITY, Excluder.DEFAULT);
    }

    private static Field fieldOf(Class<?> c, String name) {
        try {
            return c.getDeclaredField(name);
        } catch (NoSuchFieldException e) {
            throw new RuntimeException(e);
        }
    }

    // --- Structural contract: "public final class ... implements TypeAdapterFactory" ---

    @Test
    public void testClassIsPublicFinalAndImplementsTypeAdapterFactory() {
        int modifiers = ReflectiveTypeAdapterFactory.class.getModifiers();
        assertTrue(Modifier.isPublic(modifiers));
        assertTrue(Modifier.isFinal(modifiers));
        assertTrue(TypeAdapterFactory.class.isAssignableFrom(ReflectiveTypeAdapterFactory.class));
    }

    @Test
    public void testAdapterNestedClassExtendsTypeAdapter() {
        int modifiers = ReflectiveTypeAdapterFactory.Adapter.class.getModifiers();
        assertTrue(Modifier.isPublic(modifiers));
        assertTrue(Modifier.isFinal(modifiers));
        assertTrue(TypeAdapter.class.isAssignableFrom(ReflectiveTypeAdapterFactory.Adapter.class));
    }

    // --- create(Gson, TypeToken<T>) ---

    @Test
    public void testCreateReturnsNullForPrimitiveType() {
        ReflectiveTypeAdapterFactory factory = newFactory();
        Gson gson = new Gson();
        TypeToken<?> intToken = TypeToken.get(int.class);
        TypeAdapter<?> adapter = factory.create(gson, intToken);
        assertNull("Primitive types are not supported by a reflective adapter", adapter);
    }

    @Test
    public void testCreateReturnsNullForOtherPrimitiveType() {
        ReflectiveTypeAdapterFactory factory = newFactory();
        Gson gson = new Gson();
        TypeToken<?> booleanToken = TypeToken.get(boolean.class);
        TypeAdapter<?> adapter = factory.create(gson, booleanToken);
        assertNull(adapter);
    }

    @Test
    public void testCreateReturnsAdapterInstanceForPojoType() {
        ReflectiveTypeAdapterFactory factory = newFactory();
        Gson gson = new Gson();
        TypeAdapter<SimplePojo> adapter = factory.create(gson, TypeToken.get(SimplePojo.class));
        assertNotNull(adapter);
        assertTrue(adapter instanceof ReflectiveTypeAdapterFactory.Adapter);
    }

    @Test
    public void testCreateNullTypeThrows() {
        ReflectiveTypeAdapterFactory factory = newFactory();
        Gson gson = new Gson();
        try {
            factory.create(gson, null);
            fail("Expected an exception for a null type");
        } catch (RuntimeException expected) {
            // documented behavior does not cover null type; any runtime failure is acceptable
        }
    }

    // --- Adapter.read / Adapter.write round trip, reached via create() ---

    @Test
    public void testAdapterRoundTripsOrdinaryFields() throws Exception {
        ReflectiveTypeAdapterFactory factory = newFactory();
        Gson gson = new Gson();
        TypeAdapter<SimplePojo> adapter = factory.create(gson, TypeToken.get(SimplePojo.class));

        SimplePojo pojo = new SimplePojo();
        pojo.name = "Alice";
        pojo.age = 30;

        String json = adapter.toJson(pojo);
        assertTrue(json.contains("\"name\""));
        assertTrue(json.contains("Alice"));
        assertTrue(json.contains("\"age\""));
        assertTrue(json.contains("30"));

        SimplePojo roundTripped = adapter.fromJson(json);
        assertNotNull(roundTripped);
        assertEquals("Alice", roundTripped.name);
        assertEquals(30, roundTripped.age);
    }

    @Test
    public void testAdapterExcludesTransientAndStaticFieldsFromOutput() throws Exception {
        ReflectiveTypeAdapterFactory factory = newFactory();
        Gson gson = new Gson();
        TypeAdapter<SimplePojo> adapter = factory.create(gson, TypeToken.get(SimplePojo.class));

        SimplePojo pojo = new SimplePojo();
        pojo.name = "Bob";
        pojo.age = 1;

        String json = adapter.toJson(pojo);
        assertFalse("transient fields must not be serialized", json.contains("secret"));
        assertFalse("transient fields must not be serialized", json.contains("hidden"));
        assertFalse("static fields must not be serialized", json.contains("sharedStatic"));
        assertFalse("static fields must not be serialized", json.contains("static-value"));
    }

    @Test
    public void testAdapterWriteHandlesNullValue() throws Exception {
        ReflectiveTypeAdapterFactory factory = newFactory();
        Gson gson = new Gson();
        TypeAdapter<SimplePojo> adapter = factory.create(gson, TypeToken.get(SimplePojo.class));

        String json = adapter.toJson(null);
        assertEquals("null", json);
    }

    @Test
    public void testAdapterReadHandlesJsonNull() throws Exception {
        ReflectiveTypeAdapterFactory factory = newFactory();
        Gson gson = new Gson();
        TypeAdapter<SimplePojo> adapter = factory.create(gson, TypeToken.get(SimplePojo.class));

        SimplePojo result = adapter.fromJson("null");
        assertNull("Converted Java object may be null, per the read() contract", result);
    }

    @Test
    public void testAdapterHandlesEmptyClassWithNoFields() throws Exception {
        ReflectiveTypeAdapterFactory factory = newFactory();
        Gson gson = new Gson();
        TypeAdapter<EmptyPojo> adapter = factory.create(gson, TypeToken.get(EmptyPojo.class));
        assertNotNull(adapter);

        String json = adapter.toJson(new EmptyPojo());
        assertEquals("{}", json);

        EmptyPojo result = adapter.fromJson("{}");
        assertNotNull(result);
    }

    // --- excludeField(Field, boolean) and the package-private 3-arg overload ---

    @Test
    public void testExcludeFieldInstanceAndStaticOverloadAgreeForOrdinaryField() {
        ReflectiveTypeAdapterFactory factory = newFactory();
        Field f = fieldOf(SimplePojo.class, "name");

        boolean viaInstanceSerialize = factory.excludeField(f, true);
        boolean viaStaticSerialize = ReflectiveTypeAdapterFactory.excludeField(f, true, Excluder.DEFAULT);
        assertEquals(viaStaticSerialize, viaInstanceSerialize);

        boolean viaInstanceDeserialize = factory.excludeField(f, false);
        boolean viaStaticDeserialize = ReflectiveTypeAdapterFactory.excludeField(f, false, Excluder.DEFAULT);
        assertEquals(viaStaticDeserialize, viaInstanceDeserialize);
    }

    @Test
    public void testExcludeFieldInstanceAndStaticOverloadAgreeForTransientField() {
        ReflectiveTypeAdapterFactory factory = newFactory();
        Field f = fieldOf(SimplePojo.class, "secret");

        boolean viaInstance = factory.excludeField(f, true);
        boolean viaStatic = ReflectiveTypeAdapterFactory.excludeField(f, true, Excluder.DEFAULT);
        assertEquals(viaStatic, viaInstance);
    }

    @Test
    public void testExcludeFieldInstanceAndStaticOverloadAgreeForStaticField() {
        ReflectiveTypeAdapterFactory factory = newFactory();
        Field f = fieldOf(SimplePojo.class, "sharedStatic");

        boolean viaInstance = factory.excludeField(f, true);
        boolean viaStatic = ReflectiveTypeAdapterFactory.excludeField(f, true, Excluder.DEFAULT);
        assertEquals(viaStatic, viaInstance);
    }

    @Test
    public void testExcludeFieldOnOrdinaryFieldIsConsistentAcrossSerializeAndDeserialize() {
        ReflectiveTypeAdapterFactory factory = newFactory();
        Field f = fieldOf(SimplePojo.class, "age");

        // Calling the method must not throw for a normal field, in either direction.
        boolean serialize = factory.excludeField(f, true);
        boolean deserialize = factory.excludeField(f, false);
        // Both calls must return a definite (non-exceptional) boolean result.
        assertTrue(serialize == true || serialize == false);
        assertTrue(deserialize == true || deserialize == false);
    }

    @Test
    public void testExcludeFieldInstanceNullFieldThrows() {
        ReflectiveTypeAdapterFactory factory = newFactory();
        try {
            factory.excludeField(null, true);
            fail("Expected an exception for a null field");
        } catch (RuntimeException expected) {
            // documented behavior does not cover a null field; any runtime failure is acceptable
        }
    }

    @Test
    public void testExcludeFieldStaticOverloadNullExcluderThrows() {
        Field f = fieldOf(SimplePojo.class, "name");
        try {
            ReflectiveTypeAdapterFactory.excludeField(f, true, null);
            fail("Expected an exception for a null excluder");
        } catch (RuntimeException expected) {
            // documented behavior does not cover a null excluder; any runtime failure is acceptable
        }
    }

    @Test
    public void testExcludeFieldStaticOverloadNullFieldThrows() {
        try {
            ReflectiveTypeAdapterFactory.excludeField(null, true, Excluder.DEFAULT);
            fail("Expected an exception for a null field");
        } catch (RuntimeException expected) {
            // documented behavior does not cover a null field; any runtime failure is acceptable
        }
    }
}
