package org.apache.commons.csv;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.io.StringReader;

import org.junit.Test;

/**
 * Self-contained tests for {@link CSVFormat} based solely on its published javadoc.
 */
public class CSVFormatAgentTest {

    // -- predefined formats --------------------------------------------------

    @Test
    public void testPredefinedFormatsAreNotNull() {
        assertNotNull(CSVFormat.DEFAULT);
        assertNotNull(CSVFormat.EXCEL);
        assertNotNull(CSVFormat.MYSQL);
        assertNotNull(CSVFormat.RFC4180);
        assertNotNull(CSVFormat.TDF);
    }

    @Test
    public void testRfc4180FormatProperties() {
        assertEquals(',', CSVFormat.RFC4180.getDelimiter());
        assertEquals(Character.valueOf('"'), CSVFormat.RFC4180.getQuoteChar());
        assertEquals("\r\n", CSVFormat.RFC4180.getRecordSeparator());
        // DEFAULT adds ignoreEmptyLines(true) as an "Additional" setting on top of
        // RFC4180, implying RFC4180 itself leaves it at the baseline (false).
        assertFalse(CSVFormat.RFC4180.getIgnoreEmptyLines());
    }

    @Test
    public void testDefaultFormatProperties() {
        assertEquals(',', CSVFormat.DEFAULT.getDelimiter());
        assertEquals(Character.valueOf('"'), CSVFormat.DEFAULT.getQuoteChar());
        assertEquals("\r\n", CSVFormat.DEFAULT.getRecordSeparator());
        assertTrue(CSVFormat.DEFAULT.getIgnoreEmptyLines());
    }

    @Test
    public void testDefaultDiffersFromRfc4180() {
        // DEFAULT = RFC4180 + withIgnoreEmptyLines(true), so they must not be equal.
        assertFalse(CSVFormat.DEFAULT.equals(CSVFormat.RFC4180));
    }

    @Test
    public void testExcelIsSameAsRfc4180() {
        // Javadoc explicitly notes: "this is currently the same as RFC4180".
        assertTrue(CSVFormat.EXCEL.equals(CSVFormat.RFC4180));
        assertEquals(CSVFormat.EXCEL.hashCode(), CSVFormat.RFC4180.hashCode());
    }

    @Test
    public void testMysqlFormatProperties() {
        assertEquals('\t', CSVFormat.MYSQL.getDelimiter());
        assertEquals("\n", CSVFormat.MYSQL.getRecordSeparator());
        // "Values are not quoted"
        assertNull(CSVFormat.MYSQL.getQuoteChar());
        assertFalse(CSVFormat.MYSQL.isQuoting());
        // "special characters are escaped with '\'"
        assertEquals(Character.valueOf('\\'), CSVFormat.MYSQL.getEscape());
        assertTrue(CSVFormat.MYSQL.isEscaping());
    }

    @Test
    public void testTdfFormatProperties() {
        // "Tab-delimited format, with quote; leading and trailing spaces ignored."
        assertTrue(CSVFormat.TDF.isQuoting());
        assertTrue(CSVFormat.TDF.getIgnoreSurroundingSpaces());
    }

    // -- equals / hashCode -----------------------------------------------------

    @Test
    public void testEqualsIsReflexive() {
        assertTrue(CSVFormat.DEFAULT.equals(CSVFormat.DEFAULT));
        assertEquals(CSVFormat.DEFAULT.hashCode(), CSVFormat.DEFAULT.hashCode());
    }

    @Test
    public void testEqualsAgainstNullAndOtherType() {
        assertFalse(CSVFormat.DEFAULT.equals(null));
        assertFalse(CSVFormat.DEFAULT.equals("not a CSVFormat"));
    }

    // -- newFormat ---------------------------------------------------------

    @Test
    public void testNewFormatWithValidDelimiter() {
        CSVFormat format = CSVFormat.newFormat(';');
        assertNotNull(format);
        assertEquals(';', format.getDelimiter());
    }

    @Test
    public void testNewFormatRejectsLineFeedDelimiter() {
        try {
            CSVFormat.newFormat('\n');
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented behavior
        }
    }

    @Test
    public void testNewFormatRejectsCarriageReturnDelimiter() {
        try {
            CSVFormat.newFormat('\r');
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented behavior
        }
    }

    // -- withDelimiter -------------------------------------------------------

    @Test
    public void testWithDelimiterSetsValueAndPreservesImmutability() {
        CSVFormat changed = CSVFormat.DEFAULT.withDelimiter(';');
        assertEquals(';', changed.getDelimiter());
        // original is unchanged, demonstrating immutability.
        assertEquals(',', CSVFormat.DEFAULT.getDelimiter());
    }

    @Test
    public void testWithDelimiterRejectsLineBreakCharacters() {
        try {
            CSVFormat.DEFAULT.withDelimiter('\n');
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented behavior
        }
        try {
            CSVFormat.DEFAULT.withDelimiter('\r');
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented behavior
        }
    }

    // -- withQuoteChar -------------------------------------------------------

    @Test
    public void testWithQuoteCharPrimitiveSetsValue() {
        CSVFormat changed = CSVFormat.MYSQL.withQuoteChar('\'');
        assertEquals(Character.valueOf('\''), changed.getQuoteChar());
        assertTrue(changed.isQuoting());
        // original remains unquoted.
        assertNull(CSVFormat.MYSQL.getQuoteChar());
    }

    @Test
    public void testWithQuoteCharPrimitiveRejectsLineBreakCharacters() {
        try {
            CSVFormat.DEFAULT.withQuoteChar('\n');
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented behavior
        }
        try {
            CSVFormat.DEFAULT.withQuoteChar('\r');
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented behavior
        }
    }

    @Test
    public void testWithQuoteCharBoxedNullDisablesQuoting() {
        CSVFormat changed = CSVFormat.DEFAULT.withQuoteChar(null);
        assertNull(changed.getQuoteChar());
        assertFalse(changed.isQuoting());
    }

    // -- withEscape ----------------------------------------------------------

    @Test
    public void testWithEscapePrimitiveSetsValue() {
        CSVFormat changed = CSVFormat.DEFAULT.withEscape('\\');
        assertEquals(Character.valueOf('\\'), changed.getEscape());
        assertTrue(changed.isEscaping());
        // original remains unaffected.
        assertNull(CSVFormat.DEFAULT.getEscape());
        assertFalse(CSVFormat.DEFAULT.isEscaping());
    }

    @Test
    public void testWithEscapePrimitiveRejectsLineBreakCharacters() {
        try {
            CSVFormat.DEFAULT.withEscape('\n');
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented behavior
        }
        try {
            CSVFormat.DEFAULT.withEscape('\r');
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented behavior
        }
    }

    @Test
    public void testWithEscapeBoxedNullDisablesEscaping() {
        CSVFormat changed = CSVFormat.MYSQL.withEscape(null);
        assertNull(changed.getEscape());
        assertFalse(changed.isEscaping());
    }

    // -- withCommentStart ------------------------------------------------------

    @Test
    public void testWithCommentStartPrimitiveSetsValue() {
        CSVFormat changed = CSVFormat.DEFAULT.withCommentStart('#');
        assertEquals(Character.valueOf('#'), changed.getCommentStart());
        assertTrue(changed.isCommentingEnabled());
        // original remains unaffected.
        assertNull(CSVFormat.DEFAULT.getCommentStart());
        assertFalse(CSVFormat.DEFAULT.isCommentingEnabled());
    }

    @Test
    public void testWithCommentStartPrimitiveRejectsLineBreakCharacters() {
        try {
            CSVFormat.DEFAULT.withCommentStart('\n');
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented behavior
        }
        try {
            CSVFormat.DEFAULT.withCommentStart('\r');
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented behavior
        }
    }

    @Test
    public void testWithCommentStartBoxedNullDisablesCommenting() {
        CSVFormat changed = CSVFormat.DEFAULT.withCommentStart('#').withCommentStart(null);
        assertNull(changed.getCommentStart());
        assertFalse(changed.isCommentingEnabled());
    }

    // -- withHeader / getHeader ------------------------------------------------

    @Test
    public void testWithHeaderSetsValues() {
        CSVFormat changed = CSVFormat.DEFAULT.withHeader("Col1", "Col2", "Col3");
        assertArrayEquals(new String[] { "Col1", "Col2", "Col3" }, changed.getHeader());
        // original has no header.
        assertNull(CSVFormat.DEFAULT.getHeader());
    }

    @Test
    public void testWithHeaderNoArgsMeansParseAutomatically() {
        CSVFormat changed = CSVFormat.DEFAULT.withHeader();
        String[] header = changed.getHeader();
        assertNotNull(header);
        assertEquals(0, header.length);
    }

    @Test
    public void testWithHeaderNullDisablesHeader() {
        CSVFormat changed = CSVFormat.DEFAULT.withHeader("Col1").withHeader((String[]) null);
        assertNull(changed.getHeader());
    }

    @Test
    public void testGetHeaderReturnsDefensiveCopy() {
        CSVFormat format = CSVFormat.DEFAULT.withHeader("a", "b");
        String[] firstCall = format.getHeader();
        firstCall[0] = "mutated";
        String[] secondCall = format.getHeader();
        assertEquals("a", secondCall[0]);
    }

    // -- withIgnoreEmptyLines -----------------------------------------------

    @Test
    public void testWithIgnoreEmptyLines() {
        CSVFormat trueFormat = CSVFormat.RFC4180.withIgnoreEmptyLines(true);
        assertTrue(trueFormat.getIgnoreEmptyLines());
        CSVFormat falseFormat = CSVFormat.DEFAULT.withIgnoreEmptyLines(false);
        assertFalse(falseFormat.getIgnoreEmptyLines());
        // originals untouched.
        assertFalse(CSVFormat.RFC4180.getIgnoreEmptyLines());
        assertTrue(CSVFormat.DEFAULT.getIgnoreEmptyLines());
    }

    // -- withIgnoreSurroundingSpaces -----------------------------------------

    @Test
    public void testWithIgnoreSurroundingSpaces() {
        CSVFormat trueFormat = CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(true);
        assertTrue(trueFormat.getIgnoreSurroundingSpaces());
        CSVFormat falseFormat = CSVFormat.TDF.withIgnoreSurroundingSpaces(false);
        assertFalse(falseFormat.getIgnoreSurroundingSpaces());
        // original TDF keeps ignoring surrounding spaces.
        assertTrue(CSVFormat.TDF.getIgnoreSurroundingSpaces());
    }

    // -- withNullString / getNullString / isNullHandling ----------------------

    @Test
    public void testWithNullStringSetsValue() {
        CSVFormat changed = CSVFormat.DEFAULT.withNullString("N/A");
        assertEquals("N/A", changed.getNullString());
        assertTrue(changed.isNullHandling());
        // original has no null-string handling.
        assertNull(CSVFormat.DEFAULT.getNullString());
        assertFalse(CSVFormat.DEFAULT.isNullHandling());
    }

    @Test
    public void testWithNullStringNullMeansNoSubstitution() {
        CSVFormat changed = CSVFormat.DEFAULT.withNullString("N/A").withNullString(null);
        assertNull(changed.getNullString());
        assertFalse(changed.isNullHandling());
    }

    // -- withQuotePolicy / getQuotePolicy --------------------------------------

    @Test
    public void testWithQuotePolicyRoundTrip() {
        // The javadoc does not enumerate org.apache.commons.csv.Quote's constants,
        // so round-trip the value already exposed by a predefined format instead
        // of guessing a literal constant name.
        Object currentPolicy = CSVFormat.DEFAULT.getQuotePolicy();
        CSVFormat changed = CSVFormat.EXCEL.withQuotePolicy(CSVFormat.DEFAULT.getQuotePolicy());
        assertEquals(currentPolicy, changed.getQuotePolicy());
    }

    // -- withRecordSeparator ---------------------------------------------------

    @Test
    public void testWithRecordSeparatorChar() {
        CSVFormat changed = CSVFormat.DEFAULT.withRecordSeparator(';');
        assertEquals(";", changed.getRecordSeparator());
    }

    @Test
    public void testWithRecordSeparatorString() {
        CSVFormat changed = CSVFormat.MYSQL.withRecordSeparator("\r\n");
        assertEquals("\r\n", changed.getRecordSeparator());
        // original MYSQL keeps its LF record separator.
        assertEquals("\n", CSVFormat.MYSQL.getRecordSeparator());
    }

    // -- withSkipHeaderRecord / getSkipHeaderRecord -----------------------------

    @Test
    public void testWithSkipHeaderRecord() {
        assertFalse(CSVFormat.DEFAULT.getSkipHeaderRecord());
        CSVFormat changed = CSVFormat.DEFAULT.withSkipHeaderRecord(true);
        assertTrue(changed.getSkipHeaderRecord());
        // original untouched.
        assertFalse(CSVFormat.DEFAULT.getSkipHeaderRecord());
    }

    // -- format ----------------------------------------------------------------

    @Test
    public void testFormatReturnsNonNullAndContainsValues() {
        String formatted = CSVFormat.DEFAULT.format("alpha", "beta", "gamma");
        assertNotNull(formatted);
        assertTrue(formatted.contains("alpha"));
        assertTrue(formatted.contains("beta"));
        assertTrue(formatted.contains("gamma"));
    }

    @Test
    public void testFormatWithNoValuesReturnsNonNull() {
        assertNotNull(CSVFormat.DEFAULT.format());
    }

    // -- parse -------------------------------------------------------------

    @Test
    public void testParseReturnsNonNullParser() throws IOException {
        CSVParser parser = CSVFormat.DEFAULT.parse(new StringReader("a,b,c"));
        assertNotNull(parser);
    }

    // -- validate (package-private) ---------------------------------------

    @Test
    public void testValidateDoesNotThrowForPredefinedFormats() {
        CSVFormat.DEFAULT.validate();
        CSVFormat.EXCEL.validate();
        CSVFormat.MYSQL.validate();
        CSVFormat.RFC4180.validate();
        CSVFormat.TDF.validate();
    }

    // -- toString ------------------------------------------------------------

    @Test
    public void testToStringIsNonNullAndStable() {
        String first = CSVFormat.DEFAULT.toString();
        String second = CSVFormat.DEFAULT.toString();
        assertNotNull(first);
        assertEquals(first, second);
    }
}
