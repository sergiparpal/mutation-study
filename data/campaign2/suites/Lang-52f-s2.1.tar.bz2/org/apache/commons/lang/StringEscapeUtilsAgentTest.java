package org.apache.commons.lang;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import org.junit.Test;

public class StringEscapeUtilsAgentTest {

    // ---------------------------------------------------------------
    // constructor
    // ---------------------------------------------------------------

    @Test
    public void testConstructorIsPublic() {
        StringEscapeUtils instance = new StringEscapeUtils();
        assertTrue(instance instanceof StringEscapeUtils);
    }

    // ---------------------------------------------------------------
    // escapeJava(String)
    // ---------------------------------------------------------------

    @Test
    public void testEscapeJavaNull() {
        assertNull(StringEscapeUtils.escapeJava(null));
    }

    @Test
    public void testEscapeJavaEmpty() {
        assertEquals("", StringEscapeUtils.escapeJava(""));
    }

    @Test
    public void testEscapeJavaTab() {
        assertEquals("\\t", StringEscapeUtils.escapeJava("\t"));
    }

    @Test
    public void testEscapeJavaDocExample() {
        String input = "He didn't say, \"Stop!\"";
        String expected = "He didn't say, \\\"Stop!\\\"";
        assertEquals(expected, StringEscapeUtils.escapeJava(input));
    }

    @Test
    public void testEscapeJavaLeavesApostropheAlone() {
        assertEquals("it's", StringEscapeUtils.escapeJava("it's"));
    }

    @Test
    public void testEscapeJavaBackslash() {
        assertEquals("\\\\", StringEscapeUtils.escapeJava("\\"));
    }

    @Test
    public void testEscapeJavaNoSpecialChars() {
        assertEquals("hello world", StringEscapeUtils.escapeJava("hello world"));
    }

    // ---------------------------------------------------------------
    // escapeJava(Writer, String)
    // ---------------------------------------------------------------

    @Test
    public void testEscapeJavaWriterNullWriterThrows() {
        try {
            StringEscapeUtils.escapeJava(null, "abc");
            fail("Expected IllegalArgumentException for null Writer");
        } catch (IllegalArgumentException expected) {
            // documented behavior
        } catch (IOException e) {
            fail("Unexpected IOException: " + e);
        }
    }

    @Test
    public void testEscapeJavaWriterNullStringHasNoEffect() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.escapeJava(writer, null);
        assertEquals("", writer.toString());
    }

    @Test
    public void testEscapeJavaWriterMatchesStringVersion() throws IOException {
        String input = "He didn't say, \"Stop!\"\t\\";
        StringWriter writer = new StringWriter();
        StringEscapeUtils.escapeJava(writer, input);
        assertEquals(StringEscapeUtils.escapeJava(input), writer.toString());
    }

    // ---------------------------------------------------------------
    // escapeJavaScript(String)
    // ---------------------------------------------------------------

    @Test
    public void testEscapeJavaScriptNull() {
        assertNull(StringEscapeUtils.escapeJavaScript(null));
    }

    @Test
    public void testEscapeJavaScriptEmpty() {
        assertEquals("", StringEscapeUtils.escapeJavaScript(""));
    }

    @Test
    public void testEscapeJavaScriptDocExample() {
        String input = "He didn't say, \"Stop!\"";
        String expected = "He didn\\'t say, \\\"Stop!\\\"";
        assertEquals(expected, StringEscapeUtils.escapeJavaScript(input));
    }

    @Test
    public void testEscapeJavaScriptEscapesSingleQuoteUnlikeJava() {
        String input = "it's";
        assertEquals("it\\'s", StringEscapeUtils.escapeJavaScript(input));
        // confirm the difference from escapeJava, which leaves the quote alone
        assertFalse(StringEscapeUtils.escapeJavaScript(input).equals(StringEscapeUtils.escapeJava(input)));
    }

    // ---------------------------------------------------------------
    // escapeJavaScript(Writer, String)
    // ---------------------------------------------------------------

    @Test
    public void testEscapeJavaScriptWriterNullWriterThrows() {
        try {
            StringEscapeUtils.escapeJavaScript(null, "abc");
            fail("Expected IllegalArgumentException for null Writer");
        } catch (IllegalArgumentException expected) {
            // documented behavior
        } catch (IOException e) {
            fail("Unexpected IOException: " + e);
        }
    }

    @Test
    public void testEscapeJavaScriptWriterNullStringHasNoEffect() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.escapeJavaScript(writer, null);
        assertEquals("", writer.toString());
    }

    @Test
    public void testEscapeJavaScriptWriterMatchesStringVersion() throws IOException {
        String input = "it's a \"test\"";
        StringWriter writer = new StringWriter();
        StringEscapeUtils.escapeJavaScript(writer, input);
        assertEquals(StringEscapeUtils.escapeJavaScript(input), writer.toString());
    }

    // ---------------------------------------------------------------
    // unescapeJava(String)
    // ---------------------------------------------------------------

    @Test
    public void testUnescapeJavaNull() {
        assertNull(StringEscapeUtils.unescapeJava(null));
    }

    @Test
    public void testUnescapeJavaEmpty() {
        assertEquals("", StringEscapeUtils.unescapeJava(""));
    }

    @Test
    public void testUnescapeJavaNewline() {
        assertEquals("a\nb", StringEscapeUtils.unescapeJava("a\\nb"));
    }

    @Test
    public void testUnescapeJavaRoundTripsEscapeJava() {
        String original = "He didn't say, \"Stop!\"\t\\";
        String escaped = StringEscapeUtils.escapeJava(original);
        assertEquals(original, StringEscapeUtils.unescapeJava(escaped));
    }

    // ---------------------------------------------------------------
    // unescapeJava(Writer, String)
    // ---------------------------------------------------------------

    @Test
    public void testUnescapeJavaWriterNullWriterThrows() {
        try {
            StringEscapeUtils.unescapeJava(null, "abc");
            fail("Expected IllegalArgumentException for null Writer");
        } catch (IllegalArgumentException expected) {
            // documented behavior
        } catch (IOException e) {
            fail("Unexpected IOException: " + e);
        }
    }

    @Test
    public void testUnescapeJavaWriterNullStringHasNoEffect() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.unescapeJava(writer, null);
        assertEquals("", writer.toString());
    }

    @Test
    public void testUnescapeJavaWriterMatchesStringVersion() throws IOException {
        String input = "a\\nb\\tc";
        StringWriter writer = new StringWriter();
        StringEscapeUtils.unescapeJava(writer, input);
        assertEquals(StringEscapeUtils.unescapeJava(input), writer.toString());
    }

    // ---------------------------------------------------------------
    // unescapeJavaScript(String)
    // ---------------------------------------------------------------

    @Test
    public void testUnescapeJavaScriptNull() {
        assertNull(StringEscapeUtils.unescapeJavaScript(null));
    }

    @Test
    public void testUnescapeJavaScriptEmpty() {
        assertEquals("", StringEscapeUtils.unescapeJavaScript(""));
    }

    @Test
    public void testUnescapeJavaScriptRoundTripsEscapeJavaScript() {
        String original = "He didn't say, \"Stop!\"";
        String escaped = StringEscapeUtils.escapeJavaScript(original);
        assertEquals(original, StringEscapeUtils.unescapeJavaScript(escaped));
    }

    // ---------------------------------------------------------------
    // unescapeJavaScript(Writer, String)
    // ---------------------------------------------------------------

    @Test
    public void testUnescapeJavaScriptWriterNullWriterThrows() {
        try {
            StringEscapeUtils.unescapeJavaScript(null, "abc");
            fail("Expected IllegalArgumentException for null Writer");
        } catch (IllegalArgumentException expected) {
            // documented behavior
        } catch (IOException e) {
            fail("Unexpected IOException: " + e);
        }
    }

    @Test
    public void testUnescapeJavaScriptWriterNullStringHasNoEffect() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.unescapeJavaScript(writer, null);
        assertEquals("", writer.toString());
    }

    @Test
    public void testUnescapeJavaScriptWriterMatchesStringVersion() throws IOException {
        String input = "it\\'s a \\\"test\\\"";
        StringWriter writer = new StringWriter();
        StringEscapeUtils.unescapeJavaScript(writer, input);
        assertEquals(StringEscapeUtils.unescapeJavaScript(input), writer.toString());
    }

    // ---------------------------------------------------------------
    // escapeHtml(String)
    // ---------------------------------------------------------------

    @Test
    public void testEscapeHtmlNull() {
        assertNull(StringEscapeUtils.escapeHtml(null));
    }

    @Test
    public void testEscapeHtmlEmpty() {
        assertEquals("", StringEscapeUtils.escapeHtml(""));
    }

    @Test
    public void testEscapeHtmlDocExample() {
        String input = "\"bread\" & \"butter\"";
        String expected = "&quot;bread&quot; &amp; &quot;butter&quot;";
        assertEquals(expected, StringEscapeUtils.escapeHtml(input));
    }

    @Test
    public void testEscapeHtmlDoesNotEscapeApostrophe() {
        // apostrophe is explicitly documented as unsupported/not escaped
        assertEquals("it's", StringEscapeUtils.escapeHtml("it's"));
    }

    @Test
    public void testEscapeHtmlAngleBrackets() {
        assertEquals("&lt;b&gt;", StringEscapeUtils.escapeHtml("<b>"));
    }

    // ---------------------------------------------------------------
    // escapeHtml(Writer, String)
    // ---------------------------------------------------------------

    @Test
    public void testEscapeHtmlWriterNullWriterThrows() {
        try {
            StringEscapeUtils.escapeHtml(null, "abc");
            fail("Expected IllegalArgumentException for null Writer");
        } catch (IllegalArgumentException expected) {
            // documented behavior
        } catch (IOException e) {
            fail("Unexpected IOException: " + e);
        }
    }

    @Test
    public void testEscapeHtmlWriterMatchesStringVersion() throws IOException {
        String input = "\"bread\" & \"butter\"";
        StringWriter writer = new StringWriter();
        StringEscapeUtils.escapeHtml(writer, input);
        assertEquals(StringEscapeUtils.escapeHtml(input), writer.toString());
    }

    // ---------------------------------------------------------------
    // unescapeHtml(String)
    // ---------------------------------------------------------------

    @Test
    public void testUnescapeHtmlNull() {
        assertNull(StringEscapeUtils.unescapeHtml(null));
    }

    @Test
    public void testUnescapeHtmlEmpty() {
        assertEquals("", StringEscapeUtils.unescapeHtml(""));
    }

    @Test
    public void testUnescapeHtmlDocExample() {
        assertEquals("<Français>", StringEscapeUtils.unescapeHtml("&lt;Fran&ccedil;ais&gt;"));
    }

    @Test
    public void testUnescapeHtmlUnrecognizedEntityLeftAlone() {
        assertEquals(">&zzzz;x", StringEscapeUtils.unescapeHtml("&gt;&zzzz;x"));
    }

    @Test
    public void testUnescapeHtmlRoundTripsEscapeHtml() {
        String original = "\"bread\" & \"butter\" <tag>";
        String escaped = StringEscapeUtils.escapeHtml(original);
        assertEquals(original, StringEscapeUtils.unescapeHtml(escaped));
    }

    // ---------------------------------------------------------------
    // unescapeHtml(Writer, String)
    // ---------------------------------------------------------------

    @Test
    public void testUnescapeHtmlWriterNullWriterThrows() {
        try {
            StringEscapeUtils.unescapeHtml(null, "abc");
            fail("Expected IllegalArgumentException for null Writer");
        } catch (IllegalArgumentException expected) {
            // documented behavior
        } catch (IOException e) {
            fail("Unexpected IOException: " + e);
        }
    }

    @Test
    public void testUnescapeHtmlWriterMatchesStringVersion() throws IOException {
        String input = "&lt;Fran&ccedil;ais&gt;";
        StringWriter writer = new StringWriter();
        StringEscapeUtils.unescapeHtml(writer, input);
        assertEquals(StringEscapeUtils.unescapeHtml(input), writer.toString());
    }

    // ---------------------------------------------------------------
    // escapeXml(String)
    // ---------------------------------------------------------------

    @Test
    public void testEscapeXmlNull() {
        assertNull(StringEscapeUtils.escapeXml(null));
    }

    @Test
    public void testEscapeXmlEmpty() {
        assertEquals("", StringEscapeUtils.escapeXml(""));
    }

    @Test
    public void testEscapeXmlDocExample() {
        String input = "\"bread\" & \"butter\"";
        String expected = "&quot;bread&quot; &amp; &quot;butter&quot;";
        assertEquals(expected, StringEscapeUtils.escapeXml(input));
    }

    @Test
    public void testEscapeXmlFiveBasicEntities() {
        assertEquals("&lt;", StringEscapeUtils.escapeXml("<"));
        assertEquals("&gt;", StringEscapeUtils.escapeXml(">"));
        assertEquals("&amp;", StringEscapeUtils.escapeXml("&"));
        assertEquals("&apos;", StringEscapeUtils.escapeXml("'"));
        assertEquals("&quot;", StringEscapeUtils.escapeXml("\""));
    }

    @Test
    public void testEscapeXmlHighUnicodeCharacterIsEscaped() {
        // chars above 0x7f are documented as being escaped to a numerical
        // equivalent, so the literal character must not survive verbatim.
        String input = "café";
        String result = StringEscapeUtils.escapeXml(input);
        assertFalse(result.indexOf('é') >= 0);
        assertFalse(result.equals(input));
    }

    // ---------------------------------------------------------------
    // escapeXml(Writer, String)
    // ---------------------------------------------------------------

    @Test
    public void testEscapeXmlWriterNullWriterThrows() {
        try {
            StringEscapeUtils.escapeXml(null, "abc");
            fail("Expected IllegalArgumentException for null Writer");
        } catch (IllegalArgumentException expected) {
            // documented behavior
        } catch (IOException e) {
            fail("Unexpected IOException: " + e);
        }
    }

    @Test
    public void testEscapeXmlWriterMatchesStringVersion() throws IOException {
        String input = "\"bread\" & \"butter\"";
        StringWriter writer = new StringWriter();
        StringEscapeUtils.escapeXml(writer, input);
        assertEquals(StringEscapeUtils.escapeXml(input), writer.toString());
    }

    // ---------------------------------------------------------------
    // unescapeXml(String)
    // ---------------------------------------------------------------

    @Test
    public void testUnescapeXmlNull() {
        assertNull(StringEscapeUtils.unescapeXml(null));
    }

    @Test
    public void testUnescapeXmlEmpty() {
        assertEquals("", StringEscapeUtils.unescapeXml(""));
    }

    @Test
    public void testUnescapeXmlFiveBasicEntities() {
        assertEquals("<", StringEscapeUtils.unescapeXml("&lt;"));
        assertEquals(">", StringEscapeUtils.unescapeXml("&gt;"));
        assertEquals("&", StringEscapeUtils.unescapeXml("&amp;"));
        assertEquals("'", StringEscapeUtils.unescapeXml("&apos;"));
        assertEquals("\"", StringEscapeUtils.unescapeXml("&quot;"));
    }

    @Test
    public void testUnescapeXmlRoundTripsEscapeXml() {
        String original = "\"bread\" & <butter> 'knife'";
        String escaped = StringEscapeUtils.escapeXml(original);
        assertEquals(original, StringEscapeUtils.unescapeXml(escaped));
    }

    // ---------------------------------------------------------------
    // unescapeXml(Writer, String)
    // ---------------------------------------------------------------

    @Test
    public void testUnescapeXmlWriterNullWriterThrows() {
        try {
            StringEscapeUtils.unescapeXml(null, "abc");
            fail("Expected IllegalArgumentException for null Writer");
        } catch (IllegalArgumentException expected) {
            // documented behavior
        } catch (IOException e) {
            fail("Unexpected IOException: " + e);
        }
    }

    @Test
    public void testUnescapeXmlWriterMatchesStringVersion() throws IOException {
        String input = "&lt;tag&gt; &amp; &apos;value&apos;";
        StringWriter writer = new StringWriter();
        StringEscapeUtils.unescapeXml(writer, input);
        assertEquals(StringEscapeUtils.unescapeXml(input), writer.toString());
    }

    // ---------------------------------------------------------------
    // escapeSql(String)
    // ---------------------------------------------------------------

    @Test
    public void testEscapeSqlNull() {
        assertNull(StringEscapeUtils.escapeSql(null));
    }

    @Test
    public void testEscapeSqlEmpty() {
        assertEquals("", StringEscapeUtils.escapeSql(""));
    }

    @Test
    public void testEscapeSqlDocExample() {
        assertEquals("McHale''s Navy", StringEscapeUtils.escapeSql("McHale's Navy"));
    }

    @Test
    public void testEscapeSqlNoQuotesUnchanged() {
        assertEquals("select * from movies", StringEscapeUtils.escapeSql("select * from movies"));
    }

    @Test
    public void testEscapeSqlMultipleQuotes() {
        assertEquals("''''", StringEscapeUtils.escapeSql("''"));
    }
}
