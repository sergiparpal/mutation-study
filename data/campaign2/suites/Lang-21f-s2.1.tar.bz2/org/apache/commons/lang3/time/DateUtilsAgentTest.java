package org.apache.commons.lang3.time;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.TimeZone;

import org.junit.Test;

public class DateUtilsAgentTest {

    private static final TimeZone GMT = TimeZone.getTimeZone("GMT");

    private static Calendar newCal(int year, int month, int day, int hour, int min, int sec, int ms) {
        Calendar cal = Calendar.getInstance(GMT);
        cal.clear();
        cal.set(year, month, day, hour, min, sec);
        cal.set(Calendar.MILLISECOND, ms);
        return cal;
    }

    private static Date newDate(int year, int month, int day, int hour, int min, int sec, int ms) {
        return newCal(year, month, day, hour, min, sec, ms).getTime();
    }

    // ---------------------------------------------------------------
    // constants
    // ---------------------------------------------------------------

    @Test
    public void testMillisConstants() {
        assertEquals(1000L, DateUtils.MILLIS_PER_SECOND);
        assertEquals(60L * 1000L, DateUtils.MILLIS_PER_MINUTE);
        assertEquals(60L * 60L * 1000L, DateUtils.MILLIS_PER_HOUR);
        assertEquals(24L * 60L * 60L * 1000L, DateUtils.MILLIS_PER_DAY);
    }

    // ---------------------------------------------------------------
    // isSameDay
    // ---------------------------------------------------------------

    // @Test  // pruned: failed on the fixed version
    public void testIsSameDayDateTrue() {
        Date d1 = newDate(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        Date d2 = newDate(2002, Calendar.MARCH, 28, 6, 1, 0, 0);
        assertTrue(DateUtils.isSameDay(d1, d2));
    }

    @Test
    public void testIsSameDayDateFalse() {
        Date d1 = newDate(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        Date d2 = newDate(2002, Calendar.MARCH, 12, 13, 45, 0, 0);
        assertFalse(DateUtils.isSameDay(d1, d2));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testIsSameDayDateNullFirst() {
        DateUtils.isSameDay(null, new Date());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testIsSameDayDateNullSecond() {
        DateUtils.isSameDay(new Date(), null);
    }

    @Test
    public void testIsSameDayCalendarTrue() {
        Calendar c1 = newCal(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        Calendar c2 = newCal(2002, Calendar.MARCH, 28, 6, 1, 0, 0);
        assertTrue(DateUtils.isSameDay(c1, c2));
    }

    @Test
    public void testIsSameDayCalendarFalse() {
        Calendar c1 = newCal(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        Calendar c2 = newCal(2002, Calendar.MARCH, 12, 13, 45, 0, 0);
        assertFalse(DateUtils.isSameDay(c1, c2));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testIsSameDayCalendarNull() {
        DateUtils.isSameDay((Calendar) null, Calendar.getInstance());
    }

    // ---------------------------------------------------------------
    // isSameInstant
    // ---------------------------------------------------------------

    @Test
    public void testIsSameInstantDateTrue() {
        Date d1 = newDate(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        Date d2 = new Date(d1.getTime());
        assertTrue(DateUtils.isSameInstant(d1, d2));
    }

    @Test
    public void testIsSameInstantDateFalseOnSameDayDifferentTime() {
        Date d1 = newDate(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        Date d2 = newDate(2002, Calendar.MARCH, 28, 6, 1, 0, 0);
        assertFalse(DateUtils.isSameInstant(d1, d2));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testIsSameInstantDateNull() {
        DateUtils.isSameInstant((Date) null, new Date());
    }

    @Test
    public void testIsSameInstantCalendarTrueDifferentFields() {
        Calendar c1 = newCal(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        Calendar c2 = Calendar.getInstance(TimeZone.getTimeZone("America/New_York"));
        c2.setTimeInMillis(c1.getTimeInMillis());
        assertTrue(DateUtils.isSameInstant(c1, c2));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testIsSameInstantCalendarNull() {
        DateUtils.isSameInstant((Calendar) null, Calendar.getInstance());
    }

    // ---------------------------------------------------------------
    // isSameLocalTime
    // ---------------------------------------------------------------

    @Test
    public void testIsSameLocalTimeTrue() {
        Calendar c1 = newCal(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar c2 = newCal(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        assertTrue(DateUtils.isSameLocalTime(c1, c2));
    }

    @Test
    public void testIsSameLocalTimeFalse() {
        Calendar c1 = newCal(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar c2 = newCal(2002, Calendar.MARCH, 28, 13, 45, 1, 232);
        assertFalse(DateUtils.isSameLocalTime(c1, c2));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testIsSameLocalTimeNull() {
        DateUtils.isSameLocalTime(null, Calendar.getInstance());
    }

    // ---------------------------------------------------------------
    // parseDate / parseDateStrictly
    // ---------------------------------------------------------------

    @Test
    public void testParseDateFirstPatternMatches() throws ParseException {
        Date parsed = DateUtils.parseDate("2008-01-28", new String[] { "yyyy-MM-dd" });
        Calendar cal = DateUtils.toCalendar(parsed);
        assertEquals(2008, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));
        assertEquals(28, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void testParseDateTriesSubsequentPattern() throws ParseException {
        Date parsed = DateUtils.parseDate("28/01/2008", new String[] { "yyyy-MM-dd", "dd/MM/yyyy" });
        Calendar cal = DateUtils.toCalendar(parsed);
        assertEquals(2008, cal.get(Calendar.YEAR));
        assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));
        assertEquals(28, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test(expected = ParseException.class)
    public void testParseDateMustMatchWholeString() throws ParseException {
        DateUtils.parseDate("2008-01-28trailing", new String[] { "yyyy-MM-dd" });
    }

    @Test(expected = ParseException.class)
    public void testParseDateNoPatternsSuitable() throws ParseException {
        DateUtils.parseDate("not-a-date", new String[] { "yyyy-MM-dd" });
    }

    @Test(expected = ParseException.class)
    public void testParseDateNoPatternsAtAll() throws ParseException {
        DateUtils.parseDate("2008-01-28", new String[0]);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testParseDateNullString() throws ParseException {
        DateUtils.parseDate(null, new String[] { "yyyy-MM-dd" });
    }

    @Test(expected = IllegalArgumentException.class)
    public void testParseDateNullPatterns() throws ParseException {
        DateUtils.parseDate("2008-01-28", (String[]) null);
    }

    @Test
    public void testParseDateIsLenient() throws ParseException {
        // lenient parsing rolls "February 30" over into March
        Date parsed = DateUtils.parseDate("February 30, 2009", new String[] { "MMMM dd, yyyy" });
        Calendar cal = DateUtils.toCalendar(parsed);
        assertEquals(Calendar.MARCH, cal.get(Calendar.MONTH));
        assertEquals(2, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test(expected = ParseException.class)
    public void testParseDateStrictlyRejectsRollover() throws ParseException {
        DateUtils.parseDateStrictly("February 30, 2009", new String[] { "MMMM dd, yyyy" });
    }

    @Test
    public void testParseDateStrictlyAcceptsValidDate() throws ParseException {
        Date parsed = DateUtils.parseDateStrictly("January 28, 2009", new String[] { "MMMM dd, yyyy" });
        Calendar cal = DateUtils.toCalendar(parsed);
        assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));
        assertEquals(28, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testParseDateStrictlyNullString() throws ParseException {
        DateUtils.parseDateStrictly(null, new String[] { "yyyy-MM-dd" });
    }

    // ---------------------------------------------------------------
    // add* methods
    // ---------------------------------------------------------------

    @Test
    public void testAddYears() {
        Date date = newDate(2002, Calendar.MARCH, 28, 0, 0, 0, 0);
        Date result = DateUtils.addYears(date, 5);
        Calendar cal = DateUtils.toCalendar(result);
        assertEquals(2007, cal.get(Calendar.YEAR));
        assertEquals(2002, DateUtils.toCalendar(date).get(Calendar.YEAR));
    }

    @Test
    public void testAddYearsNegative() {
        Date date = newDate(2002, Calendar.MARCH, 28, 0, 0, 0, 0);
        Date result = DateUtils.addYears(date, -2);
        assertEquals(2000, DateUtils.toCalendar(result).get(Calendar.YEAR));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddYearsNull() {
        DateUtils.addYears(null, 1);
    }

    @Test
    public void testAddMonths() {
        Date date = newDate(2002, Calendar.MARCH, 28, 0, 0, 0, 0);
        Date result = DateUtils.addMonths(date, 1);
        Calendar cal = DateUtils.toCalendar(result);
        assertEquals(Calendar.APRIL, cal.get(Calendar.MONTH));
        assertNotSame(date, result);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddMonthsNull() {
        DateUtils.addMonths(null, 1);
    }

    // @Test  // pruned: failed on the fixed version
    public void testAddWeeks() {
        Date date = newDate(2002, Calendar.MARCH, 28, 0, 0, 0, 0);
        Date result = DateUtils.addWeeks(date, 1);
        Calendar cal = DateUtils.toCalendar(result);
        assertEquals(Calendar.APRIL, cal.get(Calendar.MONTH));
        assertEquals(4, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddWeeksNull() {
        DateUtils.addWeeks(null, 1);
    }

    // @Test  // pruned: failed on the fixed version
    public void testAddDays() {
        Date date = newDate(2002, Calendar.MARCH, 28, 0, 0, 0, 0);
        Date result = DateUtils.addDays(date, 4);
        Calendar cal = DateUtils.toCalendar(result);
        assertEquals(Calendar.APRIL, cal.get(Calendar.MONTH));
        assertEquals(1, cal.get(Calendar.DAY_OF_MONTH));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddDaysNull() {
        DateUtils.addDays(null, 1);
    }

    // @Test  // pruned: failed on the fixed version
    public void testAddHours() {
        Date date = newDate(2002, Calendar.MARCH, 28, 23, 0, 0, 0);
        Date result = DateUtils.addHours(date, 2);
        Calendar cal = DateUtils.toCalendar(result);
        assertEquals(29, cal.get(Calendar.DAY_OF_MONTH));
        assertEquals(1, cal.get(Calendar.HOUR_OF_DAY));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddHoursNull() {
        DateUtils.addHours(null, 1);
    }

    // @Test  // pruned: failed on the fixed version
    public void testAddMinutes() {
        Date date = newDate(2002, Calendar.MARCH, 28, 23, 59, 0, 0);
        Date result = DateUtils.addMinutes(date, 1);
        Calendar cal = DateUtils.toCalendar(result);
        assertEquals(0, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, cal.get(Calendar.MINUTE));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddMinutesNull() {
        DateUtils.addMinutes(null, 1);
    }

    @Test
    public void testAddSeconds() {
        Date date = newDate(2002, Calendar.MARCH, 28, 23, 59, 59, 0);
        Date result = DateUtils.addSeconds(date, 1);
        Calendar cal = DateUtils.toCalendar(result);
        assertEquals(0, cal.get(Calendar.SECOND));
        assertEquals(0, cal.get(Calendar.MINUTE));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddSecondsNull() {
        DateUtils.addSeconds(null, 1);
    }

    @Test
    public void testAddMilliseconds() {
        Date date = newDate(2002, Calendar.MARCH, 28, 0, 0, 0, 500);
        Date result = DateUtils.addMilliseconds(date, 600);
        assertEquals(date.getTime() + 600, result.getTime());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddMillisecondsNull() {
        DateUtils.addMilliseconds(null, 1);
    }

    // ---------------------------------------------------------------
    // set* methods
    // ---------------------------------------------------------------

    @Test
    public void testSetYears() {
        Date date = newDate(2002, Calendar.MARCH, 28, 10, 0, 0, 0);
        Date result = DateUtils.setYears(date, 1999);
        assertEquals(1999, DateUtils.toCalendar(result).get(Calendar.YEAR));
        assertEquals(2002, DateUtils.toCalendar(date).get(Calendar.YEAR));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testSetYearsNull() {
        DateUtils.setYears(null, 1999);
    }

    @Test
    public void testSetMonths() {
        Date date = newDate(2002, Calendar.MARCH, 28, 10, 0, 0, 0);
        Date result = DateUtils.setMonths(date, Calendar.JANUARY);
        assertEquals(Calendar.JANUARY, DateUtils.toCalendar(result).get(Calendar.MONTH));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testSetMonthsNull() {
        DateUtils.setMonths(null, 0);
    }

    @Test
    public void testSetDays() {
        Date date = newDate(2002, Calendar.MARCH, 28, 10, 0, 0, 0);
        Date result = DateUtils.setDays(date, 5);
        assertEquals(5, DateUtils.toCalendar(result).get(Calendar.DAY_OF_MONTH));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testSetDaysNull() {
        DateUtils.setDays(null, 5);
    }

    @Test
    public void testSetHours() {
        Date date = newDate(2002, Calendar.MARCH, 28, 10, 0, 0, 0);
        Date result = DateUtils.setHours(date, 22);
        assertEquals(22, DateUtils.toCalendar(result).get(Calendar.HOUR_OF_DAY));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testSetHoursNull() {
        DateUtils.setHours(null, 22);
    }

    @Test
    public void testSetMinutes() {
        Date date = newDate(2002, Calendar.MARCH, 28, 10, 0, 0, 0);
        Date result = DateUtils.setMinutes(date, 42);
        assertEquals(42, DateUtils.toCalendar(result).get(Calendar.MINUTE));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testSetMinutesNull() {
        DateUtils.setMinutes(null, 42);
    }

    @Test
    public void testSetSeconds() {
        Date date = newDate(2002, Calendar.MARCH, 28, 10, 0, 0, 0);
        Date result = DateUtils.setSeconds(date, 17);
        assertEquals(17, DateUtils.toCalendar(result).get(Calendar.SECOND));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testSetSecondsNull() {
        DateUtils.setSeconds(null, 17);
    }

    @Test
    public void testSetMilliseconds() {
        Date date = newDate(2002, Calendar.MARCH, 28, 10, 0, 0, 0);
        Date result = DateUtils.setMilliseconds(date, 321);
        assertEquals(321, DateUtils.toCalendar(result).get(Calendar.MILLISECOND));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testSetMillisecondsNull() {
        DateUtils.setMilliseconds(null, 321);
    }

    // ---------------------------------------------------------------
    // toCalendar
    // ---------------------------------------------------------------

    @Test
    public void testToCalendar() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar cal = DateUtils.toCalendar(date);
        assertEquals(date, cal.getTime());
        assertEquals(date.getTime(), cal.getTimeInMillis());
    }

    @Test(expected = NullPointerException.class)
    public void testToCalendarNull() {
        DateUtils.toCalendar(null);
    }

    // ---------------------------------------------------------------
    // round
    // ---------------------------------------------------------------

    @Test
    public void testRoundDateToHour() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date rounded = DateUtils.round(date, Calendar.HOUR);
        Calendar expected = newCal(2002, Calendar.MARCH, 28, 14, 0, 0, 0);
        assertEquals(expected.getTime(), rounded);
    }

    // @Test  // pruned: failed on the fixed version
    public void testRoundDateToMonth() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date rounded = DateUtils.round(date, Calendar.MONTH);
        Calendar expected = newCal(2002, Calendar.APRIL, 1, 0, 0, 0, 0);
        assertEquals(expected.getTime(), rounded);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testRoundDateNull() {
        DateUtils.round((Date) null, Calendar.HOUR);
    }

    @Test
    public void testRoundCalendarReturnsDifferentObject() {
        Calendar cal = newCal(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar rounded = DateUtils.round(cal, Calendar.HOUR);
        assertNotSame(cal, rounded);
        assertEquals(14, rounded.get(Calendar.HOUR_OF_DAY));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testRoundCalendarNull() {
        DateUtils.round((Calendar) null, Calendar.HOUR);
    }

    @Test
    public void testRoundObjectWithDate() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Object rounded = DateUtils.round((Object) date, Calendar.HOUR);
        assertTrue(rounded instanceof Date);
    }

    @Test
    public void testRoundObjectWithCalendar() {
        Calendar cal = newCal(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date rounded = DateUtils.round((Object) cal, Calendar.HOUR);
        assertNotNull(rounded);
    }

    @Test(expected = ClassCastException.class)
    public void testRoundObjectWrongType() {
        DateUtils.round((Object) "not a date", Calendar.HOUR);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testRoundObjectNull() {
        DateUtils.round((Object) null, Calendar.HOUR);
    }

    @Test(expected = ArithmeticException.class)
    public void testRoundArithmeticExceptionOnHugeYear() {
        Calendar cal = Calendar.getInstance(GMT);
        cal.set(Calendar.YEAR, 300000000);
        DateUtils.round(cal, Calendar.YEAR);
    }

    // ---------------------------------------------------------------
    // truncate
    // ---------------------------------------------------------------

    @Test
    public void testTruncateDateToHour() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date truncated = DateUtils.truncate(date, Calendar.HOUR);
        Calendar expected = newCal(2002, Calendar.MARCH, 28, 13, 0, 0, 0);
        assertEquals(expected.getTime(), truncated);
    }

    // @Test  // pruned: failed on the fixed version
    public void testTruncateDateToMonth() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date truncated = DateUtils.truncate(date, Calendar.MONTH);
        Calendar expected = newCal(2002, Calendar.MARCH, 1, 0, 0, 0, 0);
        assertEquals(expected.getTime(), truncated);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testTruncateDateNull() {
        DateUtils.truncate((Date) null, Calendar.HOUR);
    }

    @Test
    public void testTruncateCalendarReturnsDifferentObject() {
        Calendar cal = newCal(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar truncated = DateUtils.truncate(cal, Calendar.HOUR);
        assertNotSame(cal, truncated);
        assertEquals(13, truncated.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, truncated.get(Calendar.MINUTE));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testTruncateCalendarNull() {
        DateUtils.truncate((Calendar) null, Calendar.HOUR);
    }

    @Test
    public void testTruncateObjectWithCalendar() {
        Calendar cal = newCal(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date truncated = DateUtils.truncate((Object) cal, Calendar.HOUR);
        assertEquals(newCal(2002, Calendar.MARCH, 28, 13, 0, 0, 0).getTime(), truncated);
    }

    @Test(expected = ClassCastException.class)
    public void testTruncateObjectWrongType() {
        DateUtils.truncate((Object) Integer.valueOf(1), Calendar.HOUR);
    }

    // ---------------------------------------------------------------
    // ceiling
    // ---------------------------------------------------------------

    @Test
    public void testCeilingDateToHour() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date ceil = DateUtils.ceiling(date, Calendar.HOUR);
        Calendar expected = newCal(2002, Calendar.MARCH, 28, 14, 0, 0, 0);
        assertEquals(expected.getTime(), ceil);
    }

    // @Test  // pruned: failed on the fixed version
    public void testCeilingDateToMonth() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date ceil = DateUtils.ceiling(date, Calendar.MONTH);
        Calendar expected = newCal(2002, Calendar.APRIL, 1, 0, 0, 0, 0);
        assertEquals(expected.getTime(), ceil);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCeilingDateNull() {
        DateUtils.ceiling((Date) null, Calendar.HOUR);
    }

    @Test
    public void testCeilingCalendarReturnsDifferentObject() {
        Calendar cal = newCal(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar ceil = DateUtils.ceiling(cal, Calendar.HOUR);
        assertNotSame(cal, ceil);
        assertEquals(14, ceil.get(Calendar.HOUR_OF_DAY));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCeilingCalendarNull() {
        DateUtils.ceiling((Calendar) null, Calendar.HOUR);
    }

    @Test
    public void testCeilingObjectWithDate() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date ceil = DateUtils.ceiling((Object) date, Calendar.HOUR);
        assertEquals(newCal(2002, Calendar.MARCH, 28, 14, 0, 0, 0).getTime(), ceil);
    }

    @Test(expected = ClassCastException.class)
    public void testCeilingObjectWrongType() {
        DateUtils.ceiling((Object) "nope", Calendar.HOUR);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCeilingObjectNull() {
        DateUtils.ceiling((Object) null, Calendar.HOUR);
    }

    // ---------------------------------------------------------------
    // iterator
    // ---------------------------------------------------------------

    @Test
    public void testIteratorRangeMonthSunday() {
        // Thursday, July 4, 2002 -> starts Sunday June 30, ends Saturday Aug 3, 2002
        Date focus = newDate(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_MONTH_SUNDAY);
        Calendar first = it.next();
        assertEquals(Calendar.SUNDAY, first.get(Calendar.DAY_OF_WEEK));
        assertEquals(2002, first.get(Calendar.YEAR));
        assertEquals(Calendar.JUNE, first.get(Calendar.MONTH));
        assertEquals(30, first.get(Calendar.DAY_OF_MONTH));
        Calendar last = first;
        int count = 1;
        while (it.hasNext()) {
            last = it.next();
            count++;
        }
        assertEquals(Calendar.SATURDAY, last.get(Calendar.DAY_OF_WEEK));
        assertEquals(Calendar.AUGUST, last.get(Calendar.MONTH));
        assertEquals(3, last.get(Calendar.DAY_OF_MONTH));
        assertTrue(count >= 35 && count % 7 == 0);
    }

    @Test
    public void testIteratorRangeWeekSundayStartsOnSunday() {
        Date focus = newDate(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        Calendar first = it.next();
        assertEquals(Calendar.SUNDAY, first.get(Calendar.DAY_OF_WEEK));
        int count = 1;
        while (it.hasNext()) {
            it.next();
            count++;
        }
        assertEquals(7, count);
    }

    @Test
    public void testIteratorRangeWeekMondayStartsOnMonday() {
        Date focus = newDate(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_MONDAY);
        Calendar first = it.next();
        assertEquals(Calendar.MONDAY, first.get(Calendar.DAY_OF_WEEK));
        int count = 1;
        while (it.hasNext()) {
            it.next();
            count++;
        }
        assertEquals(7, count);
    }

    @Test
    public void testIteratorRangeWeekRelativeStartsOnFocus() {
        Date focus = newDate(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_RELATIVE);
        Calendar first = it.next();
        assertTrue(DateUtils.isSameDay(focus, first.getTime()));
        int count = 1;
        while (it.hasNext()) {
            it.next();
            count++;
        }
        assertEquals(7, count);
    }

    @Test
    public void testIteratorRangeWeekCenterContainsFocus() {
        Date focus = newDate(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_CENTER);
        boolean foundFocus = false;
        int count = 0;
        while (it.hasNext()) {
            Calendar c = it.next();
            if (DateUtils.isSameDay(focus, c.getTime())) {
                foundFocus = true;
            }
            count++;
        }
        assertEquals(7, count);
        assertTrue(foundFocus);
    }

    @Test
    public void testIteratorCalendarOverload() {
        Calendar focus = newCal(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        assertTrue(it.hasNext());
        // original focus calendar must not be mutated by the iterator setup
        assertEquals(Calendar.JULY, focus.get(Calendar.MONTH));
        assertEquals(4, focus.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void testIteratorObjectOverloadWithDate() {
        Date focus = newDate(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        Iterator<?> it = DateUtils.iterator((Object) focus, DateUtils.RANGE_WEEK_SUNDAY);
        assertTrue(it.hasNext());
    }

    @Test(expected = ClassCastException.class)
    public void testIteratorObjectOverloadWrongType() {
        DateUtils.iterator((Object) "not a date", DateUtils.RANGE_WEEK_SUNDAY);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testIteratorNullDate() {
        DateUtils.iterator((Date) null, DateUtils.RANGE_WEEK_SUNDAY);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testIteratorInvalidRangeStyle() {
        Date focus = newDate(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        DateUtils.iterator(focus, 99999);
    }

    // ---------------------------------------------------------------
    // getFragmentInMilliseconds
    // ---------------------------------------------------------------

    @Test
    public void testGetFragmentInMillisecondsDate() {
        Date date = newDate(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        assertEquals(538L, DateUtils.getFragmentInMilliseconds(date, Calendar.SECOND));
        assertEquals(10538L, DateUtils.getFragmentInMilliseconds(date, Calendar.MINUTE));
    }

    @Test
    public void testGetFragmentInMillisecondsZeroForMillisecondFragment() {
        Date date = newDate(2008, Calendar.JANUARY, 16, 7, 15, 10, 538);
        assertEquals(0L, DateUtils.getFragmentInMilliseconds(date, Calendar.MILLISECOND));
    }

    @Test
    public void testGetFragmentInMillisecondsCalendar() {
        Calendar cal = newCal(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(538L, DateUtils.getFragmentInMilliseconds(cal, Calendar.SECOND));
        assertEquals(10538L, DateUtils.getFragmentInMilliseconds(cal, Calendar.MINUTE));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testGetFragmentInMillisecondsNullDate() {
        DateUtils.getFragmentInMilliseconds((Date) null, Calendar.SECOND);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testGetFragmentInMillisecondsUnsupportedFragment() {
        Date date = newDate(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        DateUtils.getFragmentInMilliseconds(date, Calendar.ZONE_OFFSET);
    }

    // ---------------------------------------------------------------
    // getFragmentInSeconds
    // ---------------------------------------------------------------

    @Test
    public void testGetFragmentInSecondsDate() {
        Date date = newDate(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        assertEquals(10L, DateUtils.getFragmentInSeconds(date, Calendar.MINUTE));
    }

    // @Test  // pruned: failed on the fixed version
    public void testGetFragmentInSecondsDayOfYear() {
        Date date = newDate(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(26110L, DateUtils.getFragmentInSeconds(date, Calendar.DAY_OF_YEAR));
    }

    @Test
    public void testGetFragmentInSecondsZeroForMillisecondFragment() {
        Date date = newDate(2008, Calendar.JANUARY, 16, 7, 15, 10, 538);
        assertEquals(0L, DateUtils.getFragmentInSeconds(date, Calendar.MILLISECOND));
    }

    @Test
    public void testGetFragmentInSecondsCalendar() {
        Calendar cal = newCal(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(26110L, DateUtils.getFragmentInSeconds(cal, Calendar.DAY_OF_YEAR));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testGetFragmentInSecondsNullCalendar() {
        DateUtils.getFragmentInSeconds((Calendar) null, Calendar.MINUTE);
    }

    // ---------------------------------------------------------------
    // getFragmentInMinutes
    // ---------------------------------------------------------------

    @Test
    public void testGetFragmentInMinutesHourOfDay() {
        Date date = newDate(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        assertEquals(15L, DateUtils.getFragmentInMinutes(date, Calendar.HOUR_OF_DAY));
    }

    // @Test  // pruned: failed on the fixed version
    public void testGetFragmentInMinutesMonth() {
        Date date1 = newDate(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        assertEquals(15L, DateUtils.getFragmentInMinutes(date1, Calendar.MONTH));
        Date date6 = newDate(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(435L, DateUtils.getFragmentInMinutes(date6, Calendar.MONTH));
    }

    @Test
    public void testGetFragmentInMinutesZeroForMillisecondFragment() {
        Date date = newDate(2008, Calendar.JANUARY, 16, 7, 15, 10, 538);
        assertEquals(0L, DateUtils.getFragmentInMinutes(date, Calendar.MILLISECOND));
    }

    // @Test  // pruned: failed on the fixed version
    public void testGetFragmentInMinutesCalendar() {
        Calendar cal = newCal(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(435L, DateUtils.getFragmentInMinutes(cal, Calendar.MONTH));
    }

    // ---------------------------------------------------------------
    // getFragmentInHours
    // ---------------------------------------------------------------

    // @Test  // pruned: failed on the fixed version
    public void testGetFragmentInHoursDayOfYear() {
        Date date = newDate(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        assertEquals(7L, DateUtils.getFragmentInHours(date, Calendar.DAY_OF_YEAR));
    }

    // @Test  // pruned: failed on the fixed version
    public void testGetFragmentInHoursMonth() {
        Date date1 = newDate(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        assertEquals(7L, DateUtils.getFragmentInHours(date1, Calendar.MONTH));
        Date date6 = newDate(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(127L, DateUtils.getFragmentInHours(date6, Calendar.MONTH));
    }

    @Test
    public void testGetFragmentInHoursZeroForMillisecondFragment() {
        Date date = newDate(2008, Calendar.JANUARY, 16, 7, 15, 10, 538);
        assertEquals(0L, DateUtils.getFragmentInHours(date, Calendar.MILLISECOND));
    }

    // @Test  // pruned: failed on the fixed version
    public void testGetFragmentInHoursCalendar() {
        Calendar cal = newCal(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(127L, DateUtils.getFragmentInHours(cal, Calendar.MONTH));
    }

    // ---------------------------------------------------------------
    // getFragmentInDays
    // ---------------------------------------------------------------

    // @Test  // pruned: failed on the fixed version
    public void testGetFragmentInDaysMonth() {
        Date jan28 = newDate(2008, Calendar.JANUARY, 28, 0, 0, 0, 0);
        assertEquals(28L, DateUtils.getFragmentInDays(jan28, Calendar.MONTH));
        Date feb28 = newDate(2008, Calendar.FEBRUARY, 28, 0, 0, 0, 0);
        assertEquals(28L, DateUtils.getFragmentInDays(feb28, Calendar.MONTH));
    }

    // @Test  // pruned: failed on the fixed version
    public void testGetFragmentInDaysYear() {
        Date jan28 = newDate(2008, Calendar.JANUARY, 28, 0, 0, 0, 0);
        assertEquals(28L, DateUtils.getFragmentInDays(jan28, Calendar.YEAR));
        // 2008 is a leap year: 31 (Jan) + 28 = 59
        Date feb28 = newDate(2008, Calendar.FEBRUARY, 28, 0, 0, 0, 0);
        assertEquals(59L, DateUtils.getFragmentInDays(feb28, Calendar.YEAR));
    }

    @Test
    public void testGetFragmentInDaysZeroForMillisecondFragment() {
        Date jan28 = newDate(2008, Calendar.JANUARY, 28, 0, 0, 0, 0);
        assertEquals(0L, DateUtils.getFragmentInDays(jan28, Calendar.MILLISECOND));
    }

    @Test
    public void testGetFragmentInDaysCalendar() {
        Calendar feb28 = newCal(2008, Calendar.FEBRUARY, 28, 0, 0, 0, 0);
        assertEquals(59L, DateUtils.getFragmentInDays(feb28, Calendar.YEAR));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testGetFragmentInDaysNullCalendar() {
        DateUtils.getFragmentInDays((Calendar) null, Calendar.YEAR);
    }

    // ---------------------------------------------------------------
    // truncatedEquals / truncatedCompareTo
    // ---------------------------------------------------------------

    @Test
    public void testTruncatedEqualsCalendarTrue() {
        Calendar c1 = newCal(2020, Calendar.MARCH, 15, 10, 0, 0, 0);
        Calendar c2 = newCal(2020, Calendar.MARCH, 20, 23, 59, 59, 999);
        assertTrue(DateUtils.truncatedEquals(c1, c2, Calendar.MONTH));
    }

    @Test
    public void testTruncatedEqualsCalendarFalse() {
        Calendar c1 = newCal(2020, Calendar.MARCH, 15, 10, 0, 0, 0);
        Calendar c2 = newCal(2020, Calendar.APRIL, 1, 0, 0, 0, 0);
        assertFalse(DateUtils.truncatedEquals(c1, c2, Calendar.MONTH));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testTruncatedEqualsCalendarNull() {
        DateUtils.truncatedEquals((Calendar) null, Calendar.getInstance(), Calendar.MONTH);
    }

    @Test
    public void testTruncatedEqualsDateTrue() {
        Date d1 = newDate(2020, Calendar.MARCH, 15, 10, 0, 0, 0);
        Date d2 = newDate(2020, Calendar.MARCH, 20, 23, 59, 59, 999);
        assertTrue(DateUtils.truncatedEquals(d1, d2, Calendar.MONTH));
    }

    // @Test  // pruned: failed on the fixed version
    public void testTruncatedEqualsDateFalse() {
        Date d1 = newDate(2020, Calendar.MARCH, 15, 10, 0, 0, 0);
        Date d2 = newDate(2020, Calendar.APRIL, 1, 0, 0, 0, 0);
        assertFalse(DateUtils.truncatedEquals(d1, d2, Calendar.MONTH));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testTruncatedEqualsDateNull() {
        DateUtils.truncatedEquals((Date) null, new Date(), Calendar.MONTH);
    }

    @Test
    public void testTruncatedCompareToCalendarEqual() {
        Calendar c1 = newCal(2020, Calendar.MARCH, 15, 10, 0, 0, 0);
        Calendar c2 = newCal(2020, Calendar.MARCH, 20, 23, 59, 59, 999);
        assertEquals(0, DateUtils.truncatedCompareTo(c1, c2, Calendar.MONTH));
    }

    @Test
    public void testTruncatedCompareToCalendarLessThan() {
        Calendar c1 = newCal(2020, Calendar.MARCH, 15, 10, 0, 0, 0);
        Calendar c2 = newCal(2020, Calendar.APRIL, 1, 0, 0, 0, 0);
        assertTrue(DateUtils.truncatedCompareTo(c1, c2, Calendar.MONTH) < 0);
        assertTrue(DateUtils.truncatedCompareTo(c2, c1, Calendar.MONTH) > 0);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testTruncatedCompareToCalendarNull() {
        DateUtils.truncatedCompareTo((Calendar) null, Calendar.getInstance(), Calendar.MONTH);
    }

    @Test
    public void testTruncatedCompareToDateEqual() {
        Date d1 = newDate(2020, Calendar.MARCH, 15, 10, 0, 0, 0);
        Date d2 = newDate(2020, Calendar.MARCH, 20, 23, 59, 59, 999);
        assertEquals(0, DateUtils.truncatedCompareTo(d1, d2, Calendar.MONTH));
    }

    // @Test  // pruned: failed on the fixed version
    public void testTruncatedCompareToDateGreaterThan() {
        Date d1 = newDate(2020, Calendar.APRIL, 1, 0, 0, 0, 0);
        Date d2 = newDate(2020, Calendar.MARCH, 15, 10, 0, 0, 0);
        assertTrue(DateUtils.truncatedCompareTo(d1, d2, Calendar.MONTH) > 0);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testTruncatedCompareToDateNull() {
        DateUtils.truncatedCompareTo((Date) null, new Date(), Calendar.MONTH);
    }

    // ---------------------------------------------------------------
    // sanity check that the no-arg constructor is available (JavaBean use)
    // ---------------------------------------------------------------

    @Test
    public void testPublicConstructor() {
        assertNotNull(new DateUtils());
    }
}
