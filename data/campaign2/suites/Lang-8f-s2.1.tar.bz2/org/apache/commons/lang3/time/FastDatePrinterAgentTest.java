package org.apache.commons.lang3.time;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.FieldPosition;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

/**
 * Self-contained tests for FastDatePrinter, based solely on the documented
 * contract in the generated javadoc.
 */
public class FastDatePrinterAgentTest {

    private static final TimeZone UTC = TimeZone.getTimeZone("UTC");

    private static Calendar utcCalendar(int year, int month, int day, int hour, int minute, int second, int millis) {
        Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.clear();
        cal.set(year, month, day, hour, minute, second);
        cal.set(Calendar.MILLISECOND, millis);
        return cal;
    }

    // ---- constructor ----

    @Test
    public void testConstructorNullPatternThrowsNPE() {
        try {
            new FastDatePrinter(null, UTC, Locale.US);
            fail("Expected NullPointerException for null pattern");
        } catch (NullPointerException e) {
            // expected
        }
    }

    // @Test  // pruned: failed on the fixed version
    public void testConstructorNullTimeZoneThrowsNPE() {
        try {
            new FastDatePrinter("yyyy-MM-dd", null, Locale.US);
            fail("Expected NullPointerException for null timeZone");
        } catch (NullPointerException e) {
            // expected
        }
    }

    @Test
    public void testConstructorNullLocaleThrowsNPE() {
        try {
            new FastDatePrinter("yyyy-MM-dd", UTC, null);
            fail("Expected NullPointerException for null locale");
        } catch (NullPointerException e) {
            // expected
        }
    }

    // ---- accessors ----

    @Test
    public void testGetPatternReturnsConfiguredPattern() {
        FastDatePrinter p = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.US);
        assertEquals("yyyy-MM-dd", p.getPattern());
    }

    @Test
    public void testGetTimeZoneReturnsConfiguredTimeZone() {
        TimeZone tz = TimeZone.getTimeZone("GMT+02:00");
        FastDatePrinter p = new FastDatePrinter("yyyy-MM-dd", tz, Locale.US);
        assertEquals(tz, p.getTimeZone());
    }

    @Test
    public void testGetLocaleReturnsConfiguredLocale() {
        FastDatePrinter p = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.FRANCE);
        assertEquals(Locale.FRANCE, p.getLocale());
    }

    // ---- static style fields ----

    @Test
    public void testStaticStyleConstants() {
        assertEquals(0, FastDatePrinter.FULL);
        assertEquals(1, FastDatePrinter.LONG);
        assertEquals(2, FastDatePrinter.MEDIUM);
        assertEquals(3, FastDatePrinter.SHORT);
    }

    // ---- format(long) ----

    @Test
    public void testFormatMillisEpoch() {
        FastDatePrinter p = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.US);
        assertEquals("1970-01-01", p.format(0L));
    }

    @Test
    public void testFormatMillisBeforeEpoch() {
        FastDatePrinter p = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.US);
        assertEquals("1969-12-31", p.format(-86400000L));
    }

    @Test
    public void testFormatMillisKnownDateAndTime() {
        FastDatePrinter p = new FastDatePrinter("yyyy-MM-dd HH:mm:ss.SSS", UTC, Locale.US);
        Calendar cal = utcCalendar(2020, Calendar.JANUARY, 15, 13, 5, 9, 7);
        assertEquals("2020-01-15 13:05:09.007", p.format(cal.getTimeInMillis()));
    }

    // ---- format(Date) / format(Calendar) consistency ----

    @Test
    public void testFormatDateMatchesFormatMillis() {
        FastDatePrinter p = new FastDatePrinter("yyyy-MM-dd'T'HH:mm:ss", UTC, Locale.US);
        long millis = 123456789L;
        Date date = new Date(millis);
        assertEquals(p.format(millis), p.format(date));
    }

    @Test
    public void testFormatCalendarMatchesFormatMillisWhenZonesMatch() {
        FastDatePrinter p = new FastDatePrinter("yyyy-MM-dd'T'HH:mm:ss", UTC, Locale.US);
        long millis = 123456789L;
        Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.setTimeInMillis(millis);
        assertEquals(p.format(millis), p.format(cal));
    }

    // ---- format(..., StringBuffer) append and identity ----

    @Test
    public void testFormatMillisIntoBufferAppendsAndReturnsSameBuffer() {
        FastDatePrinter p = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.US);
        StringBuffer buf = new StringBuffer("PREFIX-");
        StringBuffer result = p.format(0L, buf);
        assertSame(buf, result);
        assertEquals("PREFIX-1970-01-01", buf.toString());
    }

    @Test
    public void testFormatDateIntoBufferAppendsAndReturnsSameBuffer() {
        FastDatePrinter p = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.US);
        StringBuffer buf = new StringBuffer("X");
        StringBuffer result = p.format(new Date(0L), buf);
        assertSame(buf, result);
        assertEquals("X1970-01-01", buf.toString());
    }

    @Test
    public void testFormatCalendarIntoBufferAppendsAndReturnsSameBuffer() {
        FastDatePrinter p = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.US);
        Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.setTimeInMillis(0L);
        StringBuffer buf = new StringBuffer("Y");
        StringBuffer result = p.format(cal, buf);
        assertSame(buf, result);
        assertEquals("Y1970-01-01", buf.toString());
    }

    // ---- format(Object, StringBuffer, FieldPosition) ----

    @Test
    public void testFormatObjectWithLong() {
        FastDatePrinter p = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.US);
        StringBuffer buf = new StringBuffer();
        StringBuffer result = p.format(Long.valueOf(0L), buf, new FieldPosition(0));
        assertSame(buf, result);
        assertEquals("1970-01-01", buf.toString());
    }

    @Test
    public void testFormatObjectWithDate() {
        FastDatePrinter p = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.US);
        StringBuffer buf = new StringBuffer();
        StringBuffer result = p.format(new Date(0L), buf, new FieldPosition(0));
        assertSame(buf, result);
        assertEquals("1970-01-01", buf.toString());
    }

    @Test
    public void testFormatObjectWithCalendar() {
        FastDatePrinter p = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.US);
        Calendar cal = Calendar.getInstance(UTC, Locale.US);
        cal.setTimeInMillis(0L);
        StringBuffer buf = new StringBuffer();
        StringBuffer result = p.format((Object) cal, buf, new FieldPosition(0));
        assertSame(buf, result);
        assertEquals("1970-01-01", buf.toString());
    }

    @Test
    public void testFormatObjectWithUnsupportedTypeThrows() {
        FastDatePrinter p = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.US);
        try {
            p.format("not a supported type", new StringBuffer(), new FieldPosition(0));
            fail("Expected an exception when formatting an unsupported object type");
        } catch (RuntimeException e) {
            // expected: the contract only documents Date, Calendar and Long as valid inputs
        }
    }

    // ---- getMaxLengthEstimate ----

    @Test
    public void testMaxLengthEstimateCoversActualOutputSimplePattern() {
        FastDatePrinter p = new FastDatePrinter("yyyy-MM-dd'T'HH:mm:ss.SSSZ", UTC, Locale.US);
        int estimate = p.getMaxLengthEstimate();
        assertTrue(estimate > 0);
        String formatted = p.format(123456789L);
        assertTrue(formatted.length() <= estimate);
    }

    @Test
    public void testMaxLengthEstimateCoversLongestMonthName() {
        FastDatePrinter p = new FastDatePrinter("EEEE, MMMM d, yyyy", UTC, Locale.US);
        int estimate = p.getMaxLengthEstimate();
        Calendar cal = utcCalendar(2020, Calendar.SEPTEMBER, 16, 0, 0, 0, 0);
        String formatted = p.format(cal);
        assertTrue(formatted.length() <= estimate);
    }

    // ---- equals / hashCode / toString ----

    @Test
    public void testEqualsIsReflexive() {
        FastDatePrinter p = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.US);
        assertTrue(p.equals(p));
    }

    @Test
    public void testEqualsSameConfigurationAreEqualWithSameHashCode() {
        FastDatePrinter p1 = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.US);
        FastDatePrinter p2 = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.US);
        assertTrue(p1.equals(p2));
        assertTrue(p2.equals(p1));
        assertEquals(p1.hashCode(), p2.hashCode());
    }

    @Test
    public void testEqualsDifferentPatternNotEqual() {
        FastDatePrinter p1 = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.US);
        FastDatePrinter p2 = new FastDatePrinter("yyyy/MM/dd", UTC, Locale.US);
        assertFalse(p1.equals(p2));
    }

    @Test
    public void testEqualsDifferentTimeZoneNotEqual() {
        FastDatePrinter p1 = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.US);
        FastDatePrinter p2 = new FastDatePrinter("yyyy-MM-dd", TimeZone.getTimeZone("GMT+01:00"), Locale.US);
        assertFalse(p1.equals(p2));
    }

    @Test
    public void testEqualsDifferentLocaleNotEqual() {
        FastDatePrinter p1 = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.US);
        FastDatePrinter p2 = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.FRANCE);
        assertFalse(p1.equals(p2));
    }

    @Test
    public void testEqualsAgainstNullIsFalse() {
        FastDatePrinter p1 = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.US);
        assertFalse(p1.equals(null));
    }

    @Test
    public void testEqualsAgainstDifferentTypeIsFalse() {
        FastDatePrinter p1 = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.US);
        assertFalse(p1.equals("yyyy-MM-dd"));
    }

    @Test
    public void testToStringIsNotNullOrEmpty() {
        FastDatePrinter p = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.US);
        String s = p.toString();
        assertNotNull(s);
        assertTrue(s.length() > 0);
    }

    // ---- time zone pattern letters Z / ZZ ----

    @Test
    public void testTimeZoneRfc822FormatPositiveOffset() {
        FastDatePrinter p = new FastDatePrinter("Z", TimeZone.getTimeZone("GMT+08:00"), Locale.US);
        assertEquals("+0800", p.format(0L));
    }

    @Test
    public void testTimeZoneIso8601FormatPositiveOffset() {
        FastDatePrinter p = new FastDatePrinter("ZZ", TimeZone.getTimeZone("GMT+08:00"), Locale.US);
        assertEquals("+08:00", p.format(0L));
    }

    @Test
    public void testTimeZoneRfc822FormatNegativeOffset() {
        FastDatePrinter p = new FastDatePrinter("Z", TimeZone.getTimeZone("GMT-11:00"), Locale.US);
        assertEquals("-1100", p.format(0L));
    }

    @Test
    public void testTimeZoneIso8601FormatNegativeOffset() {
        FastDatePrinter p = new FastDatePrinter("ZZ", TimeZone.getTimeZone("GMT-11:00"), Locale.US);
        assertEquals("-11:00", p.format(0L));
    }

    // ---- year pattern behavior (Java 7 style, as documented) ----

    @Test
    public void testYearPatternTwoLettersTruncatesToTwoDigits() {
        FastDatePrinter p = new FastDatePrinter("yy", UTC, Locale.US);
        Calendar cal = utcCalendar(2020, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals("20", p.format(cal));
    }

    @Test
    public void testYearPatternSingleLetterIsFullNumber() {
        FastDatePrinter p = new FastDatePrinter("y", UTC, Locale.US);
        Calendar cal = utcCalendar(2020, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals("2020", p.format(cal));
    }

    @Test
    public void testYearPatternThreeLettersIsFullNumber() {
        FastDatePrinter p = new FastDatePrinter("yyy", UTC, Locale.US);
        Calendar cal = utcCalendar(2020, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals("2020", p.format(cal));
    }

    @Test
    public void testYearPatternFourLettersIsFullNumber() {
        FastDatePrinter p = new FastDatePrinter("yyyy", UTC, Locale.US);
        Calendar cal = utcCalendar(2020, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals("2020", p.format(cal));
    }

    // ---- SimpleDateFormat-compatible literal text handling ----

    @Test
    public void testQuotedLiteralTextIsPreservedVerbatim() {
        FastDatePrinter p = new FastDatePrinter("'Year:'yyyy", UTC, Locale.US);
        Calendar cal = utcCalendar(2020, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals("Year:2020", p.format(cal));
    }

    @Test
    public void testDoubledSingleQuoteProducesLiteralQuoteCharacter() {
        FastDatePrinter p = new FastDatePrinter("yyyy''yy", UTC, Locale.US);
        Calendar cal = utcCalendar(2020, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals("2020'20", p.format(cal));
    }

    // ---- locale-dependent names and 12/24 hour clock ----

    @Test
    public void testFullMonthNameAndWeekdayNameUseLocale() {
        FastDatePrinter monthPrinter = new FastDatePrinter("MMMM", UTC, Locale.US);
        FastDatePrinter weekdayPrinter = new FastDatePrinter("EEEE", UTC, Locale.US);
        Calendar cal = utcCalendar(2020, Calendar.JANUARY, 15, 0, 0, 0, 0);
        assertEquals("January", monthPrinter.format(cal));
        assertEquals("Wednesday", weekdayPrinter.format(cal));
    }

    @Test
    public void testTwelveHourClockAndAmPmMarker() {
        FastDatePrinter p = new FastDatePrinter("hh a", UTC, Locale.US);
        Calendar cal = utcCalendar(2020, Calendar.JANUARY, 15, 13, 5, 9, 7);
        assertEquals("01 PM", p.format(cal));
    }

    // ---- protected applyRules ----

    @Test
    public void testApplyRulesAppendsAndReturnsSameBuffer() {
        FastDatePrinter p = new FastDatePrinter("yyyy-MM-dd HH:mm:ss.SSS", UTC, Locale.US);
        Calendar cal = utcCalendar(2020, Calendar.JANUARY, 15, 13, 5, 9, 7);
        StringBuffer buf = new StringBuffer("X");
        StringBuffer result = p.applyRules(cal, buf);
        assertSame(buf, result);
        assertEquals("X2020-01-15 13:05:09.007", buf.toString());
    }

    // ---- protected parseToken ----

    @Test
    public void testParseTokenGroupsConsecutiveIdenticalPatternLetters() {
        FastDatePrinter p = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.US);
        String token = p.parseToken("yyyy-MM-dd", new int[] { 0 });
        assertNotNull(token);
        assertTrue(token.length() > 0);
        for (int i = 0; i < token.length(); i++) {
            assertEquals('y', token.charAt(i));
        }
    }

    // ---- protected parsePattern ----

    @Test
    public void testParsePatternReturnsNonEmptyListForValidPattern() {
        FastDatePrinter p = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.US);
        assertTrue(p.parsePattern().size() > 0);
    }

    // @Test  // pruned: failed on the fixed version
    public void testParsePatternThrowsForInvalidUnterminatedQuote() {
        try {
            new FastDatePrinter("'unterminated", UTC, Locale.US).parsePattern();
            fail("Expected IllegalArgumentException for an invalid pattern");
        } catch (IllegalArgumentException e) {
            // expected, either eagerly at construction or lazily when parsing
        }
    }

    // ---- protected selectNumberRule ----

    @Test
    public void testSelectNumberRuleReturnsNonNullRule() {
        FastDatePrinter p = new FastDatePrinter("yyyy-MM-dd", UTC, Locale.US);
        assertNotNull(p.selectNumberRule(Calendar.YEAR, 4));
    }

    // ---- Serializable contract ----

    @Test
    public void testSerializationRoundTripPreservesStateAndBehavior() throws Exception {
        FastDatePrinter original = new FastDatePrinter("yyyy-MM-dd'T'HH:mm:ss", UTC, Locale.US);

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(baos);
        oos.writeObject(original);
        oos.close();

        ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(baos.toByteArray()));
        Object deserialized = ois.readObject();
        ois.close();

        assertTrue(deserialized instanceof FastDatePrinter);
        FastDatePrinter copy = (FastDatePrinter) deserialized;

        assertEquals(original.getPattern(), copy.getPattern());
        assertEquals(original.getTimeZone(), copy.getTimeZone());
        assertEquals(original.getLocale(), copy.getLocale());
        assertEquals(original.format(123456789L), copy.format(123456789L));
        assertEquals(original, copy);
    }
}
