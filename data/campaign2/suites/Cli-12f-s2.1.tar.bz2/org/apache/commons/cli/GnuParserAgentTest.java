package org.apache.commons.cli;

import junit.framework.TestCase;

/**
 * Tests for {@link GnuParser}, based on the documented contract of its
 * constructor and of the {@code flatten} method.
 */
public class GnuParserAgentTest extends TestCase {

    private GnuParser parser;

    protected void setUp() {
        parser = new GnuParser();
    }

    // -----------------------------------------------------------------
    // type / construction
    // -----------------------------------------------------------------

    public void testIsAParser() {
        assertTrue(parser instanceof Parser);
    }

    public void testIsACommandLineParser() {
        assertTrue(parser instanceof CommandLineParser);
    }

    // -----------------------------------------------------------------
    // flatten: boundary cases
    // -----------------------------------------------------------------

    public void testFlattenEmptyArgumentsReturnsEmptyArray() {
        Options options = new Options();
        String[] result = parser.flatten(options, new String[0], false);
        assertNotNull(result);
        assertEquals(0, result.length);
    }

    public void testFlattenNullArgumentsThrows() {
        Options options = new Options();
        try {
            parser.flatten(options, null, false);
            fail("Expected a NullPointerException when arguments is null");
        } catch (NullPointerException expected) {
            // documented implicitly: arguments is iterated, so null is not supported
        }
    }

    public void testFlattenNullOptionsThrowsWhenArgumentLooksLikeOption() {
        Options options = null;
        try {
            // an argument starting with '-' forces a lookup in options
            parser.flatten(options, new String[] {"-a"}, false);
            fail("Expected a NullPointerException when options is null");
        } catch (NullPointerException expected) {
            // documented implicitly: options.hasOption(...) is consulted
        }
    }

    // -----------------------------------------------------------------
    // flatten: rule 1 - whole option exists -> token added unchanged
    // -----------------------------------------------------------------

    public void testFlattenKnownWholeOptionIsNotSplit() {
        Options options = new Options();
        options.addOption("a", false, "a flag");

        String[] result = parser.flatten(options, new String[] {"-a"}, false);

        assertNotNull(result);
        assertEquals(1, result.length);
        assertEquals("-a", result[0]);
    }

    public void testFlattenKnownMultiCharWholeOptionIsNotSplit() {
        Options options = new Options();
        options.addOption("D", false, "single char option");
        // "Dfoo" is registered as a whole option in its own right
        options.addOption("Dfoo", false, "a whole option that happens to start with D");

        String[] result = parser.flatten(options, new String[] {"-Dfoo"}, false);

        assertNotNull(result);
        assertEquals(1, result.length);
        assertEquals("-Dfoo", result[0]);
    }

    // -----------------------------------------------------------------
    // flatten: rule 2 - first char is a known option, whole token is not
    // -----------------------------------------------------------------

    public void testFlattenSplitsOnFirstCharacterOption() {
        Options options = new Options();
        options.addOption("D", false, "single char option");
        // note: "Dfoo" itself is *not* registered as an option

        String[] result = parser.flatten(options, new String[] {"-Dfoo"}, false);

        assertNotNull(result);
        assertEquals(2, result.length);
        assertEquals("-D", result[0]);
        assertEquals("foo", result[1]);
    }

    public void testFlattenSplitPreservesOrderAcrossMultipleTokens() {
        Options options = new Options();
        options.addOption("D", false, "single char option");
        options.addOption("x", false, "another flag");

        String[] result = parser.flatten(
                options, new String[] {"-Dfoo", "-x"}, false);

        assertNotNull(result);
        assertEquals(3, result.length);
        assertEquals("-D", result[0]);
        assertEquals("foo", result[1]);
        assertEquals("-x", result[2]);
    }

    // -----------------------------------------------------------------
    // flatten: tokens with no matching option at all
    // -----------------------------------------------------------------

    public void testFlattenPlainArgumentIsAddedUnchanged() {
        Options options = new Options();
        options.addOption("a", false, "a flag");

        String[] result = parser.flatten(options, new String[] {"plainArg"}, false);

        assertNotNull(result);
        assertEquals(1, result.length);
        assertEquals("plainArg", result[0]);
    }

    // -----------------------------------------------------------------
    // flatten: stopAtNonOption governs behaviour once a non-option is seen
    // -----------------------------------------------------------------

    public void testFlattenContinuesProcessingWhenStopAtNonOptionFalse() {
        Options options = new Options();
        options.addOption("D", false, "single char option");

        String[] result = parser.flatten(
                options, new String[] {"plainArg", "-Dfoo"}, false);

        assertNotNull(result);
        assertEquals(3, result.length);
        assertEquals("plainArg", result[0]);
        assertEquals("-D", result[1]);
        assertEquals("foo", result[2]);
    }

    public void pruned_testFlattenStopsProcessingWhenStopAtNonOptionTrue() {
        Options options = new Options();
        options.addOption("D", false, "single char option");

        String[] result = parser.flatten(
                options, new String[] {"plainArg", "-Dfoo"}, true);

        assertNotNull(result);
        // once the non-option "plainArg" is encountered, flattening stops:
        // the remaining argument is carried through without being split
        assertEquals(2, result.length);
        assertEquals("plainArg", result[0]);
        assertEquals("-Dfoo", result[1]);
    }

    // -----------------------------------------------------------------
    // flatten: result type contract
    // -----------------------------------------------------------------

    public void testFlattenReturnsStringArrayType() {
        Options options = new Options();
        Object result = parser.flatten(options, new String[] {"a", "b"}, false);
        assertTrue(result instanceof String[]);
    }

    // -----------------------------------------------------------------
    // integration: GnuParser used through the CommandLineParser contract
    // -----------------------------------------------------------------

    public void testParseRecognizesSingleCharOptionSplitFromItsArgument() throws Exception {
        Options options = new Options();
        options.addOption("D", true, "define a property");

        CommandLineParser commandLineParser = parser;
        CommandLine cmd = commandLineParser.parse(options, new String[] {"-Dfoo"});

        assertTrue(cmd.hasOption("D"));
        assertEquals("foo", cmd.getOptionValue("D"));
    }

    public void testParseUnrecognizedOptionThrowsParseException() {
        Options options = new Options();
        options.addOption("a", false, "a flag");

        try {
            parser.parse(options, new String[] {"-z"});
            fail("Expected a ParseException for an unrecognized option");
        } catch (ParseException expected) {
            // documented via the CommandLineParser contract
        }
    }
}
