package com.google.gson.internal;

import junit.framework.TestCase;

import java.io.Serializable;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.WildcardType;
import java.util.AbstractSet;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Self-contained tests for {@link $Gson$Types} based on the documented API in api/.
 */
public class $Gson$TypesAgentTest extends TestCase {

    // Fixture fields used only to obtain generic Type metadata via reflection.
    private List<String> stringListField;
    private ArrayList<String> stringArrayListField;
    private Map<String, Integer> stringIntMapField;

    // Fixture class matching the javadoc example for getGenericSupertype:
    // "given a class IntegerSet, the result ... when supertype is Set.class is Set<Integer>".
    private static class IntegerSet extends AbstractSet<Integer> {
        public Iterator<Integer> iterator() {
            return new ArrayList<Integer>().iterator();
        }

        public int size() {
            return 0;
        }
    }

    private Type fieldType(String name) throws Exception {
        return getClass().getDeclaredField(name).getGenericType();
    }

    // ----- EMPTY_TYPE_ARRAY -----

    public void testEmptyTypeArrayIsEmpty() {
        Type[] empty = $Gson$Types.EMPTY_TYPE_ARRAY;
        assertNotNull(empty);
        assertEquals(0, empty.length);
    }

    // ----- arrayOf -----

    public void testArrayOfReturnsGenericArrayTypeWithGivenComponent() {
        GenericArrayType gat = $Gson$Types.arrayOf(String.class);
        assertEquals(String.class, gat.getGenericComponentType());
    }

    public void testArrayOfWithPrimitiveComponent() {
        GenericArrayType gat = $Gson$Types.arrayOf(int.class);
        assertEquals(int.class, gat.getGenericComponentType());
    }

    public void testArrayOfInstancesWithSameComponentAreFunctionallyEqual() {
        GenericArrayType a = $Gson$Types.arrayOf(String.class);
        GenericArrayType b = $Gson$Types.arrayOf(String.class);
        assertTrue($Gson$Types.equals(a, b));
    }

    // ----- canonicalize -----

    public void testCanonicalizeOfClassKeepsSameRawTypeAndName() {
        Type canonical = $Gson$Types.canonicalize(String.class);
        assertEquals(String.class, $Gson$Types.getRawType(canonical));
        assertEquals("java.lang.String", $Gson$Types.typeToString(canonical));
    }

    public void testCanonicalizeOfGenericArrayTypeIsFunctionallyEqualToOriginal() {
        Type original = $Gson$Types.arrayOf(String.class);
        Type canonical = $Gson$Types.canonicalize(original);
        assertTrue($Gson$Types.equals(original, canonical));
        assertTrue(canonical instanceof Serializable);
    }

    public void testCanonicalizeOfParameterizedTypeIsFunctionallyEqualToOriginal() {
        ParameterizedType original = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
        Type canonical = $Gson$Types.canonicalize(original);
        assertTrue($Gson$Types.equals(original, canonical));
        assertTrue(canonical instanceof Serializable);
    }

    // ----- equals -----

    public void testEqualsSameClassIsTrue() {
        assertTrue($Gson$Types.equals(String.class, String.class));
    }

    public void testEqualsDifferentClassIsFalse() {
        assertFalse($Gson$Types.equals(String.class, Integer.class));
    }

    public void testEqualsParameterizedTypesWithSameArgumentsIsTrue() {
        ParameterizedType p1 = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
        ParameterizedType p2 = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
        assertTrue($Gson$Types.equals(p1, p2));
    }

    public void testEqualsParameterizedTypesWithDifferentArgumentsIsFalse() {
        ParameterizedType p1 = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
        ParameterizedType p2 = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, Integer.class);
        assertFalse($Gson$Types.equals(p1, p2));
    }

    public void testEqualsWildcardTypesWithSameBoundIsTrue() {
        WildcardType w1 = $Gson$Types.subtypeOf(String.class);
        WildcardType w2 = $Gson$Types.subtypeOf(String.class);
        assertTrue($Gson$Types.equals(w1, w2));
    }

    // ----- getArrayComponentType -----

    public void testGetArrayComponentTypeForObjectArrayClass() {
        assertEquals(String.class, $Gson$Types.getArrayComponentType(String[].class));
    }

    public void testGetArrayComponentTypeForPrimitiveArrayClass() {
        assertEquals(int.class, $Gson$Types.getArrayComponentType(int[].class));
    }

    public void testGetArrayComponentTypeForGenericArrayType() {
        GenericArrayType gat = $Gson$Types.arrayOf(String.class);
        assertEquals(String.class, $Gson$Types.getArrayComponentType(gat));
    }

    public void pruned_testGetArrayComponentTypeThrowsForNonArrayType() {
        try {
            $Gson$Types.getArrayComponentType(String.class);
            fail("Expected ClassCastException for non-array type");
        } catch (ClassCastException expected) {
            // documented in api/: throws ClassCastException if this type is not an array
        }
    }

    // ----- getCollectionElementType -----

    public void testGetCollectionElementTypeForParameterizedList() throws Exception {
        Type context = fieldType("stringListField");
        Type elementType = $Gson$Types.getCollectionElementType(context, List.class);
        assertEquals(String.class, elementType);
    }

    public void testGetCollectionElementTypeThrowsForNonCollection() {
        try {
            $Gson$Types.getCollectionElementType(String.class, String.class);
            fail("Expected IllegalArgumentException for non-collection type");
        } catch (IllegalArgumentException expected) {
            // documented in api/: throws IllegalArgumentException if this type is not a collection
        }
    }

    // ----- getMapKeyAndValueTypes -----

    public void testGetMapKeyAndValueTypesForParameterizedMap() throws Exception {
        Type context = fieldType("stringIntMapField");
        Type[] kv = $Gson$Types.getMapKeyAndValueTypes(context, Map.class);
        assertEquals(2, kv.length);
        assertEquals(String.class, kv[0]);
        assertEquals(Integer.class, kv[1]);
    }

    // ----- getRawType -----

    public void testGetRawTypeForClass() {
        assertEquals(String.class, $Gson$Types.getRawType(String.class));
    }

    public void testGetRawTypeForParameterizedType() throws Exception {
        Type context = fieldType("stringListField");
        assertEquals(List.class, $Gson$Types.getRawType(context));
    }

    public void testGetRawTypeForGenericArrayType() {
        GenericArrayType gat = $Gson$Types.arrayOf(String.class);
        assertEquals(String[].class, $Gson$Types.getRawType(gat));
    }

    // ----- newParameterizedTypeWithOwner -----

    public void testNewParameterizedTypeWithOwnerBasicShape() {
        ParameterizedType pt = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
        assertNull(pt.getOwnerType());
        assertEquals(List.class, pt.getRawType());
        assertEquals(1, pt.getActualTypeArguments().length);
        assertEquals(String.class, pt.getActualTypeArguments()[0]);
        assertTrue("result must be serializable per javadoc", pt instanceof Serializable);
    }

    public void testNewParameterizedTypeWithOwnerMultipleArguments() {
        ParameterizedType pt = $Gson$Types.newParameterizedTypeWithOwner(null, Map.class, String.class, Integer.class);
        assertEquals(2, pt.getActualTypeArguments().length);
        assertEquals(String.class, pt.getActualTypeArguments()[0]);
        assertEquals(Integer.class, pt.getActualTypeArguments()[1]);
    }

    public void testNewParameterizedTypeWithOwnerNoTypeArguments() {
        ParameterizedType pt = $Gson$Types.newParameterizedTypeWithOwner(null, String.class);
        assertEquals(0, pt.getActualTypeArguments().length);
    }

    // ----- subtypeOf / supertypeOf -----

    public void testSubtypeOfSetsUpperBoundAndNoLowerBound() {
        WildcardType w = $Gson$Types.subtypeOf(CharSequence.class);
        assertEquals(1, w.getUpperBounds().length);
        assertEquals(CharSequence.class, w.getUpperBounds()[0]);
        assertEquals(0, w.getLowerBounds().length);
    }

    public void testSubtypeOfObjectIsUnboundedWildcardShorthand() {
        WildcardType w = $Gson$Types.subtypeOf(Object.class);
        assertEquals(1, w.getUpperBounds().length);
        assertEquals(Object.class, w.getUpperBounds()[0]);
        assertEquals(0, w.getLowerBounds().length);
    }

    public void testSupertypeOfSetsLowerBoundAndDefaultUpperBound() {
        WildcardType w = $Gson$Types.supertypeOf(String.class);
        assertEquals(1, w.getLowerBounds().length);
        assertEquals(String.class, w.getLowerBounds()[0]);
        // java.lang.reflect.WildcardType: "If no upper bound is explicitly declared, the upper bound is Object."
        assertEquals(1, w.getUpperBounds().length);
        assertEquals(Object.class, w.getUpperBounds()[0]);
    }

    // ----- typeToString -----

    public void testTypeToStringForClass() {
        assertEquals("java.lang.String", $Gson$Types.typeToString(String.class));
    }

    public void testTypeToStringForPrimitiveClass() {
        assertEquals("int", $Gson$Types.typeToString(int.class));
    }

    // ----- package-private helpers (accessible because this test shares the package) -----

    public void testEqualIsNullSafe() {
        assertTrue($Gson$Types.equal(null, null));
        assertFalse($Gson$Types.equal(null, "x"));
        assertFalse($Gson$Types.equal("x", null));
        assertTrue($Gson$Types.equal("x", "x"));
        assertFalse($Gson$Types.equal("x", "y"));
    }

    public void testHashCodeOrZero() {
        assertEquals(0, $Gson$Types.hashCodeOrZero(null));
        assertEquals("x".hashCode(), $Gson$Types.hashCodeOrZero("x"));
    }

    public void testCheckNotPrimitiveAllowsNonPrimitiveType() {
        // Must not throw for a non-primitive type.
        $Gson$Types.checkNotPrimitive(String.class);
    }

    public void testCheckNotPrimitiveRejectsPrimitiveType() {
        try {
            $Gson$Types.checkNotPrimitive(int.class);
            fail("Expected an exception for a primitive type");
        } catch (RuntimeException expected) {
            // name implies this is a precondition check against primitive types
        }
    }

    public void pruned_testGetGenericSupertypeResolvesDirectInterface() {
        Type result = $Gson$Types.getGenericSupertype(IntegerSet.class, IntegerSet.class, Set.class);
        assertEquals(Set.class, $Gson$Types.getRawType(result));
        if (result instanceof ParameterizedType) {
            assertEquals(Integer.class, ((ParameterizedType) result).getActualTypeArguments()[0]);
        }
    }

    public void pruned_testGetGenericSupertypeResolvesIndirectInterface() {
        Type result = $Gson$Types.getGenericSupertype(IntegerSet.class, IntegerSet.class, Collection.class);
        assertEquals(Collection.class, $Gson$Types.getRawType(result));
        if (result instanceof ParameterizedType) {
            assertEquals(Integer.class, ((ParameterizedType) result).getActualTypeArguments()[0]);
        }
    }

    public void testGetSupertypeResolvesParameterizedAncestor() throws Exception {
        Type context = fieldType("stringArrayListField");
        Type result = $Gson$Types.getSupertype(context, ArrayList.class, Iterable.class);
        assertEquals(Iterable.class, $Gson$Types.getRawType(result));
        assertTrue(result instanceof ParameterizedType);
        assertEquals(String.class, ((ParameterizedType) result).getActualTypeArguments()[0]);
    }
}
