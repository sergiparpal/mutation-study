package org.apache.commons.csv;

import java.io.IOException;
import java.io.StringReader;

import junit.framework.TestCase;

/**
 * Self-contained tests for {@link Lexer}, driven purely by the documented
 * contract of the abstract class (its javadoc, package-private fields and
 * method descriptions).
 */
public class LexerAgentTest extends TestCase {

    /** Minimal concrete subclass so the abstract Lexer can be instantiated. */
    private static final class ConcreteLexer extends Lexer {
        ConcreteLexer(final CSVFormat format, final ExtendedBufferedReader input) {
            super(format, input);
        }

        Token nextToken(final Token reusableToken) throws IOException {
            throw new UnsupportedOperationException("not needed for these tests");
        }
    }

    private static ConcreteLexer newLexer(final CSVFormat format, final String content) {
        return new ConcreteLexer(format, new ExtendedBufferedReader(new StringReader(content)));
    }

    /** Builds a format that only enables the given optional special characters. */
    private static CSVFormat withSpecialChars(final Character commentStart, final Character escape) {
        return new CSVFormat(',', Character.valueOf('"'), Quote.MINIMAL, commentStart, escape,
                false, true, "\r\n", null, (String[]) null);
    }

    // --- constructor ---------------------------------------------------

    public void testConstructorStoresFormatAndStream() {
        final CSVFormat format = CSVFormat.DEFAULT;
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("abc"));
        final ConcreteLexer lexer = new ConcreteLexer(format, reader);
        assertSame(format, lexer.format);
        assertSame(reader, lexer.in);
    }

    public void testConstructorMirrorsFormatFlags() {
        final CSVFormat format = CSVFormat.DEFAULT;
        final ConcreteLexer lexer = newLexer(format, "");
        assertEquals(format.getIgnoreSurroundingSpaces(), lexer.ignoreSurroundingSpaces);
        assertEquals(format.getIgnoreEmptyLines(), lexer.ignoreEmptyLines);
    }

    // --- isWhitespace ----------------------------------------------------

    public void testIsWhitespaceTrueForSpace() {
        final ConcreteLexer lexer = newLexer(CSVFormat.DEFAULT, "");
        assertTrue(lexer.isWhitespace(' '));
    }

    public void testIsWhitespaceFalseForLetter() {
        final ConcreteLexer lexer = newLexer(CSVFormat.DEFAULT, "");
        assertFalse(lexer.isWhitespace('a'));
    }

    public void testIsWhitespaceFalseForUndefinedSentinel() {
        final ConcreteLexer lexer = newLexer(CSVFormat.DEFAULT, "");
        assertFalse(lexer.isWhitespace(Constants.UNDEFINED));
    }

    // --- isDelimiter -------------------------------------------------------

    public void testIsDelimiterMatchesFormatDelimiter() {
        final CSVFormat format = CSVFormat.DEFAULT;
        final ConcreteLexer lexer = newLexer(format, "");
        assertTrue(lexer.isDelimiter(format.getDelimiter()));
    }

    public void testIsDelimiterFalseForUndefinedSentinel() {
        final ConcreteLexer lexer = newLexer(CSVFormat.DEFAULT, "");
        assertFalse(lexer.isDelimiter(Constants.UNDEFINED));
    }

    // --- isQuoteChar -------------------------------------------------------

    public void testIsQuoteCharMatchesFormatQuoteChar() {
        final CSVFormat format = CSVFormat.DEFAULT;
        final Character quote = format.getQuoteChar();
        assertNotNull("default format is expected to define a quote character", quote);
        final ConcreteLexer lexer = newLexer(format, "");
        assertTrue(lexer.isQuoteChar(quote.charValue()));
    }

    public void testIsQuoteCharFalseForUndefinedSentinel() {
        final ConcreteLexer lexer = newLexer(CSVFormat.DEFAULT, "");
        assertFalse(lexer.isQuoteChar(Constants.UNDEFINED));
    }

    // --- isEscape ------------------------------------------------------

    public void testIsEscapeFalseByDefault() {
        final ConcreteLexer lexer = newLexer(CSVFormat.DEFAULT, "");
        assertFalse(lexer.isEscape('\\'));
        assertFalse(lexer.isEscape(Constants.UNDEFINED));
    }

    public void testIsEscapeTrueWhenConfigured() {
        final CSVFormat format = withSpecialChars(null, Character.valueOf('\\'));
        final ConcreteLexer lexer = newLexer(format, "");
        assertTrue(lexer.isEscape('\\'));
        assertFalse(lexer.isEscape('#'));
    }

    // --- isCommentStart --------------------------------------------------

    public void testIsCommentStartFalseByDefault() {
        final ConcreteLexer lexer = newLexer(CSVFormat.DEFAULT, "");
        assertFalse(lexer.isCommentStart('#'));
        assertFalse(lexer.isCommentStart(Constants.UNDEFINED));
    }

    public void testIsCommentStartTrueWhenConfigured() {
        final CSVFormat format = withSpecialChars(Character.valueOf('#'), null);
        final ConcreteLexer lexer = newLexer(format, "");
        assertTrue(lexer.isCommentStart('#'));
        assertFalse(lexer.isCommentStart('\\'));
    }

    // --- isEndOfFile -----------------------------------------------------

    public void testIsEndOfFileTrueForEndOfStreamConstant() {
        final ConcreteLexer lexer = newLexer(CSVFormat.DEFAULT, "");
        assertTrue(lexer.isEndOfFile(Constants.END_OF_STREAM));
    }

    public void testIsEndOfFileFalseForOrdinaryChar() {
        final ConcreteLexer lexer = newLexer(CSVFormat.DEFAULT, "");
        assertFalse(lexer.isEndOfFile('a'));
    }

    // --- isStartOfLine -----------------------------------------------------

    public void testIsStartOfLineTrueForCrLfAndFileStart() {
        final ConcreteLexer lexer = newLexer(CSVFormat.DEFAULT, "");
        assertTrue(lexer.isStartOfLine(Constants.CR));
        assertTrue(lexer.isStartOfLine(Constants.LF));
        assertTrue(lexer.isStartOfLine(Constants.UNDEFINED));
    }

    public void testIsStartOfLineFalseForOrdinaryChar() {
        final ConcreteLexer lexer = newLexer(CSVFormat.DEFAULT, "");
        assertFalse(lexer.isStartOfLine('a'));
    }

    // --- readEndOfLine -----------------------------------------------------

    public void testReadEndOfLineAcceptsLf() throws IOException {
        final ConcreteLexer lexer = newLexer(CSVFormat.DEFAULT, "X");
        assertTrue(lexer.readEndOfLine('\n'));
        assertEquals('X', lexer.in.read());
    }

    public void testReadEndOfLineAcceptsCrAlone() throws IOException {
        final ConcreteLexer lexer = newLexer(CSVFormat.DEFAULT, "X");
        assertTrue(lexer.readEndOfLine('\r'));
        assertEquals('X', lexer.in.read());
    }

    public void testReadEndOfLineSilentlyConsumesLfAfterCr() throws IOException {
        final ConcreteLexer lexer = newLexer(CSVFormat.DEFAULT, "\nY");
        assertTrue(lexer.readEndOfLine('\r'));
        assertEquals('Y', lexer.in.read());
    }

    public void testReadEndOfLineFalseForOrdinaryChar() throws IOException {
        final ConcreteLexer lexer = newLexer(CSVFormat.DEFAULT, "Z");
        assertFalse(lexer.readEndOfLine('a'));
        assertEquals('Z', lexer.in.read());
    }

    // --- readEscape ------------------------------------------------------

    public void testReadEscapeThrowsIOExceptionAtEndOfStream() {
        final ConcreteLexer lexer = newLexer(CSVFormat.DEFAULT, "");
        try {
            lexer.readEscape();
            fail("Expected an IOException when the escape character is at the end of the stream");
        } catch (final IOException expected) {
            // documented: escape character is not allowed at end of stream
        }
    }

    public void testReadEscapeReturnsEndOfStreamForUnrecognizedChar() throws IOException {
        final ConcreteLexer lexer = newLexer(CSVFormat.DEFAULT, "z");
        final int result = lexer.readEscape();
        assertEquals(Constants.END_OF_STREAM, result);
        assertEquals('z', lexer.in.getLastChar());
    }

    public void testReadEscapeUnescapesQuoteChar() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT;
        final Character quote = format.getQuoteChar();
        assertNotNull("default format is expected to define a quote character", quote);
        final ConcreteLexer lexer = newLexer(format, String.valueOf(quote.charValue()));
        final int result = lexer.readEscape();
        assertEquals(quote.charValue(), result);
        assertEquals(quote.charValue(), lexer.in.getLastChar());
    }

    // --- trimTrailingSpaces ------------------------------------------------

    public void testTrimTrailingSpacesRemovesTrailingSpacesOnly() {
        final ConcreteLexer lexer = newLexer(CSVFormat.DEFAULT, "");
        final StringBuilder buffer = new StringBuilder("  abc   ");
        lexer.trimTrailingSpaces(buffer);
        assertEquals("  abc", buffer.toString());
    }

    public void testTrimTrailingSpacesNoTrailingSpaces() {
        final ConcreteLexer lexer = newLexer(CSVFormat.DEFAULT, "");
        final StringBuilder buffer = new StringBuilder("abc");
        lexer.trimTrailingSpaces(buffer);
        assertEquals("abc", buffer.toString());
    }

    public void testTrimTrailingSpacesAllSpaces() {
        final ConcreteLexer lexer = newLexer(CSVFormat.DEFAULT, "");
        final StringBuilder buffer = new StringBuilder("   ");
        lexer.trimTrailingSpaces(buffer);
        assertEquals("", buffer.toString());
    }

    public void testTrimTrailingSpacesEmptyBuffer() {
        final ConcreteLexer lexer = newLexer(CSVFormat.DEFAULT, "");
        final StringBuilder buffer = new StringBuilder("");
        lexer.trimTrailingSpaces(buffer);
        assertEquals("", buffer.toString());
    }

    // --- getLineNumber -----------------------------------------------------

    public void testGetLineNumberDelegatesToInputStream() throws IOException {
        final ConcreteLexer lexer = newLexer(CSVFormat.DEFAULT, "a\nb\nc");
        assertEquals(lexer.in.getLineNumber(), lexer.getLineNumber());
        lexer.in.readLine();
        assertEquals(lexer.in.getLineNumber(), lexer.getLineNumber());
        lexer.in.readLine();
        assertEquals(lexer.in.getLineNumber(), lexer.getLineNumber());
    }
}
