/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.cli2.commandline;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import org.apache.commons.cli2.Argument;
import org.apache.commons.cli2.Group;
import org.apache.commons.cli2.Option;
import org.apache.commons.cli2.builder.ArgumentBuilder;
import org.apache.commons.cli2.builder.DefaultOptionBuilder;
import org.apache.commons.cli2.builder.GroupBuilder;
import org.apache.commons.cli2.option.PropertyOption;

import junit.framework.TestCase;

/**
 * Self-contained tests for {@link WriteableCommandLineImpl}.
 */
public class WriteableCommandLineImplAgentTest extends TestCase {
    private Option present;
    private Option missing;
    private Option multiple;
    private Argument argument;
    private Group root;

    public void setUp() throws Exception {
        super.setUp();
        present = new DefaultOptionBuilder().withLongName("present").withShortName("p").create();
        missing = new DefaultOptionBuilder().withLongName("missing").create();
        multiple = new DefaultOptionBuilder().withLongName("multiple").create();
        argument = new ArgumentBuilder().withName("arg").create();
        root = new GroupBuilder().withOption(present).withOption(missing)
                   .withOption(multiple).withOption(argument).create();
    }

    private WriteableCommandLineImpl create(List args) {
        return new WriteableCommandLineImpl(root, args);
    }

    public void testConstructorStoresNormalisedArguments() {
        final List args = Arrays.asList(new String[] {"--present", "value"});
        final WriteableCommandLineImpl cl = create(args);

        assertEquals(args, cl.getNormalised());
        assertTrue(cl.getOptions().isEmpty());
        assertTrue(cl.getOptionTriggers().isEmpty());
    }

    public void testAddOptionMakesOptionPresentAndIndexesTriggers() {
        final WriteableCommandLineImpl cl = create(new ArrayList());

        assertFalse(cl.hasOption(present));
        cl.addOption(present);
        assertTrue(cl.hasOption(present));
        assertSame(present, cl.getOption("--present"));
        assertSame(present, cl.getOption("-p"));
        assertNull(cl.getOption("--missing"));
        assertEquals(1, cl.getOptions().size());
        assertSame(present, cl.getOptions().get(0));
    }

    public void testAddOptionTwiceAddsTwoEntriesToOptionsList() {
        final WriteableCommandLineImpl cl = create(new ArrayList());

        cl.addOption(present);
        cl.addOption(present);
        assertEquals(2, cl.getOptions().size());
        assertEquals(2, cl.getOptionCount(present));
    }

    public void testAddValueDoesNotMarkPlainOptionPresent() {
        final WriteableCommandLineImpl cl = create(new ArrayList());

        assertTrue(cl.getValues(present, null).isEmpty());
        cl.addValue(present, "value");
        assertFalse(cl.hasOption(present));

        final List values = cl.getValues(present, null);
        assertEquals(1, values.size());
        assertEquals("value", values.get(0));
    }

    public void testAddValueOnArgumentMarksOptionPresent() {
        final WriteableCommandLineImpl cl = create(new ArrayList());

        assertFalse(cl.hasOption(argument));
        cl.addValue(argument, "host");
        assertTrue(cl.hasOption(argument));

        final List values = cl.getValues(argument, null);
        assertEquals(1, values.size());
        assertEquals("host", values.get(0));
    }

    public void testGetValuesUsesSuppliedDefaultsWhenNoneSet() {
        final WriteableCommandLineImpl cl = create(new ArrayList());
        final List defaults = Arrays.asList(new String[] {"d1", "d2"});

        final List values = cl.getValues(present, defaults);
        assertEquals(defaults, values);
    }

    public void testGetValuesWithEmptyDefaultsFallsBackToOptionDefaults() {
        final WriteableCommandLineImpl cl = create(new ArrayList());
        final List optionDefaults = Arrays.asList(new String[] {"od1"});

        cl.setDefaultValues(present, optionDefaults);

        final List values = cl.getValues(present, new ArrayList());
        assertEquals(optionDefaults, values);
    }

    public void testGetValuesAugmentsShorterActualListWithExtraDefaults() {
        final WriteableCommandLineImpl cl = create(new ArrayList());

        cl.addValue(present, "actual");
        final List defaults = Arrays.asList(new String[] {"d1", "d2", "d3"});

        final List values = cl.getValues(present, defaults);
        assertEquals(3, values.size());
        assertEquals("actual", values.get(0));
        assertEquals("d2", values.get(1));
        assertEquals("d3", values.get(2));

        // the original stored values must remain untouched
        final List rawValues = cl.getUndefaultedValues(present);
        assertEquals(1, rawValues.size());
        assertEquals("actual", rawValues.get(0));
    }

    public void testGetValuesDoesNotAugmentWhenActualListIsLonger() {
        final WriteableCommandLineImpl cl = create(new ArrayList());

        cl.addValue(present, "a");
        cl.addValue(present, "b");
        final List defaults = Arrays.asList(new String[] {"d1"});

        final List values = cl.getValues(present, defaults);
        assertEquals(2, values.size());
        assertEquals("a", values.get(0));
        assertEquals("b", values.get(1));
    }

    public void testGetValuesForUnknownOptionReturnsEmptyList() {
        final WriteableCommandLineImpl cl = create(new ArrayList());

        final List values = cl.getValues(missing, null);
        assertNotNull(values);
        assertTrue(values.isEmpty());
    }

    public void testGetUndefaultedValuesIgnoresOptionDefaults() {
        final WriteableCommandLineImpl cl = create(new ArrayList());
        cl.setDefaultValues(present, Arrays.asList(new String[] {"ignored"}));

        final List values = cl.getUndefaultedValues(present);
        assertTrue(values.isEmpty());
    }

    public void testSetDefaultValuesNullRemovesDefaults() {
        final WriteableCommandLineImpl cl = create(new ArrayList());

        cl.setDefaultValues(present, Arrays.asList(new String[] {"d1"}));
        assertEquals(1, cl.getValues(present, null).size());

        cl.setDefaultValues(present, null);
        assertTrue(cl.getValues(present, null).isEmpty());
    }

    public void testAddSwitchSetsValueAndMarksOptionPresent() {
        final WriteableCommandLineImpl cl = create(new ArrayList());

        assertFalse(cl.hasOption(present));
        cl.addSwitch(present, true);
        assertTrue(cl.hasOption(present));
        assertEquals(Boolean.TRUE, cl.getSwitch(present, null));
    }

    public void testAddSwitchTwiceThrowsIllegalStateException() {
        final WriteableCommandLineImpl cl = create(new ArrayList());

        cl.addSwitch(present, true);
        try {
            cl.addSwitch(present, false);
            fail("Expected IllegalStateException when switch already set");
        } catch (IllegalStateException expected) {
            // expected
        }
    }

    public void testGetSwitchPrefersActualOverSuppliedDefault() {
        final WriteableCommandLineImpl cl = create(new ArrayList());

        cl.addSwitch(present, false);
        assertEquals(Boolean.FALSE, cl.getSwitch(present, Boolean.TRUE));
    }

    public void testGetSwitchFallsBackToSuppliedDefaultThenOptionDefault() {
        final WriteableCommandLineImpl cl = create(new ArrayList());

        assertEquals(Boolean.TRUE, cl.getSwitch(present, Boolean.TRUE));

        cl.setDefaultSwitch(present, Boolean.FALSE);
        assertEquals(Boolean.FALSE, cl.getSwitch(present, null));

        assertNull(cl.getSwitch(missing, null));
    }

    public void testSetDefaultSwitchNullRemovesDefault() {
        final WriteableCommandLineImpl cl = create(new ArrayList());

        cl.setDefaultSwitch(present, Boolean.TRUE);
        assertEquals(Boolean.TRUE, cl.getSwitch(present, null));

        cl.setDefaultSwitch(present, null);
        assertNull(cl.getSwitch(present, null));
    }

    public void testPropertyDefaultsToSuppliedDefaultValueWhenMissing() {
        final WriteableCommandLineImpl cl = create(new ArrayList());

        final PropertyOption propertyOption = new PropertyOption();
        assertNull(cl.getProperty(propertyOption, "foo", null));
        assertEquals("fallback", cl.getProperty(propertyOption, "foo", "fallback"));
    }

    public void testAddPropertyAndGetPropertyRoundTrip() {
        final WriteableCommandLineImpl cl = create(new ArrayList());
        final PropertyOption propertyOption = new PropertyOption();

        cl.addProperty(propertyOption, "foo", "bar");
        assertEquals("bar", cl.getProperty(propertyOption, "foo", null));

        final Set keys = cl.getProperties(propertyOption);
        assertEquals(1, keys.size());
        assertTrue(keys.contains("foo"));
    }

    public void testGetPropertiesForUnknownOptionIsEmpty() {
        final WriteableCommandLineImpl cl = create(new ArrayList());

        assertTrue(cl.getProperties(new PropertyOption()).isEmpty());
    }

    public void testNoArgPropertyMethodsUseDefaultPropertyOption() {
        final WriteableCommandLineImpl cl = create(new ArrayList());

        assertNull(cl.getProperty("foo"));
        cl.addProperty("foo", "bar");
        assertEquals("bar", cl.getProperty("foo"));
        assertTrue(cl.getProperties().contains("foo"));
    }

    public void testLooksLikeOptionUsesRootOptionPrefixes() {
        final WriteableCommandLineImpl cl = create(new ArrayList());

        assertTrue(cl.looksLikeOption("--present"));
        assertTrue(cl.looksLikeOption("-p"));
        assertFalse(cl.looksLikeOption("plainvalue"));
        assertFalse(cl.looksLikeOption(""));
    }

    public void testToStringQuotesArgumentsContainingSpaces() {
        final List args = Arrays.asList(new String[] {"--present", "has space", "noSpace"});
        final WriteableCommandLineImpl cl = create(args);

        assertEquals("--present \"has space\" noSpace", cl.toString());
    }

    public void testToStringOnEmptyArgumentsIsEmptyString() {
        final WriteableCommandLineImpl cl = create(new ArrayList());

        assertEquals("", cl.toString());
    }

    public void testGetNormalisedIsUnmodifiable() {
        final List args = new ArrayList();
        args.add("--present");
        final WriteableCommandLineImpl cl = create(args);

        try {
            cl.getNormalised().add("extra");
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
    }

    public void testGetOptionsIsUnmodifiable() {
        final WriteableCommandLineImpl cl = create(new ArrayList());
        cl.addOption(present);

        try {
            cl.getOptions().add(missing);
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
    }

    public void testGetOptionTriggersIsUnmodifiable() {
        final WriteableCommandLineImpl cl = create(new ArrayList());
        cl.addOption(present);

        try {
            cl.getOptionTriggers().add("--new");
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
    }
}
