/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.cli;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.List;
import java.util.Properties;

import org.junit.Test;

public class DefaultParserAgentTest
{
    @Test
    public void testSimpleShortOption() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "a flag");

        CommandLine cmd = new DefaultParser().parse(options, new String[] {"-a"});

        assertTrue(cmd.hasOption("a"));
        assertEquals(0, cmd.getArgList().size());
    }

    @Test
    public void testSimpleLongOption() throws Exception
    {
        Options options = new Options();
        options.addOption("f", "foo", true, "foo option");

        CommandLine cmd = new DefaultParser().parse(options, new String[] {"--foo", "bar"});

        assertTrue(cmd.hasOption("f"));
        assertEquals("bar", cmd.getOptionValue("foo"));
    }

    @Test
    public void testLongOptionWithEquals() throws Exception
    {
        Options options = new Options();
        options.addOption("f", "foo", true, "foo option");

        CommandLine cmd = new DefaultParser().parse(options, new String[] {"--foo=bar"});

        assertEquals("bar", cmd.getOptionValue("f"));
    }

    @Test
    public void testShortOptionWithEquals() throws Exception
    {
        Options options = new Options();
        options.addOption("f", true, "foo option");

        CommandLine cmd = new DefaultParser().parse(options, new String[] {"-f=bar"});

        assertEquals("bar", cmd.getOptionValue("f"));
    }

    @Test
    public void testShortOptionConcatenatedValue() throws Exception
    {
        Options options = new Options();
        options.addOption("f", true, "foo option");

        CommandLine cmd = new DefaultParser().parse(options, new String[] {"-fbar"});

        assertEquals("bar", cmd.getOptionValue("f"));
    }

    @Test
    public void testPartialLongOptionMatch() throws Exception
    {
        Options options = new Options();
        options.addOption(null, "foo", false, "foo flag");

        CommandLine cmd = new DefaultParser().parse(options, new String[] {"--f"});

        assertTrue(cmd.hasOption("foo"));
    }

    @Test
    public void testAmbiguousLongOptionThrows()
    {
        Options options = new Options();
        options.addOption(null, "foobar", false, "first");
        options.addOption(null, "foobaz", false, "second");

        try
        {
            new DefaultParser().parse(options, new String[] {"--foo"});
            fail("expected AmbiguousOptionException");
        }
        catch (AmbiguousOptionException e)
        {
            assertEquals("--foo", e.getOption());
            assertEquals(2, e.getMatchingOptions().size());
        }
        catch (ParseException e)
        {
            fail("expected AmbiguousOptionException, got " + e);
        }
    }

    @Test
    public void testUnrecognizedOptionThrows()
    {
        Options options = new Options();
        options.addOption("a", false, "a flag");

        try
        {
            new DefaultParser().parse(options, new String[] {"-z"});
            fail("expected UnrecognizedOptionException");
        }
        catch (UnrecognizedOptionException e)
        {
            assertEquals("-z", e.getOption());
        }
        catch (ParseException e)
        {
            fail("expected UnrecognizedOptionException, got " + e);
        }
    }

    @Test
    public void testUnrecognizedOptionWithStopAtNonOptionAddedAsArg() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "a flag");

        CommandLine cmd = new DefaultParser().parse(options, new String[] {"-z", "foo"}, true);

        assertFalse(cmd.hasOption("a"));
        assertEquals(2, cmd.getArgList().size());
        assertEquals("-z", cmd.getArgList().get(0));
        assertEquals("foo", cmd.getArgList().get(1));
    }

    @Test
    public void testNonOptionWithoutStopAtNonOptionIsAddedAsArg() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "a flag");

        CommandLine cmd = new DefaultParser().parse(options, new String[] {"-a", "bar"});

        assertTrue(cmd.hasOption("a"));
        assertEquals(1, cmd.getArgList().size());
        assertEquals("bar", cmd.getArgList().get(0));
    }

    @Test
    public void testMissingRequiredArgumentThrows()
    {
        Options options = new Options();
        options.addOption("f", true, "foo option");

        try
        {
            new DefaultParser().parse(options, new String[] {"-f"});
            fail("expected MissingArgumentException");
        }
        catch (MissingArgumentException e)
        {
            assertEquals("f", e.getOption().getOpt());
        }
        catch (ParseException e)
        {
            fail("expected MissingArgumentException, got " + e);
        }
    }

    @Test
    public void testMissingRequiredOptionThrows()
    {
        Options options = new Options();
        options.addRequiredOption("f", "foo", false, "required flag");

        try
        {
            new DefaultParser().parse(options, new String[0]);
            fail("expected MissingOptionException");
        }
        catch (MissingOptionException e)
        {
            List missing = e.getMissingOptions();
            assertEquals(1, missing.size());
            assertEquals("f", missing.get(0));
        }
        catch (ParseException e)
        {
            fail("expected MissingOptionException, got " + e);
        }
    }

    @Test
    public void testDoubleDashStopsParsing() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "a flag");

        CommandLine cmd = new DefaultParser().parse(options, new String[] {"--", "-a", "foo"});

        assertFalse(cmd.hasOption("a"));
        assertEquals(2, cmd.getArgList().size());
        assertEquals("-a", cmd.getArgList().get(0));
        assertEquals("foo", cmd.getArgList().get(1));
    }

    @Test
    public void testSingleDashIsTreatedAsArgument() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "a flag");

        CommandLine cmd = new DefaultParser().parse(options, new String[] {"-"});

        assertEquals(1, cmd.getArgList().size());
        assertEquals("-", cmd.getArgList().get(0));
    }

    @Test
    public void testNegativeNumberTreatedAsArgumentValue() throws Exception
    {
        Options options = new Options();
        options.addOption("f", true, "foo option");

        CommandLine cmd = new DefaultParser().parse(options, new String[] {"-f", "-1"});

        assertEquals("-1", cmd.getOptionValue("f"));
    }

    @Test
    public void testNegativeNumberWithoutMatchingOptionThrows()
    {
        Options options = new Options();
        options.addOption("a", false, "a flag");

        try
        {
            new DefaultParser().parse(options, new String[] {"-1"});
            fail("expected UnrecognizedOptionException");
        }
        catch (UnrecognizedOptionException e)
        {
            assertEquals("-1", e.getOption());
        }
        catch (ParseException e)
        {
            fail("expected UnrecognizedOptionException, got " + e);
        }
    }

    @Test
    public void testConcatenatedShortOptions() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "a flag");
        options.addOption("b", false, "b flag");
        options.addOption("c", false, "c flag");

        CommandLine cmd = new DefaultParser().parse(options, new String[] {"-abc"});

        assertTrue(cmd.hasOption("a"));
        assertTrue(cmd.hasOption("b"));
        assertTrue(cmd.hasOption("c"));
    }

    @Test
    public void testOptionGroupAlreadySelectedThrows()
    {
        OptionGroup group = new OptionGroup();
        Option opt1 = new Option("a", false, "a flag");
        Option opt2 = new Option("b", false, "b flag");
        group.addOption(opt1);
        group.addOption(opt2);

        Options options = new Options();
        options.addOptionGroup(group);

        try
        {
            new DefaultParser().parse(options, new String[] {"-a", "-b"});
            fail("expected AlreadySelectedException");
        }
        catch (AlreadySelectedException e)
        {
            assertEquals("b", e.getOption().getOpt());
            assertEquals("a", e.getOptionGroup().getSelected());
        }
        catch (ParseException e)
        {
            fail("expected AlreadySelectedException, got " + e);
        }
    }

    @Test
    public void testPropertiesSetsDefaultOption() throws Exception
    {
        Options options = new Options();
        options.addOption("f", true, "foo option");

        Properties properties = new Properties();
        properties.setProperty("f", "default-value");

        CommandLine cmd = new DefaultParser().parse(options, new String[0], properties);

        assertEquals("default-value", cmd.getOptionValue("f"));
    }

    @Test
    public void testPropertiesDoesNotOverrideExplicitOption() throws Exception
    {
        Options options = new Options();
        options.addOption("f", true, "foo option");

        Properties properties = new Properties();
        properties.setProperty("f", "default-value");

        CommandLine cmd = new DefaultParser().parse(options, new String[] {"-f", "explicit"}, properties);

        assertEquals("explicit", cmd.getOptionValue("f"));
    }

    @Test
    public void testPropertiesWithUnknownOptionThrows()
    {
        Options options = new Options();

        Properties properties = new Properties();
        properties.setProperty("unknown", "true");

        try
        {
            new DefaultParser().parse(options, new String[0], properties);
            fail("expected UnrecognizedOptionException");
        }
        catch (UnrecognizedOptionException e)
        {
            assertEquals("unknown", e.getOption());
        }
        catch (ParseException e)
        {
            fail("expected UnrecognizedOptionException, got " + e);
        }
    }

    @Test
    public void testPropertiesBooleanFlagNotYesTrueOneIgnored() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "a flag");

        Properties properties = new Properties();
        properties.setProperty("a", "no");

        CommandLine cmd = new DefaultParser().parse(options, new String[0], properties);

        assertFalse(cmd.hasOption("a"));
    }

    @Test
    public void testPropertiesBooleanFlagTrueIsSet() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "a flag");

        Properties properties = new Properties();
        properties.setProperty("a", "true");

        CommandLine cmd = new DefaultParser().parse(options, new String[0], properties);

        assertTrue(cmd.hasOption("a"));
    }

    @Test
    public void testJavaPropertyStyleOption() throws Exception
    {
        Options options = new Options();
        Option property = new Option("D", "use value for property");
        property.setArgs(2);
        property.setValueSeparator('=');
        options.addOption(property);

        CommandLine cmd = new DefaultParser().parse(options, new String[] {"-Dkey=value"});

        Properties props = cmd.getOptionProperties("D");
        assertEquals("value", props.getProperty("key"));
    }

    @Test
    public void testNullArgumentsArrayProducesEmptyCommandLine() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "a flag");

        CommandLine cmd = new DefaultParser().parse(options, null);

        assertFalse(cmd.hasOption("a"));
        assertEquals(0, cmd.getArgList().size());
        assertArrayEquals(new String[0], cmd.getArgs());
    }

    @Test
    public void testThreeArgOverloadDelegatesWithStopAtNonOptionTrue() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "a flag");

        CommandLine cmd = new DefaultParser().parse(options, new String[] {"-z"}, true);

        assertEquals(1, cmd.getArgList().size());
        assertEquals("-z", cmd.getArgList().get(0));
    }

    @Test
    public void testLongPrefixWithAttachedValue() throws Exception
    {
        Options options = new Options();
        options.addOption(null, "Xmx", true, "max memory");

        CommandLine cmd = new DefaultParser().parse(options, new String[] {"-Xmx512m"});

        assertEquals("512m", cmd.getOptionValue("Xmx"));
    }

    @Test
    public void testNoArgumentsReturnsEmptyCommandLine() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "a flag");

        CommandLine cmd = new DefaultParser().parse(options, new String[0]);

        assertNull(cmd.getOptionValue("a"));
        assertFalse(cmd.hasOption("a"));
        assertEquals(0, cmd.getOptions().length);
    }
}
