package org.apache.commons.lang.time;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.text.FieldPosition;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.Test;

/**
 * Self-contained tests for {@link FastDateFormat}, based solely on the
 * documented contract in the generated javadoc.
 */
public class FastDateFormatAgentTest {

    private static final Locale LOCALE = Locale.US;
    private static final TimeZone ZONE_A = TimeZone.getTimeZone("America/Los_Angeles");
    private static final TimeZone ZONE_B = TimeZone.getTimeZone("Asia/Tokyo");

    private Calendar fixedCalendar(TimeZone zone) {
        Calendar cal = new GregorianCalendar(zone, LOCALE);
        cal.clear();
        cal.set(2021, Calendar.MARCH, 15, 10, 30, 45);
        cal.set(Calendar.MILLISECOND, 123);
        return cal;
    }

    // ------------------------------------------------------------------
    // Style constants
    // ------------------------------------------------------------------

    @Test
    public void testStyleConstantsAreMutuallyDistinct() {
        int[] styles = {FastDateFormat.FULL, FastDateFormat.LONG,
                FastDateFormat.MEDIUM, FastDateFormat.SHORT};
        for (int i = 0; i < styles.length; i++) {
            for (int j = i + 1; j < styles.length; j++) {
                assertTrue("styles must be distinct", styles[i] != styles[j]);
            }
        }
    }

    // ------------------------------------------------------------------
    // Protected constructor (same package access)
    // ------------------------------------------------------------------

    @Test
    public void testConstructorNullPatternThrows() {
        try {
            new FastDateFormat(null, null, null);
            fail("expected IllegalArgumentException for null pattern");
        } catch (IllegalArgumentException expected) {
            // documented
        }
    }

    // @Test  // pruned: failed on the fixed version
    public void testConstructorInvalidPatternThrows() {
        try {
            new FastDateFormat("yyyy-MM-dd'", null, null);
            fail("expected IllegalArgumentException for unterminated quote");
        } catch (IllegalArgumentException expected) {
            // documented
        }
    }

    @Test
    public void testConstructorValidPatternStoresPattern() {
        FastDateFormat fdf = new FastDateFormat("yyyy", null, null);
        assertEquals("yyyy", fdf.getPattern());
    }

    @Test
    public void testConstructorNullTimeZoneAndLocaleUseDefaults() {
        FastDateFormat fdf = new FastDateFormat("yyyy", null, null);
        assertEquals(TimeZone.getDefault(), fdf.getTimeZone());
        assertEquals(Locale.getDefault(), fdf.getLocale());
    }

    @Test
    public void testConstructorExplicitTimeZoneAndLocaleAreStored() {
        FastDateFormat fdf = new FastDateFormat("yyyy-MM-dd", ZONE_B, Locale.GERMANY);
        assertEquals(ZONE_B, fdf.getTimeZone());
        assertEquals(Locale.GERMANY, fdf.getLocale());
    }

    // ------------------------------------------------------------------
    // getInstance() factory family
    // ------------------------------------------------------------------

    @Test
    public void testGetInstanceDefaultIsUsable() {
        FastDateFormat fdf = FastDateFormat.getInstance();
        assertNotNull(fdf);
        assertNotNull(fdf.getPattern());
        String formatted = fdf.format(new Date(0L));
        assertNotNull(formatted);
        assertFalse(formatted.length() == 0);
    }

    @Test
    public void testGetInstancePatternOnly() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd");
        assertEquals("yyyy-MM-dd", fdf.getPattern());
        assertEquals(Locale.getDefault(), fdf.getLocale());
        assertEquals(TimeZone.getDefault(), fdf.getTimeZone());
    }

    // @Test  // pruned: failed on the fixed version
    public void testGetInstancePatternInvalidThrows() {
        try {
            FastDateFormat.getInstance("yyyy-MM-dd'");
            fail("expected IllegalArgumentException for invalid pattern");
        } catch (IllegalArgumentException expected) {
            // documented
        }
    }

    @Test
    public void testGetInstancePatternAndTimeZone() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss", ZONE_A);
        assertEquals(ZONE_A, fdf.getTimeZone());
        assertEquals(Locale.getDefault(), fdf.getLocale());
    }

    @Test
    public void testGetInstancePatternAndLocale() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd", Locale.GERMANY);
        assertEquals(Locale.GERMANY, fdf.getLocale());
        assertEquals(TimeZone.getDefault(), fdf.getTimeZone());
    }

    @Test
    public void testGetInstancePatternTimeZoneLocaleNullPatternThrows() {
        try {
            FastDateFormat.getInstance(null, ZONE_A, LOCALE);
            fail("expected IllegalArgumentException for null pattern");
        } catch (IllegalArgumentException expected) {
            // documented explicitly for the 3-arg overload
        }
    }

    @Test
    public void testGetInstancePatternTimeZoneLocaleFull() {
        String pattern = "yyyy-MM-dd HH:mm:ss.SSS";
        FastDateFormat fdf = FastDateFormat.getInstance(pattern, ZONE_B, Locale.GERMANY);
        assertEquals(pattern, fdf.getPattern());
        assertEquals(ZONE_B, fdf.getTimeZone());
        assertEquals(Locale.GERMANY, fdf.getLocale());

        Date date = new Date(1000000000000L);
        SimpleDateFormat sdf = new SimpleDateFormat(pattern, Locale.GERMANY);
        sdf.setTimeZone(ZONE_B);
        assertEquals(sdf.format(date), fdf.format(date));
    }

    // ------------------------------------------------------------------
    // getDateInstance / getTimeInstance / getDateTimeInstance style families
    // ------------------------------------------------------------------

    // @Test  // pruned: failed on the fixed version
    public void testGetDateInstanceStylesProduceCrossCheckedOutput() {
        int[] styles = {FastDateFormat.FULL, FastDateFormat.LONG,
                FastDateFormat.MEDIUM, FastDateFormat.SHORT};
        Date date = new Date(1500000000000L);
        for (int i = 0; i < styles.length; i++) {
            FastDateFormat fdf = FastDateFormat.getDateInstance(styles[i], ZONE_A, LOCALE);
            assertNotNull(fdf.getPattern());
            SimpleDateFormat sdf = new SimpleDateFormat(fdf.getPattern(), LOCALE);
            sdf.setTimeZone(ZONE_A);
            assertEquals(sdf.format(date), fdf.format(date));
        }
    }

    @Test
    public void testGetTimeInstanceStylesProduceCrossCheckedOutput() {
        int[] styles = {FastDateFormat.FULL, FastDateFormat.LONG,
                FastDateFormat.MEDIUM, FastDateFormat.SHORT};
        Date date = new Date(1500000000000L);
        for (int i = 0; i < styles.length; i++) {
            FastDateFormat fdf = FastDateFormat.getTimeInstance(styles[i], ZONE_A, LOCALE);
            assertNotNull(fdf.getPattern());
            SimpleDateFormat sdf = new SimpleDateFormat(fdf.getPattern(), LOCALE);
            sdf.setTimeZone(ZONE_A);
            assertEquals(sdf.format(date), fdf.format(date));
        }
    }

    // @Test  // pruned: failed on the fixed version
    public void testGetDateTimeInstanceProducesCrossCheckedOutput() {
        Date date = new Date(1500000000000L);
        FastDateFormat fdf = FastDateFormat.getDateTimeInstance(
                FastDateFormat.MEDIUM, FastDateFormat.SHORT, ZONE_A, LOCALE);
        assertNotNull(fdf.getPattern());
        SimpleDateFormat sdf = new SimpleDateFormat(fdf.getPattern(), LOCALE);
        sdf.setTimeZone(ZONE_A);
        assertEquals(sdf.format(date), fdf.format(date));
    }

    @Test
    public void testGetDateInstanceNoTimeZoneOrLocaleUsesDefaults() {
        FastDateFormat fdf = FastDateFormat.getDateInstance(FastDateFormat.SHORT);
        assertEquals(TimeZone.getDefault(), fdf.getTimeZone());
        assertEquals(Locale.getDefault(), fdf.getLocale());
    }

    @Test
    public void testGetTimeInstanceNoTimeZoneOrLocaleUsesDefaults() {
        FastDateFormat fdf = FastDateFormat.getTimeInstance(FastDateFormat.SHORT);
        assertEquals(TimeZone.getDefault(), fdf.getTimeZone());
        assertEquals(Locale.getDefault(), fdf.getLocale());
    }

    // ------------------------------------------------------------------
    // format(long)
    // ------------------------------------------------------------------

    @Test
    public void testFormatMillisMatchesSimpleDateFormat() {
        String pattern = "yyyy/MM/dd HH:mm:ss";
        FastDateFormat fdf = FastDateFormat.getInstance(pattern, ZONE_A, LOCALE);
        long millis = 1234567890123L;
        SimpleDateFormat sdf = new SimpleDateFormat(pattern, LOCALE);
        sdf.setTimeZone(ZONE_A);
        assertEquals(sdf.format(new Date(millis)), fdf.format(millis));
    }

    @Test
    public void testFormatMillisIntoBufferAppendsAndReturnsSameBuffer() {
        String pattern = "yyyy-MM-dd";
        FastDateFormat fdf = FastDateFormat.getInstance(pattern, ZONE_A, LOCALE);
        long millis = 0L;
        StringBuffer buf = new StringBuffer("prefix:");
        StringBuffer result = fdf.format(millis, buf);
        assertSame(buf, result);
        assertEquals("prefix:" + fdf.format(millis), result.toString());
    }

    // ------------------------------------------------------------------
    // format(Date)
    // ------------------------------------------------------------------

    @Test
    public void testFormatDateMatchesSimpleDateFormat() {
        String pattern = "dd MMM yyyy";
        FastDateFormat fdf = FastDateFormat.getInstance(pattern, ZONE_B, LOCALE);
        Date date = new Date(987654321000L);
        SimpleDateFormat sdf = new SimpleDateFormat(pattern, LOCALE);
        sdf.setTimeZone(ZONE_B);
        assertEquals(sdf.format(date), fdf.format(date));
    }

    @Test
    public void testFormatDateIntoBufferAppendsAndReturnsSameBuffer() {
        String pattern = "yyyy-MM-dd";
        FastDateFormat fdf = FastDateFormat.getInstance(pattern, ZONE_A, LOCALE);
        Date date = new Date(42L);
        StringBuffer buf = new StringBuffer("X");
        StringBuffer result = fdf.format(date, buf);
        assertSame(buf, result);
        assertEquals("X" + fdf.format(date), result.toString());
    }

    // ------------------------------------------------------------------
    // format(Calendar) and the timeZoneOverridesCalendar contract
    // ------------------------------------------------------------------

    @Test
    public void testFormatCalendarMatchesSimpleDateFormatWhenZonesAgree() {
        String pattern = "yyyy-MM-dd HH:mm:ss";
        FastDateFormat fdf = FastDateFormat.getInstance(pattern, ZONE_A, LOCALE);
        Calendar cal = fixedCalendar(ZONE_A);
        SimpleDateFormat sdf = new SimpleDateFormat(pattern, LOCALE);
        sdf.setTimeZone(ZONE_A);
        assertEquals(sdf.format(cal.getTime()), fdf.format(cal));
    }

    @Test
    public void testFormatCalendarIntoBufferAppendsAndReturnsSameBuffer() {
        String pattern = "yyyy-MM-dd";
        FastDateFormat fdf = FastDateFormat.getInstance(pattern, ZONE_A, LOCALE);
        Calendar cal = fixedCalendar(ZONE_A);
        StringBuffer buf = new StringBuffer("cal:");
        StringBuffer result = fdf.format(cal, buf);
        assertSame(buf, result);
        assertEquals("cal:" + fdf.format(cal), result.toString());
    }

    // @Test  // pruned: failed on the fixed version
    public void testTimeZoneOverridesCalendarTrueWhenFormatterHasNoExplicitZone() {
        String pattern = "yyyy-MM-dd HH:mm:ss";
        FastDateFormat fdf = FastDateFormat.getInstance(pattern, LOCALE);
        assertTrue(fdf.getTimeZoneOverridesCalendar());

        Calendar cal = fixedCalendar(ZONE_A);
        SimpleDateFormat sdf = new SimpleDateFormat(pattern, LOCALE);
        sdf.setTimeZone(ZONE_A);
        assertEquals(sdf.format(cal.getTime()), fdf.format(cal));
    }

    // @Test  // pruned: failed on the fixed version
    public void testTimeZoneOverridesCalendarFalseWhenFormatterHasExplicitZone() {
        String pattern = "yyyy-MM-dd HH:mm:ss";
        FastDateFormat fdf = FastDateFormat.getInstance(pattern, ZONE_B, LOCALE);
        assertFalse(fdf.getTimeZoneOverridesCalendar());

        Calendar cal = fixedCalendar(ZONE_A);
        SimpleDateFormat sdf = new SimpleDateFormat(pattern, LOCALE);
        sdf.setTimeZone(ZONE_B);
        assertEquals(sdf.format(cal.getTime()), fdf.format(cal));
    }

    // ------------------------------------------------------------------
    // format(Object, StringBuffer, FieldPosition)
    // ------------------------------------------------------------------

    @Test
    public void testFormatObjectAcceptsDate() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd", ZONE_A, LOCALE);
        Date date = new Date(555000L);
        StringBuffer buf = new StringBuffer();
        StringBuffer result = fdf.format((Object) date, buf, new FieldPosition(0));
        assertSame(buf, result);
        assertEquals(fdf.format(date), result.toString());
    }

    @Test
    public void testFormatObjectAcceptsCalendar() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd", ZONE_A, LOCALE);
        Calendar cal = fixedCalendar(ZONE_A);
        StringBuffer buf = new StringBuffer();
        StringBuffer result = fdf.format((Object) cal, buf, new FieldPosition(0));
        assertSame(buf, result);
        assertEquals(fdf.format(cal), result.toString());
    }

    @Test
    public void testFormatObjectAcceptsLongMillis() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd", ZONE_A, LOCALE);
        Long millis = new Long(123456789L);
        StringBuffer buf = new StringBuffer();
        StringBuffer result = fdf.format((Object) millis, buf, new FieldPosition(0));
        assertSame(buf, result);
        assertEquals(fdf.format(millis.longValue()), result.toString());
    }

    @Test
    public void testFormatObjectFieldPositionIsIgnored() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd", ZONE_A, LOCALE);
        Date date = new Date(555000L);
        FieldPosition pos = new FieldPosition(0);
        StringBuffer result1 = fdf.format((Object) date, new StringBuffer(), pos);
        StringBuffer result2 = fdf.format((Object) date, new StringBuffer(), new FieldPosition(0));
        assertEquals(result2.toString(), result1.toString());
    }

    @Test
    public void testFormatObjectRejectsUnsupportedType() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd", ZONE_A, LOCALE);
        try {
            fdf.format((Object) "not a date", new StringBuffer(), new FieldPosition(0));
            fail("expected an exception for an unsupported object type");
        } catch (Exception expected) {
            // only Date, Calendar and Long are documented as supported
        }
    }

    @Test
    public void testFormatObjectRejectsNull() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd", ZONE_A, LOCALE);
        try {
            fdf.format((Object) null, new StringBuffer(), new FieldPosition(0));
            fail("expected an exception for a null object");
        } catch (Exception expected) {
            // only Date, Calendar and Long are documented as supported
        }
    }

    // ------------------------------------------------------------------
    // parseObject - parsing not supported
    // ------------------------------------------------------------------

    @Test
    public void testParseObjectAlwaysReturnsNull() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd", ZONE_A, LOCALE);
        Object result = fdf.parseObject("2021-03-15", new ParsePosition(0));
        assertNull(result);
    }

    @Test
    public void testParseObjectReturnsNullForEmptySource() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd", ZONE_A, LOCALE);
        Object result = fdf.parseObject("", new ParsePosition(0));
        assertNull(result);
    }

    // ------------------------------------------------------------------
    // getPattern / getTimeZone / getLocale accessors
    // ------------------------------------------------------------------

    @Test
    public void testGetPatternReturnsConstructionPattern() {
        FastDateFormat fdf = FastDateFormat.getInstance("HH:mm:ss", ZONE_A, LOCALE);
        assertEquals("HH:mm:ss", fdf.getPattern());
    }

    @Test
    public void testGetTimeZoneReturnsConstructionZone() {
        FastDateFormat fdf = FastDateFormat.getInstance("HH:mm:ss", ZONE_B, LOCALE);
        assertEquals(ZONE_B, fdf.getTimeZone());
    }

    @Test
    public void testGetLocaleReturnsConstructionLocale() {
        FastDateFormat fdf = FastDateFormat.getInstance("HH:mm:ss", ZONE_A, Locale.GERMANY);
        assertEquals(Locale.GERMANY, fdf.getLocale());
    }

    // ------------------------------------------------------------------
    // getMaxLengthEstimate
    // ------------------------------------------------------------------

    @Test
    public void testGetMaxLengthEstimateIsPositive() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd'T'HH:mm:ss.SSS", ZONE_A, LOCALE);
        assertTrue(fdf.getMaxLengthEstimate() > 0);
    }

    @Test
    public void testGetMaxLengthEstimateBoundsNumericOnlyPattern() {
        String pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS";
        FastDateFormat fdf = FastDateFormat.getInstance(pattern, ZONE_A, LOCALE);
        Date date = new Date(1600000000000L);
        String formatted = fdf.format(date);
        assertTrue("formatted length " + formatted.length() + " should not exceed estimate "
                + fdf.getMaxLengthEstimate(), formatted.length() <= fdf.getMaxLengthEstimate());
    }

    // ------------------------------------------------------------------
    // equals / hashCode
    // ------------------------------------------------------------------

    @Test
    public void testEqualsReflexive() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd", ZONE_A, LOCALE);
        assertTrue(fdf.equals(fdf));
    }

    @Test
    public void testEqualsTrueForSamePatternZoneLocale() {
        FastDateFormat a = FastDateFormat.getInstance("yyyy-MM-dd", ZONE_A, LOCALE);
        FastDateFormat b = FastDateFormat.getInstance("yyyy-MM-dd", ZONE_A, LOCALE);
        assertTrue(a.equals(b));
        assertTrue(b.equals(a));
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    public void testEqualsFalseForDifferentPattern() {
        FastDateFormat a = FastDateFormat.getInstance("yyyy-MM-dd", ZONE_A, LOCALE);
        FastDateFormat b = FastDateFormat.getInstance("dd-MM-yyyy", ZONE_A, LOCALE);
        assertFalse(a.equals(b));
    }

    @Test
    public void testEqualsFalseForDifferentTimeZone() {
        FastDateFormat a = FastDateFormat.getInstance("yyyy-MM-dd", ZONE_A, LOCALE);
        FastDateFormat b = FastDateFormat.getInstance("yyyy-MM-dd", ZONE_B, LOCALE);
        assertFalse(a.equals(b));
    }

    @Test
    public void testEqualsFalseForDifferentLocale() {
        FastDateFormat a = FastDateFormat.getInstance("yyyy-MM-dd", ZONE_A, Locale.US);
        FastDateFormat b = FastDateFormat.getInstance("yyyy-MM-dd", ZONE_A, Locale.GERMANY);
        assertFalse(a.equals(b));
    }

    @Test
    public void testEqualsFalseForNull() {
        FastDateFormat a = FastDateFormat.getInstance("yyyy-MM-dd", ZONE_A, LOCALE);
        assertFalse(a.equals(null));
    }

    @Test
    public void testEqualsFalseForDifferentType() {
        FastDateFormat a = FastDateFormat.getInstance("yyyy-MM-dd", ZONE_A, LOCALE);
        assertFalse(a.equals("yyyy-MM-dd"));
    }

    // ------------------------------------------------------------------
    // toString
    // ------------------------------------------------------------------

    @Test
    public void testToStringIsNonEmptyAndStable() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd", ZONE_A, LOCALE);
        String s1 = fdf.toString();
        String s2 = fdf.toString();
        assertNotNull(s1);
        assertFalse(s1.length() == 0);
        assertEquals(s1, s2);
    }

    // ------------------------------------------------------------------
    // getTimeZoneDisplay (package-private static helper)
    // ------------------------------------------------------------------

    @Test
    public void testGetTimeZoneDisplayMatchesTimeZoneApi() {
        String expectedLong = ZONE_A.getDisplayName(false, TimeZone.LONG, LOCALE);
        String actualLong = FastDateFormat.getTimeZoneDisplay(ZONE_A, false, TimeZone.LONG, LOCALE);
        assertEquals(expectedLong, actualLong);

        String expectedShort = ZONE_A.getDisplayName(true, TimeZone.SHORT, LOCALE);
        String actualShort = FastDateFormat.getTimeZoneDisplay(ZONE_A, true, TimeZone.SHORT, LOCALE);
        assertEquals(expectedShort, actualShort);
    }

    // ------------------------------------------------------------------
    // protected helpers (same-package access): parsePattern / applyRules / init
    // ------------------------------------------------------------------

    @Test
    public void testParsePatternReturnsNonEmptyRuleList() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd", ZONE_A, LOCALE);
        List rules = fdf.parsePattern();
        assertNotNull(rules);
        assertFalse(rules.isEmpty());
    }

    @Test
    public void testApplyRulesAppendsFormattedCalendarToBuffer() {
        String pattern = "yyyy-MM-dd HH:mm:ss";
        FastDateFormat fdf = FastDateFormat.getInstance(pattern, ZONE_A, LOCALE);
        Calendar cal = fixedCalendar(ZONE_A);

        StringBuffer buf = new StringBuffer("prefix-");
        StringBuffer result = fdf.applyRules(cal, buf);

        assertSame(buf, result);
        assertEquals("prefix-" + fdf.format(cal), result.toString());
    }

    @Test
    public void testInitDoesNotChangeObservableFormattingBehavior() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd", ZONE_A, LOCALE);
        long millis = 123456789L;
        String before = fdf.format(millis);
        fdf.init();
        String after = fdf.format(millis);
        assertEquals(before, after);
    }
}
