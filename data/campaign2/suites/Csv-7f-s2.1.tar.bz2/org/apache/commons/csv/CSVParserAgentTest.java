package org.apache.commons.csv;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringReader;
import java.io.Writer;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.junit.Test;

/**
 * Self-contained tests for {@link CSVParser}, based solely on its documented
 * contract.
 */
public class CSVParserAgentTest {

    private File writeTempCsv(String content) throws IOException {
        File file = File.createTempFile("CSVParserAgentTest", ".csv");
        file.deleteOnExit();
        Writer writer = new FileWriter(file);
        try {
            writer.write(content);
        } finally {
            writer.close();
        }
        return file;
    }

    // ---- constructor ----------------------------------------------------

    @Test
    public void testConstructorNullReaderThrows() {
        try {
            new CSVParser(null, CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException for null reader");
        } catch (IllegalArgumentException expected) {
            // documented
        } catch (IOException e) {
            fail("Did not expect IOException: " + e);
        }
    }

    @Test
    public void testConstructorNullFormatThrows() {
        try {
            new CSVParser(new StringReader("a,b"), null);
            fail("Expected IllegalArgumentException for null format");
        } catch (IllegalArgumentException expected) {
            // documented
        } catch (IOException e) {
            fail("Did not expect IOException: " + e);
        }
    }

    @Test
    public void testConstructorWithValidArguments() throws IOException {
        CSVParser parser = new CSVParser(new StringReader("a,b\nc,d\n"), CSVFormat.DEFAULT);
        try {
            assertFalse(parser.isClosed());
            assertEquals(0, parser.getRecordNumber());
            assertEquals(0, parser.getCurrentLineNumber());
        } finally {
            parser.close();
        }
    }

    // ---- static factory methods -----------------------------------------

    @Test
    public void testParseStringNullStringThrows() throws IOException {
        try {
            CSVParser.parse((String) null, CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException for null string");
        } catch (IllegalArgumentException expected) {
            // documented
        }
    }

    @Test
    public void testParseStringNullFormatThrows() throws IOException {
        try {
            CSVParser.parse("a,b", null);
            fail("Expected IllegalArgumentException for null format");
        } catch (IllegalArgumentException expected) {
            // documented
        }
    }

    @Test
    public void testParseStringHappyPath() throws IOException {
        CSVParser parser = CSVParser.parse("a,b,c\n1,2,3\n", CSVFormat.DEFAULT);
        try {
            List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("3", records.get(1).get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testParseFileNullFileThrows() throws IOException {
        try {
            CSVParser.parse((File) null, CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException for null file");
        } catch (IllegalArgumentException expected) {
            // documented
        }
    }

    @Test
    public void testParseFileNullFormatThrows() throws IOException {
        File file = writeTempCsv("a,b\n1,2\n");
        try {
            CSVParser.parse(file, null);
            fail("Expected IllegalArgumentException for null format");
        } catch (IllegalArgumentException expected) {
            // documented
        } finally {
            file.delete();
        }
    }

    @Test
    public void testParseFileHappyPath() throws IOException {
        File file = writeTempCsv("x,y\n10,20\n30,40\n");
        CSVParser parser = null;
        try {
            parser = CSVParser.parse(file, CSVFormat.DEFAULT);
            List<CSVRecord> records = parser.getRecords();
            assertEquals(3, records.size());
            assertEquals("30", records.get(2).get(0));
        } finally {
            if (parser != null) {
                parser.close();
            }
            file.delete();
        }
    }

    @Test
    public void testParseUrlNullUrlThrows() throws IOException {
        try {
            CSVParser.parse((URL) null, Charset.forName("UTF-8"), CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException for null url");
        } catch (IllegalArgumentException expected) {
            // documented
        }
    }

    @Test
    public void testParseUrlNullCharsetThrows() throws IOException {
        File file = writeTempCsv("a,b\n1,2\n");
        try {
            URL url = file.toURI().toURL();
            CSVParser.parse(url, null, CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException for null charset");
        } catch (IllegalArgumentException expected) {
            // documented
        } finally {
            file.delete();
        }
    }

    @Test
    public void testParseUrlNullFormatThrows() throws IOException {
        File file = writeTempCsv("a,b\n1,2\n");
        try {
            URL url = file.toURI().toURL();
            CSVParser.parse(url, Charset.forName("UTF-8"), null);
            fail("Expected IllegalArgumentException for null format");
        } catch (IllegalArgumentException expected) {
            // documented
        } finally {
            file.delete();
        }
    }

    @Test
    public void testParseUrlHappyPath() throws IOException {
        File file = writeTempCsv("p,q\nfoo,bar\n");
        CSVParser parser = null;
        try {
            URL url = file.toURI().toURL();
            parser = CSVParser.parse(url, Charset.forName("UTF-8"), CSVFormat.DEFAULT);
            List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("bar", records.get(1).get(1));
        } finally {
            if (parser != null) {
                parser.close();
            }
            file.delete();
        }
    }

    // ---- getRecords() -----------------------------------------------------

    @Test
    public void testGetRecordsEmptyInput() throws IOException {
        CSVParser parser = CSVParser.parse("", CSVFormat.DEFAULT);
        try {
            List<CSVRecord> records = parser.getRecords();
            assertNotNull(records);
            assertTrue(records.isEmpty());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetRecordsStartsAtCurrentPosition() throws IOException {
        CSVParser parser = CSVParser.parse("a,b\nc,d\ne,f\n", CSVFormat.DEFAULT);
        try {
            Iterator<CSVRecord> it = parser.iterator();
            CSVRecord first = it.next();
            assertEquals("a", first.get(0));

            List<CSVRecord> rest = parser.getRecords();
            assertEquals(2, rest.size());
            assertEquals("c", rest.get(0).get(0));
            assertEquals("e", rest.get(1).get(0));
        } finally {
            parser.close();
        }
    }

    // @Test  // pruned: failed on the fixed version
    public void testGetRecordsWithCollectionReturnsSameInstance() throws IOException {
        CSVParser parser = CSVParser.parse("x,y\n1,2\n3,4\n", CSVFormat.DEFAULT);
        try {
            List<CSVRecord> target = new ArrayList<CSVRecord>();
            List<CSVRecord> result = parser.getRecords(target);
            assertSame(target, result);
            assertEquals(2, result.size());
            assertEquals("1", result.get(0).get(0));
            assertEquals("4", result.get(1).get(1));
        } finally {
            parser.close();
        }
    }

    // ---- getHeaderMap() -----------------------------------------------------

    @Test
    public void testGetHeaderMapContentAndColumnOrder() throws IOException {
        CSVFormat format = CSVFormat.DEFAULT.withHeader("name", "age");
        CSVParser parser = CSVParser.parse("alice,30\nbob,40\n", format);
        try {
            Map<String, Integer> headerMap = parser.getHeaderMap();
            assertEquals(2, headerMap.size());
            assertEquals(Integer.valueOf(0), headerMap.get("name"));
            assertEquals(Integer.valueOf(1), headerMap.get("age"));

            List<CSVRecord> records = parser.getRecords();
            assertEquals("alice", records.get(0).get("name"));
            assertEquals("40", records.get(1).get("age"));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetHeaderMapReturnsACopy() throws IOException {
        CSVFormat format = CSVFormat.DEFAULT.withHeader("a", "b");
        CSVParser parser = CSVParser.parse("1,2\n", format);
        try {
            Map<String, Integer> headerMap = parser.getHeaderMap();
            headerMap.put("injected", 99);

            Map<String, Integer> secondCopy = parser.getHeaderMap();
            assertEquals(2, secondCopy.size());
            assertFalse(secondCopy.containsKey("injected"));
        } finally {
            parser.close();
        }
    }

    // ---- getCurrentLineNumber() / getRecordNumber() ------------------------

    @Test
    public void testLineAndRecordNumbersAdvanceTogetherForSingleLineRecords() throws IOException {
        CSVParser parser = CSVParser.parse("a,b\nc,d\ne,f\n", CSVFormat.DEFAULT);
        try {
            assertEquals(0, parser.getCurrentLineNumber());
            assertEquals(0, parser.getRecordNumber());

            Iterator<CSVRecord> it = parser.iterator();

            it.next();
            assertEquals(1, parser.getCurrentLineNumber());
            assertEquals(1, parser.getRecordNumber());

            it.next();
            assertEquals(2, parser.getCurrentLineNumber());
            assertEquals(2, parser.getRecordNumber());

            it.next();
            assertEquals(3, parser.getCurrentLineNumber());
            assertEquals(3, parser.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testLineNumberDivergesFromRecordNumberForMultilineValues() throws IOException {
        // The single quoted value spans two physical lines, so after reading
        // this one record the line number should be 2 while the record
        // number is only 1, per the documented ATTENTION notes.
        CSVParser parser = CSVParser.parse("a,\"b\nc\"\nd,e\n", CSVFormat.DEFAULT);
        try {
            Iterator<CSVRecord> it = parser.iterator();

            CSVRecord first = it.next();
            assertEquals("b\nc", first.get(1));
            assertEquals(2, parser.getCurrentLineNumber());
            assertEquals(1, parser.getRecordNumber());

            CSVRecord second = it.next();
            assertEquals("d", second.get(0));
            assertEquals(3, parser.getCurrentLineNumber());
            assertEquals(2, parser.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    // ---- isClosed() / close() ----------------------------------------------

    @Test
    public void testIsClosedLifecycle() throws IOException {
        CSVParser parser = CSVParser.parse("a,b\n", CSVFormat.DEFAULT);
        assertFalse(parser.isClosed());
        parser.close();
        assertTrue(parser.isClosed());
    }

    @Test
    public void testCloseIsIdempotent() throws IOException {
        CSVParser parser = CSVParser.parse("a,b\n", CSVFormat.DEFAULT);
        parser.close();
        parser.close();
        assertTrue(parser.isClosed());
    }

    // ---- iterator() ---------------------------------------------------------

    @Test
    public void testIteratorBasicTraversal() throws IOException {
        CSVParser parser = CSVParser.parse("1,2\n3,4\n", CSVFormat.DEFAULT);
        try {
            Iterator<CSVRecord> it = parser.iterator();

            assertTrue(it.hasNext());
            CSVRecord first = it.next();
            assertEquals("1", first.get(0));
            assertEquals("2", first.get(1));

            assertTrue(it.hasNext());
            CSVRecord second = it.next();
            assertEquals("3", second.get(0));
            assertEquals("4", second.get(1));

            assertFalse(it.hasNext());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testIteratorNextThrowsWhenExhausted() throws IOException {
        CSVParser parser = CSVParser.parse("1,2\n", CSVFormat.DEFAULT);
        try {
            Iterator<CSVRecord> it = parser.iterator();
            it.next();
            assertFalse(it.hasNext());
            try {
                it.next();
                fail("Expected NoSuchElementException once the iterator is exhausted");
            } catch (NoSuchElementException expected) {
                // documented
            }
        } finally {
            parser.close();
        }
    }

    @Test
    public void testIteratorNextThrowsAfterParserClosed() throws IOException {
        CSVParser parser = CSVParser.parse("a,b\nc,d\n", CSVFormat.DEFAULT);
        Iterator<CSVRecord> it = parser.iterator();
        parser.close();
        try {
            it.next();
            fail("Expected NoSuchElementException once the parser is closed");
        } catch (NoSuchElementException expected) {
            // documented: "If the parser is closed a call to next() will
            // throw a NoSuchElementException."
        }
    }

    // ---- nextRecord() (package-private, reachable from same package) ------

    @Test
    public void testNextRecordReturnsRecordsThenNullAtEndOfStream() throws IOException {
        CSVParser parser = new CSVParser(new StringReader("a,b\nc,d\n"), CSVFormat.DEFAULT);
        try {
            CSVRecord first = parser.nextRecord();
            assertNotNull(first);
            assertEquals("a", first.get(0));
            assertEquals("b", first.get(1));

            CSVRecord second = parser.nextRecord();
            assertNotNull(second);
            assertEquals("c", second.get(0));
            assertEquals("d", second.get(1));

            CSVRecord third = parser.nextRecord();
            assertNull(third);
        } finally {
            parser.close();
        }
    }
}
