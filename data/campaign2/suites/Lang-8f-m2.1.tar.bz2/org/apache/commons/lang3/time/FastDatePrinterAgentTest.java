/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.text.FieldPosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.Test;

/**
 * Self-contained unit tests for {@link org.apache.commons.lang3.time.FastDatePrinter}.
 */
public class FastDatePrinterAgentTest {

    // 2014-02-03 05:06:07.008 GMT - a Monday, day 34 of the year.
    private static final long REFERENCE_MILLIS = 1391403967008L;
    // 2014-02-03 00:00:00.000 GMT - midnight on the same day.
    private static final long MIDNIGHT_MILLIS = 1391385600000L;

    private static final TimeZone GMT = TimeZone.getTimeZone("GMT");

    private static FastDatePrinter newPrinter(String pattern) {
        return new FastDatePrinter(pattern, GMT, Locale.US);
    }

    private static FastDatePrinter newPrinter(String pattern, TimeZone tz) {
        return new FastDatePrinter(pattern, tz, Locale.US);
    }

    @Test
    public void testFormatDate_fullPattern() {
        FastDatePrinter printer = newPrinter("yyyy-MM-dd HH:mm:ss.SSS");
        String result = printer.format(new Date(REFERENCE_MILLIS));
        assertEquals("2014-02-03 05:06:07.008", result);
    }

    @Test
    public void testFormatLong_matchesFormatDate() {
        FastDatePrinter printer = newPrinter("yyyy-MM-dd HH:mm:ss.SSS");
        assertEquals(printer.format(new Date(REFERENCE_MILLIS)), printer.format(REFERENCE_MILLIS));
    }

    @Test
    public void testFormatCalendar_usesCalendarFieldsDirectly() {
        // The printer's own timezone/locale is irrelevant to format(Calendar, ...):
        // the calendar's own fields are read as-is.
        FastDatePrinter printer = new FastDatePrinter("yyyy-MM-dd HH:mm:ss",
                TimeZone.getTimeZone("GMT+05:30"), Locale.US);
        Calendar cal = new GregorianCalendar(GMT, Locale.US);
        cal.clear();
        cal.set(2014, Calendar.FEBRUARY, 3, 5, 6, 7);
        assertEquals("2014-02-03 05:06:07", printer.format(cal));
    }

    @Test
    public void testFormatIntoSuppliedBuffer_returnsSameBuffer() {
        FastDatePrinter printer = newPrinter("yyyy");
        StringBuffer buf = new StringBuffer("prefix-");
        StringBuffer result = printer.format(new Date(REFERENCE_MILLIS), buf);
        assertTrue(result == buf);
        assertEquals("prefix-2014", result.toString());
    }

    @Test
    public void testFormatObject_date() {
        FastDatePrinter printer = newPrinter("yyyy");
        StringBuffer buf = new StringBuffer();
        StringBuffer result = printer.format((Object) new Date(REFERENCE_MILLIS), buf, new FieldPosition(0));
        assertTrue(result == buf);
        assertEquals("2014", buf.toString());
    }

    @Test
    public void testFormatObject_calendar() {
        FastDatePrinter printer = newPrinter("yyyy");
        Calendar cal = new GregorianCalendar(GMT, Locale.US);
        cal.setTimeInMillis(REFERENCE_MILLIS);
        StringBuffer buf = new StringBuffer();
        printer.format((Object) cal, buf, new FieldPosition(0));
        assertEquals("2014", buf.toString());
    }

    @Test
    public void testFormatObject_long() {
        FastDatePrinter printer = newPrinter("yyyy");
        StringBuffer buf = new StringBuffer();
        printer.format(Long.valueOf(REFERENCE_MILLIS), buf, new FieldPosition(0));
        assertEquals("2014", buf.toString());
    }

    @Test
    public void testFormatObject_unsupportedTypeThrows() {
        FastDatePrinter printer = newPrinter("yyyy");
        try {
            printer.format("not a date", new StringBuffer(), new FieldPosition(0));
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().indexOf("String") >= 0);
        }
    }

    @Test
    public void testFormatObject_nullThrowsWithNullMessage() {
        FastDatePrinter printer = newPrinter("yyyy");
        try {
            printer.format((Object) null, new StringBuffer(), new FieldPosition(0));
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().indexOf("<null>") >= 0);
        }
    }

    @Test
    public void testGetters() {
        FastDatePrinter printer = newPrinter("yyyy-MM-dd");
        assertEquals("yyyy-MM-dd", printer.getPattern());
        assertEquals(GMT, printer.getTimeZone());
        assertEquals(Locale.US, printer.getLocale());
        assertTrue(printer.getMaxLengthEstimate() >= "yyyy-MM-dd".length());
    }

    @Test
    public void testEqualsAndHashCode() {
        FastDatePrinter p1 = newPrinter("yyyy-MM-dd");
        FastDatePrinter p2 = newPrinter("yyyy-MM-dd");
        FastDatePrinter differentPattern = newPrinter("yyyy/MM/dd");
        FastDatePrinter differentZone = newPrinter("yyyy-MM-dd", TimeZone.getTimeZone("GMT+01:00"));
        FastDatePrinter differentLocale = new FastDatePrinter("yyyy-MM-dd", GMT, Locale.GERMANY);

        assertTrue(p1.equals(p2));
        assertTrue(p2.equals(p1));
        assertEquals(p1.hashCode(), p2.hashCode());

        assertFalse(p1.equals(differentPattern));
        assertFalse(p1.equals(differentZone));
        assertFalse(p1.equals(differentLocale));
        assertFalse(p1.equals(null));
        assertFalse(p1.equals("yyyy-MM-dd"));
    }

    @Test
    public void testToString() {
        FastDatePrinter printer = newPrinter("yyyy-MM-dd");
        String s = printer.toString();
        assertTrue(s.indexOf("yyyy-MM-dd") >= 0);
        assertTrue(s.indexOf("GMT") >= 0);
    }

    @Test
    public void testTwelveHourField_midnightAndNoonBoundaries() {
        FastDatePrinter printer = newPrinter("hh:mm:ss a");
        assertEquals("12:00:00 AM", printer.format(new Date(MIDNIGHT_MILLIS)));
        assertEquals("05:06:07 AM", printer.format(new Date(REFERENCE_MILLIS)));
        // noon the same day: midnight + 12 hours
        long noon = MIDNIGHT_MILLIS + 12L * 60L * 60L * 1000L;
        assertEquals("12:00:00 PM", printer.format(new Date(noon)));
    }

    @Test
    public void testTwentyFourHourField_midnightBoundary() {
        // 'k' maps hour-of-day 0 to 24, unlike 'H' which keeps 0.
        FastDatePrinter kPrinter = newPrinter("kk");
        FastDatePrinter hPrinter = newPrinter("HH");
        assertEquals("24", kPrinter.format(new Date(MIDNIGHT_MILLIS)));
        assertEquals("00", hPrinter.format(new Date(MIDNIGHT_MILLIS)));
        assertEquals("05", kPrinter.format(new Date(REFERENCE_MILLIS)));
    }

    @Test
    public void testYearPatterns() {
        // Per class javadoc, FastDatePrinter formats 'y' and 'yyy' like 'yyyy' (Java 7 behavior).
        assertEquals("2014", newPrinter("y").format(new Date(REFERENCE_MILLIS)));
        assertEquals("2014", newPrinter("yyy").format(new Date(REFERENCE_MILLIS)));
        assertEquals("2014", newPrinter("yyyy").format(new Date(REFERENCE_MILLIS)));
        assertEquals("14", newPrinter("yy").format(new Date(REFERENCE_MILLIS)));
    }

    @Test
    public void testYearPadding_smallAndLargeValues() {
        Calendar cal = new GregorianCalendar(GMT, Locale.US);
        cal.clear();
        cal.set(7, Calendar.JANUARY, 1);
        assertEquals("0007", newPrinter("yyyy").format(cal.getTime()));
        assertEquals("07", newPrinter("yy").format(cal.getTime()));

        Calendar bigYear = new GregorianCalendar(GMT, Locale.US);
        bigYear.clear();
        bigYear.set(12345, Calendar.JANUARY, 1);
        // value exceeds the padding width: full digits are used, not truncated.
        assertEquals("12345", newPrinter("yyyy").format(bigYear.getTime()));
    }

    @Test
    public void testMonthPatterns() {
        assertEquals("2", newPrinter("M").format(new Date(REFERENCE_MILLIS)));
        assertEquals("02", newPrinter("MM").format(new Date(REFERENCE_MILLIS)));
        assertEquals("Feb", newPrinter("MMM").format(new Date(REFERENCE_MILLIS)));
        assertEquals("February", newPrinter("MMMM").format(new Date(REFERENCE_MILLIS)));
    }

    @Test
    public void testDayOfWeekTextPatterns() {
        assertEquals("Mon", newPrinter("EEE").format(new Date(REFERENCE_MILLIS)));
        assertEquals("Monday", newPrinter("EEEE").format(new Date(REFERENCE_MILLIS)));
    }

    @Test
    public void testDayOfYearWeekAndDayOfWeekInMonth() {
        assertEquals("34", newPrinter("D").format(new Date(REFERENCE_MILLIS)));
        assertEquals("034", newPrinter("DDD").format(new Date(REFERENCE_MILLIS)));
        assertEquals("6", newPrinter("w").format(new Date(REFERENCE_MILLIS)));
        assertEquals("2", newPrinter("W").format(new Date(REFERENCE_MILLIS)));
        assertEquals("1", newPrinter("F").format(new Date(REFERENCE_MILLIS)));
    }

    @Test
    public void testEraAndAmPmMarkers() {
        assertEquals("AD", newPrinter("G").format(new Date(REFERENCE_MILLIS)));
        assertEquals("AM", newPrinter("a").format(new Date(REFERENCE_MILLIS)));
        long noon = MIDNIGHT_MILLIS + 13L * 60L * 60L * 1000L;
        assertEquals("PM", newPrinter("a").format(new Date(noon)));
    }

    @Test
    public void testLiteralQuoting() {
        assertEquals("T05", newPrinter("'T'HH").format(new Date(REFERENCE_MILLIS)));
        assertEquals("'", newPrinter("''").format(new Date(REFERENCE_MILLIS)));
    }

    @Test
    public void testUnterminatedLiteralQuoteIsTreatedAsText() {
        // A trailing unterminated quote does not throw; everything after it is literal text.
        FastDatePrinter printer = newPrinter("HH:mm'abc");
        assertEquals("05:06abc", printer.format(new Date(REFERENCE_MILLIS)));
    }

    @Test
    public void testIllegalPatternCharacterThrows() {
        try {
            newPrinter("q");
            fail("Expected IllegalArgumentException for illegal pattern component");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().indexOf("Illegal pattern component") >= 0);
        }
    }

    @Test
    public void testTimeZoneNumberPatterns_positiveAndNegativeOffsets() {
        TimeZone plus = TimeZone.getTimeZone("GMT+05:30");
        TimeZone minus = TimeZone.getTimeZone("GMT-08:00");

        assertEquals("+0530", newPrinter("Z", plus).format(new Date(REFERENCE_MILLIS)));
        assertEquals("+05:30", newPrinter("ZZ", plus).format(new Date(REFERENCE_MILLIS)));
        assertEquals("-0800", newPrinter("Z", minus).format(new Date(REFERENCE_MILLIS)));
        assertEquals("-08:00", newPrinter("ZZ", minus).format(new Date(REFERENCE_MILLIS)));
    }

    @Test
    public void testTimeZoneNamePatterns() {
        assertEquals("GMT", newPrinter("z").format(new Date(REFERENCE_MILLIS)));
        assertEquals("Greenwich Mean Time", newPrinter("zzzz").format(new Date(REFERENCE_MILLIS)));
    }

    @Test
    public void testParsePatternProducesEstimateCoveringLiterals() {
        FastDatePrinter printer = newPrinter("'literal-text'yyyy");
        assertTrue(printer.getMaxLengthEstimate() >= "literal-text".length() + 4);
        assertNotNull(printer.parsePattern());
        assertFalse(printer.parsePattern().isEmpty());
    }

}
