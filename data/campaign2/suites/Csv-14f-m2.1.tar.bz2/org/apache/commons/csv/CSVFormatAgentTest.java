/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.csv;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

import org.junit.Test;

public class CSVFormatAgentTest {

    private enum Header {
        Name, Email, Phone
    }

    @Test
    public void testNewFormat() {
        final CSVFormat format = CSVFormat.newFormat(';');
        assertEquals(';', format.getDelimiter());
        assertNull(format.getQuoteCharacter());
        assertNull(format.getCommentMarker());
        assertNull(format.getEscapeCharacter());
        assertNull(format.getRecordSeparator());
        assertNull(format.getNullString());
        assertNull(format.getHeader());
        assertFalse(format.getIgnoreEmptyLines());
        assertFalse(format.getIgnoreSurroundingSpaces());
        assertFalse(format.getSkipHeaderRecord());
        assertFalse(format.getAllowMissingColumnNames());
        assertFalse(format.getIgnoreHeaderCase());
        assertFalse(format.getTrim());
        assertFalse(format.getTrailingDelimiter());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testNewFormatDelimiterIsLineBreakLf() {
        CSVFormat.newFormat('\n');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testNewFormatDelimiterIsLineBreakCr() {
        CSVFormat.newFormat('\r');
    }

    @Test
    public void testValueOf() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.valueOf("Default"));
        assertEquals(CSVFormat.EXCEL, CSVFormat.valueOf("Excel"));
        assertEquals(CSVFormat.RFC4180, CSVFormat.valueOf("RFC4180"));
        assertEquals(CSVFormat.MYSQL, CSVFormat.valueOf("MySQL"));
        assertEquals(CSVFormat.TDF, CSVFormat.valueOf("TDF"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testValueOfUnknown() {
        CSVFormat.valueOf("DoesNotExist");
    }

    @Test
    public void testPredefinedEnumGetFormat() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.Predefined.Default.getFormat());
        assertEquals(CSVFormat.EXCEL, CSVFormat.Predefined.Excel.getFormat());
        assertEquals(CSVFormat.MYSQL, CSVFormat.Predefined.MySQL.getFormat());
        assertEquals(CSVFormat.RFC4180, CSVFormat.Predefined.RFC4180.getFormat());
        assertEquals(CSVFormat.TDF, CSVFormat.Predefined.TDF.getFormat());
        assertEquals(CSVFormat.INFORMIX_UNLOAD, CSVFormat.Predefined.InformixUnload.getFormat());
        assertEquals(CSVFormat.INFORMIX_UNLOAD_CSV, CSVFormat.Predefined.InformixUnloadCsv.getFormat());
    }

    @Test
    public void testDefaultFormatProperties() {
        assertEquals(',', CSVFormat.DEFAULT.getDelimiter());
        assertEquals(Character.valueOf('"'), CSVFormat.DEFAULT.getQuoteCharacter());
        assertEquals("\r\n", CSVFormat.DEFAULT.getRecordSeparator());
        assertTrue(CSVFormat.DEFAULT.getIgnoreEmptyLines());
        assertFalse(CSVFormat.DEFAULT.isCommentMarkerSet());
        assertFalse(CSVFormat.DEFAULT.isEscapeCharacterSet());
        assertFalse(CSVFormat.DEFAULT.isNullStringSet());
        assertTrue(CSVFormat.DEFAULT.isQuoteCharacterSet());
    }

    @Test
    public void testExcelFormatProperties() {
        assertFalse(CSVFormat.EXCEL.getIgnoreEmptyLines());
        assertTrue(CSVFormat.EXCEL.getAllowMissingColumnNames());
    }

    @Test
    public void testMySqlFormatProperties() {
        assertEquals('\t', CSVFormat.MYSQL.getDelimiter());
        assertNull(CSVFormat.MYSQL.getQuoteCharacter());
        assertEquals(Character.valueOf('\\'), CSVFormat.MYSQL.getEscapeCharacter());
        assertEquals("\\N", CSVFormat.MYSQL.getNullString());
        assertEquals("\n", CSVFormat.MYSQL.getRecordSeparator());
        assertFalse(CSVFormat.MYSQL.getIgnoreEmptyLines());
    }

    @Test
    public void testTdfFormatProperties() {
        assertEquals('\t', CSVFormat.TDF.getDelimiter());
        assertTrue(CSVFormat.TDF.getIgnoreSurroundingSpaces());
    }

    @Test
    public void testRfc4180FormatProperties() {
        assertFalse(CSVFormat.RFC4180.getIgnoreEmptyLines());
        assertEquals(',', CSVFormat.RFC4180.getDelimiter());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testDelimiterSameAsQuoteCharThrows() {
        CSVFormat.DEFAULT.withDelimiter(',').withQuote(',');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testDelimiterSameAsEscapeCharThrows() {
        CSVFormat.DEFAULT.withEscape('!').withDelimiter('!');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testDelimiterSameAsCommentStartThrows() {
        CSVFormat.DEFAULT.withCommentMarker('#').withDelimiter('#');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testQuoteCharSameAsCommentStartThrows() {
        CSVFormat.DEFAULT.withQuote('#').withCommentMarker('#');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testEscapeCharSameAsCommentStartThrows() {
        CSVFormat.DEFAULT.withEscape('#').withCommentMarker('#');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testQuoteModeNoneWithoutEscapeThrows() {
        CSVFormat.DEFAULT.withQuote(null).withQuoteMode(QuoteMode.NONE);
    }

    @Test
    public void testQuoteModeNoneWithEscapeIsAllowed() {
        final CSVFormat format = CSVFormat.DEFAULT.withQuote(null).withEscape('\\').withQuoteMode(QuoteMode.NONE);
        assertEquals(QuoteMode.NONE, format.getQuoteMode());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testDuplicateHeaderNamesThrows() {
        CSVFormat.DEFAULT.withHeader("A", "B", "A");
    }

    @Test
    public void testWithDelimiterLineBreakThrows() {
        try {
            CSVFormat.DEFAULT.withDelimiter('\n');
            fail("expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            assertNotNull(e.getMessage());
        }
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithQuoteLineBreakThrows() {
        CSVFormat.DEFAULT.withQuote('\r');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithEscapeLineBreakThrows() {
        CSVFormat.DEFAULT.withEscape('\n');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithCommentMarkerLineBreakThrows() {
        CSVFormat.DEFAULT.withCommentMarker('\r');
    }

    @Test
    public void testWithQuoteNullDisables() {
        final CSVFormat format = CSVFormat.DEFAULT.withQuote((Character) null);
        assertNull(format.getQuoteCharacter());
        assertFalse(format.isQuoteCharacterSet());
    }

    @Test
    public void testWithEscapeNullDisables() {
        final CSVFormat format = CSVFormat.DEFAULT.withEscape((Character) null);
        assertNull(format.getEscapeCharacter());
        assertFalse(format.isEscapeCharacterSet());
    }

    @Test
    public void testWithCommentMarkerNullDisables() {
        final CSVFormat format = CSVFormat.DEFAULT.withCommentMarker((Character) null);
        assertNull(format.getCommentMarker());
        assertFalse(format.isCommentMarkerSet());
    }

    @Test
    public void testWithNullStringRoundTrip() {
        final CSVFormat format = CSVFormat.DEFAULT.withNullString("NULL");
        assertEquals("NULL", format.getNullString());
        assertTrue(format.isNullStringSet());
    }

    @Test
    public void testWithAllowMissingColumnNamesNoArg() {
        assertTrue(CSVFormat.DEFAULT.withAllowMissingColumnNames().getAllowMissingColumnNames());
    }

    @Test
    public void testWithIgnoreEmptyLinesNoArg() {
        assertTrue(CSVFormat.RFC4180.withIgnoreEmptyLines().getIgnoreEmptyLines());
    }

    @Test
    public void testWithIgnoreHeaderCaseNoArg() {
        assertTrue(CSVFormat.DEFAULT.withIgnoreHeaderCase().getIgnoreHeaderCase());
    }

    @Test
    public void testWithIgnoreSurroundingSpacesNoArg() {
        assertTrue(CSVFormat.DEFAULT.withIgnoreSurroundingSpaces().getIgnoreSurroundingSpaces());
    }

    @Test
    public void testWithSkipHeaderRecordNoArg() {
        assertTrue(CSVFormat.DEFAULT.withSkipHeaderRecord().getSkipHeaderRecord());
    }

    @Test
    public void testWithTrailingDelimiterNoArg() {
        assertTrue(CSVFormat.DEFAULT.withTrailingDelimiter().getTrailingDelimiter());
    }

    @Test
    public void testWithTrimNoArg() {
        assertTrue(CSVFormat.DEFAULT.withTrim().getTrim());
    }

    @Test
    public void testWithHeaderArray() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("A", "B", "C");
        assertArrayEquals(new String[] { "A", "B", "C" }, format.getHeader());
    }

    @Test
    public void testGetHeaderReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("A", "B");
        final String[] header1 = format.getHeader();
        header1[0] = "MUTATED";
        final String[] header2 = format.getHeader();
        assertEquals("A", header2[0]);
    }

    @Test
    public void testWithHeaderNullDisables() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader((String[]) null);
        assertNull(format.getHeader());
    }

    @Test
    public void testWithHeaderEmptyMeansAutoDetect() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader();
        assertNotNull(format.getHeader());
        assertEquals(0, format.getHeader().length);
    }

    @Test
    public void testWithHeaderEnum() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader(Header.class);
        assertArrayEquals(new String[] { "Name", "Email", "Phone" }, format.getHeader());
    }

    @Test
    public void testWithHeaderEnumNullDisables() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader((Class<? extends Enum<?>>) null);
        assertNull(format.getHeader());
    }

    @Test
    public void testWithFirstRecordAsHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.withFirstRecordAsHeader();
        assertNotNull(format.getHeader());
        assertEquals(0, format.getHeader().length);
        assertTrue(format.getSkipHeaderRecord());
    }

    @Test
    public void testWithHeaderComments() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeaderComments("line1", 42);
        assertArrayEquals(new String[] { "line1", "42" }, format.getHeaderComments());
    }

    @Test
    public void testWithHeaderCommentsNullDisables() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeaderComments((Object[]) null);
        assertNull(format.getHeaderComments());
    }

    @Test
    public void testGetHeaderCommentsReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeaderComments("a", "b");
        final String[] comments1 = format.getHeaderComments();
        comments1[0] = "MUTATED";
        assertEquals("a", format.getHeaderComments()[0]);
    }

    @Test
    public void testWithRecordSeparatorChar() {
        final CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator('\n');
        assertEquals("\n", format.getRecordSeparator());
    }

    @Test
    public void testWithRecordSeparatorString() {
        final CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("\r\n");
        assertEquals("\r\n", format.getRecordSeparator());
    }

    @Test
    public void testWithQuoteModeRoundTrip() {
        final CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL);
        assertEquals(QuoteMode.ALL, format.getQuoteMode());
    }

    @Test
    public void testImmutabilityOfWithMethods() {
        final CSVFormat original = CSVFormat.DEFAULT;
        final CSVFormat modified = original.withDelimiter(';');
        assertEquals(',', original.getDelimiter());
        assertEquals(';', modified.getDelimiter());
    }

    @Test
    public void testEqualsSameInstance() {
        assertTrue(CSVFormat.DEFAULT.equals(CSVFormat.DEFAULT));
    }

    @Test
    public void testEqualsNull() {
        assertFalse(CSVFormat.DEFAULT.equals(null));
    }

    @Test
    public void testEqualsDifferentType() {
        assertFalse(CSVFormat.DEFAULT.equals("not a CSVFormat"));
    }

    @Test
    public void testEqualsAndHashCodeForEquivalentFormats() {
        final CSVFormat a = CSVFormat.newFormat(',').withQuote('"').withRecordSeparator("\r\n")
                .withIgnoreEmptyLines(true);
        final CSVFormat b = CSVFormat.newFormat(',').withQuote('"').withRecordSeparator("\r\n")
                .withIgnoreEmptyLines(true);
        assertTrue(a.equals(b));
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    public void testNotEqualsDifferentDelimiter() {
        final CSVFormat a = CSVFormat.DEFAULT;
        final CSVFormat b = CSVFormat.DEFAULT.withDelimiter(';');
        assertFalse(a.equals(b));
    }

    @Test
    public void testToStringContainsDelimiter() {
        final String s = CSVFormat.DEFAULT.toString();
        assertTrue(s.contains("Delimiter=<,>"));
    }

    @Test
    public void testToStringContainsHeaderWhenSet() {
        final String s = CSVFormat.DEFAULT.withHeader("A", "B").toString();
        assertTrue(s.contains("Header:"));
        assertTrue(s.contains("A"));
    }

    @Test
    public void testFormatBasicValues() {
        final String result = CSVFormat.DEFAULT.format("a", "b", "c");
        assertEquals("a,b,c", result);
    }

    @Test
    public void testFormatQuotesValueContainingDelimiter() {
        final String result = CSVFormat.DEFAULT.format("a,b", "c");
        assertEquals("\"a,b\",c", result);
    }

    @Test
    public void testPrintToAppendable() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = CSVFormat.DEFAULT.print(writer);
        assertNotNull(printer);
        printer.printRecord("x", "y");
        printer.close();
        assertEquals("x,y\r\n", writer.toString());
    }

    @Test
    public void testParseReturnsWorkingParser() throws IOException {
        final CSVParser parser = CSVFormat.DEFAULT.parse(new StringReader("a,b,c\r\n"));
        final CSVRecord record = parser.iterator().next();
        assertEquals("a", record.get(0));
        assertEquals("b", record.get(1));
        assertEquals("c", record.get(2));
        parser.close();
    }

    @Test
    public void testPrintlnWritesRecordSeparator() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.println(writer);
        assertEquals("\r\n", writer.toString());
    }

    @Test
    public void testPrintlnWithTrailingDelimiter() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.withTrailingDelimiter(true).println(writer);
        assertEquals(",\r\n", writer.toString());
    }

    @Test
    public void testPrintRecordToAppendable() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.printRecord(writer, "1", "2", "3");
        assertEquals("1,2,3\r\n", writer.toString());
    }

    @Test
    public void testPrintSingleValueNotFirstPrependsDelimiter() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.print("value", writer, false);
        assertEquals(",value", writer.toString());
    }

    @Test
    public void testPrintSingleValueFirstNoDelimiter() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.print("value", writer, true);
        assertEquals("value", writer.toString());
    }

    @Test
    public void testPrintNullValueUsesNullString() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.withNullString("NULL").print(null, writer, true);
        assertEquals("NULL", writer.toString());
    }

    @Test
    public void testQuoteModeAllQuotesEverything() {
        final CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL);
        assertEquals("\"1\",\"2\"", format.format(1, 2));
    }

    @Test
    public void testQuoteModeNonNumericQuotesStringsOnly() {
        final CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.NON_NUMERIC);
        assertEquals("1,\"a\"", format.format(Integer.valueOf(1), "a"));
    }

    @Test
    public void testQuoteModeNoneEscapesDelimiter() {
        final CSVFormat format = CSVFormat.DEFAULT.withQuote(null).withEscape('\\').withQuoteMode(QuoteMode.NONE);
        assertEquals("a\\,b", format.format("a,b"));
    }

    @Test
    public void testWithTrimAffectsPrintedValue() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.withTrim(true).print("  hi  ", writer, true);
        assertEquals("hi", writer.toString());
    }

    @Test
    public void testEscapeCharacterEscapesSpecialChars() {
        final CSVFormat format = CSVFormat.DEFAULT.withQuote(null).withEscape('\\');
        assertEquals("a\\,b", format.format("a,b"));
    }
}
