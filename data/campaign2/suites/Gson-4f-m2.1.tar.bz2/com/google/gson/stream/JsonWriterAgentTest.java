/*
 * Copyright (C) 2014 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.gson.stream;

import java.io.IOException;
import java.io.StringWriter;
import junit.framework.TestCase;

public class JsonWriterAgentTest extends TestCase {

  public void testWriteObjectWithMixedTypes() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginObject();
    writer.name("a").value(1);
    writer.name("b").value(true);
    writer.name("c").nullValue();
    writer.name("d").value("text");
    writer.name("e").value(2.5);
    writer.endObject();
    writer.close();
    assertEquals("{\"a\":1,\"b\":true,\"c\":null,\"d\":\"text\",\"e\":2.5}", stringWriter.toString());
  }

  public void testNestedArrayAndObject() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.value(1);
    writer.beginArray();
    writer.value(2);
    writer.value(3);
    writer.endArray();
    writer.beginObject();
    writer.name("x").value(4);
    writer.endObject();
    writer.endArray();
    writer.close();
    assertEquals("[1,[2,3],{\"x\":4}]", stringWriter.toString());
  }

  public void testIndentProducesPrettyPrintedOutput() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setIndent("  ");
    writer.beginObject();
    writer.name("a").value(1);
    writer.endObject();
    writer.close();
    assertEquals("{\n  \"a\": 1\n}", stringWriter.toString());
  }

  public void testSetIndentEmptyStringMeansCompact() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setIndent("  ");
    writer.setIndent("");
    writer.beginObject();
    writer.name("a").value(1);
    writer.endObject();
    writer.close();
    assertEquals("{\"a\":1}", stringWriter.toString());
  }

  public void testHtmlSafeEscaping() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setHtmlSafe(true);
    assertTrue(writer.isHtmlSafe());
    writer.beginArray();
    writer.value("<html>&foo=bar</html>");
    writer.endArray();
    writer.close();
    assertEquals("[\"\\u003chtml\\u003e\\u0026foo\\u003dbar\\u003c/html\\u003e\"]",
        stringWriter.toString());
  }

  public void testSerializeNullsFalseSkipsNullMembers() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setSerializeNulls(false);
    assertFalse(writer.getSerializeNulls());
    writer.beginObject();
    writer.name("a").nullValue();
    writer.name("b").value(1);
    writer.endObject();
    writer.close();
    assertEquals("{\"b\":1}", stringWriter.toString());
  }

  public void testSerializeNullsDefaultTrue() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    assertTrue(writer.getSerializeNulls());
    writer.beginObject();
    writer.name("a").nullValue();
    writer.endObject();
    writer.close();
    assertEquals("{\"a\":null}", stringWriter.toString());
  }

  public void testValueStringNullDelegatesToNullValue() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.value((String) null);
    writer.endArray();
    writer.close();
    assertEquals("[null]", stringWriter.toString());
  }

  public void testJsonValueWritesRawContent() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.jsonValue("{\"raw\":true}");
    writer.endArray();
    writer.close();
    assertEquals("[{\"raw\":true}]", stringWriter.toString());
  }

  public void testNameNullThrowsNullPointerException() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginObject();
    try {
      writer.name(null);
      fail("Expected NullPointerException");
    } catch (NullPointerException expected) {
    }
  }

  public void testDoubleNameThrowsIllegalStateException() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginObject();
    writer.name("a");
    try {
      writer.name("b");
      fail("Expected IllegalStateException");
    } catch (IllegalStateException expected) {
    }
  }

  public void testNanDoubleThrowsIllegalArgumentException() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginArray();
    try {
      writer.value(Double.NaN);
      fail("Expected IllegalArgumentException");
    } catch (IllegalArgumentException expected) {
    }
  }

  public void testLenientAllowsNanNumber() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setLenient(true);
    assertTrue(writer.isLenient());
    writer.beginArray();
    writer.value((Number) Double.valueOf(Double.NaN));
    writer.endArray();
    writer.close();
    assertEquals("[NaN]", stringWriter.toString());
  }

  public void testStrictModeRejectsNanNumber() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginArray();
    try {
      writer.value((Number) Double.valueOf(Double.NaN));
      fail("Expected IllegalArgumentException");
    } catch (IllegalArgumentException expected) {
    }
  }

  public void testStrictModeRejectsMultipleTopLevelValues() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.value(1);
    try {
      writer.value(2);
      fail("Expected IllegalStateException");
    } catch (IllegalStateException expected) {
    }
  }

  public void testLenientModeAllowsMultipleTopLevelValues() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setLenient(true);
    writer.value(1);
    writer.value(2);
    assertEquals("12", stringWriter.toString());
  }

  public void testEndObjectWithoutBeginThrows() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    try {
      writer.endObject();
      fail("Expected IllegalStateException");
    } catch (IllegalStateException expected) {
    }
  }

  public void testEndArrayMismatchThrows() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginObject();
    try {
      writer.endArray();
      fail("Expected IllegalStateException");
    } catch (IllegalStateException expected) {
    }
  }

  public void testCloseIncompleteDocumentThrowsIOException() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginObject();
    try {
      writer.close();
      fail("Expected IOException");
    } catch (IOException expected) {
    }
  }

  public void testCloseDanglingNameThrows() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginObject();
    writer.name("a");
    try {
      writer.endObject();
      fail("Expected IllegalStateException");
    } catch (IllegalStateException expected) {
    }
  }

  public void testFlushAfterCloseThrows() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginArray();
    writer.endArray();
    writer.close();
    try {
      writer.flush();
      fail("Expected IllegalStateException");
    } catch (IllegalStateException expected) {
    }
  }

  public void testNullConstructorArgumentThrows() {
    try {
      new JsonWriter(null);
      fail("Expected NullPointerException");
    } catch (NullPointerException expected) {
    }
  }

  public void testLongValueBoundaries() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.value(Long.MIN_VALUE);
    writer.value(Long.MAX_VALUE);
    writer.endArray();
    writer.close();
    assertEquals("[" + Long.MIN_VALUE + "," + Long.MAX_VALUE + "]", stringWriter.toString());
  }

  public void testValueNumberNullDelegatesToNullValue() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.value((Number) null);
    writer.endArray();
    writer.close();
    assertEquals("[null]", stringWriter.toString());
  }

  public void testStringEscaping() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.value("a\tb\nc\"d\\e");
    writer.endArray();
    writer.close();
    assertEquals("[\"a\\tb\\nc\\\"d\\\\e\"]", stringWriter.toString());
  }

  public void testMethodsReturnThisForChaining() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    JsonWriter result = writer.beginArray();
    assertSame(writer, result);
    assertSame(writer, writer.value(1));
    assertSame(writer, writer.endArray());
  }
}
