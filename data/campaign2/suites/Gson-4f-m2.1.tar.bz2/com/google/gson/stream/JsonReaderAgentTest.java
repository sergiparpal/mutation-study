/*
 * Copyright (C) 2014 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.gson.stream;

import java.io.IOException;
import java.io.StringReader;
import junit.framework.TestCase;

@SuppressWarnings("resource")
public class JsonReaderAgentTest extends TestCase {

  public void testReadObjectWithMixedTypes() throws IOException {
    JsonReader reader = new JsonReader(new StringReader(
        "{\"a\":1,\"b\":true,\"c\":null,\"d\":\"text\",\"e\":2.5}"));
    reader.beginObject();
    assertEquals(JsonToken.NAME, reader.peek());
    assertEquals("a", reader.nextName());
    assertEquals(1, reader.nextInt());
    assertEquals("b", reader.nextName());
    assertTrue(reader.nextBoolean());
    assertEquals("c", reader.nextName());
    reader.nextNull();
    assertEquals("d", reader.nextName());
    assertEquals("text", reader.nextString());
    assertEquals("e", reader.nextName());
    assertEquals(2.5, reader.nextDouble(), 0.0);
    reader.endObject();
    assertEquals(JsonToken.END_DOCUMENT, reader.peek());
    reader.close();
  }

  public void testNestedArrayAndObject() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1,[2,3],{\"x\":4}]"));
    reader.beginArray();
    assertEquals(1, reader.nextInt());
    reader.beginArray();
    assertEquals(2, reader.nextInt());
    assertEquals(3, reader.nextInt());
    reader.endArray();
    reader.beginObject();
    assertEquals("x", reader.nextName());
    assertEquals(4, reader.nextInt());
    reader.endObject();
    reader.endArray();
    reader.close();
  }

  public void testHasNext() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1,2]"));
    reader.beginArray();
    assertTrue(reader.hasNext());
    reader.nextInt();
    assertTrue(reader.hasNext());
    reader.nextInt();
    assertFalse(reader.hasNext());
    reader.endArray();
  }

  public void testGetPath() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("{\"a\":[1,2]}"));
    assertEquals("$", reader.getPath());
    reader.beginObject();
    reader.nextName();
    assertEquals("$.a", reader.getPath());
    reader.beginArray();
    assertEquals("$.a[0]", reader.getPath());
    reader.nextInt();
    assertEquals("$.a[1]", reader.getPath());
    reader.nextInt();
    reader.endArray();
    reader.endObject();
  }

  public void testLongBoundaryValues() throws IOException {
    JsonReader reader = new JsonReader(new StringReader(
        "[" + Long.MIN_VALUE + "," + Long.MAX_VALUE + "]"));
    reader.beginArray();
    assertEquals(Long.MIN_VALUE, reader.nextLong());
    assertEquals(Long.MAX_VALUE, reader.nextLong());
    reader.endArray();
  }

  public void testNextIntOverflowThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[" + (((long) Integer.MAX_VALUE) + 1) + "]"));
    reader.beginArray();
    try {
      reader.nextInt();
      fail("Expected NumberFormatException");
    } catch (NumberFormatException expected) {
    }
  }

  public void testNextLongOnNonIntegerThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1.5]"));
    reader.beginArray();
    try {
      reader.nextLong();
      fail("Expected NumberFormatException");
    } catch (NumberFormatException expected) {
    }
  }

  public void testStringAsNumber() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[\"42\"]"));
    reader.beginArray();
    assertEquals(42, reader.nextInt());
    reader.endArray();
  }

  public void testNumberAsString() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[42]"));
    reader.beginArray();
    assertEquals("42", reader.nextString());
    reader.endArray();
  }

  public void testMismatchedTypeThrowsIllegalStateException() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[true]"));
    reader.beginArray();
    try {
      reader.nextInt();
      fail("Expected IllegalStateException");
    } catch (IllegalStateException expected) {
    }
  }

  public void testBeginArrayOnObjectThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("{}"));
    try {
      reader.beginArray();
      fail("Expected IllegalStateException");
    } catch (IllegalStateException expected) {
    }
  }

  public void testEndArrayWithoutFinishingElementsThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1,2]"));
    reader.beginArray();
    try {
      reader.endArray();
      fail("Expected IllegalStateException");
    } catch (IllegalStateException expected) {
    }
  }

  public void testMalformedJsonThrowsIOException() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("{"));
    reader.beginObject();
    try {
      reader.peek();
      fail("Expected IOException");
    } catch (IOException expected) {
    }
  }

  public void testStrictModeRejectsUnquotedStrings() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[a]"));
    reader.beginArray();
    try {
      reader.nextString();
      fail("Expected IOException");
    } catch (IOException expected) {
    }
  }

  public void testLenientModeAcceptsUnquotedStrings() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[a]"));
    reader.setLenient(true);
    assertTrue(reader.isLenient());
    reader.beginArray();
    assertEquals("a", reader.nextString());
    reader.endArray();
  }

  public void testLenientModeAcceptsNonExecutePrefix() throws IOException {
    JsonReader reader = new JsonReader(new StringReader(")]}'\n[1]"));
    reader.setLenient(true);
    reader.beginArray();
    assertEquals(1, reader.nextInt());
    reader.endArray();
  }

  public void testStrictModeRejectsNonExecutePrefix() throws IOException {
    JsonReader reader = new JsonReader(new StringReader(")]}'\n[1]"));
    try {
      reader.beginArray();
      fail("Expected IOException");
    } catch (IOException expected) {
    }
  }

  public void testSkipValueSkipsNestedStructure() throws IOException {
    JsonReader reader = new JsonReader(new StringReader(
        "{\"a\":{\"b\":[1,2,3]},\"c\":true}"));
    reader.beginObject();
    assertEquals("a", reader.nextName());
    reader.skipValue();
    assertEquals("c", reader.nextName());
    assertTrue(reader.nextBoolean());
    reader.endObject();
  }

  public void testCloseThenPeekThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1]"));
    reader.close();
    try {
      reader.peek();
      fail("Expected IllegalStateException");
    } catch (IllegalStateException expected) {
    }
  }

  public void testEscapedCharactersInString() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[\"a\\tb\\nc\\\"d\\u0041\"]"));
    reader.beginArray();
    assertEquals("a\tb\nc\"dA", reader.nextString());
    reader.endArray();
  }

  public void testNullConstructorArgumentThrows() {
    try {
      new JsonReader(null);
      fail("Expected NullPointerException");
    } catch (NullPointerException expected) {
    }
  }

  public void testEmptyObjectHasNoNext() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("{}"));
    reader.beginObject();
    assertFalse(reader.hasNext());
    reader.endObject();
  }

  public void testDoubleValueParsing() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1.5e2]"));
    reader.beginArray();
    assertEquals(150.0, reader.nextDouble(), 0.0);
    reader.endArray();
  }

  public void testStrictModeRejectsNanDouble() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[NaN]"));
    reader.beginArray();
    try {
      reader.nextDouble();
      fail("Expected MalformedJsonException");
    } catch (MalformedJsonException expected) {
    }
  }

  public void testNextNameOnNonNameThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1]"));
    reader.beginArray();
    try {
      reader.nextName();
      fail("Expected IllegalStateException");
    } catch (IllegalStateException expected) {
    }
  }

  public void testToStringContainsLineAndColumn() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1]"));
    String s = reader.toString();
    assertTrue(s.contains("line"));
    assertTrue(s.contains("column"));
  }

  public void testSetLenientDefaultIsFalse() {
    JsonReader reader = new JsonReader(new StringReader(""));
    assertFalse(reader.isLenient());
  }
}
