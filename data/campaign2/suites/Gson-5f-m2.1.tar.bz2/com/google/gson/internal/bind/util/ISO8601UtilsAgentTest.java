package com.google.gson.internal.bind.util;

import junit.framework.TestCase;

import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

public class ISO8601UtilsAgentTest extends TestCase {

  private static Date utcDate(int year, int month, int day, int hour, int minute, int second, int millis) {
    GregorianCalendar calendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
    calendar.clear();
    calendar.set(year, month - 1, day, hour, minute, second);
    calendar.set(Calendar.MILLISECOND, millis);
    return calendar.getTime();
  }

  // ---- format(Date) ----

  public void testFormatDefaultNoMillis() {
    Date date = utcDate(2016, 1, 15, 10, 20, 30, 500);
    assertEquals("2016-01-15T10:20:30Z", ISO8601Utils.format(date));
  }

  public void testFormatPadsSingleDigitFields() {
    Date date = utcDate(2016, 2, 3, 4, 5, 6, 0);
    assertEquals("2016-02-03T04:05:06Z", ISO8601Utils.format(date));
  }

  // ---- format(Date, boolean) ----

  public void testFormatWithMillis() {
    Date date = utcDate(2016, 1, 15, 10, 20, 30, 500);
    assertEquals("2016-01-15T10:20:30.500Z", ISO8601Utils.format(date, true));
  }

  public void testFormatWithMillisPadded() {
    Date date = utcDate(2016, 1, 15, 10, 20, 30, 5);
    assertEquals("2016-01-15T10:20:30.005Z", ISO8601Utils.format(date, true));
  }

  // ---- format(Date, boolean, TimeZone) ----

  public void testFormatWithPositiveOffset() {
    Date date = utcDate(2016, 1, 15, 10, 20, 30, 0);
    String formatted = ISO8601Utils.format(date, false, TimeZone.getTimeZone("GMT+02:00"));
    assertEquals("2016-01-15T12:20:30+02:00", formatted);
  }

  public void testFormatWithNegativeOffsetAndMinutes() {
    Date date = utcDate(2016, 1, 15, 10, 20, 30, 0);
    String formatted = ISO8601Utils.format(date, false, TimeZone.getTimeZone("GMT-05:30"));
    assertEquals("2016-01-15T04:50:30-05:30", formatted);
  }

  public void testFormatWithQuarterHourOffset() {
    Date date = utcDate(2016, 1, 15, 10, 20, 30, 0);
    String formatted = ISO8601Utils.format(date, false, TimeZone.getTimeZone("GMT+05:45"));
    assertEquals("2016-01-15T16:05:30+05:45", formatted);
  }

  public void testFormatWithZeroOffsetUsesZ() {
    Date date = utcDate(2016, 1, 15, 10, 20, 30, 0);
    String formatted = ISO8601Utils.format(date, false, TimeZone.getTimeZone("GMT+00:00"));
    assertEquals("2016-01-15T10:20:30Z", formatted);
  }

  // ---- parse: basic date only ----

  public void testParseDateOnly() throws ParseException {
    ParsePosition pos = new ParsePosition(0);
    Date date = ISO8601Utils.parse("2016-01-15", pos);
    assertEquals(10, pos.getIndex());

    Calendar cal = Calendar.getInstance();
    cal.setTime(date);
    assertEquals(2016, cal.get(Calendar.YEAR));
    assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));
    assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
  }

  public void testParseCompactDateOnly() throws ParseException {
    ParsePosition pos = new ParsePosition(0);
    Date date = ISO8601Utils.parse("20160115", pos);
    assertEquals(8, pos.getIndex());

    Calendar cal = Calendar.getInstance();
    cal.setTime(date);
    assertEquals(2016, cal.get(Calendar.YEAR));
    assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));
    assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
  }

  // ---- parse: date + time + timezone ----

  public void testParseDateTimeWithZ() throws ParseException {
    ParsePosition pos = new ParsePosition(0);
    Date date = ISO8601Utils.parse("2016-01-15T10:20:30Z", pos);
    assertEquals(20, pos.getIndex());

    Calendar cal = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
    cal.setTime(date);
    assertEquals(2016, cal.get(Calendar.YEAR));
    assertEquals(Calendar.JANUARY, cal.get(Calendar.MONTH));
    assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
    assertEquals(10, cal.get(Calendar.HOUR_OF_DAY));
    assertEquals(20, cal.get(Calendar.MINUTE));
    assertEquals(30, cal.get(Calendar.SECOND));
    assertEquals(0, cal.get(Calendar.MILLISECOND));
  }

  public void testParseDateTimeWithMillis() throws ParseException {
    ParsePosition pos = new ParsePosition(0);
    Date date = ISO8601Utils.parse("2016-01-15T10:20:30.123Z", pos);

    Calendar cal = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
    cal.setTime(date);
    assertEquals(30, cal.get(Calendar.SECOND));
    assertEquals(123, cal.get(Calendar.MILLISECOND));
  }

  public void testParseDateTimeWithShortMillisDigit() throws ParseException {
    ParsePosition pos = new ParsePosition(0);
    // single fraction digit "5" should expand to 500 ms
    Date date = ISO8601Utils.parse("2016-01-15T10:20:30.5Z", pos);

    Calendar cal = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
    cal.setTime(date);
    assertEquals(500, cal.get(Calendar.MILLISECOND));
  }

  public void testParseDateTimeWithOffsetColon() throws ParseException {
    ParsePosition pos = new ParsePosition(0);
    Date date = ISO8601Utils.parse("2016-01-15T10:20:30+02:00", pos);

    Calendar cal = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
    cal.setTime(date);
    assertEquals(8, cal.get(Calendar.HOUR_OF_DAY));
    assertEquals(20, cal.get(Calendar.MINUTE));
  }

  public void testParseDateTimeWithOffsetNoColon() throws ParseException {
    ParsePosition pos = new ParsePosition(0);
    Date date = ISO8601Utils.parse("2016-01-15T10:20:30+0200", pos);

    Calendar cal = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
    cal.setTime(date);
    assertEquals(8, cal.get(Calendar.HOUR_OF_DAY));
  }

  public void testParseDateTimeWithShortOffsetHourOnly() throws ParseException {
    ParsePosition pos = new ParsePosition(0);
    Date date = ISO8601Utils.parse("2016-01-15T10:20:30+02", pos);

    Calendar cal = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
    cal.setTime(date);
    assertEquals(8, cal.get(Calendar.HOUR_OF_DAY));
  }

  public void testParseDateTimeWithZeroOffsetEqualsZ() throws ParseException {
    ParsePosition pos1 = new ParsePosition(0);
    Date dateZ = ISO8601Utils.parse("2016-01-15T10:20:30Z", pos1);
    ParsePosition pos2 = new ParsePosition(0);
    Date dateOffset = ISO8601Utils.parse("2016-01-15T10:20:30+00:00", pos2);
    assertEquals(dateZ, dateOffset);
  }

  public void testParseLeapSecondTruncatedTo59() throws ParseException {
    ParsePosition pos = new ParsePosition(0);
    Date date = ISO8601Utils.parse("2016-01-15T10:20:60Z", pos);

    Calendar cal = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
    cal.setTime(date);
    assertEquals(59, cal.get(Calendar.SECOND));
  }

  // ---- parse: round trip with format ----

  public void testParseFormatRoundTrip() throws ParseException {
    Date original = utcDate(2016, 1, 15, 10, 20, 30, 0);
    String formatted = ISO8601Utils.format(original);
    ParsePosition pos = new ParsePosition(0);
    Date parsed = ISO8601Utils.parse(formatted, pos);
    assertEquals(original, parsed);
  }

  // ---- parse: error cases ----

  public void testParseMissingTimeZoneThrowsParseException() {
    ParsePosition pos = new ParsePosition(0);
    try {
      ISO8601Utils.parse("2016-01-15T10:20:30", pos);
      fail("Expected ParseException");
    } catch (ParseException expected) {
      assertTrue(expected.getMessage().contains("No time zone indicator"));
    }
  }

  public void testParseInvalidTimeZoneIndicatorThrowsParseException() {
    ParsePosition pos = new ParsePosition(0);
    try {
      ISO8601Utils.parse("2016-01-15T10:20:30X", pos);
      fail("Expected ParseException");
    } catch (ParseException expected) {
      assertTrue(expected.getCause() instanceof IndexOutOfBoundsException);
    }
  }

  public void testParseNonNumericFieldThrowsParseException() {
    ParsePosition pos = new ParsePosition(0);
    try {
      ISO8601Utils.parse("2016-01-XXT10:20:30Z", pos);
      fail("Expected ParseException");
    } catch (ParseException expected) {
      assertTrue(expected.getCause() instanceof NumberFormatException);
    }
  }

  public void testParseInvalidMonthThrowsParseException() {
    ParsePosition pos = new ParsePosition(0);
    try {
      ISO8601Utils.parse("2016-13-01T10:20:30Z", pos);
      fail("Expected ParseException");
    } catch (ParseException expected) {
      assertTrue(expected.getCause() instanceof IllegalArgumentException);
    }
  }

  public void testParseTooShortStringThrowsParseException() {
    ParsePosition pos = new ParsePosition(0);
    try {
      ISO8601Utils.parse("2016", pos);
      fail("Expected ParseException");
    } catch (ParseException expected) {
      // truncated "yyyy" leaves nothing for month/day -> NumberFormatException wrapped
      assertTrue(expected.getCause() instanceof NumberFormatException);
    }
  }

  public void testParseNullDateThrowsNullPointerException() {
    ParsePosition pos = new ParsePosition(0);
    try {
      ISO8601Utils.parse(null, pos);
      fail("Expected NullPointerException");
    } catch (NullPointerException expected) {
      // expected: null input is not caught/converted by the parser
    } catch (ParseException e) {
      fail("Expected NullPointerException, got ParseException: " + e);
    }
  }
}
