package org.apache.commons.lang3.text;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.Format;
import java.text.ParsePosition;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.junit.Test;

public class ExtendedMessageFormatAgentTest {

    /**
     * Simple Format that reverses the String representation of its argument.
     * Used to verify that a custom FormatFactory registered against a
     * format name is actually consulted and its result used.
     */
    private static final class ReverseFormat extends Format {
        private static final long serialVersionUID = 1L;

        public StringBuffer format(Object obj, StringBuffer toAppendTo, java.text.FieldPosition pos) {
            String s = String.valueOf(obj);
            StringBuilder reversed = new StringBuilder(s);
            reversed.reverse();
            return toAppendTo.append(reversed);
        }

        public Object parseObject(String source, ParsePosition pos) {
            return source;
        }
    }

    /**
     * FormatFactory that always returns a ReverseFormat and records the
     * name/arguments/locale it was invoked with, so tests can assert on
     * the trimming behaviour documented in the class Javadoc.
     */
    private static final class RecordingFormatFactory implements FormatFactory {
        private String lastName;
        private String lastArguments;
        private Locale lastLocale;

        public Format getFormat(String name, String arguments, Locale locale) {
            this.lastName = name;
            this.lastArguments = arguments;
            this.lastLocale = locale;
            return new ReverseFormat();
        }
    }

    private static Map<String, FormatFactory> singleEntryRegistry(String name, FormatFactory factory) {
        Map<String, FormatFactory> registry = new HashMap<String, FormatFactory>();
        registry.put(name, factory);
        return registry;
    }

    // ---------------------------------------------------------------
    // Constructors
    // ---------------------------------------------------------------

    @Test
    public void testConstructorSimplePatternDefaultLocale() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello, {0}!");
        assertEquals("Hello, {0}!", emf.toPattern());
        assertEquals("Hello, World!", emf.format(new Object[] {"World"}));
    }

    @Test
    public void testConstructorEmptyPattern() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("");
        assertEquals("", emf.toPattern());
        assertEquals("", emf.format(new Object[] {}));
    }

    @Test
    public void testConstructorWithLocale() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number}", Locale.GERMANY);
        assertEquals(Locale.GERMANY, emf.getLocale());
        // German locale uses ',' as the decimal separator.
        assertEquals("1,5", emf.format(new Object[] {new Double(1.5)}));
    }

    @Test(expected = NullPointerException.class)
    public void testConstructorNullPatternThrows() {
        new ExtendedMessageFormat(null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testConstructorUnterminatedFormatElementThrowsIllegalArgumentException() {
        new ExtendedMessageFormat("{0");
    }

    @Test
    public void testConstructorRegistryMayBeNull() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Hi {0}", (Map<String, FormatFactory>) null);
        assertEquals("Hi {0}", emf.toPattern());
        assertEquals("Hi Bob", emf.format(new Object[] {"Bob"}));
    }

    @Test
    public void testConstructorWithRegistryDefaultLocale() {
        RecordingFormatFactory factory = new RecordingFormatFactory();
        ExtendedMessageFormat emf = new ExtendedMessageFormat(
                "{0,reverse}", singleEntryRegistry("reverse", factory));
        assertEquals("cba", emf.format(new Object[] {"abc"}));
    }

    @Test
    public void testConstructorWithLocaleAndRegistry() {
        RecordingFormatFactory factory = new RecordingFormatFactory();
        ExtendedMessageFormat emf = new ExtendedMessageFormat(
                "{0,reverse}", Locale.FRANCE, singleEntryRegistry("reverse", factory));
        assertEquals(Locale.FRANCE, emf.getLocale());
        assertEquals("cba", emf.format(new Object[] {"abc"}));
        assertEquals(Locale.FRANCE, factory.lastLocale);
    }

    // ---------------------------------------------------------------
    // toPattern / applyPattern
    // ---------------------------------------------------------------

    @Test
    public void testToPatternRoundTripsSimplePattern() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0} and {1}");
        assertEquals("{0} and {1}", emf.toPattern());
    }

    @Test
    public void testApplyPatternReplacesExistingPattern() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("first {0}");
        emf.applyPattern("second {0}");
        assertEquals("second {0}", emf.toPattern());
        assertEquals("second value", emf.format(new Object[] {"value"}));
    }

    @Test(expected = NullPointerException.class)
    public void testApplyPatternNullThrows() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        emf.applyPattern(null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testApplyPatternBadPatternThrowsIllegalArgumentException() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        emf.applyPattern("{0");
    }

    @Test
    public void testApplyPatternWithUnregisteredCustomFormatNameFallsThroughAndThrows() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        try {
            emf.applyPattern("{0,notARegisteredOrStandardFormat}");
            fail("Expected IllegalArgumentException for unknown format type");
        } catch (IllegalArgumentException expected) {
            // expected: name is neither in the registry nor a standard
            // MessageFormat type (number/date/time/choice).
        }
    }

    // ---------------------------------------------------------------
    // Formatting with multiple arguments
    // ---------------------------------------------------------------

    @Test
    public void testFormatMultipleArguments() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0} and {1}");
        assertEquals("A and B", emf.format(new Object[] {"A", "B"}));
    }

    @Test
    public void testFormatNameAndStyleAreTrimmedOfWhitespace() {
        RecordingFormatFactory factory = new RecordingFormatFactory();
        ExtendedMessageFormat emf = new ExtendedMessageFormat(
                "{0, reverse , myStyle }", singleEntryRegistry("reverse", factory));
        emf.format(new Object[] {"xyz"});
        assertEquals("reverse", factory.lastName);
        assertEquals("myStyle", factory.lastArguments);
    }

    // ---------------------------------------------------------------
    // Disabled mutator methods
    // ---------------------------------------------------------------

    @Test
    public void testSetFormatThrowsUnsupportedOperationException() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        try {
            emf.setFormat(0, java.text.NumberFormat.getInstance());
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
    }

    @Test
    public void testSetFormatByArgumentIndexThrowsUnsupportedOperationException() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        try {
            emf.setFormatByArgumentIndex(0, java.text.NumberFormat.getInstance());
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
    }

    @Test
    public void testSetFormatsThrowsUnsupportedOperationException() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        try {
            emf.setFormats(new Format[] {java.text.NumberFormat.getInstance()});
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
    }

    @Test
    public void testSetFormatsByArgumentIndexThrowsUnsupportedOperationException() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        try {
            emf.setFormatsByArgumentIndex(new Format[] {java.text.NumberFormat.getInstance()});
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
    }

    // ---------------------------------------------------------------
    // equals / hashCode
    // ---------------------------------------------------------------

    @Test
    public void testEqualsIsReflexive() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertTrue(emf.equals(emf));
    }

    @Test
    public void testEqualsNullReturnsFalse() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertFalse(emf.equals(null));
    }

    @Test
    public void testEqualsDifferentTypeReturnsFalse() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertFalse(emf.equals("{0}"));
    }

    @Test
    public void testEqualsSamePatternAndLocaleReturnsTrue() {
        ExtendedMessageFormat first = new ExtendedMessageFormat("Hi {0}", Locale.US);
        ExtendedMessageFormat second = new ExtendedMessageFormat("Hi {0}", Locale.US);
        assertTrue(first.equals(second));
        assertTrue(second.equals(first));
    }

    @Test
    public void testEqualsDifferentPatternReturnsFalse() {
        ExtendedMessageFormat first = new ExtendedMessageFormat("Hi {0}", Locale.US);
        ExtendedMessageFormat second = new ExtendedMessageFormat("Bye {0}", Locale.US);
        assertFalse(first.equals(second));
    }

    @Test
    public void testEqualsDifferentLocaleReturnsFalse() {
        ExtendedMessageFormat first = new ExtendedMessageFormat("Hi {0}", Locale.US);
        ExtendedMessageFormat second = new ExtendedMessageFormat("Hi {0}", Locale.GERMANY);
        assertFalse(first.equals(second));
    }

    @Test
    public void testHashCodeConsistentWithEquals() {
        ExtendedMessageFormat first = new ExtendedMessageFormat("Hi {0}", Locale.US);
        ExtendedMessageFormat second = new ExtendedMessageFormat("Hi {0}", Locale.US);
        assertTrue(first.equals(second));
        assertEquals(first.hashCode(), second.hashCode());
    }

    @Test
    public void testHashCodeIsStableAcrossCalls() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Hi {0}", Locale.US);
        int first = emf.hashCode();
        int second = emf.hashCode();
        assertEquals(first, second);
    }

    // ---------------------------------------------------------------
    // Serialization
    // ---------------------------------------------------------------

    @Test
    public void testSerializationRoundTripPreservesPatternAndFormatting() throws Exception {
        ExtendedMessageFormat original = new ExtendedMessageFormat("Hi {0}", Locale.US);

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(baos);
        oos.writeObject(original);
        oos.close();

        ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(baos.toByteArray()));
        ExtendedMessageFormat copy = (ExtendedMessageFormat) ois.readObject();
        ois.close();

        assertNotNull(copy);
        assertEquals(original.toPattern(), copy.toPattern());
        assertEquals(original.format(new Object[] {"Bob"}), copy.format(new Object[] {"Bob"}));
    }
}
