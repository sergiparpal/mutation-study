package com.google.gson.internal.bind;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import com.google.gson.TypeAdapter;
import com.google.gson.TypeAdapterFactory;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.internal.ConstructorConstructor;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonWriter;

import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Type;

import junit.framework.TestCase;

/**
 * Tests for {@link JsonAdapterAnnotationTypeAdapterFactory}, built against the javadoc contract
 * in api/ and the well known behaviour of the {@code @JsonAdapter} annotation it implements.
 */
public class JsonAdapterAnnotationTypeAdapterFactoryAgentTest extends TestCase {

  private Gson gson;
  private ConstructorConstructor constructorConstructor;
  private JsonAdapterAnnotationTypeAdapterFactory factory;

  protected void setUp() throws Exception {
    super.setUp();
    gson = new GsonBuilder().create();
    Field field = Gson.class.getDeclaredField("constructorConstructor");
    field.setAccessible(true);
    constructorConstructor = (ConstructorConstructor) field.get(gson);
    factory = new JsonAdapterAnnotationTypeAdapterFactory(constructorConstructor);
  }

  // ---------------------------------------------------------------------
  // Fixtures: plain class with no annotation.
  // ---------------------------------------------------------------------

  static class Plain {
    String value = "plain";
  }

  public void testCreate_returnsNullWhenTypeHasNoAnnotation() throws Exception {
    TypeAdapter<Plain> adapter = factory.create(gson, TypeToken.get(Plain.class));
    assertNull(adapter);
  }

  public void testCreate_returnsNullForJdkTypeWithoutAnnotation() throws Exception {
    TypeAdapter<String> adapter = factory.create(gson, TypeToken.get(String.class));
    assertNull(adapter);
  }

  // ---------------------------------------------------------------------
  // Fixtures: @JsonAdapter pointing at a TypeAdapter subclass, default nullSafe (true).
  // ---------------------------------------------------------------------

  static class NullSafeCheckingAdapter extends TypeAdapter<WithTypeAdapter> {
    public void write(JsonWriter out, WithTypeAdapter value) throws IOException {
      if (value == null) {
        throw new AssertionError("write() must not be invoked with null when nullSafe=true");
      }
      out.value("adapted:" + value.text);
    }

    public WithTypeAdapter read(JsonReader in) throws IOException {
      if (in.peek() == JsonToken.NULL) {
        throw new AssertionError("read() must not be invoked for null when nullSafe=true");
      }
      WithTypeAdapter result = new WithTypeAdapter();
      result.text = in.nextString();
      return result;
    }
  }

  @JsonAdapter(NullSafeCheckingAdapter.class)
  static class WithTypeAdapter {
    String text = "hello";
  }

  public void testCreate_withTypeAdapterClass_isUsedForWriteAndRead() throws Exception {
    TypeAdapter<WithTypeAdapter> adapter = factory.create(gson, TypeToken.get(WithTypeAdapter.class));
    assertNotNull(adapter);

    WithTypeAdapter value = new WithTypeAdapter();
    value.text = "world";
    assertEquals("\"adapted:world\"", adapter.toJson(value));

    WithTypeAdapter read = adapter.fromJson("\"abc\"");
    assertEquals("abc", read.text);
  }

  public void testCreate_withTypeAdapterClass_wrapsNullsAsNullSafe() throws Exception {
    TypeAdapter<WithTypeAdapter> adapter = factory.create(gson, TypeToken.get(WithTypeAdapter.class));
    assertNotNull(adapter);

    // The adapter returned by the factory must be null-safe: null must be intercepted
    // before it reaches the annotation-declared adapter, which would otherwise throw
    // AssertionError.
    assertEquals("null", adapter.toJson(null));
    assertNull(adapter.fromJson("null"));
  }

  // ---------------------------------------------------------------------
  // Fixtures: @JsonAdapter pointing at a TypeAdapterFactory.
  // ---------------------------------------------------------------------

  static class WithFactoryAdapter extends TypeAdapter<WithFactory> {
    public void write(JsonWriter out, WithFactory value) throws IOException {
      out.value("factory:" + value.text);
    }

    public WithFactory read(JsonReader in) throws IOException {
      String s = in.nextString();
      WithFactory result = new WithFactory();
      result.text = s;
      return result;
    }
  }

  static class RecordingFactory implements TypeAdapterFactory {
    static Gson lastGson;
    static TypeToken<?> lastType;

    @SuppressWarnings("unchecked")
    public <T> TypeAdapter<T> create(Gson gson, TypeToken<T> type) {
      lastGson = gson;
      lastType = type;
      if (type.getRawType() == WithFactory.class) {
        return (TypeAdapter<T>) new WithFactoryAdapter();
      }
      return null;
    }
  }

  @JsonAdapter(RecordingFactory.class)
  static class WithFactory {
    String text = "f";
  }

  public void testCreate_withTypeAdapterFactoryClass_delegatesToFactory() throws Exception {
    RecordingFactory.lastGson = null;
    RecordingFactory.lastType = null;

    TypeToken<WithFactory> type = TypeToken.get(WithFactory.class);
    TypeAdapter<WithFactory> adapter = factory.create(gson, type);
    assertNotNull(adapter);

    WithFactory value = new WithFactory();
    value.text = "x";
    assertEquals("\"factory:x\"", adapter.toJson(value));

    // The same Gson instance and field type must have been handed to the nested factory.
    assertSame(gson, RecordingFactory.lastGson);
    assertEquals(type, RecordingFactory.lastType);
  }

  // ---------------------------------------------------------------------
  // Fixtures: @JsonAdapter pointing at a TypeAdapterFactory that declines the type.
  // ---------------------------------------------------------------------

  static class DecliningFactory implements TypeAdapterFactory {
    public <T> TypeAdapter<T> create(Gson gson, TypeToken<T> type) {
      return null;
    }
  }

  @JsonAdapter(DecliningFactory.class)
  static class WithDecliningFactory {
  }

  public void testCreate_whenNestedFactoryDeclines_returnsNull() throws Exception {
    TypeAdapter<WithDecliningFactory> adapter =
        factory.create(gson, TypeToken.get(WithDecliningFactory.class));
    assertNull(adapter);
  }

  // ---------------------------------------------------------------------
  // Fixtures: @JsonAdapter pointing at a JsonSerializer only.
  // ---------------------------------------------------------------------

  static class UpperCasingSerializer implements JsonSerializer<WithSerializerOnly> {
    public JsonElement serialize(WithSerializerOnly src, Type typeOfSrc, JsonSerializationContext context) {
      return new JsonPrimitive("ser:" + src.text);
    }
  }

  @JsonAdapter(UpperCasingSerializer.class)
  static class WithSerializerOnly {
    String text = "hello";
  }

  public void pruned_testCreate_withJsonSerializerOnly_usesSerializerForWriting() throws Exception {
    TypeAdapter<WithSerializerOnly> adapter =
        factory.create(gson, TypeToken.get(WithSerializerOnly.class));
    assertNotNull(adapter);

    WithSerializerOnly value = new WithSerializerOnly();
    value.text = "abc";
    assertEquals("\"ser:abc\"", adapter.toJson(value));
  }

  // ---------------------------------------------------------------------
  // Fixtures: @JsonAdapter pointing at a JsonDeserializer only.
  // ---------------------------------------------------------------------

  static class PrefixingDeserializer implements JsonDeserializer<WithDeserializerOnly> {
    public WithDeserializerOnly deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context)
        throws JsonParseException {
      WithDeserializerOnly result = new WithDeserializerOnly();
      result.text = "deser:" + json.getAsString();
      return result;
    }
  }

  @JsonAdapter(PrefixingDeserializer.class)
  static class WithDeserializerOnly {
    String text;
  }

  public void pruned_testCreate_withJsonDeserializerOnly_usesDeserializerForReading() throws Exception {
    TypeAdapter<WithDeserializerOnly> adapter =
        factory.create(gson, TypeToken.get(WithDeserializerOnly.class));
    assertNotNull(adapter);

    WithDeserializerOnly result = adapter.fromJson("\"hello\"");
    assertEquals("deser:hello", result.text);
  }

  // ---------------------------------------------------------------------
  // Fixtures: @JsonAdapter pointing at a class implementing both interfaces.
  // ---------------------------------------------------------------------

  static class BothSerializerAndDeserializer
      implements JsonSerializer<WithBoth>, JsonDeserializer<WithBoth> {
    public JsonElement serialize(WithBoth src, Type typeOfSrc, JsonSerializationContext context) {
      return new JsonPrimitive("S:" + src.text);
    }

    public WithBoth deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context)
        throws JsonParseException {
      String raw = json.getAsString();
      WithBoth result = new WithBoth();
      result.text = raw.startsWith("S:") ? raw.substring(2) : raw;
      return result;
    }
  }

  @JsonAdapter(BothSerializerAndDeserializer.class)
  static class WithBoth {
    String text = "x";
  }

  public void pruned_testCreate_withBothSerializerAndDeserializer_roundTrips() throws Exception {
    TypeAdapter<WithBoth> adapter = factory.create(gson, TypeToken.get(WithBoth.class));
    assertNotNull(adapter);

    WithBoth value = new WithBoth();
    value.text = "y";
    String json = adapter.toJson(value);
    assertEquals("\"S:y\"", json);

    WithBoth back = adapter.fromJson(json);
    assertEquals("y", back.text);
  }

  // ---------------------------------------------------------------------
  // Fixture: @JsonAdapter pointing at an unsupported class -> error case.
  // ---------------------------------------------------------------------

  @JsonAdapter(String.class)
  static class WithInvalidValue {
  }

  public void testCreate_withUnsupportedAnnotationValue_throwsIllegalArgumentException() throws Exception {
    try {
      factory.create(gson, TypeToken.get(WithInvalidValue.class));
      fail("Expected IllegalArgumentException");
    } catch (IllegalArgumentException expected) {
      assertNotNull(expected.getMessage());
    }
  }

  // ---------------------------------------------------------------------
  // Direct coverage of the package-private static getTypeAdapter() method.
  // ---------------------------------------------------------------------

  public void testGetTypeAdapter_directCall_matchesCreateBehavior() throws Exception {
    JsonAdapter annotation = WithFactory.class.getAnnotation(JsonAdapter.class);
    assertNotNull(annotation);

    TypeToken<WithFactory> type = TypeToken.get(WithFactory.class);
    TypeAdapter<?> adapter =
        JsonAdapterAnnotationTypeAdapterFactory.getTypeAdapter(constructorConstructor, gson, type, annotation);
    assertNotNull(adapter);

    WithFactory value = new WithFactory();
    value.text = "direct";
    @SuppressWarnings("unchecked")
    TypeAdapter<WithFactory> typedAdapter = (TypeAdapter<WithFactory>) adapter;
    assertEquals("\"factory:direct\"", typedAdapter.toJson(value));
  }

  public void testGetTypeAdapter_withInvalidAnnotationValue_throwsIllegalArgumentException() throws Exception {
    JsonAdapter annotation = WithInvalidValue.class.getAnnotation(JsonAdapter.class);
    assertNotNull(annotation);

    try {
      JsonAdapterAnnotationTypeAdapterFactory.getTypeAdapter(
          constructorConstructor, gson, TypeToken.get(WithInvalidValue.class), annotation);
      fail("Expected IllegalArgumentException");
    } catch (IllegalArgumentException expected) {
      // documented-by-implication: an unsupported @JsonAdapter value is an error, not a null result.
    }
  }
}
