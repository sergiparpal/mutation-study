package com.google.gson.internal;

import junit.framework.TestCase;

import java.io.Serializable;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Tests for {@link $Gson$Types} based on the documented contract in api/.
 */
public class $Gson$TypesAgentTest extends TestCase {

    // Fixtures used to exercise generic-hierarchy related methods.
    interface IntegerSet extends Set<Integer> {
    }

    static class Box<T> {
    }

    static class StringBox extends Box<String> {
    }

    // ---- EMPTY_TYPE_ARRAY ----

    public void testEmptyTypeArrayIsEmpty() {
        assertNotNull($Gson$Types.EMPTY_TYPE_ARRAY);
        assertEquals(0, $Gson$Types.EMPTY_TYPE_ARRAY.length);
    }

    // ---- newParameterizedTypeWithOwner ----

    public void testNewParameterizedTypeWithOwnerAppliesArgumentsToRawType() {
        ParameterizedType pt = $Gson$Types.newParameterizedTypeWithOwner(
                null, List.class, String.class);
        assertEquals(List.class, pt.getRawType());
        assertEquals(1, pt.getActualTypeArguments().length);
        assertEquals(String.class, pt.getActualTypeArguments()[0]);
        assertNull(pt.getOwnerType());
    }

    public void testNewParameterizedTypeWithOwnerKeepsOwnerType() {
        ParameterizedType pt = $Gson$Types.newParameterizedTypeWithOwner(
                String.class, List.class, Integer.class);
        assertEquals(String.class, pt.getOwnerType());
        assertEquals(List.class, pt.getRawType());
        assertEquals(Integer.class, pt.getActualTypeArguments()[0]);
    }

    public void testNewParameterizedTypeWithOwnerIsSerializable() {
        ParameterizedType pt = $Gson$Types.newParameterizedTypeWithOwner(
                null, List.class, String.class);
        assertTrue(pt instanceof Serializable);
    }

    // ---- arrayOf ----

    public void testArrayOfReturnsGenericArrayTypeWithGivenComponent() {
        GenericArrayType arrayType = $Gson$Types.arrayOf(String.class);
        assertEquals(String.class, arrayType.getGenericComponentType());
    }

    public void testArrayOfIsSerializable() {
        GenericArrayType arrayType = $Gson$Types.arrayOf(String.class);
        assertTrue(arrayType instanceof Serializable);
    }

    // ---- subtypeOf ----

    public void testSubtypeOfWithClassBound() {
        WildcardType wildcard = $Gson$Types.subtypeOf(CharSequence.class);
        assertEquals(1, wildcard.getUpperBounds().length);
        assertEquals(CharSequence.class, wildcard.getUpperBounds()[0]);
        assertEquals(0, wildcard.getLowerBounds().length);
    }

    public void testSubtypeOfWithObjectBoundIsShorthandForExtendsObject() {
        WildcardType wildcard = $Gson$Types.subtypeOf(Object.class);
        assertEquals(1, wildcard.getUpperBounds().length);
        assertEquals(Object.class, wildcard.getUpperBounds()[0]);
        assertEquals(0, wildcard.getLowerBounds().length);
    }

    // ---- supertypeOf ----

    public void testSupertypeOfSetsLowerBoundToGivenBound() {
        WildcardType wildcard = $Gson$Types.supertypeOf(String.class);
        assertEquals(1, wildcard.getLowerBounds().length);
        assertEquals(String.class, wildcard.getLowerBounds()[0]);
        // "? super T" always has an implicit upper bound of Object.
        assertEquals(1, wildcard.getUpperBounds().length);
        assertEquals(Object.class, wildcard.getUpperBounds()[0]);
    }

    // ---- canonicalize ----

    public void testCanonicalizeOfRawClassIsFunctionallyEqual() {
        Type canonical = $Gson$Types.canonicalize(String.class);
        assertTrue($Gson$Types.equals(String.class, canonical));
    }

    public void testCanonicalizeReturnsSerializableType() {
        ParameterizedType pt = $Gson$Types.newParameterizedTypeWithOwner(
                null, List.class, String.class);
        Type canonical = $Gson$Types.canonicalize(pt);
        assertTrue(canonical instanceof Serializable);
        assertTrue($Gson$Types.equals(pt, canonical));
    }

    public void testCanonicalizeOfArrayClassIsFunctionallyEqualToArrayOf() {
        Type canonical = $Gson$Types.canonicalize(String[].class);
        Type expected = $Gson$Types.arrayOf(String.class);
        assertTrue($Gson$Types.equals(expected, canonical));
    }

    // ---- getRawType ----

    public void testGetRawTypeOfClassIsItself() {
        assertEquals(String.class, $Gson$Types.getRawType(String.class));
    }

    public void testGetRawTypeOfParameterizedTypeIsItsRawType() {
        ParameterizedType pt = $Gson$Types.newParameterizedTypeWithOwner(
                null, List.class, String.class);
        assertEquals(List.class, $Gson$Types.getRawType(pt));
    }

    public void testGetRawTypeOfGenericArrayTypeIsArrayClassOfComponentRawType() {
        GenericArrayType arrayType = $Gson$Types.arrayOf(String.class);
        assertEquals(String[].class, $Gson$Types.getRawType(arrayType));
    }

    public void testGetRawTypeOfWildcardTypeIsRawTypeOfUpperBound() {
        WildcardType wildcard = $Gson$Types.subtypeOf(String.class);
        assertEquals(String.class, $Gson$Types.getRawType(wildcard));
    }

    public void testGetRawTypeOfTypeVariableIsObject() {
        TypeVariable<?> typeVariable = Box.class.getTypeParameters()[0];
        assertEquals(Object.class, $Gson$Types.getRawType(typeVariable));
    }

    // ---- equal (package-private helper) ----

    public void testEqualWithBothNullIsTrue() {
        assertTrue($Gson$Types.equal(null, null));
    }

    public void testEqualWithOneNullIsFalse() {
        assertFalse($Gson$Types.equal(null, "a"));
        assertFalse($Gson$Types.equal("a", null));
    }

    public void testEqualWithEqualValuesIsTrue() {
        assertTrue($Gson$Types.equal("a", "a"));
    }

    public void testEqualWithDifferentValuesIsFalse() {
        assertFalse($Gson$Types.equal("a", "b"));
    }

    // ---- equals(Type, Type) ----

    public void testEqualsOfSameClassIsTrue() {
        assertTrue($Gson$Types.equals(String.class, String.class));
    }

    public void testEqualsOfDifferentClassesIsFalse() {
        assertFalse($Gson$Types.equals(String.class, Integer.class));
    }

    public void testEqualsOfFunctionallyEqualParameterizedTypesIsTrue() {
        ParameterizedType a = $Gson$Types.newParameterizedTypeWithOwner(
                null, List.class, String.class);
        ParameterizedType b = $Gson$Types.newParameterizedTypeWithOwner(
                null, List.class, String.class);
        assertNotSame(a, b);
        assertTrue($Gson$Types.equals(a, b));
    }

    public void testEqualsOfParameterizedTypesWithDifferentArgumentsIsFalse() {
        ParameterizedType a = $Gson$Types.newParameterizedTypeWithOwner(
                null, List.class, String.class);
        ParameterizedType b = $Gson$Types.newParameterizedTypeWithOwner(
                null, List.class, Integer.class);
        assertFalse($Gson$Types.equals(a, b));
    }

    // ---- hashCodeOrZero ----

    public void testHashCodeOrZeroOfNullIsZero() {
        assertEquals(0, $Gson$Types.hashCodeOrZero(null));
    }

    public void testHashCodeOrZeroOfNonNullMatchesObjectHashCode() {
        String value = "abc";
        assertEquals(value.hashCode(), $Gson$Types.hashCodeOrZero(value));
    }

    // ---- typeToString ----

    public void testTypeToStringOfClassIsDeterministicAndDescriptive() {
        String first = $Gson$Types.typeToString(String.class);
        String second = $Gson$Types.typeToString(String.class);
        assertNotNull(first);
        assertEquals(first, second);
        assertTrue(first.indexOf("String") >= 0);
    }

    public void testTypeToStringOfParameterizedTypeIsDescriptive() {
        ParameterizedType pt = $Gson$Types.newParameterizedTypeWithOwner(
                null, List.class, String.class);
        String result = $Gson$Types.typeToString(pt);
        assertNotNull(result);
        assertTrue(result.indexOf("List") >= 0);
        assertTrue(result.indexOf("String") >= 0);
    }

    // ---- getGenericSupertype ----

    public void testGetGenericSupertypeForDirectInterface() {
        Type result = $Gson$Types.getGenericSupertype(
                IntegerSet.class, IntegerSet.class, Set.class);
        assertTrue(result instanceof ParameterizedType);
        ParameterizedType pt = (ParameterizedType) result;
        assertEquals(Set.class, pt.getRawType());
        assertEquals(Integer.class, pt.getActualTypeArguments()[0]);
    }

    public void pruned_testGetGenericSupertypeForIndirectInterface() {
        Type result = $Gson$Types.getGenericSupertype(
                IntegerSet.class, IntegerSet.class, Collection.class);
        assertTrue(result instanceof ParameterizedType);
        ParameterizedType pt = (ParameterizedType) result;
        assertEquals(Collection.class, pt.getRawType());
        assertEquals(Integer.class, pt.getActualTypeArguments()[0]);
    }

    // ---- getSupertype ----

    public void testGetSupertypeResolvesGenericFormOfInterface() {
        ParameterizedType context = $Gson$Types.newParameterizedTypeWithOwner(
                null, ArrayList.class, String.class);
        Type result = $Gson$Types.getSupertype(context, ArrayList.class, Iterable.class);
        assertTrue(result instanceof ParameterizedType);
        ParameterizedType pt = (ParameterizedType) result;
        assertEquals(Iterable.class, pt.getRawType());
        assertEquals(String.class, pt.getActualTypeArguments()[0]);
    }

    public void testGetSupertypeThrowsWhenNotASupertype() {
        try {
            $Gson$Types.getSupertype(String.class, String.class, List.class);
            fail("Expected IllegalArgumentException because String does not implement List");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    // ---- getArrayComponentType ----

    public void testGetArrayComponentTypeOfObjectArray() {
        assertEquals(String.class, $Gson$Types.getArrayComponentType(String[].class));
    }

    public void testGetArrayComponentTypeOfPrimitiveArray() {
        assertEquals(int.class, $Gson$Types.getArrayComponentType(int[].class));
    }

    public void testGetArrayComponentTypeOfGenericArrayType() {
        GenericArrayType arrayType = $Gson$Types.arrayOf(String.class);
        assertEquals(String.class, $Gson$Types.getArrayComponentType(arrayType));
    }

    public void testGetArrayComponentTypeThrowsForNonArrayType() {
        ParameterizedType notAnArray = $Gson$Types.newParameterizedTypeWithOwner(
                null, List.class, String.class);
        try {
            $Gson$Types.getArrayComponentType(notAnArray);
            fail("Expected ClassCastException because the type is not an array");
        } catch (ClassCastException expected) {
            // expected
        }
    }

    // ---- getCollectionElementType ----

    public void testGetCollectionElementTypeOfParameterizedList() {
        ParameterizedType context = $Gson$Types.newParameterizedTypeWithOwner(
                null, List.class, String.class);
        Type result = $Gson$Types.getCollectionElementType(context, List.class);
        assertEquals(String.class, result);
    }

    public void testGetCollectionElementTypeThrowsForNonCollection() {
        try {
            $Gson$Types.getCollectionElementType(Map.class, Map.class);
            fail("Expected IllegalArgumentException because Map is not a Collection");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    // ---- getMapKeyAndValueTypes ----

    public void testGetMapKeyAndValueTypesReturnsKeyAndValueInOrder() {
        ParameterizedType context = $Gson$Types.newParameterizedTypeWithOwner(
                null, Map.class, String.class, Integer.class);
        Type[] result = $Gson$Types.getMapKeyAndValueTypes(context, Map.class);
        assertEquals(2, result.length);
        assertEquals(String.class, result[0]);
        assertEquals(Integer.class, result[1]);
    }

    // ---- resolve ----

    public void testResolvePassesThroughTypeWithoutVariables() {
        Type result = $Gson$Types.resolve(Object.class, Object.class, String.class);
        assertEquals(String.class, result);
    }

    // ---- resolveTypeVariable ----

    public void testResolveTypeVariableResolvesToConcreteArgument() {
        TypeVariable<?> unknown = Box.class.getTypeParameters()[0];
        Type result = $Gson$Types.resolveTypeVariable(StringBox.class, StringBox.class, unknown);
        assertEquals(String.class, result);
    }

    // ---- checkNotPrimitive ----

    public void testCheckNotPrimitiveAllowsNonPrimitiveType() {
        $Gson$Types.checkNotPrimitive(String.class);
        // no exception expected
    }

    public void testCheckNotPrimitiveRejectsPrimitiveType() {
        try {
            $Gson$Types.checkNotPrimitive(int.class);
            fail("Expected an exception because int is a primitive type");
        } catch (RuntimeException expected) {
            // expected: contract rejects primitive types
        }
    }
}
