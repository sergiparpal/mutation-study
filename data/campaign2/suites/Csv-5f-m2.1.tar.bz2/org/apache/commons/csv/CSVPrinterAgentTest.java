/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.csv;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.Closeable;
import java.io.Flushable;
import java.io.IOException;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

public class CSVPrinterAgentTest {

    private static final String RECORD_SEPARATOR = CSVFormat.DEFAULT.getRecordSeparator();

    /** Appendable that is neither Closeable nor Flushable, to exercise the instanceof checks. */
    private static class PlainAppendable implements Appendable {
        private final StringBuilder sb = new StringBuilder();

        public Appendable append(final CharSequence csq) {
            sb.append(csq);
            return this;
        }

        public Appendable append(final CharSequence csq, final int start, final int end) {
            sb.append(csq, start, end);
            return this;
        }

        public Appendable append(final char c) {
            sb.append(c);
            return this;
        }

        public String toString() {
            return sb.toString();
        }
    }

    /** Appendable that tracks whether close()/flush() were invoked. */
    private static class TrackingAppendable implements Appendable, Closeable, Flushable {
        private final StringBuilder sb = new StringBuilder();
        private boolean closed = false;
        private boolean flushed = false;

        public Appendable append(final CharSequence csq) {
            sb.append(csq);
            return this;
        }

        public Appendable append(final CharSequence csq, final int start, final int end) {
            sb.append(csq, start, end);
            return this;
        }

        public Appendable append(final char c) {
            sb.append(c);
            return this;
        }

        public void close() throws IOException {
            closed = true;
        }

        public void flush() throws IOException {
            flushed = true;
        }

        public String toString() {
            return sb.toString();
        }
    }

    @Test
    public void testConstructorNullOutThrows() {
        try {
            new CSVPrinter(null, CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testConstructorNullFormatThrows() {
        try {
            new CSVPrinter(new StringWriter(), null);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testConstructorInvalidFormatThrows() {
        // quoteChar equal to delimiter is inconsistent and must be rejected during construction
        final CSVFormat badFormat = CSVFormat.DEFAULT.withDelimiter(',').withQuoteChar(',');
        try {
            new CSVPrinter(new StringWriter(), badFormat);
            fail("Expected IllegalStateException");
        } catch (final IllegalStateException e) {
            // expected
        }
    }

    @Test
    public void testGetOutReturnsSameInstance() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        assertTrue(printer.getOut() == sw);
    }

    @Test
    public void testPrintSimpleValue() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("a");
        assertEquals("a", sw.toString());
    }

    @Test
    public void testPrintNullValueUsesEmptyByDefault() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("x");
        printer.print(null);
        // the empty string following a delimiter is not the first token on the line, so it is not quoted
        assertEquals("x,", sw.toString());
    }

    @Test
    public void testPrintNullValueUsesNullString() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT.withNullString("NULL"));
        printer.print(null);
        assertEquals("NULL", sw.toString());
    }

    @Test
    public void testDelimiterInsertedBetweenValues() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("a");
        printer.print("b");
        printer.print("c");
        assertEquals("a,b,c", sw.toString());
    }

    @Test
    public void testPrintRecordVarargs() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecord("a", "b", "c");
        assertEquals("a,b,c" + RECORD_SEPARATOR, sw.toString());
    }

    @Test
    public void testPrintRecordIterable() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final List<String> values = new ArrayList<String>();
        values.add("a");
        values.add("b");
        printer.printRecord(values);
        assertEquals("a,b" + RECORD_SEPARATOR, sw.toString());
    }

    @Test
    public void testPrintRecordEmptyVarargs() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecord(new Object[0]);
        assertEquals(RECORD_SEPARATOR, sw.toString());
    }

    @Test
    public void testPrintRecordsIterableOfArrays() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final List<Object> records = new ArrayList<Object>();
        records.add(new String[] { "a", "b" });
        records.add(new String[] { "c", "d" });
        printer.printRecords(records);
        assertEquals("a,b" + RECORD_SEPARATOR + "c,d" + RECORD_SEPARATOR, sw.toString());
    }

    @Test
    public void testPrintRecordsIterableOfIterables() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final List<Object> records = new ArrayList<Object>();
        final List<String> row1 = new ArrayList<String>();
        row1.add("a");
        row1.add("b");
        records.add(row1);
        printer.printRecords(records);
        assertEquals("a,b" + RECORD_SEPARATOR, sw.toString());
    }

    @Test
    public void testPrintRecordsArrayOfScalars() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecords(new Object[] { "a", "b" });
        assertEquals("a" + RECORD_SEPARATOR + "b" + RECORD_SEPARATOR, sw.toString());
    }

    @Test
    public void testPrintln() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("a");
        printer.println();
        printer.print("b");
        assertEquals("a" + RECORD_SEPARATOR + "b", sw.toString());
    }

    @Test
    public void testPrintlnWithNullRecordSeparatorAppendsNothing() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT.withRecordSeparator((String) null));
        printer.print("a");
        printer.println();
        printer.print("b");
        assertEquals("ab", sw.toString());
    }

    @Test
    public void testQuotingOfValueContainingDelimiter() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("a,b");
        assertEquals("\"a,b\"", sw.toString());
    }

    @Test
    public void testQuotingOfValueContainingQuoteCharDoublesIt() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("a\"b");
        assertEquals("\"a\"\"b\"", sw.toString());
    }

    @Test
    public void testQuoteAllPolicyQuotesEverything() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT.withQuotePolicy(Quote.ALL));
        printer.print("a");
        assertEquals("\"a\"", sw.toString());
    }

    @Test
    public void testQuoteNonNumericPolicyLeavesNumbersUnquoted() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT.withQuotePolicy(Quote.NON_NUMERIC));
        printer.print(Integer.valueOf(42));
        printer.print("a");
        assertEquals("42,\"a\"", sw.toString());
    }

    @Test
    public void testQuoteNonePolicyEscapesInsteadOfQuoting() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withQuotePolicy(Quote.NONE).withEscape('!');
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        printer.print("a,b");
        assertEquals("a!,b", sw.toString());
    }

    @Test
    public void testEmptyFirstValueOnLineIsQuotedUnderMinimalPolicy() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("");
        assertEquals("\"\"", sw.toString());
    }

    @Test
    public void testEscapingWhenQuotingDisabled() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withQuoteChar((Character) null).withEscape('\\');
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        printer.print("a,b\nc");
        assertEquals("a\\,b\\nc", sw.toString());
    }

    @Test
    public void testPrintCommentWhenDisabledDoesNothing() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printComment("comment");
        assertEquals("", sw.toString());
    }

    @Test
    public void testPrintCommentWhenEnabled() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withCommentStart('#');
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printComment("comment");
        assertEquals("# comment" + RECORD_SEPARATOR, sw.toString());
    }

    @Test
    public void testPrintCommentWithEmbeddedNewlineSplitsLines() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withCommentStart('#');
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printComment("line1\nline2");
        assertEquals("# line1" + RECORD_SEPARATOR + "# line2" + RECORD_SEPARATOR, sw.toString());
    }

    @Test
    public void testPrintCommentStartsOnNewLineIfMidRecord() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withCommentStart('#');
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, format);
        printer.print("a");
        printer.printComment("c");
        assertEquals("a" + RECORD_SEPARATOR + "# c" + RECORD_SEPARATOR, sw.toString());
    }

    @Test
    public void testCloseDelegatesToCloseableAppendable() throws IOException {
        final TrackingAppendable appendable = new TrackingAppendable();
        final CSVPrinter printer = new CSVPrinter(appendable, CSVFormat.DEFAULT);
        assertFalse(appendable.closed);
        printer.close();
        assertTrue(appendable.closed);
    }

    @Test
    public void testFlushDelegatesToFlushableAppendable() throws IOException {
        final TrackingAppendable appendable = new TrackingAppendable();
        final CSVPrinter printer = new CSVPrinter(appendable, CSVFormat.DEFAULT);
        assertFalse(appendable.flushed);
        printer.flush();
        assertTrue(appendable.flushed);
    }

    @Test
    public void testCloseOnNonCloseableAppendableIsNoOp() throws IOException {
        final PlainAppendable appendable = new PlainAppendable();
        final CSVPrinter printer = new CSVPrinter(appendable, CSVFormat.DEFAULT);
        printer.print("a");
        printer.close();
        assertEquals("a", appendable.toString());
    }

    @Test
    public void testFlushOnNonFlushableAppendableIsNoOp() throws IOException {
        final PlainAppendable appendable = new PlainAppendable();
        final CSVPrinter printer = new CSVPrinter(appendable, CSVFormat.DEFAULT);
        printer.print("a");
        printer.flush();
        assertEquals("a", appendable.toString());
    }

    @Test
    public void testPrintRecordsWithNestedArrayAndIterable() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final List<String> row = new ArrayList<String>();
        row.add("x");
        row.add("y");
        printer.printRecords(new Object[] { new String[] { "a", "b" }, row, "scalar" });
        assertEquals("a,b" + RECORD_SEPARATOR + "x,y" + RECORD_SEPARATOR + "scalar" + RECORD_SEPARATOR,
                sw.toString());
    }
}
