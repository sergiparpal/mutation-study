/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang.time;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import java.util.TimeZone;

/**
 * TestCase for DurationFormatUtils.
 */
public class DurationFormatUtilsAgentTest extends TestCase {

    public DurationFormatUtilsAgentTest(String name) {
        super(name);
    }

    public static Test suite() {
        return new TestSuite(DurationFormatUtilsAgentTest.class);
    }

    public void testFormatDurationHMSZero() {
        assertEquals("0:00:00.000", DurationFormatUtils.formatDurationHMS(0));
    }

    public void testFormatDurationHMSTypical() {
        // 1h 2m 3s 5ms
        assertEquals("1:02:03.005", DurationFormatUtils.formatDurationHMS(3723005L));
    }

    public void testFormatDurationHMSNegative() {
        // negative durations are not clamped; the sign shows up on the
        // first field that goes negative
        assertEquals("0:00:-1.000", DurationFormatUtils.formatDurationHMS(-1000L));
    }

    public void testFormatDurationISOZero() {
        assertEquals("P0Y0M0DT0H0M0.000S", DurationFormatUtils.formatDurationISO(0));
    }

    public void testFormatDurationISOTypical() {
        assertEquals("P0Y0M0DT1H2M3.005S", DurationFormatUtils.formatDurationISO(3723005L));
    }

    public void testFormatDurationWithoutPadding() {
        assertEquals("1:2:3.005", DurationFormatUtils.formatDuration(3723005L, "H:m:s.S", false));
    }

    public void testFormatDurationWithPadding() {
        assertEquals("01:02:03.005", DurationFormatUtils.formatDuration(3723005L, "HH:mm:ss.SSS", true));
    }

    public void testFormatDurationDefaultsToPadded() {
        assertEquals(DurationFormatUtils.formatDuration(3723005L, "HH:mm:ss.SSS", true),
                DurationFormatUtils.formatDuration(3723005L, "HH:mm:ss.SSS"));
    }

    public void testFormatDurationEmptyFormat() {
        assertEquals("", DurationFormatUtils.formatDuration(1000L, ""));
    }

    public void testFormatDurationNullFormatThrows() {
        try {
            DurationFormatUtils.formatDuration(1000L, null);
            fail("Expected NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
    }

    public void testFormatDurationNegativeDaysAndHours() {
        // -90000000 ms = -1 day, -1 hour (truncating division)
        assertEquals("-1 days -1 hours",
                DurationFormatUtils.formatDuration(-90000000L, "d' days 'H' hours'"));
    }

    public void testFormatDurationWordsFull() {
        // 1 day, 2 hours, 2 minutes, 3 seconds, 5 ms
        assertEquals("1 day 2 hours 2 minutes 3 seconds",
                DurationFormatUtils.formatDurationWords(93723005L, false, false));
    }

    public void testFormatDurationWordsNoSuppression() {
        assertEquals("0 days 1 hour 2 minutes 3 seconds",
                DurationFormatUtils.formatDurationWords(3723005L, false, false));
    }

    public void testFormatDurationWordsSuppressLeadingAndTrailing() {
        assertEquals("5 seconds", DurationFormatUtils.formatDurationWords(5000L, true, true));
    }

    public void testFormatDurationWordsZeroSuppressedBecomesEmpty() {
        assertEquals("0 seconds", DurationFormatUtils.formatDurationWords(0L, true, true));
    }

    public void testFormatDurationWordsZeroNotSuppressed() {
        assertEquals("0 days 0 hours 0 minutes 0 seconds",
                DurationFormatUtils.formatDurationWords(0L, false, false));
    }

    public void testFormatDurationWordsSingularDay() {
        assertEquals("1 day", DurationFormatUtils.formatDurationWords(86400000L, true, true));
    }

    public void testFormatDurationWordsSingularSecond() {
        assertEquals("1 second", DurationFormatUtils.formatDurationWords(1000L, true, true));
    }

    public void testFormatPeriodISOShortDelegatesToDuration() {
        // under 28 days, formatPeriodISO just delegates to formatDurationISO
        assertEquals(DurationFormatUtils.formatDurationISO(3723005L),
                DurationFormatUtils.formatPeriodISO(0L, 3723005L));
    }

    public void testFormatPeriodShortUsesDefaultPadding() {
        assertEquals("0:00:01.000", DurationFormatUtils.formatPeriod(0L, 1000L, "H:mm:ss.SSS"));
    }

    public void testFormatPeriodLongWithExplicitTimeZone() {
        TimeZone gmt = TimeZone.getTimeZone("GMT");
        long start = 0L;
        long end = 40L * 24 * 60 * 60 * 1000L; // 40 days later, crosses the 28 day threshold
        assertEquals("0000-01-09",
                DurationFormatUtils.formatPeriod(start, end, "yyyy-MM-dd", true, gmt));
    }

    public void testFormatPeriodStartAfterEndIsNegative() {
        assertEquals("-1:-2:-3.95",
                DurationFormatUtils.formatPeriod(3723005L, 0L, "H:mm:ss.SSS"));
    }

    public void testFormatPeriodNullFormatThrows() {
        TimeZone gmt = TimeZone.getTimeZone("GMT");
        try {
            DurationFormatUtils.formatPeriod(0L, 40L * 24 * 60 * 60 * 1000L, null, true, gmt);
            fail("Expected NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
    }

    public void testFormatPeriodZeroLength() {
        assertEquals("0:00:00.000", DurationFormatUtils.formatPeriod(5000L, 5000L, "H:mm:ss.SSS"));
    }
}
