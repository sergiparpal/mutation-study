/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import java.math.BigDecimal;
import java.math.BigInteger;

import junit.framework.TestCase;

/**
 * Unit tests {@link org.apache.commons.lang3.math.NumberUtils}.
 */
public class NumberUtilsAgentTest extends TestCase {

    public void testConstructor() {
        assertNotNull(new NumberUtils());
    }

    public void testConstants() {
        assertEquals(0L, NumberUtils.LONG_ZERO.longValue());
        assertEquals(1L, NumberUtils.LONG_ONE.longValue());
        assertEquals(-1L, NumberUtils.LONG_MINUS_ONE.longValue());
        assertEquals(0, NumberUtils.INTEGER_ZERO.intValue());
        assertEquals(1, NumberUtils.INTEGER_ONE.intValue());
        assertEquals(-1, NumberUtils.INTEGER_MINUS_ONE.intValue());
        assertEquals((short) 0, NumberUtils.SHORT_ZERO.shortValue());
        assertEquals((short) 1, NumberUtils.SHORT_ONE.shortValue());
        assertEquals((short) -1, NumberUtils.SHORT_MINUS_ONE.shortValue());
        assertEquals((byte) 0, NumberUtils.BYTE_ZERO.byteValue());
        assertEquals((byte) 1, NumberUtils.BYTE_ONE.byteValue());
        assertEquals((byte) -1, NumberUtils.BYTE_MINUS_ONE.byteValue());
        assertEquals(0.0d, NumberUtils.DOUBLE_ZERO.doubleValue(), 0.0d);
        assertEquals(1.0d, NumberUtils.DOUBLE_ONE.doubleValue(), 0.0d);
        assertEquals(-1.0d, NumberUtils.DOUBLE_MINUS_ONE.doubleValue(), 0.0d);
        assertEquals(0.0f, NumberUtils.FLOAT_ZERO.floatValue(), 0.0f);
        assertEquals(1.0f, NumberUtils.FLOAT_ONE.floatValue(), 0.0f);
        assertEquals(-1.0f, NumberUtils.FLOAT_MINUS_ONE.floatValue(), 0.0f);
    }

    // -------------------- toInt --------------------

    public void testToInt() {
        assertEquals(0, NumberUtils.toInt(null));
        assertEquals(0, NumberUtils.toInt(""));
        assertEquals(1, NumberUtils.toInt("1"));
        assertEquals(-1, NumberUtils.toInt("-1"));
        assertEquals(0, NumberUtils.toInt("not a number"));
    }

    public void testToIntWithDefault() {
        assertEquals(1, NumberUtils.toInt(null, 1));
        assertEquals(1, NumberUtils.toInt("", 1));
        assertEquals(1, NumberUtils.toInt("1", 0));
        assertEquals(-1, NumberUtils.toInt("-1", 0));
        assertEquals(5, NumberUtils.toInt("not a number", 5));
    }

    // -------------------- toLong --------------------

    public void testToLong() {
        assertEquals(0L, NumberUtils.toLong(null));
        assertEquals(0L, NumberUtils.toLong(""));
        assertEquals(1L, NumberUtils.toLong("1"));
        assertEquals(0L, NumberUtils.toLong("not a number"));
        // too big for int, fits in long
        assertEquals(12345678901L, NumberUtils.toLong("12345678901"));
    }

    public void testToLongWithDefault() {
        assertEquals(1L, NumberUtils.toLong(null, 1L));
        assertEquals(1L, NumberUtils.toLong("", 1L));
        assertEquals(1L, NumberUtils.toLong("1", 0L));
        assertEquals(5L, NumberUtils.toLong("not a number", 5L));
    }

    // -------------------- toFloat --------------------

    public void testToFloat() {
        assertEquals(0.0f, NumberUtils.toFloat(null), 0.0f);
        assertEquals(0.0f, NumberUtils.toFloat(""), 0.0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5"), 0.0f);
        assertEquals(0.0f, NumberUtils.toFloat("not a number"), 0.0f);
    }

    public void testToFloatWithDefault() {
        assertEquals(1.1f, NumberUtils.toFloat(null, 1.1f), 0.0f);
        assertEquals(1.1f, NumberUtils.toFloat("", 1.1f), 0.0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5", 0.0f), 0.0f);
        assertEquals(9.9f, NumberUtils.toFloat("not a number", 9.9f), 0.0f);
    }

    // -------------------- toDouble --------------------

    public void testToDouble() {
        assertEquals(0.0d, NumberUtils.toDouble(null), 0.0d);
        assertEquals(0.0d, NumberUtils.toDouble(""), 0.0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5"), 0.0d);
        assertEquals(0.0d, NumberUtils.toDouble("not a number"), 0.0d);
    }

    public void testToDoubleWithDefault() {
        assertEquals(1.1d, NumberUtils.toDouble(null, 1.1d), 0.0d);
        assertEquals(1.1d, NumberUtils.toDouble("", 1.1d), 0.0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5", 0.0d), 0.0d);
        assertEquals(9.9d, NumberUtils.toDouble("not a number", 9.9d), 0.0d);
    }

    // -------------------- toByte --------------------

    public void testToByte() {
        assertEquals((byte) 0, NumberUtils.toByte(null));
        assertEquals((byte) 0, NumberUtils.toByte(""));
        assertEquals((byte) 1, NumberUtils.toByte("1"));
        assertEquals((byte) 0, NumberUtils.toByte("not a number"));
    }

    public void testToByteWithDefault() {
        assertEquals((byte) 1, NumberUtils.toByte(null, (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("", (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("1", (byte) 0));
        assertEquals((byte) 5, NumberUtils.toByte("not a number", (byte) 5));
    }

    // -------------------- toShort --------------------

    public void testToShort() {
        assertEquals((short) 0, NumberUtils.toShort(null));
        assertEquals((short) 0, NumberUtils.toShort(""));
        assertEquals((short) 1, NumberUtils.toShort("1"));
        assertEquals((short) 0, NumberUtils.toShort("not a number"));
    }

    public void testToShortWithDefault() {
        assertEquals((short) 1, NumberUtils.toShort(null, (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("", (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("1", (short) 0));
        assertEquals((short) 5, NumberUtils.toShort("not a number", (short) 5));
    }

    // -------------------- createNumber --------------------

    public void testCreateNumberNull() throws Exception {
        assertNull(NumberUtils.createNumber(null));
    }

    public void testCreateNumberBlankThrows() {
        try {
            NumberUtils.createNumber("");
            fail("Expected NumberFormatException for blank string");
        } catch (NumberFormatException e) {
            // expected
        }
        try {
            NumberUtils.createNumber("   ");
            fail("Expected NumberFormatException for blank string");
        } catch (NumberFormatException e) {
            // expected
        }
    }

    public void testCreateNumberDoubleMinus() throws Exception {
        assertNull(NumberUtils.createNumber("--1"));
    }

    public void testCreateNumberHex() throws Exception {
        Number n = NumberUtils.createNumber("0xFF");
        assertEquals(Integer.class, n.getClass());
        assertEquals(255, n.intValue());

        Number neg = NumberUtils.createNumber("-0xFF");
        assertEquals(-255, neg.intValue());
    }

    public void testCreateNumberInteger() throws Exception {
        Number n = NumberUtils.createNumber("123");
        assertEquals(Integer.class, n.getClass());
        assertEquals(123, n.intValue());
    }

    public void testCreateNumberLongWhenTooBigForInt() throws Exception {
        Number n = NumberUtils.createNumber("12345678901");
        assertEquals(Long.class, n.getClass());
        assertEquals(12345678901L, n.longValue());
    }

    public void testCreateNumberBigIntegerWhenTooBigForLong() throws Exception {
        String big = "123456789012345678901234567890";
        Number n = NumberUtils.createNumber(big);
        assertEquals(BigInteger.class, n.getClass());
        assertEquals(new BigInteger(big), n);
    }

    public void testCreateNumberFloatSuffix() throws Exception {
        Number n = NumberUtils.createNumber("1.5f");
        assertEquals(Float.class, n.getClass());
        assertEquals(1.5f, n.floatValue(), 0.0f);
    }

    public void testCreateNumberDoubleSuffix() throws Exception {
        Number n = NumberUtils.createNumber("1.5d");
        assertEquals(Double.class, n.getClass());
        assertEquals(1.5d, n.doubleValue(), 0.0d);
    }

    public void testCreateNumberLongSuffix() throws Exception {
        Number n = NumberUtils.createNumber("123L");
        assertEquals(Long.class, n.getClass());
        assertEquals(123L, n.longValue());
    }

    public void testCreateNumberInvalidLongSuffixThrows() {
        try {
            NumberUtils.createNumber("1.5L");
            fail("Expected NumberFormatException");
        } catch (NumberFormatException e) {
            // expected
        }
    }

    public void testCreateNumberDecimalDefaultsToFloatOrDouble() throws Exception {
        Number n = NumberUtils.createNumber("1.5");
        assertTrue(n instanceof Float || n instanceof Double);
        assertEquals(1.5d, n.doubleValue(), 0.0001d);
    }

    public void testCreateNumberBigDecimalWhenTooBigForDouble() throws Exception {
        // beyond both Float and Double range, so it must fall back to BigDecimal
        String huge = "1.5E400";
        Number n = NumberUtils.createNumber(huge);
        assertEquals(BigDecimal.class, n.getClass());
        assertEquals(new BigDecimal(huge), n);
    }

    public void testCreateNumberInvalidThrows() {
        try {
            NumberUtils.createNumber("not a number");
            fail("Expected NumberFormatException");
        } catch (NumberFormatException e) {
            // expected
        }
    }

    public void testCreateNumberExpBeforeDecimalThrows() {
        try {
            NumberUtils.createNumber("1e2.3");
            fail("Expected NumberFormatException");
        } catch (NumberFormatException e) {
            // expected
        }
    }

    // -------------------- createFloat/createDouble/createInteger/createLong/createBigInteger/createBigDecimal --------------------

    public void testCreateFloat() {
        assertNull(NumberUtils.createFloat(null));
        assertEquals(1.5f, NumberUtils.createFloat("1.5").floatValue(), 0.0f);
        try {
            NumberUtils.createFloat("not a number");
            fail("Expected NumberFormatException");
        } catch (NumberFormatException e) {
            // expected
        }
    }

    public void testCreateDouble() {
        assertNull(NumberUtils.createDouble(null));
        assertEquals(1.5d, NumberUtils.createDouble("1.5").doubleValue(), 0.0d);
        try {
            NumberUtils.createDouble("not a number");
            fail("Expected NumberFormatException");
        } catch (NumberFormatException e) {
            // expected
        }
    }

    public void testCreateInteger() {
        assertNull(NumberUtils.createInteger(null));
        assertEquals(123, NumberUtils.createInteger("123").intValue());
        assertEquals(255, NumberUtils.createInteger("0xFF").intValue());
        try {
            NumberUtils.createInteger("not a number");
            fail("Expected NumberFormatException");
        } catch (NumberFormatException e) {
            // expected
        }
    }

    public void testCreateLong() {
        assertNull(NumberUtils.createLong(null));
        assertEquals(123L, NumberUtils.createLong("123").longValue());
        try {
            NumberUtils.createLong("not a number");
            fail("Expected NumberFormatException");
        } catch (NumberFormatException e) {
            // expected
        }
    }

    public void testCreateBigInteger() {
        assertNull(NumberUtils.createBigInteger(null));
        assertEquals(BigInteger.valueOf(123L), NumberUtils.createBigInteger("123"));
        try {
            NumberUtils.createBigInteger("not a number");
            fail("Expected NumberFormatException");
        } catch (NumberFormatException e) {
            // expected
        }
    }

    public void testCreateBigDecimal() {
        assertNull(NumberUtils.createBigDecimal(null));
        assertEquals(new BigDecimal("123.45"), NumberUtils.createBigDecimal("123.45"));
        try {
            NumberUtils.createBigDecimal("");
            fail("Expected NumberFormatException for blank string");
        } catch (NumberFormatException e) {
            // expected
        }
        try {
            NumberUtils.createBigDecimal("not a number");
            fail("Expected NumberFormatException");
        } catch (NumberFormatException e) {
            // expected
        }
    }

    // -------------------- min/max arrays --------------------

    public void testMinLongArray() {
        assertEquals(1L, NumberUtils.min(new long[] { 3L, 1L, 2L }));
        assertEquals(5L, NumberUtils.min(new long[] { 5L }));
        try {
            NumberUtils.min((long[]) null);
            fail("Expected IllegalArgumentException for null array");
        } catch (IllegalArgumentException e) {
            // expected
        }
        try {
            NumberUtils.min(new long[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testMaxLongArray() {
        assertEquals(3L, NumberUtils.max(new long[] { 3L, 1L, 2L }));
        try {
            NumberUtils.max((long[]) null);
            fail("Expected IllegalArgumentException for null array");
        } catch (IllegalArgumentException e) {
            // expected
        }
        try {
            NumberUtils.max(new long[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testMinIntArray() {
        assertEquals(1, NumberUtils.min(new int[] { 3, 1, 2 }));
        try {
            NumberUtils.min((int[]) null);
            fail("Expected IllegalArgumentException for null array");
        } catch (IllegalArgumentException e) {
            // expected
        }
        try {
            NumberUtils.min(new int[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testMaxIntArray() {
        assertEquals(3, NumberUtils.max(new int[] { 3, 1, 2 }));
        try {
            NumberUtils.max((int[]) null);
            fail("Expected IllegalArgumentException for null array");
        } catch (IllegalArgumentException e) {
            // expected
        }
        try {
            NumberUtils.max(new int[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testMinShortArray() {
        assertEquals((short) 1, NumberUtils.min(new short[] { (short) 3, (short) 1, (short) 2 }));
        try {
            NumberUtils.min((short[]) null);
            fail("Expected IllegalArgumentException for null array");
        } catch (IllegalArgumentException e) {
            // expected
        }
        try {
            NumberUtils.min(new short[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testMaxShortArray() {
        assertEquals((short) 3, NumberUtils.max(new short[] { (short) 3, (short) 1, (short) 2 }));
        try {
            NumberUtils.max((short[]) null);
            fail("Expected IllegalArgumentException for null array");
        } catch (IllegalArgumentException e) {
            // expected
        }
        try {
            NumberUtils.max(new short[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testMinByteArray() {
        assertEquals((byte) 1, NumberUtils.min(new byte[] { (byte) 3, (byte) 1, (byte) 2 }));
        try {
            NumberUtils.min((byte[]) null);
            fail("Expected IllegalArgumentException for null array");
        } catch (IllegalArgumentException e) {
            // expected
        }
        try {
            NumberUtils.min(new byte[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testMaxByteArray() {
        assertEquals((byte) 3, NumberUtils.max(new byte[] { (byte) 3, (byte) 1, (byte) 2 }));
        try {
            NumberUtils.max((byte[]) null);
            fail("Expected IllegalArgumentException for null array");
        } catch (IllegalArgumentException e) {
            // expected
        }
        try {
            NumberUtils.max(new byte[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testMinDoubleArray() {
        assertEquals(1.0d, NumberUtils.min(new double[] { 3.0d, 1.0d, 2.0d }), 0.0d);
        assertTrue(Double.isNaN(NumberUtils.min(new double[] { 1.0d, Double.NaN, 2.0d })));
        try {
            NumberUtils.min((double[]) null);
            fail("Expected IllegalArgumentException for null array");
        } catch (IllegalArgumentException e) {
            // expected
        }
        try {
            NumberUtils.min(new double[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testMaxDoubleArray() {
        assertEquals(3.0d, NumberUtils.max(new double[] { 3.0d, 1.0d, 2.0d }), 0.0d);
        assertTrue(Double.isNaN(NumberUtils.max(new double[] { 1.0d, Double.NaN, 2.0d })));
        try {
            NumberUtils.max((double[]) null);
            fail("Expected IllegalArgumentException for null array");
        } catch (IllegalArgumentException e) {
            // expected
        }
        try {
            NumberUtils.max(new double[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testMinFloatArray() {
        assertEquals(1.0f, NumberUtils.min(new float[] { 3.0f, 1.0f, 2.0f }), 0.0f);
        assertTrue(Float.isNaN(NumberUtils.min(new float[] { 1.0f, Float.NaN, 2.0f })));
        try {
            NumberUtils.min((float[]) null);
            fail("Expected IllegalArgumentException for null array");
        } catch (IllegalArgumentException e) {
            // expected
        }
        try {
            NumberUtils.min(new float[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testMaxFloatArray() {
        assertEquals(3.0f, NumberUtils.max(new float[] { 3.0f, 1.0f, 2.0f }), 0.0f);
        assertTrue(Float.isNaN(NumberUtils.max(new float[] { 1.0f, Float.NaN, 2.0f })));
        try {
            NumberUtils.max((float[]) null);
            fail("Expected IllegalArgumentException for null array");
        } catch (IllegalArgumentException e) {
            // expected
        }
        try {
            NumberUtils.max(new float[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    // -------------------- 3-param min/max --------------------

    public void testMin3Long() {
        assertEquals(1L, NumberUtils.min(3L, 1L, 2L));
        assertEquals(1L, NumberUtils.min(1L, 2L, 3L));
        assertEquals(1L, NumberUtils.min(3L, 2L, 1L));
    }

    public void testMax3Long() {
        assertEquals(3L, NumberUtils.max(3L, 1L, 2L));
        assertEquals(3L, NumberUtils.max(1L, 2L, 3L));
        assertEquals(3L, NumberUtils.max(3L, 2L, 1L));
    }

    public void testMin3Int() {
        assertEquals(1, NumberUtils.min(3, 1, 2));
        assertEquals(1, NumberUtils.min(1, 2, 3));
        assertEquals(1, NumberUtils.min(3, 2, 1));
    }

    public void testMax3Int() {
        assertEquals(3, NumberUtils.max(3, 1, 2));
        assertEquals(3, NumberUtils.max(1, 2, 3));
        assertEquals(3, NumberUtils.max(3, 2, 1));
    }

    public void testMin3Short() {
        assertEquals((short) 1, NumberUtils.min((short) 3, (short) 1, (short) 2));
    }

    public void testMax3Short() {
        assertEquals((short) 3, NumberUtils.max((short) 3, (short) 1, (short) 2));
    }

    public void testMin3Byte() {
        assertEquals((byte) 1, NumberUtils.min((byte) 3, (byte) 1, (byte) 2));
    }

    public void testMax3Byte() {
        assertEquals((byte) 3, NumberUtils.max((byte) 3, (byte) 1, (byte) 2));
    }

    public void testMin3Double() {
        assertEquals(1.0d, NumberUtils.min(3.0d, 1.0d, 2.0d), 0.0d);
        assertTrue(Double.isNaN(NumberUtils.min(1.0d, Double.NaN, 2.0d)));
    }

    public void testMax3Double() {
        assertEquals(3.0d, NumberUtils.max(3.0d, 1.0d, 2.0d), 0.0d);
        assertTrue(Double.isNaN(NumberUtils.max(1.0d, Double.NaN, 2.0d)));
    }

    public void testMin3Float() {
        assertEquals(1.0f, NumberUtils.min(3.0f, 1.0f, 2.0f), 0.0f);
        assertTrue(Float.isNaN(NumberUtils.min(1.0f, Float.NaN, 2.0f)));
    }

    public void testMax3Float() {
        assertEquals(3.0f, NumberUtils.max(3.0f, 1.0f, 2.0f), 0.0f);
        assertTrue(Float.isNaN(NumberUtils.max(1.0f, Float.NaN, 2.0f)));
    }

    // -------------------- isDigits --------------------

    public void testIsDigits() {
        assertFalse(NumberUtils.isDigits(null));
        assertFalse(NumberUtils.isDigits(""));
        assertTrue(NumberUtils.isDigits("12345"));
        assertFalse(NumberUtils.isDigits("12 345"));
        assertFalse(NumberUtils.isDigits("1234.5"));
        assertFalse(NumberUtils.isDigits("-1234"));
        assertFalse(NumberUtils.isDigits("abc"));
    }

    // -------------------- isNumber --------------------

    public void testIsNumber() {
        assertFalse(NumberUtils.isNumber(null));
        assertFalse(NumberUtils.isNumber(""));
        assertTrue(NumberUtils.isNumber("12345"));
        assertTrue(NumberUtils.isNumber("-12345"));
        assertTrue(NumberUtils.isNumber("12.345"));
        assertTrue(NumberUtils.isNumber("1234E5"));
        assertTrue(NumberUtils.isNumber("1234E-5"));
        assertTrue(NumberUtils.isNumber("1234.5E-5"));
        assertTrue(NumberUtils.isNumber("0xFF"));
        assertTrue(NumberUtils.isNumber("-0x1A"));
        assertTrue(NumberUtils.isNumber("123L"));
        assertTrue(NumberUtils.isNumber("123.5f"));
        assertTrue(NumberUtils.isNumber("123.5D"));
        assertFalse(NumberUtils.isNumber("0x"));
        assertFalse(NumberUtils.isNumber("0xGG"));
        assertFalse(NumberUtils.isNumber("1.2.3"));
        assertFalse(NumberUtils.isNumber("1E"));
        assertFalse(NumberUtils.isNumber("--1"));
        assertFalse(NumberUtils.isNumber("abc"));
        assertFalse(NumberUtils.isNumber("123L5"));
        assertFalse(NumberUtils.isNumber("123E4L"));
    }
}
