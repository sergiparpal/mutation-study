package org.apache.commons.cli;

import junit.framework.TestCase;

import java.io.ByteArrayOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Comparator;

/**
 * Self-contained JUnit 3 tests for HelpFormatter, based solely on the
 * documented contract in api/org/apache/commons/cli/HelpFormatter.html.
 */
public class HelpFormatterAgentTest extends TestCase {

    private Options buildSimpleOptions() {
        Options options = new Options();
        options.addOption("a", "alpha", false, "alpha option description");
        options.addOption("b", "beta", true, "beta option description with an argument");
        return options;
    }

    // ---- defaults ----

    public void testDefaultWidth() {
        HelpFormatter hf = new HelpFormatter();
        assertEquals(HelpFormatter.DEFAULT_WIDTH, hf.getWidth());
    }

    public void testDefaultLeftPadding() {
        HelpFormatter hf = new HelpFormatter();
        assertEquals(HelpFormatter.DEFAULT_LEFT_PAD, hf.getLeftPadding());
    }

    public void testDefaultDescPadding() {
        HelpFormatter hf = new HelpFormatter();
        assertEquals(HelpFormatter.DEFAULT_DESC_PAD, hf.getDescPadding());
    }

    public void testDefaultSyntaxPrefix() {
        HelpFormatter hf = new HelpFormatter();
        assertEquals(HelpFormatter.DEFAULT_SYNTAX_PREFIX, hf.getSyntaxPrefix());
    }

    public void testDefaultOptPrefix() {
        HelpFormatter hf = new HelpFormatter();
        assertEquals(HelpFormatter.DEFAULT_OPT_PREFIX, hf.getOptPrefix());
    }

    public void testDefaultLongOptPrefix() {
        HelpFormatter hf = new HelpFormatter();
        assertEquals(HelpFormatter.DEFAULT_LONG_OPT_PREFIX, hf.getLongOptPrefix());
    }

    public void testDefaultArgName() {
        HelpFormatter hf = new HelpFormatter();
        assertEquals(HelpFormatter.DEFAULT_ARG_NAME, hf.getArgName());
    }

    public void testDefaultNewLineIsNotNull() {
        HelpFormatter hf = new HelpFormatter();
        assertNotNull(hf.getNewLine());
    }

    public void testDefaultLongOptSeparatorIsNotNull() {
        HelpFormatter hf = new HelpFormatter();
        assertNotNull(hf.getLongOptSeparator());
    }

    public void testDefaultOptionComparatorIsNotNull() {
        HelpFormatter hf = new HelpFormatter();
        assertNotNull(hf.getOptionComparator());
    }

    // ---- getters/setters round trip ----

    public void testSetGetWidth() {
        HelpFormatter hf = new HelpFormatter();
        hf.setWidth(100);
        assertEquals(100, hf.getWidth());
    }

    public void testSetGetLeftPadding() {
        HelpFormatter hf = new HelpFormatter();
        hf.setLeftPadding(7);
        assertEquals(7, hf.getLeftPadding());
    }

    public void testSetGetDescPadding() {
        HelpFormatter hf = new HelpFormatter();
        hf.setDescPadding(9);
        assertEquals(9, hf.getDescPadding());
    }

    public void testSetGetSyntaxPrefix() {
        HelpFormatter hf = new HelpFormatter();
        hf.setSyntaxPrefix("call: ");
        assertEquals("call: ", hf.getSyntaxPrefix());
    }

    public void testSetGetNewLine() {
        HelpFormatter hf = new HelpFormatter();
        hf.setNewLine("\r\n");
        assertEquals("\r\n", hf.getNewLine());
    }

    public void testSetGetOptPrefix() {
        HelpFormatter hf = new HelpFormatter();
        hf.setOptPrefix("+");
        assertEquals("+", hf.getOptPrefix());
    }

    public void testSetGetLongOptPrefix() {
        HelpFormatter hf = new HelpFormatter();
        hf.setLongOptPrefix("++");
        assertEquals("++", hf.getLongOptPrefix());
    }

    public void testSetGetLongOptSeparator() {
        HelpFormatter hf = new HelpFormatter();
        hf.setLongOptSeparator("=");
        assertEquals("=", hf.getLongOptSeparator());
    }

    public void testSetGetArgName() {
        HelpFormatter hf = new HelpFormatter();
        hf.setArgName("value");
        assertEquals("value", hf.getArgName());
    }

    public void testSetOptionComparatorKeepsSameReference() {
        HelpFormatter hf = new HelpFormatter();
        Comparator custom = new Comparator() {
            public int compare(Object o1, Object o2) {
                return 0;
            }
        };
        hf.setOptionComparator(custom);
        assertSame(custom, hf.getOptionComparator());
    }

    public void testSetOptionComparatorNullResetsToDefault() {
        HelpFormatter hf = new HelpFormatter();
        Comparator custom = new Comparator() {
            public int compare(Object o1, Object o2) {
                return 0;
            }
        };
        hf.setOptionComparator(custom);
        hf.setOptionComparator(null);
        assertNotNull(hf.getOptionComparator());
        assertNotSame(custom, hf.getOptionComparator());
    }

    // ---- createPadding (protected, same-package access) ----

    public void testCreatePaddingZeroLength() {
        HelpFormatter hf = new HelpFormatter();
        assertEquals("", hf.createPadding(0));
    }

    public void testCreatePaddingLengthAndWhitespace() {
        HelpFormatter hf = new HelpFormatter();
        String padding = hf.createPadding(5);
        assertEquals(5, padding.length());
        assertEquals("", padding.trim());
    }

    // ---- rtrim (protected) ----

    public void testRtrimRemovesTrailingWhitespaceOnly() {
        HelpFormatter hf = new HelpFormatter();
        assertEquals("  hello", hf.rtrim("  hello   "));
    }

    public void testRtrimNoTrailingWhitespaceUnchanged() {
        HelpFormatter hf = new HelpFormatter();
        assertEquals("hello", hf.rtrim("hello"));
    }

    public void testRtrimAllWhitespaceBecomesEmpty() {
        HelpFormatter hf = new HelpFormatter();
        assertEquals("", hf.rtrim("    "));
    }

    public void testRtrimEmptyStringUnchanged() {
        HelpFormatter hf = new HelpFormatter();
        assertEquals("", hf.rtrim(""));
    }

    // ---- findWrapPos (protected) ----

    public void testFindWrapPosReturnsMinusOneWhenTextFitsWithinWidth() {
        HelpFormatter hf = new HelpFormatter();
        assertEquals(-1, hf.findWrapPos("short text", 50, 0));
    }

    public void testFindWrapPosReturnsStartPlusWidthWhenNoWhitespaceFound() {
        HelpFormatter hf = new HelpFormatter();
        // "abcdefghij" has no whitespace in [0,5)
        assertEquals(5, hf.findWrapPos("abcdefghij", 5, 0));
    }

    public void testFindWrapPosReturnsLastWhitespacePositionBeforeLimit() {
        HelpFormatter hf = new HelpFormatter();
        // "abc def ghij": indices of whitespace are 3 and 7.
        // width=8, startPos=0 -> search window is [0,8), last whitespace is at 7.
        assertEquals(7, hf.findWrapPos("abc def ghij", 8, 0));
    }

    public void testFindWrapPosHonoursNonZeroStartPos() {
        HelpFormatter hf = new HelpFormatter();
        // "aa bb cc": indices a0 a1 sp2 b3 b4 sp5 c6 c7
        // startPos=3, width=3 -> window [3,6), whitespace at 5.
        assertEquals(5, hf.findWrapPos("aa bb cc", 3, 3));
    }

    // ---- renderOptions / renderWrappedText (protected) ----

    public void testRenderOptionsAppendsToGivenBufferAndReturnsSameInstance() {
        HelpFormatter hf = new HelpFormatter();
        Options options = buildSimpleOptions();
        StringBuffer sb = new StringBuffer();
        StringBuffer result = hf.renderOptions(sb, 80, options, 1, 3);
        assertSame(sb, result);
        assertTrue(result.length() > 0);
        assertTrue(result.toString().indexOf("-a") >= 0);
        assertTrue(result.toString().indexOf("-b") >= 0);
    }

    public void testRenderOptionsWithEmptyOptionsLeavesBufferUnchanged() {
        HelpFormatter hf = new HelpFormatter();
        Options options = new Options();
        StringBuffer sb = new StringBuffer("PREFIX");
        StringBuffer result = hf.renderOptions(sb, 80, options, 1, 3);
        assertSame(sb, result);
        assertEquals("PREFIX", result.toString());
    }

    public void testRenderWrappedTextAppendsToGivenBufferAndReturnsSameInstance() {
        HelpFormatter hf = new HelpFormatter();
        StringBuffer sb = new StringBuffer();
        StringBuffer result = hf.renderWrappedText(sb, 20, 0, "This is some text that should wrap");
        assertSame(sb, result);
        assertTrue(result.length() > 0);
    }

    // ---- printWrapped ----

    public void testPrintWrappedRespectsWidth() {
        HelpFormatter hf = new HelpFormatter();
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        String text = "This is a long line of text that should wrap at a given width boundary";
        hf.printWrapped(pw, 20, text);
        pw.flush();
        String[] lines = sw.toString().split("\n", -1);
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i];
            // strip a possible trailing carriage return
            if (line.endsWith("\r")) {
                line = line.substring(0, line.length() - 1);
            }
            if (line.length() > 0) {
                assertTrue("line exceeded width: [" + line + "]", line.length() <= 20);
            }
        }
    }

    public void testPrintWrappedWithTabStopRespectsWidth() {
        HelpFormatter hf = new HelpFormatter();
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        String text = "This is a long line of text that should wrap at a given width boundary";
        hf.printWrapped(pw, 30, 5, text);
        pw.flush();
        String[] lines = sw.toString().split("\n", -1);
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i];
            if (line.endsWith("\r")) {
                line = line.substring(0, line.length() - 1);
            }
            if (line.length() > 0) {
                assertTrue("line exceeded width: [" + line + "]", line.length() <= 30);
            }
        }
    }

    // ---- printUsage ----

    public void testPrintUsageWithoutOptionsContainsSyntaxPrefixAndSyntax() {
        HelpFormatter hf = new HelpFormatter();
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        hf.printUsage(pw, 80, "myapp [options]");
        pw.flush();
        String output = sw.toString();
        assertTrue(output.indexOf(HelpFormatter.DEFAULT_SYNTAX_PREFIX) >= 0);
        assertTrue(output.indexOf("myapp") >= 0);
    }

    public void testPrintUsageWithOptionsContainsAppName() {
        HelpFormatter hf = new HelpFormatter();
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        hf.printUsage(pw, 80, "myapp", buildSimpleOptions());
        pw.flush();
        String output = sw.toString();
        assertTrue(output.indexOf(HelpFormatter.DEFAULT_SYNTAX_PREFIX) >= 0);
        assertTrue(output.indexOf("myapp") >= 0);
    }

    // ---- printOptions ----

    public void testPrintOptionsContainsOptionFlagsAndDescriptions() {
        HelpFormatter hf = new HelpFormatter();
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        hf.printOptions(pw, 80, buildSimpleOptions(), 1, 3);
        pw.flush();
        String output = sw.toString();
        assertTrue(output.indexOf("-a") >= 0);
        assertTrue(output.indexOf("-b") >= 0);
        assertTrue(output.indexOf("alpha option description") >= 0);
        assertTrue(output.indexOf("beta option description") >= 0);
    }

    public void pruned_testPrintOptionsWithEmptyOptionsProducesNoOutput() {
        HelpFormatter hf = new HelpFormatter();
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        hf.printOptions(pw, 80, new Options(), 1, 3);
        pw.flush();
        assertEquals("", sw.toString());
    }

    // ---- printHelp overloads ----

    public void testPrintHelpFullSignatureContainsHeaderFooterAndSyntax() {
        HelpFormatter hf = new HelpFormatter();
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        hf.printHelp(pw, 80, "myapp", "HEADER_BANNER", buildSimpleOptions(), 1, 3, "FOOTER_BANNER");
        pw.flush();
        String output = sw.toString();
        assertTrue(output.indexOf(HelpFormatter.DEFAULT_SYNTAX_PREFIX) >= 0);
        assertTrue(output.indexOf("myapp") >= 0);
        assertTrue(output.indexOf("HEADER_BANNER") >= 0);
        assertTrue(output.indexOf("FOOTER_BANNER") >= 0);
        assertTrue(output.indexOf("-a") >= 0);
        assertTrue(output.indexOf("-b") >= 0);
    }

    public void testPrintHelpAutoUsageTrueDiffersFromFalse() {
        HelpFormatter hf = new HelpFormatter();
        Options options = buildSimpleOptions();

        StringWriter swTrue = new StringWriter();
        PrintWriter pwTrue = new PrintWriter(swTrue);
        hf.printHelp(pwTrue, 80, "myapp", null, options, 1, 3, null, true);
        pwTrue.flush();

        StringWriter swFalse = new StringWriter();
        PrintWriter pwFalse = new PrintWriter(swFalse);
        hf.printHelp(pwFalse, 80, "myapp", null, options, 1, 3, null, false);
        pwFalse.flush();

        assertFalse(swTrue.toString().equals(swFalse.toString()));
    }

    public void pruned_testPrintHelpThrowsIllegalStateExceptionWhenNoRoomToPrint() {
        HelpFormatter hf = new HelpFormatter();
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        try {
            hf.printHelp(pw, 5, "myapp", "header", buildSimpleOptions(), 10, 10, "footer");
            fail("expected IllegalStateException when there is no room to print a line");
        } catch (IllegalStateException expected) {
            // documented behaviour
        }
    }

    public void testPrintHelpStringSyntaxOptionsRunsWithoutHeaderFooter() {
        HelpFormatter hf = new HelpFormatter();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        java.io.PrintStream originalOut = System.out;
        try {
            System.setOut(new java.io.PrintStream(baos));
            hf.printHelp("myapp", buildSimpleOptions());
        } finally {
            System.setOut(originalOut);
        }
        String output = baos.toString();
        assertTrue(output.indexOf("myapp") >= 0);
        assertTrue(output.indexOf("-a") >= 0);
    }

    public void testPrintHelpStringSyntaxOptionsAutoUsageFalse() {
        HelpFormatter hf = new HelpFormatter();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        java.io.PrintStream originalOut = System.out;
        try {
            System.setOut(new java.io.PrintStream(baos));
            hf.printHelp("myapp", buildSimpleOptions(), false);
        } finally {
            System.setOut(originalOut);
        }
        String output = baos.toString();
        assertTrue(output.indexOf(HelpFormatter.DEFAULT_SYNTAX_PREFIX) >= 0);
        assertTrue(output.indexOf("myapp") >= 0);
    }

    public void testPrintHelpWithHeaderFooterStrings() {
        HelpFormatter hf = new HelpFormatter();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        java.io.PrintStream originalOut = System.out;
        try {
            System.setOut(new java.io.PrintStream(baos));
            hf.printHelp("myapp", "HEADER_BANNER", buildSimpleOptions(), "FOOTER_BANNER");
        } finally {
            System.setOut(originalOut);
        }
        String output = baos.toString();
        assertTrue(output.indexOf("HEADER_BANNER") >= 0);
        assertTrue(output.indexOf("FOOTER_BANNER") >= 0);
    }

    public void testPrintHelpWithWidthHeaderFooterStrings() {
        HelpFormatter hf = new HelpFormatter();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        java.io.PrintStream originalOut = System.out;
        try {
            System.setOut(new java.io.PrintStream(baos));
            hf.printHelp(100, "myapp", "HEADER_BANNER", buildSimpleOptions(), "FOOTER_BANNER");
        } finally {
            System.setOut(originalOut);
        }
        String output = baos.toString();
        assertTrue(output.indexOf("HEADER_BANNER") >= 0);
        assertTrue(output.indexOf("FOOTER_BANNER") >= 0);
    }
}
