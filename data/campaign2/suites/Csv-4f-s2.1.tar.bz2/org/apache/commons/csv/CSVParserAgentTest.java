package org.apache.commons.csv;

import junit.framework.TestCase;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringReader;
import java.io.Writer;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

/**
 * Self-contained tests for {@link CSVParser}, based solely on the documented
 * contract in api/org/apache/commons/csv/CSVParser.html.
 */
public class CSVParserAgentTest extends TestCase {

    private final List<File> tempFiles = new ArrayList<File>();

    protected void tearDown() throws Exception {
        for (int i = 0; i < tempFiles.size(); i++) {
            File f = tempFiles.get(i);
            if (f.exists()) {
                f.delete();
            }
        }
        tempFiles.clear();
        super.tearDown();
    }

    private File createTempCsvFile(String content) throws IOException {
        File file = File.createTempFile("csvparser-agent-test", ".csv");
        tempFiles.add(file);
        Writer writer = new FileWriter(file);
        writer.write(content);
        writer.close();
        return file;
    }

    private static List<String> recordToList(CSVRecord record) {
        List<String> values = new ArrayList<String>();
        for (String field : record) {
            values.add(field);
        }
        return values;
    }

    // ---- Constructor ----

    public void testConstructorNullReaderThrowsIllegalArgumentException() throws IOException {
        try {
            new CSVParser(null, CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException for null reader");
        } catch (IllegalArgumentException expected) {
            // documented
        }
    }

    public void testConstructorNullFormatThrowsIllegalArgumentException() throws IOException {
        try {
            new CSVParser(new StringReader("a,b"), null);
            fail("Expected IllegalArgumentException for null format");
        } catch (IllegalArgumentException expected) {
            // documented
        }
    }

    public void testConstructorValidCreatesOpenParser() throws IOException {
        CSVParser parser = new CSVParser(new StringReader("a,b\n"), CSVFormat.DEFAULT);
        assertFalse(parser.isClosed());
        parser.close();
    }

    // ---- parse(File, CSVFormat) ----

    public void testParseFileNullFileThrowsIllegalArgumentException() throws IOException {
        try {
            CSVParser.parse((File) null, CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException for null file");
        } catch (IllegalArgumentException expected) {
            // documented
        }
    }

    public void testParseFileNullFormatThrowsIllegalArgumentException() throws IOException {
        File file = createTempCsvFile("a,b\n");
        try {
            CSVParser.parse(file, null);
            fail("Expected IllegalArgumentException for null format");
        } catch (IllegalArgumentException expected) {
            // documented
        }
    }

    public void testParseFileValidParsesRecords() throws IOException {
        File file = createTempCsvFile("a,b,c\nd,e,f\n");
        CSVParser parser = CSVParser.parse(file, CSVFormat.DEFAULT);
        List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        assertEquals(Arrays.asList("a", "b", "c"), recordToList(records.get(0)));
        assertEquals(Arrays.asList("d", "e", "f"), recordToList(records.get(1)));
        parser.close();
    }

    public void testParseFileNonExistentThrowsIOException() {
        File file = new File(System.getProperty("java.io.tmpdir"),
                "csvparser-agent-test-missing-" + System.nanoTime() + ".csv");
        try {
            CSVParser.parse(file, CSVFormat.DEFAULT);
            fail("Expected IOException for non-existent file");
        } catch (IOException expected) {
            // documented: IOException if an I/O error occurs
        }
    }

    // ---- parse(String, CSVFormat) ----

    public void testParseStringNullStringThrowsIllegalArgumentException() throws IOException {
        try {
            CSVParser.parse((String) null, CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException for null string");
        } catch (IllegalArgumentException expected) {
            // documented
        }
    }

    public void testParseStringNullFormatThrowsIllegalArgumentException() throws IOException {
        try {
            CSVParser.parse("a,b", null);
            fail("Expected IllegalArgumentException for null format");
        } catch (IllegalArgumentException expected) {
            // documented
        }
    }

    public void testParseStringValidParsesRecords() throws IOException {
        CSVParser parser = CSVParser.parse("a,b\nc,d\n", CSVFormat.DEFAULT);
        List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        assertEquals(Arrays.asList("a", "b"), recordToList(records.get(0)));
        assertEquals(Arrays.asList("c", "d"), recordToList(records.get(1)));
        parser.close();
    }

    public void testParseStringEmptyReturnsEmptyRecords() throws IOException {
        CSVParser parser = CSVParser.parse("", CSVFormat.DEFAULT);
        List<CSVRecord> records = parser.getRecords();
        assertNotNull(records);
        assertTrue(records.isEmpty());
        parser.close();
    }

    // ---- parse(URL, Charset, CSVFormat) ----

    public void testParseURLNullUrlThrowsIllegalArgumentException() throws IOException {
        try {
            CSVParser.parse((URL) null, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException for null url");
        } catch (IllegalArgumentException expected) {
            // documented
        }
    }

    public void testParseURLNullCharsetThrowsIllegalArgumentException() throws IOException {
        File file = createTempCsvFile("a,b\n");
        URL url = file.toURI().toURL();
        try {
            CSVParser.parse(url, null, CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException for null charset");
        } catch (IllegalArgumentException expected) {
            // documented
        }
    }

    public void testParseURLNullFormatThrowsIllegalArgumentException() throws IOException {
        File file = createTempCsvFile("a,b\n");
        URL url = file.toURI().toURL();
        try {
            CSVParser.parse(url, StandardCharsets.UTF_8, null);
            fail("Expected IllegalArgumentException for null format");
        } catch (IllegalArgumentException expected) {
            // documented
        }
    }

    public void testParseURLValidParsesRecords() throws IOException {
        File file = createTempCsvFile("a,b,c\nd,e,f\n");
        URL url = file.toURI().toURL();
        CSVParser parser = CSVParser.parse(url, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
        List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        assertEquals(Arrays.asList("a", "b", "c"), recordToList(records.get(0)));
        assertEquals(Arrays.asList("d", "e", "f"), recordToList(records.get(1)));
        parser.close();
    }

    public void testParseURLNonExistentThrowsIOException() {
        File file = new File(System.getProperty("java.io.tmpdir"),
                "csvparser-agent-test-missing-" + System.nanoTime() + ".csv");
        try {
            URL url = file.toURI().toURL();
            CSVParser.parse(url, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
            fail("Expected IOException for non-existent resource");
        } catch (IOException expected) {
            // documented: IOException if an I/O error occurs
        }
    }

    // ---- close() / isClosed() ----

    public void testIsClosedFalseAfterConstruction() throws IOException {
        CSVParser parser = new CSVParser(new StringReader("a,b\n"), CSVFormat.DEFAULT);
        assertFalse(parser.isClosed());
        parser.close();
    }

    public void testCloseSetsIsClosedTrue() throws IOException {
        CSVParser parser = new CSVParser(new StringReader("a,b\n"), CSVFormat.DEFAULT);
        parser.close();
        assertTrue(parser.isClosed());
    }

    // ---- getRecordNumber() / getCurrentLineNumber() / nextRecord() ----

    public void testRecordNumberAndLineNumberProgressWithNextRecord() throws IOException {
        CSVParser parser = new CSVParser(new StringReader("a,b\nc,d\n"), CSVFormat.DEFAULT);

        assertEquals(0L, parser.getRecordNumber());
        assertEquals(0L, parser.getCurrentLineNumber());

        CSVRecord first = parser.nextRecord();
        assertNotNull(first);
        assertEquals(Arrays.asList("a", "b"), recordToList(first));
        assertEquals(1L, parser.getRecordNumber());
        assertEquals(1L, parser.getCurrentLineNumber());

        CSVRecord second = parser.nextRecord();
        assertNotNull(second);
        assertEquals(Arrays.asList("c", "d"), recordToList(second));
        assertEquals(2L, parser.getRecordNumber());
        assertEquals(2L, parser.getCurrentLineNumber());

        CSVRecord third = parser.nextRecord();
        assertNull(third);

        parser.close();
    }

    // ---- getRecords() ----

    public void testGetRecordsReturnsAllRecordsWithExpectedFields() throws IOException {
        CSVParser parser = new CSVParser(new StringReader("a,b,c\nd,e,f\n"), CSVFormat.DEFAULT);
        List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        assertEquals(Arrays.asList("a", "b", "c"), recordToList(records.get(0)));
        assertEquals(Arrays.asList("d", "e", "f"), recordToList(records.get(1)));
        parser.close();
    }

    public void testGetRecordsOnEmptyInputReturnsEmptyList() throws IOException {
        CSVParser parser = new CSVParser(new StringReader(""), CSVFormat.DEFAULT);
        List<CSVRecord> records = parser.getRecords();
        assertNotNull(records);
        assertTrue(records.isEmpty());
        parser.close();
    }

    public void testGetRecordsPropagatesIOExceptionFromFailedRead() throws IOException {
        StringReader reader = new StringReader("a,b\n");
        CSVParser parser = new CSVParser(reader, CSVFormat.DEFAULT);
        reader.close();
        try {
            parser.getRecords();
            fail("Expected IOException on read failure");
        } catch (IOException expected) {
            // documented: IOException on parse error or input read-failure
        }
    }

    // ---- getHeaderMap() ----

    public void testGetHeaderMapWithoutHeaderIsNullOrEmpty() throws IOException {
        CSVParser parser = new CSVParser(new StringReader("a,b\n"), CSVFormat.DEFAULT);
        Map<String, Integer> headerMap = parser.getHeaderMap();
        assertTrue(headerMap == null || headerMap.isEmpty());
        parser.close();
    }

    // ---- iterator() ----

    public void testIteratorReturnsRecordsInOrder() throws IOException {
        CSVParser parser = new CSVParser(new StringReader("a,b\nc,d\n"), CSVFormat.DEFAULT);
        Iterator<CSVRecord> it = parser.iterator();

        assertTrue(it.hasNext());
        CSVRecord first = it.next();
        assertEquals(Arrays.asList("a", "b"), recordToList(first));

        assertTrue(it.hasNext());
        CSVRecord second = it.next();
        assertEquals(Arrays.asList("c", "d"), recordToList(second));

        assertFalse(it.hasNext());
        parser.close();
    }

    public void testIteratorWrapsIOExceptionFromFailedReadAsRuntimeException() throws IOException {
        StringReader reader = new StringReader("a,b\n");
        CSVParser parser = new CSVParser(reader, CSVFormat.DEFAULT);
        reader.close();
        Iterator<CSVRecord> it = parser.iterator();
        try {
            it.next();
            fail("Expected RuntimeException wrapping an IOException");
        } catch (RuntimeException expected) {
            // documented: IOExceptions occurring during iteration are wrapped in a RuntimeException
        }
    }

    public void testIteratorNextAfterParserClosedThrowsNoSuchElementException() throws IOException {
        CSVParser parser = new CSVParser(new StringReader("a,b\n"), CSVFormat.DEFAULT);
        parser.close();
        Iterator<CSVRecord> it = parser.iterator();
        try {
            it.next();
            fail("Expected NoSuchElementException because the parser is closed");
        } catch (NoSuchElementException expected) {
            // documented: a call to next() on a closed parser throws NoSuchElementException
        }
    }

    // ---- nextRecord() (package-private, accessible from this same-package test) ----

    public void testNextRecordReturnsNullAtEndOfStream() throws IOException {
        CSVParser parser = new CSVParser(new StringReader("a\n"), CSVFormat.DEFAULT);
        CSVRecord record = parser.nextRecord();
        assertNotNull(record);
        assertEquals(Arrays.asList("a"), recordToList(record));
        assertNull(parser.nextRecord());
        parser.close();
    }
}
