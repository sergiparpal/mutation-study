/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import java.text.Format;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import junit.framework.TestCase;

/**
 * Unit tests for {@link org.apache.commons.lang3.text.ExtendedMessageFormat}.
 */
public class ExtendedMessageFormatAgentTest extends TestCase {

    public ExtendedMessageFormatAgentTest(String name) {
        super(name);
    }

    /**
     * Trivial FormatFactory that always returns the same Format instance,
     * regardless of name/arguments/locale, and records the last call made.
     */
    private static class SimpleFormatFactory implements FormatFactory {
        private final Format format;
        String lastName;
        String lastArguments;
        Locale lastLocale;

        SimpleFormatFactory(Format format) {
            this.format = format;
        }

        public Format getFormat(String name, String arguments, Locale locale) {
            lastName = name;
            lastArguments = arguments;
            lastLocale = locale;
            return format;
        }
    }

    private static Map<String, FormatFactory> registryOf(String name, FormatFactory factory) {
        Map<String, FormatFactory> registry = new HashMap<String, FormatFactory>();
        registry.put(name, factory);
        return registry;
    }

    // -----------------------------------------------------------------------
    // Construction / basic pattern behavior
    // -----------------------------------------------------------------------

    public void testNoRegistryBehavesLikeMessageFormat() {
        String pattern = "There are {0} apples";
        ExtendedMessageFormat emf = new ExtendedMessageFormat(pattern);
        MessageFormat mf = new MessageFormat(pattern);
        assertEquals(mf.format(new Object[] { Integer.valueOf(5) }),
                emf.format(new Object[] { Integer.valueOf(5) }));
        assertEquals(pattern, emf.toPattern());
    }

    public void testLocaleIsUsed() {
        String pattern = "{0,number,currency}";
        ExtendedMessageFormat emfUS = new ExtendedMessageFormat(pattern, Locale.US);
        MessageFormat mfUS = new MessageFormat(pattern, Locale.US);
        assertEquals(mfUS.format(new Object[] { Double.valueOf(1234.5) }),
                emfUS.format(new Object[] { Double.valueOf(1234.5) }));
    }

    public void testNullRegistryConstructorEquivalentToNoRegistry() {
        String pattern = "Hello, {0}!";
        ExtendedMessageFormat withNullRegistry =
                new ExtendedMessageFormat(pattern, Locale.US, null);
        ExtendedMessageFormat withoutRegistry =
                new ExtendedMessageFormat(pattern, Locale.US);
        assertEquals(withoutRegistry.toPattern(), withNullRegistry.toPattern());
        assertEquals(withoutRegistry, withNullRegistry);
    }

    // -----------------------------------------------------------------------
    // Custom format registry
    // -----------------------------------------------------------------------

    public void testCustomFormatIsInvokedWithNameAndArguments() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        SimpleFormatFactory factory = new SimpleFormatFactory(sdf);
        Map<String, FormatFactory> registry = registryOf("date-custom", factory);

        ExtendedMessageFormat emf =
                new ExtendedMessageFormat("Date: {0,date-custom,yyyy}", registry);

        assertEquals("date-custom", factory.lastName);
        assertEquals("yyyy", factory.lastArguments);

        java.util.Calendar cal = java.util.Calendar.getInstance(Locale.US);
        cal.set(2020, 0, 2, 0, 0, 0);
        cal.set(java.util.Calendar.MILLISECOND, 0);
        java.util.Date date = cal.getTime();
        String formatted = emf.format(new Object[] { date });
        assertEquals("Date: " + sdf.format(date), formatted);
    }

    public void testCustomFormatWithoutArguments() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy", Locale.US);
        SimpleFormatFactory factory = new SimpleFormatFactory(sdf);
        Map<String, FormatFactory> registry = registryOf("date-custom", factory);

        ExtendedMessageFormat emf =
                new ExtendedMessageFormat("{0,date-custom}", registry);

        assertEquals("date-custom", factory.lastName);
        assertNull(factory.lastArguments);
    }

    public void testUnknownFormatNameFallsThroughToBuiltIn() {
        // "number" is a built-in MessageFormat format type, not in our registry,
        // so getFormat() in the registry returns null and the pattern falls
        // through to MessageFormat's own handling.
        SimpleFormatFactory factory = new SimpleFormatFactory(new SimpleDateFormat());
        Map<String, FormatFactory> registry = registryOf("date-custom", factory);

        ExtendedMessageFormat emf =
                new ExtendedMessageFormat("{0,number,integer}", Locale.US, registry);

        assertEquals("1,234", emf.format(new Object[] { Integer.valueOf(1234) }));
        assertNull("registry should not have been consulted for 'number'", factory.lastName);
    }

    public void testToPatternReinsertsCustomFormat() {
        SimpleFormatFactory factory = new SimpleFormatFactory(new SimpleDateFormat("yyyy"));
        Map<String, FormatFactory> registry = registryOf("date-custom", factory);

        String pattern = "{0,date-custom,yyyy}";
        ExtendedMessageFormat emf = new ExtendedMessageFormat(pattern, registry);
        assertEquals(pattern, emf.toPattern());
    }

    public void testMultipleFormatElementsWithMixedCustomAndBuiltIn() {
        SimpleFormatFactory factory = new SimpleFormatFactory(new SimpleDateFormat("yyyy", Locale.US));
        Map<String, FormatFactory> registry = registryOf("date-custom", factory);

        String pattern = "{0,date-custom,yyyy} and {1,number,integer}";
        ExtendedMessageFormat emf = new ExtendedMessageFormat(pattern, registry);
        assertEquals(pattern, emf.toPattern());

        java.util.Calendar cal = java.util.Calendar.getInstance(Locale.US);
        cal.set(2021, 5, 1, 0, 0, 0);
        cal.set(java.util.Calendar.MILLISECOND, 0);
        String result = emf.format(new Object[] { cal.getTime(), Integer.valueOf(42) });
        assertEquals("2021 and 42", result);
    }

    // -----------------------------------------------------------------------
    // Quoting / escaping
    // -----------------------------------------------------------------------

    public void testEscapedQuoteInPattern() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("It''s {0}");
        assertEquals("It's 5", emf.format(new Object[] { Integer.valueOf(5) }));
    }

    public void testQuotedLiteralBraceIsNotParsedAsFormatElement() {
        // within a quoted section, the brace characters are literal and must
        // not be treated as the start of a format element.
        ExtendedMessageFormat emf = new ExtendedMessageFormat("'{literal}' {0}");
        assertEquals("{literal} 5", emf.format(new Object[] { Integer.valueOf(5) }));
    }

    // -----------------------------------------------------------------------
    // Error / boundary cases
    // -----------------------------------------------------------------------

    public void testUnterminatedFormatElementThrows() {
        try {
            new ExtendedMessageFormat("{0");
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // success
        }
    }

    public void testUnterminatedQuoteInFormatDescriptionThrows() {
        Map<String, FormatFactory> registry =
                registryOf("custom", new SimpleFormatFactory(new SimpleDateFormat()));
        try {
            new ExtendedMessageFormat("{0,custom,it's unterminated", registry);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // success
        }
    }

    public void testInvalidArgumentIndexThrows() {
        try {
            new ExtendedMessageFormat("{abc}");
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // success
        }
    }

    public void testEmptyPattern() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("");
        assertEquals("", emf.toPattern());
        assertEquals("", emf.format(new Object[0]));
    }

    public void testPatternWithoutFormatElements() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("just plain text");
        assertEquals("just plain text", emf.toPattern());
        assertEquals("just plain text", emf.format(new Object[0]));
    }

    // -----------------------------------------------------------------------
    // Disabled mutators
    // -----------------------------------------------------------------------

    public void testSetFormatThrowsUnsupportedOperationException() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        try {
            emf.setFormat(0, new SimpleDateFormat());
            fail("expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // success
        }
    }

    public void testSetFormatByArgumentIndexThrowsUnsupportedOperationException() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        try {
            emf.setFormatByArgumentIndex(0, new SimpleDateFormat());
            fail("expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // success
        }
    }

    public void testSetFormatsThrowsUnsupportedOperationException() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        try {
            emf.setFormats(new Format[] { new SimpleDateFormat() });
            fail("expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // success
        }
    }

    public void testSetFormatsByArgumentIndexThrowsUnsupportedOperationException() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        try {
            emf.setFormatsByArgumentIndex(new Format[] { new SimpleDateFormat() });
            fail("expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // success
        }
    }

    // -----------------------------------------------------------------------
    // equals() / hashCode()
    // -----------------------------------------------------------------------

    public void testEqualsReflexiveAndWithEquivalentInstance() {
        ExtendedMessageFormat emf1 = new ExtendedMessageFormat("{0}", Locale.US);
        ExtendedMessageFormat emf2 = new ExtendedMessageFormat("{0}", Locale.US);
        assertTrue(emf1.equals(emf1));
        assertEquals(emf1, emf2);
        assertEquals(emf1.hashCode(), emf2.hashCode());
    }

    public void testEqualsWithNullAndDifferentType() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertFalse(emf.equals(null));
        assertFalse(emf.equals("{0}"));
        assertFalse(emf.equals(new MessageFormat("{0}")));
    }

    public void testEqualsDifferentPatternsAreNotEqual() {
        ExtendedMessageFormat emf1 = new ExtendedMessageFormat("{0}");
        ExtendedMessageFormat emf2 = new ExtendedMessageFormat("{0} ");
        assertFalse(emf1.equals(emf2));
    }

    public void testEqualsDifferentRegistriesAreNotEqual() {
        Map<String, FormatFactory> registry1 =
                registryOf("x", new SimpleFormatFactory(new SimpleDateFormat("yyyy")));
        Map<String, FormatFactory> registry2 =
                registryOf("y", new SimpleFormatFactory(new SimpleDateFormat("yyyy")));
        ExtendedMessageFormat emf1 = new ExtendedMessageFormat("{0}", Locale.US, registry1);
        ExtendedMessageFormat emf2 = new ExtendedMessageFormat("{0}", Locale.US, registry2);
        assertFalse(emf1.equals(emf2));
    }
}
