/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import junit.framework.TestCase;

/**
 * Unit tests {@link org.apache.commons.lang3.SerializationUtils}.
 */
public class SerializationUtilsAgentTest extends TestCase {

    public SerializationUtilsAgentTest(String name) {
        super(name);
    }

    static class NotSerializable {
        int value;
        NotSerializable(int value) {
            this.value = value;
        }
    }

    static class HoldsNotSerializable implements Serializable {
        private static final long serialVersionUID = 1L;
        @SuppressWarnings("unused")
        private final NotSerializable inner = new NotSerializable(1);
    }

    static class SerializablePoint implements Serializable {
        private static final long serialVersionUID = 1L;
        final int x;
        final int y;
        SerializablePoint(int x, int y) {
            this.x = x;
            this.y = y;
        }
        public boolean equals(Object obj) {
            if (!(obj instanceof SerializablePoint)) {
                return false;
            }
            SerializablePoint other = (SerializablePoint) obj;
            return other.x == x && other.y == y;
        }
        public int hashCode() {
            return x * 31 + y;
        }
    }

    static class ThrowingOutputStream extends OutputStream {
        public void write(int b) throws IOException {
            throw new IOException("boom");
        }
    }

    // Constructor
    //-----------------------------------------------------------------------
    public void testConstructor() {
        assertNotNull(new SerializationUtils());
    }

    // clone
    //-----------------------------------------------------------------------
    public void testCloneNull() {
        assertNull(SerializationUtils.clone(null));
    }

    public void testCloneSimpleObject() {
        String original = "hello";
        String cloned = SerializationUtils.clone(original);
        assertEquals(original, cloned);
    }

    public void testCloneComplexObject() {
        HashMap<String, List<Integer>> original = new HashMap<String, List<Integer>>();
        List<Integer> list = new ArrayList<Integer>();
        list.add(1);
        list.add(2);
        list.add(3);
        original.put("numbers", list);

        HashMap<String, List<Integer>> cloned = SerializationUtils.clone(original);

        assertEquals(original, cloned);
        assertNotSame(original, cloned);
        assertNotSame(original.get("numbers"), cloned.get("numbers"));
    }

    public void testCloneIsDeep() {
        SerializablePoint original = new SerializablePoint(1, 2);
        SerializablePoint cloned = SerializationUtils.clone(original);
        assertEquals(original, cloned);
        assertNotSame(original, cloned);
    }

    // serialize(Serializable) -> byte[]
    //-----------------------------------------------------------------------
    public void testSerializeToByteArrayAndBack() {
        SerializablePoint point = new SerializablePoint(3, 4);
        byte[] data = SerializationUtils.serialize(point);
        assertNotNull(data);
        assertTrue(data.length > 0);

        Object result = SerializationUtils.deserialize(data);
        assertEquals(point, result);
    }

    public void testSerializeNullObject() {
        byte[] data = SerializationUtils.serialize((Serializable) null);
        assertNotNull(data);
        Object result = SerializationUtils.deserialize(data);
        assertNull(result);
    }

    public void testSerializeNotSerializableThrows() {
        try {
            SerializationUtils.serialize(new HoldsNotSerializable());
            fail("Expected SerializationException");
        } catch (SerializationException ex) {
            assertTrue(ex.getCause() instanceof IOException);
        }
    }

    // serialize(Serializable, OutputStream)
    //-----------------------------------------------------------------------
    public void testSerializeToOutputStreamNullStreamThrows() {
        try {
            SerializationUtils.serialize("abc", null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            assertEquals("The OutputStream must not be null", ex.getMessage());
        }
    }

    public void testSerializeToOutputStreamWritesData() {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        SerializationUtils.serialize("hello world", baos);
        byte[] data = baos.toByteArray();
        assertTrue(data.length > 0);
        assertEquals("hello world", SerializationUtils.deserialize(data));
    }

    public void testSerializeToOutputStreamIOExceptionWrapped() {
        try {
            SerializationUtils.serialize("abc", new ThrowingOutputStream());
            fail("Expected SerializationException");
        } catch (SerializationException ex) {
            assertTrue(ex.getCause() instanceof IOException);
        }
    }

    // deserialize(byte[])
    //-----------------------------------------------------------------------
    public void testDeserializeNullByteArrayThrows() {
        try {
            SerializationUtils.deserialize((byte[]) null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            assertEquals("The byte[] must not be null", ex.getMessage());
        }
    }

    public void testDeserializeEmptyByteArrayThrows() {
        try {
            SerializationUtils.deserialize(new byte[0]);
            fail("Expected SerializationException");
        } catch (SerializationException ex) {
            assertNotNull(ex.getCause());
        }
    }

    public void testDeserializeGarbageBytesThrows() {
        byte[] garbage = new byte[] { 1, 2, 3, 4, 5 };
        try {
            SerializationUtils.deserialize(garbage);
            fail("Expected SerializationException");
        } catch (SerializationException ex) {
            assertNotNull(ex.getCause());
        }
    }

    // deserialize(InputStream)
    //-----------------------------------------------------------------------
    public void testDeserializeNullInputStreamThrows() {
        try {
            SerializationUtils.deserialize((java.io.InputStream) null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            assertEquals("The InputStream must not be null", ex.getMessage());
        }
    }

    public void testDeserializeFromInputStream() {
        byte[] data = SerializationUtils.serialize(Integer.valueOf(42));
        Object result = SerializationUtils.deserialize(new ByteArrayInputStream(data));
        assertEquals(Integer.valueOf(42), result);
    }

    public void testDeserializeUnknownClassThrowsSerializationExceptionWithClassNotFoundCause() {
        byte[] data = SerializationUtils.serialize(new BogusHolder());
        String realName = BogusHolder.class.getName();
        // same length as realName, but refers to a class that does not exist
        String fakeName = realName.substring(0, realName.length() - 1) + "Z";

        byte[] corrupted = replaceAsciiBytes(data, realName, fakeName);

        try {
            SerializationUtils.deserialize(corrupted);
            fail("Expected SerializationException");
        } catch (SerializationException ex) {
            assertTrue(ex.getCause() instanceof ClassNotFoundException);
        }
    }

    private static byte[] replaceAsciiBytes(byte[] data, String from, String to) {
        assertEquals(from.length(), to.length());
        byte[] fromBytes = asciiBytes(from);
        byte[] toBytes = asciiBytes(to);
        int index = indexOf(data, fromBytes);
        assertTrue("marker not found in serialized data", index >= 0);
        byte[] result = data.clone();
        System.arraycopy(toBytes, 0, result, index, toBytes.length);
        return result;
    }

    private static byte[] asciiBytes(String s) {
        byte[] result = new byte[s.length()];
        for (int i = 0; i < s.length(); i++) {
            result[i] = (byte) s.charAt(i);
        }
        return result;
    }

    private static int indexOf(byte[] data, byte[] pattern) {
        outer:
        for (int i = 0; i <= data.length - pattern.length; i++) {
            for (int j = 0; j < pattern.length; j++) {
                if (data[i + j] != pattern[j]) {
                    continue outer;
                }
            }
            return i;
        }
        return -1;
    }

    static class BogusHolder implements Serializable {
        private static final long serialVersionUID = 1L;
    }
}
