package org.apache.commons.lang3.math;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;
import java.math.BigInteger;

import org.junit.Test;

public class NumberUtilsAgentTest {

    // ---------------------------------------------------------------
    // Reusable constants
    // ---------------------------------------------------------------

    @Test
    public void testConstants() {
        assertEquals(Byte.valueOf((byte) -1), NumberUtils.BYTE_MINUS_ONE);
        assertEquals(Byte.valueOf((byte) 1), NumberUtils.BYTE_ONE);
        assertEquals(Byte.valueOf((byte) 0), NumberUtils.BYTE_ZERO);

        assertEquals(Double.valueOf(-1.0d), NumberUtils.DOUBLE_MINUS_ONE);
        assertEquals(Double.valueOf(1.0d), NumberUtils.DOUBLE_ONE);
        assertEquals(Double.valueOf(0.0d), NumberUtils.DOUBLE_ZERO);

        assertEquals(Float.valueOf(-1.0f), NumberUtils.FLOAT_MINUS_ONE);
        assertEquals(Float.valueOf(1.0f), NumberUtils.FLOAT_ONE);
        assertEquals(Float.valueOf(0.0f), NumberUtils.FLOAT_ZERO);

        assertEquals(Integer.valueOf(-1), NumberUtils.INTEGER_MINUS_ONE);
        assertEquals(Integer.valueOf(1), NumberUtils.INTEGER_ONE);
        assertEquals(Integer.valueOf(0), NumberUtils.INTEGER_ZERO);

        assertEquals(Long.valueOf(-1L), NumberUtils.LONG_MINUS_ONE);
        assertEquals(Long.valueOf(1L), NumberUtils.LONG_ONE);
        assertEquals(Long.valueOf(0L), NumberUtils.LONG_ZERO);

        assertEquals(Short.valueOf((short) -1), NumberUtils.SHORT_MINUS_ONE);
        assertEquals(Short.valueOf((short) 1), NumberUtils.SHORT_ONE);
        assertEquals(Short.valueOf((short) 0), NumberUtils.SHORT_ZERO);
    }

    // ---------------------------------------------------------------
    // toInt
    // ---------------------------------------------------------------

    @Test
    public void testToInt() {
        assertEquals(0, NumberUtils.toInt(null));
        assertEquals(0, NumberUtils.toInt(""));
        assertEquals(1, NumberUtils.toInt("1"));
        assertEquals(-1, NumberUtils.toInt("-1"));
        assertEquals(0, NumberUtils.toInt("abc"));
        // overflow of int range fails conversion
        assertEquals(0, NumberUtils.toInt("2147483648"));
    }

    @Test
    public void testToIntWithDefault() {
        assertEquals(1, NumberUtils.toInt(null, 1));
        assertEquals(1, NumberUtils.toInt("", 1));
        assertEquals(1, NumberUtils.toInt("1", 0));
        assertEquals(5, NumberUtils.toInt("abc", 5));
        assertEquals(-5, NumberUtils.toInt(null, -5));
    }

    // ---------------------------------------------------------------
    // toLong
    // ---------------------------------------------------------------

    @Test
    public void testToLong() {
        assertEquals(0L, NumberUtils.toLong(null));
        assertEquals(0L, NumberUtils.toLong(""));
        assertEquals(1L, NumberUtils.toLong("1"));
        assertEquals(-1L, NumberUtils.toLong("-1"));
        assertEquals(0L, NumberUtils.toLong("abc"));
        // overflow of long range fails conversion
        assertEquals(0L, NumberUtils.toLong("9223372036854775808"));
    }

    @Test
    public void testToLongWithDefault() {
        assertEquals(1L, NumberUtils.toLong(null, 1L));
        assertEquals(1L, NumberUtils.toLong("", 1L));
        assertEquals(1L, NumberUtils.toLong("1", 0L));
        assertEquals(5L, NumberUtils.toLong("abc", 5L));
    }

    // ---------------------------------------------------------------
    // toFloat
    // ---------------------------------------------------------------

    @Test
    public void testToFloat() {
        assertEquals(0.0f, NumberUtils.toFloat(null), 0.0f);
        assertEquals(0.0f, NumberUtils.toFloat(""), 0.0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5"), 0.0f);
        assertEquals(0.0f, NumberUtils.toFloat("abc"), 0.0f);
    }

    // @Test  // pruned: failed on the fixed version
    public void testToFloatWithDefault() {
        assertEquals(1.0f, NumberUtils.toFloat(null, 1.1f), 0.0f);
        assertEquals(1.1f, NumberUtils.toFloat("", 1.1f), 0.0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5", 0.0f), 0.0f);
    }

    // ---------------------------------------------------------------
    // toDouble
    // ---------------------------------------------------------------

    @Test
    public void testToDouble() {
        assertEquals(0.0d, NumberUtils.toDouble(null), 0.0d);
        assertEquals(0.0d, NumberUtils.toDouble(""), 0.0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5"), 0.0d);
        assertEquals(0.0d, NumberUtils.toDouble("abc"), 0.0d);
    }

    @Test
    public void testToDoubleWithDefault() {
        assertEquals(1.1d, NumberUtils.toDouble(null, 1.1d), 0.0d);
        assertEquals(1.1d, NumberUtils.toDouble("", 1.1d), 0.0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5", 0.0d), 0.0d);
    }

    // ---------------------------------------------------------------
    // toByte
    // ---------------------------------------------------------------

    @Test
    public void testToByte() {
        assertEquals((byte) 0, NumberUtils.toByte(null));
        assertEquals((byte) 0, NumberUtils.toByte(""));
        assertEquals((byte) 1, NumberUtils.toByte("1"));
        assertEquals((byte) -1, NumberUtils.toByte("-1"));
        // out of byte range fails conversion
        assertEquals((byte) 0, NumberUtils.toByte("200"));
    }

    @Test
    public void testToByteWithDefault() {
        assertEquals((byte) 1, NumberUtils.toByte(null, (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("", (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("1", (byte) 0));
        assertEquals((byte) 5, NumberUtils.toByte("200", (byte) 5));
    }

    // ---------------------------------------------------------------
    // toShort
    // ---------------------------------------------------------------

    @Test
    public void testToShort() {
        assertEquals((short) 0, NumberUtils.toShort(null));
        assertEquals((short) 0, NumberUtils.toShort(""));
        assertEquals((short) 1, NumberUtils.toShort("1"));
        assertEquals((short) -1, NumberUtils.toShort("-1"));
        // out of short range fails conversion
        assertEquals((short) 0, NumberUtils.toShort("100000"));
    }

    @Test
    public void testToShortWithDefault() {
        assertEquals((short) 1, NumberUtils.toShort(null, (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("", (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("1", (short) 0));
        assertEquals((short) 5, NumberUtils.toShort("100000", (short) 5));
    }

    // ---------------------------------------------------------------
    // createNumber
    // ---------------------------------------------------------------

    @Test
    public void testCreateNumberNull() {
        assertNull(NumberUtils.createNumber(null));
    }

    @Test
    public void testCreateNumberPlainInteger() {
        Number n = NumberUtils.createNumber("123");
        assertEquals(123, n.intValue());
        assertTrue(n instanceof Integer);
    }

    @Test
    public void testCreateNumberNegativeInteger() {
        Number n = NumberUtils.createNumber("-123");
        assertEquals(-123, n.intValue());
    }

    @Test
    public void testCreateNumberLongQualifier() {
        Number n = NumberUtils.createNumber("123L");
        assertEquals(123L, n.longValue());
        assertTrue(n instanceof Long);
    }

    @Test
    public void testCreateNumberFloatQualifier() {
        Number n = NumberUtils.createNumber("3.2F");
        assertEquals(3.2f, n.floatValue(), 0.0f);
        assertTrue(n instanceof Float);
    }

    @Test
    public void testCreateNumberDoubleQualifier() {
        Number n = NumberUtils.createNumber("3.2D");
        assertEquals(3.2d, n.doubleValue(), 0.0d);
        assertTrue(n instanceof Double);
    }

    @Test
    public void testCreateNumberHex() {
        Number n = NumberUtils.createNumber("0x1A");
        assertEquals(26, n.intValue());
    }

    @Test
    public void testCreateNumberNegativeHex() {
        Number n = NumberUtils.createNumber("-0x1A");
        assertEquals(-26, n.intValue());
    }

    // @Test  // pruned: failed on the fixed version
    public void testCreateNumberLeadingZeroIsNotOctal() {
        // leading 0's are not interpreted as octal by createNumber
        Number n = NumberUtils.createNumber("010");
        assertEquals(10, n.intValue());
    }

    @Test(expected = NumberFormatException.class)
    public void testCreateNumberInvalid() {
        NumberUtils.createNumber("abc");
    }

    @Test(expected = NumberFormatException.class)
    public void testCreateNumberEmpty() {
        NumberUtils.createNumber("");
    }

    @Test(expected = NumberFormatException.class)
    public void testCreateNumberNotTrimmed() {
        // leading/trailing spaces are not trimmed and must fail
        NumberUtils.createNumber(" 123 ");
    }

    // ---------------------------------------------------------------
    // createFloat
    // ---------------------------------------------------------------

    @Test
    public void testCreateFloat() {
        assertNull(NumberUtils.createFloat(null));
        assertEquals(Float.valueOf(1.5f), NumberUtils.createFloat("1.5"));
    }

    @Test(expected = NumberFormatException.class)
    public void testCreateFloatInvalid() {
        NumberUtils.createFloat("abc");
    }

    // ---------------------------------------------------------------
    // createDouble
    // ---------------------------------------------------------------

    @Test
    public void testCreateDouble() {
        assertNull(NumberUtils.createDouble(null));
        assertEquals(Double.valueOf(1.5d), NumberUtils.createDouble("1.5"));
    }

    @Test(expected = NumberFormatException.class)
    public void testCreateDoubleInvalid() {
        NumberUtils.createDouble("abc");
    }

    // ---------------------------------------------------------------
    // createInteger
    // ---------------------------------------------------------------

    @Test
    public void testCreateInteger() {
        assertNull(NumberUtils.createInteger(null));
        assertEquals(Integer.valueOf(123), NumberUtils.createInteger("123"));
    }

    @Test
    public void testCreateIntegerHex() {
        assertEquals(Integer.valueOf(26), NumberUtils.createInteger("0x1A"));
    }

    @Test
    public void testCreateIntegerOctal() {
        // createInteger handles octal notation, unlike createNumber
        assertEquals(Integer.valueOf(8), NumberUtils.createInteger("010"));
    }

    @Test(expected = NumberFormatException.class)
    public void testCreateIntegerInvalid() {
        NumberUtils.createInteger("abc");
    }

    // ---------------------------------------------------------------
    // createLong
    // ---------------------------------------------------------------

    @Test
    public void testCreateLong() {
        assertNull(NumberUtils.createLong(null));
        assertEquals(Long.valueOf(123L), NumberUtils.createLong("123"));
    }

    @Test(expected = NumberFormatException.class)
    public void testCreateLongInvalid() {
        NumberUtils.createLong("abc");
    }

    // ---------------------------------------------------------------
    // createBigInteger
    // ---------------------------------------------------------------

    @Test
    public void testCreateBigInteger() {
        assertNull(NumberUtils.createBigInteger(null));
        assertEquals(BigInteger.valueOf(123L), NumberUtils.createBigInteger("123"));
    }

    @Test(expected = NumberFormatException.class)
    public void testCreateBigIntegerInvalid() {
        NumberUtils.createBigInteger("abc");
    }

    // ---------------------------------------------------------------
    // createBigDecimal
    // ---------------------------------------------------------------

    @Test
    public void testCreateBigDecimal() {
        assertNull(NumberUtils.createBigDecimal(null));
        assertEquals(new BigDecimal("123.45"), NumberUtils.createBigDecimal("123.45"));
    }

    @Test(expected = NumberFormatException.class)
    public void testCreateBigDecimalInvalid() {
        NumberUtils.createBigDecimal("abc");
    }

    @Test(expected = NumberFormatException.class)
    public void testCreateBigDecimalEmpty() {
        NumberUtils.createBigDecimal("");
    }

    // ---------------------------------------------------------------
    // min/max array - byte
    // ---------------------------------------------------------------

    @Test
    public void testMinByteArray() {
        assertEquals((byte) 2, NumberUtils.min(new byte[] {5, 2, 9}));
        assertEquals((byte) 7, NumberUtils.min(new byte[] {7}));
    }

    @Test
    public void testMaxByteArray() {
        assertEquals((byte) 9, NumberUtils.max(new byte[] {5, 2, 9}));
        assertEquals((byte) 7, NumberUtils.max(new byte[] {7}));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMinByteArrayNull() {
        NumberUtils.min((byte[]) null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMinByteArrayEmpty() {
        NumberUtils.min(new byte[0]);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMaxByteArrayNull() {
        NumberUtils.max((byte[]) null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMaxByteArrayEmpty() {
        NumberUtils.max(new byte[0]);
    }

    // ---------------------------------------------------------------
    // min/max array - short
    // ---------------------------------------------------------------

    @Test
    public void testMinShortArray() {
        assertEquals((short) -4, NumberUtils.min(new short[] {5, -4, 9}));
    }

    @Test
    public void testMaxShortArray() {
        assertEquals((short) 9, NumberUtils.max(new short[] {5, -4, 9}));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMinShortArrayNull() {
        NumberUtils.min((short[]) null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMaxShortArrayEmpty() {
        NumberUtils.max(new short[0]);
    }

    // ---------------------------------------------------------------
    // min/max array - int
    // ---------------------------------------------------------------

    @Test
    public void testMinIntArray() {
        assertEquals(-4, NumberUtils.min(new int[] {5, -4, 9}));
    }

    @Test
    public void testMaxIntArray() {
        assertEquals(9, NumberUtils.max(new int[] {5, -4, 9}));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMinIntArrayNull() {
        NumberUtils.min((int[]) null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMaxIntArrayEmpty() {
        NumberUtils.max(new int[0]);
    }

    // ---------------------------------------------------------------
    // min/max array - long
    // ---------------------------------------------------------------

    @Test
    public void testMinLongArray() {
        assertEquals(-4L, NumberUtils.min(new long[] {5L, -4L, 9L}));
    }

    @Test
    public void testMaxLongArray() {
        assertEquals(9L, NumberUtils.max(new long[] {5L, -4L, 9L}));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMinLongArrayNull() {
        NumberUtils.min((long[]) null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMaxLongArrayEmpty() {
        NumberUtils.max(new long[0]);
    }

    // ---------------------------------------------------------------
    // min/max array - double
    // ---------------------------------------------------------------

    @Test
    public void testMinDoubleArray() {
        assertEquals(-4.5d, NumberUtils.min(new double[] {5.5d, -4.5d, 9.5d}), 0.0d);
    }

    @Test
    public void testMaxDoubleArray() {
        assertEquals(9.5d, NumberUtils.max(new double[] {5.5d, -4.5d, 9.5d}), 0.0d);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMinDoubleArrayNull() {
        NumberUtils.min((double[]) null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMaxDoubleArrayEmpty() {
        NumberUtils.max(new double[0]);
    }

    // ---------------------------------------------------------------
    // min/max array - float
    // ---------------------------------------------------------------

    @Test
    public void testMinFloatArray() {
        assertEquals(-4.5f, NumberUtils.min(new float[] {5.5f, -4.5f, 9.5f}), 0.0f);
    }

    @Test
    public void testMaxFloatArray() {
        assertEquals(9.5f, NumberUtils.max(new float[] {5.5f, -4.5f, 9.5f}), 0.0f);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMinFloatArrayNull() {
        NumberUtils.min((float[]) null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMaxFloatArrayEmpty() {
        NumberUtils.max(new float[0]);
    }

    // ---------------------------------------------------------------
    // min/max of three values
    // ---------------------------------------------------------------

    @Test
    public void testMinMaxThreeBytes() {
        assertEquals((byte) 1, NumberUtils.min((byte) 3, (byte) 1, (byte) 2));
        assertEquals((byte) 3, NumberUtils.max((byte) 3, (byte) 1, (byte) 2));
    }

    @Test
    public void testMinMaxThreeShorts() {
        assertEquals((short) 1, NumberUtils.min((short) 3, (short) 1, (short) 2));
        assertEquals((short) 3, NumberUtils.max((short) 3, (short) 1, (short) 2));
    }

    @Test
    public void testMinMaxThreeInts() {
        assertEquals(1, NumberUtils.min(3, 1, 2));
        assertEquals(3, NumberUtils.max(3, 1, 2));
        assertEquals(-5, NumberUtils.min(-1, -5, -2));
        assertEquals(-1, NumberUtils.max(-1, -5, -2));
    }

    @Test
    public void testMinMaxThreeLongs() {
        assertEquals(1L, NumberUtils.min(3L, 1L, 2L));
        assertEquals(3L, NumberUtils.max(3L, 1L, 2L));
    }

    @Test
    public void testMinMaxThreeDoubles() {
        assertEquals(1.0d, NumberUtils.min(3.0d, 1.0d, 2.0d), 0.0d);
        assertEquals(3.0d, NumberUtils.max(3.0d, 1.0d, 2.0d), 0.0d);
    }

    @Test
    public void testMinMaxThreeFloats() {
        assertEquals(1.0f, NumberUtils.min(3.0f, 1.0f, 2.0f), 0.0f);
        assertEquals(3.0f, NumberUtils.max(3.0f, 1.0f, 2.0f), 0.0f);
    }

    @Test
    public void testMinMaxThreeDoublesWithNaN() {
        // if any value is NaN, NaN is returned
        assertTrue(Double.isNaN(NumberUtils.min(1.0d, Double.NaN, 2.0d)));
        assertTrue(Double.isNaN(NumberUtils.max(1.0d, Double.NaN, 2.0d)));
    }

    @Test
    public void testMinMaxThreeFloatsWithNaN() {
        assertTrue(Float.isNaN(NumberUtils.min(1.0f, Float.NaN, 2.0f)));
        assertTrue(Float.isNaN(NumberUtils.max(1.0f, Float.NaN, 2.0f)));
    }

    @Test
    public void testMinMaxThreeDoublesWithInfinity() {
        assertEquals(Double.NEGATIVE_INFINITY,
                NumberUtils.min(1.0d, Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY), 0.0d);
        assertEquals(Double.POSITIVE_INFINITY,
                NumberUtils.max(1.0d, Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY), 0.0d);
    }

    @Test
    public void testMinMaxThreeFloatsWithInfinity() {
        assertEquals(Float.NEGATIVE_INFINITY,
                NumberUtils.min(1.0f, Float.POSITIVE_INFINITY, Float.NEGATIVE_INFINITY), 0.0f);
        assertEquals(Float.POSITIVE_INFINITY,
                NumberUtils.max(1.0f, Float.POSITIVE_INFINITY, Float.NEGATIVE_INFINITY), 0.0f);
    }

    // ---------------------------------------------------------------
    // isDigits
    // ---------------------------------------------------------------

    @Test
    public void testIsDigits() {
        assertFalse(NumberUtils.isDigits(null));
        assertFalse(NumberUtils.isDigits(""));
        assertTrue(NumberUtils.isDigits("12345"));
        assertFalse(NumberUtils.isDigits("123a45"));
        assertFalse(NumberUtils.isDigits("-123"));
        assertFalse(NumberUtils.isDigits("12.3"));
        assertFalse(NumberUtils.isDigits(" 123"));
    }

    // ---------------------------------------------------------------
    // isNumber
    // ---------------------------------------------------------------

    @Test
    public void testIsNumber() {
        assertFalse(NumberUtils.isNumber(null));
        assertFalse(NumberUtils.isNumber(""));
        assertTrue(NumberUtils.isNumber("1"));
        assertTrue(NumberUtils.isNumber("-1"));
        assertTrue(NumberUtils.isNumber("1.5"));
        assertTrue(NumberUtils.isNumber("0x1A"));
        assertTrue(NumberUtils.isNumber("1e10"));
        assertTrue(NumberUtils.isNumber("123L"));
        assertFalse(NumberUtils.isNumber("abc"));
        assertFalse(NumberUtils.isNumber("12abc"));
        assertFalse(NumberUtils.isNumber(" 12"));
    }

    // ---------------------------------------------------------------
    // Constructor accessibility
    // ---------------------------------------------------------------

    @Test
    public void testConstructorIsPublic() {
        // "This constructor is public to permit tools that require a
        // JavaBean instance to operate."
        NumberUtils instance = new NumberUtils();
        assertTrue(instance instanceof NumberUtils);
    }
}
