/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang.time;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.FieldPosition;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Self-contained tests for {@link FastDateFormat}.
 */
public class FastDateFormatAgentTest extends TestCase {

    public static Test suite() {
        return new TestSuite(FastDateFormatAgentTest.class);
    }

    public FastDateFormatAgentTest(String name) {
        super(name);
    }

    private static final TimeZone UTC = TimeZone.getTimeZone("UTC");

    private Calendar utcCalendar(int year, int month, int day, int hour, int minute, int second, int millis) {
        Calendar cal = new GregorianCalendar(UTC);
        cal.clear();
        cal.set(year, month, day, hour, minute, second);
        cal.set(Calendar.MILLISECOND, millis);
        return cal;
    }

    //-----------------------------------------------------------------------
    // getInstance() factory methods
    //-----------------------------------------------------------------------

    public void testGetInstanceDefaultPattern() {
        FastDateFormat fdf = FastDateFormat.getInstance();
        assertNotNull(fdf);
        String expected = new SimpleDateFormat().toPattern();
        assertEquals(expected, fdf.getPattern());
    }

    public void testGetInstanceNullPatternThrows() {
        try {
            FastDateFormat.getInstance(null);
            fail("Expected IllegalArgumentException for null pattern");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    public void testGetInstanceCachesEqualRequests() {
        FastDateFormat a = FastDateFormat.getInstance("yyyy-MM-dd");
        FastDateFormat b = FastDateFormat.getInstance("yyyy-MM-dd");
        assertSame(a, b);
    }

    public void testGetInstanceDifferentPatternsDifferentObjects() {
        FastDateFormat a = FastDateFormat.getInstance("yyyy-MM-dd");
        FastDateFormat b = FastDateFormat.getInstance("yyyy/MM/dd");
        assertFalse(a.equals(b));
    }

    public void testGetInstanceInvalidPatternThrows() {
        try {
            FastDateFormat.getInstance("yyyy-Q");
            fail("Expected IllegalArgumentException for illegal pattern component");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    public void testGetDateInstanceInvalidStyleThrows() {
        try {
            FastDateFormat.getDateInstance(999);
            fail("Expected IllegalArgumentException for invalid style");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    public void testGetTimeInstanceInvalidStyleThrows() {
        try {
            FastDateFormat.getTimeInstance(-5);
            fail("Expected IllegalArgumentException for invalid style");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    public void testGetDateInstanceStyles() {
        FastDateFormat full = FastDateFormat.getDateInstance(FastDateFormat.FULL, Locale.US);
        FastDateFormat shortFmt = FastDateFormat.getDateInstance(FastDateFormat.SHORT, Locale.US);
        assertNotNull(full.getPattern());
        assertNotNull(shortFmt.getPattern());
        assertFalse(full.getPattern().equals(shortFmt.getPattern()));
    }

    public void testGetTimeInstanceCaching() {
        FastDateFormat a = FastDateFormat.getTimeInstance(FastDateFormat.SHORT, Locale.US);
        FastDateFormat b = FastDateFormat.getTimeInstance(FastDateFormat.SHORT, Locale.US);
        assertSame(a, b);
    }

    public void testGetDateTimeInstance() {
        FastDateFormat fdf = FastDateFormat.getDateTimeInstance(
                FastDateFormat.SHORT, FastDateFormat.SHORT, Locale.US);
        assertNotNull(fdf.getPattern());
        assertEquals(Locale.US, fdf.getLocale());
    }

    //-----------------------------------------------------------------------
    // format() basic patterns
    //-----------------------------------------------------------------------

    public void testFormatDateWithMillisPattern() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss.SSS", UTC, Locale.US);
        Calendar cal = utcCalendar(2023, Calendar.JANUARY, 5, 3, 4, 5, 6);
        String result = fdf.format(cal.getTime());
        assertEquals("2023-01-05 03:04:05.006", result);
    }

    public void testFormatCalendar() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd", UTC, Locale.US);
        Calendar cal = utcCalendar(1999, Calendar.DECEMBER, 31, 0, 0, 0, 0);
        assertEquals("1999-12-31", fdf.format(cal));
    }

    public void testFormatLongMillis() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd", UTC, Locale.US);
        long epoch = 0L; // 1970-01-01T00:00:00Z
        assertEquals("1970-01-01", fdf.format(epoch));
    }

    public void testFormatIntoSuppliedBuffer() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy", UTC, Locale.US);
        Calendar cal = utcCalendar(2020, Calendar.JANUARY, 1, 0, 0, 0, 0);
        StringBuffer buf = new StringBuffer("prefix-");
        StringBuffer result = fdf.format(cal.getTime(), buf);
        assertSame(buf, result);
        assertEquals("prefix-2020", result.toString());
    }

    public void testFormatCalendarIntoSuppliedBuffer() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy", UTC, Locale.US);
        Calendar cal = utcCalendar(2021, Calendar.JANUARY, 1, 0, 0, 0, 0);
        StringBuffer buf = new StringBuffer();
        StringBuffer result = fdf.format(cal, buf);
        assertSame(buf, result);
        assertEquals("2021", result.toString());
    }

    public void testFormatLongMillisIntoSuppliedBuffer() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy", UTC, Locale.US);
        StringBuffer buf = new StringBuffer();
        StringBuffer result = fdf.format(0L, buf);
        assertSame(buf, result);
        assertEquals("1970", result.toString());
    }

    //-----------------------------------------------------------------------
    // format(Object, StringBuffer, FieldPosition)
    //-----------------------------------------------------------------------

    public void testFormatObjectDispatchesDate() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy", UTC, Locale.US);
        Calendar cal = utcCalendar(2022, Calendar.JANUARY, 1, 0, 0, 0, 0);
        StringBuffer buf = new StringBuffer();
        fdf.format((Object) cal.getTime(), buf, new FieldPosition(0));
        assertEquals("2022", buf.toString());
    }

    public void testFormatObjectDispatchesCalendar() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy", UTC, Locale.US);
        Calendar cal = utcCalendar(2024, Calendar.JANUARY, 1, 0, 0, 0, 0);
        StringBuffer buf = new StringBuffer();
        fdf.format((Object) cal, buf, new FieldPosition(0));
        assertEquals("2024", buf.toString());
    }

    public void testFormatObjectDispatchesLong() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy", UTC, Locale.US);
        StringBuffer buf = new StringBuffer();
        fdf.format(Long.valueOf(0L), buf, new FieldPosition(0));
        assertEquals("1970", buf.toString());
    }

    public void testFormatObjectUnknownTypeThrows() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy", UTC, Locale.US);
        try {
            fdf.format((Object) "not a date", new StringBuffer(), new FieldPosition(0));
            fail("Expected IllegalArgumentException for unknown object type");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    public void testFormatObjectNullThrowsWithNullMessage() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy", UTC, Locale.US);
        try {
            fdf.format((Object) null, new StringBuffer(), new FieldPosition(0));
            fail("Expected IllegalArgumentException for null object");
        } catch (IllegalArgumentException ex) {
            assertTrue(ex.getMessage().indexOf("<null>") >= 0);
        }
    }

    //-----------------------------------------------------------------------
    // parseObject - unsupported
    //-----------------------------------------------------------------------

    public void testParseObjectAlwaysReturnsNull() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd", UTC, Locale.US);
        ParsePosition pos = new ParsePosition(5);
        pos.setErrorIndex(5);
        Object result = fdf.parseObject("2020-01-01", pos);
        assertNull(result);
        assertEquals(0, pos.getIndex());
        assertEquals(0, pos.getErrorIndex());
    }

    //-----------------------------------------------------------------------
    // Text fields: era, month, weekday, am/pm
    //-----------------------------------------------------------------------

    public void testTextFieldsFullAndShort() {
        FastDateFormat full = FastDateFormat.getInstance("MMMM", UTC, Locale.US);
        FastDateFormat shortFmt = FastDateFormat.getInstance("MMM", UTC, Locale.US);
        Calendar cal = utcCalendar(2023, Calendar.MARCH, 15, 0, 0, 0, 0);
        assertEquals("March", full.format(cal));
        assertEquals("Mar", shortFmt.format(cal));
    }

    public void testEraAndAmPm() {
        FastDateFormat fdf = FastDateFormat.getInstance("G a", UTC, Locale.US);
        Calendar morning = utcCalendar(2023, Calendar.MARCH, 15, 1, 0, 0, 0);
        Calendar evening = utcCalendar(2023, Calendar.MARCH, 15, 23, 0, 0, 0);
        assertEquals("AD AM", fdf.format(morning));
        assertEquals("AD PM", fdf.format(evening));
    }

    public void testWeekdayFullAndShort() {
        FastDateFormat full = FastDateFormat.getInstance("EEEE", UTC, Locale.US);
        FastDateFormat shortFmt = FastDateFormat.getInstance("EEE", UTC, Locale.US);
        // 2023-01-01 is a Sunday
        Calendar cal = utcCalendar(2023, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals("Sunday", full.format(cal));
        assertEquals("Sun", shortFmt.format(cal));
    }

    //-----------------------------------------------------------------------
    // Numeric field padding boundaries
    //-----------------------------------------------------------------------

    public void testUnpaddedVsTwoDigitVsPaddedDay() {
        FastDateFormat unpadded = FastDateFormat.getInstance("d", UTC, Locale.US);
        FastDateFormat twoDigit = FastDateFormat.getInstance("dd", UTC, Locale.US);
        FastDateFormat padded = FastDateFormat.getInstance("ddd", UTC, Locale.US);
        Calendar cal = utcCalendar(2023, Calendar.MARCH, 5, 0, 0, 0, 0);
        assertEquals("5", unpadded.format(cal));
        assertEquals("05", twoDigit.format(cal));
        assertEquals("005", padded.format(cal));
    }

    public void testUnpaddedMonthField() {
        FastDateFormat fdf = FastDateFormat.getInstance("M", UTC, Locale.US);
        Calendar cal = utcCalendar(2023, Calendar.MARCH, 5, 0, 0, 0, 0);
        assertEquals("3", fdf.format(cal));
    }

    public void testTwoDigitYearWraps() {
        FastDateFormat fdf = FastDateFormat.getInstance("yy", UTC, Locale.US);
        assertEquals("05", fdf.format(utcCalendar(2005, Calendar.JANUARY, 1, 0, 0, 0, 0)));
        assertEquals("99", fdf.format(utcCalendar(1999, Calendar.JANUARY, 1, 0, 0, 0, 0)));
        assertEquals("00", fdf.format(utcCalendar(2000, Calendar.JANUARY, 1, 0, 0, 0, 0)));
    }

    public void testPaddedFourDigitYear() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy", UTC, Locale.US);
        assertEquals("0005", fdf.format(utcCalendar(5, Calendar.JANUARY, 1, 0, 0, 0, 0)));
        assertEquals("2023", fdf.format(utcCalendar(2023, Calendar.JANUARY, 1, 0, 0, 0, 0)));
    }

    public void testTwelveHourFieldMidnightBoundary() {
        FastDateFormat fdf = FastDateFormat.getInstance("h", UTC, Locale.US);
        // internal HOUR field is 0 at both midnight and noon; midnight displays as 12
        assertEquals("12", fdf.format(utcCalendar(2023, Calendar.JANUARY, 1, 0, 0, 0, 0)));
        assertEquals("1", fdf.format(utcCalendar(2023, Calendar.JANUARY, 1, 1, 0, 0, 0)));
    }

    public void testTwentyFourHourFieldMidnightBoundary() {
        FastDateFormat fdf = FastDateFormat.getInstance("k", UTC, Locale.US);
        assertEquals("24", fdf.format(utcCalendar(2023, Calendar.JANUARY, 1, 0, 0, 0, 0)));
        assertEquals("1", fdf.format(utcCalendar(2023, Calendar.JANUARY, 1, 1, 0, 0, 0)));
    }

    public void testHourInDayZeroBased() {
        FastDateFormat fdf = FastDateFormat.getInstance("HH", UTC, Locale.US);
        assertEquals("00", fdf.format(utcCalendar(2023, Calendar.JANUARY, 1, 0, 0, 0, 0)));
        assertEquals("23", fdf.format(utcCalendar(2023, Calendar.JANUARY, 1, 23, 0, 0, 0)));
    }

    //-----------------------------------------------------------------------
    // Literal text handling in patterns
    //-----------------------------------------------------------------------

    public void testQuotedLiteralText() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy'T'HH", UTC, Locale.US);
        assertEquals("2023T05", fdf.format(utcCalendar(2023, Calendar.JANUARY, 1, 5, 0, 0, 0)));
    }

    public void testEscapedSingleQuoteLiteral() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy''yyyy", UTC, Locale.US);
        assertEquals("2023'2023", fdf.format(utcCalendar(2023, Calendar.JANUARY, 1, 0, 0, 0, 0)));
    }

    public void testPlainPunctuationPassesThrough() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd", UTC, Locale.US);
        assertEquals("2023-03-05", fdf.format(utcCalendar(2023, Calendar.MARCH, 5, 0, 0, 0, 0)));
    }

    //-----------------------------------------------------------------------
    // Time zone number rule ('Z')
    //-----------------------------------------------------------------------

    public void testTimeZoneNumberNoColon() {
        TimeZone tz = TimeZone.getTimeZone("GMT+05:30");
        FastDateFormat fdf = FastDateFormat.getInstance("Z", tz, Locale.US);
        Calendar cal = utcCalendar(2023, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals("+0530", fdf.format(cal.getTime()));
    }

    public void testTimeZoneNumberWithColon() {
        TimeZone tz = TimeZone.getTimeZone("GMT+05:30");
        FastDateFormat fdf = FastDateFormat.getInstance("ZZ", tz, Locale.US);
        Calendar cal = utcCalendar(2023, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals("+05:30", fdf.format(cal.getTime()));
    }

    public void testTimeZoneNumberNegativeOffset() {
        TimeZone tz = TimeZone.getTimeZone("GMT-07:00");
        FastDateFormat fdf = FastDateFormat.getInstance("Z", tz, Locale.US);
        Calendar cal = utcCalendar(2023, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals("-0700", fdf.format(cal.getTime()));
    }

    public void testTimeZoneNameNotEmpty() {
        TimeZone tz = TimeZone.getTimeZone("GMT+05:30");
        FastDateFormat shortName = FastDateFormat.getInstance("z", tz, Locale.US);
        FastDateFormat longName = FastDateFormat.getInstance("zzzz", tz, Locale.US);
        Calendar cal = utcCalendar(2023, Calendar.JANUARY, 1, 0, 0, 0, 0);
        String shortResult = shortName.format(cal.getTime());
        String longResult = longName.format(cal.getTime());
        assertTrue(shortResult.length() > 0);
        assertTrue(longResult.length() > 0);
    }

    //-----------------------------------------------------------------------
    // Time zone override behaviour
    //-----------------------------------------------------------------------

    public void testForcedTimeZoneOverridesCalendarTimeZone() {
        TimeZone forced = TimeZone.getTimeZone("GMT+00:00");
        FastDateFormat fdf = FastDateFormat.getInstance("HH:mm", forced, Locale.US);
        assertTrue(fdf.getTimeZoneOverridesCalendar());

        // 2023-01-01T15:00:00Z, fixed via an absolute instant so that the
        // calendar's time (not just its fields) is set before formatting
        java.util.Date instant = utcCalendar(2023, Calendar.JANUARY, 1, 15, 0, 0, 0).getTime();
        TimeZone nyZone = TimeZone.getTimeZone("GMT-05:00");
        Calendar nyCal = new GregorianCalendar(nyZone);
        nyCal.setTime(instant);
        assertEquals(10, nyCal.get(Calendar.HOUR_OF_DAY));

        // since the formatter forces GMT+00:00, the output must reflect
        // the same instant re-expressed in that zone: 15:00
        assertEquals("15:00", fdf.format(nyCal));
    }

    public void testNonForcedUsesCalendarOwnTimeZone() {
        FastDateFormat fdf = FastDateFormat.getInstance("HH:mm", Locale.US);
        assertFalse(fdf.getTimeZoneOverridesCalendar());

        java.util.Date instant = utcCalendar(2023, Calendar.JANUARY, 1, 15, 0, 0, 0).getTime();
        TimeZone nyZone = TimeZone.getTimeZone("GMT-05:00");
        Calendar nyCal = new GregorianCalendar(nyZone);
        nyCal.setTime(instant);

        assertEquals("10:00", fdf.format(nyCal));
    }

    //-----------------------------------------------------------------------
    // Accessors
    //-----------------------------------------------------------------------

    public void testAccessors() {
        TimeZone tz = TimeZone.getTimeZone("GMT+02:00");
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd", tz, Locale.FRANCE);
        assertEquals("yyyy-MM-dd", fdf.getPattern());
        assertEquals(tz, fdf.getTimeZone());
        assertEquals(Locale.FRANCE, fdf.getLocale());
        assertTrue(fdf.getTimeZoneOverridesCalendar());
        assertTrue(fdf.getMaxLengthEstimate() > 0);
    }

    public void testMaxLengthEstimateIsNotExceededByActualOutput() {
        FastDateFormat fdf = FastDateFormat.getInstance("EEEE, MMMM d, yyyy HH:mm:ss.SSS", UTC, Locale.US);
        Calendar cal = utcCalendar(2023, Calendar.SEPTEMBER, 27, 12, 30, 45, 999);
        String formatted = fdf.format(cal);
        assertTrue(formatted.length() <= fdf.getMaxLengthEstimate());
    }

    public void testToString() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd");
        assertEquals("FastDateFormat[yyyy-MM-dd]", fdf.toString());
    }

    //-----------------------------------------------------------------------
    // equals() / hashCode() - constructed directly to bypass the cache
    //-----------------------------------------------------------------------

    public void testEqualsSameFieldsAreEqual() {
        TimeZone tz = TimeZone.getTimeZone("GMT+01:00");
        FastDateFormat a = new FastDateFormat("yyyy-MM-dd", tz, Locale.US);
        FastDateFormat b = new FastDateFormat("yyyy-MM-dd", tz, Locale.US);
        assertTrue(a.equals(b));
        assertTrue(b.equals(a));
        assertEquals(a.hashCode(), b.hashCode());
    }

    public void testEqualsDifferentPatternNotEqual() {
        TimeZone tz = TimeZone.getTimeZone("GMT+01:00");
        FastDateFormat a = new FastDateFormat("yyyy-MM-dd", tz, Locale.US);
        FastDateFormat b = new FastDateFormat("dd-MM-yyyy", tz, Locale.US);
        assertFalse(a.equals(b));
    }

    public void testEqualsForcedFlagMatters() {
        // explicitly passing the default time zone sets the "forced" flag,
        // which is part of the equals() contract, even though both
        // instances resolve to the very same TimeZone object.
        TimeZone defaultTz = TimeZone.getDefault();
        FastDateFormat implicitDefault = new FastDateFormat("yyyy-MM-dd", null, Locale.US);
        FastDateFormat explicitDefault = new FastDateFormat("yyyy-MM-dd", defaultTz, Locale.US);
        assertFalse(implicitDefault.equals(explicitDefault));
    }

    public void testEqualsRejectsOtherTypesAndNull() {
        FastDateFormat a = new FastDateFormat("yyyy-MM-dd", UTC, Locale.US);
        assertFalse(a.equals("yyyy-MM-dd"));
        assertFalse(a.equals(null));
    }

    //-----------------------------------------------------------------------
    // Serialization
    //-----------------------------------------------------------------------

    public void testSerializationRoundTrip() throws Exception {
        FastDateFormat original = FastDateFormat.getInstance("yyyy-MM-dd HH:mm", UTC, Locale.US);

        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(bos);
        oos.writeObject(original);
        oos.close();

        ByteArrayInputStream bis = new ByteArrayInputStream(bos.toByteArray());
        ObjectInputStream ois = new ObjectInputStream(bis);
        FastDateFormat copy = (FastDateFormat) ois.readObject();
        ois.close();

        assertEquals(original.getPattern(), copy.getPattern());
        Calendar cal = utcCalendar(2023, Calendar.JUNE, 15, 8, 30, 0, 0);
        assertEquals(original.format(cal), copy.format(cal));
        assertEquals("2023-06-15 08:30", copy.format(cal));
    }
}
