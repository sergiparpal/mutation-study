/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.csv;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;

import org.junit.Test;

public class CSVFormatAgentTest {

    @Test
    public void testNewFormatBasicGetters() {
        final CSVFormat format = CSVFormat.newFormat(';');
        assertEquals(';', format.getDelimiter());
        assertNull(format.getQuoteChar());
        assertNull(format.getQuotePolicy());
        assertNull(format.getCommentStart());
        assertNull(format.getEscape());
        assertFalse(format.getIgnoreSurroundingSpaces());
        assertFalse(format.getIgnoreEmptyLines());
        assertNull(format.getRecordSeparator());
        assertNull(format.getNullString());
        assertNull(format.getHeader());
        assertFalse(format.getSkipHeaderRecord());
        assertFalse(format.isCommentingEnabled());
        assertFalse(format.isEscaping());
        assertFalse(format.isNullHandling());
        assertFalse(format.isQuoting());
    }

    @Test
    public void testNewFormatRejectsLineBreakDelimiter() {
        try {
            CSVFormat.newFormat('\n');
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
        try {
            CSVFormat.newFormat('\r');
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testWithDelimiterRejectsLineBreak() {
        try {
            CSVFormat.DEFAULT.withDelimiter('\n');
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testWithDelimiterReturnsNewInstanceImmutably() {
        final CSVFormat base = CSVFormat.DEFAULT;
        final CSVFormat changed = base.withDelimiter(';');
        assertEquals(',', base.getDelimiter());
        assertEquals(';', changed.getDelimiter());
        assertNotEquals(base, changed);
    }

    @Test
    public void testWithQuoteCharRejectsLineBreak() {
        try {
            CSVFormat.DEFAULT.withQuoteChar('\r');
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testWithQuoteCharAllowsNull() {
        final CSVFormat format = CSVFormat.DEFAULT.withQuoteChar(null);
        assertNull(format.getQuoteChar());
        assertFalse(format.isQuoting());
    }

    @Test
    public void testWithEscapeRejectsLineBreak() {
        try {
            CSVFormat.DEFAULT.withEscape('\n');
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testWithEscapeSetsCharacterAndFlag() {
        final CSVFormat format = CSVFormat.DEFAULT.withEscape('\\');
        assertEquals(Character.valueOf('\\'), format.getEscape());
        assertTrue(format.isEscaping());
    }

    @Test
    public void testWithCommentStartRejectsLineBreak() {
        try {
            CSVFormat.DEFAULT.withCommentStart('\r');
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testWithCommentStartSetsCharacterAndFlag() {
        final CSVFormat format = CSVFormat.DEFAULT.withCommentStart('#');
        assertEquals(Character.valueOf('#'), format.getCommentStart());
        assertTrue(format.isCommentingEnabled());
    }

    @Test
    public void testWithNullString() {
        final CSVFormat format = CSVFormat.DEFAULT.withNullString("N/A");
        assertEquals("N/A", format.getNullString());
        assertTrue(format.isNullHandling());
        assertFalse(CSVFormat.DEFAULT.isNullHandling());
    }

    @Test
    public void testWithIgnoreEmptyLinesAndSurroundingSpaces() {
        final CSVFormat format = CSVFormat.newFormat(',')
                .withIgnoreEmptyLines(true)
                .withIgnoreSurroundingSpaces(true);
        assertTrue(format.getIgnoreEmptyLines());
        assertTrue(format.getIgnoreSurroundingSpaces());
    }

    @Test
    public void testWithSkipHeaderRecord() {
        final CSVFormat format = CSVFormat.DEFAULT.withSkipHeaderRecord(true);
        assertTrue(format.getSkipHeaderRecord());
        assertFalse(CSVFormat.DEFAULT.getSkipHeaderRecord());
    }

    @Test
    public void testWithHeaderCopiesArrayAndRejectsDuplicates() {
        final String[] header = {"a", "b", "c"};
        final CSVFormat format = CSVFormat.DEFAULT.withHeader(header);
        assertArrayEquals(header, format.getHeader());
        // The returned array must be a defensive copy, not the same backing array.
        header[0] = "mutated";
        assertEquals("a", format.getHeader()[0]);

        try {
            CSVFormat.DEFAULT.withHeader("x", "y", "x");
            fail("Expected IllegalArgumentException for duplicate header entries");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testWithHeaderEmptyIsNotNull() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader();
        assertNotNull(format.getHeader());
        assertEquals(0, format.getHeader().length);
    }

    @Test
    public void testGetHeaderReturnsNullWhenUnset() {
        assertNull(CSVFormat.DEFAULT.getHeader());
    }

    @Test
    public void testWithRecordSeparatorCharAndString() {
        final CSVFormat fromChar = CSVFormat.DEFAULT.withRecordSeparator('\n');
        assertEquals("\n", fromChar.getRecordSeparator());

        final CSVFormat fromString = CSVFormat.DEFAULT.withRecordSeparator("\r\n");
        assertEquals("\r\n", fromString.getRecordSeparator());
    }

    @Test
    public void testWithQuotePolicy() {
        final CSVFormat format = CSVFormat.DEFAULT.withQuotePolicy(Quote.ALL);
        assertEquals(Quote.ALL, format.getQuotePolicy());
    }

    @Test
    public void testDefaultFormatSettings() {
        assertEquals(',', CSVFormat.DEFAULT.getDelimiter());
        assertEquals(Character.valueOf('"'), CSVFormat.DEFAULT.getQuoteChar());
        assertEquals("\r\n", CSVFormat.DEFAULT.getRecordSeparator());
        assertTrue(CSVFormat.DEFAULT.getIgnoreEmptyLines());
        assertFalse(CSVFormat.DEFAULT.getIgnoreSurroundingSpaces());
    }

    @Test
    public void testTdfFormatSettings() {
        assertEquals('\t', CSVFormat.TDF.getDelimiter());
        assertTrue(CSVFormat.TDF.getIgnoreSurroundingSpaces());
    }

    @Test
    public void testMysqlFormatSettings() {
        assertEquals('\t', CSVFormat.MYSQL.getDelimiter());
        assertEquals(Character.valueOf('\\'), CSVFormat.MYSQL.getEscape());
        assertNull(CSVFormat.MYSQL.getQuoteChar());
        assertEquals("\n", CSVFormat.MYSQL.getRecordSeparator());
        assertFalse(CSVFormat.MYSQL.getIgnoreEmptyLines());
    }

    @Test
    public void testEqualsAndHashCodeContract() {
        final CSVFormat a = CSVFormat.newFormat(',').withQuoteChar('"');
        final CSVFormat b = CSVFormat.newFormat(',').withQuoteChar('"');
        final CSVFormat c = CSVFormat.newFormat(';').withQuoteChar('"');

        assertTrue(a.equals(b));
        assertTrue(b.equals(a));
        assertEquals(a.hashCode(), b.hashCode());
        assertFalse(a.equals(c));

        assertFalse(a.equals(null));
        assertFalse(a.equals("not a CSVFormat"));
        assertTrue(a.equals(a));
    }

    @Test
    public void testFormatMethod() {
        final String formatted = CSVFormat.DEFAULT.format("a", "b", "c");
        assertEquals("a,b,c", formatted);
    }

    @Test
    public void testFormatMethodQuotesValuesContainingDelimiter() {
        final String formatted = CSVFormat.DEFAULT.format("a,b", "c");
        assertEquals("\"a,b\",c", formatted);
    }

    @Test
    public void testToStringContainsConfiguredAttributes() {
        final CSVFormat format = CSVFormat.DEFAULT
                .withCommentStart('#')
                .withEscape('\\')
                .withNullString("NULL")
                .withHeader("a", "b");
        final String text = format.toString();
        assertTrue(text.contains("Delimiter=<,>"));
        assertTrue(text.contains("Escape=<\\>"));
        assertTrue(text.contains("QuoteChar=<\">"));
        assertTrue(text.contains("CommentStart=<#>"));
        assertTrue(text.contains("NullString=<NULL>"));
        assertTrue(text.contains("Header:[a, b]"));
    }

    @Test
    public void testParseReturnsWorkingParser() throws IOException {
        final Reader in = new StringReader("a,b,c\n1,2,3\n");
        final CSVParser parser = CSVFormat.DEFAULT.parse(in);
        try {
            final CSVRecord header = parser.iterator().next();
            assertEquals("a", header.get(0));
            assertEquals("b", header.get(1));
            assertEquals("c", header.get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testValidateRejectsEqualQuoteAndDelimiter() {
        final CSVFormat format = CSVFormat.newFormat(',').withQuoteChar(',').withEscape('\\');
        try {
            format.validate();
            fail("Expected IllegalStateException");
        } catch (final IllegalStateException e) {
            // expected
        }
    }

    @Test
    public void testValidateRejectsEqualEscapeAndDelimiter() {
        final CSVFormat format = CSVFormat.newFormat(',').withEscape(',');
        try {
            format.validate();
            fail("Expected IllegalStateException");
        } catch (final IllegalStateException e) {
            // expected
        }
    }

    @Test
    public void testValidateRejectsEqualCommentAndDelimiter() {
        final CSVFormat format = CSVFormat.newFormat(',').withCommentStart(',').withEscape('\\');
        try {
            format.validate();
            fail("Expected IllegalStateException");
        } catch (final IllegalStateException e) {
            // expected
        }
    }

    @Test
    public void testValidateRejectsEqualQuoteAndComment() {
        final CSVFormat format = CSVFormat.newFormat(';')
                .withQuoteChar('#')
                .withCommentStart('#')
                .withEscape('\\');
        try {
            format.validate();
            fail("Expected IllegalStateException");
        } catch (final IllegalStateException e) {
            // expected
        }
    }

    @Test
    public void testValidateRejectsEqualEscapeAndComment() {
        final CSVFormat format = CSVFormat.newFormat(';')
                .withEscape('#')
                .withCommentStart('#');
        try {
            format.validate();
            fail("Expected IllegalStateException");
        } catch (final IllegalStateException e) {
            // expected
        }
    }

    @Test
    public void testValidateRejectsNoneQuotePolicyWithoutEscape() {
        final CSVFormat format = CSVFormat.newFormat(',').withQuotePolicy(Quote.NONE);
        try {
            format.validate();
            fail("Expected IllegalStateException");
        } catch (final IllegalStateException e) {
            // expected
        }
    }

    @Test
    public void testValidateAcceptsNoneQuotePolicyWithEscape() throws IOException {
        final CSVFormat format = CSVFormat.newFormat(',').withQuotePolicy(Quote.NONE).withEscape('\\');
        format.validate();
    }

    @Test
    public void testWithMethodsAreImmutableAndChainable() {
        final CSVFormat base = CSVFormat.DEFAULT;
        final CSVFormat derived = base
                .withDelimiter(';')
                .withQuoteChar('\'')
                .withEscape('\\')
                .withCommentStart('#')
                .withNullString("NULL")
                .withIgnoreEmptyLines(false)
                .withIgnoreSurroundingSpaces(true)
                .withSkipHeaderRecord(true)
                .withRecordSeparator('\n')
                .withHeader("x", "y");

        // Original DEFAULT must be untouched.
        assertEquals(',', base.getDelimiter());
        assertEquals(Character.valueOf('"'), base.getQuoteChar());
        assertNull(base.getEscape());
        assertNull(base.getCommentStart());
        assertNull(base.getNullString());
        assertTrue(base.getIgnoreEmptyLines());
        assertFalse(base.getIgnoreSurroundingSpaces());
        assertFalse(base.getSkipHeaderRecord());
        assertNull(base.getHeader());

        assertEquals(';', derived.getDelimiter());
        assertEquals(Character.valueOf('\''), derived.getQuoteChar());
        assertEquals(Character.valueOf('\\'), derived.getEscape());
        assertEquals(Character.valueOf('#'), derived.getCommentStart());
        assertEquals("NULL", derived.getNullString());
        assertFalse(derived.getIgnoreEmptyLines());
        assertTrue(derived.getIgnoreSurroundingSpaces());
        assertTrue(derived.getSkipHeaderRecord());
        assertArrayEquals(new String[] {"x", "y"}, derived.getHeader());
    }
}
