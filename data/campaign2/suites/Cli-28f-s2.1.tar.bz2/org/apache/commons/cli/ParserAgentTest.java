package org.apache.commons.cli;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.ListIterator;
import java.util.Properties;

import junit.framework.TestCase;

/**
 * Self-contained tests for the abstract {@link Parser} class, based solely on
 * the documented contract in Parser's javadoc.
 */
public class ParserAgentTest extends TestCase {

    /**
     * Minimal concrete subclass. flatten() is implemented as an identity
     * transform: every test below supplies arguments that are already
     * "atomic option and value tokens", so no real flattening is required
     * to exercise the documented behaviour of the non-abstract members.
     */
    private static class StubParser extends Parser {
        protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
            return arguments;
        }
    }

    private StubParser newParser() {
        return new StubParser();
    }

    // --- constructor -------------------------------------------------

    public void testConstructorCreatesInstance() {
        Parser parser = newParser();
        assertNotNull(parser);
        assertTrue(parser instanceof CommandLineParser);
    }

    // --- setOptions / getOptions --------------------------------------

    public void testSetOptionsAndGetOptionsRoundTrip() {
        StubParser parser = newParser();
        Options options = new Options();
        parser.setOptions(options);
        assertSame(options, parser.getOptions());
    }

    public void testSetOptionsReplacesPreviousValue() {
        StubParser parser = newParser();
        Options first = new Options();
        Options second = new Options();
        parser.setOptions(first);
        parser.setOptions(second);
        assertSame(second, parser.getOptions());
    }

    // --- getRequiredOptions --------------------------------------------

    public void testGetRequiredOptionsEmptyWhenNoneRequired() {
        StubParser parser = newParser();
        Options options = new Options();
        options.addOption("a", false, "a flag");
        parser.setOptions(options);

        List required = parser.getRequiredOptions();
        assertNotNull(required);
        assertEquals(0, required.size());
    }

    public void testGetRequiredOptionsReflectsRequiredOption() {
        StubParser parser = newParser();
        Options options = new Options();
        Option opt = new Option("r", false, "required flag");
        opt.setRequired(true);
        options.addOption(opt);
        parser.setOptions(options);

        List required = parser.getRequiredOptions();
        assertNotNull(required);
        assertEquals(1, required.size());
    }

    // --- parse(Options, String[]) --------------------------------------

    public void testParseTwoArgSetsFlagOption() throws Exception {
        StubParser parser = newParser();
        Options options = new Options();
        options.addOption("a", false, "a flag");

        CommandLine cmd = parser.parse(options, new String[] { "-a" });

        assertNotNull(cmd);
        assertTrue(cmd.hasOption("a"));
    }

    public void testParseTwoArgOptionWithValue() throws Exception {
        StubParser parser = newParser();
        Options options = new Options();
        options.addOption("b", "bee", true, "needs a value");

        CommandLine cmd = parser.parse(options, new String[] { "-b", "value" });

        assertTrue(cmd.hasOption("b"));
        assertEquals("value", cmd.getOptionValue("b"));
    }

    public void testParseTwoArgEmptyArgumentsYieldsEmptyCommandLine() throws Exception {
        StubParser parser = newParser();
        Options options = new Options();
        options.addOption("a", false, "a flag");

        CommandLine cmd = parser.parse(options, new String[0]);

        assertFalse(cmd.hasOption("a"));
        assertEquals(0, cmd.getArgs().length);
    }

    public void testParseTwoArgThrowsOnMissingRequiredOption() {
        StubParser parser = newParser();
        Options options = new Options();
        Option required = new Option("r", false, "required flag");
        required.setRequired(true);
        options.addOption(required);

        try {
            parser.parse(options, new String[0]);
            fail("Expected a ParseException for a missing required option");
        } catch (MissingOptionException expected) {
            // documented by checkRequiredOptions()
        } catch (ParseException e) {
            fail("Expected MissingOptionException, got " + e.getClass().getName());
        }
    }

    public void testParseTwoArgSucceedsWhenRequiredOptionPresent() throws Exception {
        StubParser parser = newParser();
        Options options = new Options();
        Option required = new Option("r", false, "required flag");
        required.setRequired(true);
        options.addOption(required);

        CommandLine cmd = parser.parse(options, new String[] { "-r" });

        assertTrue(cmd.hasOption("r"));
    }

    // --- parse(Options, String[], boolean) ------------------------------

    public void testParseThreeArgStopAtNonOptionTrueCollectsRemainingArgs() throws Exception {
        StubParser parser = newParser();
        Options options = new Options();
        options.addOption("a", false, "a flag");

        CommandLine cmd = parser.parse(options, new String[] { "-a", "unknown", "more" }, true);

        assertTrue(cmd.hasOption("a"));
        List args = cmd.getArgList();
        assertTrue(args.contains("unknown"));
        assertTrue(args.contains("more"));
    }

    public void pruned_testParseThreeArgStopAtNonOptionFalseThrowsOnUnrecognizedArgument() {
        StubParser parser = newParser();
        Options options = new Options();
        options.addOption("a", false, "a flag");

        try {
            parser.parse(options, new String[] { "-a", "unknown" }, false);
            fail("Expected a ParseException for an unrecognized argument when stopAtNonOption is false");
        } catch (ParseException expected) {
            // documented behaviour of the stopAtNonOption parameter
        }
    }

    // --- parse(Options, String[], Properties) ---------------------------

    public void testParseWithPropertiesSetsOptionFromProperties() throws Exception {
        StubParser parser = newParser();
        Options options = new Options();
        options.addOption("a", "aa", true, "needs a value");

        Properties properties = new Properties();
        properties.setProperty("a", "fromProperties");

        CommandLine cmd = parser.parse(options, new String[0], properties);

        assertTrue(cmd.hasOption("a"));
        assertEquals("fromProperties", cmd.getOptionValue("a"));
    }

    public void testParseWithPropertiesDoesNotOverrideCommandLineValue() throws Exception {
        StubParser parser = newParser();
        Options options = new Options();
        options.addOption("a", "aa", true, "needs a value");

        Properties properties = new Properties();
        properties.setProperty("a", "fromProperties");

        CommandLine cmd = parser.parse(options, new String[] { "-a", "fromCli" }, properties);

        assertTrue(cmd.hasOption("a"));
        assertEquals("fromCli", cmd.getOptionValue("a"));
    }

    // --- parse(Options, String[], Properties, boolean) ------------------

    public void testParseFourArgCombinesPropertiesAndStopAtNonOption() throws Exception {
        StubParser parser = newParser();
        Options options = new Options();
        options.addOption("a", "aa", true, "needs a value");

        Properties properties = new Properties();
        properties.setProperty("a", "fromProperties");

        CommandLine cmd = parser.parse(options, new String[] { "unknown" }, properties, true);

        assertTrue(cmd.hasOption("a"));
        assertEquals("fromProperties", cmd.getOptionValue("a"));
        assertTrue(cmd.getArgList().contains("unknown"));
    }

    public void pruned_testParseFourArgStopAtNonOptionFalseThrows() {
        StubParser parser = newParser();
        Options options = new Options();
        options.addOption("a", false, "a flag");

        try {
            parser.parse(options, new String[] { "unknown" }, new Properties(), false);
            fail("Expected a ParseException for an unrecognized argument when stopAtNonOption is false");
        } catch (ParseException expected) {
            // documented behaviour of the stopAtNonOption parameter
        }
    }

    // --- checkRequiredOptions() ------------------------------------------

    public void testCheckRequiredOptionsDoesNotThrowAfterSuccessfulParse() throws Exception {
        StubParser parser = newParser();
        Options options = new Options();
        Option required = new Option("r", false, "required flag");
        required.setRequired(true);
        options.addOption(required);

        parser.parse(options, new String[] { "-r" });

        // All required options were satisfied by the parse above; calling
        // checkRequiredOptions() again must not report anything missing.
        parser.checkRequiredOptions();
    }

    // --- processArgs(Option, ListIterator) -------------------------------

    public void pruned_testProcessArgsAssignsValueFromIterator() throws Exception {
        StubParser parser = newParser();
        Option opt = new Option("f", true, "needs a value");

        List values = new ArrayList();
        values.add("value1");
        ListIterator iter = values.listIterator();

        parser.processArgs(opt, iter);

        assertEquals("value1", opt.getValue());
    }

    public void testProcessArgsThrowsWhenValueMissing() {
        StubParser parser = newParser();
        Option opt = new Option("g", true, "needs a value");

        ListIterator emptyIter = new ArrayList().listIterator();

        try {
            parser.processArgs(opt, emptyIter);
            fail("Expected a ParseException because the required value was not found");
        } catch (ParseException expected) {
            // documented in processArgs()
        }
    }

    // --- processOption(String, ListIterator) -----------------------------

    public void testProcessOptionAddsOptionToExistingCommandLine() throws Exception {
        StubParser parser = newParser();
        Options options = new Options();
        options.addOption("a", false, "a flag");
        options.addOption("b", false, "b flag");

        CommandLine cmd = parser.parse(options, new String[] { "-a" });
        assertFalse(cmd.hasOption("b"));

        parser.processOption("-b", Collections.EMPTY_LIST.listIterator());

        // processOption() mutates the same CommandLine instance that parse()
        // returned, since it is built up on the Parser's internal state.
        assertTrue(cmd.hasOption("b"));
    }

    public void testProcessOptionThrowsForUnrecognizedArgument() throws Exception {
        StubParser parser = newParser();
        Options options = new Options();
        options.addOption("a", false, "a flag");

        parser.parse(options, new String[] { "-a" });

        try {
            parser.processOption("-z", Collections.EMPTY_LIST.listIterator());
            fail("Expected a ParseException because '-z' does not represent an Option");
        } catch (ParseException expected) {
            // documented in processOption()
        }
    }
}
