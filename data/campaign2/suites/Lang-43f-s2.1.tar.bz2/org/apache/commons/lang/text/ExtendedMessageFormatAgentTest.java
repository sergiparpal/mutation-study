package org.apache.commons.lang.text;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.text.Format;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.junit.Test;

/**
 * Self-contained JUnit 4 tests for
 * {@link org.apache.commons.lang.text.ExtendedMessageFormat}, based solely on
 * the documented contract in the generated javadoc.
 */
public class ExtendedMessageFormatAgentTest {

    // ------------------------------------------------------------------
    // Construction
    // ------------------------------------------------------------------

    @Test
    public void testConstructPatternOnly() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello, {0}!");
        assertEquals("Hello, World!", emf.format(new Object[] {"World"}));
    }

    @Test
    public void testConstructPatternAndLocale() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello, {0}!", Locale.US);
        assertEquals(Locale.US, emf.getLocale());
        assertEquals("Hello, World!", emf.format(new Object[] {"World"}));
    }

    @Test
    public void testConstructPatternAndRegistry() {
        Map registry = new HashMap();
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello, {0}!", registry);
        assertEquals("Hello, World!", emf.format(new Object[] {"World"}));
    }

    @Test
    public void testConstructPatternLocaleAndRegistry() {
        Map registry = new HashMap();
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello, {0}!", Locale.US, registry);
        assertEquals(Locale.US, emf.getLocale());
        assertEquals("Hello, World!", emf.format(new Object[] {"World"}));
    }

    @Test
    public void testConstructorRejectsUnterminatedPattern() {
        try {
            new ExtendedMessageFormat("Hello, {0");
            fail("Expected IllegalArgumentException for a bad (unterminated) pattern");
        } catch (IllegalArgumentException expected) {
            // documented behaviour
        }
    }

    @Test
    public void testConstructorRejectsNonNumericArgumentIndex() {
        try {
            new ExtendedMessageFormat("Hello, {abc}!");
            fail("Expected IllegalArgumentException for a bad pattern (non-numeric argument index)");
        } catch (IllegalArgumentException expected) {
            // documented behaviour
        }
    }

    // ------------------------------------------------------------------
    // toPattern() / applyPattern()
    // ------------------------------------------------------------------

    @Test
    public void testToPatternRoundTripsSimplePattern() {
        String pattern = "Hello, {0}!";
        ExtendedMessageFormat emf = new ExtendedMessageFormat(pattern);
        assertEquals(pattern, emf.toPattern());
    }

    @Test
    public void testApplyPatternChangesBehaviourAndToPattern() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello, {0}!");
        String newPattern = "Goodbye, {0}!";
        emf.applyPattern(newPattern);
        assertEquals(newPattern, emf.toPattern());
        assertEquals("Goodbye, World!", emf.format(new Object[] {"World"}));
    }

    @Test
    public void testApplyPatternRejectsBadPattern() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello, {0}!");
        try {
            emf.applyPattern("Hello, {0");
            fail("Expected IllegalArgumentException for a bad (unterminated) pattern");
        } catch (IllegalArgumentException expected) {
            // documented behaviour
        }
    }

    @Test
    public void testApplyPatternWithNumberSubformat() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Value: {0,number,00000}", Locale.US);
        assertEquals("Value: 00042", emf.format(new Object[] {new Integer(42)}));
    }

    @Test
    public void testApplyPatternWithChoiceSubformat() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat(
                "{0,choice,0#zero|1#one|2#many}", Locale.US);
        assertEquals("zero", emf.format(new Object[] {new Integer(0)}));
        assertEquals("one", emf.format(new Object[] {new Integer(1)}));
        assertEquals("many", emf.format(new Object[] {new Integer(2)}));
    }

    @Test
    public void testFormatWithMultipleArguments() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0} has {1,number} items.", Locale.US);
        assertEquals("Alice has 3 items.", emf.format(new Object[] {"Alice", new Integer(3)}));
    }

    @Test
    public void testFormatWithRepeatedArgumentIndex() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}-{0}", Locale.US);
        assertEquals("x-x", emf.format(new Object[] {"x"}));
    }

    @Test
    public void testFormatWithNoFormatElements() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("just plain text");
        assertEquals("just plain text", emf.format(new Object[] {}));
        assertEquals("just plain text", emf.toPattern());
    }

    // ------------------------------------------------------------------
    // Disabled mutator methods: documented to throw UnsupportedOperationException
    // ------------------------------------------------------------------

    @Test
    public void testSetFormatThrowsUnsupportedOperationException() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        try {
            emf.setFormat(0, java.text.NumberFormat.getInstance());
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // documented behaviour
        }
    }

    @Test
    public void testSetFormatByArgumentIndexThrowsUnsupportedOperationException() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        try {
            emf.setFormatByArgumentIndex(0, java.text.NumberFormat.getInstance());
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // documented behaviour
        }
    }

    @Test
    public void testSetFormatsThrowsUnsupportedOperationException() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        try {
            emf.setFormats(new Format[] {java.text.NumberFormat.getInstance()});
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // documented behaviour
        }
    }

    @Test
    public void testSetFormatsByArgumentIndexThrowsUnsupportedOperationException() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        try {
            emf.setFormatsByArgumentIndex(new Format[] {java.text.NumberFormat.getInstance()});
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // documented behaviour
        }
    }

    // ------------------------------------------------------------------
    // Inheritance / type checks implied by the javadoc
    // ------------------------------------------------------------------

    @Test
    public void testIsAMessageFormat() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertTrue(emf instanceof MessageFormat);
        assertNotNull(emf.getLocale());
    }
}
