package com.google.gson.internal.bind.util;

import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import junit.framework.TestCase;

/**
 * Self-contained tests for {@link ISO8601Utils}, based on the documented contract:
 * Supported parse/format pattern: [yyyy-MM-dd|yyyyMMdd][T(hh:mm[:ss[.sss]]|hhmm[ss[.sss]])]?[Z|[+-]hh[:]mm]]
 */
public class ISO8601UtilsAgentTest extends TestCase {

    private TimeZone originalDefault;

    protected void setUp() throws Exception {
        super.setUp();
        originalDefault = TimeZone.getDefault();
        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
    }

    protected void tearDown() throws Exception {
        TimeZone.setDefault(originalDefault);
        super.tearDown();
    }

    // ---- helpers ----

    private static Date makeUtcDate(int year, int month, int day, int hour, int minute, int second, int millis) {
        Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        cal.clear();
        cal.set(year, month - 1, day, hour, minute, second);
        cal.set(Calendar.MILLISECOND, millis);
        return cal.getTime();
    }

    private static String pad2(int v) {
        return v < 10 ? "0" + v : String.valueOf(v);
    }

    private static String pad3(int v) {
        if (v < 10) return "00" + v;
        if (v < 100) return "0" + v;
        return String.valueOf(v);
    }

    private static String pad4(int v) {
        String s = String.valueOf(v);
        while (s.length() < 4) {
            s = "0" + s;
        }
        return s;
    }

    /**
     * Builds the expected formatted string for a given date/timezone/millis combination,
     * using the pattern documented on the class and on the 3-arg format method:
     * yyyy-MM-ddThh:mm:ss[.sss][Z|[+-]hh:mm], where tz=UTC (offset 0) yields 'Z'.
     */
    private static String expectedFormatted(Date date, TimeZone tz, boolean millis) {
        Calendar cal = Calendar.getInstance(tz);
        cal.setTime(date);
        StringBuilder sb = new StringBuilder();
        sb.append(pad4(cal.get(Calendar.YEAR))).append('-')
          .append(pad2(cal.get(Calendar.MONTH) + 1)).append('-')
          .append(pad2(cal.get(Calendar.DAY_OF_MONTH)))
          .append('T')
          .append(pad2(cal.get(Calendar.HOUR_OF_DAY))).append(':')
          .append(pad2(cal.get(Calendar.MINUTE))).append(':')
          .append(pad2(cal.get(Calendar.SECOND)));
        if (millis) {
            sb.append('.').append(pad3(cal.get(Calendar.MILLISECOND)));
        }
        int offsetMillis = tz.getOffset(date.getTime());
        if (offsetMillis == 0) {
            sb.append('Z');
        } else {
            int totalMinutes = offsetMillis / 60000;
            char sign = totalMinutes < 0 ? '-' : '+';
            int abs = Math.abs(totalMinutes);
            sb.append(sign).append(pad2(abs / 60)).append(':').append(pad2(abs % 60));
        }
        return sb.toString();
    }

    // ---- format(Date) ----

    public void testFormatDate_defaultTimezoneIsUtc_noMillis() {
        Date date = makeUtcDate(2015, 6, 21, 12, 34, 56, 789);
        String result = ISO8601Utils.format(date);
        assertEquals("2015-06-21T12:34:56Z", result);
    }

    public void testFormatDate_matchesThreeArgFormatWithDefaultTimezone() {
        Date date = makeUtcDate(1999, 1, 2, 3, 4, 5, 0);
        String result = ISO8601Utils.format(date);
        assertEquals(expectedFormatted(date, TimeZone.getDefault(), false), result);
    }

    // ---- format(Date, boolean) ----

    public void testFormatDateMillis_usesGmt_includesMillis() {
        TimeZone.setDefault(TimeZone.getTimeZone("America/New_York"));
        Date date = makeUtcDate(2015, 6, 21, 12, 34, 56, 789);
        String result = ISO8601Utils.format(date, true);
        assertEquals("2015-06-21T12:34:56.789Z", result);
    }

    public void testFormatDateMillisFalse_usesGmt_noMillisFraction() {
        TimeZone.setDefault(TimeZone.getTimeZone("America/New_York"));
        Date date = makeUtcDate(2015, 6, 21, 12, 34, 56, 789);
        String result = ISO8601Utils.format(date, false);
        assertEquals("2015-06-21T12:34:56Z", result);
    }

    public void testFormatDateMillis_zeroMillis() {
        Date date = makeUtcDate(2000, 12, 31, 23, 59, 59, 0);
        String result = ISO8601Utils.format(date, true);
        assertEquals("2000-12-31T23:59:59.000Z", result);
    }

    // ---- format(Date, boolean, TimeZone) ----

    public void testFormatDateMillisTz_utcProducesZ() {
        Date date = makeUtcDate(2015, 6, 21, 12, 34, 56, 789);
        String result = ISO8601Utils.format(date, true, TimeZone.getTimeZone("UTC"));
        assertEquals("2015-06-21T12:34:56.789Z", result);
    }

    public void testFormatDateMillisTz_positiveOffsetNoDst() {
        Date date = makeUtcDate(2015, 6, 21, 12, 34, 56, 0);
        TimeZone tz = TimeZone.getTimeZone("GMT+02:00");
        String result = ISO8601Utils.format(date, false, tz);
        assertEquals(expectedFormatted(date, tz, false), result);
        assertEquals("2015-06-21T14:34:56+02:00", result);
    }

    public void testFormatDateMillisTz_negativeOffsetWithMinutes() {
        Date date = makeUtcDate(2015, 6, 21, 12, 34, 56, 0);
        TimeZone tz = TimeZone.getTimeZone("GMT-05:30");
        String result = ISO8601Utils.format(date, false, tz);
        assertEquals(expectedFormatted(date, tz, false), result);
        assertEquals("2015-06-21T07:04:56-05:30", result);
    }

    public void testFormatDateMillisTz_offsetWithMillis() {
        Date date = makeUtcDate(2015, 6, 21, 12, 34, 56, 123);
        TimeZone tz = TimeZone.getTimeZone("GMT+05:30");
        String result = ISO8601Utils.format(date, true, tz);
        assertEquals("2015-06-21T18:04:56.123+05:30", result);
    }

    public void testFormatDateMillisTz_epoch() {
        Date date = makeUtcDate(1970, 1, 1, 0, 0, 0, 0);
        String result = ISO8601Utils.format(date, false, TimeZone.getTimeZone("UTC"));
        assertEquals("1970-01-01T00:00:00Z", result);
    }

    // ---- parse(String, ParsePosition) : full date/time/zone ----

    public void testParse_fullDateTimeMillisZ() throws ParseException {
        String input = "2015-06-21T12:34:56.789Z";
        ParsePosition pos = new ParsePosition(0);
        Date result = ISO8601Utils.parse(input, pos);
        assertEquals(makeUtcDate(2015, 6, 21, 12, 34, 56, 789), result);
        assertEquals(input.length(), pos.getIndex());
    }

    public void testParse_dateTimeNoMillisZ() throws ParseException {
        String input = "2015-06-21T12:34:56Z";
        ParsePosition pos = new ParsePosition(0);
        Date result = ISO8601Utils.parse(input, pos);
        assertEquals(makeUtcDate(2015, 6, 21, 12, 34, 56, 0), result);
        assertEquals(input.length(), pos.getIndex());
    }

    public void testParse_dateOnly_defaultsToMidnight() throws ParseException {
        String input = "2015-06-21";
        ParsePosition pos = new ParsePosition(0);
        Date result = ISO8601Utils.parse(input, pos);
        assertEquals(makeUtcDate(2015, 6, 21, 0, 0, 0, 0), result);
        assertEquals(10, pos.getIndex());
    }

    public void testParse_compactDateOnly() throws ParseException {
        String input = "20150621";
        ParsePosition pos = new ParsePosition(0);
        Date result = ISO8601Utils.parse(input, pos);
        assertEquals(makeUtcDate(2015, 6, 21, 0, 0, 0, 0), result);
        assertEquals(8, pos.getIndex());
    }

    public void pruned_testParse_dateTimeHoursMinutesOnly() throws ParseException {
        String input = "2015-06-21T12:34";
        ParsePosition pos = new ParsePosition(0);
        Date result = ISO8601Utils.parse(input, pos);
        assertEquals(makeUtcDate(2015, 6, 21, 12, 34, 0, 0), result);
        assertEquals(input.length(), pos.getIndex());
    }

    public void pruned_testParse_compactTimeHoursMinutes() throws ParseException {
        String input = "2015-06-21T1234";
        ParsePosition pos = new ParsePosition(0);
        Date result = ISO8601Utils.parse(input, pos);
        assertEquals(makeUtcDate(2015, 6, 21, 12, 34, 0, 0), result);
        assertEquals(input.length(), pos.getIndex());
    }

    public void pruned_testParse_compactTimeWithSeconds() throws ParseException {
        String input = "2015-06-21T123456";
        ParsePosition pos = new ParsePosition(0);
        Date result = ISO8601Utils.parse(input, pos);
        assertEquals(makeUtcDate(2015, 6, 21, 12, 34, 56, 0), result);
        assertEquals(input.length(), pos.getIndex());
    }

    public void testParse_compactTimeWithMillisAndZ() throws ParseException {
        String input = "2015-06-21T123456.789Z";
        ParsePosition pos = new ParsePosition(0);
        Date result = ISO8601Utils.parse(input, pos);
        assertEquals(makeUtcDate(2015, 6, 21, 12, 34, 56, 789), result);
        assertEquals(input.length(), pos.getIndex());
    }

    public void testParse_positiveOffsetWithColon() throws ParseException {
        String input = "2015-06-21T12:34:56+02:00";
        ParsePosition pos = new ParsePosition(0);
        Date result = ISO8601Utils.parse(input, pos);
        assertEquals(makeUtcDate(2015, 6, 21, 10, 34, 56, 0), result);
        assertEquals(input.length(), pos.getIndex());
    }

    public void testParse_negativeOffsetWithoutColon() throws ParseException {
        String input = "2015-06-21T12:34:56-0500";
        ParsePosition pos = new ParsePosition(0);
        Date result = ISO8601Utils.parse(input, pos);
        assertEquals(makeUtcDate(2015, 6, 21, 17, 34, 56, 0), result);
        assertEquals(input.length(), pos.getIndex());
    }

    public void testParse_startsAtGivenPosition() throws ParseException {
        String input = "XXXX2015-06-21T12:34:56Z";
        ParsePosition pos = new ParsePosition(4);
        Date result = ISO8601Utils.parse(input, pos);
        assertEquals(makeUtcDate(2015, 6, 21, 12, 34, 56, 0), result);
        assertEquals(input.length(), pos.getIndex());
    }

    public void testParse_stopsAtEndOfRecognizedPortion() throws ParseException {
        String input = "2015-06-21T12:34:56Zgarbage";
        ParsePosition pos = new ParsePosition(0);
        Date result = ISO8601Utils.parse(input, pos);
        assertEquals(makeUtcDate(2015, 6, 21, 12, 34, 56, 0), result);
        assertEquals(20, pos.getIndex());
    }

    public void testParse_roundTripWithFormat() throws ParseException {
        Date original = makeUtcDate(2023, 11, 5, 8, 9, 10, 0);
        String formatted = ISO8601Utils.format(original, false, TimeZone.getTimeZone("UTC"));
        ParsePosition pos = new ParsePosition(0);
        Date parsed = ISO8601Utils.parse(formatted, pos);
        assertEquals(original, parsed);
    }

    // ---- parse error cases ----

    public void testParse_emptyStringThrows() {
        ParsePosition pos = new ParsePosition(0);
        try {
            ISO8601Utils.parse("", pos);
            fail("Expected ParseException for empty input");
        } catch (ParseException expected) {
            // documented: throws ParseException if the date is not in the appropriate format
        }
    }

    public void testParse_nonDateTextThrows() {
        ParsePosition pos = new ParsePosition(0);
        try {
            ISO8601Utils.parse("not-a-date", pos);
            fail("Expected ParseException for non-date input");
        } catch (ParseException expected) {
            // expected
        }
    }

    public void testParse_incompleteDateThrows() {
        ParsePosition pos = new ParsePosition(0);
        try {
            ISO8601Utils.parse("2015-06", pos);
            fail("Expected ParseException for incomplete date (missing day)");
        } catch (ParseException expected) {
            // expected
        }
    }

    public void testParse_yearOnlyThrows() {
        ParsePosition pos = new ParsePosition(0);
        try {
            ISO8601Utils.parse("2015", pos);
            fail("Expected ParseException for year-only input");
        } catch (ParseException expected) {
            // expected
        }
    }

    public void testParse_wrongSeparatorThrows() {
        ParsePosition pos = new ParsePosition(0);
        try {
            ISO8601Utils.parse("2015/06/21", pos);
            fail("Expected ParseException for '/' separated date");
        } catch (ParseException expected) {
            // expected
        }
    }
}
