package org.apache.commons.csv;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import junit.framework.TestCase;

/**
 * Self-contained JUnit 3.8 tests for {@link CSVPrinter}, based strictly on
 * the documented contract in the project's generated javadoc.
 */
public class CSVPrinterAgentTest extends TestCase {

    /** A Writer that records whether flush()/close() were delegated to it. */
    private static final class TrackingWriter extends Writer {
        private final StringBuilder buffer = new StringBuilder();
        private boolean flushed = false;
        private boolean closed = false;

        public void write(char[] cbuf, int off, int len) throws IOException {
            buffer.append(cbuf, off, len);
        }

        public void flush() throws IOException {
            flushed = true;
        }

        public void close() throws IOException {
            closed = true;
        }

        public String toString() {
            return buffer.toString();
        }
    }

    private static Object defaultValueFor(Class<?> type) {
        if (type == boolean.class) {
            return Boolean.FALSE;
        }
        if (type == int.class) {
            return Integer.valueOf(0);
        }
        if (type == long.class) {
            return Long.valueOf(0L);
        }
        if (type == double.class) {
            return Double.valueOf(0d);
        }
        if (type == float.class) {
            return Float.valueOf(0f);
        }
        if (type == short.class) {
            return Short.valueOf((short) 0);
        }
        if (type == byte.class) {
            return Byte.valueOf((byte) 0);
        }
        if (type == char.class) {
            return Character.valueOf('\0');
        }
        return null;
    }

    /**
     * Builds a minimal fake ResultSet backed by the given row data, using a
     * dynamic proxy so that no library-specific JDBC driver is required.
     */
    private static ResultSet fakeResultSet(final Object[][] rows) {
        final int columnCount = rows.length == 0 ? 0 : rows[0].length;

        final ResultSetMetaData metaData = (ResultSetMetaData) Proxy.newProxyInstance(
                CSVPrinterAgentTest.class.getClassLoader(),
                new Class[] { ResultSetMetaData.class },
                new InvocationHandler() {
                    public Object invoke(Object proxy, Method method, Object[] args) {
                        if ("getColumnCount".equals(method.getName())) {
                            return Integer.valueOf(columnCount);
                        }
                        return defaultValueFor(method.getReturnType());
                    }
                });

        final int[] rowIndex = new int[] { -1 };

        return (ResultSet) Proxy.newProxyInstance(
                CSVPrinterAgentTest.class.getClassLoader(),
                new Class[] { ResultSet.class },
                new InvocationHandler() {
                    public Object invoke(Object proxy, Method method, Object[] args) {
                        String name = method.getName();
                        if ("next".equals(name)) {
                            rowIndex[0]++;
                            return Boolean.valueOf(rowIndex[0] < rows.length);
                        }
                        if ("getMetaData".equals(name)) {
                            return metaData;
                        }
                        if (("getObject".equals(name) || "getString".equals(name))
                                && args != null && args.length == 1 && args[0] instanceof Integer) {
                            int col = ((Integer) args[0]).intValue();
                            if (rowIndex[0] >= 0 && rowIndex[0] < rows.length
                                    && col >= 1 && col <= rows[rowIndex[0]].length) {
                                return rows[rowIndex[0]][col - 1];
                            }
                            return null;
                        }
                        if ("close".equals(name)) {
                            return null;
                        }
                        return defaultValueFor(method.getReturnType());
                    }
                });
    }

    // -- constructor contract -------------------------------------------------

    public void testConstructorThrowsOnNullOutput() throws IOException {
        try {
            new CSVPrinter(null, CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException for null out");
        } catch (IllegalArgumentException expected) {
            // documented: thrown if either out or format are null
        }
    }

    public void testConstructorThrowsOnNullFormat() throws IOException {
        try {
            new CSVPrinter(new StringWriter(), null);
            fail("Expected IllegalArgumentException for null format");
        } catch (IllegalArgumentException expected) {
            // documented: thrown if either out or format are null
        }
    }

    public void testGetOutReturnsSameInstancePassedToConstructor() throws IOException {
        StringWriter sw = new StringWriter();
        CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT.withRecordSeparator("\n"));
        assertSame(sw, printer.getOut());
    }

    // -- print(Object) ----------------------------------------------------------

    public void testPrintSimpleValue() throws IOException {
        StringWriter sw = new StringWriter();
        CSVFormat format = CSVFormat.DEFAULT.withDelimiter(',').withQuoteChar('"').withRecordSeparator("\n");
        CSVPrinter printer = new CSVPrinter(sw, format);
        printer.print("value");
        printer.flush();
        assertEquals("value", sw.toString());
    }

    public void testPrintValueContainingDelimiterIsQuoted() throws IOException {
        StringWriter sw = new StringWriter();
        CSVFormat format = CSVFormat.DEFAULT.withDelimiter(',').withQuoteChar('"').withRecordSeparator("\n");
        CSVPrinter printer = new CSVPrinter(sw, format);
        printer.print("a,b");
        printer.flush();
        assertEquals("\"a,b\"", sw.toString());
    }

    public void testPrintValueContainingQuoteCharIsEscaped() throws IOException {
        StringWriter sw = new StringWriter();
        CSVFormat format = CSVFormat.DEFAULT.withDelimiter(',').withQuoteChar('"').withRecordSeparator("\n");
        CSVPrinter printer = new CSVPrinter(sw, format);
        printer.print("a\"b");
        printer.flush();
        assertEquals("\"a\"\"b\"", sw.toString());
    }

    public void pruned_testPrintNullValuePrintsEmptyField() throws IOException {
        StringWriter sw = new StringWriter();
        CSVFormat format = CSVFormat.DEFAULT.withDelimiter(',').withQuoteChar('"').withRecordSeparator("\n");
        CSVPrinter printer = new CSVPrinter(sw, format);
        printer.print(null);
        printer.flush();
        assertEquals("", sw.toString());
    }

    public void testSecondPrintOnSameLineIsDelimited() throws IOException {
        StringWriter sw = new StringWriter();
        CSVFormat format = CSVFormat.DEFAULT.withDelimiter(',').withQuoteChar('"').withRecordSeparator("\n");
        CSVPrinter printer = new CSVPrinter(sw, format);
        printer.print("a");
        printer.print("b");
        printer.flush();
        assertEquals("a,b", sw.toString());
    }

    // -- println() ---------------------------------------------------------------

    public void testPrintlnOutputsOnlyRecordSeparatorWhenLineEmpty() throws IOException {
        StringWriter sw = new StringWriter();
        CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("\n");
        CSVPrinter printer = new CSVPrinter(sw, format);
        printer.println();
        printer.flush();
        assertEquals("\n", sw.toString());
    }

    public void testPrintlnResetsLineSoNextPrintIsNotDelimited() throws IOException {
        StringWriter sw = new StringWriter();
        CSVFormat format = CSVFormat.DEFAULT.withDelimiter(',').withRecordSeparator("\n");
        CSVPrinter printer = new CSVPrinter(sw, format);
        printer.print("a");
        printer.println();
        printer.print("b");
        printer.flush();
        assertEquals("a\nb", sw.toString());
    }

    // -- printRecord ---------------------------------------------------------------

    public void testPrintRecordVarargs() throws IOException {
        StringWriter sw = new StringWriter();
        CSVFormat format = CSVFormat.DEFAULT.withDelimiter(',').withRecordSeparator("\n");
        CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printRecord("a", "b", "c");
        printer.flush();
        assertEquals("a,b,c\n", sw.toString());
    }

    public void testPrintRecordWithNoValuesStillTerminatesLine() throws IOException {
        StringWriter sw = new StringWriter();
        CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("\n");
        CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printRecord(new Object[0]);
        printer.flush();
        assertEquals("\n", sw.toString());
    }

    public void testPrintRecordIterable() throws IOException {
        StringWriter sw = new StringWriter();
        CSVFormat format = CSVFormat.DEFAULT.withDelimiter(',').withRecordSeparator("\n");
        CSVPrinter printer = new CSVPrinter(sw, format);
        List<String> values = new ArrayList<String>();
        values.add("x");
        values.add("y");
        printer.printRecord(values);
        printer.flush();
        assertEquals("x,y\n", sw.toString());
    }

    // -- printRecords ---------------------------------------------------------------

    public void testPrintRecordsIterableOfRecords() throws IOException {
        StringWriter sw = new StringWriter();
        CSVFormat format = CSVFormat.DEFAULT.withDelimiter(',').withRecordSeparator("\n");
        CSVPrinter printer = new CSVPrinter(sw, format);
        List<List<String>> records = new ArrayList<List<String>>();
        records.add(Arrays.asList("a", "b"));
        records.add(Arrays.asList("c", "d"));
        printer.printRecords(records);
        printer.flush();
        assertEquals("a,b\nc,d\n", sw.toString());
    }

    public void testPrintRecordsObjectArrayOfRecords() throws IOException {
        StringWriter sw = new StringWriter();
        CSVFormat format = CSVFormat.DEFAULT.withDelimiter(',').withRecordSeparator("\n");
        CSVPrinter printer = new CSVPrinter(sw, format);
        Object[] records = new Object[] { new String[] { "a", "b" }, new String[] { "c", "d" } };
        printer.printRecords(records);
        printer.flush();
        assertEquals("a,b\nc,d\n", sw.toString());
    }

    public void testPrintRecordsWithEmptyIterableProducesNoOutput() throws IOException {
        StringWriter sw = new StringWriter();
        CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("\n");
        CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printRecords(new ArrayList<Object>());
        printer.flush();
        assertEquals("", sw.toString());
    }

    public void testPrintRecordsResultSet() throws Exception {
        Object[][] rows = new Object[][] { { "1", "foo" }, { "2", "bar" } };
        ResultSet resultSet = fakeResultSet(rows);
        StringWriter sw = new StringWriter();
        CSVFormat format = CSVFormat.DEFAULT.withDelimiter(',').withRecordSeparator("\n");
        CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printRecords(resultSet);
        printer.flush();
        assertEquals("1,foo\n2,bar\n", sw.toString());
    }

    public void testPrintRecordsResultSetWithNoRowsProducesNoOutput() throws Exception {
        Object[][] rows = new Object[0][0];
        ResultSet resultSet = fakeResultSet(rows);
        StringWriter sw = new StringWriter();
        CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("\n");
        CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printRecords(resultSet);
        printer.flush();
        assertEquals("", sw.toString());
    }

    // -- printComment ---------------------------------------------------------------

    public void testPrintCommentDoesNothingWhenCommentsDisabled() throws IOException {
        StringWriter sw = new StringWriter();
        CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("\n");
        CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printComment("a comment");
        printer.flush();
        assertEquals("", sw.toString());
    }

    public void testPrintCommentWritesMarkerAndSpace() throws IOException {
        StringWriter sw = new StringWriter();
        CSVFormat format = CSVFormat.DEFAULT.withCommentStart('#').withRecordSeparator("\n");
        CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printComment("hello");
        printer.flush();
        assertEquals("# hello\n", sw.toString());
    }

    public void testPrintCommentHandlesMultipleLines() throws IOException {
        StringWriter sw = new StringWriter();
        CSVFormat format = CSVFormat.DEFAULT.withCommentStart('#').withRecordSeparator("\n");
        CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printComment("line1\nline2");
        printer.flush();
        assertEquals("# line1\n# line2\n", sw.toString());
    }

    // -- header printed on construction ---------------------------------------------

    public void testHeaderIsPrintedDuringConstruction() throws IOException {
        StringWriter sw = new StringWriter();
        CSVFormat format = CSVFormat.DEFAULT.withHeader("A", "B").withDelimiter(',').withRecordSeparator("\n");
        new CSVPrinter(sw, format);
        assertEquals("A,B\n", sw.toString());
    }

    // -- flush/close delegation -------------------------------------------------------

    public void testFlushDelegatesToUnderlyingFlushable() throws IOException {
        TrackingWriter writer = new TrackingWriter();
        CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT.withRecordSeparator("\n"));
        assertFalse(writer.flushed);
        printer.flush();
        assertTrue(writer.flushed);
    }

    public void testCloseDelegatesToUnderlyingCloseable() throws IOException {
        TrackingWriter writer = new TrackingWriter();
        CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT.withRecordSeparator("\n"));
        assertFalse(writer.closed);
        printer.close();
        assertTrue(writer.closed);
    }
}
