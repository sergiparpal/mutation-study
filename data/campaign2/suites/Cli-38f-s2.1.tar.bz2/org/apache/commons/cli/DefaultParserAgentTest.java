package org.apache.commons.cli;

import java.util.Properties;

import junit.framework.TestCase;

/**
 * Self-contained tests for {@link DefaultParser}, based solely on the
 * documented contract of the class (see api/org/apache/commons/cli/DefaultParser.html).
 */
public class DefaultParserAgentTest extends TestCase {

    // -----------------------------------------------------------------
    // Fresh instance / field state
    // -----------------------------------------------------------------

    public void testFreshInstanceHasNoState() {
        DefaultParser parser = new DefaultParser();
        // Protected fields are visible from this package; a freshly
        // constructed parser has not parsed anything yet.
        assertNull(parser.cmd);
        assertNull(parser.options);
        assertNull(parser.currentOption);
        assertNull(parser.currentToken);
        assertNull(parser.expectedOpts);
        assertFalse(parser.skipParsing);
        assertFalse(parser.stopAtNonOption);
    }

    // -----------------------------------------------------------------
    // Basic short/long option parsing
    // -----------------------------------------------------------------

    public void testParseShortOptionWithoutArgument() throws ParseException {
        Options options = new Options().addOption("a", false, "a flag");
        DefaultParser parser = new DefaultParser();

        CommandLine cmd = parser.parse(options, new String[] {"-a"});

        assertNotNull(cmd);
        assertTrue(cmd.hasOption("a"));
        assertEquals(0, cmd.getArgs().length);
    }

    public void testParseShortOptionWithArgument() throws ParseException {
        Options options = new Options().addOption("b", true, "b with value");
        DefaultParser parser = new DefaultParser();

        CommandLine cmd = parser.parse(options, new String[] {"-b", "value"});

        assertTrue(cmd.hasOption("b"));
        assertEquals("value", cmd.getOptionValue("b"));
    }

    public void testParseLongOptionWithEqualsSign() throws ParseException {
        Options options = new Options().addOption("f", "file", true, "file path");
        DefaultParser parser = new DefaultParser();

        CommandLine cmd = parser.parse(options, new String[] {"--file=test.txt"});

        assertTrue(cmd.hasOption("f"));
        assertTrue(cmd.hasOption("file"));
        assertEquals("test.txt", cmd.getOptionValue("f"));
    }

    public void testParseMultipleValuesForOption() throws ParseException {
        Option opt = new Option("b", true, "takes two values");
        opt.setArgs(2);
        Options options = new Options().addOption(opt);
        DefaultParser parser = new DefaultParser();

        CommandLine cmd = parser.parse(options, new String[] {"-b", "x", "y"});

        String[] values = cmd.getOptionValues("b");
        assertNotNull(values);
        assertEquals(2, values.length);
        assertEquals("x", values[0]);
        assertEquals("y", values[1]);
    }

    public void testParsePlainArgumentsAreCollected() throws ParseException {
        Options options = new Options();
        DefaultParser parser = new DefaultParser();

        CommandLine cmd = parser.parse(options, new String[] {"foo", "bar"});

        String[] args = cmd.getArgs();
        assertEquals(2, args.length);
        assertEquals("foo", args[0]);
        assertEquals("bar", args[1]);
    }

    public void testParseEmptyArgumentsReturnsEmptyCommandLine() throws ParseException {
        Options options = new Options();
        DefaultParser parser = new DefaultParser();

        CommandLine cmd = parser.parse(options, new String[0]);

        assertNotNull(cmd);
        assertEquals(0, cmd.getArgs().length);
        assertEquals(0, cmd.getOptions().length);
    }

    // -----------------------------------------------------------------
    // Error cases
    // -----------------------------------------------------------------

    public void testParseMissingRequiredOptionThrows() {
        Option required = new Option("r", "a required option");
        required.setRequired(true);
        Options options = new Options().addOption(required);
        DefaultParser parser = new DefaultParser();

        try {
            parser.parse(options, new String[0]);
            fail("Expected a ParseException for a missing required option");
        } catch (ParseException expected) {
            // documented: "if there are any problems encountered while parsing"
        }
    }

    public void testParseMissingArgumentValueThrows() {
        Options options = new Options().addOption("v", true, "needs a value");
        DefaultParser parser = new DefaultParser();

        try {
            parser.parse(options, new String[] {"-v"});
            fail("Expected a ParseException: -v requires a value that was not supplied");
        } catch (ParseException expected) {
            // expected
        }
    }

    public void testParseUnrecognizedOptionThrowsByDefault() {
        Options options = new Options();
        DefaultParser parser = new DefaultParser();

        try {
            parser.parse(options, new String[] {"-x"});
            fail("Expected a ParseException for an unrecognized option");
        } catch (ParseException expected) {
            // expected
        }
    }

    // -----------------------------------------------------------------
    // stopAtNonOption
    // -----------------------------------------------------------------

    public void testParseStopAtNonOptionTrueCollectsRemainingArgs() throws ParseException {
        Options options = new Options().addOption("a", false, "flag a");
        DefaultParser parser = new DefaultParser();

        CommandLine cmd = parser.parse(options, new String[] {"-a", "-x", "extra"}, true);

        assertTrue(cmd.hasOption("a"));
        String[] args = cmd.getArgs();
        assertEquals(2, args.length);
        assertEquals("-x", args[0]);
        assertEquals("extra", args[1]);
    }

    public void testParseStopAtNonOptionFalseStillThrows() {
        Options options = new Options().addOption("a", false, "flag a");
        DefaultParser parser = new DefaultParser();

        try {
            parser.parse(options, new String[] {"-a", "-x"}, false);
            fail("Expected a ParseException: stopAtNonOption is false so -x triggers an error");
        } catch (ParseException expected) {
            // expected
        }
    }

    // -----------------------------------------------------------------
    // handleConcatenatedOptions, exercised through parse()
    // -----------------------------------------------------------------

    public void testConcatenatedShortFlagsAreBurstApart() throws ParseException {
        Options options = new Options();
        options.addOption("a", false, "flag a");
        options.addOption("b", false, "flag b");
        DefaultParser parser = new DefaultParser();

        CommandLine cmd = parser.parse(options, new String[] {"-ab"});

        assertTrue(cmd.hasOption("a"));
        assertTrue(cmd.hasOption("b"));
    }

    public void testConcatenatedShortFlagWithTrailingValue() throws ParseException {
        Options options = new Options();
        options.addOption("a", false, "flag a");
        options.addOption("b", true, "flag b with value");
        DefaultParser parser = new DefaultParser();

        CommandLine cmd = parser.parse(options, new String[] {"-abvalue"});

        assertTrue(cmd.hasOption("a"));
        assertEquals("value", cmd.getOptionValue("b"));
    }

    public void testConcatenatedUnknownCharacterThrowsByDefault() {
        Options options = new Options().addOption("a", false, "flag a");
        DefaultParser parser = new DefaultParser();

        try {
            parser.parse(options, new String[] {"-az"});
            fail("Expected a ParseException: 'z' is not a known option");
        } catch (ParseException expected) {
            // expected
        }
    }

    // -----------------------------------------------------------------
    // Properties-based defaults
    // -----------------------------------------------------------------

    public void testParseWithPropertiesSuppliesDefaultValue() throws ParseException {
        Options options = new Options().addOption("p", true, "a property-backed option");
        Properties properties = new Properties();
        properties.setProperty("p", "fromProperties");
        DefaultParser parser = new DefaultParser();

        CommandLine cmd = parser.parse(options, new String[0], properties);

        assertTrue(cmd.hasOption("p"));
        assertEquals("fromProperties", cmd.getOptionValue("p"));
    }

    public void testParseArgumentsTakePrecedenceOverProperties() throws ParseException {
        Options options = new Options().addOption("p", true, "a property-backed option");
        Properties properties = new Properties();
        properties.setProperty("p", "fromProperties");
        DefaultParser parser = new DefaultParser();

        CommandLine cmd = parser.parse(options, new String[] {"-p", "fromArgs"}, properties);

        assertEquals("fromArgs", cmd.getOptionValue("p"));
    }

    public void testParseWithPropertiesAndStopAtNonOption() throws ParseException {
        Options options = new Options().addOption("a", false, "flag a");
        DefaultParser parser = new DefaultParser();

        CommandLine cmd = parser.parse(options, new String[] {"-x"}, new Properties(), true);

        assertFalse(cmd.hasOption("a"));
        String[] args = cmd.getArgs();
        assertEquals(1, args.length);
        assertEquals("-x", args[0]);
    }

    // -----------------------------------------------------------------
    // Reuse of a single parser instance
    // -----------------------------------------------------------------

    public void testParserInstanceCanBeReusedAcrossParses() throws ParseException {
        DefaultParser parser = new DefaultParser();

        Options firstOptions = new Options().addOption("a", false, "flag a");
        CommandLine first = parser.parse(firstOptions, new String[] {"-a"});
        assertTrue(first.hasOption("a"));

        Options secondOptions = new Options().addOption("c", true, "flag c with value");
        CommandLine second = parser.parse(secondOptions, new String[] {"-c", "val"});
        assertFalse(second.hasOption("a"));
        assertEquals("val", second.getOptionValue("c"));
    }
}
