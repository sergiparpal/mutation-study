/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.cli;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.ListIterator;
import java.util.Properties;

import junit.framework.TestCase;

/**
 * Self-contained tests for {@link Parser}, exercised through the
 * production {@link BasicParser} subclass, whose {@code flatten}
 * implementation simply echoes the raw arguments back.
 */
public class ParserAgentTest extends TestCase
{

    public ParserAgentTest(String name)
    {
        super(name);
    }

    private Options buildOptions()
    {
        Options options = new Options();
        options.addOption("a", "enable-a", false, "turn [a] on or off");
        options.addOption("b", "bfile", true, "set the value of [b]");
        options.addOption("c", "copt", false, "turn [c] on or off");
        return options;
    }

    public void testParseSimpleFlagOption() throws Exception
    {
        Parser parser = new BasicParser();
        CommandLine cmd = parser.parse(buildOptions(), new String[] {"-a"});

        assertTrue(cmd.hasOption("a"));
        assertFalse(cmd.hasOption("b"));
        assertEquals(0, cmd.getArgs().length);
    }

    public void testParseOptionWithArgument() throws Exception
    {
        Parser parser = new BasicParser();
        CommandLine cmd = parser.parse(buildOptions(),
                                       new String[] {"-b", "foo"});

        assertTrue(cmd.hasOption("b"));
        assertEquals("foo", cmd.getOptionValue("b"));
    }

    public void testParseMissingArgumentThrows() throws Exception
    {
        Parser parser = new BasicParser();
        try
        {
            parser.parse(buildOptions(), new String[] {"-b"});
            fail("expected MissingArgumentException");
        }
        catch (MissingArgumentException expected)
        {
            assertTrue(expected.getMessage().indexOf("b") >= 0);
        }
    }

    public void testParseUnrecognizedOptionThrows() throws Exception
    {
        Parser parser = new BasicParser();
        try
        {
            parser.parse(buildOptions(), new String[] {"-z"});
            fail("expected UnrecognizedOptionException");
        }
        catch (UnrecognizedOptionException expected)
        {
            assertTrue(expected.getMessage().indexOf("-z") >= 0);
        }
    }

    public void testParseMissingRequiredOptionThrows() throws Exception
    {
        Options options = new Options();
        options.addOption("a", "enable-a", false, "turn [a] on or off");
        Option required = new Option("b", "bfile", true, "set the value of [b]");
        required.setRequired(true);
        options.addOption(required);

        Parser parser = new BasicParser();
        try
        {
            parser.parse(options, new String[] {"-a"});
            fail("expected MissingOptionException");
        }
        catch (MissingOptionException expected)
        {
            assertTrue(expected.getMessage().indexOf("b") >= 0);
        }
    }

    public void testParseRequiredOptionPresentSucceeds() throws Exception
    {
        Options options = new Options();
        Option required = new Option("b", "bfile", true, "set the value of [b]");
        required.setRequired(true);
        options.addOption(required);

        Parser parser = new BasicParser();
        CommandLine cmd = parser.parse(options, new String[] {"-b", "val"});

        assertTrue(cmd.hasOption("b"));
        assertEquals("val", cmd.getOptionValue("b"));
    }

    public void testParseNullArgumentsTreatedAsEmpty() throws Exception
    {
        Parser parser = new BasicParser();
        CommandLine cmd = parser.parse(buildOptions(), null);

        assertEquals(0, cmd.getArgs().length);
        assertFalse(cmd.hasOption("a"));
    }

    public void testParseDoubleDashStopsOptionProcessing() throws Exception
    {
        Parser parser = new BasicParser();
        CommandLine cmd = parser.parse(buildOptions(),
                                       new String[] {"-a", "--", "-b", "arg"});

        assertTrue(cmd.hasOption("a"));
        assertFalse(cmd.hasOption("b"));
        assertEquals(2, cmd.getArgs().length);
        assertEquals("-b", cmd.getArgs()[0]);
        assertEquals("arg", cmd.getArgs()[1]);
    }

    public void testParseSingleDashIsTreatedAsArgument() throws Exception
    {
        Parser parser = new BasicParser();
        CommandLine cmd = parser.parse(buildOptions(),
                                       new String[] {"-a", "-"});

        assertTrue(cmd.hasOption("a"));
        assertEquals(1, cmd.getArgs().length);
        assertEquals("-", cmd.getArgs()[0]);
    }

    public void testParseStopAtNonOptionEatsRemainingTokens() throws Exception
    {
        Parser parser = new BasicParser();
        CommandLine cmd = parser.parse(buildOptions(),
                                       new String[] {"-a", "non-option", "-b"},
                                       true);

        assertTrue(cmd.hasOption("a"));
        assertFalse(cmd.hasOption("b"));
        assertEquals(2, cmd.getArgs().length);
        assertEquals("non-option", cmd.getArgs()[0]);
        assertEquals("-b", cmd.getArgs()[1]);
    }

    public void testParseUnknownOptionStopAtNonOptionAddedAsArg() throws Exception
    {
        Parser parser = new BasicParser();
        CommandLine cmd = parser.parse(buildOptions(),
                                       new String[] {"-z", "rest"}, true);

        assertEquals(2, cmd.getArgs().length);
        assertEquals("-z", cmd.getArgs()[0]);
        assertEquals("rest", cmd.getArgs()[1]);
    }

    public void testParseOptionGroupSecondSelectionThrows() throws Exception
    {
        Options options = new Options();
        OptionGroup group = new OptionGroup();
        group.addOption(new Option("x", "exclusive x"));
        group.addOption(new Option("y", "exclusive y"));
        options.addOptionGroup(group);

        Parser parser = new BasicParser();
        try
        {
            parser.parse(options, new String[] {"-x", "-y"});
            fail("expected AlreadySelectedException");
        }
        catch (AlreadySelectedException expected)
        {
            assertTrue(expected.getMessage().indexOf("x") >= 0);
        }
    }

    public void testParseRequiredOptionGroupSatisfiedBySelection() throws Exception
    {
        Options options = new Options();
        OptionGroup group = new OptionGroup();
        group.addOption(new Option("x", "exclusive x"));
        group.addOption(new Option("y", "exclusive y"));
        group.setRequired(true);
        options.addOptionGroup(group);

        Parser parser = new BasicParser();
        CommandLine cmd = parser.parse(options, new String[] {"-x"});

        assertTrue(cmd.hasOption("x"));
        assertEquals("x", group.getSelected());
    }

    public void testParseResetsPreviousOptionValuesBetweenCalls() throws Exception
    {
        Options options = buildOptions();
        Parser parser = new BasicParser();

        CommandLine first = parser.parse(options, new String[] {"-b", "first"});
        assertEquals("first", first.getOptionValue("b"));

        // CLI-71: re-parsing with the same Options instance must not leak
        // values accumulated on the Option objects from the previous parse.
        CommandLine second = parser.parse(options, new String[] {"-a"});
        assertFalse(second.hasOption("b"));
        assertNull(options.getOption("b").getValue());
    }

    public void testProcessPropertiesSetsFlagOptionWhenTrue() throws Exception
    {
        Options options = buildOptions();
        Parser parser = new BasicParser();

        Properties properties = new Properties();
        properties.setProperty("a", "true");

        CommandLine cmd = parser.parse(options, new String[0], properties);

        assertTrue(cmd.hasOption("a"));
    }

    public void testProcessPropertiesDoesNotSetFlagOptionWhenFalse() throws Exception
    {
        Options options = buildOptions();
        Parser parser = new BasicParser();

        Properties properties = new Properties();
        properties.setProperty("a", "false");

        CommandLine cmd = parser.parse(options, new String[0], properties);

        assertFalse(cmd.hasOption("a"));
    }

    public void testProcessPropertiesDoesNotOverrideCommandLineValue() throws Exception
    {
        Options options = buildOptions();
        Parser parser = new BasicParser();

        Properties properties = new Properties();
        properties.setProperty("b", "fromProperties");

        CommandLine cmd = parser.parse(options, new String[] {"-b", "fromArgs"},
                                       properties);

        assertEquals("fromArgs", cmd.getOptionValue("b"));
    }

    public void testProcessPropertiesSetsOptionArgument() throws Exception
    {
        Options options = buildOptions();
        Parser parser = new BasicParser();

        Properties properties = new Properties();
        properties.setProperty("b", "propValue");

        CommandLine cmd = parser.parse(options, new String[0], properties);

        assertTrue(cmd.hasOption("b"));
        assertEquals("propValue", cmd.getOptionValue("b"));
    }

    public void testGetOptionsAndRequiredOptionsAfterSetOptions() throws Exception
    {
        Options options = new Options();
        options.addOption("a", "enable-a", false, "turn [a] on or off");
        Option required = new Option("b", "bfile", true, "set the value of [b]");
        required.setRequired(true);
        options.addOption(required);

        // getOptions()/getRequiredOptions()/setOptions() are protected, but
        // this test class lives in the same package so it may call them
        // directly on a concrete Parser instance.
        Parser parser = new BasicParser();
        parser.setOptions(options);

        assertSame(options, parser.getOptions());
        assertEquals(1, parser.getRequiredOptions().size());
        assertEquals("b", parser.getRequiredOptions().get(0));
    }

    public void testCheckRequiredOptionsThrowsWithAllMissingNames() throws Exception
    {
        Options options = new Options();
        Option requiredA = new Option("a", "enable-a", false, "turn [a] on or off");
        requiredA.setRequired(true);
        options.addOption(requiredA);
        Option requiredB = new Option("b", "bfile", true, "set the value of [b]");
        requiredB.setRequired(true);
        options.addOption(requiredB);

        Parser parser = new BasicParser();
        parser.setOptions(options);

        try
        {
            parser.checkRequiredOptions();
            fail("expected MissingOptionException");
        }
        catch (MissingOptionException expected)
        {
            String message = expected.getMessage();
            assertTrue(message.indexOf("a") >= 0);
            assertTrue(message.indexOf("b") >= 0);
            assertFalse(message.endsWith(", "));
        }
    }

    public void testCheckRequiredOptionsPassesWhenNoneRequired() throws Exception
    {
        Options options = buildOptions();
        Parser parser = new BasicParser();
        parser.setOptions(options);

        // must not throw
        parser.checkRequiredOptions();
        assertEquals(0, parser.getRequiredOptions().size());
    }

    public void testProcessArgsCollectsValuesUntilNextOption() throws Exception
    {
        Options options = buildOptions();
        Parser parser = new BasicParser();
        parser.setOptions(options);

        Option opt = options.getOption("b");
        List tokens = Arrays.asList(new String[] {"value1", "-a"});
        ListIterator iterator = tokens.listIterator();

        parser.processArgs(opt, iterator);

        assertEquals("value1", opt.getValue());
        // the trailing option token must not have been consumed
        assertTrue(iterator.hasNext());
        assertEquals("-a", iterator.next());
    }

    public void testProcessArgsThrowsWhenNoValueAvailable() throws Exception
    {
        Options options = buildOptions();
        Parser parser = new BasicParser();
        parser.setOptions(options);

        Option opt = options.getOption("b");
        List tokens = new ArrayList();
        ListIterator iterator = tokens.listIterator();

        try
        {
            parser.processArgs(opt, iterator);
            fail("expected MissingArgumentException");
        }
        catch (MissingArgumentException expected)
        {
            assertTrue(expected.getMessage().indexOf("b") >= 0);
        }
    }
}
