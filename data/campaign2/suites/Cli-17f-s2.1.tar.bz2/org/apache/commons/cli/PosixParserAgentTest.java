package org.apache.commons.cli;

import junit.framework.TestCase;

import java.util.Arrays;

/**
 * Self-contained JUnit 3.8 tests for {@link PosixParser}, based solely on the
 * documented contract of its {@code flatten} and {@code burstToken} methods.
 */
public class PosixParserAgentTest extends TestCase {

    public void testFlattenEmptyArguments() {
        PosixParser parser = new PosixParser();
        Options options = new Options();

        String[] result = parser.flatten(options, new String[0], false);

        assertNotNull(result);
        assertEquals(0, result.length);
    }

    public void testFlattenPlainNonOptionArgumentsAreAddedAsIs() {
        PosixParser parser = new PosixParser();
        Options options = new Options();

        String[] result = parser.flatten(options, new String[] {"foo", "bar"}, false);

        assertEquals(Arrays.asList(new String[] {"foo", "bar"}), Arrays.asList(result));
    }

    public void testFlattenDoubleDashIsAddedAsIs() {
        PosixParser parser = new PosixParser();
        Options options = new Options();

        String[] result = parser.flatten(options, new String[] {"--", "foo", "bar"}, false);

        assertEquals(Arrays.asList(new String[] {"--", "foo", "bar"}), Arrays.asList(result));
    }

    public void testFlattenSingleDashIsAddedAsIs() {
        PosixParser parser = new PosixParser();
        Options options = new Options();

        String[] result = parser.flatten(options, new String[] {"-"}, false);

        assertEquals(Arrays.asList(new String[] {"-"}), Arrays.asList(result));
    }

    public void testFlattenValidTwoCharacterOptionIsKept() {
        PosixParser parser = new PosixParser();
        Options options = new Options();
        options.addOption("a", false, "option a");

        String[] result = parser.flatten(options, new String[] {"-a"}, false);

        assertEquals(Arrays.asList(new String[] {"-a"}), Arrays.asList(result));
    }

    public void testFlattenInvalidTwoCharacterOptionIsIgnoredWhenNotStoppingAtNonOption() {
        PosixParser parser = new PosixParser();
        Options options = new Options();
        options.addOption("a", false, "option a");

        String[] result = parser.flatten(options, new String[] {"-z"}, false);

        assertEquals(0, result.length);
    }

    public void testFlattenInvalidTwoCharacterOptionDoesNotStopFurtherProcessing() {
        PosixParser parser = new PosixParser();
        Options options = new Options();
        options.addOption("a", false, "option a");

        String[] result = parser.flatten(options, new String[] {"-z", "-a"}, false);

        assertEquals(Arrays.asList(new String[] {"-a"}), Arrays.asList(result));
    }

    public void pruned_testFlattenInvalidTwoCharacterOptionCopiesRemainingEntriesWhenStoppingAtNonOption() {
        PosixParser parser = new PosixParser();
        Options options = new Options();
        options.addOption("a", false, "option a");

        String[] result = parser.flatten(options, new String[] {"-z", "foo", "bar"}, true);

        assertEquals(Arrays.asList(new String[] {"-z", "foo", "bar"}), Arrays.asList(result));
    }

    public void testFlattenBurstsMultipleNoArgOptionsIntoSeparateTokens() {
        PosixParser parser = new PosixParser();
        Options options = new Options();
        options.addOption("a", false, "option a");
        options.addOption("b", false, "option b");

        String[] result = parser.flatten(options, new String[] {"-ab"}, false);

        assertEquals(Arrays.asList(new String[] {"-a", "-b"}), Arrays.asList(result));
    }

    public void testFlattenBurstsOptionWithArgumentValueIntoTwoTokens() {
        PosixParser parser = new PosixParser();
        Options options = new Options();
        options.addOption("a", true, "option a with value");

        String[] result = parser.flatten(options, new String[] {"-afoo"}, false);

        assertEquals(Arrays.asList(new String[] {"-a", "foo"}), Arrays.asList(result));
    }

    public void testFlattenBurstUnknownCharacterAfterKnownOptionWithStopAtNonOption() {
        PosixParser parser = new PosixParser();
        Options options = new Options();
        options.addOption("a", false, "option a");

        String[] result = parser.flatten(options, new String[] {"-ax", "foo"}, true);

        assertEquals(Arrays.asList(new String[] {"-a", "--", "x", "foo"}), Arrays.asList(result));
    }

    public void pruned_testFlattenBurstUnknownCharacterAfterKnownOptionWithoutStopAtNonOption() {
        PosixParser parser = new PosixParser();
        Options options = new Options();
        options.addOption("a", false, "option a");

        String[] result = parser.flatten(options, new String[] {"-ax"}, false);

        assertEquals(Arrays.asList(new String[] {"-a", "-x"}), Arrays.asList(result));
    }

    public void testFlattenBurstAllUnknownCharactersWithStopAtNonOption() {
        PosixParser parser = new PosixParser();
        Options options = new Options();

        String[] result = parser.flatten(options, new String[] {"-xy"}, true);

        assertEquals(Arrays.asList(new String[] {"--", "xy"}), Arrays.asList(result));
    }

    public void pruned_testFlattenBurstAllUnknownCharactersWithoutStopAtNonOption() {
        PosixParser parser = new PosixParser();
        Options options = new Options();

        String[] result = parser.flatten(options, new String[] {"-xy"}, false);

        assertEquals(Arrays.asList(new String[] {"-x", "-y"}), Arrays.asList(result));
    }

    public void testFlattenDoesNotRetainStateBetweenCalls() {
        PosixParser parser = new PosixParser();
        Options firstOptions = new Options();
        firstOptions.addOption("a", false, "option a");
        Options secondOptions = new Options();

        String[] firstResult = parser.flatten(firstOptions, new String[] {"-a"}, false);
        String[] secondResult = parser.flatten(secondOptions, new String[] {"foo"}, false);

        assertEquals(Arrays.asList(new String[] {"-a"}), Arrays.asList(firstResult));
        assertEquals(Arrays.asList(new String[] {"foo"}), Arrays.asList(secondResult));
    }
}
