package com.google.gson.stream;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.math.BigInteger;

import junit.framework.TestCase;

/**
 * Self-contained tests for {@link JsonWriter}, based solely on its documented contract.
 */
public class JsonWriterAgentTest extends TestCase {

    /** A Writer that always fails, used to verify that I/O errors propagate. */
    private static class FailingWriter extends Writer {
        public void write(char[] cbuf, int off, int len) throws IOException {
            throw new IOException("simulated failure");
        }
        public void flush() throws IOException {
            throw new IOException("simulated failure");
        }
        public void close() throws IOException {
            throw new IOException("simulated failure");
        }
    }

    /** A Writer that records whether flush()/close() were invoked on it. */
    private static class TrackingWriter extends Writer {
        final StringWriter delegate = new StringWriter();
        boolean flushed = false;
        boolean closed = false;
        public void write(char[] cbuf, int off, int len) throws IOException {
            delegate.write(cbuf, off, len);
        }
        public void flush() throws IOException {
            flushed = true;
        }
        public void close() throws IOException {
            closed = true;
        }
    }

    public void testImplementsCloseableAndFlushable() {
        JsonWriter writer = new JsonWriter(new StringWriter());
        assertTrue(writer instanceof java.io.Closeable);
        assertTrue(writer instanceof java.io.Flushable);
        assertTrue(writer instanceof java.lang.AutoCloseable);
    }

    public void testDefaultIsNotLenient() {
        JsonWriter writer = new JsonWriter(new StringWriter());
        assertFalse(writer.isLenient());
    }

    public void testDefaultIsNotHtmlSafe() {
        JsonWriter writer = new JsonWriter(new StringWriter());
        assertFalse(writer.isHtmlSafe());
    }

    public void testDefaultSerializeNullsIsTrue() {
        JsonWriter writer = new JsonWriter(new StringWriter());
        assertTrue(writer.getSerializeNulls());
    }

    public void testBeginEndArrayEmpty() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        JsonWriter ret = writer.beginArray();
        assertSame(writer, ret);
        assertSame(writer, writer.endArray());
        writer.close();
        assertEquals("[]", sw.toString());
    }

    public void testBeginEndObjectEmpty() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        assertSame(writer, writer.beginObject());
        assertSame(writer, writer.endObject());
        writer.close();
        assertEquals("{}", sw.toString());
    }

    public void testNameAndStringValue() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        writer.beginObject();
        JsonWriter afterName = writer.name("a");
        assertSame(writer, afterName);
        JsonWriter afterValue = afterName.value("b");
        assertSame(writer, afterValue);
        writer.endObject();
        writer.close();
        assertEquals("{\"a\":\"b\"}", sw.toString());
    }

    public void testObjectWithMultipleMembersOfDifferentTypes() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        writer.beginObject();
        writer.name("bool").value(true);
        writer.name("num").value(5L);
        writer.name("str").value("x");
        writer.endObject();
        writer.close();
        assertEquals("{\"bool\":true,\"num\":5,\"str\":\"x\"}", sw.toString());
    }

    public void testNestedArrayInsideObject() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        writer.beginObject();
        writer.name("arr");
        writer.beginArray();
        writer.value(1L);
        writer.value(2L);
        writer.endArray();
        writer.endObject();
        writer.close();
        assertEquals("{\"arr\":[1,2]}", sw.toString());
    }

    public void testDefaultOutputIsCompactWithoutSetIndent() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        writer.beginArray();
        writer.value(1L);
        writer.value(2L);
        writer.endArray();
        writer.close();
        assertEquals("[1,2]", sw.toString());
    }

    public void testSetIndentEmptyStringIsCompact() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        writer.setIndent("");
        writer.beginObject();
        writer.name("a").value(1L);
        writer.endObject();
        writer.close();
        assertEquals("{\"a\":1}", sw.toString());
    }

    public void testSetIndentNonEmptyProducesMultilineIndentedOutput() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        writer.setIndent("  ");
        writer.beginObject();
        writer.name("a").value(1L);
        writer.endObject();
        writer.close();
        String out = sw.toString();
        assertTrue(out.indexOf('\n') >= 0);
        assertTrue(out.indexOf("  \"a\"") >= 0);
    }

    public void testNullValueMethodEncodesNullInArray() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        writer.beginArray();
        JsonWriter ret = writer.nullValue();
        assertSame(writer, ret);
        writer.endArray();
        writer.close();
        assertEquals("[null]", sw.toString());
    }

    public void testStringValueNullEncodesNullLiteral() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        writer.beginArray();
        writer.value((String) null);
        writer.endArray();
        writer.close();
        assertEquals("[null]", sw.toString());
    }

    public void testSerializeNullsDefaultTrueKeepsObjectMember() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        writer.beginObject();
        writer.name("x").nullValue();
        writer.endObject();
        writer.close();
        assertEquals("{\"x\":null}", sw.toString());
    }

    public void testSerializeNullsFalseOmitsLeadingObjectMember() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        writer.setSerializeNulls(false);
        assertFalse(writer.getSerializeNulls());
        writer.beginObject();
        writer.name("x").nullValue();
        writer.name("y").value("z");
        writer.endObject();
        writer.close();
        assertEquals("{\"y\":\"z\"}", sw.toString());
    }

    public void testSerializeNullsFalseOmitsMiddleObjectMember() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        writer.setSerializeNulls(false);
        writer.beginObject();
        writer.name("a").value("1");
        writer.name("b").nullValue();
        writer.name("c").value("3");
        writer.endObject();
        writer.close();
        assertEquals("{\"a\":\"1\",\"c\":\"3\"}", sw.toString());
    }

    public void testSerializeNullsFalseHasNoEffectOnArrayElements() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        writer.setSerializeNulls(false);
        writer.beginArray();
        writer.nullValue();
        writer.value("a");
        writer.endArray();
        writer.close();
        assertEquals("[null,\"a\"]", sw.toString());
    }

    public void pruned_testTopLevelValueWithoutLenientThrowsIllegalStateException() throws IOException {
        JsonWriter writer = new JsonWriter(new StringWriter());
        try {
            writer.value("x");
            fail("Expected IllegalStateException");
        } catch (IllegalStateException expected) {
            // expected: non-lenient top-level value must be an object or array
        }
    }

    public void testTopLevelValueWithLenientIsAllowed() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        writer.setLenient(true);
        assertTrue(writer.isLenient());
        JsonWriter ret = writer.value("x");
        assertSame(writer, ret);
        writer.close();
        assertEquals("\"x\"", sw.toString());
    }

    public void testEndArrayWithoutBeginArrayThrowsIllegalStateException() throws IOException {
        JsonWriter writer = new JsonWriter(new StringWriter());
        try {
            writer.endArray();
            fail("Expected IllegalStateException");
        } catch (IllegalStateException expected) {
            // expected
        }
    }

    public void testEndObjectWithoutBeginObjectThrowsIllegalStateException() throws IOException {
        JsonWriter writer = new JsonWriter(new StringWriter());
        try {
            writer.endObject();
            fail("Expected IllegalStateException");
        } catch (IllegalStateException expected) {
            // expected
        }
    }

    public void testMismatchedEndArrayForObjectThrowsIllegalStateException() throws IOException {
        JsonWriter writer = new JsonWriter(new StringWriter());
        writer.beginObject();
        try {
            writer.endArray();
            fail("Expected IllegalStateException");
        } catch (IllegalStateException expected) {
            // expected: closing an object with endArray() is malformed
        }
    }

    public void testSecondTopLevelValueWithoutLenientThrowsIllegalStateException() throws IOException {
        JsonWriter writer = new JsonWriter(new StringWriter());
        writer.beginArray();
        writer.endArray();
        try {
            writer.beginArray();
            fail("Expected IllegalStateException");
        } catch (IllegalStateException expected) {
            // expected: a document may contain only one top-level value
        }
    }

    public void testCloseWithIncompleteDocumentThrowsIOException() throws IOException {
        JsonWriter writer = new JsonWriter(new StringWriter());
        writer.beginArray();
        try {
            writer.close();
            fail("Expected IOException");
        } catch (IOException expected) {
            // expected: document is incomplete
        }
    }

    public void testNameNullThrowsNullPointerException() throws IOException {
        JsonWriter writer = new JsonWriter(new StringWriter());
        writer.beginObject();
        try {
            writer.name(null);
            fail("Expected NullPointerException");
        } catch (NullPointerException expected) {
            // expected: name "may not be null"
        }
    }

    public void pruned_testNameOutsideObjectThrowsIllegalStateException() throws IOException {
        JsonWriter writer = new JsonWriter(new StringWriter());
        writer.beginArray();
        try {
            writer.name("x");
            fail("Expected IllegalStateException");
        } catch (IllegalStateException expected) {
            // expected: a name may only be written inside an object
        }
    }

    public void testValueInsideObjectWithoutNameThrowsIllegalStateException() throws IOException {
        JsonWriter writer = new JsonWriter(new StringWriter());
        writer.beginObject();
        try {
            writer.value("v");
            fail("Expected IllegalStateException");
        } catch (IllegalStateException expected) {
            // expected: a value may not be written before a name inside an object
        }
    }

    public void testRepeatedNameWithoutValueThrowsIllegalStateException() throws IOException {
        JsonWriter writer = new JsonWriter(new StringWriter());
        writer.beginObject();
        writer.name("a");
        try {
            writer.name("b");
            fail("Expected IllegalStateException");
        } catch (IllegalStateException expected) {
            // expected: a name must be followed by a value before another name
        }
    }

    public void testEndObjectAfterNameWithoutValueThrowsIllegalStateException() throws IOException {
        JsonWriter writer = new JsonWriter(new StringWriter());
        writer.beginObject();
        writer.name("k");
        try {
            writer.endObject();
            fail("Expected IllegalStateException");
        } catch (IllegalStateException expected) {
            // expected: a dangling name without a value is malformed
        }
    }

    public void testValueDoubleNaNWithoutLenientThrowsIllegalArgumentException() throws IOException {
        JsonWriter writer = new JsonWriter(new StringWriter());
        writer.beginArray();
        try {
            writer.value(Double.NaN);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected: value must be finite
        }
    }

    public void testValueDoublePositiveInfinityWithoutLenientThrowsIllegalArgumentException() throws IOException {
        JsonWriter writer = new JsonWriter(new StringWriter());
        writer.beginArray();
        try {
            writer.value(Double.POSITIVE_INFINITY);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected: value must be finite
        }
    }

    public void testValueDoubleNegativeInfinityWithoutLenientThrowsIllegalArgumentException() throws IOException {
        JsonWriter writer = new JsonWriter(new StringWriter());
        writer.beginArray();
        try {
            writer.value(Double.NEGATIVE_INFINITY);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected: value must be finite
        }
    }

    public void testValueNumberNaNWithoutLenientThrowsIllegalArgumentException() throws IOException {
        JsonWriter writer = new JsonWriter(new StringWriter());
        writer.beginArray();
        Double nanNumber = new Double(Double.NaN);
        try {
            writer.value((Number) nanNumber);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected: value must be finite
        }
    }

    public void testValueDoubleNaNWithLenientIsAllowed() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        writer.setLenient(true);
        writer.beginArray();
        JsonWriter ret = writer.value(Double.NaN);
        assertSame(writer, ret);
        writer.endArray();
        writer.close();
        assertEquals("[NaN]", sw.toString());
    }

    public void testValueDoubleInfinityWithLenientIsAllowed() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        writer.setLenient(true);
        writer.beginArray();
        writer.value(Double.POSITIVE_INFINITY);
        writer.endArray();
        writer.close();
        assertEquals("[Infinity]", sw.toString());
    }

    public void testValueDoubleFinite() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        writer.beginArray();
        writer.value(2.5);
        writer.value(0.0);
        writer.endArray();
        writer.close();
        String out = sw.toString();
        assertTrue(out.startsWith("["));
        assertTrue(out.endsWith("]"));
        String inner = out.substring(1, out.length() - 1);
        String[] parts = inner.split(",");
        assertEquals(2, parts.length);
        assertEquals(2.5, Double.parseDouble(parts[0]), 0.0);
        assertEquals(0.0, Double.parseDouble(parts[1]), 0.0);
    }

    public void testValueLongFullRange() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        writer.beginArray();
        writer.value(Long.MIN_VALUE);
        writer.value(Long.MAX_VALUE);
        writer.endArray();
        writer.close();
        assertEquals("[" + Long.MIN_VALUE + "," + Long.MAX_VALUE + "]", sw.toString());
    }

    public void testValueBooleanPrimitive() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        writer.beginArray();
        writer.value(true);
        writer.value(false);
        writer.endArray();
        writer.close();
        assertEquals("[true,false]", sw.toString());
    }

    public void testValueBooleanObject() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        writer.beginArray();
        writer.value(Boolean.TRUE);
        writer.value(Boolean.FALSE);
        writer.endArray();
        writer.close();
        assertEquals("[true,false]", sw.toString());
    }

    public void testValueNumberBigInteger() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        writer.beginArray();
        writer.value(new BigInteger("12345678901234567890"));
        writer.endArray();
        writer.close();
        assertEquals("[12345678901234567890]", sw.toString());
    }

    public void testJsonValueWritesRawTextWithoutQuotingOrEscaping() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        writer.beginArray();
        JsonWriter ret = writer.jsonValue("123");
        assertSame(writer, ret);
        writer.endArray();
        writer.close();
        assertEquals("[123]", sw.toString());
    }

    public void testJsonValueNullEncodesNullLiteral() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        writer.beginArray();
        writer.jsonValue(null);
        writer.endArray();
        writer.close();
        assertEquals("[null]", sw.toString());
    }

    public void testFlushMakesDataAvailableWithoutClosing() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        writer.beginArray();
        writer.value(1L);
        writer.flush();
        String out = sw.toString();
        assertTrue(out.indexOf('1') >= 0);
        writer.endArray();
        writer.close();
    }

    public void pruned_testCloseFlushesAndClosesUnderlyingWriter() throws IOException {
        TrackingWriter tracking = new TrackingWriter();
        JsonWriter writer = new JsonWriter(tracking);
        writer.beginArray();
        writer.endArray();
        writer.close();
        assertTrue(tracking.flushed);
        assertTrue(tracking.closed);
        assertEquals("[]", tracking.delegate.toString());
    }

    public void testHtmlSafeDefaultFalseKeepsRawCharacters() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        assertFalse(writer.isHtmlSafe());
        writer.beginArray();
        writer.value("<a&b>c=d");
        writer.endArray();
        writer.close();
        String out = sw.toString();
        assertTrue(out.indexOf('<') >= 0);
        assertTrue(out.indexOf('&') >= 0);
    }

    public void testHtmlSafeTrueEscapesSpecialCharacters() throws IOException {
        StringWriter sw = new StringWriter();
        JsonWriter writer = new JsonWriter(sw);
        writer.setHtmlSafe(true);
        assertTrue(writer.isHtmlSafe());
        writer.beginArray();
        writer.value("<a&b>c=d");
        writer.endArray();
        writer.close();
        String out = sw.toString();
        assertTrue(out.indexOf('<') < 0);
        assertTrue(out.indexOf('>') < 0);
        assertTrue(out.indexOf('&') < 0);
        assertTrue(out.indexOf('=') < 0);
        assertTrue(out.indexOf('a') >= 0);
        assertTrue(out.indexOf('b') >= 0);
        assertTrue(out.indexOf('c') >= 0);
        assertTrue(out.indexOf('d') >= 0);
    }

    public void testIOExceptionFromUnderlyingWriterPropagates() {
        JsonWriter writer = new JsonWriter(new FailingWriter());
        try {
            writer.beginArray();
            fail("Expected IOException");
        } catch (IOException expected) {
            // expected: underlying writer failures propagate
        }
    }
}
