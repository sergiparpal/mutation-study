package org.apache.commons.cli2.commandline;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import junit.framework.TestCase;

import org.apache.commons.cli2.Option;

/**
 * Self-contained JUnit 3.8 tests for WriteableCommandLineImpl, based solely on
 * the documented contract in api/org/apache/commons/cli2/commandline/WriteableCommandLineImpl.html.
 *
 * org.apache.commons.cli2.Option is an interface whose own javadoc is not part of
 * the provided spec, so fixtures are built with dynamic java.lang.reflect.Proxy
 * instances rather than a hand written implementation of that interface. The
 * proxy answers the handful of methods the contract implies (getPreferredName,
 * getTriggers, getId, isRequired, canProcess, findOption) and falls back to
 * harmless type-appropriate defaults for anything else.
 */
public class WriteableCommandLineImplAgentTest extends TestCase {

    private static int nextId = 1;

    private static final class OptionHandler implements InvocationHandler {
        private final String preferredName;
        private final Set triggers;
        private final int id;
        private final boolean required;

        OptionHandler(String preferredName, Set triggers, int id, boolean required) {
            this.preferredName = preferredName;
            this.triggers = triggers;
            this.id = id;
            this.required = required;
        }

        private static String firstStringArg(Object[] args) {
            if (args == null) {
                return null;
            }
            for (int i = 0; i < args.length; i++) {
                if (args[i] instanceof String) {
                    return (String) args[i];
                }
            }
            return null;
        }

        private static Object defaultFor(Class returnType) {
            if (returnType == void.class) {
                return null;
            }
            if (returnType == boolean.class) {
                return Boolean.FALSE;
            }
            if (returnType == int.class || returnType == long.class || returnType == short.class
                    || returnType == byte.class) {
                return new Integer(0);
            }
            if (returnType == char.class) {
                return new Character(' ');
            }
            if (returnType == double.class || returnType == float.class) {
                return new Double(0);
            }
            if (Set.class.isAssignableFrom(returnType)) {
                return new HashSet();
            }
            if (List.class.isAssignableFrom(returnType)) {
                return new ArrayList();
            }
            if (Map.class.isAssignableFrom(returnType)) {
                return new HashMap();
            }
            return null;
        }

        public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
            String name = method.getName();

            if ("equals".equals(name) && args != null && args.length == 1) {
                return Boolean.valueOf(proxy == args[0]);
            }
            if ("hashCode".equals(name)) {
                return new Integer(System.identityHashCode(proxy));
            }
            if ("toString".equals(name)) {
                return "FakeOption[" + preferredName + "]";
            }
            if ("getPreferredName".equals(name)) {
                return preferredName;
            }
            if ("getDescription".equals(name)) {
                return preferredName;
            }
            if ("getTriggers".equals(name)) {
                return triggers;
            }
            if ("getPrefixes".equals(name)) {
                return Collections.EMPTY_SET;
            }
            if ("getId".equals(name)) {
                return new Integer(id);
            }
            if ("isRequired".equals(name)) {
                return Boolean.valueOf(required);
            }
            if ("findOption".equals(name)) {
                String trigger = firstStringArg(args);
                if (trigger != null && triggers.contains(trigger)) {
                    return proxy;
                }
                return null;
            }
            if ("canProcess".equals(name)) {
                String trigger = firstStringArg(args);
                return Boolean.valueOf(trigger != null && triggers.contains(trigger));
            }
            if ("validate".equals(name) || "process".equals(name) || "appendUsage".equals(name)
                    || "help".equals(name)) {
                return null;
            }
            if ("helpLines".equals(name)) {
                return new ArrayList();
            }

            return defaultFor(method.getReturnType());
        }
    }

    private static Option newOption(String preferredName, String[] extraTriggers, boolean required) {
        Set triggers = new HashSet();
        triggers.add(preferredName);
        if (extraTriggers != null) {
            for (int i = 0; i < extraTriggers.length; i++) {
                triggers.add(extraTriggers[i]);
            }
        }
        OptionHandler handler = new OptionHandler(preferredName, triggers, nextId++, required);
        return (Option) Proxy.newProxyInstance(
                WriteableCommandLineImplAgentTest.class.getClassLoader(),
                new Class[] { Option.class },
                handler);
    }

    private static Option newRootOption() {
        return newOption("--root", new String[] { "-r" }, false);
    }

    private static WriteableCommandLineImpl newCommandLine() {
        return new WriteableCommandLineImpl(newRootOption(), new ArrayList());
    }

    public void testConstructorStartsEmpty() {
        WriteableCommandLineImpl wcl = newCommandLine();
        assertNotNull(wcl.getOptions());
        assertTrue(wcl.getOptions().isEmpty());
        assertNotNull(wcl.getOptionTriggers());
        assertTrue(wcl.getOptionTriggers().isEmpty());
        assertNotNull(wcl.getProperties());
        assertTrue(wcl.getProperties().isEmpty());
    }

    public void testGetNormalisedStartsEmptyAndHasNoPublicMutator() {
        WriteableCommandLineImpl wcl = newCommandLine();
        assertNotNull(wcl.getNormalised());
        assertTrue(wcl.getNormalised().isEmpty());

        Option option = newOption("--alpha", new String[] { "-a" }, false);
        wcl.addOption(option);
        wcl.addValue(option, "value");
        wcl.addSwitch(option, true);
        wcl.addProperty("p", "v");

        // Nothing in the documented API mutates the normalised list.
        assertNotNull(wcl.getNormalised());
        assertTrue(wcl.getNormalised().isEmpty());
    }

    public void testAddOptionIsReflectedInGetOptionsAndHasOption() {
        WriteableCommandLineImpl wcl = newCommandLine();
        Option alpha = newOption("--alpha", new String[] { "-a" }, false);
        Option beta = newOption("--beta", new String[] { "-b" }, false);

        assertFalse(wcl.hasOption(alpha));

        wcl.addOption(alpha);
        assertTrue(wcl.hasOption(alpha));
        assertFalse(wcl.hasOption(beta));
        assertEquals(1, wcl.getOptions().size());
        assertTrue(wcl.getOptions().contains(alpha));

        wcl.addOption(beta);
        assertTrue(wcl.hasOption(beta));
        assertEquals(2, wcl.getOptions().size());
        assertTrue(wcl.getOptions().contains(alpha));
        assertTrue(wcl.getOptions().contains(beta));
    }

    public void testAddOptionPopulatesOptionTriggers() {
        WriteableCommandLineImpl wcl = newCommandLine();
        Option alpha = newOption("--alpha", new String[] { "-a" }, false);
        wcl.addOption(alpha);

        Set triggers = wcl.getOptionTriggers();
        assertNotNull(triggers);
        assertTrue(triggers.containsAll(alpha.getTriggers()));
    }

    public void testAddValueThenGetValuesReturnsAddedValuesInOrder() {
        WriteableCommandLineImpl wcl = newCommandLine();
        Option option = newOption("--alpha", null, false);

        wcl.addValue(option, "foo");
        wcl.addValue(option, "bar");

        List defaults = new ArrayList();
        List values = wcl.getValues(option, defaults);
        assertEquals(Arrays.asList(new String[] { "foo", "bar" }), values);
    }

    public void pruned_testGetValuesFallsBackToSuppliedDefaultsWhenNothingSet() {
        WriteableCommandLineImpl wcl = newCommandLine();
        Option option = newOption("--alpha", null, false);

        List defaults = Arrays.asList(new String[] { "d1", "d2" });
        assertEquals(defaults, wcl.getValues(option, defaults));

        assertNull(wcl.getValues(option, null));
    }

    public void pruned_testSetDefaultValuesIsUsedBySubsequentGetValues() {
        WriteableCommandLineImpl wcl = newCommandLine();
        Option option = newOption("--alpha", null, false);

        List configuredDefaults = Arrays.asList(new String[] { "configured" });
        wcl.setDefaultValues(option, configuredDefaults);

        List paramDefaults = Arrays.asList(new String[] { "param" });
        assertEquals(configuredDefaults, wcl.getValues(option, paramDefaults));
    }

    public void testGetUndefaultedValuesIgnoresConfiguredDefaults() {
        WriteableCommandLineImpl wcl = newCommandLine();
        Option option = newOption("--alpha", null, false);

        wcl.setDefaultValues(option, Arrays.asList(new String[] { "configured" }));

        List undefaulted = wcl.getUndefaultedValues(option);
        assertNotNull(undefaulted);
        assertTrue(undefaulted.isEmpty());

        wcl.addValue(option, "real");
        undefaulted = wcl.getUndefaultedValues(option);
        assertEquals(Arrays.asList(new String[] { "real" }), undefaulted);
    }

    public void testGetUndefaultedValuesEmptyForUnknownOption() {
        WriteableCommandLineImpl wcl = newCommandLine();
        Option option = newOption("--never-added", null, false);

        List undefaulted = wcl.getUndefaultedValues(option);
        assertNotNull(undefaulted);
        assertTrue(undefaulted.isEmpty());
    }

    public void testAddSwitchThenGetSwitchIgnoresSuppliedDefault() {
        WriteableCommandLineImpl wcl = newCommandLine();
        Option option = newOption("--flag", null, false);

        wcl.addSwitch(option, true);
        assertEquals(Boolean.TRUE, wcl.getSwitch(option, Boolean.FALSE));
    }

    public void testGetSwitchFallsBackToSuppliedDefaultWhenNothingSet() {
        WriteableCommandLineImpl wcl = newCommandLine();
        Option option = newOption("--flag", null, false);

        assertEquals(Boolean.TRUE, wcl.getSwitch(option, Boolean.TRUE));
        assertNull(wcl.getSwitch(option, null));
    }

    public void pruned_testSetDefaultSwitchIsUsedBySubsequentGetSwitch() {
        WriteableCommandLineImpl wcl = newCommandLine();
        Option option = newOption("--flag", null, false);

        wcl.setDefaultSwitch(option, Boolean.TRUE);
        assertEquals(Boolean.TRUE, wcl.getSwitch(option, Boolean.FALSE));
    }

    public void testDefaultPropertySetAddAndGet() {
        WriteableCommandLineImpl wcl = newCommandLine();

        assertNull(wcl.getProperty("missing"));

        wcl.addProperty("key1", "value1");
        assertEquals("value1", wcl.getProperty("key1"));
        assertTrue(wcl.getProperties().contains("key1"));

        wcl.addProperty("key1", "value2");
        assertEquals("value2", wcl.getProperty("key1"));
    }

    public void testPerOptionPropertyAddAndGetIsIsolatedFromDefaultSet() {
        WriteableCommandLineImpl wcl = newCommandLine();
        Option option = newOption("-D", null, false);

        assertEquals("fallback", wcl.getProperty(option, "missing", "fallback"));

        wcl.addProperty(option, "name", "value");
        assertEquals("value", wcl.getProperty(option, "name", "fallback"));
        assertTrue(wcl.getProperties(option).contains("name"));

        // The default (no-option) property set is a different namespace.
        assertNull(wcl.getProperty("name"));
        assertFalse(wcl.getProperties().contains("name"));
    }

    public void testPerOptionPropertyReplacesExistingValue() {
        WriteableCommandLineImpl wcl = newCommandLine();
        Option option = newOption("-D", null, false);

        wcl.addProperty(option, "name", "first");
        wcl.addProperty(option, "name", "second");
        assertEquals("second", wcl.getProperty(option, "name", "fallback"));
    }

    public void testGetPropertiesForUnknownOptionIsEmptyNotNull() {
        WriteableCommandLineImpl wcl = newCommandLine();
        Option option = newOption("-D", null, false);

        Set properties = wcl.getProperties(option);
        assertNotNull(properties);
        assertTrue(properties.isEmpty());
    }

    public void pruned_testGetOptionFindsAddedTriggerOnRoot() {
        Option root = newRootOption();
        WriteableCommandLineImpl wcl = new WriteableCommandLineImpl(root, new ArrayList());

        assertSame(root, wcl.getOption("--root"));
        assertSame(root, wcl.getOption("-r"));
        assertNull(wcl.getOption("--does-not-exist"));
    }

    public void pruned_testLooksLikeOptionMatchesRootTriggerOnly() {
        Option root = newRootOption();
        WriteableCommandLineImpl wcl = new WriteableCommandLineImpl(root, new ArrayList());

        assertTrue(wcl.looksLikeOption("--root"));
        assertFalse(wcl.looksLikeOption("not-a-trigger"));
    }

    public void testToStringIsNotNull() {
        WriteableCommandLineImpl wcl = newCommandLine();
        assertNotNull(wcl.toString());
    }

    public void testConstructorPreservesSuppliedArguments() {
        List arguments = Arrays.asList(new String[] { "a", "b", "c" });
        WriteableCommandLineImpl wcl = new WriteableCommandLineImpl(newRootOption(), arguments);
        assertNotNull(wcl.getOptions());
        assertTrue(wcl.getOptions().isEmpty());
    }
}
