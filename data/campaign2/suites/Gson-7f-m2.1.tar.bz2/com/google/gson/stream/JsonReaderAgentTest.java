/*
 * Copyright (C) 2010 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.gson.stream;

import junit.framework.TestCase;

import java.io.EOFException;
import java.io.IOException;
import java.io.StringReader;

/**
 * Self-contained unit tests for {@link JsonReader}.
 */
public class JsonReaderAgentTest extends TestCase {

  public void testReadObject() throws IOException {
    JsonReader reader = new JsonReader(new StringReader(
        "{\"a\": \"android\", \"b\": \"banana\"}"));
    reader.beginObject();
    assertEquals("a", reader.nextName());
    assertEquals("android", reader.nextString());
    assertEquals("b", reader.nextName());
    assertEquals("banana", reader.nextString());
    reader.endObject();
    assertEquals(JsonToken.END_DOCUMENT, reader.peek());
    reader.close();
  }

  public void testReadArray() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1, 2, 3, 4]"));
    reader.beginArray();
    assertEquals(1, reader.nextInt());
    assertEquals(2, reader.nextInt());
    assertEquals(3, reader.nextInt());
    assertEquals(4, reader.nextInt());
    reader.endArray();
    reader.close();
  }

  public void testEmptyArray() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[]"));
    reader.beginArray();
    assertFalse(reader.hasNext());
    reader.endArray();
  }

  public void testNestedArrayAndObject() throws IOException {
    JsonReader reader = new JsonReader(new StringReader(
        "{\"a\": [1, 2], \"b\": {\"c\": true}}"));
    reader.beginObject();
    assertEquals("a", reader.nextName());
    reader.beginArray();
    assertEquals(1, reader.nextInt());
    assertEquals(2, reader.nextInt());
    reader.endArray();
    assertEquals("b", reader.nextName());
    reader.beginObject();
    assertEquals("c", reader.nextName());
    assertTrue(reader.nextBoolean());
    reader.endObject();
    reader.endObject();
  }

  public void testBooleans() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[true, false]"));
    reader.beginArray();
    assertEquals(JsonToken.BOOLEAN, reader.peek());
    assertTrue(reader.nextBoolean());
    assertFalse(reader.nextBoolean());
    reader.endArray();
  }

  public void testNulls() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[null]"));
    reader.beginArray();
    assertEquals(JsonToken.NULL, reader.peek());
    reader.nextNull();
    reader.endArray();
  }

  public void testNumbers() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1, 1.5, -2, 3.14159, 9223372036854775807]"));
    reader.beginArray();
    assertEquals(1, reader.nextLong());
    assertEquals(1.5, reader.nextDouble(), 0.0);
    assertEquals(-2, reader.nextInt());
    assertEquals(3.14159, reader.nextDouble(), 0.0);
    assertEquals(Long.MAX_VALUE, reader.nextLong());
    reader.endArray();
  }

  public void testStringsAsNumbers() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[\"123\"]"));
    reader.beginArray();
    assertEquals(123, reader.nextInt());
    reader.endArray();
  }

  public void testNumbersAsStrings() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[123, 45.6]"));
    reader.beginArray();
    assertEquals("123", reader.nextString());
    assertEquals("45.6", reader.nextString());
    reader.endArray();
  }

  public void testIntegerMismatchWithNonFiniteDoubleThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1.5]"));
    reader.beginArray();
    try {
      reader.nextInt();
      fail();
    } catch (NumberFormatException expected) {
    }
  }

  public void testLongOverflowThrows() throws IOException {
    // too large for long, falls back to double parse and loses precision
    JsonReader reader = new JsonReader(new StringReader("[92233720368547758070]"));
    reader.beginArray();
    try {
      reader.nextLong();
      fail();
    } catch (NumberFormatException expected) {
    }
  }

  public void testPeekDoesNotConsume() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[\"hello\"]"));
    reader.beginArray();
    assertEquals(JsonToken.STRING, reader.peek());
    assertEquals(JsonToken.STRING, reader.peek());
    assertEquals("hello", reader.nextString());
    reader.endArray();
  }

  public void testHasNextEndOfDocument() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("{}"));
    reader.beginObject();
    assertFalse(reader.hasNext());
    reader.endObject();
    assertEquals(JsonToken.END_DOCUMENT, reader.peek());
  }

  public void testSkipValueOnObject() throws IOException {
    JsonReader reader = new JsonReader(new StringReader(
        "{\"a\": {\"b\": [1, 2, 3]}, \"c\": 5}"));
    reader.beginObject();
    assertEquals("a", reader.nextName());
    reader.skipValue();
    assertEquals("c", reader.nextName());
    assertEquals(5, reader.nextInt());
    reader.endObject();
  }

  public void testSkipValueOnArray() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[[1, 2], 3]"));
    reader.beginArray();
    reader.skipValue();
    assertEquals(3, reader.nextInt());
    reader.endArray();
  }

  public void testSkipValueOnScalar() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[\"a\", \"b\"]"));
    reader.beginArray();
    reader.skipValue();
    assertEquals("b", reader.nextString());
    reader.endArray();
  }

  public void testGetPath() throws IOException {
    JsonReader reader = new JsonReader(new StringReader(
        "{\"a\": [1, 2, {\"b\": 3}]}"));
    assertEquals("$", reader.getPath());
    reader.beginObject();
    reader.nextName();
    assertEquals("$.a", reader.getPath());
    reader.beginArray();
    reader.nextInt();
    assertEquals("$.a[1]", reader.getPath());
    reader.nextInt();
    reader.beginObject();
    reader.nextName();
    assertEquals("$.a[2].b", reader.getPath());
    reader.nextInt();
    reader.endObject();
    reader.endArray();
    reader.endObject();
    assertEquals("$", reader.getPath());
  }

  public void testLenientDefaultIsFalse() {
    JsonReader reader = new JsonReader(new StringReader("{}"));
    assertFalse(reader.isLenient());
  }

  public void testSetLenientIsHonored() {
    JsonReader reader = new JsonReader(new StringReader("{}"));
    reader.setLenient(true);
    assertTrue(reader.isLenient());
    reader.setLenient(false);
    assertFalse(reader.isLenient());
  }

  public void testStrictModeRejectsUnquotedNames() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("{a: true}"));
    reader.beginObject();
    try {
      reader.nextName();
      fail();
    } catch (IOException expected) {
    }
  }

  public void testLenientModeAcceptsUnquotedNames() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("{a: true}"));
    reader.setLenient(true);
    reader.beginObject();
    assertEquals("a", reader.nextName());
    assertTrue(reader.nextBoolean());
    reader.endObject();
  }

  public void testStrictModeRejectsNonExecutePrefix() throws IOException {
    JsonReader reader = new JsonReader(new StringReader(")]}'\n[]"));
    try {
      reader.beginArray();
      fail();
    } catch (IOException expected) {
    }
  }

  public void testLenientModeAcceptsNonExecutePrefix() throws IOException {
    JsonReader reader = new JsonReader(new StringReader(")]}'\n[]"));
    reader.setLenient(true);
    reader.beginArray();
    assertFalse(reader.hasNext());
    reader.endArray();
  }

  public void testStrictModeRejectsTrailingTopLevelValues() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[][]"));
    reader.beginArray();
    reader.endArray();
    try {
      reader.peek();
      fail();
    } catch (IOException expected) {
    }
  }

  public void testStrictModeRejectsUnquotedTopLevelLiteral() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("hello"));
    try {
      reader.nextString();
      fail();
    } catch (IOException expected) {
    }
  }

  public void testLenientModeAcceptsTopLevelString() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("\"hello\""));
    reader.setLenient(true);
    assertEquals("hello", reader.nextString());
  }

  public void testBeginArrayOnObjectThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("{}"));
    try {
      reader.beginArray();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testBeginObjectOnArrayThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[]"));
    try {
      reader.beginObject();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testNextStringOnBooleanThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[true]"));
    reader.beginArray();
    try {
      reader.nextString();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testNextBooleanOnNumberThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[5]"));
    reader.beginArray();
    try {
      reader.nextBoolean();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testNextNullOnNonNullThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[5]"));
    reader.beginArray();
    try {
      reader.nextNull();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testEndArrayOnNonEmptyArrayThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1, 2]"));
    reader.beginArray();
    try {
      reader.endArray();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testEndObjectOnNonEmptyObjectThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("{\"a\": 1}"));
    reader.beginObject();
    try {
      reader.endObject();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testPrematureEndOfInputThrowsEOFException() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1,"));
    reader.beginArray();
    reader.nextInt();
    try {
      reader.hasNext();
      fail();
    } catch (EOFException expected) {
    }
  }

  public void testCloseThenUseThrowsIllegalStateException() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[]"));
    reader.close();
    try {
      reader.beginArray();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testNullReaderThrowsNullPointerException() {
    try {
      new JsonReader(null);
      fail();
    } catch (NullPointerException expected) {
    }
  }

  public void testUnterminatedStringThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[\"abc"));
    reader.beginArray();
    try {
      reader.nextString();
      fail();
    } catch (IOException expected) {
    }
  }

  public void testMissingValueInObjectThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("{\"a\":}"));
    reader.beginObject();
    reader.nextName();
    try {
      reader.peek();
      fail();
    } catch (IOException expected) {
    }
  }

  public void testCharacterUnescaping() throws IOException {
    JsonReader reader = new JsonReader(new StringReader(
        "[\"a\\tb\\nc\\rd\\\\e\\\"f\\u0041g\"]"));
    reader.beginArray();
    assertEquals("a\tb\nc\rd\\e\"fAg", reader.nextString());
    reader.endArray();
  }

  public void testUnicodeLineBreaksAreNotWhitespace() throws IOException {
    // U+2028 line separator is not JSON whitespace and should be treated as part of the string.
    JsonReader reader = new JsonReader(new StringReader("[\" \"]"));
    reader.beginArray();
    assertEquals(" ", reader.nextString());
    reader.endArray();
  }

  public void testMixedCaseLiterals() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[True, FALSE, NULL]"));
    reader.setLenient(true);
    reader.beginArray();
    assertTrue(reader.nextBoolean());
    assertFalse(reader.nextBoolean());
    reader.nextNull();
    reader.endArray();
  }

  public void testToStringContainsLineAndColumn() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[]"));
    String result = reader.toString();
    assertTrue(result.contains("line"));
    assertTrue(result.contains("column"));
  }

  public void testMultipleTopLevelValuesInLenientMode() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[] []"));
    reader.setLenient(true);
    reader.beginArray();
    reader.endArray();
    assertEquals(JsonToken.BEGIN_ARRAY, reader.peek());
    reader.beginArray();
    reader.endArray();
  }

  public void testEmptyDocumentThrowsOnFirstPeek() throws IOException {
    JsonReader reader = new JsonReader(new StringReader(""));
    try {
      reader.peek();
      fail();
    } catch (EOFException expected) {
    }
  }

  public void testCommentsRequireLenientMode() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1 // comment\n, 2]"));
    try {
      reader.beginArray();
      reader.nextInt();
      reader.nextInt();
      fail();
    } catch (IOException expected) {
    }
  }

  public void testCommentsAllowedInLenientMode() throws IOException {
    JsonReader reader = new JsonReader(new StringReader(
        "[1 // comment\n, 2 /* block */, 3]"));
    reader.setLenient(true);
    reader.beginArray();
    assertEquals(1, reader.nextInt());
    assertEquals(2, reader.nextInt());
    assertEquals(3, reader.nextInt());
    reader.endArray();
  }
}
