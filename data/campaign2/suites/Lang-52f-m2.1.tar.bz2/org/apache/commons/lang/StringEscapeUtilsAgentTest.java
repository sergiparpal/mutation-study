/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import junit.framework.TestCase;

/**
 * Self-contained unit tests for {@link org.apache.commons.lang.StringEscapeUtils}.
 */
public class StringEscapeUtilsAgentTest extends TestCase {

    public StringEscapeUtilsAgentTest(String name) {
        super(name);
    }

    // escapeJava / escapeJavaScript
    //-----------------------------------------------------------------------

    public void testEscapeJavaNull() {
        assertNull(StringEscapeUtils.escapeJava(null));
    }

    public void testEscapeJavaEmpty() {
        assertEquals("", StringEscapeUtils.escapeJava(""));
    }

    public void testEscapeJavaBasic() {
        assertEquals("He didn't say, \\\"Stop!\\\"",
                StringEscapeUtils.escapeJava("He didn't say, \"Stop!\""));
    }

    public void testEscapeJavaControlChars() {
        assertEquals("\\t\\n\\r\\f\\b", StringEscapeUtils.escapeJava("\t\n\r\f\b"));
    }

    public void testEscapeJavaBackslashAndSlash() {
        assertEquals("a\\\\b\\/c", StringEscapeUtils.escapeJava("a\\b/c"));
    }

    public void testEscapeJavaSingleQuoteNotEscaped() {
        // Java strings do not need single quotes escaped
        assertEquals("'", StringEscapeUtils.escapeJava("'"));
    }

    public void testEscapeJavaUnicode() {
        assertEquals("\\u00E9", StringEscapeUtils.escapeJava("é"));
    }

    public void testEscapeJavaScriptSingleQuoteEscaped() {
        // JavaScript strings do need single quotes escaped
        assertEquals("\\'", StringEscapeUtils.escapeJavaScript("'"));
    }

    public void testEscapeJavaScriptNull() {
        assertNull(StringEscapeUtils.escapeJavaScript(null));
    }

    public void testEscapeJavaWriterNullArgThrows() {
        try {
            StringEscapeUtils.escapeJava((Writer) null, "abc");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        } catch (IOException e) {
            fail("Expected IllegalArgumentException, got IOException");
        }
    }

    public void testEscapeJavaWriterNullStringNoOp() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.escapeJava(writer, null);
        assertEquals("", writer.toString());
    }

    public void testEscapeJavaScriptWriterNullArgThrows() {
        try {
            StringEscapeUtils.escapeJavaScript((Writer) null, "abc");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        } catch (IOException e) {
            fail("Expected IllegalArgumentException, got IOException");
        }
    }

    // unescapeJava / unescapeJavaScript
    //-----------------------------------------------------------------------

    public void testUnescapeJavaNull() {
        assertNull(StringEscapeUtils.unescapeJava(null));
    }

    public void testUnescapeJavaEmpty() {
        assertEquals("", StringEscapeUtils.unescapeJava(""));
    }

    public void testUnescapeJavaBasic() {
        assertEquals("He didn't say, \"Stop!\"",
                StringEscapeUtils.unescapeJava("He didn't say, \\\"Stop!\\\""));
    }

    public void testUnescapeJavaControlChars() {
        assertEquals("\t\n\r\f\b", StringEscapeUtils.unescapeJava("\\t\\n\\r\\f\\b"));
    }

    public void testUnescapeJavaUnicode() {
        assertEquals("é", StringEscapeUtils.unescapeJava("\\u00E9"));
    }

    public void testUnescapeJavaTrailingBackslash() {
        // a lone trailing backslash is output as-is
        assertEquals("abc\\", StringEscapeUtils.unescapeJava("abc\\"));
    }

    public void testUnescapeJavaUnknownEscapeKeepsChar() {
        assertEquals("az", StringEscapeUtils.unescapeJava("a\\z"));
    }

    public void testUnescapeJavaInvalidUnicodeThrows() {
        try {
            StringEscapeUtils.unescapeJava("\\u00zz");
            fail("Expected NestableRuntimeException for invalid unicode escape");
        } catch (RuntimeException e) {
            // expected - invalid hex digits in unicode escape
        }
    }

    public void testUnescapeJavaWriterNullArgThrows() {
        try {
            StringEscapeUtils.unescapeJava((Writer) null, "abc");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        } catch (IOException e) {
            fail("Expected IllegalArgumentException, got IOException");
        }
    }

    public void testUnescapeJavaScriptDelegatesToJava() {
        assertEquals(StringEscapeUtils.unescapeJava("a\\tb"),
                StringEscapeUtils.unescapeJavaScript("a\\tb"));
    }

    public void testUnescapeJavaScriptWriterNullArgThrows() {
        try {
            StringEscapeUtils.unescapeJavaScript((Writer) null, "abc");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        } catch (IOException e) {
            fail("Expected IllegalArgumentException, got IOException");
        }
    }

    // escapeHtml / unescapeHtml
    //-----------------------------------------------------------------------

    public void testEscapeHtmlNull() {
        assertNull(StringEscapeUtils.escapeHtml(null));
    }

    public void testEscapeHtmlEmpty() {
        assertEquals("", StringEscapeUtils.escapeHtml(""));
    }

    public void testEscapeHtmlBasic() {
        assertEquals("&quot;bread&quot; &amp; &quot;butter&quot;",
                StringEscapeUtils.escapeHtml("\"bread\" & \"butter\""));
    }

    public void testEscapeHtmlLessGreaterThan() {
        assertEquals("&lt;foo&gt;", StringEscapeUtils.escapeHtml("<foo>"));
    }

    public void testEscapeHtmlApostropheNotEscaped() {
        // apostrophe is deliberately NOT supported by escapeHtml
        assertEquals("McHale's", StringEscapeUtils.escapeHtml("McHale's"));
    }

    public void testEscapeHtmlAccentedChar() {
        assertEquals("&eacute;", StringEscapeUtils.escapeHtml("é"));
    }

    public void testEscapeHtmlWriterNullArgThrows() {
        try {
            StringEscapeUtils.escapeHtml((Writer) null, "abc");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        } catch (IOException e) {
            fail("Expected IllegalArgumentException, got IOException");
        }
    }

    public void testEscapeHtmlWriterNullStringNoOp() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.escapeHtml(writer, null);
        assertEquals("", writer.toString());
    }

    public void testUnescapeHtmlNull() {
        assertNull(StringEscapeUtils.unescapeHtml(null));
    }

    public void testUnescapeHtmlEmpty() {
        assertEquals("", StringEscapeUtils.unescapeHtml(""));
    }

    public void testUnescapeHtmlBasic() {
        assertEquals("<Français>", StringEscapeUtils.unescapeHtml("&lt;Fran&ccedil;ais&gt;"));
    }

    public void testUnescapeHtmlUnknownEntityLeftVerbatim() {
        assertEquals(">&zzzz;x", StringEscapeUtils.unescapeHtml("&gt;&zzzz;x"));
    }

    public void testUnescapeHtmlNumericEntity() {
        assertEquals("A", StringEscapeUtils.unescapeHtml("&#65;"));
    }

    public void testUnescapeHtmlWriterNullArgThrows() {
        try {
            StringEscapeUtils.unescapeHtml((Writer) null, "abc");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        } catch (IOException e) {
            fail("Expected IllegalArgumentException, got IOException");
        }
    }

    // escapeXml / unescapeXml
    //-----------------------------------------------------------------------

    public void testEscapeXmlNull() {
        assertNull(StringEscapeUtils.escapeXml(null));
    }

    public void testEscapeXmlEmpty() {
        assertEquals("", StringEscapeUtils.escapeXml(""));
    }

    public void testEscapeXmlBasic() {
        assertEquals("&quot;bread&quot; &amp; &quot;butter&quot;",
                StringEscapeUtils.escapeXml("\"bread\" & \"butter\""));
    }

    public void testEscapeXmlApostropheEscaped() {
        // unlike HTML, XML does support the apostrophe entity
        assertEquals("McHale&apos;s", StringEscapeUtils.escapeXml("McHale's"));
    }

    public void testEscapeXmlLessGreaterThan() {
        assertEquals("&lt;foo&gt;", StringEscapeUtils.escapeXml("<foo>"));
    }

    public void testEscapeXmlWriterNullArgThrows() {
        try {
            StringEscapeUtils.escapeXml((Writer) null, "abc");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        } catch (IOException e) {
            fail("Expected IllegalArgumentException, got IOException");
        }
    }

    public void testEscapeXmlWriterNullStringNoOp() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.escapeXml(writer, null);
        assertEquals("", writer.toString());
    }

    public void testUnescapeXmlNull() {
        assertNull(StringEscapeUtils.unescapeXml(null));
    }

    public void testUnescapeXmlEmpty() {
        assertEquals("", StringEscapeUtils.unescapeXml(""));
    }

    public void testUnescapeXmlBasic() {
        assertEquals("\"bread\" & \"butter\"",
                StringEscapeUtils.unescapeXml("&quot;bread&quot; &amp; &quot;butter&quot;"));
    }

    public void testUnescapeXmlApostrophe() {
        assertEquals("McHale's", StringEscapeUtils.unescapeXml("McHale&apos;s"));
    }

    public void testUnescapeXmlWriterNullArgThrows() {
        try {
            StringEscapeUtils.unescapeXml((Writer) null, "abc");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        } catch (IOException e) {
            fail("Expected IllegalArgumentException, got IOException");
        }
    }

    // escapeSql
    //-----------------------------------------------------------------------

    public void testEscapeSqlNull() {
        assertNull(StringEscapeUtils.escapeSql(null));
    }

    public void testEscapeSqlEmpty() {
        assertEquals("", StringEscapeUtils.escapeSql(""));
    }

    public void testEscapeSqlNoQuotesUnchanged() {
        assertEquals("abc", StringEscapeUtils.escapeSql("abc"));
    }

    public void testEscapeSqlDoublesSingleQuotes() {
        assertEquals("McHale''s Navy", StringEscapeUtils.escapeSql("McHale's Navy"));
    }

    public void testEscapeSqlMultipleQuotes() {
        assertEquals("''''", StringEscapeUtils.escapeSql("''"));
    }

    // round trips
    //-----------------------------------------------------------------------

    public void testEscapeUnescapeJavaRoundTrip() {
        String original = "Tab:\t Newline:\n Quote:\" Backslash:\\ Unicode:é";
        String escaped = StringEscapeUtils.escapeJava(original);
        assertEquals(original, StringEscapeUtils.unescapeJava(escaped));
    }

    public void testEscapeUnescapeHtmlRoundTrip() {
        String original = "<a href=\"test\">Français & Co</a>";
        String escaped = StringEscapeUtils.escapeHtml(original);
        assertEquals(original, StringEscapeUtils.unescapeHtml(escaped));
    }

    public void testEscapeUnescapeXmlRoundTrip() {
        String original = "<a href='test'>bread & butter</a>";
        String escaped = StringEscapeUtils.escapeXml(original);
        assertEquals(original, StringEscapeUtils.unescapeXml(escaped));
    }

    // constructor
    //-----------------------------------------------------------------------

    public void testConstructorIsPublic() {
        // the constructor is public to permit tools requiring a JavaBean instance
        assertNotNull(new StringEscapeUtils());
    }
}
