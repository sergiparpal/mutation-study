package org.apache.commons.lang3;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class SerializationUtilsAgentTest {

    private static class Box implements Serializable {
        private static final long serialVersionUID = 1L;
        private final int value;
        private final List<String> items;

        Box(int value, List<String> items) {
            this.value = value;
            this.items = items;
        }

        public boolean equals(Object o) {
            if (!(o instanceof Box)) {
                return false;
            }
            Box other = (Box) o;
            return value == other.value && items.equals(other.items);
        }

        public int hashCode() {
            return value;
        }
    }

    private static class CloseTrackingOutputStream extends OutputStream {
        private final ByteArrayOutputStream delegate = new ByteArrayOutputStream();
        private boolean closed = false;

        public void write(int b) throws IOException {
            delegate.write(b);
        }

        public void close() throws IOException {
            closed = true;
            delegate.close();
        }

        byte[] toByteArray() {
            return delegate.toByteArray();
        }

        boolean isClosed() {
            return closed;
        }
    }

    private static class CloseTrackingInputStream extends InputStream {
        private final ByteArrayInputStream delegate;
        private boolean closed = false;

        CloseTrackingInputStream(byte[] data) {
            delegate = new ByteArrayInputStream(data);
        }

        public int read() throws IOException {
            return delegate.read();
        }

        public void close() throws IOException {
            closed = true;
            delegate.close();
        }

        boolean isClosed() {
            return closed;
        }
    }

    // ---- constructor ----

    @Test
    public void testConstructorIsPublic() {
        assertNotNull(new SerializationUtils());
    }

    // ---- clone ----

    @Test
    public void testCloneSimpleObjectIsEqual() {
        String original = "hello world";
        String cloned = SerializationUtils.clone(original);
        assertEquals(original, cloned);
    }

    @Test
    public void testCloneProducesIndependentDeepCopy() {
        List<String> items = new ArrayList<String>();
        items.add("a");
        Box original = new Box(42, items);

        Box cloned = SerializationUtils.clone(original);

        assertEquals(original, cloned);
        assertNotSame(original, cloned);
        assertNotSame(original.items, cloned.items);

        cloned.items.add("b");
        assertEquals(1, original.items.size());
        assertEquals(2, cloned.items.size());
    }

    @Test
    public void testCloneNullReturnsNull() {
        Serializable cloned = SerializationUtils.<Serializable>clone(null);
        assertNull(cloned);
    }

    // ---- serialize(Serializable) ----

    @Test
    public void testSerializeReturnsNonEmptyByteArray() {
        byte[] data = SerializationUtils.serialize("abc");
        assertNotNull(data);
        assertTrue(data.length > 0);
    }

    @Test
    public void testSerializeThenDeserializeRoundTrip() {
        List<String> items = new ArrayList<String>();
        items.add("x");
        items.add("y");
        Box original = new Box(7, items);

        byte[] data = SerializationUtils.serialize(original);
        Object result = SerializationUtils.deserialize(data);

        assertEquals(original, result);
    }

    @Test
    public void testSerializeNullObjectRoundTripsToNull() {
        byte[] data = SerializationUtils.serialize(null);
        assertNotNull(data);
        Object result = SerializationUtils.deserialize(data);
        assertNull(result);
    }

    // ---- serialize(Serializable, OutputStream) ----

    @Test
    public void testSerializeToStreamWritesRoundTrippableData() {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        SerializationUtils.serialize("hello", baos);
        byte[] written = baos.toByteArray();
        assertTrue(written.length > 0);

        Object result = SerializationUtils.deserialize(written);
        assertEquals("hello", result);
    }

    @Test
    public void testSerializeToStreamClosesStream() {
        CloseTrackingOutputStream out = new CloseTrackingOutputStream();
        SerializationUtils.serialize("hello", out);
        assertTrue(out.isClosed());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testSerializeToNullStreamThrowsIllegalArgumentException() {
        SerializationUtils.serialize("hello", null);
    }

    @Test
    public void testSerializeNullObjectToStreamRoundTripsToNull() {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        SerializationUtils.serialize(null, baos);
        Object result = SerializationUtils.deserialize(baos.toByteArray());
        assertNull(result);
    }

    // ---- deserialize(byte[]) ----

    @Test(expected = IllegalArgumentException.class)
    public void testDeserializeNullByteArrayThrowsIllegalArgumentException() {
        SerializationUtils.deserialize((byte[]) null);
    }

    @Test(expected = SerializationException.class)
    public void testDeserializeEmptyByteArrayThrowsSerializationException() {
        SerializationUtils.deserialize(new byte[0]);
    }

    @Test(expected = SerializationException.class)
    public void testDeserializeGarbageByteArrayThrowsSerializationException() {
        SerializationUtils.deserialize(new byte[] {1, 2, 3, 4, 5});
    }

    // ---- deserialize(InputStream) ----

    @Test(expected = IllegalArgumentException.class)
    public void testDeserializeNullStreamThrowsIllegalArgumentException() {
        SerializationUtils.deserialize((InputStream) null);
    }

    @Test
    public void testDeserializeFromStreamReturnsObjectAndClosesStream() {
        byte[] data = SerializationUtils.serialize("closeme");
        CloseTrackingInputStream in = new CloseTrackingInputStream(data);

        Object result = SerializationUtils.deserialize((InputStream) in);

        assertEquals("closeme", result);
        assertTrue(in.isClosed());
    }

    @Test(expected = SerializationException.class)
    public void testDeserializeGarbageStreamThrowsSerializationException() {
        ByteArrayInputStream in = new ByteArrayInputStream(new byte[] {9, 9, 9});
        SerializationUtils.deserialize((InputStream) in);
    }
}
