/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.cli;

import junit.framework.TestCase;

/**
 * Test case for the GnuParser.
 */
public class GnuParserAgentTest extends TestCase
{
    private Options options;
    private GnuParser parser;

    public void setUp()
    {
        options = new Options()
            .addOption("a", "enable-a", false, "turn [a] on or off")
            .addOption("b", "bfile", true, "set the value of [b]")
            .addOption("c", "copt", false, "turn [c] on or off")
            .addOption("D", true, "use value for property");

        parser = new GnuParser();
    }

    public void testFlattenEmptyArray()
    {
        String[] result = parser.flatten(options, new String[0], false);
        assertEquals("flatten of empty array returns empty array", 0, result.length);
    }

    public void testFlattenDoubleDash()
    {
        String[] args = new String[] { "--", "-b", "toast" };

        String[] result = parser.flatten(options, args, false);

        assertEquals(3, result.length);
        assertEquals("--", result[0]);
        assertEquals("-b", result[1]);
        assertEquals("toast", result[2]);
    }

    public void testFlattenSingleDashIsKeptAsIs()
    {
        String[] args = new String[] { "-" };

        String[] result = parser.flatten(options, args, false);

        assertEquals(1, result.length);
        assertEquals("-", result[0]);
    }

    public void testFlattenKnownShortOption()
    {
        String[] args = new String[] { "-a", "foo" };

        String[] result = parser.flatten(options, args, false);

        assertEquals(2, result.length);
        assertEquals("-a", result[0]);
        assertEquals("foo", result[1]);
    }

    public void testFlattenLongOptionWithEqualsSign()
    {
        String[] args = new String[] { "--bfile=toast" };

        String[] result = parser.flatten(options, args, false);

        assertEquals("--foo=value is split into two tokens", 2, result.length);
        assertEquals("--bfile", result[0]);
        assertEquals("toast", result[1]);
    }

    public void testFlattenPropertyStyleOption()
    {
        // "-D" is a known option, "Dproperty=value" is not and has no '='
        // match for the whole "Dproperty" segment, so it falls back to the
        // "-D" + "property=value" split.
        String[] args = new String[] { "-Dproperty=value" };

        String[] result = parser.flatten(options, args, false);

        assertEquals(2, result.length);
        assertEquals("-D", result[0]);
        assertEquals("property=value", result[1]);
    }

    public void testFlattenUnknownOptionKeptWhole()
    {
        // neither "-z" nor "-z".substring(0,2) resolve to a known option
        String[] args = new String[] { "-z", "foo" };

        String[] result = parser.flatten(options, args, false);

        assertEquals(2, result.length);
        assertEquals("-z", result[0]);
        assertEquals("foo", result[1]);
    }

    public void testFlattenStopAtNonOptionEatsRest()
    {
        String[] args = new String[] { "-z", "foo", "-a" };

        String[] result = parser.flatten(options, args, true);

        assertEquals(3, result.length);
        assertEquals("-z", result[0]);
        assertEquals("foo", result[1]);
        assertEquals("-a", result[2]);
    }

    public void testSimpleShort() throws Exception
    {
        String[] args = new String[] { "-a", "-b", "toast", "foo", "bar" };

        CommandLine cl = parser.parse(options, args);

        assertTrue("Confirm -a is set", cl.hasOption("a"));
        assertTrue("Confirm -b is set", cl.hasOption("b"));
        assertEquals("Confirm arg of -b", "toast", cl.getOptionValue("b"));
        assertEquals("Confirm size of extra args", 2, cl.getArgList().size());
    }

    public void testSimpleLong() throws Exception
    {
        String[] args = new String[] { "--enable-a", "--bfile", "toast", "foo", "bar" };

        CommandLine cl = parser.parse(options, args);

        assertTrue("Confirm -a is set", cl.hasOption("a"));
        assertTrue("Confirm -b is set", cl.hasOption("b"));
        assertEquals("Confirm arg of -b", "toast", cl.getOptionValue("b"));
        assertEquals("Confirm arg of --bfile", "toast", cl.getOptionValue("bfile"));
        assertEquals("Confirm size of extra args", 2, cl.getArgList().size());
    }

    public void testLongWithEqualsSign() throws Exception
    {
        String[] args = new String[] { "--bfile=toast", "foo" };

        CommandLine cl = parser.parse(options, args);

        assertTrue("Confirm -b is set", cl.hasOption("b"));
        assertEquals("Confirm arg of -b", "toast", cl.getOptionValue("b"));
        assertEquals("Confirm size of extra args", 1, cl.getArgList().size());
        assertEquals("foo", cl.getArgList().get(0));
    }

    public void testPropertyOption() throws Exception
    {
        String[] args = new String[] { "-Dproperty=value" };

        CommandLine cl = parser.parse(options, args);

        assertTrue("Confirm -D is set", cl.hasOption("D"));
        assertEquals("property=value", cl.getOptionValue("D"));
        assertEquals("Confirm no extra args", 0, cl.getArgList().size());
    }

    public void testDoubleDash() throws Exception
    {
        String[] args = new String[] { "--copt", "--", "-b", "toast" };

        CommandLine cl = parser.parse(options, args);

        assertTrue("Confirm -c is set", cl.hasOption("c"));
        assertFalse("Confirm -b is not set", cl.hasOption("b"));
        assertEquals("Confirm 2 extra args", 2, cl.getArgList().size());
    }

    public void testSingleDash() throws Exception
    {
        String[] args = new String[] { "--copt", "-b", "-", "-a", "-" };

        CommandLine cl = parser.parse(options, args);

        assertTrue("Confirm -a is set", cl.hasOption("a"));
        assertTrue("Confirm -b is set", cl.hasOption("b"));
        assertEquals("Confirm arg of -b", "-", cl.getOptionValue("b"));
        assertEquals("Confirm 1 extra arg", 1, cl.getArgList().size());
        assertEquals("-", cl.getArgList().get(0));
    }

    public void testUnrecognizedOption() throws Exception
    {
        String[] args = new String[] { "-z" };

        boolean caught = false;
        try
        {
            parser.parse(options, args);
        }
        catch (UnrecognizedOptionException e)
        {
            caught = true;
        }

        assertTrue("Confirm UnrecognizedOptionException caught", caught);
    }

    public void testMissingArgument() throws Exception
    {
        String[] args = new String[] { "-b" };

        boolean caught = false;
        try
        {
            parser.parse(options, args);
        }
        catch (MissingArgumentException e)
        {
            caught = true;
        }

        assertTrue("Confirm MissingArgumentException caught", caught);
    }

    public void testMissingRequiredOption() throws Exception
    {
        Options reqOptions = new Options()
            .addOption(OptionBuilder.withLongOpt("required").isRequired().create("r"));

        boolean caught = false;
        try
        {
            parser.parse(reqOptions, new String[0]);
        }
        catch (MissingOptionException e)
        {
            caught = true;
            assertTrue(e.getMessage().indexOf("r") >= 0);
        }

        assertTrue("Confirm MissingOptionException caught", caught);
    }

    public void testStopAtNonOption() throws Exception
    {
        // "foober" is the first non-option token; once encountered with
        // stopAtNonOption, everything that follows (including "-btoast",
        // itself flattened into "-b" "toast") is swallowed as plain args.
        String[] args = new String[] { "-c", "foober", "-btoast" };

        CommandLine cl = parser.parse(options, args, true);

        assertTrue("Confirm -c is set", cl.hasOption("c"));
        assertEquals("Confirm 3 extra args", 3, cl.getArgList().size());
        assertEquals("foober", cl.getArgList().get(0));
        assertEquals("-b", cl.getArgList().get(1));
        assertEquals("toast", cl.getArgList().get(2));
    }

    public void testNullArguments() throws Exception
    {
        CommandLine cl = parser.parse(options, null);

        assertFalse(cl.hasOption("a"));
        assertEquals(0, cl.getArgList().size());
    }

    public void testEmptyArguments() throws Exception
    {
        CommandLine cl = parser.parse(options, new String[0]);

        assertFalse(cl.hasOption("a"));
        assertEquals(0, cl.getArgList().size());
        assertEquals(0, cl.getArgs().length);
    }
}
