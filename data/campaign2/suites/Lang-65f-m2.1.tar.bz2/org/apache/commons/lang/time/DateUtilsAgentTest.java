/*
 * Copyright 2002-2005 The Apache Software Foundation.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang.time;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.NoSuchElementException;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Self-contained unit tests for {@link org.apache.commons.lang.time.DateUtils}.
 */
public class DateUtilsAgentTest extends TestCase {

    public DateUtilsAgentTest(String name) {
        super(name);
    }

    public static Test suite() {
        return new TestSuite(DateUtilsAgentTest.class);
    }

    private Calendar newCalendar(int year, int month, int day, int hour, int min, int sec, int millis) {
        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(year, month, day, hour, min, sec);
        cal.set(Calendar.MILLISECOND, millis);
        return cal;
    }

    //-----------------------------------------------------------------------
    // isSameDay(Date, Date)
    //-----------------------------------------------------------------------

    public void testIsSameDayDateTrue() {
        Date d1 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 0, 0).getTime();
        Date d2 = newCalendar(2002, Calendar.MARCH, 28, 6, 1, 0, 0).getTime();
        assertTrue(DateUtils.isSameDay(d1, d2));
    }

    public void testIsSameDayDateFalse() {
        Date d1 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 0, 0).getTime();
        Date d2 = newCalendar(2002, Calendar.MARCH, 12, 13, 45, 0, 0).getTime();
        assertFalse(DateUtils.isSameDay(d1, d2));
    }

    public void testIsSameDayDateNull() {
        Date d1 = new Date();
        try {
            DateUtils.isSameDay(d1, null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
        try {
            DateUtils.isSameDay(null, d1);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
        try {
            DateUtils.isSameDay((Date) null, (Date) null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // isSameDay(Calendar, Calendar)
    //-----------------------------------------------------------------------

    public void testIsSameDayCalendarTrue() {
        Calendar c1 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        Calendar c2 = newCalendar(2002, Calendar.MARCH, 28, 6, 1, 0, 0);
        assertTrue(DateUtils.isSameDay(c1, c2));
    }

    public void testIsSameDayCalendarFalse() {
        Calendar c1 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        Calendar c2 = newCalendar(2003, Calendar.MARCH, 28, 13, 45, 0, 0);
        assertFalse(DateUtils.isSameDay(c1, c2));
    }

    public void testIsSameDayCalendarNull() {
        Calendar c1 = Calendar.getInstance();
        try {
            DateUtils.isSameDay((Calendar) null, c1);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // isSameInstant
    //-----------------------------------------------------------------------

    public void testIsSameInstantDate() {
        Date d1 = new Date(1000L);
        Date d2 = new Date(1000L);
        Date d3 = new Date(1001L);
        assertTrue(DateUtils.isSameInstant(d1, d2));
        assertFalse(DateUtils.isSameInstant(d1, d3));
    }

    public void testIsSameInstantDateNull() {
        try {
            DateUtils.isSameInstant(null, new Date());
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testIsSameInstantCalendar() {
        Calendar c1 = Calendar.getInstance();
        c1.setTimeInMillis(5000L);
        Calendar c2 = Calendar.getInstance();
        c2.setTimeInMillis(5000L);
        Calendar c3 = Calendar.getInstance();
        c3.setTimeInMillis(6000L);
        assertTrue(DateUtils.isSameInstant(c1, c2));
        assertFalse(DateUtils.isSameInstant(c1, c3));
    }

    public void testIsSameInstantCalendarNull() {
        try {
            DateUtils.isSameInstant((Calendar) null, Calendar.getInstance());
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // isSameLocalTime
    //-----------------------------------------------------------------------

    public void testIsSameLocalTimeTrue() {
        Calendar c1 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 10, 20);
        Calendar c2 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 10, 20);
        assertTrue(DateUtils.isSameLocalTime(c1, c2));
    }

    public void testIsSameLocalTimeFalseDifferentClass() {
        Calendar c1 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 10, 20);
        Calendar c2 = new java.util.GregorianCalendar();
        c2.setTime(c1.getTime());
        assertTrue(DateUtils.isSameLocalTime(c1, c2));
        Calendar c3 = new java.util.GregorianCalendar() {
            // anonymous subclass to differ in getClass()
        };
        c3.setTime(c1.getTime());
        assertFalse(DateUtils.isSameLocalTime(c1, c3));
    }

    public void testIsSameLocalTimeNull() {
        try {
            DateUtils.isSameLocalTime(null, Calendar.getInstance());
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // parseDate
    //-----------------------------------------------------------------------

    public void testParseDateSuccess() throws Exception {
        Date date = DateUtils.parseDate("2002-03-28", new String[] { "yyyy-MM-dd" });
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        assertEquals(2002, cal.get(Calendar.YEAR));
        assertEquals(Calendar.MARCH, cal.get(Calendar.MONTH));
        assertEquals(28, cal.get(Calendar.DAY_OF_MONTH));
    }

    public void testParseDateMultiplePatternsSecondMatches() throws Exception {
        Date date = DateUtils.parseDate("28.03.2002", new String[] { "yyyy-MM-dd", "dd.MM.yyyy" });
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        assertEquals(2002, cal.get(Calendar.YEAR));
        assertEquals(Calendar.MARCH, cal.get(Calendar.MONTH));
        assertEquals(28, cal.get(Calendar.DAY_OF_MONTH));
    }

    public void testParseDateNoPatternMatches() {
        try {
            DateUtils.parseDate("not a date", new String[] { "yyyy-MM-dd" });
            fail("Expected ParseException");
        } catch (ParseException e) {
            // expected
        }
    }

    public void testParseDatePartialMatchFails() {
        // the parser must consume the whole string
        try {
            DateUtils.parseDate("2002-03-28extra", new String[] { "yyyy-MM-dd" });
            fail("Expected ParseException");
        } catch (ParseException e) {
            // expected
        }
    }

    public void testParseDateNullArgs() {
        try {
            DateUtils.parseDate(null, new String[] { "yyyy-MM-dd" });
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        } catch (ParseException e) {
            fail("Expected IllegalArgumentException, not ParseException");
        }
        try {
            DateUtils.parseDate("2002-03-28", null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        } catch (ParseException e) {
            fail("Expected IllegalArgumentException, not ParseException");
        }
    }

    //-----------------------------------------------------------------------
    // add* methods
    //-----------------------------------------------------------------------

    public void testAddYears() {
        Date base = newCalendar(2000, Calendar.JANUARY, 1, 0, 0, 0, 0).getTime();
        Date result = DateUtils.addYears(base, 1);
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(2001, cal.get(Calendar.YEAR));
        // original unchanged
        Calendar baseCal = Calendar.getInstance();
        baseCal.setTime(base);
        assertEquals(2000, baseCal.get(Calendar.YEAR));
    }

    public void testAddMonthsNegative() {
        Date base = newCalendar(2000, Calendar.JANUARY, 1, 0, 0, 0, 0).getTime();
        Date result = DateUtils.addMonths(base, -1);
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(1999, cal.get(Calendar.YEAR));
        assertEquals(Calendar.DECEMBER, cal.get(Calendar.MONTH));
    }

    public void testAddWeeks() {
        Date base = newCalendar(2002, Calendar.MARCH, 28, 0, 0, 0, 0).getTime();
        Date result = DateUtils.addWeeks(base, 1);
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(4, cal.get(Calendar.DAY_OF_MONTH));
        assertEquals(Calendar.APRIL, cal.get(Calendar.MONTH));
    }

    public void testAddDays() {
        Date base = newCalendar(2002, Calendar.MARCH, 28, 0, 0, 0, 0).getTime();
        Date result = DateUtils.addDays(base, 5);
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(2, cal.get(Calendar.DAY_OF_MONTH));
        assertEquals(Calendar.APRIL, cal.get(Calendar.MONTH));
    }

    public void testAddHours() {
        Date base = newCalendar(2002, Calendar.MARCH, 28, 23, 0, 0, 0).getTime();
        Date result = DateUtils.addHours(base, 2);
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(1, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals(29, cal.get(Calendar.DAY_OF_MONTH));
    }

    public void testAddMinutes() {
        Date base = newCalendar(2002, Calendar.MARCH, 28, 0, 59, 0, 0).getTime();
        Date result = DateUtils.addMinutes(base, 2);
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(1, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals(1, cal.get(Calendar.MINUTE));
    }

    public void testAddSeconds() {
        Date base = newCalendar(2002, Calendar.MARCH, 28, 0, 0, 59, 0).getTime();
        Date result = DateUtils.addSeconds(base, 2);
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(1, cal.get(Calendar.MINUTE));
        assertEquals(1, cal.get(Calendar.SECOND));
    }

    public void testAddMilliseconds() {
        Date base = new Date(1000L);
        Date result = DateUtils.addMilliseconds(base, 500);
        assertEquals(1500L, result.getTime());
    }

    public void testAddNullDate() {
        try {
            DateUtils.addYears(null, 1);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
        try {
            DateUtils.add(null, Calendar.YEAR, 1);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testAddZeroAmountReturnsEquivalentDate() {
        Date base = newCalendar(2002, Calendar.MARCH, 28, 10, 20, 30, 40).getTime();
        Date result = DateUtils.add(base, Calendar.DATE, 0);
        assertEquals(base.getTime(), result.getTime());
    }

    //-----------------------------------------------------------------------
    // round(Date, int)
    //-----------------------------------------------------------------------

    public void testRoundDateHourUp() {
        Date base = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231).getTime();
        Date result = DateUtils.round(base, Calendar.HOUR_OF_DAY);
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(14, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, cal.get(Calendar.MINUTE));
        assertEquals(0, cal.get(Calendar.SECOND));
        assertEquals(0, cal.get(Calendar.MILLISECOND));
    }

    public void testRoundDateMonthUp() {
        Date base = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231).getTime();
        Date result = DateUtils.round(base, Calendar.MONTH);
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(2002, cal.get(Calendar.YEAR));
        assertEquals(Calendar.APRIL, cal.get(Calendar.MONTH));
        assertEquals(1, cal.get(Calendar.DAY_OF_MONTH));
        assertEquals(0, cal.get(Calendar.HOUR_OF_DAY));
    }

    public void testRoundDateMonthDown() {
        Date base = newCalendar(2002, Calendar.MARCH, 10, 0, 0, 0, 0).getTime();
        Date result = DateUtils.round(base, Calendar.MONTH);
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(Calendar.MARCH, cal.get(Calendar.MONTH));
        assertEquals(1, cal.get(Calendar.DAY_OF_MONTH));
    }

    public void testRoundDateNull() {
        try {
            DateUtils.round((Date) null, Calendar.YEAR);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testRoundInvalidField() {
        Date base = new Date();
        try {
            DateUtils.round(base, -9999);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testRoundCalendarReturnsDifferentObject() {
        Calendar base = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar result = DateUtils.round(base, Calendar.HOUR_OF_DAY);
        assertNotSame(base, result);
        // original unaffected
        assertEquals(45, base.get(Calendar.MINUTE));
        assertEquals(14, result.get(Calendar.HOUR_OF_DAY));
    }

    public void testRoundCalendarNull() {
        try {
            DateUtils.round((Calendar) null, Calendar.YEAR);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testRoundObjectDate() {
        Date base = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231).getTime();
        Date result = DateUtils.round((Object) base, Calendar.HOUR_OF_DAY);
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(14, cal.get(Calendar.HOUR_OF_DAY));
    }

    public void testRoundObjectCalendar() {
        Calendar base = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date result = DateUtils.round((Object) base, Calendar.HOUR_OF_DAY);
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(14, cal.get(Calendar.HOUR_OF_DAY));
    }

    public void testRoundObjectInvalidType() {
        try {
            DateUtils.round("not a date", Calendar.YEAR);
            fail("Expected ClassCastException");
        } catch (ClassCastException e) {
            // expected
        }
    }

    public void testRoundObjectNull() {
        try {
            DateUtils.round((Object) null, Calendar.YEAR);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testRoundYearTooLarge() {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.YEAR, 280000001);
        try {
            DateUtils.round(cal, Calendar.HOUR_OF_DAY);
            fail("Expected ArithmeticException");
        } catch (ArithmeticException e) {
            // expected
        }
    }

    public void testRoundSemiMonthFromDayOne() {
        Date base = newCalendar(2002, Calendar.MARCH, 1, 20, 0, 0, 0).getTime();
        Date result = DateUtils.round(base, DateUtils.SEMI_MONTH);
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        // day 1, offset 0, not > 7 so rounds down to day 1
        assertEquals(1, cal.get(Calendar.DAY_OF_MONTH));
        assertEquals(0, cal.get(Calendar.HOUR_OF_DAY));
    }

    public void testRoundSemiMonthUpToSixteen() {
        Date base = newCalendar(2002, Calendar.MARCH, 10, 0, 0, 0, 0).getTime();
        Date result = DateUtils.round(base, DateUtils.SEMI_MONTH);
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        // offset = 10 - 1 = 9, roundUp = (9 > 7) = true => rounds up to 16
        assertEquals(16, cal.get(Calendar.DAY_OF_MONTH));
        assertEquals(Calendar.MARCH, cal.get(Calendar.MONTH));
    }

    //-----------------------------------------------------------------------
    // truncate
    //-----------------------------------------------------------------------

    public void testTruncateDateHour() {
        Date base = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231).getTime();
        Date result = DateUtils.truncate(base, Calendar.HOUR_OF_DAY);
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(13, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, cal.get(Calendar.MINUTE));
        assertEquals(0, cal.get(Calendar.SECOND));
        assertEquals(0, cal.get(Calendar.MILLISECOND));
    }

    public void testTruncateDateMonth() {
        Date base = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231).getTime();
        Date result = DateUtils.truncate(base, Calendar.MONTH);
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(Calendar.MARCH, cal.get(Calendar.MONTH));
        assertEquals(1, cal.get(Calendar.DAY_OF_MONTH));
        assertEquals(0, cal.get(Calendar.HOUR_OF_DAY));
    }

    public void testTruncateDateNull() {
        try {
            DateUtils.truncate((Date) null, Calendar.YEAR);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testTruncateCalendarReturnsDifferentObject() {
        Calendar base = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar result = DateUtils.truncate(base, Calendar.HOUR_OF_DAY);
        assertNotSame(base, result);
        assertEquals(45, base.get(Calendar.MINUTE));
        assertEquals(0, result.get(Calendar.MINUTE));
    }

    public void testTruncateCalendarNull() {
        try {
            DateUtils.truncate((Calendar) null, Calendar.YEAR);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testTruncateObjectDate() {
        Date base = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231).getTime();
        Date result = DateUtils.truncate((Object) base, Calendar.HOUR_OF_DAY);
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(13, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, cal.get(Calendar.MINUTE));
    }

    public void testTruncateObjectCalendar() {
        Calendar base = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date result = DateUtils.truncate((Object) base, Calendar.HOUR_OF_DAY);
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(13, cal.get(Calendar.HOUR_OF_DAY));
    }

    public void testTruncateObjectInvalidType() {
        try {
            DateUtils.truncate(new Object(), Calendar.YEAR);
            fail("Expected ClassCastException");
        } catch (ClassCastException e) {
            // expected
        }
    }

    public void testTruncateObjectNull() {
        try {
            DateUtils.truncate((Object) null, Calendar.YEAR);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testTruncateMillisecondNoOp() {
        Date base = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231).getTime();
        Date result = DateUtils.truncate(base, Calendar.MILLISECOND);
        assertEquals(base.getTime(), result.getTime());
    }

    public void testTruncateYearTooLarge() {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.YEAR, 280000001);
        try {
            DateUtils.truncate(cal, Calendar.HOUR_OF_DAY);
            fail("Expected ArithmeticException");
        } catch (ArithmeticException e) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // iterator
    //-----------------------------------------------------------------------

    public void testIteratorWeekSundayRange() {
        // Thursday, July 4, 2002
        Date focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0).getTime();
        Iterator it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        int count = 0;
        Calendar first = null;
        Calendar last = null;
        while (it.hasNext()) {
            Calendar current = (Calendar) it.next();
            if (first == null) {
                first = current;
            }
            last = current;
            count++;
        }
        assertEquals(7, count);
        assertEquals(Calendar.SUNDAY, first.get(Calendar.DAY_OF_WEEK));
        assertEquals(Calendar.SATURDAY, last.get(Calendar.DAY_OF_WEEK));
    }

    public void testIteratorMonthSundayRange() {
        // Thursday, July 4, 2002
        Date focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0).getTime();
        Iterator it = DateUtils.iterator(focus, DateUtils.RANGE_MONTH_SUNDAY);
        int count = 0;
        Calendar first = null;
        Calendar last = null;
        while (it.hasNext()) {
            Calendar current = (Calendar) it.next();
            if (first == null) {
                first = current;
            }
            last = current;
            count++;
        }
        assertEquals(2002, first.get(Calendar.YEAR));
        assertEquals(Calendar.JUNE, first.get(Calendar.MONTH));
        assertEquals(30, first.get(Calendar.DAY_OF_MONTH));
        assertEquals(Calendar.AUGUST, last.get(Calendar.MONTH));
        assertEquals(3, last.get(Calendar.DAY_OF_MONTH));
        assertTrue(count > 0);
    }

    public void testIteratorExhaustedThrowsNoSuchElementException() {
        Date focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0).getTime();
        Iterator it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        while (it.hasNext()) {
            it.next();
        }
        assertFalse(it.hasNext());
        try {
            it.next();
            fail("Expected NoSuchElementException");
        } catch (NoSuchElementException e) {
            // expected
        }
    }

    public void testIteratorRemoveUnsupported() {
        Date focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0).getTime();
        Iterator it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        try {
            it.remove();
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException e) {
            // expected
        }
    }

    public void testIteratorCalendarOverload() {
        Calendar focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        Iterator it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        assertTrue(it.hasNext());
    }

    public void testIteratorObjectOverloadDate() {
        Date focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0).getTime();
        Iterator it = DateUtils.iterator((Object) focus, DateUtils.RANGE_WEEK_SUNDAY);
        assertTrue(it.hasNext());
    }

    public void testIteratorObjectOverloadCalendar() {
        Calendar focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        Iterator it = DateUtils.iterator((Object) focus, DateUtils.RANGE_WEEK_SUNDAY);
        assertTrue(it.hasNext());
    }

    public void testIteratorObjectOverloadInvalidType() {
        try {
            DateUtils.iterator("not a date", DateUtils.RANGE_WEEK_SUNDAY);
            fail("Expected ClassCastException");
        } catch (ClassCastException e) {
            // expected
        }
    }

    public void testIteratorNullFocus() {
        try {
            DateUtils.iterator((Date) null, DateUtils.RANGE_WEEK_SUNDAY);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
        try {
            DateUtils.iterator((Calendar) null, DateUtils.RANGE_WEEK_SUNDAY);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
        try {
            DateUtils.iterator((Object) null, DateUtils.RANGE_WEEK_SUNDAY);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testIteratorInvalidRangeStyle() {
        Date focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0).getTime();
        try {
            DateUtils.iterator(focus, -9999);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // constants
    //-----------------------------------------------------------------------

    public void testMillisConstants() {
        assertEquals(1000L, DateUtils.MILLIS_PER_SECOND);
        assertEquals(60000L, DateUtils.MILLIS_PER_MINUTE);
        assertEquals(3600000L, DateUtils.MILLIS_PER_HOUR);
        assertEquals(86400000L, DateUtils.MILLIS_PER_DAY);
    }

    public void testDeprecatedMillisConstants() {
        assertEquals(1000, DateUtils.MILLIS_IN_SECOND);
        assertEquals(60000, DateUtils.MILLIS_IN_MINUTE);
        assertEquals(3600000, DateUtils.MILLIS_IN_HOUR);
        assertEquals(86400000, DateUtils.MILLIS_IN_DAY);
    }

    public void testConstructorIsPublic() {
        DateUtils du = new DateUtils();
        assertNotNull(du);
    }
}
