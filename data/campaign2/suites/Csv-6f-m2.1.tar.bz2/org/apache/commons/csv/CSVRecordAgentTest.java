/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.csv;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.junit.Test;

public class CSVRecordAgentTest {

    private Map<String, Integer> headerMap() {
        final Map<String, Integer> mapping = new HashMap<String, Integer>();
        mapping.put("A", Integer.valueOf(0));
        mapping.put("B", Integer.valueOf(1));
        mapping.put("C", Integer.valueOf(2));
        return mapping;
    }

    private enum Header {
        A, B, C
    }

    @Test
    public void testGetByIndex() {
        final String[] values = { "one", "two", "three" };
        final CSVRecord record = new CSVRecord(values, null, null, 1L);
        assertEquals("one", record.get(0));
        assertEquals("two", record.get(1));
        assertEquals("three", record.get(2));
    }

    @Test(expected = ArrayIndexOutOfBoundsException.class)
    public void testGetByIndexOutOfBounds() {
        final String[] values = { "one" };
        final CSVRecord record = new CSVRecord(values, null, null, 1L);
        record.get(1);
    }

    @Test(expected = ArrayIndexOutOfBoundsException.class)
    public void testGetByIndexNegative() {
        final String[] values = { "one" };
        final CSVRecord record = new CSVRecord(values, null, null, 1L);
        record.get(-1);
    }

    @Test
    public void testGetByName() {
        final String[] values = { "one", "two", "three" };
        final CSVRecord record = new CSVRecord(values, headerMap(), null, 1L);
        assertEquals("one", record.get("A"));
        assertEquals("two", record.get("B"));
        assertEquals("three", record.get("C"));
    }

    @Test
    public void testGetByNameNoMapping() {
        final String[] values = { "one", "two" };
        final CSVRecord record = new CSVRecord(values, null, null, 1L);
        try {
            record.get("A");
            fail("Expected IllegalStateException");
        } catch (final IllegalStateException e) {
            // expected
        }
    }

    @Test
    public void testGetByNameUnknownName() {
        final String[] values = { "one", "two", "three" };
        final CSVRecord record = new CSVRecord(values, headerMap(), null, 1L);
        try {
            record.get("Z");
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            assertTrue(e.getMessage().indexOf("Z") >= 0);
        }
    }

    @Test
    public void testGetByNameInconsistentRecord() {
        // mapping has 3 entries, but the record only has 2 values
        final String[] values = { "one", "two" };
        final CSVRecord record = new CSVRecord(values, headerMap(), null, 1L);
        try {
            record.get("C");
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            assertTrue(e.getMessage().indexOf("C") >= 0);
        }
    }

    @Test
    public void testGetByEnum() {
        final String[] values = { "one", "two", "three" };
        final CSVRecord record = new CSVRecord(values, headerMap(), null, 1L);
        assertEquals("one", record.get(Header.A));
        assertEquals("three", record.get(Header.C));
    }

    @Test
    public void testGetComment() {
        final String[] values = { "one" };
        final CSVRecord record = new CSVRecord(values, null, "a comment", 1L);
        assertEquals("a comment", record.getComment());
    }

    @Test
    public void testGetCommentNull() {
        final String[] values = { "one" };
        final CSVRecord record = new CSVRecord(values, null, null, 1L);
        assertNull(record.getComment());
    }

    @Test
    public void testGetRecordNumber() {
        final String[] values = { "one" };
        final CSVRecord record = new CSVRecord(values, null, null, 42L);
        assertEquals(42L, record.getRecordNumber());
    }

    @Test
    public void testIsConsistentNoMapping() {
        final String[] values = { "one", "two" };
        final CSVRecord record = new CSVRecord(values, null, null, 1L);
        assertTrue(record.isConsistent());
    }

    @Test
    public void testIsConsistentMatchingMapping() {
        final String[] values = { "one", "two", "three" };
        final CSVRecord record = new CSVRecord(values, headerMap(), null, 1L);
        assertTrue(record.isConsistent());
    }

    @Test
    public void testIsConsistentMismatchedMapping() {
        final String[] values = { "one", "two" };
        final CSVRecord record = new CSVRecord(values, headerMap(), null, 1L);
        assertFalse(record.isConsistent());
    }

    @Test
    public void testIsMapped() {
        final String[] values = { "one", "two", "three" };
        final CSVRecord record = new CSVRecord(values, headerMap(), null, 1L);
        assertTrue(record.isMapped("A"));
        assertFalse(record.isMapped("Z"));
    }

    @Test
    public void testIsMappedNoMapping() {
        final String[] values = { "one" };
        final CSVRecord record = new CSVRecord(values, null, null, 1L);
        assertFalse(record.isMapped("A"));
    }

    @Test
    public void testIsSet() {
        final String[] values = { "one", "two" };
        final CSVRecord record = new CSVRecord(values, headerMap(), null, 1L);
        assertTrue(record.isSet("A"));
        assertTrue(record.isSet("B"));
        // "C" is mapped to index 2, but there are only 2 values
        assertFalse(record.isSet("C"));
        assertFalse(record.isSet("Z"));
    }

    @Test
    public void testIsSetNoMapping() {
        final String[] values = { "one" };
        final CSVRecord record = new CSVRecord(values, null, null, 1L);
        assertFalse(record.isSet("A"));
    }

    @Test
    public void testIterator() {
        final String[] values = { "one", "two", "three" };
        final CSVRecord record = new CSVRecord(values, null, null, 1L);
        final Iterator<String> it = record.iterator();
        assertTrue(it.hasNext());
        assertEquals("one", it.next());
        assertEquals("two", it.next());
        assertEquals("three", it.next());
        assertFalse(it.hasNext());
    }

    @Test
    public void testIteratorEmpty() {
        final CSVRecord record = new CSVRecord(null, null, null, 1L);
        final Iterator<String> it = record.iterator();
        assertFalse(it.hasNext());
    }

    @Test
    public void testSize() {
        final String[] values = { "one", "two", "three" };
        final CSVRecord record = new CSVRecord(values, null, null, 1L);
        assertEquals(3, record.size());
    }

    @Test
    public void testSizeNullValues() {
        final CSVRecord record = new CSVRecord(null, null, null, 1L);
        assertEquals(0, record.size());
    }

    @Test
    public void testToMap() {
        final String[] values = { "one", "two", "three" };
        final CSVRecord record = new CSVRecord(values, headerMap(), null, 1L);
        final Map<String, String> map = record.toMap();
        assertEquals(3, map.size());
        assertEquals("one", map.get("A"));
        assertEquals("two", map.get("B"));
        assertEquals("three", map.get("C"));
    }

    @Test
    public void testToMapSkipsColumnsBeyondValues() {
        final String[] values = { "one", "two" };
        final CSVRecord record = new CSVRecord(values, headerMap(), null, 1L);
        final Map<String, String> map = record.toMap();
        // "C" is mapped to index 2, which is out of range for a 2-value record
        assertEquals(2, map.size());
        assertFalse(map.containsKey("C"));
    }

    @Test
    public void testPutInExistingMap() {
        final String[] values = { "one", "two", "three" };
        final CSVRecord record = new CSVRecord(values, headerMap(), null, 1L);
        final Map<String, String> target = new HashMap<String, String>();
        target.put("preexisting", "value");
        final Map<String, String> result = record.putIn(target);
        assertSame(target, result);
        assertEquals("value", result.get("preexisting"));
        assertEquals("one", result.get("A"));
        assertEquals(4, result.size());
    }

    @Test
    public void testToString() {
        final String[] values = { "one", "two" };
        final CSVRecord record = new CSVRecord(values, null, null, 1L);
        assertEquals("[one, two]", record.toString());
    }

    @Test
    public void testToStringEmpty() {
        final CSVRecord record = new CSVRecord(null, null, null, 1L);
        assertEquals("[]", record.toString());
    }

    @Test
    public void testValues() {
        final String[] values = { "one", "two" };
        final CSVRecord record = new CSVRecord(values, null, null, 1L);
        assertSame(values, record.values());
    }

    @Test
    public void testValuesNullInput() {
        final CSVRecord record = new CSVRecord(null, null, null, 1L);
        assertEquals(0, record.values().length);
    }
}
