/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.cli;

import java.util.List;
import java.util.Properties;

import junit.framework.TestCase;

/**
 * Self-contained tests for {@link Parser}.
 */
public class ParserAgentTest extends TestCase
{
    /**
     * Minimal concrete Parser whose flatten() just echoes the arguments,
     * mirroring the simplest possible subclass behaviour.
     */
    private static class EchoParser extends Parser
    {
        protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption)
        {
            return arguments;
        }
    }

    private EchoParser parser;

    public void setUp()
    {
        parser = new EchoParser();
    }

    public void testParseSimpleShortOption() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "a flag");

        CommandLine cmd = parser.parse(options, new String[] {"-a"});

        assertTrue(cmd.hasOption("a"));
        assertEquals(0, cmd.getArgs().length);
    }

    public void testParseNullArgumentsTreatedAsEmpty() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "a flag");

        CommandLine cmd = parser.parse(options, null);

        assertFalse(cmd.hasOption("a"));
        assertEquals(0, cmd.getArgs().length);
    }

    public void testParseOptionWithRequiredArgument() throws Exception
    {
        Options options = new Options();
        options.addOption("b", true, "b with value");

        CommandLine cmd = parser.parse(options, new String[] {"-b", "value"});

        assertTrue(cmd.hasOption("b"));
        assertEquals("value", cmd.getOptionValue("b"));
    }

    public void testParseMissingRequiredArgumentThrows() throws Exception
    {
        Options options = new Options();
        options.addOption("b", true, "b with value");

        try
        {
            parser.parse(options, new String[] {"-b"});
            fail("Expected MissingArgumentException");
        }
        catch (MissingArgumentException e)
        {
            assertEquals("b", e.getOption().getOpt());
        }
    }

    public void testParseUnrecognizedOptionThrows() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "a flag");

        try
        {
            parser.parse(options, new String[] {"-z"});
            fail("Expected UnrecognizedOptionException");
        }
        catch (UnrecognizedOptionException e)
        {
            assertEquals("-z", e.getOption());
        }
    }

    public void testParseMissingRequiredOptionThrows() throws Exception
    {
        Options options = new Options();
        Option required = new Option("r", false, "required flag");
        required.setRequired(true);
        options.addOption(required);

        try
        {
            parser.parse(options, new String[0]);
            fail("Expected MissingOptionException");
        }
        catch (MissingOptionException e)
        {
            List missing = e.getMissingOptions();
            assertEquals(1, missing.size());
            assertEquals("r", missing.get(0));
        }
    }

    public void testParseRequiredOptionPresentDoesNotThrow() throws Exception
    {
        Options options = new Options();
        Option required = new Option("r", false, "required flag");
        required.setRequired(true);
        options.addOption(required);

        CommandLine cmd = parser.parse(options, new String[] {"-r"});

        assertTrue(cmd.hasOption("r"));
    }

    public void testParseStopAtNonOptionCollectsRemainingArgs() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "a flag");

        CommandLine cmd = parser.parse(options, new String[] {"-a", "foo", "-b", "bar"}, true);

        assertTrue(cmd.hasOption("a"));
        List args = cmd.getArgList();
        assertEquals(3, args.size());
        assertEquals("foo", args.get(0));
        assertEquals("-b", args.get(1));
        assertEquals("bar", args.get(2));
    }

    public void testParseStopAtNonOptionUnrecognizedDoesNotThrow() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "a flag");

        CommandLine cmd = parser.parse(options, new String[] {"-z", "-a"}, true);

        assertFalse(cmd.hasOption("a"));
        List args = cmd.getArgList();
        assertEquals(2, args.size());
        assertEquals("-z", args.get(0));
        assertEquals("-a", args.get(1));
    }

    public void testParseWithoutStopAtNonOptionUnrecognizedThrows() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "a flag");

        try
        {
            parser.parse(options, new String[] {"-z", "-a"}, false);
            fail("Expected UnrecognizedOptionException");
        }
        catch (UnrecognizedOptionException e)
        {
            assertEquals("-z", e.getOption());
        }
    }

    public void testParseDoubleDashStopsOptionProcessing() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "a flag");

        CommandLine cmd = parser.parse(options, new String[] {"--", "-a"});

        assertFalse(cmd.hasOption("a"));
        List args = cmd.getArgList();
        assertEquals(1, args.size());
        assertEquals("-a", args.get(0));
    }

    public void testParseSingleDashAddedAsArgument() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "a flag");

        CommandLine cmd = parser.parse(options, new String[] {"-"});

        List args = cmd.getArgList();
        assertEquals(1, args.size());
        assertEquals("-", args.get(0));
    }

    public void testParseSingleDashWithStopAtNonOptionEatsRest() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "a flag");

        // with stopAtNonOption a lone "-" is not itself recorded as an arg,
        // it merely switches on "eat the rest" mode for what follows
        CommandLine cmd = parser.parse(options, new String[] {"-", "foo"}, true);

        List args = cmd.getArgList();
        assertEquals(1, args.size());
        assertEquals("foo", args.get(0));
    }

    public void testParsePlainArgumentsCollected() throws Exception
    {
        Options options = new Options();

        CommandLine cmd = parser.parse(options, new String[] {"foo", "bar"});

        List args = cmd.getArgList();
        assertEquals(2, args.size());
        assertEquals("foo", args.get(0));
        assertEquals("bar", args.get(1));
    }

    public void testParseOptionGroupSelectsOption() throws Exception
    {
        Options options = new Options();
        OptionGroup group = new OptionGroup();
        group.addOption(new Option("x", false, "x opt"));
        group.addOption(new Option("y", false, "y opt"));
        options.addOptionGroup(group);

        CommandLine cmd = parser.parse(options, new String[] {"-x"});

        assertTrue(cmd.hasOption("x"));
        assertFalse(cmd.hasOption("y"));
    }

    public void testParseOptionGroupConflictThrows() throws Exception
    {
        Options options = new Options();
        OptionGroup group = new OptionGroup();
        group.addOption(new Option("x", false, "x opt"));
        group.addOption(new Option("y", false, "y opt"));
        options.addOptionGroup(group);

        try
        {
            parser.parse(options, new String[] {"-x", "-y"});
            fail("Expected AlreadySelectedException");
        }
        catch (AlreadySelectedException e)
        {
            assertEquals("y", e.getOption().getOpt());
        }
    }

    public void testParseRequiredOptionGroupMissingThrows() throws Exception
    {
        Options options = new Options();
        OptionGroup group = new OptionGroup();
        group.addOption(new Option("x", false, "x opt"));
        group.addOption(new Option("y", false, "y opt"));
        group.setRequired(true);
        options.addOptionGroup(group);

        try
        {
            parser.parse(options, new String[0]);
            fail("Expected MissingOptionException");
        }
        catch (MissingOptionException e)
        {
            assertEquals(1, e.getMissingOptions().size());
        }
    }

    public void testParseCanBeReusedAcrossInvocations() throws Exception
    {
        Options options = new Options();
        options.addOption("a", true, "a with value");

        CommandLine first = parser.parse(options, new String[] {"-a", "one"});
        assertEquals("one", first.getOptionValue("a"));

        // re-using the same Parser/Options instance must not retain state (CLI-71)
        CommandLine second = parser.parse(options, new String[0]);
        assertFalse(second.hasOption("a"));
    }

    public void testParsePropertiesAddFlagOption() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "a flag");

        Properties properties = new Properties();
        properties.setProperty("a", "true");

        CommandLine cmd = parser.parse(options, new String[0], properties);

        assertTrue(cmd.hasOption("a"));
    }

    public void testParsePropertiesFalseFlagNotAdded() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "a flag");

        Properties properties = new Properties();
        properties.setProperty("a", "false");

        CommandLine cmd = parser.parse(options, new String[0], properties);

        assertFalse(cmd.hasOption("a"));
    }

    public void testParsePropertiesDoNotOverrideCommandLine() throws Exception
    {
        Options options = new Options();
        options.addOption("a", true, "a with value");

        Properties properties = new Properties();
        properties.setProperty("a", "fromProperties");

        CommandLine cmd = parser.parse(options, new String[] {"-a", "fromCommandLine"}, properties);

        assertEquals("fromCommandLine", cmd.getOptionValue("a"));
    }

    public void testParsePropertiesSuppliesValueOption() throws Exception
    {
        Options options = new Options();
        options.addOption("a", true, "a with value");

        Properties properties = new Properties();
        properties.setProperty("a", "fromProperties");

        CommandLine cmd = parser.parse(options, new String[0], properties);

        assertEquals("fromProperties", cmd.getOptionValue("a"));
    }

    public void testParseUnknownPropertyIgnored() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "a flag");

        Properties properties = new Properties();
        properties.setProperty("unknown", "true");

        try
        {
            parser.parse(options, new String[0], properties);
            fail("Expected NullPointerException for unknown option in properties");
        }
        catch (NullPointerException e)
        {
            // getOptions().getOption(option) returns null for unknown options and
            // Parser dereferences it without checking - documents current behaviour
        }
    }

    public void testProcessArgsOptionalArgumentAllowsNoValue() throws Exception
    {
        Options options = new Options();
        Option opt = new Option("o", true, "optional");
        opt.setOptionalArg(true);
        options.addOption(opt);

        CommandLine cmd = parser.parse(options, new String[] {"-o"});

        assertTrue(cmd.hasOption("o"));
        assertNull(cmd.getOptionValue("o"));
    }

    public void testGetOptionsReturnsSetOptions() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "a flag");

        CommandLineParser p = parser;
        p.parse(options, new String[0]);

        assertSame(options, parser.getOptions());
    }

    public void testGetRequiredOptionsEmptiedAfterSatisfied() throws Exception
    {
        Options options = new Options();
        Option required = new Option("r", false, "required flag");
        required.setRequired(true);
        options.addOption(required);

        parser.parse(options, new String[] {"-r"});

        assertTrue(parser.getRequiredOptions().isEmpty());
    }
}
