/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang;

import java.io.IOException;
import java.io.StringWriter;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

/**
 * Unit tests {@link org.apache.commons.lang.Entities}.
 *
 * @version $Id$
 */
public class EntitiesAgentTest extends TestCase {

    public EntitiesAgentTest(String name) {
        super(name);
    }

    public static void main(String[] args) {
        TestRunner.run(suite());
    }

    public static Test suite() {
        TestSuite suite = new TestSuite(EntitiesAgentTest.class);
        suite.setName("Entities Agent Tests");
        return suite;
    }

    //-----------------------------------------------------------------------
    // escape(String)
    //-----------------------------------------------------------------------
    public void testEscapeXml() {
        assertEquals("&lt;foo&gt;", Entities.XML.escape("<foo>"));
        assertEquals("&quot;a&quot;&amp;&apos;b&apos;", Entities.XML.escape("\"a\"&'b'"));
        assertEquals("", Entities.XML.escape(""));
        assertEquals("plain text", Entities.XML.escape("plain text"));
    }

    public void testEscapeHtml32() {
        assertEquals("&lt;a&gt;", Entities.HTML32.escape("<a>"));
        assertEquals("&nbsp;", Entities.HTML32.escape(" "));
        // apostrophe is not part of HTML32, so it stays literal
        assertEquals("'", Entities.HTML32.escape("'"));
    }

    public void testEscapeHtml40() {
        assertEquals("&euro;", Entities.HTML40.escape("€"));
        assertEquals("&nbsp;", Entities.HTML40.escape(" "));
        assertEquals("&lt;&gt;&amp;&quot;", Entities.HTML40.escape("<>&\""));
    }

    public void testEscapeHighUnicodeWithoutEntity() {
        // character above 0x7F with no known entity name is numerically escaped
        char ch = (char) 0x1234;
        String result = Entities.XML.escape(String.valueOf(ch));
        assertEquals("&#4660;", result);
    }

    public void testEscapeLowAsciiWithoutEntity() {
        // ordinary ASCII character below 0x80 with no entity stays as-is
        assertEquals("Z", Entities.XML.escape("Z"));
    }

    //-----------------------------------------------------------------------
    // escape(Writer, String)
    //-----------------------------------------------------------------------
    public void testEscapeWriterMatchesStringVersion() throws IOException {
        String input = "<a href=\"x\">café €</a>";
        StringWriter writer = new StringWriter();
        Entities.HTML40.escape(writer, input);
        assertEquals(Entities.HTML40.escape(input), writer.toString());
    }

    public void testEscapeWriterEmptyString() throws IOException {
        StringWriter writer = new StringWriter();
        Entities.XML.escape(writer, "");
        assertEquals("", writer.toString());
    }

    //-----------------------------------------------------------------------
    // unescape(String)
    //-----------------------------------------------------------------------
    public void testUnescapeNoAmpersandReturnsSameContent() {
        assertEquals("plain text", Entities.HTML40.unescape("plain text"));
    }

    public void testUnescapeNamedEntity() {
        assertEquals("<foo>", Entities.XML.unescape("&lt;foo&gt;"));
        assertEquals("\"a\"&'b'", Entities.XML.unescape("&quot;a&quot;&amp;&apos;b&apos;"));
    }

    public void testUnescapeDecimalNumericEntity() {
        assertEquals("<", Entities.HTML40.unescape("&#60;"));
    }

    public void testUnescapeHexNumericEntityLowerAndUpperX() {
        assertEquals("<", Entities.HTML40.unescape("&#x3c;"));
        assertEquals("<", Entities.HTML40.unescape("&#X3C;"));
    }

    public void testUnescapeUnknownEntityNameLeftIntact() {
        assertEquals("&foo;", Entities.HTML40.unescape("&foo;"));
    }

    public void testUnescapeEmptyEntityNameLeftIntact() {
        assertEquals("&;", Entities.HTML40.unescape("&;"));
    }

    public void testUnescapeMissingSemicolonLeftIntact() {
        assertEquals("&lt", Entities.HTML40.unescape("&lt"));
        assertEquals("text &lt more", Entities.HTML40.unescape("text &lt more"));
    }

    public void testUnescapeHashOnlyLeftIntact() {
        assertEquals("&#;", Entities.HTML40.unescape("&#;"));
    }

    public void testUnescapeNumericOverflowLeftIntact() {
        // value greater than 0xFFFF is considered invalid and left as-is
        assertEquals("&#65536;", Entities.HTML40.unescape("&#65536;"));
    }

    public void testUnescapeInvalidNumericLeftIntact() {
        assertEquals("&#abc;", Entities.HTML40.unescape("&#abc;"));
        assertEquals("&#xZZ;", Entities.HTML40.unescape("&#xZZ;"));
    }

    public void testUnescapeNestedAmpersandBeforeSemicolon() {
        // "&...&...;" is not a valid single entity reference: the leading '&' is literal
        String input = "&foo&bar;";
        assertEquals("&foo&bar;", Entities.HTML40.unescape(input));
    }

    public void testUnescapeTrailingAmpersandWithoutSemicolon() {
        assertEquals("abc&", Entities.HTML40.unescape("abc&"));
    }

    public void testUnescapeRoundTripWithEscape() {
        String original = "<tag attr=\"val\">café & friends</tag>";
        String escaped = Entities.HTML40.escape(original);
        assertEquals(original, Entities.HTML40.unescape(escaped));
    }

    //-----------------------------------------------------------------------
    // unescape(Writer, String)
    //-----------------------------------------------------------------------
    public void testUnescapeWriterNoAmpersandWritesWholeString() throws IOException {
        StringWriter writer = new StringWriter();
        Entities.HTML40.unescape(writer, "plain text");
        assertEquals("plain text", writer.toString());
    }

    public void testUnescapeWriterMatchesStringVersion() throws IOException {
        String input = "&lt;a&gt; &#60; &#x3c; &euro; &unknown; &;";
        StringWriter writer = new StringWriter();
        Entities.HTML40.unescape(writer, input);
        assertEquals(Entities.HTML40.unescape(input), writer.toString());
    }

    //-----------------------------------------------------------------------
    // addEntity / addEntities / entityName / entityValue on a fresh instance
    //-----------------------------------------------------------------------
    public void testAddEntityAndLookupByNameAndValue() {
        Entities entities = new Entities();
        assertEquals(-1, entities.entityValue("foo"));

        entities.addEntity("foo", 0xA1);

        assertEquals(0xA1, entities.entityValue("foo"));
        assertEquals("foo", entities.entityName(0xA1));
        assertEquals("¡", entities.unescape("&foo;"));
        assertEquals("&foo;", entities.escape("¡"));
    }

    public void testAddEntitiesArray() {
        Entities entities = new Entities();
        String[][] data = {{"a", "1"}, {"b", "2"}};
        entities.addEntities(data);
        assertEquals(1, entities.entityValue("a"));
        assertEquals(2, entities.entityValue("b"));
        assertEquals("a", entities.entityName(1));
        assertEquals("b", entities.entityName(2));
    }

    public void testEntityValueUnknownReturnsMinusOne() {
        Entities entities = new Entities();
        assertEquals(-1, entities.entityValue("doesNotExist"));
    }

    public void testEntityNameUnknownReturnsNull() {
        Entities entities = new Entities();
        assertNull(entities.entityName(999999));
    }

    //-----------------------------------------------------------------------
    // Static instances sanity
    //-----------------------------------------------------------------------
    public void testXmlDoesNotContainIso8859Entities() {
        assertEquals(-1, Entities.XML.entityValue("nbsp"));
    }

    public void testHtml32DoesNotContainApos() {
        assertEquals(-1, Entities.HTML32.entityValue("apos"));
    }

    public void testHtml40ContainsBasicIsoAndHtml40Entities() {
        assertEquals(60, Entities.HTML40.entityValue("lt"));
        assertEquals(160, Entities.HTML40.entityValue("nbsp"));
        assertEquals(8364, Entities.HTML40.entityValue("euro"));
    }

    public void testFillWithHtml40Entities() {
        Entities entities = new Entities();
        Entities.fillWithHtml40Entities(entities);
        assertEquals(60, entities.entityValue("lt"));
        assertEquals(160, entities.entityValue("nbsp"));
        assertEquals(8364, entities.entityValue("euro"));
    }

    //-----------------------------------------------------------------------
    // Entities.PrimitiveEntityMap
    //-----------------------------------------------------------------------
    public void testPrimitiveEntityMap() {
        Entities.PrimitiveEntityMap map = new Entities.PrimitiveEntityMap();
        assertEquals(-1, map.value("x"));
        assertNull(map.name(5));

        map.add("x", 5);

        assertEquals(5, map.value("x"));
        assertEquals("x", map.name(5));
    }

    //-----------------------------------------------------------------------
    // Entities.HashEntityMap
    //-----------------------------------------------------------------------
    public void testHashEntityMap() {
        Entities.HashEntityMap map = new Entities.HashEntityMap();
        assertEquals(-1, map.value("x"));
        assertNull(map.name(5));

        map.add("x", 5);
        map.add("y", 6);

        assertEquals(5, map.value("x"));
        assertEquals(6, map.value("y"));
        assertEquals("x", map.name(5));
        assertEquals("y", map.name(6));
    }

    //-----------------------------------------------------------------------
    // Entities.TreeEntityMap
    //-----------------------------------------------------------------------
    public void testTreeEntityMap() {
        Entities.TreeEntityMap map = new Entities.TreeEntityMap();
        assertEquals(-1, map.value("x"));
        assertNull(map.name(5));

        map.add("x", 5);
        map.add("y", 6);

        assertEquals(5, map.value("x"));
        assertEquals(6, map.value("y"));
        assertEquals("x", map.name(5));
        assertEquals("y", map.name(6));
    }

    //-----------------------------------------------------------------------
    // Entities.LookupEntityMap
    //-----------------------------------------------------------------------
    public void testLookupEntityMapBelowTableSize() {
        Entities.LookupEntityMap map = new Entities.LookupEntityMap();
        map.add("small", 10);

        assertEquals("small", map.name(10));
        assertEquals(10, map.value("small"));
        assertNull(map.name(11));
    }

    public void testLookupEntityMapAboveTableSizeFallsBackToSuper() {
        Entities.LookupEntityMap map = new Entities.LookupEntityMap();
        map.add("big", 8364);

        assertEquals("big", map.name(8364));
        assertEquals(8364, map.value("big"));
        // forces creation of the internal lookup table and confirms it
        // does not interfere with values outside its range
        assertNull(map.name(5));
    }

    //-----------------------------------------------------------------------
    // Entities.ArrayEntityMap
    //-----------------------------------------------------------------------
    public void testArrayEntityMapDefaultGrowBy() {
        Entities.ArrayEntityMap map = new Entities.ArrayEntityMap();
        assertEquals(-1, map.value("x"));
        assertNull(map.name(1));

        map.add("x", 1);

        assertEquals(1, map.value("x"));
        assertEquals("x", map.name(1));
    }

    public void testArrayEntityMapGrowsBeyondInitialCapacity() {
        int growBy = 2;
        Entities.ArrayEntityMap map = new Entities.ArrayEntityMap(growBy);
        int count = 10;
        for (int i = 0; i < count; i++) {
            map.add("name" + i, i);
        }
        for (int i = 0; i < count; i++) {
            assertEquals(i, map.value("name" + i));
            assertEquals("name" + i, map.name(i));
        }
        assertEquals(-1, map.value("doesNotExist"));
        assertNull(map.name(-1));
    }

    public void testArrayEntityMapAllowsDuplicateValues() {
        Entities.ArrayEntityMap map = new Entities.ArrayEntityMap();
        map.add("first", 1);
        map.add("second", 1);
        // name() returns the first match found by linear scan
        assertEquals("first", map.name(1));
        assertEquals(1, map.value("first"));
        assertEquals(1, map.value("second"));
    }

    //-----------------------------------------------------------------------
    // Entities.BinaryEntityMap
    //-----------------------------------------------------------------------
    public void testBinaryEntityMapOrdersByValue() {
        Entities.BinaryEntityMap map = new Entities.BinaryEntityMap();
        map.add("c", 3);
        map.add("a", 1);
        map.add("b", 2);

        assertEquals("a", map.name(1));
        assertEquals("b", map.name(2));
        assertEquals("c", map.name(3));
        assertEquals(1, map.value("a"));
        assertEquals(2, map.value("b"));
        assertEquals(3, map.value("c"));
    }

    public void testBinaryEntityMapUnknownValueReturnsNull() {
        Entities.BinaryEntityMap map = new Entities.BinaryEntityMap();
        map.add("a", 1);
        assertNull(map.name(42));
    }

    public void testBinaryEntityMapDuplicateValueIgnored() {
        Entities.BinaryEntityMap map = new Entities.BinaryEntityMap(2);
        map.add("a", 1);
        map.add("b", 2);
        map.add("second-b", 2);
        // a duplicate add() whose value is already present at a non-zero
        // index is a no-op per binarySearch() contract
        assertEquals("b", map.name(2));
        assertEquals(2, map.value("b"));
    }

    public void testBinaryEntityMapGrowsBeyondInitialCapacity() {
        Entities.BinaryEntityMap map = new Entities.BinaryEntityMap(2);
        int count = 10;
        for (int i = count - 1; i >= 0; i--) {
            map.add("name" + i, i);
        }
        for (int i = 0; i < count; i++) {
            assertEquals("name" + i, map.name(i));
            assertEquals(i, map.value("name" + i));
        }
    }
}
