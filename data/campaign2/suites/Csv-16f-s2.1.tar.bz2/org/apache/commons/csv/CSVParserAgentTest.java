package org.apache.commons.csv;

import junit.framework.TestCase;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.Writer;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

/**
 * Self-contained tests for {@link CSVParser}, based solely on the documented
 * contract in the generated javadoc.
 */
public class CSVParserAgentTest extends TestCase {

    private static final String SIMPLE_CSV = "a,b\nc,d\n";

    private File tempFile;

    protected void setUp() throws Exception {
        tempFile = File.createTempFile("CSVParserAgentTest", ".csv");
        Writer writer = new FileWriter(tempFile);
        try {
            writer.write(SIMPLE_CSV);
        } finally {
            writer.close();
        }
    }

    protected void tearDown() throws Exception {
        if (tempFile != null) {
            tempFile.delete();
        }
    }

    // A Reader that reads a fixed prefix successfully, then throws IOException
    // instead of signalling end-of-stream, simulating a read failure mid-parse.
    private static final class FailingAfterPrefixReader extends Reader {
        private final Reader delegate;

        FailingAfterPrefixReader(String prefix) {
            delegate = new StringReader(prefix);
        }

        public int read(char[] cbuf, int off, int len) throws IOException {
            int r = delegate.read(cbuf, off, len);
            if (r == -1) {
                throw new IOException("Simulated read failure");
            }
            return r;
        }

        public void close() throws IOException {
            delegate.close();
        }
    }

    // A Reader that always fails on read.
    private static final class AlwaysFailingReader extends Reader {
        public int read(char[] cbuf, int off, int len) throws IOException {
            throw new IOException("Simulated read failure");
        }

        public void close() throws IOException {
            // no-op
        }
    }

    // ---- Constructor ----

    public void testConstructorNullReaderThrowsIllegalArgumentException() throws Exception {
        try {
            new CSVParser(null, CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented behavior
        }
    }

    public void testConstructorNullFormatThrowsIllegalArgumentException() throws Exception {
        try {
            new CSVParser(new StringReader(SIMPLE_CSV), null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented behavior
        }
    }

    public void pruned_testConstructorWithOffsetAndRecordNumber() throws Exception {
        CSVParser parser = new CSVParser(new StringReader(SIMPLE_CSV), CSVFormat.DEFAULT, 0L, 5L);
        try {
            assertEquals(5L, parser.getRecordNumber());
            CSVRecord record = parser.nextRecord();
            assertNotNull(record);
            assertEquals(6L, parser.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    // ---- parse(String, CSVFormat) ----

    public void testParseStringNullStringThrowsIllegalArgumentException() {
        try {
            CSVParser.parse((String) null, CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented behavior
        } catch (IOException e) {
            fail("Unexpected IOException: " + e);
        }
    }

    public void testParseStringNullFormatThrowsIllegalArgumentException() {
        try {
            CSVParser.parse(SIMPLE_CSV, null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented behavior
        } catch (IOException e) {
            fail("Unexpected IOException: " + e);
        }
    }

    public void testParseStringBasic() throws Exception {
        CSVParser parser = CSVParser.parse(SIMPLE_CSV, CSVFormat.DEFAULT);
        try {
            List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            CSVRecord first = records.get(0);
            assertEquals(2, first.size());
            assertEquals("a", first.get(0));
            assertEquals("b", first.get(1));
            CSVRecord second = records.get(1);
            assertEquals("c", second.get(0));
            assertEquals("d", second.get(1));
        } finally {
            parser.close();
        }
    }

    // ---- parse(Reader, CSVFormat) ----

    public void testParseReaderNullReaderThrowsIllegalArgumentException() {
        try {
            CSVParser.parse((Reader) null, CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented behavior
        } catch (IOException e) {
            fail("Unexpected IOException: " + e);
        }
    }

    public void testParseReaderNullFormatThrowsIllegalArgumentException() {
        try {
            CSVParser.parse(new StringReader(SIMPLE_CSV), null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented behavior
        } catch (IOException e) {
            fail("Unexpected IOException: " + e);
        }
    }

    public void testParseReaderBasic() throws Exception {
        CSVParser parser = CSVParser.parse(new StringReader(SIMPLE_CSV), CSVFormat.DEFAULT);
        try {
            List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
        } finally {
            parser.close();
        }
    }

    // ---- parse(File, Charset, CSVFormat) ----

    public void testParseFileNullFileThrowsIllegalArgumentException() {
        try {
            CSVParser.parse((File) null, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented behavior
        } catch (IOException e) {
            fail("Unexpected IOException: " + e);
        }
    }

    public void testParseFileNullFormatThrowsIllegalArgumentException() {
        try {
            CSVParser.parse(tempFile, StandardCharsets.UTF_8, null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented behavior
        } catch (IOException e) {
            fail("Unexpected IOException: " + e);
        }
    }

    public void testParseFileBasic() throws Exception {
        CSVParser parser = CSVParser.parse(tempFile, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
        try {
            List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("d", records.get(1).get(1));
        } finally {
            parser.close();
        }
    }

    // ---- parse(InputStream, Charset, CSVFormat) ----

    public void testParseInputStreamNullStreamThrowsIllegalArgumentException() {
        try {
            CSVParser.parse((java.io.InputStream) null, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented behavior
        } catch (IOException e) {
            fail("Unexpected IOException: " + e);
        }
    }

    public void testParseInputStreamNullFormatThrowsIllegalArgumentException() {
        ByteArrayInputStream in = new ByteArrayInputStream(SIMPLE_CSV.getBytes(StandardCharsets.UTF_8));
        try {
            CSVParser.parse(in, StandardCharsets.UTF_8, null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented behavior
        } catch (IOException e) {
            fail("Unexpected IOException: " + e);
        }
    }

    public void testParseInputStreamBasic() throws Exception {
        ByteArrayInputStream in = new ByteArrayInputStream(SIMPLE_CSV.getBytes(StandardCharsets.UTF_8));
        CSVParser parser = CSVParser.parse(in, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
        try {
            List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
        } finally {
            parser.close();
        }
    }

    // ---- parse(URL, Charset, CSVFormat) ----

    public void testParseURLNullUrlThrowsIllegalArgumentException() {
        try {
            CSVParser.parse((URL) null, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented behavior
        } catch (IOException e) {
            fail("Unexpected IOException: " + e);
        }
    }

    public void testParseURLNullCharsetThrowsIllegalArgumentException() throws Exception {
        URL url = tempFile.toURI().toURL();
        try {
            CSVParser.parse(url, null, CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented behavior
        } catch (IOException e) {
            fail("Unexpected IOException: " + e);
        }
    }

    public void testParseURLNullFormatThrowsIllegalArgumentException() throws Exception {
        URL url = tempFile.toURI().toURL();
        try {
            CSVParser.parse(url, StandardCharsets.UTF_8, null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented behavior
        } catch (IOException e) {
            fail("Unexpected IOException: " + e);
        }
    }

    public void testParseURLBasic() throws Exception {
        URL url = tempFile.toURI().toURL();
        CSVParser parser = CSVParser.parse(url, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
        try {
            List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
        } finally {
            parser.close();
        }
    }

    // ---- parse(Path, Charset, CSVFormat) ----

    public void testParsePathNullPathThrowsIllegalArgumentException() {
        try {
            CSVParser.parse((Path) null, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented behavior
        } catch (IOException e) {
            fail("Unexpected IOException: " + e);
        }
    }

    public void testParsePathNullFormatThrowsIllegalArgumentException() {
        Path path = tempFile.toPath();
        try {
            CSVParser.parse(path, StandardCharsets.UTF_8, null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // documented behavior
        } catch (IOException e) {
            fail("Unexpected IOException: " + e);
        }
    }

    public void testParsePathBasic() throws Exception {
        Path path = tempFile.toPath();
        CSVParser parser = CSVParser.parse(path, StandardCharsets.UTF_8, CSVFormat.DEFAULT);
        try {
            List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
        } finally {
            parser.close();
        }
    }

    // ---- getRecords() ----

    public void testGetRecordsEmptyAfterExhausted() throws Exception {
        CSVParser parser = CSVParser.parse(SIMPLE_CSV, CSVFormat.DEFAULT);
        try {
            List<CSVRecord> first = parser.getRecords();
            assertEquals(2, first.size());
            List<CSVRecord> second = parser.getRecords();
            assertNotNull(second);
            assertEquals(0, second.size());
        } finally {
            parser.close();
        }
    }

    public void testGetRecordsStartsAtCurrentPosition() throws Exception {
        CSVParser parser = CSVParser.parse(SIMPLE_CSV, CSVFormat.DEFAULT);
        try {
            CSVRecord consumedFirst = parser.nextRecord();
            assertNotNull(consumedFirst);
            List<CSVRecord> remaining = parser.getRecords();
            assertEquals(1, remaining.size());
            assertEquals("c", remaining.get(0).get(0));
        } finally {
            parser.close();
        }
    }

    public void testGetRecordsThrowsIOExceptionOnReadFailure() throws Exception {
        CSVParser parser = new CSVParser(new AlwaysFailingReader(), CSVFormat.DEFAULT);
        try {
            parser.getRecords();
            fail("Expected IOException");
        } catch (IOException expected) {
            // documented behavior: IOException propagates from getRecords()
        } finally {
            parser.close();
        }
    }

    // ---- nextRecord() ----

    public void testNextRecordReturnsNullAtEndOfStream() throws Exception {
        CSVParser parser = CSVParser.parse(SIMPLE_CSV, CSVFormat.DEFAULT);
        try {
            assertNotNull(parser.nextRecord());
            assertNotNull(parser.nextRecord());
            assertNull(parser.nextRecord());
            assertNull(parser.nextRecord());
        } finally {
            parser.close();
        }
    }

    // ---- iterator() ----

    public void testIteratorYieldsAllRecords() throws Exception {
        CSVParser parser = CSVParser.parse(SIMPLE_CSV, CSVFormat.DEFAULT);
        try {
            Iterator<CSVRecord> it = parser.iterator();
            assertTrue(it.hasNext());
            CSVRecord r1 = it.next();
            assertEquals("a", r1.get(0));
            assertTrue(it.hasNext());
            CSVRecord r2 = it.next();
            assertEquals("c", r2.get(0));
            assertFalse(it.hasNext());
        } finally {
            parser.close();
        }
    }

    public void testIteratorNextAfterCloseThrowsNoSuchElementException() throws Exception {
        CSVParser parser = CSVParser.parse(SIMPLE_CSV, CSVFormat.DEFAULT);
        parser.close();
        Iterator<CSVRecord> it = parser.iterator();
        try {
            it.next();
            fail("Expected NoSuchElementException");
        } catch (NoSuchElementException expected) {
            // documented behavior
        }
    }

    public void testIteratorWrapsIOExceptionAsIllegalStateException() throws Exception {
        CSVParser parser = new CSVParser(new FailingAfterPrefixReader("a,b\n"), CSVFormat.DEFAULT);
        try {
            Iterator<CSVRecord> it = parser.iterator();
            CSVRecord r1 = it.next();
            assertEquals("a", r1.get(0));
            try {
                it.next();
                fail("Expected IllegalStateException");
            } catch (IllegalStateException expected) {
                // documented: IOException re-thrown as IllegalStateException during iteration
            }
        } finally {
            parser.close();
        }
    }

    // ---- close() / isClosed() ----

    public void testIsClosedInitiallyFalse() throws Exception {
        CSVParser parser = CSVParser.parse(SIMPLE_CSV, CSVFormat.DEFAULT);
        try {
            assertFalse(parser.isClosed());
        } finally {
            parser.close();
        }
    }

    public void testCloseMarksParserClosed() throws Exception {
        CSVParser parser = CSVParser.parse(SIMPLE_CSV, CSVFormat.DEFAULT);
        parser.close();
        assertTrue(parser.isClosed());
    }

    public void testCloseIsIdempotent() throws Exception {
        CSVParser parser = CSVParser.parse(SIMPLE_CSV, CSVFormat.DEFAULT);
        parser.close();
        parser.close();
        assertTrue(parser.isClosed());
    }

    // ---- getCurrentLineNumber() ----

    public void testGetCurrentLineNumberProgresses() throws Exception {
        CSVParser parser = CSVParser.parse(SIMPLE_CSV, CSVFormat.DEFAULT);
        try {
            assertEquals(0L, parser.getCurrentLineNumber());
            parser.nextRecord();
            assertEquals(1L, parser.getCurrentLineNumber());
            parser.nextRecord();
            assertEquals(2L, parser.getCurrentLineNumber());
        } finally {
            parser.close();
        }
    }

    // ---- getRecordNumber() ----

    public void testGetRecordNumberProgresses() throws Exception {
        CSVParser parser = CSVParser.parse(SIMPLE_CSV, CSVFormat.DEFAULT);
        try {
            assertEquals(0L, parser.getRecordNumber());
            parser.nextRecord();
            assertEquals(1L, parser.getRecordNumber());
            parser.nextRecord();
            assertEquals(2L, parser.getRecordNumber());
            parser.nextRecord();
            assertEquals(2L, parser.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    // ---- getFirstEndOfLine() ----

    public void testGetFirstEndOfLineLineFeed() throws Exception {
        CSVParser parser = CSVParser.parse("a,b\nc,d\n", CSVFormat.DEFAULT);
        try {
            parser.nextRecord();
            assertEquals("\n", parser.getFirstEndOfLine());
        } finally {
            parser.close();
        }
    }

    public void testGetFirstEndOfLineCarriageReturnLineFeed() throws Exception {
        CSVParser parser = CSVParser.parse("a,b\r\nc,d\r\n", CSVFormat.DEFAULT);
        try {
            parser.nextRecord();
            assertEquals("\r\n", parser.getFirstEndOfLine());
        } finally {
            parser.close();
        }
    }

    // ---- getHeaderMap() ----

    public void testGetHeaderMapReturnsConfiguredHeaderInColumnOrder() throws Exception {
        CSVFormat format = CSVFormat.DEFAULT.withHeader("X", "Y");
        CSVParser parser = CSVParser.parse("1,2\n3,4\n", format);
        try {
            Map<String, Integer> headerMap = parser.getHeaderMap();
            assertEquals(2, headerMap.size());
            assertEquals(Integer.valueOf(0), headerMap.get("X"));
            assertEquals(Integer.valueOf(1), headerMap.get("Y"));
        } finally {
            parser.close();
        }
    }

    public void testGetHeaderMapReturnsIndependentCopy() throws Exception {
        CSVFormat format = CSVFormat.DEFAULT.withHeader("X", "Y");
        CSVParser parser = CSVParser.parse("1,2\n3,4\n", format);
        try {
            Map<String, Integer> headerMap = parser.getHeaderMap();
            headerMap.put("Z", 99);
            Map<String, Integer> headerMapAgain = parser.getHeaderMap();
            assertFalse(headerMapAgain.containsKey("Z"));
            assertEquals(2, headerMapAgain.size());
        } finally {
            parser.close();
        }
    }
}
