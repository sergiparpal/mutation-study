/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang.text;

import java.text.Format;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import junit.framework.TestCase;

/**
 * Self-contained unit tests for {@link ExtendedMessageFormat}.
 */
public class ExtendedMessageFormatAgentTest extends TestCase {

    public ExtendedMessageFormatAgentTest(String name) {
        super(name);
    }

    /** Format that upper-cases whatever toString() of the argument produces. */
    private static class UpperFormat extends Format {
        private static final long serialVersionUID = 1L;

        public StringBuffer format(Object obj, StringBuffer toAppendTo,
                java.text.FieldPosition pos) {
            return toAppendTo.append(String.valueOf(obj).toUpperCase());
        }

        public Object parseObject(String source, ParsePosition pos) {
            pos.setIndex(source.length());
            return source;
        }
    }

    private static class UpperFormatFactory implements FormatFactory {
        public Format getFormat(String name, String arguments, Locale locale) {
            if ("upper".equals(name)) {
                return new UpperFormat();
            }
            return null;
        }
    }

    private Map upperRegistry() {
        Map registry = new HashMap();
        registry.put("upper", new UpperFormatFactory());
        return registry;
    }

    // --- basic construction / no registry -------------------------------

    public void testNoRegistryBehavesLikeMessageFormat() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello, {0}!");
        assertEquals("Hello, World!", emf.format(new Object[] {"World"}));
        assertEquals("Hello, {0}!", emf.toPattern());
    }

    public void testConstructorWithLocale() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number}", Locale.US);
        assertEquals("1,234.5", emf.format(new Object[] {new Double(1234.5)}));
        assertEquals(Locale.US, emf.getLocale());
    }

    public void testConstructorWithNullRegistryDoesNotThrow() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", (Map) null);
        assertEquals("abc", emf.format(new Object[] {"abc"}));
    }

    // --- custom format registry ------------------------------------------

    public void testCustomFormatIsApplied() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", upperRegistry());
        assertEquals("ABC", emf.format(new Object[] {"abc"}));
    }

    public void testCustomFormatDescriptionPreservedInToPattern() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", upperRegistry());
        assertEquals("{0,upper}", emf.toPattern());
    }

    public void testUnrecognizedFormatNameFallsBackToStandard() {
        // "number" is not in the registry, so the factory returns null and
        // ExtendedMessageFormat must fall back to java.text.MessageFormat's
        // own handling of the "number" format type.
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number}", Locale.US, upperRegistry());
        assertEquals("1,234.5", emf.format(new Object[] {new Double(1234.5)}));
    }

    public void testMixedCustomAndStandardFormats() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat(
                "{0,upper} costs {1,number}", Locale.US, upperRegistry());
        assertEquals("ITEM costs 1,234.5",
                emf.format(new Object[] {"item", new Double(1234.5)}));
    }

    public void testRegistryWithoutFormatStyleArgument() {
        // exercises the branch of getFormat() where there is no comma
        // separating format-name from format-style (i.index <= 0)
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", upperRegistry());
        assertEquals("X", emf.format(new Object[] {"x"}));
    }

    // --- quoting ----------------------------------------------------------

    public void testEscapedQuoteInLiteralText() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("it''s {0}", upperRegistry());
        assertEquals("it's World", emf.format(new Object[] {"World"}));
    }

    public void testQuotedLiteralBraceIsNotParsedAsFormatElement() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("'{0}' {1}", upperRegistry());
        // the first {0} is quoted/literal, so only argument 1 is substituted
        assertEquals("{0} World", emf.format(new Object[] {"ignored", "World"}));
    }

    // --- error cases --------------------------------------------------

    public void testUnterminatedFormatElementThrows() {
        try {
            new ExtendedMessageFormat("{0", upperRegistry());
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().indexOf("Unterminated format element") >= 0);
        }
    }

    public void testLoneTopLevelQuoteIsTreatedLeniently() {
        // a single, unmatched quote at the top level is not an error: the
        // underlying java.text.MessageFormat treats it as a (silently
        // dropped) literal-text delimiter running to the end of the string.
        ExtendedMessageFormat emf = new ExtendedMessageFormat("it's broken", upperRegistry());
        assertEquals("its broken", emf.format(new Object[0]));
    }

    public void testInvalidFormatArgumentIndexThrows() {
        try {
            new ExtendedMessageFormat("{abc}", upperRegistry());
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().indexOf("Invalid format argument index") >= 0);
        }
    }

    public void testUnterminatedFormatDescriptionThrows() {
        try {
            // malformed: no closing brace after the format description
            new ExtendedMessageFormat("{0,upper", upperRegistry());
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().indexOf("Unterminated format element") >= 0);
        }
    }

    public void testApplyPatternRejectsBadPatternWithoutRegistry() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        try {
            emf.applyPattern("{abc}");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected: delegated straight to java.text.MessageFormat
        }
    }

    // --- disabled mutator methods -----------------------------------------

    public void testSetFormatThrowsUnsupported() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        try {
            emf.setFormat(0, null);
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException e) {
            // expected
        }
    }

    public void testSetFormatByArgumentIndexThrowsUnsupported() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        try {
            emf.setFormatByArgumentIndex(0, null);
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException e) {
            // expected
        }
    }

    public void testSetFormatsThrowsUnsupported() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        try {
            emf.setFormats(new Format[0]);
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException e) {
            // expected
        }
    }

    public void testSetFormatsByArgumentIndexThrowsUnsupported() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        try {
            emf.setFormatsByArgumentIndex(new Format[0]);
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException e) {
            // expected
        }
    }

    // --- applyPattern() re-use on same instance ---------------------------

    public void testApplyPatternCanBeCalledAgain() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", upperRegistry());
        assertEquals("ABC", emf.format(new Object[] {"abc"}));
        emf.applyPattern("plain {0}");
        assertEquals("plain xyz", emf.format(new Object[] {"xyz"}));
        assertEquals("plain {0}", emf.toPattern());
    }

    // --- parsing (inherited MessageFormat behaviour) -----------------------

    public void testParseDelegatesToMessageFormat() throws ParseException {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello, {0}!");
        Object[] parsed = emf.parse("Hello, World!");
        assertEquals(1, parsed.length);
        assertEquals("World", parsed[0]);
    }
}
