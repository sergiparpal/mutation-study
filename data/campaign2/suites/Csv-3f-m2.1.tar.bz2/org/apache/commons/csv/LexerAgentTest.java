/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.csv;

import static org.apache.commons.csv.Constants.BACKSPACE;
import static org.apache.commons.csv.Constants.CR;
import static org.apache.commons.csv.Constants.END_OF_STREAM;
import static org.apache.commons.csv.Constants.FF;
import static org.apache.commons.csv.Constants.LF;
import static org.apache.commons.csv.Constants.TAB;
import static org.apache.commons.csv.Constants.UNDEFINED;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.io.StringReader;

import org.junit.Test;

public class LexerAgentTest {

    /** Minimal concrete Lexer so the abstract class under test can be instantiated. */
    private static final class ConcreteLexer extends Lexer {
        ConcreteLexer(final CSVFormat format, final ExtendedBufferedReader in) {
            super(format, in);
        }

        @Override
        Token nextToken(final Token reusableToken) throws IOException {
            throw new UnsupportedOperationException("not needed for this test");
        }
    }

    private static ConcreteLexer createLexer(final String content, final CSVFormat format) {
        return new ConcreteLexer(format, new ExtendedBufferedReader(new StringReader(content)));
    }

    private static CSVFormat fullFormat() {
        return CSVFormat.newBuilder(',')
                .withQuoteChar('"')
                .withEscape('\\')
                .withCommentStart('#')
                .withIgnoreSurroundingSpaces(false)
                .withIgnoreEmptyLines(false)
                .build();
    }

    private static CSVFormat disabledFormat(final char delimiter) {
        // escape, quoteChar and commentStart left unset (null) -> disabled internally
        return CSVFormat.newBuilder(delimiter).build();
    }

    // --- readEscape ---------------------------------------------------

    @Test
    public void testReadEscapeNamedSequences() throws IOException {
        assertEquals(CR, createLexer("r", fullFormat()).readEscape());
        assertEquals(LF, createLexer("n", fullFormat()).readEscape());
        assertEquals(TAB, createLexer("t", fullFormat()).readEscape());
        assertEquals(BACKSPACE, createLexer("b", fullFormat()).readEscape());
        assertEquals(FF, createLexer("f", fullFormat()).readEscape());
    }

    @Test
    public void testReadEscapeLiteralControlChars() throws IOException {
        assertEquals(CR, createLexer("\r", fullFormat()).readEscape());
        assertEquals(LF, createLexer("\n", fullFormat()).readEscape());
        assertEquals(FF, createLexer("\f", fullFormat()).readEscape());
        assertEquals(TAB, createLexer("\t", fullFormat()).readEscape());
        assertEquals(BACKSPACE, createLexer("\b", fullFormat()).readEscape());
    }

    @Test
    public void testReadEscapeMetaCharacters() throws IOException {
        // delimiter, escape, quote and comment-start chars are all returned as-is
        assertEquals(',', createLexer(",", fullFormat()).readEscape());
        assertEquals('\\', createLexer("\\", fullFormat()).readEscape());
        assertEquals('"', createLexer("\"", fullFormat()).readEscape());
        assertEquals('#', createLexer("#", fullFormat()).readEscape());
    }

    @Test
    public void testReadEscapeUnexpectedCharReturnsEndOfStream() throws IOException {
        final Lexer lexer = createLexer("x", fullFormat());
        final int result = lexer.readEscape();
        assertEquals(END_OF_STREAM, result);
    }

    @Test
    public void testReadEscapeAtEndOfStreamThrows() {
        final Lexer lexer = createLexer("", fullFormat());
        try {
            lexer.readEscape();
            fail("Expected IOException when escape precedes EOF");
        } catch (final IOException e) {
            assertTrue(e.getMessage().contains("EOF"));
        }
    }

    // --- trimTrailingSpaces --------------------------------------------

    @Test
    public void testTrimTrailingSpacesRemovesTrailingWhitespace() {
        final Lexer lexer = createLexer("", fullFormat());
        final StringBuilder sb = new StringBuilder("abc   ");
        lexer.trimTrailingSpaces(sb);
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testTrimTrailingSpacesAllWhitespaceBecomesEmpty() {
        final Lexer lexer = createLexer("", fullFormat());
        final StringBuilder sb = new StringBuilder("   \t  ");
        lexer.trimTrailingSpaces(sb);
        assertEquals(0, sb.length());
    }

    @Test
    public void testTrimTrailingSpacesNoTrailingWhitespaceUnchanged() {
        final Lexer lexer = createLexer("", fullFormat());
        final StringBuilder sb = new StringBuilder("abc");
        lexer.trimTrailingSpaces(sb);
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testTrimTrailingSpacesEmptyBufferStaysEmpty() {
        final Lexer lexer = createLexer("", fullFormat());
        final StringBuilder sb = new StringBuilder();
        lexer.trimTrailingSpaces(sb);
        assertEquals(0, sb.length());
    }

    // --- readEndOfLine ---------------------------------------------------

    @Test
    public void testReadEndOfLineLoneLF() throws IOException {
        final ConcreteLexer lexer = createLexer("\n", fullFormat());
        final int c = lexer.in.read();
        assertTrue(lexer.readEndOfLine(c));
    }

    @Test
    public void testReadEndOfLineLoneCR() throws IOException {
        final ConcreteLexer lexer = createLexer("\r", fullFormat());
        final int c = lexer.in.read();
        assertTrue(lexer.readEndOfLine(c));
    }

    @Test
    public void testReadEndOfLineCRLFConsumesBothChars() throws IOException {
        final ConcreteLexer lexer = createLexer("\r\nX", fullFormat());
        final int c = lexer.in.read();
        assertTrue(lexer.readEndOfLine(c));
        // the trailing LF must have been silently consumed
        assertEquals(LF, lexer.in.getLastChar());
        assertEquals('X', lexer.in.read());
    }

    @Test
    public void testReadEndOfLineNonEolCharReturnsFalse() throws IOException {
        final ConcreteLexer lexer = createLexer("a", fullFormat());
        final int c = lexer.in.read();
        assertFalse(lexer.readEndOfLine(c));
    }

    @Test
    public void testReadEndOfLineEndOfStreamReturnsFalse() throws IOException {
        final ConcreteLexer lexer = createLexer("", fullFormat());
        final int c = lexer.in.read();
        assertEquals(END_OF_STREAM, c);
        assertFalse(lexer.readEndOfLine(c));
    }

    // --- getLineNumber ---------------------------------------------------

    @Test
    public void testGetLineNumberTracksUnderlyingReader() throws IOException {
        final ConcreteLexer lexer = createLexer("a\nb\n", fullFormat());
        assertEquals(0, lexer.getLineNumber());
        lexer.in.read(); // 'a'
        lexer.in.read(); // '\n' -> line 1
        lexer.in.read(); // 'b'
        lexer.in.read(); // '\n' -> line 2
        assertEquals(2, lexer.getLineNumber());
        assertEquals(lexer.in.getLineNumber(), lexer.getLineNumber());
    }

    // --- isWhitespace ---------------------------------------------------

    @Test
    public void testIsWhitespaceRegularSpace() {
        final Lexer lexer = createLexer("", disabledFormat(','));
        assertTrue(lexer.isWhitespace(' '));
        assertTrue(lexer.isWhitespace('\t'));
    }

    @Test
    public void testIsWhitespaceFalseForNonWhitespace() {
        final Lexer lexer = createLexer("", disabledFormat(','));
        assertFalse(lexer.isWhitespace('a'));
    }

    @Test
    public void testIsWhitespaceDelimiterNeverCountsEvenIfWhitespaceChar() {
        // tab is normally whitespace, but once it's the delimiter it must not be treated as such
        final Lexer lexer = createLexer("", disabledFormat(TAB));
        assertFalse(lexer.isWhitespace(TAB));
        assertTrue(lexer.isWhitespace(' '));
    }

    // --- isStartOfLine ---------------------------------------------------

    @Test
    public void testIsStartOfLine() {
        final Lexer lexer = createLexer("", fullFormat());
        assertTrue(lexer.isStartOfLine(LF));
        assertTrue(lexer.isStartOfLine(CR));
        assertTrue(lexer.isStartOfLine(UNDEFINED));
        assertFalse(lexer.isStartOfLine('a'));
    }

    // --- isEndOfFile ---------------------------------------------------

    @Test
    public void testIsEndOfFile() {
        final Lexer lexer = createLexer("", fullFormat());
        assertTrue(lexer.isEndOfFile(END_OF_STREAM));
        assertFalse(lexer.isEndOfFile('a'));
        assertFalse(lexer.isEndOfFile(0));
    }

    // --- isDelimiter / isEscape / isQuoteChar / isCommentStart ----------

    @Test
    public void testIsDelimiter() {
        final Lexer lexer = createLexer("", fullFormat());
        assertTrue(lexer.isDelimiter(','));
        assertFalse(lexer.isDelimiter('a'));
    }

    @Test
    public void testIsEscape() {
        final Lexer lexer = createLexer("", fullFormat());
        assertTrue(lexer.isEscape('\\'));
        assertFalse(lexer.isEscape('a'));
    }

    @Test
    public void testIsQuoteChar() {
        final Lexer lexer = createLexer("", fullFormat());
        assertTrue(lexer.isQuoteChar('"'));
        assertFalse(lexer.isQuoteChar('a'));
    }

    @Test
    public void testIsCommentStart() {
        final Lexer lexer = createLexer("", fullFormat());
        assertTrue(lexer.isCommentStart('#'));
        assertFalse(lexer.isCommentStart('a'));
    }

    @Test
    public void testDisabledEscapeQuoteCommentStartNeverMatchOrdinaryChars() {
        final Lexer lexer = createLexer("", disabledFormat(','));
        for (char c = 0; c < 128; c++) {
            assertFalse("escape should never match for char " + (int) c, lexer.isEscape(c));
            assertFalse("quoteChar should never match for char " + (int) c, lexer.isQuoteChar(c));
            assertFalse("commentStart should never match for char " + (int) c, lexer.isCommentStart(c));
        }
    }
}
