package org.apache.commons.cli;

import java.util.List;
import java.util.ListIterator;
import java.util.Properties;

import junit.framework.TestCase;

/**
 * Self-contained tests for {@link Parser}, built purely from its documented
 * contract (api/org/apache/commons/cli/Parser.html). Parser is abstract, so a
 * minimal concrete fixture is defined inline that implements the abstract
 * flatten() method as an identity transform; this isolates the behaviour
 * that Parser itself documents (option/argument/property processing,
 * required option checking) from the undocumented, subclass-specific
 * token-flattening strategies (e.g. grouped short options).
 */
public class ParserAgentTest extends TestCase {

    /**
     * Minimal concrete Parser: flatten() simply returns the arguments
     * unchanged, so the behaviour under test is exactly what Parser.parse()
     * and its helper methods do with a given token stream.
     */
    private static class IdentityParser extends Parser {
        protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption) {
            return arguments;
        }
    }

    private static Options flagOption(String opt) {
        Options options = new Options();
        options.addOption(new Option(opt, "flag " + opt));
        return options;
    }

    // -- parse(Options, String[]) -------------------------------------

    public void testParseSimpleFlagOptionIsRecognized() throws Exception {
        Options options = flagOption("a");
        IdentityParser parser = new IdentityParser();

        CommandLine cmd = parser.parse(options, new String[] {"-a"});

        assertNotNull(cmd);
        assertTrue(cmd.hasOption("a"));
    }

    public void testParseOptionWithArgumentCapturesValue() throws Exception {
        Options options = new Options();
        options.addOption(new Option("f", true, "a file"));
        IdentityParser parser = new IdentityParser();

        CommandLine cmd = parser.parse(options, new String[] {"-f", "value1"});

        assertTrue(cmd.hasOption("f"));
        assertEquals("value1", cmd.getOptionValue("f"));
    }

    public void testParseEmptyArgumentsProducesEmptyCommandLine() throws Exception {
        Options options = flagOption("a");
        IdentityParser parser = new IdentityParser();

        CommandLine cmd = parser.parse(options, new String[0]);

        assertNotNull(cmd);
        assertFalse(cmd.hasOption("a"));
        assertEquals(0, cmd.getArgs().length);
    }

    public void testParseMultipleOptionsAreAllRecognized() throws Exception {
        Options options = new Options();
        options.addOption(new Option("a", "flag a"));
        options.addOption(new Option("b", "flag b"));
        IdentityParser parser = new IdentityParser();

        CommandLine cmd = parser.parse(options, new String[] {"-a", "-b"});

        assertTrue(cmd.hasOption("a"));
        assertTrue(cmd.hasOption("b"));
    }

    public void testParseNonOptionArgumentIsAddedToArgList() throws Exception {
        Options options = flagOption("a");
        IdentityParser parser = new IdentityParser();

        CommandLine cmd = parser.parse(options, new String[] {"-a", "leftover"});

        assertTrue(cmd.hasOption("a"));
        assertTrue(cmd.getArgList().contains("leftover"));
    }

    public void testParseUnrecognizedOptionThrowsParseException() {
        Options options = flagOption("a");
        IdentityParser parser = new IdentityParser();

        try {
            parser.parse(options, new String[] {"-z"});
            fail("Expected a ParseException for an unrecognized option");
        } catch (ParseException expected) {
            // documented: processOption()/parse() throw ParseException when
            // arg does not represent a known Option
        }
    }

    public void testParseMissingRequiredOptionThrowsMissingOptionException() {
        Options options = new Options();
        Option required = new Option("r", "required flag");
        required.setRequired(true);
        options.addOption(required);
        IdentityParser parser = new IdentityParser();

        try {
            parser.parse(options, new String[0]);
            fail("Expected a MissingOptionException when a required option is absent");
        } catch (MissingOptionException expected) {
            // documented on checkRequiredOptions()
        } catch (ParseException e) {
            fail("Expected MissingOptionException but got " + e.getClass().getName());
        }
    }

    public void testParseWithRequiredOptionSatisfiedSucceeds() throws Exception {
        Options options = new Options();
        Option required = new Option("r", "required flag");
        required.setRequired(true);
        options.addOption(required);
        IdentityParser parser = new IdentityParser();

        CommandLine cmd = parser.parse(options, new String[] {"-r"});

        assertTrue(cmd.hasOption("r"));
    }

    // -- parse(Options, String[], boolean) -----------------------------

    public void testParseStopAtNonOptionFalseStillParsesOptionAfterArgument() throws Exception {
        Options options = new Options();
        options.addOption(new Option("a", "flag a"));
        options.addOption(new Option("b", "flag b"));
        IdentityParser parser = new IdentityParser();

        CommandLine cmd = parser.parse(options, new String[] {"-a", "foo", "-b"}, false);

        assertTrue(cmd.hasOption("a"));
        assertTrue(cmd.hasOption("b"));
        assertTrue(cmd.getArgList().contains("foo"));
    }

    public void testParseStopAtNonOptionTrueStopsInterpretingOptions() throws Exception {
        Options options = new Options();
        options.addOption(new Option("a", "flag a"));
        options.addOption(new Option("b", "flag b"));
        IdentityParser parser = new IdentityParser();

        CommandLine cmd = parser.parse(options, new String[] {"-a", "foo", "-b"}, true);

        assertTrue(cmd.hasOption("a"));
        assertFalse("'-b' should be treated as a plain argument once a "
                + "non-option is hit with stopAtNonOption=true", cmd.hasOption("b"));
        assertTrue(cmd.getArgList().contains("foo"));
        assertTrue(cmd.getArgList().contains("-b"));
    }

    // -- parse(Options, String[], Properties) --------------------------

    public void testParseWithPropertiesSetsFlagFromTruthyValue() throws Exception {
        Options options = flagOption("a");
        Properties properties = new Properties();
        properties.setProperty("a", "true");
        IdentityParser parser = new IdentityParser();

        CommandLine cmd = parser.parse(options, new String[0], properties);

        assertTrue(cmd.hasOption("a"));
    }

    public void testParseWithPropertiesDoesNotOverrideCommandLineValue() throws Exception {
        Options options = new Options();
        options.addOption(new Option("f", true, "a file"));
        Properties properties = new Properties();
        properties.setProperty("f", "propertyValue");
        IdentityParser parser = new IdentityParser();

        CommandLine cmd = parser.parse(options, new String[] {"-f", "cmdValue"}, properties);

        assertEquals("cmdValue", cmd.getOptionValue("f"));
    }

    // -- parse(Options, String[], Properties, boolean) ------------------

    public void testParseFourArgOverloadHonoursPropertiesAndStopFlag() throws Exception {
        Options options = new Options();
        options.addOption(new Option("a", "flag a"));
        Properties properties = new Properties();
        properties.setProperty("a", "true");
        IdentityParser parser = new IdentityParser();

        CommandLine cmd = parser.parse(options, new String[0], properties, true);

        assertTrue(cmd.hasOption("a"));
    }

    // -- processArgs(Option, ListIterator) ------------------------------

    public void pruned_testProcessArgsCollectsAvailableValue() throws Exception {
        Option opt = new Option("f", true, "a file");
        List tokens = java.util.Arrays.asList(new String[] {"value1"});
        ListIterator iter = tokens.listIterator();
        IdentityParser parser = new IdentityParser();

        parser.processArgs(opt, iter);

        assertEquals("value1", opt.getValue());
    }

    public void testProcessArgsThrowsParseExceptionWhenValueIsMissing() {
        Option opt = new Option("f", true, "a file");
        List tokens = java.util.Collections.EMPTY_LIST;
        ListIterator iter = tokens.listIterator();
        IdentityParser parser = new IdentityParser();

        try {
            parser.processArgs(opt, iter);
            fail("Expected a ParseException when the required argument value is absent");
        } catch (ParseException expected) {
            // documented: thrown if an argument value is required and not found
        }
    }

    // -- processOption(String, ListIterator) ----------------------------

    public void testProcessOptionThrowsParseExceptionForUnknownArg() throws Exception {
        Options options = flagOption("a");
        IdentityParser parser = new IdentityParser();
        parser.setOptions(options);
        parser.parse(options, new String[0]);

        List tokens = java.util.Collections.EMPTY_LIST;
        ListIterator iter = tokens.listIterator();

        try {
            parser.processOption("-z", iter);
            fail("Expected a ParseException because '-z' is not a known Option");
        } catch (ParseException expected) {
            // documented: thrown if arg does not represent an Option
        }
    }

    // -- processProperties(Properties) -----------------------------------

    public void testProcessPropertiesAppliesMatchingOption() throws Exception {
        Options options = flagOption("a");
        IdentityParser parser = new IdentityParser();
        CommandLine cmd = parser.parse(options, new String[0]);
        assertFalse(cmd.hasOption("a"));

        Properties properties = new Properties();
        properties.setProperty("a", "true");
        parser.processProperties(properties);

        assertTrue(parser.cmd.hasOption("a"));
    }

    // -- checkRequiredOptions() -------------------------------------------

    public void testCheckRequiredOptionsPassesWhenNoneAreRequired() throws Exception {
        Options options = flagOption("a");
        IdentityParser parser = new IdentityParser();
        parser.setOptions(options);
        parser.parse(options, new String[0]);

        parser.checkRequiredOptions();
    }

    // -- setOptions(Options) / getOptions() / getRequiredOptions() -------

    public void testSetOptionsAndGetOptionsRoundTrip() {
        Options options = flagOption("a");
        IdentityParser parser = new IdentityParser();

        parser.setOptions(options);

        assertSame(options, parser.getOptions());
    }

    public void testGetRequiredOptionsReflectsRequiredOption() {
        Options options = new Options();
        Option required = new Option("r", "required flag");
        required.setRequired(true);
        options.addOption(required);
        IdentityParser parser = new IdentityParser();

        parser.setOptions(options);

        List requiredOptions = parser.getRequiredOptions();
        assertNotNull(requiredOptions);
        assertFalse(requiredOptions.isEmpty());
    }

    public void testGetRequiredOptionsEmptyWhenNoneRequired() {
        Options options = flagOption("a");
        IdentityParser parser = new IdentityParser();

        parser.setOptions(options);

        List requiredOptions = parser.getRequiredOptions();
        assertNotNull(requiredOptions);
        assertTrue(requiredOptions.isEmpty());
    }

    // -- cmd field --------------------------------------------------------

    public void testCmdFieldHoldsLastParsedCommandLine() throws Exception {
        Options options = flagOption("a");
        IdentityParser parser = new IdentityParser();

        CommandLine cmd = parser.parse(options, new String[] {"-a"});

        assertSame(cmd, parser.cmd);
    }
}
