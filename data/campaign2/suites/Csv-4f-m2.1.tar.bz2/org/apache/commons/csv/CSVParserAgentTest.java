/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.csv;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.StringReader;
import java.io.Writer;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.junit.Test;

public class CSVParserAgentTest {

    @Test
    public void testConstructorRejectsNullReader() throws IOException {
        try {
            new CSVParser((Reader) null, CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testConstructorRejectsNullFormat() throws IOException {
        try {
            new CSVParser(new StringReader("a,b"), null);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testParseStringRejectsNullString() throws IOException {
        try {
            CSVParser.parse((String) null, CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testParseStringRejectsNullFormat() throws IOException {
        try {
            CSVParser.parse("a,b", null);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testParseFileRejectsNullFile() throws IOException {
        try {
            CSVParser.parse((File) null, CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testParseUrlRejectsNullUrl() throws IOException {
        try {
            CSVParser.parse((URL) null, Charset.forName("UTF-8"), CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testParseUrlRejectsNullCharset() throws IOException {
        try {
            CSVParser.parse(new File(".").toURI().toURL(), null, CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testInvalidFormatPropagatesFromConstructor() throws IOException {
        final CSVFormat brokenFormat = CSVFormat.DEFAULT.withDelimiter(',').withQuoteChar(',');
        try {
            new CSVParser(new StringReader("a,b"), brokenFormat);
            fail("Expected IllegalStateException");
        } catch (final IllegalStateException e) {
            // expected
        }
    }

    @Test
    public void testGetRecordsSimple() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a,b,c\n1,2,3\n"), CSVFormat.DEFAULT);
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());

        final CSVRecord record1 = records.get(0);
        assertEquals(3, record1.size());
        assertEquals("a", record1.get(0));
        assertEquals("b", record1.get(1));
        assertEquals("c", record1.get(2));

        final CSVRecord record2 = records.get(1);
        assertEquals("1", record2.get(0));
        assertEquals("2", record2.get(1));
        assertEquals("3", record2.get(2));

        assertEquals(2, parser.getRecordNumber());
        parser.close();
    }

    @Test
    public void testGetRecordsEmptyInput() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader(""), CSVFormat.DEFAULT);
        final List<CSVRecord> records = parser.getRecords();
        assertTrue(records.isEmpty());
        assertEquals(0, parser.getRecordNumber());
        parser.close();
    }

    @Test
    public void testNextRecordReturnsNullAtEof() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a,b\n"), CSVFormat.DEFAULT);
        final CSVRecord first = parser.nextRecord();
        assertNotNull(first);
        final CSVRecord second = parser.nextRecord();
        assertNull(second);
        parser.close();
    }

    @Test
    public void testGetHeaderMapNullWhenNoHeaderDefined() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a,b,c\n1,2,3\n"), CSVFormat.DEFAULT);
        assertNull(parser.getHeaderMap());
        parser.close();
    }

    @Test
    public void testHeaderMapFromExplicitHeader() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("A", "B", "C");
        final CSVParser parser = new CSVParser(new StringReader("1,2,3\n4,5,6\n"), format);
        final Map<String, Integer> headerMap = parser.getHeaderMap();
        assertEquals(Integer.valueOf(0), headerMap.get("A"));
        assertEquals(Integer.valueOf(1), headerMap.get("B"));
        assertEquals(Integer.valueOf(2), headerMap.get("C"));

        final List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        assertEquals("1", records.get(0).get("A"));
        assertEquals("6", records.get(1).get("C"));
        parser.close();
    }

    @Test
    public void testHeaderMapAutoDetectedFromFirstLine() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader();
        final CSVParser parser = new CSVParser(new StringReader("X,Y\n1,2\n"), format);
        final Map<String, Integer> headerMap = parser.getHeaderMap();
        assertEquals(Integer.valueOf(0), headerMap.get("X"));
        assertEquals(Integer.valueOf(1), headerMap.get("Y"));

        final List<CSVRecord> records = parser.getRecords();
        assertEquals(1, records.size());
        assertEquals("1", records.get(0).get("X"));
        parser.close();
    }

    @Test
    public void testHeaderMapWithSkipHeaderRecord() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("A", "B").withSkipHeaderRecord(true);
        final CSVParser parser = new CSVParser(new StringReader("A,B\n1,2\n"), format);
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(1, records.size());
        assertEquals("1", records.get(0).get("A"));
        parser.close();
    }

    @Test
    public void testGetHeaderMapIsCopy() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("A", "B");
        final CSVParser parser = new CSVParser(new StringReader("1,2\n"), format);
        final Map<String, Integer> headerMap = parser.getHeaderMap();
        headerMap.put("C", Integer.valueOf(99));
        assertFalse(parser.getHeaderMap().containsKey("C"));
        parser.close();
    }

    @Test
    public void testGetCurrentLineNumber() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a\nb\nc\n"), CSVFormat.DEFAULT);
        assertEquals(0, parser.getCurrentLineNumber());
        parser.nextRecord();
        assertEquals(1, parser.getCurrentLineNumber());
        parser.nextRecord();
        assertEquals(2, parser.getCurrentLineNumber());
        parser.close();
    }

    @Test
    public void testIteratorConsumesAllRecords() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("1,2\n3,4\n5,6\n"), CSVFormat.DEFAULT);
        final Iterator<CSVRecord> iterator = parser.iterator();
        int count = 0;
        while (iterator.hasNext()) {
            final CSVRecord record = iterator.next();
            assertEquals(2, record.size());
            count++;
        }
        assertEquals(3, count);
        parser.close();
    }

    @Test
    public void testIteratorHasNextIsIdempotent() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("1,2\n"), CSVFormat.DEFAULT);
        final Iterator<CSVRecord> iterator = parser.iterator();
        assertTrue(iterator.hasNext());
        assertTrue(iterator.hasNext());
        final CSVRecord record = iterator.next();
        assertEquals("1", record.get(0));
        assertFalse(iterator.hasNext());
    }

    @Test
    public void testIteratorNextWithoutHasNext() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("1,2\n"), CSVFormat.DEFAULT);
        final Iterator<CSVRecord> iterator = parser.iterator();
        final CSVRecord record = iterator.next();
        assertEquals("1", record.get(0));
    }

    @Test
    public void testIteratorNextThrowsAtEnd() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("1\n"), CSVFormat.DEFAULT);
        final Iterator<CSVRecord> iterator = parser.iterator();
        iterator.next();
        try {
            iterator.next();
            fail("Expected NoSuchElementException");
        } catch (final NoSuchElementException e) {
            // expected
        }
    }

    @Test
    public void testIteratorRemoveUnsupported() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("1\n"), CSVFormat.DEFAULT);
        final Iterator<CSVRecord> iterator = parser.iterator();
        try {
            iterator.remove();
            fail("Expected UnsupportedOperationException");
        } catch (final UnsupportedOperationException e) {
            // expected
        }
    }

    @Test
    public void testCloseMakesParserClosedAndIteratorExhausted() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("1,2\n3,4\n"), CSVFormat.DEFAULT);
        assertFalse(parser.isClosed());
        parser.close();
        assertTrue(parser.isClosed());
        final Iterator<CSVRecord> iterator = parser.iterator();
        assertFalse(iterator.hasNext());
        try {
            iterator.next();
            fail("Expected NoSuchElementException");
        } catch (final NoSuchElementException e) {
            // expected
        }
    }

    @Test
    public void testCloseIsIdempotent() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("1,2\n"), CSVFormat.DEFAULT);
        parser.close();
        parser.close();
        assertTrue(parser.isClosed());
    }

    @Test
    public void testUnterminatedQuoteThrowsIOException() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a,\"b"), CSVFormat.DEFAULT);
        try {
            parser.getRecords();
            fail("Expected IOException for unterminated quoted field");
        } catch (final IOException e) {
            assertTrue(e.getMessage().contains("EOF reached before encapsulated token finished"));
        }
        parser.close();
    }

    @Test
    public void testCommentsAreAttachedToRecordAndIgnoredAsValues() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withCommentStart('#');
        final CSVParser parser = new CSVParser(new StringReader("# comment line\na,b\n"), format);
        final CSVRecord record = parser.nextRecord();
        assertNotNull(record);
        assertEquals(2, record.size());
        assertEquals("a", record.get(0));
        assertEquals("comment line", record.getComment());
        parser.close();
    }

    @Test
    public void testNullStringConvertsMatchingValueToNull() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withNullString("NULL");
        final CSVParser parser = new CSVParser(new StringReader("a,NULL,c\n"), format);
        final CSVRecord record = parser.nextRecord();
        assertNotNull(record);
        assertEquals("a", record.get(0));
        assertNull(record.get(1));
        assertEquals("c", record.get(2));
        parser.close();
    }

    @Test
    public void testParseFile() throws IOException {
        final File file = File.createTempFile("CSVParserAgentTest", ".csv");
        file.deleteOnExit();
        final Writer writer = new OutputStreamWriter(new FileOutputStream(file), "UTF-8");
        try {
            writer.write("a,b\n1,2\n");
        } finally {
            writer.close();
        }

        final CSVParser parser = CSVParser.parse(file, CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("2", records.get(1).get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testParseUrl() throws IOException {
        final File file = File.createTempFile("CSVParserAgentTest", ".csv");
        file.deleteOnExit();
        final Writer writer = new OutputStreamWriter(new FileOutputStream(file), "UTF-8");
        try {
            writer.write("x,y\n5,6\n");
        } finally {
            writer.close();
        }

        final CSVParser parser = CSVParser.parse(file.toURI().toURL(), Charset.forName("UTF-8"), CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("5", records.get(1).get(0));
            assertEquals("6", records.get(1).get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetRecordsStartsFromCurrentPosition() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("1\n2\n3\n"), CSVFormat.DEFAULT);
        final CSVRecord first = parser.nextRecord();
        assertEquals("1", first.get(0));

        final List<CSVRecord> remaining = parser.getRecords();
        assertEquals(2, remaining.size());
        assertEquals("2", remaining.get(0).get(0));
        assertEquals("3", remaining.get(1).get(0));
        parser.close();
    }

}
