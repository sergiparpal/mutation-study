/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.csv;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.junit.Test;

public class CSVParserAgentTest {

    @Test(expected = IllegalArgumentException.class)
    public void testConstructorNullReaderThrows() throws IOException {
        new CSVParser(null, CSVFormat.DEFAULT);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testConstructorNullFormatThrows() throws IOException {
        new CSVParser(new StringReader("a,b"), null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testParseFileNullFileThrows() throws IOException {
        CSVParser.parse((File) null, CSVFormat.DEFAULT);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testParseFileNullFormatThrows() throws IOException {
        CSVParser.parse(new File("doesNotMatter.csv"), null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testParseStringNullStringThrows() throws IOException {
        CSVParser.parse((String) null, CSVFormat.DEFAULT);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testParseStringNullFormatThrows() throws IOException {
        CSVParser.parse("a,b", null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testParseUrlNullUrlThrows() throws IOException {
        CSVParser.parse(null, java.nio.charset.Charset.forName("UTF-8"), CSVFormat.DEFAULT);
    }

    @Test
    public void testParseStringBasic() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b,c\n1,2,3\n", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("b", records.get(0).get(1));
            assertEquals("c", records.get(0).get(2));
            assertEquals("1", records.get(1).get(0));
            assertEquals("2", records.get(1).get(1));
            assertEquals("3", records.get(1).get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testEmptyInputProducesNoRecords() throws IOException {
        final CSVParser parser = CSVParser.parse("", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertTrue(records.isEmpty());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetRecordNumberAndLineNumber() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a,b\nc,d\ne,f\n"), CSVFormat.DEFAULT);
        try {
            assertEquals(0, parser.getRecordNumber());
            final CSVRecord r1 = parser.nextRecord();
            assertNotNull(r1);
            assertEquals(1, r1.getRecordNumber());
            assertEquals(1, parser.getRecordNumber());

            final CSVRecord r2 = parser.nextRecord();
            assertNotNull(r2);
            assertEquals(2, r2.getRecordNumber());

            final CSVRecord r3 = parser.nextRecord();
            assertNotNull(r3);
            assertEquals(3, r3.getRecordNumber());

            final CSVRecord r4 = parser.nextRecord();
            assertNull(r4);
            assertEquals(3, parser.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testLastRecordWithoutTrailingNewline() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a,b\nc,d"), CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("c", records.get(1).get(0));
            assertEquals("d", records.get(1).get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testHeaderMapWithExplicitHeaders() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("1,2,3\n4,5,6\n"),
                CSVFormat.DEFAULT.withHeader("A", "B", "C"));
        try {
            final Map<String, Integer> headerMap = parser.getHeaderMap();
            assertEquals(Integer.valueOf(0), headerMap.get("A"));
            assertEquals(Integer.valueOf(1), headerMap.get("B"));
            assertEquals(Integer.valueOf(2), headerMap.get("C"));

            final List<CSVRecord> records = parser.getRecords();
            // No skipHeaderRecord, so the explicit header does not consume the first line.
            assertEquals(2, records.size());
            assertEquals("1", records.get(0).get("A"));
            assertEquals("2", records.get(0).get("B"));
            assertEquals("3", records.get(0).get("C"));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testHeaderMapReadFromFirstLine() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("A,B,C\n1,2,3\n"),
                CSVFormat.DEFAULT.withHeader());
        try {
            final Map<String, Integer> headerMap = parser.getHeaderMap();
            assertEquals(Integer.valueOf(0), headerMap.get("A"));
            assertEquals(Integer.valueOf(1), headerMap.get("B"));
            assertEquals(Integer.valueOf(2), headerMap.get("C"));

            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("1", records.get(0).get("A"));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testHeaderMapWithSkipHeaderRecord() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("A,B\n1,2\n3,4\n"),
                CSVFormat.DEFAULT.withHeader("A", "B").withSkipHeaderRecord(true));
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("1", records.get(0).get("A"));
            assertEquals("2", records.get(0).get("B"));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetHeaderMapReturnsCopy() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("A,B\n1,2\n"),
                CSVFormat.DEFAULT.withHeader("A", "B"));
        try {
            final Map<String, Integer> map1 = parser.getHeaderMap();
            map1.put("Z", Integer.valueOf(99));
            final Map<String, Integer> map2 = parser.getHeaderMap();
            assertFalse(map2.containsKey("Z"));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetHeaderMapNullWhenNoHeader() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("1,2\n"), CSVFormat.DEFAULT);
        try {
            assertNull(parser.getHeaderMap());
        } finally {
            parser.close();
        }
    }

    @Test(expected = IllegalStateException.class)
    public void testDuplicateHeaderNamesThrows() throws IOException {
        new CSVParser(new StringReader("A,A\n1,2\n"), CSVFormat.DEFAULT.withHeader());
    }

    @Test
    public void testNullStringConversion() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a,NULL,c\n"),
                CSVFormat.DEFAULT.withNullString("NULL"));
        try {
            final CSVRecord record = parser.nextRecord();
            assertNotNull(record);
            assertEquals("a", record.get(0));
            assertNull(record.get(1));
            assertEquals("c", record.get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testCommentsAreAttachedToRecord() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("# comment line\na,b,c\n"),
                CSVFormat.DEFAULT.withCommentStart('#'));
        try {
            final CSVRecord record = parser.nextRecord();
            assertNotNull(record);
            assertEquals("comment line", record.getComment());
            assertEquals("a", record.get(0));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testIsClosedAndClose() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a,b\n"), CSVFormat.DEFAULT);
        assertFalse(parser.isClosed());
        parser.close();
        assertTrue(parser.isClosed());
        // Closing an already-closed parser should not throw.
        parser.close();
    }

    @Test
    public void testIteratorHasNextFalseAfterClose() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a,b\nc,d\n"), CSVFormat.DEFAULT);
        final Iterator<CSVRecord> iterator = parser.iterator();
        assertTrue(iterator.hasNext());
        parser.close();
        assertFalse(iterator.hasNext());
    }

    @Test(expected = NoSuchElementException.class)
    public void testIteratorNextAfterCloseThrows() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a,b\n"), CSVFormat.DEFAULT);
        parser.close();
        parser.iterator().next();
    }

    @Test(expected = NoSuchElementException.class)
    public void testIteratorNextPastEndThrows() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a,b\n"), CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> iterator = parser.iterator();
            assertNotNull(iterator.next());
            assertFalse(iterator.hasNext());
            iterator.next();
        } finally {
            parser.close();
        }
    }

    @Test(expected = UnsupportedOperationException.class)
    public void testIteratorRemoveThrows() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a,b\n"), CSVFormat.DEFAULT);
        try {
            parser.iterator().remove();
        } finally {
            parser.close();
        }
    }

    @Test
    public void testIteratorMatchesRecordContent() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a,b\nc,d\n"), CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> iterator = parser.iterator();
            int count = 0;
            final String[] firstColumnExpected = {"a", "c"};
            while (iterator.hasNext()) {
                final CSVRecord record = iterator.next();
                assertEquals(firstColumnExpected[count], record.get(0));
                count++;
            }
            assertEquals(2, count);
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetRecordsWithProvidedCollection() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a,b\nc,d\n"), CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> target = new java.util.ArrayList<CSVRecord>();
            target.add(null); // pre-existing element must be preserved
            final List<CSVRecord> result = parser.getRecords(target);
            assertTrue(result == target);
            assertEquals(3, result.size());
            assertNull(result.get(0));
            assertEquals("a", result.get(1).get(0));
            assertEquals("c", result.get(2).get(0));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testQuotedValueWithEmbeddedDelimiterAndNewline() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("\"a,b\",\"c\nd\"\n"), CSVFormat.DEFAULT);
        try {
            final CSVRecord record = parser.nextRecord();
            assertNotNull(record);
            assertEquals(2, record.size());
            assertEquals("a,b", record.get(0));
            assertEquals("c\nd", record.get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testInvalidCharAfterEncapsulatedTokenThrowsIOException() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a,\"b\"c,d\n"), CSVFormat.DEFAULT);
        try {
            parser.nextRecord();
            fail("Expected IOException for invalid char between encapsulated token and delimiter");
        } catch (final IOException e) {
            assertTrue(e.getMessage().indexOf("invalid char between encapsulated token and delimiter") >= 0);
        } finally {
            parser.close();
        }
    }

    @Test
    public void testUnterminatedQuoteThrowsIOException() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("\"unterminated"), CSVFormat.DEFAULT);
        try {
            parser.nextRecord();
            fail("Expected IOException for unterminated quoted value");
        } catch (final IOException e) {
            assertTrue(e.getMessage().indexOf("EOF reached before encapsulated token finished") >= 0);
        } finally {
            parser.close();
        }
    }

    @Test
    public void testParseCustomFormatWithAlternateDelimiter() throws IOException {
        final Reader in = new StringReader("a;b;c\n1;2;3\n");
        final CSVParser parser = new CSVParser(in, CSVFormat.DEFAULT.withDelimiter(';'));
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("b", records.get(0).get(1));
            assertEquals("2", records.get(1).get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testSingleColumnRecords() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a\nb\nc\n"), CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(3, records.size());
            for (int i = 0; i < records.size(); i++) {
                assertEquals(1, records.get(i).size());
            }
        } finally {
            parser.close();
        }
    }
}
