package org.apache.commons.lang.time;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.junit.Test;

/**
 * Self-contained tests for {@link DurationFormatUtils} based solely on the
 * documented contract in api/org/apache/commons/lang/time/DurationFormatUtils.html
 * and DurationFormatUtils.Token.html.
 */
public class DurationFormatUtilsAgentTest {

    private static final TimeZone GMT = TimeZone.getTimeZone("GMT");

    // ------------------------------------------------------------------
    // helpers
    // ------------------------------------------------------------------

    /** Extracts every run of decimal digits in order, as Longs, ignoring any other characters. */
    private static List<Long> digitGroups(String s) {
        List<Long> result = new ArrayList<Long>();
        Matcher matcher = Pattern.compile("\\d+").matcher(s);
        while (matcher.find()) {
            result.add(Long.valueOf(matcher.group()));
        }
        return result;
    }

    private static List<Long> longs(long[] values) {
        List<Long> result = new ArrayList<Long>();
        for (int i = 0; i < values.length; i++) {
            result.add(Long.valueOf(values[i]));
        }
        return result;
    }

    private static long gmtMillis(int year, int month, int day, int hour, int minute, int second) {
        GregorianCalendar cal = new GregorianCalendar(GMT);
        cal.clear();
        cal.set(year, month, day, hour, minute, second);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTimeInMillis();
    }

    // ------------------------------------------------------------------
    // constructor
    // ------------------------------------------------------------------

    @Test
    public void testPublicConstructor() {
        // "This constructor is public to permit tools that require a JavaBean instance to operate."
        DurationFormatUtils instance = new DurationFormatUtils();
        assertNotNull(instance);
    }

    // ------------------------------------------------------------------
    // ISO_EXTENDED_FORMAT_PATTERN constant
    // ------------------------------------------------------------------

    @Test
    public void testIsoExtendedFormatPatternConstantValue() {
        // Documented exact constant value (see constant-values.html).
        assertEquals("'P'yyyy'Y'M'M'd'DT'H'H'm'M's.S'S'", DurationFormatUtils.ISO_EXTENDED_FORMAT_PATTERN);
    }

    // ------------------------------------------------------------------
    // formatDurationHMS(long) -- "H:m:s.S"
    // ------------------------------------------------------------------

    @Test
    public void testFormatDurationHMSRoundTrip() {
        long[] samples = {0L, 1L, 999L, 1000L, 61000L, 3661001L, 90061001L};
        for (int i = 0; i < samples.length; i++) {
            long total = samples[i];
            String formatted = DurationFormatUtils.formatDurationHMS(total);
            // Pattern is "H:m:s.S" -- exactly 4 numeric groups: hours, minutes, seconds, millis.
            List<Long> groups = digitGroups(formatted);
            assertEquals("formatDurationHMS(" + total + ") = " + formatted, 4, groups.size());

            long expectedHours = total / 3600000L;
            long remainder = total % 3600000L;
            long expectedMinutes = remainder / 60000L;
            remainder %= 60000L;
            long expectedSeconds = remainder / 1000L;
            long expectedMillis = remainder % 1000L;

            assertEquals(Long.valueOf(expectedHours), groups.get(0));
            assertEquals(Long.valueOf(expectedMinutes), groups.get(1));
            assertEquals(Long.valueOf(expectedSeconds), groups.get(2));
            assertEquals(Long.valueOf(expectedMillis), groups.get(3));

            // Reconstructing the original total from the decoded fields must be exact.
            long reconstructed = expectedHours * 3600000L + expectedMinutes * 60000L
                    + expectedSeconds * 1000L + expectedMillis;
            assertEquals(total, reconstructed);
        }
    }

    @Test
    public void testFormatDurationHMSHasNoDayRollover() {
        // No 'd' token appears in "H:m:s.S" so hours must accumulate past 24.
        long durationMillis = 25L * 3600000L; // 25 hours
        List<Long> groups = digitGroups(DurationFormatUtils.formatDurationHMS(durationMillis));
        assertEquals(Long.valueOf(25L), groups.get(0));
        assertEquals(Long.valueOf(0L), groups.get(1));
        assertEquals(Long.valueOf(0L), groups.get(2));
        assertEquals(Long.valueOf(0L), groups.get(3));
    }

    // ------------------------------------------------------------------
    // formatDurationISO(long) -- "such as P7D6TH5M4.321S"
    // ------------------------------------------------------------------

    // @Test  // pruned: failed on the fixed version
    public void testFormatDurationISORoundTrip() {
        long[] samples = {0L, 1L, 999L, 1000L, 61000L, 3661001L, 90000000L};
        for (int i = 0; i < samples.length; i++) {
            long total = samples[i];
            String formatted = DurationFormatUtils.formatDurationISO(total);
            assertTrue("should start with P: " + formatted, formatted.startsWith("P"));
            assertTrue("should end with S: " + formatted, formatted.endsWith("S"));

            // "days and lower fields": days, hours, minutes, seconds, millis -- 5 numeric groups.
            List<Long> groups = digitGroups(formatted);
            assertEquals("formatDurationISO(" + total + ") = " + formatted, 5, groups.size());

            long expectedDays = total / 86400000L;
            long remainder = total % 86400000L;
            long expectedHours = remainder / 3600000L;
            remainder %= 3600000L;
            long expectedMinutes = remainder / 60000L;
            remainder %= 60000L;
            long expectedSeconds = remainder / 1000L;
            long expectedMillis = remainder % 1000L;

            assertEquals(longs(new long[] {expectedDays, expectedHours, expectedMinutes, expectedSeconds, expectedMillis}), groups);
        }
    }

    // @Test  // pruned: failed on the fixed version
    public void testFormatDurationISODayRollover() {
        // 25 hours: with a 'd' token present, hours must roll into a day.
        long durationMillis = 25L * 3600000L;
        List<Long> groups = digitGroups(DurationFormatUtils.formatDurationISO(durationMillis));
        assertEquals(longs(new long[] {1L, 1L, 0L, 0L, 0L}), groups);
    }

    // ------------------------------------------------------------------
    // formatDuration(long, String) and formatDuration(long, String, boolean)
    // ------------------------------------------------------------------

    @Test
    public void testFormatDurationTwoArgPadsWithZerosByDefault() {
        // "Formats ... using the specified format, and padding with zeros and using the default timezone."
        long[] samples = {0L, 1L, 61000L, 3661001L};
        String[] patterns = {"d", "H:mm:ss.SSS", "yyyy-MM-dd"};
        for (int i = 0; i < samples.length; i++) {
            for (int j = 0; j < patterns.length; j++) {
                String twoArg = DurationFormatUtils.formatDuration(samples[i], patterns[j]);
                String threeArgTrue = DurationFormatUtils.formatDuration(samples[i], patterns[j], true);
                assertEquals(threeArgTrue, twoArg);
            }
        }
    }

    @Test
    public void testFormatDurationEmptyPatternProducesEmptyString() {
        // An empty pattern parses to zero tokens, so there is nothing to render.
        assertEquals("", DurationFormatUtils.formatDuration(123456L, ""));
        assertEquals("", DurationFormatUtils.formatDuration(123456L, "", false));
    }

    // ------------------------------------------------------------------
    // formatDurationWords(long, boolean, boolean)
    // ------------------------------------------------------------------

    @Test
    public void testFormatDurationWordsPluralizationSingular() {
        long oneDayMillis = 86400000L;
        String result = DurationFormatUtils.formatDurationWords(oneDayMillis, false, false);
        assertTrue(result, result.contains("1 day"));
        assertFalse(result, result.contains("1 days"));
    }

    @Test
    public void testFormatDurationWordsPluralizationPlural() {
        long twoDaysMillis = 2L * 86400000L;
        String result = DurationFormatUtils.formatDurationWords(twoDaysMillis, false, false);
        assertTrue(result, result.contains("2 days"));
    }

    @Test
    public void testFormatDurationWordsSuppressLeadingZeroElements() {
        // 0 days, 3 hours: a leading zero day element must not appear when suppressed.
        long durationMillis = 3L * 3600000L;
        String suppressed = DurationFormatUtils.formatDurationWords(durationMillis, true, false);
        assertFalse(suppressed, suppressed.contains("day"));
        assertTrue(suppressed, suppressed.contains("hour"));
    }

    @Test
    public void testFormatDurationWordsSuppressTrailingZeroElements() {
        // 1 day, 2 hours, 0 minutes, 0 seconds: trailing zero elements must be dropped when suppressed.
        long durationMillis = 86400000L + 2L * 3600000L;
        String suppressed = DurationFormatUtils.formatDurationWords(durationMillis, false, true);
        assertTrue(suppressed, suppressed.contains("day"));
        assertTrue(suppressed, suppressed.contains("hour"));
        assertFalse(suppressed, suppressed.contains("minute"));
        assertFalse(suppressed, suppressed.contains("second"));
    }

    @Test
    public void testFormatDurationWordsNoSuppressionOnAllZero() {
        String result = DurationFormatUtils.formatDurationWords(0L, false, false);
        assertTrue(result, result.contains("day"));
        assertTrue(result, result.contains("hour"));
        assertTrue(result, result.contains("minute"));
        assertTrue(result, result.contains("second"));
    }

    // ------------------------------------------------------------------
    // formatPeriodISO(long, long)
    // ------------------------------------------------------------------

    @Test
    public void testFormatPeriodISOZeroDifferenceIsAllZero() {
        long now = gmtMillis(2020, Calendar.JUNE, 15, 12, 0, 0);
        String result = DurationFormatUtils.formatPeriodISO(now, now);
        assertTrue(result, result.startsWith("P"));
        assertTrue(result, result.endsWith("S"));
        List<Long> groups = digitGroups(result);
        for (int i = 0; i < groups.size(); i++) {
            assertEquals(Long.valueOf(0L), groups.get(i));
        }
    }

    @Test
    public void testFormatPeriodISOSubSecondElapsed() {
        long start = gmtMillis(2020, Calendar.JUNE, 15, 12, 0, 0);
        long end = start + 1500L; // 1 second + 500 millis later, same day
        String result = DurationFormatUtils.formatPeriodISO(start, end);
        List<Long> groups = digitGroups(result);
        // years, months, days, hours, minutes are all zero; seconds=1, millis=500
        assertEquals(longs(new long[] {0L, 0L, 0L, 0L, 0L, 1L, 500L}), groups);
    }

    // ------------------------------------------------------------------
    // formatPeriod(long, long, String) and formatPeriod(long, long, String, boolean, TimeZone)
    // ------------------------------------------------------------------

    @Test
    public void testFormatPeriodThreeArgMatchesDefaultTimezonePadTrue() {
        long start = gmtMillis(2020, Calendar.JUNE, 15, 10, 0, 0);
        long end = start + 2L * 3600000L;
        String threeArg = DurationFormatUtils.formatPeriod(start, end, "d H m s");
        String fourArg = DurationFormatUtils.formatPeriod(start, end, "d H m s", true, TimeZone.getDefault());
        assertEquals(fourArg, threeArg);
    }

    @Test
    public void testFormatPeriodZeroDifferencePadded() {
        long now = gmtMillis(2020, Calendar.JUNE, 15, 12, 0, 0);
        String result = DurationFormatUtils.formatPeriod(now, now, "yyyy-MM-dd HH:mm:ss", true, GMT);
        assertEquals("0000-00-00 00:00:00", result);
    }

    @Test
    public void testFormatPeriodHoursRollIntoDaysWhenDayTokenPresent() {
        long start = gmtMillis(2020, Calendar.JUNE, 15, 10, 0, 0);
        long end = start + 25L * 3600000L; // exactly 25 hours later
        String result = DurationFormatUtils.formatPeriod(start, end, "d H", false, GMT);
        assertEquals("1 1", result);
    }

    @Test
    public void testFormatPeriodHoursDoNotRollWithoutDayToken() {
        long start = gmtMillis(2020, Calendar.JUNE, 15, 10, 0, 0);
        long end = start + 25L * 3600000L; // exactly 25 hours later
        String result = DurationFormatUtils.formatPeriod(start, end, "H m s", false, GMT);
        assertEquals("25 0 0", result);
    }

    // @Test  // pruned: failed on the fixed version
    public void testFormatPeriodPadWithZerosFalseVsTrue() {
        long start = gmtMillis(2020, Calendar.JUNE, 15, 10, 0, 0);
        long end = start + (5L * 3600000L + 3L * 60000L + 2045L); // 5h 3m 2.045s later
        String padded = DurationFormatUtils.formatPeriod(start, end, "HH:mm:ss.SSS", true, GMT);
        String unpadded = DurationFormatUtils.formatPeriod(start, end, "H:m:s.S", false, GMT);
        assertEquals("05:03:02.045", padded);
        assertEquals("5:3:2.45", unpadded);
    }

    // ------------------------------------------------------------------
    // package-private format(Token[], int, int, int, int, int, int, int, boolean)
    // and lexx(String) -- accessible from this same-package test.
    // ------------------------------------------------------------------

    @Test
    public void testLexxEmptyStringYieldsNoTokens() {
        DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("");
        assertEquals(0, tokens.length);
    }

    @Test
    public void testLexxRepeatedLetterProducesSingleTokenWithCount() {
        DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("yyyy");
        assertEquals(1, tokens.length);
        assertSame(DurationFormatUtils.y, tokens[0].getValue());
        assertEquals(4, tokens[0].getCount());
    }

    @Test
    public void testLexxDistinctSpecialLetters() {
        DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("yyyyMMdd");
        assertEquals(3, tokens.length);
        assertSame(DurationFormatUtils.y, tokens[0].getValue());
        assertEquals(4, tokens[0].getCount());
        assertSame(DurationFormatUtils.M, tokens[1].getValue());
        assertEquals(2, tokens[1].getCount());
        assertSame(DurationFormatUtils.d, tokens[2].getValue());
        assertEquals(2, tokens[2].getCount());
    }

    // @Test  // pruned: failed on the fixed version
    public void testLexxContainsTokenWithValueHelper() {
        DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("y-y");
        assertEquals(3, tokens.length);
        assertTrue(DurationFormatUtils.Token.containsTokenWithValue(tokens, DurationFormatUtils.y));
        assertFalse(DurationFormatUtils.Token.containsTokenWithValue(tokens, DurationFormatUtils.H));
    }

    // @Test  // pruned: failed on the fixed version
    public void testFormatWithExplicitTokensPaddedAndUnpadded() {
        DurationFormatUtils.Token[] paddedTokens = DurationFormatUtils.lexx("HH:mm:ss.SSS");
        String padded = DurationFormatUtils.format(paddedTokens, 0, 0, 0, 5, 3, 2, 45, true);
        assertEquals("05:03:02.045", padded);

        DurationFormatUtils.Token[] unpaddedTokens = DurationFormatUtils.lexx("H:m:s.S");
        String unpadded = DurationFormatUtils.format(unpaddedTokens, 0, 0, 0, 5, 3, 2, 45, false);
        assertEquals("5:3:2.45", unpadded);
    }

    @Test
    public void testFormatWithNoTokensProducesEmptyString() {
        DurationFormatUtils.Token[] noTokens = new DurationFormatUtils.Token[0];
        String result = DurationFormatUtils.format(noTokens, 1, 2, 3, 4, 5, 6, 7, true);
        assertEquals("", result);
    }

    // ------------------------------------------------------------------
    // Token (package-private nested class) -- equals/hashCode contract
    // ------------------------------------------------------------------

    @Test
    public void testTokenHashCodeIgnoresCount() {
        // "Thus 'TT' and 'TTTT' will have the same hashcode."
        DurationFormatUtils.Token short1 = new DurationFormatUtils.Token(DurationFormatUtils.y, 2);
        DurationFormatUtils.Token long1 = new DurationFormatUtils.Token(DurationFormatUtils.y, 4);
        assertEquals(short1.hashCode(), long1.hashCode());
    }

    @Test
    public void testTokenEqualsReflexiveAndNullSafe() {
        DurationFormatUtils.Token token = new DurationFormatUtils.Token(DurationFormatUtils.y, 4);
        assertTrue(token.equals(token));
        assertFalse(token.equals(null));
        assertFalse(token.equals("not a token"));
    }

    @Test
    public void testTokenEqualsSameValueAndCount() {
        DurationFormatUtils.Token a = new DurationFormatUtils.Token(DurationFormatUtils.H, 2);
        DurationFormatUtils.Token b = new DurationFormatUtils.Token(DurationFormatUtils.H, 2);
        assertTrue(a.equals(b));
        assertTrue(b.equals(a));
    }

    @Test
    public void testTokenIncrementIncreasesCount() {
        DurationFormatUtils.Token token = new DurationFormatUtils.Token(DurationFormatUtils.s, 1);
        assertEquals(1, token.getCount());
        token.increment();
        assertEquals(2, token.getCount());
    }

    @Test
    public void testTokenToStringIsNonEmpty() {
        DurationFormatUtils.Token token = new DurationFormatUtils.Token(DurationFormatUtils.m, 3);
        String s = token.toString();
        assertNotNull(s);
        assertTrue(s.length() > 0);
    }

    @Test
    public void testTokenGetValueReturnsWrappedValue() {
        DurationFormatUtils.Token token = new DurationFormatUtils.Token(DurationFormatUtils.S, 1);
        assertSame(DurationFormatUtils.S, token.getValue());
    }
}
