package org.apache.commons.csv;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

import junit.framework.TestCase;

/**
 * Self-contained JUnit 3.8 tests for {@link CSVRecord}, based solely on its
 * published javadoc contract.
 */
public class CSVRecordAgentTest extends TestCase {

    private enum Header {
        FIRST, SECOND
    }

    private static Map<String, Integer> mapping(String[] names) {
        Map<String, Integer> m = new LinkedHashMap<String, Integer>();
        for (int i = 0; i < names.length; i++) {
            m.put(names[i], Integer.valueOf(i));
        }
        return m;
    }

    // --- get(int) --------------------------------------------------------

    public void testGetByIndexReturnsValueAtIndex() {
        String[] values = { "a", "b", "c" };
        CSVRecord record = new CSVRecord(values, null, null, 1L);
        assertEquals("a", record.get(0));
        assertEquals("b", record.get(1));
        assertEquals("c", record.get(2));
    }

    public void testGetByIndexOutOfBoundsThrows() {
        String[] values = { "a", "b" };
        CSVRecord record = new CSVRecord(values, null, null, 1L);
        try {
            record.get(2);
            fail("Expected an IndexOutOfBoundsException for an index past the end");
        } catch (IndexOutOfBoundsException expected) {
            // documented implicitly: i is "a column index (0-based)"
        }
        try {
            record.get(-1);
            fail("Expected an IndexOutOfBoundsException for a negative index");
        } catch (IndexOutOfBoundsException expected) {
            // documented implicitly
        }
    }

    public void testGetByIndexOnEmptyRecord() {
        CSVRecord record = new CSVRecord(new String[0], null, null, 1L);
        try {
            record.get(0);
            fail("Expected an IndexOutOfBoundsException for an empty record");
        } catch (IndexOutOfBoundsException expected) {
            // documented implicitly
        }
    }

    // --- get(Enum) ---------------------------------------------------------

    public void testGetByEnumDelegatesToName() {
        String[] values = { "x", "y" };
        Map<String, Integer> map = mapping(new String[] { "FIRST", "SECOND" });
        CSVRecord record = new CSVRecord(values, map, null, 1L);
        assertEquals("x", record.get(Header.FIRST));
        assertEquals("y", record.get(Header.SECOND));
    }

    public void testGetByEnumUnmappedThrows() {
        String[] values = { "x", "y" };
        Map<String, Integer> map = mapping(new String[] { "FIRST" });
        CSVRecord record = new CSVRecord(values, map, null, 1L);
        try {
            record.get(Header.SECOND);
            fail("Expected an IllegalArgumentException for an unmapped enum name");
        } catch (IllegalArgumentException expected) {
            // documented: name is not mapped
        }
    }

    // --- get(String) ---------------------------------------------------------

    public void testGetByNameReturnsMappedValue() {
        String[] values = { "v1", "v2" };
        Map<String, Integer> map = mapping(new String[] { "H1", "H2" });
        CSVRecord record = new CSVRecord(values, map, null, 1L);
        assertEquals("v1", record.get("H1"));
        assertEquals("v2", record.get("H2"));
    }

    public void testGetByNameWithoutMappingThrowsIllegalState() {
        CSVRecord record = new CSVRecord(new String[] { "a" }, null, null, 1L);
        try {
            record.get("whatever");
            fail("Expected an IllegalStateException when no header mapping was provided");
        } catch (IllegalStateException expected) {
            // documented: no header mapping was provided
        }
    }

    public void testGetByNameNotMappedThrowsIllegalArgument() {
        Map<String, Integer> map = mapping(new String[] { "H1" });
        CSVRecord record = new CSVRecord(new String[] { "v1" }, map, null, 1L);
        try {
            record.get("unknown");
            fail("Expected an IllegalArgumentException for a name not mapped");
        } catch (IllegalArgumentException expected) {
            // documented: name is not mapped
        }
    }

    public void pruned_testGetByNameInconsistentRecordThrowsIllegalArgument() {
        Map<String, Integer> map = new LinkedHashMap<String, Integer>();
        map.put("A", Integer.valueOf(5));
        CSVRecord record = new CSVRecord(new String[] { "only one" }, map, null, 1L);
        assertFalse(record.isConsistent());
        try {
            record.get("A");
            fail("Expected an IllegalArgumentException when the record is inconsistent");
        } catch (IllegalArgumentException expected) {
            // documented: or if the record is inconsistent
        }
    }

    // --- getComment() --------------------------------------------------------

    public void testGetCommentPresent() {
        CSVRecord record = new CSVRecord(new String[] { "a" }, null, "a comment", 1L);
        assertEquals("a comment", record.getComment());
    }

    public void testGetCommentAbsentIsNull() {
        CSVRecord record = new CSVRecord(new String[] { "a" }, null, null, 1L);
        assertNull(record.getComment());
    }

    // --- getRecordNumber() --------------------------------------------------------

    public void testGetRecordNumber() {
        CSVRecord record = new CSVRecord(new String[] { "a" }, null, null, 42L);
        assertEquals(42L, record.getRecordNumber());
    }

    public void testGetRecordNumberZero() {
        CSVRecord record = new CSVRecord(new String[] { "a" }, null, null, 0L);
        assertEquals(0L, record.getRecordNumber());
    }

    // --- isConsistent() --------------------------------------------------------

    public void testIsConsistentWithoutHeaderMapping() {
        CSVRecord record = new CSVRecord(new String[] { "a", "b", "c" }, null, null, 1L);
        assertTrue(record.isConsistent());
    }

    public void testIsConsistentWhenSizesMatch() {
        Map<String, Integer> map = mapping(new String[] { "H1", "H2" });
        CSVRecord record = new CSVRecord(new String[] { "v1", "v2" }, map, null, 1L);
        assertTrue(record.isConsistent());
    }

    public void testIsConsistentWhenSizesDiffer() {
        Map<String, Integer> map = mapping(new String[] { "H1", "H2", "H3" });
        CSVRecord record = new CSVRecord(new String[] { "v1", "v2" }, map, null, 1L);
        assertFalse(record.isConsistent());
    }

    // --- isMapped(String) --------------------------------------------------------

    public void testIsMappedWithoutHeaderMapping() {
        CSVRecord record = new CSVRecord(new String[] { "a" }, null, null, 1L);
        assertFalse(record.isMapped("anything"));
    }

    public void testIsMappedTrueAndFalse() {
        Map<String, Integer> map = mapping(new String[] { "H1" });
        CSVRecord record = new CSVRecord(new String[] { "v1" }, map, null, 1L);
        assertTrue(record.isMapped("H1"));
        assertFalse(record.isMapped("H2"));
    }

    // --- isSet(String) --------------------------------------------------------

    public void testIsSetWithoutHeaderMapping() {
        CSVRecord record = new CSVRecord(new String[] { "a" }, null, null, 1L);
        assertFalse(record.isSet("anything"));
    }

    public void testIsSetMappedAndUnmapped() {
        Map<String, Integer> map = mapping(new String[] { "H1", "H2" });
        CSVRecord record = new CSVRecord(new String[] { "v1", "v2" }, map, null, 1L);
        assertTrue(record.isSet("H1"));
        assertTrue(record.isSet("H2"));
        assertFalse(record.isSet("H3"));
    }

    // --- iterator() --------------------------------------------------------

    public void testIteratorVisitsAllValuesInOrder() {
        String[] values = { "a", "b", "c" };
        CSVRecord record = new CSVRecord(values, null, null, 1L);
        Iterator<String> it = record.iterator();
        assertTrue(it.hasNext());
        assertEquals("a", it.next());
        assertTrue(it.hasNext());
        assertEquals("b", it.next());
        assertTrue(it.hasNext());
        assertEquals("c", it.next());
        assertFalse(it.hasNext());
    }

    public void testIteratorOnEmptyRecordHasNoElements() {
        CSVRecord record = new CSVRecord(new String[0], null, null, 1L);
        Iterator<String> it = record.iterator();
        assertFalse(it.hasNext());
    }

    public void testIterableForEachLoop() {
        String[] values = { "x", "y" };
        CSVRecord record = new CSVRecord(values, null, null, 1L);
        int count = 0;
        for (String value : record) {
            assertEquals(values[count], value);
            count++;
        }
        assertEquals(values.length, count);
    }

    // --- putIn(Map) --------------------------------------------------------

    public void testPutInPopulatesGivenMapAndReturnsIt() {
        Map<String, Integer> map = mapping(new String[] { "H1", "H2" });
        CSVRecord record = new CSVRecord(new String[] { "v1", "v2" }, map, null, 1L);
        Map<String, String> target = new HashMap<String, String>();
        Map<String, String> result = record.putIn(target);
        assertSame(target, result);
        assertEquals("v1", result.get("H1"));
        assertEquals("v2", result.get("H2"));
    }

    public void pruned_testPutInWithoutHeaderMappingLeavesMapUnchanged() {
        CSVRecord record = new CSVRecord(new String[] { "a" }, null, null, 1L);
        Map<String, String> target = new HashMap<String, String>();
        Map<String, String> result = record.putIn(target);
        assertSame(target, result);
        assertTrue(result.isEmpty());
    }

    // --- size() --------------------------------------------------------

    public void testSizeMatchesValueCount() {
        CSVRecord record = new CSVRecord(new String[] { "a", "b", "c" }, null, null, 1L);
        assertEquals(3, record.size());
    }

    public void testSizeOfEmptyRecordIsZero() {
        CSVRecord record = new CSVRecord(new String[0], null, null, 1L);
        assertEquals(0, record.size());
    }

    // --- toMap() --------------------------------------------------------

    public void pruned_testToMapWithoutHeadersIsEmpty() {
        CSVRecord record = new CSVRecord(new String[] { "a", "b" }, null, null, 1L);
        Map<String, String> map = record.toMap();
        assertNotNull(map);
        assertTrue(map.isEmpty());
    }

    public void testToMapWithHeadersContainsAllMappedValues() {
        Map<String, Integer> headerMap = mapping(new String[] { "H1", "H2" });
        CSVRecord record = new CSVRecord(new String[] { "v1", "v2" }, headerMap, null, 1L);
        Map<String, String> map = record.toMap();
        assertNotNull(map);
        assertEquals(2, map.size());
        assertEquals("v1", map.get("H1"));
        assertEquals("v2", map.get("H2"));
    }

    // --- toString() --------------------------------------------------------

    public void testToStringIsNeverNull() {
        CSVRecord record = new CSVRecord(new String[] { "a" }, null, "c", 1L);
        assertNotNull(record.toString());
    }

    public void testToStringIsStableForUnchangedState() {
        CSVRecord record = new CSVRecord(new String[] { "a" }, null, "c", 1L);
        assertEquals(record.toString(), record.toString());
    }

    // --- values() --------------------------------------------------------

    public void testValuesMatchesConstructorInput() {
        String[] values = { "a", "b", "c" };
        CSVRecord record = new CSVRecord(values, null, null, 1L);
        String[] result = record.values();
        assertEquals(values.length, result.length);
        for (int i = 0; i < values.length; i++) {
            assertEquals(values[i], result[i]);
        }
    }

    // --- type contract --------------------------------------------------------

    public void testImplementsSerializableAndIterable() {
        CSVRecord record = new CSVRecord(new String[] { "a" }, null, null, 1L);
        assertTrue(record instanceof Serializable);
        assertTrue(record instanceof Iterable);
    }
}
