package org.apache.commons.lang;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import org.junit.Test;

/**
 * Self-contained tests for {@link Entities}, based solely on the contract
 * documented in the generated javadoc under api/.
 */
public class EntitiesAgentTest {

    /** A Writer whose write methods always fail, to exercise the documented IOException contract. */
    private static class FailingWriter extends Writer {
        public void write(char[] cbuf, int off, int len) throws IOException {
            throw new IOException("boom");
        }
        public void write(int c) throws IOException {
            throw new IOException("boom");
        }
        public void flush() throws IOException {
        }
        public void close() throws IOException {
        }
    }

    // --- Static field contract -------------------------------------------------

    @Test
    public void testStaticFieldsAreDistinctAndNonNull() {
        assertNotNull(Entities.XML);
        assertNotNull(Entities.HTML32);
        assertNotNull(Entities.HTML40);
        assertNotSame(Entities.XML, Entities.HTML32);
        assertNotSame(Entities.XML, Entities.HTML40);
        assertNotSame(Entities.HTML32, Entities.HTML40);
    }

    // --- XML predefined entities (mandated by the XML standard the field documents) ---

    @Test
    public void testXmlEscapesThePredefinedXmlEntities() {
        assertEquals("&lt;", Entities.XML.escape("<"));
        assertEquals("&gt;", Entities.XML.escape(">"));
        assertEquals("&amp;", Entities.XML.escape("&"));
        assertEquals("&quot;", Entities.XML.escape("\""));
        assertEquals("&apos;", Entities.XML.escape("'"));
    }

    @Test
    public void testXmlUnescapesThePredefinedXmlEntities() {
        assertEquals("<", Entities.XML.unescape("&lt;"));
        assertEquals(">", Entities.XML.unescape("&gt;"));
        assertEquals("&", Entities.XML.unescape("&amp;"));
        assertEquals("\"", Entities.XML.unescape("&quot;"));
        assertEquals("'", Entities.XML.unescape("&apos;"));
    }

    @Test
    public void testXmlEscapeLeavesPlainTextUnchanged() {
        assertEquals("hello world", Entities.XML.escape("hello world"));
    }

    // --- HTML entities (HTML 3.2 / 4.0 character entities referenced in the javadoc) ---

    @Test
    public void testHtml32EscapesTheBasicMarkupEntities() {
        assertEquals("&lt;a&gt;&amp;&quot;", Entities.HTML32.escape("<a>&\""));
    }

    @Test
    public void testHtml40EscapesTheBasicMarkupEntities() {
        assertEquals("&lt;a&gt;&amp;&quot;", Entities.HTML40.escape("<a>&\""));
    }

    @Test
    public void testHtml32UnescapesNonBreakingSpace() {
        // nbsp is part of the "HTML 3.2 Character Entities for ISO Latin-1" set
        // explicitly referenced by this class's javadoc.
        assertEquals(" ", Entities.HTML32.unescape("&nbsp;"));
    }

    @Test
    public void testHtml40UnescapesNonBreakingSpace() {
        assertEquals(" ", Entities.HTML40.unescape("&nbsp;"));
    }

    // --- addEntity / entityValue / entityName / escape / unescape round trip, per javadoc example ---

    @Test
    public void testAddEntityEscapeUnescapeRoundTripMatchesJavadocExample() {
        Entities entities = new Entities();
        entities.addEntity("foo", 0xA1);

        assertEquals("&foo;", entities.escape("¡"));
        assertEquals("¡", entities.unescape("&foo;"));
        assertEquals(0xA1, entities.entityValue("foo"));
        assertEquals("foo", entities.entityName(0xA1));
    }

    @Test
    public void testAddEntityZeroValueBoundary() {
        Entities entities = new Entities();
        entities.addEntity("zero", 0);

        assertEquals(0, entities.entityValue("zero"));
        assertEquals("zero", entities.entityName(0));
    }

    @Test
    public void testEntityValueForUnknownNameIsNegative() {
        // A valid entity value is a non-negative character code, so a negative
        // result is the only way entityValue can signal "no such entity".
        Entities entities = new Entities();
        entities.addEntity("foo", 1);

        assertTrue(entities.entityValue("this-name-was-never-added") < 0);
    }

    @Test
    public void testEntityNameForUnknownValueIsNull() {
        Entities entities = new Entities();
        entities.addEntity("foo", 1);

        assertNull(entities.entityName(123456));
    }

    @Test
    public void testAddEntitiesArrayAddsAllRows() {
        Entities entities = new Entities();
        entities.addEntities(new String[][] {
            { "bar", "9731" },
            { "baz", "65" }
        });

        assertEquals(9731, entities.entityValue("bar"));
        assertEquals(65, entities.entityValue("baz"));
        assertEquals("baz", entities.entityName(65));
        assertEquals("bar", entities.entityName(9731));
    }

    @Test
    public void testAddEntitiesWithEmptyArrayIsNoOp() {
        Entities entities = new Entities();
        entities.addEntities(new String[0][0]);

        assertTrue(entities.entityValue("anything") < 0);
    }

    // --- escape / unescape boundary cases ---

    @Test
    public void testEscapeEmptyStringReturnsEmptyString() {
        Entities entities = new Entities();
        assertEquals("", entities.escape(""));
    }

    @Test
    public void testUnescapeEmptyStringReturnsEmptyString() {
        Entities entities = new Entities();
        assertEquals("", entities.unescape(""));
    }

    @Test
    public void testEscapeLeavesUnmatchedCharactersUnchanged() {
        Entities entities = new Entities();
        entities.addEntity("foo", 0xA1);

        assertEquals("hello world", entities.escape("hello world"));
    }

    @Test
    public void testUnescapeLeavesStringWithoutEntitiesUnchanged() {
        Entities entities = new Entities();
        entities.addEntity("foo", 0xA1);

        assertEquals("hello world", entities.unescape("hello world"));
    }

    @Test
    public void testUnescapeHandlesNumericCharacterReferences() {
        // Numeric character references ("&#NNN;") are part of the standard
        // XML/HTML entity syntax that unescape() is documented to process.
        Entities entities = new Entities();
        assertEquals("AB", entities.unescape("&#65;&#66;"));
    }

    // --- Writer-based overloads must agree with the String-based ones ---

    @Test
    public void testEscapeWriterProducesSameResultAsEscapeString() throws IOException {
        Entities entities = new Entities();
        entities.addEntity("foo", 0xA1);

        String expected = entities.escape("¡ plain text");
        StringWriter writer = new StringWriter();
        entities.escape(writer, "¡ plain text");

        assertEquals(expected, writer.toString());
    }

    @Test
    public void testUnescapeWriterProducesSameResultAsUnescapeString() throws IOException {
        Entities entities = new Entities();
        entities.addEntity("foo", 0xA1);

        String expected = entities.unescape("&foo; plain text");
        StringWriter writer = new StringWriter();
        entities.unescape(writer, "&foo; plain text");

        assertEquals(expected, writer.toString());
    }

    @Test
    public void testEscapeWriterPropagatesIOException() {
        Entities entities = new Entities();
        try {
            entities.escape(new FailingWriter(), "x");
            fail("Expected an IOException from the failing Writer");
        } catch (IOException expected) {
            // documented behavior
        }
    }

    @Test
    public void testUnescapeWriterPropagatesIOException() {
        Entities entities = new Entities();
        try {
            entities.unescape(new FailingWriter(), "x");
            fail("Expected an IOException from the failing Writer");
        } catch (IOException expected) {
            // documented behavior
        }
    }
}
