/*
 * Copyright (C) 2024 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.gson.stream;

import junit.framework.TestCase;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

/**
 * Self-contained unit tests for {@link JsonWriter}.
 */
public class JsonWriterAgentTest extends TestCase {

  public void testConstructorRejectsNullWriter() throws Exception {
    try {
      new JsonWriter(null);
      fail();
    } catch (NullPointerException expected) {
      assertEquals("out == null", expected.getMessage());
    }
  }

  public void testDefaults() throws Exception {
    JsonWriter writer = new JsonWriter(new StringWriter());
    assertFalse(writer.isLenient());
    assertFalse(writer.isHtmlSafe());
    assertTrue(writer.getSerializeNulls());
  }

  public void testEmptyObject() throws Exception {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginObject();
    writer.endObject();
    writer.close();
    assertEquals("{}", stringWriter.toString());
  }

  public void testEmptyArray() throws Exception {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.endArray();
    writer.close();
    assertEquals("[]", stringWriter.toString());
  }

  public void testObjectWithValues() throws Exception {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginObject();
    writer.name("a").value(1L);
    writer.name("b").value(2.5);
    writer.name("c").value(true);
    writer.name("d").value((String) null);
    writer.name("e").value("text");
    writer.endObject();
    writer.close();
    assertEquals("{\"a\":1,\"b\":2.5,\"c\":true,\"d\":null,\"e\":\"text\"}",
        stringWriter.toString());
  }

  public void testNestedArraysAndObjects() throws Exception {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginObject();
    writer.name("array");
    writer.beginArray();
    writer.value(1L);
    writer.beginObject();
    writer.name("nested").value("value");
    writer.endObject();
    writer.endArray();
    writer.endObject();
    writer.close();
    assertEquals("{\"array\":[1,{\"nested\":\"value\"}]}", stringWriter.toString());
  }

  public void testNullValueSkippedWhenSerializeNullsFalse() throws Exception {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setSerializeNulls(false);
    assertFalse(writer.getSerializeNulls());
    writer.beginObject();
    writer.name("a").value((String) null);
    writer.name("b").value(5L);
    writer.endObject();
    writer.close();
    assertEquals("{\"b\":5}", stringWriter.toString());
  }

  public void testNullValueWrittenByDefault() throws Exception {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.nullValue();
    writer.endArray();
    writer.close();
    assertEquals("[null]", stringWriter.toString());
  }

  public void testBoxedNullValues() throws Exception {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.value((Boolean) null);
    writer.value((Number) null);
    writer.endArray();
    writer.close();
    assertEquals("[null,null]", stringWriter.toString());
  }

  public void testStringEscaping() throws Exception {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setLenient(true);
    writer.value("a\"b\\c\td\ne\bf\rg\fh\u0001i j k");
    writer.close();
    assertEquals(
        "\"a\\\"b\\\\c\\td\\ne\\bf\\rg\\fh\\u0001i\\u2028j\\u2029k\"",
        stringWriter.toString());
  }

  public void testHtmlSafeEscapesSpecialCharacters() throws Exception {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setLenient(true);
    writer.setHtmlSafe(true);
    assertTrue(writer.isHtmlSafe());
    writer.value("<a>&b=c'd");
    writer.close();
    assertEquals("\"\\u003ca\\u003e\\u0026b\\u003dc\\u0027d\"", stringWriter.toString());
  }

  public void testNonHtmlSafeLeavesSpecialCharactersAlone() throws Exception {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setLenient(true);
    writer.value("<a>&b");
    writer.close();
    assertEquals("\"<a>&b\"", stringWriter.toString());
  }

  public void testIndentPrettyPrinting() throws Exception {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setIndent("  ");
    writer.beginObject();
    writer.name("a");
    writer.beginArray();
    writer.value(1L);
    writer.value(2L);
    writer.endArray();
    writer.endObject();
    writer.close();
    String expected = "{\n  \"a\": [\n    1,\n    2\n  ]\n}";
    assertEquals(expected, stringWriter.toString());
  }

  public void testSetIndentEmptyStringDisablesPrettyPrinting() throws Exception {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setIndent("  ");
    writer.setIndent("");
    writer.beginObject();
    writer.name("a").value(1L);
    writer.endObject();
    writer.close();
    assertEquals("{\"a\":1}", stringWriter.toString());
  }

  public void testJsonValueWrittenRaw() throws Exception {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.jsonValue("{\"raw\":true}");
    writer.endArray();
    writer.close();
    assertEquals("[{\"raw\":true}]", stringWriter.toString());
  }

  public void testJsonValueNullDelegatesToNullValue() throws Exception {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.jsonValue(null);
    writer.endArray();
    writer.close();
    assertEquals("[null]", stringWriter.toString());
  }

  public void testNameRejectsNull() throws Exception {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginObject();
    try {
      writer.name(null);
      fail();
    } catch (NullPointerException expected) {
      assertEquals("name == null", expected.getMessage());
    }
  }

  public void testNameCalledTwiceInARowThrows() throws Exception {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginObject();
    writer.name("a");
    try {
      writer.name("b");
      fail();
    } catch (IllegalStateException expected) {
      // no message on this particular failure
    }
  }

  public void testNameInsideArrayThrowsWhenValueIsWritten() throws Exception {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginArray();
    writer.name("a");
    try {
      writer.value(1L);
      fail();
    } catch (IllegalStateException expected) {
      assertEquals("Nesting problem.", expected.getMessage());
    }
  }

  public void testDanglingNameBeforeEndObjectThrows() throws Exception {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginObject();
    writer.name("a");
    try {
      writer.endObject();
      fail();
    } catch (IllegalStateException expected) {
      assertEquals("Dangling name: a", expected.getMessage());
    }
  }

  public void testEndArrayWithoutMatchingBeginThrows() throws Exception {
    JsonWriter writer = new JsonWriter(new StringWriter());
    try {
      writer.endArray();
      fail();
    } catch (IllegalStateException expected) {
      assertEquals("Nesting problem.", expected.getMessage());
    }
  }

  public void testEndObjectWithoutMatchingBeginThrows() throws Exception {
    JsonWriter writer = new JsonWriter(new StringWriter());
    try {
      writer.endObject();
      fail();
    } catch (IllegalStateException expected) {
      assertEquals("Nesting problem.", expected.getMessage());
    }
  }

  public void testMismatchedEndArrayThrows() throws Exception {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginObject();
    try {
      writer.endArray();
      fail();
    } catch (IllegalStateException expected) {
      assertEquals("Nesting problem.", expected.getMessage());
    }
  }

  public void testArrayInsideObjectWithoutNameThrows() throws Exception {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginObject();
    try {
      writer.beginArray();
      fail();
    } catch (IllegalStateException expected) {
      assertEquals("Nesting problem.", expected.getMessage());
    }
  }

  public void testCloseWithIncompleteDocumentThrows() throws Exception {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginObject();
    writer.name("a");
    writer.value(1L);
    try {
      writer.close();
      fail();
    } catch (IOException expected) {
      assertEquals("Incomplete document", expected.getMessage());
    }
  }

  public void testCloseWithEmptyDocumentThrows() throws Exception {
    JsonWriter writer = new JsonWriter(new StringWriter());
    try {
      writer.close();
      fail();
    } catch (IOException expected) {
      assertEquals("Incomplete document", expected.getMessage());
    }
  }

  public void testOperationsAfterCloseThrow() throws Exception {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginObject();
    writer.endObject();
    writer.close();

    try {
      writer.flush();
      fail();
    } catch (IllegalStateException expected) {
      assertEquals("JsonWriter is closed.", expected.getMessage());
    }

    try {
      writer.name("a");
      fail();
    } catch (IllegalStateException expected) {
      assertEquals("JsonWriter is closed.", expected.getMessage());
    }

    try {
      writer.beginArray();
      fail();
    } catch (IllegalStateException expected) {
      assertEquals("JsonWriter is closed.", expected.getMessage());
    }
  }

  public void testStrictModeRejectsMultipleTopLevelValues() throws Exception {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.value(1L);
    try {
      writer.value(2L);
      fail();
    } catch (IllegalStateException expected) {
      assertEquals("JSON must have only one top-level value.", expected.getMessage());
    }
  }

  public void testLenientModeAllowsMultipleTopLevelValues() throws Exception {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setLenient(true);
    writer.value(1L);
    writer.value(2L);
    writer.close();
    assertEquals("12", stringWriter.toString());
  }

  public void testStrictModeRejectsNanDouble() throws Exception {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginArray();
    try {
      writer.value(Double.NaN);
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  public void testStrictModeRejectsInfiniteDouble() throws Exception {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginArray();
    try {
      writer.value(Double.POSITIVE_INFINITY);
      fail();
    } catch (IllegalArgumentException expected) {
    }
    try {
      writer.value(Double.NEGATIVE_INFINITY);
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  public void testLenientModeAllowsNanAndInfiniteDoubles() throws Exception {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setLenient(true);
    writer.beginArray();
    writer.value(Double.NaN);
    writer.value(Double.POSITIVE_INFINITY);
    writer.value(Double.NEGATIVE_INFINITY);
    writer.endArray();
    writer.close();
    assertEquals("[NaN,Infinity,-Infinity]", stringWriter.toString());
  }

  public void testStrictModeRejectsNanNumber() throws Exception {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginArray();
    try {
      writer.value((Number) Double.valueOf(Double.NaN));
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  public void testValueNumberAcceptsFiniteValues() throws Exception {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.value(Integer.valueOf(42));
    writer.value(new java.math.BigDecimal("3.14"));
    writer.endArray();
    writer.close();
    assertEquals("[42,3.14]", stringWriter.toString());
  }

  public void testSetLenientReflectedByIsLenient() throws Exception {
    JsonWriter writer = new JsonWriter(new StringWriter());
    assertFalse(writer.isLenient());
    writer.setLenient(true);
    assertTrue(writer.isLenient());
  }

  public void testWriterReturnedForChaining() throws Exception {
    JsonWriter writer = new JsonWriter(new StringWriter());
    assertSame(writer, writer.beginObject());
    assertSame(writer, writer.name("a"));
    assertSame(writer, writer.value(1L));
    assertSame(writer, writer.endObject());
  }

  public void testFlushDoesNotCloseUnderlyingWriter() throws Exception {
    final boolean[] closed = { false };
    Writer delegate = new Writer() {
      private final StringWriter target = new StringWriter();

      public void write(char[] buf, int off, int len) throws IOException {
        target.write(buf, off, len);
      }

      public void flush() throws IOException {
        target.flush();
      }

      public void close() throws IOException {
        closed[0] = true;
      }
    };
    JsonWriter writer = new JsonWriter(delegate);
    writer.beginObject();
    writer.endObject();
    writer.flush();
    assertFalse(closed[0]);
    writer.close();
    assertTrue(closed[0]);
  }
}
