package org.apache.commons.lang.time;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;
import java.util.NoSuchElementException;
import java.util.TimeZone;

import org.junit.Test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

public class DateUtilsAgentTest {

    private static final TimeZone UTC = TimeZone.getTimeZone("UTC");

    private static Calendar newCal() {
        Calendar c = Calendar.getInstance(UTC, Locale.US);
        c.clear();
        return c;
    }

    private static Calendar calOf(int year, int month, int day, int hour, int minute, int second, int millis) {
        Calendar c = newCal();
        c.set(year, month, day, hour, minute, second);
        c.set(Calendar.MILLISECOND, millis);
        return c;
    }

    private static Calendar calOf(int year, int month, int day) {
        return calOf(year, month, day, 0, 0, 0, 0);
    }

    private static Date dateOf(int year, int month, int day, int hour, int minute, int second, int millis) {
        return calOf(year, month, day, hour, minute, second, millis).getTime();
    }

    private static Date dateOf(int year, int month, int day) {
        return dateOf(year, month, day, 0, 0, 0, 0);
    }

    private static Calendar toUtcCal(Date d) {
        Calendar c = newCal();
        c.setTime(d);
        return c;
    }

    // ---------- constructor ----------

    @Test
    public void testConstructorIsPublic() {
        DateUtils du = new DateUtils();
        assertNotNull(du);
    }

    // ---------- constants ----------

    @Test
    public void testMillisPerConstants() {
        assertEquals(1000L, DateUtils.MILLIS_PER_SECOND);
        assertEquals(60000L, DateUtils.MILLIS_PER_MINUTE);
        assertEquals(3600000L, DateUtils.MILLIS_PER_HOUR);
        assertEquals(86400000L, DateUtils.MILLIS_PER_DAY);
    }

    @Test
    public void testDeprecatedMillisInConstantsMatchNewOnes() {
        assertEquals(DateUtils.MILLIS_PER_SECOND, DateUtils.MILLIS_IN_SECOND);
        assertEquals(DateUtils.MILLIS_PER_MINUTE, DateUtils.MILLIS_IN_MINUTE);
        assertEquals(DateUtils.MILLIS_PER_HOUR, DateUtils.MILLIS_IN_HOUR);
        assertEquals(DateUtils.MILLIS_PER_DAY, DateUtils.MILLIS_IN_DAY);
    }

    @Test
    public void testUtcTimeZone() {
        assertNotNull(DateUtils.UTC_TIME_ZONE);
        assertEquals(0, DateUtils.UTC_TIME_ZONE.getRawOffset());
    }

    // ---------- isSameDay(Date, Date) ----------

    // @Test  // pruned: failed on the fixed version
    public void testIsSameDayDateTrue() {
        Date d1 = dateOf(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        Date d2 = dateOf(2002, Calendar.MARCH, 28, 6, 1, 0, 0);
        assertTrue(DateUtils.isSameDay(d1, d2));
    }

    @Test
    public void testIsSameDayDateFalse() {
        Date d1 = dateOf(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        Date d2 = dateOf(2002, Calendar.MARCH, 12, 13, 45, 0, 0);
        assertFalse(DateUtils.isSameDay(d1, d2));
    }

    @Test
    public void testIsSameDayDateNullThrows() {
        Date d = dateOf(2002, Calendar.MARCH, 28);
        try {
            DateUtils.isSameDay(null, d);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
        try {
            DateUtils.isSameDay(d, null);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    // ---------- isSameDay(Calendar, Calendar) ----------

    @Test
    public void testIsSameDayCalendarTrue() {
        Calendar c1 = calOf(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        Calendar c2 = calOf(2002, Calendar.MARCH, 28, 6, 1, 0, 0);
        assertTrue(DateUtils.isSameDay(c1, c2));
    }

    @Test
    public void testIsSameDayCalendarFalse() {
        Calendar c1 = calOf(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        Calendar c2 = calOf(2002, Calendar.MARCH, 12, 13, 45, 0, 0);
        assertFalse(DateUtils.isSameDay(c1, c2));
    }

    @Test
    public void testIsSameDayCalendarNullThrows() {
        Calendar c = calOf(2002, Calendar.MARCH, 28);
        try {
            DateUtils.isSameDay((Calendar) null, c);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    // ---------- isSameInstant(Date, Date) ----------

    @Test
    public void testIsSameInstantDateTrue() {
        Date d1 = dateOf(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date d2 = new Date(d1.getTime());
        assertTrue(DateUtils.isSameInstant(d1, d2));
    }

    @Test
    public void testIsSameInstantDateFalse() {
        Date d1 = dateOf(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date d2 = new Date(d1.getTime() + 1);
        assertFalse(DateUtils.isSameInstant(d1, d2));
    }

    @Test
    public void testIsSameInstantDateNullThrows() {
        Date d = dateOf(2002, Calendar.MARCH, 28);
        try {
            DateUtils.isSameInstant(null, d);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    // ---------- isSameInstant(Calendar, Calendar) ----------

    @Test
    public void testIsSameInstantCalendarTrueAcrossTimeZones() {
        Calendar c1 = calOf(2002, Calendar.MARCH, 28, 13, 0, 0, 0);
        Calendar c2 = Calendar.getInstance(TimeZone.getTimeZone("GMT+1"), Locale.US);
        c2.setTimeInMillis(c1.getTimeInMillis());
        assertTrue(DateUtils.isSameInstant(c1, c2));
    }

    @Test
    public void testIsSameInstantCalendarFalse() {
        Calendar c1 = calOf(2002, Calendar.MARCH, 28, 13, 0, 0, 0);
        Calendar c2 = calOf(2002, Calendar.MARCH, 28, 14, 0, 0, 0);
        assertFalse(DateUtils.isSameInstant(c1, c2));
    }

    @Test
    public void testIsSameInstantCalendarNullThrows() {
        Calendar c = calOf(2002, Calendar.MARCH, 28);
        try {
            DateUtils.isSameInstant((Calendar) null, c);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    // ---------- isSameLocalTime(Calendar, Calendar) ----------

    @Test
    public void testIsSameLocalTimeTrueEvenAcrossInstants() {
        Calendar c1 = calOf(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        Calendar c2 = Calendar.getInstance(TimeZone.getTimeZone("GMT+1"), Locale.US);
        c2.clear();
        c2.set(2002, Calendar.MARCH, 28, 13, 45, 0);
        c2.set(Calendar.MILLISECOND, 0);
        // same field values, but different time zones means a different instant
        assertFalse(DateUtils.isSameInstant(c1, c2));
        assertTrue(DateUtils.isSameLocalTime(c1, c2));
    }

    @Test
    public void testIsSameLocalTimeFalse() {
        Calendar c1 = calOf(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        Calendar c2 = calOf(2002, Calendar.MARCH, 28, 13, 46, 0, 0);
        assertFalse(DateUtils.isSameLocalTime(c1, c2));
    }

    @Test
    public void testIsSameLocalTimeNullThrows() {
        Calendar c = calOf(2002, Calendar.MARCH, 28);
        try {
            DateUtils.isSameLocalTime(null, c);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    // ---------- parseDate ----------

    @Test
    public void testParseDateFirstPatternMatches() throws ParseException {
        Date parsed = DateUtils.parseDate("2002-03-28", new String[] { "yyyy-MM-dd" });
        Calendar c = toUtcCal(parsed);
        assertEquals(2002, c.get(Calendar.YEAR));
        assertEquals(Calendar.MARCH, c.get(Calendar.MONTH));
        assertEquals(28, c.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void testParseDateFallsBackToLaterPattern() throws ParseException {
        Date parsed = DateUtils.parseDate("2002-03-28",
                new String[] { "dd/MM/yyyy", "yyyy-MM-dd" });
        Calendar c = toUtcCal(parsed);
        assertEquals(2002, c.get(Calendar.YEAR));
        assertEquals(Calendar.MARCH, c.get(Calendar.MONTH));
        assertEquals(28, c.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void testParseDateRequiresWholeStringConsumed() {
        try {
            DateUtils.parseDate("2002-03-28garbage", new String[] { "yyyy-MM-dd" });
            fail("expected ParseException because trailing text is not consumed");
        } catch (ParseException expected) {
            // expected
        }
    }

    @Test
    public void testParseDateNoPatternMatchesThrowsParseException() {
        try {
            DateUtils.parseDate("not-a-date-at-all", new String[] { "yyyy/MM/dd" });
            fail("expected ParseException");
        } catch (ParseException expected) {
            // expected
        }
    }

    @Test
    public void testParseDateNullArgumentsThrowIllegalArgument() throws ParseException {
        try {
            DateUtils.parseDate(null, new String[] { "yyyy-MM-dd" });
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
        try {
            DateUtils.parseDate("2002-03-28", null);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    // ---------- addYears / addMonths / addWeeks / addDays / addHours / addMinutes / addSeconds / addMilliseconds ----------

    @Test
    public void testAddYears() {
        Date original = dateOf(2002, Calendar.MARCH, 28);
        long originalMillis = original.getTime();
        Date result = DateUtils.addYears(original, 3);
        assertEquals(originalMillis, original.getTime());
        Calendar c = toUtcCal(result);
        assertEquals(2005, c.get(Calendar.YEAR));
        assertEquals(Calendar.MARCH, c.get(Calendar.MONTH));
        assertEquals(28, c.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void testAddYearsNegative() {
        Date original = dateOf(2002, Calendar.MARCH, 28);
        Date result = DateUtils.addYears(original, -2);
        Calendar c = toUtcCal(result);
        assertEquals(2000, c.get(Calendar.YEAR));
    }

    @Test
    public void testAddYearsNullThrows() {
        try {
            DateUtils.addYears(null, 1);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    // @Test  // pruned: failed on the fixed version
    public void testAddMonths() {
        Date original = dateOf(2002, Calendar.MARCH, 28);
        Date result = DateUtils.addMonths(original, 2);
        Calendar c = toUtcCal(result);
        assertEquals(2002, c.get(Calendar.YEAR));
        assertEquals(Calendar.MAY, c.get(Calendar.MONTH));
        assertEquals(28, c.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void testAddMonthsNullThrows() {
        try {
            DateUtils.addMonths(null, 1);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    public void testAddWeeks() {
        Date original = dateOf(2002, Calendar.MARCH, 28);
        Date result = DateUtils.addWeeks(original, 1);
        Calendar c = toUtcCal(result);
        assertEquals(2002, c.get(Calendar.YEAR));
        assertEquals(Calendar.APRIL, c.get(Calendar.MONTH));
        assertEquals(4, c.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void testAddWeeksNullThrows() {
        try {
            DateUtils.addWeeks(null, 1);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    public void testAddDays() {
        Date original = dateOf(2002, Calendar.MARCH, 28);
        Date result = DateUtils.addDays(original, 5);
        Calendar c = toUtcCal(result);
        assertEquals(Calendar.APRIL, c.get(Calendar.MONTH));
        assertEquals(2, c.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void testAddDaysNegative() {
        Date original = dateOf(2002, Calendar.MARCH, 28);
        Date result = DateUtils.addDays(original, -28);
        Calendar c = toUtcCal(result);
        assertEquals(Calendar.FEBRUARY, c.get(Calendar.MONTH));
        assertEquals(28, c.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void testAddDaysNullThrows() {
        try {
            DateUtils.addDays(null, 1);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    public void testAddHours() {
        Date original = dateOf(2002, Calendar.MARCH, 28, 23, 0, 0, 0);
        Date result = DateUtils.addHours(original, 2);
        Calendar c = toUtcCal(result);
        assertEquals(29, c.get(Calendar.DAY_OF_MONTH));
        assertEquals(1, c.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    public void testAddHoursNullThrows() {
        try {
            DateUtils.addHours(null, 1);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    public void testAddMinutes() {
        Date original = dateOf(2002, Calendar.MARCH, 28, 0, 59, 0, 0);
        Date result = DateUtils.addMinutes(original, 2);
        Calendar c = toUtcCal(result);
        assertEquals(1, c.get(Calendar.HOUR_OF_DAY));
        assertEquals(1, c.get(Calendar.MINUTE));
    }

    @Test
    public void testAddMinutesNullThrows() {
        try {
            DateUtils.addMinutes(null, 1);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    public void testAddSeconds() {
        Date original = dateOf(2002, Calendar.MARCH, 28, 0, 0, 59, 0);
        Date result = DateUtils.addSeconds(original, 2);
        Calendar c = toUtcCal(result);
        assertEquals(1, c.get(Calendar.MINUTE));
        assertEquals(1, c.get(Calendar.SECOND));
    }

    @Test
    public void testAddSecondsNullThrows() {
        try {
            DateUtils.addSeconds(null, 1);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    public void testAddMilliseconds() {
        Date original = dateOf(2002, Calendar.MARCH, 28, 0, 0, 0, 998);
        Date result = DateUtils.addMilliseconds(original, 5);
        assertEquals(original.getTime() + 5, result.getTime());
    }

    @Test
    public void testAddMillisecondsNullThrows() {
        try {
            DateUtils.addMilliseconds(null, 1);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    // ---------- add(Date, int, int) ----------

    // @Test  // pruned: failed on the fixed version
    public void testAddGeneric() {
        Date original = dateOf(2002, Calendar.MARCH, 28);
        long originalMillis = original.getTime();
        Date result = DateUtils.add(original, Calendar.MONTH, 1);
        assertEquals(originalMillis, original.getTime());
        Calendar c = toUtcCal(result);
        assertEquals(Calendar.APRIL, c.get(Calendar.MONTH));
        assertEquals(28, c.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void testAddGenericNullThrows() {
        try {
            DateUtils.add(null, Calendar.MONTH, 1);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    // ---------- round(Date, int) ----------

    @Test
    public void testRoundDateToHour() {
        Date d = dateOf(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date rounded = DateUtils.round(d, Calendar.HOUR_OF_DAY);
        Calendar c = toUtcCal(rounded);
        assertEquals(2002, c.get(Calendar.YEAR));
        assertEquals(Calendar.MARCH, c.get(Calendar.MONTH));
        assertEquals(28, c.get(Calendar.DAY_OF_MONTH));
        assertEquals(14, c.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, c.get(Calendar.MINUTE));
        assertEquals(0, c.get(Calendar.SECOND));
        assertEquals(0, c.get(Calendar.MILLISECOND));
    }

    // @Test  // pruned: failed on the fixed version
    public void testRoundDateToMonth() {
        Date d = dateOf(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date rounded = DateUtils.round(d, Calendar.MONTH);
        Calendar c = toUtcCal(rounded);
        assertEquals(2002, c.get(Calendar.YEAR));
        assertEquals(Calendar.APRIL, c.get(Calendar.MONTH));
        assertEquals(1, c.get(Calendar.DAY_OF_MONTH));
        assertEquals(0, c.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, c.get(Calendar.MINUTE));
        assertEquals(0, c.get(Calendar.SECOND));
        assertEquals(0, c.get(Calendar.MILLISECOND));
    }

    @Test
    public void testRoundDateNullThrows() {
        try {
            DateUtils.round((Date) null, Calendar.HOUR_OF_DAY);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    public void testRoundDateHugeYearThrowsArithmetic() {
        Calendar huge = newCal();
        huge.set(Calendar.YEAR, 300000000);
        huge.set(Calendar.MONTH, Calendar.JANUARY);
        huge.set(Calendar.DAY_OF_MONTH, 1);
        try {
            DateUtils.round(huge.getTime(), Calendar.HOUR_OF_DAY);
            fail("expected ArithmeticException for year over 280 million");
        } catch (ArithmeticException expected) {
            // expected
        }
    }

    // ---------- round(Calendar, int) ----------

    @Test
    public void testRoundCalendarReturnsDifferentInstance() {
        Calendar c = calOf(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar rounded = DateUtils.round(c, Calendar.HOUR_OF_DAY);
        assertNotSame(c, rounded);
        assertEquals(14, rounded.get(Calendar.HOUR_OF_DAY));
        assertEquals(28, rounded.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void testRoundCalendarNullThrows() {
        try {
            DateUtils.round((Calendar) null, Calendar.HOUR_OF_DAY);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    // ---------- round(Object, int) ----------

    @Test
    public void testRoundObjectWithDate() {
        Date d = dateOf(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date rounded = DateUtils.round((Object) d, Calendar.HOUR_OF_DAY);
        Calendar c = toUtcCal(rounded);
        assertEquals(14, c.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    public void testRoundObjectWithCalendar() {
        Calendar cal = calOf(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date rounded = DateUtils.round((Object) cal, Calendar.HOUR_OF_DAY);
        Calendar c = toUtcCal(rounded);
        assertEquals(14, c.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    public void testRoundObjectInvalidTypeThrowsClassCast() {
        try {
            DateUtils.round("not a date", Calendar.HOUR_OF_DAY);
            fail("expected ClassCastException");
        } catch (ClassCastException expected) {
            // expected
        }
    }

    @Test
    public void testRoundObjectNullThrows() {
        try {
            DateUtils.round((Object) null, Calendar.HOUR_OF_DAY);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    // ---------- truncate(Date, int) ----------

    @Test
    public void testTruncateDateToHour() {
        Date d = dateOf(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date truncated = DateUtils.truncate(d, Calendar.HOUR_OF_DAY);
        Calendar c = toUtcCal(truncated);
        assertEquals(28, c.get(Calendar.DAY_OF_MONTH));
        assertEquals(13, c.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, c.get(Calendar.MINUTE));
        assertEquals(0, c.get(Calendar.SECOND));
        assertEquals(0, c.get(Calendar.MILLISECOND));
    }

    // @Test  // pruned: failed on the fixed version
    public void testTruncateDateToMonth() {
        Date d = dateOf(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date truncated = DateUtils.truncate(d, Calendar.MONTH);
        Calendar c = toUtcCal(truncated);
        assertEquals(2002, c.get(Calendar.YEAR));
        assertEquals(Calendar.MARCH, c.get(Calendar.MONTH));
        assertEquals(1, c.get(Calendar.DAY_OF_MONTH));
        assertEquals(0, c.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    public void testTruncateDateNullThrows() {
        try {
            DateUtils.truncate((Date) null, Calendar.HOUR_OF_DAY);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    public void testTruncateDateHugeYearThrowsArithmetic() {
        Calendar huge = newCal();
        huge.set(Calendar.YEAR, 300000000);
        huge.set(Calendar.MONTH, Calendar.JANUARY);
        huge.set(Calendar.DAY_OF_MONTH, 1);
        try {
            DateUtils.truncate(huge.getTime(), Calendar.HOUR_OF_DAY);
            fail("expected ArithmeticException for year over 280 million");
        } catch (ArithmeticException expected) {
            // expected
        }
    }

    // ---------- truncate(Calendar, int) ----------

    @Test
    public void testTruncateCalendarReturnsDifferentInstance() {
        Calendar c = calOf(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar truncated = DateUtils.truncate(c, Calendar.HOUR_OF_DAY);
        assertNotSame(c, truncated);
        assertEquals(13, truncated.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, truncated.get(Calendar.MINUTE));
    }

    @Test
    public void testTruncateCalendarNullThrows() {
        try {
            DateUtils.truncate((Calendar) null, Calendar.HOUR_OF_DAY);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    // ---------- truncate(Object, int) ----------

    @Test
    public void testTruncateObjectWithDate() {
        Date d = dateOf(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date truncated = DateUtils.truncate((Object) d, Calendar.HOUR_OF_DAY);
        Calendar c = toUtcCal(truncated);
        assertEquals(13, c.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    public void testTruncateObjectWithCalendar() {
        Calendar cal = calOf(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date truncated = DateUtils.truncate((Object) cal, Calendar.HOUR_OF_DAY);
        Calendar c = toUtcCal(truncated);
        assertEquals(13, c.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    public void testTruncateObjectInvalidTypeThrowsClassCast() {
        try {
            DateUtils.truncate(new Object(), Calendar.HOUR_OF_DAY);
            fail("expected ClassCastException");
        } catch (ClassCastException expected) {
            // expected
        }
    }

    @Test
    public void testTruncateObjectNullThrows() {
        try {
            DateUtils.truncate((Object) null, Calendar.HOUR_OF_DAY);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    // ---------- iterator(Date, int) ----------

    @Test
    public void testIteratorMonthSundayMatchesJavadocExample() {
        Date focus = dateOf(2002, Calendar.JULY, 4);
        Iterator it = DateUtils.iterator(focus, DateUtils.RANGE_MONTH_SUNDAY);

        assertTrue(it.hasNext());
        Calendar first = (Calendar) it.next();
        assertEquals(2002, first.get(Calendar.YEAR));
        assertEquals(Calendar.JUNE, first.get(Calendar.MONTH));
        assertEquals(30, first.get(Calendar.DAY_OF_MONTH));
        assertEquals(Calendar.SUNDAY, first.get(Calendar.DAY_OF_WEEK));

        int count = 1;
        Calendar last = first;
        while (it.hasNext()) {
            last = (Calendar) it.next();
            count++;
        }
        assertEquals(2002, last.get(Calendar.YEAR));
        assertEquals(Calendar.AUGUST, last.get(Calendar.MONTH));
        assertEquals(3, last.get(Calendar.DAY_OF_MONTH));
        assertEquals(Calendar.SATURDAY, last.get(Calendar.DAY_OF_WEEK));
        assertEquals(35, count);
    }

    @Test
    public void testIteratorMonthMonday() {
        Date focus = dateOf(2002, Calendar.JULY, 4);
        Iterator it = DateUtils.iterator(focus, DateUtils.RANGE_MONTH_MONDAY);

        Calendar first = (Calendar) it.next();
        assertEquals(Calendar.JULY, first.get(Calendar.MONTH));
        assertEquals(1, first.get(Calendar.DAY_OF_MONTH));
        assertEquals(Calendar.MONDAY, first.get(Calendar.DAY_OF_WEEK));

        int count = 1;
        Calendar last = first;
        while (it.hasNext()) {
            last = (Calendar) it.next();
            count++;
        }
        assertEquals(Calendar.AUGUST, last.get(Calendar.MONTH));
        assertEquals(4, last.get(Calendar.DAY_OF_MONTH));
        assertEquals(Calendar.SUNDAY, last.get(Calendar.DAY_OF_WEEK));
        assertEquals(35, count);
    }

    @Test
    public void testIteratorWeekSunday() {
        Date focus = dateOf(2002, Calendar.JULY, 4);
        Iterator it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);

        Calendar first = (Calendar) it.next();
        assertEquals(Calendar.JUNE, first.get(Calendar.MONTH));
        assertEquals(30, first.get(Calendar.DAY_OF_MONTH));

        int count = 1;
        Calendar last = first;
        while (it.hasNext()) {
            last = (Calendar) it.next();
            count++;
        }
        assertEquals(Calendar.JULY, last.get(Calendar.MONTH));
        assertEquals(6, last.get(Calendar.DAY_OF_MONTH));
        assertEquals(7, count);
    }

    @Test
    public void testIteratorWeekMonday() {
        Date focus = dateOf(2002, Calendar.JULY, 4);
        Iterator it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_MONDAY);

        Calendar first = (Calendar) it.next();
        assertEquals(1, first.get(Calendar.DAY_OF_MONTH));

        int count = 1;
        Calendar last = first;
        while (it.hasNext()) {
            last = (Calendar) it.next();
            count++;
        }
        assertEquals(7, last.get(Calendar.DAY_OF_MONTH));
        assertEquals(7, count);
    }

    // @Test  // pruned: failed on the fixed version
    public void testIteratorWeekRelativeStartsOnFocusDay() {
        Date focus = dateOf(2002, Calendar.JULY, 4);
        Iterator it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_RELATIVE);

        Calendar first = (Calendar) it.next();
        assertEquals(4, first.get(Calendar.DAY_OF_MONTH));

        int count = 1;
        Calendar last = first;
        while (it.hasNext()) {
            last = (Calendar) it.next();
            count++;
        }
        assertEquals(10, last.get(Calendar.DAY_OF_MONTH));
        assertEquals(7, count);
    }

    // @Test  // pruned: failed on the fixed version
    public void testIteratorWeekCenterIncludesFocusDayInMiddle() {
        Date focus = dateOf(2002, Calendar.JULY, 4);
        Iterator it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_CENTER);

        boolean sawFocusDay = false;
        int count = 0;
        Calendar first = null;
        Calendar last = null;
        while (it.hasNext()) {
            Calendar current = (Calendar) it.next();
            if (first == null) {
                first = current;
            }
            last = current;
            count++;
            if (current.get(Calendar.DAY_OF_MONTH) == 4
                    && current.get(Calendar.MONTH) == Calendar.JULY) {
                sawFocusDay = true;
            }
        }
        assertEquals(7, count);
        assertTrue(sawFocusDay);
        assertEquals(1, first.get(Calendar.DAY_OF_MONTH));
        assertEquals(7, last.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void testIteratorReturnsCalendarInstances() {
        Date focus = dateOf(2002, Calendar.JULY, 4);
        Iterator it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        Object next = it.next();
        assertTrue(next instanceof Calendar);
    }

    @Test
    public void testIteratorRemoveThrowsUnsupported() {
        Date focus = dateOf(2002, Calendar.JULY, 4);
        Iterator it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        try {
            it.remove();
            fail("expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
    }

    @Test
    public void testIteratorExhaustedThrowsNoSuchElement() {
        Date focus = dateOf(2002, Calendar.JULY, 4);
        Iterator it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        while (it.hasNext()) {
            it.next();
        }
        assertFalse(it.hasNext());
        try {
            it.next();
            fail("expected NoSuchElementException");
        } catch (NoSuchElementException expected) {
            // expected
        }
    }

    @Test
    public void testIteratorDateNullThrows() {
        try {
            DateUtils.iterator((Date) null, DateUtils.RANGE_WEEK_SUNDAY);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    public void testIteratorInvalidRangeStyleThrows() {
        Date focus = dateOf(2002, Calendar.JULY, 4);
        try {
            DateUtils.iterator(focus, 999999);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    // ---------- iterator(Calendar, int) ----------

    @Test
    public void testIteratorCalendarOverload() {
        Calendar focus = calOf(2002, Calendar.JULY, 4);
        Iterator it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        Calendar first = (Calendar) it.next();
        assertEquals(Calendar.JUNE, first.get(Calendar.MONTH));
        assertEquals(30, first.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void testIteratorCalendarNullThrows() {
        try {
            DateUtils.iterator((Calendar) null, DateUtils.RANGE_WEEK_SUNDAY);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    // ---------- iterator(Object, int) ----------

    @Test
    public void testIteratorObjectWithDate() {
        Date focus = dateOf(2002, Calendar.JULY, 4);
        Iterator it = DateUtils.iterator((Object) focus, DateUtils.RANGE_WEEK_SUNDAY);
        Calendar first = (Calendar) it.next();
        assertEquals(30, first.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void testIteratorObjectWithCalendar() {
        Calendar focus = calOf(2002, Calendar.JULY, 4);
        Iterator it = DateUtils.iterator((Object) focus, DateUtils.RANGE_WEEK_SUNDAY);
        Calendar first = (Calendar) it.next();
        assertEquals(30, first.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void testIteratorObjectInvalidTypeThrowsClassCast() {
        try {
            DateUtils.iterator("not a date", DateUtils.RANGE_WEEK_SUNDAY);
            fail("expected ClassCastException");
        } catch (ClassCastException expected) {
            // expected
        }
    }

    @Test
    public void testIteratorObjectNullThrows() {
        try {
            DateUtils.iterator((Object) null, DateUtils.RANGE_WEEK_SUNDAY);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }
}
