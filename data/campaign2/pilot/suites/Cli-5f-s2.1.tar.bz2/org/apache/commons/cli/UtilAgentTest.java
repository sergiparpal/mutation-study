package org.apache.commons.cli;

import junit.framework.TestCase;

/**
 * Tests for the package-private {@link Util} helper class, based on the
 * documented contract in the generated javadoc:
 * <ul>
 * <li>{@code stripLeadingHyphens(String)} removes the hyphens from the
 * beginning of the given string and returns the new String.</li>
 * <li>{@code stripLeadingAndTrailingQuotes(String)} removes the leading and
 * trailing quotes from the given string, e.g. {@code "\"one two\""} becomes
 * {@code "one two"}.</li>
 * </ul>
 */
public class UtilAgentTest extends TestCase
{
    // --- Util() constructor -------------------------------------------

    public void testConstructorIsAccessibleWithinPackage()
    {
        // The package-private no-arg constructor must be usable from
        // within the org.apache.commons.cli package.
        Util util = new Util();
        assertNotNull(util);
    }

    // --- stripLeadingHyphens(String) -----------------------------------

    public void testStripLeadingHyphensDoubleHyphen()
    {
        assertEquals("foo", Util.stripLeadingHyphens("--foo"));
    }

    public void testStripLeadingHyphensSingleHyphen()
    {
        assertEquals("foo", Util.stripLeadingHyphens("-foo"));
    }

    public void testStripLeadingHyphensNoHyphens()
    {
        assertEquals("foo", Util.stripLeadingHyphens("foo"));
    }

    public void testStripLeadingHyphensEmptyString()
    {
        assertEquals("", Util.stripLeadingHyphens(""));
    }

    public void testStripLeadingHyphensSingleHyphenOnly()
    {
        assertEquals("", Util.stripLeadingHyphens("-"));
    }

    public void testStripLeadingHyphensDoubleHyphenOnly()
    {
        assertEquals("", Util.stripLeadingHyphens("--"));
    }

    public void testStripLeadingHyphensNonLeadingHyphenIsKept()
    {
        // The hyphen is not at the beginning of the string, so it must
        // not be removed.
        assertEquals("foo-bar", Util.stripLeadingHyphens("foo-bar"));
    }

    public void testStripLeadingHyphensOnlyTwoLeadingHyphensAreStripped()
    {
        // Only the leading "--" marker is stripped; any further hyphen
        // immediately following is not itself a leading hyphen.
        assertEquals("-foo", Util.stripLeadingHyphens("---foo"));
    }

    public void testStripLeadingHyphensNull()
    {
        assertNull(Util.stripLeadingHyphens(null));
    }

    // --- stripLeadingAndTrailingQuotes(String) --------------------------

    public void testStripLeadingAndTrailingQuotesBothPresent()
    {
        assertEquals("one two", Util.stripLeadingAndTrailingQuotes("\"one two\""));
    }

    public void testStripLeadingAndTrailingQuotesNoQuotes()
    {
        assertEquals("one two", Util.stripLeadingAndTrailingQuotes("one two"));
    }

    public void pruned_testStripLeadingAndTrailingQuotesOnlyLeadingQuote()
    {
        // No trailing quote present, so the string must be left unchanged.
        assertEquals("\"one two", Util.stripLeadingAndTrailingQuotes("\"one two"));
    }

    public void pruned_testStripLeadingAndTrailingQuotesOnlyTrailingQuote()
    {
        // No leading quote present, so the string must be left unchanged.
        assertEquals("one two\"", Util.stripLeadingAndTrailingQuotes("one two\""));
    }

    public void testStripLeadingAndTrailingQuotesEmptyString()
    {
        assertEquals("", Util.stripLeadingAndTrailingQuotes(""));
    }

    public void pruned_testStripLeadingAndTrailingQuotesSingleQuoteCharacter()
    {
        // A single quote character cannot simultaneously be both a
        // distinct leading and a distinct trailing quote, so it must be
        // left untouched.
        assertEquals("\"", Util.stripLeadingAndTrailingQuotes("\""));
    }

    public void testStripLeadingAndTrailingQuotesTwoQuoteCharactersOnly()
    {
        // The leading quote (position 0) and trailing quote (position 1)
        // are distinct characters; removing both leaves the empty string.
        assertEquals("", Util.stripLeadingAndTrailingQuotes("\"\""));
    }

    public void testStripLeadingAndTrailingQuotesNull()
    {
        try
        {
            Util.stripLeadingAndTrailingQuotes(null);
            fail("Expected a NullPointerException for a null argument");
        }
        catch (NullPointerException expected)
        {
            // documented behaviour is silent on null handling; since the
            // method must inspect the characters of str, a null argument
            // cannot be processed and a NullPointerException is expected
        }
    }
}
