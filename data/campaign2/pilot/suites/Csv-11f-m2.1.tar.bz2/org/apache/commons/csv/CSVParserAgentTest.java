/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.csv;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.junit.Test;

public class CSVParserAgentTest {

    private File writeTempFile(final String content) throws IOException {
        final File file = File.createTempFile("CSVParserAgentTest", ".csv");
        file.deleteOnExit();
        final Writer writer = new OutputStreamWriter(new FileOutputStream(file), "UTF-8");
        try {
            writer.write(content);
        } finally {
            writer.close();
        }
        return file;
    }

    @Test
    public void testParseStringBasic() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b,c\n1,2,3\n", CSVFormat.DEFAULT);
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        assertEquals("a", records.get(0).get(0));
        assertEquals("3", records.get(1).get(2));
        parser.close();
    }

    @Test
    public void testParseEmptyString() throws IOException {
        final CSVParser parser = CSVParser.parse("", CSVFormat.DEFAULT);
        final List<CSVRecord> records = parser.getRecords();
        assertTrue(records.isEmpty());
        parser.close();
    }

    @Test
    public void testParseStringNullStringThrows() throws IOException {
        try {
            CSVParser.parse((String) null, CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testParseStringNullFormatThrows() throws IOException {
        try {
            CSVParser.parse("a,b", null);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testParseFileNullFileThrows() throws IOException {
        try {
            CSVParser.parse((File) null, Charset.forName("UTF-8"), CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testParseFileNullFormatThrows() throws IOException {
        final File file = writeTempFile("a,b\n1,2\n");
        try {
            CSVParser.parse(file, Charset.forName("UTF-8"), null);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testParseFileBasic() throws IOException {
        final File file = writeTempFile("x,y\n9,8\n");
        final CSVParser parser = CSVParser.parse(file, Charset.forName("UTF-8"), CSVFormat.DEFAULT);
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        assertEquals("9", records.get(1).get(0));
        parser.close();
    }

    @Test
    public void testParseUrlNullUrlThrows() throws IOException {
        try {
            CSVParser.parse((URL) null, Charset.forName("UTF-8"), CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testParseUrlNullCharsetThrows() throws IOException {
        final File file = writeTempFile("a,b\n");
        try {
            CSVParser.parse(file.toURI().toURL(), null, CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testParseUrlNullFormatThrows() throws IOException {
        final File file = writeTempFile("a,b\n");
        try {
            CSVParser.parse(file.toURI().toURL(), Charset.forName("UTF-8"), null);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testParseUrlBasic() throws IOException {
        final File file = writeTempFile("p,q\n5,6\n");
        final CSVParser parser = CSVParser.parse(file.toURI().toURL(), Charset.forName("UTF-8"), CSVFormat.DEFAULT);
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        assertEquals("6", records.get(1).get(1));
        parser.close();
    }

    @Test
    public void testConstructorNullReaderThrows() throws IOException {
        try {
            new CSVParser(null, CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testConstructorNullFormatThrows() throws IOException {
        try {
            new CSVParser(new java.io.StringReader("a,b"), null);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testGetHeaderMapWithoutHeaderIsNull() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n1,2\n", CSVFormat.DEFAULT);
        assertNull(parser.getHeaderMap());
        parser.close();
    }

    @Test
    public void testGetHeaderMapReadFromFirstLine() throws IOException {
        final CSVParser parser = CSVParser.parse("name,age\nJohn,20\n", CSVFormat.DEFAULT.withHeader());
        final Map<String, Integer> headerMap = parser.getHeaderMap();
        assertEquals(Integer.valueOf(0), headerMap.get("name"));
        assertEquals(Integer.valueOf(1), headerMap.get("age"));
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(1, records.size());
        assertEquals("John", records.get(0).get("name"));
        parser.close();
    }

    @Test
    public void testGetHeaderMapIsIndependentCopy() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n1,2\n", CSVFormat.DEFAULT.withHeader());
        final Map<String, Integer> first = parser.getHeaderMap();
        first.put("extra", Integer.valueOf(99));
        final Map<String, Integer> second = parser.getHeaderMap();
        assertFalse(second.containsKey("extra"));
        parser.close();
    }

    @Test
    public void testExplicitHeaderWithSkipHeaderRecord() throws IOException {
        final CSVParser parser = CSVParser.parse("A,B\n1,2\n",
                CSVFormat.DEFAULT.withHeader("A", "B").withSkipHeaderRecord(true));
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(1, records.size());
        assertEquals("1", records.get(0).get("A"));
        parser.close();
    }

    @Test
    public void testExplicitHeaderWithoutSkipHeaderRecord() throws IOException {
        final CSVParser parser = CSVParser.parse("A,B\n1,2\n",
                CSVFormat.DEFAULT.withHeader("A", "B").withSkipHeaderRecord(false));
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        assertEquals("A", records.get(0).get("A"));
        parser.close();
    }

    @Test
    public void testDuplicateHeaderNamesThrows() throws IOException {
        try {
            CSVParser.parse("a,a\n1,2\n", CSVFormat.DEFAULT.withHeader());
            fail("Expected IllegalArgumentException for duplicate header");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testIteratorBasicAndExhaustion() throws IOException {
        final CSVParser parser = CSVParser.parse("1,2\n3,4\n", CSVFormat.DEFAULT);
        final Iterator<CSVRecord> iterator = parser.iterator();
        assertTrue(iterator.hasNext());
        final CSVRecord first = iterator.next();
        assertEquals("1", first.get(0));
        assertTrue(iterator.hasNext());
        final CSVRecord second = iterator.next();
        assertEquals("4", second.get(1));
        assertFalse(iterator.hasNext());
        try {
            iterator.next();
            fail("Expected NoSuchElementException");
        } catch (final NoSuchElementException e) {
            // expected
        }
        parser.close();
    }

    @Test
    public void testIteratorNextWithoutHasNext() throws IOException {
        final CSVParser parser = CSVParser.parse("x\ny\n", CSVFormat.DEFAULT);
        final Iterator<CSVRecord> iterator = parser.iterator();
        assertEquals("x", iterator.next().get(0));
        assertEquals("y", iterator.next().get(0));
        parser.close();
    }

    @Test
    public void testIteratorRemoveUnsupported() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n", CSVFormat.DEFAULT);
        final Iterator<CSVRecord> iterator = parser.iterator();
        try {
            iterator.remove();
            fail("Expected UnsupportedOperationException");
        } catch (final UnsupportedOperationException e) {
            // expected
        }
        parser.close();
    }

    @Test
    public void testCloseMakesParserClosedAndIteratorExhausted() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n1,2\n", CSVFormat.DEFAULT);
        assertFalse(parser.isClosed());
        parser.close();
        assertTrue(parser.isClosed());
        final Iterator<CSVRecord> iterator = parser.iterator();
        assertFalse(iterator.hasNext());
        try {
            iterator.next();
            fail("Expected NoSuchElementException after close");
        } catch (final NoSuchElementException e) {
            // expected
        }
    }

    @Test
    public void testRecordNumberIncrementsPerRecord() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n2\n3\n", CSVFormat.DEFAULT);
        assertEquals(0, parser.getRecordNumber());
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(3, records.size());
        assertEquals(1, records.get(0).getRecordNumber());
        assertEquals(3, records.get(2).getRecordNumber());
        assertEquals(3, parser.getRecordNumber());
        parser.close();
    }

    @Test
    public void testGetCurrentLineNumber() throws IOException {
        final CSVParser parser = CSVParser.parse("a\nb\nc\n", CSVFormat.DEFAULT);
        assertEquals(0, parser.getCurrentLineNumber());
        parser.nextRecord();
        assertEquals(1, parser.getCurrentLineNumber());
        parser.nextRecord();
        assertEquals(2, parser.getCurrentLineNumber());
        parser.close();
    }

    @Test
    public void testCommentsAreIgnoredAsRecords() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n# this is a comment\nc,d\n",
                CSVFormat.DEFAULT.withCommentStart('#'));
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        assertEquals("a", records.get(0).get(0));
        assertEquals("c", records.get(1).get(0));
        parser.close();
    }

    @Test
    public void testNullStringMapsFieldToNull() throws IOException {
        final CSVParser parser = CSVParser.parse("a,NULL,c\n", CSVFormat.DEFAULT.withNullString("NULL"));
        final CSVRecord record = parser.iterator().next();
        assertEquals("a", record.get(0));
        assertNull(record.get(1));
        assertEquals("c", record.get(2));
        parser.close();
    }

    @Test
    public void testGetRecordsNoArgReturnsNewArrayList() throws IOException {
        final CSVParser parser = CSVParser.parse("a\nb\n", CSVFormat.DEFAULT);
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        parser.close();
    }

    @Test
    public void testGetRecordsAppendsToSuppliedCollection() throws IOException {
        final CSVParser parser = CSVParser.parse("a\nb\n", CSVFormat.DEFAULT);
        final List<CSVRecord> target = new ArrayList<CSVRecord>();
        target.add(null);
        final List<CSVRecord> result = parser.getRecords(target);
        assertTrue(result == target);
        assertEquals(3, result.size());
        parser.close();
    }

    @Test
    public void testUnterminatedQuoteThrowsIOException() throws IOException {
        final CSVParser parser = CSVParser.parse("\"a,b\n", CSVFormat.DEFAULT);
        try {
            parser.getRecords();
            fail("Expected IOException for unterminated quoted value");
        } catch (final IOException e) {
            assertTrue(e.getMessage().indexOf("EOF reached before encapsulated token finished") >= 0);
        } finally {
            parser.close();
        }
    }

    @Test
    public void testInvalidCharAfterQuoteThrowsIOException() throws IOException {
        final CSVParser parser = CSVParser.parse("\"a\"b,c\n", CSVFormat.DEFAULT);
        try {
            parser.getRecords();
            fail("Expected IOException for invalid char after encapsulated token");
        } catch (final IOException e) {
            assertTrue(e.getMessage().indexOf("invalid char between encapsulated token and delimiter") >= 0);
        } finally {
            parser.close();
        }
    }

    @Test
    public void testTrailingDelimiterProducesEmptyLastField() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b,\n", CSVFormat.DEFAULT);
        final CSVRecord record = parser.iterator().next();
        assertEquals(3, record.size());
        assertEquals("", record.get(2));
        parser.close();
    }

    @Test
    public void testLastRecordWithoutTrailingNewline() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b", CSVFormat.DEFAULT);
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(1, records.size());
        assertEquals("b", records.get(0).get(1));
        parser.close();
    }
}
