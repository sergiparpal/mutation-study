/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang.text;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Unit tests for {@link org.apache.commons.lang.text.StrBuilder}.
 */
public class StrBuilderAgentTest extends TestCase {

    public StrBuilderAgentTest(String name) {
        super(name);
    }

    public static Test suite() {
        return new TestSuite(StrBuilderAgentTest.class);
    }

    //-----------------------------------------------------------------------
    // constructors
    //-----------------------------------------------------------------------

    public void testConstructorDefault() {
        StrBuilder sb = new StrBuilder();
        assertEquals(0, sb.length());
        assertEquals(32, sb.capacity());
        assertEquals("", sb.toString());
    }

    public void testConstructorCapacity() {
        StrBuilder sb = new StrBuilder(10);
        assertEquals(10, sb.capacity());
        assertEquals(0, sb.length());
    }

    public void testConstructorCapacityNonPositive() {
        StrBuilder sb = new StrBuilder(0);
        assertEquals(32, sb.capacity());
        StrBuilder sb2 = new StrBuilder(-5);
        assertEquals(32, sb2.capacity());
    }

    public void testConstructorString() {
        StrBuilder sb = new StrBuilder("hello");
        assertEquals("hello", sb.toString());
        assertEquals(5, sb.length());
    }

    public void testConstructorNullString() {
        StrBuilder sb = new StrBuilder((String) null);
        assertEquals(0, sb.length());
        assertEquals("", sb.toString());
    }

    //-----------------------------------------------------------------------
    // length / setLength
    //-----------------------------------------------------------------------

    public void testSetLengthGrow() {
        StrBuilder sb = new StrBuilder("abc");
        sb.setLength(5);
        assertEquals(5, sb.length());
        assertEquals('\0', sb.charAt(3));
        assertEquals('\0', sb.charAt(4));
    }

    public void testSetLengthShrink() {
        StrBuilder sb = new StrBuilder("abcdef");
        sb.setLength(3);
        assertEquals(3, sb.length());
        assertEquals("abc", sb.toString());
    }

    public void testSetLengthNegativeThrows() {
        StrBuilder sb = new StrBuilder("abc");
        try {
            sb.setLength(-1);
            fail("Expected StringIndexOutOfBoundsException");
        } catch (StringIndexOutOfBoundsException ex) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // capacity / ensureCapacity / minimizeCapacity
    //-----------------------------------------------------------------------

    public void testEnsureCapacity() {
        StrBuilder sb = new StrBuilder(5);
        sb.ensureCapacity(20);
        assertTrue(sb.capacity() >= 20);
        sb.ensureCapacity(2);
        assertTrue(sb.capacity() >= 20);
    }

    public void testMinimizeCapacity() {
        StrBuilder sb = new StrBuilder(50);
        sb.append("abc");
        sb.minimizeCapacity();
        assertEquals(3, sb.capacity());
        assertEquals("abc", sb.toString());
    }

    //-----------------------------------------------------------------------
    // size / isEmpty / clear
    //-----------------------------------------------------------------------

    public void testSizeIsEmptyClear() {
        StrBuilder sb = new StrBuilder();
        assertTrue(sb.isEmpty());
        assertEquals(0, sb.size());
        sb.append("xyz");
        assertFalse(sb.isEmpty());
        assertEquals(3, sb.size());
        sb.clear();
        assertTrue(sb.isEmpty());
        assertEquals(0, sb.size());
        assertEquals("", sb.toString());
    }

    //-----------------------------------------------------------------------
    // charAt / setCharAt / deleteCharAt
    //-----------------------------------------------------------------------

    public void testCharAt() {
        StrBuilder sb = new StrBuilder("abc");
        assertEquals('a', sb.charAt(0));
        assertEquals('c', sb.charAt(2));
    }

    public void testCharAtOutOfBounds() {
        StrBuilder sb = new StrBuilder("abc");
        try {
            sb.charAt(-1);
            fail("Expected StringIndexOutOfBoundsException");
        } catch (StringIndexOutOfBoundsException ex) {
            // expected
        }
        try {
            sb.charAt(3);
            fail("Expected StringIndexOutOfBoundsException");
        } catch (StringIndexOutOfBoundsException ex) {
            // expected
        }
    }

    public void testSetCharAt() {
        StrBuilder sb = new StrBuilder("abc");
        StrBuilder result = sb.setCharAt(1, 'X');
        assertSame(sb, result);
        assertEquals("aXc", sb.toString());
    }

    public void testSetCharAtOutOfBounds() {
        StrBuilder sb = new StrBuilder("abc");
        try {
            sb.setCharAt(3, 'X');
            fail("Expected StringIndexOutOfBoundsException");
        } catch (StringIndexOutOfBoundsException ex) {
            // expected
        }
    }

    public void testDeleteCharAt() {
        StrBuilder sb = new StrBuilder("abc");
        sb.deleteCharAt(1);
        assertEquals("ac", sb.toString());
    }

    public void testDeleteCharAtOutOfBounds() {
        StrBuilder sb = new StrBuilder("abc");
        try {
            sb.deleteCharAt(10);
            fail("Expected StringIndexOutOfBoundsException");
        } catch (StringIndexOutOfBoundsException ex) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // toCharArray / getChars
    //-----------------------------------------------------------------------

    public void testToCharArrayEmpty() {
        StrBuilder sb = new StrBuilder();
        char[] arr = sb.toCharArray();
        assertEquals(0, arr.length);
    }

    public void testToCharArrayFull() {
        StrBuilder sb = new StrBuilder("abc");
        char[] arr = sb.toCharArray();
        assertEquals(3, arr.length);
        assertEquals('a', arr[0]);
        assertEquals('c', arr[2]);
    }

    public void testToCharArrayRange() {
        StrBuilder sb = new StrBuilder("abcdef");
        char[] arr = sb.toCharArray(1, 4);
        assertEquals(3, arr.length);
        assertEquals("bcd", new String(arr));
    }

    public void testToCharArrayRangeEmpty() {
        StrBuilder sb = new StrBuilder("abcdef");
        char[] arr = sb.toCharArray(2, 2);
        assertEquals(0, arr.length);
    }

    public void testGetCharsDestinationNull() {
        StrBuilder sb = new StrBuilder("abc");
        char[] dest = sb.getChars(null);
        assertEquals(3, dest.length);
        assertEquals("abc", new String(dest));
    }

    public void testGetCharsDestinationTooSmall() {
        StrBuilder sb = new StrBuilder("abc");
        char[] input = new char[1];
        char[] dest = sb.getChars(input);
        assertNotSame(input, dest);
        assertEquals(3, dest.length);
    }

    public void testGetCharsRange() {
        StrBuilder sb = new StrBuilder("abcdef");
        char[] dest = new char[6];
        sb.getChars(1, 4, dest, 0);
        assertEquals('b', dest[0]);
        assertEquals('c', dest[1]);
        assertEquals('d', dest[2]);
    }

    public void testGetCharsRangeInvalid() {
        StrBuilder sb = new StrBuilder("abc");
        try {
            sb.getChars(-1, 2, new char[3], 0);
            fail("Expected StringIndexOutOfBoundsException");
        } catch (StringIndexOutOfBoundsException ex) {
            // expected
        }
        try {
            sb.getChars(2, 1, new char[3], 0);
            fail("Expected StringIndexOutOfBoundsException");
        } catch (StringIndexOutOfBoundsException ex) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // newLine / nullText
    //-----------------------------------------------------------------------

    public void testAppendNewLineDefault() {
        StrBuilder sb = new StrBuilder();
        sb.appendNewLine();
        assertEquals(System.getProperty("line.separator"), sb.toString());
    }

    public void testAppendNewLineCustom() {
        StrBuilder sb = new StrBuilder();
        sb.setNewLineText("<br/>");
        assertEquals("<br/>", sb.getNewLineText());
        sb.appendNewLine();
        assertEquals("<br/>", sb.toString());
    }

    public void testNullTextDefaultNoOutput() {
        StrBuilder sb = new StrBuilder();
        assertNull(sb.getNullText());
        sb.appendNull();
        assertEquals("", sb.toString());
    }

    public void testSetNullTextEmptyBecomesNull() {
        StrBuilder sb = new StrBuilder();
        sb.setNullText("");
        assertNull(sb.getNullText());
    }

    public void testSetNullTextCustom() {
        StrBuilder sb = new StrBuilder();
        sb.setNullText("NULL");
        sb.append((Object) null);
        assertEquals("NULL", sb.toString());
    }

    //-----------------------------------------------------------------------
    // append(Object/String/StringBuffer/StrBuilder/char[]) and primitives
    //-----------------------------------------------------------------------

    public void testAppendObject() {
        StrBuilder sb = new StrBuilder();
        sb.append((Object) new Integer(42));
        assertEquals("42", sb.toString());
    }

    public void testAppendObjectNull() {
        StrBuilder sb = new StrBuilder();
        StrBuilder result = sb.append((Object) null);
        assertSame(sb, result);
        assertEquals("", sb.toString());
    }

    public void testAppendString() {
        StrBuilder sb = new StrBuilder();
        sb.append("hello");
        assertEquals("hello", sb.toString());
    }

    public void testAppendStringNull() {
        StrBuilder sb = new StrBuilder();
        sb.append((String) null);
        assertEquals("", sb.toString());
    }

    public void testAppendStringRange() {
        StrBuilder sb = new StrBuilder();
        sb.append("hello world", 6, 5);
        assertEquals("world", sb.toString());
    }

    public void testAppendStringRangeInvalidStart() {
        StrBuilder sb = new StrBuilder();
        try {
            sb.append("hello", -1, 2);
            fail("Expected StringIndexOutOfBoundsException");
        } catch (StringIndexOutOfBoundsException ex) {
            // expected
        }
    }

    public void testAppendStringRangeInvalidLength() {
        StrBuilder sb = new StrBuilder();
        try {
            sb.append("hello", 0, 100);
            fail("Expected StringIndexOutOfBoundsException");
        } catch (StringIndexOutOfBoundsException ex) {
            // expected
        }
    }

    public void testAppendStringRangeNull() {
        StrBuilder sb = new StrBuilder();
        sb.append((String) null, 0, 0);
        assertEquals("", sb.toString());
    }

    public void testAppendStringBuffer() {
        StrBuilder sb = new StrBuilder();
        sb.append(new StringBuffer("hello"));
        assertEquals("hello", sb.toString());
    }

    public void testAppendStringBufferNull() {
        StrBuilder sb = new StrBuilder();
        sb.append((StringBuffer) null);
        assertEquals("", sb.toString());
    }

    public void testAppendStringBufferRange() {
        StrBuilder sb = new StrBuilder();
        sb.append(new StringBuffer("hello world"), 6, 5);
        assertEquals("world", sb.toString());
    }

    public void testAppendStrBuilder() {
        StrBuilder sb = new StrBuilder();
        sb.append(new StrBuilder("hello"));
        assertEquals("hello", sb.toString());
    }

    public void testAppendStrBuilderNull() {
        StrBuilder sb = new StrBuilder();
        sb.append((StrBuilder) null);
        assertEquals("", sb.toString());
    }

    public void testAppendStrBuilderRange() {
        StrBuilder sb = new StrBuilder();
        sb.append(new StrBuilder("hello world"), 6, 5);
        assertEquals("world", sb.toString());
    }

    public void testAppendCharArray() {
        StrBuilder sb = new StrBuilder();
        sb.append(new char[] {'a', 'b', 'c'});
        assertEquals("abc", sb.toString());
    }

    public void testAppendCharArrayNull() {
        StrBuilder sb = new StrBuilder();
        sb.append((char[]) null);
        assertEquals("", sb.toString());
    }

    public void testAppendCharArrayRange() {
        StrBuilder sb = new StrBuilder();
        sb.append(new char[] {'a', 'b', 'c', 'd', 'e'}, 1, 3);
        assertEquals("bcd", sb.toString());
    }

    public void testAppendCharArrayRangeInvalid() {
        StrBuilder sb = new StrBuilder();
        try {
            sb.append(new char[] {'a', 'b'}, 0, 5);
            fail("Expected StringIndexOutOfBoundsException");
        } catch (StringIndexOutOfBoundsException ex) {
            // expected
        }
    }

    public void testAppendBoolean() {
        StrBuilder sb = new StrBuilder();
        sb.append(true);
        sb.append(false);
        assertEquals("truefalse", sb.toString());
    }

    public void testAppendChar() {
        StrBuilder sb = new StrBuilder();
        StrBuilder result = sb.append('x');
        assertSame(sb, result);
        assertEquals("x", sb.toString());
    }

    public void testAppendInt() {
        StrBuilder sb = new StrBuilder();
        sb.append(42);
        assertEquals("42", sb.toString());
    }

    public void testAppendLong() {
        StrBuilder sb = new StrBuilder();
        sb.append(42L);
        assertEquals("42", sb.toString());
    }

    public void testAppendFloat() {
        StrBuilder sb = new StrBuilder();
        sb.append(1.5f);
        assertEquals("1.5", sb.toString());
    }

    public void testAppendDouble() {
        StrBuilder sb = new StrBuilder();
        sb.append(1.5d);
        assertEquals("1.5", sb.toString());
    }

    //-----------------------------------------------------------------------
    // appendWithSeparators
    //-----------------------------------------------------------------------

    public void testAppendWithSeparatorsArray() {
        StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators(new Object[] {"a", "b", "c"}, ",");
        assertEquals("a,b,c", sb.toString());
    }

    public void testAppendWithSeparatorsArrayNull() {
        StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators((Object[]) null, ",");
        assertEquals("", sb.toString());
    }

    public void testAppendWithSeparatorsArrayEmpty() {
        StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators(new Object[0], ",");
        assertEquals("", sb.toString());
    }

    public void testAppendWithSeparatorsArrayNullSeparator() {
        StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators(new Object[] {"a", "b"}, null);
        assertEquals("ab", sb.toString());
    }

    public void testAppendWithSeparatorsCollection() {
        StrBuilder sb = new StrBuilder();
        List list = new ArrayList();
        list.add("a");
        list.add("b");
        sb.appendWithSeparators(list, "-");
        assertEquals("a-b", sb.toString());
    }

    public void testAppendWithSeparatorsCollectionNull() {
        StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators((List) null, "-");
        assertEquals("", sb.toString());
    }

    public void testAppendWithSeparatorsIterator() {
        StrBuilder sb = new StrBuilder();
        List list = new ArrayList();
        list.add("a");
        list.add("b");
        sb.appendWithSeparators(list.iterator(), "-");
        assertEquals("a-b", sb.toString());
    }

    public void testAppendWithSeparatorsIteratorNull() {
        StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators((java.util.Iterator) null, "-");
        assertEquals("", sb.toString());
    }

    //-----------------------------------------------------------------------
    // appendPadding / appendFixedWidthPad
    //-----------------------------------------------------------------------

    public void testAppendPadding() {
        StrBuilder sb = new StrBuilder();
        sb.appendPadding(3, '*');
        assertEquals("***", sb.toString());
    }

    public void testAppendPaddingNegative() {
        StrBuilder sb = new StrBuilder();
        sb.appendPadding(-1, '*');
        assertEquals("", sb.toString());
    }

    public void testAppendFixedWidthPadLeftObject() {
        StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft("5", 3, '0');
        assertEquals("005", sb.toString());
    }

    public void testAppendFixedWidthPadLeftTruncates() {
        StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft("123456", 3, '0');
        assertEquals("456", sb.toString());
    }

    public void testAppendFixedWidthPadLeftZeroWidth() {
        StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft("abc", 0, '0');
        assertEquals("", sb.toString());
    }

    public void testAppendFixedWidthPadLeftNullUsesNullText() {
        StrBuilder sb = new StrBuilder();
        sb.setNullText("NULL");
        sb.appendFixedWidthPadLeft((Object) null, 6, ' ');
        assertEquals("  NULL", sb.toString());
    }

    public void testAppendFixedWidthPadLeftInt() {
        StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft(7, 3, '0');
        assertEquals("007", sb.toString());
    }

    public void testAppendFixedWidthPadRightObject() {
        StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadRight("5", 3, '0');
        assertEquals("500", sb.toString());
    }

    public void testAppendFixedWidthPadRightTruncates() {
        StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadRight("123456", 3, '0');
        assertEquals("123", sb.toString());
    }

    public void testAppendFixedWidthPadRightInt() {
        StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadRight(7, 3, '0');
        assertEquals("700", sb.toString());
    }

    //-----------------------------------------------------------------------
    // insert
    //-----------------------------------------------------------------------

    public void testInsertObject() {
        StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, (Object) new Integer(9));
        assertEquals("a9c", sb.toString());
    }

    public void testInsertObjectNullUsesNullText() {
        StrBuilder sb = new StrBuilder("ac");
        sb.setNullText("X");
        sb.insert(1, (Object) null);
        assertEquals("aXc", sb.toString());
    }

    public void testInsertString() {
        StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, "b");
        assertEquals("abc", sb.toString());
    }

    public void testInsertStringNull() {
        StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, (String) null);
        assertEquals("ac", sb.toString());
    }

    public void testInsertStringInvalidIndex() {
        StrBuilder sb = new StrBuilder("ac");
        try {
            sb.insert(10, "b");
            fail("Expected StringIndexOutOfBoundsException");
        } catch (StringIndexOutOfBoundsException ex) {
            // expected
        }
        try {
            sb.insert(-1, "b");
            fail("Expected StringIndexOutOfBoundsException");
        } catch (StringIndexOutOfBoundsException ex) {
            // expected
        }
    }

    public void testInsertCharArray() {
        StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, new char[] {'b', 'b'});
        assertEquals("abbc", sb.toString());
    }

    public void testInsertCharArrayNull() {
        StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, (char[]) null);
        assertEquals("ac", sb.toString());
    }

    public void testInsertCharArrayRange() {
        StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, new char[] {'x', 'b', 'y'}, 1, 1);
        assertEquals("abc", sb.toString());
    }

    public void testInsertCharArrayRangeInvalidOffset() {
        StrBuilder sb = new StrBuilder("ac");
        try {
            sb.insert(1, new char[] {'a'}, -1, 1);
            fail("Expected StringIndexOutOfBoundsException");
        } catch (StringIndexOutOfBoundsException ex) {
            // expected
        }
    }

    public void testInsertCharArrayRangeInvalidLength() {
        StrBuilder sb = new StrBuilder("ac");
        try {
            sb.insert(1, new char[] {'a'}, 0, 5);
            fail("Expected StringIndexOutOfBoundsException");
        } catch (StringIndexOutOfBoundsException ex) {
            // expected
        }
    }

    public void testInsertBoolean() {
        StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, true);
        assertEquals("atruec", sb.toString());
    }

    public void testInsertChar() {
        StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, 'b');
        assertEquals("abc", sb.toString());
    }

    public void testInsertInt() {
        StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, 9);
        assertEquals("a9c", sb.toString());
    }

    public void testInsertLong() {
        StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, 9L);
        assertEquals("a9c", sb.toString());
    }

    public void testInsertFloat() {
        StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, 1.5f);
        assertEquals("a1.5c", sb.toString());
    }

    public void testInsertDouble() {
        StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, 1.5d);
        assertEquals("a1.5c", sb.toString());
    }

    //-----------------------------------------------------------------------
    // delete / deleteAll / deleteFirst
    //-----------------------------------------------------------------------

    public void testDeleteRange() {
        StrBuilder sb = new StrBuilder("abcdef");
        sb.delete(1, 3);
        assertEquals("adef", sb.toString());
    }

    public void testDeleteRangeEndTooLarge() {
        StrBuilder sb = new StrBuilder("abcdef");
        sb.delete(4, 100);
        assertEquals("abcd", sb.toString());
    }

    public void testDeleteRangeInvalidStart() {
        StrBuilder sb = new StrBuilder("abc");
        try {
            sb.delete(-1, 2);
            fail("Expected StringIndexOutOfBoundsException");
        } catch (StringIndexOutOfBoundsException ex) {
            // expected
        }
    }

    public void testDeleteAllChar() {
        StrBuilder sb = new StrBuilder("abcabc");
        sb.deleteAll('a');
        assertEquals("bcbc", sb.toString());
    }

    public void testDeleteFirstChar() {
        StrBuilder sb = new StrBuilder("abcabc");
        sb.deleteFirst('a');
        assertEquals("bcabc", sb.toString());
    }

    public void testDeleteAllString() {
        StrBuilder sb = new StrBuilder("abcabc");
        sb.deleteAll("bc");
        assertEquals("aa", sb.toString());
    }

    public void testDeleteAllStringNull() {
        StrBuilder sb = new StrBuilder("abc");
        sb.deleteAll((String) null);
        assertEquals("abc", sb.toString());
    }

    public void testDeleteFirstString() {
        StrBuilder sb = new StrBuilder("abcabc");
        sb.deleteFirst("bc");
        assertEquals("aabc", sb.toString());
    }

    public void testDeleteAllMatcher() {
        StrBuilder sb = new StrBuilder("a1b2c3");
        sb.deleteAll(StrMatcher.charSetMatcher("123"));
        assertEquals("abc", sb.toString());
    }

    public void testDeleteFirstMatcher() {
        StrBuilder sb = new StrBuilder("a1b2c3");
        sb.deleteFirst(StrMatcher.charSetMatcher("123"));
        assertEquals("ab2c3", sb.toString());
    }

    //-----------------------------------------------------------------------
    // replace / replaceAll / replaceFirst
    //-----------------------------------------------------------------------

    public void testReplaceRange() {
        StrBuilder sb = new StrBuilder("abcdef");
        sb.replace(1, 3, "XYZ");
        assertEquals("aXYZdef", sb.toString());
    }

    public void testReplaceRangeShorter() {
        StrBuilder sb = new StrBuilder("abcdef");
        sb.replace(1, 5, "X");
        assertEquals("aXf", sb.toString());
    }

    public void testReplaceAllChar() {
        StrBuilder sb = new StrBuilder("abcabc");
        sb.replaceAll('a', 'X');
        assertEquals("XbcXbc", sb.toString());
    }

    public void testReplaceFirstChar() {
        StrBuilder sb = new StrBuilder("abcabc");
        sb.replaceFirst('a', 'X');
        assertEquals("Xbcabc", sb.toString());
    }

    public void testReplaceAllString() {
        StrBuilder sb = new StrBuilder("abcabc");
        sb.replaceAll("bc", "X");
        assertEquals("aXaX", sb.toString());
    }

    public void testReplaceAllStringNullReplace() {
        StrBuilder sb = new StrBuilder("abcabc");
        sb.replaceAll("bc", null);
        assertEquals("aa", sb.toString());
    }

    public void testReplaceFirstString() {
        StrBuilder sb = new StrBuilder("abcabc");
        sb.replaceFirst("bc", "X");
        assertEquals("aXabc", sb.toString());
    }

    public void testReplaceAllMatcher() {
        StrBuilder sb = new StrBuilder("a1b2c3");
        sb.replaceAll(StrMatcher.charSetMatcher("123"), "#");
        assertEquals("a#b#c#", sb.toString());
    }

    public void testReplaceFirstMatcher() {
        StrBuilder sb = new StrBuilder("a1b2c3");
        sb.replaceFirst(StrMatcher.charSetMatcher("123"), "#");
        assertEquals("a#b2c3", sb.toString());
    }

    //-----------------------------------------------------------------------
    // reverse / trim
    //-----------------------------------------------------------------------

    public void testReverse() {
        StrBuilder sb = new StrBuilder("abcde");
        sb.reverse();
        assertEquals("edcba", sb.toString());
    }

    public void testReverseEmpty() {
        StrBuilder sb = new StrBuilder();
        sb.reverse();
        assertEquals("", sb.toString());
    }

    public void testTrim() {
        StrBuilder sb = new StrBuilder("  abc  ");
        sb.trim();
        assertEquals("abc", sb.toString());
    }

    public void testTrimAllWhitespace() {
        StrBuilder sb = new StrBuilder("   ");
        sb.trim();
        assertEquals("", sb.toString());
    }

    public void testTrimEmpty() {
        StrBuilder sb = new StrBuilder();
        sb.trim();
        assertEquals("", sb.toString());
    }

    //-----------------------------------------------------------------------
    // startsWith / endsWith
    //-----------------------------------------------------------------------

    public void testStartsWith() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertTrue(sb.startsWith("abc"));
        assertFalse(sb.startsWith("bcd"));
        assertTrue(sb.startsWith(""));
        assertFalse(sb.startsWith(null));
        assertFalse(sb.startsWith("abcdefg"));
    }

    public void testEndsWith() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertTrue(sb.endsWith("def"));
        assertFalse(sb.endsWith("abc"));
        assertTrue(sb.endsWith(""));
        assertFalse(sb.endsWith(null));
        assertFalse(sb.endsWith("abcdefg"));
    }

    //-----------------------------------------------------------------------
    // substring / leftString / rightString / midString
    //-----------------------------------------------------------------------

    public void testSubstringStart() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("cdef", sb.substring(2));
    }

    public void testSubstringRange() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("cd", sb.substring(2, 4));
    }

    public void testSubstringInvalid() {
        StrBuilder sb = new StrBuilder("abc");
        try {
            sb.substring(-1, 2);
            fail("Expected StringIndexOutOfBoundsException");
        } catch (StringIndexOutOfBoundsException ex) {
            // expected
        }
    }

    public void testLeftString() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("abc", sb.leftString(3));
        assertEquals("", sb.leftString(-1));
        assertEquals("abcdef", sb.leftString(100));
    }

    public void testRightString() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("def", sb.rightString(3));
        assertEquals("", sb.rightString(0));
        assertEquals("abcdef", sb.rightString(100));
    }

    public void testMidString() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("cde", sb.midString(2, 3));
        assertEquals("abc", sb.midString(-5, 3));
        assertEquals("", sb.midString(2, -1));
        assertEquals("", sb.midString(100, 3));
        assertEquals("ef", sb.midString(4, 10));
    }

    //-----------------------------------------------------------------------
    // contains
    //-----------------------------------------------------------------------

    public void testContainsChar() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertTrue(sb.contains('c'));
        assertFalse(sb.contains('z'));
    }

    public void testContainsString() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertTrue(sb.contains("cde"));
        assertFalse(sb.contains("xyz"));
    }

    public void testContainsMatcher() {
        StrBuilder sb = new StrBuilder("abc123");
        assertTrue(sb.contains(StrMatcher.charSetMatcher("123")));
        assertFalse(sb.contains(StrMatcher.charSetMatcher("xyz")));
    }

    //-----------------------------------------------------------------------
    // indexOf / lastIndexOf
    //-----------------------------------------------------------------------

    public void testIndexOfChar() {
        StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(0, sb.indexOf('a'));
        assertEquals(3, sb.indexOf('a', 1));
        assertEquals(-1, sb.indexOf('z'));
    }

    public void testIndexOfString() {
        StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(1, sb.indexOf("bc"));
        assertEquals(4, sb.indexOf("bc", 2));
        assertEquals(-1, sb.indexOf("zz"));
        assertEquals(-1, sb.indexOf((String) null));
    }

    public void testIndexOfMatcher() {
        StrBuilder sb = new StrBuilder("abc123");
        assertEquals(3, sb.indexOf(StrMatcher.charSetMatcher("123")));
        assertEquals(-1, sb.indexOf((StrMatcher) null));
    }

    public void testLastIndexOfChar() {
        StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(3, sb.lastIndexOf('a'));
        assertEquals(0, sb.lastIndexOf('a', 2));
        assertEquals(-1, sb.lastIndexOf('z'));
    }

    public void testLastIndexOfString() {
        StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(4, sb.lastIndexOf("bc"));
        assertEquals(-1, sb.lastIndexOf("zz"));
        assertEquals(-1, sb.lastIndexOf((String) null));
    }

    public void testLastIndexOfMatcher() {
        StrBuilder sb = new StrBuilder("abc123");
        assertEquals(5, sb.lastIndexOf(StrMatcher.charSetMatcher("123")));
        assertEquals(-1, sb.lastIndexOf((StrMatcher) null));
    }

    //-----------------------------------------------------------------------
    // asTokenizer / asReader / asWriter
    //-----------------------------------------------------------------------

    public void testAsTokenizer() {
        StrBuilder sb = new StrBuilder("a b c");
        StrTokenizer tokenizer = sb.asTokenizer();
        assertEquals("a", tokenizer.next());
        assertEquals("b", tokenizer.next());
        assertEquals("c", tokenizer.next());
        assertFalse(tokenizer.hasNext());
    }

    public void testAsReader() throws IOException {
        StrBuilder sb = new StrBuilder("abc");
        Reader reader = sb.asReader();
        assertEquals('a', reader.read());
        assertEquals('b', reader.read());
        assertEquals('c', reader.read());
        assertEquals(-1, reader.read());
    }

    public void testAsReaderMarkReset() throws IOException {
        StrBuilder sb = new StrBuilder("abcdef");
        Reader reader = sb.asReader();
        assertTrue(reader.markSupported());
        reader.read();
        reader.mark(10);
        reader.read();
        reader.read();
        reader.reset();
        assertEquals('b', reader.read());
    }

    public void testAsReaderSkip() throws IOException {
        StrBuilder sb = new StrBuilder("abcdef");
        Reader reader = sb.asReader();
        long skipped = reader.skip(2);
        assertEquals(2, skipped);
        assertEquals('c', reader.read());
    }

    public void testAsWriter() throws IOException {
        StrBuilder sb = new StrBuilder();
        Writer writer = sb.asWriter();
        writer.write('a');
        writer.write("bc");
        writer.write(new char[] {'d', 'e'});
        assertEquals("abcde", sb.toString());
    }

    //-----------------------------------------------------------------------
    // equals / equalsIgnoreCase / hashCode
    //-----------------------------------------------------------------------

    public void testEqualsStrBuilder() {
        StrBuilder sb1 = new StrBuilder("abc");
        StrBuilder sb2 = new StrBuilder("abc");
        StrBuilder sb3 = new StrBuilder("abd");
        assertTrue(sb1.equals(sb2));
        assertFalse(sb1.equals(sb3));
        assertTrue(sb1.equals(sb1));
    }

    public void testEqualsObject() {
        StrBuilder sb1 = new StrBuilder("abc");
        assertFalse(sb1.equals((Object) "abc"));
        assertFalse(sb1.equals((Object) null));
        assertTrue(sb1.equals((Object) new StrBuilder("abc")));
    }

    public void testEqualsIgnoreCase() {
        StrBuilder sb1 = new StrBuilder("ABC");
        StrBuilder sb2 = new StrBuilder("abc");
        StrBuilder sb3 = new StrBuilder("abd");
        assertTrue(sb1.equalsIgnoreCase(sb2));
        assertFalse(sb1.equalsIgnoreCase(sb3));
        assertTrue(sb1.equalsIgnoreCase(sb1));
    }

    public void testHashCodeConsistentWithEquals() {
        StrBuilder sb1 = new StrBuilder("abc");
        StrBuilder sb2 = new StrBuilder("abc");
        assertEquals(sb1.hashCode(), sb2.hashCode());
    }

    //-----------------------------------------------------------------------
    // toString / toStringBuffer
    //-----------------------------------------------------------------------

    public void testToStringIndependent() {
        StrBuilder sb = new StrBuilder("abc");
        String s = sb.toString();
        sb.append("def");
        assertEquals("abc", s);
        assertEquals("abcdef", sb.toString());
    }

    public void testToStringBuffer() {
        StrBuilder sb = new StrBuilder("abc");
        StringBuffer buf = sb.toStringBuffer();
        assertEquals("abc", buf.toString());
    }

    //-----------------------------------------------------------------------
    // chaining
    //-----------------------------------------------------------------------

    public void testMethodChaining() {
        StrBuilder sb = new StrBuilder();
        sb.append("a").append(1).append(true).append('z');
        assertEquals("a1truez", sb.toString());
    }
}
