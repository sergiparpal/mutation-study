/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.csv;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.junit.Test;

public class CSVParserAgentTest {

    @Test
    public void testParseStringSimple() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b,c\n1,2,3\n", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            final CSVRecord first = records.get(0);
            assertEquals("a", first.get(0));
            assertEquals("b", first.get(1));
            assertEquals("c", first.get(2));
            final CSVRecord second = records.get(1);
            assertEquals("1", second.get(0));
            assertEquals("2", second.get(1));
            assertEquals("3", second.get(2));
            assertEquals(2, parser.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetRecordNumberIncrementsPerRecord() throws IOException {
        final CSVParser parser = CSVParser.parse("a\nb\nc\n", CSVFormat.DEFAULT);
        try {
            assertEquals(0, parser.getRecordNumber());
            final CSVRecord r1 = parser.nextRecord();
            assertEquals(1, r1.getRecordNumber());
            assertEquals(1, parser.getRecordNumber());
            final CSVRecord r2 = parser.nextRecord();
            assertEquals(2, r2.getRecordNumber());
            final CSVRecord r3 = parser.nextRecord();
            assertEquals(3, r3.getRecordNumber());
            assertNull(parser.nextRecord());
            assertEquals(3, parser.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testEmptyInputProducesNoRecords() throws IOException {
        final CSVParser parser = CSVParser.parse("", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertTrue(records.isEmpty());
            assertEquals(0, parser.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testHeaderMapIsNullWithoutHeaderFormat() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n1,2\n", CSVFormat.DEFAULT);
        try {
            assertNull(parser.getHeaderMap());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testHeaderMapFromFirstLine() throws IOException {
        final CSVParser parser = CSVParser.parse("name,age\nJohn,22\n", CSVFormat.DEFAULT.withHeader());
        try {
            final Map<String, Integer> headerMap = parser.getHeaderMap();
            assertNotNull(headerMap);
            assertEquals(Integer.valueOf(0), headerMap.get("name"));
            assertEquals(Integer.valueOf(1), headerMap.get("age"));

            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("John", records.get(0).get("name"));
            assertEquals("22", records.get(0).get("age"));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testHeaderMapReturnsDefensiveCopy() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n1,2\n", CSVFormat.DEFAULT.withHeader("a", "b"));
        try {
            final Map<String, Integer> map1 = parser.getHeaderMap();
            map1.put("c", Integer.valueOf(99));
            final Map<String, Integer> map2 = parser.getHeaderMap();
            assertFalse(map2.containsKey("c"));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testExplicitHeaderDoesNotConsumeFirstDataLine() throws IOException {
        final CSVParser parser = CSVParser.parse("1,2\n3,4\n", CSVFormat.DEFAULT.withHeader("a", "b"));
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("1", records.get(0).get("a"));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testExplicitHeaderWithSkipHeaderRecordSkipsFirstLine() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n1,2\n",
                CSVFormat.DEFAULT.withHeader("a", "b").withSkipHeaderRecord(true));
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("1", records.get(0).get("a"));
            assertEquals("2", records.get(0).get("b"));
        } finally {
            parser.close();
        }
    }

    @Test(expected = IllegalArgumentException.class)
    public void testDuplicateHeaderNamesThrows() throws IOException {
        final CSVParser parser = CSVParser.parse("a,a\n1,2\n", CSVFormat.DEFAULT.withHeader());
        parser.close();
    }

    @Test
    public void testDuplicateEmptyHeaderNamesAllowedWhenIgnored() throws IOException {
        final CSVParser parser = CSVParser.parse("a,,\n1,2,3\n",
                CSVFormat.DEFAULT.withHeader().withIgnoreEmptyHeaders(true));
        try {
            final Map<String, Integer> headerMap = parser.getHeaderMap();
            assertEquals(Integer.valueOf(0), headerMap.get("a"));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testIteratorReadsAllRecords() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n2\n3\n", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            int count = 0;
            String last = null;
            while (it.hasNext()) {
                last = it.next().get(0);
                count++;
            }
            assertEquals(3, count);
            assertEquals("3", last);
        } finally {
            parser.close();
        }
    }

    @Test
    public void testIteratorNextWithoutHasNext() throws IOException {
        final CSVParser parser = CSVParser.parse("1,2\n", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            final CSVRecord record = it.next();
            assertEquals("1", record.get(0));
            assertFalse(it.hasNext());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testIteratorNextThrowsAtEnd() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            it.next();
            assertFalse(it.hasNext());
            try {
                it.next();
                fail("Expected NoSuchElementException");
            } catch (final NoSuchElementException expected) {
                // expected
            }
        } finally {
            parser.close();
        }
    }

    @Test
    public void testIteratorRemoveUnsupported() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            try {
                it.remove();
                fail("Expected UnsupportedOperationException");
            } catch (final UnsupportedOperationException expected) {
                // expected
            }
        } finally {
            parser.close();
        }
    }

    @Test
    public void testIteratorAfterCloseHasNoNext() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n2\n", CSVFormat.DEFAULT);
        final Iterator<CSVRecord> it = parser.iterator();
        parser.close();
        assertFalse(it.hasNext());
        try {
            it.next();
            fail("Expected NoSuchElementException after close");
        } catch (final NoSuchElementException expected) {
            // expected
        }
    }

    @Test
    public void testCloseSetsIsClosed() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n", CSVFormat.DEFAULT);
        assertFalse(parser.isClosed());
        parser.close();
        assertTrue(parser.isClosed());
    }

    @Test
    public void testNullStringConvertsToNull() throws IOException {
        final CSVParser parser = CSVParser.parse("a,NULL,c\n", CSVFormat.DEFAULT.withNullString("NULL"));
        try {
            final CSVRecord record = parser.nextRecord();
            assertEquals("a", record.get(0));
            assertNull(record.get(1));
            assertEquals("c", record.get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetCurrentLineNumber() throws IOException {
        final CSVParser parser = CSVParser.parse("a\nb\nc\n", CSVFormat.DEFAULT);
        try {
            assertEquals(0, parser.getCurrentLineNumber());
            parser.nextRecord();
            assertEquals(1, parser.getCurrentLineNumber());
            parser.nextRecord();
            assertEquals(2, parser.getCurrentLineNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testMultiLineRecordLineNumberMismatch() throws IOException {
        final CSVParser parser = CSVParser.parse("\"a\nb\",c\nd,e\n", CSVFormat.DEFAULT);
        try {
            final CSVRecord first = parser.nextRecord();
            assertEquals("a\nb", first.get(0));
            assertEquals("c", first.get(1));
            // two physical lines were consumed by the first logical record
            assertEquals(2, parser.getCurrentLineNumber());
            final CSVRecord second = parser.nextRecord();
            assertEquals("d", second.get(0));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testCommentsAreIgnoredButSkipLine() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n# comment line\nc,d\n",
                CSVFormat.DEFAULT.withCommentStart('#'));
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("c", records.get(1).get(0));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetRecordsIntoProvidedCollection() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n2\n", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> target = new java.util.ArrayList<CSVRecord>();
            final List<CSVRecord> result = parser.getRecords(target);
            assertTrue(result == target);
            assertEquals(2, result.size());
        } finally {
            parser.close();
        }
    }

    @Test(expected = IllegalArgumentException.class)
    public void testConstructorNullReaderThrows() throws IOException {
        new CSVParser(null, CSVFormat.DEFAULT);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testConstructorNullFormatThrows() throws IOException {
        new CSVParser(new java.io.StringReader("a,b"), null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testParseStringNullStringThrows() throws IOException {
        CSVParser.parse((String) null, CSVFormat.DEFAULT);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testParseStringNullFormatThrows() throws IOException {
        CSVParser.parse("a,b", null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testParseFileNullFileThrows() throws IOException {
        CSVParser.parse((File) null, Charset.forName("UTF-8"), CSVFormat.DEFAULT);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testParseFileNullFormatThrows() throws IOException {
        CSVParser.parse(File.createTempFile("csvparseragenttest", ".csv"), Charset.forName("UTF-8"), null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testParseUrlNullUrlThrows() throws IOException {
        CSVParser.parse((URL) null, Charset.forName("UTF-8"), CSVFormat.DEFAULT);
    }

    @Test
    public void testParseFileRoundTrip() throws IOException {
        final File file = File.createTempFile("csvparseragenttest", ".csv");
        file.deleteOnExit();
        final Writer writer = new OutputStreamWriter(new FileOutputStream(file), "UTF-8");
        try {
            writer.write("x,y\n1,2\n");
        } finally {
            writer.close();
        }
        final CSVParser parser = CSVParser.parse(file, Charset.forName("UTF-8"), CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("x", records.get(0).get(0));
            assertEquals("1", records.get(1).get(0));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testInvalidCharAfterEncapsulatedTokenThrowsIOException() throws IOException {
        final CSVParser parser = CSVParser.parse("a,\"b\"c,d\n", CSVFormat.DEFAULT);
        try {
            parser.nextRecord();
            fail("Expected IOException for invalid char after encapsulated token");
        } catch (final IOException expected) {
            assertTrue(expected.getMessage().indexOf("invalid char between encapsulated token and delimiter") >= 0);
        } finally {
            parser.close();
        }
    }

    @Test
    public void testUnterminatedQuotedTokenThrowsIOException() throws IOException {
        final CSVParser parser = CSVParser.parse("a,\"unterminated", CSVFormat.DEFAULT);
        try {
            parser.nextRecord();
            fail("Expected IOException for unterminated encapsulated token");
        } catch (final IOException expected) {
            assertTrue(expected.getMessage().indexOf("EOF reached before encapsulated token finished") >= 0);
        } finally {
            parser.close();
        }
    }

    @Test
    public void testTrailingNewlineDoesNotProduceExtraRecord() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testNoTrailingNewlineStillParsesLastRecord() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("b", records.get(0).get(1));
        } finally {
            parser.close();
        }
    }
}
