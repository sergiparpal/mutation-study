/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.csv;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.StringReader;
import java.io.Writer;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.junit.Test;

/**
 * Self-contained tests for {@link CSVParser}.
 */
public class CSVParserAgentTest {

    @Test
    public void testParseSimpleRecords() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a,b,c\n1,2,3\n"), CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("b", records.get(0).get(1));
            assertEquals("c", records.get(0).get(2));
            assertEquals("1", records.get(1).get(0));
            assertEquals("2", records.get(1).get(1));
            assertEquals("3", records.get(1).get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetRecordNumberIncrements() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a\nb\nc\n"), CSVFormat.DEFAULT);
        try {
            assertEquals(0, parser.getRecordNumber());
            final CSVRecord r1 = parser.nextRecord();
            assertEquals(1, r1.getRecordNumber());
            assertEquals(1, parser.getRecordNumber());
            final CSVRecord r2 = parser.nextRecord();
            assertEquals(2, r2.getRecordNumber());
            final CSVRecord r3 = parser.nextRecord();
            assertEquals(3, r3.getRecordNumber());
            assertNull(parser.nextRecord());
            // record number should stay unchanged once exhausted
            assertEquals(3, parser.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testEmptyInputProducesNoRecords() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader(""), CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertTrue(records.isEmpty());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetRecordsAppendsToGivenCollection() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("x,y\n"), CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> seed = new java.util.ArrayList<CSVRecord>();
            final List<CSVRecord> result = parser.getRecords(seed);
            assertTrue("getRecords(T) should return the same collection passed in", result == seed);
            assertEquals(1, result.size());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testHeaderMapIsBuiltFromFirstLine() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("name,age\nJohn,30\n"),
                CSVFormat.DEFAULT.withHeader());
        try {
            final Map<String, Integer> headerMap = parser.getHeaderMap();
            assertNotNull(headerMap);
            assertEquals(Integer.valueOf(0), headerMap.get("name"));
            assertEquals(Integer.valueOf(1), headerMap.get("age"));

            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("John", records.get(0).get("name"));
            assertEquals("30", records.get(0).get("age"));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testHeaderMapCopyIsIndependent() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a,b\n1,2\n"), CSVFormat.DEFAULT.withHeader());
        try {
            final Map<String, Integer> map1 = parser.getHeaderMap();
            map1.put("extra", Integer.valueOf(99));
            final Map<String, Integer> map2 = parser.getHeaderMap();
            assertFalse("mutating one copy must not affect another", map2.containsKey("extra"));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testExplicitHeaderNamesDoNotConsumeFirstRecordByDefault() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("1,2\n3,4\n"),
                CSVFormat.DEFAULT.withHeader("col1", "col2"));
        try {
            final List<CSVRecord> records = parser.getRecords();
            // Explicit header names given: skipHeaderRecord defaults to false,
            // so the first data line "1,2" must still be present as a record.
            assertEquals(2, records.size());
            assertEquals("1", records.get(0).get("col1"));
            assertEquals("2", records.get(0).get("col2"));
            assertEquals("3", records.get(1).get("col1"));
            assertEquals("4", records.get(1).get("col2"));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testExplicitHeaderWithSkipHeaderRecord() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("col1,col2\n1,2\n"),
                CSVFormat.DEFAULT.withHeader("col1", "col2").withSkipHeaderRecord(true));
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("1", records.get(0).get("col1"));
            assertEquals("2", records.get(0).get("col2"));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testNoHeaderMeansNullHeaderMap() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a,b\n"), CSVFormat.DEFAULT);
        try {
            assertNull(parser.getHeaderMap());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetHeaderNameByIndexThrowsIllegalStateWithoutHeader() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a,b\n"), CSVFormat.DEFAULT);
        try {
            final CSVRecord record = parser.nextRecord();
            try {
                record.get("a");
                fail("Expected IllegalStateException since no header mapping was specified");
            } catch (final IllegalStateException expected) {
                // expected
            }
        } finally {
            parser.close();
        }
    }

    @Test
    public void testDuplicateHeaderNameThrows() {
        try {
            new CSVParser(new StringReader("a,a\n1,2\n"), CSVFormat.DEFAULT.withHeader());
            fail("Expected IllegalArgumentException for duplicate header name");
        } catch (final IllegalArgumentException expected) {
            // expected
        } catch (final IOException e) {
            fail("Unexpected IOException: " + e);
        }
    }

    @Test
    public void testCloseIsIdempotentAndMarksClosed() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a,b\n"), CSVFormat.DEFAULT);
        assertFalse(parser.isClosed());
        parser.close();
        assertTrue(parser.isClosed());
        // closing again should not throw
        parser.close();
        assertTrue(parser.isClosed());
    }

    @Test
    public void testNextRecordReturnsNullAtEndOfStream() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a\n"), CSVFormat.DEFAULT);
        try {
            final CSVRecord first = parser.nextRecord();
            assertNotNull(first);
            final CSVRecord second = parser.nextRecord();
            assertNull(second);
        } finally {
            parser.close();
        }
    }

    @Test
    public void testIteratorHasNextIsFalseWhenClosed() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a,b\nc,d\n"), CSVFormat.DEFAULT);
        final Iterator<CSVRecord> iterator = parser.iterator();
        parser.close();
        assertFalse("hasNext() must be false once the parser is closed", iterator.hasNext());
    }

    @Test
    public void testIteratorNextThrowsNoSuchElementWhenClosed() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a,b\nc,d\n"), CSVFormat.DEFAULT);
        final Iterator<CSVRecord> iterator = parser.iterator();
        parser.close();
        try {
            iterator.next();
            fail("Expected NoSuchElementException once the parser is closed");
        } catch (final NoSuchElementException expected) {
            // expected
        }
    }

    @Test
    public void testIteratorNextThrowsNoSuchElementAtEnd() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a\n"), CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> iterator = parser.iterator();
            assertTrue(iterator.hasNext());
            assertNotNull(iterator.next());
            assertFalse(iterator.hasNext());
            try {
                iterator.next();
                fail("Expected NoSuchElementException");
            } catch (final NoSuchElementException expected) {
                // expected
            }
        } finally {
            parser.close();
        }
    }

    @Test(expected = UnsupportedOperationException.class)
    public void testIteratorRemoveUnsupported() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a\n"), CSVFormat.DEFAULT);
        try {
            parser.iterator().remove();
        } finally {
            parser.close();
        }
    }

    @Test
    public void testQuotedValueWithEmbeddedDelimiterAndNewline() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("\"a,b\",\"c\nd\"\n"), CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("a,b", records.get(0).get(0));
            assertEquals("c\nd", records.get(0).get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testNullStringConvertsMatchingTokenToNull() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a,NULL,c\n"),
                CSVFormat.DEFAULT.withNullString("NULL"));
        try {
            final CSVRecord record = parser.nextRecord();
            assertEquals("a", record.get(0));
            assertNull(record.get(1));
            assertEquals("c", record.get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testCommentLinesAreNotReturnedAsRecords() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("# comment\na,b\n"),
                CSVFormat.DEFAULT.withCommentStart('#'));
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("b", records.get(0).get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testCommentAttachedToFollowingRecordIsCaptured() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("# my comment\na,b\n"),
                CSVFormat.DEFAULT.withCommentStart('#'));
        try {
            final CSVRecord record = parser.nextRecord();
            assertEquals("my comment", record.getComment());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testInconsistentRecordSizeIsDetectable() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a,b,c\n1,2\n"),
                CSVFormat.DEFAULT.withHeader("a", "b", "c").withSkipHeaderRecord(true));
        try {
            final CSVRecord record = parser.nextRecord();
            assertFalse("record with fewer values than headers must be inconsistent", record.isConsistent());
        } finally {
            parser.close();
        }
    }

    @Test(expected = IllegalArgumentException.class)
    public void testConstructorRejectsNullReader() throws IOException {
        new CSVParser(null, CSVFormat.DEFAULT);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testConstructorRejectsNullFormat() throws IOException {
        new CSVParser(new StringReader("a\n"), null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testStaticParseStringRejectsNullString() throws IOException {
        CSVParser.parse((String) null, CSVFormat.DEFAULT);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testStaticParseStringRejectsNullFormat() throws IOException {
        CSVParser.parse("a,b\n", null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testStaticParseFileRejectsNullFile() throws IOException {
        CSVParser.parse((File) null, Charset.forName("UTF-8"), CSVFormat.DEFAULT);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testStaticParseUrlRejectsNullUrl() throws IOException {
        CSVParser.parse((URL) null, Charset.forName("UTF-8"), CSVFormat.DEFAULT);
    }

    @Test
    public void testStaticParseStringProducesExpectedRecords() throws IOException {
        final CSVParser parser = CSVParser.parse("x,y\n1,2\n", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("x", records.get(0).get(0));
            assertEquals("1", records.get(1).get(0));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testStaticParseFileProducesExpectedRecords() throws IOException {
        final File tempFile = File.createTempFile("CSVParserAgentTest", ".csv");
        tempFile.deleteOnExit();
        final Writer writer = new OutputStreamWriter(new FileOutputStream(tempFile), Charset.forName("UTF-8"));
        try {
            writer.write("a,b\nc,d\n");
        } finally {
            writer.close();
        }
        final CSVParser parser = CSVParser.parse(tempFile, Charset.forName("UTF-8"), CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("d", records.get(1).get(1));
        } finally {
            parser.close();
            tempFile.delete();
        }
    }

    @Test
    public void testGetCurrentLineNumberTracksMultipleLines() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a\nb\nc\n"), CSVFormat.DEFAULT);
        try {
            assertEquals(0, parser.getCurrentLineNumber());
            parser.nextRecord();
            assertEquals(1, parser.getCurrentLineNumber());
            parser.nextRecord();
            assertEquals(2, parser.getCurrentLineNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testIgnoreEmptyHeaderAllowsMultipleBlankHeaders() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader(",,\n1,2,3\n"),
                CSVFormat.DEFAULT.withHeader().withIgnoreEmptyHeaders(true));
        try {
            final Map<String, Integer> headerMap = parser.getHeaderMap();
            assertNotNull(headerMap);
            // a single key "" should map to the last empty header's index
            assertTrue(headerMap.containsKey(""));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testHeaderFromEmptyStreamIsEmptyMapNotNull() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader(""), CSVFormat.DEFAULT.withHeader());
        try {
            final Map<String, Integer> headerMap = parser.getHeaderMap();
            assertNotNull("format declares a header, so the map should not be null even if input is empty",
                    headerMap);
            assertTrue(headerMap.isEmpty());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetByUnmappedNameThrowsIllegalArgument() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a,b\n1,2\n"),
                CSVFormat.DEFAULT.withHeader("a", "b").withSkipHeaderRecord(true));
        try {
            final CSVRecord record = parser.nextRecord();
            try {
                record.get("doesNotExist");
                fail("Expected IllegalArgumentException for unmapped column name");
            } catch (final IllegalArgumentException expected) {
                // expected
            }
        } finally {
            parser.close();
        }
    }

    @Test
    public void testDuplicateEmptyHeaderWithoutIgnoreThrows() {
        try {
            new CSVParser(new StringReader(",,\n1,2,3\n"),
                    CSVFormat.DEFAULT.withHeader().withIgnoreEmptyHeaders(false));
            fail("Expected IllegalArgumentException for duplicate empty header names");
        } catch (final IllegalArgumentException expected) {
            // expected
        } catch (final IOException e) {
            fail("Unexpected IOException: " + e);
        }
    }
}
