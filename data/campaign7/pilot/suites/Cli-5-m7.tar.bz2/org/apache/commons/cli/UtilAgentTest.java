/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.cli;

import junit.framework.TestCase;

public class UtilAgentTest extends TestCase {

    public void testStripLeadingHyphensNull() {
        assertNull(Util.stripLeadingHyphens(null));
    }

    public void testStripLeadingHyphensDoubleHyphen() {
        assertEquals("foo", Util.stripLeadingHyphens("--foo"));
    }

    public void testStripLeadingHyphensSingleHyphen() {
        assertEquals("foo", Util.stripLeadingHyphens("-foo"));
    }

    public void testStripLeadingHyphensNoHyphen() {
        assertEquals("foo", Util.stripLeadingHyphens("foo"));
    }

    public void testStripLeadingHyphensEmptyString() {
        assertEquals("", Util.stripLeadingHyphens(""));
    }

    public void testStripLeadingHyphensOnlyDoubleHyphen() {
        assertEquals("", Util.stripLeadingHyphens("--"));
    }

    public void testStripLeadingHyphensOnlySingleHyphen() {
        assertEquals("", Util.stripLeadingHyphens("-"));
    }

    public void testStripLeadingHyphensTripleHyphen() {
        assertEquals("-foo", Util.stripLeadingHyphens("---foo"));
    }

    public void testStripLeadingAndTrailingQuotesBoth() {
        assertEquals("one two", Util.stripLeadingAndTrailingQuotes("\"one two\""));
    }

    public void testStripLeadingAndTrailingQuotesLeadingOnly() {
        assertEquals("one two", Util.stripLeadingAndTrailingQuotes("\"one two"));
    }

    public void testStripLeadingAndTrailingQuotesTrailingOnly() {
        assertEquals("one two", Util.stripLeadingAndTrailingQuotes("one two\""));
    }

    public void testStripLeadingAndTrailingQuotesNoQuotes() {
        assertEquals("one two", Util.stripLeadingAndTrailingQuotes("one two"));
    }

    public void testStripLeadingAndTrailingQuotesEmptyString() {
        assertEquals("", Util.stripLeadingAndTrailingQuotes(""));
    }

    public void testStripLeadingAndTrailingQuotesOnlyOneQuoteChar() {
        assertEquals("", Util.stripLeadingAndTrailingQuotes("\""));
    }

    public void testStripLeadingAndTrailingQuotesNullThrowsNPE() {
        try {
            Util.stripLeadingAndTrailingQuotes(null);
            fail("Expected NullPointerException");
        } catch (NullPointerException e) {
            // expected: Util does not null-check this argument
        }
    }
}
