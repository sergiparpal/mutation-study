/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang.text;

import java.io.Reader;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

import junit.framework.TestCase;

/**
 * Self-contained JUnit 3 tests for {@link StrBuilder}.
 */
public class StrBuilderAgentTest extends TestCase {

    public StrBuilderAgentTest(String name) {
        super(name);
    }

    //-----------------------------------------------------------------------
    // constructors
    //-----------------------------------------------------------------------

    public void testConstructorDefault() {
        StrBuilder sb = new StrBuilder();
        assertEquals(0, sb.length());
        assertEquals(32, sb.capacity());
        assertEquals("", sb.toString());
    }

    public void testConstructorCapacity() {
        StrBuilder sb = new StrBuilder(10);
        assertEquals(0, sb.length());
        assertEquals(10, sb.capacity());
    }

    public void testConstructorCapacityZeroOrLessDefaultsTo32() {
        assertEquals(32, new StrBuilder(0).capacity());
        assertEquals(32, new StrBuilder(-5).capacity());
    }

    public void testConstructorString() {
        StrBuilder sb = new StrBuilder("abc");
        assertEquals(3, sb.length());
        assertEquals("abc", sb.toString());
        assertEquals(3 + 32, sb.capacity());
    }

    public void testConstructorNullString() {
        StrBuilder sb = new StrBuilder((String) null);
        assertEquals(0, sb.length());
        assertEquals("", sb.toString());
        assertEquals(32, sb.capacity());
    }

    //-----------------------------------------------------------------------
    // newLine / nullText properties
    //-----------------------------------------------------------------------

    public void testNewLineText() {
        StrBuilder sb = new StrBuilder();
        assertNull(sb.getNewLineText());
        StrBuilder result = sb.setNewLineText("<br/>");
        assertSame(sb, result);
        assertEquals("<br/>", sb.getNewLineText());
        sb.appendNewLine();
        assertEquals("<br/>", sb.toString());
    }

    public void testAppendNewLineSystemDefault() {
        StrBuilder sb = new StrBuilder();
        sb.appendNewLine();
        assertEquals(System.getProperty("line.separator"), sb.toString());
    }

    public void testNullText() {
        StrBuilder sb = new StrBuilder();
        assertNull(sb.getNullText());
        StrBuilder result = sb.setNullText("NULL");
        assertSame(sb, result);
        assertEquals("NULL", sb.getNullText());
    }

    public void testSetNullTextEmptyBecomesNull() {
        StrBuilder sb = new StrBuilder();
        sb.setNullText("");
        assertNull(sb.getNullText());
    }

    public void testAppendNullDefault() {
        StrBuilder sb = new StrBuilder();
        sb.appendNull();
        assertEquals("", sb.toString());
    }

    public void testAppendNullWithNullTextSet() {
        StrBuilder sb = new StrBuilder();
        sb.setNullText("NULL");
        sb.appendNull();
        assertEquals("NULL", sb.toString());
    }

    //-----------------------------------------------------------------------
    // length / setLength / size / isEmpty / clear
    //-----------------------------------------------------------------------

    public void testLength() {
        StrBuilder sb = new StrBuilder("abcde");
        assertEquals(5, sb.length());
        assertEquals(sb.length(), sb.size());
    }

    public void testSetLengthShrink() {
        StrBuilder sb = new StrBuilder("abcde");
        sb.setLength(2);
        assertEquals(2, sb.length());
        assertEquals("ab", sb.toString());
    }

    public void testSetLengthGrowPadsWithNulChar() {
        StrBuilder sb = new StrBuilder("ab");
        sb.setLength(4);
        assertEquals(4, sb.length());
        assertEquals('\0', sb.charAt(2));
        assertEquals('\0', sb.charAt(3));
    }

    public void testSetLengthNegativeThrows() {
        StrBuilder sb = new StrBuilder("abc");
        try {
            sb.setLength(-1);
            fail("Expected IndexOutOfBoundsException");
        } catch (IndexOutOfBoundsException ex) {
            // expected
        }
    }

    public void testSizeIsEmptyClear() {
        StrBuilder sb = new StrBuilder();
        assertTrue(sb.isEmpty());
        sb.append("x");
        assertFalse(sb.isEmpty());
        assertEquals(1, sb.size());
        StrBuilder result = sb.clear();
        assertSame(sb, result);
        assertEquals(0, sb.size());
        assertTrue(sb.isEmpty());
    }

    //-----------------------------------------------------------------------
    // capacity / ensureCapacity / minimizeCapacity
    //-----------------------------------------------------------------------

    public void testEnsureCapacityGrows() {
        StrBuilder sb = new StrBuilder(5);
        StrBuilder result = sb.ensureCapacity(20);
        assertSame(sb, result);
        assertTrue(sb.capacity() >= 20);
    }

    public void testEnsureCapacityNoShrink() {
        StrBuilder sb = new StrBuilder(50);
        sb.ensureCapacity(5);
        assertEquals(50, sb.capacity());
    }

    public void testMinimizeCapacity() {
        StrBuilder sb = new StrBuilder(50);
        sb.append("abc");
        sb.minimizeCapacity();
        assertEquals(3, sb.capacity());
        assertEquals("abc", sb.toString());
    }

    //-----------------------------------------------------------------------
    // charAt / setCharAt / deleteCharAt
    //-----------------------------------------------------------------------

    public void testCharAt() {
        StrBuilder sb = new StrBuilder("abc");
        assertEquals('a', sb.charAt(0));
        assertEquals('c', sb.charAt(2));
    }

    public void testCharAtInvalidIndexThrows() {
        StrBuilder sb = new StrBuilder("abc");
        try {
            sb.charAt(-1);
            fail("Expected exception for negative index");
        } catch (IndexOutOfBoundsException ex) {
            // expected
        }
        try {
            sb.charAt(3);
            fail("Expected exception for index == length");
        } catch (IndexOutOfBoundsException ex) {
            // expected
        }
    }

    public void testSetCharAt() {
        StrBuilder sb = new StrBuilder("abc");
        StrBuilder result = sb.setCharAt(1, 'X');
        assertSame(sb, result);
        assertEquals("aXc", sb.toString());
    }

    public void testSetCharAtInvalidIndexThrows() {
        StrBuilder sb = new StrBuilder("abc");
        try {
            sb.setCharAt(3, 'z');
            fail("Expected exception");
        } catch (IndexOutOfBoundsException ex) {
            // expected
        }
    }

    public void testDeleteCharAt() {
        StrBuilder sb = new StrBuilder("abc");
        StrBuilder result = sb.deleteCharAt(1);
        assertSame(sb, result);
        assertEquals("ac", sb.toString());
    }

    public void testDeleteCharAtInvalidIndexThrows() {
        StrBuilder sb = new StrBuilder("abc");
        try {
            sb.deleteCharAt(3);
            fail("Expected exception");
        } catch (IndexOutOfBoundsException ex) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // toCharArray / getChars
    //-----------------------------------------------------------------------

    public void testToCharArray() {
        StrBuilder sb = new StrBuilder("abc");
        char[] chars = sb.toCharArray();
        assertEquals(3, chars.length);
        assertEquals('a', chars[0]);
        assertEquals('c', chars[2]);
    }

    public void testToCharArrayEmpty() {
        StrBuilder sb = new StrBuilder();
        char[] chars = sb.toCharArray();
        assertEquals(0, chars.length);
    }

    public void testToCharArrayRange() {
        StrBuilder sb = new StrBuilder("abcdef");
        char[] chars = sb.toCharArray(1, 4);
        assertEquals(3, chars.length);
        assertEquals("bcd", new String(chars));
    }

    public void testToCharArrayRangeEndTooLargeTreatedAsEnd() {
        StrBuilder sb = new StrBuilder("abc");
        char[] chars = sb.toCharArray(1, 1000);
        assertEquals("bc", new String(chars));
    }

    public void testToCharArrayRangeInvalidStartThrows() {
        StrBuilder sb = new StrBuilder("abc");
        try {
            sb.toCharArray(-1, 2);
            fail("Expected exception");
        } catch (IndexOutOfBoundsException ex) {
            // expected
        }
    }

    public void testGetCharsDestinationNull() {
        StrBuilder sb = new StrBuilder("abc");
        char[] dest = sb.getChars(null);
        assertEquals("abc", new String(dest));
    }

    public void testGetCharsDestinationTooSmall() {
        StrBuilder sb = new StrBuilder("abc");
        char[] dest = sb.getChars(new char[1]);
        assertEquals(3, dest.length);
        assertEquals("abc", new String(dest));
    }

    public void testGetCharsWithRange() {
        StrBuilder sb = new StrBuilder("abcdef");
        char[] dest = new char[10];
        sb.getChars(1, 4, dest, 2);
        assertEquals('b', dest[2]);
        assertEquals('c', dest[3]);
        assertEquals('d', dest[4]);
    }

    public void testGetCharsRangeInvalidThrows() {
        StrBuilder sb = new StrBuilder("abc");
        try {
            sb.getChars(2, 1, new char[5], 0);
            fail("Expected exception for end < start");
        } catch (IndexOutOfBoundsException ex) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // append(Object/String/StringBuffer/StrBuilder/char[]/primitives)
    //-----------------------------------------------------------------------

    public void testAppendObject() {
        StrBuilder sb = new StrBuilder();
        StrBuilder result = sb.append((Object) new Integer(42));
        assertSame(sb, result);
        assertEquals("42", sb.toString());
    }

    public void testAppendObjectNull() {
        StrBuilder sb = new StrBuilder();
        sb.append((Object) null);
        assertEquals("", sb.toString());
    }

    public void testAppendString() {
        StrBuilder sb = new StrBuilder();
        sb.append("hello");
        assertEquals("hello", sb.toString());
    }

    public void testAppendStringNull() {
        StrBuilder sb = new StrBuilder();
        sb.setNullText("NULL");
        sb.append((String) null);
        assertEquals("NULL", sb.toString());
    }

    public void testAppendStringPart() {
        StrBuilder sb = new StrBuilder();
        sb.append("hello world", 6, 5);
        assertEquals("world", sb.toString());
    }

    public void testAppendStringPartInvalidStartThrows() {
        StrBuilder sb = new StrBuilder();
        try {
            sb.append("hello", -1, 2);
            fail("Expected exception");
        } catch (IndexOutOfBoundsException ex) {
            // expected
        }
    }

    public void testAppendStringPartInvalidLengthThrows() {
        StrBuilder sb = new StrBuilder();
        try {
            sb.append("hello", 2, 10);
            fail("Expected exception");
        } catch (IndexOutOfBoundsException ex) {
            // expected
        }
    }

    public void testAppendStringBuffer() {
        StrBuilder sb = new StrBuilder();
        sb.append(new StringBuffer("xyz"));
        assertEquals("xyz", sb.toString());
    }

    public void testAppendStringBuffer_Null() {
        StrBuilder sb = new StrBuilder();
        sb.append((StringBuffer) null);
        assertEquals("", sb.toString());
    }

    public void testAppendStringBufferPart() {
        StrBuilder sb = new StrBuilder();
        sb.append(new StringBuffer("hello world"), 6, 5);
        assertEquals("world", sb.toString());
    }

    public void testAppendStrBuilder() {
        StrBuilder sb = new StrBuilder("foo");
        StrBuilder other = new StrBuilder("bar");
        sb.append(other);
        assertEquals("foobar", sb.toString());
    }

    public void testAppendStrBuilderNull() {
        StrBuilder sb = new StrBuilder("foo");
        sb.append((StrBuilder) null);
        assertEquals("foo", sb.toString());
    }

    public void testAppendStrBuilderPart() {
        StrBuilder sb = new StrBuilder();
        StrBuilder other = new StrBuilder("hello world");
        sb.append(other, 6, 5);
        assertEquals("world", sb.toString());
    }

    public void testAppendCharArray() {
        StrBuilder sb = new StrBuilder();
        sb.append(new char[] {'a', 'b', 'c'});
        assertEquals("abc", sb.toString());
    }

    public void testAppendCharArrayNull() {
        StrBuilder sb = new StrBuilder();
        sb.append((char[]) null);
        assertEquals("", sb.toString());
    }

    public void testAppendCharArrayPart() {
        StrBuilder sb = new StrBuilder();
        sb.append(new char[] {'a', 'b', 'c', 'd', 'e'}, 1, 3);
        assertEquals("bcd", sb.toString());
    }

    public void testAppendCharArrayPartInvalidThrows() {
        StrBuilder sb = new StrBuilder();
        try {
            sb.append(new char[] {'a', 'b', 'c'}, 1, 10);
            fail("Expected exception");
        } catch (IndexOutOfBoundsException ex) {
            // expected
        }
    }

    public void testAppendBoolean() {
        StrBuilder sb = new StrBuilder();
        sb.append(true);
        sb.append(' ');
        sb.append(false);
        assertEquals("true false", sb.toString());
    }

    public void testAppendChar() {
        StrBuilder sb = new StrBuilder();
        StrBuilder result = sb.append('Z');
        assertSame(sb, result);
        assertEquals("Z", sb.toString());
    }

    public void testAppendIntLongFloatDouble() {
        StrBuilder sb = new StrBuilder();
        sb.append(1);
        sb.append('-');
        sb.append(2L);
        sb.append('-');
        sb.append(1.5f);
        sb.append('-');
        sb.append(2.5d);
        assertEquals("1-2-1.5-2.5", sb.toString());
    }

    //-----------------------------------------------------------------------
    // appendWithSeparators
    //-----------------------------------------------------------------------

    public void testAppendWithSeparatorsArray() {
        StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators(new Object[] {"a", "b", "c"}, ",");
        assertEquals("a,b,c", sb.toString());
    }

    public void testAppendWithSeparatorsArrayNull() {
        StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators((Object[]) null, ",");
        assertEquals("", sb.toString());
    }

    public void testAppendWithSeparatorsArrayNullSeparator() {
        StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators(new Object[] {"a", "b"}, null);
        assertEquals("ab", sb.toString());
    }

    public void testAppendWithSeparatorsCollection() {
        StrBuilder sb = new StrBuilder();
        List list = new ArrayList();
        list.add("a");
        list.add("b");
        sb.appendWithSeparators(list, "-");
        assertEquals("a-b", sb.toString());
    }

    public void testAppendWithSeparatorsCollectionNull() {
        StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators((java.util.Collection) null, "-");
        assertEquals("", sb.toString());
    }

    public void testAppendWithSeparatorsIterator() {
        StrBuilder sb = new StrBuilder();
        List list = new ArrayList();
        list.add("a");
        list.add("b");
        sb.appendWithSeparators(list.iterator(), "-");
        assertEquals("a-b", sb.toString());
    }

    public void testAppendWithSeparatorsIteratorNull() {
        StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators((java.util.Iterator) null, "-");
        assertEquals("", sb.toString());
    }

    //-----------------------------------------------------------------------
    // appendPadding / appendFixedWidthPad
    //-----------------------------------------------------------------------

    public void testAppendPadding() {
        StrBuilder sb = new StrBuilder("ab");
        sb.appendPadding(3, '*');
        assertEquals("ab***", sb.toString());
    }

    public void testAppendPaddingNegativeIsNoOp() {
        StrBuilder sb = new StrBuilder("ab");
        sb.appendPadding(-3, '*');
        assertEquals("ab", sb.toString());
    }

    public void testAppendFixedWidthPadLeft() {
        StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft("5", 3, '0');
        assertEquals("005", sb.toString());
    }

    public void testAppendFixedWidthPadLeftTruncatesLeft() {
        StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft("123456", 3, '0');
        assertEquals("456", sb.toString());
    }

    public void testAppendFixedWidthPadLeftZeroWidthNoEffect() {
        StrBuilder sb = new StrBuilder("x");
        sb.appendFixedWidthPadLeft("abc", 0, '0');
        assertEquals("x", sb.toString());
    }

    public void testAppendFixedWidthPadLeftIntValue() {
        StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft(5, 3, '0');
        assertEquals("005", sb.toString());
    }

    public void testAppendFixedWidthPadLeftNullObjectUsesNullText() {
        // Per the javadoc, a null object should fall back to the configured
        // null text, which defaults to "no text" (as it does everywhere else
        // in this class, e.g. appendNull()/append(Object)), not throw.
        StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft(null, 3, '*');
        assertEquals("***", sb.toString());
    }

    public void testAppendFixedWidthPadRight() {
        StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadRight("5", 3, '0');
        assertEquals("500", sb.toString());
    }

    public void testAppendFixedWidthPadRightTruncatesRight() {
        StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadRight("123456", 3, '0');
        assertEquals("123", sb.toString());
    }

    public void testAppendFixedWidthPadRightIntValue() {
        StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadRight(5, 3, '0');
        assertEquals("500", sb.toString());
    }

    public void testAppendFixedWidthPadRightNullObjectUsesNullText() {
        StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadRight(null, 3, '*');
        assertEquals("***", sb.toString());
    }

    //-----------------------------------------------------------------------
    // insert
    //-----------------------------------------------------------------------

    public void testInsertObject() {
        StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, (Object) new Integer(9));
        assertEquals("a9c", sb.toString());
    }

    public void testInsertObjectNullUsesNullText() {
        StrBuilder sb = new StrBuilder("ac");
        sb.setNullText("NULL");
        sb.insert(1, (Object) null);
        assertEquals("aNULLc", sb.toString());
    }

    public void testInsertString() {
        StrBuilder sb = new StrBuilder("ac");
        StrBuilder result = sb.insert(1, "XY");
        assertSame(sb, result);
        assertEquals("aXYc", sb.toString());
    }

    public void testInsertStringNullNoNullTextIsNoOp() {
        StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, (String) null);
        assertEquals("ac", sb.toString());
    }

    public void testInsertStringInvalidIndexThrows() {
        StrBuilder sb = new StrBuilder("ac");
        try {
            sb.insert(5, "x");
            fail("Expected exception");
        } catch (IndexOutOfBoundsException ex) {
            // expected
        }
    }

    public void testInsertCharArray() {
        StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, new char[] {'X', 'Y'});
        assertEquals("aXYc", sb.toString());
    }

    public void testInsertCharArrayNullNoNullTextIsNoOp() {
        StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, (char[]) null);
        assertEquals("ac", sb.toString());
    }

    public void testInsertCharArrayPart() {
        StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, new char[] {'W', 'X', 'Y', 'Z'}, 1, 2);
        assertEquals("aXYc", sb.toString());
    }

    public void testInsertCharArrayPartInvalidOffsetThrows() {
        StrBuilder sb = new StrBuilder("ac");
        try {
            sb.insert(1, new char[] {'a', 'b'}, 5, 1);
            fail("Expected exception");
        } catch (IndexOutOfBoundsException ex) {
            // expected
        }
    }

    public void testInsertBoolean() {
        StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, true);
        assertEquals("atruec", sb.toString());
    }

    public void testInsertCharPrimitive() {
        StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, 'X');
        assertEquals("aXc", sb.toString());
    }

    public void testInsertIntLongFloatDouble() {
        assertEquals("a1c", new StrBuilder("ac").insert(1, 1).toString());
        assertEquals("a1c", new StrBuilder("ac").insert(1, 1L).toString());
        assertEquals("a1.5c", new StrBuilder("ac").insert(1, 1.5f).toString());
        assertEquals("a1.5c", new StrBuilder("ac").insert(1, 1.5d).toString());
    }

    //-----------------------------------------------------------------------
    // delete / deleteAll / deleteFirst
    //-----------------------------------------------------------------------

    public void testDeleteRange() {
        StrBuilder sb = new StrBuilder("abcdef");
        StrBuilder result = sb.delete(1, 3);
        assertSame(sb, result);
        assertEquals("adef", sb.toString());
    }

    public void testDeleteRangeEndTooLargeTreatedAsEnd() {
        StrBuilder sb = new StrBuilder("abc");
        sb.delete(1, 100);
        assertEquals("a", sb.toString());
    }

    public void testDeleteRangeInvalidStartThrows() {
        StrBuilder sb = new StrBuilder("abc");
        try {
            sb.delete(-1, 2);
            fail("Expected exception");
        } catch (IndexOutOfBoundsException ex) {
            // expected
        }
    }

    public void testDeleteAllChar() {
        StrBuilder sb = new StrBuilder("abcabc");
        sb.deleteAll('a');
        assertEquals("bcbc", sb.toString());
    }

    public void testDeleteFirstChar() {
        StrBuilder sb = new StrBuilder("abcabc");
        sb.deleteFirst('a');
        assertEquals("bcabc", sb.toString());
    }

    public void testDeleteAllString() {
        StrBuilder sb = new StrBuilder("ababab");
        sb.deleteAll("ab");
        assertEquals("", sb.toString());
    }

    public void testDeleteAllStringNullIsNoOp() {
        StrBuilder sb = new StrBuilder("abc");
        sb.deleteAll((String) null);
        assertEquals("abc", sb.toString());
    }

    public void testDeleteFirstString() {
        StrBuilder sb = new StrBuilder("ababab");
        sb.deleteFirst("ab");
        assertEquals("abab", sb.toString());
    }

    public void testDeleteAllMatcher() {
        StrBuilder sb = new StrBuilder("a1b2c3");
        sb.deleteAll(StrMatcher.charSetMatcher("123"));
        assertEquals("abc", sb.toString());
    }

    public void testDeleteFirstMatcher() {
        StrBuilder sb = new StrBuilder("a1b2c3");
        sb.deleteFirst(StrMatcher.charSetMatcher("123"));
        assertEquals("ab2c3", sb.toString());
    }

    //-----------------------------------------------------------------------
    // replace
    //-----------------------------------------------------------------------

    public void testReplaceRange() {
        StrBuilder sb = new StrBuilder("abcdef");
        sb.replace(1, 3, "XYZ");
        assertEquals("aXYZdef", sb.toString());
    }

    public void testReplaceRangeWithNullDeletes() {
        StrBuilder sb = new StrBuilder("abcdef");
        sb.replace(1, 3, null);
        assertEquals("adef", sb.toString());
    }

    public void testReplaceAllChar() {
        StrBuilder sb = new StrBuilder("banana");
        sb.replaceAll('a', 'o');
        assertEquals("bonono", sb.toString());
    }

    public void testReplaceFirstChar() {
        StrBuilder sb = new StrBuilder("banana");
        sb.replaceFirst('a', 'o');
        assertEquals("bonana", sb.toString());
    }

    public void testReplaceAllString() {
        StrBuilder sb = new StrBuilder("one two one two");
        sb.replaceAll("one", "ONE");
        assertEquals("ONE two ONE two", sb.toString());
    }

    public void testReplaceFirstString() {
        StrBuilder sb = new StrBuilder("one two one two");
        sb.replaceFirst("one", "ONE");
        assertEquals("ONE two one two", sb.toString());
    }

    public void testReplaceAllMatcher() {
        StrBuilder sb = new StrBuilder("a1b2c3");
        sb.replaceAll(StrMatcher.charSetMatcher("123"), "#");
        assertEquals("a#b#c#", sb.toString());
    }

    public void testReplaceFirstMatcher() {
        StrBuilder sb = new StrBuilder("a1b2c3");
        sb.replaceFirst(StrMatcher.charSetMatcher("123"), "#");
        assertEquals("a#b2c3", sb.toString());
    }

    //-----------------------------------------------------------------------
    // reverse / trim
    //-----------------------------------------------------------------------

    public void testReverse() {
        StrBuilder sb = new StrBuilder("abcde");
        sb.reverse();
        assertEquals("edcba", sb.toString());
    }

    public void testReverseEmpty() {
        StrBuilder sb = new StrBuilder();
        sb.reverse();
        assertEquals("", sb.toString());
    }

    public void testTrim() {
        StrBuilder sb = new StrBuilder("  abc  ");
        sb.trim();
        assertEquals("abc", sb.toString());
    }

    public void testTrimAllWhitespace() {
        StrBuilder sb = new StrBuilder("   ");
        sb.trim();
        assertEquals("", sb.toString());
    }

    //-----------------------------------------------------------------------
    // startsWith / endsWith
    //-----------------------------------------------------------------------

    public void testStartsWith() {
        StrBuilder sb = new StrBuilder("hello world");
        assertTrue(sb.startsWith("hello"));
        assertFalse(sb.startsWith("world"));
    }

    public void testStartsWithNullReturnsFalse() {
        StrBuilder sb = new StrBuilder("hello");
        assertFalse(sb.startsWith(null));
    }

    public void testStartsWithEmptyReturnsTrue() {
        StrBuilder sb = new StrBuilder("hello");
        assertTrue(sb.startsWith(""));
    }

    public void testEndsWith() {
        StrBuilder sb = new StrBuilder("hello world");
        assertTrue(sb.endsWith("world"));
        assertFalse(sb.endsWith("hello"));
    }

    public void testEndsWithNullReturnsFalse() {
        StrBuilder sb = new StrBuilder("hello");
        assertFalse(sb.endsWith(null));
    }

    //-----------------------------------------------------------------------
    // substring / leftString / rightString / midString
    //-----------------------------------------------------------------------

    public void testSubstringFrom() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("cdef", sb.substring(2));
    }

    public void testSubstringRange() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("cd", sb.substring(2, 4));
    }

    public void testSubstringRangeEndTooLargeTreatedAsEnd() {
        StrBuilder sb = new StrBuilder("abc");
        assertEquals("bc", sb.substring(1, 100));
    }

    public void testLeftString() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("abc", sb.leftString(3));
    }

    public void testLeftStringTooLongReturnsWhole() {
        StrBuilder sb = new StrBuilder("abc");
        assertEquals("abc", sb.leftString(100));
    }

    public void testLeftStringNegativeReturnsEmpty() {
        StrBuilder sb = new StrBuilder("abc");
        assertEquals("", sb.leftString(-1));
    }

    public void testRightString() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("def", sb.rightString(3));
    }

    public void testRightStringTooLongReturnsWhole() {
        StrBuilder sb = new StrBuilder("abc");
        assertEquals("abc", sb.rightString(100));
    }

    public void testRightStringNegativeReturnsEmpty() {
        StrBuilder sb = new StrBuilder("abc");
        assertEquals("", sb.rightString(-1));
    }

    public void testMidString() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("cd", sb.midString(2, 2));
    }

    public void testMidStringNegativeIndexTreatedAsZero() {
        StrBuilder sb = new StrBuilder("abcdef");
        assertEquals("ab", sb.midString(-5, 2));
    }

    public void testMidStringIndexBeyondSizeReturnsEmpty() {
        StrBuilder sb = new StrBuilder("abc");
        assertEquals("", sb.midString(10, 2));
    }

    public void testMidStringNegativeLengthReturnsEmpty() {
        StrBuilder sb = new StrBuilder("abc");
        assertEquals("", sb.midString(0, -1));
    }

    public void testMidStringLengthBeyondAvailableReturnsAvailable() {
        StrBuilder sb = new StrBuilder("abc");
        assertEquals("bc", sb.midString(1, 100));
    }

    //-----------------------------------------------------------------------
    // contains
    //-----------------------------------------------------------------------

    public void testContainsCharFound() {
        StrBuilder sb = new StrBuilder("abc");
        assertTrue(sb.contains('b'));
        assertFalse(sb.contains('z'));
    }

    public void testContainsString() {
        StrBuilder sb = new StrBuilder("hello world");
        assertTrue(sb.contains("wor"));
        assertFalse(sb.contains("xyz"));
    }

    public void testContainsMatcher() {
        StrBuilder sb = new StrBuilder("abc123");
        assertTrue(sb.contains(StrMatcher.charSetMatcher("123")));
        assertFalse(sb.contains(StrMatcher.charSetMatcher("xyz")));
    }

    /**
     * BUG: contains(char) scans the internal buffer's full capacity
     * (buffer.length) instead of the builder's logical size, so characters
     * left over in the unused tail of the buffer after a shrink (setLength)
     * are wrongly reported as "contained".
     */
    public void testContainsCharIgnoresDataBeyondLogicalSize() {
        StrBuilder sb = new StrBuilder("ab");
        sb.append("cd");
        sb.setLength(2);
        assertEquals("ab", sb.toString());
        assertFalse("builder shrunk to 'ab' must not contain leftover 'c'", sb.contains('c'));
    }

    //-----------------------------------------------------------------------
    // indexOf / lastIndexOf
    //-----------------------------------------------------------------------

    public void testIndexOfChar() {
        StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(1, sb.indexOf('b'));
        assertEquals(-1, sb.indexOf('z'));
    }

    public void testIndexOfCharFromIndex() {
        StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(4, sb.indexOf('b', 2));
    }

    public void testIndexOfCharNegativeStartTreatedAsZero() {
        StrBuilder sb = new StrBuilder("abc");
        assertEquals(0, sb.indexOf('a', -5));
    }

    public void testIndexOfCharStartBeyondSizeReturnsMinusOne() {
        StrBuilder sb = new StrBuilder("abc");
        assertEquals(-1, sb.indexOf('a', 10));
    }

    /**
     * BUG: indexOf(char, int) scans up to buffer.length (the array's
     * capacity) rather than size (the builder's logical length), so a
     * character that only exists in the unused tail of the buffer -
     * e.g. left there after shrinking with setLength() - is incorrectly
     * reported as found, and at an index outside the logical string.
     */
    public void testIndexOfCharIgnoresDataBeyondLogicalSize() {
        StrBuilder sb = new StrBuilder("ab");
        sb.append("cd");
        sb.setLength(2);
        assertEquals("ab", sb.toString());
        assertEquals(-1, sb.indexOf('c'));
    }

    public void testIndexOfString() {
        StrBuilder sb = new StrBuilder("hello world hello");
        assertEquals(0, sb.indexOf("hello"));
        assertEquals(-1, sb.indexOf("xyz"));
    }

    public void testIndexOfStringFromIndex() {
        StrBuilder sb = new StrBuilder("hello world hello");
        assertEquals(12, sb.indexOf("hello", 1));
    }

    public void testIndexOfStringNullReturnsMinusOne() {
        StrBuilder sb = new StrBuilder("abc");
        assertEquals(-1, sb.indexOf((String) null));
    }

    public void testIndexOfEmptyStringReturnsStartIndex() {
        StrBuilder sb = new StrBuilder("abc");
        assertEquals(1, sb.indexOf("", 1));
    }

    /**
     * BUG: indexOf(String, int) computes its search bound from
     * buffer.length (the array's capacity) instead of size (the
     * builder's logical length), so a leftover substring in the unused
     * tail of the buffer after shrinking is incorrectly reported as
     * found.
     */
    public void testIndexOfStringIgnoresDataBeyondLogicalSize() {
        StrBuilder sb = new StrBuilder("ab");
        sb.append("cd");
        sb.setLength(2);
        assertEquals("ab", sb.toString());
        assertEquals(-1, sb.indexOf("cd"));
    }

    public void testIndexOfMatcher() {
        StrBuilder sb = new StrBuilder("abc123");
        assertEquals(3, sb.indexOf(StrMatcher.charSetMatcher("123")));
        assertEquals(-1, sb.indexOf(StrMatcher.charSetMatcher("xyz")));
    }

    public void testLastIndexOfChar() {
        StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(4, sb.lastIndexOf('b'));
        assertEquals(-1, sb.lastIndexOf('z'));
    }

    public void testLastIndexOfCharFromIndex() {
        StrBuilder sb = new StrBuilder("abcabc");
        assertEquals(1, sb.lastIndexOf('b', 3));
    }

    public void testLastIndexOfString() {
        StrBuilder sb = new StrBuilder("hello world hello");
        assertEquals(12, sb.lastIndexOf("hello"));
    }

    public void testLastIndexOfStringNullReturnsMinusOne() {
        StrBuilder sb = new StrBuilder("abc");
        assertEquals(-1, sb.lastIndexOf((String) null));
    }

    public void testLastIndexOfMatcher() {
        StrBuilder sb = new StrBuilder("abc123");
        assertEquals(5, sb.lastIndexOf(StrMatcher.charSetMatcher("123")));
    }

    //-----------------------------------------------------------------------
    // asReader / asWriter / asTokenizer
    //-----------------------------------------------------------------------

    public void testAsReaderReadsContent() throws Exception {
        StrBuilder sb = new StrBuilder("abc");
        Reader reader = sb.asReader();
        assertEquals('a', reader.read());
        assertEquals('b', reader.read());
        assertEquals('c', reader.read());
        assertEquals(-1, reader.read());
    }

    public void testAsWriterWritesIntoBuilder() throws Exception {
        StrBuilder sb = new StrBuilder();
        Writer writer = sb.asWriter();
        writer.write("hello");
        assertEquals("hello", sb.toString());
    }

    public void testAsTokenizer() {
        StrBuilder sb = new StrBuilder("a b c");
        StrTokenizer tok = sb.asTokenizer();
        String[] tokens = tok.getTokenArray();
        assertEquals(3, tokens.length);
        assertEquals("a", tokens[0]);
        assertEquals("b", tokens[1]);
        assertEquals("c", tokens[2]);
    }

    //-----------------------------------------------------------------------
    // equals / equalsIgnoreCase / hashCode
    //-----------------------------------------------------------------------

    public void testEqualsStrBuilderSameContent() {
        StrBuilder sb1 = new StrBuilder("abc");
        StrBuilder sb2 = new StrBuilder("abc");
        assertTrue(sb1.equals(sb2));
        assertTrue(sb2.equals(sb1));
    }

    public void testEqualsStrBuilderDifferentContent() {
        StrBuilder sb1 = new StrBuilder("abc");
        StrBuilder sb2 = new StrBuilder("abd");
        assertFalse(sb1.equals(sb2));
    }

    public void testEqualsStrBuilderDifferentLength() {
        StrBuilder sb1 = new StrBuilder("abc");
        StrBuilder sb2 = new StrBuilder("ab");
        assertFalse(sb1.equals(sb2));
    }

    public void testEqualsObjectNotStrBuilder() {
        StrBuilder sb = new StrBuilder("abc");
        assertFalse(sb.equals("abc"));
        assertFalse(sb.equals((Object) null));
    }

    /**
     * BUG: the javadoc of equals(StrBuilder) states "null returns false",
     * but the method dereferences the argument's size field without a
     * null check, so it throws NullPointerException instead.
     */
    public void testEqualsStrBuilderNullReturnsFalse() {
        StrBuilder sb = new StrBuilder("abc");
        StrBuilder other = null;
        assertFalse(sb.equals(other));
    }

    public void testEqualsIgnoreCase() {
        StrBuilder sb1 = new StrBuilder("ABC");
        StrBuilder sb2 = new StrBuilder("abc");
        assertTrue(sb1.equalsIgnoreCase(sb2));
    }

    public void testEqualsIgnoreCaseDifferent() {
        StrBuilder sb1 = new StrBuilder("ABC");
        StrBuilder sb2 = new StrBuilder("abd");
        assertFalse(sb1.equalsIgnoreCase(sb2));
    }

    /**
     * BUG: the javadoc of equalsIgnoreCase(StrBuilder) states "null returns
     * false", but the method dereferences the argument's size field without
     * a null check, so it throws NullPointerException instead.
     */
    public void testEqualsIgnoreCaseNullReturnsFalse() {
        StrBuilder sb = new StrBuilder("abc");
        StrBuilder other = null;
        assertFalse(sb.equalsIgnoreCase(other));
    }

    public void testHashCodeConsistentWithEquals() {
        StrBuilder sb1 = new StrBuilder("abc");
        StrBuilder sb2 = new StrBuilder("abc");
        assertEquals(sb1.hashCode(), sb2.hashCode());
    }

    //-----------------------------------------------------------------------
    // toString / toStringBuffer
    //-----------------------------------------------------------------------

    public void testToStringIndependentOfBuilder() {
        StrBuilder sb = new StrBuilder("abc");
        String s = sb.toString();
        sb.append("def");
        assertEquals("abc", s);
        assertEquals("abcdef", sb.toString());
    }

    public void testToStringBuffer() {
        StrBuilder sb = new StrBuilder("abc");
        StringBuffer buf = sb.toStringBuffer();
        assertEquals("abc", buf.toString());
    }

    //-----------------------------------------------------------------------
    // chaining returns 'this'
    //-----------------------------------------------------------------------

    public void testChainingReturnsSameInstance() {
        StrBuilder sb = new StrBuilder();
        StrBuilder result = sb.append("a").append(1).append('b').appendNewLine();
        assertSame(sb, result);
    }
}
