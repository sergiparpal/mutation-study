package org.apache.commons.lang.text;

import java.io.Reader;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

public class StrBuilderAgentTest {

    @Test
    public void testDefaultConstructor() {
        StrBuilder sb = new StrBuilder();
        assertEquals(0, sb.length());
        assertEquals(32, sb.capacity());
        assertEquals("", sb.toString());
    }

    @Test
    public void testCapacityConstructorNonPositiveDefaultsTo32() {
        StrBuilder sb = new StrBuilder(0);
        assertEquals(32, sb.capacity());
        StrBuilder sb2 = new StrBuilder(-5);
        assertEquals(32, sb2.capacity());
    }

    @Test
    public void testCapacityConstructorPositive() {
        StrBuilder sb = new StrBuilder(10);
        assertEquals(10, sb.capacity());
    }

    @Test
    public void testStringConstructorNull() {
        StrBuilder sb = new StrBuilder((String) null);
        assertEquals(0, sb.length());
        assertEquals("", sb.toString());
    }

    @Test
    public void testStringConstructorNonNull() {
        StrBuilder sb = new StrBuilder("abc");
        assertEquals(3, sb.length());
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testNewLineTextDefaultAndAppend() {
        StrBuilder sb = new StrBuilder();
        assertNull(sb.getNewLineText());
        sb.setNewLineText("<NL>");
        assertEquals("<NL>", sb.getNewLineText());
        sb.append("a").appendNewLine();
        assertEquals("a<NL>", sb.toString());
    }

    @Test
    public void testAppendNewLineDefaultUsesSystemLineSeparator() {
        StrBuilder sb = new StrBuilder();
        sb.appendNewLine();
        assertEquals(System.getProperty("line.separator"), sb.toString());
    }

    @Test
    public void testNullTextDefaultIsNoAppend() {
        StrBuilder sb = new StrBuilder();
        assertNull(sb.getNullText());
        sb.appendNull();
        assertEquals("", sb.toString());
    }

    @Test
    public void testSetNullTextEmptyStringBecomesNull() {
        StrBuilder sb = new StrBuilder();
        sb.setNullText("");
        assertNull(sb.getNullText());
    }

    @Test
    public void testSetNullTextAndAppendObjectNull() {
        StrBuilder sb = new StrBuilder();
        sb.setNullText("NULL");
        sb.append((Object) null);
        assertEquals("NULL", sb.toString());
    }

    @Test
    public void testSetLengthShrink() {
        StrBuilder sb = new StrBuilder("abcdef");
        sb.setLength(3);
        assertEquals(3, sb.length());
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testSetLengthGrowPadsWithNulChar() {
        StrBuilder sb = new StrBuilder("ab");
        sb.setLength(4);
        assertEquals(4, sb.length());
        assertEquals('\0', sb.charAt(2));
        assertEquals('\0', sb.charAt(3));
    }

    @Test
    public void testSetLengthNegativeThrows() {
        StrBuilder sb = new StrBuilder("abc");
        try {
            sb.setLength(-1);
            fail("expected exception");
        } catch (StringIndexOutOfBoundsException e) {
            // expected
        }
    }

    @Test
    public void testEnsureCapacityAndMinimizeCapacity() {
        StrBuilder sb = new StrBuilder(5);
        sb.ensureCapacity(100);
        assertTrue(sb.capacity() >= 100);
        sb.append("hi");
        sb.minimizeCapacity();
        assertEquals(2, sb.capacity());
    }

    @Test
    public void testSizeIsEmptyClear() {
        StrBuilder sb = new StrBuilder();
        assertTrue(sb.isEmpty());
        assertEquals(0, sb.size());
        sb.append("x");
        assertFalse(sb.isEmpty());
        assertEquals(1, sb.size());
        StrBuilder result = sb.clear();
        assertSame(sb, result);
        assertEquals(0, sb.size());
        assertTrue(sb.isEmpty());
    }

    @Test
    public void testCharAtValidAndInvalid() {
        StrBuilder sb = new StrBuilder("abc");
        assertEquals('a', sb.charAt(0));
        assertEquals('c', sb.charAt(2));
        try {
            sb.charAt(3);
            fail("expected exception");
        } catch (StringIndexOutOfBoundsException e) {
            // expected
        }
        try {
            sb.charAt(-1);
            fail("expected exception");
        } catch (StringIndexOutOfBoundsException e) {
            // expected
        }
    }

    @Test
    public void testSetCharAt() {
        StrBuilder sb = new StrBuilder("abc");
        sb.setCharAt(1, 'X');
        assertEquals("aXc", sb.toString());
        try {
            sb.setCharAt(10, 'Y');
            fail("expected exception");
        } catch (StringIndexOutOfBoundsException e) {
            // expected
        }
    }

    @Test
    public void testDeleteCharAt() {
        StrBuilder sb = new StrBuilder("abc");
        sb.deleteCharAt(1);
        assertEquals("ac", sb.toString());
        try {
            sb.deleteCharAt(10);
            fail("expected exception");
        } catch (StringIndexOutOfBoundsException e) {
            // expected
        }
    }

    @Test
    public void testToCharArrayEmpty() {
        StrBuilder sb = new StrBuilder();
        char[] chars = sb.toCharArray();
        assertEquals(0, chars.length);
    }

    @Test
    public void testToCharArrayFull() {
        StrBuilder sb = new StrBuilder("abc");
        char[] chars = sb.toCharArray();
        assertEquals(3, chars.length);
        assertEquals('a', chars[0]);
        assertEquals('c', chars[2]);
    }

    @Test
    public void testToCharArrayRange() {
        StrBuilder sb = new StrBuilder("abcdef");
        char[] chars = sb.toCharArray(1, 4);
        assertEquals(3, chars.length);
        assertEquals("bcd", new String(chars));
    }

    @Test
    public void testToCharArrayRangeEndTooLargeTreatedAsEnd() {
        StrBuilder sb = new StrBuilder("abc");
        char[] chars = sb.toCharArray(0, 100);
        assertEquals("abc", new String(chars));
    }

    @Test
    public void testGetCharsDestinationNullCreatesArray() {
        StrBuilder sb = new StrBuilder("abc");
        char[] result = sb.getChars(null);
        assertEquals(3, result.length);
        assertEquals("abc", new String(result));
    }

    @Test
    public void testGetCharsWithIndices() {
        StrBuilder sb = new StrBuilder("abcdef");
        char[] dest = new char[10];
        sb.getChars(1, 4, dest, 2);
        assertEquals('b', dest[2]);
        assertEquals('c', dest[3]);
        assertEquals('d', dest[4]);
    }

    @Test
    public void testGetCharsInvalidRangeThrows() {
        StrBuilder sb = new StrBuilder("abc");
        char[] dest = new char[10];
        try {
            sb.getChars(2, 1, dest, 0);
            fail("expected exception");
        } catch (StringIndexOutOfBoundsException e) {
            // expected
        }
    }

    @Test
    public void testAppendObjectAndNull() {
        StrBuilder sb = new StrBuilder();
        sb.append((Object) new Integer(42));
        assertEquals("42", sb.toString());
        sb.append((Object) null);
        assertEquals("42", sb.toString());
    }

    @Test
    public void testAppendStringChaining() {
        StrBuilder sb = new StrBuilder();
        StrBuilder result = sb.append("hello").append(" ").append("world");
        assertSame(sb, result);
        assertEquals("hello world", sb.toString());
    }

    @Test
    public void testAppendStringPartial() {
        StrBuilder sb = new StrBuilder();
        sb.append("hello world", 6, 5);
        assertEquals("world", sb.toString());
    }

    @Test
    public void testAppendStringPartialInvalidStartIndex() {
        StrBuilder sb = new StrBuilder();
        try {
            sb.append("abc", -1, 1);
            fail("expected exception");
        } catch (StringIndexOutOfBoundsException e) {
            // expected
        }
        try {
            sb.append("abc", 4, 1);
            fail("expected exception");
        } catch (StringIndexOutOfBoundsException e) {
            // expected
        }
    }

    @Test
    public void testAppendStringPartialInvalidLength() {
        StrBuilder sb = new StrBuilder();
        try {
            sb.append("abc", 0, -1);
            fail("expected exception");
        } catch (StringIndexOutOfBoundsException e) {
            // expected
        }
        try {
            sb.append("abc", 1, 5);
            fail("expected exception");
        } catch (StringIndexOutOfBoundsException e) {
            // expected
        }
    }

    @Test
    public void testAppendStringBuffer() {
        StrBuilder sb = new StrBuilder();
        sb.append(new StringBuffer("abc"));
        assertEquals("abc", sb.toString());
        sb.append((StringBuffer) null);
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendStringBufferPartial() {
        StrBuilder sb = new StrBuilder();
        sb.append(new StringBuffer("abcdef"), 2, 3);
        assertEquals("cde", sb.toString());
    }

    @Test
    public void testAppendStrBuilder() {
        StrBuilder sb = new StrBuilder();
        sb.append(new StrBuilder("xyz"));
        assertEquals("xyz", sb.toString());
        sb.append((StrBuilder) null);
        assertEquals("xyz", sb.toString());
    }

    @Test
    public void testAppendStrBuilderPartial() {
        StrBuilder sb = new StrBuilder();
        sb.append(new StrBuilder("abcdef"), 1, 2);
        assertEquals("bc", sb.toString());
    }

    @Test
    public void testAppendCharArray() {
        StrBuilder sb = new StrBuilder();
        sb.append(new char[] {'a', 'b', 'c'});
        assertEquals("abc", sb.toString());
        sb.append((char[]) null);
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testAppendCharArrayPartial() {
        StrBuilder sb = new StrBuilder();
        sb.append(new char[] {'a', 'b', 'c', 'd', 'e'}, 1, 3);
        assertEquals("bcd", sb.toString());
    }

    @Test
    public void testAppendCharArrayPartialInvalid() {
        StrBuilder sb = new StrBuilder();
        try {
            sb.append(new char[] {'a', 'b'}, -1, 1);
            fail("expected exception");
        } catch (StringIndexOutOfBoundsException e) {
            // expected
        }
        try {
            sb.append(new char[] {'a', 'b'}, 0, 5);
            fail("expected exception");
        } catch (StringIndexOutOfBoundsException e) {
            // expected
        }
    }

    @Test
    public void testAppendBoolean() {
        StrBuilder sb = new StrBuilder();
        sb.append(true);
        assertEquals("true", sb.toString());
        sb.clear();
        sb.append(false);
        assertEquals("false", sb.toString());
    }

    @Test
    public void testAppendCharPrimitive() {
        StrBuilder sb = new StrBuilder();
        sb.append('Z');
        assertEquals("Z", sb.toString());
    }

    @Test
    public void testAppendNumericPrimitives() {
        StrBuilder sb = new StrBuilder();
        sb.append(123).append(' ').append(456L).append(' ').append(1.5f).append(' ').append(2.5d);
        assertEquals("123 456 1.5 2.5", sb.toString());
    }

    @Test
    public void testAppendWithSeparatorsObjectArray() {
        StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators(new Object[] {"a", "b", "c"}, ",");
        assertEquals("a,b,c", sb.toString());
    }

    @Test
    public void testAppendWithSeparatorsObjectArrayNullSeparator() {
        StrBuilder sb = new StrBuilder();
        sb.appendWithSeparators(new Object[] {"a", "b"}, null);
        assertEquals("ab", sb.toString());
    }

    @Test
    public void testAppendWithSeparatorsNullArrayNoEffect() {
        StrBuilder sb = new StrBuilder("x");
        sb.appendWithSeparators((Object[]) null, ",");
        assertEquals("x", sb.toString());
    }

    @Test
    public void testAppendWithSeparatorsCollection() {
        StrBuilder sb = new StrBuilder();
        List list = new ArrayList();
        list.add("a");
        list.add("b");
        list.add("c");
        sb.appendWithSeparators(list, "-");
        assertEquals("a-b-c", sb.toString());
    }

    @Test
    public void testAppendWithSeparatorsCollectionNull() {
        StrBuilder sb = new StrBuilder("x");
        sb.appendWithSeparators((java.util.Collection) null, "-");
        assertEquals("x", sb.toString());
    }

    @Test
    public void testAppendWithSeparatorsIterator() {
        StrBuilder sb = new StrBuilder();
        List list = new ArrayList();
        list.add("1");
        list.add("2");
        sb.appendWithSeparators(list.iterator(), "/");
        assertEquals("1/2", sb.toString());
    }

    @Test
    public void testAppendPadding() {
        StrBuilder sb = new StrBuilder("ab");
        sb.appendPadding(3, '*');
        assertEquals("ab***", sb.toString());
    }

    @Test
    public void testAppendPaddingNegativeNoEffect() {
        StrBuilder sb = new StrBuilder("ab");
        sb.appendPadding(-1, '*');
        assertEquals("ab", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadLeftTruncates() {
        StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft("hello", 3, ' ');
        assertEquals("llo", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadLeftPads() {
        StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft("ab", 5, '0');
        assertEquals("000ab", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadLeftZeroWidthNoEffect() {
        StrBuilder sb = new StrBuilder("x");
        sb.appendFixedWidthPadLeft("ab", 0, '0');
        assertEquals("x", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadLeftNullObjectUsesNullText() {
        StrBuilder sb = new StrBuilder();
        sb.setNullText("NA");
        sb.appendFixedWidthPadLeft((Object) null, 4, '-');
        assertEquals("--NA", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadLeftInt() {
        StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadLeft(7, 3, '0');
        assertEquals("007", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadRightTruncates() {
        StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadRight("hello", 3, ' ');
        assertEquals("hel", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadRightPads() {
        StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadRight("ab", 5, '-');
        assertEquals("ab---", sb.toString());
    }

    @Test
    public void testAppendFixedWidthPadRightInt() {
        StrBuilder sb = new StrBuilder();
        sb.appendFixedWidthPadRight(7, 3, '0');
        assertEquals("700", sb.toString());
    }

    @Test
    public void testInsertObject() {
        StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, (Object) new Integer(9));
        assertEquals("a9c", sb.toString());
    }

    @Test
    public void testInsertObjectNullUsesNullText() {
        StrBuilder sb = new StrBuilder("ac");
        sb.setNullText("NULL");
        sb.insert(1, (Object) null);
        assertEquals("aNULLc", sb.toString());
    }

    @Test
    public void testInsertString() {
        StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, "bb");
        assertEquals("abbc", sb.toString());
    }

    @Test
    public void testInsertStringNullNoTextNoEffect() {
        StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, (String) null);
        assertEquals("ac", sb.toString());
    }

    @Test
    public void testInsertStringInvalidIndexThrows() {
        StrBuilder sb = new StrBuilder("abc");
        try {
            sb.insert(-1, "x");
            fail("expected exception");
        } catch (StringIndexOutOfBoundsException e) {
            // expected
        }
        try {
            sb.insert(10, "x");
            fail("expected exception");
        } catch (StringIndexOutOfBoundsException e) {
            // expected
        }
    }

    @Test
    public void testInsertCharArray() {
        StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, new char[] {'x', 'y'});
        assertEquals("axyc", sb.toString());
    }

    @Test
    public void testInsertCharArrayNullNoEffect() {
        StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, (char[]) null);
        assertEquals("ac", sb.toString());
    }

    @Test
    public void testInsertCharArrayPartial() {
        StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, new char[] {'w', 'x', 'y', 'z'}, 1, 2);
        assertEquals("axyc", sb.toString());
    }

    @Test
    public void testInsertCharArrayPartialInvalidOffset() {
        StrBuilder sb = new StrBuilder("ac");
        try {
            sb.insert(1, new char[] {'a', 'b'}, -1, 1);
            fail("expected exception");
        } catch (StringIndexOutOfBoundsException e) {
            // expected
        }
    }

    @Test
    public void testInsertCharArrayPartialInvalidLength() {
        StrBuilder sb = new StrBuilder("ac");
        try {
            sb.insert(1, new char[] {'a', 'b'}, 0, 10);
            fail("expected exception");
        } catch (StringIndexOutOfBoundsException e) {
            // expected
        }
    }

    @Test
    public void testInsertBoolean() {
        StrBuilder sb = new StrBuilder("ac");
        sb.insert(1, true);
        assertEquals("atruec", sb.toString());
        sb = new StrBuilder("ac");
        sb.insert(1, false);
        assertEquals("afalsec", sb.toString());
    }

    @Test
    public void testInsertPrimitives() {
        StrBuilder sb = new StrBuilder("[]");
        sb.insert(1, 42);
        assertEquals("[42]", sb.toString());
        sb = new StrBuilder("[]");
        sb.insert(1, 42L);
        assertEquals("[42]", sb.toString());
        sb = new StrBuilder("[]");
        sb.insert(1, 1.5f);
        assertEquals("[1.5]", sb.toString());
        sb = new StrBuilder("[]");
        sb.insert(1, 1.5d);
        assertEquals("[1.5]", sb.toString());
    }

    @Test
    public void testDeleteRange() {
        StrBuilder sb = new StrBuilder("abcdef");
        sb.delete(1, 3);
        assertEquals("adef", sb.toString());
    }

    @Test
    public void testDeleteRangeEndTooLargeTreatedAsEnd() {
        StrBuilder sb = new StrBuilder("abc");
        sb.delete(1, 100);
        assertEquals("a", sb.toString());
    }

    @Test
    public void testDeleteRangeInvalidThrows() {
        StrBuilder sb = new StrBuilder("abc");
        try {
            sb.delete(-1, 2);
            fail("expected exception");
        } catch (StringIndexOutOfBoundsException e) {
            // expected
        }
        try {
            sb.delete(2, 1);
            fail("expected exception");
        } catch (StringIndexOutOfBoundsException e) {
            // expected
        }
    }

    @Test
    public void testDeleteAllChar() {
        StrBuilder sb = new StrBuilder("abcabc");
        sb.deleteAll('a');
        assertEquals("bcbc", sb.toString());
    }

    @Test
    public void testDeleteAllCharNoMatch() {
        StrBuilder sb = new StrBuilder("abc");
        sb.deleteAll('z');
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testDeleteFirstChar() {
        StrBuilder sb = new StrBuilder("abcabc");
        sb.deleteFirst('a');
        assertEquals("bcabc", sb.toString());
    }

    @Test
    public void testDeleteAllString() {
        StrBuilder sb = new StrBuilder("abXcdXef");
        sb.deleteAll("X");
        assertEquals("abcdef", sb.toString());
    }

    @Test
    public void testDeleteAllStringNullNoEffect() {
        StrBuilder sb = new StrBuilder("abc");
        sb.deleteAll((String) null);
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testDeleteFirstString() {
        StrBuilder sb = new StrBuilder("abXcdXef");
        sb.deleteFirst("X");
        assertEquals("abcdXef", sb.toString());
    }

    @Test
    public void testDeleteAllMatcher() {
        StrBuilder sb = new StrBuilder("a1b2c3");
        sb.deleteAll(StrMatcher.charSetMatcher("123"));
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testDeleteFirstMatcher() {
        StrBuilder sb = new StrBuilder("a1b2c3");
        sb.deleteFirst(StrMatcher.charSetMatcher("123"));
        assertEquals("ab2c3", sb.toString());
    }

    @Test
    public void testReplaceRange() {
        StrBuilder sb = new StrBuilder("abcdef");
        sb.replace(1, 3, "XYZ");
        assertEquals("aXYZdef", sb.toString());
    }

    @Test
    public void testReplaceRangeNullDeletes() {
        StrBuilder sb = new StrBuilder("abcdef");
        sb.replace(1, 3, null);
        assertEquals("adef", sb.toString());
    }

    @Test
    public void testReplaceAllChar() {
        StrBuilder sb = new StrBuilder("banana");
        sb.replaceAll('a', 'o');
        assertEquals("bonono", sb.toString());
    }

    @Test
    public void testReplaceFirstChar() {
        StrBuilder sb = new StrBuilder("banana");
        sb.replaceFirst('a', 'o');
        assertEquals("bonana", sb.toString());
    }

    @Test
    public void testReplaceAllString() {
        StrBuilder sb = new StrBuilder("one two one two");
        sb.replaceAll("one", "ONE");
        assertEquals("ONE two ONE two", sb.toString());
    }

    @Test
    public void testReplaceFirstString() {
        StrBuilder sb = new StrBuilder("one two one two");
        sb.replaceFirst("one", "ONE");
        assertEquals("ONE two one two", sb.toString());
    }

    @Test
    public void testReplaceAllStringNullSearchNoEffect() {
        StrBuilder sb = new StrBuilder("abc");
        sb.replaceAll((String) null, "x");
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testReplaceAllMatcher() {
        StrBuilder sb = new StrBuilder("a1b2c3");
        sb.replaceAll(StrMatcher.charSetMatcher("123"), "#");
        assertEquals("a#b#c#", sb.toString());
    }

    @Test
    public void testReplaceFirstMatcher() {
        StrBuilder sb = new StrBuilder("a1b2c3");
        sb.replaceFirst(StrMatcher.charSetMatcher("123"), "#");
        assertEquals("a#b2c3", sb.toString());
    }

    @Test
    public void testReverseEmptyAndNonEmpty() {
        StrBuilder sb = new StrBuilder();
        sb.reverse();
        assertEquals("", sb.toString());
        sb = new StrBuilder("abcd");
        sb.reverse();
        assertEquals("dcba", sb.toString());
    }

    @Test
    public void testTrim() {
        StrBuilder sb = new StrBuilder("  hello world  ");
        sb.trim();
        assertEquals("hello world", sb.toString());
    }

    @Test
    public void testTrimAllWhitespace() {
        StrBuilder sb = new StrBuilder("   ");
        sb.trim();
        assertEquals("", sb.toString());
    }

    @Test
    public void testStartsWith() {
        StrBuilder sb = new StrBuilder("hello world");
        assertTrue(sb.startsWith("hello"));
        assertFalse(sb.startsWith("world"));
        assertFalse(sb.startsWith(null));
        assertTrue(sb.startsWith(""));
        assertFalse(sb.startsWith("this is too long to match"));
    }

    @Test
    public void testEndsWith() {
        StrBuilder sb = new StrBuilder("hello world");
        assertTrue(sb.endsWith("world"));
        assertFalse(sb.endsWith("hello"));
        assertFalse(sb.endsWith(null));
        assertTrue(sb.endsWith(""));
    }

    @Test
    public void testSubstringOneArg() {
        StrBuilder sb = new StrBuilder("hello world");
        assertEquals("world", sb.substring(6));
    }

    @Test
    public void testSubstringTwoArgs() {
        StrBuilder sb = new StrBuilder("hello world");
        assertEquals("hello", sb.substring(0, 5));
    }

    @Test
    public void testSubstringEndTooLargeTreatedAsEnd() {
        StrBuilder sb = new StrBuilder("abc");
        assertEquals("abc", sb.substring(0, 999));
    }

    @Test
    public void testLeftString() {
        StrBuilder sb = new StrBuilder("hello");
        assertEquals("he", sb.leftString(2));
        assertEquals("hello", sb.leftString(100));
        assertEquals("", sb.leftString(0));
        assertEquals("", sb.leftString(-1));
    }

    @Test
    public void testRightString() {
        StrBuilder sb = new StrBuilder("hello");
        assertEquals("lo", sb.rightString(2));
        assertEquals("hello", sb.rightString(100));
        assertEquals("", sb.rightString(0));
        assertEquals("", sb.rightString(-1));
    }

    @Test
    public void testMidString() {
        StrBuilder sb = new StrBuilder("hello world");
        assertEquals("llo", sb.midString(2, 3));
        assertEquals("hello world", sb.midString(-5, 100));
        assertEquals("", sb.midString(2, -1));
        assertEquals("", sb.midString(100, 3));
    }

    @Test
    public void testContainsChar() {
        StrBuilder sb = new StrBuilder("hello");
        assertTrue(sb.contains('e'));
        assertFalse(sb.contains('z'));
    }

    @Test
    public void testContainsString() {
        StrBuilder sb = new StrBuilder("hello world");
        assertTrue(sb.contains("wor"));
        assertFalse(sb.contains("xyz"));
    }

    @Test
    public void testContainsMatcher() {
        StrBuilder sb = new StrBuilder("hello123");
        assertTrue(sb.contains(StrMatcher.charSetMatcher("0123456789")));
        assertFalse(sb.contains(StrMatcher.charSetMatcher("xyz")));
    }

    @Test
    public void testIndexOfChar() {
        StrBuilder sb = new StrBuilder("hello");
        assertEquals(2, sb.indexOf('l'));
        assertEquals(-1, sb.indexOf('z'));
    }

    @Test
    public void testIndexOfCharWithStart() {
        StrBuilder sb = new StrBuilder("hello");
        assertEquals(3, sb.indexOf('l', 3));
        assertEquals(-1, sb.indexOf('l', 10));
    }

    @Test
    public void testIndexOfString() {
        StrBuilder sb = new StrBuilder("hello world");
        assertEquals(6, sb.indexOf("world"));
        assertEquals(-1, sb.indexOf("xyz"));
        assertEquals(-1, sb.indexOf((String) null));
    }

    @Test
    public void testIndexOfStringEmptyReturnsStartIndex() {
        StrBuilder sb = new StrBuilder("hello");
        assertEquals(2, sb.indexOf("", 2));
    }

    @Test
    public void testIndexOfMatcher() {
        StrBuilder sb = new StrBuilder("ab12cd");
        assertEquals(2, sb.indexOf(StrMatcher.charSetMatcher("0123456789")));
        assertEquals(-1, sb.indexOf((StrMatcher) null));
    }

    @Test
    public void testLastIndexOfChar() {
        StrBuilder sb = new StrBuilder("hello");
        assertEquals(3, sb.lastIndexOf('l'));
        assertEquals(-1, sb.lastIndexOf('z'));
    }

    @Test
    public void testLastIndexOfString() {
        StrBuilder sb = new StrBuilder("one two one two");
        assertEquals(8, sb.lastIndexOf("one"));
        assertEquals(-1, sb.lastIndexOf("xyz"));
        assertEquals(-1, sb.lastIndexOf((String) null));
    }

    @Test
    public void testLastIndexOfMatcher() {
        StrBuilder sb = new StrBuilder("ab12cd34");
        assertEquals(7, sb.lastIndexOf(StrMatcher.charSetMatcher("0123456789")));
        assertEquals(-1, sb.lastIndexOf((StrMatcher) null));
    }

    @Test
    public void testAsTokenizer() {
        StrBuilder sb = new StrBuilder("a b c");
        StrTokenizer tokenizer = sb.asTokenizer();
        assertNotNull(tokenizer);
        String[] tokens = tokenizer.getTokenArray();
        assertEquals(3, tokens.length);
        assertEquals("a", tokens[0]);
        assertEquals("c", tokens[2]);
    }

    @Test
    public void testAsReader() throws Exception {
        StrBuilder sb = new StrBuilder("abc");
        Reader reader = sb.asReader();
        assertEquals('a', reader.read());
        assertEquals('b', reader.read());
        assertEquals('c', reader.read());
        assertEquals(-1, reader.read());
        reader.close();
    }

    @Test
    public void testAsReaderBulkReadAndMarkReset() throws Exception {
        StrBuilder sb = new StrBuilder("abcdef");
        Reader reader = sb.asReader();
        char[] buf = new char[3];
        int n = reader.read(buf, 0, 3);
        assertEquals(3, n);
        assertEquals("abc", new String(buf));
        assertTrue(reader.markSupported());
        reader.mark(10);
        reader.read();
        reader.reset();
        assertEquals('d', reader.read());
    }

    @Test
    public void testAsWriter() throws Exception {
        StrBuilder sb = new StrBuilder();
        Writer writer = sb.asWriter();
        writer.write("hello");
        writer.write(' ');
        writer.write(new char[] {'w', 'o', 'r', 'l', 'd'});
        assertEquals("hello world", sb.toString());
        writer.close();
    }

    @Test
    public void testEqualsIgnoreCase() {
        StrBuilder sb1 = new StrBuilder("Hello");
        StrBuilder sb2 = new StrBuilder("HELLO");
        assertTrue(sb1.equalsIgnoreCase(sb2));
        StrBuilder sb3 = new StrBuilder("World");
        assertFalse(sb1.equalsIgnoreCase(sb3));
        assertTrue(sb1.equalsIgnoreCase(sb1));
        try {
            sb1.equalsIgnoreCase(null);
            fail("expected exception");
        } catch (NullPointerException e) {
            // expected: equalsIgnoreCase(StrBuilder) does not null-check its argument
        }
    }

    @Test
    public void testEqualsStrBuilder() {
        StrBuilder sb1 = new StrBuilder("abc");
        StrBuilder sb2 = new StrBuilder("abc");
        assertTrue(sb1.equals(sb2));
        StrBuilder sb3 = new StrBuilder("ABC");
        assertFalse(sb1.equals(sb3));
        try {
            sb1.equals((StrBuilder) null);
            fail("expected exception");
        } catch (NullPointerException e) {
            // expected: equals(StrBuilder) does not null-check its argument
        }
    }

    @Test
    public void testEqualsObject() {
        StrBuilder sb1 = new StrBuilder("abc");
        assertTrue(sb1.equals((Object) new StrBuilder("abc")));
        assertFalse(sb1.equals((Object) "abc"));
        assertFalse(sb1.equals((Object) null));
    }

    @Test
    public void testHashCodeConsistentWithEquals() {
        StrBuilder sb1 = new StrBuilder("abc");
        StrBuilder sb2 = new StrBuilder("abc");
        assertEquals(sb1.hashCode(), sb2.hashCode());
    }

    @Test
    public void testToStringIndependentOfBuilder() {
        StrBuilder sb = new StrBuilder("abc");
        String s = sb.toString();
        sb.append("def");
        assertEquals("abc", s);
        assertEquals("abcdef", sb.toString());
    }

    @Test
    public void testToStringBuffer() {
        StrBuilder sb = new StrBuilder("abc");
        StringBuffer buf = sb.toStringBuffer();
        assertEquals("abc", buf.toString());
    }
}
