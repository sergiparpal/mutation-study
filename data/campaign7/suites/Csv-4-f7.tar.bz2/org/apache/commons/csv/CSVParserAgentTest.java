/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.csv;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.StringReader;
import java.io.Writer;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.junit.Test;

public class CSVParserAgentTest {

    private File writeFile(String content) throws IOException {
        File file = File.createTempFile("CSVParserAgentTest", ".csv");
        file.deleteOnExit();
        Writer writer = new OutputStreamWriter(new FileOutputStream(file), Charset.forName("UTF-8"));
        try {
            writer.write(content);
        } finally {
            writer.close();
        }
        return file;
    }

    // --- constructor / factory null checks ---

    @Test
    public void testConstructorNullReader() throws Exception {
        try {
            new CSVParser(null, CSVFormat.DEFAULT);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testConstructorNullFormat() throws Exception {
        try {
            new CSVParser(new StringReader("a,b"), null);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testParseStringNullString() throws Exception {
        try {
            CSVParser.parse((String) null, CSVFormat.DEFAULT);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testParseStringNullFormat() throws Exception {
        try {
            CSVParser.parse("a,b", null);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testParseFileNullFile() throws Exception {
        try {
            CSVParser.parse((File) null, CSVFormat.DEFAULT);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testParseUrlNullCharset() throws Exception {
        try {
            CSVParser.parse(new URL("file:///nonexistent"), null, CSVFormat.DEFAULT);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testParseFileNotFound() throws Exception {
        File missing = new File("this-file-does-not-exist-csv-parser-agent-test.csv");
        assertFalse(missing.exists());
        try {
            CSVParser.parse(missing, CSVFormat.DEFAULT);
            fail("expected IOException");
        } catch (FileNotFoundException e) {
            // expected
        }
    }

    // --- basic parsing behaviour ---

    @Test
    public void testGetRecordsBasic() throws Exception {
        CSVParser parser = CSVParser.parse("a,b,c\n1,2,3\n", CSVFormat.DEFAULT);
        try {
            List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());

            CSVRecord r1 = records.get(0);
            assertEquals(3, r1.size());
            assertEquals("a", r1.get(0));
            assertEquals("b", r1.get(1));
            assertEquals("c", r1.get(2));
            assertEquals(1, r1.getRecordNumber());

            CSVRecord r2 = records.get(1);
            assertEquals("1", r2.get(0));
            assertEquals("2", r2.get(1));
            assertEquals("3", r2.get(2));
            assertEquals(2, r2.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testParseFileRoundTrip() throws Exception {
        File file = writeFile("x,y\n10,20\n");
        CSVParser parser = CSVParser.parse(file, CSVFormat.DEFAULT);
        try {
            List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("x", records.get(0).get(0));
            assertEquals("10", records.get(1).get(0));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testParseUrlRoundTrip() throws Exception {
        File file = writeFile("p,q\n5,6\n");
        CSVParser parser = CSVParser.parse(file.toURI().toURL(), Charset.forName("UTF-8"), CSVFormat.DEFAULT);
        try {
            List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("p", records.get(0).get(0));
            assertEquals("q", records.get(0).get(1));
            assertEquals("6", records.get(1).get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testEmptyInputYieldsNoRecords() throws Exception {
        CSVParser parser = CSVParser.parse("", CSVFormat.DEFAULT);
        try {
            List<CSVRecord> records = parser.getRecords();
            assertTrue(records.isEmpty());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetRecordsOnlyReturnsRemainingRecords() throws Exception {
        CSVParser parser = CSVParser.parse("a\nb\nc\n", CSVFormat.DEFAULT);
        try {
            CSVRecord first = parser.nextRecord();
            assertEquals("a", first.get(0));

            List<CSVRecord> rest = parser.getRecords();
            assertEquals(2, rest.size());
            assertEquals("b", rest.get(0).get(0));
            assertEquals("c", rest.get(1).get(0));
        } finally {
            parser.close();
        }
    }

    // --- line / record numbers ---

    @Test
    public void testGetCurrentLineNumber() throws Exception {
        CSVParser parser = CSVParser.parse("a\nb\nc\n", CSVFormat.DEFAULT);
        try {
            assertEquals(0, parser.getCurrentLineNumber());
            parser.nextRecord();
            assertEquals(1, parser.getCurrentLineNumber());
            parser.nextRecord();
            assertEquals(2, parser.getCurrentLineNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetRecordNumber() throws Exception {
        CSVParser parser = CSVParser.parse("a\nb\n", CSVFormat.DEFAULT);
        try {
            assertEquals(0, parser.getRecordNumber());
            parser.nextRecord();
            assertEquals(1, parser.getRecordNumber());
            parser.nextRecord();
            assertEquals(2, parser.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    // --- header handling ---

    @Test
    public void testHeaderAutoDetected() throws Exception {
        CSVParser parser = CSVParser.parse("a,b,c\n1,2,3\n", CSVFormat.DEFAULT.withHeader());
        try {
            Map<String, Integer> headerMap = parser.getHeaderMap();
            assertEquals(Integer.valueOf(0), headerMap.get("a"));
            assertEquals(Integer.valueOf(1), headerMap.get("b"));
            assertEquals(Integer.valueOf(2), headerMap.get("c"));

            List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("1", records.get(0).get("a"));
            assertEquals("2", records.get(0).get("b"));
            assertEquals("3", records.get(0).get("c"));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testHeaderExplicitWithSkip() throws Exception {
        CSVParser parser = CSVParser.parse("ignored,header,line\n1,2,3\n",
                CSVFormat.DEFAULT.withHeader("x", "y", "z").withSkipHeaderRecord(true));
        try {
            Map<String, Integer> headerMap = parser.getHeaderMap();
            assertEquals(Integer.valueOf(0), headerMap.get("x"));
            assertEquals(Integer.valueOf(2), headerMap.get("z"));

            List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("1", records.get(0).get("x"));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testHeaderExplicitWithoutSkip() throws Exception {
        CSVParser parser = CSVParser.parse("1,2,3\n",
                CSVFormat.DEFAULT.withHeader("x", "y", "z").withSkipHeaderRecord(false));
        try {
            List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("1", records.get(0).get("x"));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testNoHeaderMapWhenFormatHasNoHeader() throws Exception {
        CSVParser parser = CSVParser.parse("a,b\n", CSVFormat.DEFAULT);
        try {
            Map<String, Integer> headerMap = parser.getHeaderMap();
            assertTrue(headerMap.isEmpty());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetHeaderMapIsACopy() throws Exception {
        CSVParser parser = CSVParser.parse("a,b\n1,2\n", CSVFormat.DEFAULT.withHeader());
        try {
            Map<String, Integer> headerMap = parser.getHeaderMap();
            headerMap.put("z", Integer.valueOf(99));
            Map<String, Integer> headerMapAgain = parser.getHeaderMap();
            assertFalse(headerMapAgain.containsKey("z"));
        } finally {
            parser.close();
        }
    }

    // --- quoting / escaping / null string / comments ---

    @Test
    public void testQuotedValueWithEmbeddedDelimiter() throws Exception {
        CSVParser parser = CSVParser.parse("a,\"b,c\",d\n", CSVFormat.DEFAULT);
        try {
            List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            CSVRecord record = records.get(0);
            assertEquals(3, record.size());
            assertEquals("b,c", record.get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testNullStringConversion() throws Exception {
        CSVParser parser = CSVParser.parse("a,NULL,c\n", CSVFormat.DEFAULT.withNullString("NULL"));
        try {
            List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertNull(records.get(0).get(1));
            assertEquals("a", records.get(0).get(0));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testCommentsAreAttachedToFollowingRecord() throws Exception {
        CSVParser parser = CSVParser.parse("# a comment\na,b\n", CSVFormat.DEFAULT.withCommentStart('#'));
        try {
            List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("a comment", records.get(0).getComment());
            assertEquals("a", records.get(0).get(0));
        } finally {
            parser.close();
        }
    }

    // --- iterator behaviour ---

    @Test
    public void testIteratorBasic() throws Exception {
        CSVParser parser = CSVParser.parse("1\n2\n3\n", CSVFormat.DEFAULT);
        try {
            Iterator<CSVRecord> it = parser.iterator();
            int count = 0;
            String last = null;
            while (it.hasNext()) {
                CSVRecord record = it.next();
                last = record.get(0);
                count++;
            }
            assertEquals(3, count);
            assertEquals("3", last);
        } finally {
            parser.close();
        }
    }

    @Test
    public void testIteratorNextWithoutHasNext() throws Exception {
        CSVParser parser = CSVParser.parse("1\n2\n", CSVFormat.DEFAULT);
        try {
            Iterator<CSVRecord> it = parser.iterator();
            assertEquals("1", it.next().get(0));
            assertEquals("2", it.next().get(0));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testIteratorNextThrowsAtEnd() throws Exception {
        CSVParser parser = CSVParser.parse("1\n", CSVFormat.DEFAULT);
        try {
            Iterator<CSVRecord> it = parser.iterator();
            assertTrue(it.hasNext());
            it.next();
            assertFalse(it.hasNext());
            try {
                it.next();
                fail("expected NoSuchElementException");
            } catch (NoSuchElementException e) {
                // expected
            }
        } finally {
            parser.close();
        }
    }

    @Test
    public void testIteratorRemoveUnsupported() throws Exception {
        CSVParser parser = CSVParser.parse("1\n", CSVFormat.DEFAULT);
        try {
            Iterator<CSVRecord> it = parser.iterator();
            try {
                it.remove();
                fail("expected UnsupportedOperationException");
            } catch (UnsupportedOperationException e) {
                // expected
            }
        } finally {
            parser.close();
        }
    }

    @Test
    public void testIteratorHasNextIsIdempotent() throws Exception {
        CSVParser parser = CSVParser.parse("1\n2\n", CSVFormat.DEFAULT);
        try {
            Iterator<CSVRecord> it = parser.iterator();
            assertTrue(it.hasNext());
            assertTrue(it.hasNext());
            assertEquals("1", it.next().get(0));
        } finally {
            parser.close();
        }
    }

    // --- close() / isClosed() ---

    @Test
    public void testIsClosedInitiallyFalse() throws Exception {
        CSVParser parser = CSVParser.parse("a\n", CSVFormat.DEFAULT);
        try {
            assertFalse(parser.isClosed());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testCloseSetsClosed() throws Exception {
        CSVParser parser = CSVParser.parse("a\n", CSVFormat.DEFAULT);
        parser.close();
        assertTrue(parser.isClosed());
    }

    @Test
    public void testIteratorHasNextFalseAfterClose() throws Exception {
        CSVParser parser = CSVParser.parse("a\nb\n", CSVFormat.DEFAULT);
        Iterator<CSVRecord> it = parser.iterator();
        parser.close();
        assertFalse(it.hasNext());
    }

    @Test
    public void testIteratorNextThrowsAfterClose() throws Exception {
        CSVParser parser = CSVParser.parse("a\nb\n", CSVFormat.DEFAULT);
        Iterator<CSVRecord> it = parser.iterator();
        parser.close();
        try {
            it.next();
            fail("expected NoSuchElementException");
        } catch (NoSuchElementException e) {
            // expected
        }
    }

    // --- inconsistent row lengths ---

    @Test
    public void testInconsistentRecordWithHeaderIsFlagged() throws Exception {
        CSVParser parser = CSVParser.parse("a,b,c\n1,2\n", CSVFormat.DEFAULT.withHeader());
        try {
            List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertFalse(records.get(0).isConsistent());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testTrailingEmptyLineIsIgnoredByDefault() throws Exception {
        CSVParser parser = CSVParser.parse("a,b\n\n", CSVFormat.DEFAULT);
        try {
            List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
        } finally {
            parser.close();
        }
    }
}
