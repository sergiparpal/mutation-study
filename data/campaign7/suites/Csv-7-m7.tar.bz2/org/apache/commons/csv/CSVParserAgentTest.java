/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.csv;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.junit.Test;

public class CSVParserAgentTest {

    @Test
    public void testConstructorRejectsNullReader() throws IOException {
        try {
            new CSVParser(null, CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            assertTrue(e.getMessage().contains("reader"));
        }
    }

    @Test
    public void testConstructorRejectsNullFormat() throws IOException {
        try {
            new CSVParser(new StringReader("a,b"), null);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            assertTrue(e.getMessage().contains("format"));
        }
    }

    @Test
    public void testParseStringRejectsNullArgs() throws IOException {
        try {
            CSVParser.parse((String) null, CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            assertTrue(e.getMessage().contains("string"));
        }
        try {
            CSVParser.parse("a,b", null);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            assertTrue(e.getMessage().contains("format"));
        }
    }

    @Test
    public void testParseFileRejectsNullArgs() throws IOException {
        try {
            CSVParser.parse((File) null, CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            assertTrue(e.getMessage().contains("file"));
        }
    }

    @Test
    public void testParseUrlRejectsNullArgs() throws IOException {
        try {
            CSVParser.parse((URL) null, Charset.forName("UTF-8"), CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            assertTrue(e.getMessage().contains("url"));
        }
    }

    @Test
    public void testSimpleParse() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b,c\n1,2,3\n", CSVFormat.DEFAULT);
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());

        final CSVRecord first = records.get(0);
        assertEquals(3, first.size());
        assertEquals("a", first.get(0));
        assertEquals("b", first.get(1));
        assertEquals("c", first.get(2));
        assertEquals(1, first.getRecordNumber());

        final CSVRecord second = records.get(1);
        assertEquals("1", second.get(0));
        assertEquals("2", second.get(1));
        assertEquals("3", second.get(2));
        assertEquals(2, second.getRecordNumber());

        assertEquals(2, parser.getRecordNumber());
        parser.close();
    }

    @Test
    public void testEmptyInputProducesNoRecords() throws IOException {
        final CSVParser parser = CSVParser.parse("", CSVFormat.DEFAULT);
        final List<CSVRecord> records = parser.getRecords();
        assertTrue(records.isEmpty());
        assertEquals(0, parser.getRecordNumber());
        parser.close();
    }

    @Test
    public void testGetRecordsIntoExistingCollection() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\nc,d\n", CSVFormat.DEFAULT);
        final List<CSVRecord> target = new java.util.ArrayList<CSVRecord>();
        target.add(null);
        final List<CSVRecord> result = parser.getRecords(target);
        assertTrue(result == target);
        assertEquals(3, result.size());
        parser.close();
    }

    @Test
    public void testHeaderMapWithExplicitHeader() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("X", "Y", "Z");
        final CSVParser parser = CSVParser.parse("1,2,3\n4,5,6\n", format);
        final Map<String, Integer> headerMap = parser.getHeaderMap();
        assertEquals(Integer.valueOf(0), headerMap.get("X"));
        assertEquals(Integer.valueOf(1), headerMap.get("Y"));
        assertEquals(Integer.valueOf(2), headerMap.get("Z"));

        final List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        assertEquals("1", records.get(0).get("X"));
        assertEquals("6", records.get(1).get("Z"));
        parser.close();
    }

    @Test
    public void testHeaderMapAutoDetectedFromFirstLine() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader();
        final CSVParser parser = CSVParser.parse("a,b,c\n1,2,3\n", format);
        final Map<String, Integer> headerMap = parser.getHeaderMap();
        assertEquals(Integer.valueOf(0), headerMap.get("a"));
        assertEquals(Integer.valueOf(1), headerMap.get("b"));
        assertEquals(Integer.valueOf(2), headerMap.get("c"));

        final List<CSVRecord> records = parser.getRecords();
        assertEquals(1, records.size());
        assertEquals("1", records.get(0).get("a"));
        parser.close();
    }

    @Test
    public void testHeaderMapNullWhenNoHeaderConfigured() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n", CSVFormat.DEFAULT);
        assertNull(parser.getHeaderMap());
        parser.close();
    }

    @Test
    public void testDuplicateHeaderNamesThrow() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("A", "B", "A");
        try {
            CSVParser.parse("1,2,3\n", format);
            fail("Expected IllegalStateException due to duplicate header names");
        } catch (final IllegalStateException e) {
            assertTrue(e.getMessage().contains("duplicate"));
        }
    }

    @Test
    public void testNullStringConversion() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withNullString("NULL");
        final CSVParser parser = CSVParser.parse("a,NULL,c\n", format);
        final CSVRecord record = parser.getRecords().get(0);
        assertEquals("a", record.get(0));
        assertNull(record.get(1));
        assertEquals("c", record.get(2));
        parser.close();
    }

    @Test
    public void testGetCurrentLineNumber() throws IOException {
        final CSVParser parser = CSVParser.parse("a\nb\nc\n", CSVFormat.DEFAULT);
        assertEquals(0, parser.getCurrentLineNumber());
        parser.nextRecord();
        assertEquals(1, parser.getCurrentLineNumber());
        parser.nextRecord();
        assertEquals(2, parser.getCurrentLineNumber());
        parser.close();
    }

    @Test
    public void testIteratorHasNextAndNext() throws IOException {
        final CSVParser parser = CSVParser.parse("1,2\n3,4\n", CSVFormat.DEFAULT);
        final Iterator<CSVRecord> iterator = parser.iterator();
        assertTrue(iterator.hasNext());
        assertTrue(iterator.hasNext());
        final CSVRecord first = iterator.next();
        assertEquals("1", first.get(0));
        assertTrue(iterator.hasNext());
        final CSVRecord second = iterator.next();
        assertEquals("3", second.get(0));
        assertFalse(iterator.hasNext());
        parser.close();
    }

    @Test
    public void testIteratorNextWithoutHasNextCallsThrough() throws IOException {
        final CSVParser parser = CSVParser.parse("1,2\n", CSVFormat.DEFAULT);
        final Iterator<CSVRecord> iterator = parser.iterator();
        final CSVRecord first = iterator.next();
        assertEquals("1", first.get(0));
        try {
            iterator.next();
            fail("Expected NoSuchElementException");
        } catch (final NoSuchElementException e) {
            assertTrue(e.getMessage().contains("No more CSV records"));
        }
        parser.close();
    }

    @Test
    public void testIteratorRemoveUnsupported() throws IOException {
        final CSVParser parser = CSVParser.parse("1,2\n", CSVFormat.DEFAULT);
        final Iterator<CSVRecord> iterator = parser.iterator();
        try {
            iterator.remove();
            fail("Expected UnsupportedOperationException");
        } catch (final UnsupportedOperationException e) {
            // expected
        }
        parser.close();
    }

    @Test
    public void testIteratorAfterCloseHasNoNext() throws IOException {
        final CSVParser parser = CSVParser.parse("1,2\n3,4\n", CSVFormat.DEFAULT);
        final Iterator<CSVRecord> iterator = parser.iterator();
        parser.close();
        assertTrue(parser.isClosed());
        assertFalse(iterator.hasNext());
        try {
            iterator.next();
            fail("Expected NoSuchElementException because parser is closed");
        } catch (final NoSuchElementException e) {
            assertTrue(e.getMessage().contains("closed"));
        }
    }

    @Test
    public void testIsClosed() throws IOException {
        final CSVParser parser = CSVParser.parse("a\n", CSVFormat.DEFAULT);
        assertFalse(parser.isClosed());
        parser.close();
        assertTrue(parser.isClosed());
    }

    @Test
    public void testCommentsAreAttachedToFollowingRecord() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withCommentStart('#');
        final CSVParser parser = CSVParser.parse("# comment line\na,b\n", format);
        final CSVRecord record = parser.nextRecord();
        assertEquals("comment line", record.getComment());
        assertEquals("a", record.get(0));
        assertEquals("b", record.get(1));
        parser.close();
    }

    @Test
    public void testInvalidTokenThrowsIOException() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withQuoteChar('"');
        final CSVParser parser = CSVParser.parse("\"a\"b,c\n", format);
        try {
            parser.nextRecord();
            fail("Expected IOException for invalid parse sequence");
        } catch (final IOException e) {
            assertTrue(e.getMessage().toLowerCase().contains("invalid"));
        }
        parser.close();
    }

    @Test
    public void testNextRecordReturnsNullAtEndOfStream() throws IOException {
        final CSVParser parser = CSVParser.parse("a\n", CSVFormat.DEFAULT);
        final CSVRecord record = parser.nextRecord();
        assertEquals("a", record.get(0));
        assertNull(parser.nextRecord());
        parser.close();
    }

    @Test
    public void testParseFromFile() throws IOException {
        final File tempFile = File.createTempFile("CSVParserAgentTest", ".csv");
        tempFile.deleteOnExit();
        final java.io.FileWriter writer = new java.io.FileWriter(tempFile);
        writer.write("x,y\n1,2\n");
        writer.close();

        final CSVParser parser = CSVParser.parse(tempFile, CSVFormat.DEFAULT);
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        assertEquals("1", records.get(1).get(0));
        parser.close();
        tempFile.delete();
    }

    @Test
    public void testCloseIsIdempotent() throws IOException {
        final CSVParser parser = CSVParser.parse("a\n", CSVFormat.DEFAULT);
        parser.close();
        parser.close();
        assertTrue(parser.isClosed());
    }
}
