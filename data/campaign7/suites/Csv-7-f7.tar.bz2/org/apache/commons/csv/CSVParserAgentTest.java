/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.csv;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringReader;
import java.io.Writer;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.junit.Test;

public class CSVParserAgentTest {

    private static File writeFile(final String content) throws IOException {
        final File file = File.createTempFile("CSVParserAgentTest", ".csv");
        final Writer writer = new FileWriter(file);
        try {
            writer.write(content);
        } finally {
            writer.close();
        }
        return file;
    }

    // --- static factory null-argument checks ---

    @Test
    public void testParseStringNullStringThrows() throws IOException {
        try {
            CSVParser.parse((String) null, CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testParseStringNullFormatThrows() throws IOException {
        try {
            CSVParser.parse("a,b", null);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testParseFileNullFileThrows() throws IOException {
        try {
            CSVParser.parse((File) null, CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testParseFileNullFormatThrows() throws IOException {
        final File file = writeFile("a,b\n");
        try {
            CSVParser.parse(file, null);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        } finally {
            file.delete();
        }
    }

    @Test
    public void testParseUrlNullUrlThrows() throws IOException {
        try {
            CSVParser.parse((URL) null, Charset.forName("UTF-8"), CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testParseUrlNullCharsetThrows() throws IOException {
        final File file = writeFile("a,b\n");
        try {
            CSVParser.parse(file.toURI().toURL(), null, CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        } finally {
            file.delete();
        }
    }

    @Test
    public void testParseUrlNullFormatThrows() throws IOException {
        final File file = writeFile("a,b\n");
        try {
            CSVParser.parse(file.toURI().toURL(), Charset.forName("UTF-8"), null);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        } finally {
            file.delete();
        }
    }

    @Test
    public void testConstructorNullReaderThrows() throws IOException {
        try {
            new CSVParser(null, CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testConstructorNullFormatThrows() throws IOException {
        try {
            new CSVParser(new StringReader("a,b"), null);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testConstructorInconsistentFormatThrows() throws IOException {
        // quoteChar == delimiter is an inconsistent format and must be rejected by validate()
        final CSVFormat broken = CSVFormat.DEFAULT.withQuoteChar(',');
        try {
            new CSVParser(new StringReader("a,b"), broken);
            fail("Expected IllegalStateException");
        } catch (final IllegalStateException e) {
            // expected
        }
    }

    // --- basic parsing ---

    @Test
    public void testParseStringHappyPath() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b,c\r\n1,2,3\r\n", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            final CSVRecord first = records.get(0);
            assertEquals(3, first.size());
            assertEquals("a", first.get(0));
            assertEquals("b", first.get(1));
            assertEquals("c", first.get(2));
            final CSVRecord second = records.get(1);
            assertEquals("1", second.get(0));
            assertEquals("2", second.get(1));
            assertEquals("3", second.get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testParseFileHappyPath() throws IOException {
        final File file = writeFile("x,y\r\n1,2\r\n");
        try {
            final CSVParser parser = CSVParser.parse(file, CSVFormat.DEFAULT);
            try {
                final List<CSVRecord> records = parser.getRecords();
                assertEquals(2, records.size());
                assertEquals("x", records.get(0).get(0));
                assertEquals("2", records.get(1).get(1));
            } finally {
                parser.close();
            }
        } finally {
            file.delete();
        }
    }

    @Test
    public void testParseUrlHappyPath() throws IOException {
        final File file = writeFile("u,v\r\n5,6\r\n");
        try {
            final CSVParser parser = CSVParser.parse(file.toURI().toURL(), Charset.forName("UTF-8"),
                    CSVFormat.DEFAULT);
            try {
                final List<CSVRecord> records = parser.getRecords();
                assertEquals(2, records.size());
                assertEquals("5", records.get(1).get(0));
                assertEquals("6", records.get(1).get(1));
            } finally {
                parser.close();
            }
        } finally {
            file.delete();
        }
    }

    @Test
    public void testGetRecordsReturnedCollectionIsSameInstance() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a,b\nc,d\n"), CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> target = new ArrayList<CSVRecord>();
            final List<CSVRecord> result = parser.getRecords(target);
            assertSame(target, result);
            assertEquals(2, result.size());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetRecordsEmptyInputReturnsEmptyList() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader(""), CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertTrue(records.isEmpty());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testNoTrailingNewlineStillYieldsLastRecord() throws IOException {
        // EOF reached with pending content must still produce a final record.
        final CSVParser parser = new CSVParser(new StringReader("a,b,c"), CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("b", records.get(0).get(1));
            assertEquals("c", records.get(0).get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testTrailingDelimiterProducesEmptyLastField() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a,b,\n"), CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            final CSVRecord record = records.get(0);
            assertEquals(3, record.size());
            assertEquals("a", record.get(0));
            assertEquals("b", record.get(1));
            assertEquals("", record.get(2));
        } finally {
            parser.close();
        }
    }

    // --- quoting / escaping ---

    @Test
    public void testQuotedValueWithEmbeddedDelimiterAndDoubledQuote() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("\"a,b\",\"c\"\"d\"\n"), CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            final CSVRecord record = records.get(0);
            assertEquals("a,b", record.get(0));
            assertEquals("c\"d", record.get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testEncapsulatedTokenUnterminatedThrowsIOException() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("\"a,b"), CSVFormat.DEFAULT);
        try {
            parser.getRecords();
            fail("Expected IOException for an unterminated quoted value");
        } catch (final IOException e) {
            // expected
        } finally {
            parser.close();
        }
    }

    @Test
    public void testEscapedDelimiterInMySqlFormat() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a\\\tb\tc\n"), CSVFormat.MYSQL);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            final CSVRecord record = records.get(0);
            assertEquals(2, record.size());
            assertEquals("a\tb", record.get(0));
            assertEquals("c", record.get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testInvalidCharBetweenEncapsulatedTokenAndDelimiterThrows() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("\"a\"b,c\n"), CSVFormat.DEFAULT);
        try {
            parser.getRecords();
            fail("Expected IOException for an invalid char between encapsulated token and delimiter");
        } catch (final IOException e) {
            // expected
        } finally {
            parser.close();
        }
    }

    @Test
    public void testQuotedValueSpanningMultipleLines() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("\"line1\nline2\",b\n"), CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("line1\nline2", records.get(0).get(0));
            assertEquals("b", records.get(0).get(1));
            assertEquals(1, records.get(0).getRecordNumber());
        } finally {
            parser.close();
        }
    }

    // --- null string handling ---

    @Test
    public void testNullStringConversion() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withNullString("NULL");
        final CSVParser parser = new CSVParser(new StringReader("a,NULL,c\n"), format);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            final CSVRecord record = records.get(0);
            assertEquals("a", record.get(0));
            assertNull(record.get(1));
            assertEquals("c", record.get(2));
        } finally {
            parser.close();
        }
    }

    // --- empty line handling ---

    @Test
    public void testIgnoreEmptyLinesDefault() throws IOException {
        // CSVFormat.DEFAULT has getIgnoreEmptyLines() == true
        final CSVParser parser = new CSVParser(new StringReader("a,b\n\nc,d\n"), CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("c", records.get(1).get(0));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testEmptyLinesNotIgnoredWhenDisabled() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withIgnoreEmptyLines(false);
        final CSVParser parser = new CSVParser(new StringReader("a,b\n\nc,d\n"), format);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(3, records.size());
            assertEquals(1, records.get(1).size());
            assertEquals("", records.get(1).get(0));
        } finally {
            parser.close();
        }
    }

    // --- comments ---

    @Test
    public void testCommentAttachedToFollowingRecord() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withCommentStart('#');
        final CSVParser parser = new CSVParser(new StringReader("# a comment\na,b\n"), format);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            final CSVRecord record = records.get(0);
            assertEquals("a comment", record.getComment());
            assertEquals("a", record.get(0));
            assertEquals("b", record.get(1));
        } finally {
            parser.close();
        }
    }

    // --- header handling ---

    @Test
    public void testHeaderMapIsNullWithoutHeaderFormat() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a,b\n1,2\n"), CSVFormat.DEFAULT);
        try {
            assertNull(parser.getHeaderMap());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testHeaderMapAutoDetectedFromFirstRecord() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader();
        final CSVParser parser = new CSVParser(new StringReader("name,amount\nfoo,1\nbar,2\n"), format);
        try {
            final Map<String, Integer> headerMap = parser.getHeaderMap();
            assertEquals(Integer.valueOf(0), headerMap.get("name"));
            assertEquals(Integer.valueOf(1), headerMap.get("amount"));

            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("foo", records.get(0).get("name"));
            assertEquals("1", records.get(0).get("amount"));
            assertEquals("bar", records.get(1).get("name"));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testHeaderMapExplicitWithSkipHeaderRecord() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("name", "amount").withSkipHeaderRecord(true);
        final CSVParser parser = new CSVParser(new StringReader("name,amount\nfoo,1\n"), format);
        try {
            final Map<String, Integer> headerMap = parser.getHeaderMap();
            assertEquals(Integer.valueOf(0), headerMap.get("name"));
            assertEquals(Integer.valueOf(1), headerMap.get("amount"));

            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("foo", records.get(0).get("name"));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testHeaderMapExplicitWithoutSkipHeaderRecordKeepsFirstRow() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("name", "amount");
        final CSVParser parser = new CSVParser(new StringReader("foo,1\nbar,2\n"), format);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("foo", records.get(0).get("name"));
            assertEquals("bar", records.get(1).get("name"));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetHeaderMapReturnsIndependentCopy() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("a", "b");
        final CSVParser parser = new CSVParser(new StringReader("1,2\n"), format);
        try {
            final Map<String, Integer> firstCopy = parser.getHeaderMap();
            firstCopy.put("injected", Integer.valueOf(99));
            final Map<String, Integer> secondCopy = parser.getHeaderMap();
            assertFalse(secondCopy.containsKey("injected"));
            assertEquals(2, secondCopy.size());
        } finally {
            parser.close();
        }
    }

    // --- record/line numbering ---

    @Test
    public void testGetRecordNumberIncrementsPerRecord() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a\nb\nc\n"), CSVFormat.DEFAULT);
        try {
            assertEquals(0, parser.getRecordNumber());
            final CSVRecord r1 = parser.nextRecord();
            assertEquals(1, r1.getRecordNumber());
            assertEquals(1, parser.getRecordNumber());
            final CSVRecord r2 = parser.nextRecord();
            assertEquals(2, r2.getRecordNumber());
            final CSVRecord r3 = parser.nextRecord();
            assertEquals(3, r3.getRecordNumber());
            assertNull(parser.nextRecord());
            assertEquals(3, parser.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetCurrentLineNumber() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a\nb\nc\n"), CSVFormat.DEFAULT);
        try {
            assertEquals(0, parser.getCurrentLineNumber());
            parser.nextRecord();
            assertEquals(1, parser.getCurrentLineNumber());
            parser.nextRecord();
            assertEquals(2, parser.getCurrentLineNumber());
        } finally {
            parser.close();
        }
    }

    // --- close / isClosed ---

    @Test
    public void testIsClosedInitiallyFalseThenTrueAfterClose() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a,b\n"), CSVFormat.DEFAULT);
        assertFalse(parser.isClosed());
        parser.close();
        assertTrue(parser.isClosed());
    }

    @Test
    public void testIteratorHasNextFalseAfterClose() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a,b\nc,d\n"), CSVFormat.DEFAULT);
        parser.close();
        final Iterator<CSVRecord> it = parser.iterator();
        assertFalse(it.hasNext());
    }

    @Test
    public void testIteratorNextThrowsAfterClose() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a,b\nc,d\n"), CSVFormat.DEFAULT);
        parser.close();
        final Iterator<CSVRecord> it = parser.iterator();
        try {
            it.next();
            fail("Expected NoSuchElementException");
        } catch (final NoSuchElementException e) {
            // expected
        }
    }

    // --- iterator semantics ---

    @Test
    public void testIteratorFullTraversalThenExhausted() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a\nb\n"), CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            assertTrue(it.hasNext());
            assertEquals("a", it.next().get(0));
            assertTrue(it.hasNext());
            assertEquals("b", it.next().get(0));
            assertFalse(it.hasNext());
            try {
                it.next();
                fail("Expected NoSuchElementException");
            } catch (final NoSuchElementException e) {
                // expected
            }
        } finally {
            parser.close();
        }
    }

    @Test
    public void testIteratorNextWithoutCallingHasNextFirst() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("only\n"), CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            final CSVRecord record = it.next();
            assertEquals("only", record.get(0));
            assertFalse(it.hasNext());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testIteratorRemoveUnsupported() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a\n"), CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            try {
                it.remove();
                fail("Expected UnsupportedOperationException");
            } catch (final UnsupportedOperationException e) {
                // expected
            }
        } finally {
            parser.close();
        }
    }

    @Test
    public void testForEachLoopOverParser() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("1,2\n3,4\n"), CSVFormat.DEFAULT);
        try {
            int count = 0;
            int sumFirstColumn = 0;
            for (final CSVRecord record : parser) {
                count++;
                sumFirstColumn += Integer.parseInt(record.get(0));
            }
            assertEquals(2, count);
            assertEquals(4, sumFirstColumn);
        } finally {
            parser.close();
        }
    }

    // --- nextRecord() directly ---

    @Test
    public void testNextRecordReturnsNullAtEndOfStream() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a\n"), CSVFormat.DEFAULT);
        try {
            final CSVRecord record = parser.nextRecord();
            assertEquals("a", record.get(0));
            assertNull(parser.nextRecord());
        } finally {
            parser.close();
        }
    }
}
