/*
 * Copyright (C) 2024 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.gson.stream;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.io.StringWriter;
import org.junit.Test;

public class JsonWriterAgentTest {

  @Test
  public void testConstructorRejectsNullWriter() {
    try {
      new JsonWriter(null);
      fail();
    } catch (NullPointerException expected) {
    }
  }

  @Test
  public void testEmptyArray() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.endArray();
    assertEquals("[]", stringWriter.toString());
  }

  @Test
  public void testEmptyObject() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginObject();
    writer.endObject();
    assertEquals("{}", stringWriter.toString());
  }

  @Test
  public void testObjectWithValues() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginObject();
    writer.name("a").value(1);
    writer.name("b").value(true);
    writer.name("c").value("text");
    writer.name("d").nullValue();
    writer.endObject();
    assertEquals("{\"a\":1,\"b\":true,\"c\":\"text\",\"d\":null}", stringWriter.toString());
  }

  @Test
  public void testNestedArrayAndObject() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.beginObject();
    writer.name("x").value(1L);
    writer.endObject();
    writer.beginArray();
    writer.value(1.5);
    writer.endArray();
    writer.endArray();
    assertEquals("[{\"x\":1},[1.5]]", stringWriter.toString());
  }

  @Test
  public void testMethodsReturnThis() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    assertSame(writer, writer.beginArray());
    assertSame(writer, writer.value(1));
    assertSame(writer, writer.endArray());
  }

  @Test
  public void testNameWithoutValueThrowsOnClose() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginObject();
    writer.name("a");
    try {
      writer.endObject();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  @Test
  public void testNullNameThrows() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginObject();
    try {
      writer.name(null);
      fail();
    } catch (NullPointerException expected) {
    }
  }

  @Test
  public void testTwoNamesInARowThrows() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginObject();
    writer.name("a");
    try {
      writer.name("b");
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  @Test
  public void testValueWithoutNameInObjectThrows() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginObject();
    try {
      writer.value("x");
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  @Test
  public void testMultipleTopLevelValuesStrictThrows() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.endArray();
    try {
      writer.beginArray();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  @Test
  public void testMultipleTopLevelValuesLenientAllowed() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setLenient(true);
    assertTrue(writer.isLenient());
    writer.value(1);
    writer.value(2);
    assertEquals("12", stringWriter.toString());
  }

  @Test
  public void testFirstTopLevelValueAllowedEvenWhenStrict() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.value(1);
    assertEquals("1", stringWriter.toString());
  }

  @Test
  public void testTopLevelValueLenientAllowed() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setLenient(true);
    writer.value(5);
    assertEquals("5", stringWriter.toString());
  }

  @Test
  public void testClosingIncompleteDocumentThrows() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    try {
      writer.close();
      fail();
    } catch (IOException expected) {
    }
  }

  @Test
  public void testClosingEmptyDocumentThrows() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    try {
      writer.close();
      fail();
    } catch (IOException expected) {
    }
  }

  @Test
  public void testOperationsAfterCloseThrow() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.endArray();
    writer.close();
    try {
      writer.beginArray();
      fail();
    } catch (IllegalStateException expected) {
    }
    try {
      writer.flush();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  @Test
  public void testMismatchedEndArrayThrows() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginObject();
    try {
      writer.endArray();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  @Test
  public void testMismatchedEndObjectThrows() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    try {
      writer.endObject();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  @Test
  public void testNanAndInfinityDoubleStrictThrows() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    try {
      writer.value(Double.NaN);
      fail();
    } catch (IllegalArgumentException expected) {
    }
    try {
      writer.value(Double.POSITIVE_INFINITY);
      fail();
    } catch (IllegalArgumentException expected) {
    }
    try {
      writer.value(Double.NEGATIVE_INFINITY);
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  @Test
  public void testNanAndInfinityDoubleLenientAllowed() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setLenient(true);
    writer.beginArray();
    writer.value(Double.NaN);
    writer.value(Double.POSITIVE_INFINITY);
    writer.value(Double.NEGATIVE_INFINITY);
    writer.endArray();
    assertEquals("[NaN,Infinity,-Infinity]", stringWriter.toString());
  }

  @Test
  public void testNanNumberStrictThrows() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    try {
      writer.value(Double.valueOf(Double.NaN));
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  @Test
  public void testNullNumberWritesNull() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.value((Number) null);
    writer.endArray();
    assertEquals("[null]", stringWriter.toString());
  }

  @Test
  public void testNullStringWritesNull() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.value((String) null);
    writer.endArray();
    assertEquals("[null]", stringWriter.toString());
  }

  @Test
  public void testNullBooleanWritesNull() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.value((Boolean) null);
    writer.endArray();
    assertEquals("[null]", stringWriter.toString());
  }

  @Test
  public void testSerializeNullsDefaultTrue() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    assertTrue(writer.getSerializeNulls());
  }

  @Test
  public void testSerializeNullsFalseSkipsNullMembers() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setSerializeNulls(false);
    assertFalse(writer.getSerializeNulls());
    writer.beginObject();
    writer.name("a").nullValue();
    writer.name("b").value(1);
    writer.endObject();
    assertEquals("{\"b\":1}", stringWriter.toString());
  }

  @Test
  public void testStringEscaping() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.value("a\"b\\c\td\be\nf\rg\fh");
    writer.endArray();
    assertEquals("[\"a\\\"b\\\\c\\td\\be\\nf\\rg\\fh\"]", stringWriter.toString());
  }

  @Test
  public void testControlCharacterEscaping() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.value("a\u0001b");
    writer.endArray();
    assertEquals("[\"a\\u0001b\"]", stringWriter.toString());
  }

  @Test
  public void testHtmlUnsafeCharactersNotEscapedByDefault() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    assertFalse(writer.isHtmlSafe());
    writer.beginArray();
    writer.value("<a>&'=");
    writer.endArray();
    assertEquals("[\"<a>&'=\"]", stringWriter.toString());
  }

  @Test
  public void testHtmlSafeEscaping() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setHtmlSafe(true);
    assertTrue(writer.isHtmlSafe());
    writer.beginArray();
    writer.value("<a>&'=");
    writer.endArray();
    assertEquals("[\"\\u003ca\\u003e\\u0026\\u0027\\u003d\"]", stringWriter.toString());
  }

  @Test
  public void testLineSeparatorEscaping() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.value("  ");
    writer.endArray();
    assertEquals("[\"\\u2028\\u2029\"]", stringWriter.toString());
  }

  @Test
  public void testJsonValueWrittenRaw() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.jsonValue("{\"raw\":true}");
    writer.endArray();
    assertEquals("[{\"raw\":true}]", stringWriter.toString());
  }

  @Test
  public void testJsonValueNullWritesNullLiteral() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.jsonValue(null);
    writer.endArray();
    assertEquals("[null]", stringWriter.toString());
  }

  @Test
  public void testIndentProducesPrettyPrinting() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setIndent("  ");
    writer.beginObject();
    writer.name("a").value(1);
    writer.endObject();
    assertEquals("{\n  \"a\": 1\n}", stringWriter.toString());
  }

  @Test
  public void testEmptyIndentDisablesPrettyPrinting() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setIndent("  ");
    writer.setIndent("");
    writer.beginObject();
    writer.name("a").value(1);
    writer.endObject();
    assertEquals("{\"a\":1}", stringWriter.toString());
  }

  @Test
  public void testLongValue() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.value(Long.MIN_VALUE);
    writer.value(Long.MAX_VALUE);
    writer.endArray();
    assertEquals("[-9223372036854775808,9223372036854775807]", stringWriter.toString());
  }

  @Test
  public void testDeepNestingExceedsInitialStackCapacity() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    int depth = 40;
    for (int i = 0; i < depth; i++) {
      writer.beginArray();
    }
    for (int i = 0; i < depth; i++) {
      writer.endArray();
    }
    StringBuilder expected = new StringBuilder();
    for (int i = 0; i < depth; i++) {
      expected.append('[');
    }
    for (int i = 0; i < depth; i++) {
      expected.append(']');
    }
    assertEquals(expected.toString(), stringWriter.toString());
  }

  @Test
  public void testFlushAfterClosedUnderlyingWriterStillFlushesStack() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.endArray();
    writer.flush();
    assertEquals("[]", stringWriter.toString());
  }
}
