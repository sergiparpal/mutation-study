/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.cli;

import java.util.List;
import java.util.Properties;
import java.util.Vector;

import junit.framework.TestCase;

/**
 * Self-contained tests for {@link Parser}, exercising the common parsing
 * logic (token loop, required-option tracking, option groups, properties
 * processing) through a minimal concrete subclass whose {@link
 * Parser#flatten} simply echoes its input, the same way {@link BasicParser}
 * does.
 */
public class ParserAgentTest extends TestCase
{
    /** Minimal concrete Parser: flatten() just echoes the arguments. */
    private static class IdentityParser extends Parser
    {
        protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption)
        {
            return arguments;
        }
    }

    /**
     * A Properties subclass that returns its property names in a fixed,
     * caller-specified order, so tests do not depend on Hashtable's
     * unspecified iteration order.
     */
    private static class OrderedProperties extends Properties
    {
        private final Vector order = new Vector();

        public Object setProperty(String key, String value)
        {
            order.add(key);
            return super.setProperty(key, value);
        }

        public java.util.Enumeration propertyNames()
        {
            return order.elements();
        }
    }

    private Parser parser;
    private Options options;

    public void setUp()
    {
        parser = new IdentityParser();
        options = new Options();
        options.addOption("a", "enable-a", false, "turn [a] on or off");
        options.addOption("b", "bfile", true, "set the value of [b]");
        options.addOption("c", "copt", false, "turn [c] on or off");
    }

    public void testSimpleParsing() throws Exception
    {
        String[] args = new String[] { "-a", "-b", "toast", "foo", "bar" };

        CommandLine cl = parser.parse(options, args);

        assertTrue("a should be set", cl.hasOption("a"));
        assertTrue("b should be set", cl.hasOption("b"));
        assertEquals("toast", cl.getOptionValue("b"));
        assertEquals(2, cl.getArgList().size());
        assertEquals("foo", cl.getArgList().get(0));
        assertEquals("bar", cl.getArgList().get(1));
    }

    public void testNullArgumentsTreatedAsEmpty() throws Exception
    {
        CommandLine cl = parser.parse(options, null);

        assertNotNull(cl);
        assertFalse(cl.hasOption("a"));
        assertEquals(0, cl.getArgList().size());
    }

    public void testEmptyArgumentArray() throws Exception
    {
        CommandLine cl = parser.parse(options, new String[0]);

        assertNotNull(cl);
        assertEquals(0, cl.getArgList().size());
        assertEquals(0, cl.getOptions().length);
    }

    public void testUnrecognizedOption()
    {
        String[] args = new String[] { "-a", "-z" };

        try
        {
            parser.parse(options, args);
            fail("UnrecognizedOptionException should have been thrown");
        }
        catch (UnrecognizedOptionException e)
        {
            assertEquals("-z", e.getOption());
        }
        catch (ParseException e)
        {
            fail("expected UnrecognizedOptionException, got " + e);
        }
    }

    public void testMissingArgument()
    {
        String[] args = new String[] { "-b" };

        try
        {
            parser.parse(options, args);
            fail("MissingArgumentException should have been thrown");
        }
        catch (MissingArgumentException e)
        {
            assertEquals("b", e.getOption().getOpt());
        }
        catch (ParseException e)
        {
            fail("expected MissingArgumentException, got " + e);
        }
    }

    public void testDoubleDashStopsOptionParsing() throws Exception
    {
        String[] args = new String[] { "-a", "--", "-b", "toast" };

        CommandLine cl = parser.parse(options, args);

        assertTrue("a should be set", cl.hasOption("a"));
        assertFalse("b should not be set, it is after --", cl.hasOption("b"));
        assertEquals(2, cl.getArgList().size());
        assertEquals("-b", cl.getArgList().get(0));
        assertEquals("toast", cl.getArgList().get(1));
    }

    public void testSingleDashIsTreatedAsArgument() throws Exception
    {
        String[] args = new String[] { "-a", "-" };

        CommandLine cl = parser.parse(options, args);

        assertTrue(cl.hasOption("a"));
        assertEquals(1, cl.getArgList().size());
        assertEquals("-", cl.getArgList().get(0));
    }

    /**
     * When stopAtNonOption is true, every other branch that stops parsing
     * (an unrecognized "-xxx" option, or a plain argument) adds the
     * triggering token itself to the arg list before eating the rest, e.g.
     * "cmd.addArg(t)" runs before "eatTheRest = true". The bare "-" branch
     * is the only one that sets eatTheRest without adding "t", so the "-"
     * token is silently dropped instead of ending up in the leftover args.
     */
    public void testSingleDashWithStopAtNonOptionIsEaten() throws Exception
    {
        String[] args = new String[] { "-a", "-", "foo" };

        CommandLine cl = parser.parse(options, args, true);

        assertTrue(cl.hasOption("a"));
        assertEquals(2, cl.getArgList().size());
        assertEquals("-", cl.getArgList().get(0));
        assertEquals("foo", cl.getArgList().get(1));
    }

    public void testStopAtNonOptionEatsRemainder() throws Exception
    {
        String[] args = new String[] { "-a", "-z", "-b", "toast" };

        CommandLine cl = parser.parse(options, args, true);

        assertTrue("a should be set", cl.hasOption("a"));
        assertFalse("b should not be set, parsing stopped before it", cl.hasOption("b"));
        assertEquals(3, cl.getArgList().size());
        assertEquals("-z", cl.getArgList().get(0));
        assertEquals("-b", cl.getArgList().get(1));
        assertEquals("toast", cl.getArgList().get(2));
    }

    public void testUnrecognizedArgumentWithoutStopAtNonOptionThrows()
    {
        String[] args = new String[] { "-a", "-z", "-b", "toast" };

        try
        {
            parser.parse(options, args, false);
            fail("UnrecognizedOptionException should have been thrown");
        }
        catch (UnrecognizedOptionException e)
        {
            assertEquals("-z", e.getOption());
        }
        catch (ParseException e)
        {
            fail("expected UnrecognizedOptionException, got " + e);
        }
    }

    public void testNonOptionArgumentDoesNotStopParsingByDefault() throws Exception
    {
        String[] args = new String[] { "foo", "-a" };

        CommandLine cl = parser.parse(options, args);

        assertTrue("a should still be parsed as an option", cl.hasOption("a"));
        assertEquals(1, cl.getArgList().size());
        assertEquals("foo", cl.getArgList().get(0));
    }

    public void testNonOptionArgumentStopsParsingWithStopAtNonOption() throws Exception
    {
        String[] args = new String[] { "foo", "-a" };

        CommandLine cl = parser.parse(options, args, true);

        assertFalse("a should not be parsed, it comes after a non-option arg", cl.hasOption("a"));
        assertEquals(2, cl.getArgList().size());
        assertEquals("foo", cl.getArgList().get(0));
        assertEquals("-a", cl.getArgList().get(1));
    }

    public void testMissingRequiredOption()
    {
        Options opts = new Options();
        opts.addOption("a", false, null);
        opts.addOption(OptionBuilder.withLongOpt("bfile").hasArg().isRequired().create('b'));

        try
        {
            parser.parse(opts, new String[] { "-a" });
            fail("MissingOptionException should have been thrown");
        }
        catch (MissingOptionException e)
        {
            assertEquals("Missing required option: b", e.getMessage());
            assertTrue(e.getMissingOptions().contains("b"));
        }
        catch (ParseException e)
        {
            fail("expected MissingOptionException, got " + e);
        }
    }

    public void testRequiredOptionPresentDoesNotThrow() throws Exception
    {
        Options opts = new Options();
        opts.addOption(OptionBuilder.isRequired().create('v'));

        CommandLine cl = parser.parse(opts, new String[] { "-v" });

        assertTrue(cl.hasOption('v'));
    }

    public void testOptionsCanBeReusedAcrossParses() throws Exception
    {
        Options opts = new Options();
        opts.addOption(OptionBuilder.isRequired().create('v'));

        parser.parse(opts, new String[] { "-v" });

        try
        {
            parser.parse(opts, new String[0]);
            fail("MissingOptionException should have been thrown on second parse");
        }
        catch (MissingOptionException e)
        {
            // expected: the required-option bookkeeping must be reset per-parse (CLI-71)
        }
    }

    public void testOptionGroupSelection() throws Exception
    {
        OptionGroup group = new OptionGroup();
        group.addOption(new Option("x", "x option"));
        group.addOption(new Option("y", "y option"));

        Options opts = new Options();
        opts.addOptionGroup(group);

        CommandLine cl = parser.parse(opts, new String[] { "-y" });

        assertTrue(cl.hasOption("y"));
        assertEquals("y", group.getSelected());
    }

    public void testMissingRequiredOptionGroup()
    {
        OptionGroup group = new OptionGroup();
        group.addOption(new Option("x", "x option"));
        group.addOption(new Option("y", "y option"));
        group.setRequired(true);

        Options opts = new Options();
        opts.addOptionGroup(group);

        try
        {
            parser.parse(opts, new String[0]);
            fail("MissingOptionException should have been thrown");
        }
        catch (MissingOptionException e)
        {
            assertEquals(1, e.getMissingOptions().size());
            assertTrue(e.getMissingOptions().get(0) instanceof OptionGroup);
        }
        catch (ParseException e)
        {
            fail("expected MissingOptionException, got " + e);
        }
    }

    public void testPropertyAddsOptionWithArgument() throws Exception
    {
        Options opts = new Options();
        opts.addOption(OptionBuilder.hasArg().create('b'));

        Properties props = new Properties();
        props.setProperty("b", "value");

        CommandLine cl = parser.parse(opts, new String[0], props);

        assertTrue(cl.hasOption("b"));
        assertEquals("value", cl.getOptionValue("b"));
    }

    public void testPropertyDoesNotOverrideValueAlreadySetOnCommandLine() throws Exception
    {
        Options opts = new Options();
        opts.addOption(OptionBuilder.hasArg().create('b'));

        Properties props = new Properties();
        props.setProperty("b", "fromProperties");

        CommandLine cl = parser.parse(opts, new String[] { "-b", "fromArgs" }, props);

        assertEquals("fromArgs", cl.getOptionValue("b"));
    }

    public void testPropertyFalseFlagIsNotSet() throws Exception
    {
        Options opts = new Options();
        opts.addOption("x", false, null);

        Properties props = new Properties();
        props.setProperty("x", "false");

        CommandLine cl = parser.parse(opts, new String[0], props);

        assertFalse("a property value of 'false' must not set the flag", cl.hasOption("x"));
    }

    /**
     * The javadoc of Parser#processProperties states that when a boolean
     * property's value is not "yes"/"true"/"1" the *option* is simply not
     * added, and processing is expected to continue with the other
     * properties. The current implementation uses a "break" instead of a
     * "continue" for that case, so a single disabled flag silently stops
     * every later property from being applied. This demonstrates that bug:
     * the "y" flag (true) is defined after the "x" flag (false) in
     * iteration order, so it must still be set.
     */
    public void testPropertyProcessingContinuesAfterDisabledFlag() throws Exception
    {
        Options opts = new Options();
        opts.addOption("x", false, null);
        opts.addOption("y", false, null);

        OrderedProperties props = new OrderedProperties();
        props.setProperty("x", "false");
        props.setProperty("y", "true");

        CommandLine cl = parser.parse(opts, new String[0], props);

        assertFalse("x is false and must not be set", cl.hasOption("x"));
        assertTrue("y is true and must be set regardless of x's position", cl.hasOption("y"));
    }

    public void testUnlimitedArgs() throws Exception
    {
        Options opts = new Options();
        opts.addOption(OptionBuilder.hasArgs().create("e"));

        String[] args = new String[] { "-e", "one", "two", "three" };

        CommandLine cl = parser.parse(opts, args);

        assertTrue(cl.hasOption("e"));
        assertEquals(3, cl.getOptionValues("e").length);
        assertEquals("one", cl.getOptionValues("e")[0]);
        assertEquals("three", cl.getOptionValues("e")[2]);
    }

    public void testProcessArgsStopsAtNextRecognizedOption() throws Exception
    {
        Options opts = new Options();
        opts.addOption(OptionBuilder.hasArgs().create("e"));
        opts.addOption("f", false, null);

        String[] args = new String[] { "-e", "one", "two", "-f" };

        CommandLine cl = parser.parse(opts, args);

        assertTrue(cl.hasOption("e"));
        assertEquals(2, cl.getOptionValues("e").length);
        assertTrue("f should be recognized as an option, not an arg value of e", cl.hasOption("f"));
    }

    public void testGetOptionsAndGetRequiredOptionsAccessors() throws Exception
    {
        Options opts = new Options();
        opts.addOption(OptionBuilder.isRequired().create('r'));

        IdentityParser identity = new IdentityParser();
        identity.parse(opts, new String[] { "-r" });

        assertSame(opts, identity.getOptions());
        assertNotNull(identity.getRequiredOptions());
        assertTrue("the required option must be removed from the list once satisfied",
                   identity.getRequiredOptions().isEmpty());
    }
}
