/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.cli;

import java.util.List;

import junit.framework.TestCase;

public class PosixParserAgentTest extends TestCase
{
    private Options options;
    private PosixParser parser;

    public void setUp()
    {
        options = new Options()
            .addOption("a", "enable-a", false, "turn [a] on or off")
            .addOption("b", "bfile", true, "set the value of [b]")
            .addOption("c", "copt", false, "turn [c] on or off");

        parser = new PosixParser();
    }

    public void testSimpleShort() throws Exception
    {
        String[] args = new String[] { "-a", "-b", "toast", "foo", "bar" };

        CommandLine cl = parser.parse(options, args);

        assertTrue("Confirm -a is set", cl.hasOption("a"));
        assertTrue("Confirm -b is set", cl.hasOption("b"));
        assertEquals("toast", cl.getOptionValue("b"));
        assertEquals(2, cl.getArgList().size());
    }

    public void testSimpleLong() throws Exception
    {
        String[] args = new String[] { "--enable-a", "--bfile", "toast", "foo", "bar" };

        CommandLine cl = parser.parse(options, args);

        assertTrue("Confirm -a is set", cl.hasOption("a"));
        assertTrue("Confirm -b is set", cl.hasOption("b"));
        assertEquals("toast", cl.getOptionValue("b"));
        assertEquals(2, cl.getArgList().size());
    }

    public void testLongWithEquals() throws Exception
    {
        String[] args = new String[] { "--bfile=toast" };

        CommandLine cl = parser.parse(options, args);

        assertTrue(cl.hasOption("b"));
        assertEquals("toast", cl.getOptionValue("b"));
    }

    public void testBurstingOfFlags() throws Exception
    {
        // "-ac" should burst into "-a" and "-c", both flag options
        String[] args = new String[] { "-ac" };

        CommandLine cl = parser.parse(options, args);

        assertTrue("Confirm -a is set", cl.hasOption("a"));
        assertTrue("Confirm -c is set", cl.hasOption("c"));
        assertFalse("Confirm -b is not set", cl.hasOption("b"));
        assertEquals(0, cl.getArgList().size());
    }

    public void testBurstingWithArgAttached() throws Exception
    {
        // "-btoast" should burst to the option "b" with attached arg "toast"
        String[] args = new String[] { "-btoast" };

        CommandLine cl = parser.parse(options, args);

        assertTrue(cl.hasOption("b"));
        assertEquals("toast", cl.getOptionValue("b"));
    }

    public void testUnrecognizedOption() throws Exception
    {
        // an unrecognized token longer than 2 characters is preserved whole
        // by burstToken() and then rejected by Parser.processOption()
        String[] args = new String[] { "-a", "-dd", "-b", "toast", "foo", "bar" };

        try
        {
            parser.parse(options, args);
            fail("UnrecognizedOptionException wasn't thrown");
        }
        catch (UnrecognizedOptionException e)
        {
            assertEquals("-dd", e.getOption());
        }
    }

    public void testMissingArg() throws Exception
    {
        String[] args = new String[] { "-b" };

        try
        {
            parser.parse(options, args);
            fail("MissingArgumentException wasn't thrown");
        }
        catch (MissingArgumentException e)
        {
            assertEquals("b", e.getOption().getOpt());
        }
    }

    public void testStop() throws Exception
    {
        String[] args = new String[] { "-c", "foober", "-b", "toast" };

        CommandLine cl = parser.parse(options, args, true);

        assertTrue("Confirm -c is set", cl.hasOption("c"));
        assertEquals(3, cl.getArgList().size());
    }

    public void testDoubleDash() throws Exception
    {
        String[] args = new String[] { "--copt", "--", "-b", "toast" };

        CommandLine cl = parser.parse(options, args);

        assertTrue("Confirm -c is set", cl.hasOption("c"));
        assertFalse("Confirm -b is not set", cl.hasOption("b"));
        assertEquals(2, cl.getArgList().size());
    }

    public void testSingleDash() throws Exception
    {
        String[] args = new String[] { "--copt", "-b", "-", "-a", "-" };

        CommandLine cl = parser.parse(options, args);

        assertTrue("Confirm -a is set", cl.hasOption("a"));
        assertTrue("Confirm -b is set", cl.hasOption("b"));
        assertEquals("-", cl.getOptionValue("b"));
        assertEquals(1, cl.getArgList().size());
        assertEquals("-", cl.getArgList().get(0));
    }

    public void testNegativeArgument() throws Exception
    {
        // a multi-digit negative number is 3+ characters long, so it goes
        // through burstToken() as a whole, unrecognized token and survives
        // as the argument value for option "a"
        String[] args = new String[] { "-a", "-42" };

        Options opts = new Options();
        opts.addOption("a", "aopt", true, "a with an arg");

        CommandLine cl = parser.parse(opts, args);

        assertEquals("-42", cl.getOptionValue("a"));
    }

    public void testSingleDigitNegativeArgumentIsSwallowed() throws Exception
    {
        // a single-digit negative number is exactly 2 characters, so
        // PosixParser treats it as a (unrecognized) short option token and
        // silently drops it instead of treating it as an argument value
        String[] args = new String[] { "-a", "-1" };

        Options opts = new Options();
        opts.addOption("a", "aopt", true, "a with an arg");

        try
        {
            parser.parse(opts, args);
            fail("MissingArgumentException wasn't thrown");
        }
        catch (MissingArgumentException e)
        {
            assertEquals("a", e.getOption().getOpt());
        }
    }

    public void testEmptyArguments() throws Exception
    {
        CommandLine cl = parser.parse(options, new String[0]);

        assertNotNull(cl);
        assertEquals(0, cl.getArgList().size());
        assertFalse(cl.hasOption("a"));
    }

    public void testNullArguments() throws Exception
    {
        CommandLine cl = parser.parse(options, null);

        assertNotNull(cl);
        assertEquals(0, cl.getArgList().size());
    }

    // --- direct tests of the protected flatten()/burstToken() methods ---

    public void testFlattenEmptyArguments()
    {
        String[] result = parser.flatten(options, new String[0], false);

        assertNotNull(result);
        assertEquals(0, result.length);
    }

    public void testFlattenDoubleDashAlone()
    {
        String[] result = parser.flatten(options, new String[] { "--" }, false);

        assertEquals(1, result.length);
        assertEquals("--", result[0]);
    }

    public void testFlattenSingleHyphenAlone()
    {
        String[] result = parser.flatten(options, new String[] { "-" }, false);

        assertEquals(1, result.length);
        assertEquals("-", result[0]);
    }

    public void testFlattenLongOptionWithEqualsSplitsTokens()
    {
        String[] result = parser.flatten(options, new String[] { "--bfile=toast" }, false);

        assertEquals(2, result.length);
        assertEquals("--bfile", result[0]);
        assertEquals("toast", result[1]);
    }

    public void testFlattenMultiCharOptionRegisteredDirectlyIsNotBurst()
    {
        Options opts = new Options();
        opts.addOption("xyz", false, "multi char short opt");

        String[] result = parser.flatten(opts, new String[] { "-xyz" }, false);

        assertEquals(1, result.length);
        assertEquals("-xyz", result[0]);
    }

    public void testFlattenUnknownTwoCharOptionIgnoredWhenNotStopping()
    {
        String[] result = parser.flatten(options, new String[] { "-d" }, false);

        // not a registered option, and stopAtNonOption is false: entry is ignored
        assertEquals(0, result.length);
    }

    public void testFlattenUnknownTwoCharOptionStopsAndCopiesRemainder()
    {
        // the unrecognized "-d" token itself is dropped (never added to the
        // tokens list), but once stopAtNonOption triggers eatTheRest, all
        // remaining raw tokens are copied through untouched
        String[] result = parser.flatten(options, new String[] { "-d", "-a", "foo" }, true);

        assertEquals(2, result.length);
        assertEquals("-a", result[0]);
        assertEquals("foo", result[1]);
    }

    public void testBurstTokenUnknownCharNotStoppingKeepsWholeToken()
    {
        // 'a' is a known flag, 'z' is unknown; stopAtNonOption is false.
        // The recognized prefix "-a" is added, then the unknown character
        // causes the *entire original token* to also be appended.
        String[] result = parser.flatten(options, new String[] { "-az" }, false);

        assertEquals(2, result.length);
        assertEquals("-a", result[0]);
        assertEquals("-az", result[1]);
    }

    public void testBurstTokenUnknownCharStoppingEatsRemainder()
    {
        // 'a' is a known flag (no arg), 'z' is unknown; stopAtNonOption true
        String[] result = parser.flatten(options, new String[] { "-az", "trailing" }, true);

        assertEquals(4, result.length);
        assertEquals("-a", result[0]);
        assertEquals("--", result[1]);
        assertEquals("z", result[2]);
        assertEquals("trailing", result[3]);
    }

    public void testBurstTokenArgOptionConsumesRemainderOfToken()
    {
        String[] result = parser.flatten(options, new String[] { "-btoast" }, false);

        assertEquals(2, result.length);
        assertEquals("-b", result[0]);
        assertEquals("toast", result[1]);
    }

    public void testRepeatedParseResetsState() throws Exception
    {
        String[] args1 = new String[] { "-a" };
        CommandLine cl1 = parser.parse(options, args1);
        assertTrue(cl1.hasOption("a"));

        // a second, independent parse must not retain state (e.g. eatTheRest,
        // tokens) from the previous call
        String[] args2 = new String[] { "-c" };
        CommandLine cl2 = parser.parse(options, args2);
        assertTrue(cl2.hasOption("c"));
        assertFalse(cl2.hasOption("a"));
        assertEquals(0, cl2.getArgList().size());
    }

    public void testExtraOptionWithStopAtNonOptionAndRecognizedOption() throws Exception
    {
        // first non-option is actually a recognized option further processed
        String[] args = new String[] { "foo", "-a" };

        CommandLine cl = parser.parse(options, args, true);

        assertFalse("Confirm -a is not set", cl.hasOption("a"));
        assertEquals(2, cl.getArgList().size());
        assertEquals("foo", cl.getArgList().get(0));
        assertEquals("-a", cl.getArgList().get(1));
    }

    public void testShortOptionAlreadyRegisteredAsWholeTokenIsNotBurst() throws Exception
    {
        Options opts = new Options();
        opts.addOption("xyz", true, "multi char short opt with arg");

        List argList;
        CommandLine cl = parser.parse(opts, new String[] { "-xyz", "value" });

        assertTrue(cl.hasOption("xyz"));
        assertEquals("value", cl.getOptionValue("xyz"));
        argList = cl.getArgList();
        assertEquals(0, argList.size());
    }
}
