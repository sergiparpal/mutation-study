/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.cli;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.Properties;

import org.junit.Test;

public class DefaultParserAgentTest
{
    private final DefaultParser parser = new DefaultParser();

    @Test
    public void testSimpleShortOption() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "a flag");

        CommandLine cmd = parser.parse(options, new String[] {"-a"});

        assertTrue(cmd.hasOption("a"));
        assertEquals(0, cmd.getArgs().length);
    }

    @Test
    public void testShortOptionWithArgSeparate() throws Exception
    {
        Options options = new Options();
        options.addOption("b", true, "b with arg");

        CommandLine cmd = parser.parse(options, new String[] {"-b", "foo"});

        assertTrue(cmd.hasOption("b"));
        assertEquals("foo", cmd.getOptionValue("b"));
    }

    @Test
    public void testShortOptionWithArgAttached() throws Exception
    {
        Options options = new Options();
        options.addOption("b", true, "b with arg");

        CommandLine cmd = parser.parse(options, new String[] {"-bfoo"});

        assertTrue(cmd.hasOption("b"));
        assertEquals("foo", cmd.getOptionValue("b"));
    }

    @Test
    public void testShortOptionWithEquals() throws Exception
    {
        Options options = new Options();
        options.addOption("b", true, "b with arg");

        CommandLine cmd = parser.parse(options, new String[] {"-b=foo"});

        assertTrue(cmd.hasOption("b"));
        assertEquals("foo", cmd.getOptionValue("b"));
    }

    @Test
    public void testLongOptionWithArgSeparate() throws Exception
    {
        Options options = new Options();
        options.addOption("b", "bar", true, "bar with arg");

        CommandLine cmd = parser.parse(options, new String[] {"--bar", "foo"});

        assertTrue(cmd.hasOption("bar"));
        assertEquals("foo", cmd.getOptionValue("bar"));
    }

    @Test
    public void testLongOptionWithEquals() throws Exception
    {
        Options options = new Options();
        options.addOption("b", "bar", true, "bar with arg");

        CommandLine cmd = parser.parse(options, new String[] {"--bar=foo"});

        assertTrue(cmd.hasOption("bar"));
        assertEquals("foo", cmd.getOptionValue("bar"));
    }

    @Test
    public void testLongOptionPartialMatch() throws Exception
    {
        Options options = new Options();
        options.addOption("b", "bar", false, "bar flag");

        CommandLine cmd = parser.parse(options, new String[] {"--ba"});

        assertTrue(cmd.hasOption("bar"));
    }

    @Test
    public void testAmbiguousLongOptionThrows() throws Exception
    {
        Options options = new Options();
        options.addOption(null, "bar", false, "bar flag");
        options.addOption(null, "baz", false, "baz flag");

        try
        {
            parser.parse(options, new String[] {"--ba"});
            fail("Expected AmbiguousOptionException");
        }
        catch (AmbiguousOptionException e)
        {
            assertEquals("--ba", e.getOption());
            assertEquals(2, e.getMatchingOptions().size());
        }
    }

    @Test
    public void testUnrecognizedOptionThrows() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "a flag");

        try
        {
            parser.parse(options, new String[] {"-z"});
            fail("Expected UnrecognizedOptionException");
        }
        catch (UnrecognizedOptionException e)
        {
            assertEquals("-z", e.getOption());
        }
    }

    @Test
    public void testUnrecognizedNonOptionTokenBecomesArg() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "a flag");

        CommandLine cmd = parser.parse(options, new String[] {"plainArg"});

        assertFalse(cmd.hasOption("a"));
        assertArrayEquals(new String[] {"plainArg"}, cmd.getArgs());
    }

    @Test
    public void testStopAtNonOption() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "a flag");

        CommandLine cmd = parser.parse(options, new String[] {"-a", "foo", "-b"}, true);

        assertTrue(cmd.hasOption("a"));
        assertArrayEquals(new String[] {"foo", "-b"}, cmd.getArgs());
    }

    @Test
    public void testDoubleDashStopsParsing() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "a flag");

        CommandLine cmd = parser.parse(options, new String[] {"-a", "--", "-a"});

        assertTrue(cmd.hasOption("a"));
        assertArrayEquals(new String[] {"-a"}, cmd.getArgs());
    }

    @Test
    public void testMissingArgumentThrows() throws Exception
    {
        Options options = new Options();
        options.addOption("b", true, "b with arg");

        try
        {
            parser.parse(options, new String[] {"-b"});
            fail("Expected MissingArgumentException");
        }
        catch (MissingArgumentException e)
        {
            assertEquals("b", e.getOption().getOpt());
        }
    }

    @Test
    public void testMissingRequiredOptionThrows() throws Exception
    {
        Options options = new Options();
        options.addOption(Option.builder("a").required().build());

        try
        {
            parser.parse(options, new String[] {});
            fail("Expected MissingOptionException");
        }
        catch (MissingOptionException e)
        {
            assertTrue(e.getMissingOptions().contains("a"));
        }
    }

    @Test
    public void testRequiredOptionPresentDoesNotThrow() throws Exception
    {
        Options options = new Options();
        options.addOption(Option.builder("a").required().build());

        CommandLine cmd = parser.parse(options, new String[] {"-a"});

        assertTrue(cmd.hasOption("a"));
    }

    @Test
    public void testNegativeNumberAsArgument() throws Exception
    {
        Options options = new Options();
        options.addOption("b", true, "b with arg");

        CommandLine cmd = parser.parse(options, new String[] {"-b", "-42"});

        assertEquals("-42", cmd.getOptionValue("b"));
    }

    @Test
    public void testStandaloneNegativeNumberWithoutPendingOptionIsUnrecognized() throws Exception
    {
        // Negative-number detection only comes into play while an argument is
        // expected by the previously-seen option; a leading "-42" with no
        // option currently accepting an argument looks like an (unknown)
        // option and is rejected rather than treated as a plain argument.
        Options options = new Options();

        try
        {
            parser.parse(options, new String[] {"-42"});
            fail("Expected UnrecognizedOptionException");
        }
        catch (UnrecognizedOptionException e)
        {
            assertEquals("-42", e.getOption());
        }
    }

    @Test
    public void testConcatenatedShortOptions() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "a flag");
        options.addOption("b", false, "b flag");
        options.addOption("c", false, "c flag");

        CommandLine cmd = parser.parse(options, new String[] {"-abc"});

        assertTrue(cmd.hasOption("a"));
        assertTrue(cmd.hasOption("b"));
        assertTrue(cmd.hasOption("c"));
    }

    @Test
    public void testConcatenatedShortOptionsWithTrailingArg() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "a flag");
        options.addOption("b", true, "b with arg");

        CommandLine cmd = parser.parse(options, new String[] {"-abfoo"});

        assertTrue(cmd.hasOption("a"));
        assertEquals("foo", cmd.getOptionValue("b"));
    }

    @Test
    public void testJavaPropertyStyleOption() throws Exception
    {
        Options options = new Options();
        options.addOption(Option.builder("D").hasArgs().valueSeparator('=').build());

        CommandLine cmd = parser.parse(options, new String[] {"-Dkey=value"});

        String[] values = cmd.getOptionValues("D");
        assertArrayEquals(new String[] {"key", "value"}, values);
    }

    @Test
    public void testLongPrefixOption() throws Exception
    {
        Options options = new Options();
        options.addOption(Option.builder().longOpt("Xmx").hasArg().build());

        CommandLine cmd = parser.parse(options, new String[] {"-Xmx512m"});

        assertTrue(cmd.hasOption("Xmx"));
        assertEquals("512m", cmd.getOptionValue("Xmx"));
    }

    @Test
    public void testAlreadySelectedThrows() throws Exception
    {
        Options options = new Options();
        OptionGroup group = new OptionGroup();
        group.addOption(new Option("a", "aaa", false, "a flag"));
        group.addOption(new Option("b", "bbb", false, "b flag"));
        options.addOptionGroup(group);

        try
        {
            parser.parse(options, new String[] {"-a", "-b"});
            fail("Expected AlreadySelectedException");
        }
        catch (AlreadySelectedException e)
        {
            assertEquals("a", e.getOptionGroup().getSelected());
            assertEquals("b", e.getOption().getOpt());
        }
    }

    @Test
    public void testSameGroupOptionTwiceDoesNotThrow() throws Exception
    {
        Options options = new Options();
        OptionGroup group = new OptionGroup();
        group.addOption(new Option("a", "aaa", false, "a flag"));
        group.addOption(new Option("b", "bbb", false, "b flag"));
        options.addOptionGroup(group);

        CommandLine cmd = parser.parse(options, new String[] {"-a", "-a"});

        assertTrue(cmd.hasOption("a"));
    }

    @Test
    public void testPropertiesSetsOptionWhenNotPresent() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "a flag");

        Properties props = new Properties();
        props.setProperty("a", "true");

        CommandLine cmd = parser.parse(options, new String[] {}, props);

        assertTrue(cmd.hasOption("a"));
    }

    @Test
    public void testPropertiesDoesNotOverrideCommandLine() throws Exception
    {
        Options options = new Options();
        options.addOption("a", true, "a with arg");

        Properties props = new Properties();
        props.setProperty("a", "fromProps");

        CommandLine cmd = parser.parse(options, new String[] {"-a", "fromCli"}, props);

        assertEquals("fromCli", cmd.getOptionValue("a"));
    }

    @Test
    public void testPropertiesWithFalseValueDoesNotSetFlag() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "a flag");

        Properties props = new Properties();
        props.setProperty("a", "false");

        CommandLine cmd = parser.parse(options, new String[] {}, props);

        assertFalse(cmd.hasOption("a"));
    }

    @Test
    public void testUnrecognizedPropertyThrows() throws Exception
    {
        Options options = new Options();

        Properties props = new Properties();
        props.setProperty("unknown", "true");

        try
        {
            parser.parse(options, new String[] {}, props);
            fail("Expected UnrecognizedOptionException");
        }
        catch (UnrecognizedOptionException e)
        {
            assertEquals("unknown", e.getOption());
        }
    }

    @Test
    public void testNullArgumentsArray() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "a flag");

        CommandLine cmd = parser.parse(options, null);

        assertFalse(cmd.hasOption("a"));
        assertEquals(0, cmd.getArgs().length);
    }

    @Test
    public void testSingleHyphenIsArgument() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "a flag");

        CommandLine cmd = parser.parse(options, new String[] {"-"});

        assertArrayEquals(new String[] {"-"}, cmd.getArgs());
    }

    @Test
    public void testEmptyArgumentsArray() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "a flag");

        CommandLine cmd = parser.parse(options, new String[0]);

        assertFalse(cmd.hasOption("a"));
        assertEquals(0, cmd.getArgs().length);
        assertEquals(0, cmd.getArgList().size());
    }

    @Test
    public void testRepeatedOptionAccumulatesValues() throws Exception
    {
        Options options = new Options();
        options.addOption(Option.builder("a").hasArg().build());

        CommandLine cmd = parser.parse(options, new String[] {"-a", "one", "-a", "two"});

        assertArrayEquals(new String[] {"one", "two"}, cmd.getOptionValues("a"));
    }

    @Test
    public void testThreeDashesTreatedAsUnknownLongOption() throws Exception
    {
        Options options = new Options();

        try
        {
            parser.parse(options, new String[] {"---"});
            fail("Expected an exception for malformed option token");
        }
        catch (UnrecognizedOptionException e)
        {
            // expected: token starts with "--" and has no matching long option
        }
    }

    @Test
    public void testOptionValueIsNullWhenNoArgSupplied() throws Exception
    {
        Options options = new Options();
        options.addOption("a", false, "a flag");

        CommandLine cmd = parser.parse(options, new String[] {"-a"});

        assertNull(cmd.getOptionValue("a"));
    }
}
