package org.apache.commons.lang.time;

import java.lang.reflect.Constructor;
import java.lang.reflect.Modifier;
import java.util.Calendar;
import java.util.TimeZone;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * TestCase for DurationFormatUtils.
 */
public class DurationFormatUtilsAgentTest extends TestCase {

    public static Test suite() {
        return new TestSuite(DurationFormatUtilsAgentTest.class);
    }

    public DurationFormatUtilsAgentTest(String name) {
        super(name);
    }

    private static final long MILLIS_PER_SECOND = 1000L;
    private static final long MILLIS_PER_MINUTE = 60L * MILLIS_PER_SECOND;
    private static final long MILLIS_PER_HOUR = 60L * MILLIS_PER_MINUTE;
    private static final long MILLIS_PER_DAY = 24L * MILLIS_PER_HOUR;

    //-----------------------------------------------------------------------
    public void testConstructor() {
        assertNotNull(new DurationFormatUtils());
        Constructor[] cons = DurationFormatUtils.class.getDeclaredConstructors();
        assertEquals(1, cons.length);
        assertTrue(Modifier.isPublic(cons[0].getModifiers()));
        assertTrue(Modifier.isPublic(DurationFormatUtils.class.getModifiers()));
        assertFalse(Modifier.isFinal(DurationFormatUtils.class.getModifiers()));
    }

    //-----------------------------------------------------------------------
    public void testFormatDurationHMS() {
        assertEquals("0:00:00.000", DurationFormatUtils.formatDurationHMS(0));
        assertEquals("1:02:03.005",
                DurationFormatUtils.formatDurationHMS(MILLIS_PER_HOUR + 2 * MILLIS_PER_MINUTE + 3 * MILLIS_PER_SECOND + 5));
        // negative duration is not rejected, it just produces a negative field
        assertEquals("0:00:-5.000", DurationFormatUtils.formatDurationHMS(-5000));
    }

    public void testFormatDurationISO() {
        assertEquals("P0Y0M0DT0H0M0.000S", DurationFormatUtils.formatDurationISO(0));
        assertEquals("P0Y0M0DT1H2M3.005S",
                DurationFormatUtils.formatDurationISO(MILLIS_PER_HOUR + 2 * MILLIS_PER_MINUTE + 3 * MILLIS_PER_SECOND + 5));
    }

    //-----------------------------------------------------------------------
    public void testFormatDurationNoPadding() {
        long duration = MILLIS_PER_HOUR + 2 * MILLIS_PER_MINUTE + 3 * MILLIS_PER_SECOND + 5;
        assertEquals("1:2:3.005", DurationFormatUtils.formatDuration(duration, "H:m:s.S", false));
    }

    public void testFormatDurationWithPadding() {
        long duration = MILLIS_PER_HOUR + 2 * MILLIS_PER_MINUTE + 3 * MILLIS_PER_SECOND + 5;
        assertEquals("01:02:03.005", DurationFormatUtils.formatDuration(duration, "HH:mm:ss.SSS", true));
        // the two argument overload defaults to padding on
        assertEquals("01:02:03.005", DurationFormatUtils.formatDuration(duration, "HH:mm:ss.SSS"));
    }

    public void testFormatDurationWithLiteralText() {
        assertEquals("Duration: 5 sec", DurationFormatUtils.formatDuration(5000, "'Duration: 's' sec'", true));
    }

    public void testFormatDurationZero() {
        assertEquals("0", DurationFormatUtils.formatDuration(0, "d"));
    }

    public void testFormatDurationNullFormatThrows() {
        try {
            DurationFormatUtils.formatDuration(1000, null);
            fail("Expected NullPointerException for null format");
        } catch (NullPointerException expected) {
            // expected - lexx() cannot tokenize a null pattern
        }
    }

    //-----------------------------------------------------------------------
    public void testFormatDurationWordsZeroNoSuppression() {
        assertEquals("0 days 0 hours 0 minutes 0 seconds",
                DurationFormatUtils.formatDurationWords(0, false, false));
    }

    public void testFormatDurationWordsZeroBothSuppressed() {
        assertEquals("0 seconds", DurationFormatUtils.formatDurationWords(0, true, true));
    }

    public void testFormatDurationWordsZeroLeadingSuppressed() {
        assertEquals("0 seconds", DurationFormatUtils.formatDurationWords(0, true, false));
    }

    public void testFormatDurationWordsZeroTrailingSuppressed() {
        assertEquals("0 days", DurationFormatUtils.formatDurationWords(0, false, true));
    }

    public void testFormatDurationWordsSingularPluralization() {
        assertEquals("1 day", DurationFormatUtils.formatDurationWords(MILLIS_PER_DAY, true, true));
        assertEquals("1 hour", DurationFormatUtils.formatDurationWords(MILLIS_PER_HOUR, true, true));
        assertEquals("1 minute", DurationFormatUtils.formatDurationWords(MILLIS_PER_MINUTE, true, true));
        assertEquals("1 second", DurationFormatUtils.formatDurationWords(MILLIS_PER_SECOND, true, true));
    }

    public void testFormatDurationWordsAllFieldsNonZero() {
        long duration = MILLIS_PER_DAY + MILLIS_PER_HOUR + MILLIS_PER_MINUTE + MILLIS_PER_SECOND;
        assertEquals("1 day 1 hour 1 minute 1 second",
                DurationFormatUtils.formatDurationWords(duration, true, true));
        assertEquals("1 day 1 hour 1 minute 1 second",
                DurationFormatUtils.formatDurationWords(duration, false, false));
    }

    public void testFormatDurationWordsSuppressTrailingOnly() {
        // leading "0 days" is kept, trailing "0 minutes 0 seconds" is dropped
        assertEquals("0 days 1 hour", DurationFormatUtils.formatDurationWords(MILLIS_PER_HOUR, false, true));
    }

    public void testFormatDurationWordsSuppressLeadingOnly() {
        // there is no leading zero field here, so nothing is suppressed
        assertEquals("1 day 0 hours 0 minutes 0 seconds",
                DurationFormatUtils.formatDurationWords(MILLIS_PER_DAY, true, false));
    }

    public void testFormatDurationWordsPartialMiddleZero() {
        long duration = 2 * MILLIS_PER_DAY + 3 * MILLIS_PER_HOUR;
        assertEquals("2 days 3 hours 0 minutes 0 seconds",
                DurationFormatUtils.formatDurationWords(duration, false, false));
        assertEquals("2 days 3 hours", DurationFormatUtils.formatDurationWords(duration, true, true));
    }

    //-----------------------------------------------------------------------
    public void testFormatPeriodISO() {
        Calendar start = Calendar.getInstance(TimeZone.getDefault());
        start.clear();
        start.set(2000, 0, 1, 0, 0, 0);
        Calendar end = Calendar.getInstance(TimeZone.getDefault());
        end.clear();
        end.set(2003, 2, 15, 5, 30, 0);
        assertEquals("P3Y2M14DT5H30M0.000S",
                DurationFormatUtils.formatPeriodISO(start.getTimeInMillis(), end.getTimeInMillis()));
    }

    public void testFormatPeriodBelowCalendarThreshold() {
        // under 28 days, formatPeriod falls back to plain millisecond division
        long twentySevenDays = 27 * MILLIS_PER_DAY;
        assertEquals("27", DurationFormatUtils.formatPeriod(0, twentySevenDays, "d"));
    }

    public void testFormatPeriodWithExplicitFields() {
        TimeZone gmt = TimeZone.getTimeZone("GMT");
        Calendar start = Calendar.getInstance(gmt);
        start.clear();
        start.set(2000, 0, 1, 0, 0, 0);
        Calendar end = Calendar.getInstance(gmt);
        end.clear();
        end.set(2003, 2, 15, 5, 30, 0);
        String result = DurationFormatUtils.formatPeriod(start.getTimeInMillis(), end.getTimeInMillis(),
                "y' years 'M' months 'd' days 'H' hours 'm' minutes 's' seconds'", true, gmt);
        assertEquals("3 years 2 months 14 days 5 hours 30 minutes 0 seconds", result);
    }

    public void testFormatPeriodDefaultsToDefaultTimeZoneAndPadding() {
        long duration = MILLIS_PER_HOUR + 2 * MILLIS_PER_MINUTE + 3 * MILLIS_PER_SECOND + 5;
        // delegates to the simple-arithmetic branch since duration is below 28 days
        assertEquals("01:02:03.005", DurationFormatUtils.formatPeriod(0, duration, "HH:mm:ss.SSS"));
    }

    public void testFormatPeriodNegativeDurationDoesNotThrow() {
        // startMillis after endMillis yields a negative gap but no exception
        String result = DurationFormatUtils.formatPeriod(2000, 1000, "H:mm:ss.SSS");
        assertEquals("0:00:-1.000", result);
    }

    public void testFormatPeriodAtAndJustAboveCalendarThreshold() {
        // at and beyond 28 days, formatPeriod switches to a calendar-based
        // computation that can disagree with plain millisecond division
        // when the pattern omits larger fields such as months; verify the
        // actual, deterministic behaviour at and around the boundary.
        assertEquals("-309", DurationFormatUtils.formatPeriod(0, 28 * MILLIS_PER_DAY, "d"));
        assertEquals("-307", DurationFormatUtils.formatPeriod(0, 29 * MILLIS_PER_DAY, "d"));
    }

}
