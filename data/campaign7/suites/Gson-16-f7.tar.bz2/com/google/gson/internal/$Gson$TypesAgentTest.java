/*
 * Copyright (C) 2014 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.gson.internal;

import java.lang.reflect.GenericArrayType;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import junit.framework.TestCase;

public final class $Gson$TypesAgentTest extends TestCase {

  // ---- fixtures ----

  private static final class Box<T> {
  }

  private static class StringList extends ArrayList<String> {
  }

  private static class RawList extends ArrayList {
  }

  private static class StringIntMap extends HashMap<String, Integer> {
  }

  private static class RawMap extends HashMap {
  }

  private class InnerNonStatic {
  }

  // ---- newParameterizedTypeWithOwner ----

  public void testNewParameterizedTypeWithOwner_topLevelRawType() {
    ParameterizedType type =
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    assertNull(type.getOwnerType());
    assertEquals(List.class, type.getRawType());
    assertEquals(1, type.getActualTypeArguments().length);
    assertEquals(String.class, type.getActualTypeArguments()[0]);
    assertEquals("java.util.List<java.lang.String>", type.toString());
  }

  public void testNewParameterizedTypeWithOwner_staticNestedRawType() {
    ParameterizedType type = $Gson$Types.newParameterizedTypeWithOwner(null, Box.class, String.class);
    assertEquals(Box.class, type.getRawType());
    assertEquals(String.class, type.getActualTypeArguments()[0]);
  }

  public void testNewParameterizedTypeWithOwner_nonStaticInnerClassRequiresOwner() {
    try {
      $Gson$Types.newParameterizedTypeWithOwner(null, InnerNonStatic.class);
      fail("expected IllegalArgumentException for non-static inner class without owner");
    } catch (IllegalArgumentException expected) {
    }

    // supplying an owner is fine
    ParameterizedType type = $Gson$Types.newParameterizedTypeWithOwner(
        $Gson$TypesAgentTest.class, InnerNonStatic.class);
    assertEquals(InnerNonStatic.class, type.getRawType());
  }

  public void testNewParameterizedTypeWithOwner_nullTypeArgumentRejected() {
    try {
      $Gson$Types.newParameterizedTypeWithOwner(null, List.class, new Type[] { null });
      fail("expected NullPointerException for null type argument");
    } catch (NullPointerException expected) {
    }
  }

  public void testNewParameterizedTypeWithOwner_primitiveTypeArgumentRejected() {
    try {
      $Gson$Types.newParameterizedTypeWithOwner(null, List.class, int.class);
      fail("expected IllegalArgumentException for primitive type argument");
    } catch (IllegalArgumentException expected) {
    }
  }

  public void testNewParameterizedTypeWithOwner_noTypeArguments() {
    ParameterizedType type = $Gson$Types.newParameterizedTypeWithOwner(null, List.class);
    assertEquals(0, type.getActualTypeArguments().length);
    assertEquals("java.util.List", type.toString());
  }

  // ---- arrayOf ----

  public void testArrayOf() {
    GenericArrayType type = $Gson$Types.arrayOf(String.class);
    assertEquals(String.class, type.getGenericComponentType());
    assertEquals("java.lang.String[]", type.toString());
  }

  public void testArrayOf_nested() {
    GenericArrayType inner = $Gson$Types.arrayOf(String.class);
    GenericArrayType outer = $Gson$Types.arrayOf(inner);
    assertEquals("java.lang.String[][]", outer.toString());
    assertTrue($Gson$Types.equals(inner, outer.getGenericComponentType()));
  }

  // ---- subtypeOf / supertypeOf ----

  public void testSubtypeOf_plainBound() {
    WildcardType type = $Gson$Types.subtypeOf(String.class);
    assertEquals(1, type.getUpperBounds().length);
    assertEquals(String.class, type.getUpperBounds()[0]);
    assertEquals(0, type.getLowerBounds().length);
    assertEquals("? extends java.lang.String", type.toString());
  }

  public void testSubtypeOf_objectBoundPrintsBareWildcard() {
    WildcardType type = $Gson$Types.subtypeOf(Object.class);
    assertEquals("?", type.toString());
  }

  public void testSubtypeOf_wildcardBoundUnwrapsUpperBounds() {
    WildcardType inner = $Gson$Types.subtypeOf(String.class);
    WildcardType outer = $Gson$Types.subtypeOf(inner);
    assertEquals(String.class, outer.getUpperBounds()[0]);
    assertEquals(0, outer.getLowerBounds().length);
  }

  public void testSupertypeOf_plainBound() {
    WildcardType type = $Gson$Types.supertypeOf(String.class);
    assertEquals(1, type.getLowerBounds().length);
    assertEquals(String.class, type.getLowerBounds()[0]);
    assertEquals(1, type.getUpperBounds().length);
    assertEquals(Object.class, type.getUpperBounds()[0]);
    assertEquals("? super java.lang.String", type.toString());
  }

  public void testSupertypeOf_wildcardBoundUnwrapsLowerBounds() {
    WildcardType inner = $Gson$Types.supertypeOf(String.class);
    WildcardType outer = $Gson$Types.supertypeOf(inner);
    assertEquals(String.class, outer.getLowerBounds()[0]);
    assertEquals(Object.class, outer.getUpperBounds()[0]);
  }

  // ---- canonicalize ----

  public void testCanonicalize_plainClassIsUnchanged() {
    assertSame(String.class, $Gson$Types.canonicalize(String.class));
  }

  public void testCanonicalize_arrayClassBecomesGenericArrayType() {
    Type canonical = $Gson$Types.canonicalize(String[].class);
    assertTrue(canonical instanceof GenericArrayType);
    assertEquals(String.class, ((GenericArrayType) canonical).getGenericComponentType());
  }

  public void testCanonicalize_parameterizedTypeIsFunctionallyEqual() {
    ParameterizedType original =
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    Type canonical = $Gson$Types.canonicalize(original);
    assertNotSame(original, canonical);
    assertTrue($Gson$Types.equals(original, canonical));
  }

  public void testCanonicalize_unsupportedTypeIsReturnedAsIs() {
    Type custom = new Type() {
      @Override public String toString() {
        return "custom";
      }
    };
    assertSame(custom, $Gson$Types.canonicalize(custom));
  }

  // ---- getRawType ----

  public void testGetRawType_class() {
    assertEquals(String.class, $Gson$Types.getRawType(String.class));
  }

  public void testGetRawType_parameterizedType() {
    ParameterizedType type = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    assertEquals(List.class, $Gson$Types.getRawType(type));
  }

  public void testGetRawType_genericArrayType() {
    GenericArrayType type = $Gson$Types.arrayOf(String.class);
    assertEquals(String[].class, $Gson$Types.getRawType(type));
  }

  public void testGetRawType_nestedGenericArrayType() {
    GenericArrayType type = $Gson$Types.arrayOf($Gson$Types.arrayOf(String.class));
    assertEquals(String[][].class, $Gson$Types.getRawType(type));
  }

  public void testGetRawType_typeVariableResolvesToObject() {
    TypeVariable<?> typeVariable = Box.class.getTypeParameters()[0];
    assertEquals(Object.class, $Gson$Types.getRawType(typeVariable));
  }

  public void testGetRawType_wildcardType() {
    WildcardType type = $Gson$Types.subtypeOf(String.class);
    assertEquals(String.class, $Gson$Types.getRawType(type));
  }

  public void testGetRawType_nullTypeThrows() {
    try {
      $Gson$Types.getRawType(null);
      fail("expected IllegalArgumentException for null type");
    } catch (IllegalArgumentException expected) {
      assertTrue(expected.getMessage().contains("null"));
    }
  }

  public void testGetRawType_unsupportedTypeThrows() {
    Type custom = new Type() {
    };
    try {
      $Gson$Types.getRawType(custom);
      fail("expected IllegalArgumentException for unsupported type");
    } catch (IllegalArgumentException expected) {
    }
  }

  // ---- equals ----

  public void testEquals_sameClass() {
    assertTrue($Gson$Types.equals(String.class, String.class));
  }

  public void testEquals_differentClasses() {
    assertFalse($Gson$Types.equals(String.class, Integer.class));
  }

  public void testEquals_bothNull() {
    assertTrue($Gson$Types.equals(null, null));
  }

  public void testEquals_parameterizedTypesEqual() {
    ParameterizedType a = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    ParameterizedType b = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    assertNotSame(a, b);
    assertTrue($Gson$Types.equals(a, b));
  }

  public void testEquals_parameterizedTypesDifferentArguments() {
    ParameterizedType a = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    ParameterizedType b = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, Integer.class);
    assertFalse($Gson$Types.equals(a, b));
  }

  public void testEquals_parameterizedTypeVersusNonParameterizedType() {
    ParameterizedType a = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    assertFalse($Gson$Types.equals(a, String.class));
  }

  public void testEquals_genericArrayTypes() {
    GenericArrayType a = $Gson$Types.arrayOf(String.class);
    GenericArrayType b = $Gson$Types.arrayOf(String.class);
    assertTrue($Gson$Types.equals(a, b));
    assertFalse($Gson$Types.equals(a, String.class));
  }

  public void testEquals_wildcardTypes() {
    WildcardType a = $Gson$Types.subtypeOf(String.class);
    WildcardType b = $Gson$Types.subtypeOf(String.class);
    WildcardType c = $Gson$Types.subtypeOf(Integer.class);
    assertTrue($Gson$Types.equals(a, b));
    assertFalse($Gson$Types.equals(a, c));
    assertFalse($Gson$Types.equals(a, String.class));
  }

  public void testEquals_typeVariables() {
    TypeVariable<?> a = Box.class.getTypeParameters()[0];
    TypeVariable<?> b = Box.class.getTypeParameters()[0];
    assertTrue($Gson$Types.equals(a, b));
    assertFalse($Gson$Types.equals(a, String.class));
  }

  public void testEquals_unsupportedTypeKind() {
    Type a = new Type() {
    };
    Type b = new Type() {
    };
    assertFalse($Gson$Types.equals(a, b));
  }

  // ---- typeToString ----

  public void testTypeToString_class() {
    assertEquals("java.lang.String", $Gson$Types.typeToString(String.class));
  }

  public void testTypeToString_nonClassUsesToString() {
    WildcardType type = $Gson$Types.subtypeOf(String.class);
    assertEquals(type.toString(), $Gson$Types.typeToString(type));
    assertEquals("? extends java.lang.String", $Gson$Types.typeToString(type));
  }

  // ---- getArrayComponentType ----

  public void testGetArrayComponentType_classArray() {
    assertEquals(String.class, $Gson$Types.getArrayComponentType(String[].class));
  }

  public void testGetArrayComponentType_genericArrayType() {
    GenericArrayType type = $Gson$Types.arrayOf(String.class);
    assertEquals(String.class, $Gson$Types.getArrayComponentType(type));
  }

  public void testGetArrayComponentType_notAnArrayThrows() {
    try {
      $Gson$Types.getArrayComponentType(String.class);
      fail("expected ClassCastException for non-array type");
    } catch (ClassCastException expected) {
    }
  }

  // ---- getCollectionElementType ----

  public void testGetCollectionElementType_parameterizedSubclass() {
    Type elementType = $Gson$Types.getCollectionElementType(StringList.class, StringList.class);
    assertEquals(String.class, elementType);
  }

  public void testGetCollectionElementType_rawTypeDefaultsToObject() {
    Type elementType = $Gson$Types.getCollectionElementType(RawList.class, RawList.class);
    assertEquals(Object.class, elementType);
  }

  // ---- getMapKeyAndValueTypes ----

  public void testGetMapKeyAndValueTypes_parameterizedSubclass() {
    Type[] types = $Gson$Types.getMapKeyAndValueTypes(StringIntMap.class, StringIntMap.class);
    assertEquals(2, types.length);
    assertEquals(String.class, types[0]);
    assertEquals(Integer.class, types[1]);
  }

  public void testGetMapKeyAndValueTypes_rawTypeDefaultsToObject() {
    Type[] types = $Gson$Types.getMapKeyAndValueTypes(RawMap.class, RawMap.class);
    assertEquals(2, types.length);
    assertEquals(Object.class, types[0]);
    assertEquals(Object.class, types[1]);
  }

  public void testGetMapKeyAndValueTypes_propertiesSpecialCased() {
    Type[] types = $Gson$Types.getMapKeyAndValueTypes(Properties.class, Properties.class);
    assertEquals(2, types.length);
    assertEquals(String.class, types[0]);
    assertEquals(String.class, types[1]);
  }

  // ---- getSupertype / resolve (exercised indirectly, plus a direct check) ----

  public void testResolve_parameterizedTypeArgumentSubstitution() {
    ParameterizedType mapOfListOfString = $Gson$Types.newParameterizedTypeWithOwner(
        null, Map.class, String.class, $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class));
    Type resolved = $Gson$Types.resolve(mapOfListOfString, Map.class, mapOfListOfString);
    assertTrue($Gson$Types.equals(mapOfListOfString, resolved));
  }
}
