/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.builder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import junit.framework.TestCase;

/**
 * Self-contained test case for {@link ToStringStyle}.
 */
public class ToStringStyleAgentTest extends TestCase {

    public ToStringStyleAgentTest(String name) {
        super(name);
    }

    public ToStringStyleAgentTest() {
        super();
    }

    private static class ToStringStyleImpl extends ToStringStyle {
    }

    //-----------------------------------------------------------------------
    // appendStart / appendEnd / appendSuper / appendToString
    //-----------------------------------------------------------------------

    public void testAppendStartAndEnd() {
        ToStringStyle style = new ToStringStyleImpl();
        StringBuffer buffer = new StringBuffer();
        Object obj = new Object();
        style.appendStart(buffer, obj);
        String afterStart = buffer.toString();
        assertTrue(afterStart.startsWith(obj.getClass().getName()));
        assertTrue(afterStart.indexOf('@') >= 0);
        assertTrue(afterStart.endsWith("["));

        style.appendEnd(buffer, obj);
        String afterEnd = buffer.toString();
        assertTrue(afterEnd.endsWith("]"));
    }

    public void testAppendStartWithNullObjectAppendsNothing() {
        ToStringStyle style = new ToStringStyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.appendStart(buffer, null);
        assertEquals("", buffer.toString());
    }

    public void testAppendEndRemovesTrailingFieldSeparator() {
        ToStringStyle style = new ToStringStyleImpl();
        StringBuffer buffer = new StringBuffer();
        buffer.append("abc").append(style.getFieldSeparator());
        style.appendEnd(buffer, new Object());
        assertEquals("abc]", buffer.toString());
    }

    public void testAppendEndKeepsFieldSeparatorWhenAtEndFlagSet() {
        ToStringStyleImpl style = new ToStringStyleImpl();
        style.setFieldSeparatorAtEnd(true);
        StringBuffer buffer = new StringBuffer();
        buffer.append("abc").append(style.getFieldSeparator());
        style.appendEnd(buffer, new Object());
        assertEquals("abc,]", buffer.toString());
    }

    public void testAppendSuperWithNullIsIgnored() {
        ToStringStyle style = new ToStringStyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.appendSuper(buffer, null);
        assertEquals("", buffer.toString());
    }

    public void testAppendSuperWithContentAppendsDataAndSeparator() {
        ToStringStyle style = new ToStringStyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.appendSuper(buffer, "SomeClass@1[field=1]");
        assertEquals("field=1,", buffer.toString());
    }

    public void testAppendToStringWithEmptyContentAddsNothing() {
        ToStringStyle style = new ToStringStyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.appendToString(buffer, "SomeClass@1[]");
        assertEquals("", buffer.toString());
    }

    //-----------------------------------------------------------------------
    // append(Object) with full detail flag
    //-----------------------------------------------------------------------

    public void testAppendObjectValueNull() {
        ToStringStyle style = new ToStringStyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "name", (Object) null, Boolean.TRUE);
        assertEquals("name=<null>,", buffer.toString());
    }

    public void testAppendObjectValueDetailTrue() {
        ToStringStyle style = new ToStringStyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "name", "value", Boolean.TRUE);
        assertEquals("name=value,", buffer.toString());
    }

    public void testAppendObjectValueSummaryFalse() {
        ToStringStyle style = new ToStringStyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "name", "value", Boolean.FALSE);
        assertEquals("name=<String>,", buffer.toString());
    }

    public void testAppendObjectValueNullFullDetailUsesDefault() {
        ToStringStyleImpl style = new ToStringStyleImpl();
        style.setDefaultFullDetail(false);
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "name", "value", null);
        assertEquals("name=<String>,", buffer.toString());
    }

    public void testAppendFieldNameOmittedWhenUseFieldNamesFalse() {
        ToStringStyleImpl style = new ToStringStyleImpl();
        style.setUseFieldNames(false);
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "name", "value", Boolean.TRUE);
        assertEquals("value,", buffer.toString());
    }

    public void testAppendFieldNameOmittedWhenFieldNameNull() {
        ToStringStyle style = new ToStringStyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, null, "value", Boolean.TRUE);
        assertEquals("value,", buffer.toString());
    }

    public void testAppendCollectionDetail() {
        ToStringStyle style = new ToStringStyleImpl();
        StringBuffer buffer = new StringBuffer();
        List<String> list = new ArrayList<String>();
        list.add("a");
        list.add("b");
        style.append(buffer, "items", list, Boolean.TRUE);
        assertEquals("items=[a, b],", buffer.toString());
    }

    public void testAppendCollectionSummary() {
        ToStringStyle style = new ToStringStyleImpl();
        StringBuffer buffer = new StringBuffer();
        List<String> list = new ArrayList<String>();
        list.add("a");
        list.add("b");
        list.add("c");
        style.append(buffer, "items", list, Boolean.FALSE);
        assertEquals("items=<size=3>,", buffer.toString());
    }

    public void testAppendMapDetail() {
        ToStringStyle style = new ToStringStyleImpl();
        StringBuffer buffer = new StringBuffer();
        Map<String, String> map = new HashMap<String, String>();
        map.put("k", "v");
        style.append(buffer, "m", map, Boolean.TRUE);
        assertEquals("m={k=v},", buffer.toString());
    }

    public void testAppendMapSummary() {
        ToStringStyle style = new ToStringStyleImpl();
        StringBuffer buffer = new StringBuffer();
        Map<String, String> map = new HashMap<String, String>();
        map.put("k", "v");
        style.append(buffer, "m", map, Boolean.FALSE);
        assertEquals("m=<size=1>,", buffer.toString());
    }

    //-----------------------------------------------------------------------
    // primitive append methods
    //-----------------------------------------------------------------------

    public void testAppendLong() {
        ToStringStyle style = new ToStringStyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "age", 33L);
        assertEquals("age=33,", buffer.toString());
    }

    public void testAppendInt() {
        ToStringStyle style = new ToStringStyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "age", -7);
        assertEquals("age=-7,", buffer.toString());
    }

    public void testAppendShort() {
        ToStringStyle style = new ToStringStyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "age", (short) 5);
        assertEquals("age=5,", buffer.toString());
    }

    public void testAppendByte() {
        ToStringStyle style = new ToStringStyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "age", (byte) 2);
        assertEquals("age=2,", buffer.toString());
    }

    public void testAppendChar() {
        ToStringStyle style = new ToStringStyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "letter", 'z');
        assertEquals("letter=z,", buffer.toString());
    }

    public void testAppendDouble() {
        ToStringStyle style = new ToStringStyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "d", 1.5d);
        assertEquals("d=1.5,", buffer.toString());
    }

    public void testAppendFloat() {
        ToStringStyle style = new ToStringStyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "f", 2.5f);
        assertEquals("f=2.5,", buffer.toString());
    }

    public void testAppendBoolean() {
        ToStringStyle style = new ToStringStyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "smoker", false);
        assertEquals("smoker=false,", buffer.toString());
    }

    //-----------------------------------------------------------------------
    // arrays
    //-----------------------------------------------------------------------

    public void testAppendObjectArrayDetail() {
        ToStringStyle style = new ToStringStyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", new String[] {"a", "b"}, Boolean.TRUE);
        assertEquals("arr={a,b},", buffer.toString());
    }

    public void testAppendObjectArrayWithNullElement() {
        ToStringStyle style = new ToStringStyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", new String[] {null, "b"}, Boolean.TRUE);
        assertEquals("arr={<null>,b},", buffer.toString());
    }

    public void testAppendObjectArrayNull() {
        ToStringStyle style = new ToStringStyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", (Object[]) null, Boolean.TRUE);
        assertEquals("arr=<null>,", buffer.toString());
    }

    public void testAppendObjectArraySummary() {
        ToStringStyle style = new ToStringStyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", new String[] {"a", "b", "c"}, Boolean.FALSE);
        assertEquals("arr=<size=3>,", buffer.toString());
    }

    public void testAppendIntArrayDetailAndSummary() {
        ToStringStyle style = new ToStringStyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", new int[] {1, 2, 3}, Boolean.TRUE);
        assertEquals("arr={1,2,3},", buffer.toString());

        buffer = new StringBuffer();
        style.append(buffer, "arr", new int[] {1, 2, 3}, Boolean.FALSE);
        assertEquals("arr=<size=3>,", buffer.toString());
    }

    public void testAppendLongArrayDetail() {
        ToStringStyle style = new ToStringStyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", new long[] {1L, 2L}, Boolean.TRUE);
        assertEquals("arr={1,2},", buffer.toString());
    }

    public void testAppendShortArrayDetail() {
        ToStringStyle style = new ToStringStyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", new short[] {1, 2}, Boolean.TRUE);
        assertEquals("arr={1,2},", buffer.toString());
    }

    public void testAppendByteArrayDetail() {
        ToStringStyle style = new ToStringStyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", new byte[] {1, 2}, Boolean.TRUE);
        assertEquals("arr={1,2},", buffer.toString());
    }

    public void testAppendCharArrayDetail() {
        ToStringStyle style = new ToStringStyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", new char[] {'x', 'y'}, Boolean.TRUE);
        assertEquals("arr={x,y},", buffer.toString());
    }

    public void testAppendDoubleArrayDetail() {
        ToStringStyle style = new ToStringStyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", new double[] {1.0, 2.0}, Boolean.TRUE);
        assertEquals("arr={1.0,2.0},", buffer.toString());
    }

    public void testAppendFloatArrayDetail() {
        ToStringStyle style = new ToStringStyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", new float[] {1.0f, 2.0f}, Boolean.TRUE);
        assertEquals("arr={1.0,2.0},", buffer.toString());
    }

    public void testAppendBooleanArrayDetail() {
        ToStringStyle style = new ToStringStyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", new boolean[] {true, false}, Boolean.TRUE);
        assertEquals("arr={true,false},", buffer.toString());
    }

    public void testAppendEmptyArrayDetail() {
        ToStringStyle style = new ToStringStyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", new int[0], Boolean.TRUE);
        assertEquals("arr={},", buffer.toString());
    }

    //-----------------------------------------------------------------------
    // setters/getters boundary behavior (null -> empty string)
    //-----------------------------------------------------------------------

    public void testSetArrayStartNullBecomesEmpty() {
        ToStringStyleImpl style = new ToStringStyleImpl();
        assertEquals("{", style.getArrayStart());
        style.setArrayStart(null);
        assertEquals("", style.getArrayStart());
        style.setArrayStart("<<");
        assertEquals("<<", style.getArrayStart());
    }

    public void testSetArrayEndNullBecomesEmpty() {
        ToStringStyleImpl style = new ToStringStyleImpl();
        style.setArrayEnd(null);
        assertEquals("", style.getArrayEnd());
    }

    public void testSetArraySeparatorNullBecomesEmpty() {
        ToStringStyleImpl style = new ToStringStyleImpl();
        style.setArraySeparator(null);
        assertEquals("", style.getArraySeparator());
    }

    public void testSetContentStartNullBecomesEmpty() {
        ToStringStyleImpl style = new ToStringStyleImpl();
        assertEquals("[", style.getContentStart());
        style.setContentStart(null);
        assertEquals("", style.getContentStart());
    }

    public void testSetContentEndNullBecomesEmpty() {
        ToStringStyleImpl style = new ToStringStyleImpl();
        assertEquals("]", style.getContentEnd());
        style.setContentEnd(null);
        assertEquals("", style.getContentEnd());
    }

    public void testSetFieldNameValueSeparatorNullBecomesEmpty() {
        ToStringStyleImpl style = new ToStringStyleImpl();
        assertEquals("=", style.getFieldNameValueSeparator());
        style.setFieldNameValueSeparator(null);
        assertEquals("", style.getFieldNameValueSeparator());
    }

    public void testSetFieldSeparatorNullBecomesEmpty() {
        ToStringStyleImpl style = new ToStringStyleImpl();
        assertEquals(",", style.getFieldSeparator());
        style.setFieldSeparator(null);
        assertEquals("", style.getFieldSeparator());
    }

    public void testSetNullTextNullBecomesEmpty() {
        ToStringStyleImpl style = new ToStringStyleImpl();
        assertEquals("<null>", style.getNullText());
        style.setNullText(null);
        assertEquals("", style.getNullText());
    }

    public void testSetSizeStartTextNullBecomesEmpty() {
        ToStringStyleImpl style = new ToStringStyleImpl();
        style.setSizeStartText(null);
        assertEquals("", style.getSizeStartText());
    }

    public void testSetSizeEndTextNullBecomesEmpty() {
        ToStringStyleImpl style = new ToStringStyleImpl();
        style.setSizeEndText(null);
        assertEquals("", style.getSizeEndText());
    }

    public void testSetSummaryObjectStartTextNullBecomesEmpty() {
        ToStringStyleImpl style = new ToStringStyleImpl();
        style.setSummaryObjectStartText(null);
        assertEquals("", style.getSummaryObjectStartText());
    }

    public void testSetSummaryObjectEndTextNullBecomesEmpty() {
        ToStringStyleImpl style = new ToStringStyleImpl();
        style.setSummaryObjectEndText(null);
        assertEquals("", style.getSummaryObjectEndText());
    }

    public void testDefaultFlagValues() {
        ToStringStyleImpl style = new ToStringStyleImpl();
        assertTrue(style.isUseClassName());
        assertFalse(style.isUseShortClassName());
        assertTrue(style.isUseIdentityHashCode());
        assertTrue(style.isUseFieldNames());
        assertTrue(style.isDefaultFullDetail());
        assertTrue(style.isArrayContentDetail());
        assertFalse(style.isFieldSeparatorAtStart());
        assertFalse(style.isFieldSeparatorAtEnd());
    }

    public void testSettersUpdateFlags() {
        ToStringStyleImpl style = new ToStringStyleImpl();
        style.setUseClassName(false);
        assertFalse(style.isUseClassName());
        style.setUseShortClassName(true);
        assertTrue(style.isUseShortClassName());
        style.setUseIdentityHashCode(false);
        assertFalse(style.isUseIdentityHashCode());
        style.setUseFieldNames(false);
        assertFalse(style.isUseFieldNames());
        style.setDefaultFullDetail(false);
        assertFalse(style.isDefaultFullDetail());
        style.setArrayContentDetail(false);
        assertFalse(style.isArrayContentDetail());
        style.setFieldSeparatorAtStart(true);
        assertTrue(style.isFieldSeparatorAtStart());
        style.setFieldSeparatorAtEnd(true);
        assertTrue(style.isFieldSeparatorAtEnd());
    }

    //-----------------------------------------------------------------------
    // isFullDetail
    //-----------------------------------------------------------------------

    public void testIsFullDetailNullUsesDefaultTrue() {
        ToStringStyleImpl style = new ToStringStyleImpl();
        assertTrue(style.isFullDetail(null));
    }

    public void testIsFullDetailNullUsesDefaultFalse() {
        ToStringStyleImpl style = new ToStringStyleImpl();
        style.setDefaultFullDetail(false);
        assertFalse(style.isFullDetail(null));
    }

    public void testIsFullDetailExplicitValueOverridesDefault() {
        ToStringStyleImpl style = new ToStringStyleImpl();
        style.setDefaultFullDetail(false);
        assertTrue(style.isFullDetail(Boolean.TRUE));
        style.setDefaultFullDetail(true);
        assertFalse(style.isFullDetail(Boolean.FALSE));
    }

    //-----------------------------------------------------------------------
    // removeLastFieldSeparator
    //-----------------------------------------------------------------------

    public void testRemoveLastFieldSeparatorMatching() {
        ToStringStyleImpl style = new ToStringStyleImpl();
        StringBuffer buffer = new StringBuffer("abc,");
        style.removeLastFieldSeparator(buffer);
        assertEquals("abc", buffer.toString());
    }

    public void testRemoveLastFieldSeparatorNoMatch() {
        ToStringStyleImpl style = new ToStringStyleImpl();
        StringBuffer buffer = new StringBuffer("abcd");
        style.removeLastFieldSeparator(buffer);
        assertEquals("abcd", buffer.toString());
    }

    public void testRemoveLastFieldSeparatorEmptyBuffer() {
        ToStringStyleImpl style = new ToStringStyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.removeLastFieldSeparator(buffer);
        assertEquals("", buffer.toString());
    }

    public void testRemoveLastFieldSeparatorBufferShorterThanSeparator() {
        ToStringStyleImpl style = new ToStringStyleImpl();
        style.setFieldSeparator("###");
        StringBuffer buffer = new StringBuffer("a");
        style.removeLastFieldSeparator(buffer);
        assertEquals("a", buffer.toString());
    }

    public void testRemoveLastFieldSeparatorEmptySeparatorNoOp() {
        ToStringStyleImpl style = new ToStringStyleImpl();
        style.setFieldSeparator(null);
        StringBuffer buffer = new StringBuffer("abc");
        style.removeLastFieldSeparator(buffer);
        assertEquals("abc", buffer.toString());
    }

    //-----------------------------------------------------------------------
    // appendFieldStart / appendFieldSeparator / appendNullText / appendSummarySize
    //-----------------------------------------------------------------------

    public void testAppendFieldSeparator() {
        ToStringStyleImpl style = new ToStringStyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.appendFieldSeparator(buffer);
        assertEquals(",", buffer.toString());
    }

    public void testAppendNullTextCustom() {
        ToStringStyleImpl style = new ToStringStyleImpl();
        style.setNullText("NULL");
        StringBuffer buffer = new StringBuffer();
        style.appendNullText(buffer, "field");
        assertEquals("NULL", buffer.toString());
    }

    public void testAppendSummarySize() {
        ToStringStyleImpl style = new ToStringStyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.appendSummarySize(buffer, "field", 42);
        assertEquals("<size=42>", buffer.toString());
    }

    //-----------------------------------------------------------------------
    // appendClassName / appendIdentityHashCode / getShortClassName
    //-----------------------------------------------------------------------

    public void testAppendClassNameFullWhenUseClassNameTrue() {
        ToStringStyleImpl style = new ToStringStyleImpl();
        StringBuffer buffer = new StringBuffer();
        Object obj = "hello";
        style.appendClassName(buffer, obj);
        assertEquals(String.class.getName(), buffer.toString());
    }

    public void testAppendClassNameOmittedWhenUseClassNameFalse() {
        ToStringStyleImpl style = new ToStringStyleImpl();
        style.setUseClassName(false);
        StringBuffer buffer = new StringBuffer();
        style.appendClassName(buffer, "hello");
        assertEquals("", buffer.toString());
    }

    public void testAppendClassNameShort() {
        ToStringStyleImpl style = new ToStringStyleImpl();
        style.setUseShortClassName(true);
        StringBuffer buffer = new StringBuffer();
        style.appendClassName(buffer, "hello");
        assertEquals("String", buffer.toString());
    }

    public void testAppendIdentityHashCodeOmittedWhenFlagFalse() {
        ToStringStyleImpl style = new ToStringStyleImpl();
        style.setUseIdentityHashCode(false);
        StringBuffer buffer = new StringBuffer();
        style.appendIdentityHashCode(buffer, "hello");
        assertEquals("", buffer.toString());
    }

    public void testAppendIdentityHashCodePresentByDefault() {
        ToStringStyleImpl style = new ToStringStyleImpl();
        StringBuffer buffer = new StringBuffer();
        Object obj = new Object();
        style.appendIdentityHashCode(buffer, obj);
        String expected = "@" + Integer.toHexString(System.identityHashCode(obj));
        assertEquals(expected, buffer.toString());
    }

    public void testGetShortClassName() {
        ToStringStyleImpl style = new ToStringStyleImpl();
        assertEquals("String", style.getShortClassName(String.class));
    }

    //-----------------------------------------------------------------------
    // appendCyclicObject / register / isRegistered via appendInternal
    //-----------------------------------------------------------------------

    public void testAppendCyclicObjectUsesIdentityToString() {
        ToStringStyleImpl style = new ToStringStyleImpl();
        StringBuffer buffer = new StringBuffer();
        Object obj = new Object();
        style.appendCyclicObject(buffer, "field", obj);
        String expected = obj.getClass().getName() + "@" + Integer.toHexString(System.identityHashCode(obj));
        assertEquals(expected, buffer.toString());
    }

    public void testAppendInternalDetectsCycle() {
        ToStringStyleImpl style = new ToStringStyleImpl();
        Object obj = new ArrayList<Object>();
        ToStringStyle.register(obj);
        try {
            StringBuffer buffer = new StringBuffer();
            style.append(buffer, "field", obj, Boolean.TRUE);
            String expected = "field=" + obj.getClass().getName()
                    + "@" + Integer.toHexString(System.identityHashCode(obj)) + ",";
            assertEquals(expected, buffer.toString());
        } finally {
            ToStringStyle.unregister(obj);
        }
    }

    public void testRegisterAndIsRegisteredAndUnregister() {
        Object obj = new Object();
        assertFalse(ToStringStyle.isRegistered(obj));
        ToStringStyle.register(obj);
        assertTrue(ToStringStyle.isRegistered(obj));
        ToStringStyle.unregister(obj);
        assertFalse(ToStringStyle.isRegistered(obj));
    }

    //-----------------------------------------------------------------------
    // reflectionAppendArrayDetail
    //-----------------------------------------------------------------------

    public void testReflectionAppendArrayDetail() {
        ToStringStyleImpl style = new ToStringStyleImpl();
        StringBuffer buffer = new StringBuffer();
        style.reflectionAppendArrayDetail(buffer, "arr", new int[] {7, 8, 9});
        assertEquals("{7,8,9}", buffer.toString());
    }

    //-----------------------------------------------------------------------
    // full round trip using the Person fixture, similar to real usage
    //-----------------------------------------------------------------------

    static class Person {
        String name;
        int age;
        boolean smoker;
    }

    public void testFullToStringBuildUp() {
        ToStringStyleImpl style = new ToStringStyleImpl();
        Person p = new Person();
        p.name = "John Doe";
        p.age = 33;
        p.smoker = false;

        StringBuffer buffer = new StringBuffer();
        style.appendStart(buffer, p);
        style.append(buffer, "name", p.name, Boolean.TRUE);
        style.append(buffer, "age", p.age);
        style.append(buffer, "smoker", p.smoker);
        style.appendEnd(buffer, p);

        String result = buffer.toString();
        assertTrue(result.startsWith(Person.class.getName()));
        assertTrue(result.indexOf("name=John Doe") >= 0);
        assertTrue(result.indexOf("age=33") >= 0);
        assertTrue(result.indexOf("smoker=false") >= 0);
        assertTrue(result.endsWith("]"));
        assertFalse(result.endsWith(",]"));
    }
}
