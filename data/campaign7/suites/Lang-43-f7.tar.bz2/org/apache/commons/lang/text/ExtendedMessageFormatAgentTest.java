package org.apache.commons.lang.text;

import java.lang.reflect.Method;
import java.text.FieldPosition;
import java.text.Format;
import java.text.ParsePosition;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import junit.framework.TestCase;

/**
 * Self-contained tests for {@link ExtendedMessageFormat}.
 */
public class ExtendedMessageFormatAgentTest extends TestCase {

    public ExtendedMessageFormatAgentTest(String name) {
        super(name);
    }

    /** Lower-cases whatever is given to it; used to verify custom format wiring. */
    private static final class LowerCaseFormat extends Format {
        public StringBuffer format(Object obj, StringBuffer toAppendTo, FieldPosition pos) {
            return toAppendTo.append(String.valueOf(obj).toLowerCase());
        }
        public Object parseObject(String source, ParsePosition pos) {
            return source;
        }
    }

    /** FormatFactory that always hands back a LowerCaseFormat, ignoring args. */
    private static final class LowerCaseFormatFactory implements FormatFactory {
        public Format getFormat(String name, String arguments, Locale locale) {
            return new LowerCaseFormat();
        }
    }

    /** FormatFactory that records the name/arguments/locale it was invoked with. */
    private static final class CapturingFormatFactory implements FormatFactory {
        String capturedName;
        String capturedArguments;
        Locale capturedLocale;

        public Format getFormat(String name, String arguments, Locale locale) {
            this.capturedName = name;
            this.capturedArguments = arguments;
            this.capturedLocale = locale;
            return new EchoFormat();
        }
    }

    /** Wraps the value with markers so we can tell the custom format was used. */
    private static final class EchoFormat extends Format {
        public StringBuffer format(Object obj, StringBuffer toAppendTo, FieldPosition pos) {
            return toAppendTo.append("<<").append(obj).append(">>");
        }
        public Object parseObject(String source, ParsePosition pos) {
            return source;
        }
    }

    // ------------------------------------------------------------------
    // Construction / basic contract
    // ------------------------------------------------------------------

    public void testDefaultLocaleConstructorUsesDefaultLocale() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertEquals(Locale.getDefault(), emf.getLocale());
    }

    public void testLocaleConstructorStoresGivenLocale() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", Locale.GERMANY);
        assertEquals(Locale.GERMANY, emf.getLocale());
    }

    // ------------------------------------------------------------------
    // No registry / plain MessageFormat behaviour
    // ------------------------------------------------------------------

    public void testNoRegistryFormatsLikeStandardMessageFormat() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0} and {1,number}");
        String result = emf.format(new Object[] { "x", new Integer(7) });
        assertEquals("x and 7", result);
    }

    public void testNoRegistryToPatternRoundTrips() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0} and {1,number}");
        assertEquals("{0} and {1,number}", emf.toPattern());
    }

    public void testEmptyRegistryBehavesLikeNoRegistry() {
        Map emptyRegistry = new HashMap();
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0} plain", emptyRegistry);
        assertEquals("{0} plain", emf.toPattern());
        assertEquals("Z plain", emf.format(new Object[] { "Z" }));
    }

    // ------------------------------------------------------------------
    // Custom formats via registry
    // ------------------------------------------------------------------

    public void testCustomFormatIsAppliedDuringFormat() {
        Map registry = new HashMap();
        registry.put("lower", new LowerCaseFormatFactory());
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,lower}", registry);
        assertEquals("abc", emf.format(new Object[] { "ABC" }));
    }

    public void testCustomFormatToPatternIncludesFormatName() {
        Map registry = new HashMap();
        registry.put("lower", new LowerCaseFormatFactory());
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,lower}", registry);
        assertEquals("{0,lower}", emf.toPattern());
    }

    public void testMixedCustomAndStandardFormatsInSamePattern() {
        Map registry = new HashMap();
        registry.put("lower", new LowerCaseFormatFactory());
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,lower} and {1,number}", registry);
        assertEquals("abc and 42", emf.format(new Object[] { "ABC", new Integer(42) }));
        assertEquals("{0,lower} and {1,number}", emf.toPattern());
    }

    public void testUnknownRegistryNameFallsBackToStandardFormat() {
        Map registry = new HashMap();
        registry.put("lower", new LowerCaseFormatFactory());
        // "number" is not in the registry, so it must fall back to the
        // built-in MessageFormat handling instead of being treated as custom.
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number}", registry);
        assertEquals("42", emf.format(new Object[] { new Integer(42) }));
        assertEquals("{0,number}", emf.toPattern());
    }

    public void testFormatFactoryReceivesNameArgumentsAndLocale() {
        CapturingFormatFactory factory = new CapturingFormatFactory();
        Map registry = new HashMap();
        registry.put("custom", factory);
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,custom,some style}", Locale.FRANCE, registry);
        assertEquals("custom", factory.capturedName);
        assertEquals("some style", factory.capturedArguments);
        assertEquals(Locale.FRANCE, factory.capturedLocale);
        assertEquals("<<V>>", emf.format(new Object[] { "V" }));
        assertEquals("{0,custom,some style}", emf.toPattern());
    }

    public void testMultiDigitArgumentIndexIsParsedCorrectly() {
        CapturingFormatFactory factory = new CapturingFormatFactory();
        Map registry = new HashMap();
        registry.put("custom", factory);
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{10,custom}", registry);
        assertEquals("{10,custom}", emf.toPattern());
    }

    // ------------------------------------------------------------------
    // Disabled mutators
    // ------------------------------------------------------------------

    public void testSetFormatThrowsUnsupportedOperationException() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        try {
            emf.setFormat(0, new LowerCaseFormat());
            fail("expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // ok
        }
    }

    public void testSetFormatByArgumentIndexThrowsUnsupportedOperationException() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        try {
            emf.setFormatByArgumentIndex(0, new LowerCaseFormat());
            fail("expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // ok
        }
    }

    public void testSetFormatsThrowsUnsupportedOperationException() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        try {
            emf.setFormats(new Format[] { new LowerCaseFormat() });
            fail("expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // ok
        }
    }

    public void testSetFormatsByArgumentIndexThrowsUnsupportedOperationException() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        try {
            emf.setFormatsByArgumentIndex(new Format[] { new LowerCaseFormat() });
            fail("expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // ok
        }
    }

    public void testFormatStillWorksAfterRejectedMutationAttempt() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        try {
            emf.setFormat(0, new LowerCaseFormat());
        } catch (UnsupportedOperationException expected) {
            // ok
        }
        // state must be unaffected by the rejected mutation attempt
        assertEquals("hello", emf.format(new Object[] { "hello" }));
    }

    // ------------------------------------------------------------------
    // Malformed patterns
    // ------------------------------------------------------------------

    public void testUnterminatedFormatElementThrows() {
        Map registry = new HashMap();
        registry.put("custom", new LowerCaseFormatFactory());
        try {
            new ExtendedMessageFormat("{0,custom", registry);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // ok
        }
    }

    public void testUnterminatedBareArgumentIndexThrows() {
        Map registry = new HashMap();
        registry.put("custom", new LowerCaseFormatFactory());
        try {
            new ExtendedMessageFormat("{0", registry);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // ok
        }
    }

    public void testNonDigitInArgumentIndexThrows() {
        Map registry = new HashMap();
        registry.put("custom", new LowerCaseFormatFactory());
        try {
            new ExtendedMessageFormat("{0a,custom}", registry);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // ok
        }
    }

    public void testMissingArgumentIndexDigitsThrows() {
        Map registry = new HashMap();
        registry.put("custom", new LowerCaseFormatFactory());
        try {
            new ExtendedMessageFormat("{,custom}", registry);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // ok
        }
    }

    public void testNoRegistryToleratesUnterminatedQuote() {
        // No registry: parsing is delegated straight to java.text.MessageFormat,
        // which treats a dangling quote as running to the end of the pattern
        // rather than raising an error.
        ExtendedMessageFormat emf = new ExtendedMessageFormat("'unterminated");
        assertEquals("unterminated", emf.toPattern());
        assertEquals("unterminated", emf.format(new Object[0]));
    }

    // ------------------------------------------------------------------
    // Bug: quoted text in the pattern is mishandled whenever a registry is
    // supplied. ExtendedMessageFormat.appendQuotedString(pattern, pos, sb, true)
    // is called by applyPattern() at the exact position of the opening quote.
    // Its very first check - "if escapingOn and the current character is a
    // quote, append a quote and return" - fires unconditionally in that case
    // (the current character always *is* the opening quote being handled), so
    // the method returns immediately without advancing the parse position or
    // consuming the quoted text. The caller's parsing loop therefore never
    // moves past that character and spins forever re-appending the quote to
    // its buffer. In practice this means: *any* pattern containing a single
    // quote character, used together with a non-null format registry, hangs
    // applyPattern() in an infinite loop (observed to run the heap out of
    // memory rather than ever return or throw). We exercise the faulty
    // method directly via reflection so the defect can be demonstrated
    // without hanging/crashing the test JVM.
    // ------------------------------------------------------------------

    public void testAppendQuotedStringAdvancesPastLeadingQuote() throws Exception {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        Method m = ExtendedMessageFormat.class.getDeclaredMethod("appendQuotedString",
                new Class[] { String.class, ParsePosition.class, StringBuffer.class, boolean.class });
        m.setAccessible(true);

        String pattern = "'x' rest";
        ParsePosition pos = new ParsePosition(0);
        StringBuffer appendTo = new StringBuffer();

        m.invoke(emf, new Object[] { pattern, pos, appendTo, Boolean.TRUE });

        // A correctly behaving call must consume the whole quoted section
        // "'x'" (positions 0..2 inclusive) and land the parse position just
        // past the closing quote, having appended the unquoted text "x".
        assertTrue("parse position must advance past the quoted text, but stayed at "
                + pos.getIndex(), pos.getIndex() > 0);
        assertEquals("x", appendTo.toString());
    }

    // NOTE: an end-to-end test such as
    //   new ExtendedMessageFormat("a 'quoted' bit {0,lower}", registry)
    // would demonstrate the same defect through the public API, but it
    // never returns and exhausts the heap, so it is intentionally not
    // exercised here; the reflection-based test above isolates the same
    // root cause safely.
}
