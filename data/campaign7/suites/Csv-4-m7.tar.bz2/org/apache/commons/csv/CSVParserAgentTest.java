/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.csv;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.junit.Test;

public class CSVParserAgentTest {

    @Test
    public void testConstructorRejectsNullReader() throws IOException {
        try {
            new CSVParser(null, CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    public void testConstructorRejectsNullFormat() throws IOException {
        try {
            new CSVParser(new StringReader("a,b"), null);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    public void testParseStringRejectsNullString() throws IOException {
        try {
            CSVParser.parse((String) null, CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    public void testParseFileRejectsNullFile() throws IOException {
        try {
            CSVParser.parse((File) null, CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    public void testGetRecordsSimple() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b,c\n1,2,3\n", CSVFormat.DEFAULT);
        final List<CSVRecord> records = parser.getRecords();
        parser.close();

        assertEquals(2, records.size());

        final CSVRecord first = records.get(0);
        assertEquals(3, first.size());
        assertEquals("a", first.get(0));
        assertEquals("b", first.get(1));
        assertEquals("c", first.get(2));
        assertEquals(1, first.getRecordNumber());

        final CSVRecord second = records.get(1);
        assertEquals("1", second.get(0));
        assertEquals("2", second.get(1));
        assertEquals("3", second.get(2));
        assertEquals(2, second.getRecordNumber());
    }

    @Test
    public void testGetRecordsEmptyInput() throws IOException {
        final CSVParser parser = CSVParser.parse("", CSVFormat.DEFAULT);
        final List<CSVRecord> records = parser.getRecords();
        parser.close();

        assertTrue(records.isEmpty());
    }

    @Test
    public void testGetRecordNumberAndLineNumberTracking() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\nc,d\ne,f\n", CSVFormat.DEFAULT);
        try {
            assertEquals(0, parser.getRecordNumber());

            final CSVRecord r1 = parser.nextRecord();
            assertEquals(1, r1.getRecordNumber());
            assertEquals(1, parser.getRecordNumber());
            assertEquals(1, parser.getCurrentLineNumber());

            final CSVRecord r2 = parser.nextRecord();
            assertEquals(2, r2.getRecordNumber());
            assertEquals(2, parser.getRecordNumber());

            final CSVRecord r3 = parser.nextRecord();
            assertEquals(3, r3.getRecordNumber());

            assertNull(parser.nextRecord());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testHeaderMapFromExplicitHeader() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("A", "B", "C");
        final CSVParser parser = CSVParser.parse("1,2,3\n4,5,6\n", format);
        try {
            final Map<String, Integer> headerMap = parser.getHeaderMap();
            assertEquals(Integer.valueOf(0), headerMap.get("A"));
            assertEquals(Integer.valueOf(1), headerMap.get("B"));
            assertEquals(Integer.valueOf(2), headerMap.get("C"));

            // Explicit header without skipHeaderRecord does NOT consume the first data line
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("1", records.get(0).get("A"));
            assertEquals("5", records.get(1).get("B"));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testHeaderMapFromFirstLineAutoDetected() throws IOException {
        // Empty varargs to withHeader() means: read header from first line
        final CSVFormat format = CSVFormat.DEFAULT.withHeader();
        final CSVParser parser = CSVParser.parse("name,age\nJohn,30\n", format);
        try {
            final Map<String, Integer> headerMap = parser.getHeaderMap();
            assertEquals(Integer.valueOf(0), headerMap.get("name"));
            assertEquals(Integer.valueOf(1), headerMap.get("age"));

            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("John", records.get(0).get("name"));
            assertEquals("30", records.get(0).get("age"));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testHeaderMapSkipHeaderRecord() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("A", "B").withSkipHeaderRecord(true);
        final CSVParser parser = CSVParser.parse("A,B\n1,2\n", format);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("1", records.get(0).get("A"));
            assertEquals("2", records.get(0).get("B"));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetHeaderMapNullWhenNoHeaderDefined() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n", CSVFormat.DEFAULT);
        try {
            assertNull(parser.getHeaderMap());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetHeaderMapIsACopy() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("A", "B");
        final CSVParser parser = CSVParser.parse("1,2\n", format);
        try {
            final Map<String, Integer> copy = parser.getHeaderMap();
            copy.put("Z", Integer.valueOf(99));
            assertFalse(parser.getHeaderMap().containsKey("Z"));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testIteratorHasNextAndNext() throws IOException {
        final CSVParser parser = CSVParser.parse("1,2\n3,4\n", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            assertTrue(it.hasNext());
            // Calling hasNext() repeatedly must not advance the iterator
            assertTrue(it.hasNext());
            final CSVRecord first = it.next();
            assertEquals("1", first.get(0));

            assertTrue(it.hasNext());
            final CSVRecord second = it.next();
            assertEquals("3", second.get(0));

            assertFalse(it.hasNext());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testIteratorNextWithoutHasNext() throws IOException {
        final CSVParser parser = CSVParser.parse("1,2\n", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            final CSVRecord record = it.next();
            assertEquals("1", record.get(0));
            assertEquals("2", record.get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testIteratorNextThrowsWhenExhausted() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            it.next();
            try {
                it.next();
                fail("Expected NoSuchElementException");
            } catch (final NoSuchElementException expected) {
                // expected
            }
        } finally {
            parser.close();
        }
    }

    @Test
    public void testIteratorRemoveUnsupported() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            try {
                it.remove();
                fail("Expected UnsupportedOperationException");
            } catch (final UnsupportedOperationException expected) {
                // expected
            }
        } finally {
            parser.close();
        }
    }

    @Test
    public void testCloseMakesParserClosedAndIteratorExhausted() throws IOException {
        final CSVParser parser = CSVParser.parse("1,2\n3,4\n", CSVFormat.DEFAULT);
        assertFalse(parser.isClosed());
        parser.close();
        assertTrue(parser.isClosed());

        final Iterator<CSVRecord> it = parser.iterator();
        assertFalse(it.hasNext());
        try {
            it.next();
            fail("Expected NoSuchElementException after close");
        } catch (final NoSuchElementException expected) {
            // expected
        }
    }

    @Test
    public void testCloseIsIdempotent() throws IOException {
        final CSVParser parser = CSVParser.parse("a\n", CSVFormat.DEFAULT);
        parser.close();
        parser.close();
        assertTrue(parser.isClosed());
    }

    @Test
    public void testNullStringConvertsMatchingTokenToNull() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withNullString("NULL");
        final CSVParser parser = CSVParser.parse("a,NULL,c\n", format);
        try {
            final CSVRecord record = parser.nextRecord();
            assertEquals("a", record.get(0));
            assertNull(record.get(1));
            assertEquals("c", record.get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testCommentsAreAttachedToFollowingRecord() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withCommentStart('#');
        final CSVParser parser = CSVParser.parse("# comment line\na,b,c\n", format);
        try {
            final CSVRecord record = parser.nextRecord();
            assertEquals("comment line", record.getComment());
            assertEquals("a", record.get(0));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testUnterminatedQuoteThrowsIOException() throws IOException {
        final CSVParser parser = CSVParser.parse("\"unterminated", CSVFormat.DEFAULT);
        try {
            parser.nextRecord();
            fail("Expected IOException for unterminated quoted value");
        } catch (final IOException expected) {
            assertTrue(expected.getMessage().contains("EOF"));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testParseFileFactory() throws IOException {
        final File file = File.createTempFile("CSVParserAgentTest", ".csv");
        file.deleteOnExit();
        final java.io.FileWriter writer = new java.io.FileWriter(file);
        writer.write("x,y\n1,2\n");
        writer.close();

        final CSVParser parser = CSVParser.parse(file, CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("x", records.get(0).get(0));
            assertEquals("1", records.get(1).get(0));
        } finally {
            parser.close();
            file.delete();
        }
    }

    @Test
    public void testGetRecordsStartsFromCurrentPosition() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n2\n3\n", CSVFormat.DEFAULT);
        try {
            final CSVRecord first = parser.nextRecord();
            assertEquals("1", first.get(0));

            final List<CSVRecord> remaining = parser.getRecords();
            assertEquals(2, remaining.size());
            assertEquals("2", remaining.get(0).get(0));
            assertEquals("3", remaining.get(1).get(0));
        } finally {
            parser.close();
        }
    }
}
