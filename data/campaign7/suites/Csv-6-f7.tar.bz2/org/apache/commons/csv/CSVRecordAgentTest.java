/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.csv;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.junit.Test;

/**
 * Self-contained tests for {@link CSVRecord}.
 */
public class CSVRecordAgentTest {

    private enum Header {
        NAME, AGE
    }

    private static Map<String, Integer> headerMapping() {
        final Map<String, Integer> mapping = new HashMap<String, Integer>();
        mapping.put("NAME", Integer.valueOf(0));
        mapping.put("AGE", Integer.valueOf(1));
        return mapping;
    }

    @Test
    public void testGetByIndex() {
        final CSVRecord record = new CSVRecord(new String[] { "John", "30" }, null, null, 1L);
        assertEquals("John", record.get(0));
        assertEquals("30", record.get(1));
    }

    @Test
    public void testGetByIndexOutOfBounds() {
        final CSVRecord record = new CSVRecord(new String[] { "John" }, null, null, 1L);
        try {
            record.get(1);
            fail("Expected IndexOutOfBoundsException");
        } catch (final IndexOutOfBoundsException e) {
            // expected
        }
    }

    @Test
    public void testGetByIndexNegative() {
        final CSVRecord record = new CSVRecord(new String[] { "John" }, null, null, 1L);
        try {
            record.get(-1);
            fail("Expected IndexOutOfBoundsException");
        } catch (final IndexOutOfBoundsException e) {
            // expected
        }
    }

    @Test
    public void testGetByName() {
        final CSVRecord record = new CSVRecord(new String[] { "John", "30" }, headerMapping(), null, 1L);
        assertEquals("John", record.get("NAME"));
        assertEquals("30", record.get("AGE"));
    }

    @Test
    public void testGetByNameNoMapping() {
        final CSVRecord record = new CSVRecord(new String[] { "John", "30" }, null, null, 1L);
        try {
            record.get("NAME");
            fail("Expected IllegalStateException");
        } catch (final IllegalStateException e) {
            // expected
        }
    }

    @Test
    public void testGetByNameUnmappedName() {
        final CSVRecord record = new CSVRecord(new String[] { "John", "30" }, headerMapping(), null, 1L);
        try {
            record.get("UNKNOWN");
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testGetByNameInconsistentRecord() {
        // mapping expects index 1 (AGE) but values array only has one element
        final CSVRecord record = new CSVRecord(new String[] { "John" }, headerMapping(), null, 1L);
        try {
            record.get("AGE");
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testGetByEnum() {
        final CSVRecord record = new CSVRecord(new String[] { "John", "30" }, headerMapping(), null, 1L);
        assertEquals("John", record.get(Header.NAME));
        assertEquals("30", record.get(Header.AGE));
    }

    @Test
    public void testGetComment() {
        final CSVRecord record = new CSVRecord(new String[] { "a" }, null, "a comment", 1L);
        assertEquals("a comment", record.getComment());
    }

    @Test
    public void testGetCommentNull() {
        final CSVRecord record = new CSVRecord(new String[] { "a" }, null, null, 1L);
        assertNull(record.getComment());
    }

    @Test
    public void testGetRecordNumber() {
        final CSVRecord record = new CSVRecord(new String[] { "a" }, null, null, 42L);
        assertEquals(42L, record.getRecordNumber());
    }

    @Test
    public void testIsConsistentNullMapping() {
        final CSVRecord record = new CSVRecord(new String[] { "a", "b" }, null, null, 1L);
        assertTrue(record.isConsistent());
    }

    @Test
    public void testIsConsistentMatchingMapping() {
        final CSVRecord record = new CSVRecord(new String[] { "John", "30" }, headerMapping(), null, 1L);
        assertTrue(record.isConsistent());
    }

    @Test
    public void testIsConsistentMismatchedMapping() {
        final CSVRecord record = new CSVRecord(new String[] { "John" }, headerMapping(), null, 1L);
        assertFalse(record.isConsistent());
    }

    @Test
    public void testIsMappedTrueAndFalse() {
        final CSVRecord record = new CSVRecord(new String[] { "John", "30" }, headerMapping(), null, 1L);
        assertTrue(record.isMapped("NAME"));
        assertFalse(record.isMapped("UNKNOWN"));
    }

    @Test
    public void testIsMappedNullMapping() {
        final CSVRecord record = new CSVRecord(new String[] { "John" }, null, null, 1L);
        assertFalse(record.isMapped("NAME"));
    }

    @Test
    public void testIsSetTrue() {
        final CSVRecord record = new CSVRecord(new String[] { "John", "30" }, headerMapping(), null, 1L);
        assertTrue(record.isSet("NAME"));
        assertTrue(record.isSet("AGE"));
    }

    @Test
    public void testIsSetFalseWhenNotMapped() {
        final CSVRecord record = new CSVRecord(new String[] { "John", "30" }, headerMapping(), null, 1L);
        assertFalse(record.isSet("UNKNOWN"));
    }

    @Test
    public void testIsSetFalseWhenMappedButMissingValue() {
        // AGE maps to index 1, but only one value present
        final CSVRecord record = new CSVRecord(new String[] { "John" }, headerMapping(), null, 1L);
        assertFalse(record.isSet("AGE"));
    }

    @Test
    public void testIterator() {
        final CSVRecord record = new CSVRecord(new String[] { "John", "30" }, null, null, 1L);
        final Iterator<String> it = record.iterator();
        assertTrue(it.hasNext());
        assertEquals("John", it.next());
        assertTrue(it.hasNext());
        assertEquals("30", it.next());
        assertFalse(it.hasNext());
    }

    @Test
    public void testSize() {
        final CSVRecord record = new CSVRecord(new String[] { "a", "b", "c" }, null, null, 1L);
        assertEquals(3, record.size());
    }

    @Test
    public void testSizeNullValues() {
        final CSVRecord record = new CSVRecord(null, null, null, 1L);
        assertEquals(0, record.size());
    }

    @Test
    public void testToMap() {
        final CSVRecord record = new CSVRecord(new String[] { "John", "30" }, headerMapping(), null, 1L);
        final Map<String, String> map = record.toMap();
        assertEquals(2, map.size());
        assertEquals("John", map.get("NAME"));
        assertEquals("30", map.get("AGE"));
    }

    @Test
    public void testToMapNullMappingIsEmpty() {
        // Javadoc: "A new Map. The map is empty if the record has no headers."
        final CSVRecord record = new CSVRecord(new String[] { "John", "30" }, null, null, 1L);
        final Map<String, String> map = record.toMap();
        assertTrue(map.isEmpty());
    }

    @Test
    public void testToString() {
        final CSVRecord record = new CSVRecord(new String[] { "a", "b" }, null, null, 1L);
        assertEquals("[a, b]", record.toString());
    }

    @Test
    public void testValues() {
        final String[] values = new String[] { "a", "b" };
        final CSVRecord record = new CSVRecord(values, null, null, 1L);
        final String[] result = record.values();
        assertEquals(2, result.length);
        assertEquals("a", result[0]);
        assertEquals("b", result[1]);
    }

    @Test
    public void testPutIn() {
        final CSVRecord record = new CSVRecord(new String[] { "John", "30" }, headerMapping(), null, 1L);
        final Map<String, String> map = new HashMap<String, String>();
        final Map<String, String> result = record.putIn(map);
        assertTrue(result == map);
        assertEquals("John", map.get("NAME"));
        assertEquals("30", map.get("AGE"));
    }
}
