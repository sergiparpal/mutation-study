/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.NotSerializableException;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

/**
 * Self-contained unit tests for {@link org.apache.commons.lang3.SerializationUtils}.
 */
public class SerializationUtilsAgentTest {

    /**
     * Simple serializable fixture with a working equals/hashCode so clones
     * can be compared for value equality.
     */
    private static class Fixture implements Serializable {
        private static final long serialVersionUID = 1L;
        private final String name;
        private final int value;

        Fixture(String name, int value) {
            this.name = name;
            this.value = value;
        }

        @Override
        public boolean equals(Object obj) {
            if (!(obj instanceof Fixture)) {
                return false;
            }
            Fixture other = (Fixture) obj;
            return value == other.value
                    && (name == null ? other.name == null : name.equals(other.name));
        }

        @Override
        public int hashCode() {
            return value;
        }
    }

    /**
     * Implements Serializable but holds a non-serializable field, so any
     * attempt to serialize it must fail.
     */
    private static class NotActuallySerializable implements Serializable {
        private static final long serialVersionUID = 1L;
        @SuppressWarnings("unused")
        private final Object notSerializable = new Object();
    }

    // clone()
    //-----------------------------------------------------------------------

    @Test
    public void testCloneNull() {
        assertNull(SerializationUtils.clone(null));
    }

    @Test
    public void testCloneSimpleValue() {
        Integer original = new Integer(123);
        Integer cloned = SerializationUtils.clone(original);
        assertEquals(original, cloned);
    }

    @Test
    public void testCloneProducesDistinctEqualObject() {
        Fixture original = new Fixture("alice", 42);
        Fixture cloned = SerializationUtils.clone(original);
        assertEquals(original, cloned);
        assertNotSame(original, cloned);
    }

    @Test
    public void testCloneDeepClonesMutableState() {
        ArrayList<String> list = new ArrayList<String>();
        list.add("a");
        list.add("b");
        ArrayList<?> cloned = SerializationUtils.clone(list);
        assertEquals(list, cloned);
        assertNotSame(list, cloned);
        list.add("c");
        assertEquals(2, cloned.size());
    }

    @Test
    public void testCloneUnserializableThrowsSerializationException() {
        try {
            SerializationUtils.clone(new NotActuallySerializable());
            fail("Expected SerializationException");
        } catch (SerializationException expected) {
            assertTrue(expected.getCause() instanceof NotSerializableException);
        }
    }

    // serialize(Serializable, OutputStream)
    //-----------------------------------------------------------------------

    @Test
    public void testSerializeToStreamNullOutputStreamThrows() {
        try {
            SerializationUtils.serialize(new Fixture("x", 1), null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    public void testSerializeNullObjectToStream() {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        SerializationUtils.serialize(null, baos);
        Object result = SerializationUtils.deserialize(baos.toByteArray());
        assertNull(result);
    }

    @Test
    public void testSerializeToStreamClosesStream() {
        final boolean[] closed = new boolean[1];
        final ByteArrayOutputStream delegate = new ByteArrayOutputStream();
        OutputStream wrapper = new OutputStream() {
            @Override
            public void write(int b) {
                delegate.write(b);
            }

            @Override
            public void close() {
                closed[0] = true;
            }
        };
        SerializationUtils.serialize(new Fixture("y", 2), wrapper);
        assertTrue("stream should be closed after serialize()", closed[0]);
    }

    @Test
    public void testSerializeUnserializableToStreamThrows() {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try {
            SerializationUtils.serialize(new NotActuallySerializable(), baos);
            fail("Expected SerializationException");
        } catch (SerializationException expected) {
            assertTrue(expected.getCause() instanceof NotSerializableException);
        }
    }

    // serialize(Serializable) -> byte[]
    //-----------------------------------------------------------------------

    @Test
    public void testSerializeByteArrayRoundTrip() {
        Fixture original = new Fixture("bob", 7);
        byte[] data = SerializationUtils.serialize(original);
        assertNotNull(data);
        assertTrue(data.length > 0);
        Object result = SerializationUtils.deserialize(data);
        assertEquals(original, result);
    }

    @Test
    public void testSerializeNullToByteArray() {
        byte[] data = SerializationUtils.serialize(null);
        assertNotNull(data);
        assertNull(SerializationUtils.deserialize(data));
    }

    // deserialize(InputStream)
    //-----------------------------------------------------------------------

    @Test
    public void testDeserializeNullInputStreamThrows() {
        try {
            SerializationUtils.deserialize((java.io.InputStream) null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    public void testDeserializeFromStreamRoundTrip() {
        Fixture original = new Fixture("carol", 99);
        byte[] data = SerializationUtils.serialize(original);
        Object result = SerializationUtils.deserialize(new ByteArrayInputStream(data));
        assertEquals(original, result);
    }

    @Test
    public void testDeserializeGarbageStreamThrowsSerializationException() {
        byte[] garbage = new byte[] {1, 2, 3, 4, 5};
        try {
            SerializationUtils.deserialize(new ByteArrayInputStream(garbage));
            fail("Expected SerializationException");
        } catch (SerializationException expected) {
            // expected
        }
    }

    // deserialize(byte[])
    //-----------------------------------------------------------------------

    @Test
    public void testDeserializeNullByteArrayThrows() {
        try {
            SerializationUtils.deserialize((byte[]) null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    public void testDeserializeEmptyByteArrayThrowsSerializationException() {
        try {
            SerializationUtils.deserialize(new byte[0]);
            fail("Expected SerializationException");
        } catch (SerializationException expected) {
            // expected
        }
    }

    @Test
    public void testDeserializeTruncatedByteArrayThrowsSerializationException() {
        byte[] data = SerializationUtils.serialize(new Fixture("dan", 5));
        byte[] truncated = new byte[data.length - 2];
        System.arraycopy(data, 0, truncated, 0, truncated.length);
        try {
            SerializationUtils.deserialize(truncated);
            fail("Expected SerializationException");
        } catch (SerializationException expected) {
            // expected
        }
    }

    @Test
    public void testDeserializeMapRoundTrip() {
        Map<String, Integer> map = new HashMap<String, Integer>();
        map.put("one", new Integer(1));
        map.put("two", new Integer(2));
        byte[] data = SerializationUtils.serialize((Serializable) map);
        Object result = SerializationUtils.deserialize(data);
        assertEquals(map, result);
        assertNotSame(map, result);
    }

    // constructor
    //-----------------------------------------------------------------------

    @Test
    public void testConstructorIsPublic() {
        assertNotNull(new SerializationUtils());
        assertFalse(java.lang.reflect.Modifier.isFinal(SerializationUtils.class.getModifiers()));
    }
}
