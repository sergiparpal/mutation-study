/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang.time;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.FieldPosition;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

import junit.framework.TestCase;

/**
 * Self-contained test case for {@link FastDateFormat}.
 */
public class FastDateFormatAgentTest extends TestCase {

    public FastDateFormatAgentTest(String name) {
        super(name);
    }

    private static final TimeZone GMT = TimeZone.getTimeZone("GMT");

    private Calendar newCalendar(int year, int month, int day, int hour, int minute, int second) {
        Calendar cal = new GregorianCalendar(GMT, Locale.US);
        cal.clear();
        cal.set(year, month, day, hour, minute, second);
        return cal;
    }

    //-----------------------------------------------------------------------
    public void testGetInstanceDefault() {
        FastDateFormat format = FastDateFormat.getInstance();
        assertNotNull(format);
        assertNotNull(format.getPattern());
    }

    public void testGetInstanceCaching() {
        FastDateFormat format1 = FastDateFormat.getInstance("yyyy-MM-dd", GMT, Locale.US);
        FastDateFormat format2 = FastDateFormat.getInstance("yyyy-MM-dd", GMT, Locale.US);
        assertSame(format1, format2);

        FastDateFormat format3 = FastDateFormat.getInstance("yyyy-MM-dd", TimeZone.getTimeZone("GMT+1"), Locale.US);
        assertNotSame(format1, format3);
    }

    public void testGetInstanceNullPatternThrows() {
        try {
            FastDateFormat.getInstance(null);
            fail("Expected IllegalArgumentException for null pattern");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    public void testIllegalPatternLetterThrows() {
        try {
            FastDateFormat.getInstance("q");
            fail("Expected IllegalArgumentException for illegal pattern letter");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    public void testFormatDate() {
        FastDateFormat format = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss", GMT, Locale.US);
        Calendar cal = newCalendar(2005, Calendar.JANUARY, 1, 12, 30, 45);
        String result = format.format(cal.getTime());
        assertEquals("2005-01-01 12:30:45", result);
    }

    public void testFormatCalendar() {
        FastDateFormat format = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss", GMT, Locale.US);
        Calendar cal = newCalendar(2002, Calendar.FEBRUARY, 23, 9, 11, 12);
        String result = format.format(cal);
        assertEquals("2002-02-23 09:11:12", result);
    }

    public void testFormatLong() {
        FastDateFormat format = FastDateFormat.getInstance("yyyy-MM-dd", GMT, Locale.US);
        Calendar cal = newCalendar(2010, Calendar.JUNE, 15, 0, 0, 0);
        String result = format.format(cal.getTime().getTime());
        assertEquals("2010-06-15", result);
    }

    public void testFormatIntoStringBuffer() {
        FastDateFormat format = FastDateFormat.getInstance("yyyy", GMT, Locale.US);
        Calendar cal = newCalendar(1999, Calendar.MARCH, 3, 0, 0, 0);

        StringBuffer bufDate = new StringBuffer("X");
        StringBuffer resultDate = format.format(cal.getTime(), bufDate);
        assertSame(bufDate, resultDate);
        assertEquals("X1999", resultDate.toString());

        StringBuffer bufCal = new StringBuffer("Y");
        StringBuffer resultCal = format.format(cal, bufCal);
        assertSame(bufCal, resultCal);
        assertEquals("Y1999", resultCal.toString());

        StringBuffer bufLong = new StringBuffer("Z");
        StringBuffer resultLong = format.format(cal.getTime().getTime(), bufLong);
        assertSame(bufLong, resultLong);
        assertEquals("Z1999", resultLong.toString());
    }

    public void testFormatObjectDispatch() {
        FastDateFormat format = FastDateFormat.getInstance("yyyy-MM-dd", GMT, Locale.US);
        Calendar cal = newCalendar(2008, Calendar.JULY, 4, 0, 0, 0);

        StringBuffer buf1 = new StringBuffer();
        format.format((Object) cal.getTime(), buf1, new FieldPosition(0));
        assertEquals("2008-07-04", buf1.toString());

        StringBuffer buf2 = new StringBuffer();
        format.format((Object) cal, buf2, new FieldPosition(0));
        assertEquals("2008-07-04", buf2.toString());

        StringBuffer buf3 = new StringBuffer();
        format.format((Object) new Long(cal.getTime().getTime()), buf3, new FieldPosition(0));
        assertEquals("2008-07-04", buf3.toString());
    }

    public void testFormatObjectUnknownTypeThrows() {
        FastDateFormat format = FastDateFormat.getInstance("yyyy-MM-dd");
        try {
            format.format((Object) "not a date", new StringBuffer(), new FieldPosition(0));
            fail("Expected IllegalArgumentException for unsupported object type");
        } catch (IllegalArgumentException ex) {
            // expected
        }
        try {
            format.format((Object) null, new StringBuffer(), new FieldPosition(0));
            fail("Expected IllegalArgumentException for null object");
        } catch (IllegalArgumentException ex) {
            assertTrue(ex.getMessage().indexOf("<null>") >= 0);
        }
    }

    //-----------------------------------------------------------------------
    public void testParseObjectNotSupported() {
        FastDateFormat format = FastDateFormat.getInstance();
        ParsePosition pos = new ParsePosition(5);
        pos.setErrorIndex(5);
        Object result = format.parseObject("2005-01-01", pos);
        assertNull(result);
        assertEquals(0, pos.getIndex());
        assertEquals(0, pos.getErrorIndex());
    }

    //-----------------------------------------------------------------------
    public void testPaddedYear() {
        FastDateFormat format = FastDateFormat.getInstance("yyyy", GMT, Locale.US);
        assertEquals("0005", format.format(newCalendar(5, Calendar.JANUARY, 1, 0, 0, 0)));
        assertEquals("0050", format.format(newCalendar(50, Calendar.JANUARY, 1, 0, 0, 0)));
        assertEquals("0500", format.format(newCalendar(500, Calendar.JANUARY, 1, 0, 0, 0)));
        assertEquals("2005", format.format(newCalendar(2005, Calendar.JANUARY, 1, 0, 0, 0)));
    }

    public void testTwoDigitYear() {
        FastDateFormat format = FastDateFormat.getInstance("yy", GMT, Locale.US);
        assertEquals("05", format.format(newCalendar(2005, Calendar.JANUARY, 1, 0, 0, 0)));
        assertEquals("99", format.format(newCalendar(1999, Calendar.JANUARY, 1, 0, 0, 0)));
    }

    public void testMonthVariants() {
        Calendar cal = newCalendar(2005, Calendar.MARCH, 1, 0, 0, 0);
        assertEquals("3", FastDateFormat.getInstance("M", GMT, Locale.US).format(cal));
        assertEquals("03", FastDateFormat.getInstance("MM", GMT, Locale.US).format(cal));
        assertEquals("Mar", FastDateFormat.getInstance("MMM", GMT, Locale.US).format(cal));
        assertEquals("March", FastDateFormat.getInstance("MMMM", GMT, Locale.US).format(cal));
    }

    public void testTwelveHourFieldMidnightIsTwelve() {
        FastDateFormat format = FastDateFormat.getInstance("h", GMT, Locale.US);
        Calendar midnight = newCalendar(2005, Calendar.JANUARY, 1, 0, 15, 0);
        assertEquals("12", format.format(midnight));

        Calendar noon = newCalendar(2005, Calendar.JANUARY, 1, 12, 15, 0);
        assertEquals("12", format.format(noon));

        Calendar oneAm = newCalendar(2005, Calendar.JANUARY, 1, 1, 0, 0);
        assertEquals("1", format.format(oneAm));
    }

    public void testTwentyFourHourFieldMidnightIsTwentyFour() {
        FastDateFormat format = FastDateFormat.getInstance("k", GMT, Locale.US);
        Calendar midnight = newCalendar(2005, Calendar.JANUARY, 1, 0, 15, 0);
        assertEquals("24", format.format(midnight));

        Calendar elevenPm = newCalendar(2005, Calendar.JANUARY, 1, 23, 0, 0);
        assertEquals("23", format.format(elevenPm));
    }

    public void testTimeZoneNumberRule() {
        TimeZone tz = TimeZone.getTimeZone("GMT-3");
        Calendar cal = Calendar.getInstance(tz);
        cal.set(2002, Calendar.FEBRUARY, 23, 9, 11, 12);

        FastDateFormat noColon = FastDateFormat.getInstance("Z", tz, Locale.US);
        assertEquals("-0300", noColon.format(cal));

        FastDateFormat withColon = FastDateFormat.getInstance("ZZ", tz, Locale.US);
        assertEquals("-03:00", withColon.format(cal));
    }

    public void testTimeZoneNameRuleMatchesTimeZoneDisplayName() {
        TimeZone tz = TimeZone.getTimeZone("GMT");
        FastDateFormat shortName = FastDateFormat.getInstance("z", tz, Locale.US);
        FastDateFormat longName = FastDateFormat.getInstance("zzzz", tz, Locale.US);

        Calendar cal = newCalendar(2005, Calendar.JANUARY, 1, 0, 0, 0);
        cal.setTimeZone(tz);

        assertEquals(tz.getDisplayName(false, TimeZone.SHORT, Locale.US), shortName.format(cal));
        assertEquals(tz.getDisplayName(false, TimeZone.LONG, Locale.US), longName.format(cal));
    }

    //-----------------------------------------------------------------------
    public void testEqualsAndHashCode() {
        FastDateFormat format1 = FastDateFormat.getInstance("yyyy-MM-dd", GMT, Locale.US);
        FastDateFormat format2 = FastDateFormat.getInstance("yyyy-MM-dd", GMT, Locale.US);
        FastDateFormat format3 = FastDateFormat.getInstance("yyyy-MM-dd", TimeZone.getTimeZone("GMT+2"), Locale.US);

        assertTrue(format1.equals(format2));
        assertEquals(format1.hashCode(), format2.hashCode());
        assertFalse(format1.equals(format3));
        assertFalse(format1.equals("not a format"));
        assertFalse(format1.equals(null));
    }

    public void testAccessors() {
        FastDateFormat format = FastDateFormat.getInstance("yyyy-MM-dd", GMT, Locale.US);
        assertEquals("yyyy-MM-dd", format.getPattern());
        assertEquals(GMT, format.getTimeZone());
        assertEquals(Locale.US, format.getLocale());
        assertTrue(format.getTimeZoneOverridesCalendar());
        assertTrue(format.getMaxLengthEstimate() > 0);
    }

    public void testTimeZoneOverridesCalendarWhenForced() throws Exception {
        TimeZone forced = TimeZone.getTimeZone("GMT+5");
        FastDateFormat format = FastDateFormat.getInstance("HH", forced, Locale.US);

        java.lang.reflect.Field f = FastDateFormat.class.getDeclaredField("cInstanceCache");
        f.setAccessible(true);
        java.util.Map cache = (java.util.Map) f.get(null);
        System.out.println("DEBUG cache size=" + cache.size());
        java.util.Iterator it = cache.keySet().iterator();
        while (it.hasNext()) {
            Object k = it.next();
            System.out.println("DEBUG key=" + k + " identical=" + (k == format));
        }

        Calendar cal = Calendar.getInstance(GMT);
        cal.set(2005, Calendar.JANUARY, 1, 10, 0, 0);
        System.out.println("DEBUG cal class=" + cal.getClass() + " defaultLocale=" + Locale.getDefault());

        Calendar manualClone = (Calendar) cal.clone();
        manualClone.setTimeZone(forced);
        System.out.println("DEBUG manual clone hour=" + manualClone.get(Calendar.HOUR_OF_DAY));

        String result = format.format(cal);
        System.out.println("DEBUG overrides=" + format.getTimeZoneOverridesCalendar()
                + " tz=" + format.getTimeZone() + " hourField=" + cal.get(Calendar.HOUR_OF_DAY)
                + " result=" + result);
        assertEquals("15", result);
        // original calendar must not be mutated by the forced formatting
        assertEquals(GMT, cal.getTimeZone());
    }

    public void testToString() {
        FastDateFormat format = FastDateFormat.getInstance("yyyy-MM-dd", GMT, Locale.US);
        assertEquals("FastDateFormat[yyyy-MM-dd]", format.toString());
    }

    //-----------------------------------------------------------------------
    public void testDateInstance() {
        FastDateFormat format = FastDateFormat.getDateInstance(FastDateFormat.SHORT, GMT, Locale.US);
        assertNotNull(format);
        Calendar cal = newCalendar(2005, Calendar.JANUARY, 1, 10, 30, 0);
        String result = format.format(cal);
        assertNotNull(result);
        assertTrue(result.length() > 0);
    }

    public void testDateTimeInstance() {
        FastDateFormat format = FastDateFormat.getDateTimeInstance(
                FastDateFormat.SHORT, FastDateFormat.SHORT, GMT, Locale.US);
        assertNotNull(format);
        Calendar cal = newCalendar(2005, Calendar.JANUARY, 1, 10, 30, 0);
        String result = format.format(cal);
        assertNotNull(result);
        assertTrue(result.length() > 0);
    }

    //-----------------------------------------------------------------------
    public void testSerialization() throws Exception {
        FastDateFormat format = FastDateFormat.getInstance("yyyy-MM-dd", GMT, Locale.US);

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(baos);
        oos.writeObject(format);
        oos.close();

        ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(baos.toByteArray()));
        FastDateFormat deserialized = (FastDateFormat) ois.readObject();
        ois.close();

        assertEquals(format, deserialized);
        Calendar cal = newCalendar(2005, Calendar.JANUARY, 1, 0, 0, 0);
        assertEquals("2005-01-01", deserialized.format(cal));
    }
}
