/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.csv;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

import org.junit.Test;

public class CSVRecordAgentTest {

    private Map<String, Integer> headerMap() {
        final Map<String, Integer> map = new LinkedHashMap<String, Integer>();
        map.put("A", Integer.valueOf(0));
        map.put("B", Integer.valueOf(1));
        map.put("C", Integer.valueOf(2));
        return map;
    }

    @Test
    public void testGetByIndex() {
        final CSVRecord record = new CSVRecord(new String[] { "one", "two", "three" }, null, null, 1L);
        assertEquals("one", record.get(0));
        assertEquals("two", record.get(1));
        assertEquals("three", record.get(2));
    }

    @Test
    public void testGetByIndexOutOfBounds() {
        final CSVRecord record = new CSVRecord(new String[] { "one" }, null, null, 1L);
        try {
            record.get(1);
            fail("Expected ArrayIndexOutOfBoundsException");
        } catch (final ArrayIndexOutOfBoundsException e) {
            // expected
        }
        try {
            record.get(-1);
            fail("Expected ArrayIndexOutOfBoundsException");
        } catch (final ArrayIndexOutOfBoundsException e) {
            // expected
        }
    }

    @Test
    public void testGetByNameNoMapping() {
        final CSVRecord record = new CSVRecord(new String[] { "one", "two" }, null, null, 1L);
        try {
            record.get("A");
            fail("Expected IllegalStateException");
        } catch (final IllegalStateException e) {
            // expected
        }
    }

    @Test
    public void testGetByNameUnknownColumn() {
        final CSVRecord record = new CSVRecord(new String[] { "one", "two", "three" }, headerMap(), null, 1L);
        try {
            record.get("Z");
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            assertTrue(e.getMessage().contains("Z"));
        }
    }

    @Test
    public void testGetByNameMappedButMissingValue() {
        // mapping has 3 entries but only 2 values are present (inconsistent record)
        final CSVRecord record = new CSVRecord(new String[] { "one", "two" }, headerMap(), null, 1L);
        assertFalse(record.isConsistent());
        try {
            record.get("C");
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            assertTrue(e.getMessage().contains("C"));
        }
    }

    @Test
    public void testGetByNameHappyPath() {
        final CSVRecord record = new CSVRecord(new String[] { "one", "two", "three" }, headerMap(), null, 1L);
        assertEquals("one", record.get("A"));
        assertEquals("two", record.get("B"));
        assertEquals("three", record.get("C"));
    }

    @Test
    public void testGetByEnum() {
        final Map<String, Integer> map = new LinkedHashMap<String, Integer>();
        map.put("ALPHA", Integer.valueOf(0));
        map.put("BETA", Integer.valueOf(1));
        final CSVRecord record = new CSVRecord(new String[] { "a-value", "b-value" }, map, null, 1L);
        assertEquals("a-value", record.get(Column.ALPHA));
        assertEquals("b-value", record.get(Column.BETA));
    }

    private enum Column {
        ALPHA, BETA
    }

    @Test
    public void testGetComment() {
        final CSVRecord withComment = new CSVRecord(new String[] { "a" }, null, "a comment", 1L);
        assertEquals("a comment", withComment.getComment());

        final CSVRecord withoutComment = new CSVRecord(new String[] { "a" }, null, null, 1L);
        assertNull(withoutComment.getComment());
    }

    @Test
    public void testGetRecordNumber() {
        final CSVRecord record = new CSVRecord(new String[] { "a" }, null, null, 42L);
        assertEquals(42L, record.getRecordNumber());
    }

    @Test
    public void testIsConsistentNullMapping() {
        final CSVRecord record = new CSVRecord(new String[] { "a", "b" }, null, null, 1L);
        assertTrue(record.isConsistent());
    }

    @Test
    public void testIsConsistentMatchingMapping() {
        final CSVRecord record = new CSVRecord(new String[] { "one", "two", "three" }, headerMap(), null, 1L);
        assertTrue(record.isConsistent());
    }

    @Test
    public void testIsConsistentMismatchedMapping() {
        final CSVRecord record = new CSVRecord(new String[] { "one", "two" }, headerMap(), null, 1L);
        assertFalse(record.isConsistent());
    }

    @Test
    public void testIsMapped() {
        final CSVRecord record = new CSVRecord(new String[] { "one", "two", "three" }, headerMap(), null, 1L);
        assertTrue(record.isMapped("A"));
        assertFalse(record.isMapped("Z"));
    }

    @Test
    public void testIsMappedNullMapping() {
        final CSVRecord record = new CSVRecord(new String[] { "one" }, null, null, 1L);
        assertFalse(record.isMapped("A"));
    }

    @Test
    public void testIsSet() {
        // mapping has C -> 2 but only 2 values present, so C is mapped but not set
        final CSVRecord record = new CSVRecord(new String[] { "one", "two" }, headerMap(), null, 1L);
        assertTrue(record.isSet("A"));
        assertTrue(record.isSet("B"));
        assertFalse(record.isSet("C"));
        assertFalse(record.isSet("Z"));
    }

    @Test
    public void testIsSetNullMapping() {
        final CSVRecord record = new CSVRecord(new String[] { "one" }, null, null, 1L);
        assertFalse(record.isSet("A"));
    }

    @Test
    public void testIterator() {
        final CSVRecord record = new CSVRecord(new String[] { "one", "two", "three" }, null, null, 1L);
        final Iterator<String> it = record.iterator();
        assertTrue(it.hasNext());
        assertEquals("one", it.next());
        assertEquals("two", it.next());
        assertEquals("three", it.next());
        assertFalse(it.hasNext());
    }

    @Test
    public void testIteratorEmptyValues() {
        final CSVRecord record = new CSVRecord(null, null, null, 1L);
        final Iterator<String> it = record.iterator();
        assertFalse(it.hasNext());
    }

    @Test
    public void testSize() {
        final CSVRecord record = new CSVRecord(new String[] { "one", "two", "three" }, null, null, 1L);
        assertEquals(3, record.size());

        final CSVRecord empty = new CSVRecord(null, null, null, 1L);
        assertEquals(0, empty.size());
    }

    @Test
    public void testToMap() {
        final CSVRecord record = new CSVRecord(new String[] { "one", "two", "three" }, headerMap(), null, 1L);
        final Map<String, String> map = record.toMap();
        assertEquals(3, map.size());
        assertEquals("one", map.get("A"));
        assertEquals("two", map.get("B"));
        assertEquals("three", map.get("C"));
    }

    @Test
    public void testToMapWithMissingValues() {
        // Only 2 values but 3 mapped columns; the unset column should be excluded.
        final CSVRecord record = new CSVRecord(new String[] { "one", "two" }, headerMap(), null, 1L);
        final Map<String, String> map = record.toMap();
        assertEquals(2, map.size());
        assertEquals("one", map.get("A"));
        assertEquals("two", map.get("B"));
        assertFalse(map.containsKey("C"));
    }

    @Test
    public void testToMapIsIndependentCopy() {
        final CSVRecord record = new CSVRecord(new String[] { "one", "two" }, headerMap(), null, 1L);
        final Map<String, String> map1 = record.toMap();
        map1.put("A", "mutated");
        final Map<String, String> map2 = record.toMap();
        assertEquals("one", map2.get("A"));
    }

    @Test
    public void testPutInExistingMap() {
        final CSVRecord record = new CSVRecord(new String[] { "one", "two", "three" }, headerMap(), null, 1L);
        final Map<String, String> target = new HashMap<String, String>();
        target.put("PRESET", "value");
        final Map<String, String> result = record.putIn(target);
        assertTrue(result == target);
        assertEquals("value", result.get("PRESET"));
        assertEquals("one", result.get("A"));
        assertEquals(4, result.size());
    }

    @Test
    public void testToString() {
        final CSVRecord record = new CSVRecord(new String[] { "one", "two" }, null, null, 1L);
        assertEquals("[one, two]", record.toString());
    }

    @Test
    public void testToStringEmpty() {
        final CSVRecord record = new CSVRecord(null, null, null, 1L);
        assertEquals("[]", record.toString());
    }

    @Test
    public void testValues() {
        final String[] values = new String[] { "one", "two" };
        final CSVRecord record = new CSVRecord(values, null, null, 1L);
        assertEquals(2, record.values().length);
        assertEquals("one", record.values()[0]);
        assertEquals("two", record.values()[1]);
    }

    @Test
    public void testValuesNullInputDefaultsToEmptyArray() {
        final CSVRecord record = new CSVRecord(null, null, null, 1L);
        assertEquals(0, record.values().length);
    }
}
