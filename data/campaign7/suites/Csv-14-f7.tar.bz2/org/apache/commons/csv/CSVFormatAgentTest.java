/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.csv;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.io.StringWriter;

import org.junit.Test;

public class CSVFormatAgentTest {

    private enum Header {
        Name, Email, Phone
    }

    // --- Predefined formats ---

    @Test
    public void testDefaultSettings() {
        final CSVFormat f = CSVFormat.DEFAULT;
        assertEquals(',', f.getDelimiter());
        assertEquals(Character.valueOf('"'), f.getQuoteCharacter());
        assertNull(f.getCommentMarker());
        assertNull(f.getEscapeCharacter());
        assertEquals("\r\n", f.getRecordSeparator());
        assertTrue(f.getIgnoreEmptyLines());
        assertFalse(f.getIgnoreSurroundingSpaces());
        assertFalse(f.getSkipHeaderRecord());
        assertNull(f.getHeader());
    }

    @Test
    public void testExcelSettings() {
        final CSVFormat f = CSVFormat.EXCEL;
        assertEquals(',', f.getDelimiter());
        assertFalse(f.getIgnoreEmptyLines());
        assertTrue(f.getAllowMissingColumnNames());
    }

    @Test
    public void testMySqlSettings() {
        final CSVFormat f = CSVFormat.MYSQL;
        assertEquals('\t', f.getDelimiter());
        assertNull(f.getQuoteCharacter());
        assertEquals(Character.valueOf('\\'), f.getEscapeCharacter());
        assertEquals("\n", f.getRecordSeparator());
        assertFalse(f.getIgnoreEmptyLines());
        assertEquals("\\N", f.getNullString());
    }

    @Test
    public void testRfc4180Settings() {
        final CSVFormat f = CSVFormat.RFC4180;
        assertFalse(f.getIgnoreEmptyLines());
        assertEquals(',', f.getDelimiter());
        assertEquals(Character.valueOf('"'), f.getQuoteCharacter());
    }

    @Test
    public void testTdfSettings() {
        final CSVFormat f = CSVFormat.TDF;
        assertEquals('\t', f.getDelimiter());
        assertTrue(f.getIgnoreSurroundingSpaces());
    }

    @Test
    public void testValueOf() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.valueOf("Default"));
        assertEquals(CSVFormat.EXCEL, CSVFormat.valueOf("Excel"));
        assertEquals(CSVFormat.MYSQL, CSVFormat.valueOf("MySQL"));
        assertEquals(CSVFormat.RFC4180, CSVFormat.valueOf("RFC4180"));
        assertEquals(CSVFormat.TDF, CSVFormat.valueOf("TDF"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testValueOfUnknown() {
        CSVFormat.valueOf("DoesNotExist");
    }

    // --- newFormat ---

    @Test
    public void testNewFormat() {
        final CSVFormat f = CSVFormat.newFormat(';');
        assertEquals(';', f.getDelimiter());
        assertNull(f.getQuoteCharacter());
        assertNull(f.getCommentMarker());
        assertNull(f.getEscapeCharacter());
        assertNull(f.getRecordSeparator());
        assertFalse(f.getIgnoreEmptyLines());
        assertFalse(f.getIgnoreSurroundingSpaces());
        assertFalse(f.getSkipHeaderRecord());
        assertFalse(f.getAllowMissingColumnNames());
        assertFalse(f.getIgnoreHeaderCase());
        assertFalse(f.getTrim());
        assertFalse(f.getTrailingDelimiter());
        assertNull(f.getHeader());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testNewFormatDelimiterIsLf() {
        CSVFormat.newFormat('\n');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testNewFormatDelimiterIsCr() {
        CSVFormat.newFormat('\r');
    }

    // --- validate() via constructor-triggering with-methods ---

    @Test(expected = IllegalArgumentException.class)
    public void testDelimiterSameAsQuoteThrows() {
        CSVFormat.newFormat(',').withQuote('A').withDelimiter('A');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testDelimiterSameAsEscapeThrows() {
        CSVFormat.DEFAULT.withDelimiter('!').withEscape('!');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testDelimiterSameAsCommentMarkerThrows() {
        CSVFormat.DEFAULT.withDelimiter('!').withCommentMarker('!');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testQuoteSameAsCommentMarkerThrows() {
        CSVFormat.newFormat(',').withQuote('#').withCommentMarker('#');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testEscapeSameAsCommentMarkerThrows() {
        CSVFormat.newFormat(',').withEscape('#').withCommentMarker('#');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testQuoteModeNoneWithoutEscapeThrows() {
        CSVFormat.DEFAULT.withEscape((Character) null).withQuoteMode(QuoteMode.NONE);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testDuplicateHeaderThrows() {
        CSVFormat.DEFAULT.withHeader("A", "B", "A");
    }

    @Test
    public void testDuplicateHeaderAllowedWhenDifferent() {
        final CSVFormat f = CSVFormat.DEFAULT.withHeader("A", "B", "C");
        assertArrayEquals(new String[] {"A", "B", "C"}, f.getHeader());
    }

    // --- with* immutability and getters ---

    @Test(expected = IllegalArgumentException.class)
    public void testWithDelimiterLineBreakThrows() {
        CSVFormat.DEFAULT.withDelimiter('\n');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithCommentMarkerLineBreakThrows() {
        CSVFormat.DEFAULT.withCommentMarker('\r');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithEscapeLineBreakThrows() {
        CSVFormat.DEFAULT.withEscape('\n');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithQuoteLineBreakThrows() {
        CSVFormat.DEFAULT.withQuote('\n');
    }

    @Test
    public void testWithNullCommentMarkerDisables() {
        final CSVFormat f = CSVFormat.DEFAULT.withCommentMarker('#').withCommentMarker((Character) null);
        assertNull(f.getCommentMarker());
        assertFalse(f.isCommentMarkerSet());
    }

    @Test
    public void testWithNullEscapeDisables() {
        final CSVFormat f = CSVFormat.DEFAULT.withEscape('\\').withEscape((Character) null);
        assertNull(f.getEscapeCharacter());
        assertFalse(f.isEscapeCharacterSet());
    }

    @Test
    public void testWithNullQuoteDisables() {
        final CSVFormat f = CSVFormat.DEFAULT.withQuote((Character) null);
        assertNull(f.getQuoteCharacter());
        assertFalse(f.isQuoteCharacterSet());
    }

    @Test
    public void testWithDoesNotMutateOriginal() {
        final CSVFormat original = CSVFormat.DEFAULT;
        final CSVFormat changed = original.withDelimiter(';');
        assertEquals(',', original.getDelimiter());
        assertEquals(';', changed.getDelimiter());
    }

    @Test
    public void testGetHeaderReturnsDefensiveCopy() {
        final CSVFormat f = CSVFormat.DEFAULT.withHeader("A", "B");
        final String[] header1 = f.getHeader();
        header1[0] = "MUTATED";
        final String[] header2 = f.getHeader();
        assertEquals("A", header2[0]);
    }

    @Test
    public void testGetHeaderCommentsReturnsDefensiveCopy() {
        final CSVFormat f = CSVFormat.DEFAULT.withHeaderComments("c1", "c2");
        final String[] comments1 = f.getHeaderComments();
        comments1[0] = "MUTATED";
        final String[] comments2 = f.getHeaderComments();
        assertEquals("c1", comments2[0]);
    }

    @Test
    public void testWithHeaderCommentsConvertsToString() {
        final CSVFormat f = CSVFormat.DEFAULT.withHeaderComments("text", Integer.valueOf(42), null);
        final String[] comments = f.getHeaderComments();
        assertEquals("text", comments[0]);
        assertEquals("42", comments[1]);
        assertNull(comments[2]);
    }

    @Test
    public void testWithHeaderCommentsNull() {
        final CSVFormat f = CSVFormat.DEFAULT.withHeaderComments((Object[]) null);
        assertNull(f.getHeaderComments());
    }

    @Test
    public void testWithHeaderEnum() {
        final CSVFormat f = CSVFormat.DEFAULT.withHeader(Header.class);
        assertArrayEquals(new String[] {"Name", "Email", "Phone"}, f.getHeader());
    }

    @Test
    public void testWithHeaderEnumNull() {
        final CSVFormat f = CSVFormat.DEFAULT.withHeader((Class<? extends Enum<?>>) null);
        assertNull(f.getHeader());
    }

    @Test
    public void testWithHeaderEmptyMeansAutoDetect() {
        final CSVFormat f = CSVFormat.DEFAULT.withHeader();
        assertNotNull(f.getHeader());
        assertEquals(0, f.getHeader().length);
    }

    @Test
    public void testWithFirstRecordAsHeader() {
        final CSVFormat f = CSVFormat.DEFAULT.withFirstRecordAsHeader();
        assertNotNull(f.getHeader());
        assertEquals(0, f.getHeader().length);
        assertTrue(f.getSkipHeaderRecord());
    }

    @Test
    public void testWithAllowMissingColumnNames() {
        final CSVFormat f = CSVFormat.DEFAULT.withAllowMissingColumnNames();
        assertTrue(f.getAllowMissingColumnNames());
        assertFalse(f.withAllowMissingColumnNames(false).getAllowMissingColumnNames());
    }

    @Test
    public void testWithIgnoreHeaderCase() {
        assertTrue(CSVFormat.DEFAULT.withIgnoreHeaderCase().getIgnoreHeaderCase());
        assertFalse(CSVFormat.DEFAULT.getIgnoreHeaderCase());
    }

    @Test
    public void testWithIgnoreEmptyLines() {
        assertFalse(CSVFormat.DEFAULT.withIgnoreEmptyLines(false).getIgnoreEmptyLines());
        assertTrue(CSVFormat.DEFAULT.withIgnoreEmptyLines().getIgnoreEmptyLines());
    }

    @Test
    public void testWithIgnoreSurroundingSpaces() {
        assertTrue(CSVFormat.DEFAULT.withIgnoreSurroundingSpaces().getIgnoreSurroundingSpaces());
        assertFalse(CSVFormat.DEFAULT.getIgnoreSurroundingSpaces());
    }

    @Test
    public void testWithNullString() {
        final CSVFormat f = CSVFormat.DEFAULT.withNullString("NULL");
        assertTrue(f.isNullStringSet());
        assertEquals("NULL", f.getNullString());
    }

    @Test
    public void testWithoutNullString() {
        assertFalse(CSVFormat.DEFAULT.isNullStringSet());
        assertNull(CSVFormat.DEFAULT.getNullString());
    }

    @Test
    public void testWithQuoteMode() {
        final CSVFormat f = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL);
        assertEquals(QuoteMode.ALL, f.getQuoteMode());
    }

    @Test
    public void testWithRecordSeparatorChar() {
        final CSVFormat f = CSVFormat.DEFAULT.withRecordSeparator('\n');
        assertEquals("\n", f.getRecordSeparator());
    }

    @Test
    public void testWithRecordSeparatorString() {
        final CSVFormat f = CSVFormat.DEFAULT.withRecordSeparator("\r\n");
        assertEquals("\r\n", f.getRecordSeparator());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithRecordSeparatorRejectsInvalidValue() {
        // Per javadoc: "@throws IllegalArgumentException if recordSeparator is none of CR, LF or CRLF"
        CSVFormat.DEFAULT.withRecordSeparator("XYZ");
    }

    @Test
    public void testWithSkipHeaderRecord() {
        assertTrue(CSVFormat.DEFAULT.withSkipHeaderRecord().getSkipHeaderRecord());
        assertFalse(CSVFormat.DEFAULT.withSkipHeaderRecord(false).getSkipHeaderRecord());
    }

    @Test
    public void testWithTrailingDelimiter() {
        assertTrue(CSVFormat.DEFAULT.withTrailingDelimiter().getTrailingDelimiter());
        assertFalse(CSVFormat.DEFAULT.getTrailingDelimiter());
    }

    @Test
    public void testWithTrim() {
        assertTrue(CSVFormat.DEFAULT.withTrim().getTrim());
        assertFalse(CSVFormat.DEFAULT.getTrim());
    }

    // --- equals / hashCode ---

    @Test
    public void testEqualsSameInstance() {
        final CSVFormat f = CSVFormat.DEFAULT;
        assertTrue(f.equals(f));
    }

    @Test
    public void testEqualsNullAndDifferentType() {
        assertFalse(CSVFormat.DEFAULT.equals(null));
        assertFalse(CSVFormat.DEFAULT.equals("not a format"));
    }

    @Test
    public void testEqualsEquivalentFormats() {
        final CSVFormat a = CSVFormat.newFormat(',').withQuote('"').withRecordSeparator("\r\n");
        final CSVFormat b = CSVFormat.newFormat(',').withQuote('"').withRecordSeparator("\r\n");
        assertTrue(a.equals(b));
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    public void testNotEqualsDifferentDelimiter() {
        final CSVFormat a = CSVFormat.newFormat(',');
        final CSVFormat b = CSVFormat.newFormat(';');
        assertFalse(a.equals(b));
    }

    @Test
    public void testNotEqualsDifferentHeader() {
        final CSVFormat a = CSVFormat.DEFAULT.withHeader("A");
        final CSVFormat b = CSVFormat.DEFAULT.withHeader("B");
        assertFalse(a.equals(b));
    }

    // --- toString ---

    @Test
    public void testToStringContainsDelimiter() {
        final String s = CSVFormat.DEFAULT.toString();
        assertTrue(s.contains("Delimiter=<,>"));
    }

    @Test
    public void testToStringContainsQuoteCharWhenSet() {
        final String s = CSVFormat.DEFAULT.toString();
        assertTrue(s.contains("QuoteChar=<\">"));
    }

    @Test
    public void testToStringOmitsQuoteCharWhenUnset() {
        final String s = CSVFormat.MYSQL.toString();
        assertFalse(s.contains("QuoteChar"));
    }

    // --- format ---

    @Test
    public void testFormatSimpleValues() {
        final String result = CSVFormat.DEFAULT.format("a", "b", "c");
        assertEquals("a,b,c", result);
    }

    @Test
    public void testFormatQuotesValueContainingDelimiter() {
        final String result = CSVFormat.DEFAULT.format("a,b", "c");
        assertEquals("\"a,b\",c", result);
    }

    @Test
    public void testFormatEmptyValues() {
        final String result = CSVFormat.DEFAULT.format();
        assertEquals("", result);
    }

    // --- print / println / printRecord ---

    @Test
    public void testPrintSimpleValue() throws IOException {
        final StringWriter sw = new StringWriter();
        CSVFormat.DEFAULT.print("hello", sw, true);
        assertEquals("hello", sw.toString());
    }

    @Test
    public void testPrintNonFirstValuePrependsDelimiter() throws IOException {
        final StringWriter sw = new StringWriter();
        CSVFormat.DEFAULT.print("hello", sw, false);
        assertEquals(",hello", sw.toString());
    }

    @Test
    public void testPrintNullUsesNullString() throws IOException {
        final StringWriter sw = new StringWriter();
        CSVFormat.DEFAULT.withNullString("NULL").print(null, sw, true);
        assertEquals("NULL", sw.toString());
    }

    @Test
    public void testPrintNullWithoutNullStringIsEmpty() throws IOException {
        final StringWriter sw = new StringWriter();
        CSVFormat.DEFAULT.print(null, sw, true);
        assertEquals("", sw.toString());
    }

    @Test
    public void testPrintTrimsWhenTrimEnabled() throws IOException {
        final StringWriter sw = new StringWriter();
        CSVFormat.DEFAULT.withTrim().print("  hi  ", sw, true);
        assertEquals("hi", sw.toString());
    }

    @Test
    public void testPrintlnWritesRecordSeparator() throws IOException {
        final StringWriter sw = new StringWriter();
        CSVFormat.DEFAULT.println(sw);
        assertEquals("\r\n", sw.toString());
    }

    @Test
    public void testPrintlnWithTrailingDelimiter() throws IOException {
        final StringWriter sw = new StringWriter();
        CSVFormat.DEFAULT.withTrailingDelimiter().println(sw);
        assertEquals(",\r\n", sw.toString());
    }

    @Test
    public void testPrintRecordAppendsSeparator() throws IOException {
        final StringWriter sw = new StringWriter();
        CSVFormat.DEFAULT.printRecord(sw, "a", "b");
        assertEquals("a,b\r\n", sw.toString());
    }

    // --- quote modes via format() ---

    @Test
    public void testQuoteModeAllQuotesEverything() {
        final String result = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL).format("a", "1");
        assertEquals("\"a\",\"1\"", result);
    }

    @Test
    public void testQuoteModeNonNumericQuotesStringsOnly() {
        final String result = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.NON_NUMERIC).format("a", Integer.valueOf(1));
        assertEquals("\"a\",1", result);
    }

    @Test
    public void testQuoteModeNoneUsesEscaping() {
        final String result = CSVFormat.DEFAULT.withEscape('\\').withQuoteMode(QuoteMode.NONE).format("a,b");
        assertEquals("a\\,b", result);
    }

    @Test
    public void testQuoteCharacterGetsDoubled() {
        final String result = CSVFormat.DEFAULT.format("a\"b");
        assertEquals("\"a\"\"b\"", result);
    }

    // --- escaping without quoting ---

    @Test
    public void testEscapeWithoutQuoting() {
        final CSVFormat f = CSVFormat.newFormat(',').withEscape('\\');
        assertEquals("a\\,b", f.format("a,b"));
    }

    @Test
    public void testNoQuoteNoEscapeWritesRaw() {
        final CSVFormat f = CSVFormat.newFormat(',');
        assertEquals("a,b", f.format("a,b"));
    }

    // --- parse ---

    @Test
    public void testParseReturnsNonNullParser() throws IOException {
        final CSVParser parser = CSVFormat.DEFAULT.parse(new java.io.StringReader("a,b\n"));
        try {
            assertNotNull(parser);
        } finally {
            parser.close();
        }
    }

    // --- misc boundary ---

    @Test
    public void testIsSetFlagsDefaultFalseOnNewFormat() {
        final CSVFormat f = CSVFormat.newFormat(',');
        assertFalse(f.isQuoteCharacterSet());
        assertFalse(f.isEscapeCharacterSet());
        assertFalse(f.isCommentMarkerSet());
        assertFalse(f.isNullStringSet());
    }

    @Test
    public void testWithQuoteSameCharTwiceIsIdempotent() {
        final CSVFormat f = CSVFormat.DEFAULT.withQuote('"').withQuote('"');
        assertEquals(Character.valueOf('"'), f.getQuoteCharacter());
    }

    @Test
    public void testPredefinedEnumGetFormat() {
        assertSame(CSVFormat.DEFAULT, CSVFormat.Predefined.Default.getFormat());
        assertSame(CSVFormat.EXCEL, CSVFormat.Predefined.Excel.getFormat());
        assertSame(CSVFormat.MYSQL, CSVFormat.Predefined.MySQL.getFormat());
        assertSame(CSVFormat.RFC4180, CSVFormat.Predefined.RFC4180.getFormat());
        assertSame(CSVFormat.TDF, CSVFormat.Predefined.TDF.getFormat());
    }
}
