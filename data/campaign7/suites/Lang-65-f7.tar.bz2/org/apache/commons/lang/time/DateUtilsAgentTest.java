package org.apache.commons.lang.time;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.NoSuchElementException;

import junit.framework.TestCase;

/**
 * Self-contained tests for {@link DateUtils}.
 */
public class DateUtilsAgentTest extends TestCase {

    public DateUtilsAgentTest(String name) {
        super(name);
    }

    private static Calendar newCalendar(int year, int month, int day, int hour, int minute, int second, int millis) {
        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(year, month, day, hour, minute, second);
        cal.set(Calendar.MILLISECOND, millis);
        return cal;
    }

    private static Date newDate(int year, int month, int day, int hour, int minute, int second, int millis) {
        return newCalendar(year, month, day, hour, minute, second, millis).getTime();
    }

    //-----------------------------------------------------------------------
    // constants
    //-----------------------------------------------------------------------

    public void testConstants() {
        assertEquals(1000L, DateUtils.MILLIS_PER_SECOND);
        assertEquals(60000L, DateUtils.MILLIS_PER_MINUTE);
        assertEquals(3600000L, DateUtils.MILLIS_PER_HOUR);
        assertEquals(86400000L, DateUtils.MILLIS_PER_DAY);
        assertEquals(1000, DateUtils.MILLIS_IN_SECOND);
        assertEquals(60000, DateUtils.MILLIS_IN_MINUTE);
        assertEquals(3600000, DateUtils.MILLIS_IN_HOUR);
        assertEquals(86400000, DateUtils.MILLIS_IN_DAY);
        assertEquals(1, DateUtils.RANGE_WEEK_SUNDAY);
        assertEquals(2, DateUtils.RANGE_WEEK_MONDAY);
        assertEquals(3, DateUtils.RANGE_WEEK_RELATIVE);
        assertEquals(4, DateUtils.RANGE_WEEK_CENTER);
        assertEquals(5, DateUtils.RANGE_MONTH_SUNDAY);
        assertEquals(6, DateUtils.RANGE_MONTH_MONDAY);
    }

    //-----------------------------------------------------------------------
    // isSameDay
    //-----------------------------------------------------------------------

    public void testIsSameDayDate() {
        Date d1 = newDate(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        Date d2 = newDate(2002, Calendar.MARCH, 28, 6, 1, 0, 0);
        Date d3 = newDate(2002, Calendar.MARCH, 12, 13, 45, 0, 0);
        assertTrue(DateUtils.isSameDay(d1, d2));
        assertFalse(DateUtils.isSameDay(d1, d3));
    }

    public void testIsSameDayDateNull() {
        try {
            DateUtils.isSameDay((Date) null, new Date());
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
        try {
            DateUtils.isSameDay(new Date(), (Date) null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    public void testIsSameDayCalendar() {
        Calendar c1 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        Calendar c2 = newCalendar(2002, Calendar.MARCH, 28, 6, 1, 0, 0);
        Calendar c3 = newCalendar(2002, Calendar.MARCH, 12, 13, 45, 0, 0);
        assertTrue(DateUtils.isSameDay(c1, c2));
        assertFalse(DateUtils.isSameDay(c1, c3));
    }

    public void testIsSameDayCalendarNull() {
        try {
            DateUtils.isSameDay((Calendar) null, Calendar.getInstance());
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // isSameInstant
    //-----------------------------------------------------------------------

    public void testIsSameInstantDate() {
        Date d1 = new Date(1000L);
        Date d2 = new Date(1000L);
        Date d3 = new Date(2000L);
        assertTrue(DateUtils.isSameInstant(d1, d2));
        assertFalse(DateUtils.isSameInstant(d1, d3));
    }

    public void testIsSameInstantDateNull() {
        try {
            DateUtils.isSameInstant((Date) null, new Date());
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    public void testIsSameInstantCalendar() {
        Calendar c1 = Calendar.getInstance();
        c1.setTimeInMillis(1000L);
        Calendar c2 = Calendar.getInstance();
        c2.setTimeInMillis(1000L);
        Calendar c3 = Calendar.getInstance();
        c3.setTimeInMillis(2000L);
        assertTrue(DateUtils.isSameInstant(c1, c2));
        assertFalse(DateUtils.isSameInstant(c1, c3));
    }

    public void testIsSameInstantCalendarNull() {
        try {
            DateUtils.isSameInstant((Calendar) null, Calendar.getInstance());
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // isSameLocalTime
    //-----------------------------------------------------------------------

    public void testIsSameLocalTime() {
        Calendar c1 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 0);
        Calendar c2 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 0);
        assertTrue(DateUtils.isSameLocalTime(c1, c2));

        Calendar c3 = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 2, 0);
        assertFalse(DateUtils.isSameLocalTime(c1, c3));
    }

    public void testIsSameLocalTimeNull() {
        try {
            DateUtils.isSameLocalTime((Calendar) null, Calendar.getInstance());
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // parseDate
    //-----------------------------------------------------------------------

    public void testParseDateValid() throws Exception {
        Date expected = newDate(2002, Calendar.MARCH, 28, 0, 0, 0, 0);
        Date parsed = DateUtils.parseDate("2002-03-28", new String[] {"yyyy-MM-dd"});
        assertEquals(expected, parsed);
    }

    public void testParseDateSkipsPartialMatch() throws Exception {
        // "yyyy-MM" would partially match "2002-03-28" but not consume the
        // whole string, so it must be skipped in favour of the full match.
        Date expected = newDate(2002, Calendar.MARCH, 28, 0, 0, 0, 0);
        Date parsed = DateUtils.parseDate("2002-03-28", new String[] {"yyyy-MM", "yyyy-MM-dd"});
        assertEquals(expected, parsed);
    }

    public void testParseDateNoMatch() {
        try {
            DateUtils.parseDate("not-a-date", new String[] {"yyyy-MM-dd"});
            fail("Expected ParseException");
        } catch (ParseException ex) {
            // expected
        }
    }

    public void testParseDateNullArgs() {
        try {
            DateUtils.parseDate(null, new String[] {"yyyy-MM-dd"});
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        } catch (ParseException ex) {
            fail("Expected IllegalArgumentException, not ParseException");
        }
        try {
            DateUtils.parseDate("2002-03-28", null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        } catch (ParseException ex) {
            fail("Expected IllegalArgumentException, not ParseException");
        }
    }

    //-----------------------------------------------------------------------
    // add* methods
    //-----------------------------------------------------------------------

    public void testAddYears() {
        Date orig = newDate(2002, Calendar.MARCH, 28, 0, 0, 0, 0);
        Date result = DateUtils.addYears(orig, 1);
        assertEquals(newDate(2003, Calendar.MARCH, 28, 0, 0, 0, 0), result);
        // original unchanged
        assertEquals(newDate(2002, Calendar.MARCH, 28, 0, 0, 0, 0), orig);
    }

    public void testAddYearsNegative() {
        Date orig = newDate(2002, Calendar.MARCH, 28, 0, 0, 0, 0);
        Date result = DateUtils.addYears(orig, -1);
        assertEquals(newDate(2001, Calendar.MARCH, 28, 0, 0, 0, 0), result);
    }

    public void testAddMonths() {
        Date orig = newDate(2002, Calendar.MARCH, 28, 0, 0, 0, 0);
        Date result = DateUtils.addMonths(orig, 2);
        assertEquals(newDate(2002, Calendar.MAY, 28, 0, 0, 0, 0), result);
    }

    public void testAddWeeks() {
        Date orig = newDate(2002, Calendar.MARCH, 28, 0, 0, 0, 0);
        Date result = DateUtils.addWeeks(orig, 1);
        assertEquals(newDate(2002, Calendar.APRIL, 4, 0, 0, 0, 0), result);
    }

    public void testAddDays() {
        Date orig = newDate(2002, Calendar.MARCH, 28, 0, 0, 0, 0);
        Date result = DateUtils.addDays(orig, 3);
        assertEquals(newDate(2002, Calendar.MARCH, 31, 0, 0, 0, 0), result);
    }

    public void testAddHours() {
        Date orig = newDate(2002, Calendar.MARCH, 28, 23, 0, 0, 0);
        Date result = DateUtils.addHours(orig, 2);
        assertEquals(newDate(2002, Calendar.MARCH, 29, 1, 0, 0, 0), result);
    }

    public void testAddMinutes() {
        Date orig = newDate(2002, Calendar.MARCH, 28, 0, 59, 0, 0);
        Date result = DateUtils.addMinutes(orig, 2);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 1, 1, 0, 0), result);
    }

    public void testAddSeconds() {
        Date orig = newDate(2002, Calendar.MARCH, 28, 0, 0, 59, 0);
        Date result = DateUtils.addSeconds(orig, 2);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 0, 1, 1, 0), result);
    }

    public void testAddMilliseconds() {
        Date orig = new Date(1000L);
        Date result = DateUtils.addMilliseconds(orig, 500);
        assertEquals(new Date(1500L), result);
    }

    public void testAddNullDate() {
        try {
            DateUtils.addDays(null, 1);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    public void testAddGeneric() {
        Date orig = newDate(2002, Calendar.MARCH, 28, 0, 0, 0, 0);
        Date result = DateUtils.add(orig, Calendar.DATE, 5);
        assertEquals(newDate(2002, Calendar.APRIL, 2, 0, 0, 0, 0), result);
    }

    public void testAddGenericNullDate() {
        try {
            DateUtils.add(null, Calendar.DATE, 1);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // round(Date, int)
    //-----------------------------------------------------------------------

    public void testRoundDateHour() {
        Date orig = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date rounded = DateUtils.round(orig, Calendar.HOUR);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 14, 0, 0, 0), rounded);
        // original unchanged
        assertEquals(newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231), orig);
    }

    public void testRoundDateMonth() {
        Date orig = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date rounded = DateUtils.round(orig, Calendar.MONTH);
        assertEquals(newDate(2002, Calendar.APRIL, 1, 0, 0, 0, 0), rounded);
    }

    public void testRoundDateNull() {
        try {
            DateUtils.round((Date) null, Calendar.HOUR);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    public void testRoundDateUnsupportedField() {
        try {
            DateUtils.round(new Date(), Calendar.DAY_OF_WEEK);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // round(Calendar, int)
    //-----------------------------------------------------------------------

    public void testRoundCalendar() {
        Calendar orig = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar rounded = DateUtils.round(orig, Calendar.HOUR);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 14, 0, 0, 0), rounded.getTime());
        // original calendar is not altered; a different object is returned
        assertEquals(newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231), orig.getTime());
        assertNotSame(orig, rounded);
    }

    public void testRoundCalendarNull() {
        try {
            DateUtils.round((Calendar) null, Calendar.HOUR);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // round(Object, int)
    //-----------------------------------------------------------------------

    public void testRoundObjectDate() {
        Date orig = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date rounded = DateUtils.round((Object) orig, Calendar.HOUR);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 14, 0, 0, 0), rounded);
    }

    public void testRoundObjectCalendar() {
        Calendar orig = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date rounded = DateUtils.round((Object) orig, Calendar.HOUR);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 14, 0, 0, 0), rounded);
    }

    public void testRoundObjectNull() {
        try {
            DateUtils.round((Object) null, Calendar.HOUR);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    public void testRoundObjectInvalidType() {
        try {
            DateUtils.round((Object) "not a date", Calendar.HOUR);
            fail("Expected ClassCastException");
        } catch (ClassCastException ex) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // SEMI_MONTH rounding
    //-----------------------------------------------------------------------

    public void testRoundSemiMonthLowerHalfRoundsUp() {
        // day 10 is closer to day 16 than to day 1
        Date orig = newDate(2002, Calendar.MARCH, 10, 0, 0, 0, 0);
        Date rounded = DateUtils.round(orig, DateUtils.SEMI_MONTH);
        assertEquals(newDate(2002, Calendar.MARCH, 16, 0, 0, 0, 0), rounded);
    }

    public void testRoundSemiMonthUpperHalfRoundsDown() {
        // day 20 is closer to day 16 than to day 1 of next month
        Date orig = newDate(2002, Calendar.MARCH, 20, 0, 0, 0, 0);
        Date rounded = DateUtils.round(orig, DateUtils.SEMI_MONTH);
        assertEquals(newDate(2002, Calendar.MARCH, 16, 0, 0, 0, 0), rounded);
    }

    public void testRoundSemiMonthDayOne() {
        Date orig = newDate(2002, Calendar.MARCH, 1, 0, 0, 0, 0);
        Date rounded = DateUtils.round(orig, DateUtils.SEMI_MONTH);
        assertEquals(newDate(2002, Calendar.MARCH, 1, 0, 0, 0, 0), rounded);
    }

    //-----------------------------------------------------------------------
    // truncate(Date, int)
    //-----------------------------------------------------------------------

    public void testTruncateDateHour() {
        Date orig = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date truncated = DateUtils.truncate(orig, Calendar.HOUR);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 13, 0, 0, 0), truncated);
        // original unchanged
        assertEquals(newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231), orig);
    }

    public void testTruncateDateMonth() {
        Date orig = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date truncated = DateUtils.truncate(orig, Calendar.MONTH);
        assertEquals(newDate(2002, Calendar.MARCH, 1, 0, 0, 0, 0), truncated);
    }

    public void testTruncateDateNull() {
        try {
            DateUtils.truncate((Date) null, Calendar.HOUR);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    public void testTruncateDateUnsupportedField() {
        try {
            DateUtils.truncate(new Date(), Calendar.DAY_OF_WEEK);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // truncate(Calendar, int)
    //-----------------------------------------------------------------------

    public void testTruncateCalendar() {
        Calendar orig = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar truncated = DateUtils.truncate(orig, Calendar.HOUR);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 13, 0, 0, 0), truncated.getTime());
        assertEquals(newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231), orig.getTime());
        assertNotSame(orig, truncated);
    }

    public void testTruncateCalendarNull() {
        try {
            DateUtils.truncate((Calendar) null, Calendar.HOUR);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // truncate(Object, int)
    //-----------------------------------------------------------------------

    public void testTruncateObjectDate() {
        Date orig = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date truncated = DateUtils.truncate((Object) orig, Calendar.HOUR);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 13, 0, 0, 0), truncated);
    }

    public void testTruncateObjectCalendar() {
        Calendar orig = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date truncated = DateUtils.truncate((Object) orig, Calendar.HOUR);
        assertEquals(newDate(2002, Calendar.MARCH, 28, 13, 0, 0, 0), truncated);
    }

    public void testTruncateObjectNull() {
        try {
            DateUtils.truncate((Object) null, Calendar.HOUR);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    public void testTruncateObjectInvalidType() {
        try {
            DateUtils.truncate((Object) new Object(), Calendar.HOUR);
            fail("Expected ClassCastException");
        } catch (ClassCastException ex) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // iterator(Date, int) / iterator(Calendar, int) / iterator(Object, int)
    //-----------------------------------------------------------------------

    public void testIteratorMonthSunday() {
        // Thursday 4 July 2002
        Date focus = newDate(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        Iterator it = DateUtils.iterator(focus, DateUtils.RANGE_MONTH_SUNDAY);
        Calendar first = null;
        Calendar last = null;
        int count = 0;
        while (it.hasNext()) {
            Calendar c = (Calendar) it.next();
            if (first == null) {
                first = c;
            }
            last = c;
            count++;
        }
        assertEquals(newDate(2002, Calendar.JUNE, 30, 0, 0, 0, 0), first.getTime());
        assertEquals(newDate(2002, Calendar.AUGUST, 3, 0, 0, 0, 0), last.getTime());
        assertEquals(35, count);
    }

    public void testIteratorWeekSunday() {
        // Thursday 4 July 2002
        Calendar focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        Iterator it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        Calendar first = null;
        Calendar last = null;
        int count = 0;
        while (it.hasNext()) {
            Calendar c = (Calendar) it.next();
            if (first == null) {
                first = c;
            }
            last = c;
            count++;
        }
        assertEquals(7, count);
        assertEquals(Calendar.SUNDAY, first.get(Calendar.DAY_OF_WEEK));
        assertEquals(Calendar.SATURDAY, last.get(Calendar.DAY_OF_WEEK));
        assertEquals(newDate(2002, Calendar.JUNE, 30, 0, 0, 0, 0), first.getTime());
    }

    public void testIteratorWeekRelative() {
        // Thursday 4 July 2002: relative week starts on the focus day itself
        Calendar focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        Iterator it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_RELATIVE);
        Calendar first = (Calendar) it.next();
        assertEquals(newDate(2002, Calendar.JULY, 4, 0, 0, 0, 0), first.getTime());
        int count = 1;
        Calendar last = first;
        while (it.hasNext()) {
            last = (Calendar) it.next();
            count++;
        }
        assertEquals(7, count);
        assertEquals(newDate(2002, Calendar.JULY, 10, 0, 0, 0, 0), last.getTime());
    }

    public void testIteratorWeekCenter() {
        // Thursday 4 July 2002: centered week runs Mon 1 Jul - Sun 7 Jul
        Calendar focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        Iterator it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_CENTER);
        Calendar first = (Calendar) it.next();
        assertEquals(newDate(2002, Calendar.JULY, 1, 0, 0, 0, 0), first.getTime());
        int count = 1;
        Calendar last = first;
        while (it.hasNext()) {
            last = (Calendar) it.next();
            count++;
        }
        assertEquals(7, count);
        assertEquals(newDate(2002, Calendar.JULY, 7, 0, 0, 0, 0), last.getTime());
    }

    public void testIteratorDateNull() {
        try {
            DateUtils.iterator((Date) null, DateUtils.RANGE_WEEK_SUNDAY);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    public void testIteratorCalendarNull() {
        try {
            DateUtils.iterator((Calendar) null, DateUtils.RANGE_WEEK_SUNDAY);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    public void testIteratorInvalidRangeStyle() {
        try {
            DateUtils.iterator(new Date(), 999);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    public void testIteratorObjectDate() {
        Date focus = newDate(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        Iterator it = DateUtils.iterator((Object) focus, DateUtils.RANGE_WEEK_SUNDAY);
        assertTrue(it.hasNext());
    }

    public void testIteratorObjectCalendar() {
        Calendar focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        Iterator it = DateUtils.iterator((Object) focus, DateUtils.RANGE_WEEK_SUNDAY);
        assertTrue(it.hasNext());
    }

    public void testIteratorObjectNull() {
        try {
            DateUtils.iterator((Object) null, DateUtils.RANGE_WEEK_SUNDAY);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    public void testIteratorObjectInvalidType() {
        try {
            DateUtils.iterator((Object) "not a date", DateUtils.RANGE_WEEK_SUNDAY);
            fail("Expected ClassCastException");
        } catch (ClassCastException ex) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // DateIterator (package-private nested class)
    //-----------------------------------------------------------------------

    public void testDateIteratorSingleDay() {
        Calendar day = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        Calendar sameDay = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        DateUtils.DateIterator it = new DateUtils.DateIterator(day, sameDay);
        assertTrue(it.hasNext());
        Calendar result = (Calendar) it.next();
        assertEquals(newDate(2002, Calendar.JULY, 4, 0, 0, 0, 0), result.getTime());
        assertFalse(it.hasNext());
    }

    public void testDateIteratorExhaustionThrows() {
        Calendar start = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        Calendar end = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        DateUtils.DateIterator it = new DateUtils.DateIterator(start, end);
        it.next();
        assertFalse(it.hasNext());
        try {
            it.next();
            fail("Expected NoSuchElementException");
        } catch (NoSuchElementException ex) {
            // expected
        }
    }

    public void testDateIteratorRemoveUnsupported() {
        Calendar start = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        Calendar end = newCalendar(2002, Calendar.JULY, 6, 0, 0, 0, 0);
        DateUtils.DateIterator it = new DateUtils.DateIterator(start, end);
        try {
            it.remove();
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException ex) {
            // expected
        }
    }
}
