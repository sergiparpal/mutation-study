/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang.text;

import java.text.FieldPosition;
import java.text.Format;
import java.text.ParsePosition;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Self-contained unit tests for {@link ExtendedMessageFormat}.
 */
public class ExtendedMessageFormatAgentTest extends TestCase {

    public ExtendedMessageFormatAgentTest(String name) {
        super(name);
    }

    public static Test suite() {
        return new TestSuite(ExtendedMessageFormatAgentTest.class);
    }

    /** Format that upper-cases the String form of its argument. */
    private static class UpperCaseFormat extends Format {
        private static final long serialVersionUID = 1L;

        public StringBuffer format(Object obj, StringBuffer toAppendTo, FieldPosition pos) {
            return toAppendTo.append(String.valueOf(obj).toUpperCase());
        }

        public Object parseObject(String source, ParsePosition pos) {
            pos.setIndex(source.length());
            return source;
        }
    }

    private static class UpperCaseFormatFactory implements FormatFactory {
        public Format getFormat(String name, String arguments, Locale locale) {
            if ("upper".equals(name)) {
                return new UpperCaseFormat();
            }
            return null;
        }
    }

    private Map createRegistry() {
        Map registry = new HashMap();
        registry.put("upper", new UpperCaseFormatFactory());
        return registry;
    }

    public void testConstructorDefaultLocale() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello, {0}!");
        assertEquals("Hello, World!", emf.format(new Object[] {"World"}));
        assertEquals(Locale.getDefault(), emf.getLocale());
    }

    public void testConstructorWithLocale() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number,integer}", Locale.US);
        assertEquals(Locale.US, emf.getLocale());
        assertEquals("1,234", emf.format(new Object[] {new Integer(1234)}));
    }

    public void testConstructorNullRegistryBehavesLikeMessageFormat() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number,integer}", Locale.US, null);
        assertEquals("42", emf.format(new Object[] {new Integer(42)}));
        assertEquals("{0,number,integer}", emf.toPattern());
    }

    public void testUnknownFormatWithoutRegistryThrows() {
        try {
            new ExtendedMessageFormat("{0,upper}");
            fail("Expected IllegalArgumentException for unknown built-in format");
        } catch (IllegalArgumentException e) {
            // expected: "upper" is not a format known to java.text.MessageFormat
        }
    }

    public void testCustomFormatIsUsed() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", createRegistry());
        assertEquals("ABC", emf.format(new Object[] {"abc"}));
        assertEquals("{0,upper}", emf.toPattern());
    }

    public void testUnmatchedFormatNameFallsBackToStandardAndThrows() {
        try {
            new ExtendedMessageFormat("{0,bogus}", createRegistry());
            fail("Expected IllegalArgumentException since 'bogus' is neither custom nor standard");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testToPatternPreservesCustomFormatDescription() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper} and {1}", createRegistry());
        assertEquals("{0,upper} and {1}", emf.toPattern());
        assertEquals("A and b", emf.format(new Object[] {"a", "b"}));
    }

    public void testToPatternPreservesStandardFormatUnchanged() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number,integer}", createRegistry());
        assertEquals("{0,number,integer}", emf.toPattern());
    }

    public void testApplyPatternReplacesPreviousPattern() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", createRegistry());
        assertEquals("first", emf.format(new Object[] {"first"}));
        emf.applyPattern("{0,upper}");
        assertEquals("{0,upper}", emf.toPattern());
        assertEquals("SECOND", emf.format(new Object[] {"second"}));
    }

    public void testWhitespaceAroundArgumentIndexIsTrimmed() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{ 0 ,upper}", createRegistry());
        assertEquals("{0,upper}", emf.toPattern());
        assertEquals("XYZ", emf.format(new Object[] {"xyz"}));
    }

    public void testWhitespaceBeforeFormatNameIsTrimmed() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0, upper}", createRegistry());
        assertEquals("{0,upper}", emf.toPattern());
        assertEquals("AB", emf.format(new Object[] {"ab"}));
    }

    public void testPlainTextPatternWithNoFormatElements() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("no placeholders here", createRegistry());
        assertEquals("no placeholders here", emf.toPattern());
        assertEquals("no placeholders here", emf.format(new Object[0]));
    }

    public void testEscapedQuoteInPattern() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("it''s {0}", createRegistry());
        assertEquals("it's done", emf.format(new Object[] {"done"}));
    }

    public void testQuotedLiteralIsNotParsedAsFormatElement() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("'{0}' literal {1}", createRegistry());
        assertEquals("{0} literal done", emf.format(new Object[] {"ignored", "done"}));
    }

    public void testQuoteWithinCustomFormatDescription() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper,it's a style}", createRegistry());
        assertEquals("X", emf.format(new Object[] {"x"}));
    }

    public void testUnterminatedFormatElementThrows() {
        try {
            new ExtendedMessageFormat("{0", createRegistry());
            fail("Expected IllegalArgumentException for unterminated format element");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testInvalidArgumentIndexThrows() {
        try {
            new ExtendedMessageFormat("{abc}", createRegistry());
            fail("Expected IllegalArgumentException for non-numeric argument index");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testUnreadableFormatElementThrows() {
        try {
            new ExtendedMessageFormat("{0 upper}", createRegistry());
            fail("Expected IllegalArgumentException for unreadable format element");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testSetFormatThrowsUnsupportedOperationException() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", createRegistry());
        try {
            emf.setFormat(0, new UpperCaseFormat());
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException e) {
            // expected
        }
    }

    public void testSetFormatByArgumentIndexThrowsUnsupportedOperationException() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", createRegistry());
        try {
            emf.setFormatByArgumentIndex(0, new UpperCaseFormat());
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException e) {
            // expected
        }
    }

    public void testSetFormatsThrowsUnsupportedOperationException() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", createRegistry());
        try {
            emf.setFormats(new Format[] {new UpperCaseFormat()});
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException e) {
            // expected
        }
    }

    public void testSetFormatsByArgumentIndexThrowsUnsupportedOperationException() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", createRegistry());
        try {
            emf.setFormatsByArgumentIndex(new Format[] {new UpperCaseFormat()});
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException e) {
            // expected
        }
    }

    public void testMultipleArgumentsWithMixedFormats() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat(
                "{0,upper}-{1,number,integer}-{2}", createRegistry());
        String result = emf.format(new Object[] {"mix", new Integer(7), "plain"});
        assertEquals("MIX-7-plain", result);
    }

    public void testEqualsAndHashCodeWithoutCustomFormats() {
        ExtendedMessageFormat emf1 = new ExtendedMessageFormat("{0,number,integer}", Locale.US);
        ExtendedMessageFormat emf2 = new ExtendedMessageFormat("{0,number,integer}", Locale.US);
        assertEquals(emf1, emf2);
        assertEquals(emf1.hashCode(), emf2.hashCode());
    }

    public void testNotEqualsForDifferentPattern() {
        ExtendedMessageFormat emf1 = new ExtendedMessageFormat("{0,number,integer}", Locale.US);
        ExtendedMessageFormat emf2 = new ExtendedMessageFormat("{0}", Locale.US);
        assertFalse(emf1.equals(emf2));
    }
}
