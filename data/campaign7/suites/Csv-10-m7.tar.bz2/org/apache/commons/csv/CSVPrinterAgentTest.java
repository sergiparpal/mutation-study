/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.csv;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.Closeable;
import java.io.Flushable;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;

/**
 * Tests for {@link CSVPrinter}.
 */
public class CSVPrinterAgentTest {

    /** Appendable that also tracks flush/close calls, to verify delegation. */
    private static class TrackingAppendable implements Appendable, Closeable, Flushable {
        private final StringBuilder sb = new StringBuilder();
        private boolean flushed = false;
        private boolean closed = false;

        public Appendable append(final CharSequence csq) throws IOException {
            sb.append(csq);
            return this;
        }

        public Appendable append(final CharSequence csq, final int start, final int end) throws IOException {
            sb.append(csq, start, end);
            return this;
        }

        public Appendable append(final char c) throws IOException {
            sb.append(c);
            return this;
        }

        public void flush() throws IOException {
            flushed = true;
        }

        public void close() throws IOException {
            closed = true;
        }

        public String toString() {
            return sb.toString();
        }
    }

    @Test
    public void testPrintSimpleValue() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("a");
        printer.print("b");
        assertEquals("a,b", sb.toString());
    }

    @Test
    public void testPrintNullUsesEmptyStringByDefault() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("x");
        printer.print(null);
        assertEquals("x,", sb.toString());
    }

    @Test
    public void testPrintNullUsesConfiguredNullString() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT.withNullString("N/A"));
        printer.print(null);
        assertEquals("N/A", sb.toString());
    }

    @Test
    public void testPrintRecordVarargs() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord("a", "b", "c");
        assertEquals("a,b,c\r\n", sb.toString());
    }

    @Test
    public void testPrintRecordIterable() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        final List<String> values = new ArrayList<String>();
        values.add("a");
        values.add("b");
        printer.printRecord(values);
        assertEquals("a,b\r\n", sb.toString());
    }

    @Test
    public void testPrintRecordEmptyVarargs() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord(new Object[0]);
        assertEquals("\r\n", sb.toString());
    }

    @Test
    public void testPrintlnWithNullRecordSeparator() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT.withRecordSeparator(null));
        printer.print("a");
        printer.println();
        printer.print("b");
        assertEquals("ab", sb.toString());
    }

    @Test
    public void testPrintRecordsIterableOfArraysAndIterablesAndScalars() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        final List<Object> records = new ArrayList<Object>();
        records.add(new Object[] { "a", "b" });
        records.add(Arrays.asList("c", "d"));
        records.add("e");
        printer.printRecords(records);
        assertEquals("a,b\r\nc,d\r\ne\r\n", sb.toString());
    }

    @Test
    public void testPrintRecordsObjectArrayOfArraysAndIterablesAndScalars() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        final Object[] records = new Object[] {
                new Object[] { "a", "b" },
                Arrays.asList("c", "d"),
                "e"
        };
        printer.printRecords(records);
        assertEquals("a,b\r\nc,d\r\ne\r\n", sb.toString());
    }

    @Test
    public void testQuoteMinimalWrapsValueContainingDelimiter() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("a,b");
        assertEquals("\"a,b\"", sb.toString());
    }

    @Test
    public void testQuoteMinimalDoublesEmbeddedQuoteChar() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("a\"b");
        assertEquals("\"a\"\"b\"", sb.toString());
    }

    @Test
    public void testQuoteMinimalEmptyFirstFieldIsQuoted() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord("");
        assertEquals("\"\"\r\n", sb.toString());
    }

    @Test
    public void testQuoteMinimalPlainValueIsNotQuoted() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.print("abc");
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testQuoteAllQuotesEveryField() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT.withQuotePolicy(Quote.ALL));
        printer.printRecord("a", "1");
        assertEquals("\"a\",\"1\"\r\n", sb.toString());
    }

    @Test
    public void testQuoteNonNumericQuotesOnlyNonNumbers() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT.withQuotePolicy(Quote.NON_NUMERIC));
        printer.printRecord("a", Integer.valueOf(1));
        assertEquals("\"a\",1\r\n", sb.toString());
    }

    @Test
    public void testQuoteNoneUsesEscapingInstead() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb,
                CSVFormat.DEFAULT.withEscape('\\').withQuotePolicy(Quote.NONE));
        printer.print("a,b");
        assertEquals("a\\,b", sb.toString());
    }

    @Test
    public void testEscapingWithoutQuoting() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVFormat format = CSVFormat.newFormat(',').withEscape('\\').withQuoteChar(null)
                .withRecordSeparator("\n");
        final CSVPrinter printer = new CSVPrinter(sb, format);
        printer.print("a,b\nc");
        assertEquals("a\\,b\\nc", sb.toString());
    }

    @Test
    public void testPrintCommentDisabledIsNoOp() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printComment("this is a comment");
        assertEquals("", sb.toString());
    }

    @Test
    public void testPrintCommentEnabledSingleLine() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT.withCommentStart('#'));
        printer.printComment("hello");
        assertEquals("# hello\r\n", sb.toString());
    }

    @Test
    public void testPrintCommentEnabledMultiLineWithCrLfAndLf() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT.withCommentStart('#'));
        printer.printComment("line1\r\nline2\nline3");
        assertEquals("# line1\r\n# line2\r\n# line3\r\n", sb.toString());
    }

    @Test
    public void testPrintCommentStartsOnNewLineWhenMidRecord() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT.withCommentStart('#'));
        printer.print("a");
        printer.printComment("c");
        assertEquals("a\r\n# c\r\n", sb.toString());
    }

    @Test
    public void testConstructorWithHeaderPrintsHeaderImmediately() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT.withHeader("A", "B"));
        printer.printRecord("1", "2");
        assertEquals("A,B\r\n1,2\r\n", sb.toString());
    }

    @Test
    public void testConstructorNullOutThrowsIllegalArgumentException() throws IOException {
        try {
            new CSVPrinter(null, CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testConstructorNullFormatThrowsIllegalArgumentException() throws IOException {
        try {
            new CSVPrinter(new StringBuilder(), null);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testConstructorInvalidFormatThrowsIllegalStateException() throws IOException {
        final CSVFormat invalid = CSVFormat.DEFAULT.withDelimiter('!').withCommentStart('!');
        try {
            new CSVPrinter(new StringBuilder(), invalid);
            fail("Expected IllegalStateException");
        } catch (final IllegalStateException e) {
            // expected
        }
    }

    @Test
    public void testGetOutReturnsSameInstance() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        assertSame(sb, printer.getOut());
    }

    @Test
    public void testFlushDelegatesToFlushableOut() throws IOException {
        final TrackingAppendable appendable = new TrackingAppendable();
        final CSVPrinter printer = new CSVPrinter(appendable, CSVFormat.DEFAULT);
        assertFalse(appendable.flushed);
        printer.flush();
        assertTrue(appendable.flushed);
    }

    @Test
    public void testFlushOnNonFlushableOutDoesNotThrow() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.flush();
    }

    @Test
    public void testCloseDelegatesToCloseableOut() throws IOException {
        final TrackingAppendable appendable = new TrackingAppendable();
        final CSVPrinter printer = new CSVPrinter(appendable, CSVFormat.DEFAULT);
        assertFalse(appendable.closed);
        printer.close();
        assertTrue(appendable.closed);
    }

    @Test
    public void testCloseOnNonCloseableOutDoesNotThrow() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.close();
    }

    @Test
    public void testPrintRecordsEmptyIterableProducesNoOutput() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecords(new ArrayList<Object>());
        assertEquals("", sb.toString());
    }

    @Test
    public void testNewRecordTrackingAcrossMultipleRecords() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.printRecord("a");
        printer.printRecord("b");
        assertEquals("a\r\nb\r\n", sb.toString());
    }
}
