/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.csv;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.io.StringWriter;

import org.junit.Test;

public class CSVFormatAgentTest {

    private enum Header {
        Name, Email, Phone
    }

    @Test
    public void testNewFormatDefaults() {
        final CSVFormat format = CSVFormat.newFormat(';');
        assertEquals(';', format.getDelimiter());
        assertNull(format.getQuoteCharacter());
        assertNull(format.getQuoteMode());
        assertNull(format.getCommentMarker());
        assertNull(format.getEscapeCharacter());
        assertFalse(format.getIgnoreSurroundingSpaces());
        assertFalse(format.getIgnoreEmptyLines());
        assertNull(format.getRecordSeparator());
        assertNull(format.getNullString());
        assertNull(format.getHeaderComments());
        assertNull(format.getHeader());
        assertFalse(format.getSkipHeaderRecord());
        assertFalse(format.getAllowMissingColumnNames());
        assertFalse(format.getIgnoreHeaderCase());
        assertFalse(format.getTrim());
        assertFalse(format.getTrailingDelimiter());
    }

    @Test
    public void testNewFormatRejectsLineBreakDelimiter() {
        try {
            CSVFormat.newFormat('\n');
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
        try {
            CSVFormat.newFormat('\r');
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testDefaultFormatSettings() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertEquals(',', format.getDelimiter());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\r\n", format.getRecordSeparator());
        assertTrue(format.getIgnoreEmptyLines());
        assertFalse(format.getTrailingDelimiter());
    }

    @Test
    public void testExcelFormatSettings() {
        final CSVFormat format = CSVFormat.EXCEL;
        assertFalse(format.getIgnoreEmptyLines());
        assertTrue(format.getAllowMissingColumnNames());
    }

    @Test
    public void testMySqlFormatSettings() {
        final CSVFormat format = CSVFormat.MYSQL;
        assertEquals('\t', format.getDelimiter());
        assertNull(format.getQuoteCharacter());
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
        assertEquals("\n", format.getRecordSeparator());
        assertEquals("\\N", format.getNullString());
        assertFalse(format.getIgnoreEmptyLines());
    }

    @Test
    public void testRfc4180Settings() {
        final CSVFormat format = CSVFormat.RFC4180;
        assertFalse(format.getIgnoreEmptyLines());
        assertEquals(',', format.getDelimiter());
    }

    @Test
    public void testTdfSettings() {
        final CSVFormat format = CSVFormat.TDF;
        assertEquals('\t', format.getDelimiter());
        assertTrue(format.getIgnoreSurroundingSpaces());
    }

    @Test
    public void testValueOfPredefined() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.valueOf("Default"));
        assertEquals(CSVFormat.EXCEL, CSVFormat.valueOf("Excel"));
        assertEquals(CSVFormat.MYSQL, CSVFormat.valueOf("MySQL"));
        assertEquals(CSVFormat.RFC4180, CSVFormat.valueOf("RFC4180"));
        assertEquals(CSVFormat.TDF, CSVFormat.valueOf("TDF"));
    }

    @Test
    public void testValueOfUnknownThrows() {
        try {
            CSVFormat.valueOf("DoesNotExist");
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testWithDelimiter() {
        final CSVFormat format = CSVFormat.DEFAULT.withDelimiter('|');
        assertEquals('|', format.getDelimiter());
        // original unaffected (immutability)
        assertEquals(',', CSVFormat.DEFAULT.getDelimiter());
    }

    @Test
    public void testWithDelimiterRejectsLineBreak() {
        try {
            CSVFormat.DEFAULT.withDelimiter('\n');
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testWithQuoteCharAndSetFlag() {
        final CSVFormat noQuote = CSVFormat.newFormat(',');
        assertFalse(noQuote.isQuoteCharacterSet());
        final CSVFormat withQuote = noQuote.withQuote('\'');
        assertTrue(withQuote.isQuoteCharacterSet());
        assertEquals(Character.valueOf('\''), withQuote.getQuoteCharacter());
    }

    @Test
    public void testWithQuoteNullDisables() {
        final CSVFormat withQuote = CSVFormat.DEFAULT.withQuote('\'');
        final CSVFormat withoutQuote = withQuote.withQuote((Character) null);
        assertFalse(withoutQuote.isQuoteCharacterSet());
        assertNull(withoutQuote.getQuoteCharacter());
    }

    @Test
    public void testWithQuoteRejectsLineBreak() {
        try {
            CSVFormat.DEFAULT.withQuote('\r');
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testWithQuoteSameAsDelimiterThrows() {
        try {
            CSVFormat.newFormat(',').withQuote(',');
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testWithEscapeAndSetFlag() {
        final CSVFormat noEscape = CSVFormat.newFormat(',');
        assertFalse(noEscape.isEscapeCharacterSet());
        final CSVFormat withEscape = noEscape.withEscape('\\');
        assertTrue(withEscape.isEscapeCharacterSet());
        assertEquals(Character.valueOf('\\'), withEscape.getEscapeCharacter());
    }

    @Test
    public void testWithEscapeSameAsDelimiterThrows() {
        try {
            CSVFormat.newFormat(',').withEscape(',');
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testWithEscapeRejectsLineBreak() {
        try {
            CSVFormat.DEFAULT.withEscape('\n');
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testWithCommentMarkerAndSetFlag() {
        final CSVFormat noComment = CSVFormat.newFormat(',');
        assertFalse(noComment.isCommentMarkerSet());
        final CSVFormat withComment = noComment.withCommentMarker('#');
        assertTrue(withComment.isCommentMarkerSet());
        assertEquals(Character.valueOf('#'), withComment.getCommentMarker());
    }

    @Test
    public void testWithCommentMarkerSameAsDelimiterThrows() {
        try {
            CSVFormat.newFormat('#').withCommentMarker('#');
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testWithCommentMarkerSameAsQuoteThrows() {
        try {
            CSVFormat.newFormat(',').withQuote('#').withCommentMarker('#');
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testWithCommentMarkerSameAsEscapeThrows() {
        try {
            CSVFormat.newFormat(',').withEscape('#').withCommentMarker('#');
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testNoEscapeAndQuoteModeNoneThrows() {
        try {
            CSVFormat.newFormat(',').withQuoteMode(QuoteMode.NONE);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testQuoteModeNoneWithEscapeIsAllowed() {
        final CSVFormat format = CSVFormat.newFormat(',').withEscape('\\').withQuoteMode(QuoteMode.NONE);
        assertEquals(QuoteMode.NONE, format.getQuoteMode());
    }

    @Test
    public void testWithHeaderStringArray() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("A", "B", "C");
        assertArrayEquals(new String[] {"A", "B", "C"}, format.getHeader());
    }

    @Test
    public void testGetHeaderReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("A", "B");
        final String[] header1 = format.getHeader();
        header1[0] = "MUTATED";
        final String[] header2 = format.getHeader();
        assertEquals("A", header2[0]);
    }

    @Test
    public void testWithHeaderDuplicateThrows() {
        try {
            CSVFormat.DEFAULT.withHeader("A", "B", "A");
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testWithHeaderNullDisablesHeader() {
        final CSVFormat withHeader = CSVFormat.DEFAULT.withHeader("A");
        final CSVFormat withoutHeader = withHeader.withHeader((String[]) null);
        assertNull(withoutHeader.getHeader());
    }

    @Test
    public void testWithHeaderEnum() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader(Header.class);
        assertArrayEquals(new String[] {"Name", "Email", "Phone"}, format.getHeader());
    }

    @Test
    public void testWithHeaderEnumNull() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader((Class<? extends Enum<?>>) null);
        assertNull(format.getHeader());
    }

    @Test
    public void testWithFirstRecordAsHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.withFirstRecordAsHeader();
        assertNotNull(format.getHeader());
        assertEquals(0, format.getHeader().length);
        assertTrue(format.getSkipHeaderRecord());
    }

    @Test
    public void testWithHeaderComments() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeaderComments("line1", "line2");
        assertArrayEquals(new String[] {"line1", "line2"}, format.getHeaderComments());
    }

    @Test
    public void testWithHeaderCommentsNull() {
        final CSVFormat withComments = CSVFormat.DEFAULT.withHeaderComments("line1");
        final CSVFormat withoutComments = withComments.withHeaderComments((Object[]) null);
        assertNull(withoutComments.getHeaderComments());
    }

    @Test
    public void testWithIgnoreEmptyLinesNoArg() {
        final CSVFormat format = CSVFormat.newFormat(',').withIgnoreEmptyLines();
        assertTrue(format.getIgnoreEmptyLines());
    }

    @Test
    public void testWithIgnoreHeaderCase() {
        final CSVFormat format = CSVFormat.newFormat(',').withIgnoreHeaderCase();
        assertTrue(format.getIgnoreHeaderCase());
        final CSVFormat format2 = format.withIgnoreHeaderCase(false);
        assertFalse(format2.getIgnoreHeaderCase());
    }

    @Test
    public void testWithIgnoreSurroundingSpaces() {
        final CSVFormat format = CSVFormat.newFormat(',').withIgnoreSurroundingSpaces();
        assertTrue(format.getIgnoreSurroundingSpaces());
    }

    @Test
    public void testWithNullString() {
        final CSVFormat noNull = CSVFormat.newFormat(',');
        assertFalse(noNull.isNullStringSet());
        final CSVFormat withNull = noNull.withNullString("N/A");
        assertTrue(withNull.isNullStringSet());
        assertEquals("N/A", withNull.getNullString());
    }

    @Test
    public void testWithQuoteMode() {
        final CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL);
        assertEquals(QuoteMode.ALL, format.getQuoteMode());
    }

    @Test
    public void testWithRecordSeparatorChar() {
        final CSVFormat format = CSVFormat.newFormat(',').withRecordSeparator('\n');
        assertEquals("\n", format.getRecordSeparator());
    }

    @Test
    public void testWithSkipHeaderRecord() {
        final CSVFormat format = CSVFormat.newFormat(',').withSkipHeaderRecord();
        assertTrue(format.getSkipHeaderRecord());
        final CSVFormat format2 = format.withSkipHeaderRecord(false);
        assertFalse(format2.getSkipHeaderRecord());
    }

    @Test
    public void testWithTrailingDelimiter() {
        final CSVFormat format = CSVFormat.newFormat(',').withTrailingDelimiter();
        assertTrue(format.getTrailingDelimiter());
    }

    @Test
    public void testWithTrim() {
        final CSVFormat format = CSVFormat.newFormat(',').withTrim();
        assertTrue(format.getTrim());
        final CSVFormat format2 = format.withTrim(false);
        assertFalse(format2.getTrim());
    }

    @Test
    public void testWithAllowMissingColumnNames() {
        final CSVFormat format = CSVFormat.newFormat(',').withAllowMissingColumnNames();
        assertTrue(format.getAllowMissingColumnNames());
    }

    @Test
    public void testEqualsAndHashCode() {
        final CSVFormat a = CSVFormat.DEFAULT.withHeader("A", "B");
        final CSVFormat b = CSVFormat.DEFAULT.withHeader("A", "B");
        assertTrue(a.equals(b));
        assertTrue(b.equals(a));
        assertEquals(a.hashCode(), b.hashCode());
        assertTrue(a.equals(a));
        assertFalse(a.equals(null));
        assertFalse(a.equals("not a CSVFormat"));

        final CSVFormat c = CSVFormat.DEFAULT.withHeader("A", "C");
        assertFalse(a.equals(c));
    }

    @Test
    public void testFormatValues() {
        final String result = CSVFormat.DEFAULT.format("a", "b", "c");
        assertEquals("a,b,c", result);
    }

    @Test
    public void testFormatWithQuotingNeeded() {
        final String result = CSVFormat.DEFAULT.format("a,b", "c");
        assertEquals("\"a,b\",c", result);
    }

    @Test
    public void testPrintRecordAddsSeparator() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.printRecord(writer, "x", "y");
        assertEquals("x,y\r\n", writer.toString());
    }

    @Test
    public void testPrintSingleValue() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.print("value", writer, true);
        assertEquals("value", writer.toString());
    }

    @Test
    public void testPrintNotNewRecordPrependsDelimiter() throws IOException {
        final StringWriter writer = new StringWriter();
        CSVFormat.DEFAULT.print("value", writer, false);
        assertEquals(",value", writer.toString());
    }

    @Test
    public void testPrintNullValueUsesNullString() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withNullString("NULL");
        final StringWriter writer = new StringWriter();
        format.print(null, writer, true);
        assertEquals("NULL", writer.toString());
    }

    @Test
    public void testPrintlnWithTrailingDelimiter() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withTrailingDelimiter();
        final StringWriter writer = new StringWriter();
        format.println(writer);
        assertEquals(",\r\n", writer.toString());
    }

    @Test
    public void testParseReturnsParser() throws IOException {
        final java.io.StringReader reader = new java.io.StringReader("a,b,c\n");
        final CSVParser parser = CSVFormat.DEFAULT.parse(reader);
        assertNotNull(parser);
        parser.close();
    }

    @Test
    public void testPrintReturnsPrinter() throws IOException {
        final StringWriter writer = new StringWriter();
        final CSVPrinter printer = CSVFormat.DEFAULT.print(writer);
        assertNotNull(printer);
        printer.close();
    }

    @Test
    public void testToStringContainsDelimiter() {
        final String s = CSVFormat.DEFAULT.toString();
        assertTrue(s.contains("Delimiter=<,>"));
    }

    @Test
    public void testPredefinedEnumGetFormat() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.Predefined.Default.getFormat());
        assertEquals(CSVFormat.EXCEL, CSVFormat.Predefined.Excel.getFormat());
        assertEquals(CSVFormat.MYSQL, CSVFormat.Predefined.MySQL.getFormat());
        assertEquals(CSVFormat.RFC4180, CSVFormat.Predefined.RFC4180.getFormat());
        assertEquals(CSVFormat.TDF, CSVFormat.Predefined.TDF.getFormat());
        assertEquals(CSVFormat.INFORMIX_UNLOAD, CSVFormat.Predefined.InformixUnload.getFormat());
        assertEquals(CSVFormat.INFORMIX_UNLOAD_CSV, CSVFormat.Predefined.InformixUnloadCsv.getFormat());
    }

    @Test
    public void testInformixUnloadFormat() {
        final CSVFormat format = CSVFormat.INFORMIX_UNLOAD;
        assertEquals('|', format.getDelimiter());
        assertEquals(Character.valueOf('\\'), format.getEscapeCharacter());
        assertEquals(Character.valueOf('"'), format.getQuoteCharacter());
        assertEquals("\n", format.getRecordSeparator());
    }
}
