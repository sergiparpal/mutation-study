/*
 * Copyright (C) 2010 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.gson.stream;

import java.io.EOFException;
import java.io.IOException;
import java.io.StringReader;
import junit.framework.TestCase;

@SuppressWarnings("resource")
public final class JsonReaderAgentTest extends TestCase {

  public void testConstructorRejectsNull() {
    try {
      new JsonReader(null);
      fail();
    } catch (NullPointerException expected) {
    }
  }

  public void testEmptyArray() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[]"));
    reader.beginArray();
    assertFalse(reader.hasNext());
    reader.endArray();
    assertEquals(JsonToken.END_DOCUMENT, reader.peek());
  }

  public void testEmptyObject() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("{}"));
    reader.beginObject();
    assertFalse(reader.hasNext());
    reader.endObject();
    assertEquals(JsonToken.END_DOCUMENT, reader.peek());
  }

  public void testObjectWithNameValuePairs() throws IOException {
    JsonReader reader = new JsonReader(new StringReader(
        "{\"a\":1,\"b\":\"two\",\"c\":true,\"d\":null}"));
    reader.beginObject();
    assertEquals("a", reader.nextName());
    assertEquals(1, reader.nextInt());
    assertEquals("b", reader.nextName());
    assertEquals("two", reader.nextString());
    assertEquals("c", reader.nextName());
    assertTrue(reader.nextBoolean());
    assertEquals("d", reader.nextName());
    reader.nextNull();
    reader.endObject();
  }

  public void testNestedArraysAndObjects() throws IOException {
    JsonReader reader = new JsonReader(new StringReader(
        "[1,[2,3],{\"x\":4}]"));
    reader.beginArray();
    assertEquals(1, reader.nextInt());
    reader.beginArray();
    assertEquals(2, reader.nextInt());
    assertEquals(3, reader.nextInt());
    reader.endArray();
    reader.beginObject();
    assertEquals("x", reader.nextName());
    assertEquals(4, reader.nextInt());
    reader.endObject();
    reader.endArray();
  }

  public void testBeginArrayOnObjectThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("{}"));
    try {
      reader.beginArray();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testBeginObjectOnArrayThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[]"));
    try {
      reader.beginObject();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testEndArrayTooEarlyThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1,2]"));
    reader.beginArray();
    try {
      reader.endArray();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testNextNameWhenNotAtNameThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1]"));
    reader.beginArray();
    try {
      reader.nextName();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testNextStringForNumber() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[123]"));
    reader.beginArray();
    assertEquals("123", reader.nextString());
    reader.endArray();
  }

  public void testNextIntForQuotedNumericString() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[\"123\"]"));
    reader.beginArray();
    assertEquals(123, reader.nextInt());
    reader.endArray();
  }

  public void testNextIntOnNonNumericStringThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[\"abc\"]"));
    reader.beginArray();
    try {
      reader.nextInt();
      fail();
    } catch (NumberFormatException expected) {
    }
  }

  public void testNextIntWithFractionalLossThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1.5]"));
    reader.beginArray();
    try {
      reader.nextInt();
      fail();
    } catch (NumberFormatException expected) {
    }
  }

  public void testNextLongLargeValue() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[9223372036854775807]"));
    reader.beginArray();
    assertEquals(Long.MAX_VALUE, reader.nextLong());
    reader.endArray();
  }

  public void testNextLongMinValue() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[-9223372036854775808]"));
    reader.beginArray();
    assertEquals(Long.MIN_VALUE, reader.nextLong());
    reader.endArray();
  }

  public void testNextDoubleForNumber() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[3.14]"));
    reader.beginArray();
    assertEquals(3.14, reader.nextDouble(), 0.0);
    reader.endArray();
  }

  public void testNextDoubleNanAsQuotedStringWithoutLenientThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[\"NaN\"]"));
    reader.beginArray();
    try {
      reader.nextDouble();
      fail();
    } catch (MalformedJsonException expected) {
    }
  }

  public void testStrictModeRejectsNanLiteral() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[NaN]"));
    reader.beginArray();
    try {
      reader.nextDouble();
      fail();
    } catch (MalformedJsonException expected) {
    }
  }

  public void testStringEscapes() throws IOException {
    JsonReader reader = new JsonReader(new StringReader(
        "[\"\\t\\b\\n\\r\\f\\\"\\\\\\u0041\"]"));
    reader.beginArray();
    assertEquals("\t\b\n\r\f\"\\A", reader.nextString());
    reader.endArray();
  }

  public void testUnterminatedStringThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[\"abc"));
    reader.beginArray();
    try {
      reader.nextString();
      fail();
    } catch (IOException expected) {
    }
  }

  public void testMalformedUnicodeEscapeThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[\"\\uZZZZ\"]"));
    reader.beginArray();
    try {
      reader.nextString();
      fail();
    } catch (NumberFormatException expected) {
    }
  }

  public void testSkipValueSkipsObject() throws IOException {
    JsonReader reader = new JsonReader(new StringReader(
        "[1,{\"a\":[1,2,3],\"b\":{\"c\":1}},2]"));
    reader.beginArray();
    assertEquals(1, reader.nextInt());
    reader.skipValue();
    assertEquals(2, reader.nextInt());
    reader.endArray();
  }

  public void testSkipValueSkipsArray() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[[1,2,3],4]"));
    reader.beginArray();
    reader.skipValue();
    assertEquals(4, reader.nextInt());
    reader.endArray();
  }

  public void testPeekReturnsEndDocumentAfterTopLevelValue() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("true"));
    reader.setLenient(true);
    assertTrue(reader.nextBoolean());
    assertEquals(JsonToken.END_DOCUMENT, reader.peek());
  }

  public void testTopLevelValueWithoutLenientThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("true"));
    try {
      reader.nextBoolean();
      fail();
    } catch (IOException expected) {
    }
  }

  public void testMultipleTopLevelValuesRequireLenient() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1][2]"));
    reader.setLenient(true);
    reader.beginArray();
    assertEquals(1, reader.nextInt());
    reader.endArray();
    reader.beginArray();
    assertEquals(2, reader.nextInt());
    reader.endArray();
  }

  public void testCommentsRequireLenient() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1 // comment\n]"));
    try {
      reader.beginArray();
      reader.nextInt();
      reader.hasNext();
      fail();
    } catch (MalformedJsonException expected) {
    }
  }

  public void testCommentsWithLenient() throws IOException {
    JsonReader reader = new JsonReader(new StringReader(
        "[1 // comment\n, 2 /* block */, 3]"));
    reader.setLenient(true);
    reader.beginArray();
    assertEquals(1, reader.nextInt());
    assertEquals(2, reader.nextInt());
    assertEquals(3, reader.nextInt());
    reader.endArray();
  }

  public void testUnquotedNamesAndValuesRequireLenient() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("{a:b}"));
    try {
      reader.beginObject();
      reader.nextName();
      fail();
    } catch (MalformedJsonException expected) {
    }
  }

  public void testUnquotedNamesAndValuesWithLenient() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("{a:b}"));
    reader.setLenient(true);
    reader.beginObject();
    assertEquals("a", reader.nextName());
    assertEquals("b", reader.nextString());
    reader.endObject();
  }

  public void testSingleQuotedStrings() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("['hello']"));
    reader.setLenient(true);
    reader.beginArray();
    assertEquals("hello", reader.nextString());
    reader.endArray();
  }

  public void testNonExecutePrefix() throws IOException {
    JsonReader reader = new JsonReader(new StringReader(")]}'\n[1]"));
    reader.setLenient(true);
    reader.beginArray();
    assertEquals(1, reader.nextInt());
    reader.endArray();
  }

  public void testNonExecutePrefixRequiresLenient() throws IOException {
    JsonReader reader = new JsonReader(new StringReader(")]}'\n[1]"));
    try {
      reader.beginArray();
      fail();
    } catch (IOException expected) {
    }
  }

  public void testCloseThenOperationThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1]"));
    reader.close();
    try {
      reader.beginArray();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testEmptyReaderThrowsEOF() throws IOException {
    JsonReader reader = new JsonReader(new StringReader(""));
    try {
      reader.beginArray();
      fail();
    } catch (EOFException expected) {
    }
  }

  public void testPeekDoesNotConsume() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1]"));
    reader.beginArray();
    assertEquals(JsonToken.NUMBER, reader.peek());
    assertEquals(JsonToken.NUMBER, reader.peek());
    assertEquals(1, reader.nextInt());
    reader.endArray();
  }

  public void testLenientZeroLengthArrayElementMeansNull() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[,,1]"));
    reader.setLenient(true);
    reader.beginArray();
    assertEquals(JsonToken.NULL, reader.peek());
    reader.nextNull();
    assertEquals(JsonToken.NULL, reader.peek());
    reader.nextNull();
    assertEquals(1, reader.nextInt());
    reader.endArray();
  }

  public void testGetPathTracksArrayIndices() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1,2,3]"));
    assertEquals("$", reader.getPath());
    reader.beginArray();
    assertEquals("$[0]", reader.getPath());
    reader.nextInt();
    assertEquals("$[1]", reader.getPath());
    reader.nextInt();
    assertEquals("$[2]", reader.getPath());
    reader.nextInt();
    reader.endArray();
    assertEquals("$", reader.getPath());
  }

  public void testGetPathTracksObjectNames() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("{\"a\":1}"));
    reader.beginObject();
    reader.nextName();
    assertEquals("$.a", reader.getPath());
    reader.nextInt();
    reader.endObject();
  }

  public void testLongValueAsString() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[\"-9223372036854775808\"]"));
    reader.beginArray();
    assertEquals(Long.MIN_VALUE, reader.nextLong());
    reader.endArray();
  }

  public void testNumberWithLeadingZeroRequiresLenient() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[01]"));
    try {
      reader.beginArray();
      reader.nextInt();
      fail();
    } catch (MalformedJsonException expected) {
    }
  }

  public void testBooleanTrueFalse() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[true,false]"));
    reader.beginArray();
    assertTrue(reader.nextBoolean());
    assertFalse(reader.nextBoolean());
    reader.endArray();
  }

  public void testNextBooleanOnNonBooleanThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1]"));
    reader.beginArray();
    try {
      reader.nextBoolean();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testNextNullOnNonNullThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1]"));
    reader.beginArray();
    try {
      reader.nextNull();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testSetAndIsLenient() {
    JsonReader reader = new JsonReader(new StringReader("[]"));
    assertFalse(reader.isLenient());
    reader.setLenient(true);
    assertTrue(reader.isLenient());
    reader.setLenient(false);
    assertFalse(reader.isLenient());
  }

  public void testNumberAsStringWithExponent() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1.5e10]"));
    reader.beginArray();
    assertEquals(1.5e10, reader.nextDouble(), 0.0);
    reader.endArray();
  }

  public void testNextLongOnNonParsableStringFallsBackToDoubleAndThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[\"1.5\"]"));
    reader.beginArray();
    try {
      reader.nextLong();
      fail();
    } catch (NumberFormatException expected) {
    }
  }
}
