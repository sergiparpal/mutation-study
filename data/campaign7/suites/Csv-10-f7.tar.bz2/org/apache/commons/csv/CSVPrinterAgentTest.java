/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.csv;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.Closeable;
import java.io.Flushable;
import java.io.IOException;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;

public class CSVPrinterAgentTest {

    /** A simple Appendable that is also Closeable and Flushable, to observe close()/flush() delegation. */
    private static class TrackingAppendable implements Appendable, Closeable, Flushable {
        private final StringBuilder sb = new StringBuilder();
        private boolean closed = false;
        private boolean flushed = false;

        public Appendable append(final CharSequence csq) throws IOException {
            sb.append(csq);
            return this;
        }

        public Appendable append(final CharSequence csq, final int start, final int end) throws IOException {
            sb.append(csq, start, end);
            return this;
        }

        public Appendable append(final char c) throws IOException {
            sb.append(c);
            return this;
        }

        public void close() throws IOException {
            closed = true;
        }

        public void flush() throws IOException {
            flushed = true;
        }

        public String toString() {
            return sb.toString();
        }
    }

    // ======================================================
    // constructor
    // ======================================================

    @Test
    public void testConstructorRejectsNullAppendable() throws IOException {
        try {
            new CSVPrinter(null, CSVFormat.DEFAULT);
            fail("expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testConstructorRejectsNullFormat() throws IOException {
        try {
            new CSVPrinter(new StringWriter(), null);
            fail("expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testConstructorRejectsInconsistentFormat() throws IOException {
        // quote char equal to delimiter is invalid
        final CSVFormat broken = CSVFormat.DEFAULT.withQuoteChar(',');
        try {
            new CSVPrinter(new StringWriter(), broken);
            fail("expected IllegalStateException");
        } catch (final IllegalStateException e) {
            // expected
        }
    }

    @Test
    public void testConstructorRejectsNoneQuotePolicyWithoutEscape() throws IOException {
        final CSVFormat broken = CSVFormat.DEFAULT.withQuotePolicy(Quote.NONE);
        try {
            new CSVPrinter(new StringWriter(), broken);
            fail("expected IllegalStateException");
        } catch (final IllegalStateException e) {
            // expected
        }
    }

    @Test
    public void testGetOutReturnsSameInstance() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        assertSame(sw, printer.getOut());
    }

    // ======================================================
    // print(Object)
    // ======================================================

    @Test
    public void testPrintSimpleValue() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("abc");
        assertEquals("abc", sw.toString());
    }

    @Test
    public void testPrintAddsDelimiterBetweenValues() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("a");
        printer.print("b");
        assertEquals("a,b", sw.toString());
    }

    @Test
    public void testPrintNullWithoutNullStringWritesEmptyAndIsQuotedAsFirstValue() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print(null);
        // an empty token that is the only (first) one on the line must be quoted,
        // otherwise the line would carry no token at all.
        assertEquals("\"\"", sw.toString());
    }

    @Test
    public void testPrintNullWithNullStringWritesNullString() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT.withNullString("N/A"));
        printer.print(null);
        assertEquals("N/A", sw.toString());
    }

    // ======================================================
    // quoting - MINIMAL (default)
    // ======================================================

    @Test
    public void testMinimalQuotingQuotesValueContainingDelimiter() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("a,b");
        assertEquals("\"a,b\"", sw.toString());
    }

    @Test
    public void testMinimalQuotingDoublesEmbeddedQuoteChar() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("a\"b");
        assertEquals("\"a\"\"b\"", sw.toString());
    }

    @Test
    public void testMinimalQuotingLeavesPlainValueUnquoted() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("a");
        printer.print("plain");
        assertEquals("a,plain", sw.toString());
    }

    @Test
    public void testMinimalQuotingQuotesValueEndingInSpace() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("abc ");
        assertEquals("\"abc \"", sw.toString());
    }

    // ======================================================
    // quoting - ALL
    // ======================================================

    @Test
    public void testAllQuotePolicyQuotesEveryValue() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT.withQuotePolicy(Quote.ALL));
        printer.print("abc");
        printer.print(Integer.valueOf(5));
        assertEquals("\"abc\",\"5\"", sw.toString());
    }

    // ======================================================
    // quoting - NON_NUMERIC
    // ======================================================

    @Test
    public void testNonNumericQuotePolicyLeavesNumbersUnquoted() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT.withQuotePolicy(Quote.NON_NUMERIC));
        printer.print(Integer.valueOf(5));
        assertEquals("5", sw.toString());
    }

    @Test
    public void testNonNumericQuotePolicyQuotesStrings() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT.withQuotePolicy(Quote.NON_NUMERIC));
        printer.print("abc");
        assertEquals("\"abc\"", sw.toString());
    }

    // ======================================================
    // quoting - NONE (falls back to escaping)
    // ======================================================

    @Test
    public void testNoneQuotePolicyEscapesDelimiterInsteadOfQuoting() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.withQuotePolicy(Quote.NONE).withEscape('\\');
        final CSVPrinter printer = new CSVPrinter(sw, format);
        printer.print("a,b");
        assertEquals("a\\,b", sw.toString());
    }

    @Test
    public void testPureEscapingFormatEscapesEscapeCharItself() throws IOException {
        final StringWriter sw = new StringWriter();
        // MYSQL has no quote char, only escaping
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.MYSQL);
        printer.print("a\\b");
        final String expected = "a" + '\\' + '\\' + "b";
        assertEquals(expected, sw.toString());
    }

    @Test
    public void testPureEscapingFormatEscapesNewlines() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.MYSQL);
        printer.print("a\nb\rc");
        assertEquals("a\\nb\\rc", sw.toString());
    }

    // ======================================================
    // println
    // ======================================================

    @Test
    public void testPrintlnWritesRecordSeparator() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.println();
        assertEquals("\r\n", sw.toString());
    }

    @Test
    public void testPrintlnResetsNewRecordSoNoLeadingDelimiter() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("a");
        printer.println();
        printer.print("b");
        assertEquals("a\r\nb", sw.toString());
    }

    // ======================================================
    // printRecord
    // ======================================================

    @Test
    public void testPrintRecordVarargs() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecord("a", "b", "c");
        assertEquals("a,b,c\r\n", sw.toString());
    }

    @Test
    public void testPrintRecordIterable() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final List<String> values = new ArrayList<String>();
        values.add("x");
        values.add("y");
        printer.printRecord(values);
        assertEquals("x,y\r\n", sw.toString());
    }

    @Test
    public void testPrintRecordEmptyVarargsStillWritesSeparator() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecord(new Object[0]);
        assertEquals("\r\n", sw.toString());
    }

    // ======================================================
    // printRecords
    // ======================================================

    @Test
    public void testPrintRecordsObjectArrayOfArrays() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final Object[] records = new Object[] {
            new String[] { "a", "b" },
            new String[] { "c", "d" }
        };
        printer.printRecords(records);
        assertEquals("a,b\r\nc,d\r\n", sw.toString());
    }

    @Test
    public void testPrintRecordsIterableOfIterables() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final List<List<String>> records = new ArrayList<List<String>>();
        records.add(Arrays.asList("a", "b"));
        records.add(Arrays.asList("c", "d"));
        printer.printRecords(records);
        assertEquals("a,b\r\nc,d\r\n", sw.toString());
    }

    @Test
    public void testPrintRecordsFlatIterableTreatsEachElementAsOwnRecord() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final List<String> flat = new ArrayList<String>();
        flat.add("a");
        flat.add("b");
        printer.printRecords(flat);
        assertEquals("a\r\nb\r\n", sw.toString());
    }

    // ======================================================
    // printComment
    // ======================================================

    @Test
    public void testPrintCommentDoesNothingWhenCommentsDisabled() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printComment("a comment");
        assertEquals("", sw.toString());
    }

    @Test
    public void testPrintCommentSingleLine() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT.withCommentStart('#'));
        printer.printComment("foo");
        assertEquals("# foo\r\n", sw.toString());
    }

    @Test
    public void testPrintCommentMultiLine() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT.withCommentStart('#'));
        printer.printComment("foo\nbar");
        assertEquals("# foo\r\n# bar\r\n", sw.toString());
    }

    @Test
    public void testPrintCommentStartsOnNewLineWhenMidRecord() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT.withCommentStart('#'));
        printer.print("a");
        printer.printComment("x");
        assertEquals("a\r\n# x\r\n", sw.toString());
    }

    // ======================================================
    // close / flush
    // ======================================================

    @Test
    public void testCloseDelegatesToCloseableOut() throws IOException {
        final TrackingAppendable ta = new TrackingAppendable();
        final CSVPrinter printer = new CSVPrinter(ta, CSVFormat.DEFAULT);
        printer.close();
        assertTrue(ta.closed);
    }

    @Test
    public void testCloseOnNonCloseableOutDoesNotThrow() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.close();
        // no exception expected
        assertEquals("", sb.toString());
    }

    @Test
    public void testFlushDelegatesToFlushableOut() throws IOException {
        final TrackingAppendable ta = new TrackingAppendable();
        final CSVPrinter printer = new CSVPrinter(ta, CSVFormat.DEFAULT);
        assertFalse(ta.flushed);
        printer.flush();
        assertTrue(ta.flushed);
    }

    @Test
    public void testFlushOnNonFlushableOutDoesNotThrow() throws IOException {
        final StringBuilder sb = new StringBuilder();
        final CSVPrinter printer = new CSVPrinter(sb, CSVFormat.DEFAULT);
        printer.flush();
        assertEquals("", sb.toString());
    }
}
