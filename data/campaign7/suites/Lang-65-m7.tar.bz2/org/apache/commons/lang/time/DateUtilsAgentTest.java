/*
 * Copyright 2002-2005 The Apache Software Foundation.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang.time;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.NoSuchElementException;

import junit.framework.TestCase;

/**
 * Self-contained TestCase for {@link DateUtils}.
 */
public class DateUtilsAgentTest extends TestCase {

    public DateUtilsAgentTest(String name) {
        super(name);
    }

    private Calendar newCal(int year, int month, int day, int hour, int minute, int second, int millis) {
        Calendar cal = new GregorianCalendar(year, month, day, hour, minute, second);
        cal.set(Calendar.MILLISECOND, millis);
        return cal;
    }

    //-----------------------------------------------------------------------
    // isSameDay
    //-----------------------------------------------------------------------

    public void testIsSameDayDate() {
        Date date1 = newCal(2002, Calendar.MARCH, 28, 13, 45, 0, 0).getTime();
        Date date2 = newCal(2002, Calendar.MARCH, 28, 6, 1, 0, 0).getTime();
        Date date3 = newCal(2002, Calendar.MARCH, 12, 13, 45, 0, 0).getTime();
        assertTrue(DateUtils.isSameDay(date1, date2));
        assertFalse(DateUtils.isSameDay(date1, date3));
        try {
            DateUtils.isSameDay((Date) null, date1);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
        try {
            DateUtils.isSameDay(date1, (Date) null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testIsSameDayCalendar() {
        Calendar cal1 = newCal(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        Calendar cal2 = newCal(2002, Calendar.MARCH, 28, 6, 1, 0, 0);
        Calendar cal3 = newCal(2002, Calendar.MARCH, 12, 13, 45, 0, 0);
        assertTrue(DateUtils.isSameDay(cal1, cal2));
        assertFalse(DateUtils.isSameDay(cal1, cal3));
        try {
            DateUtils.isSameDay((Calendar) null, cal1);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // isSameInstant
    //-----------------------------------------------------------------------

    public void testIsSameInstantDate() {
        Date date1 = new Date(1000L);
        Date date2 = new Date(1000L);
        Date date3 = new Date(2000L);
        assertTrue(DateUtils.isSameInstant(date1, date2));
        assertFalse(DateUtils.isSameInstant(date1, date3));
        try {
            DateUtils.isSameInstant((Date) null, date1);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testIsSameInstantCalendar() {
        Calendar cal1 = Calendar.getInstance();
        cal1.setTimeInMillis(1000L);
        Calendar cal2 = Calendar.getInstance();
        cal2.setTimeInMillis(1000L);
        Calendar cal3 = Calendar.getInstance();
        cal3.setTimeInMillis(2000L);
        assertTrue(DateUtils.isSameInstant(cal1, cal2));
        assertFalse(DateUtils.isSameInstant(cal1, cal3));
        try {
            DateUtils.isSameInstant(cal1, (Calendar) null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // isSameLocalTime
    //-----------------------------------------------------------------------

    public void testIsSameLocalTime() {
        Calendar cal1 = newCal(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        Calendar cal2 = newCal(2002, Calendar.MARCH, 28, 13, 45, 0, 0);
        assertTrue(DateUtils.isSameLocalTime(cal1, cal2));

        Calendar cal3 = newCal(2002, Calendar.MARCH, 28, 13, 46, 0, 0);
        assertFalse(DateUtils.isSameLocalTime(cal1, cal3));

        // documents the actual behaviour: HOUR (12h clock) is compared, not
        // HOUR_OF_DAY or AM_PM, so 1am and 1pm on the same day are "equal"
        Calendar am = newCal(2002, Calendar.MARCH, 28, 1, 0, 0, 0);
        Calendar pm = newCal(2002, Calendar.MARCH, 28, 13, 0, 0, 0);
        assertTrue(DateUtils.isSameLocalTime(am, pm));

        // different calendar class -> not equal even with the same fields
        Calendar other = new GregorianCalendar(2002, Calendar.MARCH, 28, 13, 45, 0) {
            // anonymous subclass => different getClass()
        };
        other.set(Calendar.MILLISECOND, 0);
        assertFalse(DateUtils.isSameLocalTime(cal1, other));

        try {
            DateUtils.isSameLocalTime((Calendar) null, cal1);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // parseDate
    //-----------------------------------------------------------------------

    public void testParseDateFirstPatternMatches() throws Exception {
        Date date = DateUtils.parseDate("2002-03-28", new String[] {"yyyy-MM-dd"});
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        assertEquals(2002, cal.get(Calendar.YEAR));
        assertEquals(Calendar.MARCH, cal.get(Calendar.MONTH));
        assertEquals(28, cal.get(Calendar.DAY_OF_MONTH));
    }

    public void testParseDateFallsBackToSecondPattern() throws Exception {
        Date date = DateUtils.parseDate("28/03/2002", new String[] {"yyyy-MM-dd", "dd/MM/yyyy"});
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        assertEquals(2002, cal.get(Calendar.YEAR));
        assertEquals(Calendar.MARCH, cal.get(Calendar.MONTH));
        assertEquals(28, cal.get(Calendar.DAY_OF_MONTH));
    }

    public void testParseDateNoPatternMatches() {
        try {
            DateUtils.parseDate("2002-03-28X", new String[] {"yyyy-MM-dd"});
            fail("Expected ParseException");
        } catch (ParseException e) {
            // expected
        }
    }

    public void testParseDatePartialMatchFails() {
        // the parser must consume the whole string, not just a prefix
        try {
            DateUtils.parseDate("2002-03-28 garbage", new String[] {"yyyy-MM-dd"});
            fail("Expected ParseException");
        } catch (ParseException e) {
            // expected
        }
    }

    public void testParseDateNullArguments() {
        try {
            DateUtils.parseDate(null, new String[] {"yyyy-MM-dd"});
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        } catch (ParseException e) {
            fail("Expected IllegalArgumentException, not ParseException");
        }
        try {
            DateUtils.parseDate("2002-03-28", null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        } catch (ParseException e) {
            fail("Expected IllegalArgumentException, not ParseException");
        }
    }

    //-----------------------------------------------------------------------
    // add* methods
    //-----------------------------------------------------------------------

    public void testAddYears() {
        Date base = newCal(2002, Calendar.MARCH, 28, 0, 0, 0, 0).getTime();
        Date result = DateUtils.addYears(base, 1);
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(2003, cal.get(Calendar.YEAR));
        // original date object must be unchanged
        Calendar baseCal = Calendar.getInstance();
        baseCal.setTime(base);
        assertEquals(2002, baseCal.get(Calendar.YEAR));
    }

    public void testAddMonthsNegativeCrossesYearBoundary() {
        Date base = newCal(2002, Calendar.JANUARY, 15, 0, 0, 0, 0).getTime();
        Date result = DateUtils.addMonths(base, -1);
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(2001, cal.get(Calendar.YEAR));
        assertEquals(Calendar.DECEMBER, cal.get(Calendar.MONTH));
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH));
    }

    public void testAddWeeks() {
        Date base = newCal(2002, Calendar.MARCH, 28, 0, 0, 0, 0).getTime();
        Date result = DateUtils.addWeeks(base, 1);
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(Calendar.APRIL, cal.get(Calendar.MONTH));
        assertEquals(4, cal.get(Calendar.DAY_OF_MONTH));
    }

    public void testAddDays() {
        Date base = newCal(2002, Calendar.MARCH, 28, 0, 0, 0, 0).getTime();
        Date result = DateUtils.addDays(base, 5);
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(Calendar.APRIL, cal.get(Calendar.MONTH));
        assertEquals(2, cal.get(Calendar.DAY_OF_MONTH));
    }

    public void testAddHours() {
        Date base = newCal(2002, Calendar.MARCH, 28, 23, 0, 0, 0).getTime();
        Date result = DateUtils.addHours(base, 2);
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(Calendar.MARCH, cal.get(Calendar.MONTH));
        assertEquals(29, cal.get(Calendar.DAY_OF_MONTH));
        assertEquals(1, cal.get(Calendar.HOUR_OF_DAY));
    }

    public void testAddMinutes() {
        Date base = newCal(2002, Calendar.MARCH, 28, 0, 59, 0, 0).getTime();
        Date result = DateUtils.addMinutes(base, 2);
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(1, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals(1, cal.get(Calendar.MINUTE));
    }

    public void testAddSeconds() {
        Date base = newCal(2002, Calendar.MARCH, 28, 0, 0, 59, 0).getTime();
        Date result = DateUtils.addSeconds(base, 2);
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(1, cal.get(Calendar.MINUTE));
        assertEquals(1, cal.get(Calendar.SECOND));
    }

    public void testAddMilliseconds() {
        Date base = new Date(0L);
        Date result = DateUtils.addMilliseconds(base, 500);
        assertEquals(500L, result.getTime());
        assertEquals(0L, base.getTime());
    }

    public void testAddWithNullDateThrows() {
        try {
            DateUtils.add(null, Calendar.DATE, 1);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testAddZeroAmountReturnsEquivalentButDifferentInstant() {
        Date base = newCal(2002, Calendar.MARCH, 28, 10, 0, 0, 0).getTime();
        Date result = DateUtils.add(base, Calendar.DATE, 0);
        assertEquals(base.getTime(), result.getTime());
    }

    //-----------------------------------------------------------------------
    // round
    //-----------------------------------------------------------------------

    public void testRoundDateHourAndMonth() {
        Date base = newCal(2002, Calendar.MARCH, 28, 13, 45, 1, 231).getTime();

        Date roundedHour = DateUtils.round(base, Calendar.HOUR_OF_DAY);
        Calendar cal = Calendar.getInstance();
        cal.setTime(roundedHour);
        assertEquals(2002, cal.get(Calendar.YEAR));
        assertEquals(Calendar.MARCH, cal.get(Calendar.MONTH));
        assertEquals(28, cal.get(Calendar.DAY_OF_MONTH));
        assertEquals(14, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, cal.get(Calendar.MINUTE));
        assertEquals(0, cal.get(Calendar.SECOND));
        assertEquals(0, cal.get(Calendar.MILLISECOND));

        Date roundedMonth = DateUtils.round(base, Calendar.MONTH);
        cal.setTime(roundedMonth);
        assertEquals(2002, cal.get(Calendar.YEAR));
        assertEquals(Calendar.APRIL, cal.get(Calendar.MONTH));
        assertEquals(1, cal.get(Calendar.DAY_OF_MONTH));
        assertEquals(0, cal.get(Calendar.HOUR_OF_DAY));

        // original is untouched
        Calendar baseCal = Calendar.getInstance();
        baseCal.setTime(base);
        assertEquals(13, baseCal.get(Calendar.HOUR_OF_DAY));
        assertEquals(45, baseCal.get(Calendar.MINUTE));
    }

    public void testRoundCalendarSemiMonth() {
        Calendar base = newCal(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar rounded = DateUtils.round(base, DateUtils.SEMI_MONTH);
        assertEquals(Calendar.APRIL, rounded.get(Calendar.MONTH));
        assertEquals(1, rounded.get(Calendar.DAY_OF_MONTH));
        // the original calendar must not have been mutated
        assertEquals(Calendar.MARCH, base.get(Calendar.MONTH));
        assertEquals(28, base.get(Calendar.DAY_OF_MONTH));
    }

    public void testRoundObjectDispatchesToDateAndCalendar() {
        Date dateArg = newCal(2002, Calendar.MARCH, 28, 13, 45, 1, 231).getTime();
        Calendar calArg = newCal(2002, Calendar.MARCH, 28, 13, 45, 1, 231);

        Date fromDate = DateUtils.round((Object) dateArg, Calendar.HOUR_OF_DAY);
        Date fromCal = DateUtils.round((Object) calArg, Calendar.HOUR_OF_DAY);
        assertEquals(fromDate.getTime(), fromCal.getTime());
    }

    public void testRoundNullThrows() {
        try {
            DateUtils.round((Date) null, Calendar.HOUR_OF_DAY);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
        try {
            DateUtils.round((Object) null, Calendar.HOUR_OF_DAY);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testRoundObjectWithInvalidTypeThrowsClassCastException() {
        try {
            DateUtils.round("not a date", Calendar.HOUR_OF_DAY);
            fail("Expected ClassCastException");
        } catch (ClassCastException e) {
            // expected
        }
    }

    public void testRoundWithUnsupportedFieldThrows() {
        Calendar cal = newCal(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        try {
            DateUtils.round(cal, Calendar.ZONE_OFFSET);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testRoundWithExcessiveYearThrowsArithmeticException() {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.YEAR, 280000001);
        try {
            DateUtils.round(cal, Calendar.HOUR_OF_DAY);
            fail("Expected ArithmeticException");
        } catch (ArithmeticException e) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // truncate
    //-----------------------------------------------------------------------

    public void testTruncateDateHourAndMonth() {
        Date base = newCal(2002, Calendar.MARCH, 28, 13, 45, 1, 231).getTime();

        Date truncatedHour = DateUtils.truncate(base, Calendar.HOUR_OF_DAY);
        Calendar cal = Calendar.getInstance();
        cal.setTime(truncatedHour);
        assertEquals(28, cal.get(Calendar.DAY_OF_MONTH));
        assertEquals(13, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, cal.get(Calendar.MINUTE));
        assertEquals(0, cal.get(Calendar.SECOND));
        assertEquals(0, cal.get(Calendar.MILLISECOND));

        Date truncatedMonth = DateUtils.truncate(base, Calendar.MONTH);
        cal.setTime(truncatedMonth);
        assertEquals(Calendar.MARCH, cal.get(Calendar.MONTH));
        assertEquals(1, cal.get(Calendar.DAY_OF_MONTH));
        assertEquals(0, cal.get(Calendar.HOUR_OF_DAY));
    }

    public void testTruncateCalendarSemiMonth() {
        Calendar base = newCal(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar truncated = DateUtils.truncate(base, DateUtils.SEMI_MONTH);
        assertEquals(Calendar.MARCH, truncated.get(Calendar.MONTH));
        assertEquals(16, truncated.get(Calendar.DAY_OF_MONTH));
        assertEquals(0, truncated.get(Calendar.HOUR_OF_DAY));
        // original untouched
        assertEquals(28, base.get(Calendar.DAY_OF_MONTH));
    }

    public void testTruncateObjectDispatchesToDateAndCalendar() {
        Date dateArg = newCal(2002, Calendar.MARCH, 28, 13, 45, 1, 231).getTime();
        Calendar calArg = newCal(2002, Calendar.MARCH, 28, 13, 45, 1, 231);

        Date fromDate = DateUtils.truncate((Object) dateArg, Calendar.DATE);
        Date fromCal = DateUtils.truncate((Object) calArg, Calendar.DATE);
        assertEquals(fromDate.getTime(), fromCal.getTime());
    }

    public void testTruncateNullThrows() {
        try {
            DateUtils.truncate((Calendar) null, Calendar.DATE);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testTruncateObjectWithInvalidTypeThrowsClassCastException() {
        try {
            DateUtils.truncate(new Object(), Calendar.DATE);
            fail("Expected ClassCastException");
        } catch (ClassCastException e) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // iterator
    //-----------------------------------------------------------------------

    public void testIteratorRangeWeekSunday() {
        Calendar focus = newCal(2002, Calendar.JULY, 4, 0, 0, 0, 0); // a Thursday
        Iterator it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        assertRangeBounds(it, Calendar.JUNE, 30, Calendar.JULY, 6, 7, Calendar.SUNDAY, Calendar.SATURDAY);
    }

    public void testIteratorRangeWeekMonday() {
        Calendar focus = newCal(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        Iterator it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_MONDAY);
        assertRangeBounds(it, Calendar.JULY, 1, Calendar.JULY, 7, 7, Calendar.MONDAY, Calendar.SUNDAY);
    }

    public void testIteratorRangeWeekRelative() {
        Calendar focus = newCal(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        Iterator it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_RELATIVE);
        assertRangeBounds(it, Calendar.JULY, 4, Calendar.JULY, 10, 7, Calendar.THURSDAY, Calendar.WEDNESDAY);
    }

    public void testIteratorRangeWeekCenter() {
        Calendar focus = newCal(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        Iterator it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_CENTER);
        assertRangeBounds(it, Calendar.JULY, 1, Calendar.JULY, 7, 7, Calendar.MONDAY, Calendar.SUNDAY);
    }

    public void testIteratorRangeMonthSunday() {
        Calendar focus = newCal(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        Iterator it = DateUtils.iterator(focus, DateUtils.RANGE_MONTH_SUNDAY);
        assertRangeBounds(it, Calendar.JUNE, 30, Calendar.AUGUST, 3, 35, Calendar.SUNDAY, Calendar.SATURDAY);
    }

    public void testIteratorRangeMonthMonday() {
        Calendar focus = newCal(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        Iterator it = DateUtils.iterator(focus, DateUtils.RANGE_MONTH_MONDAY);
        assertRangeBounds(it, Calendar.JULY, 1, Calendar.AUGUST, 4, 35, Calendar.MONDAY, Calendar.SUNDAY);
    }

    private void assertRangeBounds(Iterator it, int firstMonth, int firstDay, int lastMonth, int lastDay,
            int expectedCount, int firstDow, int lastDow) {
        Calendar first = null;
        Calendar last = null;
        int count = 0;
        while (it.hasNext()) {
            Calendar c = (Calendar) it.next();
            if (first == null) {
                first = c;
            }
            last = c;
            count++;
        }
        assertEquals(expectedCount, count);
        assertEquals(firstMonth, first.get(Calendar.MONTH));
        assertEquals(firstDay, first.get(Calendar.DAY_OF_MONTH));
        assertEquals(firstDow, first.get(Calendar.DAY_OF_WEEK));
        assertEquals(lastMonth, last.get(Calendar.MONTH));
        assertEquals(lastDay, last.get(Calendar.DAY_OF_MONTH));
        assertEquals(lastDow, last.get(Calendar.DAY_OF_WEEK));
    }

    public void testIteratorObjectDispatchesToDateAndCalendar() {
        Calendar focus = newCal(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        Iterator fromCal = DateUtils.iterator((Object) focus, DateUtils.RANGE_WEEK_SUNDAY);
        Iterator fromDate = DateUtils.iterator((Object) focus.getTime(), DateUtils.RANGE_WEEK_SUNDAY);
        int countCal = 0;
        while (fromCal.hasNext()) {
            fromCal.next();
            countCal++;
        }
        int countDate = 0;
        while (fromDate.hasNext()) {
            fromDate.next();
            countDate++;
        }
        assertEquals(7, countCal);
        assertEquals(countCal, countDate);
    }

    public void testIteratorNullFocusThrows() {
        try {
            DateUtils.iterator((Date) null, DateUtils.RANGE_WEEK_SUNDAY);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
        try {
            DateUtils.iterator((Object) null, DateUtils.RANGE_WEEK_SUNDAY);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testIteratorInvalidRangeStyleThrows() {
        try {
            DateUtils.iterator(new Date(), 999);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testIteratorObjectWithInvalidTypeThrowsClassCastException() {
        try {
            DateUtils.iterator("not a date", DateUtils.RANGE_WEEK_SUNDAY);
            fail("Expected ClassCastException");
        } catch (ClassCastException e) {
            // expected
        }
    }

    public void testIteratorRemoveUnsupported() {
        Iterator it = DateUtils.iterator(new Date(), DateUtils.RANGE_WEEK_SUNDAY);
        try {
            it.remove();
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException e) {
            // expected
        }
    }

    public void testIteratorExhaustedThrowsNoSuchElementException() {
        Iterator it = DateUtils.iterator(new Date(), DateUtils.RANGE_WEEK_SUNDAY);
        while (it.hasNext()) {
            it.next();
        }
        try {
            it.next();
            fail("Expected NoSuchElementException");
        } catch (NoSuchElementException e) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // constants
    //-----------------------------------------------------------------------

    public void testMillisecondConstants() {
        assertEquals(1000L, DateUtils.MILLIS_PER_SECOND);
        assertEquals(60 * 1000L, DateUtils.MILLIS_PER_MINUTE);
        assertEquals(60 * 60 * 1000L, DateUtils.MILLIS_PER_HOUR);
        assertEquals(24 * 60 * 60 * 1000L, DateUtils.MILLIS_PER_DAY);

        assertEquals(1000, DateUtils.MILLIS_IN_SECOND);
        assertEquals(60 * 1000, DateUtils.MILLIS_IN_MINUTE);
        assertEquals(60 * 60 * 1000, DateUtils.MILLIS_IN_HOUR);
        assertEquals(24 * 60 * 60 * 1000, DateUtils.MILLIS_IN_DAY);
    }

    public void testConstructorIsPublic() {
        // the no-arg constructor exists so JavaBean tools can instantiate the class
        DateUtils instance = new DateUtils();
        assertNotNull(instance);
    }
}
