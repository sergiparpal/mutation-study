/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import java.math.BigDecimal;
import java.math.BigInteger;

import junit.framework.TestCase;

/**
 * Unit tests {@link org.apache.commons.lang3.math.NumberUtils}.
 */
public class NumberUtilsAgentTest extends TestCase {

    public void testConstructorExists() {
        new NumberUtils();
    }

    //-----------------------------------------------------------------------
    // toInt / toLong / toFloat / toDouble / toByte / toShort
    //-----------------------------------------------------------------------

    public void testToInt() {
        assertEquals(0, NumberUtils.toInt(null));
        assertEquals(0, NumberUtils.toInt(""));
        assertEquals(1, NumberUtils.toInt("1"));
        assertEquals(-1, NumberUtils.toInt("-1"));
        assertEquals(0, NumberUtils.toInt("not a number"));
        assertEquals(0, NumberUtils.toInt("1.1"));
        assertEquals(Integer.MAX_VALUE, NumberUtils.toInt(String.valueOf(Integer.MAX_VALUE)));
    }

    public void testToIntWithDefault() {
        assertEquals(1, NumberUtils.toInt(null, 1));
        assertEquals(1, NumberUtils.toInt("", 1));
        assertEquals(1, NumberUtils.toInt("1", 0));
        assertEquals(2, NumberUtils.toInt("not a number", 2));
        // too big for an int, must fall back to the default
        assertEquals(2, NumberUtils.toInt("99999999999999999999", 2));
    }

    public void testToLong() {
        assertEquals(0L, NumberUtils.toLong(null));
        assertEquals(0L, NumberUtils.toLong(""));
        assertEquals(1L, NumberUtils.toLong("1"));
        assertEquals(0L, NumberUtils.toLong("not a number"));
        assertEquals(Long.MAX_VALUE, NumberUtils.toLong(String.valueOf(Long.MAX_VALUE)));
    }

    public void testToLongWithDefault() {
        assertEquals(1L, NumberUtils.toLong(null, 1L));
        assertEquals(1L, NumberUtils.toLong("", 1L));
        assertEquals(1L, NumberUtils.toLong("1", 0L));
        assertEquals(2L, NumberUtils.toLong("not a number", 2L));
    }

    public void testToFloat() {
        assertEquals(0.0f, NumberUtils.toFloat(null), 0f);
        assertEquals(0.0f, NumberUtils.toFloat(""), 0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5"), 0f);
        assertEquals(0.0f, NumberUtils.toFloat("not a number"), 0f);
    }

    public void testToFloatWithDefault() {
        assertEquals(1.1f, NumberUtils.toFloat(null, 1.1f), 0.0001f);
        assertEquals(1.1f, NumberUtils.toFloat("", 1.1f), 0.0001f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5", 0.0f), 0.0001f);
        assertEquals(2.2f, NumberUtils.toFloat("not a number", 2.2f), 0.0001f);
    }

    public void testToDouble() {
        assertEquals(0.0d, NumberUtils.toDouble(null), 0d);
        assertEquals(0.0d, NumberUtils.toDouble(""), 0d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5"), 0d);
        assertEquals(0.0d, NumberUtils.toDouble("not a number"), 0d);
    }

    public void testToDoubleWithDefault() {
        assertEquals(1.1d, NumberUtils.toDouble(null, 1.1d), 0.0001d);
        assertEquals(1.1d, NumberUtils.toDouble("", 1.1d), 0.0001d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5", 0.0d), 0.0001d);
        assertEquals(2.2d, NumberUtils.toDouble("not a number", 2.2d), 0.0001d);
    }

    public void testToByte() {
        assertEquals((byte) 0, NumberUtils.toByte(null));
        assertEquals((byte) 0, NumberUtils.toByte(""));
        assertEquals((byte) 1, NumberUtils.toByte("1"));
        assertEquals((byte) 0, NumberUtils.toByte("not a number"));
        // out of byte range, must fall back to zero
        assertEquals((byte) 0, NumberUtils.toByte("128"));
    }

    public void testToByteWithDefault() {
        assertEquals((byte) 1, NumberUtils.toByte(null, (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("", (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("1", (byte) 0));
        assertEquals((byte) 2, NumberUtils.toByte("not a number", (byte) 2));
    }

    public void testToShort() {
        assertEquals((short) 0, NumberUtils.toShort(null));
        assertEquals((short) 0, NumberUtils.toShort(""));
        assertEquals((short) 1, NumberUtils.toShort("1"));
        assertEquals((short) 0, NumberUtils.toShort("not a number"));
        // out of short range, must fall back to zero
        assertEquals((short) 0, NumberUtils.toShort("32768"));
    }

    public void testToShortWithDefault() {
        assertEquals((short) 1, NumberUtils.toShort(null, (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("", (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("1", (short) 0));
        assertEquals((short) 2, NumberUtils.toShort("not a number", (short) 2));
    }

    //-----------------------------------------------------------------------
    // createNumber
    //-----------------------------------------------------------------------

    public void testCreateNumberNull() throws Exception {
        assertNull(NumberUtils.createNumber(null));
    }

    public void testCreateNumberBlankThrows() {
        try {
            NumberUtils.createNumber("");
            fail("expected NumberFormatException for empty string");
        } catch (NumberFormatException expected) {
            // expected
        }
        try {
            NumberUtils.createNumber("   ");
            fail("expected NumberFormatException for blank string");
        } catch (NumberFormatException expected) {
            // expected
        }
    }

    public void testCreateNumberDoubleMinusReturnsNull() throws Exception {
        assertNull(NumberUtils.createNumber("--1"));
    }

    public void testCreateNumberPlainInteger() throws Exception {
        Number n = NumberUtils.createNumber("123");
        assertEquals(Integer.class, n.getClass());
        assertEquals(123, n.intValue());
    }

    public void testCreateNumberNegativeInteger() throws Exception {
        Number n = NumberUtils.createNumber("-123");
        assertEquals(Integer.class, n.getClass());
        assertEquals(-123, n.intValue());
    }

    public void testCreateNumberOverflowsToLong() throws Exception {
        String s = String.valueOf(((long) Integer.MAX_VALUE) + 1L);
        Number n = NumberUtils.createNumber(s);
        assertEquals(Long.class, n.getClass());
        assertEquals(((long) Integer.MAX_VALUE) + 1L, n.longValue());
    }

    public void testCreateNumberOverflowsToBigInteger() throws Exception {
        String s = "99999999999999999999999999999999999999";
        Number n = NumberUtils.createNumber(s);
        assertEquals(BigInteger.class, n.getClass());
        assertEquals(new BigInteger(s), n);
    }

    public void testCreateNumberLongSuffix() throws Exception {
        Number n = NumberUtils.createNumber("123L");
        assertEquals(Long.class, n.getClass());
        assertEquals(123L, n.longValue());
    }

    public void testCreateNumberFloatSuffix() throws Exception {
        Number n = NumberUtils.createNumber("1.5f");
        assertEquals(Float.class, n.getClass());
        assertEquals(1.5f, n.floatValue(), 0.0001f);
    }

    public void testCreateNumberDoubleSuffix() throws Exception {
        Number n = NumberUtils.createNumber("1.5d");
        assertEquals(Double.class, n.getClass());
        assertEquals(1.5d, n.doubleValue(), 0.0001d);
    }

    public void testCreateNumberPlainDecimal() throws Exception {
        Number n = NumberUtils.createNumber("1.5");
        assertEquals(Float.class, n.getClass());
        assertEquals(1.5f, n.floatValue(), 0.0001f);
    }

    public void testCreateNumberHex() throws Exception {
        Number n = NumberUtils.createNumber("0xFF");
        assertEquals(Integer.class, n.getClass());
        assertEquals(255, n.intValue());
    }

    public void testCreateNumberNegativeHex() throws Exception {
        Number n = NumberUtils.createNumber("-0xFF");
        assertEquals(Integer.class, n.getClass());
        assertEquals(-255, n.intValue());
    }

    public void testCreateNumberInvalidThrows() {
        try {
            NumberUtils.createNumber("not a number");
            fail("expected NumberFormatException");
        } catch (NumberFormatException expected) {
            // expected
        }
    }

    /**
     * BUG: createNumber("1.1L") throws NumberFormatException (a decimal
     * value cannot carry a long/'L' suffix), yet NumberUtils.isNumber("1.1L")
     * (tested below) reports it as a valid number. The two methods disagree
     * about the same input.
     */
    public void testCreateNumberDecimalWithLongSuffixThrows() {
        try {
            NumberUtils.createNumber("1.1L");
            fail("expected NumberFormatException: a decimal cannot have an L suffix");
        } catch (NumberFormatException expected) {
            // expected
        }
    }

    /**
     * BUG: a trailing decimal point with no following digit (e.g. "1.") is
     * a perfectly valid floating point literal in Java (Double.valueOf("1.")
     * == 1.0), but createNumber mistakes the '.' for an unrecognised type
     * qualifier (since Character.isDigit('.') is false) and throws instead
     * of returning a Float/Double of value 1.0.
     */
    public void testCreateNumberTrailingDot() throws Exception {
        Number n = NumberUtils.createNumber("1.");
        assertEquals(1.0d, n.doubleValue(), 0.0001d);
    }

    //-----------------------------------------------------------------------
    // createFloat / createDouble / createInteger / createLong /
    // createBigInteger / createBigDecimal
    //-----------------------------------------------------------------------

    public void testCreateFloat() {
        assertNull(NumberUtils.createFloat(null));
        assertEquals(1.5f, NumberUtils.createFloat("1.5").floatValue(), 0.0001f);
        try {
            NumberUtils.createFloat("not a number");
            fail("expected NumberFormatException");
        } catch (NumberFormatException expected) {
            // expected
        }
    }

    public void testCreateDouble() {
        assertNull(NumberUtils.createDouble(null));
        assertEquals(1.5d, NumberUtils.createDouble("1.5").doubleValue(), 0.0001d);
        try {
            NumberUtils.createDouble("not a number");
            fail("expected NumberFormatException");
        } catch (NumberFormatException expected) {
            // expected
        }
    }

    public void testCreateInteger() {
        assertNull(NumberUtils.createInteger(null));
        assertEquals(12, NumberUtils.createInteger("12").intValue());
        assertEquals(255, NumberUtils.createInteger("0xFF").intValue());
        try {
            NumberUtils.createInteger("not a number");
            fail("expected NumberFormatException");
        } catch (NumberFormatException expected) {
            // expected
        }
    }

    public void testCreateLong() {
        assertNull(NumberUtils.createLong(null));
        assertEquals(12L, NumberUtils.createLong("12").longValue());
        try {
            NumberUtils.createLong("not a number");
            fail("expected NumberFormatException");
        } catch (NumberFormatException expected) {
            // expected
        }
    }

    public void testCreateBigInteger() {
        assertNull(NumberUtils.createBigInteger(null));
        assertEquals(BigInteger.valueOf(12L), NumberUtils.createBigInteger("12"));
        try {
            NumberUtils.createBigInteger("not a number");
            fail("expected NumberFormatException");
        } catch (NumberFormatException expected) {
            // expected
        }
    }

    public void testCreateBigDecimal() {
        assertNull(NumberUtils.createBigDecimal(null));
        assertEquals(new BigDecimal("1.5"), NumberUtils.createBigDecimal("1.5"));
        try {
            NumberUtils.createBigDecimal("not a number");
            fail("expected NumberFormatException");
        } catch (NumberFormatException expected) {
            // expected
        }
        try {
            NumberUtils.createBigDecimal("  ");
            fail("expected NumberFormatException for blank string");
        } catch (NumberFormatException expected) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // min/max over arrays
    //-----------------------------------------------------------------------

    public void testMinMaxLongArray() {
        long[] array = { 3L, -5L, 10L, 0L };
        assertEquals(-5L, NumberUtils.min(array));
        assertEquals(10L, NumberUtils.max(array));
        try {
            NumberUtils.min((long[]) null);
            fail("expected IllegalArgumentException for null array");
        } catch (IllegalArgumentException expected) {
            // expected
        }
        try {
            NumberUtils.min(new long[0]);
            fail("expected IllegalArgumentException for empty array");
        } catch (IllegalArgumentException expected) {
            // expected
        }
        try {
            NumberUtils.max((long[]) null);
            fail("expected IllegalArgumentException for null array");
        } catch (IllegalArgumentException expected) {
            // expected
        }
        try {
            NumberUtils.max(new long[0]);
            fail("expected IllegalArgumentException for empty array");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    public void testMinMaxIntArray() {
        int[] array = { 3, -5, 10, 0 };
        assertEquals(-5, NumberUtils.min(array));
        assertEquals(10, NumberUtils.max(array));
        try {
            NumberUtils.min((int[]) null);
            fail("expected IllegalArgumentException for null array");
        } catch (IllegalArgumentException expected) {
            // expected
        }
        try {
            NumberUtils.max(new int[0]);
            fail("expected IllegalArgumentException for empty array");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    public void testMinMaxShortArray() {
        short[] array = { (short) 3, (short) -5, (short) 10 };
        assertEquals((short) -5, NumberUtils.min(array));
        assertEquals((short) 10, NumberUtils.max(array));
        try {
            NumberUtils.min((short[]) null);
            fail("expected IllegalArgumentException for null array");
        } catch (IllegalArgumentException expected) {
            // expected
        }
        try {
            NumberUtils.max(new short[0]);
            fail("expected IllegalArgumentException for empty array");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    public void testMinMaxByteArray() {
        byte[] array = { (byte) 3, (byte) -5, (byte) 10 };
        assertEquals((byte) -5, NumberUtils.min(array));
        assertEquals((byte) 10, NumberUtils.max(array));
        try {
            NumberUtils.min((byte[]) null);
            fail("expected IllegalArgumentException for null array");
        } catch (IllegalArgumentException expected) {
            // expected
        }
        try {
            NumberUtils.max(new byte[0]);
            fail("expected IllegalArgumentException for empty array");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    public void testMinMaxDoubleArray() {
        double[] array = { 3.2d, -5.1d, 10.7d };
        assertEquals(-5.1d, NumberUtils.min(array), 0.0001d);
        assertEquals(10.7d, NumberUtils.max(array), 0.0001d);

        double[] withNaN = { 1.0d, Double.NaN, 2.0d };
        assertTrue(Double.isNaN(NumberUtils.min(withNaN)));
        assertTrue(Double.isNaN(NumberUtils.max(withNaN)));

        try {
            NumberUtils.min((double[]) null);
            fail("expected IllegalArgumentException for null array");
        } catch (IllegalArgumentException expected) {
            // expected
        }
        try {
            NumberUtils.max(new double[0]);
            fail("expected IllegalArgumentException for empty array");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    public void testMinMaxFloatArray() {
        float[] array = { 3.2f, -5.1f, 10.7f };
        assertEquals(-5.1f, NumberUtils.min(array), 0.0001f);
        assertEquals(10.7f, NumberUtils.max(array), 0.0001f);

        float[] withNaN = { 1.0f, Float.NaN, 2.0f };
        assertTrue(Float.isNaN(NumberUtils.min(withNaN)));
        assertTrue(Float.isNaN(NumberUtils.max(withNaN)));

        try {
            NumberUtils.min((float[]) null);
            fail("expected IllegalArgumentException for null array");
        } catch (IllegalArgumentException expected) {
            // expected
        }
        try {
            NumberUtils.max(new float[0]);
            fail("expected IllegalArgumentException for empty array");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // min/max of three values
    //-----------------------------------------------------------------------

    public void testMinMaxThreeLongs() {
        assertEquals(1L, NumberUtils.min(1L, 2L, 3L));
        assertEquals(1L, NumberUtils.min(3L, 2L, 1L));
        assertEquals(1L, NumberUtils.min(2L, 1L, 3L));
        assertEquals(3L, NumberUtils.max(1L, 2L, 3L));
        assertEquals(3L, NumberUtils.max(3L, 2L, 1L));
        assertEquals(3L, NumberUtils.max(2L, 1L, 3L));
    }

    public void testMinMaxThreeInts() {
        assertEquals(1, NumberUtils.min(1, 2, 3));
        assertEquals(1, NumberUtils.min(3, 2, 1));
        assertEquals(1, NumberUtils.min(2, 1, 3));
        assertEquals(3, NumberUtils.max(1, 2, 3));
        assertEquals(3, NumberUtils.max(3, 2, 1));
        assertEquals(3, NumberUtils.max(2, 1, 3));
    }

    public void testMinMaxThreeShorts() {
        assertEquals((short) 1, NumberUtils.min((short) 1, (short) 2, (short) 3));
        assertEquals((short) 3, NumberUtils.max((short) 1, (short) 2, (short) 3));
    }

    public void testMinMaxThreeBytes() {
        assertEquals((byte) 1, NumberUtils.min((byte) 1, (byte) 2, (byte) 3));
        assertEquals((byte) 3, NumberUtils.max((byte) 1, (byte) 2, (byte) 3));
    }

    public void testMinMaxThreeDoubles() {
        assertEquals(1.0d, NumberUtils.min(1.0d, 2.0d, 3.0d), 0.0001d);
        assertEquals(3.0d, NumberUtils.max(1.0d, 2.0d, 3.0d), 0.0001d);
        assertTrue(Double.isNaN(NumberUtils.min(1.0d, Double.NaN, 3.0d)));
        assertTrue(Double.isNaN(NumberUtils.max(1.0d, Double.NaN, 3.0d)));
    }

    public void testMinMaxThreeFloats() {
        assertEquals(1.0f, NumberUtils.min(1.0f, 2.0f, 3.0f), 0.0001f);
        assertEquals(3.0f, NumberUtils.max(1.0f, 2.0f, 3.0f), 0.0001f);
        assertTrue(Float.isNaN(NumberUtils.min(1.0f, Float.NaN, 3.0f)));
        assertTrue(Float.isNaN(NumberUtils.max(1.0f, Float.NaN, 3.0f)));
    }

    //-----------------------------------------------------------------------
    // isDigits
    //-----------------------------------------------------------------------

    public void testIsDigits() {
        assertFalse(NumberUtils.isDigits(null));
        assertFalse(NumberUtils.isDigits(""));
        assertTrue(NumberUtils.isDigits("12345"));
        assertFalse(NumberUtils.isDigits("12.345"));
        assertFalse(NumberUtils.isDigits("-12345"));
        assertFalse(NumberUtils.isDigits("abc"));
        assertFalse(NumberUtils.isDigits("12 34"));
    }

    //-----------------------------------------------------------------------
    // isNumber
    //-----------------------------------------------------------------------

    public void testIsNumber() {
        assertFalse(NumberUtils.isNumber(null));
        assertFalse(NumberUtils.isNumber(""));
        assertTrue(NumberUtils.isNumber("12345"));
        assertTrue(NumberUtils.isNumber("-12345"));
        assertTrue(NumberUtils.isNumber("12.345"));
        assertTrue(NumberUtils.isNumber("1.2345E10"));
        assertTrue(NumberUtils.isNumber("1.2345e10"));
        assertTrue(NumberUtils.isNumber("0xFF"));
        assertTrue(NumberUtils.isNumber("123L"));
        assertTrue(NumberUtils.isNumber("123.3F"));
        assertFalse(NumberUtils.isNumber("0x"));
        assertFalse(NumberUtils.isNumber("abc"));
        assertFalse(NumberUtils.isNumber("1.2.3"));
        assertFalse(NumberUtils.isNumber("--1"));
        assertFalse(NumberUtils.isNumber("1E"));
        assertFalse(NumberUtils.isNumber("E1"));
    }

    /**
     * BUG: isNumber claims "1.1L" is a valid number (returns true), but a
     * decimal value with an 'L' (long) suffix is not actually parseable as
     * a number: NumberUtils.createNumber("1.1L") throws
     * NumberFormatException (see testCreateNumberDecimalWithLongSuffixThrows
     * above), and no Java numeric type accepts "1.1L" either. isNumber's
     * contract ("checks whether the String is a correctly formatted
     * number") is violated here.
     */
    public void testIsNumberDecimalWithLongSuffixIsNotActuallyANumber() {
        assertFalse("1.1L is not parseable as any number but isNumber reports it valid",
                NumberUtils.isNumber("1.1L"));
    }

}
