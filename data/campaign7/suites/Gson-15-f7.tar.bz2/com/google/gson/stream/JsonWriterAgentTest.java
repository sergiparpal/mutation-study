/*
 * Copyright (C) 2010 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.gson.stream;

import java.io.IOException;
import java.io.StringWriter;
import junit.framework.TestCase;

public final class JsonWriterAgentTest extends TestCase {

  public void testWriteTopLevelArray() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.value(true);
    writer.value(false);
    writer.value(1L);
    writer.value(1.5d);
    writer.value("a");
    writer.nullValue();
    writer.endArray();
    assertEquals("[true,false,1,1.5,\"a\",null]", stringWriter.toString());
  }

  public void testWriteTopLevelObject() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginObject();
    writer.name("a").value(1L);
    writer.name("b").value(2L);
    writer.endObject();
    assertEquals("{\"a\":1,\"b\":2}", stringWriter.toString());
  }

  public void testSingleTopLevelScalarSucceedsWithoutLenient() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.value("a");
    writer.close();
    assertEquals("\"a\"", stringWriter.toString());
  }

  public void testLenientTopLevelValueSucceeds() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setLenient(true);
    assertTrue(writer.isLenient());
    writer.value("a");
    writer.close();
    assertEquals("\"a\"", stringWriter.toString());
  }

  public void testTwoTopLevelValuesStrictFails() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.value(1L);
    try {
      writer.value(2L);
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testConstructorNullWriterFails() {
    try {
      new JsonWriter(null);
      fail();
    } catch (NullPointerException expected) {
    }
  }

  public void testNameNullFails() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginObject();
    try {
      writer.name(null);
      fail();
    } catch (NullPointerException expected) {
    }
  }

  public void testNameWithoutValueFails() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginObject();
    writer.name("a");
    try {
      writer.name("b");
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testNameOutsideObjectFails() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.name("a");
    try {
      writer.value(1L);
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testEndArrayMismatchWithObjectFails() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginObject();
    try {
      writer.endArray();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testEndObjectMismatchWithArrayFails() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginArray();
    try {
      writer.endObject();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testEndObjectWithDanglingNameFails() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginObject();
    writer.name("a");
    try {
      writer.endObject();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testNullValueFromName() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginObject();
    writer.name("a").value((String) null);
    writer.endObject();
    assertEquals("{\"a\":null}", stringWriter.toString());
  }

  public void testSuppressedNullsOmitMember() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setSerializeNulls(false);
    assertFalse(writer.getSerializeNulls());
    writer.beginObject();
    writer.name("a").nullValue();
    writer.name("b").value(1L);
    writer.endObject();
    assertEquals("{\"b\":1}", stringWriter.toString());
  }

  public void testDefaultSerializeNullsIsTrue() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    assertTrue(writer.getSerializeNulls());
  }

  public void testNonFiniteDoublesFailStrict() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginArray();
    try {
      writer.value(Double.NaN);
      fail();
    } catch (IllegalArgumentException expected) {
    }
    try {
      writer.value(Double.POSITIVE_INFINITY);
      fail();
    } catch (IllegalArgumentException expected) {
    }
    try {
      writer.value(Double.NEGATIVE_INFINITY);
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  public void testNonFiniteDoublesSucceedWhenLenient() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setLenient(true);
    writer.beginArray();
    writer.value(Double.NaN);
    writer.value(Double.POSITIVE_INFINITY);
    writer.value(Double.NEGATIVE_INFINITY);
    writer.endArray();
    assertEquals("[NaN,Infinity,-Infinity]", stringWriter.toString());
  }

  public void testNonFiniteNumbersFailStrict() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginArray();
    try {
      writer.value(Double.valueOf(Double.NaN));
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  public void testNullNumberValueWritesNull() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.value((Number) null);
    writer.endArray();
    assertEquals("[null]", stringWriter.toString());
  }

  public void testNullBooleanValueWritesNull() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.value((Boolean) null);
    writer.endArray();
    assertEquals("[null]", stringWriter.toString());
  }

  public void testStringEscaping() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.value("a\"b\\c\td\be\nf\rg\fh\u0001i");
    writer.endArray();
    assertEquals("[\"a\\\"b\\\\c\\td\\be\\nf\\rg\\fh\\u0001i\"]", stringWriter.toString());
  }

  public void testHtmlSafeDefaultFalse() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    assertFalse(writer.isHtmlSafe());
  }

  public void testHtmlSafeEscaping() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setHtmlSafe(true);
    assertTrue(writer.isHtmlSafe());
    writer.beginArray();
    writer.value("<foo>&bar=baz'qux'");
    writer.endArray();
    assertEquals("[\"\\u003cfoo\\u003e\\u0026bar\\u003dbaz\\u0027qux\\u0027\"]",
        stringWriter.toString());
  }

  public void testJsonValueWritesRawLiteral() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.jsonValue("{\"raw\":true}");
    writer.endArray();
    assertEquals("[{\"raw\":true}]", stringWriter.toString());
  }

  public void testJsonValueNullWritesNullLiteral() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.jsonValue(null);
    writer.endArray();
    assertEquals("[null]", stringWriter.toString());
  }

  public void testIndentPrettyPrints() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setIndent("   ");
    writer.beginObject();
    writer.name("a");
    writer.beginArray();
    writer.value(1L);
    writer.value(2L);
    writer.endArray();
    writer.endObject();
    String expected = "{\n   \"a\": [\n      1,\n      2\n   ]\n}";
    assertEquals(expected, stringWriter.toString());
  }

  public void testEmptyIndentMeansCompact() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setIndent("  ");
    writer.setIndent("");
    writer.beginObject();
    writer.name("a").value(1L);
    writer.endObject();
    assertEquals("{\"a\":1}", stringWriter.toString());
  }

  public void testEmptyArrayAndObjectNoNewlineInside() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setIndent("  ");
    writer.beginArray();
    writer.endArray();
    assertEquals("[]", stringWriter.toString());
  }

  public void testCloseIncompleteDocumentThrows() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginObject();
    writer.name("a");
    try {
      writer.close();
      fail();
    } catch (IOException expected) {
    }
  }

  public void testCloseEmptyWriterThrows() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    try {
      writer.close();
      fail();
    } catch (IOException expected) {
    }
  }

  public void testFlushAfterCloseFails() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.endArray();
    writer.close();
    try {
      writer.flush();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testOperationAfterCloseFails() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.endArray();
    writer.close();
    try {
      writer.beginArray();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testCloseSucceedsOnCompleteDocument() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.endArray();
    writer.close();
    assertEquals("[]", stringWriter.toString());
  }

  public void testNestedArraysAndObjects() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginObject();
    writer.name("array");
    writer.beginArray();
    writer.beginObject();
    writer.name("x").value(1L);
    writer.endObject();
    writer.endArray();
    writer.endObject();
    assertEquals("{\"array\":[{\"x\":1}]}", stringWriter.toString());
  }

  public void testMultipleNamesForSameValueFails() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginObject();
    writer.name("a");
    try {
      writer.name("a");
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testSetIndentNullFails() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    try {
      writer.setIndent(null);
      fail();
    } catch (NullPointerException expected) {
    }
  }

  public void testBeginArrayReturnsThis() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    assertSame(writer, writer.beginArray());
  }

  public void testValueReturnsThis() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    writer.beginArray();
    assertSame(writer, writer.value(1L));
  }
}
