/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.csv;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.StringWriter;

import org.junit.Test;

/**
 * Self-contained tests for {@link CSVFormat}.
 */
public class CSVFormatAgentTest {

    private enum HeaderEnum {
        NAME, EMAIL, PHONE
    }

    // ---- newFormat ----

    @Test
    public void testNewFormatDefaults() {
        final CSVFormat format = CSVFormat.newFormat(';');
        assertEquals(';', format.getDelimiter());
        assertNull(format.getQuoteCharacter());
        assertNull(format.getQuoteMode());
        assertNull(format.getCommentMarker());
        assertNull(format.getEscapeCharacter());
        assertFalse(format.getIgnoreSurroundingSpaces());
        assertFalse(format.getIgnoreEmptyLines());
        assertNull(format.getRecordSeparator());
        assertNull(format.getNullString());
        assertNull(format.getHeaderComments());
        assertNull(format.getHeader());
        assertFalse(format.getSkipHeaderRecord());
        assertFalse(format.getAllowMissingColumnNames());
        assertFalse(format.getIgnoreHeaderCase());
        assertFalse(format.getTrim());
        assertFalse(format.getTrailingDelimiter());
        assertFalse(format.getAutoFlush());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testNewFormatDelimiterIsLf() {
        CSVFormat.newFormat('\n');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testNewFormatDelimiterIsCr() {
        CSVFormat.newFormat('\r');
    }

    // ---- predefined formats ----

    @Test
    public void testDefaultFormatSettings() {
        assertEquals(',', CSVFormat.DEFAULT.getDelimiter());
        assertEquals(Character.valueOf('"'), CSVFormat.DEFAULT.getQuoteCharacter());
        assertEquals("\r\n", CSVFormat.DEFAULT.getRecordSeparator());
        assertTrue(CSVFormat.DEFAULT.getIgnoreEmptyLines());
    }

    @Test
    public void testRfc4180DiffersFromDefaultOnIgnoreEmptyLines() {
        assertFalse(CSVFormat.RFC4180.getIgnoreEmptyLines());
        assertTrue(CSVFormat.DEFAULT.getIgnoreEmptyLines());
    }

    @Test
    public void testExcelFormat() {
        assertFalse(CSVFormat.EXCEL.getIgnoreEmptyLines());
        assertTrue(CSVFormat.EXCEL.getAllowMissingColumnNames());
    }

    @Test
    public void testMySqlFormat() {
        assertEquals('\t', CSVFormat.MYSQL.getDelimiter());
        assertNull(CSVFormat.MYSQL.getQuoteCharacter());
        assertEquals(Character.valueOf('\\'), CSVFormat.MYSQL.getEscapeCharacter());
        assertEquals("\n", CSVFormat.MYSQL.getRecordSeparator());
        assertEquals("\\N", CSVFormat.MYSQL.getNullString());
        assertEquals(QuoteMode.ALL_NON_NULL, CSVFormat.MYSQL.getQuoteMode());
    }

    @Test
    public void testTdfFormat() {
        assertEquals('\t', CSVFormat.TDF.getDelimiter());
        assertTrue(CSVFormat.TDF.getIgnoreSurroundingSpaces());
    }

    @Test
    public void testValueOfLooksUpPredefinedFormat() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.valueOf("Default"));
        assertEquals(CSVFormat.EXCEL, CSVFormat.valueOf("Excel"));
        assertEquals(CSVFormat.MYSQL, CSVFormat.valueOf("MySQL"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testValueOfUnknownNameThrows() {
        CSVFormat.valueOf("NotARealPredefinedFormat");
    }

    // ---- validation in constructor / with* methods ----

    @Test(expected = IllegalArgumentException.class)
    public void testWithDelimiterLineBreakThrows() {
        CSVFormat.DEFAULT.withDelimiter('\n');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithQuoteSameAsDelimiterThrows() {
        CSVFormat.newFormat(',').withQuote(',');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithEscapeSameAsDelimiterThrows() {
        CSVFormat.newFormat(',').withEscape(',');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithCommentMarkerSameAsDelimiterThrows() {
        CSVFormat.newFormat(',').withCommentMarker(',');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCommentMarkerSameAsQuoteThrows() {
        CSVFormat.newFormat(',').withQuote('#').withCommentMarker('#');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCommentMarkerSameAsEscapeThrows() {
        CSVFormat.newFormat(',').withEscape('#').withCommentMarker('#');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testQuoteModeNoneWithoutEscapeThrows() {
        CSVFormat.newFormat(',').withQuoteMode(QuoteMode.NONE);
    }

    @Test
    public void testQuoteModeNoneWithEscapeIsAllowed() {
        final CSVFormat format = CSVFormat.newFormat(',').withEscape('\\').withQuoteMode(QuoteMode.NONE);
        assertEquals(QuoteMode.NONE, format.getQuoteMode());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithCommentMarkerLineBreakThrows() {
        CSVFormat.DEFAULT.withCommentMarker('\r');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithEscapeLineBreakThrows() {
        CSVFormat.DEFAULT.withEscape('\n');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithQuoteLineBreakThrows() {
        CSVFormat.DEFAULT.withQuote('\r');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testDuplicateHeaderNameThrows() {
        CSVFormat.DEFAULT.withHeader("A", "B", "A");
    }

    @Test
    public void testHeaderWithoutDuplicatesIsAllowed() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("A", "B", "C");
        assertArrayEquals(new String[] { "A", "B", "C" }, format.getHeader());
    }

    // ---- getters round-trip, independence of returned arrays ----

    @Test
    public void testGetHeaderReturnsDefensiveCopy() {
        final String[] original = { "A", "B" };
        final CSVFormat format = CSVFormat.DEFAULT.withHeader(original);
        original[0] = "Z";
        assertArrayEquals(new String[] { "A", "B" }, format.getHeader());

        final String[] returned = format.getHeader();
        returned[0] = "mutated";
        assertArrayEquals(new String[] { "A", "B" }, format.getHeader());
    }

    @Test
    public void testGetHeaderNullWhenDisabled() {
        assertNull(CSVFormat.DEFAULT.getHeader());
    }

    @Test
    public void testGetHeaderEmptyWhenAutoDetected() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader();
        assertNotNull(format.getHeader());
        assertEquals(0, format.getHeader().length);
    }

    @Test
    public void testGetHeaderCommentsReturnsDefensiveCopyAndStringifies() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeaderComments("a", Integer.valueOf(1), null);
        final String[] comments = format.getHeaderComments();
        assertArrayEquals(new String[] { "a", "1", null }, comments);
        comments[0] = "mutated";
        assertArrayEquals(new String[] { "a", "1", null }, format.getHeaderComments());
    }

    @Test
    public void testHeaderCommentsNullWhenNotSet() {
        assertNull(CSVFormat.DEFAULT.getHeaderComments());
    }

    // ---- withHeader(Class<Enum>) ----

    @Test
    public void testWithHeaderEnum() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader(HeaderEnum.class);
        assertArrayEquals(new String[] { "NAME", "EMAIL", "PHONE" }, format.getHeader());
    }

    @Test
    public void testWithHeaderEnumNullDisablesHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader((Class<? extends Enum<?>>) null);
        assertNull(format.getHeader());
    }

    // ---- withFirstRecordAsHeader ----

    @Test
    public void testWithFirstRecordAsHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.withFirstRecordAsHeader();
        assertNotNull(format.getHeader());
        assertEquals(0, format.getHeader().length);
        assertTrue(format.getSkipHeaderRecord());
    }

    // ---- isXxxSet helpers ----

    @Test
    public void testIsSetHelpers() {
        assertFalse(CSVFormat.newFormat(',').isQuoteCharacterSet());
        assertTrue(CSVFormat.newFormat(',').withQuote('"').isQuoteCharacterSet());

        assertFalse(CSVFormat.newFormat(',').isEscapeCharacterSet());
        assertTrue(CSVFormat.newFormat(',').withEscape('\\').isEscapeCharacterSet());

        assertFalse(CSVFormat.newFormat(',').isCommentMarkerSet());
        assertTrue(CSVFormat.newFormat(',').withCommentMarker('#').isCommentMarkerSet());

        assertFalse(CSVFormat.newFormat(',').isNullStringSet());
        assertTrue(CSVFormat.newFormat(',').withNullString("NULL").isNullStringSet());
    }

    // ---- equals / hashCode ----

    @Test
    public void testEqualsSameInstance() {
        assertTrue(CSVFormat.DEFAULT.equals(CSVFormat.DEFAULT));
    }

    @Test
    public void testEqualsNullAndDifferentType() {
        assertFalse(CSVFormat.DEFAULT.equals(null));
        assertFalse(CSVFormat.DEFAULT.equals("not a format"));
    }

    @Test
    public void testEqualsAndHashCodeForEquivalentFormats() {
        final CSVFormat a = CSVFormat.newFormat(',').withQuote('"');
        final CSVFormat b = CSVFormat.newFormat(',').withQuote('"');
        assertTrue(a.equals(b));
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    public void testNotEqualsForDifferentDelimiter() {
        final CSVFormat a = CSVFormat.newFormat(',');
        final CSVFormat b = CSVFormat.newFormat(';');
        assertFalse(a.equals(b));
        assertFalse(b.equals(a));
    }

    @Test
    public void testNotEqualsForDifferentHeader() {
        final CSVFormat a = CSVFormat.DEFAULT.withHeader("A");
        final CSVFormat b = CSVFormat.DEFAULT.withHeader("B");
        assertFalse(a.equals(b));
    }

    /**
     * CSVFormat#equals ignores the trim flag entirely, so two formats that differ only in
     * their trim setting (and thus behave differently when formatting/parsing) compare equal.
     * This contradicts the general equals() contract for an otherwise fully value-based class:
     * distinct observable configurations should not be reported as equal.
     */
    @Test
    public void testEqualsShouldDistinguishTrimSetting() {
        final CSVFormat untrimmed = CSVFormat.DEFAULT;
        final CSVFormat trimmed = CSVFormat.DEFAULT.withTrim(true);
        assertFalse("CSVFormat.equals() must not ignore the trim setting", untrimmed.equals(trimmed));
    }

    /**
     * Likewise, equals() ignores allowMissingColumnNames, so EXCEL-like and DEFAULT-like formats
     * that only differ by that flag are reported equal.
     */
    @Test
    public void testEqualsShouldDistinguishAllowMissingColumnNames() {
        final CSVFormat a = CSVFormat.DEFAULT.withIgnoreEmptyLines(false);
        final CSVFormat b = CSVFormat.DEFAULT.withIgnoreEmptyLines(false).withAllowMissingColumnNames(true);
        assertFalse("CSVFormat.equals() must not ignore allowMissingColumnNames", a.equals(b));
    }

    // ---- record separator: documented to reject anything other than CR, LF, CRLF ----

    /**
     * The javadoc for {@link CSVFormat#withRecordSeparator(String)} states it throws
     * IllegalArgumentException "if recordSeparator is none of CR, LF or CRLF", but the
     * implementation performs no such validation.
     */
    @Test(expected = IllegalArgumentException.class)
    public void testWithRecordSeparatorRejectsInvalidValue() {
        CSVFormat.DEFAULT.withRecordSeparator("not-a-valid-separator");
    }

    @Test
    public void testWithRecordSeparatorAcceptsStandardValues() {
        assertEquals("\n", CSVFormat.DEFAULT.withRecordSeparator('\n').getRecordSeparator());
        assertEquals("\r", CSVFormat.DEFAULT.withRecordSeparator('\r').getRecordSeparator());
        assertEquals("\r\n", CSVFormat.DEFAULT.withRecordSeparator("\r\n").getRecordSeparator());
    }

    // ---- withAutoFlush / withTrailingDelimiter / withIgnoreHeaderCase ----

    @Test
    public void testWithAutoFlush() {
        assertFalse(CSVFormat.DEFAULT.getAutoFlush());
        assertTrue(CSVFormat.DEFAULT.withAutoFlush(true).getAutoFlush());
    }

    @Test
    public void testWithTrailingDelimiter() {
        assertFalse(CSVFormat.DEFAULT.getTrailingDelimiter());
        assertTrue(CSVFormat.DEFAULT.withTrailingDelimiter().getTrailingDelimiter());
        assertTrue(CSVFormat.DEFAULT.withTrailingDelimiter(true).getTrailingDelimiter());
        assertFalse(CSVFormat.DEFAULT.withTrailingDelimiter(true).withTrailingDelimiter(false).getTrailingDelimiter());
    }

    @Test
    public void testWithIgnoreHeaderCase() {
        assertFalse(CSVFormat.DEFAULT.getIgnoreHeaderCase());
        assertTrue(CSVFormat.DEFAULT.withIgnoreHeaderCase().getIgnoreHeaderCase());
    }

    @Test
    public void testWithTrim() {
        assertFalse(CSVFormat.DEFAULT.getTrim());
        assertTrue(CSVFormat.DEFAULT.withTrim().getTrim());
        assertTrue(CSVFormat.DEFAULT.withTrim(true).getTrim());
    }

    // ---- format(Object...) ----

    @Test
    public void testFormatSimpleValues() {
        assertEquals("a,b,c", CSVFormat.DEFAULT.format(new Object[] { "a", "b", "c" }));
    }

    @Test
    public void testFormatQuotesValueContainingDelimiter() {
        assertEquals("a,\"b,c\",d", CSVFormat.DEFAULT.format(new Object[] { "a", "b,c", "d" }));
    }

    @Test
    public void testFormatNullValueUsesNullString() {
        final CSVFormat format = CSVFormat.DEFAULT.withNullString("NULL");
        assertEquals("a,NULL,c", format.format(new Object[] { "a", null, "c" }));
    }

    // ---- print(Object, Appendable, boolean) ----

    @Test
    public void testPrintSingleValueNewRecordNoDelimiterPrefix() throws IOException {
        final StringWriter sw = new StringWriter();
        CSVFormat.DEFAULT.print("value", sw, true);
        assertEquals("value", sw.toString());
    }

    @Test
    public void testPrintSingleValueNotNewRecordPrependsDelimiter() throws IOException {
        final StringWriter sw = new StringWriter();
        CSVFormat.DEFAULT.print("value", sw, false);
        assertEquals(",value", sw.toString());
    }

    @Test
    public void testPrintEscapesSpecialCharactersWhenNoQuote() throws IOException {
        final CSVFormat format = CSVFormat.newFormat(',').withEscape('\\');
        final StringWriter sw = new StringWriter();
        format.print("a,b", sw, true);
        assertEquals("a\\,b", sw.toString());
    }

    // ---- println(Appendable) ----

    @Test
    public void testPrintlnWritesRecordSeparator() throws IOException {
        final StringWriter sw = new StringWriter();
        CSVFormat.DEFAULT.println(sw);
        assertEquals("\r\n", sw.toString());
    }

    @Test
    public void testPrintlnWithTrailingDelimiter() throws IOException {
        final CSVFormat format = CSVFormat.DEFAULT.withTrailingDelimiter();
        final StringWriter sw = new StringWriter();
        format.println(sw);
        assertEquals(",\r\n", sw.toString());
    }

    @Test
    public void testPrintlnWithNoRecordSeparatorWritesNothing() throws IOException {
        final CSVFormat format = CSVFormat.newFormat(',');
        final StringWriter sw = new StringWriter();
        format.println(sw);
        assertEquals("", sw.toString());
    }

    // ---- printRecord(Appendable, Object...) ----

    @Test
    public void testPrintRecord() throws IOException {
        final StringWriter sw = new StringWriter();
        CSVFormat.DEFAULT.printRecord(sw, new Object[] { "a", "b", "c" });
        assertEquals("a,b,c\r\n", sw.toString());
    }

    @Test
    public void testPrintRecordEmptyValuesStillWritesSeparator() throws IOException {
        final StringWriter sw = new StringWriter();
        CSVFormat.DEFAULT.printRecord(sw, new Object[0]);
        assertEquals("\r\n", sw.toString());
    }

    // ---- toString() ----

    @Test
    public void testToStringContainsDelimiter() {
        final String s = CSVFormat.DEFAULT.toString();
        assertTrue(s.contains("Delimiter=<,>"));
    }

    @Test
    public void testToStringContainsQuoteCharWhenSet() {
        final String s = CSVFormat.DEFAULT.toString();
        assertTrue(s.contains("QuoteChar=<\">"));
    }

    @Test
    public void testToStringOmitsQuoteCharWhenNotSet() {
        final String s = CSVFormat.newFormat(',').toString();
        assertFalse(s.contains("QuoteChar="));
    }

    // ---- withHeader(String...) and withSkipHeaderRecord ----

    @Test
    public void testWithSkipHeaderRecord() {
        assertFalse(CSVFormat.DEFAULT.getSkipHeaderRecord());
        assertTrue(CSVFormat.DEFAULT.withSkipHeaderRecord().getSkipHeaderRecord());
        assertTrue(CSVFormat.DEFAULT.withSkipHeaderRecord(true).getSkipHeaderRecord());
    }

    // ---- withAllowMissingColumnNames ----

    @Test
    public void testWithAllowMissingColumnNames() {
        assertFalse(CSVFormat.DEFAULT.getAllowMissingColumnNames());
        assertTrue(CSVFormat.DEFAULT.withAllowMissingColumnNames().getAllowMissingColumnNames());
    }

    // ---- withIgnoreEmptyLines / withIgnoreSurroundingSpaces ----

    @Test
    public void testWithIgnoreEmptyLines() {
        assertTrue(CSVFormat.DEFAULT.withIgnoreEmptyLines().getIgnoreEmptyLines());
        assertFalse(CSVFormat.DEFAULT.withIgnoreEmptyLines(false).getIgnoreEmptyLines());
    }

    @Test
    public void testWithIgnoreSurroundingSpaces() {
        assertTrue(CSVFormat.DEFAULT.withIgnoreSurroundingSpaces().getIgnoreSurroundingSpaces());
        assertFalse(CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(false).getIgnoreSurroundingSpaces());
    }

    // ---- withNullString ----

    @Test
    public void testWithNullString() {
        assertNull(CSVFormat.DEFAULT.getNullString());
        assertEquals("N/A", CSVFormat.DEFAULT.withNullString("N/A").getNullString());
    }

    // ---- withQuoteMode ----

    @Test
    public void testWithQuoteMode() {
        assertNull(CSVFormat.DEFAULT.getQuoteMode());
        assertEquals(QuoteMode.ALL, CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL).getQuoteMode());
    }

    // ---- Serialization round trip ----

    @Test
    public void testSerialization() throws IOException, ClassNotFoundException {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("A", "B").withQuote('\'').withNullString("NULL");

        final ByteArrayOutputStream bos = new ByteArrayOutputStream();
        final ObjectOutputStream oos = new ObjectOutputStream(bos);
        oos.writeObject(format);
        oos.flush();
        oos.close();

        final ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(bos.toByteArray()));
        final CSVFormat deserialized = (CSVFormat) ois.readObject();
        ois.close();

        assertEquals(format.getDelimiter(), deserialized.getDelimiter());
        assertEquals(format.getQuoteCharacter(), deserialized.getQuoteCharacter());
        assertEquals(format.getNullString(), deserialized.getNullString());
        assertArrayEquals(format.getHeader(), deserialized.getHeader());
    }

    // ---- withHeader(ResultSetMetaData) / withHeader(ResultSet) with null arguments ----

    @Test
    public void testWithHeaderNullResultSetMetaDataDisablesHeader() throws java.sql.SQLException {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader((java.sql.ResultSetMetaData) null);
        assertNull(format.getHeader());
    }

    @Test
    public void testWithHeaderNullResultSetDisablesHeader() throws java.sql.SQLException {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader((java.sql.ResultSet) null);
        assertNull(format.getHeader());
    }
}
