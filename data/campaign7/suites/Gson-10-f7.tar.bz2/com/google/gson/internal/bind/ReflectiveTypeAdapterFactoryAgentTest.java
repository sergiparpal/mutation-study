/*
 * Copyright (C) 2024 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.gson.internal.bind;

import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.InstanceCreator;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.internal.ConstructorConstructor;
import com.google.gson.internal.Excluder;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

import junit.framework.TestCase;

import java.io.StringReader;
import java.io.StringWriter;
import java.lang.reflect.Field;
import java.lang.reflect.Type;
import java.util.Collections;
import java.util.Map;

public final class ReflectiveTypeAdapterFactoryAgentTest extends TestCase {

  private final Gson gson = new Gson();
  private final ReflectiveTypeAdapterFactory factory = newFactory();

  private static ReflectiveTypeAdapterFactory newFactory() {
    Map<Type, InstanceCreator<?>> emptyCreators = Collections.emptyMap();
    return new ReflectiveTypeAdapterFactory(
        new ConstructorConstructor(emptyCreators), FieldNamingPolicy.IDENTITY, Excluder.DEFAULT);
  }

  private <T> TypeAdapter<T> adapterFor(Class<T> clazz) {
    return factory.create(gson, TypeToken.get(clazz));
  }

  private static String write(TypeAdapter<Object> adapter, Object value) throws Exception {
    StringWriter stringWriter = new StringWriter();
    JsonWriter jsonWriter = new JsonWriter(stringWriter);
    adapter.write(jsonWriter, value);
    jsonWriter.close();
    return stringWriter.toString();
  }

  private static <T> T read(TypeAdapter<T> adapter, String json) throws Exception {
    JsonReader jsonReader = new JsonReader(new StringReader(json));
    T result = adapter.read(jsonReader);
    jsonReader.close();
    return result;
  }

  // --- Fixtures -------------------------------------------------------

  static class Simple {
    int a;
    String b;
  }

  static class WithTransientAndStatic {
    transient int skippedTransient = 5;
    static int skippedStatic = 6;
    int kept = 7;
  }

  static class WithAlternates {
    @SerializedName(value = "real", alternate = {"alt1", "alt2"})
    String name;
  }

  static class DuplicateName {
    @SerializedName("same")
    int a;
    @SerializedName("same")
    int b;
  }

  static class Base {
    int value = 1;
  }

  static class Hider extends Base {
    String value = "shadow";
  }

  static class SelfReferencing {
    SelfReferencing cause;
    String message;
  }

  static class WithIntField {
    int number = 42;
  }

  interface Marker {
  }

  static class MarkerImpl implements Marker {
    public int ignoredByInterfaceAdapter = 99;
  }

  // --- Tests ------------------------------------------------------------

  public void testCreateReturnsNullForPrimitiveType() {
    TypeAdapter<Integer> adapter = factory.create(gson, TypeToken.get(int.class));
    assertNull(adapter);
  }

  public void testCreateReturnsNonNullForBoxedPrimitive() {
    TypeAdapter<Integer> adapter = factory.create(gson, TypeToken.get(Integer.class));
    assertNotNull(adapter);
  }

  public void testRoundTripSimpleObject() throws Exception {
    TypeAdapter<Object> adapter = (TypeAdapter<Object>) (TypeAdapter<?>) adapterFor(Simple.class);
    Simple s = new Simple();
    s.a = 10;
    s.b = "hello";
    String json = write(adapter, s);
    assertEquals("{\"a\":10,\"b\":\"hello\"}", json);

    Simple read = (Simple) read(adapter, "{\"a\":99,\"b\":\"world\"}");
    assertEquals(99, read.a);
    assertEquals("world", read.b);
  }

  public void testTransientAndStaticFieldsExcluded() throws Exception {
    TypeAdapter<Object> adapter =
        (TypeAdapter<Object>) (TypeAdapter<?>) adapterFor(WithTransientAndStatic.class);
    WithTransientAndStatic value = new WithTransientAndStatic();
    String json = write(adapter, value);
    assertEquals("{\"kept\":7}", json);
  }

  public void testAlternateNameUsedOnlyForDeserialization() throws Exception {
    TypeAdapter<Object> adapter = (TypeAdapter<Object>) (TypeAdapter<?>) adapterFor(WithAlternates.class);
    WithAlternates value = new WithAlternates();
    value.name = "x";
    String json = write(adapter, value);
    assertEquals("{\"real\":\"x\"}", json);

    WithAlternates viaAlt1 = (WithAlternates) read(adapter, "{\"alt1\":\"y\"}");
    assertEquals("y", viaAlt1.name);

    WithAlternates viaAlt2 = (WithAlternates) read(adapter, "{\"alt2\":\"z\"}");
    assertEquals("z", viaAlt2.name);

    WithAlternates viaReal = (WithAlternates) read(adapter, "{\"real\":\"w\"}");
    assertEquals("w", viaReal.name);
  }

  public void testDuplicateSerializedNameThrowsIllegalArgumentException() {
    try {
      adapterFor(DuplicateName.class);
      fail("Expected IllegalArgumentException for duplicate JSON field name");
    } catch (IllegalArgumentException expected) {
      // expected: two distinct fields explicitly mapped to the same JSON name
    }
  }

  public void testFieldHidingAcrossHierarchyIsSupported() throws Exception {
    // A subclass re-declaring a field with the same name as a superclass field
    // (standard Java field hiding) should not be treated as an ambiguous
    // duplicate: only the subclass's field should be bound.
    TypeAdapter<Object> adapter = (TypeAdapter<Object>) (TypeAdapter<?>) adapterFor(Hider.class);
    Hider value = new Hider();
    value.value = "shadow-value";
    String json = write(adapter, value);
    assertEquals("{\"value\":\"shadow-value\"}", json);
  }

  public void testSelfReferencingFieldSkippedToAvoidRecursion() throws Exception {
    TypeAdapter<Object> adapter = (TypeAdapter<Object>) (TypeAdapter<?>) adapterFor(SelfReferencing.class);
    SelfReferencing value = new SelfReferencing();
    value.cause = value; // self-reference, like Throwable.cause defaults to "this"
    value.message = "boom";
    String json = write(adapter, value);
    assertEquals("{\"message\":\"boom\"}", json);
  }

  public void testNullIntoPrimitiveFieldLeavesExistingValueUntouched() throws Exception {
    // WithIntField.number is initialized to 42 by its field initializer; a JSON
    // null for a primitive field must not overwrite it (int can't hold null).
    TypeAdapter<Object> adapter = (TypeAdapter<Object>) (TypeAdapter<?>) adapterFor(WithIntField.class);
    WithIntField value = (WithIntField) read(adapter, "{\"number\":null}");
    assertEquals(42, value.number);
  }

  public void testUnknownPropertySkippedDuringRead() throws Exception {
    TypeAdapter<Object> adapter = (TypeAdapter<Object>) (TypeAdapter<?>) adapterFor(Simple.class);
    Simple value = (Simple) read(adapter, "{\"unknownField\":{\"nested\":[1,2,3]},\"a\":5,\"b\":\"ok\"}");
    assertEquals(5, value.a);
    assertEquals("ok", value.b);
  }

  public void testReadJsonNullReturnsNullInstance() throws Exception {
    TypeAdapter<Object> adapter = (TypeAdapter<Object>) (TypeAdapter<?>) adapterFor(Simple.class);
    Object value = read(adapter, "null");
    assertNull(value);
  }

  public void testWriteNullValueWritesJsonNull() throws Exception {
    TypeAdapter<Object> adapter = (TypeAdapter<Object>) (TypeAdapter<?>) adapterFor(Simple.class);
    String json = write(adapter, null);
    assertEquals("null", json);
  }

  public void testInterfaceTypeProducesEmptyBoundFieldsAdapter() throws Exception {
    TypeAdapter<Object> adapter = (TypeAdapter<Object>) (TypeAdapter<?>) adapterFor(Marker.class);
    assertNotNull(adapter);
    MarkerImpl impl = new MarkerImpl();
    String json = write(adapter, impl);
    assertEquals("{}", json);
  }

  public void testExcludeFieldStaticHelperIncludesOrdinaryField() throws Exception {
    Field kept = WithTransientAndStatic.class.getDeclaredField("kept");
    assertTrue(ReflectiveTypeAdapterFactory.excludeField(kept, true, Excluder.DEFAULT));
    assertTrue(ReflectiveTypeAdapterFactory.excludeField(kept, false, Excluder.DEFAULT));
  }

  public void testExcludeFieldStaticHelperExcludesTransientField() throws Exception {
    Field skipped = WithTransientAndStatic.class.getDeclaredField("skippedTransient");
    assertFalse(ReflectiveTypeAdapterFactory.excludeField(skipped, true, Excluder.DEFAULT));
    assertFalse(ReflectiveTypeAdapterFactory.excludeField(skipped, false, Excluder.DEFAULT));
  }

  public void testExcludeFieldStaticHelperExcludesStaticField() throws Exception {
    Field skipped = WithTransientAndStatic.class.getDeclaredField("skippedStatic");
    assertFalse(ReflectiveTypeAdapterFactory.excludeField(skipped, true, Excluder.DEFAULT));
  }

  public void testInstanceExcludeFieldMatchesStaticHelper() throws Exception {
    Field kept = WithTransientAndStatic.class.getDeclaredField("kept");
    assertTrue(factory.excludeField(kept, true));
    Field skipped = WithTransientAndStatic.class.getDeclaredField("skippedTransient");
    assertFalse(factory.excludeField(skipped, true));
  }
}
