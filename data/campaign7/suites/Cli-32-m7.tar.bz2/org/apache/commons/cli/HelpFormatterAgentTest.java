/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.cli;

import java.io.ByteArrayOutputStream;
import java.io.PrintWriter;
import java.util.Comparator;

import junit.framework.TestCase;

public class HelpFormatterAgentTest extends TestCase
{
    private static class ReverseComparator implements Comparator
    {
        public int compare(Object o1, Object o2)
        {
            Option opt1 = (Option) o1;
            Option opt2 = (Option) o2;
            return opt2.getKey().compareToIgnoreCase(opt1.getKey());
        }
    }

    public void testDefaults()
    {
        HelpFormatter formatter = new HelpFormatter();

        assertEquals(HelpFormatter.DEFAULT_WIDTH, formatter.getWidth());
        assertEquals(HelpFormatter.DEFAULT_LEFT_PAD, formatter.getLeftPadding());
        assertEquals(HelpFormatter.DEFAULT_DESC_PAD, formatter.getDescPadding());
        assertEquals(HelpFormatter.DEFAULT_SYNTAX_PREFIX, formatter.getSyntaxPrefix());
        assertEquals(HelpFormatter.DEFAULT_OPT_PREFIX, formatter.getOptPrefix());
        assertEquals(HelpFormatter.DEFAULT_LONG_OPT_PREFIX, formatter.getLongOptPrefix());
        assertEquals(HelpFormatter.DEFAULT_LONG_OPT_SEPARATOR, formatter.getLongOptSeparator());
        assertEquals(HelpFormatter.DEFAULT_ARG_NAME, formatter.getArgName());
        assertEquals(System.getProperty("line.separator"), formatter.getNewLine());
        assertNotNull(formatter.getOptionComparator());
    }

    public void testSettersAndGetters()
    {
        HelpFormatter formatter = new HelpFormatter();

        formatter.setWidth(100);
        assertEquals(100, formatter.getWidth());

        formatter.setLeftPadding(5);
        assertEquals(5, formatter.getLeftPadding());

        formatter.setDescPadding(7);
        assertEquals(7, formatter.getDescPadding());

        formatter.setSyntaxPrefix("call: ");
        assertEquals("call: ", formatter.getSyntaxPrefix());

        formatter.setNewLine("\n");
        assertEquals("\n", formatter.getNewLine());

        formatter.setOptPrefix("+");
        assertEquals("+", formatter.getOptPrefix());

        formatter.setLongOptPrefix("++");
        assertEquals("++", formatter.getLongOptPrefix());

        formatter.setLongOptSeparator("=");
        assertEquals("=", formatter.getLongOptSeparator());

        formatter.setArgName("argument");
        assertEquals("argument", formatter.getArgName());
    }

    public void testOptionComparatorNullResetsToDefault()
    {
        HelpFormatter formatter = new HelpFormatter();
        Comparator original = formatter.getOptionComparator();

        formatter.setOptionComparator(new ReverseComparator());
        assertFalse(original == formatter.getOptionComparator());

        formatter.setOptionComparator(null);
        assertNotNull(formatter.getOptionComparator());

        // default comparator sorts ascending alphabetically
        Option a = new Option("a", "aaa", false, "a desc");
        Option b = new Option("b", "bbb", false, "b desc");
        assertTrue(formatter.getOptionComparator().compare(a, b) < 0);
    }

    public void testCreatePadding()
    {
        HelpFormatter formatter = new HelpFormatter();

        assertEquals("     ", formatter.createPadding(5));
        assertEquals("", formatter.createPadding(0));
    }

    public void testRtrim()
    {
        HelpFormatter formatter = new HelpFormatter();

        assertEquals("foo", formatter.rtrim("foo   "));
        assertEquals("foo", formatter.rtrim("foo"));
        assertNull(formatter.rtrim(null));
        assertEquals("", formatter.rtrim(""));
        assertEquals("", formatter.rtrim("   "));
    }

    public void testFindWrapPosNoWrapNeeded()
    {
        HelpFormatter formatter = new HelpFormatter();

        // text shorter than width: no wrap position
        assertEquals(-1, formatter.findWrapPos("short text", 20, 0));
    }

    public void testFindWrapPosAtWhitespace()
    {
        HelpFormatter formatter = new HelpFormatter();

        String text = "This is a long line of text that must wrap";
        int pos = formatter.findWrapPos(text, 10, 0);

        assertTrue(pos > 0);
        assertTrue(pos <= 10);
        assertTrue(Character.isWhitespace(text.charAt(pos)) || pos == 10);
    }

    public void testFindWrapPosNewlineTakesPriority()
    {
        HelpFormatter formatter = new HelpFormatter();

        String text = "abc\ndef";
        // newline at index 3, width large enough that it is found first
        assertEquals(4, formatter.findWrapPos(text, 20, 0));
    }

    public void testFindWrapPosTabTakesPriority()
    {
        HelpFormatter formatter = new HelpFormatter();

        String text = "abc\tdef";
        assertEquals(4, formatter.findWrapPos(text, 20, 0));
    }

    public void testFindWrapPosNoWhitespaceChopsAtWidth()
    {
        HelpFormatter formatter = new HelpFormatter();

        // no whitespace at all, text longer than width: chop exactly at width
        String text = "abcdefghijklmnopqrstuvwxyz";
        int pos = formatter.findWrapPos(text, 5, 0);
        assertEquals(5, pos);
    }

    public void testRenderWrappedTextSimple()
    {
        HelpFormatter formatter = new HelpFormatter();
        formatter.setNewLine("\n");

        StringBuffer sb = new StringBuffer();
        formatter.renderWrappedText(sb, 80, 0, "This is a short line.");

        assertEquals("This is a short line.", sb.toString());
    }

    public void testRenderWrappedTextWraps()
    {
        HelpFormatter formatter = new HelpFormatter();
        formatter.setNewLine("\n");

        StringBuffer sb = new StringBuffer();
        String text = "aaaa bbbb cccc dddd eeee ffff";
        formatter.renderWrappedText(sb, 10, 0, text);

        String result = sb.toString();
        assertTrue(result.indexOf('\n') > 0);

        String[] lines = result.split("\n");
        for (int i = 0; i < lines.length; i++)
        {
            assertTrue("line too long: [" + lines[i] + "]", lines[i].length() <= 10);
        }
    }

    public void testPrintWrappedWritesNewline()
    {
        HelpFormatter formatter = new HelpFormatter();
        formatter.setNewLine("\n");

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PrintWriter pw = new PrintWriter(out);
        formatter.printWrapped(pw, 80, "hello world");
        pw.flush();

        String result = out.toString();
        assertEquals("hello world" + System.getProperty("line.separator"), result);
    }

    public void testPrintHelpRejectsNullSyntax()
    {
        HelpFormatter formatter = new HelpFormatter();
        Options options = new Options();

        try
        {
            formatter.printHelp(null, options);
            fail("Expected IllegalArgumentException for null cmdLineSyntax");
        }
        catch (IllegalArgumentException e)
        {
            // expected
        }
    }

    public void testPrintHelpRejectsEmptySyntax()
    {
        HelpFormatter formatter = new HelpFormatter();
        Options options = new Options();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PrintWriter pw = new PrintWriter(out);

        try
        {
            formatter.printHelp(pw, 80, "", null, options, 1, 3, null, false);
            fail("Expected IllegalArgumentException for empty cmdLineSyntax");
        }
        catch (IllegalArgumentException e)
        {
            // expected
        }
    }

    public void testPrintUsageSimpleRequiredOption()
    {
        HelpFormatter formatter = new HelpFormatter();

        Options options = new Options();
        options.addOption("a", "aaa", false, "a desc");

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PrintWriter pw = new PrintWriter(out);
        formatter.printUsage(pw, 80, "app", options);
        pw.flush();

        String result = out.toString().trim();
        assertEquals("usage: app [-a]", result);
    }

    public void testPrintUsageRequiredOptionHasNoBrackets()
    {
        HelpFormatter formatter = new HelpFormatter();

        Options options = new Options();
        Option opt = new Option("a", "aaa", false, "a desc");
        opt.setRequired(true);
        options.addOption(opt);

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PrintWriter pw = new PrintWriter(out);
        formatter.printUsage(pw, 80, "app", options);
        pw.flush();

        String result = out.toString().trim();
        assertEquals("usage: app -a", result);
    }

    public void testPrintUsageWithOptionGroup()
    {
        HelpFormatter formatter = new HelpFormatter();

        OptionGroup group = new OptionGroup();
        group.addOption(new Option("a", false, "a desc"));
        group.addOption(new Option("b", false, "b desc"));
        group.setRequired(true);

        Options options = new Options();
        options.addOptionGroup(group);

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PrintWriter pw = new PrintWriter(out);
        formatter.printUsage(pw, 80, "app", options);
        pw.flush();

        String result = out.toString().trim();
        assertEquals("usage: app -a | -b", result);
    }

    public void testPrintUsageOptionalOptionGroupHasBrackets()
    {
        HelpFormatter formatter = new HelpFormatter();

        OptionGroup group = new OptionGroup();
        group.addOption(new Option("a", false, "a desc"));
        group.addOption(new Option("b", false, "b desc"));
        // group not required by default

        Options options = new Options();
        options.addOptionGroup(group);

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PrintWriter pw = new PrintWriter(out);
        formatter.printUsage(pw, 80, "app", options);
        pw.flush();

        String result = out.toString().trim();
        assertEquals("usage: app [-a | -b]", result);
    }

    public void testPrintUsageWithArgName()
    {
        HelpFormatter formatter = new HelpFormatter();

        Options options = new Options();
        Option opt = new Option("f", true, "file to use");
        opt.setArgName("file");
        opt.setRequired(true);
        options.addOption(opt);

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PrintWriter pw = new PrintWriter(out);
        formatter.printUsage(pw, 80, "app", options);
        pw.flush();

        String result = out.toString().trim();
        assertEquals("usage: app -f <file>", result);
    }

    public void testRenderOptionsBasic()
    {
        HelpFormatter formatter = new HelpFormatter();
        formatter.setNewLine("\n");

        Options options = new Options();
        options.addOption("a", "aaa", false, "aaaa aaaa aaaa aaaa aaaa");
        options.addOption(null, "bbb", false, "bbbb bbbb bbbb bbbb bbbb");

        StringBuffer sb = new StringBuffer();
        formatter.renderOptions(sb, 80, options, 1, 3);

        String result = sb.toString();

        assertTrue(result.indexOf("-a,--aaa") >= 0);
        assertTrue(result.indexOf("--bbb") >= 0);
        assertTrue(result.indexOf("aaaa aaaa aaaa aaaa aaaa") >= 0);
        assertTrue(result.indexOf("bbbb bbbb bbbb bbbb bbbb") >= 0);
    }

    public void testRenderOptionsSortedByComparator()
    {
        HelpFormatter formatter = new HelpFormatter();
        formatter.setNewLine("\n");

        Options options = new Options();
        options.addOption("b", "bbb", false, "b desc");
        options.addOption("a", "aaa", false, "a desc");

        StringBuffer sb = new StringBuffer();
        formatter.renderOptions(sb, 80, options, 1, 3);

        String result = sb.toString();
        int posA = result.indexOf("-a,--aaa");
        int posB = result.indexOf("-b,--bbb");

        assertTrue(posA >= 0);
        assertTrue(posB >= 0);
        assertTrue("default comparator should sort -a before -b", posA < posB);
    }

    public void testPrintOptionsNoOptions()
    {
        HelpFormatter formatter = new HelpFormatter();
        formatter.setNewLine("\n");

        Options options = new Options();

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PrintWriter pw = new PrintWriter(out);
        formatter.printOptions(pw, 80, options, 1, 3);
        pw.flush();

        assertEquals("" + System.getProperty("line.separator"), out.toString());
    }

    public void testPrintHelpFullOutputContainsHeaderAndFooter()
    {
        HelpFormatter formatter = new HelpFormatter();
        formatter.setNewLine("\n");

        Options options = new Options();
        options.addOption("h", "help", false, "print help");

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PrintWriter pw = new PrintWriter(out);

        formatter.printHelp(pw, 80, "myapp", "Header text", options, 1, 3, "Footer text", false);
        pw.flush();

        String result = out.toString();
        assertTrue(result.indexOf("usage: myapp") >= 0);
        assertTrue(result.indexOf("Header text") >= 0);
        assertTrue(result.indexOf("-h,--help") >= 0);
        assertTrue(result.indexOf("print help") >= 0);
        assertTrue(result.indexOf("Footer text") >= 0);
    }

    public void testPrintHelpWithAutoUsage()
    {
        HelpFormatter formatter = new HelpFormatter();
        formatter.setNewLine("\n");

        Options options = new Options();
        options.addOption("x", false, "the x option");

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PrintWriter pw = new PrintWriter(out);

        formatter.printHelp(pw, 80, "myapp", null, options, 1, 3, null, true);
        pw.flush();

        String result = out.toString();
        assertTrue(result.indexOf("usage: myapp [-x]") >= 0);
    }

    public void testPrintHelpBlankHeaderFooterOmitted()
    {
        HelpFormatter formatter = new HelpFormatter();
        formatter.setNewLine("\n");

        Options options = new Options();
        options.addOption("x", false, "the x option");

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PrintWriter pw = new PrintWriter(out);

        formatter.printHelp(pw, 80, "myapp", "   ", options, 1, 3, "   ", false);
        pw.flush();

        String result = out.toString();
        // only usage line and the option line should be present, blank header/footer skipped
        String[] lines = result.split(System.getProperty("line.separator"));
        assertEquals(2, lines.length);
    }
}
