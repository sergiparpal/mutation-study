/*
 * Copyright (C) 2014 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.gson.internal;

import java.lang.reflect.Constructor;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import junit.framework.TestCase;

public final class $Gson$TypesAgentTest extends TestCase {

  // ---- fixtures ----

  private static final class StringList extends ArrayList<String> {
    private static final long serialVersionUID = 1L;
  }

  private static final class StringIntegerMap extends HashMap<String, Integer> {
    private static final long serialVersionUID = 1L;
  }

  private static class GenericHolder<T> {
    T value;
  }

  private static final class StringHolder extends GenericHolder<String> {
  }

  // non-static inner class: has an implicit, non-null enclosing instance type.
  private final class NonStaticInner {
  }

  // ---- private constructor ----

  public void testPrivateConstructorThrows() throws Exception {
    Constructor<?> constructor = $Gson$Types.class.getDeclaredConstructor();
    constructor.setAccessible(true);
    try {
      constructor.newInstance();
      fail();
    } catch (InvocationTargetException expected) {
      assertTrue(expected.getCause() instanceof UnsupportedOperationException);
    }
  }

  // ---- newParameterizedTypeWithOwner ----

  public void testNewParameterizedTypeWithOwner_topLevelRawType() {
    ParameterizedType type =
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    assertNull(type.getOwnerType());
    assertEquals(List.class, type.getRawType());
    assertEquals(1, type.getActualTypeArguments().length);
    assertEquals(String.class, type.getActualTypeArguments()[0]);
  }

  public void testNewParameterizedTypeWithOwner_nonStaticRawTypeRequiresOwner() {
    try {
      $Gson$Types.newParameterizedTypeWithOwner(null, NonStaticInner.class, String.class);
      fail();
    } catch (IllegalArgumentException expected) {
    }

    // Supplying the owner type makes it valid.
    ParameterizedType type = $Gson$Types.newParameterizedTypeWithOwner(
        $Gson$TypesAgentTest.class, NonStaticInner.class);
    assertEquals($Gson$TypesAgentTest.class, type.getOwnerType());
  }

  public void testNewParameterizedTypeWithOwner_rejectsNullTypeArgument() {
    try {
      $Gson$Types.newParameterizedTypeWithOwner(null, List.class, new Type[] { null });
      fail();
    } catch (NullPointerException expected) {
    }
  }

  public void testNewParameterizedTypeWithOwner_rejectsPrimitiveTypeArgument() {
    try {
      $Gson$Types.newParameterizedTypeWithOwner(null, List.class, int.class);
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  public void testParameterizedTypeEqualsAndHashCode() {
    ParameterizedType a = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    ParameterizedType b = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    ParameterizedType c = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, Integer.class);

    assertTrue(a.equals(b));
    assertEquals(a.hashCode(), b.hashCode());
    assertFalse(a.equals(c));
    assertFalse(a.equals("not a type"));
  }

  public void testParameterizedTypeToString() {
    ParameterizedType single =
        $Gson$Types.newParameterizedTypeWithOwner(null, Map.class, String.class);
    assertEquals("java.util.Map<java.lang.String>", single.toString());

    ParameterizedType multi =
        $Gson$Types.newParameterizedTypeWithOwner(null, Map.class, String.class, Integer.class);
    assertEquals("java.util.Map<java.lang.String, java.lang.Integer>", multi.toString());

    ParameterizedType none = $Gson$Types.newParameterizedTypeWithOwner(null, List.class);
    assertEquals("java.util.List", none.toString());
  }

  // ---- arrayOf ----

  public void testArrayOf() {
    GenericArrayType arrayType = $Gson$Types.arrayOf(String.class);
    assertEquals(String.class, arrayType.getGenericComponentType());
    assertEquals("java.lang.String[]", arrayType.toString());
  }

  // ---- subtypeOf / supertypeOf ----

  public void testSubtypeOfObject() {
    WildcardType wildcard = $Gson$Types.subtypeOf(Object.class);
    assertEquals(1, wildcard.getUpperBounds().length);
    assertEquals(Object.class, wildcard.getUpperBounds()[0]);
    assertEquals(0, wildcard.getLowerBounds().length);
    assertEquals("?", wildcard.toString());
  }

  public void testSubtypeOfConcreteBound() {
    WildcardType wildcard = $Gson$Types.subtypeOf(CharSequence.class);
    assertEquals(CharSequence.class, wildcard.getUpperBounds()[0]);
    assertEquals("? extends java.lang.CharSequence", wildcard.toString());
  }

  public void testSubtypeOfWildcardBoundCopiesUpperBounds() {
    WildcardType existing = $Gson$Types.subtypeOf(String.class);
    WildcardType derived = $Gson$Types.subtypeOf(existing);
    assertEquals(String.class, derived.getUpperBounds()[0]);
  }

  public void testSubtypeOfRejectsPrimitive() {
    try {
      $Gson$Types.subtypeOf(int.class);
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  public void testSupertypeOf() {
    WildcardType wildcard = $Gson$Types.supertypeOf(String.class);
    assertEquals(Object.class, wildcard.getUpperBounds()[0]);
    assertEquals(1, wildcard.getLowerBounds().length);
    assertEquals(String.class, wildcard.getLowerBounds()[0]);
    assertEquals("? super java.lang.String", wildcard.toString());
  }

  public void testWildcardEqualsAndHashCode() {
    WildcardType a = $Gson$Types.subtypeOf(String.class);
    WildcardType b = $Gson$Types.subtypeOf(String.class);
    WildcardType c = $Gson$Types.supertypeOf(String.class);

    assertTrue(a.equals(b));
    assertEquals(a.hashCode(), b.hashCode());
    assertFalse(a.equals(c));
  }

  // ---- canonicalize ----

  public void testCanonicalizeClass() {
    assertEquals(String.class, $Gson$Types.canonicalize(String.class));
  }

  public void testCanonicalizeArrayClassBecomesGenericArrayType() {
    Type canonical = $Gson$Types.canonicalize(String[].class);
    assertTrue(canonical instanceof GenericArrayType);
    assertEquals(String.class, ((GenericArrayType) canonical).getGenericComponentType());
  }

  public void testCanonicalizeParameterizedType() {
    ParameterizedType original =
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    Type canonical = $Gson$Types.canonicalize(original);
    assertTrue($Gson$Types.equals(original, canonical));
  }

  public void testCanonicalizeUnsupportedTypeReturnsSameInstance() throws Exception {
    TypeVariable<?> typeVariable = GenericHolder.class.getTypeParameters()[0];
    assertSame(typeVariable, $Gson$Types.canonicalize(typeVariable));
  }

  // ---- getRawType ----

  public void testGetRawTypeOfClass() {
    assertEquals(String.class, $Gson$Types.getRawType(String.class));
  }

  public void testGetRawTypeOfParameterizedType() {
    ParameterizedType type =
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    assertEquals(List.class, $Gson$Types.getRawType(type));
  }

  public void testGetRawTypeOfGenericArrayType() {
    GenericArrayType arrayType = $Gson$Types.arrayOf(String.class);
    assertEquals(String[].class, $Gson$Types.getRawType(arrayType));
  }

  public void testGetRawTypeOfTypeVariableReturnsObject() throws Exception {
    TypeVariable<?> typeVariable = GenericHolder.class.getTypeParameters()[0];
    assertEquals(Object.class, $Gson$Types.getRawType(typeVariable));
  }

  public void testGetRawTypeOfWildcardType() {
    WildcardType wildcard = $Gson$Types.subtypeOf(String.class);
    assertEquals(String.class, $Gson$Types.getRawType(wildcard));
  }

  public void testGetRawTypeRejectsNull() {
    try {
      $Gson$Types.getRawType(null);
      fail();
    } catch (IllegalArgumentException expected) {
      assertTrue(expected.getMessage().contains("null"));
    }
  }

  public void testGetRawTypeRejectsUnknownTypeKind() {
    Type unsupported = new Type() {
    };
    try {
      $Gson$Types.getRawType(unsupported);
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  // ---- equals ----

  public void testEqualsSameInstance() {
    assertTrue($Gson$Types.equals(String.class, String.class));
    assertTrue($Gson$Types.equals(null, null));
  }

  public void testEqualsClasses() {
    assertTrue($Gson$Types.equals(String.class, String.class));
    assertFalse($Gson$Types.equals(String.class, Integer.class));
  }

  public void testEqualsParameterizedTypes() {
    ParameterizedType a = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    ParameterizedType b = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    ParameterizedType c = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, Integer.class);
    assertTrue($Gson$Types.equals(a, b));
    assertFalse($Gson$Types.equals(a, c));
    assertFalse($Gson$Types.equals(a, String.class));
  }

  public void testEqualsGenericArrayTypes() {
    GenericArrayType a = $Gson$Types.arrayOf(String.class);
    GenericArrayType b = $Gson$Types.arrayOf(String.class);
    GenericArrayType c = $Gson$Types.arrayOf(Integer.class);
    assertTrue($Gson$Types.equals(a, b));
    assertFalse($Gson$Types.equals(a, c));
    assertFalse($Gson$Types.equals(a, String.class));
  }

  public void testEqualsWildcardTypes() {
    WildcardType a = $Gson$Types.subtypeOf(String.class);
    WildcardType b = $Gson$Types.subtypeOf(String.class);
    WildcardType c = $Gson$Types.supertypeOf(String.class);
    assertTrue($Gson$Types.equals(a, b));
    assertFalse($Gson$Types.equals(a, c));
    assertFalse($Gson$Types.equals(a, String.class));
  }

  public void testEqualsTypeVariables() throws Exception {
    TypeVariable<?> a = GenericHolder.class.getTypeParameters()[0];
    TypeVariable<?> b = GenericHolder.class.getTypeParameters()[0];
    assertTrue($Gson$Types.equals(a, b));
    assertFalse($Gson$Types.equals(a, String.class));
  }

  public void testEqualsUnsupportedKindReturnsFalse() {
    Type unsupportedA = new Type() {
    };
    Type unsupportedB = new Type() {
    };
    assertFalse($Gson$Types.equals(unsupportedA, unsupportedB));
  }

  // ---- typeToString ----

  public void testTypeToString() {
    assertEquals("java.lang.String", $Gson$Types.typeToString(String.class));

    GenericArrayType arrayType = $Gson$Types.arrayOf(String.class);
    assertEquals("java.lang.String[]", $Gson$Types.typeToString(arrayType));
  }

  // ---- getArrayComponentType ----

  public void testGetArrayComponentTypeOfClassArray() {
    assertEquals(String.class, $Gson$Types.getArrayComponentType(String[].class));
    assertEquals(int.class, $Gson$Types.getArrayComponentType(int[].class));
  }

  public void testGetArrayComponentTypeOfGenericArrayType() {
    GenericArrayType arrayType = $Gson$Types.arrayOf(String.class);
    assertEquals(String.class, $Gson$Types.getArrayComponentType(arrayType));
  }

  public void testGetArrayComponentTypeOfNonArrayClassReturnsNull() {
    assertNull($Gson$Types.getArrayComponentType(String.class));
  }

  public void testGetArrayComponentTypeRejectsNonArrayNonClassType() {
    ParameterizedType notAnArray =
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    try {
      $Gson$Types.getArrayComponentType(notAnArray);
      fail();
    } catch (ClassCastException expected) {
    }
  }

  // ---- getCollectionElementType ----

  public void testGetCollectionElementTypeFromConcreteSubclass() {
    Type elementType = $Gson$Types.getCollectionElementType(StringList.class, StringList.class);
    assertEquals(String.class, elementType);
  }

  public void testGetCollectionElementTypeFromParameterizedContext() {
    ParameterizedType context =
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, Integer.class);
    Type elementType = $Gson$Types.getCollectionElementType(context, List.class);
    assertEquals(Integer.class, elementType);
  }

  public void testGetCollectionElementTypeNotAssignableThrows() {
    try {
      $Gson$Types.getCollectionElementType(String.class, String.class);
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  // ---- getMapKeyAndValueTypes ----

  public void testGetMapKeyAndValueTypesFromConcreteSubclass() {
    Type[] types = $Gson$Types.getMapKeyAndValueTypes(StringIntegerMap.class, StringIntegerMap.class);
    assertEquals(2, types.length);
    assertEquals(String.class, types[0]);
    assertEquals(Integer.class, types[1]);
  }

  public void testGetMapKeyAndValueTypesPropertiesSpecialCase() {
    Type[] types = $Gson$Types.getMapKeyAndValueTypes(Properties.class, Properties.class);
    assertEquals(2, types.length);
    assertEquals(String.class, types[0]);
    assertEquals(String.class, types[1]);
  }

  public void testGetMapKeyAndValueTypesRawMapDefaultsToObject() {
    Type[] types = $Gson$Types.getMapKeyAndValueTypes(Map.class, Map.class);
    assertEquals(2, types.length);
    assertEquals(Object.class, types[0]);
    assertEquals(Object.class, types[1]);
  }

  // ---- resolve / getSupertype (exercised indirectly through public entry points) ----

  public void testResolveTypeVariableThroughInheritance() {
    Type resolved = $Gson$Types.getSupertype(StringHolder.class, StringHolder.class, GenericHolder.class);
    assertTrue(resolved instanceof ParameterizedType);
    assertEquals(String.class, ((ParameterizedType) resolved).getActualTypeArguments()[0]);
  }

  public void testGetSupertypeRejectsUnrelatedType() {
    try {
      $Gson$Types.getSupertype(String.class, String.class, List.class);
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  public void testResolveNonGenericTypeReturnsSameInstance() {
    Type resolved = $Gson$Types.resolve(String.class, String.class, Integer.class);
    assertSame(Integer.class, resolved);
  }

  // ---- checkNotPrimitive via Modifier sanity check on fixtures ----

  public void testNonStaticInnerFixtureIsNotStatic() {
    assertFalse(Modifier.isStatic(NonStaticInner.class.getModifiers()));
  }
}
