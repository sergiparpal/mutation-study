/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.math;

import java.math.BigDecimal;
import java.math.BigInteger;

import junit.framework.TestCase;

public class NumberUtilsAgentTest extends TestCase {

    public void testToInt() {
        assertEquals(0, NumberUtils.toInt(null));
        assertEquals(0, NumberUtils.toInt(""));
        assertEquals(1, NumberUtils.toInt("1"));
        assertEquals(0, NumberUtils.toInt("not a number"));
        assertEquals(1, NumberUtils.toInt(null, 1));
        assertEquals(1, NumberUtils.toInt("", 1));
        assertEquals(1, NumberUtils.toInt("1", 0));
        assertEquals(-1, NumberUtils.toInt("-1", 0));
    }

    public void testToLong() {
        assertEquals(0L, NumberUtils.toLong(null));
        assertEquals(0L, NumberUtils.toLong(""));
        assertEquals(1L, NumberUtils.toLong("1"));
        assertEquals(0L, NumberUtils.toLong("not a number"));
        assertEquals(1L, NumberUtils.toLong(null, 1L));
        assertEquals(1L, NumberUtils.toLong("", 1L));
        assertEquals(1L, NumberUtils.toLong("1", 0L));
    }

    public void testToFloat() {
        assertEquals(0.0f, NumberUtils.toFloat(null), 0.0001f);
        assertEquals(0.0f, NumberUtils.toFloat(""), 0.0001f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5"), 0.0001f);
        assertEquals(0.0f, NumberUtils.toFloat("not a number"), 0.0001f);
        assertEquals(1.0f, NumberUtils.toFloat(null, 1.0f), 0.0001f);
        assertEquals(1.1f, NumberUtils.toFloat("", 1.1f), 0.0001f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5", 0.0f), 0.0001f);
    }

    public void testToDouble() {
        assertEquals(0.0d, NumberUtils.toDouble(null), 0.0001d);
        assertEquals(0.0d, NumberUtils.toDouble(""), 0.0001d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5"), 0.0001d);
        assertEquals(0.0d, NumberUtils.toDouble("not a number"), 0.0001d);
        assertEquals(1.1d, NumberUtils.toDouble(null, 1.1d), 0.0001d);
        assertEquals(1.1d, NumberUtils.toDouble("", 1.1d), 0.0001d);
        assertEquals(1.5d, NumberUtils.toDouble("1.5", 0.0d), 0.0001d);
    }

    public void testToByte() {
        assertEquals((byte) 0, NumberUtils.toByte(null));
        assertEquals((byte) 0, NumberUtils.toByte(""));
        assertEquals((byte) 1, NumberUtils.toByte("1"));
        assertEquals((byte) 1, NumberUtils.toByte(null, (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("", (byte) 1));
        assertEquals((byte) 1, NumberUtils.toByte("1", (byte) 0));
        assertEquals((byte) 0, NumberUtils.toByte("not a number", (byte) 0));
    }

    public void testToShort() {
        assertEquals((short) 0, NumberUtils.toShort(null));
        assertEquals((short) 0, NumberUtils.toShort(""));
        assertEquals((short) 1, NumberUtils.toShort("1"));
        assertEquals((short) 1, NumberUtils.toShort(null, (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("", (short) 1));
        assertEquals((short) 1, NumberUtils.toShort("1", (short) 0));
        assertEquals((short) 0, NumberUtils.toShort("not a number", (short) 0));
    }

    public void testCreateNumberNull() {
        assertNull(NumberUtils.createNumber(null));
    }

    public void testCreateNumberBlankThrows() {
        try {
            NumberUtils.createNumber("");
            fail("Expected NumberFormatException for blank string");
        } catch (NumberFormatException expected) {
            // expected
        }
        try {
            NumberUtils.createNumber("   ");
            fail("Expected NumberFormatException for blank string");
        } catch (NumberFormatException expected) {
            // expected
        }
    }

    public void testCreateNumberDoubleMinus() {
        assertNull(NumberUtils.createNumber("--1"));
    }

    public void testCreateNumberInvalid() {
        try {
            NumberUtils.createNumber("12.5.2");
            fail("Expected NumberFormatException for invalid number");
        } catch (NumberFormatException expected) {
            // expected
        }
        try {
            NumberUtils.createNumber("not a number");
            fail("Expected NumberFormatException for invalid number");
        } catch (NumberFormatException expected) {
            // expected
        }
    }

    public void testCreateNumberHex() {
        Number n = NumberUtils.createNumber("0x10");
        assertEquals(Integer.valueOf(16), n);
        Number neg = NumberUtils.createNumber("-0x10");
        assertEquals(Integer.valueOf(-16), neg);
    }

    public void testCreateNumberIntegerLongBigInteger() {
        assertEquals(Integer.valueOf(123), NumberUtils.createNumber("123"));
        assertTrue(NumberUtils.createNumber("123") instanceof Integer);

        String bigLong = String.valueOf(Long.MAX_VALUE);
        assertTrue(NumberUtils.createNumber(bigLong) instanceof Long);
        assertEquals(Long.valueOf(Long.MAX_VALUE), NumberUtils.createNumber(bigLong));

        String bigger = "123456789012345678901234567890";
        Number bigNum = NumberUtils.createNumber(bigger);
        assertTrue(bigNum instanceof BigInteger);
        assertEquals(new BigInteger(bigger), bigNum);
    }

    public void testCreateNumberFloatDoubleBigDecimal() {
        Number f = NumberUtils.createNumber("1.5");
        assertTrue(f instanceof Float);
        assertEquals(1.5f, f.floatValue(), 0.0001f);

        Number withTypeL = NumberUtils.createNumber("3L");
        assertTrue(withTypeL instanceof Long);
        assertEquals(3L, withTypeL.longValue());

        Number withTypeF = NumberUtils.createNumber("3.2F");
        assertTrue(withTypeF instanceof Float);
        assertEquals(3.2f, withTypeF.floatValue(), 0.0001f);

        Number withTypeD = NumberUtils.createNumber("3.2D");
        assertTrue(withTypeD instanceof Double);
        assertEquals(3.2d, withTypeD.doubleValue(), 0.0001d);
    }

    public void testCreateNumberBadLSuffix() {
        try {
            NumberUtils.createNumber("1.5L");
            fail("Expected NumberFormatException for non-digit value with L suffix");
        } catch (NumberFormatException expected) {
            // expected
        }
    }

    public void testCreateFloat() {
        assertNull(NumberUtils.createFloat(null));
        assertEquals(new Float("1.5"), NumberUtils.createFloat("1.5"));
        try {
            NumberUtils.createFloat("not a number");
            fail("Expected NumberFormatException");
        } catch (NumberFormatException expected) {
            // expected
        }
    }

    public void testCreateDouble() {
        assertNull(NumberUtils.createDouble(null));
        assertEquals(new Double("1.5"), NumberUtils.createDouble("1.5"));
        try {
            NumberUtils.createDouble("not a number");
            fail("Expected NumberFormatException");
        } catch (NumberFormatException expected) {
            // expected
        }
    }

    public void testCreateInteger() {
        assertNull(NumberUtils.createInteger(null));
        assertEquals(new Integer(12345), NumberUtils.createInteger("12345"));
        assertEquals(new Integer(26), NumberUtils.createInteger("0x1A"));
        try {
            NumberUtils.createInteger("not a number");
            fail("Expected NumberFormatException");
        } catch (NumberFormatException expected) {
            // expected
        }
    }

    public void testCreateLong() {
        assertNull(NumberUtils.createLong(null));
        assertEquals(new Long(12345L), NumberUtils.createLong("12345"));
        try {
            NumberUtils.createLong("not a number");
            fail("Expected NumberFormatException");
        } catch (NumberFormatException expected) {
            // expected
        }
    }

    public void testCreateBigInteger() {
        assertNull(NumberUtils.createBigInteger(null));
        assertEquals(new BigInteger("12345"), NumberUtils.createBigInteger("12345"));
        try {
            NumberUtils.createBigInteger("not a number");
            fail("Expected NumberFormatException");
        } catch (NumberFormatException expected) {
            // expected
        }
    }

    public void testCreateBigDecimal() {
        assertNull(NumberUtils.createBigDecimal(null));
        assertEquals(new BigDecimal("12345.1"), NumberUtils.createBigDecimal("12345.1"));
        try {
            NumberUtils.createBigDecimal("");
            fail("Expected NumberFormatException for blank string");
        } catch (NumberFormatException expected) {
            // expected
        }
        try {
            NumberUtils.createBigDecimal("not a number");
            fail("Expected NumberFormatException");
        } catch (NumberFormatException expected) {
            // expected
        }
    }

    public void testMinLongArray() {
        assertEquals(5L, NumberUtils.min(new long[] { 5L }));
        assertEquals(-3L, NumberUtils.min(new long[] { 5L, 1L, 9L, -3L }));
        try {
            NumberUtils.min((long[]) null);
            fail("Expected IllegalArgumentException for null array");
        } catch (IllegalArgumentException expected) {
            // expected
        }
        try {
            NumberUtils.min(new long[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    public void testMinIntArray() {
        assertEquals(5, NumberUtils.min(new int[] { 5 }));
        assertEquals(-3, NumberUtils.min(new int[] { 5, 1, 9, -3 }));
        try {
            NumberUtils.min((int[]) null);
            fail("Expected IllegalArgumentException for null array");
        } catch (IllegalArgumentException expected) {
            // expected
        }
        try {
            NumberUtils.min(new int[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    public void testMinShortArray() {
        assertEquals((short) -3, NumberUtils.min(new short[] { (short) 5, (short) 1, (short) -3 }));
        try {
            NumberUtils.min((short[]) null);
            fail("Expected IllegalArgumentException for null array");
        } catch (IllegalArgumentException expected) {
            // expected
        }
        try {
            NumberUtils.min(new short[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    public void testMinByteArray() {
        assertEquals((byte) -3, NumberUtils.min(new byte[] { (byte) 5, (byte) 1, (byte) -3 }));
        try {
            NumberUtils.min((byte[]) null);
            fail("Expected IllegalArgumentException for null array");
        } catch (IllegalArgumentException expected) {
            // expected
        }
        try {
            NumberUtils.min(new byte[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    public void testMinDoubleArray() {
        assertEquals(-3.5d, NumberUtils.min(new double[] { 5.0d, 1.0d, -3.5d }), 0.0001d);
        assertTrue(Double.isNaN(NumberUtils.min(new double[] { 1.0d, Double.NaN, 2.0d })));
        try {
            NumberUtils.min((double[]) null);
            fail("Expected IllegalArgumentException for null array");
        } catch (IllegalArgumentException expected) {
            // expected
        }
        try {
            NumberUtils.min(new double[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    public void testMinFloatArray() {
        assertEquals(-3.5f, NumberUtils.min(new float[] { 5.0f, 1.0f, -3.5f }), 0.0001f);
        assertTrue(Float.isNaN(NumberUtils.min(new float[] { 1.0f, Float.NaN, 2.0f })));
        try {
            NumberUtils.min((float[]) null);
            fail("Expected IllegalArgumentException for null array");
        } catch (IllegalArgumentException expected) {
            // expected
        }
        try {
            NumberUtils.min(new float[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    public void testMaxLongArray() {
        assertEquals(9L, NumberUtils.max(new long[] { 5L, 1L, 9L, -3L }));
        try {
            NumberUtils.max((long[]) null);
            fail("Expected IllegalArgumentException for null array");
        } catch (IllegalArgumentException expected) {
            // expected
        }
        try {
            NumberUtils.max(new long[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    public void testMaxIntArray() {
        assertEquals(9, NumberUtils.max(new int[] { 5, 1, 9, -3 }));
        try {
            NumberUtils.max((int[]) null);
            fail("Expected IllegalArgumentException for null array");
        } catch (IllegalArgumentException expected) {
            // expected
        }
        try {
            NumberUtils.max(new int[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    public void testMaxShortArray() {
        assertEquals((short) 9, NumberUtils.max(new short[] { (short) 5, (short) 9, (short) -3 }));
        try {
            NumberUtils.max((short[]) null);
            fail("Expected IllegalArgumentException for null array");
        } catch (IllegalArgumentException expected) {
            // expected
        }
        try {
            NumberUtils.max(new short[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    public void testMaxByteArray() {
        assertEquals((byte) 9, NumberUtils.max(new byte[] { (byte) 5, (byte) 9, (byte) -3 }));
        try {
            NumberUtils.max((byte[]) null);
            fail("Expected IllegalArgumentException for null array");
        } catch (IllegalArgumentException expected) {
            // expected
        }
        try {
            NumberUtils.max(new byte[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    public void testMaxDoubleArray() {
        assertEquals(9.5d, NumberUtils.max(new double[] { 5.0d, 9.5d, -3.0d }), 0.0001d);
        assertTrue(Double.isNaN(NumberUtils.max(new double[] { 1.0d, Double.NaN, 2.0d })));
        try {
            NumberUtils.max((double[]) null);
            fail("Expected IllegalArgumentException for null array");
        } catch (IllegalArgumentException expected) {
            // expected
        }
        try {
            NumberUtils.max(new double[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    public void testMaxFloatArray() {
        assertEquals(9.5f, NumberUtils.max(new float[] { 5.0f, 9.5f, -3.0f }), 0.0001f);
        assertTrue(Float.isNaN(NumberUtils.max(new float[] { 1.0f, Float.NaN, 2.0f })));
        try {
            NumberUtils.max((float[]) null);
            fail("Expected IllegalArgumentException for null array");
        } catch (IllegalArgumentException expected) {
            // expected
        }
        try {
            NumberUtils.max(new float[0]);
            fail("Expected IllegalArgumentException for empty array");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    public void testMinThreeValues() {
        assertEquals(1L, NumberUtils.min(3L, 1L, 2L));
        assertEquals(1, NumberUtils.min(3, 1, 2));
        assertEquals((short) 1, NumberUtils.min((short) 3, (short) 1, (short) 2));
        assertEquals((byte) 1, NumberUtils.min((byte) 3, (byte) 1, (byte) 2));
        assertEquals(1.0d, NumberUtils.min(3.0d, 1.0d, 2.0d), 0.0001d);
        assertEquals(1.0f, NumberUtils.min(3.0f, 1.0f, 2.0f), 0.0001f);
        assertTrue(Double.isNaN(NumberUtils.min(3.0d, Double.NaN, 2.0d)));
    }

    public void testMaxThreeValues() {
        assertEquals(3L, NumberUtils.max(3L, 1L, 2L));
        assertEquals(3, NumberUtils.max(3, 1, 2));
        assertEquals((short) 3, NumberUtils.max((short) 3, (short) 1, (short) 2));
        assertEquals((byte) 3, NumberUtils.max((byte) 3, (byte) 1, (byte) 2));
        assertEquals(3.0d, NumberUtils.max(3.0d, 1.0d, 2.0d), 0.0001d);
        assertEquals(3.0f, NumberUtils.max(3.0f, 1.0f, 2.0f), 0.0001f);
        assertTrue(Double.isNaN(NumberUtils.max(3.0d, Double.NaN, 2.0d)));
    }

    public void testIsDigits() {
        assertFalse(NumberUtils.isDigits(null));
        assertFalse(NumberUtils.isDigits(""));
        assertTrue(NumberUtils.isDigits("12345"));
        assertFalse(NumberUtils.isDigits("12 345"));
        assertFalse(NumberUtils.isDigits("1234.5"));
        assertFalse(NumberUtils.isDigits("-1234"));
        assertFalse(NumberUtils.isDigits("1ab"));
    }

    public void testIsNumber() {
        assertFalse(NumberUtils.isNumber(null));
        assertFalse(NumberUtils.isNumber(""));
        assertTrue(NumberUtils.isNumber("12345"));
        assertTrue(NumberUtils.isNumber("-1234"));
        assertTrue(NumberUtils.isNumber("1234.5"));
        assertTrue(NumberUtils.isNumber("1234E5"));
        assertTrue(NumberUtils.isNumber("1234.5E-10"));
        assertTrue(NumberUtils.isNumber("0x1A"));
        assertFalse(NumberUtils.isNumber("0x"));
        assertFalse(NumberUtils.isNumber("1234E"));
        assertFalse(NumberUtils.isNumber("--1234"));
        assertFalse(NumberUtils.isNumber("1.2.3"));
        assertTrue(NumberUtils.isNumber("1234L"));
        assertTrue(NumberUtils.isNumber("1234.5F"));
        assertTrue(NumberUtils.isNumber("1234.5D"));
        assertFalse(NumberUtils.isNumber("1234E5L"));
        assertFalse(NumberUtils.isNumber("abc"));
        assertFalse(NumberUtils.isNumber("."));
        assertTrue(NumberUtils.isNumber("1."));
    }

    public void testConstants() {
        assertEquals(0L, NumberUtils.LONG_ZERO.longValue());
        assertEquals(1L, NumberUtils.LONG_ONE.longValue());
        assertEquals(-1L, NumberUtils.LONG_MINUS_ONE.longValue());
        assertEquals(0, NumberUtils.INTEGER_ZERO.intValue());
        assertEquals(1, NumberUtils.INTEGER_ONE.intValue());
        assertEquals(-1, NumberUtils.INTEGER_MINUS_ONE.intValue());
        assertEquals((short) 0, NumberUtils.SHORT_ZERO.shortValue());
        assertEquals((short) 1, NumberUtils.SHORT_ONE.shortValue());
        assertEquals((short) -1, NumberUtils.SHORT_MINUS_ONE.shortValue());
        assertEquals((byte) 0, NumberUtils.BYTE_ZERO.byteValue());
        assertEquals((byte) 1, NumberUtils.BYTE_ONE.byteValue());
        assertEquals((byte) -1, NumberUtils.BYTE_MINUS_ONE.byteValue());
        assertEquals(0.0d, NumberUtils.DOUBLE_ZERO.doubleValue(), 0.0001d);
        assertEquals(1.0d, NumberUtils.DOUBLE_ONE.doubleValue(), 0.0001d);
        assertEquals(-1.0d, NumberUtils.DOUBLE_MINUS_ONE.doubleValue(), 0.0001d);
        assertEquals(0.0f, NumberUtils.FLOAT_ZERO.floatValue(), 0.0001f);
        assertEquals(1.0f, NumberUtils.FLOAT_ONE.floatValue(), 0.0001f);
        assertEquals(-1.0f, NumberUtils.FLOAT_MINUS_ONE.floatValue(), 0.0001f);
    }

    public void testConstructor() {
        assertNotNull(new NumberUtils());
    }
}
