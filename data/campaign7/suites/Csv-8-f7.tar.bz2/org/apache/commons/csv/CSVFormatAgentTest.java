/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.csv;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.junit.Test;

public class CSVFormatAgentTest {

    // ---------------------------------------------------------------
    // Predefined formats
    // ---------------------------------------------------------------

    @Test
    public void testDefaultFormat() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertEquals(',', format.getDelimiter());
        assertEquals(Character.valueOf('"'), format.getQuoteChar());
        assertNull(format.getQuotePolicy());
        assertNull(format.getCommentStart());
        assertNull(format.getEscape());
        assertFalse(format.getIgnoreSurroundingSpaces());
        assertTrue(format.getIgnoreEmptyLines());
        assertEquals("\r\n", format.getRecordSeparator());
        assertNull(format.getNullString());
        assertNull(format.getHeader());
        assertFalse(format.getSkipHeaderRecord());
    }

    @Test
    public void testRfc4180Format() {
        final CSVFormat format = CSVFormat.RFC4180;
        assertEquals(',', format.getDelimiter());
        assertEquals(Character.valueOf('"'), format.getQuoteChar());
        assertFalse(format.getIgnoreEmptyLines());
        assertEquals("\r\n", format.getRecordSeparator());
    }

    @Test
    public void testExcelFormat() {
        final CSVFormat format = CSVFormat.EXCEL;
        assertEquals(',', format.getDelimiter());
        assertEquals(Character.valueOf('"'), format.getQuoteChar());
        assertFalse(format.getIgnoreEmptyLines());
        assertEquals("\r\n", format.getRecordSeparator());
        // Per the Excel format javadoc, this is currently the same as RFC4180
        assertEquals(CSVFormat.RFC4180, CSVFormat.EXCEL);
    }

    @Test
    public void testTdfFormat() {
        final CSVFormat format = CSVFormat.TDF;
        assertEquals('\t', format.getDelimiter());
        assertEquals(Character.valueOf('"'), format.getQuoteChar());
        assertTrue(format.getIgnoreSurroundingSpaces());
        assertTrue(format.getIgnoreEmptyLines());
        assertEquals("\r\n", format.getRecordSeparator());
    }

    @Test
    public void testMySqlFormat() {
        final CSVFormat format = CSVFormat.MYSQL;
        assertEquals('\t', format.getDelimiter());
        assertNull(format.getQuoteChar());
        assertEquals(Character.valueOf('\\'), format.getEscape());
        assertFalse(format.getIgnoreEmptyLines());
        assertEquals("\n", format.getRecordSeparator());
    }

    // ---------------------------------------------------------------
    // newFormat / constructor validation
    // ---------------------------------------------------------------

    @Test
    public void testNewFormat() {
        final CSVFormat format = CSVFormat.newFormat(';');
        assertEquals(';', format.getDelimiter());
        assertNull(format.getQuoteChar());
        assertNull(format.getQuotePolicy());
        assertNull(format.getCommentStart());
        assertNull(format.getEscape());
        assertFalse(format.getIgnoreSurroundingSpaces());
        assertFalse(format.getIgnoreEmptyLines());
        assertNull(format.getRecordSeparator());
        assertNull(format.getNullString());
        assertNull(format.getHeader());
        assertFalse(format.getSkipHeaderRecord());
    }

    @Test
    public void testNewFormatRejectsLfDelimiter() {
        try {
            CSVFormat.newFormat('\n');
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    public void testNewFormatRejectsCrDelimiter() {
        try {
            CSVFormat.newFormat('\r');
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    // ---------------------------------------------------------------
    // with* line-break rejection
    // ---------------------------------------------------------------

    @Test
    public void testWithDelimiterRejectsLineBreak() {
        try {
            CSVFormat.DEFAULT.withDelimiter('\n');
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    public void testWithCommentStartRejectsLineBreak() {
        try {
            CSVFormat.DEFAULT.withCommentStart('\r');
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    public void testWithEscapeRejectsLineBreak() {
        try {
            CSVFormat.DEFAULT.withEscape('\n');
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    public void testWithQuoteCharRejectsLineBreak() {
        try {
            CSVFormat.DEFAULT.withQuoteChar('\r');
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    public void testWithQuoteCharNullDisablesQuoting() {
        final CSVFormat format = CSVFormat.DEFAULT.withQuoteChar(null);
        assertNull(format.getQuoteChar());
        assertFalse(format.isQuoting());
    }

    @Test
    public void testWithEscapeNullDisablesEscaping() {
        final CSVFormat format = CSVFormat.DEFAULT.withEscape(Character.valueOf('\\')).withEscape((Character) null);
        assertNull(format.getEscape());
        assertFalse(format.isEscaping());
    }

    @Test
    public void testWithCommentStartNullDisablesCommenting() {
        final CSVFormat format = CSVFormat.DEFAULT.withCommentStart('#').withCommentStart((Character) null);
        assertNull(format.getCommentStart());
        assertFalse(format.isCommentingEnabled());
    }

    // ---------------------------------------------------------------
    // with* value propagation (immutability - "withers" return new instances
    // leaving the original unchanged, and only change the targeted field)
    // ---------------------------------------------------------------

    @Test
    public void testWithDelimiterDoesNotMutateOriginal() {
        final CSVFormat original = CSVFormat.DEFAULT;
        final CSVFormat changed = original.withDelimiter(';');
        assertEquals(',', original.getDelimiter());
        assertEquals(';', changed.getDelimiter());
    }

    @Test
    public void testWithNullString() {
        final CSVFormat format = CSVFormat.DEFAULT.withNullString("N/A");
        assertEquals("N/A", format.getNullString());
        assertTrue(format.isNullHandling());
    }

    @Test
    public void testWithIgnoreEmptyLines() {
        assertFalse(CSVFormat.DEFAULT.withIgnoreEmptyLines(false).getIgnoreEmptyLines());
        assertTrue(CSVFormat.DEFAULT.withIgnoreEmptyLines(true).getIgnoreEmptyLines());
    }

    @Test
    public void testWithIgnoreSurroundingSpaces() {
        assertTrue(CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(true).getIgnoreSurroundingSpaces());
        assertFalse(CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(false).getIgnoreSurroundingSpaces());
    }

    @Test
    public void testWithRecordSeparatorChar() {
        final CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator('\n');
        assertEquals("\n", format.getRecordSeparator());
    }

    @Test
    public void testWithRecordSeparatorString() {
        final CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("\r\n");
        assertEquals("\r\n", format.getRecordSeparator());
    }

    @Test
    public void testWithSkipHeaderRecord() {
        assertTrue(CSVFormat.DEFAULT.withSkipHeaderRecord(true).getSkipHeaderRecord());
        assertFalse(CSVFormat.DEFAULT.withSkipHeaderRecord(false).getSkipHeaderRecord());
    }

    @Test
    public void testWithQuotePolicy() {
        final CSVFormat format = CSVFormat.DEFAULT.withQuotePolicy(Quote.ALL);
        assertEquals(Quote.ALL, format.getQuotePolicy());
    }

    // ---------------------------------------------------------------
    // Header handling and defensive copying
    // ---------------------------------------------------------------

    @Test
    public void testWithHeaderStoresGivenNames() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("A", "B", "C");
        assertArrayEquals(new String[] { "A", "B", "C" }, format.getHeader());
    }

    @Test
    public void testWithHeaderNoArgsYieldsEmptyArrayNotNull() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader();
        assertNotNull(format.getHeader());
        assertEquals(0, format.getHeader().length);
    }

    @Test
    public void testGetHeaderReturnsDefensiveCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("A", "B");
        final String[] header1 = format.getHeader();
        header1[0] = "MUTATED";
        final String[] header2 = format.getHeader();
        assertEquals("A", header2[0]);
    }

    @Test
    public void testWithHeaderStoresDefensiveCopyOfInputArray() {
        final String[] input = { "A", "B" };
        final CSVFormat format = CSVFormat.DEFAULT.withHeader(input);
        input[0] = "MUTATED";
        assertEquals("A", format.getHeader()[0]);
    }

    // ---------------------------------------------------------------
    // equals / hashCode
    // ---------------------------------------------------------------

    @Test
    public void testEqualsReflexive() {
        final CSVFormat format = CSVFormat.DEFAULT;
        assertTrue(format.equals(format));
    }

    @Test
    public void testEqualsNull() {
        assertFalse(CSVFormat.DEFAULT.equals(null));
    }

    @Test
    public void testEqualsDifferentClass() {
        assertFalse(CSVFormat.DEFAULT.equals("not a CSVFormat"));
    }

    @Test
    public void testEqualsAndHashCodeForEquivalentFormats() {
        final CSVFormat a = CSVFormat.newFormat(',').withQuoteChar('"').withRecordSeparator("\r\n")
                .withIgnoreEmptyLines(true);
        final CSVFormat b = CSVFormat.newFormat(',').withQuoteChar('"').withRecordSeparator("\r\n")
                .withIgnoreEmptyLines(true);
        assertTrue(a.equals(b));
        assertTrue(b.equals(a));
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    public void testEqualsDifferentDelimiter() {
        final CSVFormat a = CSVFormat.newFormat(',');
        final CSVFormat b = CSVFormat.newFormat(';');
        assertFalse(a.equals(b));
    }

    @Test
    public void testEqualsDifferentHeader() {
        final CSVFormat a = CSVFormat.DEFAULT.withHeader("A", "B");
        final CSVFormat b = CSVFormat.DEFAULT.withHeader("A", "C");
        assertFalse(a.equals(b));
    }

    @Test
    public void testEqualsSameHeaderContent() {
        final CSVFormat a = CSVFormat.DEFAULT.withHeader("A", "B");
        final CSVFormat b = CSVFormat.DEFAULT.withHeader("A", "B");
        assertTrue(a.equals(b));
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    public void testExcelAndRfc4180AreEqual() {
        // Both are DEFAULT.withIgnoreEmptyLines(false); the Excel javadoc
        // states this is currently intentional.
        assertEquals(CSVFormat.RFC4180, CSVFormat.EXCEL);
        assertEquals(CSVFormat.RFC4180.hashCode(), CSVFormat.EXCEL.hashCode());
    }

    @Test
    public void testNotEqualsDefaultAndRfc4180() {
        assertNotEquals(CSVFormat.DEFAULT, CSVFormat.RFC4180);
    }

    // ---------------------------------------------------------------
    // isXxx() predicates
    // ---------------------------------------------------------------

    @Test
    public void testIsQuoting() {
        assertTrue(CSVFormat.DEFAULT.isQuoting());
        assertFalse(CSVFormat.DEFAULT.withQuoteChar((Character) null).isQuoting());
    }

    @Test
    public void testIsEscaping() {
        assertFalse(CSVFormat.DEFAULT.isEscaping());
        assertTrue(CSVFormat.DEFAULT.withEscape('\\').isEscaping());
    }

    @Test
    public void testIsCommentingEnabled() {
        assertFalse(CSVFormat.DEFAULT.isCommentingEnabled());
        assertTrue(CSVFormat.DEFAULT.withCommentStart('#').isCommentingEnabled());
    }

    @Test
    public void testIsNullHandling() {
        assertFalse(CSVFormat.DEFAULT.isNullHandling());
        assertTrue(CSVFormat.DEFAULT.withNullString("NULL").isNullHandling());
    }

    // ---------------------------------------------------------------
    // validate()
    // ---------------------------------------------------------------

    @Test
    public void testValidateDefaultDoesNotThrow() {
        CSVFormat.DEFAULT.validate();
    }

    @Test
    public void testValidateRejectsQuoteCharEqualToDelimiter() {
        final CSVFormat format = CSVFormat.newFormat(',').withQuoteChar(',').withEscape('\\');
        try {
            format.validate();
            fail("Expected IllegalStateException");
        } catch (final IllegalStateException expected) {
            // expected
        }
    }

    @Test
    public void testValidateRejectsEscapeEqualToDelimiter() {
        final CSVFormat format = CSVFormat.newFormat(',').withEscape(',');
        try {
            format.validate();
            fail("Expected IllegalStateException");
        } catch (final IllegalStateException expected) {
            // expected
        }
    }

    @Test
    public void testValidateRejectsCommentStartEqualToDelimiter() {
        final CSVFormat format = CSVFormat.newFormat(',').withCommentStart(',').withEscape('\\');
        try {
            format.validate();
            fail("Expected IllegalStateException");
        } catch (final IllegalStateException expected) {
            // expected
        }
    }

    @Test
    public void testValidateRejectsQuoteCharEqualToCommentStart() {
        final CSVFormat format = CSVFormat.newFormat(',').withQuoteChar('#').withCommentStart('#').withEscape('\\');
        try {
            format.validate();
            fail("Expected IllegalStateException");
        } catch (final IllegalStateException expected) {
            // expected
        }
    }

    @Test
    public void testValidateRejectsEscapeEqualToCommentStart() {
        final CSVFormat format = CSVFormat.newFormat(',').withEscape('#').withCommentStart('#');
        try {
            format.validate();
            fail("Expected IllegalStateException");
        } catch (final IllegalStateException expected) {
            // expected
        }
    }

    @Test
    public void testValidateRejectsNoneQuotePolicyWithoutEscape() {
        final CSVFormat format = CSVFormat.newFormat(',').withQuotePolicy(Quote.NONE);
        try {
            format.validate();
            fail("Expected IllegalStateException");
        } catch (final IllegalStateException expected) {
            // expected
        }
    }

    @Test
    public void testValidateAcceptsNoneQuotePolicyWithEscape() {
        final CSVFormat format = CSVFormat.newFormat(',').withQuotePolicy(Quote.NONE).withEscape('\\');
        format.validate();
    }

    @Test
    public void testValidateRejectsDuplicateHeaderNames() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("A", "B", "A");
        try {
            format.validate();
            fail("Expected IllegalStateException");
        } catch (final IllegalStateException expected) {
            // expected
        }
    }

    @Test
    public void testValidateAcceptsDistinctHeaderNames() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("A", "B", "C");
        format.validate();
    }

    // ---------------------------------------------------------------
    // format()
    // ---------------------------------------------------------------

    @Test
    public void testFormatSimpleValues() {
        final String result = CSVFormat.DEFAULT.format(new Object[] { "a", "b", "c" });
        assertEquals("a,b,c", result);
    }

    @Test
    public void testFormatQuotesValueContainingDelimiter() {
        final String result = CSVFormat.DEFAULT.format(new Object[] { "a,b", "c" });
        assertEquals("\"a,b\",c", result);
    }

    @Test
    public void testFormatWithCustomDelimiter() {
        final String result = CSVFormat.newFormat(';').withQuoteChar('"').format(new Object[] { "a", "b" });
        assertEquals("a;b", result);
    }

    // ---------------------------------------------------------------
    // toString()
    // ---------------------------------------------------------------

    @Test
    public void testToStringContainsDelimiter() {
        final String s = CSVFormat.DEFAULT.toString();
        assertTrue(s.contains("Delimiter=<,>"));
    }

    @Test
    public void testToStringContainsHeaderWhenSet() {
        final String s = CSVFormat.DEFAULT.withHeader("A", "B").toString();
        assertTrue(s.contains("Header:"));
        assertTrue(s.contains("A"));
        assertTrue(s.contains("B"));
    }

    @Test
    public void testToStringOmitsHeaderWhenNotSet() {
        final String s = CSVFormat.DEFAULT.toString();
        assertFalse(s.contains("Header:"));
    }
}
