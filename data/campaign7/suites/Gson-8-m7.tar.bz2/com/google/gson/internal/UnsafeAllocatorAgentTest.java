/*
 * Copyright (C) 2011 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.google.gson.internal;

import junit.framework.TestCase;

public class UnsafeAllocatorAgentTest extends TestCase {

  public static class NoArgConstructor {
    public NoArgConstructor() {
      throw new AssertionError("constructor should not be invoked by UnsafeAllocator");
    }
  }

  public static class WithFinalField {
    // Not a compile-time constant (Integer.parseInt call), so javac cannot inline
    // this value at field-access sites; the test can observe the real field value.
    public final int value = Integer.parseInt("42");
  }

  public abstract static class AbstractClass {
  }

  public interface SomeInterface {
  }

  public void testCreateReturnsNonNullAllocator() {
    UnsafeAllocator allocator = UnsafeAllocator.create();
    assertNotNull(allocator);
  }

  public void testCreateReturnsNewInstanceEachTime() {
    UnsafeAllocator first = UnsafeAllocator.create();
    UnsafeAllocator second = UnsafeAllocator.create();
    assertNotNull(first);
    assertNotNull(second);
    assertNotSame(first, second);
  }

  public void testNewInstanceBypassesConstructor() throws Exception {
    UnsafeAllocator allocator = UnsafeAllocator.create();
    NoArgConstructor instance = allocator.newInstance(NoArgConstructor.class);
    assertNotNull(instance);
    assertTrue(instance instanceof NoArgConstructor);
  }

  public void testNewInstanceOfPlainObject() throws Exception {
    UnsafeAllocator allocator = UnsafeAllocator.create();
    Object instance = allocator.newInstance(Object.class);
    assertNotNull(instance);
  }

  public void testNewInstanceLeavesFinalFieldAtDefault() throws Exception {
    UnsafeAllocator allocator = UnsafeAllocator.create();
    WithFinalField instance = allocator.newInstance(WithFinalField.class);
    assertNotNull(instance);
    assertEquals(0, instance.value);
  }

  public void testNewInstanceOnInterfaceThrows() throws Exception {
    UnsafeAllocator allocator = UnsafeAllocator.create();
    try {
      allocator.newInstance(SomeInterface.class);
      fail("Expected UnsupportedOperationException for interface");
    } catch (UnsupportedOperationException expected) {
      assertTrue(expected.getMessage().contains(SomeInterface.class.getName()));
    }
  }

  public void testNewInstanceOnAbstractClassThrows() throws Exception {
    UnsafeAllocator allocator = UnsafeAllocator.create();
    try {
      allocator.newInstance(AbstractClass.class);
      fail("Expected UnsupportedOperationException for abstract class");
    } catch (UnsupportedOperationException expected) {
      assertTrue(expected.getMessage().contains(AbstractClass.class.getName()));
    }
  }

  public void testNewInstanceTwiceProducesDistinctObjects() throws Exception {
    UnsafeAllocator allocator = UnsafeAllocator.create();
    NoArgConstructor first = allocator.newInstance(NoArgConstructor.class);
    NoArgConstructor second = allocator.newInstance(NoArgConstructor.class);
    assertNotNull(first);
    assertNotNull(second);
    assertNotSame(first, second);
  }
}
