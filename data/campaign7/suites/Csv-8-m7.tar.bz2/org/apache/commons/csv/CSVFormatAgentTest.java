/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.csv;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;

import org.junit.Test;

public class CSVFormatAgentTest {

    @Test
    public void testDefaultFormatValues() {
        assertEquals(',', CSVFormat.DEFAULT.getDelimiter());
        assertEquals(Character.valueOf('"'), CSVFormat.DEFAULT.getQuoteChar());
        assertNull(CSVFormat.DEFAULT.getCommentStart());
        assertNull(CSVFormat.DEFAULT.getEscape());
        assertTrue(CSVFormat.DEFAULT.getIgnoreEmptyLines());
        assertFalse(CSVFormat.DEFAULT.getIgnoreSurroundingSpaces());
        assertEquals("\r\n", CSVFormat.DEFAULT.getRecordSeparator());
        assertNull(CSVFormat.DEFAULT.getNullString());
        assertNull(CSVFormat.DEFAULT.getHeader());
        assertFalse(CSVFormat.DEFAULT.getSkipHeaderRecord());
        assertTrue(CSVFormat.DEFAULT.isQuoting());
        assertFalse(CSVFormat.DEFAULT.isCommentingEnabled());
        assertFalse(CSVFormat.DEFAULT.isEscaping());
        assertFalse(CSVFormat.DEFAULT.isNullHandling());
    }

    @Test
    public void testRfc4180DiffersFromDefaultOnlyByIgnoreEmptyLines() {
        assertFalse(CSVFormat.RFC4180.getIgnoreEmptyLines());
        assertEquals(CSVFormat.DEFAULT.getDelimiter(), CSVFormat.RFC4180.getDelimiter());
        assertEquals(CSVFormat.DEFAULT.getQuoteChar(), CSVFormat.RFC4180.getQuoteChar());
        assertFalse(CSVFormat.DEFAULT.equals(CSVFormat.RFC4180));
    }

    @Test
    public void testTdfFormat() {
        assertEquals('\t', CSVFormat.TDF.getDelimiter());
        assertTrue(CSVFormat.TDF.getIgnoreSurroundingSpaces());
        assertEquals(Character.valueOf('"'), CSVFormat.TDF.getQuoteChar());
    }

    @Test
    public void testMySqlFormat() {
        assertEquals('\t', CSVFormat.MYSQL.getDelimiter());
        assertEquals(Character.valueOf('\\'), CSVFormat.MYSQL.getEscape());
        assertFalse(CSVFormat.MYSQL.getIgnoreEmptyLines());
        assertNull(CSVFormat.MYSQL.getQuoteChar());
        assertEquals("\n", CSVFormat.MYSQL.getRecordSeparator());
        assertFalse(CSVFormat.MYSQL.isQuoting());
        assertTrue(CSVFormat.MYSQL.isEscaping());
    }

    @Test
    public void testNewFormat() {
        final CSVFormat format = CSVFormat.newFormat(';');
        assertEquals(';', format.getDelimiter());
        assertNull(format.getQuoteChar());
        assertNull(format.getQuotePolicy());
        assertNull(format.getCommentStart());
        assertNull(format.getEscape());
        assertFalse(format.getIgnoreSurroundingSpaces());
        assertFalse(format.getIgnoreEmptyLines());
        assertNull(format.getRecordSeparator());
        assertNull(format.getNullString());
        assertNull(format.getHeader());
        assertFalse(format.getSkipHeaderRecord());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testNewFormatWithLineBreakDelimiterThrows() {
        CSVFormat.newFormat('\n');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithDelimiterCrThrows() {
        CSVFormat.DEFAULT.withDelimiter('\r');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithQuoteCharLineBreakThrows() {
        CSVFormat.DEFAULT.withQuoteChar('\n');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithEscapeLineBreakThrows() {
        CSVFormat.DEFAULT.withEscape('\r');
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithCommentStartLineBreakThrows() {
        CSVFormat.DEFAULT.withCommentStart('\n');
    }

    @Test
    public void testWithDelimiter() {
        final CSVFormat format = CSVFormat.DEFAULT.withDelimiter('!');
        assertEquals('!', format.getDelimiter());
        // original is unchanged (immutability)
        assertEquals(',', CSVFormat.DEFAULT.getDelimiter());
    }

    @Test
    public void testWithQuoteChar() {
        final CSVFormat format = CSVFormat.DEFAULT.withQuoteChar('\'');
        assertEquals(Character.valueOf('\''), format.getQuoteChar());
        assertTrue(format.isQuoting());

        final CSVFormat disabled = format.withQuoteChar((Character) null);
        assertNull(disabled.getQuoteChar());
        assertFalse(disabled.isQuoting());
    }

    @Test
    public void testWithEscape() {
        final CSVFormat format = CSVFormat.DEFAULT.withEscape('&');
        assertEquals(Character.valueOf('&'), format.getEscape());
        assertTrue(format.isEscaping());
    }

    @Test
    public void testWithCommentStart() {
        final CSVFormat format = CSVFormat.DEFAULT.withCommentStart('#');
        assertEquals(Character.valueOf('#'), format.getCommentStart());
        assertTrue(format.isCommentingEnabled());
    }

    @Test
    public void testWithNullString() {
        final CSVFormat format = CSVFormat.DEFAULT.withNullString("N/A");
        assertEquals("N/A", format.getNullString());
        assertTrue(format.isNullHandling());
        assertFalse(CSVFormat.DEFAULT.isNullHandling());
    }

    @Test
    public void testWithIgnoreEmptyLines() {
        assertFalse(CSVFormat.DEFAULT.withIgnoreEmptyLines(false).getIgnoreEmptyLines());
        assertTrue(CSVFormat.DEFAULT.withIgnoreEmptyLines(true).getIgnoreEmptyLines());
    }

    @Test
    public void testWithIgnoreSurroundingSpaces() {
        assertTrue(CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(true).getIgnoreSurroundingSpaces());
        assertFalse(CSVFormat.DEFAULT.withIgnoreSurroundingSpaces(false).getIgnoreSurroundingSpaces());
    }

    @Test
    public void testWithRecordSeparatorChar() {
        final CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator('\n');
        assertEquals("\n", format.getRecordSeparator());
    }

    @Test
    public void testWithRecordSeparatorString() {
        final CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("|");
        assertEquals("|", format.getRecordSeparator());
    }

    @Test
    public void testWithSkipHeaderRecord() {
        assertTrue(CSVFormat.DEFAULT.withSkipHeaderRecord(true).getSkipHeaderRecord());
        assertFalse(CSVFormat.DEFAULT.withSkipHeaderRecord(false).getSkipHeaderRecord());
    }

    @Test
    public void testWithQuotePolicy() {
        final CSVFormat format = CSVFormat.DEFAULT.withQuotePolicy(Quote.ALL);
        assertEquals(Quote.ALL, format.getQuotePolicy());
    }

    @Test
    public void testWithHeaderReturnsCopy() {
        final String[] header = {"a", "b", "c"};
        final CSVFormat format = CSVFormat.DEFAULT.withHeader(header);
        header[0] = "changed";
        assertEquals("a", format.getHeader()[0]);
    }

    @Test
    public void testGetHeaderReturnsCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("a", "b");
        final String[] first = format.getHeader();
        final String[] second = format.getHeader();
        assertNotSame(first, second);
        assertArrayEquals(first, second);
        first[0] = "mutated";
        assertEquals("a", format.getHeader()[0]);
    }

    @Test
    public void testWithHeaderNull() {
        final CSVFormat withHeader = CSVFormat.DEFAULT.withHeader("a", "b");
        final CSVFormat withoutHeader = withHeader.withHeader((String[]) null);
        assertNull(withoutHeader.getHeader());
    }

    @Test
    public void testWithHeaderEmpty() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader();
        assertNotNull(format.getHeader());
        assertEquals(0, format.getHeader().length);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithHeaderDuplicateThrows() {
        CSVFormat.DEFAULT.withHeader("a", "b", "a");
    }

    @Test
    public void testEqualsAndHashCode() {
        final CSVFormat a = CSVFormat.DEFAULT.withHeader("x", "y");
        final CSVFormat b = CSVFormat.DEFAULT.withHeader("x", "y");
        assertTrue(a.equals(b));
        assertTrue(b.equals(a));
        assertEquals(a.hashCode(), b.hashCode());
        assertTrue(a.equals(a));
    }

    @Test
    public void testEqualsDifferentFields() {
        final CSVFormat base = CSVFormat.DEFAULT;
        assertFalse(base.equals(base.withDelimiter(';')));
        assertFalse(base.equals(base.withQuoteChar('\'')));
        assertFalse(base.equals(base.withCommentStart('#')));
        assertFalse(base.equals(base.withEscape('\\')));
        assertFalse(base.equals(base.withNullString("N/A")));
        assertFalse(base.equals(base.withHeader("a")));
        assertFalse(base.equals(base.withIgnoreSurroundingSpaces(true)));
        assertFalse(base.equals(base.withIgnoreEmptyLines(false)));
        assertFalse(base.equals(base.withSkipHeaderRecord(true)));
        assertFalse(base.equals(base.withRecordSeparator("\n")));
        assertFalse(base.equals(base.withQuotePolicy(Quote.ALL)));
    }

    @Test
    public void testEqualsNullAndOtherType() {
        assertFalse(CSVFormat.DEFAULT.equals(null));
        assertFalse(CSVFormat.DEFAULT.equals("not a format"));
    }

    @Test
    public void testFormatValues() {
        final String formatted = CSVFormat.DEFAULT.format("a", "b", "c");
        assertEquals("a,b,c", formatted);
    }

    @Test
    public void testFormatWithQuoting() {
        final String formatted = CSVFormat.DEFAULT.format("a,b", "c");
        assertEquals("\"a,b\",c", formatted);
    }

    @Test
    public void testToStringContainsDelimiter() {
        final String str = CSVFormat.DEFAULT.toString();
        assertTrue(str.contains("Delimiter=<,>"));
    }

    @Test
    public void testToStringContainsHeaderWhenSet() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("a", "b");
        final String str = format.toString();
        assertTrue(str.contains("Header:"));
    }

    @Test
    public void testToStringOmitsOptionalPartsWhenDisabled() {
        final CSVFormat format = CSVFormat.newFormat(',');
        final String str = format.toString();
        assertFalse(str.contains("Escape="));
        assertFalse(str.contains("QuoteChar="));
        assertFalse(str.contains("CommentStart="));
        assertFalse(str.contains("NullString="));
        assertFalse(str.contains("Header:"));
    }

    @Test
    public void testParseReturnsNonNullParser() throws IOException {
        final Reader in = new StringReader("a,b,c\n1,2,3\n");
        final CSVParser parser = CSVFormat.DEFAULT.parse(in);
        assertNotNull(parser);
        parser.close();
    }

    @Test(expected = IllegalStateException.class)
    public void testValidateQuoteCharEqualsDelimiterThrows() {
        CSVFormat.newFormat(',').withQuoteChar(',').withEscape('\\').validate();
    }

    @Test(expected = IllegalStateException.class)
    public void testValidateEscapeEqualsDelimiterThrows() {
        CSVFormat.newFormat(',').withEscape(',').validate();
    }

    @Test(expected = IllegalStateException.class)
    public void testValidateCommentStartEqualsDelimiterThrows() {
        CSVFormat.newFormat(',').withCommentStart(',').withEscape('\\').validate();
    }

    @Test(expected = IllegalStateException.class)
    public void testValidateQuoteCharEqualsCommentStartThrows() {
        CSVFormat.newFormat(',').withQuoteChar('#').withCommentStart('#').withEscape('\\').validate();
    }

    @Test(expected = IllegalStateException.class)
    public void testValidateEscapeEqualsCommentStartThrows() {
        CSVFormat.newFormat(',').withEscape('#').withCommentStart('#').validate();
    }

    @Test(expected = IllegalStateException.class)
    public void testValidateNoEscapeWithQuoteNoneThrows() {
        CSVFormat.newFormat(',').withQuotePolicy(Quote.NONE).validate();
    }

    @Test
    public void testValidatePassesForDefaultFormat() {
        CSVFormat.DEFAULT.validate();
        CSVFormat.RFC4180.validate();
        CSVFormat.EXCEL.validate();
        CSVFormat.TDF.validate();
        CSVFormat.MYSQL.validate();
    }

    @Test
    public void testIsSetFlags() {
        final CSVFormat format = CSVFormat.newFormat(',')
                .withQuoteChar('"')
                .withEscape('\\')
                .withCommentStart('#')
                .withNullString("NULL");
        assertTrue(format.isQuoting());
        assertTrue(format.isEscaping());
        assertTrue(format.isCommentingEnabled());
        assertTrue(format.isNullHandling());
    }
}
