/*
 * Copyright (C) 2024 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.google.gson.internal;

import junit.framework.TestCase;

public class UnsafeAllocatorAgentTest extends TestCase {

  /** A class whose constructor must never run if allocation truly bypasses it. */
  public static class ThrowingCtor {
    static int constructorCallCount = 0;
    int value = 42;

    public ThrowingCtor() {
      constructorCallCount++;
      throw new RuntimeException("constructor should not be invoked by UnsafeAllocator");
    }
  }

  public static class HasPrivateCtor {
    private final String name;

    private HasPrivateCtor() {
      this.name = "built-by-constructor";
    }

    public String getName() {
      return name;
    }
  }

  public abstract static class AbstractThing {
    int x;
  }

  public interface SomeInterface {
  }

  public void testCreateReturnsNonNullInstance() {
    UnsafeAllocator allocator = UnsafeAllocator.create();
    assertNotNull(allocator);
  }

  public void testNewInstanceBypassesConstructor() throws Exception {
    ThrowingCtor.constructorCallCount = 0;
    UnsafeAllocator allocator = UnsafeAllocator.create();

    ThrowingCtor instance = allocator.newInstance(ThrowingCtor.class);

    assertNotNull(instance);
    assertEquals(0, ThrowingCtor.constructorCallCount);
    // Field initializer ("value = 42") runs inside the constructor; since the
    // constructor never ran, the field must still have its default value.
    assertEquals(0, instance.value);
  }

  public void testNewInstanceReturnsCorrectType() throws Exception {
    UnsafeAllocator allocator = UnsafeAllocator.create();
    HasPrivateCtor instance = allocator.newInstance(HasPrivateCtor.class);

    assertNotNull(instance);
    assertTrue(instance instanceof HasPrivateCtor);
    // Private constructor was skipped, so the field it sets must be unset.
    assertNull(instance.getName());
  }

  public void testNewInstanceProducesDistinctObjects() throws Exception {
    UnsafeAllocator allocator = UnsafeAllocator.create();

    ThrowingCtor first = allocator.newInstance(ThrowingCtor.class);
    ThrowingCtor second = allocator.newInstance(ThrowingCtor.class);

    assertNotNull(first);
    assertNotNull(second);
    assertNotSame(first, second);
  }

  public void testMultipleAllocatorsBothWork() throws Exception {
    UnsafeAllocator allocatorA = UnsafeAllocator.create();
    UnsafeAllocator allocatorB = UnsafeAllocator.create();

    ThrowingCtor fromA = allocatorA.newInstance(ThrowingCtor.class);
    ThrowingCtor fromB = allocatorB.newInstance(ThrowingCtor.class);

    assertNotNull(fromA);
    assertNotNull(fromB);
  }

  public void testNewInstanceOnAbstractClassFails() {
    UnsafeAllocator allocator = UnsafeAllocator.create();
    try {
      allocator.newInstance(AbstractThing.class);
      fail("Expected an exception when allocating an abstract class");
    } catch (Exception expected) {
      // An abstract class has no concrete layout to allocate; some exception
      // (e.g. InstantiationException, possibly wrapped) must be thrown.
    }
  }

  public void testNewInstanceOnInterfaceFails() {
    UnsafeAllocator allocator = UnsafeAllocator.create();
    try {
      allocator.newInstance(SomeInterface.class);
      fail("Expected an exception when allocating an interface");
    } catch (Exception expected) {
      // Interfaces cannot be instantiated.
    }
  }
}
