/*
 * Copyright (C) 2024 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.gson.internal.bind;

import com.google.gson.Gson;
import com.google.gson.TypeAdapter;
import com.google.gson.TypeAdapterFactory;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.internal.ConstructorConstructor;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import java.util.HashMap;
import junit.framework.TestCase;

public final class JsonAdapterAnnotationTypeAdapterFactoryAgentTest extends TestCase {

  // -------------------- fixtures --------------------

  private static class PlainClass {
  }

  private static class NotAnAdapter {
  }

  @JsonAdapter(FooTypeAdapter.class)
  private static class AnnotatedWithAdapter {
    String value;

    AnnotatedWithAdapter() {
      this("default");
    }

    AnnotatedWithAdapter(String value) {
      this.value = value;
    }
  }

  @JsonAdapter(FooTypeAdapterFactory.class)
  private static class AnnotatedWithFactory {
  }

  @JsonAdapter(NotAnAdapter.class)
  private static class AnnotatedWithInvalidValue {
  }

  @JsonAdapter(NullReturningFactory.class)
  private static class AnnotatedWithNullFactory {
  }

  public static class FooTypeAdapter extends TypeAdapter<AnnotatedWithAdapter> {
    @Override public void write(JsonWriter out, AnnotatedWithAdapter value) throws IOException {
      out.value(value.value);
    }

    @Override public AnnotatedWithAdapter read(JsonReader in) throws IOException {
      return new AnnotatedWithAdapter(in.nextString());
    }
  }

  public static class FooTypeAdapterFactory implements TypeAdapterFactory {
    @SuppressWarnings("unchecked")
    @Override public <T> TypeAdapter<T> create(Gson gson, TypeToken<T> type) {
      if (type.getRawType() != AnnotatedWithFactory.class) {
        return null;
      }
      return (TypeAdapter<T>) new TypeAdapter<AnnotatedWithFactory>() {
        @Override public void write(JsonWriter out, AnnotatedWithFactory value) throws IOException {
          out.value("from-factory");
        }

        @Override public AnnotatedWithFactory read(JsonReader in) throws IOException {
          in.nextString();
          return new AnnotatedWithFactory();
        }
      };
    }
  }

  public static class NullReturningFactory implements TypeAdapterFactory {
    @Override public <T> TypeAdapter<T> create(Gson gson, TypeToken<T> type) {
      return null;
    }
  }

  private static JsonAdapterAnnotationTypeAdapterFactory newFactory() {
    return new JsonAdapterAnnotationTypeAdapterFactory(
        new ConstructorConstructor(new HashMap<java.lang.reflect.Type, com.google.gson.InstanceCreator<?>>()));
  }

  // -------------------- tests --------------------

  public void testCreate_returnsNullWhenNoAnnotationPresent() {
    JsonAdapterAnnotationTypeAdapterFactory factory = newFactory();
    Gson gson = new Gson();
    TypeAdapter<PlainClass> adapter = factory.create(gson, TypeToken.get(PlainClass.class));
    assertNull(adapter);
  }

  public void testCreate_withTypeAdapterValue() throws IOException {
    JsonAdapterAnnotationTypeAdapterFactory factory = newFactory();
    Gson gson = new Gson();
    TypeAdapter<AnnotatedWithAdapter> adapter =
        factory.create(gson, TypeToken.get(AnnotatedWithAdapter.class));
    assertNotNull(adapter);

    String json = adapter.toJson(new AnnotatedWithAdapter("hello"));
    assertEquals("\"hello\"", json);

    AnnotatedWithAdapter read = adapter.fromJson("\"world\"");
    assertEquals("world", read.value);
  }

  public void testCreate_withTypeAdapterValueIsNullSafe() throws IOException {
    JsonAdapterAnnotationTypeAdapterFactory factory = newFactory();
    Gson gson = new Gson();
    TypeAdapter<AnnotatedWithAdapter> adapter =
        factory.create(gson, TypeToken.get(AnnotatedWithAdapter.class));
    assertNotNull(adapter);

    // nullSafe() wrapping means null values do not reach FooTypeAdapter.write/read.
    assertEquals("null", adapter.toJson(null));
    assertNull(adapter.fromJson("null"));
  }

  public void testCreate_withTypeAdapterFactoryValue() throws IOException {
    JsonAdapterAnnotationTypeAdapterFactory factory = newFactory();
    Gson gson = new Gson();
    TypeAdapter<AnnotatedWithFactory> adapter =
        factory.create(gson, TypeToken.get(AnnotatedWithFactory.class));
    assertNotNull(adapter);

    assertEquals("\"from-factory\"", adapter.toJson(new AnnotatedWithFactory()));
    assertNotNull(adapter.fromJson("\"x\""));
    assertNull(adapter.fromJson("null"));
  }

  public void testCreate_withFactoryReturningNullYieldsNullAdapter() {
    JsonAdapterAnnotationTypeAdapterFactory factory = newFactory();
    Gson gson = new Gson();
    TypeAdapter<AnnotatedWithNullFactory> adapter =
        factory.create(gson, TypeToken.get(AnnotatedWithNullFactory.class));
    assertNull(adapter);
  }

  public void testCreate_withInvalidAnnotationValueThrows() {
    JsonAdapterAnnotationTypeAdapterFactory factory = newFactory();
    Gson gson = new Gson();
    try {
      factory.create(gson, TypeToken.get(AnnotatedWithInvalidValue.class));
      fail("Expected IllegalArgumentException");
    } catch (IllegalArgumentException expected) {
      assertEquals(
          "@JsonAdapter value must be TypeAdapter or TypeAdapterFactory reference.",
          expected.getMessage());
    }
  }

  public void testGetTypeAdapter_directTypeAdapterClass() throws IOException {
    JsonAdapter annotation = AnnotatedWithAdapter.class.getAnnotation(JsonAdapter.class);
    assertNotNull(annotation);

    ConstructorConstructor constructorConstructor =
        new ConstructorConstructor(new HashMap<java.lang.reflect.Type, com.google.gson.InstanceCreator<?>>());
    @SuppressWarnings("unchecked")
    TypeAdapter<AnnotatedWithAdapter> adapter =
        (TypeAdapter<AnnotatedWithAdapter>) JsonAdapterAnnotationTypeAdapterFactory.getTypeAdapter(
            constructorConstructor, new Gson(), TypeToken.get(AnnotatedWithAdapter.class), annotation);
    assertNotNull(adapter);
    assertEquals("\"hi\"", adapter.toJson(new AnnotatedWithAdapter("hi")));
  }

  public void testGetTypeAdapter_invalidValueThrows() {
    JsonAdapter annotation = AnnotatedWithInvalidValue.class.getAnnotation(JsonAdapter.class);
    assertNotNull(annotation);

    ConstructorConstructor constructorConstructor =
        new ConstructorConstructor(new HashMap<java.lang.reflect.Type, com.google.gson.InstanceCreator<?>>());
    try {
      JsonAdapterAnnotationTypeAdapterFactory.getTypeAdapter(
          constructorConstructor, new Gson(), TypeToken.get(AnnotatedWithInvalidValue.class), annotation);
      fail("Expected IllegalArgumentException");
    } catch (IllegalArgumentException expected) {
      // expected
    }
  }
}
