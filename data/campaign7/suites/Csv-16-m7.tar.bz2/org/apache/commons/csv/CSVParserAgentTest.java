/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.csv;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.io.StringReader;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.junit.Test;

public class CSVParserAgentTest {

    @Test
    public void testSimpleParse() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b,c\n1,2,3\n", CSVFormat.DEFAULT);
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(2, records.size());
        assertEquals(3, records.get(0).size());
        assertEquals("a", records.get(0).get(0));
        assertEquals("c", records.get(0).get(2));
        assertEquals("1", records.get(1).get(0));
        assertEquals("3", records.get(1).get(2));
        parser.close();
    }

    @Test
    public void testEmptyInputYieldsNoRecords() throws IOException {
        final CSVParser parser = CSVParser.parse("", CSVFormat.DEFAULT);
        final List<CSVRecord> records = parser.getRecords();
        assertTrue(records.isEmpty());
        parser.close();
    }

    @Test
    public void testGetRecordsOnlyReturnsRemainingRecords() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\nc,d\ne,f\n", CSVFormat.DEFAULT);
        final CSVRecord first = parser.nextRecord();
        assertEquals("a", first.get(0));
        final List<CSVRecord> rest = parser.getRecords();
        assertEquals(2, rest.size());
        assertEquals("c", rest.get(0).get(0));
        assertEquals("e", rest.get(1).get(0));
        parser.close();
    }

    @Test
    public void testHeaderMapWithExplicitHeader() throws IOException {
        final CSVParser parser = CSVParser.parse("1,2,3\n", CSVFormat.DEFAULT.withHeader("A", "B", "C"));
        final Map<String, Integer> headerMap = parser.getHeaderMap();
        assertEquals(Integer.valueOf(0), headerMap.get("A"));
        assertEquals(Integer.valueOf(1), headerMap.get("B"));
        assertEquals(Integer.valueOf(2), headerMap.get("C"));
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(1, records.size());
        assertEquals("2", records.get(0).get("B"));
        parser.close();
    }

    @Test
    public void testHeaderMapReturnsNullWithoutHeaderFormat() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n", CSVFormat.DEFAULT);
        assertNull(parser.getHeaderMap());
        parser.close();
    }

    @Test
    public void testHeaderMapIsCopyNotLive() throws IOException {
        final CSVParser parser = CSVParser.parse("1,2\n", CSVFormat.DEFAULT.withHeader("A", "B"));
        final Map<String, Integer> firstCopy = parser.getHeaderMap();
        firstCopy.remove("A");
        final Map<String, Integer> secondCopy = parser.getHeaderMap();
        assertTrue(secondCopy.containsKey("A"));
        parser.close();
    }

    @Test(expected = IllegalArgumentException.class)
    public void testDuplicateHeaderNamesThrowException() throws IOException {
        CSVParser.parse("1,2\n", CSVFormat.DEFAULT.withHeader("A", "A"));
    }

    @Test
    public void testSkipHeaderRecordReadFromFirstLine() throws IOException {
        final CSVParser parser = CSVParser.parse("name,age\nJohn,20\n",
                CSVFormat.DEFAULT.withHeader().withSkipHeaderRecord(true));
        final Map<String, Integer> headerMap = parser.getHeaderMap();
        assertTrue(headerMap.containsKey("name"));
        assertTrue(headerMap.containsKey("age"));
        final List<CSVRecord> records = parser.getRecords();
        assertEquals(1, records.size());
        assertEquals("John", records.get(0).get("name"));
        parser.close();
    }

    @Test
    public void testGetRecordNumberIncrements() throws IOException {
        final CSVParser parser = CSVParser.parse("a\nb\nc\n", CSVFormat.DEFAULT);
        assertEquals(0, parser.getRecordNumber());
        final CSVRecord r1 = parser.nextRecord();
        assertEquals(1, r1.getRecordNumber());
        assertEquals(1, parser.getRecordNumber());
        final CSVRecord r2 = parser.nextRecord();
        assertEquals(2, r2.getRecordNumber());
        parser.close();
    }

    @Test
    public void testNextRecordReturnsNullAtEndOfStream() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n", CSVFormat.DEFAULT);
        assertEquals("a", parser.nextRecord().get(0));
        assertNull(parser.nextRecord());
        assertNull(parser.nextRecord());
        parser.close();
    }

    @Test
    public void testGetCurrentLineNumber() throws IOException {
        final CSVParser parser = CSVParser.parse("a\nb\nc\n", CSVFormat.DEFAULT);
        assertEquals(0, parser.getCurrentLineNumber());
        parser.nextRecord();
        assertEquals(1, parser.getCurrentLineNumber());
        parser.nextRecord();
        assertEquals(2, parser.getCurrentLineNumber());
        parser.close();
    }

    @Test
    public void testIteratorHasNextAndNext() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n2\n", CSVFormat.DEFAULT);
        final Iterator<CSVRecord> iterator = parser.iterator();
        assertTrue(iterator.hasNext());
        assertEquals("1", iterator.next().get(0));
        assertTrue(iterator.hasNext());
        assertEquals("2", iterator.next().get(0));
        assertFalse(iterator.hasNext());
        parser.close();
    }

    @Test
    public void testIteratorNextWithoutHasNextThrowsOnExhaustion() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n", CSVFormat.DEFAULT);
        final Iterator<CSVRecord> iterator = parser.iterator();
        assertEquals("1", iterator.next().get(0));
        try {
            iterator.next();
            fail("Expected NoSuchElementException");
        } catch (final NoSuchElementException e) {
            // expected
        }
        parser.close();
    }

    @Test
    public void testIteratorRemoveUnsupported() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n", CSVFormat.DEFAULT);
        final Iterator<CSVRecord> iterator = parser.iterator();
        try {
            iterator.remove();
            fail("Expected UnsupportedOperationException");
        } catch (final UnsupportedOperationException e) {
            // expected
        }
        parser.close();
    }

    @Test
    public void testIteratorHasNextFalseAfterClose() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n2\n", CSVFormat.DEFAULT);
        parser.close();
        assertTrue(parser.isClosed());
        assertFalse(parser.iterator().hasNext());
    }

    @Test
    public void testIteratorNextThrowsAfterClose() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n2\n", CSVFormat.DEFAULT);
        parser.close();
        try {
            parser.iterator().next();
            fail("Expected NoSuchElementException");
        } catch (final NoSuchElementException e) {
            // expected
        }
    }

    @Test
    public void testCloseIsIdempotent() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n", CSVFormat.DEFAULT);
        assertFalse(parser.isClosed());
        parser.close();
        assertTrue(parser.isClosed());
        parser.close();
        assertTrue(parser.isClosed());
    }

    @Test
    public void testConstructorWithCharacterOffsetAndRecordNumber() throws IOException {
        final CSVParser parser = new CSVParser(new StringReader("a,b\nc,d\n"), CSVFormat.DEFAULT, 100, 5);
        final CSVRecord record = parser.nextRecord();
        assertEquals(5, record.getRecordNumber());
        assertEquals(100, record.getCharacterPosition());
        parser.close();
    }

    @Test(expected = IllegalArgumentException.class)
    public void testNullReaderThrowsException() throws IOException {
        new CSVParser(null, CSVFormat.DEFAULT);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testNullFormatThrowsException() throws IOException {
        new CSVParser(new StringReader("a,b\n"), null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testParseNullStringThrowsException() throws IOException {
        CSVParser.parse((String) null, CSVFormat.DEFAULT);
    }

    @Test
    public void testInvalidParseSequenceThrowsIOException() throws IOException {
        final CSVParser parser = CSVParser.parse("a,\"b\n", CSVFormat.DEFAULT);
        try {
            parser.getRecords();
            fail("Expected IOException due to unterminated quoted value");
        } catch (final IOException e) {
            // expected
        } finally {
            parser.close();
        }
    }

    @Test
    public void testCommentsAreAttachedToRecord() throws IOException {
        final CSVParser parser = CSVParser.parse("# comment\na,b\n", CSVFormat.DEFAULT.withCommentMarker('#'));
        final CSVRecord record = parser.nextRecord();
        assertEquals("a", record.get(0));
        assertTrue(record.hasComment());
        assertEquals("comment", record.getComment());
        parser.close();
    }

    @Test
    public void testTrailingDelimiterIsDropped() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b,\n", CSVFormat.DEFAULT.withTrailingDelimiter(true));
        final CSVRecord record = parser.nextRecord();
        assertEquals(2, record.size());
        parser.close();
    }

    @Test
    public void testTrimRemovesSurroundingWhitespace() throws IOException {
        final CSVParser parser = CSVParser.parse(" a , b \n", CSVFormat.DEFAULT.withTrim(true));
        final CSVRecord record = parser.nextRecord();
        assertEquals("a", record.get(0));
        assertEquals("b", record.get(1));
        parser.close();
    }

    @Test
    public void testNullStringIsConvertedToNullValue() throws IOException {
        final CSVParser parser = CSVParser.parse("NULL,b\n", CSVFormat.DEFAULT.withNullString("NULL"));
        final CSVRecord record = parser.nextRecord();
        assertNull(record.get(0));
        assertEquals("b", record.get(1));
        parser.close();
    }

    @Test
    public void testGetFirstEndOfLine() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\r\nc,d\n", CSVFormat.DEFAULT);
        parser.getRecords();
        assertEquals("\r\n", parser.getFirstEndOfLine());
        parser.close();
    }

    @Test
    public void testLastRecordWithoutTrailingNewlineIsStillParsed() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b", CSVFormat.DEFAULT);
        final CSVRecord record = parser.nextRecord();
        assertEquals("a", record.get(0));
        assertEquals("b", record.get(1));
        assertNull(parser.nextRecord());
        parser.close();
    }
}
