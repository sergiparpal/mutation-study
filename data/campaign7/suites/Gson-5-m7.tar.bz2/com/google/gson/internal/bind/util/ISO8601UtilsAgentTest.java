package com.google.gson.internal.bind.util;

import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

import junit.framework.TestCase;

public class ISO8601UtilsAgentTest extends TestCase {

  private static Date utcDate(int year, int month, int day, int hour, int minute, int second, int millis) {
    Calendar calendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
    calendar.clear();
    calendar.set(year, month - 1, day, hour, minute, second);
    calendar.set(Calendar.MILLISECOND, millis);
    return calendar.getTime();
  }

  public void testFormatDefaultNoMillis() {
    Date date = utcDate(2018, 6, 25, 10, 30, 15, 123);
    String formatted = ISO8601Utils.format(date);
    assertEquals("2018-06-25T10:30:15Z", formatted);
  }

  public void testFormatWithMillis() {
    Date date = utcDate(2018, 6, 25, 10, 30, 15, 123);
    String formatted = ISO8601Utils.format(date, true);
    assertEquals("2018-06-25T10:30:15.123Z", formatted);
  }

  public void testFormatWithNonUtcTimeZone() {
    Date date = utcDate(2018, 6, 25, 10, 30, 15, 0);
    TimeZone plusFive = TimeZone.getTimeZone("GMT+05:00");
    String formatted = ISO8601Utils.format(date, false, plusFive);
    assertEquals("2018-06-25T15:30:15+05:00", formatted);
  }

  public void testFormatWithNegativeOffsetTimeZone() {
    Date date = utcDate(2018, 6, 25, 10, 30, 15, 0);
    TimeZone minusFive = TimeZone.getTimeZone("GMT-05:00");
    String formatted = ISO8601Utils.format(date, false, minusFive);
    assertEquals("2018-06-25T05:30:15-05:00", formatted);
  }

  public void testFormatPadsSingleDigitFields() {
    Date date = utcDate(5, 1, 2, 3, 4, 5, 6);
    String formatted = ISO8601Utils.format(date, true);
    assertEquals("0005-01-02T03:04:05.006Z", formatted);
  }

  public void testParseDateOnly() throws ParseException {
    ParsePosition pos = new ParsePosition(0);
    Date parsed = ISO8601Utils.parse("2018-06-25", pos);
    Calendar calendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
    calendar.setTime(parsed);
    assertEquals(2018, calendar.get(Calendar.YEAR));
    assertEquals(Calendar.JUNE, calendar.get(Calendar.MONTH));
    assertEquals(25, calendar.get(Calendar.DAY_OF_MONTH));
    assertEquals(10, pos.getIndex());
  }

  public void testParseDateTimeWithZ() throws ParseException {
    ParsePosition pos = new ParsePosition(0);
    Date parsed = ISO8601Utils.parse("2018-06-25T10:30:15Z", pos);
    Calendar calendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
    calendar.setTime(parsed);
    assertEquals(2018, calendar.get(Calendar.YEAR));
    assertEquals(Calendar.JUNE, calendar.get(Calendar.MONTH));
    assertEquals(25, calendar.get(Calendar.DAY_OF_MONTH));
    assertEquals(10, calendar.get(Calendar.HOUR_OF_DAY));
    assertEquals(30, calendar.get(Calendar.MINUTE));
    assertEquals(15, calendar.get(Calendar.SECOND));
    assertEquals(0, calendar.get(Calendar.MILLISECOND));
    assertEquals("2018-06-25T10:30:15Z".length(), pos.getIndex());
  }

  public void testParseDateTimeWithMillis() throws ParseException {
    ParsePosition pos = new ParsePosition(0);
    Date parsed = ISO8601Utils.parse("2018-06-25T10:30:15.123Z", pos);
    Calendar calendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
    calendar.setTime(parsed);
    assertEquals(123, calendar.get(Calendar.MILLISECOND));
  }

  public void testParseDateTimeWithSingleDigitMillisFraction() throws ParseException {
    ParsePosition pos = new ParsePosition(0);
    Date parsed = ISO8601Utils.parse("2018-06-25T10:30:15.1Z", pos);
    Calendar calendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
    calendar.setTime(parsed);
    assertEquals(100, calendar.get(Calendar.MILLISECOND));
  }

  public void testParseDateTimeWithTwoDigitMillisFraction() throws ParseException {
    ParsePosition pos = new ParsePosition(0);
    Date parsed = ISO8601Utils.parse("2018-06-25T10:30:15.12Z", pos);
    Calendar calendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
    calendar.setTime(parsed);
    assertEquals(120, calendar.get(Calendar.MILLISECOND));
  }

  public void testParseDateTimeWithTimeZoneOffsetColon() throws ParseException {
    ParsePosition pos = new ParsePosition(0);
    Date parsed = ISO8601Utils.parse("2018-06-25T10:30:15+02:00", pos);
    Calendar calendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
    calendar.setTime(parsed);
    assertEquals(8, calendar.get(Calendar.HOUR_OF_DAY));
    assertEquals(30, calendar.get(Calendar.MINUTE));
  }

  public void testParseDateTimeWithTimeZoneOffsetNoColon() throws ParseException {
    ParsePosition pos = new ParsePosition(0);
    Date parsed = ISO8601Utils.parse("2018-06-25T10:30:15+0200", pos);
    Calendar calendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
    calendar.setTime(parsed);
    assertEquals(8, calendar.get(Calendar.HOUR_OF_DAY));
    assertEquals(30, calendar.get(Calendar.MINUTE));
  }

  public void testParseDateTimeWithTimeZoneOffsetHourOnly() throws ParseException {
    ParsePosition pos = new ParsePosition(0);
    Date parsed = ISO8601Utils.parse("2018-06-25T10:30:15+02", pos);
    Calendar calendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
    calendar.setTime(parsed);
    assertEquals(8, calendar.get(Calendar.HOUR_OF_DAY));
    assertEquals(30, calendar.get(Calendar.MINUTE));
  }

  public void testParseDateTimeWithoutSeconds() throws ParseException {
    ParsePosition pos = new ParsePosition(0);
    Date parsed = ISO8601Utils.parse("2018-06-25T10:30Z", pos);
    Calendar calendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
    calendar.setTime(parsed);
    assertEquals(10, calendar.get(Calendar.HOUR_OF_DAY));
    assertEquals(30, calendar.get(Calendar.MINUTE));
    assertEquals(0, calendar.get(Calendar.SECOND));
  }

  public void testParseLeapSecondIsTruncatedTo59() throws ParseException {
    ParsePosition pos = new ParsePosition(0);
    Date parsed = ISO8601Utils.parse("2018-06-25T10:30:60Z", pos);
    Calendar calendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
    calendar.setTime(parsed);
    assertEquals(59, calendar.get(Calendar.SECOND));
  }

  public void testParseFromNonZeroStartPosition() throws ParseException {
    ParsePosition pos = new ParsePosition(7);
    Date parsed = ISO8601Utils.parse("prefix-2018-06-25T10:30:15Z", pos);
    Calendar calendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
    calendar.setTime(parsed);
    assertEquals(2018, calendar.get(Calendar.YEAR));
    assertEquals("prefix-2018-06-25T10:30:15Z".length(), pos.getIndex());
  }

  public void testRoundTripFormatThenParse() throws ParseException {
    Date original = utcDate(2021, 11, 3, 23, 59, 59, 999);
    String formatted = ISO8601Utils.format(original, true);
    ParsePosition pos = new ParsePosition(0);
    Date parsed = ISO8601Utils.parse(formatted, pos);
    assertEquals(original, parsed);
  }

  public void testParseMissingTimeZoneIndicatorThrows() {
    ParsePosition pos = new ParsePosition(0);
    try {
      ISO8601Utils.parse("2018-06-25T10:30:15", pos);
      fail("Expected ParseException");
    } catch (ParseException expected) {
      assertTrue(expected.getMessage().contains("No time zone indicator"));
    }
  }

  public void testParseInvalidTimeZoneIndicatorThrows() {
    ParsePosition pos = new ParsePosition(0);
    try {
      ISO8601Utils.parse("2018-06-25T10:30:15X", pos);
      fail("Expected ParseException");
    } catch (ParseException expected) {
      assertTrue(expected.getMessage().contains("Invalid time zone indicator"));
    }
  }

  public void testParseNonNumericYearThrows() {
    ParsePosition pos = new ParsePosition(0);
    try {
      ISO8601Utils.parse("abcd-06-25", pos);
      fail("Expected ParseException");
    } catch (ParseException expected) {
      // expected: underlying NumberFormatException wrapped as ParseException
    }
  }

  public void testParseEmptyStringThrows() {
    ParsePosition pos = new ParsePosition(0);
    try {
      ISO8601Utils.parse("", pos);
      fail("Expected ParseException");
    } catch (ParseException expected) {
      // expected
    }
  }

  public void testParseTruncatedStringThrows() {
    ParsePosition pos = new ParsePosition(0);
    try {
      ISO8601Utils.parse("2018-06", pos);
      fail("Expected ParseException");
    } catch (ParseException expected) {
      // expected
    }
  }

  public void testParseMismatchingTimeZoneThrows() {
    ParsePosition pos = new ParsePosition(0);
    try {
      ISO8601Utils.parse("2018-06-25T10:30:15+25:61", pos);
      fail("Expected ParseException");
    } catch (ParseException expected) {
      // expected: invalid offset resolves to a mismatching time zone id
    }
  }

  public void testFormatYearOneIsPaddedToFourDigits() {
    Date date = utcDate(1, 1, 1, 0, 0, 0, 0);
    String formatted = ISO8601Utils.format(date);
    assertEquals("0001-01-01T00:00:00Z", formatted);
  }
}
