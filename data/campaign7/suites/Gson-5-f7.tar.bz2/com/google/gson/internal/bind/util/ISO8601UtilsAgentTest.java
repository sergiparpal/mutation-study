/*
 * Copyright (C) 2008 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.gson.internal.bind.util;

import junit.framework.TestCase;

import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

/**
 * Self-contained unit tests for {@link ISO8601Utils}.
 */
public class ISO8601UtilsAgentTest extends TestCase {

  private static final TimeZone UTC = TimeZone.getTimeZone("UTC");

  private static Date utcDate(int year, int month, int day, int hour, int minute, int second, int millis) {
    Calendar calendar = new GregorianCalendar(UTC);
    calendar.clear();
    calendar.set(year, month - 1, day, hour, minute, second);
    calendar.set(Calendar.MILLISECOND, millis);
    return calendar.getTime();
  }

  /* ---------------------------- format() ---------------------------- */

  public void testFormatDefaultNoMillis() {
    Date date = utcDate(2014, 3, 10, 13, 14, 15, 123);
    String formatted = ISO8601Utils.format(date);
    // default format has no millis and uses UTC, so trailing 'Z'
    assertEquals("2014-03-10T13:14:15Z", formatted);
  }

  public void testFormatWithMillis() {
    Date date = utcDate(2014, 3, 10, 13, 14, 15, 123);
    String formatted = ISO8601Utils.format(date, true);
    assertEquals("2014-03-10T13:14:15.123Z", formatted);
  }

  public void testFormatZeroPadsSmallMillis() {
    Date date = utcDate(2014, 3, 10, 13, 14, 15, 5);
    String formatted = ISO8601Utils.format(date, true);
    assertEquals("2014-03-10T13:14:15.005Z", formatted);
  }

  public void testFormatZeroPadsSingleDigitFields() {
    Date date = utcDate(2014, 1, 2, 3, 4, 5, 0);
    String formatted = ISO8601Utils.format(date, false);
    assertEquals("2014-01-02T03:04:05Z", formatted);
  }

  public void testFormatWithPositiveOffsetTimezone() {
    Date date = utcDate(2014, 3, 10, 13, 14, 15, 0);
    TimeZone plusTwo = TimeZone.getTimeZone("GMT+02:00");
    String formatted = ISO8601Utils.format(date, false, plusTwo);
    assertEquals("2014-03-10T15:14:15+02:00", formatted);
  }

  public void testFormatWithNegativeOffsetTimezone() {
    Date date = utcDate(2014, 3, 10, 13, 14, 15, 0);
    TimeZone minusEight = TimeZone.getTimeZone("GMT-08:00");
    String formatted = ISO8601Utils.format(date, false, minusEight);
    assertEquals("2014-03-10T05:14:15-08:00", formatted);
  }

  public void testFormatWithHalfHourOffsetTimezone() {
    Date date = utcDate(2014, 3, 10, 13, 14, 15, 0);
    TimeZone plusFiveThirty = TimeZone.getTimeZone("GMT+05:30");
    String formatted = ISO8601Utils.format(date, false, plusFiveThirty);
    assertEquals("2014-03-10T18:44:15+05:30", formatted);
  }

  /* ---------------------------- parse() basic ---------------------------- */

  public void testParseBasicWithSeconds() throws ParseException {
    ParsePosition pos = new ParsePosition(0);
    Date parsed = ISO8601Utils.parse("2014-03-10T13:14:15Z", pos);
    assertEquals(utcDate(2014, 3, 10, 13, 14, 15, 0), parsed);
    assertEquals("2014-03-10T13:14:15Z".length(), pos.getIndex());
  }

  public void testParseWithMillis() throws ParseException {
    ParsePosition pos = new ParsePosition(0);
    Date parsed = ISO8601Utils.parse("2014-03-10T13:14:15.123Z", pos);
    assertEquals(utcDate(2014, 3, 10, 13, 14, 15, 123), parsed);
  }

  public void testParseWithoutSeconds() throws ParseException {
    ParsePosition pos = new ParsePosition(0);
    Date parsed = ISO8601Utils.parse("2014-03-10T13:14Z", pos);
    assertEquals(utcDate(2014, 3, 10, 13, 14, 0, 0), parsed);
  }

  public void testParseCompactFormatNoSeparators() throws ParseException {
    ParsePosition pos = new ParsePosition(0);
    Date parsed = ISO8601Utils.parse("20140310T131415Z", pos);
    assertEquals(utcDate(2014, 3, 10, 13, 14, 15, 0), parsed);
    assertEquals("20140310T131415Z".length(), pos.getIndex());
  }

  public void testParseDateOnlyUsesDefaultTimeZone() throws ParseException {
    ParsePosition pos = new ParsePosition(0);
    Date parsed = ISO8601Utils.parse("2014-03-10", pos);

    Calendar expectedCal = new GregorianCalendar(2014, Calendar.MARCH, 10);
    assertEquals(expectedCal.getTime(), parsed);
    assertEquals("2014-03-10".length(), pos.getIndex());
  }

  public void testParsePositiveTimezoneOffsetWithColon() throws ParseException {
    ParsePosition pos = new ParsePosition(0);
    Date parsed = ISO8601Utils.parse("2014-03-10T15:14:15+02:00", pos);
    assertEquals(utcDate(2014, 3, 10, 13, 14, 15, 0), parsed);
  }

  public void testParseNegativeTimezoneOffsetWithoutColon() throws ParseException {
    ParsePosition pos = new ParsePosition(0);
    Date parsed = ISO8601Utils.parse("2014-03-10T05:14:15-0800", pos);
    assertEquals(utcDate(2014, 3, 10, 13, 14, 15, 0), parsed);
  }

  public void testParsePlusZeroWithColonIsUtc() throws ParseException {
    ParsePosition pos = new ParsePosition(0);
    Date parsed = ISO8601Utils.parse("2014-03-10T13:14:15+00:00", pos);
    assertEquals(utcDate(2014, 3, 10, 13, 14, 15, 0), parsed);
  }

  public void testParsePlusZeroWithoutColonIsUtc() throws ParseException {
    ParsePosition pos = new ParsePosition(0);
    Date parsed = ISO8601Utils.parse("2014-03-10T13:14:15+0000", pos);
    assertEquals(utcDate(2014, 3, 10, 13, 14, 15, 0), parsed);
  }

  public void testParseStartsFromGivenPosition() throws ParseException {
    String junkPrefix = "garbage-";
    ParsePosition pos = new ParsePosition(junkPrefix.length());
    Date parsed = ISO8601Utils.parse(junkPrefix + "2014-03-10T13:14:15Z", pos);
    assertEquals(utcDate(2014, 3, 10, 13, 14, 15, 0), parsed);
    assertEquals(junkPrefix.length() + "2014-03-10T13:14:15Z".length(), pos.getIndex());
  }

  public void testParseLeavesTrailingCharactersUnconsumed() throws ParseException {
    ParsePosition pos = new ParsePosition(0);
    String input = "2014-03-10T13:14:15Z-trailing-junk";
    Date parsed = ISO8601Utils.parse(input, pos);
    assertEquals(utcDate(2014, 3, 10, 13, 14, 15, 0), parsed);
    assertEquals("2014-03-10T13:14:15Z".length(), pos.getIndex());
  }

  /* ---------------------------- fractional seconds ---------------------------- */

  public void testParseFractionalSecondsOneDigitScaledToHundreds() throws ParseException {
    ParsePosition pos = new ParsePosition(0);
    Date parsed = ISO8601Utils.parse("2014-03-10T13:14:15.1Z", pos);
    assertEquals(utcDate(2014, 3, 10, 13, 14, 15, 100), parsed);
  }

  public void testParseFractionalSecondsTwoDigitsScaledToTens() throws ParseException {
    ParsePosition pos = new ParsePosition(0);
    Date parsed = ISO8601Utils.parse("2014-03-10T13:14:15.12Z", pos);
    assertEquals(utcDate(2014, 3, 10, 13, 14, 15, 120), parsed);
  }

  public void testParseFractionalSecondsThreeDigitsExact() throws ParseException {
    ParsePosition pos = new ParsePosition(0);
    Date parsed = ISO8601Utils.parse("2014-03-10T13:14:15.123Z", pos);
    assertEquals(utcDate(2014, 3, 10, 13, 14, 15, 123), parsed);
  }

  public void testParseFractionalSecondsFourDigitsTruncatedToThree() throws ParseException {
    ParsePosition pos = new ParsePosition(0);
    Date parsed = ISO8601Utils.parse("2014-03-10T13:14:15.1234Z", pos);
    assertEquals(utcDate(2014, 3, 10, 13, 14, 15, 123), parsed);
    assertEquals("2014-03-10T13:14:15.1234Z".length(), pos.getIndex());
  }

  /* ---------------------------- leap second ---------------------------- */

  public void testParseLeapSecondTruncatedTo59() throws ParseException {
    ParsePosition pos = new ParsePosition(0);
    Date parsed = ISO8601Utils.parse("2014-01-01T23:59:60Z", pos);
    assertEquals(utcDate(2014, 1, 1, 23, 59, 59, 0), parsed);
  }

  /* ---------------------------- error cases ---------------------------- */

  public void testParseMissingTimeZoneThrows() {
    ParsePosition pos = new ParsePosition(0);
    try {
      ISO8601Utils.parse("2014-01-01T23:34", pos);
      fail("expected ParseException");
    } catch (ParseException expected) {
      assertTrue(expected.getMessage().indexOf("No time zone indicator") >= 0);
    }
  }

  public void testParseInvalidTimeZoneIndicatorThrows() {
    ParsePosition pos = new ParsePosition(0);
    try {
      ISO8601Utils.parse("2014-01-01T23:34:00X", pos);
      fail("expected ParseException");
    } catch (ParseException expected) {
      assertTrue(expected.getMessage().indexOf("Invalid time zone indicator") >= 0);
    }
  }

  public void testParseTruncatedStringThrows() {
    ParsePosition pos = new ParsePosition(0);
    try {
      ISO8601Utils.parse("2014-01", pos);
      fail("expected ParseException");
    } catch (ParseException expected) {
      // expected: string too short to contain the day field
    }
  }

  public void testParseNonDigitInYearThrows() {
    ParsePosition pos = new ParsePosition(0);
    try {
      ISO8601Utils.parse("20XX-01-01T00:00:00Z", pos);
      fail("expected ParseException");
    } catch (ParseException expected) {
      assertTrue(expected.getMessage().indexOf("Invalid number") >= 0);
    }
  }

  public void testParseFailureDoesNotAdvancePosition() {
    ParsePosition pos = new ParsePosition(0);
    try {
      ISO8601Utils.parse("2014-01-01T23:34", pos);
      fail("expected ParseException");
    } catch (ParseException expected) {
      // on failure, the position should remain where parsing started
      assertEquals(0, pos.getIndex());
    }
  }

  public void testParseEmptyStringThrows() {
    ParsePosition pos = new ParsePosition(0);
    try {
      ISO8601Utils.parse("", pos);
      fail("expected ParseException");
    } catch (ParseException expected) {
      // expected
    }
  }

  /* ---------------------------- round trip ---------------------------- */

  public void testRoundTripFormatThenParse() throws ParseException {
    Date original = utcDate(2014, 3, 10, 13, 14, 15, 0);
    String formatted = ISO8601Utils.format(original);
    ParsePosition pos = new ParsePosition(0);
    Date parsed = ISO8601Utils.parse(formatted, pos);
    assertEquals(original, parsed);
  }

  public void testRoundTripFormatThenParseWithMillis() throws ParseException {
    Date original = utcDate(2014, 3, 10, 13, 14, 15, 123);
    String formatted = ISO8601Utils.format(original, true);
    ParsePosition pos = new ParsePosition(0);
    Date parsed = ISO8601Utils.parse(formatted, pos);
    assertEquals(original, parsed);
  }
}
