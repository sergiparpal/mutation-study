/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.NoSuchElementException;

import junit.framework.TestCase;

public class DateUtilsAgentTest extends TestCase {

    private Calendar newCalendar(int year, int month, int day, int hour, int minute, int second, int millis) {
        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(year, month, day, hour, minute, second);
        cal.set(Calendar.MILLISECOND, millis);
        return cal;
    }

    // isSameDay(Date, Date)

    public void testIsSameDayDateTrue() {
        Date d1 = newCalendar(2005, Calendar.JANUARY, 1, 1, 0, 0, 0).getTime();
        Date d2 = newCalendar(2005, Calendar.JANUARY, 1, 23, 59, 59, 999).getTime();
        assertTrue(DateUtils.isSameDay(d1, d2));
    }

    public void testIsSameDayDateFalse() {
        Date d1 = newCalendar(2005, Calendar.JANUARY, 1, 23, 59, 59, 999).getTime();
        Date d2 = newCalendar(2005, Calendar.JANUARY, 2, 0, 0, 0, 0).getTime();
        assertFalse(DateUtils.isSameDay(d1, d2));
    }

    public void testIsSameDayDateNull() {
        Date d1 = new Date();
        try {
            DateUtils.isSameDay(null, d1);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
        try {
            DateUtils.isSameDay(d1, null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    // isSameDay(Calendar, Calendar)

    public void testIsSameDayCalendarTrue() {
        Calendar c1 = newCalendar(2005, Calendar.MARCH, 28, 1, 0, 0, 0);
        Calendar c2 = newCalendar(2005, Calendar.MARCH, 28, 20, 0, 0, 0);
        assertTrue(DateUtils.isSameDay(c1, c2));
    }

    public void testIsSameDayCalendarFalseDifferentYear() {
        Calendar c1 = newCalendar(2005, Calendar.MARCH, 28, 1, 0, 0, 0);
        Calendar c2 = newCalendar(2006, Calendar.MARCH, 28, 1, 0, 0, 0);
        assertFalse(DateUtils.isSameDay(c1, c2));
    }

    public void testIsSameDayCalendarNull() {
        Calendar c1 = Calendar.getInstance();
        try {
            DateUtils.isSameDay((Calendar) null, c1);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    // isSameInstant(Date, Date)

    public void testIsSameInstantDate() {
        Date d1 = new Date(1000L);
        Date d2 = new Date(1000L);
        Date d3 = new Date(1001L);
        assertTrue(DateUtils.isSameInstant(d1, d2));
        assertFalse(DateUtils.isSameInstant(d1, d3));
    }

    public void testIsSameInstantDateNull() {
        try {
            DateUtils.isSameInstant(null, new Date());
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    // isSameInstant(Calendar, Calendar)

    public void testIsSameInstantCalendar() {
        Calendar c1 = Calendar.getInstance();
        c1.setTimeInMillis(5000L);
        Calendar c2 = Calendar.getInstance();
        c2.setTimeInMillis(5000L);
        // Different fields set, but same instant.
        c2.set(Calendar.YEAR, 1999);
        c2.setTimeInMillis(5000L);
        assertTrue(DateUtils.isSameInstant(c1, c2));
    }

    public void testIsSameInstantCalendarNull() {
        try {
            DateUtils.isSameInstant((Calendar) null, Calendar.getInstance());
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    // isSameLocalTime(Calendar, Calendar)

    public void testIsSameLocalTimeTrue() {
        Calendar c1 = newCalendar(2005, Calendar.MARCH, 28, 10, 20, 30, 10);
        Calendar c2 = newCalendar(2005, Calendar.MARCH, 28, 10, 20, 30, 10);
        assertTrue(DateUtils.isSameLocalTime(c1, c2));
    }

    public void testIsSameLocalTimeFalseDifferentClass() {
        Calendar c1 = newCalendar(2005, Calendar.MARCH, 28, 10, 20, 30, 10);
        Calendar c2 = new java.util.GregorianCalendar() {
            // anonymous subclass => different getClass()
        };
        c2.setTime(c1.getTime());
        assertFalse(DateUtils.isSameLocalTime(c1, c2));
    }

    public void testIsSameLocalTimeNull() {
        try {
            DateUtils.isSameLocalTime(null, Calendar.getInstance());
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    // parseDate / parseDateStrictly

    public void testParseDateSuccess() throws Exception {
        Date date = DateUtils.parseDate("2005-03-28", new String[] { "yyyy-MM-dd" });
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        assertEquals(2005, cal.get(Calendar.YEAR));
        assertEquals(Calendar.MARCH, cal.get(Calendar.MONTH));
        assertEquals(28, cal.get(Calendar.DAY_OF_MONTH));
    }

    public void testParseDateNoPatternMatches() {
        try {
            DateUtils.parseDate("2005-03-28", new String[] { "MM/dd/yyyy" });
            fail("Expected ParseException");
        } catch (ParseException e) {
            // expected
        }
    }

    public void testParseDateNullString() {
        try {
            DateUtils.parseDate(null, new String[] { "yyyy-MM-dd" });
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        } catch (ParseException e) {
            fail("Expected IllegalArgumentException, got ParseException");
        }
    }

    public void testParseDateNullPatterns() {
        try {
            DateUtils.parseDate("2005-03-28", (String[]) null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        } catch (ParseException e) {
            fail("Expected IllegalArgumentException, got ParseException");
        }
    }

    public void testParseDateStrictlyLenientFallback() throws Exception {
        // "February 942, 1996"-like day overflow is allowed leniently but not strictly.
        Date lenient = DateUtils.parseDate("20050230", new String[] { "yyyyMMdd" });
        Calendar cal = Calendar.getInstance();
        cal.setTime(lenient);
        // Leniently, Feb 30 2005 rolls over to March 2 2005.
        assertEquals(Calendar.MARCH, cal.get(Calendar.MONTH));
        assertEquals(2, cal.get(Calendar.DAY_OF_MONTH));

        try {
            DateUtils.parseDateStrictly("20050230", new String[] { "yyyyMMdd" });
            fail("Expected ParseException for strict parse of invalid date");
        } catch (ParseException e) {
            // expected
        }
    }

    // addYears/addMonths/addWeeks/addDays/addHours/addMinutes/addSeconds/addMilliseconds

    public void testAddYears() {
        Date date = newCalendar(2005, Calendar.MARCH, 28, 0, 0, 0, 0).getTime();
        Date result = DateUtils.addYears(date, 2);
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(2007, cal.get(Calendar.YEAR));
        // Original unchanged.
        Calendar orig = Calendar.getInstance();
        orig.setTime(date);
        assertEquals(2005, orig.get(Calendar.YEAR));
    }

    public void testAddMonthsNegative() {
        Date date = newCalendar(2005, Calendar.MARCH, 28, 0, 0, 0, 0).getTime();
        Date result = DateUtils.addMonths(date, -4);
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(2004, cal.get(Calendar.YEAR));
        assertEquals(Calendar.NOVEMBER, cal.get(Calendar.MONTH));
    }

    public void testAddWeeks() {
        Date date = newCalendar(2005, Calendar.JANUARY, 10, 0, 0, 0, 0).getTime();
        Date result = DateUtils.addWeeks(date, 1);
        assertEquals(7 * DateUtils.MILLIS_PER_DAY, result.getTime() - date.getTime());
    }

    public void testAddDaysNullDate() {
        try {
            DateUtils.addDays(null, 1);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testAddHoursZero() {
        Date date = newCalendar(2005, Calendar.MARCH, 28, 10, 0, 0, 0).getTime();
        Date result = DateUtils.addHours(date, 0);
        assertEquals(date.getTime(), result.getTime());
        assertNotSame(date, result);
    }

    public void testAddMinutes() {
        Date date = new Date(0L);
        Date result = DateUtils.addMinutes(date, 90);
        assertEquals(90 * DateUtils.MILLIS_PER_MINUTE, result.getTime());
    }

    public void testAddSeconds() {
        Date date = new Date(0L);
        Date result = DateUtils.addSeconds(date, -5);
        assertEquals(-5 * DateUtils.MILLIS_PER_SECOND, result.getTime());
    }

    public void testAddMilliseconds() {
        Date date = new Date(100L);
        Date result = DateUtils.addMilliseconds(date, 50);
        assertEquals(150L, result.getTime());
    }

    // setYears/setMonths/setDays/setHours/setMinutes/setSeconds/setMilliseconds

    public void testSetYears() {
        Date date = newCalendar(2005, Calendar.MARCH, 28, 10, 20, 30, 0).getTime();
        Date result = DateUtils.setYears(date, 2000);
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(2000, cal.get(Calendar.YEAR));
        assertEquals(Calendar.MARCH, cal.get(Calendar.MONTH));
        assertEquals(28, cal.get(Calendar.DAY_OF_MONTH));
    }

    public void testSetMonthsInvalidThrowsIllegalArgument() {
        Date date = newCalendar(2005, Calendar.MARCH, 28, 10, 20, 30, 0).getTime();
        try {
            // Non-lenient calendar: month 13 is invalid.
            DateUtils.setMonths(date, 13);
            fail("Expected IllegalArgumentException for invalid month");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testSetDaysNullDate() {
        try {
            DateUtils.setDays(null, 1);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testSetHours() {
        Date date = newCalendar(2005, Calendar.MARCH, 28, 10, 20, 30, 0).getTime();
        Date result = DateUtils.setHours(date, 5);
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(5, cal.get(Calendar.HOUR_OF_DAY));
    }

    public void testSetMinutes() {
        Date date = newCalendar(2005, Calendar.MARCH, 28, 10, 20, 30, 0).getTime();
        Date result = DateUtils.setMinutes(date, 45);
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(45, cal.get(Calendar.MINUTE));
    }

    public void testSetSeconds() {
        Date date = newCalendar(2005, Calendar.MARCH, 28, 10, 20, 30, 0).getTime();
        Date result = DateUtils.setSeconds(date, 15);
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(15, cal.get(Calendar.SECOND));
    }

    public void testSetMilliseconds() {
        Date date = newCalendar(2005, Calendar.MARCH, 28, 10, 20, 30, 0).getTime();
        Date result = DateUtils.setMilliseconds(date, 123);
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(123, cal.get(Calendar.MILLISECOND));
    }

    // toCalendar

    public void testToCalendar() {
        Date date = newCalendar(2005, Calendar.MARCH, 28, 10, 20, 30, 0).getTime();
        Calendar cal = DateUtils.toCalendar(date);
        assertEquals(date, cal.getTime());
    }

    public void testToCalendarNullThrowsNPE() {
        try {
            DateUtils.toCalendar(null);
            fail("Expected NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
    }

    // round/truncate/ceiling Object overloads (ClassCastException and null handling)

    public void testRoundObjectDate() {
        Date date = newCalendar(2005, Calendar.MARCH, 28, 13, 45, 1, 231).getTime();
        Date result = DateUtils.round((Object) date, Calendar.HOUR_OF_DAY);
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(14, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, cal.get(Calendar.MINUTE));
    }

    public void testRoundObjectCalendar() {
        Calendar cal = newCalendar(2005, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date result = DateUtils.round((Object) cal, Calendar.HOUR_OF_DAY);
        Calendar resultCal = Calendar.getInstance();
        resultCal.setTime(result);
        assertEquals(14, resultCal.get(Calendar.HOUR_OF_DAY));
    }

    public void testRoundObjectInvalidType() {
        try {
            DateUtils.round("not a date", Calendar.HOUR_OF_DAY);
            fail("Expected ClassCastException");
        } catch (ClassCastException e) {
            // expected
        }
    }

    public void testRoundObjectNull() {
        try {
            DateUtils.round((Object) null, Calendar.HOUR_OF_DAY);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testTruncateObjectInvalidType() {
        try {
            DateUtils.truncate(Integer.valueOf(5), Calendar.HOUR_OF_DAY);
            fail("Expected ClassCastException");
        } catch (ClassCastException e) {
            // expected
        }
    }

    public void testCeilingObjectInvalidType() {
        try {
            DateUtils.ceiling(Integer.valueOf(5), Calendar.HOUR_OF_DAY);
            fail("Expected ClassCastException");
        } catch (ClassCastException e) {
            // expected
        }
    }

    public void testCeilingDate() {
        Date date = newCalendar(2002, Calendar.MARCH, 28, 13, 45, 1, 231).getTime();
        Date result = DateUtils.ceiling(date, Calendar.HOUR_OF_DAY);
        Calendar cal = Calendar.getInstance();
        cal.setTime(result);
        assertEquals(14, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, cal.get(Calendar.MINUTE));
        assertEquals(0, cal.get(Calendar.SECOND));
        assertEquals(0, cal.get(Calendar.MILLISECOND));
    }

    public void testCeilingNullDate() {
        try {
            DateUtils.ceiling((Date) null, Calendar.HOUR_OF_DAY);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testModifyUnsupportedFieldThrows() {
        Date date = newCalendar(2005, Calendar.MARCH, 28, 13, 45, 1, 231).getTime();
        try {
            DateUtils.truncate(date, Calendar.DAY_OF_WEEK);
            fail("Expected IllegalArgumentException for unsupported field");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testRoundArithmeticExceptionForHugeYear() {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.YEAR, 280000001);
        try {
            DateUtils.round(cal, Calendar.HOUR_OF_DAY);
            fail("Expected ArithmeticException");
        } catch (ArithmeticException e) {
            // expected
        }
    }

    // iterator

    public void testIteratorWeekSundayCount() {
        Date focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0).getTime();
        Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        int count = 0;
        Calendar first = null;
        Calendar last = null;
        while (it.hasNext()) {
            Calendar c = it.next();
            if (first == null) {
                first = c;
            }
            last = c;
            count++;
        }
        assertEquals(7, count);
        assertEquals(Calendar.SUNDAY, first.get(Calendar.DAY_OF_WEEK));
        assertEquals(Calendar.SATURDAY, last.get(Calendar.DAY_OF_WEEK));
    }

    public void testIteratorExhaustedThrowsNoSuchElement() {
        Date focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0).getTime();
        Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        while (it.hasNext()) {
            it.next();
        }
        try {
            it.next();
            fail("Expected NoSuchElementException");
        } catch (NoSuchElementException e) {
            // expected
        }
    }

    public void testIteratorRemoveUnsupported() {
        Date focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0).getTime();
        Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        try {
            it.remove();
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException e) {
            // expected
        }
    }

    public void testIteratorInvalidRangeStyle() {
        Date focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0).getTime();
        try {
            DateUtils.iterator(focus, -999);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testIteratorNullDate() {
        try {
            DateUtils.iterator((Date) null, DateUtils.RANGE_WEEK_SUNDAY);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testIteratorObjectInvalidType() {
        try {
            DateUtils.iterator("not a date", DateUtils.RANGE_WEEK_SUNDAY);
            fail("Expected ClassCastException");
        } catch (ClassCastException e) {
            // expected
        }
    }

    public void testIteratorMonthSundayContainsWholeMonth() {
        Date focus = newCalendar(2002, Calendar.JULY, 4, 0, 0, 0, 0).getTime();
        Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_MONTH_SUNDAY);
        boolean sawFirstOfMonth = false;
        boolean sawLastOfMonth = false;
        while (it.hasNext()) {
            Calendar c = it.next();
            if (c.get(Calendar.YEAR) == 2002 && c.get(Calendar.MONTH) == Calendar.JULY) {
                if (c.get(Calendar.DAY_OF_MONTH) == 1) {
                    sawFirstOfMonth = true;
                }
                if (c.get(Calendar.DAY_OF_MONTH) == 31) {
                    sawLastOfMonth = true;
                }
            }
        }
        assertTrue(sawFirstOfMonth);
        assertTrue(sawLastOfMonth);
    }

    // truncatedEquals / truncatedCompareTo

    public void testTruncatedEqualsDateTrue() {
        Date d1 = newCalendar(2005, Calendar.MARCH, 28, 10, 20, 30, 0).getTime();
        Date d2 = newCalendar(2005, Calendar.MARCH, 28, 10, 45, 59, 999).getTime();
        assertTrue(DateUtils.truncatedEquals(d1, d2, Calendar.HOUR_OF_DAY));
    }

    public void testTruncatedEqualsDateFalse() {
        Date d1 = newCalendar(2005, Calendar.MARCH, 28, 10, 20, 30, 0).getTime();
        Date d2 = newCalendar(2005, Calendar.MARCH, 28, 11, 0, 0, 0).getTime();
        assertFalse(DateUtils.truncatedEquals(d1, d2, Calendar.HOUR_OF_DAY));
    }

    public void testTruncatedCompareToDate() {
        Date earlier = newCalendar(2005, Calendar.MARCH, 28, 10, 0, 0, 0).getTime();
        Date later = newCalendar(2005, Calendar.MARCH, 29, 10, 0, 0, 0).getTime();
        assertTrue(DateUtils.truncatedCompareTo(earlier, later, Calendar.DATE) < 0);
        assertTrue(DateUtils.truncatedCompareTo(later, earlier, Calendar.DATE) > 0);
        assertEquals(0, DateUtils.truncatedCompareTo(earlier, earlier, Calendar.DATE));
    }

    public void testTruncatedEqualsCalendar() {
        Calendar c1 = newCalendar(2005, Calendar.MARCH, 28, 10, 20, 30, 0);
        Calendar c2 = newCalendar(2005, Calendar.MARCH, 28, 10, 45, 59, 999);
        assertTrue(DateUtils.truncatedEquals(c1, c2, Calendar.HOUR_OF_DAY));
    }

    public void testTruncatedCompareToCalendar() {
        Calendar earlier = newCalendar(2005, Calendar.MARCH, 28, 10, 0, 0, 0);
        Calendar later = newCalendar(2005, Calendar.MARCH, 29, 10, 0, 0, 0);
        assertTrue(DateUtils.truncatedCompareTo(earlier, later, Calendar.DATE) < 0);
    }

    // getFragment error paths not already covered by DateUtilsFragmentTest

    public void testGetFragmentInMillisecondsUnsupportedFragment() {
        Date date = newCalendar(2005, Calendar.MARCH, 28, 10, 20, 30, 0).getTime();
        try {
            DateUtils.getFragmentInMilliseconds(date, Calendar.DAY_OF_WEEK);
            fail("Expected IllegalArgumentException for unsupported fragment");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    // Constants sanity

    public void testMillisConstants() {
        assertEquals(1000L, DateUtils.MILLIS_PER_SECOND);
        assertEquals(60000L, DateUtils.MILLIS_PER_MINUTE);
        assertEquals(3600000L, DateUtils.MILLIS_PER_HOUR);
        assertEquals(86400000L, DateUtils.MILLIS_PER_DAY);
    }
}
