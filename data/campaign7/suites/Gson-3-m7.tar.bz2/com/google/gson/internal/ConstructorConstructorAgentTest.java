/*
 * Copyright (C) 2024 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.gson.internal;

import java.lang.reflect.Type;
import java.util.Collections;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ConcurrentNavigableMap;

import junit.framework.TestCase;

import com.google.gson.InstanceCreator;
import com.google.gson.JsonIOException;
import com.google.gson.reflect.TypeToken;

public final class ConstructorConstructorAgentTest extends TestCase {

  private static ConstructorConstructor newConstructorConstructor() {
    return new ConstructorConstructor(Collections.<Type, InstanceCreator<?>>emptyMap());
  }

  // ---- fixtures ----

  /** Has an accessible public no-args constructor. */
  public static class PublicNoArgs {
    boolean constructed = true;
  }

  /** Has only a private no-args constructor. */
  public static class PrivateNoArgs {
    private PrivateNoArgs() {}
  }

  /** Has no no-args constructor at all, and does not implement Collection/Map. */
  public static class NoNoArgsConstructor {
    final int value;
    public NoNoArgsConstructor(int value) {
      this.value = value;
    }
  }

  /** No-args constructor that throws a checked-looking RuntimeException. */
  public static class ThrowingConstructor {
    public ThrowingConstructor() {
      throw new IllegalStateException("boom");
    }
  }

  enum Color { RED, GREEN, BLUE }

  private static class RecordingInstanceCreator implements InstanceCreator<Object> {
    Type seenType;
    @Override public Object createInstance(Type type) {
      this.seenType = type;
      return "created";
    }
  }

  // ---- InstanceCreator: exact type match ----

  public void testExactTypeInstanceCreatorIsUsed() {
    RecordingInstanceCreator creator = new RecordingInstanceCreator();
    Map<Type, InstanceCreator<?>> creators = new HashMap<Type, InstanceCreator<?>>();
    Type exactType = new TypeToken<List<String>>() {}.getType();
    creators.put(exactType, creator);
    ConstructorConstructor cc = new ConstructorConstructor(creators);

    ObjectConstructor<List<String>> objectConstructor =
        cc.get(new TypeToken<List<String>>() {});
    Object result = objectConstructor.construct();

    assertEquals("created", result);
    assertEquals(exactType, creator.seenType);
  }

  // ---- InstanceCreator: raw type fallback ----

  public void testRawTypeInstanceCreatorIsUsedWhenNoExactMatch() {
    RecordingInstanceCreator creator = new RecordingInstanceCreator();
    Map<Type, InstanceCreator<?>> creators = new HashMap<Type, InstanceCreator<?>>();
    creators.put(PublicNoArgs.class, creator);
    ConstructorConstructor cc = new ConstructorConstructor(creators);

    ObjectConstructor<PublicNoArgs> objectConstructor =
        cc.get(TypeToken.get(PublicNoArgs.class));
    Object result = objectConstructor.construct();

    assertEquals("created", result);
  }

  // ---- default no-args constructor ----

  public void testPublicNoArgsConstructorIsUsed() {
    ConstructorConstructor cc = newConstructorConstructor();
    ObjectConstructor<PublicNoArgs> objectConstructor = cc.get(TypeToken.get(PublicNoArgs.class));
    PublicNoArgs instance = objectConstructor.construct();
    assertNotNull(instance);
    assertTrue(instance.constructed);
  }

  public void testPrivateNoArgsConstructorIsMadeAccessible() {
    ConstructorConstructor cc = newConstructorConstructor();
    ObjectConstructor<PrivateNoArgs> objectConstructor = cc.get(TypeToken.get(PrivateNoArgs.class));
    PrivateNoArgs instance = objectConstructor.construct();
    assertNotNull(instance);
  }

  public void testConstructorThrowingExceptionIsWrapped() {
    ConstructorConstructor cc = newConstructorConstructor();
    ObjectConstructor<ThrowingConstructor> objectConstructor =
        cc.get(TypeToken.get(ThrowingConstructor.class));
    try {
      objectConstructor.construct();
      fail("Expected RuntimeException");
    } catch (RuntimeException expected) {
      assertTrue(expected.getCause() instanceof IllegalStateException);
    }
  }

  // ---- collections ----

  public void testPlainListUsesArrayList() {
    ConstructorConstructor cc = newConstructorConstructor();
    ObjectConstructor<List<String>> objectConstructor = cc.get(new TypeToken<List<String>>() {});
    List<String> list = objectConstructor.construct();
    assertTrue(list instanceof java.util.ArrayList);
    assertTrue(list.isEmpty());
    list.add("x");
    assertEquals(1, list.size());
  }

  public void testSortedSetUsesTreeSet() {
    ConstructorConstructor cc = newConstructorConstructor();
    ObjectConstructor<SortedSet<String>> objectConstructor =
        cc.get(new TypeToken<SortedSet<String>>() {});
    SortedSet<String> set = objectConstructor.construct();
    assertTrue(set instanceof java.util.TreeSet);
  }

  public void testPlainSetUsesLinkedHashSet() {
    ConstructorConstructor cc = newConstructorConstructor();
    ObjectConstructor<Set<String>> objectConstructor = cc.get(new TypeToken<Set<String>>() {});
    Set<String> set = objectConstructor.construct();
    assertTrue(set instanceof java.util.LinkedHashSet);
  }

  public void testQueueUsesLinkedList() {
    ConstructorConstructor cc = newConstructorConstructor();
    ObjectConstructor<Queue<String>> objectConstructor = cc.get(new TypeToken<Queue<String>>() {});
    Queue<String> queue = objectConstructor.construct();
    assertTrue(queue instanceof java.util.LinkedList);
  }

  public void testEnumSetWithParameterizedTypeCreatesEmptySet() {
    ConstructorConstructor cc = newConstructorConstructor();
    ObjectConstructor<EnumSet<Color>> objectConstructor =
        cc.get(new TypeToken<EnumSet<Color>>() {});
    EnumSet<Color> set = objectConstructor.construct();
    assertNotNull(set);
    assertTrue(set.isEmpty());
    set.add(Color.RED);
    assertTrue(set.contains(Color.RED));
  }

  @SuppressWarnings("rawtypes")
  public void testRawEnumSetTypeThrowsJsonIOException() {
    ConstructorConstructor cc = newConstructorConstructor();
    ObjectConstructor<EnumSet> objectConstructor = cc.get(TypeToken.get(EnumSet.class));
    try {
      objectConstructor.construct();
      fail("Expected JsonIOException for raw EnumSet type");
    } catch (JsonIOException expected) {
      assertTrue(expected.getMessage().contains("EnumSet"));
    }
  }

  // ---- maps ----

  public void testSortedMapUsesTreeMap() {
    ConstructorConstructor cc = newConstructorConstructor();
    ObjectConstructor<SortedMap<String, String>> objectConstructor =
        cc.get(new TypeToken<SortedMap<String, String>>() {});
    SortedMap<String, String> map = objectConstructor.construct();
    assertTrue(map instanceof java.util.TreeMap);
  }

  public void testConcurrentNavigableMapUsesConcurrentSkipListMap() {
    ConstructorConstructor cc = newConstructorConstructor();
    ObjectConstructor<ConcurrentNavigableMap<String, String>> objectConstructor =
        cc.get(new TypeToken<ConcurrentNavigableMap<String, String>>() {});
    ConcurrentNavigableMap<String, String> map = objectConstructor.construct();
    assertTrue(map instanceof java.util.concurrent.ConcurrentSkipListMap);
  }

  public void testConcurrentMapUsesConcurrentHashMap() {
    ConstructorConstructor cc = newConstructorConstructor();
    ObjectConstructor<ConcurrentMap<String, String>> objectConstructor =
        cc.get(new TypeToken<ConcurrentMap<String, String>>() {});
    ConcurrentMap<String, String> map = objectConstructor.construct();
    assertTrue(map instanceof java.util.concurrent.ConcurrentHashMap);
  }

  public void testStringKeyedMapUsesLinkedTreeMap() {
    ConstructorConstructor cc = newConstructorConstructor();
    ObjectConstructor<Map<String, String>> objectConstructor =
        cc.get(new TypeToken<Map<String, String>>() {});
    Map<String, String> map = objectConstructor.construct();
    assertTrue(map instanceof LinkedTreeMap);
  }

  public void testNonStringKeyedMapUsesLinkedHashMap() {
    ConstructorConstructor cc = newConstructorConstructor();
    ObjectConstructor<Map<Integer, String>> objectConstructor =
        cc.get(new TypeToken<Map<Integer, String>>() {});
    Map<Integer, String> map = objectConstructor.construct();
    assertTrue(map instanceof java.util.LinkedHashMap);
  }

  @SuppressWarnings("rawtypes")
  public void testRawMapTypeUsesLinkedTreeMap() {
    ConstructorConstructor cc = newConstructorConstructor();
    ObjectConstructor<Map> objectConstructor = cc.get(TypeToken.get(Map.class));
    Map map = objectConstructor.construct();
    assertTrue(map instanceof LinkedTreeMap);
  }

  // ---- unsafe allocator fallback ----

  public void testClassWithoutNoArgsConstructorUsesUnsafeAllocator() {
    ConstructorConstructor cc = newConstructorConstructor();
    ObjectConstructor<NoNoArgsConstructor> objectConstructor =
        cc.get(TypeToken.get(NoNoArgsConstructor.class));
    NoNoArgsConstructor instance = objectConstructor.construct();
    assertNotNull(instance);
    // Field is left at its default value since no constructor ran.
    assertEquals(0, instance.value);
  }

  // ---- toString ----

  public void testToStringReflectsInstanceCreatorsMap() {
    RecordingInstanceCreator creator = new RecordingInstanceCreator();
    Map<Type, InstanceCreator<?>> creators = new HashMap<Type, InstanceCreator<?>>();
    creators.put(PublicNoArgs.class, creator);
    ConstructorConstructor cc = new ConstructorConstructor(creators);
    assertEquals(creators.toString(), cc.toString());
  }
}
