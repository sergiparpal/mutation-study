/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.cli2.commandline;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import junit.framework.TestCase;

import org.apache.commons.cli2.Argument;
import org.apache.commons.cli2.Group;
import org.apache.commons.cli2.Option;
import org.apache.commons.cli2.builder.ArgumentBuilder;
import org.apache.commons.cli2.builder.DefaultOptionBuilder;
import org.apache.commons.cli2.builder.GroupBuilder;
import org.apache.commons.cli2.option.PropertyOption;

/**
 * Tests the implementation-specific behaviour of {@link WriteableCommandLineImpl},
 * beyond the generic {@link org.apache.commons.cli2.WriteableCommandLine} contract.
 */
public class WriteableCommandLineImplAgentTest extends TestCase {

    private Option optA;
    private Group root;
    private WriteableCommandLineImpl impl;

    public void setUp() {
        optA = new DefaultOptionBuilder().withShortName("a").withLongName("alpha").create();
        root = new GroupBuilder().withOption(optA).create();
        impl = new WriteableCommandLineImpl(root, new ArrayList());
    }

    private static List list(final Object[] values) {
        return new ArrayList(Arrays.asList(values));
    }

    public void testGetNormalisedReturnsSuppliedArguments() {
        final List args = list(new Object[] { "--alpha", "foo" });
        final WriteableCommandLineImpl cl = new WriteableCommandLineImpl(root, args);
        assertEquals(args, cl.getNormalised());
    }

    public void testGetNormalisedIsUnmodifiable() {
        final List args = list(new Object[] { "--alpha" });
        final WriteableCommandLineImpl cl = new WriteableCommandLineImpl(root, args);
        try {
            cl.getNormalised().add("extra");
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
    }

    public void testToStringQuotesArgumentsContainingSpaces() {
        final List args = list(new Object[] { "--alpha", "foo bar", "baz" });
        final WriteableCommandLineImpl cl = new WriteableCommandLineImpl(root, args);
        assertEquals("--alpha \"foo bar\" baz", cl.toString());
    }

    public void testToStringEmptyArguments() {
        final WriteableCommandLineImpl cl = new WriteableCommandLineImpl(root, new ArrayList());
        assertEquals("", cl.toString());
    }

    public void testGetOptionByTrigger() {
        impl.addOption(optA);
        assertSame(optA, impl.getOption("-a"));
        assertSame(optA, impl.getOption("--alpha"));
        assertNull(impl.getOption("--doesnotexist"));
    }

    public void testHasOptionByTriggerDelegatesToOptionLookup() {
        assertFalse(impl.hasOption("-a"));
        impl.addOption(optA);
        assertTrue(impl.hasOption("-a"));
        assertTrue(impl.hasOption("--alpha"));
    }

    public void testHasOptionByUnknownTriggerIsFalse() {
        assertFalse(impl.hasOption("--nosuchtrigger"));
    }

    public void testGetOptionsReflectsEachAddOptionCall() {
        impl.addOption(optA);
        impl.addOption(optA);
        assertEquals(2, impl.getOptionCount(optA));
        assertEquals(2, impl.getOptionCount("-a"));
    }

    public void testGetOptionsIsUnmodifiable() {
        try {
            impl.getOptions().add(optA);
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
    }

    public void testGetOptionCountForNullOptionIsZero() {
        assertEquals(0, impl.getOptionCount((Option) null));
    }

    public void testGetOptionCountForUnknownTriggerIsZero() {
        assertEquals(0, impl.getOptionCount("--nosuchtrigger"));
    }

    public void testAddOptionClimbsParentChainOnlyOnce() {
        final Option sub = new DefaultOptionBuilder().withShortName("c").create();
        final Group parentGroup = new GroupBuilder().withName("mygroup").withOption(sub).create();
        final WriteableCommandLineImpl cl = new WriteableCommandLineImpl(parentGroup, new ArrayList());

        cl.addOption(sub);
        cl.addOption(sub);

        assertEquals(2, cl.getOptionCount(sub));
        assertEquals(1, cl.getOptionCount(parentGroup));
        assertTrue(cl.hasOption(parentGroup));
    }

    public void testAddOptionFullyRegistersAncestorsForTriggerLookup() {
        final Option sub = new DefaultOptionBuilder().withShortName("c").create();
        final Group parentGroup = new GroupBuilder().withName("mygroup").withOption(sub).create();
        final WriteableCommandLineImpl cl = new WriteableCommandLineImpl(parentGroup, new ArrayList());

        cl.addOption(sub);

        // the ancestor is present...
        assertTrue(cl.hasOption(parentGroup));
        // ...and should therefore be resolvable by its own preferred name,
        // exactly as if addOption(parentGroup) had been called directly.
        assertSame(parentGroup, cl.getOption("mygroup"));
    }

    public void testAddValuePreservesInsertionOrder() {
        impl.addValue(optA, "v1");
        impl.addValue(optA, "v2");
        impl.addValue(optA, "v3");
        assertEquals(list(new Object[] { "v1", "v2", "v3" }), impl.getValues(optA));
    }

    public void testAddValueOnArgumentAlsoRegistersTrigger() {
        final Argument arg = new ArgumentBuilder().withName("target").create();
        impl.addValue(arg, "v1");
        assertEquals(1, impl.getOptionCount(arg));
    }

    public void testAddPropertyReplacesExistingValue() {
        impl.addProperty(optA, "key", "first");
        impl.addProperty(optA, "key", "second");
        assertEquals("second", impl.getProperty(optA, "key"));
    }

    public void testGetPropertyWithExplicitDefault() {
        impl.addProperty(optA, "key", "value");
        assertEquals("value", impl.getProperty(optA, "key", "fallback"));
        assertEquals("fallback", impl.getProperty(optA, "missing", "fallback"));
    }

    public void testGetPropertiesForOptionWithNoPropertiesIsEmptySet() {
        final Set properties = impl.getProperties(optA);
        assertNotNull(properties);
        assertTrue(properties.isEmpty());
    }

    public void testLooksLikeOptionWithNoPrefixesAlwaysFalse() {
        // a Group built solely from an Argument contributes no prefixes,
        // since prefixes are only collected from non-Argument options
        final Argument arg = new ArgumentBuilder().withName("target").create();
        final Group argOnlyRoot = new GroupBuilder().withOption(arg).create();
        final WriteableCommandLineImpl cl = new WriteableCommandLineImpl(argOnlyRoot, new ArrayList());

        assertTrue(argOnlyRoot.getPrefixes().isEmpty());
        assertFalse(cl.looksLikeOption("-anything"));
        assertFalse(cl.looksLikeOption("anything"));
    }

    public void testSetDefaultValuesWithNullRemovesPreviousDefault() {
        impl.setDefaultValues(optA, list(new Object[] { "d1" }));
        assertFalse(impl.getValues(optA).isEmpty());
        impl.setDefaultValues(optA, null);
        assertTrue(impl.getValues(optA).isEmpty());
    }

    public void testSetDefaultSwitchWithNullRemovesPreviousDefault() {
        impl.setDefaultSwitch(optA, Boolean.TRUE);
        assertEquals(Boolean.TRUE, impl.getSwitch(optA, null));
        impl.setDefaultSwitch(optA, null);
        assertNull(impl.getSwitch(optA, null));
    }
}
