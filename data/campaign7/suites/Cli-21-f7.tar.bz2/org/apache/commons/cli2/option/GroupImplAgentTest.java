/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.cli2.option;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;

import junit.framework.TestCase;

import org.apache.commons.cli2.Argument;
import org.apache.commons.cli2.DisplaySetting;
import org.apache.commons.cli2.Group;
import org.apache.commons.cli2.HelpLine;
import org.apache.commons.cli2.Option;
import org.apache.commons.cli2.OptionException;
import org.apache.commons.cli2.WriteableCommandLine;
import org.apache.commons.cli2.builder.ArgumentBuilder;
import org.apache.commons.cli2.builder.DefaultOptionBuilder;
import org.apache.commons.cli2.commandline.WriteableCommandLineImpl;

/**
 * Tests {@link GroupImpl} in isolation, using only production classes
 * (builders and other option implementations) to build fixtures.
 */
public class GroupImplAgentTest extends TestCase {

    private static List list(final Object[] values) {
        return new ArrayList(Arrays.asList(values));
    }

    private static WriteableCommandLine commandLine(final Option root, final List args) {
        return new WriteableCommandLineImpl(root, args);
    }

    public void testConstructorSeparatesArgumentsFromOptions() {
        final Option optHelp = new DefaultOptionBuilder().withShortName("h").create();
        final Argument target = new ArgumentBuilder().withName("target").create();

        final List options = list(new Object[] { optHelp, target });
        final GroupImpl group = new GroupImpl(options, "grp", "desc", 0, Integer.MAX_VALUE, false);

        assertEquals(1, group.getOptions().size());
        assertSame(optHelp, group.getOptions().get(0));
        assertEquals(1, group.getAnonymous().size());
        assertSame(target, group.getAnonymous().get(0));
    }

    public void testConstructorSetsParentOnChildOptions() {
        final Option optHelp = new DefaultOptionBuilder().withShortName("h").create();
        final List options = list(new Object[] { optHelp });
        final Group group = new GroupImpl(options, "grp", null, 0, Integer.MAX_VALUE, false);

        assertSame(group, optHelp.getParent());
    }

    public void testGetOptionsIsUnmodifiable() {
        final Option optHelp = new DefaultOptionBuilder().withShortName("h").create();
        final GroupImpl group = new GroupImpl(list(new Object[] { optHelp }), "grp", null, 0,
                Integer.MAX_VALUE, false);

        try {
            group.getOptions().add(optHelp);
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
    }

    public void testGetAnonymousIsUnmodifiable() {
        final Argument target = new ArgumentBuilder().withName("target").create();
        final GroupImpl group = new GroupImpl(list(new Object[] { target }), "grp", null, 0,
                Integer.MAX_VALUE, false);

        try {
            group.getAnonymous().add(target);
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
    }

    public void testGetTriggersReturnsAllChildOptionTriggersButNoArguments() {
        final Option optHelp = new DefaultOptionBuilder().withShortName("h").withLongName("help").create();
        final Option optVerbose = new DefaultOptionBuilder().withShortName("v").create();
        final Argument target = new ArgumentBuilder().withName("target").create();

        final Group group = new GroupImpl(list(new Object[] { optHelp, optVerbose, target }), "grp", null,
                0, Integer.MAX_VALUE, false);

        final Set triggers = group.getTriggers();
        assertEquals(3, triggers.size());
        assertTrue(triggers.contains("-h"));
        assertTrue(triggers.contains("--help"));
        assertTrue(triggers.contains("-v"));
        assertFalse(triggers.contains("target"));
    }

    public void testGetPrefixesIsUnionOfChildPrefixesExcludingArguments() {
        final Option optHelp = new DefaultOptionBuilder().withShortName("h").withLongName("help").create();
        final Argument target = new ArgumentBuilder().withName("target").create();

        final Group group = new GroupImpl(list(new Object[] { optHelp, target }), "grp", null, 0,
                Integer.MAX_VALUE, false);

        final Set prefixes = group.getPrefixes();
        assertEquals(2, prefixes.size());
        assertTrue(prefixes.contains("-"));
        assertTrue(prefixes.contains("--"));
    }

    public void testGetPrefixesEmptyWhenOnlyArgumentsPresent() {
        final Argument target = new ArgumentBuilder().withName("target").create();
        final Group group = new GroupImpl(list(new Object[] { target }), "grp", null, 0,
                Integer.MAX_VALUE, false);

        assertTrue(group.getPrefixes().isEmpty());
    }

    public void testCanProcessNullArgumentIsFalse() {
        final Option optHelp = new DefaultOptionBuilder().withShortName("h").create();
        final Group group = new GroupImpl(list(new Object[] { optHelp }), "grp", null, 0,
                Integer.MAX_VALUE, false);
        final WriteableCommandLine cl = commandLine(group, list(new Object[0]));

        assertFalse(group.canProcess(cl, (String) null));
    }

    public void testCanProcessKnownTriggerIsTrue() {
        final Option optHelp = new DefaultOptionBuilder().withShortName("h").create();
        final Group group = new GroupImpl(list(new Object[] { optHelp }), "grp", null, 0,
                Integer.MAX_VALUE, false);
        final WriteableCommandLine cl = commandLine(group, list(new Object[0]));

        assertTrue(group.canProcess(cl, "-h"));
    }

    public void testCanProcessUnknownOptionLikeTokenIsFalseEvenWithAnonymousPresent() {
        final Option optHelp = new DefaultOptionBuilder().withShortName("h").create();
        final Argument target = new ArgumentBuilder().withName("target").withMinimum(0).create();
        final Group group = new GroupImpl(list(new Object[] { optHelp, target }), "grp", null, 0,
                Integer.MAX_VALUE, false);
        final WriteableCommandLine cl = commandLine(group, list(new Object[0]));

        // "-x" looks like an option (matches the "-" prefix) but is not a
        // known trigger, so it must not be swallowed as an anonymous value
        assertFalse(group.canProcess(cl, "-x"));
    }

    public void testCanProcessUnknownPlainTokenIsTrueWhenAnonymousPresent() {
        final Argument target = new ArgumentBuilder().withName("target").withMinimum(0).create();
        final Group group = new GroupImpl(list(new Object[] { target }), "grp", null, 0,
                Integer.MAX_VALUE, false);
        final WriteableCommandLine cl = commandLine(group, list(new Object[0]));

        assertTrue(group.canProcess(cl, "somevalue"));
    }

    public void testCanProcessUnknownPlainTokenIsFalseWhenNoAnonymous() {
        final Option optHelp = new DefaultOptionBuilder().withShortName("h").create();
        final Group group = new GroupImpl(list(new Object[] { optHelp }), "grp", null, 0,
                Integer.MAX_VALUE, false);
        final WriteableCommandLine cl = commandLine(group, list(new Object[0]));

        assertFalse(group.canProcess(cl, "somevalue"));
    }

    public void testProcessStopsEntirelyAtFirstUnrecognisedToken() throws OptionException {
        final Option optHelp = new DefaultOptionBuilder().withShortName("h").create();
        final Option optVerbose = new DefaultOptionBuilder().withShortName("v").create();
        final Group group = new GroupImpl(list(new Object[] { optHelp, optVerbose }), "grp", null, 0,
                Integer.MAX_VALUE, false);

        final List args = list(new Object[] { "-h", "value", "-v" });
        final ListIterator iterator = args.listIterator();
        final WriteableCommandLine cl = commandLine(group, args);

        group.process(cl, iterator);

        assertTrue(cl.hasOption(optHelp));
        // processing must have stopped before consuming "-v", because
        // "value" could not be recognised and there were no anonymous
        // arguments able to absorb it
        assertFalse(cl.hasOption(optVerbose));
        assertTrue(iterator.hasNext());
        assertEquals("value", iterator.next());
    }

    public void testProcessConsumesAnonymousArguments() throws OptionException {
        final Argument target = new ArgumentBuilder().withName("target").withMinimum(0).create();
        final Group group = new GroupImpl(list(new Object[] { target }), "grp", null, 0,
                Integer.MAX_VALUE, false);

        final List args = list(new Object[] { "foo", "bar" });
        final ListIterator iterator = args.listIterator();
        final WriteableCommandLine cl = commandLine(group, args);

        group.process(cl, iterator);

        assertFalse(iterator.hasNext());
        assertEquals(list(new Object[] { "foo", "bar" }), cl.getValues(target));
    }

    public void testValidatePassesWhenWithinMinimumAndMaximum() throws OptionException {
        final Option optHelp = new DefaultOptionBuilder().withShortName("h").create();
        final Option optVerbose = new DefaultOptionBuilder().withShortName("v").create();
        final Group group = new GroupImpl(list(new Object[] { optHelp, optVerbose }), "grp", null, 0,
                1, false);
        final WriteableCommandLine cl = commandLine(group, list(new Object[0]));
        cl.addOption(optHelp);

        group.validate(cl);
    }

    public void testValidateThrowsWhenMaximumExceeded() {
        final Option optHelp = new DefaultOptionBuilder().withShortName("h").create();
        final Option optVerbose = new DefaultOptionBuilder().withShortName("v").create();
        final Group group = new GroupImpl(list(new Object[] { optHelp, optVerbose }), "grp", null, 0,
                1, false);
        final WriteableCommandLine cl = commandLine(group, list(new Object[0]));
        cl.addOption(optHelp);
        cl.addOption(optVerbose);

        try {
            group.validate(cl);
            fail("Expected OptionException: too many options present");
        } catch (OptionException e) {
            assertSame(group, e.getOption());
        }
    }

    public void testValidateThrowsWhenMinimumNotMet() {
        final Option optHelp = new DefaultOptionBuilder().withShortName("h").create();
        final Group group = new GroupImpl(list(new Object[] { optHelp }), "grp", null, 1,
                Integer.MAX_VALUE, false);
        final WriteableCommandLine cl = commandLine(group, list(new Object[0]));

        try {
            group.validate(cl);
            fail("Expected OptionException: missing option");
        } catch (OptionException e) {
            assertSame(group, e.getOption());
        }
    }

    public void testValidateWithZeroMinimumAndNoOptionsPasses() throws OptionException {
        final Option optHelp = new DefaultOptionBuilder().withShortName("h").create();
        final Group group = new GroupImpl(list(new Object[] { optHelp }), "grp", null, 0,
                Integer.MAX_VALUE, false);
        final WriteableCommandLine cl = commandLine(group, list(new Object[0]));

        group.validate(cl);
    }

    public void testValidateValidatesAnonymousArguments() {
        final Argument target = new ArgumentBuilder().withName("target").withMinimum(1).create();
        final Group group = new GroupImpl(list(new Object[] { target }), "grp", null, 0,
                Integer.MAX_VALUE, false);
        final WriteableCommandLine cl = commandLine(group, list(new Object[0]));

        try {
            group.validate(cl);
            fail("Expected OptionException: target argument requires at least one value");
        } catch (OptionException e) {
            assertSame(target, e.getOption());
        }
    }

    public void testIsRequiredRootGroupIgnoresRequiredFlagButHonoursMinimum() {
        final Group rootRequiredFlagTrueButMinimumZero =
            new GroupImpl(new ArrayList(), "grp", null, 0, Integer.MAX_VALUE, true);
        assertNull(rootRequiredFlagTrueButMinimumZero.getParent());
        assertFalse(rootRequiredFlagTrueButMinimumZero.isRequired());

        final Group rootRequiredFlagFalseButMinimumPositive =
            new GroupImpl(new ArrayList(), "grp", null, 3, Integer.MAX_VALUE, false);
        assertNull(rootRequiredFlagFalseButMinimumPositive.getParent());
        assertTrue(rootRequiredFlagFalseButMinimumPositive.isRequired());
    }

    public void testIsRequiredChildGroupNeedsBothRequiredFlagAndMinimum() {
        final Group child = new GroupImpl(new ArrayList(), "child", null, 5, Integer.MAX_VALUE, false);
        final List parentOptions = list(new Object[] { child });
        new GroupImpl(parentOptions, "parent", null, 0, Integer.MAX_VALUE, true);

        assertNotNull(child.getParent());
        assertFalse(child.isRequired());

        final Group child2 = new GroupImpl(new ArrayList(), "child2", null, 5, Integer.MAX_VALUE, true);
        final List parentOptions2 = list(new Object[] { child2 });
        new GroupImpl(parentOptions2, "parent2", null, 0, Integer.MAX_VALUE, true);

        assertNotNull(child2.getParent());
        assertTrue(child2.isRequired());
    }

    public void testFindOptionRecursesThroughChildGroups() {
        final Option innerOption = new DefaultOptionBuilder().withShortName("x").create();
        final Group innerGroup = new GroupImpl(list(new Object[] { innerOption }), null, null, 0,
                Integer.MAX_VALUE, false);
        final Option outerOption =
            new DefaultOptionBuilder().withLongName("outer").withChildren(innerGroup).create();

        final Group group = new GroupImpl(list(new Object[] { outerOption }), "grp", null, 0,
                Integer.MAX_VALUE, false);

        assertSame(outerOption, group.findOption("--outer"));
        assertSame(innerOption, group.findOption("-x"));
        assertNull(group.findOption("--nosuch"));
    }

    public void testFindOptionWithNullTriggerReturnsNull() {
        final Option optHelp = new DefaultOptionBuilder().withShortName("h").create();
        final Group group = new GroupImpl(list(new Object[] { optHelp }), "grp", null, 0,
                Integer.MAX_VALUE, false);

        assertNull(group.findOption(null));
    }

    public void testGetPreferredNameAndDescriptionMayBeNull() {
        final Group group = new GroupImpl(new ArrayList(), null, null, 0, Integer.MAX_VALUE, false);

        assertNull(group.getPreferredName());
        assertNull(group.getDescription());
    }

    public void testGetMinimumAndGetMaximum() {
        final Group group = new GroupImpl(new ArrayList(), "grp", null, 2, 7, false);

        assertEquals(2, group.getMinimum());
        assertEquals(7, group.getMaximum());
    }

    public void testAppendUsageNullNameIsAlwaysExpanded() {
        final Option optHelp = new DefaultOptionBuilder().withShortName("h").withRequired(true).create();
        final Group group = new GroupImpl(list(new Object[] { optHelp }), null, null, 0,
                Integer.MAX_VALUE, false);

        final StringBuffer buffer = new StringBuffer();
        final Set settings = new HashSet(DisplaySetting.ALL);
        settings.remove(DisplaySetting.DISPLAY_GROUP_EXPANDED);

        group.appendUsage(buffer, settings, null);

        assertEquals("[-h]", buffer.toString());
    }

    public void testAppendUsageWithCustomSeparator() {
        final Option optHelp = new DefaultOptionBuilder().withShortName("h").create();
        final Option optVerbose = new DefaultOptionBuilder().withShortName("v").create();
        final Group group = new GroupImpl(list(new Object[] { optHelp, optVerbose }), "grp", null, 1,
                Integer.MAX_VALUE, true);

        final StringBuffer buffer = new StringBuffer();
        final Set settings = new HashSet();
        settings.add(DisplaySetting.DISPLAY_GROUP_NAME);
        settings.add(DisplaySetting.DISPLAY_GROUP_EXPANDED);

        group.appendUsage(buffer, settings, null, ";");

        assertEquals("grp (-h;-v)", buffer.toString());
    }

    public void testHelpLinesIncludesGroupAndChildrenAtIncreasingDepth() {
        final Option optHelp = new DefaultOptionBuilder().withShortName("h").create();
        final Argument target = new ArgumentBuilder().withName("target").create();
        final Group group = new GroupImpl(list(new Object[] { optHelp, target }), "grp", null, 0,
                Integer.MAX_VALUE, false);

        final List lines = group.helpLines(2, DisplaySetting.ALL, null);
        final Iterator i = lines.iterator();

        final HelpLine line1 = (HelpLine) i.next();
        assertEquals(2, line1.getIndent());
        assertSame(group, line1.getOption());

        final HelpLine line2 = (HelpLine) i.next();
        assertEquals(3, line2.getIndent());
        assertSame(optHelp, line2.getOption());

        final HelpLine line3 = (HelpLine) i.next();
        assertEquals(3, line3.getIndent());
        assertSame(target, line3.getOption());

        assertFalse(i.hasNext());
    }

    public void testHelpLinesExcludesGroupNameWhenSettingAbsent() {
        final Option optHelp = new DefaultOptionBuilder().withShortName("h").create();
        final Group group = new GroupImpl(list(new Object[] { optHelp }), "grp", null, 0,
                Integer.MAX_VALUE, false);

        final Set settings = new HashSet(DisplaySetting.ALL);
        settings.remove(DisplaySetting.DISPLAY_GROUP_NAME);

        final List lines = group.helpLines(0, settings, null);
        final Iterator i = lines.iterator();

        final HelpLine line1 = (HelpLine) i.next();
        assertEquals(1, line1.getIndent());
        assertSame(optHelp, line1.getOption());

        assertFalse(i.hasNext());
    }

    public void testDefaultsDelegatesToAnonymousArguments() {
        final Option optHelp = new DefaultOptionBuilder().withShortName("h").create();
        final Argument target = new ArgumentBuilder().withName("target").withDefault("defaultVal").create();
        final Group group = new GroupImpl(list(new Object[] { optHelp, target }), "grp", null, 0,
                Integer.MAX_VALUE, false);
        final WriteableCommandLine cl = commandLine(group, list(new Object[0]));

        group.defaults(cl);

        assertEquals(list(new Object[] { "defaultVal" }), cl.getValues(target));
    }

    public void testDefaultsOnEmptyGroupDoesNotThrow() {
        final Group group = new GroupImpl(new ArrayList(), "grp", null, 0, Integer.MAX_VALUE, false);
        final WriteableCommandLine cl = commandLine(group, list(new Object[0]));

        group.defaults(cl);
    }
}
