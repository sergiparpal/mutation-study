/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.cli2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import junit.framework.TestCase;

import org.apache.commons.cli2.builder.ArgumentBuilder;
import org.apache.commons.cli2.builder.DefaultOptionBuilder;
import org.apache.commons.cli2.builder.GroupBuilder;
import org.apache.commons.cli2.commandline.WriteableCommandLineImpl;
import org.apache.commons.cli2.option.PropertyOption;

/**
 * Exercises the contract of {@link WriteableCommandLine}, using
 * {@link WriteableCommandLineImpl} as the concrete implementation under test.
 */
public class WriteableCommandLineAgentTest extends TestCase {

    private Option optA;
    private Group root;
    private WriteableCommandLine wcl;

    public void setUp() {
        optA = new DefaultOptionBuilder().withShortName("a").withLongName("alpha").create();
        root = new GroupBuilder().withOption(optA).create();
        wcl = new WriteableCommandLineImpl(root, new ArrayList());
    }

    private static List list(final Object[] values) {
        return new ArrayList(Arrays.asList(values));
    }

    public void testAddOptionMakesItPresent() {
        assertFalse(wcl.hasOption(optA));
        wcl.addOption(optA);
        assertTrue(wcl.hasOption(optA));
    }

    public void testAddOptionAlsoAddsAncestors() {
        final Option sub = new DefaultOptionBuilder().withShortName("c").create();
        final Group parentGroup = new GroupBuilder().withOption(sub).create();
        assertSame(parentGroup, sub.getParent());

        assertFalse(wcl.hasOption(sub));
        assertFalse(wcl.hasOption(parentGroup));

        wcl.addOption(sub);

        assertTrue(wcl.hasOption(sub));
        assertTrue(wcl.hasOption(parentGroup));
    }

    public void testAddValueOnPlainOptionDoesNotImplyPresence() {
        wcl.addValue(optA, "foo");
        assertFalse(wcl.hasOption(optA));
        assertEquals(list(new Object[] { "foo" }), wcl.getValues(optA));
    }

    public void testAddValueOnArgumentImpliesPresence() {
        final Argument arg = new ArgumentBuilder().withName("arg").create();
        assertFalse(wcl.hasOption(arg));
        wcl.addValue(arg, "value");
        assertTrue(wcl.hasOption(arg));
        assertEquals(list(new Object[] { "value" }), wcl.getValues(arg));
    }

    public void testGetValuesWhenAbsentReturnsEmptyList() {
        assertTrue(wcl.getValues(optA).isEmpty());
        assertTrue(wcl.getUndefaultedValues(optA).isEmpty());
    }

    public void testAddSwitchMakesOptionPresentAndSetsValue() {
        assertFalse(wcl.hasOption(optA));
        assertNull(wcl.getSwitch(optA));
        wcl.addSwitch(optA, true);
        assertTrue(wcl.hasOption(optA));
        assertEquals(Boolean.TRUE, wcl.getSwitch(optA));
    }

    public void testAddSwitchTwiceThrowsIllegalStateException() {
        wcl.addSwitch(optA, true);
        try {
            wcl.addSwitch(optA, false);
            fail("Expected IllegalStateException on second addSwitch");
        } catch (IllegalStateException expected) {
            // expected
        }
    }

    public void testGetSwitchUsesSuppliedDefaultWhenNotSet() {
        assertEquals(Boolean.FALSE, wcl.getSwitch(optA, Boolean.FALSE));
    }

    public void testSetDefaultSwitchAppliesWhenNoSwitchAdded() {
        wcl.setDefaultSwitch(optA, Boolean.TRUE);
        assertEquals(Boolean.TRUE, wcl.getSwitch(optA));
    }

    public void testAddSwitchOverridesDefaultSwitch() {
        wcl.setDefaultSwitch(optA, Boolean.TRUE);
        wcl.addSwitch(optA, false);
        assertEquals(Boolean.FALSE, wcl.getSwitch(optA));
    }

    public void testSetDefaultValuesAppliesWhenNoneAdded() {
        final List defaults = list(new Object[] { "d1", "d2" });
        wcl.setDefaultValues(optA, defaults);
        assertEquals(defaults, wcl.getValues(optA));
    }

    public void testSetDefaultValuesExtendBeyondActualValues() {
        wcl.addValue(optA, "v1");
        wcl.setDefaultValues(optA, list(new Object[] { "d1", "d2", "d3" }));

        // the single actual value is kept, and the defaults fill in the
        // remaining, unfilled positions
        assertEquals(list(new Object[] { "v1", "d2", "d3" }), wcl.getValues(optA));
    }

    public void testGetValuesWithExplicitDefaultArgument() {
        wcl.addValue(optA, "v1");
        final List explicitDefault = list(new Object[] { "x1", "x2", "x3" });
        assertEquals(list(new Object[] { "v1", "x2", "x3" }), wcl.getValues(optA, explicitDefault));
    }

    public void testGetValuesWithExplicitDefaultArgumentWhenNoneActual() {
        final List explicitDefault = list(new Object[] { "x1", "x2" });
        assertEquals(explicitDefault, wcl.getValues(optA, explicitDefault));
    }

    public void testGetUndefaultedValuesIgnoresDefaults() {
        wcl.addValue(optA, "v1");
        wcl.setDefaultValues(optA, list(new Object[] { "d1", "d2" }));

        assertEquals(list(new Object[] { "v1" }), wcl.getUndefaultedValues(optA));
    }

    public void testSetDefaultValuesNullRemovesDefault() {
        wcl.setDefaultValues(optA, list(new Object[] { "d1" }));
        wcl.setDefaultValues(optA, null);
        assertTrue(wcl.getValues(optA).isEmpty());
    }

    public void testAddPropertyAndGetProperty() {
        final PropertyOption propOpt = new PropertyOption();
        assertNull(wcl.getProperty(propOpt, "name"));
        wcl.addProperty(propOpt, "name", "value");
        assertEquals("value", wcl.getProperty(propOpt, "name"));
    }

    public void testAddPropertyLookupByEquivalentOptionInstance() {
        wcl.addProperty(new PropertyOption(), "name", "value");
        // a distinct, but equal, PropertyOption instance should still find it
        assertEquals("value", wcl.getProperty(new PropertyOption(), "name"));
    }

    public void testDefaultPropertyAddAndGet() {
        assertNull(wcl.getProperty("name"));
        wcl.addProperty("name", "value");
        assertEquals("value", wcl.getProperty("name"));
    }

    public void testGetPropertyMissingPropertyReturnsNull() {
        wcl.addProperty("name", "value");
        assertNull(wcl.getProperty("othername"));
    }

    public void testGetPropertiesReturnsAllNamesForDefaultOption() {
        wcl.addProperty("p1", "v1");
        wcl.addProperty("p2", "v2");
        final java.util.Set properties = wcl.getProperties();
        assertEquals(2, properties.size());
        assertTrue(properties.contains("p1"));
        assertTrue(properties.contains("p2"));
    }

    public void testGetPropertiesForUnknownOptionIsEmpty() {
        assertTrue(wcl.getProperties(new PropertyOption()).isEmpty());
    }

    public void testLooksLikeOptionMatchesRootPrefixes() {
        assertTrue(wcl.looksLikeOption("-a"));
        assertTrue(wcl.looksLikeOption("--alpha"));
        assertFalse(wcl.looksLikeOption("alpha"));
        assertFalse(wcl.looksLikeOption(""));
    }
}
