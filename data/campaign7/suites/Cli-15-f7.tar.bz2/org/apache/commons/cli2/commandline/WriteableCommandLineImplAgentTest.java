/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.cli2.commandline;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import junit.framework.TestCase;

import org.apache.commons.cli2.Argument;
import org.apache.commons.cli2.Option;
import org.apache.commons.cli2.builder.ArgumentBuilder;
import org.apache.commons.cli2.builder.DefaultOptionBuilder;
import org.apache.commons.cli2.option.DefaultOption;
import org.apache.commons.cli2.option.PropertyOption;

/**
 * Self-contained tests for {@link WriteableCommandLineImpl}.
 */
public class WriteableCommandLineImplAgentTest extends TestCase {

    private DefaultOption root;

    protected void setUp() throws Exception {
        root = new DefaultOptionBuilder().withShortName("root").create();
    }

    private WriteableCommandLineImpl newCommandLine() {
        return new WriteableCommandLineImpl(root, new ArrayList());
    }

    private WriteableCommandLineImpl newCommandLine(List normalised) {
        return new WriteableCommandLineImpl(root, normalised);
    }

    // -- addOption / hasOption / getOption --------------------------------

    public void testAddOptionMakesItPresent() {
        WriteableCommandLineImpl cl = newCommandLine();
        Option opt = new DefaultOptionBuilder().withShortName("a").create();

        assertFalse(cl.hasOption(opt));

        cl.addOption(opt);

        assertTrue(cl.hasOption(opt));
        assertEquals(1, cl.getOptions().size());
        assertSame(opt, cl.getOptions().get(0));
    }

    public void testHasOptionFalseForUnrelatedOption() {
        WriteableCommandLineImpl cl = newCommandLine();
        Option opt = new DefaultOptionBuilder().withShortName("a").create();
        Option other = new DefaultOptionBuilder().withShortName("b").create();

        cl.addOption(opt);

        assertFalse(cl.hasOption(other));
    }

    public void testAddOptionRegistersPreferredNameAndAliasesAsTriggers() {
        WriteableCommandLineImpl cl = newCommandLine();
        Option opt = new DefaultOptionBuilder().withShortName("a").withLongName("alpha").create();

        cl.addOption(opt);

        assertSame(opt, cl.getOption("-a"));
        assertSame(opt, cl.getOption("--alpha"));

        Set triggers = cl.getOptionTriggers();
        assertTrue(triggers.contains("-a"));
        assertTrue(triggers.contains("--alpha"));
    }

    public void testGetOptionForUnknownTriggerReturnsNull() {
        WriteableCommandLineImpl cl = newCommandLine();
        assertNull(cl.getOption("--does-not-exist"));
    }

    // -- addValue / getValues / getUndefaultedValues -----------------------

    public void testAddValueOnArgumentAutoRegistersOption() {
        WriteableCommandLineImpl cl = newCommandLine();
        Argument arg = new ArgumentBuilder().withName("file").create();

        cl.addValue(arg, "readme.txt");

        assertTrue("an Argument should be auto-registered via addOption", cl.hasOption(arg));

        List values = cl.getValues(arg, new ArrayList());
        assertEquals(1, values.size());
        assertEquals("readme.txt", values.get(0));
    }

    public void testAddValueAccumulatesMultipleValues() {
        WriteableCommandLineImpl cl = newCommandLine();
        Argument arg = new ArgumentBuilder().withName("file").create();

        cl.addValue(arg, "one");
        cl.addValue(arg, "two");

        List values = cl.getUndefaultedValues(arg);
        assertEquals(Arrays.asList(new String[] {"one", "two"}), values);
    }

    public void testGetUndefaultedValuesEmptyWhenNoneAdded() {
        WriteableCommandLineImpl cl = newCommandLine();
        Argument arg = new ArgumentBuilder().withName("file").create();

        List values = cl.getUndefaultedValues(arg);
        assertNotNull(values);
        assertTrue(values.isEmpty());
    }

    public void testGetUndefaultedValuesIgnoresRegisteredDefaults() {
        WriteableCommandLineImpl cl = newCommandLine();
        Argument arg = new ArgumentBuilder().withName("file").create();

        cl.setDefaultValues(arg, Arrays.asList(new String[] {"default.txt"}));

        // getUndefaultedValues must never return programmatically supplied defaults
        List values = cl.getUndefaultedValues(arg);
        assertTrue(values.isEmpty());
    }

    public void testGetValuesUsesSuppliedDefaultWhenNoCommandLineValue() {
        WriteableCommandLineImpl cl = newCommandLine();
        Argument arg = new ArgumentBuilder().withName("file").create();

        List defaults = Arrays.asList(new String[] {"d1", "d2"});
        List values = cl.getValues(arg, defaults);

        assertEquals(defaults, values);
    }

    public void testGetValuesPrefersCommandLineValueOverSuppliedDefault() {
        WriteableCommandLineImpl cl = newCommandLine();
        Argument arg = new ArgumentBuilder().withName("file").create();

        cl.addValue(arg, "actual");

        List values = cl.getValues(arg, Arrays.asList(new String[] {"default"}));

        assertEquals(1, values.size());
        assertEquals("actual", values.get(0));
    }

    public void testGetValuesFallsBackToRegisteredDefaultsWhenNoOtherValuesExist() {
        WriteableCommandLineImpl cl = newCommandLine();
        Argument arg = new ArgumentBuilder().withName("file").create();

        List registered = Arrays.asList(new String[] {"registered"});
        cl.setDefaultValues(arg, registered);

        // getValues(Option) delegates to getValues(Option, EMPTY_LIST)
        List values = cl.getValues((Option) arg);

        assertEquals(registered, values);
    }

    public void testSetDefaultValuesNullRemovesDefaults() {
        WriteableCommandLineImpl cl = newCommandLine();
        Argument arg = new ArgumentBuilder().withName("file").create();

        cl.setDefaultValues(arg, Arrays.asList(new String[] {"registered"}));
        cl.setDefaultValues(arg, null);

        List values = cl.getValues((Option) arg);
        assertTrue(values.isEmpty());
    }

    public void testGetValuesEmptyWhenNothingAvailable() {
        WriteableCommandLineImpl cl = newCommandLine();
        Argument arg = new ArgumentBuilder().withName("file").create();

        List values = cl.getValues(arg, new ArrayList());
        assertNotNull(values);
        assertTrue(values.isEmpty());
    }

    // -- addSwitch / getSwitch ---------------------------------------------

    public void testAddSwitchAndGetSwitch() {
        WriteableCommandLineImpl cl = newCommandLine();
        Option opt = new DefaultOptionBuilder().withShortName("v").create();

        cl.addSwitch(opt, true);

        assertEquals(Boolean.TRUE, cl.getSwitch(opt, null));
        assertTrue(cl.hasOption(opt));
    }

    public void testAddSwitchTwiceThrowsAndDoesNotDuplicateOption() {
        WriteableCommandLineImpl cl = newCommandLine();
        Option opt = new DefaultOptionBuilder().withShortName("v").create();

        cl.addSwitch(opt, true);
        try {
            cl.addSwitch(opt, false);
            fail("expected IllegalStateException on duplicate switch");
        } catch (IllegalStateException expected) {
            // expected
        }

        // the first, successful call registered the option exactly once;
        // the rejected second call must not have mutated the option list.
        assertEquals(1, cl.getOptionCount(opt));
    }

    public void testGetSwitchDefaultParameterUsedWhenNoSwitchSet() {
        WriteableCommandLineImpl cl = newCommandLine();
        Option opt = new DefaultOptionBuilder().withShortName("v").create();

        assertEquals(Boolean.FALSE, cl.getSwitch(opt, Boolean.FALSE));
    }

    public void testGetSwitchFallsBackToRegisteredDefaultSwitch() {
        WriteableCommandLineImpl cl = newCommandLine();
        Option opt = new DefaultOptionBuilder().withShortName("v").create();

        cl.setDefaultSwitch(opt, Boolean.TRUE);

        assertEquals(Boolean.TRUE, cl.getSwitch(opt, null));
    }

    public void testGetSwitchCommandLineValueBeatsSuppliedDefault() {
        WriteableCommandLineImpl cl = newCommandLine();
        Option opt = new DefaultOptionBuilder().withShortName("v").create();

        cl.addSwitch(opt, true);

        assertEquals(Boolean.TRUE, cl.getSwitch(opt, Boolean.FALSE));
    }

    public void testSetDefaultSwitchNullRemovesDefault() {
        WriteableCommandLineImpl cl = newCommandLine();
        Option opt = new DefaultOptionBuilder().withShortName("v").create();

        cl.setDefaultSwitch(opt, Boolean.TRUE);
        cl.setDefaultSwitch(opt, null);

        assertNull(cl.getSwitch(opt, null));
    }

    public void testGetSwitchNullWhenNothingAvailable() {
        WriteableCommandLineImpl cl = newCommandLine();
        Option opt = new DefaultOptionBuilder().withShortName("v").create();

        assertNull(cl.getSwitch(opt, null));
    }

    // -- addProperty / getProperty / getProperties -------------------------

    public void testAddPropertyAndGetPropertyForOption() {
        WriteableCommandLineImpl cl = newCommandLine();
        Option opt = new DefaultOptionBuilder().withShortName("D").create();

        cl.addProperty(opt, "name", "value");

        assertEquals("value", cl.getProperty(opt, "name", "fallback"));
    }

    public void testGetPropertyDefaultValueWhenMissing() {
        WriteableCommandLineImpl cl = newCommandLine();
        Option opt = new DefaultOptionBuilder().withShortName("D").create();

        assertEquals("fallback", cl.getProperty(opt, "missing", "fallback"));
    }

    public void testGetPropertyDefaultValueForUnknownOption() {
        WriteableCommandLineImpl cl = newCommandLine();
        Option opt = new DefaultOptionBuilder().withShortName("D").create();

        // nothing was ever added for this option
        assertEquals("fallback", cl.getProperty(opt, "name", "fallback"));
    }

    public void testAddPropertyReplacesExistingValue() {
        WriteableCommandLineImpl cl = newCommandLine();
        Option opt = new DefaultOptionBuilder().withShortName("D").create();

        cl.addProperty(opt, "name", "first");
        cl.addProperty(opt, "name", "second");

        assertEquals("second", cl.getProperty(opt, "name", null));
    }

    public void testAddPropertyAndGetPropertyUseDefaultPropertyOption() {
        WriteableCommandLineImpl cl = newCommandLine();

        cl.addProperty("name", "value");

        assertEquals("value", cl.getProperty("name"));
    }

    public void testGetPropertyUnknownNameReturnsNull() {
        WriteableCommandLineImpl cl = newCommandLine();
        assertNull(cl.getProperty("unset"));
    }

    public void testGetPropertiesForOption() {
        WriteableCommandLineImpl cl = newCommandLine();
        Option opt = new DefaultOptionBuilder().withShortName("D").create();

        cl.addProperty(opt, "a", "1");
        cl.addProperty(opt, "b", "2");

        Set properties = cl.getProperties(opt);
        assertEquals(2, properties.size());
        assertTrue(properties.contains("a"));
        assertTrue(properties.contains("b"));
    }

    public void testGetPropertiesEmptyForUnknownOption() {
        WriteableCommandLineImpl cl = newCommandLine();
        Option opt = new DefaultOptionBuilder().withShortName("D").create();

        Set properties = cl.getProperties(opt);
        assertNotNull(properties);
        assertTrue(properties.isEmpty());
    }

    public void testGetPropertiesIsUnmodifiable() {
        WriteableCommandLineImpl cl = newCommandLine();
        Option opt = new DefaultOptionBuilder().withShortName("D").create();
        cl.addProperty(opt, "a", "1");

        Set properties = cl.getProperties(opt);
        try {
            properties.add("c");
            fail("expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
    }

    // -- looksLikeOption ----------------------------------------------------

    public void testLooksLikeOptionUsesRootPrefixes() {
        WriteableCommandLineImpl cl = newCommandLine();

        assertTrue(cl.looksLikeOption("--alpha"));
        assertTrue(cl.looksLikeOption("-a"));
        assertFalse(cl.looksLikeOption("alpha"));
        assertFalse(cl.looksLikeOption(""));
    }

    // -- toString / getNormalised --------------------------------------------

    public void testToStringJoinsArgumentsWithSpaces() {
        List normalised = Arrays.asList(new String[] {"--name", "value"});
        WriteableCommandLineImpl cl = newCommandLine(normalised);

        assertEquals("--name value", cl.toString());
    }

    public void testToStringQuotesArgumentsContainingSpaces() {
        List normalised = Arrays.asList(new String[] {"--name", "John Doe"});
        WriteableCommandLineImpl cl = newCommandLine(normalised);

        assertEquals("--name \"John Doe\"", cl.toString());
    }

    public void testToStringEmptyWhenNoArguments() {
        WriteableCommandLineImpl cl = newCommandLine(new ArrayList());
        assertEquals("", cl.toString());
    }

    public void testGetNormalisedReturnsSuppliedArguments() {
        List normalised = Arrays.asList(new String[] {"a", "b"});
        WriteableCommandLineImpl cl = newCommandLine(normalised);

        assertEquals(normalised, cl.getNormalised());
    }

    public void testGetNormalisedIsUnmodifiable() {
        List normalised = new ArrayList();
        normalised.add("a");
        WriteableCommandLineImpl cl = newCommandLine(normalised);

        try {
            cl.getNormalised().add("b");
            fail("expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
    }

    // -- getOptions / getOptionTriggers unmodifiability ----------------------

    public void testGetOptionsIsUnmodifiable() {
        WriteableCommandLineImpl cl = newCommandLine();
        Option opt = new DefaultOptionBuilder().withShortName("a").create();
        cl.addOption(opt);

        try {
            cl.getOptions().add(opt);
            fail("expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
    }

    public void testGetOptionTriggersIsUnmodifiable() {
        WriteableCommandLineImpl cl = newCommandLine();
        Option opt = new DefaultOptionBuilder().withShortName("a").create();
        cl.addOption(opt);

        try {
            cl.getOptionTriggers().add("-z");
            fail("expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
    }

    // -- getOptionCount (inherited from CommandLineImpl, exercised here) ----

    public void testGetOptionCountZeroForUnknownTrigger() {
        WriteableCommandLineImpl cl = newCommandLine();
        assertEquals(0, cl.getOptionCount("--nope"));
    }

    public void testGetOptionCountCountsRepeatedAdds() {
        WriteableCommandLineImpl cl = newCommandLine();
        Option opt = new DefaultOptionBuilder().withShortName("a").create();

        cl.addOption(opt);
        cl.addOption(opt);

        assertEquals(2, cl.getOptionCount(opt));
    }
}
