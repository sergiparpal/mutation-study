/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.FieldPosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.Test;

/**
 * Self-contained tests for {@link FastDatePrinter}.
 */
public class FastDatePrinterAgentTest {

    private static final TimeZone NEW_YORK = TimeZone.getTimeZone("America/New_York");
    private static final TimeZone GMT = TimeZone.getTimeZone("GMT");

    private FastDatePrinter newPrinter(String pattern, TimeZone tz, Locale locale) {
        return new FastDatePrinter(pattern, tz, locale);
    }

    private Calendar calendar(int year, int month, int day, int hour, int minute, int second, int millis, TimeZone tz) {
        Calendar cal = new GregorianCalendar(tz, Locale.US);
        cal.clear();
        cal.set(year, month, day, hour, minute, second);
        cal.set(Calendar.MILLISECOND, millis);
        return cal;
    }

    @Test
    public void testBasicFormatDate() {
        FastDatePrinter printer = newPrinter("yyyy-MM-dd", GMT, Locale.US);
        Calendar cal = calendar(2021, Calendar.MARCH, 5, 10, 15, 30, 0, GMT);
        String result = printer.format(cal.getTime());
        assertEquals("2021-03-05", result);
    }

    @Test
    public void testFormatCalendar() {
        FastDatePrinter printer = newPrinter("yyyy-MM-dd HH:mm:ss", GMT, Locale.US);
        Calendar cal = calendar(1999, Calendar.DECEMBER, 31, 23, 59, 59, 0, GMT);
        assertEquals("1999-12-31 23:59:59", printer.format(cal));
    }

    @Test
    public void testFormatMillis() {
        FastDatePrinter printer = newPrinter("yyyy-MM-dd", GMT, Locale.US);
        Calendar cal = calendar(1970, Calendar.JANUARY, 1, 0, 0, 0, 0, GMT);
        assertEquals("1970-01-01", printer.format(cal.getTimeInMillis()));
    }

    @Test
    public void testFormatObjectDate() {
        FastDatePrinter printer = newPrinter("yyyy", GMT, Locale.US);
        Calendar cal = calendar(2005, Calendar.JUNE, 15, 0, 0, 0, 0, GMT);
        Date date = cal.getTime();
        StringBuffer sb = new StringBuffer();
        StringBuffer result = printer.format((Object) date, sb, new FieldPosition(0));
        assertEquals("2005", result.toString());
        assertTrue(result == sb);
    }

    @Test
    public void testFormatObjectCalendar() {
        FastDatePrinter printer = newPrinter("yyyy", GMT, Locale.US);
        Calendar cal = calendar(2005, Calendar.JUNE, 15, 0, 0, 0, 0, GMT);
        StringBuffer sb = new StringBuffer();
        printer.format((Object) cal, sb, new FieldPosition(0));
        assertEquals("2005", sb.toString());
    }

    @Test
    public void testFormatObjectLong() {
        FastDatePrinter printer = newPrinter("yyyy", GMT, Locale.US);
        Calendar cal = calendar(2005, Calendar.JUNE, 15, 0, 0, 0, 0, GMT);
        Long millis = Long.valueOf(cal.getTimeInMillis());
        StringBuffer sb = new StringBuffer();
        printer.format((Object) millis, sb, new FieldPosition(0));
        assertEquals("2005", sb.toString());
    }

    @Test
    public void testFormatObjectUnknownTypeThrows() {
        FastDatePrinter printer = newPrinter("yyyy", GMT, Locale.US);
        try {
            printer.format((Object) "not a date", new StringBuffer(), new FieldPosition(0));
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testFormatObjectNullThrows() {
        FastDatePrinter printer = newPrinter("yyyy", GMT, Locale.US);
        try {
            printer.format((Object) null, new StringBuffer(), new FieldPosition(0));
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().contains("<null>"));
        }
    }

    @Test
    public void testTwoDigitYear() {
        FastDatePrinter printer = newPrinter("yy", GMT, Locale.US);
        Calendar cal = calendar(2009, Calendar.JANUARY, 1, 0, 0, 0, 0, GMT);
        assertEquals("09", printer.format(cal));

        Calendar cal2 = calendar(2000, Calendar.JANUARY, 1, 0, 0, 0, 0, GMT);
        assertEquals("00", printer.format(cal2));
    }

    @Test
    public void testFourDigitYear() {
        FastDatePrinter printer = newPrinter("yyyy", GMT, Locale.US);
        Calendar cal = calendar(9, Calendar.JANUARY, 1, 0, 0, 0, 0, GMT);
        // padded to at least 4 digits
        assertEquals("0009", printer.format(cal));
    }

    @Test
    public void testUnpaddedMonth() {
        FastDatePrinter printer = newPrinter("M", GMT, Locale.US);
        Calendar cal = calendar(2020, Calendar.MARCH, 1, 0, 0, 0, 0, GMT);
        assertEquals("3", printer.format(cal));

        Calendar cal2 = calendar(2020, Calendar.NOVEMBER, 1, 0, 0, 0, 0, GMT);
        assertEquals("11", printer.format(cal2));
    }

    @Test
    public void testTwoDigitMonth() {
        FastDatePrinter printer = newPrinter("MM", GMT, Locale.US);
        Calendar cal = calendar(2020, Calendar.MARCH, 1, 0, 0, 0, 0, GMT);
        assertEquals("03", printer.format(cal));
    }

    @Test
    public void testFullMonthName() {
        FastDatePrinter printer = newPrinter("MMMM", GMT, Locale.US);
        Calendar cal = calendar(2020, Calendar.MARCH, 1, 0, 0, 0, 0, GMT);
        assertEquals("March", printer.format(cal));
    }

    @Test
    public void testShortMonthName() {
        FastDatePrinter printer = newPrinter("MMM", GMT, Locale.US);
        Calendar cal = calendar(2020, Calendar.MARCH, 1, 0, 0, 0, 0, GMT);
        assertEquals("Mar", printer.format(cal));
    }

    @Test
    public void testEraDesignator() {
        FastDatePrinter printer = newPrinter("G", GMT, Locale.US);
        Calendar cal = calendar(2020, Calendar.MARCH, 1, 0, 0, 0, 0, GMT);
        assertEquals("AD", printer.format(cal));
    }

    @Test
    public void testDayOfWeekShortAndLong() {
        FastDatePrinter shortPrinter = newPrinter("E", GMT, Locale.US);
        FastDatePrinter longPrinter = newPrinter("EEEE", GMT, Locale.US);
        // 2021-03-05 is a Friday
        Calendar cal = calendar(2021, Calendar.MARCH, 5, 0, 0, 0, 0, GMT);
        assertEquals("Fri", shortPrinter.format(cal));
        assertEquals("Friday", longPrinter.format(cal));
    }

    @Test
    public void testAmPmMarker() {
        FastDatePrinter printer = newPrinter("a", GMT, Locale.US);
        Calendar am = calendar(2020, Calendar.JANUARY, 1, 2, 0, 0, 0, GMT);
        Calendar pm = calendar(2020, Calendar.JANUARY, 1, 14, 0, 0, 0, GMT);
        assertEquals("AM", printer.format(am));
        assertEquals("PM", printer.format(pm));
    }

    @Test
    public void testTwelveHourFieldMidnightBecomesTwelve() {
        FastDatePrinter printer = newPrinter("h", GMT, Locale.US);
        Calendar midnight = calendar(2020, Calendar.JANUARY, 1, 0, 0, 0, 0, GMT);
        assertEquals("12", printer.format(midnight));

        Calendar oneAm = calendar(2020, Calendar.JANUARY, 1, 1, 0, 0, 0, GMT);
        assertEquals("1", printer.format(oneAm));
    }

    @Test
    public void testTwentyFourHourFieldMidnightBecomesTwentyFour() {
        FastDatePrinter printer = newPrinter("k", GMT, Locale.US);
        Calendar midnight = calendar(2020, Calendar.JANUARY, 1, 0, 0, 0, 0, GMT);
        assertEquals("24", printer.format(midnight));

        Calendar oneAm = calendar(2020, Calendar.JANUARY, 1, 1, 0, 0, 0, GMT);
        assertEquals("1", printer.format(oneAm));
    }

    @Test
    public void testHourInDayZeroBased() {
        FastDatePrinter printer = newPrinter("HH", GMT, Locale.US);
        Calendar midnight = calendar(2020, Calendar.JANUARY, 1, 0, 0, 0, 0, GMT);
        assertEquals("00", printer.format(midnight));
    }

    @Test
    public void testHourInAmPmZeroBased() {
        FastDatePrinter printer = newPrinter("KK", GMT, Locale.US);
        Calendar midnight = calendar(2020, Calendar.JANUARY, 1, 0, 0, 0, 0, GMT);
        assertEquals("00", printer.format(midnight));
    }

    @Test
    public void testMillisecondPadding() {
        FastDatePrinter printer = newPrinter("SSS", GMT, Locale.US);
        Calendar cal = calendar(2020, Calendar.JANUARY, 1, 0, 0, 0, 7, GMT);
        assertEquals("007", printer.format(cal));
    }

    @Test
    public void testLiteralTextSingleQuoteEscape() {
        FastDatePrinter printer = newPrinter("yyyy'o''clock'", GMT, Locale.US);
        Calendar cal = calendar(2020, Calendar.JANUARY, 1, 0, 0, 0, 0, GMT);
        assertEquals("2020o'clock", printer.format(cal));
    }

    @Test
    public void testLiteralTextSingleCharacter() {
        FastDatePrinter printer = newPrinter("yyyy'T'HH", GMT, Locale.US);
        Calendar cal = calendar(2020, Calendar.JANUARY, 1, 5, 0, 0, 0, GMT);
        assertEquals("2020T05", printer.format(cal));
    }

    @Test
    public void testNonLetterCharactersPassThrough() {
        FastDatePrinter printer = newPrinter("yyyy-MM-dd", GMT, Locale.US);
        Calendar cal = calendar(2020, Calendar.JANUARY, 5, 0, 0, 0, 0, GMT);
        assertEquals("2020-01-05", printer.format(cal));
    }

    @Test
    public void testTimeZoneRfc822NoColon() {
        FastDatePrinter printer = newPrinter("Z", NEW_YORK, Locale.US);
        // January is EST, UTC-5, no DST
        Calendar cal = calendar(2020, Calendar.JANUARY, 1, 0, 0, 0, 0, NEW_YORK);
        assertEquals("-0500", printer.format(cal));
    }

    @Test
    public void testTimeZoneIso8601WithColon() {
        FastDatePrinter printer = newPrinter("ZZ", NEW_YORK, Locale.US);
        Calendar cal = calendar(2020, Calendar.JANUARY, 1, 0, 0, 0, 0, NEW_YORK);
        assertEquals("-05:00", printer.format(cal));
    }

    @Test
    public void testTimeZoneGmtNoOffset() {
        FastDatePrinter printer = newPrinter("Z", GMT, Locale.US);
        Calendar cal = calendar(2020, Calendar.JANUARY, 1, 0, 0, 0, 0, GMT);
        assertEquals("+0000", printer.format(cal));
    }

    @Test
    public void testTimeZoneNameShortAndLong() {
        FastDatePrinter shortPrinter = newPrinter("z", GMT, Locale.US);
        FastDatePrinter longPrinter = newPrinter("zzzz", GMT, Locale.US);
        Calendar cal = calendar(2020, Calendar.JANUARY, 1, 0, 0, 0, 0, GMT);
        assertEquals("GMT", shortPrinter.format(cal));
        assertEquals("Greenwich Mean Time", longPrinter.format(cal));
    }

    @Test
    public void testIllegalPatternThrows() {
        try {
            newPrinter("yyyy-QQ", GMT, Locale.US);
            fail("Expected IllegalArgumentException for illegal pattern component");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().contains("Illegal pattern component"));
        }
    }

    @Test
    public void testGetPatternTimeZoneLocale() {
        FastDatePrinter printer = newPrinter("yyyy-MM-dd", GMT, Locale.US);
        assertEquals("yyyy-MM-dd", printer.getPattern());
        assertEquals(GMT, printer.getTimeZone());
        assertEquals(Locale.US, printer.getLocale());
    }

    @Test
    public void testGetMaxLengthEstimatePositive() {
        FastDatePrinter printer = newPrinter("yyyy-MM-dd HH:mm:ss.SSS", GMT, Locale.US);
        assertTrue(printer.getMaxLengthEstimate() > 0);
    }

    @Test
    public void testEqualsAndHashCode() {
        FastDatePrinter printer1 = newPrinter("yyyy-MM-dd", GMT, Locale.US);
        FastDatePrinter printer2 = newPrinter("yyyy-MM-dd", GMT, Locale.US);
        FastDatePrinter printer3 = newPrinter("yyyy-MM", GMT, Locale.US);

        assertTrue(printer1.equals(printer2));
        assertEquals(printer1.hashCode(), printer2.hashCode());
        assertFalse(printer1.equals(printer3));
        assertFalse(printer1.equals(null));
        assertFalse(printer1.equals("not a printer"));
    }

    @Test
    public void testToStringContainsPatternLocaleAndZone() {
        FastDatePrinter printer = newPrinter("yyyy", GMT, Locale.US);
        String str = printer.toString();
        assertTrue(str.contains("yyyy"));
        assertTrue(str.contains("GMT"));
    }

    @Test
    public void testFormatIntoProvidedBufferAppends() {
        FastDatePrinter printer = newPrinter("yyyy", GMT, Locale.US);
        Calendar cal = calendar(2020, Calendar.JANUARY, 1, 0, 0, 0, 0, GMT);
        StringBuffer buf = new StringBuffer("prefix-");
        StringBuffer result = printer.format(cal, buf);
        assertEquals("prefix-2020", result.toString());
        assertTrue(result == buf);
    }

    @Test
    public void testFormatDateIntoProvidedBuffer() {
        FastDatePrinter printer = newPrinter("yyyy", GMT, Locale.US);
        Calendar cal = calendar(2020, Calendar.JANUARY, 1, 0, 0, 0, 0, GMT);
        StringBuffer buf = new StringBuffer();
        StringBuffer result = printer.format(cal.getTime(), buf);
        assertEquals("2020", result.toString());
        assertTrue(result == buf);
    }

    @Test
    public void testFormatMillisIntoProvidedBuffer() {
        FastDatePrinter printer = newPrinter("yyyy", GMT, Locale.US);
        Calendar cal = calendar(2020, Calendar.JANUARY, 1, 0, 0, 0, 0, GMT);
        StringBuffer buf = new StringBuffer();
        StringBuffer result = printer.format(cal.getTimeInMillis(), buf);
        assertEquals("2020", result.toString());
        assertTrue(result == buf);
    }

    @Test
    public void testSerializationRoundTrip() throws Exception {
        FastDatePrinter printer = newPrinter("yyyy-MM-dd HH:mm:ss", GMT, Locale.US);

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(baos);
        oos.writeObject(printer);
        oos.close();

        ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
        ObjectInputStream ois = new ObjectInputStream(bais);
        FastDatePrinter deserialized = (FastDatePrinter) ois.readObject();
        ois.close();

        assertEquals(printer, deserialized);

        Calendar cal = calendar(2021, Calendar.MARCH, 5, 10, 15, 30, 0, GMT);
        assertEquals(printer.format(cal), deserialized.format(cal));
    }

    @Test
    public void testDayOfYearPadded() {
        FastDatePrinter printer = newPrinter("DDD", GMT, Locale.US);
        Calendar cal = calendar(2020, Calendar.JANUARY, 1, 0, 0, 0, 0, GMT);
        assertEquals("001", printer.format(cal));
    }

    @Test
    public void testWeekInYearUnpadded() {
        FastDatePrinter printer = newPrinter("w", GMT, Locale.US);
        Calendar cal = calendar(2020, Calendar.JANUARY, 1, 0, 0, 0, 0, GMT);
        int expected = cal.get(Calendar.WEEK_OF_YEAR);
        assertEquals(String.valueOf(expected), printer.format(cal));
    }

    @Test
    public void testPaddedFieldWithLargeYearValue() {
        FastDatePrinter printer = newPrinter("yyyy", GMT, Locale.US);
        Calendar cal = calendar(12345, Calendar.JANUARY, 1, 0, 0, 0, 0, GMT);
        assertEquals("12345", printer.format(cal));
    }
}
