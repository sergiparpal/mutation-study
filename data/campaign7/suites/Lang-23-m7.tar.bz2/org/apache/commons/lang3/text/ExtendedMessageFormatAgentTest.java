/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import java.text.FieldPosition;
import java.text.Format;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import junit.framework.TestCase;

/**
 * Self-contained unit tests for {@link ExtendedMessageFormat}.
 */
public class ExtendedMessageFormatAgentTest extends TestCase {

    public ExtendedMessageFormatAgentTest(String name) {
        super(name);
    }

    /** Simple Format which upper-cases the String representation of its argument. */
    private static final class UpperCaseFormat extends Format {
        private static final long serialVersionUID = 1L;

        @Override
        public StringBuffer format(Object obj, StringBuffer toAppendTo, FieldPosition pos) {
            return toAppendTo.append(String.valueOf(obj).toUpperCase());
        }

        @Override
        public Object parseObject(String source, ParsePosition pos) {
            pos.setIndex(source.length());
            return source;
        }
    }

    /** FormatFactory registering a single "upper" format, optionally recording the args passed. */
    private static final class UpperCaseFormatFactory implements FormatFactory {
        private String lastName;
        private String lastArguments;
        private Locale lastLocale;

        public Format getFormat(String name, String arguments, Locale locale) {
            this.lastName = name;
            this.lastArguments = arguments;
            this.lastLocale = locale;
            if ("upper".equals(name)) {
                return new UpperCaseFormat();
            }
            return null;
        }
    }

    private Map<String, FormatFactory> registryWithUpper(UpperCaseFormatFactory factory) {
        Map<String, FormatFactory> registry = new HashMap<String, FormatFactory>();
        registry.put("upper", factory);
        return registry;
    }

    // --- construction / toPattern -------------------------------------------------

    public void testSimplePatternNoRegistry() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello, {0}!");
        assertEquals("Hello, {0}!", emf.toPattern());
        assertEquals("Hello, World!", emf.format(new Object[] { "World" }));
    }

    public void testLocaleIsApplied() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number,#,##0.00}", Locale.GERMAN);
        String result = emf.format(new Object[] { new Double(1234.5) });
        assertEquals("1.234,50", result);
        assertEquals(Locale.GERMAN, emf.getLocale());
    }

    public void testNullRegistryBehavesLikePlainMessageFormat() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}-{1}", (Map<String, FormatFactory>) null);
        assertEquals("a-b", emf.format(new Object[] { "a", "b" }));
        assertEquals("{0}-{1}", emf.toPattern());
    }

    // --- custom format via registry -------------------------------------------------

    public void testCustomFormatIsUsedAndPatternPreserved() {
        UpperCaseFormatFactory factory = new UpperCaseFormatFactory();
        ExtendedMessageFormat emf = new ExtendedMessageFormat(
                "Value: {0,upper}", registryWithUpper(factory));
        assertEquals("Value: {0,upper}", emf.toPattern());
        assertEquals("Value: ABC", emf.format(new Object[] { "abc" }));
        assertEquals("upper", factory.lastName);
        assertNull(factory.lastArguments);
    }

    public void testCustomFormatWithStyleArgumentsPassedThrough() {
        UpperCaseFormatFactory factory = new UpperCaseFormatFactory();
        ExtendedMessageFormat emf = new ExtendedMessageFormat(
                "{0,upper,foo}", registryWithUpper(factory));
        assertEquals("foo", factory.lastArguments);
        assertEquals("{0,upper,foo}", emf.toPattern());
    }

    public void testUnknownFormatNameFallsBackToStandardFormat() {
        UpperCaseFormatFactory factory = new UpperCaseFormatFactory();
        ExtendedMessageFormat emf = new ExtendedMessageFormat(
                "{0,number}", registryWithUpper(factory));
        // "number" is not in the registry (only "upper" is), so getFormat() returns null
        // and the standard MessageFormat number handling is used instead.
        assertEquals("42", emf.format(new Object[] { new Integer(42) }));
        assertEquals("{0,number}", emf.toPattern());
    }

    public void testMixedCustomAndStandardFormats() {
        UpperCaseFormatFactory factory = new UpperCaseFormatFactory();
        ExtendedMessageFormat emf = new ExtendedMessageFormat(
                "{0,upper} costs {1,number,currency}", registryWithUpper(factory));
        String result = emf.format(new Object[] { "widget", new Double(3) });
        assertTrue(result.startsWith("WIDGET costs"));
    }

    public void testDoubledQuoteIsLiteralApostrophe() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat(
                "it''s a test {0}", new HashMap<String, FormatFactory>());
        assertEquals("it's a test X", emf.format(new Object[] { "X" }));
    }

    public void testQuotedLiteralTextWithoutBraces() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat(
                "quoted 'literal' {0}", new HashMap<String, FormatFactory>());
        assertEquals("quoted literal X", emf.format(new Object[] { "X" }));
    }

    // --- parse-time errors ----------------------------------------------------------

    public void testUnterminatedFormatElementThrows() {
        try {
            new ExtendedMessageFormat("{0", new HashMap<String, FormatFactory>());
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testInvalidArgumentIndexThrows() {
        try {
            new ExtendedMessageFormat("{abc}", new HashMap<String, FormatFactory>());
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testUnterminatedQuoteLeavesRemainderAsLiteral() {
        // An unmatched opening quote degrades gracefully: the remainder of the
        // pattern including the "{0}" is treated as literal text, not a format
        // element, and no argument substitution occurs.
        ExtendedMessageFormat emf = new ExtendedMessageFormat(
                "plain '{0}", new HashMap<String, FormatFactory>());
        assertEquals("plain {0}", emf.format(new Object[] { "X" }));
    }

    public void testUnterminatedFormatDescriptionThrows() {
        try {
            new ExtendedMessageFormat("{0,upper", registryWithUpper(new UpperCaseFormatFactory()));
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testEmptyPatternProducesEmptyOutput() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("", new HashMap<String, FormatFactory>());
        assertEquals("", emf.toPattern());
        assertEquals("", emf.format(new Object[0]));
    }

    // --- disabled mutators ------------------------------------------------------------

    public void testSetFormatThrowsUnsupported() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        try {
            emf.setFormat(0, new UpperCaseFormat());
            fail("expected UnsupportedOperationException");
        } catch (UnsupportedOperationException e) {
            // expected
        }
    }

    public void testSetFormatByArgumentIndexThrowsUnsupported() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        try {
            emf.setFormatByArgumentIndex(0, new UpperCaseFormat());
            fail("expected UnsupportedOperationException");
        } catch (UnsupportedOperationException e) {
            // expected
        }
    }

    public void testSetFormatsThrowsUnsupported() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        try {
            emf.setFormats(new Format[] { new UpperCaseFormat() });
            fail("expected UnsupportedOperationException");
        } catch (UnsupportedOperationException e) {
            // expected
        }
    }

    public void testSetFormatsByArgumentIndexThrowsUnsupported() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        try {
            emf.setFormatsByArgumentIndex(new Format[] { new UpperCaseFormat() });
            fail("expected UnsupportedOperationException");
        } catch (UnsupportedOperationException e) {
            // expected
        }
    }

    // --- equals / hashCode --------------------------------------------------------------

    public void testEqualsReflexiveAndWithEqualPattern() {
        ExtendedMessageFormat emf1 = new ExtendedMessageFormat("{0}", Locale.US);
        ExtendedMessageFormat emf2 = new ExtendedMessageFormat("{0}", Locale.US);
        assertTrue(emf1.equals(emf1));
        assertTrue(emf1.equals(emf2));
        assertTrue(emf2.equals(emf1));
        assertEquals(emf1.hashCode(), emf2.hashCode());
    }

    public void testEqualsFalseForNullAndDifferentType() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", Locale.US);
        assertFalse(emf.equals(null));
        assertFalse(emf.equals("not a format"));
    }

    public void testEqualsFalseForDifferentPattern() {
        ExtendedMessageFormat emf1 = new ExtendedMessageFormat("{0}", Locale.US);
        ExtendedMessageFormat emf2 = new ExtendedMessageFormat("{0}!", Locale.US);
        assertFalse(emf1.equals(emf2));
    }

    public void testEqualsFalseForDifferentRegistry() {
        Map<String, FormatFactory> registry1 = registryWithUpper(new UpperCaseFormatFactory());
        Map<String, FormatFactory> registry2 = new HashMap<String, FormatFactory>();
        ExtendedMessageFormat emf1 = new ExtendedMessageFormat("{0,upper}", registry1);
        ExtendedMessageFormat emf2 = new ExtendedMessageFormat("{0}", registry2);
        assertFalse(emf1.equals(emf2));
    }

    public void testEqualsFalseAgainstPlainMessageFormat() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", Locale.US);
        java.text.MessageFormat mf = new java.text.MessageFormat("{0}", Locale.US);
        assertFalse(emf.equals(mf));
    }

    // --- parse round-trip -----------------------------------------------------------

    public void testParseRoundTrip() throws ParseException {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}-{1}", new HashMap<String, FormatFactory>());
        Object[] parsed = emf.parse("foo-bar");
        assertEquals(2, parsed.length);
        assertEquals("foo", parsed[0]);
        assertEquals("bar", parsed[1]);
    }

    public void testMultipleArgumentIndexesOutOfOrder() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{1} {0}", new HashMap<String, FormatFactory>());
        assertEquals("b a", emf.format(new Object[] { "a", "b" }));
    }
}
