/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.FieldPosition;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import org.junit.Test;

/**
 * Self-contained tests for {@link FastDatePrinter}, exercising it directly
 * (this test lives in the same package so it can use the protected
 * constructor and protected helper methods).
 */
public class FastDatePrinterAgentTest {

    private static final TimeZone GMT = TimeZone.getTimeZone("GMT");

    private static Calendar calendar(TimeZone tz, int year, int month, int day,
                                      int hour, int minute, int second, int millis) {
        Calendar c = new GregorianCalendar(tz);
        c.clear();
        c.set(Calendar.YEAR, year);
        c.set(Calendar.MONTH, month);
        c.set(Calendar.DAY_OF_MONTH, day);
        c.set(Calendar.HOUR_OF_DAY, hour);
        c.set(Calendar.MINUTE, minute);
        c.set(Calendar.SECOND, second);
        c.set(Calendar.MILLISECOND, millis);
        return c;
    }

    private static FastDatePrinter printer(String pattern) {
        return new FastDatePrinter(pattern, GMT, Locale.US);
    }

    // -------------------------------------------------------------
    // Basic formatting
    // -------------------------------------------------------------

    @Test
    public void testFormatCalendar_yyyyMMdd() {
        FastDatePrinter p = printer("yyyy-MM-dd");
        Calendar c = calendar(GMT, 2021, Calendar.JUNE, 15, 10, 0, 0, 0);
        assertEquals("2021-06-15", p.format(c));
    }

    @Test
    public void testFormatDate_matchesFormatCalendar() {
        FastDatePrinter p = printer("yyyy-MM-dd HH:mm:ss");
        Calendar c = calendar(GMT, 1999, Calendar.DECEMBER, 31, 23, 59, 58, 0);
        Date d = c.getTime();
        assertEquals("1999-12-31 23:59:58", p.format(d));
    }

    @Test
    public void testFormatLongMillis() {
        FastDatePrinter p = printer("yyyy-MM-dd");
        Calendar c = calendar(GMT, 2000, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals("2000-01-01", p.format(c.getTime().getTime()));
    }

    @Test
    public void testFormatIntoSuppliedBuffer() {
        FastDatePrinter p = printer("yyyy");
        Calendar c = calendar(GMT, 2021, Calendar.JANUARY, 1, 0, 0, 0, 0);
        StringBuffer buf = new StringBuffer("prefix-");
        StringBuffer result = p.format(c, buf);
        assertSameBuffer(buf, result);
        assertEquals("prefix-2021", buf.toString());
    }

    private static void assertSameBuffer(StringBuffer expected, StringBuffer actual) {
        assertTrue("format() should return the same buffer instance passed in",
                expected == actual);
    }

    @Test
    public void testEmptyPatternFormatsToEmptyString() {
        FastDatePrinter p = printer("");
        Calendar c = calendar(GMT, 2021, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals("", p.format(c));
        assertEquals(0, p.getMaxLengthEstimate());
    }

    // -------------------------------------------------------------
    // Year field
    // -------------------------------------------------------------

    @Test
    public void testTwoDigitYear() {
        FastDatePrinter p = printer("yy");
        assertEquals("05", p.format(calendar(GMT, 2005, Calendar.JANUARY, 1, 0, 0, 0, 0)));
        assertEquals("99", p.format(calendar(GMT, 1999, Calendar.JANUARY, 1, 0, 0, 0, 0)));
        assertEquals("00", p.format(calendar(GMT, 2000, Calendar.JANUARY, 1, 0, 0, 0, 0)));
        assertEquals("00", p.format(calendar(GMT, 1900, Calendar.JANUARY, 1, 0, 0, 0, 0)));
    }

    @Test
    public void testSingleYPatternPadsToFourDigits() {
        FastDatePrinter p = printer("y");
        assertEquals("0007", p.format(calendar(GMT, 7, Calendar.JANUARY, 1, 0, 0, 0, 0)));
        assertEquals("2023", p.format(calendar(GMT, 2023, Calendar.JANUARY, 1, 0, 0, 0, 0)));
    }

    @Test
    public void testFourDigitYearPattern() {
        FastDatePrinter p = printer("yyyy");
        assertEquals("0042", p.format(calendar(GMT, 42, Calendar.JANUARY, 1, 0, 0, 0, 0)));
        assertEquals("1987", p.format(calendar(GMT, 1987, Calendar.JANUARY, 1, 0, 0, 0, 0)));
        assertEquals("12021", p.format(calendar(GMT, 12021, Calendar.JANUARY, 1, 0, 0, 0, 0)));
    }

    // -------------------------------------------------------------
    // Month field
    // -------------------------------------------------------------

    @Test
    public void testMonthFieldVariants() {
        Calendar c = calendar(GMT, 2021, Calendar.MARCH, 5, 0, 0, 0, 0);
        assertEquals("3", printer("M").format(c));
        assertEquals("03", printer("MM").format(c));
        assertEquals("Mar", printer("MMM").format(c));
        assertEquals("March", printer("MMMM").format(c));
    }

    @Test
    public void testMonthFieldDecember() {
        Calendar c = calendar(GMT, 2021, Calendar.DECEMBER, 1, 0, 0, 0, 0);
        assertEquals("12", printer("MM").format(c));
        assertEquals("Dec", printer("MMM").format(c));
    }

    // -------------------------------------------------------------
    // Day of month field
    // -------------------------------------------------------------

    @Test
    public void testDayOfMonthPadding() {
        Calendar c = calendar(GMT, 2021, Calendar.JANUARY, 5, 0, 0, 0, 0);
        assertEquals("5", printer("d").format(c));
        assertEquals("05", printer("dd").format(c));
        assertEquals("005", printer("ddd").format(c));
    }

    // -------------------------------------------------------------
    // Hour fields: H (0-23), h (1-12), k (1-24), K (0-11)
    // -------------------------------------------------------------

    @Test
    public void testHourFieldsAtMidnight() {
        Calendar c = calendar(GMT, 2021, Calendar.JANUARY, 1, 0, 30, 0, 0);
        assertEquals("0", printer("H").format(c));
        assertEquals("12", printer("h").format(c));
        assertEquals("24", printer("k").format(c));
        assertEquals("0", printer("K").format(c));
    }

    @Test
    public void testHourFieldsAtNoon() {
        Calendar c = calendar(GMT, 2021, Calendar.JANUARY, 1, 12, 0, 0, 0);
        assertEquals("12", printer("H").format(c));
        assertEquals("12", printer("h").format(c));
        assertEquals("12", printer("k").format(c));
        assertEquals("0", printer("K").format(c));
    }

    @Test
    public void testHourFieldsAfternoon() {
        Calendar c = calendar(GMT, 2021, Calendar.JANUARY, 1, 15, 0, 0, 0);
        assertEquals("15", printer("H").format(c));
        assertEquals("3", printer("h").format(c));
        assertEquals("15", printer("k").format(c));
        assertEquals("3", printer("K").format(c));
    }

    @Test
    public void testAmPmMarker() {
        assertEquals("AM", printer("a").format(calendar(GMT, 2021, Calendar.JANUARY, 1, 3, 0, 0, 0)));
        assertEquals("PM", printer("a").format(calendar(GMT, 2021, Calendar.JANUARY, 1, 15, 0, 0, 0)));
    }

    // -------------------------------------------------------------
    // Minute / second / millisecond
    // -------------------------------------------------------------

    @Test
    public void testMinuteSecondMillisecond() {
        Calendar c = calendar(GMT, 2021, Calendar.JANUARY, 1, 1, 2, 3, 4);
        assertEquals("02", printer("mm").format(c));
        assertEquals("03", printer("ss").format(c));
        assertEquals("004", printer("SSS").format(c));
    }

    @Test
    public void testMillisecondLargeValue() {
        Calendar c = calendar(GMT, 2021, Calendar.JANUARY, 1, 1, 2, 3, 999);
        assertEquals("999", printer("SSS").format(c));
    }

    // -------------------------------------------------------------
    // Day of week (text)
    // -------------------------------------------------------------

    @Test
    public void testDayOfWeekTextShortAndLong() {
        // 2021-06-16 is a Wednesday.
        Calendar c = calendar(GMT, 2021, Calendar.JUNE, 16, 0, 0, 0, 0);
        assertEquals("Wed", printer("E").format(c));
        assertEquals("Wed", printer("EEE").format(c));
        assertEquals("Wednesday", printer("EEEE").format(c));
    }

    // -------------------------------------------------------------
    // Era
    // -------------------------------------------------------------

    @Test
    public void testEraField() {
        Calendar c = calendar(GMT, 2021, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals("AD", printer("G").format(c));
    }

    // -------------------------------------------------------------
    // Time zone number fields Z / ZZ
    // -------------------------------------------------------------

    @Test
    public void testTimeZoneNumberNoColon() {
        TimeZone tz = TimeZone.getTimeZone("Etc/GMT+5");
        FastDatePrinter p = new FastDatePrinter("Z", tz, Locale.US);
        Calendar c = calendar(tz, 2021, Calendar.JUNE, 15, 10, 0, 0, 0);
        assertEquals("-0500", p.format(c));
    }

    @Test
    public void testTimeZoneNumberWithColon() {
        TimeZone tz = TimeZone.getTimeZone("Etc/GMT+5");
        FastDatePrinter p = new FastDatePrinter("ZZ", tz, Locale.US);
        Calendar c = calendar(tz, 2021, Calendar.JUNE, 15, 10, 0, 0, 0);
        assertEquals("-05:00", p.format(c));
    }

    @Test
    public void testTimeZoneNumberPositiveOffset() {
        TimeZone tz = TimeZone.getTimeZone("Etc/GMT-5");
        FastDatePrinter p = new FastDatePrinter("Z", tz, Locale.US);
        Calendar c = calendar(tz, 2021, Calendar.JUNE, 15, 10, 0, 0, 0);
        assertEquals("+0500", p.format(c));
    }

    // -------------------------------------------------------------
    // Literal text / quoting
    // -------------------------------------------------------------

    @Test
    public void testLiteralQuotedText() {
        FastDatePrinter p = printer("'Year:' yyyy");
        Calendar c = calendar(GMT, 2021, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals("Year: 2021", p.format(c));
    }

    @Test
    public void testEscapedSingleQuoteLiteral() {
        FastDatePrinter p = printer("''");
        Calendar c = calendar(GMT, 2021, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals("'", p.format(c));
    }

    @Test
    public void testEscapedQuoteWithinLiteralText() {
        FastDatePrinter p = printer("'it''s'");
        Calendar c = calendar(GMT, 2021, Calendar.JANUARY, 1, 0, 0, 0, 0);
        assertEquals("it's", p.format(c));
    }

    @Test
    public void testFullPatternCombiningLiteralsAndFields() {
        FastDatePrinter p = printer("yyyy-MM-dd'T'HH:mm:ss");
        Calendar c = calendar(GMT, 2021, Calendar.JUNE, 15, 14, 30, 5, 0);
        assertEquals("2021-06-15T14:30:05", p.format(c));
    }

    // -------------------------------------------------------------
    // Invalid pattern
    // -------------------------------------------------------------

    @Test
    public void testInvalidPatternLetterThrows() {
        try {
            printer("L");
            fail("Expected IllegalArgumentException for unsupported pattern letter");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    // -------------------------------------------------------------
    // format(Object, StringBuffer, FieldPosition)
    // -------------------------------------------------------------

    @Test
    public void testFormatObjectWithDate() {
        FastDatePrinter p = printer("yyyy-MM-dd");
        Calendar c = calendar(GMT, 2021, Calendar.JANUARY, 2, 0, 0, 0, 0);
        StringBuffer buf = new StringBuffer();
        p.format(c.getTime(), buf, new FieldPosition(0));
        assertEquals("2021-01-02", buf.toString());
    }

    @Test
    public void testFormatObjectWithCalendar() {
        FastDatePrinter p = printer("yyyy-MM-dd");
        Calendar c = calendar(GMT, 2021, Calendar.JANUARY, 2, 0, 0, 0, 0);
        StringBuffer buf = new StringBuffer();
        p.format((Object) c, buf, new FieldPosition(0));
        assertEquals("2021-01-02", buf.toString());
    }

    @Test
    public void testFormatObjectWithLong() {
        FastDatePrinter p = printer("yyyy-MM-dd");
        Calendar c = calendar(GMT, 2021, Calendar.JANUARY, 2, 0, 0, 0, 0);
        StringBuffer buf = new StringBuffer();
        p.format(Long.valueOf(c.getTime().getTime()), buf, new FieldPosition(0));
        assertEquals("2021-01-02", buf.toString());
    }

    @Test
    public void testFormatObjectWithUnsupportedTypeThrows() {
        FastDatePrinter p = printer("yyyy-MM-dd");
        try {
            p.format("not a date", new StringBuffer(), new FieldPosition(0));
            fail("Expected IllegalArgumentException for unsupported object type");
        } catch (IllegalArgumentException expected) {
            assertTrue(expected.getMessage().indexOf("String") >= 0);
        }
    }

    @Test
    public void testFormatObjectWithNullThrows() {
        FastDatePrinter p = printer("yyyy-MM-dd");
        try {
            p.format(null, new StringBuffer(), new FieldPosition(0));
            fail("Expected IllegalArgumentException for null object");
        } catch (IllegalArgumentException expected) {
            assertTrue(expected.getMessage().indexOf("<null>") >= 0);
        }
    }

    // -------------------------------------------------------------
    // Accessors
    // -------------------------------------------------------------

    @Test
    public void testAccessors() {
        TimeZone tz = TimeZone.getTimeZone("Etc/GMT+5");
        FastDatePrinter p = new FastDatePrinter("yyyy-MM-dd", tz, Locale.US);
        assertEquals("yyyy-MM-dd", p.getPattern());
        assertEquals(tz, p.getTimeZone());
        assertEquals(Locale.US, p.getLocale());
        assertTrue(p.getMaxLengthEstimate() >= "2021-06-15".length());
    }

    @Test
    public void testMaxLengthEstimateIsNotExceededByActualOutput() {
        FastDatePrinter p = printer("EEEE, MMMM d, yyyy HH:mm:ss.SSS zzzz");
        Calendar c = calendar(GMT, 2021, Calendar.JUNE, 16, 14, 30, 5, 123);
        String formatted = p.format(c);
        assertTrue("formatted length " + formatted.length() + " should not exceed estimate "
                + p.getMaxLengthEstimate(), formatted.length() <= p.getMaxLengthEstimate());
    }

    // -------------------------------------------------------------
    // equals / hashCode / toString
    // -------------------------------------------------------------

    @Test
    public void testEqualsAndHashCodeForEquivalentInstances() {
        FastDatePrinter p1 = new FastDatePrinter("yyyy-MM-dd", GMT, Locale.US);
        FastDatePrinter p2 = new FastDatePrinter("yyyy-MM-dd", GMT, Locale.US);
        assertTrue(p1.equals(p2));
        assertTrue(p2.equals(p1));
        assertEquals(p1.hashCode(), p2.hashCode());
    }

    @Test
    public void testEqualsReturnsFalseForDifferentPattern() {
        FastDatePrinter p1 = new FastDatePrinter("yyyy-MM-dd", GMT, Locale.US);
        FastDatePrinter p2 = new FastDatePrinter("MM/dd/yyyy", GMT, Locale.US);
        assertFalse(p1.equals(p2));
    }

    @Test
    public void testEqualsReturnsFalseForDifferentTimeZone() {
        FastDatePrinter p1 = new FastDatePrinter("yyyy-MM-dd", GMT, Locale.US);
        FastDatePrinter p2 = new FastDatePrinter("yyyy-MM-dd", TimeZone.getTimeZone("Etc/GMT+5"), Locale.US);
        assertFalse(p1.equals(p2));
    }

    @Test
    public void testEqualsReturnsFalseForDifferentLocale() {
        FastDatePrinter p1 = new FastDatePrinter("yyyy-MM-dd", GMT, Locale.US);
        FastDatePrinter p2 = new FastDatePrinter("yyyy-MM-dd", GMT, Locale.FRANCE);
        assertFalse(p1.equals(p2));
    }

    @Test
    public void testEqualsReturnsFalseForNullAndUnrelatedType() {
        FastDatePrinter p1 = new FastDatePrinter("yyyy-MM-dd", GMT, Locale.US);
        assertFalse(p1.equals(null));
        assertFalse(p1.equals("yyyy-MM-dd"));
    }

    @Test
    public void testToStringContainsPatternLocaleAndTimeZoneId() {
        FastDatePrinter p = new FastDatePrinter("yyyy", GMT, Locale.US);
        String s = p.toString();
        assertTrue(s.indexOf("yyyy") >= 0);
        assertTrue(s.indexOf("GMT") >= 0);
    }

    // -------------------------------------------------------------
    // Serialization
    // -------------------------------------------------------------

    @Test
    public void testSerializationRoundTripStillFormats() throws Exception {
        FastDatePrinter original = new FastDatePrinter("yyyy-MM-dd", GMT, Locale.US);

        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(bos);
        oos.writeObject(original);
        oos.close();

        ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(bos.toByteArray()));
        FastDatePrinter copy = (FastDatePrinter) ois.readObject();
        ois.close();

        assertEquals(original, copy);
        Calendar c = calendar(GMT, 2021, Calendar.JUNE, 15, 0, 0, 0, 0);
        assertEquals(original.format(c), copy.format(c));
        assertEquals("2021-06-15", copy.format(c));
    }

    // -------------------------------------------------------------
    // Protected helper methods (same package access)
    // -------------------------------------------------------------

    @Test
    public void testParsePatternProducesOneRulePerToken() {
        FastDatePrinter p = printer("yyyy-MM-dd");
        List<?> rules = p.parsePattern();
        // y y y y, literal '-', M M, literal '-', d d -> 5 rule objects
        assertEquals(5, rules.size());
    }

    @Test
    public void testParseTokenReadsRunOfSameLetter() {
        FastDatePrinter p = printer("yyyy-MM-dd");
        int[] indexRef = new int[] {0};
        String token = p.parseToken("yyyy-MM-dd", indexRef);
        assertEquals("yyyy", token);
        assertEquals(3, indexRef[0]);
    }

    @Test
    public void testSelectNumberRuleRejectsPaddingBelowThree() {
        FastDatePrinter p = printer("yyyy");
        try {
            p.selectNumberRule(Calendar.YEAR, 0);
            fail("Expected IllegalArgumentException for padding < 3 that is not 1 or 2");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    // -------------------------------------------------------------
    // Documented null-argument contract on the constructor
    // -------------------------------------------------------------

    @Test
    public void testConstructorThrowsNpeForNullPattern() {
        try {
            new FastDatePrinter(null, GMT, Locale.US);
            fail("Expected NullPointerException for null pattern, per class javadoc");
        } catch (NullPointerException expected) {
            // expected
        }
    }

    @Test
    public void testConstructorThrowsNpeForNullLocale() {
        try {
            new FastDatePrinter("yyyy-MM-dd", GMT, null);
            fail("Expected NullPointerException for null locale, per class javadoc");
        } catch (NullPointerException expected) {
            // expected
        }
    }

    @Test
    public void testConstructorThrowsNpeForNullTimeZone() {
        // The class javadoc states: "@throws NullPointerException if pattern,
        // timeZone, or locale is null." A pattern that does not reference the
        // time zone at all must still be rejected up front according to that
        // contract.
        try {
            new FastDatePrinter("yyyy-MM-dd", null, Locale.US);
            fail("Expected NullPointerException for null timeZone, per class javadoc");
        } catch (NullPointerException expected) {
            // expected
        }
    }
}
