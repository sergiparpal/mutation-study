/*
 * Copyright (C) 2010 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.gson.stream;

import java.io.EOFException;
import java.io.IOException;
import java.io.StringReader;
import junit.framework.TestCase;

@SuppressWarnings("resource")
public class JsonReaderAgentTest extends TestCase {

  public void testNullConstructorArgument() {
    try {
      new JsonReader(null);
      fail();
    } catch (NullPointerException expected) {
    }
  }

  public void testReadEmptyObject() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("{}"));
    reader.beginObject();
    assertFalse(reader.hasNext());
    reader.endObject();
    assertEquals(JsonToken.END_DOCUMENT, reader.peek());
  }

  public void testReadEmptyArray() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[]"));
    reader.beginArray();
    assertFalse(reader.hasNext());
    reader.endArray();
  }

  public void testReadObjectValues() throws IOException {
    JsonReader reader = new JsonReader(new StringReader(
        "{\"a\":1,\"b\":true,\"c\":\"hello\",\"d\":null,\"e\":2.5}"));
    reader.beginObject();
    assertEquals("a", reader.nextName());
    assertEquals(1, reader.nextInt());
    assertEquals("b", reader.nextName());
    assertTrue(reader.nextBoolean());
    assertEquals("c", reader.nextName());
    assertEquals("hello", reader.nextString());
    assertEquals("d", reader.nextName());
    reader.nextNull();
    assertEquals("e", reader.nextName());
    assertEquals(2.5, reader.nextDouble());
    reader.endObject();
  }

  public void testReadArrayOfValues() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1,2,3]"));
    reader.beginArray();
    assertTrue(reader.hasNext());
    assertEquals(1, reader.nextInt());
    assertEquals(2, reader.nextInt());
    assertEquals(3, reader.nextInt());
    assertFalse(reader.hasNext());
    reader.endArray();
  }

  public void testNestedArraysAndObjects() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[{\"a\":[1,2]},{}]"));
    reader.beginArray();
    reader.beginObject();
    assertEquals("a", reader.nextName());
    reader.beginArray();
    assertEquals(1, reader.nextInt());
    assertEquals(2, reader.nextInt());
    reader.endArray();
    reader.endObject();
    reader.beginObject();
    reader.endObject();
    reader.endArray();
  }

  public void testPeekDoesNotConsume() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[42]"));
    reader.beginArray();
    assertEquals(JsonToken.NUMBER, reader.peek());
    assertEquals(JsonToken.NUMBER, reader.peek());
    assertEquals(42, reader.nextInt());
  }

  public void testNextLongExact() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[9223372036854775807]"));
    reader.beginArray();
    assertEquals(Long.MAX_VALUE, reader.nextLong());
  }

  public void testNextLongMinValue() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[-9223372036854775808]"));
    reader.beginArray();
    assertEquals(Long.MIN_VALUE, reader.nextLong());
  }

  public void testNextIntOverflowThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[3000000000]"));
    reader.beginArray();
    try {
      reader.nextInt();
      fail();
    } catch (NumberFormatException expected) {
    }
  }

  public void testNextStringAcceptsNumber() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[123]"));
    reader.beginArray();
    assertEquals("123", reader.nextString());
  }

  public void testNextIntAcceptsQuotedValue() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[\"123\"]"));
    reader.beginArray();
    assertEquals(123, reader.nextInt());
  }

  public void testMismatchedTypeThrowsNumberFormatException() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[\"a\"]"));
    reader.beginArray();
    try {
      reader.nextInt();
      fail();
    } catch (NumberFormatException expected) {
    }
  }

  public void testBeginArrayOnObjectThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("{}"));
    try {
      reader.beginArray();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testEndArrayTooEarlyThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1,2]"));
    reader.beginArray();
    try {
      reader.endArray();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testUnterminatedArrayThrowsMalformedJson() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1,2"));
    reader.beginArray();
    reader.nextInt();
    reader.nextInt();
    try {
      reader.hasNext();
      fail();
    } catch (EOFException expected) {
    }
  }

  public void testNonLenientTopLevelStringThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("\"hello\""));
    try {
      reader.nextString();
      fail();
    } catch (IOException expected) {
    }
  }

  public void testLenientTopLevelString() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("hello"));
    reader.setLenient(true);
    assertEquals("hello", reader.nextString());
  }

  public void testLenientAllowsUnquotedNamesAndValues() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("{a:b}"));
    reader.setLenient(true);
    reader.beginObject();
    assertEquals("a", reader.nextName());
    assertEquals("b", reader.nextString());
    reader.endObject();
  }

  public void testStrictRejectsUnquotedNames() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("{a:\"b\"}"));
    reader.beginObject();
    try {
      reader.nextName();
      fail();
    } catch (IOException expected) {
    }
  }

  public void testSkipValueSkipsNestedObject() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[{\"a\":[1,2,3]},2]"));
    reader.beginArray();
    reader.skipValue();
    assertEquals(2, reader.nextInt());
    reader.endArray();
  }

  public void testIsLenientDefaultsFalse() {
    JsonReader reader = new JsonReader(new StringReader("[]"));
    assertFalse(reader.isLenient());
    reader.setLenient(true);
    assertTrue(reader.isLenient());
  }

  public void testCloseMakesSubsequentCallsThrow() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1,2]"));
    reader.beginArray();
    reader.close();
    try {
      reader.nextInt();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testStringEscapes() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[\"a\\tb\\nc\\\"d\\\\e\\u0041\"]"));
    reader.beginArray();
    assertEquals("a\tb\nc\"d\\eA", reader.nextString());
  }

  public void testGetPathAfterReadingTokens() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("{\"a\":[1,2]}"));
    assertEquals("$", reader.getPath());
    reader.beginObject();
    reader.nextName();
    reader.beginArray();
    reader.nextInt();
    assertEquals("$.a[1]", reader.getPath());
  }

  public void testEmptyDocumentThrowsOnFirstPeek() throws IOException {
    JsonReader reader = new JsonReader(new StringReader(""));
    try {
      reader.peek();
      fail();
    } catch (EOFException expected) {
    }
  }

  public void testTopLevelScalarStrictThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("1 2"));
    try {
      reader.nextInt();
      fail();
    } catch (IOException expected) {
    }
  }

  public void testMultipleTopLevelValuesLenientAllowed() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("1 2"));
    reader.setLenient(true);
    assertEquals(1, reader.nextInt());
    assertEquals(2, reader.nextInt());
  }

  public void testNextDoubleRejectsNanStrict() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[NaN]"));
    reader.beginArray();
    try {
      reader.nextDouble();
      fail();
    } catch (MalformedJsonException expected) {
    }
  }
}
