/*
 * Copyright (C) 2010 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.gson.stream;

import java.io.IOException;
import java.io.StringWriter;
import junit.framework.TestCase;

public class JsonWriterAgentTest extends TestCase {

  public void testNullConstructorArgument() {
    try {
      new JsonWriter(null);
      fail();
    } catch (NullPointerException expected) {
    }
  }

  public void testWriteEmptyObject() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginObject();
    writer.endObject();
    writer.close();
    assertEquals("{}", stringWriter.toString());
  }

  public void testWriteEmptyArray() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.endArray();
    writer.close();
    assertEquals("[]", stringWriter.toString());
  }

  public void testWriteObjectWithValues() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginObject();
    writer.name("a").value(1);
    writer.name("b").value(true);
    writer.name("c").value("hello");
    writer.name("d").nullValue();
    writer.endObject();
    writer.close();
    assertEquals("{\"a\":1,\"b\":true,\"c\":\"hello\",\"d\":null}", stringWriter.toString());
  }

  public void testWriteArrayOfValues() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.value(1);
    writer.value(2.5);
    writer.value("x");
    writer.endArray();
    writer.close();
    assertEquals("[1,2.5,\"x\"]", stringWriter.toString());
  }

  public void testNestedArraysAndObjects() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.beginObject();
    writer.name("a");
    writer.beginArray();
    writer.value(1);
    writer.value(2);
    writer.endArray();
    writer.endObject();
    writer.endArray();
    writer.close();
    assertEquals("[{\"a\":[1,2]}]", stringWriter.toString());
  }

  public void testMismatchedEndObjectThrows() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    try {
      writer.endObject();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testTopLevelValueStrictThrows() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    try {
      writer.value(1);
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testLenientAllowsTopLevelValue() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setLenient(true);
    writer.value(1);
    writer.close();
    assertEquals("1", stringWriter.toString());
  }

  public void testNanThrowsForDouble() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    try {
      writer.value(Double.NaN);
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  public void testInfinityThrowsForDouble() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    try {
      writer.value(Double.POSITIVE_INFINITY);
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  public void testNanAllowedWhenLenient() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setLenient(true);
    writer.value(Double.NaN);
    writer.close();
    assertEquals("NaN", stringWriter.toString());
  }

  public void testNameWithNullThrows() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginObject();
    try {
      writer.name(null);
      fail();
    } catch (NullPointerException expected) {
    }
  }

  public void testDanglingNameThrowsOnClose() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginObject();
    writer.name("a");
    try {
      writer.endObject();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testCloseWithIncompleteDocumentThrows() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    try {
      writer.close();
      fail();
    } catch (IOException expected) {
    }
  }

  public void testStringEscaping() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.value("a\"b\\c\nd\te");
    writer.endArray();
    writer.close();
    assertEquals("[\"a\\\"b\\\\c\\nd\\te\"]", stringWriter.toString());
  }

  public void testHtmlSafeEscaping() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setHtmlSafe(true);
    writer.beginArray();
    writer.value("<html>&amp;</html>");
    writer.endArray();
    writer.close();
    String result = stringWriter.toString();
    assertTrue(result.indexOf("<") == -1);
    assertTrue(result.indexOf(">") == -1);
    assertTrue(result.indexOf("&") == -1);
  }

  public void testSerializeNullsFalseOmitsNullMembers() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setSerializeNulls(false);
    writer.beginObject();
    writer.name("a").nullValue();
    writer.name("b").value(1);
    writer.endObject();
    writer.close();
    assertEquals("{\"b\":1}", stringWriter.toString());
  }

  public void testGetSerializeNullsDefaultsTrue() throws IOException {
    JsonWriter writer = new JsonWriter(new StringWriter());
    assertTrue(writer.getSerializeNulls());
    writer.setSerializeNulls(false);
    assertFalse(writer.getSerializeNulls());
  }

  public void testSetIndentPrettyPrints() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setIndent("  ");
    writer.beginObject();
    writer.name("a").value(1);
    writer.endObject();
    writer.close();
    assertEquals("{\n  \"a\": 1\n}", stringWriter.toString());
  }

  public void testFlushAfterCloseThrows() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.endArray();
    writer.close();
    try {
      writer.flush();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testValueMethodsReturnThisForChaining() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    JsonWriter result = writer.beginArray().value(1).value("x").value(true);
    assertSame(writer, result);
    writer.endArray();
    writer.close();
  }

  public void testIsLenientDefaultsFalse() {
    JsonWriter writer = new JsonWriter(new StringWriter());
    assertFalse(writer.isLenient());
    writer.setLenient(true);
    assertTrue(writer.isLenient());
  }

  public void testIsHtmlSafeDefaultsFalse() {
    JsonWriter writer = new JsonWriter(new StringWriter());
    assertFalse(writer.isHtmlSafe());
    writer.setHtmlSafe(true);
    assertTrue(writer.isHtmlSafe());
  }

  public void testJsonValueWritesRawContent() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.jsonValue("{\"x\":1}");
    writer.endArray();
    writer.close();
    assertEquals("[{\"x\":1}]", stringWriter.toString());
  }
}
