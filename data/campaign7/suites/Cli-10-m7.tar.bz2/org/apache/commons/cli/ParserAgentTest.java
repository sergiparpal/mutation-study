/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.cli;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import junit.framework.TestCase;

/**
 * Self-contained tests for {@link Parser}, exercising its token-handling,
 * properties-processing and required-option logic directly through a
 * minimal concrete subclass that performs no flattening of its own.
 */
public class ParserAgentTest extends TestCase
{
    /**
     * Minimal concrete {@link Parser} whose flatten() is the identity
     * function, so that only Parser's own logic is under test.
     */
    private static class SimpleParser extends Parser
    {
        protected String[] flatten(Options opts, String[] arguments,
                                    boolean stopAtNonOption)
        {
            return arguments;
        }
    }

    public ParserAgentTest(String name)
    {
        super(name);
    }

    private SimpleParser parser;

    public void setUp()
    {
        parser = new SimpleParser();
    }

    public void testParseSimple() throws Exception
    {
        Options options = new Options().addOption("a", false, "a flag")
                                        .addOption("b", true, "b value");

        CommandLine cl = parser.parse(options, new String[] { "-a", "-b", "val", "foo" });

        assertTrue(cl.hasOption("a"));
        assertTrue(cl.hasOption("b"));
        assertEquals("val", cl.getOptionValue("b"));
        assertEquals(1, cl.getArgList().size());
        assertEquals("foo", cl.getArgList().get(0));
    }

    public void testParseNullArgumentsTreatedAsEmpty() throws Exception
    {
        Options options = new Options().addOption("a", false, "a flag");

        CommandLine cl = parser.parse(options, null);

        assertFalse(cl.hasOption("a"));
        assertEquals(0, cl.getArgList().size());
        assertEquals(0, cl.getArgs().length);
    }

    public void testParseEmptyArguments() throws Exception
    {
        Options options = new Options().addOption("a", false, "a flag");

        CommandLine cl = parser.parse(options, new String[0]);

        assertNotNull(cl);
        assertEquals(0, cl.getArgList().size());
    }

    public void testUnrecognizedOptionThrows()
    {
        Options options = new Options().addOption("a", false, "a flag");

        try
        {
            parser.parse(options, new String[] { "-z" });
            fail("Expected UnrecognizedOptionException");
        }
        catch (UnrecognizedOptionException e)
        {
            assertTrue(e.getMessage().indexOf("-z") >= 0);
        }
        catch (ParseException e)
        {
            fail("Expected UnrecognizedOptionException, got " + e);
        }
    }

    public void testMissingArgumentThrows()
    {
        Options options = new Options().addOption("b", true, "b value");

        try
        {
            parser.parse(options, new String[] { "-b" });
            fail("Expected MissingArgumentException");
        }
        catch (MissingArgumentException e)
        {
            // expected
        }
        catch (ParseException e)
        {
            fail("Expected MissingArgumentException, got " + e);
        }
    }

    public void testMissingArgumentNotThrownForOptionalArg() throws Exception
    {
        Option opt = new Option("b", true, "b value");
        opt.setOptionalArg(true);
        Options options = new Options().addOption(opt);

        CommandLine cl = parser.parse(options, new String[] { "-b" });

        assertTrue(cl.hasOption("b"));
        assertNull(cl.getOptionValue("b"));
    }

    public void testMissingSingleRequiredOption()
    {
        Option required = new Option("r", false, "required flag");
        required.setRequired(true);
        Options options = new Options().addOption(required);

        try
        {
            parser.parse(options, new String[0]);
            fail("Expected MissingOptionException");
        }
        catch (MissingOptionException e)
        {
            assertTrue(e.getMessage().startsWith("Missing required option"));
            assertFalse(e.getMessage().startsWith("Missing required options"));
            assertTrue(e.getMessage().indexOf("r") >= 0);
        }
        catch (ParseException e)
        {
            fail("Expected MissingOptionException, got " + e);
        }
    }

    public void testMissingMultipleRequiredOptionsUsesPlural()
    {
        Option r1 = new Option("r", false, "required flag 1");
        r1.setRequired(true);
        Option r2 = new Option("s", false, "required flag 2");
        r2.setRequired(true);
        Options options = new Options().addOption(r1).addOption(r2);

        try
        {
            parser.parse(options, new String[0]);
            fail("Expected MissingOptionException");
        }
        catch (MissingOptionException e)
        {
            assertTrue(e.getMessage().startsWith("Missing required options"));
        }
        catch (ParseException e)
        {
            fail("Expected MissingOptionException, got " + e);
        }
    }

    public void testRequiredOptionSatisfiedDoesNotThrow() throws Exception
    {
        Option required = new Option("r", false, "required flag");
        required.setRequired(true);
        Options options = new Options().addOption(required);

        CommandLine cl = parser.parse(options, new String[] { "-r" });

        assertTrue(cl.hasOption("r"));
    }

    public void testRequiredOptionGroupSatisfiedByOneMember() throws Exception
    {
        Option a = new Option("a", false, "a");
        Option b = new Option("b", false, "b");
        OptionGroup group = new OptionGroup();
        group.addOption(a);
        group.addOption(b);
        group.setRequired(true);

        Options options = new Options().addOptionGroup(group);

        CommandLine cl = parser.parse(options, new String[] { "-a" });

        assertTrue(cl.hasOption("a"));
        assertFalse(cl.hasOption("b"));
        assertEquals("a", group.getSelected());
    }

    public void testRequiredOptionGroupUnsatisfiedThrows()
    {
        Option a = new Option("a", false, "a");
        Option b = new Option("b", false, "b");
        OptionGroup group = new OptionGroup();
        group.addOption(a);
        group.addOption(b);
        group.setRequired(true);

        Options options = new Options().addOptionGroup(group);

        try
        {
            parser.parse(options, new String[0]);
            fail("Expected MissingOptionException");
        }
        catch (MissingOptionException e)
        {
            // expected
        }
        catch (ParseException e)
        {
            fail("Expected MissingOptionException, got " + e);
        }
    }

    public void testDoubleDashStopsOptionProcessing() throws Exception
    {
        Options options = new Options().addOption("a", false, "a flag")
                                        .addOption("b", true, "b value");

        CommandLine cl = parser.parse(options, new String[] { "-a", "--", "-b", "val" });

        assertTrue(cl.hasOption("a"));
        assertFalse(cl.hasOption("b"));
        assertEquals(2, cl.getArgList().size());
        assertEquals("-b", cl.getArgList().get(0));
        assertEquals("val", cl.getArgList().get(1));
    }

    public void testOnlyFirstDoubleDashIsConsumed() throws Exception
    {
        Options options = new Options().addOption("a", false, "a flag");

        CommandLine cl = parser.parse(options, new String[] { "--", "--", "foo" });

        // the first "--" triggers eat-the-rest and is never added itself;
        // any further "--" encountered while eating the rest is dropped too
        assertEquals(1, cl.getArgList().size());
        assertEquals("foo", cl.getArgList().get(0));
    }

    public void testSingleDashAddedAsArgumentWhenNotStopping() throws Exception
    {
        Options options = new Options().addOption("a", false, "a flag");

        CommandLine cl = parser.parse(options, new String[] { "-a", "-" });

        assertTrue(cl.hasOption("a"));
        assertEquals(1, cl.getArgList().size());
        assertEquals("-", cl.getArgList().get(0));
    }

    public void testSingleDashTriggersStopWithoutBeingKept() throws Exception
    {
        Options options = new Options().addOption("a", false, "a flag");

        CommandLine cl = parser.parse(options, new String[] { "-", "foo", "bar" }, true);

        // the triggering "-" token itself is not added to the arg list,
        // only the tokens that follow it
        assertEquals(2, cl.getArgList().size());
        assertEquals("foo", cl.getArgList().get(0));
        assertEquals("bar", cl.getArgList().get(1));
    }

    public void testStopAtNonOptionKeepsUnknownLookingOption() throws Exception
    {
        Options options = new Options().addOption("a", false, "a flag");

        CommandLine cl = parser.parse(options, new String[] { "foo", "-z" }, true);

        assertFalse(cl.hasOption("a"));
        assertEquals(2, cl.getArgList().size());
        assertEquals("foo", cl.getArgList().get(0));
        assertEquals("-z", cl.getArgList().get(1));
    }

    public void testStopAtNonOptionFalseStillThrowsForUnknownOption()
    {
        Options options = new Options().addOption("a", false, "a flag");

        try
        {
            parser.parse(options, new String[] { "foo", "-z" }, false);
            fail("Expected UnrecognizedOptionException");
        }
        catch (UnrecognizedOptionException e)
        {
            // expected: "foo" is just collected as an arg, then "-z" is
            // still processed as an (unknown) option since stopAtNonOption
            // is false
        }
        catch (ParseException e)
        {
            fail("Expected UnrecognizedOptionException, got " + e);
        }
    }

    public void testProcessPropertiesSetsOptionNotOnCommandLine() throws Exception
    {
        Options options = new Options().addOption("a", false, "a flag")
                                        .addOption("b", true, "b value");

        Properties props = new Properties();
        props.setProperty("b", "fromProps");

        CommandLine cl = parser.parse(options, new String[0], props);

        assertTrue(cl.hasOption("b"));
        assertEquals("fromProps", cl.getOptionValue("b"));
    }

    public void testProcessPropertiesDoesNotOverrideCommandLineValue() throws Exception
    {
        Options options = new Options().addOption("b", true, "b value");

        Properties props = new Properties();
        props.setProperty("b", "fromProps");

        CommandLine cl = parser.parse(options, new String[] { "-b", "fromArgs" }, props);

        assertEquals("fromArgs", cl.getOptionValue("b"));
    }

    public void testProcessPropertiesFlagRequiresTrueYesOrOne() throws Exception
    {
        Options options = new Options().addOption("a", false, "a flag");

        Properties noProps = new Properties();
        noProps.setProperty("a", "no");
        CommandLine cl = parser.parse(options, new String[0], noProps);
        assertFalse(cl.hasOption("a"));

        parser = new SimpleParser();
        Properties yesProps = new Properties();
        yesProps.setProperty("a", "yes");
        cl = parser.parse(options, new String[0], yesProps);
        assertTrue(cl.hasOption("a"));

        parser = new SimpleParser();
        Properties oneProps = new Properties();
        oneProps.setProperty("a", "1");
        cl = parser.parse(options, new String[0], oneProps);
        assertTrue(cl.hasOption("a"));
    }

    public void testProcessPropertiesIgnoresUnknownOptionValue()
    {
        Options options = new Options().addOption("a", false, "a flag");

        Properties props = new Properties();
        // "z" is not a defined option; getOption("z") returns null inside
        // processProperties, which must not blow up parse() with an NPE
        // other than what the implementation itself would raise -- guard
        // the assertion against either outcome being a clean ParseException
        props.setProperty("z", "true");

        try
        {
            parser.parse(options, new String[0], props);
            fail("Expected an exception for an unknown property option");
        }
        catch (RuntimeException expected)
        {
            // NullPointerException from Options.getOption("z") returning null
        }
        catch (ParseException expected)
        {
            // also acceptable if a future implementation guards this case
        }
    }

    public void testProcessArgsDirectlyCollectsValuesUntilNextOption() throws Exception
    {
        Options options = new Options().addOption("a", false, "a flag")
                                        .addOption("b", true, "b value");
        parser.setOptions(options);

        List tokens = new ArrayList();
        tokens.add("val1");
        tokens.add("-a");

        Option b = options.getOption("b");
        parser.processArgs(b, tokens.listIterator());

        assertEquals("val1", b.getValue());
    }

    public void testProcessArgsDirectlyThrowsWhenNoValueAvailable()
    {
        Options options = new Options().addOption("a", false, "a flag")
                                        .addOption("b", true, "b value");
        parser.setOptions(options);

        List tokens = new ArrayList();
        tokens.add("-a");

        Option b = options.getOption("b");

        try
        {
            parser.processArgs(b, tokens.listIterator());
            fail("Expected MissingArgumentException");
        }
        catch (MissingArgumentException e)
        {
            // expected
        }
        catch (ParseException e)
        {
            fail("Expected MissingArgumentException, got " + e);
        }
    }

    public void testSetOptionsAndGetOptionsAccessors()
    {
        Options options = new Options().addOption("a", false, "a flag");

        assertNull(parser.getOptions());

        parser.setOptions(options);

        assertSame(options, parser.getOptions());
        assertNotNull(parser.getRequiredOptions());
        assertEquals(0, parser.getRequiredOptions().size());
    }

    public void testGetRequiredOptionsReflectsRequiredOptionList()
    {
        Option required = new Option("r", false, "required flag");
        required.setRequired(true);
        Options options = new Options().addOption(required);

        parser.setOptions(options);

        assertEquals(1, parser.getRequiredOptions().size());
    }

    public void testParseClearsPreviousOptionValuesBetweenCalls() throws Exception
    {
        Options options = new Options().addOption("b", true, "b value");

        CommandLine first = parser.parse(options, new String[] { "-b", "first" });
        assertEquals("first", first.getOptionValue("b"));

        CommandLine second = parser.parse(options, new String[0]);
        assertFalse(second.hasOption("b"));
        assertNull(options.getOption("b").getValue());
    }
}
