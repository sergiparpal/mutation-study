/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang.time;

import java.text.DateFormat;
import java.text.FieldPosition;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

import junit.framework.TestCase;

/**
 * Self-contained tests for {@link FastDateFormat}.
 */
public class FastDateFormatAgentTest extends TestCase {

    public FastDateFormatAgentTest(String name) {
        super(name);
    }

    private Date buildDate(TimeZone zone, int year, int month, int day,
            int hour, int minute, int second, int millis) {
        Calendar cal = new GregorianCalendar(zone);
        cal.clear();
        cal.set(year, month, day, hour, minute, second);
        cal.set(Calendar.MILLISECOND, millis);
        return cal.getTime();
    }

    //-----------------------------------------------------------------------
    // Basic formatting, cross-checked against SimpleDateFormat
    //-----------------------------------------------------------------------

    public void testFormatDateMatchesSimpleDateFormat() throws Exception {
        String pattern = "yyyy-MM-dd HH:mm:ss.SSS EEE G a";
        TimeZone[] zones = {
            TimeZone.getTimeZone("GMT+02:00"),
            TimeZone.getTimeZone("GMT-05:00"),
            TimeZone.getTimeZone("America/Los_Angeles"),
        };
        for (int i = 0; i < zones.length; i++) {
            TimeZone zone = zones[i];
            Date[] dates = {
                buildDate(zone, 2023, Calendar.MARCH, 15, 13, 45, 9, 123),
                buildDate(zone, 2024, Calendar.FEBRUARY, 29, 0, 0, 0, 0),
                buildDate(zone, 1999, Calendar.DECEMBER, 31, 23, 59, 59, 999),
                buildDate(zone, 1970, Calendar.JANUARY, 1, 0, 0, 0, 0),
            };
            FastDateFormat fdf = FastDateFormat.getInstance(pattern, zone, Locale.US);
            SimpleDateFormat sdf = new SimpleDateFormat(pattern, Locale.US);
            sdf.setTimeZone(zone);
            for (int j = 0; j < dates.length; j++) {
                assertEquals("zone=" + zone + " date=" + dates[j],
                        sdf.format(dates[j]), fdf.format(dates[j]));
            }
        }
    }

    public void testHourFieldsMatchSimpleDateFormat() {
        String pattern = "hh HH kk KK a";
        TimeZone zone = TimeZone.getTimeZone("UTC");
        FastDateFormat fdf = FastDateFormat.getInstance(pattern, zone, Locale.US);
        SimpleDateFormat sdf = new SimpleDateFormat(pattern, Locale.US);
        sdf.setTimeZone(zone);

        Date midnight = buildDate(zone, 2023, Calendar.JUNE, 1, 0, 0, 0, 0);
        Date noon = buildDate(zone, 2023, Calendar.JUNE, 1, 12, 0, 0, 0);
        Date afternoon = buildDate(zone, 2023, Calendar.JUNE, 1, 13, 30, 0, 0);

        assertEquals(sdf.format(midnight), fdf.format(midnight));
        assertEquals(sdf.format(noon), fdf.format(noon));
        assertEquals(sdf.format(afternoon), fdf.format(afternoon));
    }

    public void testTwoDigitYearMatchesSimpleDateFormat() {
        TimeZone zone = TimeZone.getTimeZone("UTC");
        FastDateFormat fdf = FastDateFormat.getInstance("yy", zone, Locale.US);
        SimpleDateFormat sdf = new SimpleDateFormat("yy", Locale.US);
        sdf.setTimeZone(zone);

        Date d2005 = buildDate(zone, 2005, Calendar.JANUARY, 1, 0, 0, 0, 0);
        Date d1999 = buildDate(zone, 1999, Calendar.JANUARY, 1, 0, 0, 0, 0);
        Date d2000 = buildDate(zone, 2000, Calendar.JANUARY, 1, 0, 0, 0, 0);

        assertEquals(sdf.format(d2005), fdf.format(d2005));
        assertEquals(sdf.format(d1999), fdf.format(d1999));
        assertEquals(sdf.format(d2000), fdf.format(d2000));
        assertEquals("05", fdf.format(d2005));
        assertEquals("00", fdf.format(d2000));
    }

    public void testUnpaddedMonthAndDayMatchSimpleDateFormat() {
        TimeZone zone = TimeZone.getTimeZone("UTC");
        FastDateFormat fdf = FastDateFormat.getInstance("M/d/yyyy", zone, Locale.US);
        SimpleDateFormat sdf = new SimpleDateFormat("M/d/yyyy", Locale.US);
        sdf.setTimeZone(zone);

        Date d = buildDate(zone, 2023, Calendar.MARCH, 5, 0, 0, 0, 0);
        assertEquals("3/5/2023", fdf.format(d));
        assertEquals(sdf.format(d), fdf.format(d));
    }

    //-----------------------------------------------------------------------
    // Padded numeric field boundaries
    //-----------------------------------------------------------------------

    public void testPaddedFourDigitYearBoundaries() {
        TimeZone zone = TimeZone.getTimeZone("UTC");
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy", zone, Locale.US);

        assertEquals("0001", fdf.format(buildDate(zone, 1, Calendar.JANUARY, 1, 0, 0, 0, 0)));
        assertEquals("9999", fdf.format(buildDate(zone, 9999, Calendar.JANUARY, 1, 0, 0, 0, 0)));
        assertEquals("10000", fdf.format(buildDate(zone, 10000, Calendar.JANUARY, 1, 0, 0, 0, 0)));
    }

    /**
     * PaddedNumberField.estimateLength() always returns 4, regardless of the
     * requested field width. For "yyyyy" (width 5) the formatted output is
     * zero-padded to 5 digits, which already exceeds the estimate for an
     * ordinary 4 digit year - violating the documented contract of
     * getMaxLengthEstimate() ("the actual formatted length will almost
     * always be less than or equal to this amount").
     */
    public void testGetMaxLengthEstimate_bug_ignoresPaddedFieldWidth() {
        TimeZone zone = TimeZone.getTimeZone("UTC");
        FastDateFormat fdf = FastDateFormat.getInstance("yyyyy", zone, Locale.US);
        String formatted = fdf.format(buildDate(zone, 2023, Calendar.JANUARY, 1, 0, 0, 0, 0));
        assertEquals("02023", formatted);
        assertTrue("getMaxLengthEstimate() [" + fdf.getMaxLengthEstimate()
                + "] should be >= actual formatted length [" + formatted.length() + "]",
                fdf.getMaxLengthEstimate() >= formatted.length());
    }

    //-----------------------------------------------------------------------
    // Time zone numeric offset ('Z' / 'ZZ')
    //-----------------------------------------------------------------------

    public void testTimeZoneNumberNoColon() {
        TimeZone zone = TimeZone.getTimeZone("GMT+05:30");
        FastDateFormat fdf = FastDateFormat.getInstance("Z", zone, Locale.US);
        Date d = buildDate(zone, 2023, Calendar.JUNE, 1, 10, 0, 0, 0);
        assertEquals("+0530", fdf.format(d));
    }

    public void testTimeZoneNumberWithColon() {
        TimeZone zone = TimeZone.getTimeZone("GMT+05:30");
        FastDateFormat fdf = FastDateFormat.getInstance("ZZ", zone, Locale.US);
        Date d = buildDate(zone, 2023, Calendar.JUNE, 1, 10, 0, 0, 0);
        assertEquals("+05:30", fdf.format(d));
    }

    public void testTimeZoneNumberNegativeOffset() {
        TimeZone zone = TimeZone.getTimeZone("GMT-09:30");
        FastDateFormat fdfNoColon = FastDateFormat.getInstance("Z", zone, Locale.US);
        FastDateFormat fdfColon = FastDateFormat.getInstance("ZZ", zone, Locale.US);
        Date d = buildDate(zone, 2023, Calendar.JUNE, 1, 10, 0, 0, 0);
        assertEquals("-0930", fdfNoColon.format(d));
        assertEquals("-09:30", fdfColon.format(d));
    }

    /**
     * TimeZoneNumberRule.estimateLength() returns a constant 5 for both the
     * colon and no-colon variants, but the colon variant ("+05:30") is 6
     * characters long. This undercounts the estimate for "ZZ" patterns.
     */
    public void testGetMaxLengthEstimate_bug_timeZoneColonVariantUnderestimated() {
        TimeZone zone = TimeZone.getTimeZone("GMT+05:30");
        FastDateFormat fdf = FastDateFormat.getInstance("ZZ", zone, Locale.US);
        Date d = buildDate(zone, 2023, Calendar.JUNE, 1, 10, 0, 0, 0);
        String formatted = fdf.format(d);
        assertEquals("+05:30", formatted);
        assertTrue("getMaxLengthEstimate() [" + fdf.getMaxLengthEstimate()
                + "] should be >= actual formatted length [" + formatted.length() + "]",
                fdf.getMaxLengthEstimate() >= formatted.length());
    }

    //-----------------------------------------------------------------------
    // Time zone names ('z' / 'zzzz')
    //-----------------------------------------------------------------------

    public void testTimeZoneNameForcedUsesFormatterZone() {
        TimeZone zone = TimeZone.getTimeZone("America/Los_Angeles");
        FastDateFormat fdf = FastDateFormat.getInstance("zzzz", zone, Locale.US);

        Date winter = buildDate(zone, 2023, Calendar.JANUARY, 15, 12, 0, 0, 0);
        Date summer = buildDate(zone, 2023, Calendar.JULY, 15, 12, 0, 0, 0);

        String expectedStandard = zone.getDisplayName(false, TimeZone.LONG, Locale.US);
        String expectedDaylight = zone.getDisplayName(true, TimeZone.LONG, Locale.US);

        assertEquals(expectedStandard, fdf.format(winter));
        assertEquals(expectedDaylight, fdf.format(summer));
    }

    public void testTimeZoneNameNonForcedUsesCalendarZone() {
        FastDateFormat fdf = FastDateFormat.getInstance("z", Locale.US);
        assertFalse(fdf.getTimeZoneOverridesCalendar());

        TimeZone otherZone = TimeZone.getTimeZone("Europe/Paris");
        Calendar cal = new GregorianCalendar(otherZone);
        cal.clear();
        cal.set(2023, Calendar.JANUARY, 15, 12, 0, 0);

        boolean isDaylight = otherZone.useDaylightTime() && cal.get(Calendar.DST_OFFSET) != 0;
        String expected = otherZone.getDisplayName(isDaylight, TimeZone.SHORT, Locale.US);
        assertEquals(expected, fdf.format(cal));
    }

    //-----------------------------------------------------------------------
    // Literal text / quoting
    //-----------------------------------------------------------------------

    public void testLiteralQuotedText() {
        TimeZone zone = TimeZone.getTimeZone("UTC");
        FastDateFormat fdf = FastDateFormat.getInstance("'T'HH':'mm", zone, Locale.US);
        Date d = buildDate(zone, 2023, Calendar.JANUARY, 1, 9, 5, 0, 0);
        assertEquals("T09:05", fdf.format(d));
    }

    public void testLiteralEscapedQuote() {
        TimeZone zone = TimeZone.getTimeZone("UTC");
        FastDateFormat fdf = FastDateFormat.getInstance("HH''mm", zone, Locale.US);
        Date d = buildDate(zone, 2023, Calendar.JANUARY, 1, 9, 5, 0, 0);
        assertEquals("09'05", fdf.format(d));
    }

    /**
     * The class documentation states that "all patterns are compatible with
     * SimpleDateFormat" (aside from time zones). SimpleDateFormat rejects a
     * pattern with an unterminated quoted literal ("Unterminated quote").
     * FastDateFormat's parseToken() silently treats the rest of the pattern
     * as a literal instead of flagging the malformed pattern.
     */
    public void testUnterminatedQuote_bug_shouldRejectMalformedPattern() {
        try {
            new SimpleDateFormat("'abc");
            fail("expected SimpleDateFormat to reject an unterminated quote - oracle assumption invalid");
        } catch (IllegalArgumentException expected) {
            // expected from the oracle, confirms the pattern is indeed malformed
        }
        try {
            FastDateFormat.getInstance("'abc");
            fail("FastDateFormat should reject an unterminated quoted literal like SimpleDateFormat does");
        } catch (IllegalArgumentException expected) {
            // this is the desired behaviour
        }
    }

    //-----------------------------------------------------------------------
    // Pattern parsing errors
    //-----------------------------------------------------------------------

    public void testInvalidPatternLetterThrows() {
        try {
            FastDateFormat.getInstance("q");
            fail("expected IllegalArgumentException for unsupported pattern letter");
        } catch (IllegalArgumentException expected) {
            assertTrue(expected.getMessage().indexOf("q") >= 0);
        }
    }

    public void testNullPatternThrows() {
        try {
            FastDateFormat.getInstance((String) null);
            fail("expected IllegalArgumentException for null pattern");
        } catch (IllegalArgumentException expected) {
            assertEquals("The pattern must not be null", expected.getMessage());
        }
    }

    //-----------------------------------------------------------------------
    // format(Object, StringBuffer, FieldPosition) dispatch
    //-----------------------------------------------------------------------

    public void testFormatObjectDispatchesByType() {
        TimeZone zone = TimeZone.getTimeZone("UTC");
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd", zone, Locale.US);
        Date d = buildDate(zone, 2023, Calendar.MARCH, 5, 0, 0, 0, 0);
        Calendar cal = new GregorianCalendar(zone);
        cal.setTime(d);

        StringBuffer buf1 = new StringBuffer();
        fdf.format((Object) d, buf1, new FieldPosition(0));
        assertEquals("2023-03-05", buf1.toString());

        StringBuffer buf2 = new StringBuffer();
        fdf.format((Object) cal, buf2, new FieldPosition(0));
        assertEquals("2023-03-05", buf2.toString());

        StringBuffer buf3 = new StringBuffer();
        fdf.format((Object) new Long(d.getTime()), buf3, new FieldPosition(0));
        assertEquals("2023-03-05", buf3.toString());
    }

    public void testFormatObjectWithUnsupportedTypeThrows() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd");
        try {
            fdf.format((Object) "not a date", new StringBuffer(), new FieldPosition(0));
            fail("expected IllegalArgumentException for unsupported type");
        } catch (IllegalArgumentException expected) {
            assertTrue(expected.getMessage().indexOf("String") >= 0);
        }
    }

    public void testFormatObjectWithNullThrows() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd");
        try {
            fdf.format((Object) null, new StringBuffer(), new FieldPosition(0));
            fail("expected IllegalArgumentException for null object");
        } catch (IllegalArgumentException expected) {
            assertTrue(expected.getMessage().indexOf("<null>") >= 0);
        }
    }

    //-----------------------------------------------------------------------
    // Convenience format(long) overloads
    //-----------------------------------------------------------------------

    public void testFormatLongMatchesFormatDate() {
        TimeZone zone = TimeZone.getTimeZone("UTC");
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss", zone, Locale.US);
        Date d = buildDate(zone, 2023, Calendar.MARCH, 5, 10, 20, 30, 0);
        assertEquals(fdf.format(d), fdf.format(d.getTime()));

        StringBuffer buf = new StringBuffer();
        fdf.format(d.getTime(), buf);
        assertEquals(fdf.format(d), buf.toString());
    }

    //-----------------------------------------------------------------------
    // parseObject (unsupported)
    //-----------------------------------------------------------------------

    public void testParseObjectAlwaysReturnsNull() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd");
        ParsePosition pos = new ParsePosition(5);
        pos.setErrorIndex(3);
        Object result = fdf.parseObject("2023-03-05", pos);
        assertNull(result);
        assertEquals(0, pos.getIndex());
        assertEquals(0, pos.getErrorIndex());
    }

    //-----------------------------------------------------------------------
    // Caching / identity
    //-----------------------------------------------------------------------

    public void testGetInstanceCachesSamePatternAndArgs() {
        FastDateFormat a = FastDateFormat.getInstance("yyyy-MM-dd", TimeZone.getTimeZone("UTC"), Locale.US);
        FastDateFormat b = FastDateFormat.getInstance("yyyy-MM-dd", TimeZone.getTimeZone("UTC"), Locale.US);
        assertSame(a, b);
    }

    public void testGetInstanceDifferentArgsAreDifferentInstances() {
        FastDateFormat a = FastDateFormat.getInstance("yyyy-MM-dd", TimeZone.getTimeZone("UTC"), Locale.US);
        FastDateFormat b = FastDateFormat.getInstance("yyyy-MM-dd", TimeZone.getTimeZone("GMT+01:00"), Locale.US);
        FastDateFormat c = FastDateFormat.getInstance("yyyy-MM-dd", TimeZone.getTimeZone("UTC"), Locale.FRANCE);
        FastDateFormat dflt = FastDateFormat.getInstance("yyyy-MM-dd");
        assertFalse(a.equals(b));
        assertFalse(a.equals(c));
        assertFalse(a.equals(dflt));
    }

    public void testGetDateInstanceCaching() {
        FastDateFormat a = FastDateFormat.getDateInstance(FastDateFormat.SHORT, Locale.US);
        FastDateFormat b = FastDateFormat.getDateInstance(FastDateFormat.SHORT, Locale.US);
        assertSame(a, b);
    }

    //-----------------------------------------------------------------------
    // equals()/hashCode() contract, using the package-visible constructor
    //-----------------------------------------------------------------------

    public void testEqualsAndHashCodeContract() {
        TimeZone tz1 = TimeZone.getTimeZone("GMT+01:00");
        TimeZone tz1b = TimeZone.getTimeZone("GMT+01:00");
        Locale loc1 = new Locale("en", "US");
        Locale loc1b = new Locale("en", "US");

        FastDateFormat a = new FastDateFormat("yyyy-MM-dd", tz1, loc1);
        FastDateFormat b = new FastDateFormat("yyyy-MM-dd", tz1b, loc1b);

        assertTrue(a.equals(b));
        assertTrue(b.equals(a));
        assertEquals(a.hashCode(), b.hashCode());
        assertNotSame(a, b);

        FastDateFormat differentPattern = new FastDateFormat("dd-MM-yyyy", tz1, loc1);
        assertFalse(a.equals(differentPattern));

        FastDateFormat differentZone = new FastDateFormat("yyyy-MM-dd", TimeZone.getTimeZone("GMT-01:00"), loc1);
        assertFalse(a.equals(differentZone));

        FastDateFormat differentLocale = new FastDateFormat("yyyy-MM-dd", tz1, Locale.FRANCE);
        assertFalse(a.equals(differentLocale));

        FastDateFormat nullTimeZoneArg = new FastDateFormat("yyyy-MM-dd", null, loc1);
        FastDateFormat explicitDefaultTimeZoneArg = new FastDateFormat("yyyy-MM-dd", TimeZone.getDefault(), loc1);
        assertFalse("forced vs non-forced time zone should not be equal even with the same effective zone",
                nullTimeZoneArg.equals(explicitDefaultTimeZoneArg));

        assertFalse(a.equals(null));
        assertFalse(a.equals("not a FastDateFormat"));
        assertTrue(a.equals(a));
    }

    public void testConstructorRejectsNullPattern() {
        try {
            new FastDateFormat(null, null, null);
            fail("expected IllegalArgumentException for null pattern");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    public void testToString() {
        FastDateFormat fdf = new FastDateFormat("yyyy-MM-dd", null, Locale.US);
        assertEquals("FastDateFormat[yyyy-MM-dd]", fdf.toString());
    }

    //-----------------------------------------------------------------------
    // Accessors
    //-----------------------------------------------------------------------

    public void testAccessorsWithExplicitTimeZoneAndLocale() {
        TimeZone zone = TimeZone.getTimeZone("GMT+03:00");
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd", zone, Locale.GERMANY);
        assertEquals("yyyy-MM-dd", fdf.getPattern());
        assertEquals(zone, fdf.getTimeZone());
        assertTrue(fdf.getTimeZoneOverridesCalendar());
        assertEquals(Locale.GERMANY, fdf.getLocale());
    }

    public void testAccessorsWithDefaults() {
        FastDateFormat fdf = FastDateFormat.getInstance("yyyy-MM-dd");
        assertFalse(fdf.getTimeZoneOverridesCalendar());
        assertEquals(TimeZone.getDefault(), fdf.getTimeZone());
        assertEquals(Locale.getDefault(), fdf.getLocale());
    }

    public void testGetInstanceNoArgUsesDefaultPattern() {
        FastDateFormat fdf = FastDateFormat.getInstance();
        String expectedPattern = new SimpleDateFormat().toPattern();
        assertEquals(expectedPattern, fdf.getPattern());
    }

    public void testStyleConstantsMatchDateFormat() {
        assertEquals(DateFormat.FULL, FastDateFormat.FULL);
        assertEquals(DateFormat.LONG, FastDateFormat.LONG);
        assertEquals(DateFormat.MEDIUM, FastDateFormat.MEDIUM);
        assertEquals(DateFormat.SHORT, FastDateFormat.SHORT);
    }

    //-----------------------------------------------------------------------
    // format(Calendar) time zone override behaviour
    //-----------------------------------------------------------------------

    public void testFormatCalendarUsesCalendarZoneWhenNotForced() {
        FastDateFormat fdf = FastDateFormat.getInstance("HH:mm z", Locale.US);
        assertFalse(fdf.getTimeZoneOverridesCalendar());

        TimeZone zone = TimeZone.getTimeZone("GMT+04:00");
        Calendar cal = new GregorianCalendar(zone);
        cal.clear();
        cal.set(2023, Calendar.JANUARY, 1, 10, 30, 0);

        String result = fdf.format(cal);
        assertTrue(result.startsWith("10:30"));
        // the calendar passed in must not be mutated
        assertEquals(zone, cal.getTimeZone());
    }

    public void testFormatCalendarForcedZoneOverridesCalendarZoneWithoutMutatingCaller() {
        TimeZone forcedZone = TimeZone.getTimeZone("GMT+04:00");
        TimeZone callerZone = TimeZone.getTimeZone("GMT-01:00");
        FastDateFormat fdf = FastDateFormat.getInstance("HH:mm", forcedZone, Locale.US);
        assertTrue(fdf.getTimeZoneOverridesCalendar());

        Calendar cal = new GregorianCalendar(callerZone);
        cal.clear();
        cal.set(2023, Calendar.JANUARY, 1, 10, 30, 0);
        cal.getTimeInMillis(); // fix the instant before changing zones below

        String result = fdf.format(cal);
        // forced zone is 5 hours ahead of the caller's zone
        assertEquals("15:30", result);
        // the original calendar object must be left untouched
        assertEquals(callerZone, cal.getTimeZone());
    }

    //-----------------------------------------------------------------------
    // Date / Time / DateTime instance factories
    //-----------------------------------------------------------------------

    public void testGetDateInstanceMatchesSimpleDateFormatPattern() {
        FastDateFormat fdf = FastDateFormat.getDateInstance(FastDateFormat.SHORT, Locale.US);
        SimpleDateFormat sdf = (SimpleDateFormat) DateFormat.getDateInstance(DateFormat.SHORT, Locale.US);
        assertEquals(sdf.toPattern(), fdf.getPattern());
    }

    public void testGetTimeInstanceMatchesSimpleDateFormatPattern() {
        FastDateFormat fdf = FastDateFormat.getTimeInstance(FastDateFormat.MEDIUM, Locale.US);
        SimpleDateFormat sdf = (SimpleDateFormat) DateFormat.getTimeInstance(DateFormat.MEDIUM, Locale.US);
        assertEquals(sdf.toPattern(), fdf.getPattern());
    }

    public void testGetDateTimeInstanceMatchesSimpleDateFormatPattern() {
        FastDateFormat fdf = FastDateFormat.getDateTimeInstance(
                FastDateFormat.LONG, FastDateFormat.SHORT, Locale.US);
        SimpleDateFormat sdf = (SimpleDateFormat) DateFormat.getDateTimeInstance(
                DateFormat.LONG, DateFormat.SHORT, Locale.US);
        assertEquals(sdf.toPattern(), fdf.getPattern());
    }

    public void testGetDateInstanceInvalidStyleThrows() {
        try {
            FastDateFormat.getDateInstance(999);
            fail("expected an exception for an invalid date style");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }
}
