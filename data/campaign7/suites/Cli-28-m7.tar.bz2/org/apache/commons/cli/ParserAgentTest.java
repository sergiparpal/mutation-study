/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.cli;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.Properties;

import junit.framework.TestCase;

/**
 * Self-contained tests for {@link Parser}, exercised through a trivial
 * concrete subclass whose <code>flatten</code> method is the identity
 * transform (so the behaviour under test is entirely the one implemented
 * in the abstract base class).
 */
public class ParserAgentTest extends TestCase
{
    /**
     * Minimal concrete {@link Parser} used purely as a test fixture. It does
     * not burst short options or expand "=" syntax; it simply hands the
     * arguments straight through so the base class logic can be exercised
     * in isolation.
     */
    private static class IdentityParser extends Parser
    {
        protected String[] flatten(Options opts, String[] arguments, boolean stopAtNonOption)
        {
            return arguments;
        }
    }

    private IdentityParser parser;

    private Options options;

    public void setUp()
    {
        parser = new IdentityParser();
        options = new Options()
            .addOption("a", "enable-a", false, "turn [a] on or off")
            .addOption("b", "bfile", true, "set the value of [b]")
            .addOption("c", "copt", false, "turn [c] on or off");
    }

    public void testParseSimpleOptionsAndArgs() throws Exception
    {
        String[] args = new String[] { "-a", "-b", "toast", "foo", "bar" };

        CommandLine cl = parser.parse(options, args);

        assertTrue("option a should be set", cl.hasOption("a"));
        assertTrue("option b should be set", cl.hasOption("b"));
        assertEquals("toast", cl.getOptionValue("b"));
        assertEquals(2, cl.getArgList().size());
        assertEquals("foo", cl.getArgList().get(0));
        assertEquals("bar", cl.getArgList().get(1));
    }

    public void testParseNullArgumentsTreatedAsEmpty() throws Exception
    {
        CommandLine cl = parser.parse(options, null);

        assertNotNull(cl);
        assertFalse(cl.hasOption("a"));
        assertTrue(cl.getArgList().isEmpty());
    }

    public void testParseUnrecognizedOptionThrows()
    {
        String[] args = new String[] { "-a", "-d" };

        try
        {
            parser.parse(options, args);
            fail("UnrecognizedOptionException expected");
        }
        catch (UnrecognizedOptionException e)
        {
            assertEquals("-d", e.getOption());
        }
        catch (ParseException e)
        {
            fail("wrong exception type: " + e);
        }
    }

    public void testParseStopAtNonOptionUnrecognizedOption() throws Exception
    {
        String[] args = new String[] { "-a", "-d", "-b", "toast" };

        CommandLine cl = parser.parse(options, args, true);

        assertTrue("option a should be set", cl.hasOption("a"));
        assertFalse("option b should not be reached", cl.hasOption("b"));
        List extra = cl.getArgList();
        assertEquals(3, extra.size());
        assertEquals("-d", extra.get(0));
        assertEquals("-b", extra.get(1));
        assertEquals("toast", extra.get(2));
    }

    public void testParseDoubleDashStopsOptionProcessing() throws Exception
    {
        String[] args = new String[] { "-a", "--", "-b", "toast" };

        CommandLine cl = parser.parse(options, args);

        assertTrue("option a should be set", cl.hasOption("a"));
        assertFalse("option b must not be parsed after --", cl.hasOption("b"));
        List extra = cl.getArgList();
        assertEquals(2, extra.size());
        assertEquals("-b", extra.get(0));
        assertEquals("toast", extra.get(1));
    }

    public void testParseDoubleDashOnlyFirstOccurrenceDropped() throws Exception
    {
        String[] args = new String[] { "--", "--", "foo" };

        CommandLine cl = parser.parse(options, args);

        List extra = cl.getArgList();
        assertEquals(1, extra.size());
        assertEquals("foo", extra.get(0));
    }

    public void testParseSingleDashWithoutStopIsAddedAsArg() throws Exception
    {
        String[] args = new String[] { "-a", "-" };

        CommandLine cl = parser.parse(options, args);

        assertTrue(cl.hasOption("a"));
        assertEquals(1, cl.getArgList().size());
        assertEquals("-", cl.getArgList().get(0));
    }

    public void testParseSingleDashWithStopIsDropped() throws Exception
    {
        String[] args = new String[] { "-a", "-", "foo" };

        CommandLine cl = parser.parse(options, args, true);

        assertTrue(cl.hasOption("a"));
        List extra = cl.getArgList();
        assertEquals(1, extra.size());
        assertEquals("foo", extra.get(0));
    }

    public void testParseMissingRequiredOptionThrows()
    {
        Option required = new Option("r", "req", false, "a required option");
        required.setRequired(true);
        options.addOption(required);

        try
        {
            parser.parse(options, new String[0]);
            fail("MissingOptionException expected");
        }
        catch (MissingOptionException e)
        {
            assertTrue(e.getMissingOptions().contains("r"));
        }
        catch (ParseException e)
        {
            fail("wrong exception type: " + e);
        }
    }

    public void testParseRequiredOptionSatisfied() throws Exception
    {
        Option required = new Option("r", "req", false, "a required option");
        required.setRequired(true);
        options.addOption(required);

        CommandLine cl = parser.parse(options, new String[] { "-r" });

        assertTrue(cl.hasOption("r"));
    }

    public void testParseRequiredOptionGroupSatisfied() throws Exception
    {
        OptionGroup group = new OptionGroup();
        group.addOption(new Option("x", "exclusive x"));
        group.addOption(new Option("y", "exclusive y"));
        group.setRequired(true);
        options.addOptionGroup(group);

        CommandLine cl = parser.parse(options, new String[] { "-x" });

        assertTrue(cl.hasOption("x"));
        assertFalse(cl.hasOption("y"));
    }

    public void testParseRequiredOptionGroupMissingThrows()
    {
        OptionGroup group = new OptionGroup();
        group.addOption(new Option("x", "exclusive x"));
        group.addOption(new Option("y", "exclusive y"));
        group.setRequired(true);
        options.addOptionGroup(group);

        try
        {
            parser.parse(options, new String[0]);
            fail("MissingOptionException expected");
        }
        catch (MissingOptionException e)
        {
            assertEquals(1, e.getMissingOptions().size());
        }
        catch (ParseException e)
        {
            fail("wrong exception type: " + e);
        }
    }

    public void testParseMissingArgumentThrows()
    {
        try
        {
            parser.parse(options, new String[] { "-b" });
            fail("MissingArgumentException expected");
        }
        catch (MissingArgumentException e)
        {
            assertEquals("b", e.getOption().getOpt());
        }
        catch (ParseException e)
        {
            fail("wrong exception type: " + e);
        }
    }

    public void testParseOptionalArgNotProvidedDoesNotThrow() throws Exception
    {
        Option optional = new Option("o", "optional with arg");
        optional.setArgs(1);
        optional.setOptionalArg(true);
        options.addOption(optional);

        CommandLine cl = parser.parse(options, new String[] { "-o" });

        assertTrue(cl.hasOption("o"));
        assertNull(cl.getOptionValue("o"));
    }

    public void testProcessPropertiesSetsOptionWhenAbsentFromCommandLine() throws Exception
    {
        Properties properties = new Properties();
        properties.setProperty("b", "fromProperties");

        CommandLine cl = parser.parse(options, new String[0], properties);

        assertTrue(cl.hasOption("b"));
        assertEquals("fromProperties", cl.getOptionValue("b"));
    }

    public void testProcessPropertiesDoesNotOverrideCommandLineValue() throws Exception
    {
        Properties properties = new Properties();
        properties.setProperty("b", "fromProperties");

        CommandLine cl = parser.parse(options, new String[] { "-b", "fromCli" }, properties);

        assertTrue(cl.hasOption("b"));
        assertEquals("fromCli", cl.getOptionValue("b"));
    }

    public void testProcessPropertiesBooleanFalseValueNotAdded() throws Exception
    {
        Properties properties = new Properties();
        properties.setProperty("a", "false");

        CommandLine cl = parser.parse(options, new String[0], properties);

        assertFalse(cl.hasOption("a"));
    }

    public void testProcessPropertiesBooleanTrueValueAdded() throws Exception
    {
        Properties properties = new Properties();
        properties.setProperty("a", "true");

        CommandLine cl = parser.parse(options, new String[0], properties);

        assertTrue(cl.hasOption("a"));
    }

    public void testProcessPropertiesNullIsNoOp() throws Exception
    {
        CommandLine cl = parser.parse(options, new String[0], (Properties) null);

        assertNotNull(cl);
        assertFalse(cl.hasOption("a"));
    }

    public void testProcessArgsCollectsValuesAndStopsAtNextOption() throws Exception
    {
        parser.parse(options, new String[0]);

        Option opt = new Option("b", true, "set the value of [b]");
        opt.setArgs(Option.UNLIMITED_VALUES);

        List tokens = new ArrayList();
        tokens.add("value1");
        tokens.add("value2");
        tokens.add("-a");
        ListIterator iterator = tokens.listIterator();

        parser.processArgs(opt, iterator);

        assertEquals(2, opt.getValues().length);
        assertEquals("value1", opt.getValues()[0]);
        assertEquals("value2", opt.getValues()[1]);
        assertTrue("iterator should be positioned right before the next option", iterator.hasNext());
        assertEquals("-a", iterator.next());
    }

    public void testProcessArgsMissingArgumentThrows() throws Exception
    {
        parser.parse(options, new String[0]);

        Option opt = new Option("b", true, "set the value of [b]");
        List tokens = new ArrayList();
        ListIterator iterator = tokens.listIterator();

        try
        {
            parser.processArgs(opt, iterator);
            fail("MissingArgumentException expected");
        }
        catch (MissingArgumentException e)
        {
            assertSame(opt, e.getOption());
        }
    }

    public void testCheckRequiredOptionsThrowsWhenPending() throws Exception
    {
        Option required = new Option("r", "req", false, "required");
        required.setRequired(true);
        Options opts = new Options();
        opts.addOption(required);

        parser.setOptions(opts);

        try
        {
            parser.checkRequiredOptions();
            fail("MissingOptionException expected");
        }
        catch (MissingOptionException e)
        {
            assertEquals(1, e.getMissingOptions().size());
            assertTrue(e.getMissingOptions().contains("r"));
        }
    }

    public void testCheckRequiredOptionsPassesWhenListEmpty() throws Exception
    {
        Options opts = new Options();
        opts.addOption("a", false, "not required");

        parser.setOptions(opts);

        parser.checkRequiredOptions();
        assertTrue(parser.getRequiredOptions().isEmpty());
    }

    public void testGetOptionsAndGetRequiredOptionsReflectSetOptions() throws Exception
    {
        Option required = new Option("r", "req", false, "required");
        required.setRequired(true);
        Options opts = new Options();
        opts.addOption(required);

        parser.parse(opts, new String[] { "-r" });

        assertSame(opts, parser.getOptions());
        assertTrue("required option should have been satisfied and removed",
            parser.getRequiredOptions().isEmpty());
    }
}
