/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.csv;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.Closeable;
import java.io.Flushable;
import java.io.IOException;
import java.io.StringWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;

/**
 * Self-contained tests for {@link CSVPrinter}.
 */
public class CSVPrinterAgentTest {

    private final String recordSeparator = CSVFormat.DEFAULT.getRecordSeparator();

    /** Appendable that tracks whether close()/flush() were invoked on it. */
    private static final class TrackingAppendable implements Appendable, Closeable, Flushable {
        private final StringBuilder sb = new StringBuilder();
        private boolean closed = false;
        private boolean flushed = false;

        public Appendable append(final CharSequence csq) throws IOException {
            sb.append(csq);
            return this;
        }

        public Appendable append(final CharSequence csq, final int start, final int end) throws IOException {
            sb.append(csq, start, end);
            return this;
        }

        public Appendable append(final char c) throws IOException {
            sb.append(c);
            return this;
        }

        public void close() throws IOException {
            closed = true;
        }

        public void flush() throws IOException {
            flushed = true;
        }

        public String toString() {
            return sb.toString();
        }
    }

    /** Appendable that is neither Closeable nor Flushable. */
    private static final class PlainAppendable implements Appendable {
        private final StringBuilder sb = new StringBuilder();

        public Appendable append(final CharSequence csq) throws IOException {
            sb.append(csq);
            return this;
        }

        public Appendable append(final CharSequence csq, final int start, final int end) throws IOException {
            sb.append(csq, start, end);
            return this;
        }

        public Appendable append(final char c) throws IOException {
            sb.append(c);
            return this;
        }

        public String toString() {
            return sb.toString();
        }
    }

    @Test(expected = IllegalArgumentException.class)
    public void testConstructorNullAppendable() {
        new CSVPrinter(null, CSVFormat.DEFAULT);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testConstructorNullFormat() {
        new CSVPrinter(new StringWriter(), null);
    }

    @Test
    public void testGetOutReturnsSameInstance() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        assertSame(sw, printer.getOut());
        printer.close();
    }

    @Test
    public void testCloseDelegatesToCloseableOut() throws IOException {
        final TrackingAppendable ta = new TrackingAppendable();
        final CSVPrinter printer = new CSVPrinter(ta, CSVFormat.DEFAULT);
        assertFalse(ta.closed);
        printer.close();
        assertTrue(ta.closed);
    }

    @Test
    public void testCloseOnNonCloseableOutIsNoop() throws IOException {
        final PlainAppendable pa = new PlainAppendable();
        final CSVPrinter printer = new CSVPrinter(pa, CSVFormat.DEFAULT);
        printer.printRecord("a", "b");
        printer.close();
        assertEquals("a,b" + recordSeparator, pa.toString());
    }

    @Test
    public void testFlushDelegatesToFlushableOut() throws IOException {
        final TrackingAppendable ta = new TrackingAppendable();
        final CSVPrinter printer = new CSVPrinter(ta, CSVFormat.DEFAULT);
        assertFalse(ta.flushed);
        printer.flush();
        assertTrue(ta.flushed);
    }

    @Test
    public void testFlushOnNonFlushableOutIsNoop() throws IOException {
        final PlainAppendable pa = new PlainAppendable();
        final CSVPrinter printer = new CSVPrinter(pa, CSVFormat.DEFAULT);
        printer.flush();
        assertEquals("", pa.toString());
    }

    @Test
    public void testPrintNullDefaultNullString() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print(null);
        // the null is rendered as an empty string, which, being the first (and only)
        // token on the line, must be quoted so the line is not mistaken for empty
        assertEquals("\"\"", sw.toString());
        printer.close();
    }

    @Test
    public void testPrintRecordEmptyVarargs() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecord();
        assertEquals(recordSeparator, sw.toString());
        printer.close();
    }

    @Test
    public void testPrintRecordSingleEmptyValueIsQuoted() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecord("");
        assertEquals("\"\"" + recordSeparator, sw.toString());
        printer.close();
    }

    @Test
    public void testPrintRecordIterable() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final List<String> values = new ArrayList<String>();
        values.add("a");
        values.add("b");
        values.add("c");
        printer.printRecord(values);
        assertEquals("a,b,c" + recordSeparator, sw.toString());
        printer.close();
    }

    @Test
    public void testPrintRecordsIterableMixedTypes() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final List<Object> records = new ArrayList<Object>();
        records.add(new String[] { "r1c1", "r1c2" });
        records.add(Arrays.asList("r2c1", "r2c2"));
        records.add("plain");
        printer.printRecords(records);
        assertEquals("r1c1,r1c2" + recordSeparator + "r2c1,r2c2" + recordSeparator + "plain" + recordSeparator,
                sw.toString());
        printer.close();
    }

    @Test
    public void testPrintRecordsObjectArrayMixedTypes() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final Object[] records = new Object[] { new String[] { "r1c1", "r1c2" },
                Arrays.asList("r2c1", "r2c2"), "plain" };
        printer.printRecords(records);
        assertEquals("r1c1,r1c2" + recordSeparator + "r2c1,r2c2" + recordSeparator + "plain" + recordSeparator,
                sw.toString());
        printer.close();
    }

    @Test
    public void testPrintRecordsEmptyArray() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecords(new Object[0]);
        assertEquals("", sw.toString());
        printer.close();
    }

    @Test
    public void testDisabledCommentProducesNoOutput() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printComment("comment text");
        assertEquals("", sw.toString());
        printer.close();
    }

    @Test
    public void testCommentStartsOnNewLineAfterExistingRecord() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT.withCommentStart('#'));
        printer.print("a");
        printer.printComment("hello");
        assertEquals("a" + recordSeparator + "# hello" + recordSeparator, sw.toString());
        printer.close();
    }

    @Test
    public void testPrintlnWritesSeparatorAndResetsNewRecord() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("a");
        printer.println();
        // newRecord is true again, so the next print should NOT be preceded by a delimiter
        printer.print("b");
        assertEquals("a" + recordSeparator + "b", sw.toString());
        printer.close();
    }

    @Test
    public void testQuotePolicyNoneWithEscapeHandlesDelimiter() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.withEscape('!').withQuotePolicy(Quote.NONE);
        final CSVPrinter printer = new CSVPrinter(sw, format);
        printer.printRecord("a,b", "c");
        assertEquals("a!,b,c" + recordSeparator, sw.toString());
        printer.close();
    }

    @Test
    public void testQuotePolicyNoneWithoutEscapeThrowsOnConstruction() {
        final StringWriter sw = new StringWriter();
        final CSVFormat format = CSVFormat.DEFAULT.withQuotePolicy(Quote.NONE);
        try {
            new CSVPrinter(sw, format);
            fail("Expected an IllegalStateException because Quote.NONE requires an escape character");
        } catch (final IllegalStateException expected) {
            // format.validate() rejects Quote.NONE without an escape character at construction time
        }
    }

    @Test
    public void testQuoteNonNumericQuotesStringsNotNumbers() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT.withQuotePolicy(Quote.NON_NUMERIC));
        printer.printRecord("text", Integer.valueOf(42), Double.valueOf(3.5));
        assertEquals("\"text\",42,3.5" + recordSeparator, sw.toString());
        printer.close();
    }

    @Test
    public void testQuoteCharWithEmbeddedQuoteIsDoubled() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecord("say \"hi\"");
        assertEquals("\"say \"\"hi\"\"\"" + recordSeparator, sw.toString());
        printer.close();
    }

    @Test
    public void testPrintRecordsResultSet() throws IOException, ClassNotFoundException, SQLException {
        final StringWriter sw = new StringWriter();
        Class.forName("org.h2.Driver");
        final Connection connection = DriverManager.getConnection("jdbc:h2:mem:CSVPrinterAgentTest;", "sa", "");
        try {
            final Statement stmt = connection.createStatement();
            stmt.execute("CREATE TABLE AGENT_TEST(ID INT PRIMARY KEY, NAME VARCHAR(255))");
            stmt.execute("insert into AGENT_TEST values(1, 'one')");
            stmt.execute("insert into AGENT_TEST values(2, 'two')");
            final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
            printer.printRecords(stmt.executeQuery("select ID, NAME from AGENT_TEST order by ID"));
            assertEquals("1,one" + recordSeparator + "2,two" + recordSeparator, sw.toString());
            printer.close();
        } finally {
            connection.close();
        }
    }

    @Test
    public void testNewRecordTrueAtStart() throws IOException {
        // An empty value as the very first token on the line must be quoted (MINIMAL policy),
        // proving that a freshly constructed printer starts in "new record" state.
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("");
        assertEquals("\"\"", sw.toString());
        printer.close();
    }
}
