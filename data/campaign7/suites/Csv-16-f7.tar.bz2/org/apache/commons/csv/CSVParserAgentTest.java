/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.csv;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.io.StringReader;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.junit.Test;

/**
 * Self-contained tests for {@link CSVParser}.
 */
public class CSVParserAgentTest {

    @Test
    public void testParseSimpleRecords() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b,c\n1,2,3\n", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("b", records.get(0).get(1));
            assertEquals("c", records.get(0).get(2));
            assertEquals("1", records.get(1).get(0));
            assertEquals("2", records.get(1).get(1));
            assertEquals("3", records.get(1).get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testParseWithHeader() throws IOException {
        final CSVParser parser = CSVParser.parse("name,age\nJohn,25\nJane,30\n",
                CSVFormat.DEFAULT.withHeader("name", "age"));
        try {
            final Map<String, Integer> headerMap = parser.getHeaderMap();
            assertEquals(Integer.valueOf(0), headerMap.get("name"));
            assertEquals(Integer.valueOf(1), headerMap.get("age"));

            final List<CSVRecord> records = parser.getRecords();
            assertEquals(3, records.size());
            assertEquals("name", records.get(0).get("name"));
            assertEquals("age", records.get(0).get("age"));
            assertEquals("John", records.get(1).get("name"));
            assertEquals("25", records.get(1).get("age"));
            assertEquals("Jane", records.get(2).get("name"));
            assertEquals("30", records.get(2).get("age"));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testParseWithHeaderFromFirstLine() throws IOException {
        final CSVParser parser = CSVParser.parse("name,age\nJohn,25\n",
                CSVFormat.DEFAULT.withHeader());
        try {
            final Map<String, Integer> headerMap = parser.getHeaderMap();
            assertEquals(Integer.valueOf(0), headerMap.get("name"));
            assertEquals(Integer.valueOf(1), headerMap.get("age"));

            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("John", records.get(0).get("name"));
            assertEquals("25", records.get(0).get("age"));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testParseWithSkipHeaderRecord() throws IOException {
        final CSVParser parser = CSVParser.parse("name,age\nJohn,25\n",
                CSVFormat.DEFAULT.withHeader("name", "age").withSkipHeaderRecord(true));
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(1, records.size());
            assertEquals("John", records.get(0).get("name"));
            assertEquals("25", records.get(0).get("age"));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetHeaderMapReturnsCopy() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n1,2\n", CSVFormat.DEFAULT.withHeader("a", "b"));
        try {
            final Map<String, Integer> headerMap = parser.getHeaderMap();
            headerMap.put("c", Integer.valueOf(99));
            final Map<String, Integer> headerMap2 = parser.getHeaderMap();
            assertFalse(headerMap2.containsKey("c"));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetHeaderMapNullWhenNoHeader() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n1,2\n", CSVFormat.DEFAULT);
        try {
            assertNull(parser.getHeaderMap());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testEmptyInputProducesNoRecords() throws IOException {
        final CSVParser parser = CSVParser.parse("", CSVFormat.DEFAULT);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertTrue(records.isEmpty());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetRecordNumber() throws IOException {
        final CSVParser parser = CSVParser.parse("a\nb\nc\n", CSVFormat.DEFAULT);
        try {
            assertEquals(0, parser.getRecordNumber());
            final Iterator<CSVRecord> it = parser.iterator();
            final CSVRecord r1 = it.next();
            assertEquals(1, r1.getRecordNumber());
            assertEquals(1, parser.getRecordNumber());
            final CSVRecord r2 = it.next();
            assertEquals(2, r2.getRecordNumber());
            final CSVRecord r3 = it.next();
            assertEquals(3, r3.getRecordNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testIteratorHasNextAndNext() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n2\n", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            assertTrue(it.hasNext());
            assertTrue(it.hasNext()); // calling twice should not consume a record
            assertEquals("1", it.next().get(0));
            assertTrue(it.hasNext());
            assertEquals("2", it.next().get(0));
            assertFalse(it.hasNext());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testIteratorNextWithoutHasNextThrowsAtEnd() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            assertEquals("1", it.next().get(0));
            try {
                it.next();
                fail("Expected NoSuchElementException");
            } catch (final NoSuchElementException expected) {
                // expected
            }
        } finally {
            parser.close();
        }
    }

    @Test
    public void testIteratorRemoveUnsupported() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n", CSVFormat.DEFAULT);
        try {
            final Iterator<CSVRecord> it = parser.iterator();
            try {
                it.remove();
                fail("Expected UnsupportedOperationException");
            } catch (final UnsupportedOperationException expected) {
                // expected
            }
        } finally {
            parser.close();
        }
    }

    @Test
    public void testCloseAndIsClosed() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n2\n", CSVFormat.DEFAULT);
        assertFalse(parser.isClosed());
        parser.close();
        assertTrue(parser.isClosed());
    }

    @Test
    public void testIteratorAfterCloseHasNoNext() throws IOException {
        final CSVParser parser = CSVParser.parse("1\n2\n", CSVFormat.DEFAULT);
        final Iterator<CSVRecord> it = parser.iterator();
        parser.close();
        assertFalse(it.hasNext());
        try {
            it.next();
            fail("Expected NoSuchElementException after close");
        } catch (final NoSuchElementException expected) {
            // expected
        }
    }

    @Test(expected = IllegalArgumentException.class)
    public void testParseNullStringThrows() throws IOException {
        CSVParser.parse((String) null, CSVFormat.DEFAULT);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testConstructorNullReaderThrows() throws IOException {
        new CSVParser(null, CSVFormat.DEFAULT);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testConstructorNullFormatThrows() throws IOException {
        new CSVParser(new StringReader("a,b"), null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testDuplicateHeaderNamesThrow() throws IOException {
        CSVParser.parse("a,b,a\n1,2,3\n", CSVFormat.DEFAULT.withHeader());
    }

    @Test
    public void testNullStringSubstitution() throws IOException {
        final CSVParser parser = CSVParser.parse("a,NULL,c\n", CSVFormat.DEFAULT.withNullString("NULL"));
        try {
            final CSVRecord record = parser.iterator().next();
            assertEquals("a", record.get(0));
            assertNull(record.get(1));
            assertEquals("c", record.get(2));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testTrimValues() throws IOException {
        final CSVParser parser = CSVParser.parse("  a  , b \n", CSVFormat.DEFAULT.withTrim(true).withDelimiter(','));
        try {
            final CSVRecord record = parser.iterator().next();
            assertEquals("a", record.get(0));
            assertEquals("b", record.get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testCommentsIgnoredFromRecordsButAvailable() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b\n# this is a comment\nc,d\n",
                CSVFormat.DEFAULT.withCommentMarker('#'));
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("c", records.get(1).get(0));
            assertEquals("this is a comment", records.get(1).getComment());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testQuotedValueWithEmbeddedDelimiter() throws IOException {
        final CSVParser parser = CSVParser.parse("\"a,b\",c\n", CSVFormat.DEFAULT);
        try {
            final CSVRecord record = parser.iterator().next();
            assertEquals(2, record.size());
            assertEquals("a,b", record.get(0));
            assertEquals("c", record.get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testGetCurrentLineNumber() throws IOException {
        final CSVParser parser = CSVParser.parse("a\nb\nc\n", CSVFormat.DEFAULT);
        try {
            assertEquals(0, parser.getCurrentLineNumber());
            parser.nextRecord();
            assertEquals(1, parser.getCurrentLineNumber());
            parser.nextRecord();
            assertEquals(2, parser.getCurrentLineNumber());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testNextRecordReturnsNullAtEof() throws IOException {
        final CSVParser parser = CSVParser.parse("a\n", CSVFormat.DEFAULT);
        try {
            final CSVRecord first = parser.nextRecord();
            assertEquals("a", first.get(0));
            assertNull(parser.nextRecord());
        } finally {
            parser.close();
        }
    }

    @Test
    public void testTrailingDelimiterDropsLastEmptyField() throws IOException {
        final CSVParser parser = CSVParser.parse("a,b,\n", CSVFormat.DEFAULT.withTrailingDelimiter(true));
        try {
            final CSVRecord record = parser.iterator().next();
            assertEquals(2, record.size());
            assertEquals("a", record.get(0));
            assertEquals("b", record.get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testUnterminatedQuoteThrowsIOException() throws IOException {
        final CSVParser parser = CSVParser.parse("a,\"b\n", CSVFormat.DEFAULT);
        try {
            try {
                parser.getRecords();
                fail("Expected IOException for unterminated quote");
            } catch (final IOException expected) {
                // expected
            }
        } finally {
            parser.close();
        }
    }

    @Test
    public void testFirstRecordAsHeaderCaseInsensitive() throws IOException {
        final CSVParser parser = CSVParser.parse("Name,Age\nJohn,25\n",
                CSVFormat.DEFAULT.withHeader().withIgnoreHeaderCase());
        try {
            final CSVRecord record = parser.iterator().next();
            assertEquals("John", record.get("name"));
            assertEquals("25", record.get("AGE"));
        } finally {
            parser.close();
        }
    }
}
