/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.cli;

import junit.framework.TestCase;

/**
 * Self-contained test case for {@link GnuParser}.
 */
public class GnuParserAgentTest extends TestCase
{
    private Options options;
    private GnuParser parser;

    public void setUp()
    {
        options = new Options()
            .addOption("a", "enable-a", false, "turn [a] on or off")
            .addOption("b", "bfile", true, "set the value of [b]")
            .addOption("c", "copt", false, "turn [c] on or off")
            .addOption("D", true, "property");

        parser = new GnuParser();
    }

    public void testFlattenEmptyArguments()
    {
        String[] flattened = parser.flatten(options, new String[0], false);

        assertEquals("empty input produces empty output", 0, flattened.length);
    }

    public void testFlattenPlainArguments()
    {
        String[] args = new String[] { "foo", "bar" };

        String[] flattened = parser.flatten(options, args, false);

        assertEquals(2, flattened.length);
        assertEquals("foo", flattened[0]);
        assertEquals("bar", flattened[1]);
    }

    public void testFlattenRecognizedOptionKeptAsSingleToken()
    {
        String[] args = new String[] { "-a" };

        String[] flattened = parser.flatten(options, args, false);

        assertEquals(1, flattened.length);
        assertEquals("-a", flattened[0]);
    }

    public void testFlattenSingleDashKept()
    {
        String[] args = new String[] { "-c", "-", "foo" };

        String[] flattened = parser.flatten(options, args, false);

        assertEquals(3, flattened.length);
        assertEquals("-c", flattened[0]);
        assertEquals("-", flattened[1]);
        assertEquals("foo", flattened[2]);
    }

    public void testFlattenDoubleDashStopsOptionProcessingAndEatsRest()
    {
        String[] args = new String[] { "-c", "--", "-a", "bar" };

        String[] flattened = parser.flatten(options, args, false);

        assertEquals(4, flattened.length);
        assertEquals("-c", flattened[0]);
        assertEquals("--", flattened[1]);
        // once "--" is seen everything after it is passed through untouched,
        // even tokens that look like a recognized option
        assertEquals("-a", flattened[2]);
        assertEquals("bar", flattened[3]);
    }

    public void testFlattenLongOptionWithEqualsIsSplit()
    {
        String[] args = new String[] { "--bfile=value" };

        String[] flattened = parser.flatten(options, args, false);

        assertEquals(2, flattened.length);
        assertEquals("--bfile", flattened[0]);
        assertEquals("value", flattened[1]);
    }

    public void testFlattenPropertyStyleOptionIsSplit()
    {
        String[] args = new String[] { "-Dproperty=value" };

        String[] flattened = parser.flatten(options, args, false);

        assertEquals(2, flattened.length);
        assertEquals("-D", flattened[0]);
        assertEquals("property=value", flattened[1]);
    }

    public void testFlattenUnrecognizedOptionWithoutStopIsKeptInPlace()
    {
        String[] args = new String[] { "-z", "foo" };

        String[] flattened = parser.flatten(options, args, false);

        assertEquals(2, flattened.length);
        assertEquals("-z", flattened[0]);
        assertEquals("foo", flattened[1]);
    }

    public void testFlattenUnrecognizedOptionWithStopEatsRemainingArgs()
    {
        String[] args = new String[] { "-c", "-z", "foo", "bar" };

        String[] flattened = parser.flatten(options, args, true);

        assertEquals(4, flattened.length);
        assertEquals("-c", flattened[0]);
        assertEquals("-z", flattened[1]);
        assertEquals("foo", flattened[2]);
        assertEquals("bar", flattened[3]);
    }

    public void testParseSimpleShortAndLongOptions() throws Exception
    {
        String[] args = new String[] { "-a", "--bfile", "toast", "foo", "bar" };

        CommandLine cl = parser.parse(options, args);

        assertTrue(cl.hasOption("a"));
        assertTrue(cl.hasOption("b"));
        assertEquals("toast", cl.getOptionValue("b"));
        assertEquals(2, cl.getArgList().size());
    }

    public void testParseLongOptionWithEquals() throws Exception
    {
        String[] args = new String[] { "--bfile=toast" };

        CommandLine cl = parser.parse(options, args);

        assertTrue(cl.hasOption("b"));
        assertEquals("toast", cl.getOptionValue("bfile"));
    }

    public void testParsePropertyStyleOption() throws Exception
    {
        String[] args = new String[] { "-Dproperty=value" };

        CommandLine cl = parser.parse(options, args);

        assertTrue(cl.hasOption("D"));
        assertEquals("property=value", cl.getOptionValue("D"));
    }

    public void testParseUnrecognizedOptionThrows()
    {
        String[] args = new String[] { "-z" };

        try
        {
            parser.parse(options, args);
            fail("UnrecognizedOptionException expected");
        }
        catch (UnrecognizedOptionException e)
        {
            // expected
        }
        catch (ParseException e)
        {
            fail("expected UnrecognizedOptionException, got " + e);
        }
    }

    public void testParseMissingArgumentThrows()
    {
        String[] args = new String[] { "-b" };

        try
        {
            parser.parse(options, args);
            fail("MissingArgumentException expected");
        }
        catch (MissingArgumentException e)
        {
            // expected
        }
        catch (ParseException e)
        {
            fail("expected MissingArgumentException, got " + e);
        }
    }

    public void testParseStopAtNonOption() throws Exception
    {
        String[] args = new String[] { "-c", "foober", "-b", "toast" };

        CommandLine cl = parser.parse(options, args, true);

        assertTrue(cl.hasOption("c"));
        assertFalse(cl.hasOption("b"));
        assertEquals(3, cl.getArgList().size());
    }

    public void testParseNullArguments() throws Exception
    {
        CommandLine cl = parser.parse(options, null);

        assertEquals(0, cl.getArgList().size());
        assertFalse(cl.hasOption("a"));
    }
}
