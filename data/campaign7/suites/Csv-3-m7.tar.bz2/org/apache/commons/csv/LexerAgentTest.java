/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.csv;

import static org.apache.commons.csv.Constants.BACKSPACE;
import static org.apache.commons.csv.Constants.CR;
import static org.apache.commons.csv.Constants.END_OF_STREAM;
import static org.apache.commons.csv.Constants.FF;
import static org.apache.commons.csv.Constants.LF;
import static org.apache.commons.csv.Constants.TAB;
import static org.apache.commons.csv.Constants.UNDEFINED;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.io.StringReader;

import org.junit.Test;

/**
 * Self-contained tests for {@link Lexer}, exercised through a minimal
 * concrete subclass since Lexer itself is abstract.
 */
public class LexerAgentTest {

    /** Minimal concrete Lexer used only to expose the package-private shared behavior under test. */
    private static final class ConcreteLexer extends Lexer {
        ConcreteLexer(final CSVFormat format, final ExtendedBufferedReader in) {
            super(format, in);
        }

        @Override
        Token nextToken(final Token reusableToken) throws IOException {
            throw new UnsupportedOperationException("not used by this test");
        }
    }

    private ConcreteLexer createLexer(final String input, final CSVFormat format) {
        return new ConcreteLexer(format, new ExtendedBufferedReader(new StringReader(input)));
    }

    private CSVFormat formatWith(final char delimiter, final Character escape, final Character quoteChar,
            final Character commentStart) {
        return CSVFormat.newBuilder(delimiter).withEscape(escape).withQuoteChar(quoteChar)
                .withCommentStart(commentStart).build();
    }

    // readEscape() -------------------------------------------------------

    @Test
    public void testReadEscapeNamedEscapes() throws IOException {
        final ConcreteLexer lexer = createLexer("rntbf", formatWith(',', '\\', '"', '#'));
        assertEquals(CR, lexer.readEscape());
        assertEquals(LF, lexer.readEscape());
        assertEquals(TAB, lexer.readEscape());
        assertEquals(BACKSPACE, lexer.readEscape());
        assertEquals(FF, lexer.readEscape());
    }

    @Test
    public void testReadEscapeLiteralControlCharsPassThrough() throws IOException {
        final String input = "" + CR + LF + FF + TAB + BACKSPACE;
        final ConcreteLexer lexer = createLexer(input, formatWith(',', '\\', '"', '#'));
        assertEquals(CR, lexer.readEscape());
        assertEquals(LF, lexer.readEscape());
        assertEquals(FF, lexer.readEscape());
        assertEquals(TAB, lexer.readEscape());
        assertEquals(BACKSPACE, lexer.readEscape());
    }

    @Test
    public void testReadEscapeMetaCharactersPassThrough() throws IOException {
        final ConcreteLexer lexer = createLexer(",\\\"#", formatWith(',', '\\', '"', '#'));
        assertEquals(',', lexer.readEscape());
        assertEquals('\\', lexer.readEscape());
        assertEquals('"', lexer.readEscape());
        assertEquals('#', lexer.readEscape());
    }

    @Test
    public void testReadEscapeUnexpectedCharReturnsEndOfStream() throws IOException {
        final ConcreteLexer lexer = createLexer("x", formatWith(',', '\\', '"', '#'));
        assertEquals(END_OF_STREAM, lexer.readEscape());
    }

    @Test
    public void testReadEscapeAtEndOfFileThrows() throws IOException {
        final ConcreteLexer lexer = createLexer("", formatWith(',', '\\', '"', '#'));
        try {
            lexer.readEscape();
            fail("Expected IOException when escape is at end of stream");
        } catch (final IOException e) {
            // expected
        }
    }

    // trimTrailingSpaces() ------------------------------------------------

    @Test
    public void testTrimTrailingSpacesRemovesTrailingWhitespace() {
        final ConcreteLexer lexer = createLexer("", formatWith(',', null, '"', '#'));
        final StringBuilder sb = new StringBuilder("abc   \t");
        lexer.trimTrailingSpaces(sb);
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testTrimTrailingSpacesNoTrailingWhitespace() {
        final ConcreteLexer lexer = createLexer("", formatWith(',', null, '"', '#'));
        final StringBuilder sb = new StringBuilder("abc");
        lexer.trimTrailingSpaces(sb);
        assertEquals("abc", sb.toString());
    }

    @Test
    public void testTrimTrailingSpacesAllWhitespace() {
        final ConcreteLexer lexer = createLexer("", formatWith(',', null, '"', '#'));
        final StringBuilder sb = new StringBuilder("   ");
        lexer.trimTrailingSpaces(sb);
        assertEquals("", sb.toString());
    }

    @Test
    public void testTrimTrailingSpacesEmptyBuffer() {
        final ConcreteLexer lexer = createLexer("", formatWith(',', null, '"', '#'));
        final StringBuilder sb = new StringBuilder("");
        lexer.trimTrailingSpaces(sb);
        assertEquals("", sb.toString());
    }

    // readEndOfLine() ------------------------------------------------------

    @Test
    public void testReadEndOfLineLfAlone() throws IOException {
        final ConcreteLexer lexer = createLexer("x", formatWith(',', null, '"', '#'));
        assertTrue(lexer.readEndOfLine(LF));
    }

    @Test
    public void testReadEndOfLineCrAlone() throws IOException {
        final ConcreteLexer lexer = createLexer("x", formatWith(',', null, '"', '#'));
        assertTrue(lexer.readEndOfLine(CR));
        // the trailing 'x' must still be available; the CR had no following LF to consume
        assertEquals('x', lexer.in.read());
    }

    @Test
    public void testReadEndOfLineCrLfConsumesLf() throws IOException {
        final ConcreteLexer lexer = createLexer("" + LF + "x", formatWith(',', null, '"', '#'));
        assertTrue(lexer.readEndOfLine(CR));
        // the LF following the CR must have been consumed, leaving 'x' as the next char
        assertEquals('x', lexer.in.read());
    }

    @Test
    public void testReadEndOfLineOtherCharIsFalse() throws IOException {
        final ConcreteLexer lexer = createLexer("x", formatWith(',', null, '"', '#'));
        assertFalse(lexer.readEndOfLine('a'));
    }

    // getLineNumber() -------------------------------------------------------

    @Test
    public void testGetLineNumberDelegatesToReader() throws IOException {
        final ConcreteLexer lexer = createLexer("a\nb\n", formatWith(',', null, '"', '#'));
        assertEquals(0, lexer.getLineNumber());
        lexer.in.read(); // a
        lexer.in.read(); // \n
        assertEquals(1, lexer.getLineNumber());
        lexer.in.read(); // b
        lexer.in.read(); // \n
        assertEquals(2, lexer.getLineNumber());
    }

    // isWhitespace() ----------------------------------------------------

    @Test
    public void testIsWhitespaceSpaceIsWhitespace() {
        final ConcreteLexer lexer = createLexer("", formatWith(',', null, '"', '#'));
        assertTrue(lexer.isWhitespace(' '));
        assertTrue(lexer.isWhitespace('\t'));
        assertFalse(lexer.isWhitespace('x'));
    }

    @Test
    public void testIsWhitespaceDelimiterIsNeverWhitespace() {
        // use a delimiter character that is normally whitespace to prove the exception
        final ConcreteLexer lexer = createLexer("", formatWith('\t', null, '"', '#'));
        assertFalse(lexer.isWhitespace('\t'));
    }

    // isStartOfLine() ------------------------------------------------------

    @Test
    public void testIsStartOfLine() {
        final ConcreteLexer lexer = createLexer("", formatWith(',', null, '"', '#'));
        assertTrue(lexer.isStartOfLine(LF));
        assertTrue(lexer.isStartOfLine(CR));
        assertTrue(lexer.isStartOfLine(UNDEFINED));
        assertFalse(lexer.isStartOfLine('a'));
        assertFalse(lexer.isStartOfLine(END_OF_STREAM));
    }

    // isEndOfFile() ---------------------------------------------------------

    @Test
    public void testIsEndOfFile() {
        final ConcreteLexer lexer = createLexer("", formatWith(',', null, '"', '#'));
        assertTrue(lexer.isEndOfFile(END_OF_STREAM));
        assertFalse(lexer.isEndOfFile('a'));
        assertFalse(lexer.isEndOfFile(0));
    }

    // isDelimiter/isEscape/isQuoteChar/isCommentStart ----------------------

    @Test
    public void testIsDelimiter() {
        final ConcreteLexer lexer = createLexer("", formatWith(';', '\\', '"', '#'));
        assertTrue(lexer.isDelimiter(';'));
        assertFalse(lexer.isDelimiter(','));
    }

    @Test
    public void testIsEscapeEnabled() {
        final ConcreteLexer lexer = createLexer("", formatWith(',', '\\', '"', '#'));
        assertTrue(lexer.isEscape('\\'));
        assertFalse(lexer.isEscape('/'));
    }

    @Test
    public void testIsEscapeDisabledWhenNull() {
        final ConcreteLexer lexer = createLexer("", formatWith(',', null, '"', '#'));
        assertFalse(lexer.isEscape('\\'));
        assertFalse(lexer.isEscape(END_OF_STREAM));
    }

    @Test
    public void testIsQuoteCharEnabled() {
        final ConcreteLexer lexer = createLexer("", formatWith(',', '\\', '"', '#'));
        assertTrue(lexer.isQuoteChar('"'));
        assertFalse(lexer.isQuoteChar('\''));
    }

    @Test
    public void testIsQuoteCharDisabledWhenNull() {
        final ConcreteLexer lexer = createLexer("", formatWith(',', '\\', null, '#'));
        assertFalse(lexer.isQuoteChar('"'));
    }

    @Test
    public void testIsCommentStartEnabled() {
        final ConcreteLexer lexer = createLexer("", formatWith(',', '\\', '"', '#'));
        assertTrue(lexer.isCommentStart('#'));
        assertFalse(lexer.isCommentStart('!'));
    }

    @Test
    public void testIsCommentStartDisabledWhenNull() {
        final ConcreteLexer lexer = createLexer("", formatWith(',', '\\', '"', null));
        assertFalse(lexer.isCommentStart('#'));
    }

    // constructor wiring ------------------------------------------------

    @Test
    public void testConstructorCopiesFormatFlags() {
        final CSVFormat format = CSVFormat.newBuilder(',').withIgnoreSurroundingSpaces(true)
                .withIgnoreEmptyLines(true).build();
        final ConcreteLexer lexer = createLexer("", format);
        assertTrue(lexer.ignoreSurroundingSpaces);
        assertTrue(lexer.ignoreEmptyLines);
        assertEquals(format, lexer.format);
    }

    @Test
    public void testConstructorDefaultFlagsFalse() {
        final CSVFormat format = CSVFormat.newBuilder(',').withIgnoreSurroundingSpaces(false)
                .withIgnoreEmptyLines(false).build();
        final ConcreteLexer lexer = createLexer("", format);
        assertFalse(lexer.ignoreSurroundingSpaces);
        assertFalse(lexer.ignoreEmptyLines);
    }
}
