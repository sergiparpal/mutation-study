/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.cli;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import java.util.Properties;

import junit.framework.TestCase;

/**
 * Self-contained tests for {@link Parser}, exercised through the trivial
 * {@link BasicParser} subclass (whose {@code flatten} simply echoes the
 * arguments back), so that the behaviour under test is exclusively the
 * logic implemented in {@code Parser} itself.
 */
public class ParserAgentTest extends TestCase
{
    public ParserAgentTest(String name)
    {
        super(name);
    }

    /**
     * A {@link Properties} subclass that remembers insertion order, so
     * that tests can rely on a deterministic iteration order for
     * {@link Parser#processProperties(Properties)}.
     */
    private static class OrderedProperties extends Properties
    {
        private final List order = new ArrayList();

        public synchronized Object setProperty(String key, String value)
        {
            if (!order.contains(key))
            {
                order.add(key);
            }
            return super.setProperty(key, value);
        }

        public Enumeration propertyNames()
        {
            return Collections.enumeration(order);
        }
    }

    public void testNullArgumentsTreatedAsEmpty() throws Exception
    {
        Options options = new Options().addOption("a", false, "a opt");
        Parser parser = new BasicParser();

        CommandLine cl = parser.parse(options, null);

        assertNotNull(cl);
        assertEquals(0, cl.getArgs().length);
        assertFalse(cl.hasOption("a"));
    }

    public void testSimpleOptionIsSet() throws Exception
    {
        Options options = new Options().addOption("a", false, "a opt");
        Parser parser = new BasicParser();

        CommandLine cl = parser.parse(options, new String[] { "-a" });

        assertTrue(cl.hasOption("a"));
        assertEquals(0, cl.getArgList().size());
    }

    public void testOptionWithArgumentValue() throws Exception
    {
        Options options = new Options().addOption("b", true, "b opt");
        Parser parser = new BasicParser();

        CommandLine cl = parser.parse(options, new String[] { "-b", "value" });

        assertTrue(cl.hasOption("b"));
        assertEquals("value", cl.getOptionValue("b"));
    }

    public void testMissingArgumentThrows() throws Exception
    {
        Options options = new Options().addOption("b", true, "b opt");
        Parser parser = new BasicParser();

        try
        {
            parser.parse(options, new String[] { "-b" });
            fail("expected MissingArgumentException");
        }
        catch (MissingArgumentException e)
        {
            assertTrue(e.getMessage().indexOf("b") >= 0);
        }
    }

    public void testOptionalArgumentNotConsumedFromNextOption() throws Exception
    {
        Option b = new Option("b", "b opt");
        b.setArgs(1);
        b.setOptionalArg(true);
        Options options = new Options().addOption(b).addOption("a", false, "a opt");
        Parser parser = new BasicParser();

        CommandLine cl = parser.parse(options, new String[] { "-b", "-a" });

        assertTrue(cl.hasOption("b"));
        assertNull(cl.getOptionValue("b"));
        assertTrue(cl.hasOption("a"));
    }

    public void testUnrecognizedOptionThrows() throws Exception
    {
        Options options = new Options().addOption("a", false, "a opt");
        Parser parser = new BasicParser();

        try
        {
            parser.parse(options, new String[] { "-z" });
            fail("expected UnrecognizedOptionException");
        }
        catch (UnrecognizedOptionException e)
        {
            assertTrue(e.getMessage().indexOf("-z") >= 0);
        }
    }

    public void testMissingRequiredOptionSingular() throws Exception
    {
        Option a = new Option("a", "a opt");
        a.setRequired(true);
        Options options = new Options().addOption(a);
        Parser parser = new BasicParser();

        try
        {
            parser.parse(options, new String[0]);
            fail("expected MissingOptionException");
        }
        catch (MissingOptionException e)
        {
            assertEquals("Missing required option: a", e.getMessage());
        }
    }

    public void testMissingRequiredOptionsPlural() throws Exception
    {
        Option a = new Option("a", "a opt");
        a.setRequired(true);
        Option b = new Option("b", "b opt");
        b.setRequired(true);
        Options options = new Options().addOption(a).addOption(b);
        Parser parser = new BasicParser();

        try
        {
            parser.parse(options, new String[0]);
            fail("expected MissingOptionException");
        }
        catch (MissingOptionException e)
        {
            assertEquals("Missing required options: a, b", e.getMessage());
        }
    }

    public void testRequiredOptionPresentDoesNotThrow() throws Exception
    {
        Option a = new Option("a", "a opt");
        a.setRequired(true);
        Options options = new Options().addOption(a);
        Parser parser = new BasicParser();

        CommandLine cl = parser.parse(options, new String[] { "-a" });

        assertTrue(cl.hasOption("a"));
    }

    public void testOptionGroupAlreadySelectedThrows() throws Exception
    {
        Option a = new Option("a", "a opt");
        Option b = new Option("b", "b opt");
        OptionGroup group = new OptionGroup();
        group.addOption(a);
        group.addOption(b);
        Options options = new Options().addOptionGroup(group);
        Parser parser = new BasicParser();

        try
        {
            parser.parse(options, new String[] { "-a", "-b" });
            fail("expected AlreadySelectedException");
        }
        catch (AlreadySelectedException e)
        {
            assertNotNull(e.getMessage());
        }
    }

    public void testRequiredOptionGroupSatisfiedByOneOption() throws Exception
    {
        Option a = new Option("a", "a opt");
        Option b = new Option("b", "b opt");
        OptionGroup group = new OptionGroup();
        group.addOption(a);
        group.addOption(b);
        group.setRequired(true);
        Options options = new Options().addOptionGroup(group);
        Parser parser = new BasicParser();

        CommandLine cl = parser.parse(options, new String[] { "-a" });

        assertTrue(cl.hasOption("a"));
        assertEquals("a", group.getSelected());
    }

    public void testRequiredOptionGroupUnsatisfiedThrows() throws Exception
    {
        Option a = new Option("a", "a opt");
        Option b = new Option("b", "b opt");
        OptionGroup group = new OptionGroup();
        group.addOption(a);
        group.addOption(b);
        group.setRequired(true);
        Options options = new Options().addOptionGroup(group);
        Parser parser = new BasicParser();

        try
        {
            parser.parse(options, new String[0]);
            fail("expected MissingOptionException");
        }
        catch (MissingOptionException e)
        {
            assertNotNull(e.getMessage());
        }
    }

    public void testSingleDashIsArgumentWhenNotStopping() throws Exception
    {
        Options options = new Options();
        Parser parser = new BasicParser();

        CommandLine cl = parser.parse(options, new String[] { "-" });

        assertEquals(1, cl.getArgList().size());
        assertEquals("-", cl.getArgList().get(0));
    }

    public void testSingleDashStopsParsingWhenStopAtNonOption() throws Exception
    {
        Options options = new Options();
        Parser parser = new BasicParser();

        CommandLine cl = parser.parse(options,
                                       new String[] { "-", "foo", "bar" },
                                       true);

        assertEquals(2, cl.getArgList().size());
        assertEquals("foo", cl.getArgList().get(0));
        assertEquals("bar", cl.getArgList().get(1));
    }

    public void testDoubleDashIsExcludedFromRemainingArgs() throws Exception
    {
        Options options = new Options().addOption("a", false, "a opt");
        Parser parser = new BasicParser();

        CommandLine cl = parser.parse(options, new String[] { "--", "-a" });

        assertFalse(cl.hasOption("a"));
        assertEquals(1, cl.getArgList().size());
        assertEquals("-a", cl.getArgList().get(0));
    }

    public void testOnlyOneDoubleDashKeptWhenTwoPresent() throws Exception
    {
        Options options = new Options();
        Parser parser = new BasicParser();

        CommandLine cl = parser.parse(options, new String[] { "--", "--", "foo" });

        assertEquals(1, cl.getArgList().size());
        assertEquals("foo", cl.getArgList().get(0));
    }

    public void testStopAtNonOptionArgument() throws Exception
    {
        Options options = new Options().addOption("a", false, "a opt");
        Parser parser = new BasicParser();

        CommandLine cl = parser.parse(options, new String[] { "foo", "-a" }, true);

        assertFalse(cl.hasOption("a"));
        assertEquals(2, cl.getArgList().size());
        assertEquals("foo", cl.getArgList().get(0));
        assertEquals("-a", cl.getArgList().get(1));
    }

    public void testStopAtNonOptionUnrecognizedOption() throws Exception
    {
        Options options = new Options().addOption("a", false, "a opt");
        Parser parser = new BasicParser();

        CommandLine cl = parser.parse(options,
                                       new String[] { "-a", "-z", "foo" },
                                       true);

        assertTrue(cl.hasOption("a"));
        assertEquals(2, cl.getArgList().size());
        assertEquals("-z", cl.getArgList().get(0));
        assertEquals("foo", cl.getArgList().get(1));
    }

    public void testQuotesAreStrippedFromOptionValue() throws Exception
    {
        Options options = new Options().addOption("b", true, "b opt");
        Parser parser = new BasicParser();

        CommandLine cl = parser.parse(options, new String[] { "-b", "\"quoted value\"" });

        assertEquals("quoted value", cl.getOptionValue("b"));
    }

    public void testOptionValuesAreClearedBetweenParses() throws Exception
    {
        Option b = new Option("b", "b opt");
        b.setArgs(1);
        b.setOptionalArg(true);
        Options options = new Options().addOption(b);
        Parser parser = new BasicParser();

        CommandLine first = parser.parse(options, new String[] { "-b", "first" });
        assertEquals("first", first.getOptionValue("b"));

        CommandLine second = parser.parse(options, new String[] { "-b" });
        assertTrue(second.hasOption("b"));
        assertNull("value from the previous parse must not leak (CLI-71)",
                   second.getOptionValue("b"));
    }

    public void testPropertyFillsOptionWithArgNotOnCommandLine() throws Exception
    {
        Options options = new Options().addOption("b", true, "b opt");
        Parser parser = new BasicParser();
        Properties props = new Properties();
        props.setProperty("b", "fromProps");

        CommandLine cl = parser.parse(options, new String[0], props);

        assertTrue(cl.hasOption("b"));
        assertEquals("fromProps", cl.getOptionValue("b"));
    }

    public void testPropertyDoesNotOverrideCommandLineValue() throws Exception
    {
        Options options = new Options().addOption("b", true, "b opt");
        Parser parser = new BasicParser();
        Properties props = new Properties();
        props.setProperty("b", "fromProps");

        CommandLine cl = parser.parse(options, new String[] { "-b", "fromCmd" }, props);

        assertEquals("fromCmd", cl.getOptionValue("b"));
    }

    public void testPropertyTrueEnablesFlagOption() throws Exception
    {
        Options options = new Options().addOption("c", false, "c opt");
        Parser parser = new BasicParser();
        Properties props = new Properties();
        props.setProperty("c", "true");

        CommandLine cl = parser.parse(options, new String[0], props);

        assertTrue(cl.hasOption("c"));
    }

    public void testPropertyFalseDoesNotEnableFlagOption() throws Exception
    {
        Options options = new Options().addOption("c", false, "c opt");
        Parser parser = new BasicParser();
        Properties props = new Properties();
        props.setProperty("c", "false");

        CommandLine cl = parser.parse(options, new String[0], props);

        assertFalse(cl.hasOption("c"));
    }

    public void testPropertiesAreAllProcessedIndependently() throws Exception
    {
        Options options = new Options()
            .addOption("f", false, "flag opt")
            .addOption("x", true, "arg opt");
        Parser parser = new BasicParser();
        OrderedProperties props = new OrderedProperties();
        // "f" is a no-arg option with a value that is not yes/true/1: it
        // must simply be skipped, without preventing later properties
        // (here "x") from still being processed.
        props.setProperty("f", "false");
        props.setProperty("x", "hello");

        CommandLine cl = parser.parse(options, new String[0], props);

        assertFalse(cl.hasOption("f"));
        assertTrue("property \"x\" should still be processed even though "
                   + "the earlier property \"f\" was a non-enabled flag",
                   cl.hasOption("x"));
        assertEquals("hello", cl.getOptionValue("x"));
    }

    public void testNullPropertiesAreIgnored() throws Exception
    {
        Options options = new Options().addOption("a", false, "a opt");
        Parser parser = new BasicParser();

        CommandLine cl = parser.parse(options, new String[0], (Properties) null);

        assertFalse(cl.hasOption("a"));
        assertEquals(0, cl.getArgList().size());
    }
}
