/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang;

import java.io.IOException;
import java.io.StringWriter;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Self-contained unit tests for {@link org.apache.commons.lang.Entities}.
 */
public class EntitiesAgentTest extends TestCase {

    public EntitiesAgentTest(String name) {
        super(name);
    }

    public static Test suite() {
        return new TestSuite(EntitiesAgentTest.class);
    }

    // ---- basic entity sets ----

    public void testXmlEntitiesKnown() {
        assertEquals(34, Entities.XML.entityValue("quot"));
        assertEquals(38, Entities.XML.entityValue("amp"));
        assertEquals(60, Entities.XML.entityValue("lt"));
        assertEquals(62, Entities.XML.entityValue("gt"));
        assertEquals(39, Entities.XML.entityValue("apos"));
        assertEquals("quot", Entities.XML.entityName(34));
        assertEquals("apos", Entities.XML.entityName(39));
    }

    public void testHtml32HasNoApos() {
        assertEquals(-1, Entities.HTML32.entityValue("apos"));
        assertEquals(160, Entities.HTML32.entityValue("nbsp"));
        assertEquals(255, Entities.HTML32.entityValue("yuml"));
    }

    public void testHtml40HasNoAposButHasHtml40Entities() {
        assertEquals(-1, Entities.HTML40.entityValue("apos"));
        assertEquals(34, Entities.HTML40.entityValue("quot"));
        assertEquals(160, Entities.HTML40.entityValue("nbsp"));
        assertEquals(8364, Entities.HTML40.entityValue("euro"));
        assertEquals(913, Entities.HTML40.entityValue("Alpha"));
    }

    public void testFillWithHtml40EntitiesPopulatesAllGroups() {
        Entities entities = new Entities();
        Entities.fillWithHtml40Entities(entities);
        assertEquals(34, entities.entityValue("quot"));
        assertEquals(160, entities.entityValue("nbsp"));
        assertEquals(8364, entities.entityValue("euro"));
    }

    public void testEntityValueUnknownNameReturnsMinusOne() {
        assertEquals(-1, Entities.XML.entityValue("notARealEntityName"));
    }

    public void testEntityValueNullNameReturnsMinusOne() {
        assertEquals(-1, Entities.XML.entityValue(null));
    }

    public void testEntityNameUnknownValueReturnsNull() {
        // Large value, not present in any map - falls through to the
        // underlying PrimitiveEntityMap lookup which must return null.
        assertNull(Entities.XML.entityName(999999));
    }

    // ---- escape ----

    public void testEscapeBasicXmlChars() {
        assertEquals("&quot;&amp;&lt;&gt;", Entities.XML.escape("\"&<>"));
    }

    public void testEscapePlainTextUnchanged() {
        assertEquals("hello world 123", Entities.XML.escape("hello world 123"));
    }

    public void testEscapeHighCharacterWithoutEntityUsesNumericReference() {
        // U+1234 has no entity name defined anywhere, so it must be
        // escaped as a decimal numeric character reference.
        String result = Entities.XML.escape("ሴ");
        assertEquals("&#4660;", result);
    }

    public void testEscapeHighCharacterWithEntityUsesName() {
        assertEquals("&copy;", Entities.HTML32.escape("©"));
    }

    public void testEscapeWriterMatchesEscapeString() throws IOException {
        String input = "plain \"quoted\" & © ሴ text";
        String expected = Entities.HTML40.escape(input);

        StringWriter writer = new StringWriter();
        Entities.HTML40.escape(writer, input);
        assertEquals(expected, writer.toString());
    }

    public void testEscapeEmptyString() {
        assertEquals("", Entities.XML.escape(""));
    }

    // ---- unescape ----

    public void testUnescapeBasicXmlChars() {
        assertEquals("\"&<>", Entities.XML.unescape("&quot;&amp;&lt;&gt;"));
    }

    public void testUnescapeDecimalNumericReference() {
        assertEquals("A", Entities.XML.unescape("&#65;"));
    }

    public void testUnescapeHexNumericReferenceLowerAndUpperX() {
        assertEquals("A", Entities.XML.unescape("&#x41;"));
        assertEquals("A", Entities.XML.unescape("&#X41;"));
    }

    public void testUnescapeUnknownEntityNameLeftLiteral() {
        assertEquals("&notAnEntity;", Entities.XML.unescape("&notAnEntity;"));
    }

    public void testUnescapeUnterminatedEntityLeftLiteral() {
        assertEquals("&quot no semicolon here", Entities.XML.unescape("&quot no semicolon here"));
    }

    public void testUnescapeEmptyEntityLeftLiteral() {
        assertEquals("&;", Entities.XML.unescape("&;"));
    }

    public void testUnescapeInvalidNumericReferenceLeftLiteral() {
        assertEquals("&#abc;", Entities.XML.unescape("&#abc;"));
    }

    public void testUnescapeNoAmpersandReturnsSameContent() {
        assertEquals("nothing special here", Entities.XML.unescape("nothing special here"));
    }

    public void testUnescapeAmpersandFollowedByAnotherAmpersandBeforeSemicolon() {
        // "&foo&amp;" : the first '&' starts a candidate entity "foo&amp"
        // but since another '&' appears before the terminating ';', the
        // first '&' is treated as literal text and scanning resumes from
        // the second '&', which is a valid "amp" entity.
        assertEquals("&foo&", Entities.XML.unescape("&foo&amp;"));
    }

    public void testUnescapeWriterMatchesUnescapeString() throws IOException {
        String input = "&quot;mix&#65;&#x42;&bogus;&amp;&foo&amp;";
        String expected = Entities.XML.unescape(input);

        StringWriter writer = new StringWriter();
        Entities.XML.unescape(writer, input);
        assertEquals(expected, writer.toString());
    }

    public void testEscapeUnescapeRoundTripForNumericReference() {
        String original = "☃"; // snowman, no named entity anywhere
        String escaped = Entities.XML.escape(original);
        assertEquals("&#9731;", escaped);
        assertEquals(original, Entities.XML.unescape(escaped));
    }

    // ---- Entities instance / addEntity / addEntities ----

    public void testAddEntityAndLookupBothWays() {
        Entities entities = new Entities();
        entities.addEntity("foo", 0xA1);
        assertEquals(0xA1, entities.entityValue("foo"));
        assertEquals("foo", entities.entityName(0xA1));
        assertEquals("&foo;", entities.escape("¡"));
        assertEquals("¡", entities.unescape("&foo;"));
    }

    public void testAddEntitiesArray() {
        Entities entities = new Entities();
        entities.addEntities(new String[][] { {"a", "1"}, {"b", "2"} });
        assertEquals(1, entities.entityValue("a"));
        assertEquals(2, entities.entityValue("b"));
    }

    // ---- ArrayEntityMap ----

    public void testArrayEntityMapAddAndLookup() {
        Entities.ArrayEntityMap map = new Entities.ArrayEntityMap();
        map.add("one", 1);
        map.add("two", 2);
        assertEquals(1, map.value("one"));
        assertEquals(2, map.value("two"));
        assertEquals("one", map.name(1));
        assertEquals("two", map.name(2));
        assertEquals(-1, map.value("missing"));
        assertNull(map.name(999));
    }

    public void testArrayEntityMapGrowsBeyondInitialCapacity() {
        int growBy = 3;
        Entities.ArrayEntityMap map = new Entities.ArrayEntityMap(growBy);
        for (int i = 0; i < 10; i++) {
            map.add("name" + i, i);
        }
        for (int i = 0; i < 10; i++) {
            assertEquals(i, map.value("name" + i));
            assertEquals("name" + i, map.name(i));
        }
    }

    // ---- BinaryEntityMap ----

    public void testBinaryEntityMapOrderedLookupAfterUnorderedInsertion() {
        Entities.BinaryEntityMap map = new Entities.BinaryEntityMap();
        map.add("five", 5);
        map.add("one", 1);
        map.add("three", 3);
        map.add("two", 2);
        map.add("four", 4);

        assertEquals("one", map.name(1));
        assertEquals("two", map.name(2));
        assertEquals("three", map.name(3));
        assertEquals("four", map.name(4));
        assertEquals("five", map.name(5));
        assertNull(map.name(6));

        assertEquals(1, map.value("one"));
        assertEquals(5, map.value("five"));
        assertEquals(-1, map.value("missing"));
    }

    public void testBinaryEntityMapDuplicateValueAtFirstSlotIsIgnored() {
        // Per the class's own contract ("this means you can't insert the
        // same value twice"), adding a second entry with a value that is
        // already present must be a silent no-op, regardless of where in
        // the sorted array that value happens to sit - including the very
        // first slot.
        Entities.BinaryEntityMap map = new Entities.BinaryEntityMap();
        map.add("first", 100);
        map.add("second", 100);

        assertEquals("first", map.name(100));
        assertEquals(100, map.value("first"));
        assertEquals(-1, map.value("second"));
    }

    // ---- HashEntityMap / TreeEntityMap ----

    public void testHashEntityMapAddAndLookup() {
        Entities.HashEntityMap map = new Entities.HashEntityMap();
        map.add("x", 10);
        map.add("y", 20);
        assertEquals(10, map.value("x"));
        assertEquals("y", map.name(20));
        assertEquals(-1, map.value("z"));
        assertNull(map.name(30));
    }

    public void testTreeEntityMapAddAndLookup() {
        Entities.TreeEntityMap map = new Entities.TreeEntityMap();
        map.add("x", 10);
        map.add("y", 20);
        assertEquals(10, map.value("x"));
        assertEquals("y", map.name(20));
        assertEquals(-1, map.value("z"));
        assertNull(map.name(30));
    }

    // ---- LookupEntityMap ----

    public void testLookupEntityMapSmallAndLargeValues() {
        Entities.LookupEntityMap map = new Entities.LookupEntityMap();
        map.add("small", 5);
        map.add("large", 500);
        assertEquals("small", map.name(5));
        assertEquals("large", map.name(500));
        assertEquals(5, map.value("small"));
        assertEquals(500, map.value("large"));
        assertNull(map.name(6));
        assertNull(map.name(999999));
    }

    public void testLookupEntityMapNegativeValueDoesNotThrow() {
        // entityName()/name() is documented to return the entity name
        // associated with a value, or (by symmetry with the >= lookup
        // table size case, and with ArrayEntityMap/BinaryEntityMap/
        // HashEntityMap/TreeEntityMap which all return null for an unknown
        // value) null when there is no such entity - it must not throw for
        // a value that simply isn't in the table, negative or otherwise.
        Entities.LookupEntityMap map = new Entities.LookupEntityMap();
        map.add("small", 5);
        assertNull(map.name(-1));
    }

    public void testEntityNameNegativeValueDoesNotThrow() {
        assertNull(Entities.XML.entityName(-1));
    }
}
