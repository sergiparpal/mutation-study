/*
 * Copyright (C) 2024 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.gson.stream;

import java.io.EOFException;
import java.io.IOException;
import java.io.StringReader;
import junit.framework.TestCase;

@SuppressWarnings("resource")
public final class JsonReaderAgentTest extends TestCase {

  public void testReadObject() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("{\"a\":\"android\",\"b\":\"banana\"}"));
    reader.beginObject();
    assertEquals(JsonToken.NAME, reader.peek());
    assertEquals("a", reader.nextName());
    assertEquals(JsonToken.STRING, reader.peek());
    assertEquals("android", reader.nextString());
    assertEquals("b", reader.nextName());
    assertEquals("banana", reader.nextString());
    reader.endObject();
    assertEquals(JsonToken.END_DOCUMENT, reader.peek());
  }

  public void testReadEmptyArray() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[]"));
    reader.beginArray();
    assertFalse(reader.hasNext());
    reader.endArray();
  }

  public void testReadArrayValues() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[true,false,null,1,2.5,\"s\"]"));
    reader.beginArray();
    assertTrue(reader.hasNext());
    assertTrue(reader.nextBoolean());
    assertFalse(reader.nextBoolean());
    reader.nextNull();
    assertEquals(1, reader.nextInt());
    assertEquals(2.5, reader.nextDouble());
    assertEquals("s", reader.nextString());
    assertFalse(reader.hasNext());
    reader.endArray();
  }

  public void testNextLongAndNextIntBoundaries() throws IOException {
    JsonReader reader = new JsonReader(new StringReader(
        "[" + Long.MAX_VALUE + "," + Long.MIN_VALUE + "]"));
    reader.beginArray();
    assertEquals(Long.MAX_VALUE, reader.nextLong());
    assertEquals(Long.MIN_VALUE, reader.nextLong());
    reader.endArray();
  }

  public void testNextIntOverflowFallsBackToDouble() throws IOException {
    // Value is too large for an int but has no fractional loss when read as a long,
    // so nextInt() must detect the precision loss and reject it.
    JsonReader reader = new JsonReader(new StringReader("[3000000000]"));
    reader.beginArray();
    try {
      reader.nextInt();
      fail();
    } catch (NumberFormatException expected) {
    }
  }

  public void testNumberAsString() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1,\"1\"]"));
    reader.beginArray();
    assertEquals(1, reader.nextInt());
    assertEquals("1", reader.nextString());
    reader.endArray();
  }

  public void testStringAsNumber() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[\"123\"]"));
    reader.beginArray();
    assertEquals(123, reader.nextInt());
    reader.endArray();
  }

  public void testMismatchedTypeThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[\"hello\"]"));
    reader.beginArray();
    try {
      reader.nextInt();
      fail();
    } catch (NumberFormatException expected) {
    }
  }

  public void testBeginArrayOnObjectThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("{}"));
    try {
      reader.beginArray();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testBeginObjectOnArrayThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[]"));
    try {
      reader.beginObject();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testEndArrayTooEarlyThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1,2]"));
    reader.beginArray();
    try {
      reader.endArray();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testNextNameOnValueThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1]"));
    reader.beginArray();
    try {
      reader.nextName();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testNextBooleanOnStringThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[\"true\"]"));
    reader.beginArray();
    try {
      reader.nextBoolean();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testPrematureEndOfInputThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("{"));
    reader.beginObject();
    try {
      reader.hasNext();
      fail();
    } catch (EOFException expected) {
    }
  }

  public void testMalformedNumbersAreStringsByDefault() throws IOException {
    // Not a well-formed number literal ('d'), so strict mode must reject it as a bare literal.
    JsonReader reader = new JsonReader(new StringReader("[1d]"));
    reader.setLenient(false);
    reader.beginArray();
    try {
      reader.nextInt();
      fail();
    } catch (MalformedJsonException expected) {
    }
  }

  public void testNonExecutePrefixRequiresLenient() {
    JsonReader reader = new JsonReader(new StringReader(")]}'\n[1]"));
    reader.setLenient(false);
    try {
      reader.beginArray();
      fail();
    } catch (IOException expected) {
    }
  }

  public void testNonExecutePrefixWithLenient() throws IOException {
    JsonReader reader = new JsonReader(new StringReader(")]}'\n[1]"));
    reader.setLenient(true);
    assertTrue(reader.isLenient());
    reader.beginArray();
    assertEquals(1, reader.nextInt());
    reader.endArray();
  }

  public void testUnquotedStringsRequireLenient() {
    JsonReader reader = new JsonReader(new StringReader("[a]"));
    reader.setLenient(false);
    try {
      reader.beginArray();
      reader.nextString();
      fail();
    } catch (IOException expected) {
    }
  }

  public void testUnquotedStringsWithLenient() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[a,b]"));
    reader.setLenient(true);
    reader.beginArray();
    assertEquals("a", reader.nextString());
    assertEquals("b", reader.nextString());
    reader.endArray();
  }

  public void testSingleQuotedStringsRequireLenient() {
    JsonReader reader = new JsonReader(new StringReader("['hi']"));
    reader.setLenient(false);
    try {
      reader.beginArray();
      reader.nextString();
      fail();
    } catch (IOException expected) {
    }
  }

  public void testStrictCommentsRejected() {
    JsonReader reader = new JsonReader(new StringReader("[1 // comment\n]"));
    reader.setLenient(false);
    try {
      reader.beginArray();
      reader.nextInt();
      reader.hasNext();
      fail();
    } catch (IOException expected) {
    }
  }

  public void testLenientCommentsSkipped() throws IOException {
    JsonReader reader = new JsonReader(
        new StringReader("[1, /* block */ 2 // line\n]"));
    reader.setLenient(true);
    reader.beginArray();
    assertEquals(1, reader.nextInt());
    assertEquals(2, reader.nextInt());
    reader.endArray();
  }

  public void testSkipValueSkipsNestedObject() throws IOException {
    JsonReader reader = new JsonReader(
        new StringReader("[1,{\"a\":[1,2,{\"c\":3}]},2]"));
    reader.beginArray();
    assertEquals(1, reader.nextInt());
    reader.skipValue();
    assertEquals(2, reader.nextInt());
    reader.endArray();
  }

  public void testSkipValueOnScalar() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[\"skip me\",2]"));
    reader.beginArray();
    reader.skipValue();
    assertEquals(2, reader.nextInt());
    reader.endArray();
  }

  public void testCloseThenOperationThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1]"));
    reader.close();
    try {
      reader.beginArray();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testNullReaderThrows() {
    try {
      new JsonReader(null);
      fail();
    } catch (NullPointerException expected) {
    }
  }

  public void testGetPathWithObjectsAndArrays() throws IOException {
    JsonReader reader = new JsonReader(
        new StringReader("{\"a\":[1,2,{\"b\":3}]}"));
    assertEquals("$", reader.getPath());
    reader.beginObject();
    reader.nextName();
    assertEquals("$.a", reader.getPath());
    reader.beginArray();
    reader.nextInt();
    assertEquals("$.a[1]", reader.getPath());
    reader.nextInt();
    reader.beginObject();
    reader.nextName();
    assertEquals("$.a[2].b", reader.getPath());
  }

  public void testEscapedCharactersInString() throws IOException {
    // JSON source: ["\"\\\n\tA"]  (quote, backslash, newline, tab, then A escape for 'A')
    String json = "[\"" + "\\\"" + "\\\\" + "\\n" + "\\t" + "\\u0041" + "\"]";
    JsonReader reader = new JsonReader(new StringReader(json));
    reader.beginArray();
    assertEquals("\"\\\n\tA", reader.nextString());
    reader.endArray();
  }

  public void testMultipleTopLevelValuesRequireLenient() {
    JsonReader reader = new JsonReader(new StringReader("[1][2]"));
    reader.setLenient(false);
    try {
      reader.beginArray();
      reader.nextInt();
      reader.endArray();
      reader.beginArray();
      fail();
    } catch (IOException expected) {
    }
  }

  public void testMultipleTopLevelValuesWithLenient() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1][2]"));
    reader.setLenient(true);
    reader.beginArray();
    assertEquals(1, reader.nextInt());
    reader.endArray();
    reader.beginArray();
    assertEquals(2, reader.nextInt());
    reader.endArray();
  }

  public void testTopLevelScalarKeywordAllowedEvenWhenStrict() throws IOException {
    // Unlike unquoted string literals, keyword scalars (true/false/null) and numbers
    // are not gated by checkLenient(), so they are readable at the top level even in
    // strict mode.
    JsonReader reader = new JsonReader(new StringReader("true"));
    reader.setLenient(false);
    assertTrue(reader.nextBoolean());
  }

  public void testTopLevelScalarWithLenient() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("true"));
    reader.setLenient(true);
    assertTrue(reader.nextBoolean());
  }

  public void testToStringContainsLineAndColumn() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1]"));
    String s = reader.toString();
    assertTrue(s.contains("line"));
    assertTrue(s.contains("column"));
  }

  public void testCaseInsensitiveKeywordsRequireLenient() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[TRUE,FALSE,NULL]"));
    reader.setLenient(true);
    reader.beginArray();
    assertTrue(reader.nextBoolean());
    assertFalse(reader.nextBoolean());
    reader.nextNull();
    reader.endArray();
  }

  public void testLongBuiltFromManyDigitsOverflowsToDouble() throws IOException {
    // 20 nines overflow a long, so the reader must fall back to double parsing.
    JsonReader reader = new JsonReader(new StringReader("[99999999999999999999]"));
    reader.beginArray();
    double d = reader.nextDouble();
    assertEquals(1.0E20, d);
    reader.endArray();
  }

  public void testNanAndInfinityRejectedByDefault() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[\"NaN\"]"));
    reader.beginArray();
    try {
      reader.nextDouble();
      fail();
    } catch (MalformedJsonException expected) {
    }
  }

  public void testNanAndInfinityAcceptedWhenLenientValuesUsed() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[NaN,Infinity,-Infinity]"));
    reader.setLenient(true);
    reader.beginArray();
    assertTrue(Double.isNaN(reader.nextDouble()));
    assertTrue(Double.isInfinite(reader.nextDouble()));
    assertTrue(Double.isInfinite(reader.nextDouble()));
    reader.endArray();
  }
}
