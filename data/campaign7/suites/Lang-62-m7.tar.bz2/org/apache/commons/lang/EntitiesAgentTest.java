package org.apache.commons.lang;

import java.io.IOException;
import java.io.StringWriter;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Self-contained unit tests for {@link org.apache.commons.lang.Entities}.
 */
public class EntitiesAgentTest extends TestCase {

    public EntitiesAgentTest(String name) {
        super(name);
    }

    public static Test suite() {
        return new TestSuite(EntitiesAgentTest.class);
    }

    // -- escape(String) --------------------------------------------------

    public void testEscapeBasicXml() {
        assertEquals("&amp;&lt;&gt;&quot;&apos;", Entities.XML.escape("&<>\"'"));
    }

    public void testEscapeNoSpecialCharacters() {
        String plain = "hello world 123";
        assertEquals(plain, Entities.XML.escape(plain));
    }

    public void testEscapeEmptyString() {
        assertEquals("", Entities.XML.escape(""));
    }

    public void testEscapeUnmappedHighCharacterUsesNumericReference() {
        // U+00E9 (eacute) is not in the XML entity set, so it must be
        // emitted as a decimal numeric character reference.
        assertEquals("&#233;", Entities.XML.escape("é"));
    }

    public void testEscapeMappedHighCharacterUsesName() {
        // eacute (233) is part of HTML40.
        assertEquals("&eacute;", Entities.HTML40.escape("é"));
    }

    public void testEscapeLowAsciiControlCharacterPassesThrough() {
        assertEquals("\u0001", Entities.XML.escape("\u0001"));
    }

    // -- escape(Writer, String) ------------------------------------------

    public void testEscapeToWriterMatchesStringResult() throws IOException {
        String input = "<a href=\"x\">&eacute;</a>";
        StringWriter writer = new StringWriter();
        Entities.HTML40.escape(writer, input);
        assertEquals(Entities.HTML40.escape(input), writer.toString());
    }

    public void testEscapeToWriterPropagatesIOException() {
        final IOException boom = new IOException("boom");
        java.io.Writer failingWriter = new java.io.Writer() {
            public void write(char[] cbuf, int off, int len) throws IOException {
                throw boom;
            }
            public void flush() throws IOException {
            }
            public void close() throws IOException {
            }
        };
        try {
            Entities.XML.escape(failingWriter, "&");
            fail("Expected IOException to propagate");
        } catch (IOException e) {
            assertSame(boom, e);
        }
    }

    // -- unescape(String) --------------------------------------------------

    public void testUnescapeBasicXml() {
        assertEquals("&<>\"'", Entities.XML.unescape("&amp;&lt;&gt;&quot;&apos;"));
    }

    public void testUnescapeNoAmpersandReturnsSameContent() {
        String plain = "no entities here";
        assertEquals(plain, Entities.XML.unescape(plain));
    }

    public void testUnescapeEmptyString() {
        assertEquals("", Entities.XML.unescape(""));
    }

    public void testUnescapeUnknownEntityIsLeftAsIs() {
        assertEquals("&bogus;", Entities.XML.unescape("&bogus;"));
    }

    public void testUnescapeMissingSemicolonIsLeftAsIs() {
        String input = "&amp no semicolon";
        assertEquals(input, Entities.XML.unescape(input));
    }

    public void testUnescapeEmptyEntityNameIsLeftAsIs() {
        assertEquals("&;", Entities.XML.unescape("&;"));
    }

    public void testUnescapeDecimalNumericReference() {
        assertEquals("é", Entities.XML.unescape("&#233;"));
    }

    public void testUnescapeHexNumericReference() {
        assertEquals("é", Entities.XML.unescape("&#x00E9;"));
    }

    public void testUnescapeHexNumericReferenceLowercaseX() {
        assertEquals("é", Entities.XML.unescape("&#xE9;"));
    }

    public void testUnescapeNumericReferenceOutOfRangeIsLeftAsIs() {
        // 0x10000 exceeds the supported char range and must not be converted.
        String input = "&#65536;";
        assertEquals(input, Entities.XML.unescape(input));
    }

    public void testUnescapeHashOnlyIsLeftAsIs() {
        assertEquals("&#;", Entities.XML.unescape("&#;"));
    }

    public void testUnescapeMalformedNumericReferenceIsLeftAsIs() {
        String input = "&#abc;";
        assertEquals(input, Entities.XML.unescape(input));
    }

    public void testUnescapeAdjacentAmpersandBeforeSemicolonLeavesFirstAmpersandLiteral() {
        // "&amp&lt;;" has an '&' before the ';' terminating the first entity,
        // so that first '&' is treated as a literal and only the trailing
        // "&lt;" is decoded.
        assertEquals("&amp<;", Entities.XML.unescape("&amp&lt;;"));
    }

    public void testUnescapeTrailingAmpersandWithoutSemicolonIsLeftAsIs() {
        String input = "abc&amp";
        assertEquals(input, Entities.XML.unescape(input));
    }

    // -- unescape(Writer, String) ------------------------------------------

    public void testUnescapeToWriterMatchesStringResult() throws IOException {
        String input = "&lt;tag&gt;&eacute;&amp;";
        StringWriter writer = new StringWriter();
        Entities.HTML40.unescape(writer, input);
        assertEquals(Entities.HTML40.unescape(input), writer.toString());
    }

    public void testUnescapeToWriterNoAmpersandWritesOriginal() throws IOException {
        StringWriter writer = new StringWriter();
        Entities.XML.unescape(writer, "plain text");
        assertEquals("plain text", writer.toString());
    }

    public void testUnescapeToWriterPropagatesIOException() {
        final IOException boom = new IOException("boom");
        java.io.Writer failingWriter = new java.io.Writer() {
            public void write(char[] cbuf, int off, int len) throws IOException {
                throw boom;
            }
            public void flush() throws IOException {
            }
            public void close() throws IOException {
            }
        };
        try {
            Entities.XML.unescape(failingWriter, "text with no ampersand");
            fail("Expected IOException to propagate");
        } catch (IOException e) {
            assertSame(boom, e);
        }
    }

    // -- addEntity / entityName / entityValue ------------------------------

    public void testAddEntityAndLookupByNameAndValue() {
        Entities entities = new Entities();
        entities.addEntity("foo", 0xA1);
        assertEquals(0xA1, entities.entityValue("foo"));
        assertEquals("foo", entities.entityName(0xA1));
    }

    public void testEntityValueUnknownNameReturnsMinusOne() {
        Entities entities = new Entities();
        assertEquals(-1, entities.entityValue("doesNotExist"));
    }

    public void testEntityNameUnknownValueReturnsNull() {
        Entities entities = new Entities();
        assertNull(entities.entityName(999999));
    }

    public void testEntityValueIsCaseSensitive() {
        Entities entities = new Entities();
        entities.addEntity("Foo", 5);
        assertEquals(-1, entities.entityValue("foo"));
        assertEquals(5, entities.entityValue("Foo"));
    }

    public void testAddEntitiesArray() {
        Entities entities = new Entities();
        String[][] array = {
            {"one", "1"},
            {"two", "2"},
        };
        entities.addEntities(array);
        assertEquals(1, entities.entityValue("one"));
        assertEquals(2, entities.entityValue("two"));
    }

    public void testCustomEntityRoundTripsThroughEscapeAndUnescape() {
        Entities entities = new Entities();
        entities.addEntity("foo", 0xA1);
        assertEquals("&foo;", entities.escape("¡"));
        assertEquals("¡", entities.unescape("&foo;"));
    }

    // -- static shared instances --------------------------------------------

    public void testXmlDoesNotKnowHtmlOnlyEntities() {
        assertEquals(-1, Entities.XML.entityValue("nbsp"));
    }

    public void testHtml32KnowsNbspButNotApos() {
        assertEquals(160, Entities.HTML32.entityValue("nbsp"));
        assertEquals(-1, Entities.HTML32.entityValue("apos"));
    }

    public void testHtml40KnowsGreekLetters() {
        assertEquals(945, Entities.HTML40.entityValue("alpha"));
        assertEquals("alpha", Entities.HTML40.entityName(945));
    }

    public void testXmlKnowsAposUnlikeHtml32() {
        assertEquals(39, Entities.XML.entityValue("apos"));
        assertEquals(-1, Entities.HTML32.entityValue("apos"));
    }

    // -- EntityMap implementations ------------------------------------------

    public void testArrayEntityMapAddAndLookup() {
        Entities.ArrayEntityMap map = new Entities.ArrayEntityMap();
        map.add("amp", 38);
        assertEquals(38, map.value("amp"));
        assertEquals("amp", map.name(38));
        assertEquals(-1, map.value("missing"));
        assertNull(map.name(999));
    }

    public void testArrayEntityMapGrowsBeyondInitialCapacity() {
        Entities.ArrayEntityMap map = new Entities.ArrayEntityMap(2);
        for (int i = 0; i < 10; i++) {
            map.add("e" + i, i);
        }
        for (int i = 0; i < 10; i++) {
            assertEquals(i, map.value("e" + i));
            assertEquals("e" + i, map.name(i));
        }
    }

    public void testHashEntityMapAddAndLookup() {
        Entities.HashEntityMap map = new Entities.HashEntityMap();
        map.add("lt", 60);
        assertEquals(60, map.value("lt"));
        assertEquals("lt", map.name(60));
        assertEquals(-1, map.value("missing"));
    }

    public void testTreeEntityMapAddAndLookup() {
        Entities.TreeEntityMap map = new Entities.TreeEntityMap();
        map.add("gt", 62);
        assertEquals(62, map.value("gt"));
        assertEquals("gt", map.name(62));
        assertEquals(-1, map.value("missing"));
    }

    public void testPrimitiveEntityMapAddAndLookup() {
        Entities.PrimitiveEntityMap map = new Entities.PrimitiveEntityMap();
        map.add("quot", 34);
        assertEquals(34, map.value("quot"));
        assertEquals("quot", map.name(34));
        assertEquals(-1, map.value("missing"));
    }

    public void testLookupEntityMapUsesTableForLowValuesAndFallsBackAbove() {
        Entities.LookupEntityMap map = new Entities.LookupEntityMap();
        map.add("amp", 38);
        map.add("euro", 8364);
        assertEquals("amp", map.name(38));
        assertEquals("euro", map.name(8364));
        assertNull(map.name(39));
    }

    public void testBinaryEntityMapAddAndLookupSorted() {
        Entities.BinaryEntityMap map = new Entities.BinaryEntityMap();
        map.add("gt", 62);
        map.add("amp", 38);
        map.add("lt", 60);
        assertEquals("amp", map.name(38));
        assertEquals("lt", map.name(60));
        assertEquals("gt", map.name(62));
        assertNull(map.name(1));
    }

    public void testBinaryEntityMapRejectsDuplicateValue() {
        Entities.BinaryEntityMap map = new Entities.BinaryEntityMap();
        map.add("a", 10);
        map.add("b", 20);
        map.add("c", 30);
        map.add("bb", 20);
        // Per the documented behavior, inserting the same value twice is a no-op,
        // so the first name registered for that value wins.
        assertEquals("b", map.name(20));
        assertEquals(3, map.size);
    }

    public void testFillWithHtml40EntitiesPopulatesBasicIsoAndHtml40Sets() {
        Entities entities = new Entities();
        Entities.fillWithHtml40Entities(entities);
        assertEquals(38, entities.entityValue("amp"));
        assertEquals(160, entities.entityValue("nbsp"));
        assertEquals(945, entities.entityValue("alpha"));
    }
}
