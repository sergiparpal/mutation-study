/*
 * Copyright (C) 2014 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.gson.internal;

import java.lang.reflect.Constructor;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import junit.framework.TestCase;

public final class $Gson$TypesAgentTest extends TestCase {

  // ---- fixtures -----------------------------------------------------

  private static final class Box<T> {
  }

  private static final class Box2<T> {
  }

  private static abstract class StringList extends ArrayList<String> {
  }

  private static abstract class StringToIntegerMap extends HashMap<String, Integer> {
  }

  // ---- newParameterizedTypeWithOwner ---------------------------------

  public void testNewParameterizedTypeWithOwner_basic() {
    ParameterizedType type =
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    assertEquals(List.class, type.getRawType());
    assertNull(type.getOwnerType());
    assertEquals(1, type.getActualTypeArguments().length);
    assertEquals(String.class, type.getActualTypeArguments()[0]);
    assertEquals("java.util.List<java.lang.String>", type.toString());
  }

  public void testNewParameterizedTypeWithOwner_noTypeArguments() {
    ParameterizedType type = $Gson$Types.newParameterizedTypeWithOwner(null, List.class);
    assertEquals("java.util.List", type.toString());
  }

  public void testNewParameterizedTypeWithOwner_nonStaticInnerClassRequiresOwner() {
    class LocalNonStatic {
    }
    try {
      $Gson$Types.newParameterizedTypeWithOwner(null, LocalNonStatic.class, String.class);
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  public void testNewParameterizedTypeWithOwner_staticInnerClassDoesNotRequireOwner() {
    ParameterizedType type =
        $Gson$Types.newParameterizedTypeWithOwner(null, Box.class, String.class);
    assertEquals(Box.class, type.getRawType());
  }

  public void testNewParameterizedTypeWithOwner_primitiveArgumentRejected() {
    try {
      $Gson$Types.newParameterizedTypeWithOwner(null, List.class, int.class);
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  public void testNewParameterizedTypeWithOwner_nullArgumentRejected() {
    try {
      $Gson$Types.newParameterizedTypeWithOwner(null, List.class, (Type) null);
      fail();
    } catch (NullPointerException expected) {
    }
  }

  // ---- arrayOf ---------------------------------------------------------

  public void testArrayOf() {
    GenericArrayType arrayType = $Gson$Types.arrayOf(String.class);
    assertEquals(String.class, arrayType.getGenericComponentType());
    assertEquals("java.lang.String[]", arrayType.toString());
  }

  // ---- subtypeOf / supertypeOf ------------------------------------------

  public void testSubtypeOf_withClassBound() {
    WildcardType wildcard = $Gson$Types.subtypeOf(Number.class);
    assertEquals(1, wildcard.getUpperBounds().length);
    assertEquals(Number.class, wildcard.getUpperBounds()[0]);
    assertEquals(0, wildcard.getLowerBounds().length);
    assertEquals("? extends java.lang.Number", wildcard.toString());
  }

  public void testSubtypeOf_withObjectBound() {
    WildcardType wildcard = $Gson$Types.subtypeOf(Object.class);
    assertEquals("?", wildcard.toString());
  }

  public void testSubtypeOf_unwrapsNestedWildcard() {
    WildcardType inner = $Gson$Types.subtypeOf(Number.class);
    WildcardType outer = $Gson$Types.subtypeOf(inner);
    assertEquals(1, outer.getUpperBounds().length);
    assertEquals(Number.class, outer.getUpperBounds()[0]);
    assertEquals("? extends java.lang.Number", outer.toString());
  }

  public void testSupertypeOf() {
    WildcardType wildcard = $Gson$Types.supertypeOf(String.class);
    assertEquals(1, wildcard.getLowerBounds().length);
    assertEquals(String.class, wildcard.getLowerBounds()[0]);
    assertEquals(1, wildcard.getUpperBounds().length);
    assertEquals(Object.class, wildcard.getUpperBounds()[0]);
    assertEquals("? super java.lang.String", wildcard.toString());
  }

  public void testSupertypeOf_unwrapsNestedWildcard() {
    WildcardType inner = $Gson$Types.supertypeOf(String.class);
    WildcardType outer = $Gson$Types.supertypeOf(inner);
    assertEquals(1, outer.getLowerBounds().length);
    assertEquals(String.class, outer.getLowerBounds()[0]);
    assertEquals("? super java.lang.String", outer.toString());
  }

  // ---- canonicalize ------------------------------------------------------

  public void testCanonicalize_nonArrayClassIsIdentity() {
    Type canonical = $Gson$Types.canonicalize(String.class);
    assertSame(String.class, canonical);
  }

  public void testCanonicalize_arrayClassBecomesGenericArrayType() {
    Type canonical = $Gson$Types.canonicalize(String[].class);
    assertTrue(canonical instanceof GenericArrayType);
    assertEquals(String.class, ((GenericArrayType) canonical).getGenericComponentType());
  }

  public void testCanonicalize_parameterizedType() {
    ParameterizedType original =
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    Type canonical = $Gson$Types.canonicalize(original);
    assertTrue(canonical instanceof ParameterizedType);
    assertTrue($Gson$Types.equals(original, canonical));
  }

  public void testCanonicalize_genericArrayType() {
    GenericArrayType custom = new GenericArrayType() {
      public Type getGenericComponentType() {
        return String.class;
      }
    };
    Type canonical = $Gson$Types.canonicalize(custom);
    assertNotSame(custom, canonical);
    assertTrue($Gson$Types.equals(custom, canonical));
  }

  public void testCanonicalize_wildcardType() {
    WildcardType custom = new WildcardType() {
      public Type[] getUpperBounds() {
        return new Type[] { Number.class };
      }
      public Type[] getLowerBounds() {
        return new Type[0];
      }
    };
    Type canonical = $Gson$Types.canonicalize(custom);
    assertNotSame(custom, canonical);
    assertTrue($Gson$Types.equals(custom, canonical));
  }

  public void testCanonicalize_unsupportedTypeReturnsSameInstance() {
    TypeVariable<?> typeVariable = Box.class.getTypeParameters()[0];
    Type canonical = $Gson$Types.canonicalize(typeVariable);
    assertSame(typeVariable, canonical);
  }

  // ---- getRawType ---------------------------------------------------------

  public void testGetRawType_class() {
    assertEquals(String.class, $Gson$Types.getRawType(String.class));
  }

  public void testGetRawType_parameterizedType() {
    Type type = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    assertEquals(List.class, $Gson$Types.getRawType(type));
  }

  public void testGetRawType_genericArrayType() {
    Type type = $Gson$Types.arrayOf(String.class);
    assertEquals(String[].class, $Gson$Types.getRawType(type));
  }

  public void testGetRawType_typeVariable() {
    TypeVariable<?> typeVariable = Box.class.getTypeParameters()[0];
    assertEquals(Object.class, $Gson$Types.getRawType(typeVariable));
  }

  public void testGetRawType_wildcardType() {
    WildcardType wildcard = $Gson$Types.subtypeOf(Number.class);
    assertEquals(Number.class, $Gson$Types.getRawType(wildcard));
  }

  public void testGetRawType_unsupportedTypeThrows() {
    Type unsupported = new Type() {
    };
    try {
      $Gson$Types.getRawType(unsupported);
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  public void testGetRawType_nullThrows() {
    try {
      $Gson$Types.getRawType(null);
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  // ---- equals ---------------------------------------------------------------

  public void testEquals_sameReference() {
    assertTrue($Gson$Types.equals(String.class, String.class));
    assertTrue($Gson$Types.equals(null, null));
  }

  public void testEquals_classes() {
    assertTrue($Gson$Types.equals(String.class, String.class));
    assertFalse($Gson$Types.equals(String.class, Integer.class));
  }

  public void testEquals_parameterizedTypes() {
    Type a = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    Type b = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    Type c = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, Integer.class);
    assertTrue($Gson$Types.equals(a, b));
    assertFalse($Gson$Types.equals(a, c));
    assertFalse($Gson$Types.equals(a, Integer.class));
  }

  public void testEquals_genericArrayTypes() {
    Type a = $Gson$Types.arrayOf(String.class);
    Type b = $Gson$Types.arrayOf(String.class);
    Type c = $Gson$Types.arrayOf(Integer.class);
    assertTrue($Gson$Types.equals(a, b));
    assertFalse($Gson$Types.equals(a, c));
    assertFalse($Gson$Types.equals(a, String.class));
  }

  public void testEquals_wildcardTypes() {
    WildcardType a = $Gson$Types.subtypeOf(Number.class);
    WildcardType b = $Gson$Types.subtypeOf(Number.class);
    WildcardType c = $Gson$Types.supertypeOf(Number.class);
    assertTrue($Gson$Types.equals(a, b));
    assertFalse($Gson$Types.equals(a, c));
    assertFalse($Gson$Types.equals(a, Number.class));
  }

  public void testEquals_typeVariables() {
    TypeVariable<?> a1 = Box.class.getTypeParameters()[0];
    TypeVariable<?> a2 = Box.class.getTypeParameters()[0];
    TypeVariable<?> b = Box2.class.getTypeParameters()[0];
    assertTrue($Gson$Types.equals(a1, a2));
    assertFalse($Gson$Types.equals(a1, b));
    assertFalse($Gson$Types.equals(a1, String.class));
  }

  public void testEquals_differentKinds() {
    Type parameterized = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    WildcardType wildcard = $Gson$Types.subtypeOf(Number.class);
    assertFalse($Gson$Types.equals(parameterized, wildcard));
    assertFalse($Gson$Types.equals(wildcard, parameterized));
  }

  public void testEquals_nullHandling() {
    assertFalse($Gson$Types.equals(null, String.class));
    assertFalse($Gson$Types.equals(String.class, null));
  }

  // ---- typeToString -----------------------------------------------------------

  public void testTypeToString_class() {
    assertEquals("java.lang.String", $Gson$Types.typeToString(String.class));
  }

  public void testTypeToString_parameterizedType() {
    Type type = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    assertEquals("java.util.List<java.lang.String>", $Gson$Types.typeToString(type));
  }

  // ---- getArrayComponentType ------------------------------------------------

  public void testGetArrayComponentType_genericArrayType() {
    Type arrayType = $Gson$Types.arrayOf(String.class);
    assertEquals(String.class, $Gson$Types.getArrayComponentType(arrayType));
  }

  public void testGetArrayComponentType_classArray() {
    assertEquals(String.class, $Gson$Types.getArrayComponentType(String[].class));
  }

  public void testGetArrayComponentType_nonArrayClassReturnsNull() {
    assertNull($Gson$Types.getArrayComponentType(String.class));
  }

  // ---- getCollectionElementType -----------------------------------------------

  public void testGetCollectionElementType_direct() {
    Type listOfString = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    Type elementType = $Gson$Types.getCollectionElementType(listOfString, List.class);
    assertEquals(String.class, elementType);
  }

  public void testGetCollectionElementType_viaSubclass() {
    Type elementType = $Gson$Types.getCollectionElementType(StringList.class, StringList.class);
    assertEquals(String.class, elementType);
  }

  public void testGetCollectionElementType_rawFallbackIsObject() {
    Type elementType = $Gson$Types.getCollectionElementType(Collection.class, Collection.class);
    assertEquals(Object.class, elementType);
  }

  public void testGetCollectionElementType_notCollectionThrows() {
    try {
      $Gson$Types.getCollectionElementType(String.class, String.class);
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  // ---- getMapKeyAndValueTypes --------------------------------------------------

  public void testGetMapKeyAndValueTypes_direct() {
    Type mapType =
        $Gson$Types.newParameterizedTypeWithOwner(null, Map.class, String.class, Integer.class);
    Type[] types = $Gson$Types.getMapKeyAndValueTypes(mapType, Map.class);
    assertEquals(2, types.length);
    assertEquals(String.class, types[0]);
    assertEquals(Integer.class, types[1]);
  }

  public void testGetMapKeyAndValueTypes_viaSubclass() {
    Type[] types =
        $Gson$Types.getMapKeyAndValueTypes(StringToIntegerMap.class, StringToIntegerMap.class);
    assertEquals(2, types.length);
    assertEquals(String.class, types[0]);
    assertEquals(Integer.class, types[1]);
  }

  public void testGetMapKeyAndValueTypes_propertiesSpecialCase() {
    Type[] types = $Gson$Types.getMapKeyAndValueTypes(Properties.class, Properties.class);
    assertEquals(2, types.length);
    assertEquals(String.class, types[0]);
    assertEquals(String.class, types[1]);
  }

  public void testGetMapKeyAndValueTypes_rawFallbackIsObjectObject() {
    Type[] types = $Gson$Types.getMapKeyAndValueTypes(Map.class, Map.class);
    assertEquals(2, types.length);
    assertEquals(Object.class, types[0]);
    assertEquals(Object.class, types[1]);
  }

  // ---- resolve -----------------------------------------------------------------

  public void testResolve_nonGenericTypeIsIdentity() {
    Type resolved = $Gson$Types.resolve(String.class, String.class, Integer.class);
    assertSame(Integer.class, resolved);
  }

  public void testResolve_arrayWithUnchangedComponentReturnsSameInstance() {
    Type resolved = $Gson$Types.resolve(String.class, String.class, String[].class);
    assertSame(String[].class, resolved);
  }

  public void testResolve_typeVariableThroughHierarchy() {
    Type listOfString = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    TypeVariable<?> elementVariable = List.class.getTypeParameters()[0];
    Type resolved = $Gson$Types.resolve(listOfString, List.class, elementVariable);
    assertEquals(String.class, resolved);
  }

  // ---- getGenericSupertype / getSupertype --------------------------------------

  public void testGetGenericSupertype_sameTypeReturnsContext() {
    Type context = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    Type result = $Gson$Types.getGenericSupertype(context, List.class, List.class);
    assertSame(context, result);
  }

  public void testGetGenericSupertype_unrelatedTypeReturnsToResolveUnchanged() {
    Type result = $Gson$Types.getGenericSupertype(Integer.class, Integer.class, List.class);
    assertSame(List.class, result);
  }

  public void testGetSupertype_invalidSupertypeThrows() {
    try {
      $Gson$Types.getSupertype(String.class, String.class, List.class);
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  public void testGetSupertype_resolvesCollectionOfStringList() {
    Type result = $Gson$Types.getSupertype(StringList.class, StringList.class, Collection.class);
    assertTrue(result instanceof ParameterizedType);
    assertEquals(String.class, ((ParameterizedType) result).getActualTypeArguments()[0]);
  }

  // ---- resolveTypeVariable -------------------------------------------------------

  public void testResolveTypeVariable_resolvesThroughSubclass() {
    // ArrayList is StringList's direct superclass, so this is a single-step resolution;
    // resolveTypeVariable() (unlike resolve()) does not walk multiple inheritance levels.
    TypeVariable<?> elementVariable = ArrayList.class.getTypeParameters()[0];
    Type resolved = $Gson$Types.resolveTypeVariable(StringList.class, StringList.class, elementVariable);
    assertEquals(String.class, resolved);
  }

  public void testResolveTypeVariable_unrelatedReturnsUnknownUnchanged() {
    TypeVariable<?> boxVariable = Box.class.getTypeParameters()[0];
    Type resolved = $Gson$Types.resolveTypeVariable(Integer.class, Integer.class, boxVariable);
    assertSame(boxVariable, resolved);
  }

  // ---- small package-private helpers ------------------------------------------------

  public void testCheckNotPrimitive() {
    try {
      $Gson$Types.checkNotPrimitive(int.class);
      fail();
    } catch (IllegalArgumentException expected) {
    }
    // non-primitive type must not throw
    $Gson$Types.checkNotPrimitive(Integer.class);
  }

  public void testEqualHelper() {
    assertTrue($Gson$Types.equal(null, null));
    assertTrue($Gson$Types.equal("x", "x"));
    assertFalse($Gson$Types.equal("x", "y"));
    assertFalse($Gson$Types.equal(null, "x"));
    assertFalse($Gson$Types.equal("x", null));
  }

  public void testHashCodeOrZero() {
    assertEquals(0, $Gson$Types.hashCodeOrZero(null));
    assertEquals("abc".hashCode(), $Gson$Types.hashCodeOrZero("abc"));
  }

  // ---- private constructor ---------------------------------------------------------

  public void testPrivateConstructorThrows() throws Exception {
    Constructor<$Gson$Types> constructor = $Gson$Types.class.getDeclaredConstructor();
    constructor.setAccessible(true);
    try {
      constructor.newInstance();
      fail();
    } catch (InvocationTargetException expected) {
      assertTrue(expected.getCause() instanceof UnsupportedOperationException);
    }
  }
}
