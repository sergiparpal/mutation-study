/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang.time;

import java.util.Calendar;
import java.util.TimeZone;

import junit.framework.TestCase;

/**
 * Self-contained tests for {@link DurationFormatUtils}.
 */
public class DurationFormatUtilsAgentTest extends TestCase {

    private static final long MILLIS_PER_SECOND = 1000L;
    private static final long MILLIS_PER_MINUTE = 60L * MILLIS_PER_SECOND;
    private static final long MILLIS_PER_HOUR = 60L * MILLIS_PER_MINUTE;
    private static final long MILLIS_PER_DAY = 24L * MILLIS_PER_HOUR;
    private static final TimeZone UTC = TimeZone.getTimeZone("UTC");

    //-----------------------------------------------------------------------
    // formatDurationHMS
    //-----------------------------------------------------------------------

    public void testFormatDurationHMSZero() {
        assertEquals("0:00:00.000", DurationFormatUtils.formatDurationHMS(0L));
    }

    public void testFormatDurationHMSTypical() {
        // 1 hour, 1 minute, 1 second, 1 millisecond
        long millis = MILLIS_PER_HOUR + MILLIS_PER_MINUTE + MILLIS_PER_SECOND + 1L;
        assertEquals("1:01:01.001", DurationFormatUtils.formatDurationHMS(millis));
    }

    public void testFormatDurationHMSHoursNotWrappedToDays() {
        // no 'd' token exists in "H:mm:ss.SSS", so hours accumulate past 24
        long millis = 25 * MILLIS_PER_HOUR + 2 * MILLIS_PER_MINUTE + 3 * MILLIS_PER_SECOND + 4L;
        assertEquals("25:02:03.004", DurationFormatUtils.formatDurationHMS(millis));
    }

    /**
     * BUG: formatDurationHMS (via formatDuration) casts the hours quotient to
     * int. For a sufficiently large duration this quotient overflows a
     * 32-bit int, silently producing a wrong (and even negative) hour count
     * instead of the true value.
     */
    public void testFormatDurationHMSLargeDurationHourOverflow() {
        long millis = Long.MAX_VALUE;
        long expectedHours = millis / MILLIS_PER_HOUR;
        String result = DurationFormatUtils.formatDurationHMS(millis);
        String hoursPart = result.substring(0, result.indexOf(':'));
        assertEquals(Long.toString(expectedHours), hoursPart);
    }

    //-----------------------------------------------------------------------
    // formatDurationISO
    //-----------------------------------------------------------------------

    public void testFormatDurationISOZero() {
        assertEquals("P0Y0M0DT0H0M0.000S", DurationFormatUtils.formatDurationISO(0L));
    }

    public void testFormatDurationISOTypical() {
        // 1 day, 2 hours, 3 minutes, 4.005 seconds
        long millis = MILLIS_PER_DAY + 2 * MILLIS_PER_HOUR + 3 * MILLIS_PER_MINUTE + 4005L;
        assertEquals("P0Y0M1DT2H3M4.005S", DurationFormatUtils.formatDurationISO(millis));
    }

    //-----------------------------------------------------------------------
    // formatDuration(millis, format[, padWithZeros])
    //-----------------------------------------------------------------------

    public void testFormatDurationDefaultPadding() {
        // default 2-arg overload pads with zeros
        assertEquals("05", DurationFormatUtils.formatDuration(5000L, "ss"));
    }

    public void testFormatDurationNoPadding() {
        assertEquals("5", DurationFormatUtils.formatDuration(5000L, "s", false));
    }

    public void testFormatDurationPadDoesNotTruncateWiderValues() {
        // pad width is smaller than the actual number of digits: value must
        // not be truncated, only left as-is
        long millis = 100 * MILLIS_PER_DAY;
        assertEquals("100", DurationFormatUtils.formatDuration(millis, "dd", true));
    }

    public void testFormatDurationYearsAndMonthsAlwaysZero() {
        // formatDuration only ever resolves days and smaller; year/month
        // tokens are always rendered as 0 regardless of the input duration
        assertEquals("0000y", DurationFormatUtils.formatDuration(123456789L, "yyyy'y'", true));
    }

    public void testFormatDurationEmptyFormatYieldsEmptyString() {
        assertEquals("", DurationFormatUtils.formatDuration(12345L, ""));
    }

    public void testFormatDurationNullFormatThrowsNPE() {
        try {
            DurationFormatUtils.formatDuration(1000L, null);
            fail("Expected NullPointerException for a null format");
        } catch (NullPointerException expected) {
            // expected
        }
    }

    public void testFormatDurationNegativeDuration() {
        assertEquals("-5", DurationFormatUtils.formatDuration(-5000L, "s", true));
    }

    public void testFormatDurationFractionalSecondsBorrowSmallMillis() {
        // the implementation "borrows" from the seconds field so a small
        // millisecond remainder is still rendered with leading zeros
        long millis = 7 * MILLIS_PER_SECOND + 5L;
        assertEquals("7.005", DurationFormatUtils.formatDuration(millis, "s.SSS", true));
    }

    public void testFormatDurationMillisOnlyWithoutSecondsToken() {
        // with no 's', 'm', 'H' or 'd' token, everything collapses into the
        // millisecond field, with no upper bound on its value
        assertEquals("123456", DurationFormatUtils.formatDuration(123456L, "SSS", true));
    }

    //-----------------------------------------------------------------------
    // formatDurationWords
    //-----------------------------------------------------------------------

    public void testFormatDurationWordsTypicalWithSingular() {
        long millis = MILLIS_PER_DAY + 2 * MILLIS_PER_HOUR + 5 * MILLIS_PER_SECOND;
        String result = DurationFormatUtils.formatDurationWords(millis, false, false);
        assertEquals("1 day 2 hours 0 minutes 5 seconds", result);
    }

    public void testFormatDurationWordsSuppressTrailingKeepsInnerZero() {
        long millis = MILLIS_PER_DAY + 2 * MILLIS_PER_HOUR + 3 * MILLIS_PER_MINUTE;
        String result = DurationFormatUtils.formatDurationWords(millis, false, true);
        assertEquals("1 day 2 hours 3 minutes", result);
    }

    public void testFormatDurationWordsSuppressLeadingStopsAtFirstNonZero() {
        long millis = 5 * MILLIS_PER_MINUTE + 7 * MILLIS_PER_SECOND;
        String result = DurationFormatUtils.formatDurationWords(millis, true, false);
        assertEquals("5 minutes 7 seconds", result);
    }

    /**
     * BUG: when suppressLeadingZeroElements is true, the cascading removal
     * in formatDurationWords assigns "duration = tmp" before comparing
     * tmp.length() to duration.length(), so that comparison is always
     * false. As a result the final (seconds) element of an all-zero
     * duration is never stripped, even though every other all-zero element
     * is. A zero-length duration should format to "", but instead a
     * trailing "0 seconds" (or "0 minutes 0 seconds", depending on which
     * cascade step is reached) survives.
     */
    public void testFormatDurationWordsAllZeroSuppressLeadingShouldBeEmpty() {
        String result = DurationFormatUtils.formatDurationWords(0L, true, false);
        assertEquals("", result);
    }

    public void testFormatDurationWordsAllZeroBothSuppressedShouldBeEmpty() {
        String result = DurationFormatUtils.formatDurationWords(0L, true, true);
        assertEquals("", result);
    }

    //-----------------------------------------------------------------------
    // formatPeriod
    //-----------------------------------------------------------------------

    public void testFormatPeriodBelowTwentyEightDayThresholdUsesSimpleDivision() {
        // just under the 28-day cut-off: delegates straight to formatDuration
        long end = 28 * MILLIS_PER_DAY - 1L;
        assertEquals("27", DurationFormatUtils.formatPeriod(0L, end, "d", true, UTC));
    }

    public void testFormatPeriodAtTwentyEightDayThresholdMatchesSimpleDivision() {
        // exactly at the cut-off: goes through the full calendar-based path,
        // which must still agree with simple division for a clean 28-day gap
        long end = 28 * MILLIS_PER_DAY;
        assertEquals("672", DurationFormatUtils.formatPeriod(0L, end, "H", true, UTC));
    }

    public void testFormatPeriodAcrossYearsAndMonths() {
        Calendar start = Calendar.getInstance(UTC);
        start.clear();
        start.set(1970, Calendar.JANUARY, 1, 0, 0, 0);
        Calendar end = Calendar.getInstance(UTC);
        end.clear();
        end.set(2000, Calendar.MARCH, 1, 0, 0, 0);

        String result = DurationFormatUtils.formatPeriod(
                start.getTimeInMillis(), end.getTimeInMillis(), "y-M-d", true, UTC);
        assertEquals("30-2-0", result);
    }

    public void testFormatPeriodThreeArgOverloadDelegatesCorrectly() {
        assertEquals("1", DurationFormatUtils.formatPeriod(0L, 1000L, "s"));
    }

    public void testFormatPeriodISOMatchesFormatDurationISOBelowThreshold() {
        long end = MILLIS_PER_HOUR;
        assertEquals(DurationFormatUtils.formatDurationISO(end),
                DurationFormatUtils.formatPeriodISO(0L, end));
    }

    //-----------------------------------------------------------------------
    // package-private lexx()/Token helpers
    //-----------------------------------------------------------------------

    public void testLexxCollapsesRepeatedTokenCharsWithCount() {
        DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("yyyy-MM");
        assertEquals(3, tokens.length);
        assertEquals(4, tokens[0].getCount());
        assertEquals(1, tokens[1].getCount());
        assertEquals(2, tokens[2].getCount());
    }

    public void testLexxLiteralCharactersAreKeptVerbatim() {
        DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("'literal'H");
        assertEquals(2, tokens.length);
        assertEquals("literal", tokens[0].getValue().toString());
        assertEquals(1, tokens[1].getCount());
    }

    public void testTokenContainsTokenWithValueFoundAndNotFound() {
        DurationFormatUtils.Token[] tokens = DurationFormatUtils.lexx("HH:mm");
        assertTrue(DurationFormatUtils.Token.containsTokenWithValue(tokens, "H"));
        assertFalse(DurationFormatUtils.Token.containsTokenWithValue(tokens, "s"));
    }
}
