/*
 * Copyright (C) 2011 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.gson.internal.bind;

import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.InstanceCreator;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.internal.ConstructorConstructor;
import com.google.gson.internal.Excluder;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;

import junit.framework.TestCase;

public final class ReflectiveTypeAdapterFactoryAgentTest extends TestCase {

  private Gson gson;
  private ReflectiveTypeAdapterFactory factory;

  @Override protected void setUp() {
    gson = new Gson();
    factory = newFactory();
  }

  private static ReflectiveTypeAdapterFactory newFactory() {
    Map<Type, InstanceCreator<?>> instanceCreators = new HashMap<Type, InstanceCreator<?>>();
    ConstructorConstructor constructorConstructor = new ConstructorConstructor(instanceCreators);
    return new ReflectiveTypeAdapterFactory(
        constructorConstructor, FieldNamingPolicy.IDENTITY, Excluder.DEFAULT);
  }

  private static String write(TypeAdapter<Object> adapter, Object value) throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter jsonWriter = new JsonWriter(stringWriter);
    adapter.write(jsonWriter, value);
    jsonWriter.flush();
    return stringWriter.toString();
  }

  private static Object read(TypeAdapter<Object> adapter, String json) throws IOException {
    JsonReader jsonReader = new JsonReader(new StringReader(json));
    return adapter.read(jsonReader);
  }

  public static class Simple {
    String name;
    int age;
  }

  public void testWriteAndReadRoundTrip() throws IOException {
    TypeAdapter<Object> adapter = getAdapter(Simple.class);

    Simple value = new Simple();
    value.name = "Bob";
    value.age = 42;
    String json = write(adapter, value);
    assertEquals("{\"name\":\"Bob\",\"age\":42}", json);

    Simple read = (Simple) read(adapter, json);
    assertEquals("Bob", read.name);
    assertEquals(42, read.age);
  }

  public void testWriteNullValue() throws IOException {
    TypeAdapter<Object> adapter = getAdapter(Simple.class);
    assertEquals("null", write(adapter, null));
  }

  public void testReadJsonNullReturnsNull() throws IOException {
    TypeAdapter<Object> adapter = getAdapter(Simple.class);
    Object result = read(adapter, "null");
    assertNull(result);
  }

  public void testReadNullForPrimitiveFieldKeepsDefault() throws IOException {
    TypeAdapter<Object> adapter = getAdapter(Simple.class);
    Simple read = (Simple) read(adapter, "{\"name\":null,\"age\":null}");
    assertNull(read.name);
    assertEquals(0, read.age);
  }

  public void testReadSkipsUnknownProperties() throws IOException {
    TypeAdapter<Object> adapter = getAdapter(Simple.class);
    Simple read = (Simple) read(adapter, "{\"unknown\":{\"a\":[1,2,3]},\"name\":\"Ann\",\"age\":7}");
    assertEquals("Ann", read.name);
    assertEquals(7, read.age);
  }

  public static class WithTransientAndStatic {
    String name;
    transient String ignored = "untouched";
    static String staticField = "static-default";
  }

  public void testTransientAndStaticFieldsExcluded() throws IOException {
    TypeAdapter<Object> adapter = getAdapter(WithTransientAndStatic.class);

    WithTransientAndStatic value = new WithTransientAndStatic();
    value.name = "x";
    value.ignored = "should not appear";
    String json = write(adapter, value);
    assertEquals("{\"name\":\"x\"}", json);

    WithTransientAndStatic read = (WithTransientAndStatic)
        read(adapter, "{\"name\":\"y\",\"ignored\":\"nope\",\"staticField\":\"nope\"}");
    assertEquals("y", read.name);
    assertEquals("untouched", read.ignored);
    assertEquals("static-default", WithTransientAndStatic.staticField);
  }

  public static class WithAlternateNames {
    @SerializedName(value = "main", alternate = {"alt1", "alt2"})
    String value;
  }

  public void testSerializedNameAlternatesOnlyUsedForDeserialization() throws IOException {
    TypeAdapter<Object> adapter = getAdapter(WithAlternateNames.class);

    WithAlternateNames value = new WithAlternateNames();
    value.value = "hello";
    assertEquals("{\"main\":\"hello\"}", write(adapter, value));

    WithAlternateNames readMain = (WithAlternateNames) read(adapter, "{\"main\":\"m\"}");
    assertEquals("m", readMain.value);

    WithAlternateNames readAlt1 = (WithAlternateNames) read(adapter, "{\"alt1\":\"a1\"}");
    assertEquals("a1", readAlt1.value);

    WithAlternateNames readAlt2 = (WithAlternateNames) read(adapter, "{\"alt2\":\"a2\"}");
    assertEquals("a2", readAlt2.value);
  }

  public static class DuplicateNames {
    @SerializedName("dup") String a;
    @SerializedName("dup") String b;
  }

  public void testDuplicateJsonFieldNamesThrows() {
    try {
      factory.create(gson, TypeToken.get(DuplicateNames.class));
      fail("Expected IllegalArgumentException for duplicate JSON field names");
    } catch (IllegalArgumentException expected) {
      assertTrue(expected.getMessage().contains("dup"));
    }
  }

  public static class SelfRef {
    String name;
    SelfRef self;
  }

  public void testWriteFieldAvoidsRecursionWhenFieldReferencesOwner() throws IOException {
    TypeAdapter<Object> adapter = getAdapter(SelfRef.class);

    SelfRef value = new SelfRef();
    value.name = "loop";
    value.self = value;

    String json = write(adapter, value);
    assertEquals("{\"name\":\"loop\"}", json);
  }

  public interface MarkerInterface {
    // no members; used to verify interface types have no bound fields
  }

  public static class ConcreteImpl implements MarkerInterface {
    String hidden = "secret";
  }

  @SuppressWarnings("unchecked")
  public void testInterfaceTypeHasNoBoundFields() throws IOException {
    TypeAdapter<Object> adapter =
        (TypeAdapter<Object>) (TypeAdapter<?>) factory.create(gson, TypeToken.get(MarkerInterface.class));
    assertNotNull(adapter);

    ConcreteImpl impl = new ConcreteImpl();
    String json = write(adapter, impl);
    assertEquals("{}", json);
  }

  public void testCreateReturnsNullForPrimitiveType() {
    TypeAdapter<Integer> adapter = factory.create(gson, TypeToken.get(int.class));
    assertNull(adapter);
  }

  public abstract static class AbstractNoDefaultConstructor {
    String value;
  }

  public void testReadFailsForAbstractTypeWithNoConstructor() throws IOException {
    TypeAdapter<Object> adapter = getAdapter(AbstractNoDefaultConstructor.class);
    try {
      read(adapter, "{}");
      fail("Expected a RuntimeException because an abstract class cannot be instantiated");
    } catch (RuntimeException expected) {
      // thrown by ConstructorConstructor's unsafe-allocator fallback
    }
  }

  public void testExcludeFieldPublicOverloadMatchesFieldLevelExclusion() throws Exception {
    // despite its name, excludeField(Field, boolean) returns true when the field should
    // be included (it is the negation used internally by getBoundFields).
    java.lang.reflect.Field transientField = WithTransientAndStatic.class.getDeclaredField("ignored");
    assertFalse(factory.excludeField(transientField, true));
    assertFalse(factory.excludeField(transientField, false));

    java.lang.reflect.Field normalField = WithTransientAndStatic.class.getDeclaredField("name");
    assertTrue(factory.excludeField(normalField, true));
    assertTrue(factory.excludeField(normalField, false));
  }

  @SuppressWarnings("unchecked")
  private TypeAdapter<Object> getAdapter(Class<?> clazz) {
    return (TypeAdapter<Object>) factory.create(gson, TypeToken.get(clazz));
  }
}
