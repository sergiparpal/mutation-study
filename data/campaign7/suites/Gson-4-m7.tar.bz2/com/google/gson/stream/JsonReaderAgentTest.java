/*
 * Copyright (C) 2014 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.gson.stream;

import java.io.EOFException;
import java.io.IOException;
import java.io.StringReader;
import junit.framework.TestCase;

@SuppressWarnings("resource")
public class JsonReaderAgentTest extends TestCase {

  public void testReadEmptyObject() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("{}"));
    reader.beginObject();
    assertFalse(reader.hasNext());
    reader.endObject();
    assertEquals(JsonToken.END_DOCUMENT, reader.peek());
  }

  public void testReadEmptyArray() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[]"));
    reader.beginArray();
    assertFalse(reader.hasNext());
    reader.endArray();
  }

  public void testBasicObject() throws IOException {
    JsonReader reader = new JsonReader(new StringReader(
        "{\"a\":1,\"b\":\"text\",\"c\":true,\"d\":null,\"e\":1.5}"));
    reader.beginObject();
    assertEquals("a", reader.nextName());
    assertEquals(1, reader.nextInt());
    assertEquals("b", reader.nextName());
    assertEquals("text", reader.nextString());
    assertEquals("c", reader.nextName());
    assertTrue(reader.nextBoolean());
    assertEquals("d", reader.nextName());
    reader.nextNull();
    assertEquals("e", reader.nextName());
    assertEquals(1.5, reader.nextDouble(), 0.0);
    reader.endObject();
  }

  public void testNestedArraysAndObjects() throws IOException {
    JsonReader reader = new JsonReader(
        new StringReader("[1,[2,3],{\"a\":[4,5]}]"));
    reader.beginArray();
    assertEquals(1, reader.nextInt());
    reader.beginArray();
    assertEquals(2, reader.nextInt());
    assertEquals(3, reader.nextInt());
    reader.endArray();
    reader.beginObject();
    assertEquals("a", reader.nextName());
    reader.beginArray();
    assertEquals(4, reader.nextInt());
    assertEquals(5, reader.nextInt());
    reader.endArray();
    reader.endObject();
    reader.endArray();
  }

  public void testNextLongExact() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[9223372036854775807,-9223372036854775808]"));
    reader.beginArray();
    assertEquals(Long.MAX_VALUE, reader.nextLong());
    assertEquals(Long.MIN_VALUE, reader.nextLong());
    reader.endArray();
  }

  public void testNextIntPrecisionLossThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[3000000000]"));
    reader.beginArray();
    try {
      reader.nextInt();
      fail();
    } catch (NumberFormatException expected) {
    }
  }

  public void testNextLongPrecisionLossThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1.5]"));
    reader.beginArray();
    try {
      reader.nextLong();
      fail();
    } catch (NumberFormatException expected) {
    }
  }

  public void testNumberAsStringAndStringAsNumber() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[\"123\",456]"));
    reader.beginArray();
    assertEquals(123, reader.nextInt());
    assertEquals("456", reader.nextString());
    reader.endArray();
  }

  public void testMismatchedBeginArrayThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("{}"));
    try {
      reader.beginArray();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testMismatchedBeginObjectThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[]"));
    try {
      reader.beginObject();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testNextStringOnBooleanThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("true"));
    reader.setLenient(true);
    try {
      reader.nextString();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testNextNameOnNonNameThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("{\"a\":1}"));
    reader.beginObject();
    try {
      reader.nextInt();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testTopLevelScalarAllowedWithoutLenient() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("true"));
    assertEquals(JsonToken.BOOLEAN, reader.peek());
    assertTrue(reader.nextBoolean());
  }

  public void testTopLevelValueWithLenient() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("true"));
    reader.setLenient(true);
    assertTrue(reader.nextBoolean());
  }

  public void testPrematureEndOfInputThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("{"));
    reader.beginObject();
    try {
      reader.nextName();
      fail();
    } catch (EOFException expected) {
    }
  }

  public void testUnterminatedArrayThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1,2"));
    reader.beginArray();
    assertEquals(1, reader.nextInt());
    assertEquals(2, reader.nextInt());
    try {
      reader.hasNext();
      fail();
    } catch (EOFException expected) {
    }
  }

  public void testStringEscapes() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("\"a\\tb\\nc\\\"d\\\\e\\u0041\""));
    reader.setLenient(true);
    assertEquals("a\tb\nc\"d\\eA", reader.nextString());
  }

  public void testMalformedUnicodeEscapeThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("\"\\uxxxx\""));
    reader.setLenient(true);
    try {
      reader.nextString();
      fail();
    } catch (NumberFormatException expected) {
    }
  }

  public void testSkipValueSkipsObject() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1,{\"a\":[1,2,3]},2]"));
    reader.beginArray();
    assertEquals(1, reader.nextInt());
    reader.skipValue();
    assertEquals(2, reader.nextInt());
    reader.endArray();
  }

  public void testSkipValueSkipsLiteral() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[\"a\",1,true,null,2]"));
    reader.beginArray();
    reader.skipValue();
    reader.skipValue();
    reader.skipValue();
    reader.skipValue();
    assertEquals(2, reader.nextInt());
    reader.endArray();
  }

  public void testGetPath() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("{\"a\":[1,2]}"));
    assertEquals("$", reader.getPath());
    reader.beginObject();
    reader.nextName();
    reader.beginArray();
    reader.nextInt();
    assertEquals("$.a[1]", reader.getPath());
  }

  public void testLenientNanAndInfinity() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[NaN,Infinity,-Infinity]"));
    reader.setLenient(true);
    reader.beginArray();
    assertTrue(Double.isNaN(reader.nextDouble()));
    assertTrue(Double.isInfinite(reader.nextDouble()));
    assertTrue(Double.isInfinite(reader.nextDouble()));
    reader.endArray();
  }

  public void testStrictNanThrows() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[\"NaN\"]"));
    reader.beginArray();
    try {
      reader.nextDouble();
      fail();
    } catch (MalformedJsonException expected) {
    }
  }

  public void testCloseThenOperationsThrow() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("{\"a\":1}"));
    reader.close();
    try {
      reader.beginObject();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testNullConstructorThrows() {
    try {
      new JsonReader(null);
      fail();
    } catch (NullPointerException expected) {
    }
  }

  public void testLenientDefaultsFalse() {
    JsonReader reader = new JsonReader(new StringReader("[]"));
    assertFalse(reader.isLenient());
    reader.setLenient(true);
    assertTrue(reader.isLenient());
  }

  public void testMultipleTopLevelValuesRequiresLenient() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[][]"));
    reader.beginArray();
    reader.endArray();
    try {
      reader.peek();
      fail();
    } catch (IOException expected) {
    }
  }

  public void testMultipleTopLevelValuesWithLenient() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[]true"));
    reader.setLenient(true);
    reader.beginArray();
    reader.endArray();
    assertTrue(reader.nextBoolean());
  }

  public void testToStringContainsLineAndColumn() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("[1,2]"));
    String s = reader.toString();
    assertTrue(s.contains("line"));
    assertTrue(s.contains("column"));
  }

  public void testNonExecutePrefix() throws IOException {
    JsonReader reader = new JsonReader(new StringReader(")]}'\n[1]"));
    reader.setLenient(true);
    reader.beginArray();
    assertEquals(1, reader.nextInt());
    reader.endArray();
  }

  public void testSingleQuotedStringsRequireLenient() throws IOException {
    JsonReader reader = new JsonReader(new StringReader("['a']"));
    reader.beginArray();
    try {
      reader.nextString();
      fail();
    } catch (IOException expected) {
    }
  }
}
