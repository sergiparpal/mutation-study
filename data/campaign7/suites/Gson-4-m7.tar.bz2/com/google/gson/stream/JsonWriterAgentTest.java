/*
 * Copyright (C) 2014 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.gson.stream;

import java.io.IOException;
import java.io.StringWriter;
import junit.framework.TestCase;

public class JsonWriterAgentTest extends TestCase {

  public void testEmptyObject() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginObject();
    writer.endObject();
    writer.close();
    assertEquals("{}", stringWriter.toString());
  }

  public void testEmptyArray() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.endArray();
    writer.close();
    assertEquals("[]", stringWriter.toString());
  }

  public void testBasicObject() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginObject();
    writer.name("a").value(1);
    writer.name("b").value("text");
    writer.name("c").value(true);
    writer.name("d").nullValue();
    writer.name("e").value(1.5);
    writer.endObject();
    writer.close();
    assertEquals("{\"a\":1,\"b\":\"text\",\"c\":true,\"d\":null,\"e\":1.5}", stringWriter.toString());
  }

  public void testNestedArraysAndObjects() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.value(1);
    writer.beginArray();
    writer.value(2);
    writer.value(3);
    writer.endArray();
    writer.beginObject();
    writer.name("a");
    writer.beginArray();
    writer.value(4);
    writer.value(5);
    writer.endArray();
    writer.endObject();
    writer.endArray();
    writer.close();
    assertEquals("[1,[2,3],{\"a\":[4,5]}]", stringWriter.toString());
  }

  public void testStringEscaping() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.value("a\tb\nc\"d\\e");
    writer.endArray();
    writer.close();
    assertEquals("[\"a\\tb\\nc\\\"d\\\\e\"]", stringWriter.toString());
  }

  public void testIndent() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setIndent("  ");
    writer.beginObject();
    writer.name("a").value(1);
    writer.endObject();
    writer.close();
    assertEquals("{\n  \"a\": 1\n}", stringWriter.toString());
  }

  public void testSetIndentEmptyDisablesPrettyPrinting() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setIndent("  ");
    writer.setIndent("");
    writer.beginObject();
    writer.name("a").value(1);
    writer.endObject();
    writer.close();
    assertEquals("{\"a\":1}", stringWriter.toString());
  }

  public void testHtmlSafe() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setHtmlSafe(true);
    assertTrue(writer.isHtmlSafe());
    writer.beginArray();
    writer.value("<html>&'=");
    writer.endArray();
    writer.close();
    assertEquals("[\"\\u003chtml\\u003e\\u0026\\u0027\\u003d\"]", stringWriter.toString());
  }

  public void testSerializeNullsDefaultTrue() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    assertTrue(writer.getSerializeNulls());
    writer.beginObject();
    writer.name("a").nullValue();
    writer.endObject();
    writer.close();
    assertEquals("{\"a\":null}", stringWriter.toString());
  }

  public void testSerializeNullsFalseOmitsNullMembers() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setSerializeNulls(false);
    writer.beginObject();
    writer.name("a").nullValue();
    writer.name("b").value(1);
    writer.endObject();
    writer.close();
    assertEquals("{\"b\":1}", stringWriter.toString());
  }

  public void testNameWithoutValueThrowsOnClose() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginObject();
    writer.name("a");
    try {
      writer.endObject();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testDoubleNameThrows() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginObject();
    writer.name("a");
    try {
      writer.name("b");
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testNullNameThrows() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginObject();
    try {
      writer.name(null);
      fail();
    } catch (NullPointerException expected) {
    }
  }

  public void testMismatchedEndArrayThrows() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginObject();
    try {
      writer.endArray();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testMultipleTopLevelValuesWithoutLenientThrows() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.endArray();
    try {
      writer.beginArray();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testMultipleTopLevelValuesWithLenient() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setLenient(true);
    assertTrue(writer.isLenient());
    writer.beginArray();
    writer.endArray();
    writer.beginArray();
    writer.endArray();
    writer.close();
    assertEquals("[][]", stringWriter.toString());
  }

  public void testNanAndInfinityThrowWithoutLenient() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    try {
      writer.value(Double.NaN);
      fail();
    } catch (IllegalArgumentException expected) {
    }
    try {
      writer.value(Double.POSITIVE_INFINITY);
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  public void testNanAndInfinityAllowedWithLenient() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setLenient(true);
    writer.beginArray();
    writer.value(Double.valueOf(Double.NaN));
    writer.value(Double.valueOf(Double.POSITIVE_INFINITY));
    writer.value(Double.valueOf(Double.NEGATIVE_INFINITY));
    writer.endArray();
    writer.close();
    assertEquals("[NaN,Infinity,-Infinity]", stringWriter.toString());
  }

  public void testNumberValueNullWritesNullLiteral() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.value((Number) null);
    writer.endArray();
    writer.close();
    assertEquals("[null]", stringWriter.toString());
  }

  public void testStringValueNullWritesNullLiteral() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.value((String) null);
    writer.endArray();
    writer.close();
    assertEquals("[null]", stringWriter.toString());
  }

  public void testJsonValueWritesRawJson() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.jsonValue("{\"x\":1}");
    writer.endArray();
    writer.close();
    assertEquals("[{\"x\":1}]", stringWriter.toString());
  }

  public void testCloseWithIncompleteDocumentThrows() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    try {
      writer.close();
      fail();
    } catch (IOException expected) {
    }
  }

  public void testFlushAfterCloseThrows() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.endArray();
    writer.close();
    try {
      writer.flush();
      fail();
    } catch (IllegalStateException expected) {
    }
  }

  public void testNullConstructorThrows() {
    try {
      new JsonWriter(null);
      fail();
    } catch (NullPointerException expected) {
    }
  }

  public void testValueMethodsReturnSameWriterForChaining() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    JsonWriter afterBegin = writer.beginArray();
    assertSame(writer, afterBegin);
    JsonWriter afterValue = writer.value(1);
    assertSame(writer, afterValue);
    JsonWriter afterEnd = writer.endArray();
    assertSame(writer, afterEnd);
  }

  public void testTopLevelLongValue() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.setLenient(true);
    writer.value(Long.MIN_VALUE);
    writer.close();
    assertEquals(Long.toString(Long.MIN_VALUE), stringWriter.toString());
  }

  public void testNameOnClosedWriterThrows() throws IOException {
    StringWriter stringWriter = new StringWriter();
    JsonWriter writer = new JsonWriter(stringWriter);
    writer.beginArray();
    writer.endArray();
    writer.close();
    try {
      writer.name("a");
      fail();
    } catch (IllegalStateException expected) {
    }
  }
}
