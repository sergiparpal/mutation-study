/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.NoSuchElementException;

import org.junit.Test;

public class DateUtilsAgentTest {

    private static Calendar newCal(int year, int month, int day, int hour, int minute, int second, int millis) {
        Calendar c = Calendar.getInstance();
        c.clear();
        c.set(year, month, day, hour, minute, second);
        c.set(Calendar.MILLISECOND, millis);
        return c;
    }

    private static Date newDate(int year, int month, int day, int hour, int minute, int second, int millis) {
        return newCal(year, month, day, hour, minute, second, millis).getTime();
    }

    // ---------------------------------------------------------- isSameDay

    @Test
    public void testIsSameDayDate() {
        Date d1 = newDate(2003, Calendar.MARCH, 28, 13, 45, 0, 0);
        Date d2 = newDate(2003, Calendar.MARCH, 28, 6, 1, 0, 0);
        Date d3 = newDate(2003, Calendar.MARCH, 12, 13, 45, 0, 0);
        assertTrue(DateUtils.isSameDay(d1, d2));
        assertFalse(DateUtils.isSameDay(d1, d3));
    }

    @Test
    public void testIsSameDayDateNull() {
        try {
            DateUtils.isSameDay((Date) null, new Date());
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
        try {
            DateUtils.isSameDay(new Date(), (Date) null);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testIsSameDayCalendar() {
        Calendar c1 = newCal(2003, Calendar.MARCH, 28, 13, 45, 0, 0);
        Calendar c2 = newCal(2003, Calendar.MARCH, 28, 6, 1, 0, 0);
        Calendar c3 = newCal(2003, Calendar.MARCH, 12, 13, 45, 0, 0);
        assertTrue(DateUtils.isSameDay(c1, c2));
        assertFalse(DateUtils.isSameDay(c1, c3));
        try {
            DateUtils.isSameDay((Calendar) null, c1);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    // ------------------------------------------------------ isSameInstant

    @Test
    public void testIsSameInstantDate() {
        Date d1 = new Date(10000L);
        Date d2 = new Date(10000L);
        Date d3 = new Date(10001L);
        assertTrue(DateUtils.isSameInstant(d1, d2));
        assertFalse(DateUtils.isSameInstant(d1, d3));
        try {
            DateUtils.isSameInstant((Date) null, d1);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testIsSameInstantCalendar() {
        Calendar c1 = Calendar.getInstance();
        c1.setTimeInMillis(50000L);
        Calendar c2 = Calendar.getInstance();
        c2.setTimeInMillis(50000L);
        Calendar c3 = Calendar.getInstance();
        c3.setTimeInMillis(50001L);
        assertTrue(DateUtils.isSameInstant(c1, c2));
        assertFalse(DateUtils.isSameInstant(c1, c3));
        try {
            DateUtils.isSameInstant((Calendar) null, c1);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    // ----------------------------------------------------- isSameLocalTime

    @Test
    public void testIsSameLocalTimeTrue() {
        Calendar c1 = newCal(2005, Calendar.JULY, 23, 19, 53, 47, 991);
        Calendar c2 = newCal(2005, Calendar.JULY, 23, 19, 53, 47, 991);
        assertTrue(DateUtils.isSameLocalTime(c1, c2));
    }

    @Test
    public void testIsSameLocalTimeDifferentClass() {
        Calendar c1 = newCal(2005, Calendar.JULY, 23, 19, 53, 47, 991);
        Calendar c2 = new GregorianCalendar() {
            // anonymous subclass -> different getClass()
        };
        c2.setTimeZone(c1.getTimeZone());
        c2.clear();
        c2.set(2005, Calendar.JULY, 23, 19, 53, 47);
        c2.set(Calendar.MILLISECOND, 991);
        assertFalse(DateUtils.isSameLocalTime(c1, c2));
    }

    @Test
    public void testIsSameLocalTimeNull() {
        try {
            DateUtils.isSameLocalTime(null, Calendar.getInstance());
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    // ----------------------------------------------------------- parseDate

    @Test
    public void testParseDateFirstMatchingPattern() throws ParseException {
        Date parsed = DateUtils.parseDate("2003-03-28", new String[] { "yyyy-MM", "yyyy-MM-dd" });
        Calendar c = DateUtils.toCalendar(parsed);
        assertEquals(2003, c.get(Calendar.YEAR));
        assertEquals(Calendar.MARCH, c.get(Calendar.MONTH));
        assertEquals(28, c.get(Calendar.DAY_OF_MONTH));
    }

    @Test(expected = ParseException.class)
    public void testParseDateNoMatch() throws ParseException {
        DateUtils.parseDate("not-a-date", new String[] { "yyyy-MM-dd" });
    }

    @Test
    public void testParseDateNullArgs() {
        try {
            DateUtils.parseDate(null, new String[] { "yyyy-MM-dd" });
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        } catch (ParseException e) {
            fail("expected IllegalArgumentException, not ParseException");
        }
        try {
            DateUtils.parseDate("2003-03-28", (String[]) null);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        } catch (ParseException e) {
            fail("expected IllegalArgumentException, not ParseException");
        }
    }

    @Test
    public void testParseDateLenientAcceptsOverflow() throws ParseException {
        // Lenient parsing should roll Feb 30 over into March.
        Date parsed = DateUtils.parseDate("2003-02-30", new String[] { "yyyy-MM-dd" });
        Calendar c = DateUtils.toCalendar(parsed);
        assertEquals(Calendar.MARCH, c.get(Calendar.MONTH));
        assertEquals(2, c.get(Calendar.DAY_OF_MONTH));
    }

    @Test(expected = ParseException.class)
    public void testParseDateStrictlyRejectsOverflow() throws ParseException {
        DateUtils.parseDateStrictly("2003-02-30", new String[] { "yyyy-MM-dd" });
    }

    @Test
    public void testParseDateDoesNotMatchPartialString() {
        // "2003-03-28extra" must not be accepted by a pattern that only matches the prefix.
        try {
            DateUtils.parseDate("2003-03-28extra", new String[] { "yyyy-MM-dd" });
            fail("expected ParseException because only a prefix of the input matches");
        } catch (ParseException e) {
            // expected
        }
    }

    // ------------------------------------------------------------- addXxx

    @Test
    public void testAddYears() {
        Date start = newDate(2003, Calendar.MARCH, 28, 0, 0, 0, 0);
        Date result = DateUtils.addYears(start, 2);
        Calendar c = DateUtils.toCalendar(result);
        assertEquals(2005, c.get(Calendar.YEAR));
        // original must be unchanged
        assertEquals(2003, DateUtils.toCalendar(start).get(Calendar.YEAR));
    }

    @Test
    public void testAddMonthsNegative() {
        Date start = newDate(2003, Calendar.JANUARY, 15, 0, 0, 0, 0);
        Date result = DateUtils.addMonths(start, -1);
        Calendar c = DateUtils.toCalendar(result);
        assertEquals(2002, c.get(Calendar.YEAR));
        assertEquals(Calendar.DECEMBER, c.get(Calendar.MONTH));
    }

    @Test
    public void testAddWeeks() {
        Date start = newDate(2003, Calendar.MARCH, 28, 0, 0, 0, 0);
        Date result = DateUtils.addWeeks(start, 1);
        assertEquals(7 * DateUtils.MILLIS_PER_DAY, result.getTime() - start.getTime());
    }

    @Test
    public void testAddDays() {
        Date start = newDate(2003, Calendar.MARCH, 28, 0, 0, 0, 0);
        Date result = DateUtils.addDays(start, 3);
        Calendar c = DateUtils.toCalendar(result);
        assertEquals(31, c.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void testAddHours() {
        Date start = newDate(2003, Calendar.MARCH, 28, 23, 0, 0, 0);
        Date result = DateUtils.addHours(start, 2);
        Calendar c = DateUtils.toCalendar(result);
        assertEquals(29, c.get(Calendar.DAY_OF_MONTH));
        assertEquals(1, c.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    public void testAddMinutes() {
        Date start = newDate(2003, Calendar.MARCH, 28, 0, 59, 0, 0);
        Date result = DateUtils.addMinutes(start, 2);
        Calendar c = DateUtils.toCalendar(result);
        assertEquals(1, c.get(Calendar.HOUR_OF_DAY));
        assertEquals(1, c.get(Calendar.MINUTE));
    }

    @Test
    public void testAddSeconds() {
        Date start = newDate(2003, Calendar.MARCH, 28, 0, 0, 59, 0);
        Date result = DateUtils.addSeconds(start, 2);
        Calendar c = DateUtils.toCalendar(result);
        assertEquals(1, c.get(Calendar.MINUTE));
        assertEquals(1, c.get(Calendar.SECOND));
    }

    @Test
    public void testAddMilliseconds() {
        Date start = new Date(999L);
        Date result = DateUtils.addMilliseconds(start, 2);
        assertEquals(1001L, result.getTime());
    }

    @Test
    public void testAddNullDate() {
        try {
            DateUtils.addDays(null, 1);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    // ------------------------------------------------------------- setXxx

    @Test
    public void testSetYears() {
        Date start = newDate(2003, Calendar.MARCH, 28, 0, 0, 0, 0);
        Date result = DateUtils.setYears(start, 2008);
        Calendar c = DateUtils.toCalendar(result);
        assertEquals(2008, c.get(Calendar.YEAR));
        assertEquals(Calendar.MARCH, c.get(Calendar.MONTH));
        assertEquals(28, c.get(Calendar.DAY_OF_MONTH));
        // original unchanged
        assertEquals(2003, DateUtils.toCalendar(start).get(Calendar.YEAR));
    }

    @Test
    public void testSetMonths() {
        Date start = newDate(2003, Calendar.MARCH, 28, 0, 0, 0, 0);
        Date result = DateUtils.setMonths(start, Calendar.JUNE);
        Calendar c = DateUtils.toCalendar(result);
        assertEquals(Calendar.JUNE, c.get(Calendar.MONTH));
    }

    @Test
    public void testSetMonthsOutOfRangeThrows() {
        Date start = newDate(2003, Calendar.MARCH, 28, 0, 0, 0, 0);
        try {
            DateUtils.setMonths(start, 13);
            fail("expected IllegalArgumentException for an out of range month");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testSetDaysOutOfRangeForMonthThrows() {
        // February 2003 (not a leap year) has only 28 days.
        Date start = newDate(2003, Calendar.FEBRUARY, 15, 0, 0, 0, 0);
        try {
            DateUtils.setDays(start, 30);
            fail("expected IllegalArgumentException for a day that does not exist in the month");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testSetHours() {
        Date start = newDate(2003, Calendar.MARCH, 28, 0, 0, 0, 0);
        Date result = DateUtils.setHours(start, 23);
        Calendar c = DateUtils.toCalendar(result);
        assertEquals(23, c.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    public void testSetHoursOutOfRangeThrows() {
        Date start = newDate(2003, Calendar.MARCH, 28, 0, 0, 0, 0);
        try {
            DateUtils.setHours(start, 24);
            fail("expected IllegalArgumentException for an out of range hour");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testSetMinutes() {
        Date start = newDate(2003, Calendar.MARCH, 28, 0, 0, 0, 0);
        Date result = DateUtils.setMinutes(start, 59);
        assertEquals(59, DateUtils.toCalendar(result).get(Calendar.MINUTE));
    }

    @Test
    public void testSetSeconds() {
        Date start = newDate(2003, Calendar.MARCH, 28, 0, 0, 0, 0);
        Date result = DateUtils.setSeconds(start, 59);
        assertEquals(59, DateUtils.toCalendar(result).get(Calendar.SECOND));
    }

    @Test
    public void testSetMilliseconds() {
        Date start = newDate(2003, Calendar.MARCH, 28, 0, 0, 0, 0);
        Date result = DateUtils.setMilliseconds(start, 500);
        assertEquals(500, DateUtils.toCalendar(result).get(Calendar.MILLISECOND));
    }

    @Test
    public void testSetNullDate() {
        try {
            DateUtils.setYears(null, 2000);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    // --------------------------------------------------------- toCalendar

    @Test
    public void testToCalendar() {
        Date date = newDate(2003, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar c = DateUtils.toCalendar(date);
        assertEquals(date, c.getTime());
    }

    @Test
    public void testToCalendarNull() {
        try {
            DateUtils.toCalendar(null);
            fail("expected NullPointerException");
        } catch (NullPointerException e) {
            // expected
        }
    }

    // -------------------------------------------------------------- round

    @Test
    public void testRoundDateUp() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date rounded = DateUtils.round(date, Calendar.HOUR);
        Calendar c = DateUtils.toCalendar(rounded);
        assertEquals(14, c.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, c.get(Calendar.MINUTE));
        assertEquals(0, c.get(Calendar.SECOND));
        assertEquals(0, c.get(Calendar.MILLISECOND));
    }

    @Test
    public void testRoundDateDown() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 15, 1, 231);
        Date rounded = DateUtils.round(date, Calendar.HOUR);
        Calendar c = DateUtils.toCalendar(rounded);
        assertEquals(13, c.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, c.get(Calendar.MINUTE));
    }

    @Test
    public void testRoundMonthRollsToNextMonth() {
        // 28 Mar 2002 13:45:01.231 rounded to MONTH -> 1 April 2002 00:00:00.000
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date rounded = DateUtils.round(date, Calendar.MONTH);
        Calendar c = DateUtils.toCalendar(rounded);
        assertEquals(2002, c.get(Calendar.YEAR));
        assertEquals(Calendar.APRIL, c.get(Calendar.MONTH));
        assertEquals(1, c.get(Calendar.DAY_OF_MONTH));
        assertEquals(0, c.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    public void testRoundCalendarReturnsDifferentInstance() {
        Calendar date = newCal(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar rounded = DateUtils.round(date, Calendar.HOUR);
        assertTrue(rounded != date);
        // original must be unchanged
        assertEquals(45, date.get(Calendar.MINUTE));
    }

    @Test
    public void testRoundObjectDispatchesToDateAndCalendar() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar cal = newCal(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date rd = DateUtils.round((Object) date, Calendar.HOUR);
        Date rc = DateUtils.round((Object) cal, Calendar.HOUR);
        assertEquals(rd, rc);
    }

    @Test
    public void testRoundObjectWrongTypeThrowsClassCastException() {
        try {
            DateUtils.round("not a date", Calendar.HOUR);
            fail("expected ClassCastException");
        } catch (ClassCastException e) {
            // expected
        }
    }

    @Test
    public void testRoundNullThrows() {
        try {
            DateUtils.round((Date) null, Calendar.HOUR);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
        try {
            DateUtils.round((Object) null, Calendar.HOUR);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testRoundSemiMonthFirstHalfRoundsToSixteenth() {
        Date date = newDate(2007, Calendar.JANUARY, 6, 0, 0, 0, 0);
        Date rounded = DateUtils.round(date, DateUtils.SEMI_MONTH);
        Calendar c = DateUtils.toCalendar(rounded);
        assertEquals(1, c.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void testRoundSemiMonthSecondHalfRoundsToNextMonthFirst() {
        Date date = newDate(2007, Calendar.JANUARY, 27, 0, 0, 0, 0);
        Date rounded = DateUtils.round(date, DateUtils.SEMI_MONTH);
        Calendar c = DateUtils.toCalendar(rounded);
        assertEquals(Calendar.FEBRUARY, c.get(Calendar.MONTH));
        assertEquals(1, c.get(Calendar.DAY_OF_MONTH));
    }

    @Test
    public void testRoundArithmeticExceptionForHugeYear() {
        Calendar huge = Calendar.getInstance();
        huge.clear();
        huge.set(Calendar.YEAR, 300000000);
        try {
            DateUtils.round(huge, Calendar.YEAR);
            fail("expected ArithmeticException for a year over 280 million");
        } catch (ArithmeticException e) {
            // expected
        }
    }

    // ----------------------------------------------------------- truncate

    @Test
    public void testTruncateDate() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date truncated = DateUtils.truncate(date, Calendar.HOUR_OF_DAY);
        Calendar c = DateUtils.toCalendar(truncated);
        assertEquals(13, c.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, c.get(Calendar.MINUTE));
        assertEquals(0, c.get(Calendar.SECOND));
        assertEquals(0, c.get(Calendar.MILLISECOND));
    }

    @Test
    public void testTruncateMonth() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date truncated = DateUtils.truncate(date, Calendar.MONTH);
        Calendar c = DateUtils.toCalendar(truncated);
        assertEquals(Calendar.MARCH, c.get(Calendar.MONTH));
        assertEquals(1, c.get(Calendar.DAY_OF_MONTH));
        assertEquals(0, c.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    public void testTruncateCalendarReturnsDifferentInstance() {
        Calendar date = newCal(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Calendar truncated = DateUtils.truncate(date, Calendar.HOUR_OF_DAY);
        assertTrue(truncated != date);
        assertEquals(45, date.get(Calendar.MINUTE));
    }

    @Test
    public void testTruncateObjectWrongTypeThrowsClassCastException() {
        try {
            DateUtils.truncate(new Object(), Calendar.HOUR);
            fail("expected ClassCastException");
        } catch (ClassCastException e) {
            // expected
        }
    }

    @Test
    public void testTruncateNullThrows() {
        try {
            DateUtils.truncate((Date) null, Calendar.HOUR);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    // ------------------------------------------------------------ ceiling

    @Test
    public void testCeilingDateAlreadyOnBoundaryIsUnchanged() {
        // Like Math.ceil(), ceiling a value that already sits exactly on the
        // target boundary must return that same value, not advance past it.
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 0, 0, 0);
        Date ceiled = DateUtils.ceiling(date, Calendar.HOUR_OF_DAY);
        Calendar c = DateUtils.toCalendar(ceiled);
        assertEquals(13, c.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, c.get(Calendar.MINUTE));
    }

    @Test
    public void testCeilingDateWithRemainder() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 0, 1, 0);
        Date ceiled = DateUtils.ceiling(date, Calendar.HOUR_OF_DAY);
        Calendar c = DateUtils.toCalendar(ceiled);
        assertEquals(14, c.get(Calendar.HOUR_OF_DAY));
        assertEquals(0, c.get(Calendar.MINUTE));
        assertEquals(0, c.get(Calendar.SECOND));
    }

    @Test
    public void testCeilingMonth() {
        Date date = newDate(2002, Calendar.MARCH, 28, 13, 45, 1, 231);
        Date ceiled = DateUtils.ceiling(date, Calendar.MONTH);
        Calendar c = DateUtils.toCalendar(ceiled);
        assertEquals(Calendar.APRIL, c.get(Calendar.MONTH));
        assertEquals(1, c.get(Calendar.DAY_OF_MONTH));
        assertEquals(0, c.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    public void testCeilingObjectWrongTypeThrowsClassCastException() {
        try {
            DateUtils.ceiling(Boolean.TRUE, Calendar.HOUR);
            fail("expected ClassCastException");
        } catch (ClassCastException e) {
            // expected
        }
    }

    @Test
    public void testCeilingNullThrows() {
        try {
            DateUtils.ceiling((Calendar) null, Calendar.HOUR);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    // ----------------------------------------------------------- iterator

    @Test
    public void testIteratorRangeWeekSunday() {
        // Thursday, July 4, 2002
        Date focus = newDate(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        Calendar first = it.next();
        assertEquals(Calendar.SUNDAY, first.get(Calendar.DAY_OF_WEEK));
        int count = 1;
        Calendar last = first;
        while (it.hasNext()) {
            last = it.next();
            count++;
        }
        assertEquals(7, count);
        assertEquals(Calendar.SATURDAY, last.get(Calendar.DAY_OF_WEEK));
    }

    @Test
    public void testIteratorRangeMonthSunday() {
        Date focus = newDate(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_MONTH_SUNDAY);
        Calendar first = it.next();
        // 30 June 2002 is the Sunday on or before July 1, 2002
        assertEquals(Calendar.JUNE, first.get(Calendar.MONTH));
        assertEquals(30, first.get(Calendar.DAY_OF_MONTH));
        assertEquals(Calendar.SUNDAY, first.get(Calendar.DAY_OF_WEEK));
        Calendar last = first;
        int count = 1;
        while (it.hasNext()) {
            last = it.next();
            count++;
        }
        // Ends with Saturday, August 3, 2002
        assertEquals(Calendar.AUGUST, last.get(Calendar.MONTH));
        assertEquals(3, last.get(Calendar.DAY_OF_MONTH));
        assertEquals(Calendar.SATURDAY, last.get(Calendar.DAY_OF_WEEK));
    }

    @Test
    public void testIteratorExhaustionThrowsNoSuchElementException() {
        Date focus = newDate(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        while (it.hasNext()) {
            it.next();
        }
        try {
            it.next();
            fail("expected NoSuchElementException");
        } catch (NoSuchElementException e) {
            // expected
        }
    }

    @Test
    public void testIteratorRemoveThrowsUnsupportedOperationException() {
        Date focus = newDate(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        Iterator<Calendar> it = DateUtils.iterator(focus, DateUtils.RANGE_WEEK_SUNDAY);
        try {
            it.remove();
            fail("expected UnsupportedOperationException");
        } catch (UnsupportedOperationException e) {
            // expected
        }
    }

    @Test
    public void testIteratorInvalidRangeStyleThrows() {
        Date focus = newDate(2002, Calendar.JULY, 4, 0, 0, 0, 0);
        try {
            DateUtils.iterator(focus, 999);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testIteratorNullFocusThrows() {
        try {
            DateUtils.iterator((Date) null, DateUtils.RANGE_WEEK_SUNDAY);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testIteratorObjectWrongTypeThrowsClassCastException() {
        try {
            DateUtils.iterator("not a date", DateUtils.RANGE_WEEK_SUNDAY);
            fail("expected ClassCastException");
        } catch (ClassCastException e) {
            // expected
        }
    }

    // ----------------------------------------------------- getFragmentInX

    @Test
    public void testGetFragmentInMillisecondsSecond() {
        Date date = newDate(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        assertEquals(538L, DateUtils.getFragmentInMilliseconds(date, Calendar.SECOND));
    }

    @Test
    public void testGetFragmentInSecondsMinute() {
        Date date = newDate(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        assertEquals(10L, DateUtils.getFragmentInSeconds(date, Calendar.MINUTE));
    }

    @Test
    public void testGetFragmentInSecondsDayOfYear() {
        Date date = newDate(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(7 * 3600L + 15 * 60L + 10L, DateUtils.getFragmentInSeconds(date, Calendar.DAY_OF_YEAR));
    }

    @Test
    public void testGetFragmentInMinutesHourOfDay() {
        Date date = newDate(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        assertEquals(15L, DateUtils.getFragmentInMinutes(date, Calendar.HOUR_OF_DAY));
    }

    @Test
    public void testGetFragmentInHoursDayOfYear() {
        Date date = newDate(2008, Calendar.JANUARY, 1, 7, 15, 10, 538);
        assertEquals(7L, DateUtils.getFragmentInHours(date, Calendar.DAY_OF_YEAR));
    }

    @Test
    public void testGetFragmentInDaysYear() {
        // February 28, 2008 is the 59th day of the leap year 2008.
        Date date = newDate(2008, Calendar.FEBRUARY, 28, 0, 0, 0, 0);
        assertEquals(59L, DateUtils.getFragmentInDays(date, Calendar.YEAR));
    }

    @Test
    public void testGetFragmentInDaysMonth() {
        Date date = newDate(2008, Calendar.FEBRUARY, 28, 0, 0, 0, 0);
        assertEquals(28L, DateUtils.getFragmentInDays(date, Calendar.MONTH));
    }

    @Test
    public void testGetFragmentMillisecondFragmentAlwaysZero() {
        Date date = newDate(2008, Calendar.JANUARY, 16, 7, 15, 10, 538);
        assertEquals(0L, DateUtils.getFragmentInMilliseconds(date, Calendar.MILLISECOND));
        assertEquals(0L, DateUtils.getFragmentInSeconds(date, Calendar.MILLISECOND));
        assertEquals(0L, DateUtils.getFragmentInMinutes(date, Calendar.MILLISECOND));
        assertEquals(0L, DateUtils.getFragmentInHours(date, Calendar.MILLISECOND));
        assertEquals(0L, DateUtils.getFragmentInDays(date, Calendar.MILLISECOND));
    }

    @Test
    public void testGetFragmentCalendarOverloadsMatchDateOverloads() {
        Calendar cal = newCal(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        assertEquals(538L, DateUtils.getFragmentInMilliseconds(cal, Calendar.SECOND));
        assertEquals(10L, DateUtils.getFragmentInSeconds(cal, Calendar.MINUTE));
        assertEquals(15L, DateUtils.getFragmentInMinutes(cal, Calendar.HOUR_OF_DAY));
        assertEquals(7L, DateUtils.getFragmentInHours(cal, Calendar.DAY_OF_YEAR));
    }

    @Test
    public void testGetFragmentUnsupportedFragmentThrows() {
        Date date = newDate(2008, Calendar.JANUARY, 6, 7, 15, 10, 538);
        try {
            DateUtils.getFragmentInSeconds(date, Calendar.DAY_OF_WEEK);
            fail("expected IllegalArgumentException for an unsupported fragment");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testGetFragmentNullDateThrows() {
        try {
            DateUtils.getFragmentInSeconds((Date) null, Calendar.MINUTE);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    // ---------------------------------------------- truncatedEquals/Compare

    @Test
    public void testTruncatedEqualsDate() {
        Date d1 = newDate(2003, Calendar.MARCH, 28, 13, 45, 0, 0);
        Date d2 = newDate(2003, Calendar.MARCH, 28, 9, 0, 0, 0);
        assertTrue(DateUtils.truncatedEquals(d1, d2, Calendar.DATE));
        assertFalse(DateUtils.truncatedEquals(d1, d2, Calendar.HOUR_OF_DAY));
    }

    @Test
    public void testTruncatedEqualsCalendar() {
        Calendar c1 = newCal(2003, Calendar.MARCH, 28, 13, 45, 0, 0);
        Calendar c2 = newCal(2003, Calendar.MARCH, 28, 9, 0, 0, 0);
        assertTrue(DateUtils.truncatedEquals(c1, c2, Calendar.DATE));
        assertFalse(DateUtils.truncatedEquals(c1, c2, Calendar.HOUR_OF_DAY));
    }

    @Test
    public void testTruncatedCompareToDate() {
        Date earlier = newDate(2003, Calendar.MARCH, 27, 23, 59, 0, 0);
        Date later = newDate(2003, Calendar.MARCH, 28, 0, 1, 0, 0);
        assertTrue(DateUtils.truncatedCompareTo(earlier, later, Calendar.DATE) < 0);
        assertTrue(DateUtils.truncatedCompareTo(later, earlier, Calendar.DATE) > 0);
        assertEquals(0, DateUtils.truncatedCompareTo(earlier, earlier, Calendar.DATE));
    }

    @Test
    public void testTruncatedCompareToCalendar() {
        Calendar earlier = newCal(2003, Calendar.MARCH, 27, 23, 59, 0, 0);
        Calendar later = newCal(2003, Calendar.MARCH, 28, 0, 1, 0, 0);
        assertTrue(DateUtils.truncatedCompareTo(earlier, later, Calendar.DATE) < 0);
    }

    // ------------------------------------------------------------- constants

    @Test
    public void testMillisConstants() {
        assertEquals(1000L, DateUtils.MILLIS_PER_SECOND);
        assertEquals(60000L, DateUtils.MILLIS_PER_MINUTE);
        assertEquals(3600000L, DateUtils.MILLIS_PER_HOUR);
        assertEquals(86400000L, DateUtils.MILLIS_PER_DAY);
    }

    @Test
    public void testUtcTimeZone() {
        assertNotNull(DateUtils.UTC_TIME_ZONE);
        assertEquals(0, DateUtils.UTC_TIME_ZONE.getRawOffset());
    }
}
