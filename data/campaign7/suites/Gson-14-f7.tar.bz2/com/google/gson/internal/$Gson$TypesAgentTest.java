/*
 * Copyright (C) 2014 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.gson.internal;

import java.lang.reflect.GenericArrayType;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import junit.framework.TestCase;

public final class $Gson$TypesAgentTest extends TestCase {

  // ---- fixtures ----

  private static final class StringList extends ArrayList<String> {
  }

  private static final class IntStringMap extends HashMap<Integer, String> {
  }

  private static class GenericContainer<T> extends ArrayList<T> {
  }

  private static final class StringContainer extends GenericContainer<String> {
  }

  private static final class Holder<T> {
    T value;
  }

  public static <E> E identity(E e) {
    return e;
  }

  // ---- newParameterizedTypeWithOwner ----

  public void testNewParameterizedTypeWithOwner_basic() throws Exception {
    ParameterizedType type =
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    assertEquals(List.class, type.getRawType());
    assertNull(type.getOwnerType());
    assertEquals(1, type.getActualTypeArguments().length);
    assertEquals(String.class, type.getActualTypeArguments()[0]);
  }

  public void testNewParameterizedTypeWithOwner_requiresOwnerForNonStaticInnerClass()
      throws Exception {
    class LocalClass {
    }
    try {
      $Gson$Types.newParameterizedTypeWithOwner(null, LocalClass.class, String.class);
      fail();
    } catch (IllegalArgumentException expected) {
    }

    // supplying an owner is fine
    Type type =
        $Gson$Types.newParameterizedTypeWithOwner(
            $Gson$TypesAgentTest.class, LocalClass.class, String.class);
    assertNotNull(type);
  }

  public void testNewParameterizedTypeWithOwner_rejectsNullTypeArgument() throws Exception {
    try {
      $Gson$Types.newParameterizedTypeWithOwner(null, List.class, new Type[] {null});
      fail();
    } catch (NullPointerException expected) {
    }
  }

  public void testNewParameterizedTypeWithOwner_rejectsPrimitiveTypeArgument() throws Exception {
    try {
      $Gson$Types.newParameterizedTypeWithOwner(null, List.class, int.class);
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  public void testGetActualTypeArguments_returnsDefensiveCopy() throws Exception {
    ParameterizedType type =
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    Type[] args = type.getActualTypeArguments();
    args[0] = Integer.class;
    // mutating the returned array must not affect internal state
    assertEquals(String.class, type.getActualTypeArguments()[0]);
  }

  public void testParameterizedTypeImpl_toStringAndEqualsAndHashCode() throws Exception {
    Type a = $Gson$Types.newParameterizedTypeWithOwner(null, Map.class, String.class, Integer.class);
    Type b = $Gson$Types.newParameterizedTypeWithOwner(null, Map.class, String.class, Integer.class);
    assertEquals("java.util.Map<java.lang.String, java.lang.Integer>", a.toString());
    assertTrue($Gson$Types.equals(a, b));
    assertEquals(a.hashCode(), b.hashCode());

    Type noArgs = $Gson$Types.newParameterizedTypeWithOwner(null, List.class);
    assertEquals("java.util.List", noArgs.toString());
  }

  // ---- arrayOf ----

  public void testArrayOf() throws Exception {
    GenericArrayType type = $Gson$Types.arrayOf(String.class);
    assertEquals(String.class, type.getGenericComponentType());
    assertEquals("java.lang.String[]", type.toString());
  }

  // ---- subtypeOf / supertypeOf ----

  public void testSubtypeOfObject() throws Exception {
    WildcardType type = $Gson$Types.subtypeOf(Object.class);
    assertEquals("?", type.toString());
    assertEquals(Object.class, type.getUpperBounds()[0]);
    assertEquals(0, type.getLowerBounds().length);
  }

  public void testSubtypeOfBound() throws Exception {
    WildcardType type = $Gson$Types.subtypeOf(String.class);
    assertEquals("? extends java.lang.String", type.toString());
    assertEquals(String.class, type.getUpperBounds()[0]);
    assertEquals(0, type.getLowerBounds().length);
  }

  public void testSupertypeOf() throws Exception {
    WildcardType type = $Gson$Types.supertypeOf(String.class);
    assertEquals("? super java.lang.String", type.toString());
    assertEquals(Object.class, type.getUpperBounds()[0]);
    assertEquals(1, type.getLowerBounds().length);
    assertEquals(String.class, type.getLowerBounds()[0]);
  }

  // ---- canonicalize ----

  public void testCanonicalizeNonArrayClassReturnsSameInstance() throws Exception {
    Type canonicalized = $Gson$Types.canonicalize(String.class);
    assertSame(String.class, canonicalized);
  }

  public void testCanonicalizeArrayClassBecomesGenericArrayType() throws Exception {
    Type canonicalized = $Gson$Types.canonicalize(int[].class);
    assertTrue(canonicalized instanceof GenericArrayType);
    assertEquals("int[]", canonicalized.toString());
  }

  public void testCanonicalizeParameterizedTypeProducesEqualButPossiblyDistinctInstance()
      throws Exception {
    ParameterizedType original =
        $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    Type canonicalized = $Gson$Types.canonicalize(original);
    assertTrue($Gson$Types.equals(original, canonicalized));
  }

  public void testCanonicalizeUnsupportedTypeReturnsSameInstance() throws Exception {
    // a TypeVariable is neither Class, ParameterizedType, GenericArrayType nor WildcardType
    TypeVariable<?> typeVariable = Holder.class.getTypeParameters()[0];
    Type canonicalized = $Gson$Types.canonicalize(typeVariable);
    assertSame(typeVariable, canonicalized);
  }

  // ---- getRawType ----

  public void testGetRawTypeOfClass() throws Exception {
    assertEquals(String.class, $Gson$Types.getRawType(String.class));
  }

  public void testGetRawTypeOfParameterizedType() throws Exception {
    Type type = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    assertEquals(List.class, $Gson$Types.getRawType(type));
  }

  public void testGetRawTypeOfGenericArrayType() throws Exception {
    Type type = $Gson$Types.arrayOf(int.class);
    assertEquals(int[].class, $Gson$Types.getRawType(type));
  }

  public void testGetRawTypeOfTypeVariableReturnsObject() throws Exception {
    TypeVariable<?> typeVariable = Holder.class.getTypeParameters()[0];
    assertEquals(Object.class, $Gson$Types.getRawType(typeVariable));
  }

  public void testGetRawTypeOfWildcardType() throws Exception {
    WildcardType type = $Gson$Types.subtypeOf(String.class);
    assertEquals(String.class, $Gson$Types.getRawType(type));
  }

  public void testGetRawTypeOfNullThrows() throws Exception {
    try {
      $Gson$Types.getRawType(null);
      fail();
    } catch (IllegalArgumentException expected) {
      assertTrue(expected.getMessage().contains("null"));
    }
  }

  public void testGetRawTypeOfUnsupportedTypeThrows() throws Exception {
    Type unsupported = new Type() {
      @Override public String toString() {
        return "weird";
      }
    };
    try {
      $Gson$Types.getRawType(unsupported);
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  // ---- equals ----

  public void testEqualsBothNull() throws Exception {
    assertTrue($Gson$Types.equals(null, null));
  }

  public void testEqualsOneNull() throws Exception {
    assertFalse($Gson$Types.equals(null, String.class));
    assertFalse($Gson$Types.equals(String.class, null));
  }

  public void testEqualsClasses() throws Exception {
    assertTrue($Gson$Types.equals(String.class, String.class));
    assertFalse($Gson$Types.equals(String.class, Integer.class));
  }

  public void testEqualsParameterizedTypeVsClassIsFalse() throws Exception {
    Type parameterized = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    assertFalse($Gson$Types.equals(parameterized, List.class));
  }

  public void testEqualsGenericArrayTypes() throws Exception {
    Type a = $Gson$Types.arrayOf(String.class);
    Type b = $Gson$Types.arrayOf(String.class);
    Type c = $Gson$Types.arrayOf(Integer.class);
    assertTrue($Gson$Types.equals(a, b));
    assertFalse($Gson$Types.equals(a, c));
    assertFalse($Gson$Types.equals(a, String.class));
  }

  public void testEqualsWildcardTypes() throws Exception {
    Type a = $Gson$Types.subtypeOf(String.class);
    Type b = $Gson$Types.subtypeOf(String.class);
    Type c = $Gson$Types.supertypeOf(String.class);
    assertTrue($Gson$Types.equals(a, b));
    assertFalse($Gson$Types.equals(a, c));
    assertFalse($Gson$Types.equals(a, String.class));
  }

  public void testEqualsTypeVariables() throws Exception {
    TypeVariable<?> v1 = Holder.class.getTypeParameters()[0];
    TypeVariable<?> v2 = Holder.class.getTypeParameters()[0];
    assertTrue($Gson$Types.equals(v1, v2));
    assertFalse($Gson$Types.equals(v1, String.class));
  }

  public void testEqualsUnsupportedTypeIsFalseUnlessSameInstance() throws Exception {
    Type unsupported1 = new Type() {
    };
    Type unsupported2 = new Type() {
    };
    assertTrue($Gson$Types.equals(unsupported1, unsupported1));
    assertFalse($Gson$Types.equals(unsupported1, unsupported2));
  }

  // ---- typeToString ----

  public void testTypeToStringOfClass() throws Exception {
    assertEquals("java.lang.String", $Gson$Types.typeToString(String.class));
  }

  public void testTypeToStringOfNonClass() throws Exception {
    Type type = $Gson$Types.arrayOf(String.class);
    assertEquals(type.toString(), $Gson$Types.typeToString(type));
  }

  // ---- getArrayComponentType ----

  public void testGetArrayComponentTypeOfClassArray() throws Exception {
    assertEquals(String.class, $Gson$Types.getArrayComponentType(String[].class));
  }

  public void testGetArrayComponentTypeOfGenericArrayType() throws Exception {
    Type arrayType = $Gson$Types.arrayOf(String.class);
    assertEquals(String.class, $Gson$Types.getArrayComponentType(arrayType));
  }

  public void testGetArrayComponentTypeOfNonArrayThrows() throws Exception {
    Type notAnArray = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    try {
      $Gson$Types.getArrayComponentType(notAnArray);
      fail();
    } catch (ClassCastException expected) {
    }
  }

  // ---- getCollectionElementType / getMapKeyAndValueTypes ----

  public void testGetCollectionElementTypeDirectGeneric() throws Exception {
    Type elementType = $Gson$Types.getCollectionElementType(StringList.class, StringList.class);
    assertEquals(String.class, elementType);
  }

  public void testGetCollectionElementTypeThroughTwoLevelsOfInheritance() throws Exception {
    Type elementType =
        $Gson$Types.getCollectionElementType(StringContainer.class, StringContainer.class);
    assertEquals(String.class, elementType);
  }

  public void testGetCollectionElementTypeRejectsNonCollection() throws Exception {
    try {
      $Gson$Types.getCollectionElementType(IntStringMap.class, IntStringMap.class);
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  public void testGetMapKeyAndValueTypesDirectGeneric() throws Exception {
    Type[] types = $Gson$Types.getMapKeyAndValueTypes(IntStringMap.class, IntStringMap.class);
    assertEquals(2, types.length);
    assertEquals(Integer.class, types[0]);
    assertEquals(String.class, types[1]);
  }

  public void testGetMapKeyAndValueTypesRawMapDefaultsToObject() throws Exception {
    // using the raw Map interface itself as context: there is no parameterization to
    // resolve, so key and value types default to Object.
    Type[] types = $Gson$Types.getMapKeyAndValueTypes(Map.class, Map.class);
    assertEquals(2, types.length);
    assertEquals(Object.class, types[0]);
    assertEquals(Object.class, types[1]);
  }

  public void testGetMapKeyAndValueTypesPropertiesSpecialCase() throws Exception {
    Type[] types = $Gson$Types.getMapKeyAndValueTypes(Properties.class, Properties.class);
    assertEquals(2, types.length);
    assertEquals(String.class, types[0]);
    assertEquals(String.class, types[1]);
  }

  // ---- package-private helpers: getGenericSupertype / getSupertype / resolve /
  // resolveTypeVariable ----

  public void testGetGenericSupertypeSameTypeReturnsContextUnchanged() throws Exception {
    Type context = StringList.class;
    Type result = $Gson$Types.getGenericSupertype(context, StringList.class, StringList.class);
    assertSame(context, result);
  }

  public void testGetSupertypeRejectsTypeThatIsNotASupertype() throws Exception {
    try {
      $Gson$Types.getSupertype(StringList.class, StringList.class, Map.class);
      fail();
    } catch (IllegalArgumentException expected) {
    }
  }

  public void testResolveTypeVariableAcrossHierarchy() throws Exception {
    TypeVariable<?> t = GenericContainer.class.getTypeParameters()[0];
    Type resolved =
        $Gson$Types.resolveTypeVariable(StringContainer.class, StringContainer.class, t);
    assertEquals(String.class, resolved);
  }

  public void testResolveTypeVariableDeclaredByMethodIsUnresolvable() throws Exception {
    Method method = $Gson$TypesAgentTest.class.getMethod("identity", Object.class);
    TypeVariable<?> methodTypeVariable = (TypeVariable<?>) method.getTypeParameters()[0];
    Type resolved =
        $Gson$Types.resolveTypeVariable(Object.class, Object.class, methodTypeVariable);
    assertSame(methodTypeVariable, resolved);
  }

  public void testResolveNonVariableTypeIsUnchanged() throws Exception {
    Type resolved = $Gson$Types.resolve(StringList.class, StringList.class, String.class);
    assertSame(String.class, resolved);
  }

  public void testCheckNotPrimitiveAllowsWrapperTypes() throws Exception {
    // should not throw for a non-primitive, boxed type argument
    Type type = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, Integer.class);
    assertNotNull(type);
  }
}
