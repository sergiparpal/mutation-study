/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.cli;

import junit.framework.TestCase;

/**
 * Test case for GnuParser.
 */
public class GnuParserAgentTest extends TestCase
{
    private Options options;
    private GnuParser parser;

    public void setUp()
    {
        options = new Options()
            .addOption("a", "enable-a", false, "turn [a] on or off")
            .addOption("b", "bfile", true, "set the value of [b]")
            .addOption("c", "copt", false, "turn [c] on or off");

        parser = new GnuParser();
    }

    public void testSimpleShort() throws Exception
    {
        String[] args = new String[] { "-a", "-b", "toast", "foo", "bar" };

        CommandLine cl = parser.parse(options, args);

        assertTrue("Confirm -a is set", cl.hasOption("a"));
        assertTrue("Confirm -b is set", cl.hasOption("b"));
        assertEquals("Confirm arg of -b", "toast", cl.getOptionValue("b"));
        assertEquals("Confirm size of extra args", 2, cl.getArgList().size());
    }

    public void testSimpleLong() throws Exception
    {
        String[] args = new String[] { "--enable-a", "--bfile", "toast", "foo", "bar" };

        CommandLine cl = parser.parse(options, args);

        assertTrue("Confirm -a is set", cl.hasOption("a"));
        assertTrue("Confirm -b is set", cl.hasOption("b"));
        assertEquals("Confirm arg of -b", "toast", cl.getOptionValue("b"));
        assertEquals("Confirm size of extra args", 2, cl.getArgList().size());
    }

    public void testDoubleDash() throws Exception
    {
        String[] args = new String[] { "--copt", "--", "-b", "toast" };

        CommandLine cl = parser.parse(options, args);

        assertTrue("Confirm -c is set", cl.hasOption("c"));
        assertFalse("Confirm -b is not set", cl.hasOption("b"));
        assertEquals("Confirm 2 extra args", 2, cl.getArgList().size());
        assertEquals("-b", cl.getArgList().get(0));
        assertEquals("toast", cl.getArgList().get(1));
    }

    public void testSingleDash() throws Exception
    {
        String[] args = new String[] { "--copt", "-b", "-", "-a", "-" };

        CommandLine cl = parser.parse(options, args);

        assertTrue("Confirm -a is set", cl.hasOption("a"));
        assertTrue("Confirm -b is set", cl.hasOption("b"));
        assertEquals("Confirm arg of -b", "-", cl.getOptionValue("b"));
        assertEquals("Confirm 1 extra arg", 1, cl.getArgList().size());
        assertEquals("-", cl.getArgList().get(0));
    }

    public void testStop() throws Exception
    {
        // Note: GnuParser's flatten() splits "-btoast" into "-b" and "toast"
        // because "b" is a recognised option (GNU-style joined short option),
        // unlike PosixParser which leaves the unrecognised token intact.
        // Once "foober" triggers stopAtNonOption, the remaining split tokens
        // are pushed through unprocessed as plain arguments.
        String[] args = new String[] { "-c", "foober", "-btoast" };

        CommandLine cl = parser.parse(options, args, true);

        assertTrue("Confirm -c is set", cl.hasOption("c"));
        assertFalse("Confirm -b is not set", cl.hasOption("b"));
        assertEquals("Confirm 3 extra args", 3, cl.getArgList().size());
        assertEquals("foober", cl.getArgList().get(0));
        assertEquals("-b", cl.getArgList().get(1));
        assertEquals("toast", cl.getArgList().get(2));
    }

    public void testUnrecognizedOption() throws Exception
    {
        String[] args = new String[] { "-z" };

        boolean caught = false;
        try
        {
            parser.parse(options, args);
        }
        catch (UnrecognizedOptionException e)
        {
            caught = true;
        }

        assertTrue("Confirm UnrecognizedOptionException caught", caught);
    }

    public void testUnrecognizedOptionWithStopAtNonOption() throws Exception
    {
        String[] args = new String[] { "-z", "foo", "bar" };

        CommandLine cl = parser.parse(options, args, true);

        assertFalse("Confirm -z is not set", cl.hasOption('z'));
        assertEquals("Confirm all tokens pushed to args", 3, cl.getArgList().size());
        assertEquals("-z", cl.getArgList().get(0));
        assertEquals("foo", cl.getArgList().get(1));
        assertEquals("bar", cl.getArgList().get(2));
    }

    public void testMissingArg() throws Exception
    {
        String[] args = new String[] { "-b" };

        boolean caught = false;
        try
        {
            parser.parse(options, args);
        }
        catch (MissingArgumentException e)
        {
            caught = true;
        }

        assertTrue("Confirm MissingArgumentException caught", caught);
    }

    public void testPropertyOptionGnuStyle() throws Exception
    {
        // "-Dproperty=value" style: -D is a known short option, the rest
        // of the token is split off and becomes a separate argument.
        Options propOptions = new Options().addOption("D", true, "define a property");

        String[] args = new String[] { "-Dfoo=bar" };

        CommandLine cl = parser.parse(propOptions, args);

        assertTrue("Confirm -D is set", cl.hasOption("D"));
        assertEquals("Confirm value of -D", "foo=bar", cl.getOptionValue("D"));
        assertEquals("Confirm no extra args", 0, cl.getArgList().size());
    }

    public void testFlattenDoubleDashStopsProcessing()
    {
        String[] args = new String[] { "-a", "--", "-b", "foo" };

        String[] flattened = parser.flatten(options, args, false);

        assertEquals(4, flattened.length);
        assertEquals("-a", flattened[0]);
        assertEquals("--", flattened[1]);
        assertEquals("-b", flattened[2]);
        assertEquals("foo", flattened[3]);
    }

    public void testFlattenSingleDashPreserved()
    {
        String[] args = new String[] { "-" };

        String[] flattened = parser.flatten(options, args, false);

        assertEquals(1, flattened.length);
        assertEquals("-", flattened[0]);
    }

    public void testFlattenKnownShortOptionUnchanged()
    {
        String[] args = new String[] { "-a" };

        String[] flattened = parser.flatten(options, args, false);

        assertEquals(1, flattened.length);
        assertEquals("-a", flattened[0]);
    }

    public void testFlattenUnknownOptionNotStopped()
    {
        String[] args = new String[] { "-z", "foo" };

        String[] flattened = parser.flatten(options, args, false);

        assertEquals(2, flattened.length);
        assertEquals("-z", flattened[0]);
        assertEquals("foo", flattened[1]);
    }

    public void testFlattenUnknownOptionStopped()
    {
        String[] args = new String[] { "-z", "foo", "bar" };

        String[] flattened = parser.flatten(options, args, true);

        assertEquals(3, flattened.length);
        assertEquals("-z", flattened[0]);
        assertEquals("foo", flattened[1]);
        assertEquals("bar", flattened[2]);
    }

    public void testFlattenPlainArgumentUnchanged()
    {
        String[] args = new String[] { "foo", "bar" };

        String[] flattened = parser.flatten(options, args, false);

        assertEquals(2, flattened.length);
        assertEquals("foo", flattened[0]);
        assertEquals("bar", flattened[1]);
    }

    public void testFlattenEmptyArguments()
    {
        String[] args = new String[0];

        String[] flattened = parser.flatten(options, args, false);

        assertEquals(0, flattened.length);
    }

    public void testComplexShortNotBundled() throws Exception
    {
        // Unlike PosixParser, GnuParser does not bundle multiple
        // single-letter boolean options into one token; "-acbtoast"
        // is split into the short option "-a" and the rest as a
        // plain (non-option) argument.
        String[] args = new String[] { "-acbtoast", "foo" };

        CommandLine cl = parser.parse(options, args);

        assertTrue("Confirm -a is set", cl.hasOption("a"));
        assertFalse("Confirm -b is not set", cl.hasOption("b"));
        assertFalse("Confirm -c is not set", cl.hasOption("c"));
        assertEquals("Confirm 2 extra args", 2, cl.getArgList().size());
        assertEquals("cbtoast", cl.getArgList().get(0));
        assertEquals("foo", cl.getArgList().get(1));
    }
}
