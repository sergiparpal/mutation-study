/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.text.FieldPosition;
import java.text.Format;
import java.text.ParsePosition;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.junit.Test;

/**
 * Tests for {@link ExtendedMessageFormat}.
 */
public class ExtendedMessageFormatAgentTest {

    /**
     * Simple custom format that upper-cases its argument's String value and
     * records the arguments string it was built with.
     */
    private static class UpperCaseFormat extends Format {
        private static final long serialVersionUID = 1L;
        final String args;

        UpperCaseFormat(String args) {
            this.args = args;
        }

        @Override
        public StringBuffer format(Object obj, StringBuffer toAppendTo, FieldPosition pos) {
            return toAppendTo.append(String.valueOf(obj).toUpperCase());
        }

        @Override
        public Object parseObject(String source, ParsePosition pos) {
            return source;
        }
    }

    private static class UpperCaseFormatFactory implements FormatFactory {
        String lastName;
        String lastArgs;
        Locale lastLocale;

        public Format getFormat(String name, String arguments, Locale locale) {
            lastName = name;
            lastArgs = arguments;
            lastLocale = locale;
            return new UpperCaseFormat(arguments);
        }
    }

    private Map<String, FormatFactory> registryOf(String name, FormatFactory factory) {
        Map<String, FormatFactory> map = new HashMap<String, FormatFactory>();
        map.put(name, factory);
        return map;
    }

    // -----------------------------------------------------------------------
    // Basic behaviour, no registry
    // -----------------------------------------------------------------------

    @Test
    public void testNoRegistrySimplePattern() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("Hello, {0}!");
        assertEquals("Hello, {0}!", emf.toPattern());
        assertEquals("Hello, World!", emf.format(new Object[] { "World" }));
    }

    @Test
    public void testDefaultLocaleConstructorUsesDefaultLocale() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        assertEquals(Locale.getDefault(), emf.getLocale());
    }

    @Test
    public void testExplicitLocaleIsHonoured() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}", Locale.GERMANY);
        assertEquals(Locale.GERMANY, emf.getLocale());
    }

    @Test
    public void testNullRegistryBehavesLikePlainMessageFormat() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number,#.##}", Locale.US,
                null);
        assertEquals("3.14", emf.format(new Object[] { new Double(3.14159) }));
        assertEquals("{0,number,#0.##}", emf.toPattern());
    }

    // -----------------------------------------------------------------------
    // Registry-driven custom formats
    // -----------------------------------------------------------------------

    @Test
    public void testCustomFormatIsUsedForFormatting() {
        UpperCaseFormatFactory factory = new UpperCaseFormatFactory();
        Map<String, FormatFactory> registry = registryOf("upper", factory);
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", registry);
        assertEquals("ABC", emf.format(new Object[] { "abc" }));
    }

    @Test
    public void testCustomFormatPatternRoundTrips() {
        UpperCaseFormatFactory factory = new UpperCaseFormatFactory();
        Map<String, FormatFactory> registry = registryOf("upper", factory);
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}", registry);
        assertEquals("{0,upper}", emf.toPattern());
    }

    @Test
    public void testCustomFormatReceivesStyleArguments() {
        UpperCaseFormatFactory factory = new UpperCaseFormatFactory();
        Map<String, FormatFactory> registry = registryOf("upper", factory);
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper,someStyle}", registry);
        assertEquals("upper", factory.lastName);
        assertEquals("someStyle", factory.lastArgs);
        assertEquals("{0,upper,someStyle}", emf.toPattern());
        assertEquals("XYZ", emf.format(new Object[] { "xyz" }));
    }

    @Test
    public void testUnknownFormatNameFallsBackToBuiltIn() {
        Map<String, FormatFactory> registry = registryOf("upper", new UpperCaseFormatFactory());
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,number,#.#}", registry);
        assertEquals("3.1", emf.format(new Object[] { new Double(3.14) }));
        assertEquals("{0,number,#0.#}", emf.toPattern());
    }

    @Test
    public void testMultipleArgumentsMixedCustomAndBuiltIn() {
        Map<String, FormatFactory> registry = registryOf("upper", new UpperCaseFormatFactory());
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper} and {1,number,#.#}",
                registry);
        assertEquals("ABC and 3.1", emf.format(new Object[] { "abc", new Double(3.14) }));
    }

    @Test
    public void testWhitespaceAroundFormatElementIsTrimmed() {
        UpperCaseFormatFactory factory = new UpperCaseFormatFactory();
        Map<String, FormatFactory> registry = registryOf("upper", factory);
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{ 0 , upper }", registry);
        assertEquals("ABC", emf.format(new Object[] { "abc" }));
        assertEquals("upper", factory.lastName);
    }

    // -----------------------------------------------------------------------
    // Disabled mutators
    // -----------------------------------------------------------------------

    @Test
    public void testSetFormatThrowsUnsupported() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        try {
            emf.setFormat(0, new UpperCaseFormat(null));
            fail("expected UnsupportedOperationException");
        } catch (UnsupportedOperationException e) {
            // expected
        }
    }

    @Test
    public void testSetFormatByArgumentIndexThrowsUnsupported() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        try {
            emf.setFormatByArgumentIndex(0, new UpperCaseFormat(null));
            fail("expected UnsupportedOperationException");
        } catch (UnsupportedOperationException e) {
            // expected
        }
    }

    @Test
    public void testSetFormatsThrowsUnsupported() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        try {
            emf.setFormats(new Format[] { new UpperCaseFormat(null) });
            fail("expected UnsupportedOperationException");
        } catch (UnsupportedOperationException e) {
            // expected
        }
    }

    @Test
    public void testSetFormatsByArgumentIndexThrowsUnsupported() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0}");
        try {
            emf.setFormatsByArgumentIndex(new Format[] { new UpperCaseFormat(null) });
            fail("expected UnsupportedOperationException");
        } catch (UnsupportedOperationException e) {
            // expected
        }
    }

    // -----------------------------------------------------------------------
    // Error / boundary cases
    // -----------------------------------------------------------------------

    @Test
    public void testUnterminatedFormatElementThrows() {
        try {
            new ExtendedMessageFormat("{0", new HashMap<String, FormatFactory>());
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testNonDigitArgumentIndexThrows() {
        try {
            new ExtendedMessageFormat("{abc}", new HashMap<String, FormatFactory>());
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testEmptyArgumentIndexThrows() {
        try {
            new ExtendedMessageFormat("{}", new HashMap<String, FormatFactory>());
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testTrailingUnmatchedQuoteIsImplicitlyClosed() {
        // java.text.MessageFormat tolerates a quote left open at the end of
        // the pattern by implicitly closing it; ExtendedMessageFormat should
        // behave the same way, with or without a registry.
        ExtendedMessageFormat noRegistry = new ExtendedMessageFormat("'{0}");
        assertEquals("{0}", noRegistry.format(new Object[] { "X" }));

        ExtendedMessageFormat withRegistry = new ExtendedMessageFormat("'{0}",
                new HashMap<String, FormatFactory>());
        assertEquals("{0}", withRegistry.format(new Object[] { "X" }));
    }

    @Test
    public void testNullPatternWithoutRegistryThrows() {
        try {
            new ExtendedMessageFormat(null);
            fail("expected an exception for a null pattern");
        } catch (RuntimeException e) {
            // expected: NullPointerException from the superclass
        }
    }

    @Test
    public void testNullPatternWithRegistryThrows() {
        try {
            new ExtendedMessageFormat(null, new HashMap<String, FormatFactory>());
            fail("expected an exception for a null pattern");
        } catch (RuntimeException e) {
            // expected: NullPointerException while scanning the pattern
        }
    }

    // -----------------------------------------------------------------------
    // Quoted literal text
    // -----------------------------------------------------------------------

    @Test
    public void testEscapedQuoteProducesLiteralQuoteNoRegistry() {
        ExtendedMessageFormat emf = new ExtendedMessageFormat("it''s {0}");
        assertEquals("it's ok", emf.format(new Object[] { "ok" }));
    }

    @Test
    public void testEscapedQuoteProducesLiteralQuoteWithRegistry() {
        Map<String, FormatFactory> registry = registryOf("upper", new UpperCaseFormatFactory());
        ExtendedMessageFormat emf = new ExtendedMessageFormat("it''s {0,upper}", registry);
        assertEquals("it's OK", emf.format(new Object[] { "ok" }));
    }

    @Test
    public void testQuotedLiteralBraceIsNotTreatedAsFormatElement() {
        // '{0}' is a literal, quoted "{0}" - it must not be substituted and
        // must not interfere with the following, real format element.
        ExtendedMessageFormat emf = new ExtendedMessageFormat("'{0}' {1}");
        assertEquals("{0} hi", emf.format(new Object[] { "ignored", "hi" }));
    }

    @Test
    public void testQuotedLiteralBraceBeforeCustomFormatElement() {
        // Same as above, but the real argument after the quoted literal uses
        // a registry-provided custom format, exercising the interaction
        // between the quote-skipping logic and the custom-format bookkeeping.
        Map<String, FormatFactory> registry = registryOf("upper", new UpperCaseFormatFactory());
        ExtendedMessageFormat emf = new ExtendedMessageFormat("'{0}' {1,upper}", registry);
        assertEquals("{0} HI", emf.format(new Object[] { "ignored", "hi" }));
    }

    // -----------------------------------------------------------------------
    // Format element index re-numbering sanity check
    // -----------------------------------------------------------------------

    @Test
    public void testRepeatedArgumentIndexUsesSameValue() {
        Map<String, FormatFactory> registry = registryOf("upper", new UpperCaseFormatFactory());
        ExtendedMessageFormat emf = new ExtendedMessageFormat("{0,upper}-{0}", registry);
        assertEquals("AB-ab", emf.format(new Object[] { "ab" }));
    }

    @Test
    public void testFormatEqualsPatternIndependentOfRegistryPresence() {
        ExtendedMessageFormat plain = new ExtendedMessageFormat("{0}");
        ExtendedMessageFormat withEmptyRegistry = new ExtendedMessageFormat("{0}",
                new HashMap<String, FormatFactory>());
        assertEquals(plain.format(new Object[] { "x" }), withEmptyRegistry.format(new Object[] { "x" }));
        assertFalse(plain.toPattern() == null);
        assertTrue(plain.toPattern().length() > 0);
    }
}
