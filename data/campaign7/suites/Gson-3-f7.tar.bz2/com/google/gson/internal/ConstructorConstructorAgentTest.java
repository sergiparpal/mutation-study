/*
 * Copyright (C) 2024 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.gson.internal;

import java.lang.reflect.Type;
import java.util.Collection;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;

import junit.framework.TestCase;

import com.google.gson.InstanceCreator;
import com.google.gson.JsonIOException;
import com.google.gson.reflect.TypeToken;

public final class ConstructorConstructorAgentTest extends TestCase {

  private static ConstructorConstructor withCreators(Map<Type, InstanceCreator<?>> creators) {
    return new ConstructorConstructor(creators);
  }

  private static ConstructorConstructor withNoCreators() {
    return new ConstructorConstructor(new HashMap<Type, InstanceCreator<?>>());
  }

  // ---- fixtures ----

  public static class PublicNoArg {
    public int x = 7;
    public PublicNoArg() {}
  }

  public static class PrivateNoArg {
    public String marker = "default";
    private PrivateNoArg() {
      marker = "constructed";
    }
  }

  public static class ThrowsInCtor {
    public ThrowsInCtor() {
      throw new IllegalStateException("boom");
    }
  }

  public static class NoNoArgCtor {
    public final int val;
    public NoNoArgCtor(int val) {
      this.val = val;
    }
  }

  public abstract static class AbstractWithImplicitCtor {
  }

  public interface PlainInterface {
  }

  public static class Box<T> {
    public T value;
  }

  public enum Color { RED, GREEN, BLUE }

  // ---- instance creators ----

  public void testInstanceCreator_exactTypeMatch() {
    Map<Type, InstanceCreator<?>> creators = new HashMap<Type, InstanceCreator<?>>();
    final PublicNoArg created = new PublicNoArg();
    created.x = 99;
    creators.put(PublicNoArg.class, new InstanceCreator<PublicNoArg>() {
      @Override public PublicNoArg createInstance(Type type) {
        return created;
      }
    });
    ConstructorConstructor cc = withCreators(creators);
    ObjectConstructor<PublicNoArg> constructor = cc.get(TypeToken.get(PublicNoArg.class));
    PublicNoArg instance = constructor.construct();
    assertSame(created, instance);
    assertEquals(99, instance.x);
  }

  public void testInstanceCreator_rawTypeMatchForParameterizedType() {
    Map<Type, InstanceCreator<?>> creators = new HashMap<Type, InstanceCreator<?>>();
    final Box<String> created = new Box<String>();
    created.value = "from-raw-creator";
    creators.put(Box.class, new InstanceCreator<Box<String>>() {
      @Override public Box<String> createInstance(Type type) {
        return created;
      }
    });
    ConstructorConstructor cc = withCreators(creators);
    TypeToken<Box<String>> token = new TypeToken<Box<String>>() {};
    ObjectConstructor<Box<String>> constructor = cc.get(token);
    Box<String> instance = constructor.construct();
    assertSame(created, instance);
    assertEquals("from-raw-creator", instance.value);
  }

  public void testInstanceCreator_exactTypeTakesPriorityOverRawType() {
    Map<Type, InstanceCreator<?>> creators = new HashMap<Type, InstanceCreator<?>>();
    TypeToken<Box<String>> token = new TypeToken<Box<String>>() {};
    final Box<String> fromExact = new Box<String>();
    fromExact.value = "exact";
    final Box<String> fromRaw = new Box<String>();
    fromRaw.value = "raw";
    creators.put(token.getType(), new InstanceCreator<Box<String>>() {
      @Override public Box<String> createInstance(Type type) {
        return fromExact;
      }
    });
    creators.put(Box.class, new InstanceCreator<Box<String>>() {
      @Override public Box<String> createInstance(Type type) {
        return fromRaw;
      }
    });
    ConstructorConstructor cc = withCreators(creators);
    ObjectConstructor<Box<String>> constructor = cc.get(token);
    Box<String> instance = constructor.construct();
    assertSame(fromExact, instance);
  }

  public void testInstanceCreator_receivesRequestedType() {
    Map<Type, InstanceCreator<?>> creators = new HashMap<Type, InstanceCreator<?>>();
    TypeToken<Box<String>> token = new TypeToken<Box<String>>() {};
    final Type[] received = new Type[1];
    creators.put(Box.class, new InstanceCreator<Box<String>>() {
      @Override public Box<String> createInstance(Type type) {
        received[0] = type;
        return new Box<String>();
      }
    });
    ConstructorConstructor cc = withCreators(creators);
    cc.get(token).construct();
    assertEquals(token.getType(), received[0]);
  }

  // ---- default no-arg constructor ----

  public void testDefaultConstructor_publicNoArgInvoked() {
    ConstructorConstructor cc = withNoCreators();
    ObjectConstructor<PublicNoArg> constructor = cc.get(TypeToken.get(PublicNoArg.class));
    PublicNoArg instance = constructor.construct();
    assertEquals(7, instance.x);
  }

  public void testDefaultConstructor_privateNoArgIsInvokedViaSetAccessible() {
    ConstructorConstructor cc = withNoCreators();
    ObjectConstructor<PrivateNoArg> constructor = cc.get(TypeToken.get(PrivateNoArg.class));
    PrivateNoArg instance = constructor.construct();
    assertEquals("constructed", instance.marker);
  }

  public void testDefaultConstructor_eachCallReturnsNewInstance() {
    ConstructorConstructor cc = withNoCreators();
    ObjectConstructor<PublicNoArg> constructor = cc.get(TypeToken.get(PublicNoArg.class));
    PublicNoArg a = constructor.construct();
    PublicNoArg b = constructor.construct();
    assertNotSame(a, b);
  }

  public void testDefaultConstructor_exceptionFromCtorIsWrappedWithOriginalCause() {
    ConstructorConstructor cc = withNoCreators();
    ObjectConstructor<ThrowsInCtor> constructor = cc.get(TypeToken.get(ThrowsInCtor.class));
    try {
      constructor.construct();
      fail("Expected RuntimeException");
    } catch (RuntimeException expected) {
      assertTrue(expected.getCause() instanceof IllegalStateException);
      assertEquals("boom", expected.getCause().getMessage());
    }
  }

  public void testAbstractClassWithImplicitNoArgConstructor_constructThrows() {
    ConstructorConstructor cc = withNoCreators();
    ObjectConstructor<AbstractWithImplicitCtor> constructor =
        cc.get(TypeToken.get(AbstractWithImplicitCtor.class));
    assertNotNull(constructor);
    try {
      constructor.construct();
      fail("Expected an exception when instantiating an abstract class");
    } catch (RuntimeException expected) {
      // abstract classes cannot be instantiated reflectively
    }
  }

  // ---- fallback to unsafe allocator ----

  public void testNoNoArgConstructor_fallsBackToUnsafeAllocatorWithoutInvokingCtor() {
    ConstructorConstructor cc = withNoCreators();
    ObjectConstructor<NoNoArgCtor> constructor = cc.get(TypeToken.get(NoNoArgCtor.class));
    NoNoArgCtor instance = constructor.construct();
    assertNotNull(instance);
    assertEquals(0, instance.val);
  }

  public void testInterface_constructThrows() {
    ConstructorConstructor cc = withNoCreators();
    ObjectConstructor<PlainInterface> constructor = cc.get(TypeToken.get(PlainInterface.class));
    assertNotNull(constructor);
    try {
      constructor.construct();
      fail("Expected an exception when instantiating an interface");
    } catch (RuntimeException expected) {
      // interfaces cannot be instantiated
    }
  }

  // ---- default collection/map implementations ----

  public void testList_defaultsToArrayList() {
    ConstructorConstructor cc = withNoCreators();
    TypeToken<List<String>> token = new TypeToken<List<String>>() {};
    List<String> instance = cc.get(token).construct();
    assertEquals(java.util.ArrayList.class, instance.getClass());
    instance.add("a");
    assertEquals(1, instance.size());
  }

  public void testAbstractCollection_defaultsToArrayList() {
    ConstructorConstructor cc = withNoCreators();
    TypeToken<Collection<String>> token = new TypeToken<Collection<String>>() {};
    Collection<String> instance = cc.get(token).construct();
    assertEquals(java.util.ArrayList.class, instance.getClass());
  }

  public void testSet_defaultsToLinkedHashSet() {
    ConstructorConstructor cc = withNoCreators();
    TypeToken<Set<String>> token = new TypeToken<Set<String>>() {};
    Set<String> instance = cc.get(token).construct();
    assertEquals(LinkedHashSet.class, instance.getClass());
  }

  public void testSortedSet_defaultsToTreeSet() {
    ConstructorConstructor cc = withNoCreators();
    TypeToken<SortedSet<String>> token = new TypeToken<SortedSet<String>>() {};
    SortedSet<String> instance = cc.get(token).construct();
    assertEquals(TreeSet.class, instance.getClass());
  }

  public void testQueue_defaultsToLinkedList() {
    ConstructorConstructor cc = withNoCreators();
    TypeToken<Queue<String>> token = new TypeToken<Queue<String>>() {};
    Queue<String> instance = cc.get(token).construct();
    assertEquals(LinkedList.class, instance.getClass());
  }

  public void testMapWithStringKey_defaultsToLinkedTreeMap() {
    ConstructorConstructor cc = withNoCreators();
    TypeToken<Map<String, Integer>> token = new TypeToken<Map<String, Integer>>() {};
    Map<String, Integer> instance = cc.get(token).construct();
    assertEquals(LinkedTreeMap.class, instance.getClass());
  }

  public void testMapWithNonStringKey_defaultsToLinkedHashMap() {
    ConstructorConstructor cc = withNoCreators();
    TypeToken<Map<Integer, String>> token = new TypeToken<Map<Integer, String>>() {};
    Map<Integer, String> instance = cc.get(token).construct();
    assertEquals(LinkedHashMap.class, instance.getClass());
  }

  public void testSortedMap_defaultsToTreeMap() {
    ConstructorConstructor cc = withNoCreators();
    TypeToken<SortedMap<String, Integer>> token = new TypeToken<SortedMap<String, Integer>>() {};
    SortedMap<String, Integer> instance = cc.get(token).construct();
    assertEquals(TreeMap.class, instance.getClass());
  }

  public void testRawMap_withoutTypeParameters_defaultsToLinkedTreeMap() {
    ConstructorConstructor cc = withNoCreators();
    @SuppressWarnings("unchecked")
    TypeToken<Map> token = (TypeToken<Map>) TypeToken.get(Map.class);
    Map instance = cc.get(token).construct();
    assertEquals(LinkedTreeMap.class, instance.getClass());
  }

  public void testEnumSet_withParameterizedType_createsEnumSetOfRequestedEnum() {
    ConstructorConstructor cc = withNoCreators();
    TypeToken<EnumSet<Color>> token = new TypeToken<EnumSet<Color>>() {};
    EnumSet<Color> instance = cc.get(token).construct();
    assertTrue(instance.isEmpty());
    instance.add(Color.RED);
    assertTrue(instance.contains(Color.RED));
  }

  public void testEnumSet_withoutParameterizedType_constructThrowsJsonIOException() {
    ConstructorConstructor cc = withNoCreators();
    @SuppressWarnings("unchecked")
    TypeToken<EnumSet> token = (TypeToken<EnumSet>) TypeToken.get(EnumSet.class);
    ObjectConstructor<EnumSet> constructor = cc.get(token);
    try {
      constructor.construct();
      fail("Expected JsonIOException for raw EnumSet type");
    } catch (JsonIOException expected) {
      assertTrue(expected.getMessage().contains("Invalid EnumSet type"));
    }
  }

  // ---- misc ----

  public void testToString_reflectsInstanceCreatorsMap() {
    Map<Type, InstanceCreator<?>> creators = new HashMap<Type, InstanceCreator<?>>();
    InstanceCreator<PublicNoArg> creator = new InstanceCreator<PublicNoArg>() {
      @Override public PublicNoArg createInstance(Type type) {
        return new PublicNoArg();
      }
    };
    creators.put(PublicNoArg.class, creator);
    ConstructorConstructor cc = withCreators(creators);
    assertEquals(creators.toString(), cc.toString());
  }

  public void testGet_returnsNonNullConstructorForEveryKind() {
    ConstructorConstructor cc = withNoCreators();
    assertNotNull(cc.get(TypeToken.get(PublicNoArg.class)));
    assertNotNull(cc.get(TypeToken.get(NoNoArgCtor.class)));
    assertNotNull(cc.get(TypeToken.get(PlainInterface.class)));
    assertNotNull(cc.get(new TypeToken<List<String>>() {}));
  }
}
