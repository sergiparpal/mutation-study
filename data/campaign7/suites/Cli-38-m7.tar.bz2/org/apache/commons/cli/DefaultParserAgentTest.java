/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.cli;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.Properties;

import org.junit.Test;

/**
 * Self-contained tests for {@link DefaultParser}.
 */
public class DefaultParserAgentTest
{
    private Options newBasicOptions()
    {
        Options options = new Options();
        options.addOption("a", "enable-a", false, "turn [a] on or off");
        options.addOption("b", "bfile", true, "set the value of [b]");
        options.addOption("c", "copt", false, "turn [c] on or off");
        return options;
    }

    @Test
    public void testSimpleShortOptions() throws Exception
    {
        DefaultParser parser = new DefaultParser();
        Options options = newBasicOptions();

        String[] args = new String[] { "-a", "-b", "toast", "foo", "bar" };

        CommandLine cl = parser.parse(options, args);

        assertTrue(cl.hasOption("a"));
        assertTrue(cl.hasOption("b"));
        assertEquals("toast", cl.getOptionValue("b"));
        assertEquals(2, cl.getArgList().size());
        assertEquals("foo", cl.getArgList().get(0));
        assertEquals("bar", cl.getArgList().get(1));
    }

    @Test
    public void testSimpleLongOptions() throws Exception
    {
        DefaultParser parser = new DefaultParser();
        Options options = newBasicOptions();

        String[] args = new String[] { "--enable-a", "--bfile", "toast" };

        CommandLine cl = parser.parse(options, args);

        assertTrue(cl.hasOption("a"));
        assertEquals("toast", cl.getOptionValue("bfile"));
        assertEquals(0, cl.getArgList().size());
    }

    @Test
    public void testNullArgumentsArray() throws Exception
    {
        DefaultParser parser = new DefaultParser();
        Options options = newBasicOptions();

        CommandLine cl = parser.parse(options, null);

        assertFalse(cl.hasOption("a"));
        assertEquals(0, cl.getArgList().size());
        assertEquals(0, cl.getOptions().length);
    }

    @Test
    public void testEmptyArgumentsArray() throws Exception
    {
        DefaultParser parser = new DefaultParser();
        Options options = newBasicOptions();

        CommandLine cl = parser.parse(options, new String[0]);

        assertFalse(cl.hasOption("a"));
        assertEquals(0, cl.getArgList().size());
    }

    @Test
    public void testUnrecognizedOptionThrows()
    {
        DefaultParser parser = new DefaultParser();
        Options options = newBasicOptions();

        String[] args = new String[] { "-a", "-d", "-b", "toast" };

        try
        {
            parser.parse(options, args);
            fail("expected UnrecognizedOptionException");
        }
        catch (UnrecognizedOptionException e)
        {
            assertEquals("-d", e.getOption());
        }
        catch (ParseException e)
        {
            fail("expected UnrecognizedOptionException, got " + e);
        }
    }

    @Test
    public void testMissingArgumentThrows()
    {
        DefaultParser parser = new DefaultParser();
        Options options = newBasicOptions();

        String[] args = new String[] { "-b" };

        try
        {
            parser.parse(options, args);
            fail("expected MissingArgumentException");
        }
        catch (MissingArgumentException e)
        {
            assertEquals("b", e.getOption().getOpt());
        }
        catch (ParseException e)
        {
            fail("expected MissingArgumentException, got " + e);
        }
    }

    @Test
    public void testMissingRequiredOptionThrows()
    {
        DefaultParser parser = new DefaultParser();
        Options options = new Options();
        options.addOption("a", false, null);
        options.addOption(OptionBuilder.withLongOpt("bfile").hasArg().isRequired().create('b'));

        try
        {
            parser.parse(options, new String[] { "-a" });
            fail("expected MissingOptionException");
        }
        catch (MissingOptionException e)
        {
            assertEquals("Missing required option: b", e.getMessage());
            assertTrue(e.getMissingOptions().contains("b"));
        }
        catch (ParseException e)
        {
            fail("expected MissingOptionException, got " + e);
        }
    }

    @Test
    public void testMissingMultipleRequiredOptionsThrows()
    {
        DefaultParser parser = new DefaultParser();
        Options options = new Options();
        options.addOption(OptionBuilder.isRequired().create('b'));
        options.addOption(OptionBuilder.isRequired().create('c'));

        try
        {
            parser.parse(options, new String[0]);
            fail("expected MissingOptionException");
        }
        catch (MissingOptionException e)
        {
            assertEquals(2, e.getMissingOptions().size());
            assertTrue(e.getMissingOptions().contains("b"));
            assertTrue(e.getMissingOptions().contains("c"));
        }
        catch (ParseException e)
        {
            fail("expected MissingOptionException, got " + e);
        }
    }

    @Test
    public void testAmbiguousPartialLongOptionThrows()
    {
        DefaultParser parser = new DefaultParser();
        Options options = new Options();
        options.addOption(OptionBuilder.withLongOpt("version").create());
        options.addOption(OptionBuilder.withLongOpt("verbose").create());

        try
        {
            parser.parse(options, new String[] { "--ver" });
            fail("expected AmbiguousOptionException");
        }
        catch (AmbiguousOptionException e)
        {
            assertEquals("--ver", e.getOption());
            assertEquals(2, e.getMatchingOptions().size());
        }
        catch (ParseException e)
        {
            fail("expected AmbiguousOptionException, got " + e);
        }
    }

    @Test
    public void testAlreadySelectedExceptionInGroupThrows()
    {
        DefaultParser parser = new DefaultParser();

        OptionGroup group = new OptionGroup();
        group.addOption(OptionBuilder.create("a"));
        group.addOption(OptionBuilder.create("b"));

        Options options = new Options();
        options.addOptionGroup(group);

        try
        {
            parser.parse(options, new String[] { "-a", "-b" });
            fail("expected AlreadySelectedException");
        }
        catch (AlreadySelectedException e)
        {
            assertEquals("b", e.getOption().getOpt());
            assertEquals("a", e.getOptionGroup().getSelected());
        }
        catch (ParseException e)
        {
            fail("expected AlreadySelectedException, got " + e);
        }
    }

    @Test
    public void testDoubleDashStopsOptionParsing() throws Exception
    {
        DefaultParser parser = new DefaultParser();
        Options options = newBasicOptions();

        String[] args = new String[] { "--copt", "--", "-b", "toast" };

        CommandLine cl = parser.parse(options, args);

        assertTrue(cl.hasOption("c"));
        assertFalse(cl.hasOption("b"));
        assertEquals(2, cl.getArgList().size());
        assertEquals("-b", cl.getArgList().get(0));
        assertEquals("toast", cl.getArgList().get(1));
    }

    @Test
    public void testStopAtNonOptionAddsRemainingAsArgs() throws Exception
    {
        DefaultParser parser = new DefaultParser();
        Options options = newBasicOptions();

        String[] args = new String[] { "-z", "-a", "-btoast" };

        CommandLine cl = parser.parse(options, args, true);

        assertFalse(cl.hasOption("a"));
        assertEquals(3, cl.getArgList().size());
        assertEquals("-z", cl.getArgList().get(0));
    }

    @Test
    public void testStopAtNonOptionFalseThrowsForSameInput()
    {
        DefaultParser parser = new DefaultParser();
        Options options = newBasicOptions();

        String[] args = new String[] { "-z", "-a" };

        try
        {
            parser.parse(options, args, false);
            fail("expected UnrecognizedOptionException");
        }
        catch (UnrecognizedOptionException e)
        {
            assertEquals("-z", e.getOption());
        }
        catch (ParseException e)
        {
            fail("expected UnrecognizedOptionException, got " + e);
        }
    }

    @Test
    public void testNegativeNumberTreatedAsArgumentValue() throws Exception
    {
        DefaultParser parser = new DefaultParser();
        Options options = newBasicOptions();

        String[] args = new String[] { "-b", "-1" };

        CommandLine cl = parser.parse(options, args);

        assertEquals("-1", cl.getOptionValue("b"));
        assertEquals(0, cl.getArgList().size());
    }

    @Test
    public void testSingleDashTreatedAsArgument() throws Exception
    {
        DefaultParser parser = new DefaultParser();
        Options options = newBasicOptions();

        String[] args = new String[] { "-b", "-" };

        CommandLine cl = parser.parse(options, args);

        assertTrue(cl.hasOption("b"));
        assertEquals("-", cl.getOptionValue("b"));
    }

    @Test
    public void testShortOptionBursting() throws Exception
    {
        DefaultParser parser = new DefaultParser();
        Options options = newBasicOptions();

        String[] args = new String[] { "-acbtoast", "foo" };

        CommandLine cl = parser.parse(options, args);

        assertTrue(cl.hasOption("a"));
        assertTrue(cl.hasOption("b"));
        assertTrue(cl.hasOption("c"));
        assertEquals("toast", cl.getOptionValue("b"));
        assertEquals(1, cl.getArgList().size());
        assertEquals("foo", cl.getArgList().get(0));
    }

    @Test
    public void testShortOptionWithEqualsSign() throws Exception
    {
        DefaultParser parser = new DefaultParser();
        Options options = new Options();
        options.addOption(OptionBuilder.withLongOpt("foo").hasArg().create('f'));

        CommandLine cl = parser.parse(options, new String[] { "-f=bar" });

        assertEquals("bar", cl.getOptionValue("foo"));
    }

    @Test
    public void testLongOptionWithEqualsSign() throws Exception
    {
        DefaultParser parser = new DefaultParser();
        Options options = new Options();
        options.addOption(OptionBuilder.withLongOpt("foo").hasArg().create('f'));

        CommandLine cl = parser.parse(options, new String[] { "--foo=bar" });

        assertEquals("bar", cl.getOptionValue("foo"));
    }

    @Test
    public void testPropertiesSuppliesMissingBooleanOption() throws Exception
    {
        DefaultParser parser = new DefaultParser();
        Options options = new Options();
        options.addOption("a", false, "toggle -a");

        Properties properties = new Properties();
        properties.setProperty("a", "true");

        CommandLine cl = parser.parse(options, new String[0], properties);

        assertTrue(cl.hasOption("a"));
    }

    @Test
    public void testPropertiesIgnoredWhenAlreadySetOnCommandLine() throws Exception
    {
        DefaultParser parser = new DefaultParser();
        Options options = new Options();
        options.addOption(OptionBuilder.hasArg().create('b'));

        Properties properties = new Properties();
        properties.setProperty("b", "fromProperties");

        CommandLine cl = parser.parse(options, new String[] { "-b", "fromArgs" }, properties);

        assertEquals("fromArgs", cl.getOptionValue("b"));
    }

    @Test
    public void testUnknownPropertyThrowsUnrecognizedOptionException()
    {
        DefaultParser parser = new DefaultParser();
        Options options = new Options();

        Properties properties = new Properties();
        properties.setProperty("f", "true");

        try
        {
            parser.parse(options, null, properties);
            fail("expected UnrecognizedOptionException");
        }
        catch (UnrecognizedOptionException e)
        {
            assertEquals("f", e.getOption());
        }
        catch (ParseException e)
        {
            fail("expected UnrecognizedOptionException, got " + e);
        }
    }

    @Test
    public void testNullPropertiesAreIgnored() throws Exception
    {
        DefaultParser parser = new DefaultParser();
        Options options = newBasicOptions();

        CommandLine cl = parser.parse(options, new String[] { "-a" }, (Properties) null);

        assertTrue(cl.hasOption("a"));
    }

    @Test
    public void testThreeArgOverloadWithStopAtNonOption() throws Exception
    {
        DefaultParser parser = new DefaultParser();
        Options options = newBasicOptions();

        CommandLine cl = parser.parse(options, new String[] { "-z", "-a" }, true);

        assertFalse(cl.hasOption("a"));
        assertEquals(2, cl.getArgList().size());
    }

    @Test
    public void testReusingOptionsInstanceAcrossParsesResetsGroupSelection() throws Exception
    {
        DefaultParser parser = new DefaultParser();

        Options options = new Options();
        options.addOption(OptionBuilder.isRequired().create('v'));

        // first parse succeeds
        CommandLine first = parser.parse(options, new String[] { "-v" });
        assertTrue(first.hasOption("v"));

        // second parse with the same Options instance but missing the required option
        try
        {
            parser.parse(options, new String[0]);
            fail("expected MissingOptionException");
        }
        catch (MissingOptionException e)
        {
            assertTrue(e.getMissingOptions().contains("v"));
        }
        catch (ParseException e)
        {
            fail("expected MissingOptionException, got " + e);
        }
    }

    @Test
    public void testOptionCloneIsolatesSuccessiveParses() throws Exception
    {
        DefaultParser parser = new DefaultParser();

        Options options = new Options();
        options.addOption(OptionBuilder.hasArg().create('b'));

        CommandLine first = parser.parse(options, new String[] { "-b", "one" });
        assertEquals("one", first.getOptionValue("b"));

        CommandLine second = parser.parse(options, new String[] { "-b", "two" });
        assertEquals("two", second.getOptionValue("b"));

        // the first CommandLine's option instance must not have been mutated by the second parse
        assertEquals("one", first.getOptionValue("b"));
    }

    @Test
    public void testUnlimitedArgsConsumesUntilNextOption() throws Exception
    {
        DefaultParser parser = new DefaultParser();
        Options options = new Options();
        options.addOption(OptionBuilder.hasArgs().create("e"));
        options.addOption(OptionBuilder.hasArgs().create("f"));

        CommandLine cl = parser.parse(options, new String[] { "-e", "one", "two", "-f", "alpha" });

        assertEquals(2, cl.getOptionValues("e").length);
        assertEquals(1, cl.getOptionValues("f").length);
    }

    @Test
    public void testGetOptionValueReturnsNullWhenOptionAbsent() throws Exception
    {
        DefaultParser parser = new DefaultParser();
        Options options = newBasicOptions();

        CommandLine cl = parser.parse(options, new String[0]);

        assertNull(cl.getOptionValue("b"));
        assertFalse(cl.hasOption("b"));
    }

    @Test
    public void testMultipleArgsFollowedByOptionStopsAtOption() throws Exception
    {
        DefaultParser parser = new DefaultParser();
        Options options = newBasicOptions();

        String[] args = new String[] { "-c", "foobar", "-b", "toast" };

        CommandLine cl = parser.parse(options, args, true);

        assertTrue(cl.hasOption("c"));
        assertEquals(3, cl.getArgList().size());
        assertFalse(cl.hasOption("b"));
    }

    @Test
    public void testArgumentStartingWithHyphenIsConsumed() throws Exception
    {
        DefaultParser parser = new DefaultParser();
        Options options = newBasicOptions();

        CommandLine cl = parser.parse(options, new String[] { "-b", "-foo" });

        assertEquals("-foo", cl.getOptionValue("b"));
    }

    @Test
    public void testPartialLongOptionResolvesUnambiguously() throws Exception
    {
        DefaultParser parser = new DefaultParser();
        Options options = new Options();
        options.addOption(OptionBuilder.withLongOpt("version").create());
        options.addOption(OptionBuilder.withLongOpt("help").create());

        CommandLine cl = parser.parse(options, new String[] { "--ver" });

        assertTrue(cl.hasOption("version"));
        assertFalse(cl.hasOption("help"));
    }

    @Test
    public void testLongOptionWithUnexpectedArgumentThrows()
    {
        DefaultParser parser = new DefaultParser();
        Options options = new Options();
        options.addOption(OptionBuilder.withLongOpt("foo").create('f'));

        try
        {
            parser.parse(options, new String[] { "--foo=bar" });
            fail("expected UnrecognizedOptionException");
        }
        catch (UnrecognizedOptionException e)
        {
            assertEquals("--foo=bar", e.getOption());
        }
        catch (ParseException e)
        {
            fail("expected UnrecognizedOptionException, got " + e);
        }
    }

    @Test
    public void testOptionGroupTracksSelectedOption() throws Exception
    {
        DefaultParser parser = new DefaultParser();

        OptionGroup group = new OptionGroup();
        group.addOption(OptionBuilder.create("a"));
        group.addOption(OptionBuilder.create("b"));

        Options options = new Options();
        options.addOptionGroup(group);

        CommandLine cl = parser.parse(options, new String[] { "-b" });

        assertTrue(cl.hasOption("b"));
        assertEquals("b", group.getSelected());
    }

    @Test
    public void testFieldsAreProtectedAndAccessibleFromSubclass() throws Exception
    {
        // DefaultParser exposes several protected fields; exercise a subclass
        // to confirm they are populated as documented after a parse.
        TrackingParser parser = new TrackingParser();
        Options options = newBasicOptions();

        CommandLine cl = parser.parse(options, new String[] { "-a", "foo" });

        assertNotNull(parser.cmd);
        assertTrue(parser.cmd == cl);
        assertTrue(parser.options == options);
        assertFalse(parser.stopAtNonOption);
    }

    /**
     * Minimal subclass used only to confirm the protected fields declared by
     * {@link DefaultParser} are visible and populated for subclasses.
     */
    private static class TrackingParser extends DefaultParser
    {
    }
}
