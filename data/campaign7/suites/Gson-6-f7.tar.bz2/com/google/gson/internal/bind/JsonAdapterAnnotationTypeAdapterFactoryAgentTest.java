/*
 * Copyright (C) 2024 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.gson.internal.bind;

import com.google.gson.Gson;
import com.google.gson.InstanceCreator;
import com.google.gson.TypeAdapter;
import com.google.gson.TypeAdapterFactory;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.internal.ConstructorConstructor;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import java.io.StringReader;
import java.lang.reflect.Type;
import java.util.Collections;
import java.util.Map;
import junit.framework.TestCase;

public final class JsonAdapterAnnotationTypeAdapterFactoryAgentTest extends TestCase {

  private static int pointAdapterInstanceCount;

  private JsonAdapterAnnotationTypeAdapterFactory newFactory() {
    Map<Type, InstanceCreator<?>> instanceCreators = Collections.emptyMap();
    ConstructorConstructor constructorConstructor = new ConstructorConstructor(instanceCreators);
    return new JsonAdapterAnnotationTypeAdapterFactory(constructorConstructor);
  }

  // No annotation on this class.
  private static class PlainClass {
  }

  @JsonAdapter(PointTypeAdapter.class)
  private static class Point {
    int x;
    int y;
  }

  private static class PointTypeAdapter extends TypeAdapter<Point> {
    private PointTypeAdapter() {
      pointAdapterInstanceCount++;
    }

    @Override public void write(JsonWriter out, Point value) throws IOException {
      out.value(value.x + "," + value.y);
    }

    @Override public Point read(JsonReader in) throws IOException {
      String[] parts = in.nextString().split(",");
      Point point = new Point();
      point.x = Integer.parseInt(parts[0]);
      point.y = Integer.parseInt(parts[1]);
      return point;
    }
  }

  @JsonAdapter(ColorTypeAdapterFactory.class)
  private static class Color {
    String name;
  }

  private static class ColorTypeAdapterFactory implements TypeAdapterFactory {
    static Gson lastGson;
    static TypeToken<?> lastTypeToken;

    @Override public <T> TypeAdapter<T> create(Gson gson, TypeToken<T> type) {
      lastGson = gson;
      lastTypeToken = type;
      @SuppressWarnings("unchecked")
      TypeAdapter<T> adapter = (TypeAdapter<T>) new ColorTypeAdapter();
      return adapter;
    }
  }

  private static class ColorTypeAdapter extends TypeAdapter<Color> {
    @Override public void write(JsonWriter out, Color value) throws IOException {
      out.value(value.name);
    }

    @Override public Color read(JsonReader in) throws IOException {
      Color color = new Color();
      color.name = in.nextString();
      return color;
    }
  }

  // Annotation value is neither a TypeAdapter nor a TypeAdapterFactory.
  @JsonAdapter(String.class)
  private static class BadlyAnnotated {
  }

  public void testCreate_noAnnotation_returnsNull() {
    JsonAdapterAnnotationTypeAdapterFactory factory = newFactory();
    TypeAdapter<PlainClass> adapter = factory.create(new Gson(), TypeToken.get(PlainClass.class));
    assertNull(adapter);
  }

  public void testCreate_withTypeAdapterValue_readsAndWrites() throws IOException {
    JsonAdapterAnnotationTypeAdapterFactory factory = newFactory();
    TypeAdapter<Point> adapter = factory.create(new Gson(), TypeToken.get(Point.class));
    assertNotNull(adapter);

    Point point = new Point();
    point.x = 3;
    point.y = 4;
    assertEquals("\"3,4\"", adapter.toJson(point));

    Point read = adapter.fromJson(new StringReader("\"5,6\""));
    assertEquals(5, read.x);
    assertEquals(6, read.y);
  }

  public void testCreate_withTypeAdapterValue_isNullSafe() throws IOException {
    JsonAdapterAnnotationTypeAdapterFactory factory = newFactory();
    TypeAdapter<Point> adapter = factory.create(new Gson(), TypeToken.get(Point.class));

    assertEquals("null", adapter.toJson(null));
    Point read = adapter.fromJson(new StringReader("null"));
    assertNull(read);
  }

  public void testCreate_withTypeAdapterValue_newInstanceEachCall() {
    JsonAdapterAnnotationTypeAdapterFactory factory = newFactory();
    pointAdapterInstanceCount = 0;
    factory.create(new Gson(), TypeToken.get(Point.class));
    factory.create(new Gson(), TypeToken.get(Point.class));
    assertEquals(2, pointAdapterInstanceCount);
  }

  public void testCreate_withTypeAdapterFactoryValue_delegatesToFactory() throws IOException {
    JsonAdapterAnnotationTypeAdapterFactory factory = newFactory();
    Gson gson = new Gson();
    TypeToken<Color> typeToken = TypeToken.get(Color.class);
    ColorTypeAdapterFactory.lastGson = null;
    ColorTypeAdapterFactory.lastTypeToken = null;

    TypeAdapter<Color> adapter = factory.create(gson, typeToken);
    assertNotNull(adapter);
    assertSame(gson, ColorTypeAdapterFactory.lastGson);
    assertEquals(typeToken, ColorTypeAdapterFactory.lastTypeToken);

    Color color = new Color();
    color.name = "red";
    assertEquals("\"red\"", adapter.toJson(color));
  }

  public void testCreate_withTypeAdapterFactoryValue_isNullSafe() throws IOException {
    JsonAdapterAnnotationTypeAdapterFactory factory = newFactory();
    TypeAdapter<Color> adapter = factory.create(new Gson(), TypeToken.get(Color.class));

    assertEquals("null", adapter.toJson(null));
    Color read = adapter.fromJson(new StringReader("null"));
    assertNull(read);
  }

  public void testCreate_invalidAnnotationValue_throwsIllegalArgumentException() {
    JsonAdapterAnnotationTypeAdapterFactory factory = newFactory();
    try {
      factory.create(new Gson(), TypeToken.get(BadlyAnnotated.class));
      fail("Expected IllegalArgumentException");
    } catch (IllegalArgumentException expected) {
    }
  }

  public void testGetTypeAdapter_withTypeAdapterValue_wrapsNullSafe() {
    ConstructorConstructor constructorConstructor =
        new ConstructorConstructor(Collections.<Type, InstanceCreator<?>>emptyMap());
    JsonAdapter annotation = Point.class.getAnnotation(JsonAdapter.class);
    TypeAdapter<?> adapter = JsonAdapterAnnotationTypeAdapterFactory.getTypeAdapter(
        constructorConstructor, new Gson(), TypeToken.get(Point.class), annotation);
    assertNotNull(adapter);
    assertFalse(adapter instanceof PointTypeAdapter);
  }

  public void testGetTypeAdapter_invalidValue_throwsIllegalArgumentException() {
    ConstructorConstructor constructorConstructor =
        new ConstructorConstructor(Collections.<Type, InstanceCreator<?>>emptyMap());
    JsonAdapter annotation = BadlyAnnotated.class.getAnnotation(JsonAdapter.class);
    try {
      JsonAdapterAnnotationTypeAdapterFactory.getTypeAdapter(
          constructorConstructor, new Gson(), TypeToken.get(BadlyAnnotated.class), annotation);
      fail("Expected IllegalArgumentException");
    } catch (IllegalArgumentException expected) {
    }
  }
}
