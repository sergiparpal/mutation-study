/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.cli2.commandline;

import java.util.ArrayList;
import java.util.List;

import junit.framework.TestCase;

import org.apache.commons.cli2.Argument;
import org.apache.commons.cli2.Option;
import org.apache.commons.cli2.builder.ArgumentBuilder;
import org.apache.commons.cli2.builder.DefaultOptionBuilder;
import org.apache.commons.cli2.option.PropertyOption;

public class WriteableCommandLineImplAgentTest extends TestCase {

    private Option root;
    private Option optionA;
    private Option optionB;
    private Argument argument;

    public void setUp() throws Exception {
        super.setUp();
        root = new DefaultOptionBuilder().withShortName("r").withLongName("root").create();
        optionA = new DefaultOptionBuilder().withShortName("a").withLongName("alpha").create();
        optionB = new DefaultOptionBuilder().withShortName("b").withLongName("beta").create();
        argument = new ArgumentBuilder().withName("arg").create();
    }

    private WriteableCommandLineImpl create(List args) {
        return new WriteableCommandLineImpl(root, args);
    }

    public void testConstructorCapturesPrefixesFromRoot() {
        final WriteableCommandLineImpl cl = create(new ArrayList());
        assertTrue(cl.looksLikeOption("-x"));
        assertTrue(cl.looksLikeOption("--xyz"));
        assertFalse(cl.looksLikeOption("xyz"));
        assertFalse(cl.looksLikeOption(""));
    }

    public void testGetNormalisedReturnsSuppliedArguments() {
        final List args = new ArrayList();
        args.add("foo");
        args.add("bar");
        final WriteableCommandLineImpl cl = create(args);
        assertEquals(args, cl.getNormalised());
    }

    public void testGetNormalisedIsUnmodifiable() {
        final WriteableCommandLineImpl cl = create(new ArrayList());
        try {
            cl.getNormalised().add("x");
            fail("expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
    }

    public void testAddOptionAndHasOption() {
        final WriteableCommandLineImpl cl = create(new ArrayList());
        assertFalse(cl.hasOption(optionA));
        cl.addOption(optionA);
        assertTrue(cl.hasOption(optionA));
        assertFalse(cl.hasOption(optionB));
    }

    public void testGetOptionByTrigger() {
        final WriteableCommandLineImpl cl = create(new ArrayList());
        cl.addOption(optionA);
        assertSame(optionA, cl.getOption("-a"));
        assertSame(optionA, cl.getOption("--alpha"));
        assertNull(cl.getOption("--unknown"));
    }

    public void testGetOptionsReturnsAddedOptionsInOrderAndIsUnmodifiable() {
        final WriteableCommandLineImpl cl = create(new ArrayList());
        cl.addOption(optionA);
        cl.addOption(optionB);
        final List options = cl.getOptions();
        assertEquals(2, options.size());
        assertSame(optionA, options.get(0));
        assertSame(optionB, options.get(1));
        try {
            options.add(optionA);
            fail("expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
    }

    public void testGetOptionTriggersIsUnmodifiable() {
        final WriteableCommandLineImpl cl = create(new ArrayList());
        cl.addOption(optionA);
        assertTrue(cl.getOptionTriggers().contains("-a"));
        assertTrue(cl.getOptionTriggers().contains("--alpha"));
        try {
            cl.getOptionTriggers().add("--bogus");
            fail("expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
    }

    public void testAddValueForNonArgumentDoesNotForceOptionPresent() {
        final WriteableCommandLineImpl cl = create(new ArrayList());
        assertFalse(cl.hasOption(optionA));
        cl.addValue(optionA, "value1");
        assertFalse(cl.hasOption(optionA));
        assertEquals(1, cl.getValues(optionA, null).size());
        assertEquals("value1", cl.getValues(optionA, null).get(0));
    }

    public void testAddValueForArgumentForcesOptionPresent() {
        final WriteableCommandLineImpl cl = create(new ArrayList());
        assertFalse(cl.hasOption(argument));
        cl.addValue(argument, "value1");
        assertTrue(cl.hasOption(argument));
    }

    public void testAddValueAccumulatesMultipleValues() {
        final WriteableCommandLineImpl cl = create(new ArrayList());
        cl.addValue(optionA, "v1");
        cl.addValue(optionA, "v2");
        final List values = cl.getValues(optionA, null);
        assertEquals(2, values.size());
        assertEquals("v1", values.get(0));
        assertEquals("v2", values.get(1));
    }

    public void testGetValuesWithNoValuesAndNoDefaultsReturnsEmptyList() {
        final WriteableCommandLineImpl cl = create(new ArrayList());
        final List values = cl.getValues(optionA, null);
        assertNotNull(values);
        assertTrue(values.isEmpty());
    }

    public void testGetValuesWithNoActualValuesUsesSuppliedDefaults() {
        final WriteableCommandLineImpl cl = create(new ArrayList());
        final List defaults = new ArrayList();
        defaults.add("d1");
        defaults.add("d2");
        final List values = cl.getValues(optionA, defaults);
        assertEquals(defaults, values);
    }

    public void testGetValuesWithNoSuppliedDefaultsFallsBackToInstanceDefaults() {
        final WriteableCommandLineImpl cl = create(new ArrayList());
        final List instanceDefaults = new ArrayList();
        instanceDefaults.add("id1");
        cl.setDefaultValues(optionA, instanceDefaults);

        final List values = cl.getValues(optionA, null);
        assertEquals(instanceDefaults, values);

        final List valuesWithEmptyParam = cl.getValues(optionA, new ArrayList());
        assertEquals(instanceDefaults, valuesWithEmptyParam);
    }

    public void testGetValuesAugmentsShorterActualListWithExtraDefaults() {
        final WriteableCommandLineImpl cl = create(new ArrayList());
        cl.addValue(optionA, "a");
        cl.addValue(optionA, "b");

        final List defaults = new ArrayList();
        defaults.add("x");
        defaults.add("y");
        defaults.add("z");

        final List values = cl.getValues(optionA, defaults);
        assertEquals(3, values.size());
        assertEquals("a", values.get(0));
        assertEquals("b", values.get(1));
        assertEquals("z", values.get(2));
    }

    public void testGetValuesDoesNotAugmentWhenActualListIsLongerOrEqual() {
        final WriteableCommandLineImpl cl = create(new ArrayList());
        cl.addValue(optionA, "a");
        cl.addValue(optionA, "b");
        cl.addValue(optionA, "c");

        final List defaults = new ArrayList();
        defaults.add("x");
        defaults.add("y");

        final List values = cl.getValues(optionA, defaults);
        assertEquals(3, values.size());
        assertEquals("a", values.get(0));
        assertEquals("b", values.get(1));
        assertEquals("c", values.get(2));
    }

    public void testSetDefaultValuesNullRemovesDefaults() {
        final WriteableCommandLineImpl cl = create(new ArrayList());
        final List instanceDefaults = new ArrayList();
        instanceDefaults.add("id1");
        cl.setDefaultValues(optionA, instanceDefaults);
        assertFalse(cl.getValues(optionA, null).isEmpty());

        cl.setDefaultValues(optionA, null);
        assertTrue(cl.getValues(optionA, null).isEmpty());
    }

    public void testGetUndefaultedValuesIgnoresInstanceDefaults() {
        final WriteableCommandLineImpl cl = create(new ArrayList());
        final List instanceDefaults = new ArrayList();
        instanceDefaults.add("id1");
        cl.setDefaultValues(optionA, instanceDefaults);

        assertTrue(cl.getUndefaultedValues(optionA).isEmpty());

        cl.addValue(optionA, "actual");
        final List undefaulted = cl.getUndefaultedValues(optionA);
        assertEquals(1, undefaulted.size());
        assertEquals("actual", undefaulted.get(0));
    }

    public void testAddSwitchSetsValueAndMarksOptionPresent() {
        final WriteableCommandLineImpl cl = create(new ArrayList());
        assertFalse(cl.hasOption(optionA));
        cl.addSwitch(optionA, true);
        assertTrue(cl.hasOption(optionA));
        assertEquals(Boolean.TRUE, cl.getSwitch(optionA, null));
    }

    public void testAddSwitchFalseValue() {
        final WriteableCommandLineImpl cl = create(new ArrayList());
        cl.addSwitch(optionA, false);
        assertEquals(Boolean.FALSE, cl.getSwitch(optionA, null));
    }

    public void testAddSwitchTwiceThrowsIllegalStateException() {
        final WriteableCommandLineImpl cl = create(new ArrayList());
        cl.addSwitch(optionA, true);
        try {
            cl.addSwitch(optionA, false);
            fail("expected IllegalStateException");
        } catch (IllegalStateException expected) {
            // expected
        }
    }

    public void testGetSwitchWithNoValueAndNoDefaultsReturnsNull() {
        final WriteableCommandLineImpl cl = create(new ArrayList());
        assertNull(cl.getSwitch(optionA, null));
    }

    public void testGetSwitchFallsBackToInstanceDefaultSwitch() {
        final WriteableCommandLineImpl cl = create(new ArrayList());
        cl.setDefaultSwitch(optionA, Boolean.TRUE);
        assertEquals(Boolean.TRUE, cl.getSwitch(optionA, null));
    }

    public void testGetSwitchParamDefaultTakesPrecedenceOverInstanceDefault() {
        final WriteableCommandLineImpl cl = create(new ArrayList());
        cl.setDefaultSwitch(optionA, Boolean.TRUE);
        assertEquals(Boolean.FALSE, cl.getSwitch(optionA, Boolean.FALSE));
    }

    public void testGetSwitchActualValueTakesPrecedenceOverBothDefaults() {
        final WriteableCommandLineImpl cl = create(new ArrayList());
        cl.setDefaultSwitch(optionA, Boolean.FALSE);
        cl.addSwitch(optionA, true);
        assertEquals(Boolean.TRUE, cl.getSwitch(optionA, Boolean.FALSE));
    }

    public void testSetDefaultSwitchNullRemovesDefault() {
        final WriteableCommandLineImpl cl = create(new ArrayList());
        cl.setDefaultSwitch(optionA, Boolean.TRUE);
        assertEquals(Boolean.TRUE, cl.getSwitch(optionA, null));

        cl.setDefaultSwitch(optionA, null);
        assertNull(cl.getSwitch(optionA, null));
    }

    public void testAddAndGetPropertyOnOption() {
        final WriteableCommandLineImpl cl = create(new ArrayList());
        final PropertyOption propertyOption = new PropertyOption();

        assertNull(cl.getProperty(propertyOption, "missing", null));
        assertEquals("fallback", cl.getProperty(propertyOption, "missing", "fallback"));

        cl.addProperty(propertyOption, "key", "value");
        assertEquals("value", cl.getProperty(propertyOption, "key", "fallback"));
    }

    public void testAddAndGetPropertyUsingStringConvenienceMethods() {
        final WriteableCommandLineImpl cl = create(new ArrayList());
        assertNull(cl.getProperty("missing"));

        cl.addProperty("key", "value");
        assertEquals("value", cl.getProperty("key"));
    }

    public void testGetPropertiesForOptionWithNoProperties() {
        final WriteableCommandLineImpl cl = create(new ArrayList());
        assertTrue(cl.getProperties(new PropertyOption()).isEmpty());
    }

    public void testGetPropertiesForOptionReturnsKeySet() {
        final WriteableCommandLineImpl cl = create(new ArrayList());
        final PropertyOption propertyOption = new PropertyOption();
        cl.addProperty(propertyOption, "key1", "value1");
        cl.addProperty(propertyOption, "key2", "value2");

        final java.util.Set keys = cl.getProperties(propertyOption);
        assertEquals(2, keys.size());
        assertTrue(keys.contains("key1"));
        assertTrue(keys.contains("key2"));
    }

    public void testGetPropertiesWithoutOptionUsesDefaultPropertyOption() {
        final WriteableCommandLineImpl cl = create(new ArrayList());
        cl.addProperty("key", "value");
        assertTrue(cl.getProperties().contains("key"));
    }

    public void testToStringQuotesArgumentsContainingSpaces() {
        final List args = new ArrayList();
        args.add("--name");
        args.add("has space");
        final WriteableCommandLineImpl cl = create(args);
        assertEquals("--name \"has space\"", cl.toString());
    }

    public void testToStringWithEmptyArgumentsIsEmptyString() {
        final WriteableCommandLineImpl cl = create(new ArrayList());
        assertEquals("", cl.toString());
    }

    public void testToStringWithNoSpacesIsUnquoted() {
        final List args = new ArrayList();
        args.add("-a");
        args.add("value");
        final WriteableCommandLineImpl cl = create(args);
        assertEquals("-a value", cl.toString());
    }
}
