/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.csv;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.io.StringWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;

/**
 * Self-contained tests for {@link CSVPrinter}.
 */
public class CSVPrinterAgentTest {

    private final String crlf = CSVFormat.DEFAULT.getRecordSeparator();

    /**
     * An Appendable that is both Closeable and Flushable, used to verify
     * that CSVPrinter#close() and #flush() actually delegate to the target.
     */
    private static class TrackingAppendable implements Appendable, java.io.Closeable, java.io.Flushable {
        private final StringBuilder sb = new StringBuilder();
        private boolean closed = false;
        private boolean flushed = false;

        public Appendable append(final CharSequence csq) throws IOException {
            sb.append(csq);
            return this;
        }

        public Appendable append(final CharSequence csq, final int start, final int end) throws IOException {
            sb.append(csq, start, end);
            return this;
        }

        public Appendable append(final char c) throws IOException {
            sb.append(c);
            return this;
        }

        public void close() throws IOException {
            closed = true;
        }

        public void flush() throws IOException {
            flushed = true;
        }

        public String toString() {
            return sb.toString();
        }
    }

    /**
     * A plain Appendable that is neither Closeable nor Flushable.
     */
    private static class PlainAppendable implements Appendable {
        private final StringBuilder sb = new StringBuilder();

        public Appendable append(final CharSequence csq) throws IOException {
            sb.append(csq);
            return this;
        }

        public Appendable append(final CharSequence csq, final int start, final int end) throws IOException {
            sb.append(csq, start, end);
            return this;
        }

        public Appendable append(final char c) throws IOException {
            sb.append(c);
            return this;
        }

        public String toString() {
            return sb.toString();
        }
    }

    // ===================== constructor =====================

    @Test
    public void testConstructorNullOutThrowsIllegalArgumentException() {
        try {
            new CSVPrinter(null, CSVFormat.DEFAULT);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testConstructorNullFormatThrowsIllegalArgumentException() {
        try {
            new CSVPrinter(new StringWriter(), null);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testConstructorInconsistentFormatThrowsIllegalArgumentExceptionPerJavadoc() {
        // Javadoc on the constructor documents IllegalArgumentException
        // "if the parameters of the format are inconsistent".
        final CSVFormat inconsistent = CSVFormat.DEFAULT.withQuoteChar(',');
        try {
            new CSVPrinter(new StringWriter(), inconsistent);
            fail("Expected IllegalArgumentException per CSVPrinter constructor javadoc");
        } catch (final IllegalArgumentException e) {
            // expected per javadoc
        }
    }

    @Test
    public void testConstructorQuoteNoneWithoutEscapeThrowsIllegalArgumentExceptionPerJavadoc() {
        final CSVFormat noQuoteNoEscape = CSVFormat.DEFAULT.withQuotePolicy(Quote.NONE);
        try {
            new CSVPrinter(new StringWriter(), noQuoteNoEscape);
            fail("Expected IllegalArgumentException per CSVPrinter constructor javadoc");
        } catch (final IllegalArgumentException e) {
            // expected per javadoc
        }
    }

    @Test
    public void testGetOutReturnsSameInstancePassedToConstructor() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        assertSame(sw, printer.getOut());
        printer.close();
    }

    // ===================== print / printRecord =====================

    @Test
    public void testPrintNullValueDefaultsToEmptyString() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecord((Object) null, "b");
        // null is treated as empty; an empty value that is first on the line is always quoted
        assertEquals("\"\",b" + crlf, sw.toString());
        printer.close();
    }

    @Test
    public void testPrintNullValueWithCustomNullString() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT.withNullString("NULL"));
        printer.printRecord((Object) null, "b");
        assertEquals("NULL,b" + crlf, sw.toString());
        printer.close();
    }

    @Test
    public void testPrintRecordObjectVarargs() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecord("a", "b", "c");
        assertEquals("a,b,c" + crlf, sw.toString());
        printer.close();
    }

    @Test
    public void testPrintRecordIterable() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final List<String> values = new ArrayList<String>();
        values.add("a");
        values.add("b");
        printer.printRecord(values);
        assertEquals("a,b" + crlf, sw.toString());
        printer.close();
    }

    @Test
    public void testPrintObjectNumberIsNotQuotedUnderMinimal() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print(Integer.valueOf(5));
        assertEquals("5", sw.toString());
        printer.close();
    }

    // ===================== quoting: MINIMAL =====================

    @Test
    public void testEmptyFirstFieldIsQuoted() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecord("", "b");
        assertEquals("\"\",b" + crlf, sw.toString());
        printer.close();
    }

    @Test
    public void testEmptyNonFirstFieldIsNotQuoted() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecord("a", "");
        assertEquals("a," + crlf, sw.toString());
        printer.close();
    }

    @Test
    public void testFieldContainingDelimiterIsQuoted() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecord("a,b", "c");
        assertEquals("\"a,b\",c" + crlf, sw.toString());
        printer.close();
    }

    @Test
    public void testFieldContainingQuoteCharIsQuotedAndDoubled() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecord("a", "b\"c");
        assertEquals("a,\"b\"\"c\"" + crlf, sw.toString());
        printer.close();
    }

    @Test
    public void testFieldStartingWithQuoteCharIsQuotedAndDoubled() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecord("a", "\"bc");
        assertEquals("a,\"\"\"bc\"" + crlf, sw.toString());
        printer.close();
    }

    @Test
    public void testFieldContainingLineFeedIsQuoted() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecord("a", "b\nc");
        assertEquals("a,\"b\nc\"" + crlf, sw.toString());
        printer.close();
    }

    @Test
    public void testFieldWithLeadingSpaceIsQuotedWhenFirstOnLine() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecord(" a", "b");
        assertEquals("\" a\",b" + crlf, sw.toString());
        printer.close();
    }

    @Test
    public void testFieldWithTrailingSpaceIsQuotedEvenWhenNotFirst() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecord("a", "b ");
        assertEquals("a,\"b \"" + crlf, sw.toString());
        printer.close();
    }

    // ===================== quoting: ALL / NON_NUMERIC / NONE =====================

    @Test
    public void testQuoteAllPolicyQuotesEverythingIncludingNumbers() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT.withQuotePolicy(Quote.ALL));
        printer.printRecord("a", Integer.valueOf(1));
        assertEquals("\"a\",\"1\"" + crlf, sw.toString());
        printer.close();
    }

    @Test
    public void testQuoteNonNumericPolicyLeavesNumbersUnquoted() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT.withQuotePolicy(Quote.NON_NUMERIC));
        printer.printRecord("a", Integer.valueOf(1));
        assertEquals("\"a\",1" + crlf, sw.toString());
        printer.close();
    }

    @Test
    public void testQuoteNonePolicyEscapesDelimiterInsteadOfQuoting() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw,
                CSVFormat.DEFAULT.withQuotePolicy(Quote.NONE).withEscape('\\'));
        printer.printRecord("a,b", "c");
        assertEquals("a\\,b,c" + crlf, sw.toString());
        printer.close();
    }

    // ===================== escaping format (no quoting) =====================

    @Test
    public void testEscapingFormatEscapesDelimiterAndEscapeChar() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.MYSQL);
        printer.printRecord("a\tb", "c\\d");
        // MYSQL format: delimiter is TAB, escape is backslash, record sep is LF
        assertEquals("a\\\tb\tc\\\\d\n", sw.toString());
        printer.close();
    }

    @Test
    public void testEscapingFormatTranslatesLineBreaksToLiteralLetters() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.MYSQL);
        printer.print("a\nb\rc");
        assertEquals("a\\nb\\rc", sw.toString());
        printer.close();
    }

    // ===================== printRecords =====================

    @Test
    public void testPrintRecordsIterableOfArrays() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final List<String[]> rows = new ArrayList<String[]>();
        rows.add(new String[] { "a", "b" });
        rows.add(new String[] { "c", "d" });
        printer.printRecords(rows);
        assertEquals("a,b" + crlf + "c,d" + crlf, sw.toString());
        printer.close();
    }

    @Test
    public void testPrintRecordsArrayOfIterables() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        final List<String> row1 = Arrays.asList("a", "b");
        final List<String> row2 = Arrays.asList("c", "d");
        printer.printRecords(new Object[] { row1, row2 });
        assertEquals("a,b" + crlf + "c,d" + crlf, sw.toString());
        printer.close();
    }

    @Test
    public void testPrintRecordsOfPlainScalarsOneValuePerLine() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printRecords(new Object[] { "a", "b" });
        assertEquals("a" + crlf + "b" + crlf, sw.toString());
        printer.close();
    }

    @Test
    public void testPrintRecordsResultSet() throws IOException, ClassNotFoundException, SQLException {
        final StringWriter sw = new StringWriter();
        Class.forName("org.h2.Driver");
        final Connection connection = DriverManager.getConnection("jdbc:h2:mem:csvprinter_agent_test;", "sa", "");
        try {
            final Statement stmt = connection.createStatement();
            stmt.execute("CREATE TABLE AGENT_TEST(ID INT PRIMARY KEY, NAME VARCHAR(255))");
            stmt.execute("insert into AGENT_TEST values(1, 'r1')");
            stmt.execute("insert into AGENT_TEST values(2, 'r2')");
            final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
            final ResultSet rs = stmt.executeQuery("select ID, NAME from AGENT_TEST order by ID");
            printer.printRecords(rs);
            assertEquals("1,r1" + crlf + "2,r2" + crlf, sw.toString());
            printer.close();
        } finally {
            connection.close();
        }
    }

    @Test
    public void testPrintRecordsClosedResultSetThrowsSQLException() throws IOException, ClassNotFoundException, SQLException {
        final StringWriter sw = new StringWriter();
        Class.forName("org.h2.Driver");
        final Connection connection = DriverManager.getConnection("jdbc:h2:mem:csvprinter_agent_test2;", "sa", "");
        try {
            final Statement stmt = connection.createStatement();
            stmt.execute("CREATE TABLE AGENT_TEST2(ID INT PRIMARY KEY)");
            stmt.execute("insert into AGENT_TEST2 values(1)");
            final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
            final ResultSet rs = stmt.executeQuery("select ID from AGENT_TEST2");
            rs.close();
            try {
                printer.printRecords(rs);
                fail("Expected SQLException on a closed ResultSet");
            } catch (final SQLException e) {
                // expected
            }
            printer.close();
        } finally {
            connection.close();
        }
    }

    // ===================== comments =====================

    @Test
    public void testPrintCommentDoesNothingWhenCommentingDisabled() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.printComment("a comment");
        assertEquals("", sw.toString());
        printer.close();
    }

    @Test
    public void testPrintCommentSingleLine() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT.withCommentStart('#'));
        printer.printComment("a comment");
        assertEquals("# a comment" + crlf, sw.toString());
        printer.close();
    }

    @Test
    public void testPrintCommentMultiLineUsesLFBoundary() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT.withCommentStart('#'));
        printer.printComment("line1\nline2");
        assertEquals("# line1" + crlf + "# line2" + crlf, sw.toString());
        printer.close();
    }

    @Test
    public void testPrintCommentCRLFTreatedAsSingleLineBreak() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT.withCommentStart('#'));
        printer.printComment("line1\r\nline2");
        assertEquals("# line1" + crlf + "# line2" + crlf, sw.toString());
        printer.close();
    }

    @Test
    public void testPrintCommentAfterValueStartsOnNewLine() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT.withCommentStart('#'));
        printer.print("a");
        printer.printComment("comment");
        assertEquals("a" + crlf + "# comment" + crlf, sw.toString());
        printer.close();
    }

    // ===================== println =====================

    @Test
    public void testPrintlnOutputsRecordSeparatorAndResetsNewRecordFlag() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.DEFAULT);
        printer.print("a");
        printer.println();
        // newRecord should be reset: printing a value right after should not emit a leading delimiter
        printer.print("b");
        assertEquals("a" + crlf + "b", sw.toString());
        printer.close();
    }

    // ===================== close / flush =====================

    @Test
    public void testCloseClosesCloseableTarget() throws IOException {
        final TrackingAppendable target = new TrackingAppendable();
        final CSVPrinter printer = new CSVPrinter(target, CSVFormat.DEFAULT);
        printer.close();
        assertTrue(target.closed);
    }

    @Test
    public void testCloseOnNonCloseableTargetDoesNotThrow() throws IOException {
        final PlainAppendable target = new PlainAppendable();
        final CSVPrinter printer = new CSVPrinter(target, CSVFormat.DEFAULT);
        printer.print("a");
        printer.close();
        assertEquals("a", target.toString());
    }

    @Test
    public void testFlushFlushesFlushableTarget() throws IOException {
        final TrackingAppendable target = new TrackingAppendable();
        final CSVPrinter printer = new CSVPrinter(target, CSVFormat.DEFAULT);
        printer.flush();
        assertTrue(target.flushed);
    }

    @Test
    public void testFlushOnNonFlushableTargetDoesNotThrow() throws IOException {
        final PlainAppendable target = new PlainAppendable();
        final CSVPrinter printer = new CSVPrinter(target, CSVFormat.DEFAULT);
        printer.print("a");
        printer.flush();
        assertEquals("a", target.toString());
    }

    // ===================== delimiter configuration =====================

    @Test
    public void testCustomDelimiterFromTdfFormat() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = new CSVPrinter(sw, CSVFormat.TDF);
        printer.printRecord("a", "b");
        assertEquals("a\tb" + crlf, sw.toString());
        printer.close();
    }
}
