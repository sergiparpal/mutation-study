/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.csv;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.List;

import org.junit.Test;

/**
 * Self-contained tests for {@link CSVFormat}.
 */
public class CSVFormatAgentTest {

    private enum Header {
        Name, Email, Phone
    }

    /**
     * Minimal stub, only the two methods used by {@link CSVFormat#withHeader(ResultSetMetaData)} are implemented.
     */
    private static final class StubResultSetMetaData implements ResultSetMetaData {

        private final String[] labels;

        StubResultSetMetaData(final String[] labels) {
            this.labels = labels;
        }

        @Override
        public int getColumnCount() throws SQLException {
            return labels.length;
        }

        @Override
        public String getColumnLabel(final int column) throws SQLException {
            return labels[column - 1];
        }

        @Override
        public boolean isAutoIncrement(final int column) throws SQLException {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean isCaseSensitive(final int column) throws SQLException {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean isSearchable(final int column) throws SQLException {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean isCurrency(final int column) throws SQLException {
            throw new UnsupportedOperationException();
        }

        @Override
        public int isNullable(final int column) throws SQLException {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean isSigned(final int column) throws SQLException {
            throw new UnsupportedOperationException();
        }

        @Override
        public int getColumnDisplaySize(final int column) throws SQLException {
            throw new UnsupportedOperationException();
        }

        @Override
        public String getColumnName(final int column) throws SQLException {
            throw new UnsupportedOperationException();
        }

        @Override
        public String getSchemaName(final int column) throws SQLException {
            throw new UnsupportedOperationException();
        }

        @Override
        public int getPrecision(final int column) throws SQLException {
            throw new UnsupportedOperationException();
        }

        @Override
        public int getScale(final int column) throws SQLException {
            throw new UnsupportedOperationException();
        }

        @Override
        public String getTableName(final int column) throws SQLException {
            throw new UnsupportedOperationException();
        }

        @Override
        public String getCatalogName(final int column) throws SQLException {
            throw new UnsupportedOperationException();
        }

        @Override
        public int getColumnType(final int column) throws SQLException {
            throw new UnsupportedOperationException();
        }

        @Override
        public String getColumnTypeName(final int column) throws SQLException {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean isReadOnly(final int column) throws SQLException {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean isWritable(final int column) throws SQLException {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean isDefinitelyWritable(final int column) throws SQLException {
            throw new UnsupportedOperationException();
        }

        @Override
        public String getColumnClassName(final int column) throws SQLException {
            throw new UnsupportedOperationException();
        }

        @Override
        public <T> T unwrap(final Class<T> iface) throws SQLException {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean isWrapperFor(final Class<?> iface) throws SQLException {
            throw new UnsupportedOperationException();
        }
    }

    @Test
    public void testNewFormatDefaults() {
        final CSVFormat format = CSVFormat.newFormat(',');
        assertEquals(',', format.getDelimiter());
        assertNull(format.getQuoteCharacter());
        assertFalse(format.isQuoteCharacterSet());
        assertNull(format.getQuoteMode());
        assertNull(format.getCommentMarker());
        assertFalse(format.isCommentMarkerSet());
        assertNull(format.getEscapeCharacter());
        assertFalse(format.isEscapeCharacterSet());
        assertNull(format.getRecordSeparator());
        assertNull(format.getNullString());
        assertFalse(format.isNullStringSet());
        assertNull(format.getHeader());
        assertNull(format.getHeaderComments());
        assertFalse(format.getSkipHeaderRecord());
        assertFalse(format.getAllowMissingColumnNames());
        assertFalse(format.getIgnoreHeaderCase());
        assertFalse(format.getIgnoreEmptyLines());
        assertFalse(format.getIgnoreSurroundingSpaces());
        assertFalse(format.getTrailingDelimiter());
        assertFalse(format.getTrim());
        assertFalse(format.getAutoFlush());
    }

    @Test
    public void testNewFormatLineBreakDelimiterThrows() {
        try {
            CSVFormat.newFormat('\n');
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
        try {
            CSVFormat.newFormat('\r');
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testWithDelimiterLineBreakThrows() {
        try {
            CSVFormat.DEFAULT.withDelimiter('\n');
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testWithQuoteSameAsDelimiterThrows() {
        try {
            CSVFormat.newFormat(',').withQuote(',');
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testWithEscapeSameAsDelimiterThrows() {
        try {
            CSVFormat.newFormat(',').withEscape(',');
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testWithCommentMarkerSameAsDelimiterThrows() {
        try {
            CSVFormat.newFormat(',').withCommentMarker(',');
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testQuoteCharacterEqualsCommentMarkerThrows() {
        try {
            // DEFAULT uses '"' as quote character
            CSVFormat.DEFAULT.withCommentMarker('"');
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testEscapeCharacterEqualsCommentMarkerThrows() {
        try {
            CSVFormat.newFormat(',').withEscape('#').withCommentMarker('#');
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testEscapeNullAndQuoteModeNoneThrows() {
        try {
            CSVFormat.newFormat(',').withQuoteMode(QuoteMode.NONE);
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testWithHeaderDuplicateThrows() {
        try {
            CSVFormat.newFormat(',').withHeader("a", "b", "a");
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testWithCommentMarkerNullDisables() {
        final CSVFormat format = CSVFormat.DEFAULT.withCommentMarker('#').withCommentMarker((Character) null);
        assertNull(format.getCommentMarker());
        assertFalse(format.isCommentMarkerSet());
    }

    @Test
    public void testEqualsAndHashCode() {
        final CSVFormat a = CSVFormat.newFormat(',').withQuote('"');
        final CSVFormat b = CSVFormat.newFormat(',').withQuote('"');
        final CSVFormat c = CSVFormat.newFormat(';').withQuote('"');

        assertTrue(a.equals(a));
        assertTrue(a.equals(b));
        assertEquals(a.hashCode(), b.hashCode());
        assertFalse(a.equals(c));
        assertFalse(a.equals(null));
        assertFalse(a.equals("not a CSVFormat"));
    }

    @Test
    public void testFormat() {
        final String formatted = CSVFormat.DEFAULT.format("a", "b,c", "d");
        assertEquals("a,\"b,c\",d", formatted);
    }

    @Test
    public void testPrintNullWithNullStringAndQuoteModeAll() throws IOException {
        final CSVFormat plain = CSVFormat.DEFAULT.withNullString("NULL");
        final StringBuilder out = new StringBuilder();
        plain.print(null, out, true);
        assertEquals("NULL", out.toString());

        final CSVFormat quoted = plain.withQuoteMode(QuoteMode.ALL);
        final StringBuilder out2 = new StringBuilder();
        quoted.print(null, out2, true);
        assertEquals("\"NULL\"", out2.toString());
    }

    @Test
    public void testPrintNullWithoutNullString() throws IOException {
        final StringBuilder out = new StringBuilder();
        CSVFormat.DEFAULT.print(null, out, true);
        assertEquals("", out.toString());
    }

    @Test
    public void testPrintlnTrailingDelimiter() throws IOException {
        final CSVFormat withTrailing = CSVFormat.newFormat(',').withRecordSeparator('\n').withTrailingDelimiter(true);
        final StringBuilder out = new StringBuilder();
        withTrailing.println(out);
        assertEquals(",\n", out.toString());

        final CSVFormat withoutTrailing = withTrailing.withTrailingDelimiter(false);
        final StringBuilder out2 = new StringBuilder();
        withoutTrailing.println(out2);
        assertEquals("\n", out2.toString());
    }

    @Test
    public void testPrintRecord() throws IOException {
        final StringBuilder out = new StringBuilder();
        CSVFormat.DEFAULT.printRecord(out, "x", "y");
        assertEquals("x,y\r\n", out.toString());
    }

    @Test
    public void testToString() {
        final String s = CSVFormat.DEFAULT.toString();
        assertTrue(s.contains("Delimiter=<,>"));
        assertTrue(s.contains("QuoteChar=<\">"));
        assertTrue(s.contains("EmptyLines:ignored"));
        assertTrue(s.contains("SkipHeaderRecord:false"));
        assertFalse(s.contains("Escape="));
    }

    @Test
    public void testWithHeaderEnum() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader(Header.class);
        assertArrayEquals(new String[] { "Name", "Email", "Phone" }, format.getHeader());

        final CSVFormat disabled = CSVFormat.DEFAULT.withHeader((Class<? extends Enum<?>>) null);
        assertNull(disabled.getHeader());
    }

    @Test
    public void testWithHeaderResultSetMetaData() throws SQLException {
        final ResultSetMetaData metaData = new StubResultSetMetaData(new String[] { "A", "B" });
        final CSVFormat format = CSVFormat.DEFAULT.withHeader(metaData);
        assertArrayEquals(new String[] { "A", "B" }, format.getHeader());

        final CSVFormat disabled = CSVFormat.DEFAULT.withHeader((ResultSetMetaData) null);
        assertNull(disabled.getHeader());
    }

    @Test
    public void testGetHeaderReturnsIndependentCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeader("a", "b");
        final String[] first = format.getHeader();
        first[0] = "mutated";
        final String[] second = format.getHeader();
        assertEquals("a", second[0]);
    }

    @Test
    public void testGetHeaderCommentsReturnsIndependentCopy() {
        final CSVFormat format = CSVFormat.DEFAULT.withHeaderComments("c1", "c2");
        final String[] first = format.getHeaderComments();
        first[0] = "mutated";
        final String[] second = format.getHeaderComments();
        assertEquals("c1", second[0]);
    }

    @Test
    public void testWithFirstRecordAsHeader() {
        final CSVFormat format = CSVFormat.DEFAULT.withFirstRecordAsHeader();
        assertTrue(format.getSkipHeaderRecord());
        assertNotNull(format.getHeader());
        assertEquals(0, format.getHeader().length);
    }

    @Test
    public void testValueOfAndPredefined() {
        assertEquals(CSVFormat.DEFAULT, CSVFormat.valueOf("Default"));
        assertEquals(CSVFormat.EXCEL, CSVFormat.valueOf("Excel"));
        try {
            CSVFormat.valueOf("NotAFormat");
            fail("Expected IllegalArgumentException");
        } catch (final IllegalArgumentException e) {
            // expected
        }
    }

    @Test
    public void testParse() throws IOException {
        final Reader in = new StringReader("a,b\r\nc,d\r\n");
        final CSVParser parser = CSVFormat.DEFAULT.parse(in);
        try {
            final List<CSVRecord> records = parser.getRecords();
            assertEquals(2, records.size());
            assertEquals("a", records.get(0).get(0));
            assertEquals("b", records.get(0).get(1));
            assertEquals("c", records.get(1).get(0));
            assertEquals("d", records.get(1).get(1));
        } finally {
            parser.close();
        }
    }

    @Test
    public void testPrintToAppendable() throws IOException {
        final StringWriter sw = new StringWriter();
        final CSVPrinter printer = CSVFormat.DEFAULT.print(sw);
        try {
            printer.printRecord("1", "2");
        } finally {
            printer.close();
        }
        assertEquals("1,2\r\n", sw.toString());
    }

    @Test
    public void testWithAutoFlushAndTrim() {
        final CSVFormat format = CSVFormat.DEFAULT.withAutoFlush(true).withTrim(true);
        assertTrue(format.getAutoFlush());
        assertTrue(format.getTrim());
    }

    @Test
    public void testWithIgnoreHeaderCaseAndSurroundingSpacesAndAllowMissing() {
        final CSVFormat format = CSVFormat.DEFAULT.withIgnoreHeaderCase().withIgnoreSurroundingSpaces()
                .withAllowMissingColumnNames();
        assertTrue(format.getIgnoreHeaderCase());
        assertTrue(format.getIgnoreSurroundingSpaces());
        assertTrue(format.getAllowMissingColumnNames());
    }

    @Test
    public void testWithQuoteModeAndNullString() {
        final CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.ALL_NON_NULL).withNullString("N/A");
        assertEquals(QuoteMode.ALL_NON_NULL, format.getQuoteMode());
        assertEquals("N/A", format.getNullString());
        assertTrue(format.isNullStringSet());
    }

    @Test
    public void testWithRecordSeparator() {
        final CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator('\n');
        assertEquals("\n", format.getRecordSeparator());
    }

    @Test
    public void testWithSkipHeaderRecordAndTrailingDelimiter() {
        final CSVFormat format = CSVFormat.DEFAULT.withSkipHeaderRecord().withTrailingDelimiter();
        assertTrue(format.getSkipHeaderRecord());
        assertTrue(format.getTrailingDelimiter());
    }

    @Test
    public void testImmutabilityOfWithMethods() {
        final CSVFormat original = CSVFormat.DEFAULT;
        final CSVFormat changed = original.withDelimiter(';');
        assertEquals(',', original.getDelimiter());
        assertEquals(';', changed.getDelimiter());
    }
}
