/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.builder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import junit.framework.TestCase;

import org.apache.commons.lang3.SystemUtils;

/**
 * Self-contained test case for {@link ToStringStyle}.
 */
public class ToStringStyleAgentTest extends TestCase {

    public ToStringStyleAgentTest(String name) {
        super(name);
    }

    /** Trivial concrete subclass used to instantiate the abstract class. */
    private static class Style extends ToStringStyle {
    }

    //-----------------------------------------------------------------------
    // Setters / getters: null is accepted and converted to ""
    //-----------------------------------------------------------------------

    public void testSetArrayStartAcceptsNull() {
        ToStringStyle style = new Style();
        assertEquals("{", style.getArrayStart());
        style.setArrayStart(null);
        assertEquals("", style.getArrayStart());
        style.setArrayStart("<<");
        assertEquals("<<", style.getArrayStart());
    }

    public void testSetArrayEndAcceptsNull() {
        ToStringStyle style = new Style();
        assertEquals("}", style.getArrayEnd());
        style.setArrayEnd(null);
        assertEquals("", style.getArrayEnd());
    }

    public void testSetArraySeparatorAcceptsNull() {
        ToStringStyle style = new Style();
        assertEquals(",", style.getArraySeparator());
        style.setArraySeparator(null);
        assertEquals("", style.getArraySeparator());
    }

    public void testSetContentStartAcceptsNull() {
        ToStringStyle style = new Style();
        assertEquals("[", style.getContentStart());
        style.setContentStart(null);
        assertEquals("", style.getContentStart());
    }

    public void testSetContentEndAcceptsNull() {
        ToStringStyle style = new Style();
        assertEquals("]", style.getContentEnd());
        style.setContentEnd(null);
        assertEquals("", style.getContentEnd());
    }

    public void testSetFieldNameValueSeparatorAcceptsNull() {
        ToStringStyle style = new Style();
        assertEquals("=", style.getFieldNameValueSeparator());
        style.setFieldNameValueSeparator(null);
        assertEquals("", style.getFieldNameValueSeparator());
    }

    public void testSetFieldSeparatorAcceptsNull() {
        ToStringStyle style = new Style();
        assertEquals(",", style.getFieldSeparator());
        style.setFieldSeparator(null);
        assertEquals("", style.getFieldSeparator());
    }

    public void testSetNullTextAcceptsNull() {
        ToStringStyle style = new Style();
        assertEquals("<null>", style.getNullText());
        style.setNullText(null);
        assertEquals("", style.getNullText());
    }

    public void testSetSizeStartTextAcceptsNull() {
        ToStringStyle style = new Style();
        assertEquals("<size=", style.getSizeStartText());
        style.setSizeStartText(null);
        assertEquals("", style.getSizeStartText());
    }

    public void testSetSizeEndTextAcceptsNull() {
        ToStringStyle style = new Style();
        assertEquals(">", style.getSizeEndText());
        style.setSizeEndText(null);
        assertEquals("", style.getSizeEndText());
    }

    public void testSetSummaryObjectStartTextAcceptsNull() {
        ToStringStyle style = new Style();
        assertEquals("<", style.getSummaryObjectStartText());
        style.setSummaryObjectStartText(null);
        assertEquals("", style.getSummaryObjectStartText());
    }

    public void testSetSummaryObjectEndTextAcceptsNull() {
        ToStringStyle style = new Style();
        assertEquals(">", style.getSummaryObjectEndText());
        style.setSummaryObjectEndText(null);
        assertEquals("", style.getSummaryObjectEndText());
    }

    //-----------------------------------------------------------------------
    // Defaults
    //-----------------------------------------------------------------------

    public void testDefaultFlags() {
        Style style = new Style();
        assertTrue(style.isUseFieldNames());
        assertTrue(style.isUseClassName());
        assertFalse(style.isUseShortClassName());
        assertTrue(style.isUseIdentityHashCode());
        assertTrue(style.isDefaultFullDetail());
        assertTrue(style.isArrayContentDetail());
        assertFalse(style.isFieldSeparatorAtStart());
        assertFalse(style.isFieldSeparatorAtEnd());
    }

    //-----------------------------------------------------------------------
    // isFullDetail
    //-----------------------------------------------------------------------

    public void testIsFullDetailNullUsesDefault() {
        Style style = new Style();
        assertTrue(style.isFullDetail(null));
        style.setDefaultFullDetail(false);
        assertFalse(style.isFullDetail(null));
    }

    public void testIsFullDetailExplicitOverridesDefault() {
        Style style = new Style();
        style.setDefaultFullDetail(true);
        assertFalse(style.isFullDetail(Boolean.FALSE));
        style.setDefaultFullDetail(false);
        assertTrue(style.isFullDetail(Boolean.TRUE));
    }

    //-----------------------------------------------------------------------
    // appendFieldStart / appendFieldEnd / appendFieldSeparator
    //-----------------------------------------------------------------------

    public void testAppendFieldStartWithFieldName() {
        Style style = new Style();
        StringBuffer buffer = new StringBuffer();
        style.appendFieldStart(buffer, "name");
        assertEquals("name=", buffer.toString());
    }

    public void testAppendFieldStartWithNullFieldNameAppendsNothing() {
        Style style = new Style();
        StringBuffer buffer = new StringBuffer();
        style.appendFieldStart(buffer, null);
        assertEquals("", buffer.toString());
    }

    public void testAppendFieldStartWithUseFieldNamesFalseAppendsNothing() {
        Style style = new Style();
        style.setUseFieldNames(false);
        StringBuffer buffer = new StringBuffer();
        style.appendFieldStart(buffer, "name");
        assertEquals("", buffer.toString());
    }

    public void testAppendFieldEndAlwaysAppendsSeparator() {
        Style style = new Style();
        StringBuffer buffer = new StringBuffer("x");
        style.appendFieldEnd(buffer, null);
        assertEquals("x,", buffer.toString());
    }

    public void testAppendFieldSeparator() {
        Style style = new Style();
        style.setFieldSeparator(" | ");
        StringBuffer buffer = new StringBuffer("a");
        style.appendFieldSeparator(buffer);
        assertEquals("a | ", buffer.toString());
    }

    //-----------------------------------------------------------------------
    // appendNullText
    //-----------------------------------------------------------------------

    public void testAppendNullText() {
        Style style = new Style();
        StringBuffer buffer = new StringBuffer();
        style.appendNullText(buffer, "field");
        assertEquals("<null>", buffer.toString());
    }

    //-----------------------------------------------------------------------
    // removeLastFieldSeparator
    //-----------------------------------------------------------------------

    public void testRemoveLastFieldSeparatorMatching() {
        Style style = new Style();
        StringBuffer buffer = new StringBuffer("abc,");
        style.removeLastFieldSeparator(buffer);
        assertEquals("abc", buffer.toString());
    }

    public void testRemoveLastFieldSeparatorNotMatching() {
        Style style = new Style();
        StringBuffer buffer = new StringBuffer("abcd");
        style.removeLastFieldSeparator(buffer);
        assertEquals("abcd", buffer.toString());
    }

    public void testRemoveLastFieldSeparatorEmptyBuffer() {
        Style style = new Style();
        StringBuffer buffer = new StringBuffer();
        style.removeLastFieldSeparator(buffer);
        assertEquals("", buffer.toString());
    }

    public void testRemoveLastFieldSeparatorEmptySeparatorIsNoop() {
        Style style = new Style();
        style.setFieldSeparator("");
        StringBuffer buffer = new StringBuffer("abc");
        style.removeLastFieldSeparator(buffer);
        assertEquals("abc", buffer.toString());
    }

    public void testRemoveLastFieldSeparatorBufferShorterThanSeparator() {
        Style style = new Style();
        style.setFieldSeparator("###");
        StringBuffer buffer = new StringBuffer("#");
        style.removeLastFieldSeparator(buffer);
        assertEquals("#", buffer.toString());
    }

    //-----------------------------------------------------------------------
    // appendSummarySize / appendSummary / appendDetail
    //-----------------------------------------------------------------------

    public void testAppendSummarySize() {
        Style style = new Style();
        StringBuffer buffer = new StringBuffer();
        style.appendSummarySize(buffer, "field", 5);
        assertEquals("<size=5>", buffer.toString());
    }

    public void testAppendSummaryObject() {
        Style style = new Style();
        StringBuffer buffer = new StringBuffer();
        style.appendSummary(buffer, "field", "hello");
        assertEquals("<String>", buffer.toString());
    }

    public void testAppendDetailObject() {
        Style style = new Style();
        StringBuffer buffer = new StringBuffer();
        style.appendDetail(buffer, "field", Integer.valueOf(42));
        assertEquals("42", buffer.toString());
    }

    public void testAppendDetailCollection() {
        Style style = new Style();
        StringBuffer buffer = new StringBuffer();
        List list = new ArrayList();
        list.add("a");
        list.add("b");
        style.appendDetail(buffer, "field", (java.util.Collection) list);
        assertEquals(list.toString(), buffer.toString());
    }

    public void testAppendDetailMap() {
        Style style = new Style();
        StringBuffer buffer = new StringBuffer();
        Map map = new HashMap();
        map.put("k", "v");
        style.appendDetail(buffer, "field", (Map) map);
        assertEquals(map.toString(), buffer.toString());
    }

    //-----------------------------------------------------------------------
    // getShortClassName
    //-----------------------------------------------------------------------

    public void testGetShortClassName() {
        Style style = new Style();
        assertEquals("String", style.getShortClassName(String.class));
        assertEquals("Integer", style.getShortClassName(Integer.class));
    }

    //-----------------------------------------------------------------------
    // append(..., Object, Boolean)
    //-----------------------------------------------------------------------

    public void testAppendObjectNullValue() {
        Style style = new Style();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "foo", (Object) null, Boolean.TRUE);
        assertEquals("foo=<null>,", buffer.toString());
    }

    public void testAppendObjectFullDetailTrue() {
        Style style = new Style();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "foo", "bar", Boolean.TRUE);
        assertEquals("foo=bar,", buffer.toString());
    }

    public void testAppendObjectFullDetailFalse() {
        Style style = new Style();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "foo", "bar", Boolean.FALSE);
        assertEquals("foo=<String>,", buffer.toString());
    }

    //-----------------------------------------------------------------------
    // append(..., primitive)
    //-----------------------------------------------------------------------

    public void testAppendPrimitives() {
        Style style = new Style();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "l", 1L);
        style.append(buffer, "i", 2);
        style.append(buffer, "s", (short) 3);
        style.append(buffer, "b", (byte) 4);
        style.append(buffer, "c", 'x');
        style.append(buffer, "d", 5.5d);
        style.append(buffer, "f", 6.5f);
        style.append(buffer, "bool", true);
        assertEquals("l=1,i=2,s=3,b=4,c=x,d=5.5,f=6.5,bool=true,", buffer.toString());
    }

    //-----------------------------------------------------------------------
    // append(..., Object[], Boolean)
    //-----------------------------------------------------------------------

    public void testAppendObjectArrayNull() {
        Style style = new Style();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", (Object[]) null, Boolean.TRUE);
        assertEquals("arr=<null>,", buffer.toString());
    }

    public void testAppendObjectArrayDetail() {
        Style style = new Style();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", new Object[] {"a", "b"}, Boolean.TRUE);
        assertEquals("arr={a,b},", buffer.toString());
    }

    public void testAppendObjectArraySummary() {
        Style style = new Style();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", new Object[] {"a", "b", "c"}, Boolean.FALSE);
        assertEquals("arr=<size=3>,", buffer.toString());
    }

    public void testAppendObjectArrayWithNullElement() {
        Style style = new Style();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", new Object[] {"a", null}, Boolean.TRUE);
        assertEquals("arr={a,<null>},", buffer.toString());
    }

    public void testAppendObjectArrayDetailFalseContentDetailSummarizesElements() {
        Style style = new Style();
        style.setArrayContentDetail(false);
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", new Object[] {"a", "b"}, Boolean.TRUE);
        assertEquals("arr={<String>,<String>},", buffer.toString());
    }

    public void testAppendIntArrayDetailAndSummary() {
        Style style = new Style();
        StringBuffer bufferDetail = new StringBuffer();
        style.append(bufferDetail, "arr", new int[] {1, 2, 3}, Boolean.TRUE);
        assertEquals("arr={1,2,3},", bufferDetail.toString());

        StringBuffer bufferSummary = new StringBuffer();
        style.append(bufferSummary, "arr", new int[] {1, 2, 3}, Boolean.FALSE);
        assertEquals("arr=<size=3>,", bufferSummary.toString());
    }

    public void testAppendIntArrayNull() {
        Style style = new Style();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", (int[]) null, Boolean.TRUE);
        assertEquals("arr=<null>,", buffer.toString());
    }

    public void testAppendBooleanArrayDetail() {
        Style style = new Style();
        StringBuffer buffer = new StringBuffer();
        style.append(buffer, "arr", new boolean[] {true, false}, Boolean.TRUE);
        assertEquals("arr={true,false},", buffer.toString());
    }

    //-----------------------------------------------------------------------
    // appendInternal cycle detection
    //-----------------------------------------------------------------------

    public void testAppendInternalDetectsSelfReferencingArray() {
        Style style = new Style();
        StringBuffer buffer = new StringBuffer();
        Object[] arr = new Object[1];
        arr[0] = arr;
        style.appendInternal(buffer, "arr", arr, true);
        String expectedInner = arr.getClass().getName() + "@" + Integer.toHexString(System.identityHashCode(arr));
        assertEquals("{" + expectedInner + "}", buffer.toString());
    }

    //-----------------------------------------------------------------------
    // registry (package-private statics)
    //-----------------------------------------------------------------------

    public void testRegistryRegisterIsRegisteredUnregister() {
        Object value = new Object();
        assertFalse(ToStringStyle.isRegistered(value));
        ToStringStyle.register(value);
        assertTrue(ToStringStyle.isRegistered(value));
        ToStringStyle.unregister(value);
        assertFalse(ToStringStyle.isRegistered(value));
    }

    public void testRegistryNullIsNoop() {
        ToStringStyle.register(null);
        ToStringStyle.unregister(null);
        assertFalse(ToStringStyle.isRegistered(null));
    }

    //-----------------------------------------------------------------------
    // appendStart / appendEnd
    //-----------------------------------------------------------------------

    public void testAppendStartWithNullObjectAppendsNothing() {
        Style style = new Style();
        StringBuffer buffer = new StringBuffer();
        style.appendStart(buffer, null);
        assertEquals("", buffer.toString());
    }

    public void testAppendEndWithNullObjectIsConsistentWithAppendStart() {
        Style style = new Style();
        StringBuffer buffer = new StringBuffer();
        style.appendEnd(buffer, null);
        assertEquals("", buffer.toString());
    }

    public void testAppendStartAndEndRemoveTrailingSeparator() {
        Style style = new Style();
        StringBuffer buffer = new StringBuffer();
        Object obj = new Object();
        style.appendStart(buffer, obj);
        style.append(buffer, "a", 1);
        style.append(buffer, "b", 2);
        style.appendEnd(buffer, obj);
        String expected = obj.getClass().getName()
                + "@" + Integer.toHexString(System.identityHashCode(obj))
                + "[a=1,b=2]";
        assertEquals(expected, buffer.toString());
    }

    //-----------------------------------------------------------------------
    // appendToString / appendSuper
    //-----------------------------------------------------------------------

    public void testAppendToStringNullIsIgnored() {
        Style style = new Style();
        StringBuffer buffer = new StringBuffer("existing");
        style.appendToString(buffer, null);
        assertEquals("existing", buffer.toString());
    }

    public void testAppendToStringWithoutBracketsIsIgnored() {
        Style style = new Style();
        StringBuffer buffer = new StringBuffer();
        style.appendToString(buffer, "no brackets here");
        assertEquals("", buffer.toString());
    }

    public void testAppendToStringWithEmptyContentIsIgnored() {
        Style style = new Style();
        StringBuffer buffer = new StringBuffer();
        style.appendToString(buffer, "Foo[]");
        assertEquals("", buffer.toString());
    }

    public void testAppendSuperExtractsInnerContent() {
        Style style = new Style();
        StringBuffer buffer = new StringBuffer();
        style.appendSuper(buffer, "Foo[a=1,b=2]");
        assertEquals("a=1,b=2,", buffer.toString());
    }

    //-----------------------------------------------------------------------
    // Predefined styles produce the documented output
    //-----------------------------------------------------------------------

    private StringBuffer buildFixtureToString(ToStringStyle style, AgentFixturePerson fixture) {
        StringBuffer buffer = new StringBuffer();
        style.appendStart(buffer, fixture);
        style.append(buffer, "name", fixture.name, null);
        style.append(buffer, "age", fixture.age);
        style.append(buffer, "smoker", fixture.smoker);
        style.appendEnd(buffer, fixture);
        return buffer;
    }

    public void testDefaultStyleOutput() {
        AgentFixturePerson p = new AgentFixturePerson("John Doe", 33, false);
        StringBuffer buffer = buildFixtureToString(ToStringStyle.DEFAULT_STYLE, p);
        String expected = p.getClass().getName()
                + "@" + Integer.toHexString(System.identityHashCode(p))
                + "[name=John Doe,age=33,smoker=false]";
        assertEquals(expected, buffer.toString());
    }

    public void testNoFieldNamesStyleOutput() {
        AgentFixturePerson p = new AgentFixturePerson("John Doe", 33, false);
        StringBuffer buffer = buildFixtureToString(ToStringStyle.NO_FIELD_NAMES_STYLE, p);
        String expected = p.getClass().getName()
                + "@" + Integer.toHexString(System.identityHashCode(p))
                + "[John Doe,33,false]";
        assertEquals(expected, buffer.toString());
    }

    public void testShortPrefixStyleOutput() {
        AgentFixturePerson p = new AgentFixturePerson("John Doe", 33, false);
        StringBuffer buffer = buildFixtureToString(ToStringStyle.SHORT_PREFIX_STYLE, p);
        String expected = "AgentFixturePerson[name=John Doe,age=33,smoker=false]";
        assertEquals(expected, buffer.toString());
    }

    public void testSimpleStyleOutput() {
        AgentFixturePerson p = new AgentFixturePerson("John Doe", 33, false);
        StringBuffer buffer = buildFixtureToString(ToStringStyle.SIMPLE_STYLE, p);
        assertEquals("John Doe,33,false", buffer.toString());
    }

    public void testMultiLineStyleOutput() {
        AgentFixturePerson p = new AgentFixturePerson("John Doe", 33, false);
        StringBuffer buffer = buildFixtureToString(ToStringStyle.MULTI_LINE_STYLE, p);
        String sep = SystemUtils.LINE_SEPARATOR;
        String expected = p.getClass().getName()
                + "@" + Integer.toHexString(System.identityHashCode(p))
                + "[" + sep + "  name=John Doe" + sep + "  age=33" + sep + "  smoker=false" + sep + "]";
        assertEquals(expected, buffer.toString());
    }
}

/**
 * Fixture used by {@link ToStringStyleAgentTest}. Declared top-level (and
 * package-private) in this file so that its short class name does not
 * include an enclosing class prefix.
 */
class AgentFixturePerson {
    String name;
    int age;
    boolean smoker;

    AgentFixturePerson(String name, int age, boolean smoker) {
        this.name = name;
        this.age = age;
        this.smoker = smoker;
    }
}
