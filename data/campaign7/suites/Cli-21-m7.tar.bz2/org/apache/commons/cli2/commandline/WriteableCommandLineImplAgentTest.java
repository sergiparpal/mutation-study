/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.cli2.commandline;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import junit.framework.TestCase;

import org.apache.commons.cli2.Group;
import org.apache.commons.cli2.Option;
import org.apache.commons.cli2.WriteableCommandLine;
import org.apache.commons.cli2.builder.DefaultOptionBuilder;
import org.apache.commons.cli2.option.Command;
import org.apache.commons.cli2.option.GroupImpl;

public class WriteableCommandLineImplAgentTest extends TestCase {

    private static Option plainOption(final String name) {
        return new Command(name, "desc of " + name, null, false, null, null, 0);
    }

    public void testConstructorSetsCurrentOptionToRoot() {
        final Option root = plainOption("root");
        final WriteableCommandLineImpl cl = new WriteableCommandLineImpl(root, new ArrayList());

        assertEquals(root, cl.getCurrentOption());
    }

    public void testAddOptionAlsoAddsAncestorOptions() {
        final List childOptions = new ArrayList();
        final Option grandchild = plainOption("grandchild");
        childOptions.add(grandchild);

        final Group childGroup =
            new GroupImpl(childOptions, "child-group", "desc", 0, Integer.MAX_VALUE, false);

        final List rootOptions = new ArrayList();
        rootOptions.add(childGroup);
        final Group root = new GroupImpl(rootOptions, "root-group", "desc", 0, Integer.MAX_VALUE, false);

        final WriteableCommandLineImpl cl = new WriteableCommandLineImpl(root, new ArrayList());

        assertFalse(cl.hasOption(grandchild));
        assertFalse(cl.hasOption(childGroup));

        cl.addOption(grandchild);

        assertTrue(cl.hasOption(grandchild));
        assertTrue("parent group should be added automatically", cl.hasOption(childGroup));
    }

    public void testAddOptionRegistersTriggers() {
        final WriteableCommandLineImpl cl =
            new WriteableCommandLineImpl(plainOption("root"), new ArrayList());
        final Option help =
            new DefaultOptionBuilder().withShortName("h").withLongName("help").create();

        cl.addOption(help);

        assertEquals(help, cl.getOption("--help"));
        assertEquals(help, cl.getOption("-h"));
        assertNull(cl.getOption("--unknown"));
    }

    public void testGetOptionsIsUnmodifiable() {
        final WriteableCommandLineImpl cl =
            new WriteableCommandLineImpl(plainOption("root"), new ArrayList());

        try {
            cl.getOptions().add(plainOption("illegal"));
            fail("should have thrown UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
    }

    public void testGetOptionTriggersIsUnmodifiable() {
        final WriteableCommandLineImpl cl =
            new WriteableCommandLineImpl(plainOption("root"), new ArrayList());

        try {
            cl.getOptionTriggers().add("--illegal");
            fail("should have thrown UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
    }

    public void testGetValuesAugmentsWithExtraDefaultValues() {
        final WriteableCommandLineImpl cl =
            new WriteableCommandLineImpl(plainOption("root"), new ArrayList());
        final Option option = plainOption("present");

        cl.addValue(option, "explicit");

        final List defaults = Arrays.asList(new String[] {"default1", "default2", "default3"});
        final List result = cl.getValues(option, defaults);

        // explicit value kept, but the extra default values are appended
        assertEquals(Arrays.asList(new String[] {"explicit", "default2", "default3"}), result);
    }

    public void testGetValuesWithNoExplicitValuesReturnsSuppliedDefaults() {
        final WriteableCommandLineImpl cl =
            new WriteableCommandLineImpl(plainOption("root"), new ArrayList());
        final Option option = plainOption("present");
        final List defaults = Arrays.asList(new String[] {"d1", "d2"});

        assertEquals(defaults, cl.getValues(option, defaults));
    }

    public void testGetValuesReturnsEmptyListForUnknownOption() {
        final WriteableCommandLineImpl cl =
            new WriteableCommandLineImpl(plainOption("root"), new ArrayList());
        final Option option = plainOption("unused");

        final List values = cl.getValues(option, null);
        assertNotNull(values);
        assertTrue(values.isEmpty());
    }

    public void testGetUndefaultedValuesForUnknownOptionReturnsEmptyList() {
        final WriteableCommandLineImpl cl =
            new WriteableCommandLineImpl(plainOption("root"), new ArrayList());
        final Option option = plainOption("unused");

        assertTrue(cl.getUndefaultedValues(option).isEmpty());
    }

    public void testGetSwitchFallbackOrder() {
        final WriteableCommandLineImpl cl =
            new WriteableCommandLineImpl(plainOption("root"), new ArrayList());
        final Option option = plainOption("present");

        // nothing set -> method-level default wins
        assertEquals(Boolean.FALSE, cl.getSwitch(option, Boolean.FALSE));

        // the option's own default switch takes over when no method default
        cl.setDefaultSwitch(option, Boolean.TRUE);
        assertEquals(Boolean.TRUE, cl.getSwitch(option, null));
        assertEquals(Boolean.TRUE, cl.getSwitch(option));

        // an explicit switch beats both defaults
        cl.addSwitch(option, false);
        assertEquals(Boolean.FALSE, cl.getSwitch(option, Boolean.TRUE));
    }

    public void testHasOptionFalseForNullOption() {
        final WriteableCommandLineImpl cl =
            new WriteableCommandLineImpl(plainOption("root"), new ArrayList());

        assertFalse(cl.hasOption((Option) null));
    }

    public void testToStringQuotesValuesContainingSpaces() {
        final List normalised = new ArrayList();
        normalised.add("--present");
        normalised.add("has space");
        normalised.add("nospace");

        final WriteableCommandLineImpl cl =
            new WriteableCommandLineImpl(plainOption("root"), normalised);

        assertEquals("--present \"has space\" nospace", cl.toString());
    }

    public void testToStringEmptyWhenNoArguments() {
        final WriteableCommandLineImpl cl =
            new WriteableCommandLineImpl(plainOption("root"), new ArrayList());

        assertEquals("", cl.toString());
    }

    public void testGetNormalisedIsUnmodifiableAndReflectsConstructorArgument() {
        final List normalised = new ArrayList();
        normalised.add("foo");

        final WriteableCommandLineImpl cl =
            new WriteableCommandLineImpl(plainOption("root"), normalised);

        assertEquals(normalised, cl.getNormalised());

        try {
            cl.getNormalised().add("bar");
            fail("should have thrown UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // expected
        }
    }

    public void testAddPropertyDefaultUsesPropertyOptionBucket() {
        final WriteableCommandLineImpl cl =
            new WriteableCommandLineImpl(plainOption("root"), new ArrayList());

        cl.addProperty("alpha", "one");

        assertEquals("one", cl.getProperty("alpha"));
        assertEquals("one", cl.getProperty(new org.apache.commons.cli2.option.PropertyOption(), "alpha", null));
    }

    public void testGetPropertiesForUnknownOptionReturnsEmptySet() {
        final WriteableCommandLineImpl cl =
            new WriteableCommandLineImpl(plainOption("root"), new ArrayList());
        final Option option = plainOption("-D");

        assertTrue(cl.getProperties(option).isEmpty());
    }

    public void testSetCurrentOptionAndGetCurrentOption() {
        final Option root = plainOption("root");
        final WriteableCommandLineImpl cl = new WriteableCommandLineImpl(root, new ArrayList());
        final Option other = plainOption("other");

        cl.setCurrentOption(other);
        assertSame(other, cl.getCurrentOption());
    }

    public void testLooksLikeOptionReentrantCallReturnsFalseForSameTrigger() {
        // Build a root whose own canProcess would recurse back into
        // looksLikeOption for the very same trigger, exercising the
        // re-entrancy guard (checkForOption) in looksLikeOption().
        final List options = new ArrayList();
        options.add(new DefaultOptionBuilder().withShortName("h").withLongName("help").create());
        final Group root = new GroupImpl(options, "root", "desc", 0, Integer.MAX_VALUE, false);

        final WriteableCommandLineImpl cl = new WriteableCommandLineImpl(root, new ArrayList());

        // "--other" shares the "--" prefix but matches no option and there are
        // no anonymous arguments, so it should not look like an option.
        assertFalse(cl.looksLikeOption("--other"));
    }
}
