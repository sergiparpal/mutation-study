/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.cli2.option;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;

import junit.framework.TestCase;

import org.apache.commons.cli2.DisplaySetting;
import org.apache.commons.cli2.Group;
import org.apache.commons.cli2.Option;
import org.apache.commons.cli2.OptionException;
import org.apache.commons.cli2.WriteableCommandLine;
import org.apache.commons.cli2.builder.ArgumentBuilder;
import org.apache.commons.cli2.builder.DefaultOptionBuilder;
import org.apache.commons.cli2.commandline.WriteableCommandLineImpl;

public class GroupImplAgentTest extends TestCase {

    private static Option help() {
        return new DefaultOptionBuilder().withShortName("h").withLongName("help").create();
    }

    private static Option required(final String name) {
        return new DefaultOptionBuilder().withLongName(name).withRequired(true).create();
    }

    private static Option optional(final String name) {
        return new DefaultOptionBuilder().withLongName(name).withRequired(false).create();
    }

    private static WriteableCommandLine commandLine(final Option root, final List args) {
        return new WriteableCommandLineImpl(root, args);
    }

    public void testGetPrefixesAggregatesChildPrefixes() {
        final List options = new ArrayList();
        options.add(help());

        final Group group = new GroupImpl(options, "grp", "desc", 0, Integer.MAX_VALUE, false);

        final Set expected = new HashSet();
        expected.add("-");
        expected.add("--");
        assertEquals(expected, group.getPrefixes());
    }

    public void testGetPrefixesEmptyWhenNoOptions() {
        final Group group = new GroupImpl(new ArrayList(), "grp", "desc", 0, Integer.MAX_VALUE, false);
        assertTrue(group.getPrefixes().isEmpty());
    }

    public void testGetTriggersReturnsAllChildTriggers() {
        final List options = new ArrayList();
        options.add(help());

        final Group group = new GroupImpl(options, "grp", "desc", 0, Integer.MAX_VALUE, false);

        final Set expected = new HashSet();
        expected.add("--help");
        expected.add("-h");
        assertEquals(expected, group.getTriggers());
    }

    public void testConstructorRemovesArgumentsFromOptionsButExposesThemAsAnonymous() {
        final List options = new ArrayList();
        final Option helpOption = help();
        final Option argument = new ArgumentBuilder().withName("target").create();
        options.add(helpOption);
        options.add(argument);

        final GroupImpl group = new GroupImpl(options, "grp", "desc", 0, Integer.MAX_VALUE, false);

        assertEquals(1, group.getOptions().size());
        assertTrue(group.getOptions().contains(helpOption));
        assertFalse(group.getOptions().contains(argument));
        assertEquals(1, group.getAnonymous().size());
        assertTrue(group.getAnonymous().contains(argument));
    }

    public void testConstructorSetsParentOnChildOptions() {
        final List options = new ArrayList();
        final Option child = help();
        options.add(child);

        final Group group = new GroupImpl(options, "grp", "desc", 0, Integer.MAX_VALUE, false);

        assertEquals(group, child.getParent());
    }

    public void testCanProcessNullArgumentReturnsFalse() {
        final Group group = new GroupImpl(new ArrayList(), "grp", "desc", 0, Integer.MAX_VALUE, false);
        final WriteableCommandLine cl = commandLine(group, new ArrayList());

        assertFalse(group.canProcess(cl, (String) null));
    }

    public void testCanProcessKnownTrigger() {
        final List options = new ArrayList();
        options.add(help());
        final Group group = new GroupImpl(options, "grp", "desc", 0, Integer.MAX_VALUE, false);
        final WriteableCommandLine cl = commandLine(group, new ArrayList());

        assertTrue(group.canProcess(cl, "--help"));
    }

    public void testCanProcessUnknownTriggerWithNoAnonymousArgumentsReturnsFalse() {
        final List options = new ArrayList();
        options.add(help());
        final Group group = new GroupImpl(options, "grp", "desc", 0, Integer.MAX_VALUE, false);
        final WriteableCommandLine cl = commandLine(group, new ArrayList());

        assertFalse(group.canProcess(cl, "--unknown"));
    }

    public void testCanProcessUnknownNonOptionArgumentWithAnonymousArgumentReturnsTrue() {
        final List options = new ArrayList();
        options.add(new ArgumentBuilder().withName("target").create());
        final Group group = new GroupImpl(options, "grp", "desc", 0, Integer.MAX_VALUE, false);
        final WriteableCommandLine cl = commandLine(group, new ArrayList());

        assertTrue(group.canProcess(cl, "value"));
    }

    public void testFindOptionDelegatesToChildren() {
        final List options = new ArrayList();
        options.add(help());
        final Group group = new GroupImpl(options, "grp", "desc", 0, Integer.MAX_VALUE, false);

        assertNotNull(group.findOption("--help"));
        assertNull(group.findOption("--missing"));
    }

    public void testProcessRecognisedOption() throws OptionException {
        final List options = new ArrayList();
        options.add(help());
        final Group group = new GroupImpl(options, "grp", "desc", 0, Integer.MAX_VALUE, false);

        final List args = new ArrayList();
        args.add("--help");
        final ListIterator iterator = args.listIterator();
        final WriteableCommandLine cl = commandLine(group, args);

        group.process(cl, iterator);

        assertFalse(iterator.hasNext());
        assertTrue(cl.hasOption("--help"));
    }

    public void testProcessStopsWhenArgumentIsNotAnonymousAndNotRecognised() throws OptionException {
        final List options = new ArrayList();
        options.add(help());
        final Group group = new GroupImpl(options, "grp", "desc", 0, Integer.MAX_VALUE, false);

        final List args = new ArrayList();
        args.add("not-an-option");
        final ListIterator iterator = args.listIterator();
        final WriteableCommandLine cl = commandLine(group, args);

        group.process(cl, iterator);

        // nothing consumed, no anonymous arguments to catch the token
        assertTrue(iterator.hasNext());
        assertEquals("not-an-option", iterator.next());
    }

    public void testValidateSucceedsWithinMinMaxBounds() throws OptionException {
        final List options = new ArrayList();
        final Option restart = optional("restart");
        options.add(restart);
        final Group group = new GroupImpl(options, "grp", "desc", 1, 1, true);

        final WriteableCommandLine cl = commandLine(group, new ArrayList());
        cl.addOption(restart);

        group.validate(cl);
    }

    public void testValidateFailsWhenTooManyOptionsPresent() {
        final List options = new ArrayList();
        final Option restart = optional("restart");
        final Option stop = optional("stop");
        options.add(restart);
        options.add(stop);
        final Group group = new GroupImpl(options, "grp", "desc", 0, 1, false);

        final WriteableCommandLine cl = commandLine(group, new ArrayList());
        cl.addOption(restart);
        cl.addOption(stop);

        try {
            group.validate(cl);
            fail("expected OptionException for too many options");
        } catch (OptionException e) {
            assertEquals(group, e.getOption());
        }
    }

    public void testValidateFailsWhenBelowMinimum() {
        final List options = new ArrayList();
        options.add(optional("restart"));
        final Group group = new GroupImpl(options, "grp", "desc", 1, 1, true);

        final WriteableCommandLine cl = commandLine(group, new ArrayList());

        try {
            group.validate(cl);
            fail("expected OptionException for missing option");
        } catch (OptionException e) {
            assertEquals(group, e.getOption());
        }
    }

    public void testValidatePropagatesToRequiredChild() {
        final Option requiredChild = required("required");
        final List options = new ArrayList();
        options.add(requiredChild);
        final Group group = new GroupImpl(options, "grp", "desc", 0, Integer.MAX_VALUE, false);

        final WriteableCommandLine cl = commandLine(group, new ArrayList());

        try {
            group.validate(cl);
            fail("expected OptionException because required child is missing");
        } catch (OptionException e) {
            assertEquals(requiredChild, e.getOption());
        }
    }

    public void testGetPreferredNameAndDescription() {
        final Group group =
            new GroupImpl(new ArrayList(), "my-group", "my description", 0, Integer.MAX_VALUE, false);

        assertEquals("my-group", group.getPreferredName());
        assertEquals("my description", group.getDescription());
    }

    public void testGetMinimumAndMaximum() {
        final Group group = new GroupImpl(new ArrayList(), "grp", "desc", 2, 5, false);

        assertEquals(2, group.getMinimum());
        assertEquals(5, group.getMaximum());
    }

    public void testIsRequiredFalseWhenMinimumIsZero() {
        final Group group = new GroupImpl(new ArrayList(), "grp", "desc", 0, Integer.MAX_VALUE, true);
        assertFalse(group.isRequired());
    }

    public void testIsRequiredFalseWhenRequiredFlagNotSetEvenWithMinimum() {
        final List childOptions = new ArrayList();
        final Group child = new GroupImpl(new ArrayList(), "child", "desc", 3, Integer.MAX_VALUE, false);
        childOptions.add(child);
        new GroupImpl(childOptions, "parent", "desc", 0, Integer.MAX_VALUE, false);

        assertFalse(child.isRequired());
    }

    public void testIsRequiredTrueWhenFlagSetAndMinimumPositiveWithParent() {
        final List childOptions = new ArrayList();
        final Group child = new GroupImpl(new ArrayList(), "child", "desc", 3, Integer.MAX_VALUE, true);
        childOptions.add(child);
        new GroupImpl(childOptions, "parent", "desc", 0, Integer.MAX_VALUE, false);

        assertTrue(child.isRequired());
    }

    public void testIsRequiredTrueForRootGroupWithPositiveMinimumRegardlessOfFlag() {
        final Group root = new GroupImpl(new ArrayList(), "root", "desc", 1, Integer.MAX_VALUE, false);
        assertTrue(root.isRequired());
    }

    public void testAppendUsageBasic() {
        final List options = new ArrayList();
        options.add(required("alpha"));
        options.add(optional("beta"));
        // minimum >= 1 and required = true so the group itself isn't
        // rendered as optional (no surrounding brackets)
        final Group group = new GroupImpl(options, "grp", "desc", 1, Integer.MAX_VALUE, true);

        final StringBuffer buffer = new StringBuffer();
        group.appendUsage(buffer, new HashSet(DisplaySetting.ALL), null);

        // DISPLAY_OPTIONAL is stripped from the settings used for children,
        // so individual options are never bracketed here - only the group
        // itself would be, were it optional.
        assertEquals("grp (--alpha|--beta)", buffer.toString());
    }

    public void testAppendUsageWithoutGroupName() {
        final List options = new ArrayList();
        options.add(optional("alpha"));
        final Group group = new GroupImpl(options, "grp", "desc", 0, Integer.MAX_VALUE, false);

        final Set settings = new HashSet(DisplaySetting.ALL);
        settings.remove(DisplaySetting.DISPLAY_GROUP_NAME);

        final StringBuffer buffer = new StringBuffer();
        group.appendUsage(buffer, settings, null);

        assertEquals("[--alpha]", buffer.toString());
    }

    public void testAppendUsageNotExpandedUsesNameOnly() {
        final List options = new ArrayList();
        options.add(optional("alpha"));
        final Group group = new GroupImpl(options, "grp", "desc", 1, Integer.MAX_VALUE, true);

        final Set settings = new HashSet(DisplaySetting.ALL);
        settings.remove(DisplaySetting.DISPLAY_GROUP_EXPANDED);

        final StringBuffer buffer = new StringBuffer();
        group.appendUsage(buffer, settings, null);

        assertEquals("grp", buffer.toString());
    }

    public void testHelpLinesIncludesGroupAndChildren() {
        final Option alpha = optional("alpha");
        final List options = new ArrayList();
        options.add(alpha);
        final Group group = new GroupImpl(options, "grp", "desc", 0, Integer.MAX_VALUE, false);

        final List lines = group.helpLines(0, DisplaySetting.ALL, null);

        assertEquals(2, lines.size());
    }

    public void testHelpLinesExcludesChildrenWhenNotExpanded() {
        final Option alpha = optional("alpha");
        final List options = new ArrayList();
        options.add(alpha);
        final Group group = new GroupImpl(options, "grp", "desc", 0, Integer.MAX_VALUE, false);

        final Set settings = new HashSet(DisplaySetting.ALL);
        settings.remove(DisplaySetting.DISPLAY_GROUP_EXPANDED);

        final List lines = group.helpLines(0, settings, null);

        assertEquals(1, lines.size());
    }

    public void testDefaultsAreAppliedToChildrenAndAnonymous() {
        final Option argument =
            new ArgumentBuilder().withName("target").withDefault("defaultValue").create();
        final List options = new ArrayList();
        options.add(argument);
        final Group group = new GroupImpl(options, "grp", "desc", 0, Integer.MAX_VALUE, false);

        final WriteableCommandLine cl = commandLine(group, new ArrayList());
        group.defaults(cl);

        assertEquals("defaultValue", cl.getValue(argument));
    }
}
