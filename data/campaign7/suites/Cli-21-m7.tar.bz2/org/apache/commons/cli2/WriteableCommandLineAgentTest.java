/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.cli2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import junit.framework.TestCase;

import org.apache.commons.cli2.builder.ArgumentBuilder;
import org.apache.commons.cli2.builder.DefaultOptionBuilder;
import org.apache.commons.cli2.commandline.WriteableCommandLineImpl;
import org.apache.commons.cli2.option.Command;
import org.apache.commons.cli2.option.GroupImpl;

/**
 * Exercises the contract of the {@link WriteableCommandLine} interface using
 * {@link WriteableCommandLineImpl} as the vehicle, since the interface itself
 * cannot be instantiated.
 */
public class WriteableCommandLineAgentTest extends TestCase {

    private static Option plainOption(final String name) {
        return new Command(name, "desc of " + name, null, false, null, null, 0);
    }

    private static WriteableCommandLine commandLine() {
        final Option root = plainOption("root");
        return new WriteableCommandLineImpl(root, new ArrayList());
    }

    public void testAddOption() {
        final WriteableCommandLine cl = commandLine();
        final Option option = plainOption("present");

        assertFalse(cl.hasOption(option));
        cl.addOption(option);
        assertTrue(cl.hasOption(option));
        assertTrue(cl.getOptions().contains(option));
    }

    public void testAddValueOnNonArgumentDoesNotImplyOptionIsPresent() {
        final WriteableCommandLine cl = commandLine();
        final Option option = plainOption("multiple");

        assertTrue(cl.getValues(option).isEmpty());
        cl.addValue(option, "value 1");
        cl.addValue(option, "value 2");

        assertEquals(Arrays.asList(new String[] {"value 1", "value 2"}), cl.getValues(option));
        // non-Argument options don't become "present" just because a value
        // was recorded for them
        assertFalse(cl.hasOption(option));
    }

    public void testAddValueOnArgumentForcesOptionPresent() {
        final WriteableCommandLine cl = commandLine();
        final Argument argument = new ArgumentBuilder().withName("file").create();

        assertFalse(cl.hasOption(argument));
        cl.addValue(argument, "value");
        assertTrue(cl.hasOption(argument));
        assertEquals(Arrays.asList(new String[] {"value"}), cl.getValues(argument));
    }

    public void testGetUndefaultedValuesIsEmptyByDefault() {
        final WriteableCommandLine cl = commandLine();
        final Option option = plainOption("present");

        assertTrue(cl.getUndefaultedValues(option).isEmpty());
    }

    public void testGetUndefaultedValuesExcludesDefaultsButGetValuesIncludesThem() {
        final WriteableCommandLine cl = commandLine();
        final Option option = plainOption("present");
        final List defaults = Arrays.asList(new String[] {"default"});

        cl.setDefaultValues(option, defaults);

        assertTrue(cl.getUndefaultedValues(option).isEmpty());
        assertEquals(defaults, cl.getValues(option));

        cl.addValue(option, "real");

        assertEquals(Arrays.asList(new String[] {"real"}), cl.getUndefaultedValues(option));
    }

    public void testSetDefaultValuesNullRemovesDefault() {
        final WriteableCommandLine cl = commandLine();
        final Option option = plainOption("present");

        cl.setDefaultValues(option, Arrays.asList(new String[] {"default"}));
        assertFalse(cl.getValues(option).isEmpty());

        cl.setDefaultValues(option, null);
        assertTrue(cl.getValues(option).isEmpty());
    }

    public void testAddSwitch() {
        final WriteableCommandLine cl = commandLine();
        final Option option = plainOption("present");

        assertNull(cl.getSwitch(option));
        cl.addSwitch(option, true);
        assertEquals(Boolean.TRUE, cl.getSwitch(option));
        assertTrue(cl.hasOption(option));
    }

    public void testAddSwitchTwiceThrowsIllegalStateException() {
        final WriteableCommandLine cl = commandLine();
        final Option option = plainOption("present");

        cl.addSwitch(option, true);

        try {
            cl.addSwitch(option, false);
            fail("should have thrown IllegalStateException");
        } catch (IllegalStateException expected) {
            // expected
        }
    }

    public void testSetDefaultSwitchIsUsedWhenNoExplicitSwitchAdded() {
        final WriteableCommandLine cl = commandLine();
        final Option option = plainOption("present");

        assertNull(cl.getSwitch(option));
        cl.setDefaultSwitch(option, Boolean.TRUE);
        assertEquals(Boolean.TRUE, cl.getSwitch(option));
    }

    public void testExplicitSwitchOverridesDefaultSwitch() {
        final WriteableCommandLine cl = commandLine();
        final Option option = plainOption("present");

        cl.setDefaultSwitch(option, Boolean.TRUE);
        cl.addSwitch(option, false);

        assertEquals(Boolean.FALSE, cl.getSwitch(option));
    }

    public void testSetDefaultSwitchNullRemovesDefault() {
        final WriteableCommandLine cl = commandLine();
        final Option option = plainOption("present");

        cl.setDefaultSwitch(option, Boolean.TRUE);
        cl.setDefaultSwitch(option, null);

        assertNull(cl.getSwitch(option));
    }

    public void testAddPropertyWithOption() {
        final WriteableCommandLine cl = commandLine();
        final Option option = plainOption("-D");

        assertNull(cl.getProperty(option, "present", null));
        cl.addProperty(option, "present", "present value");
        assertEquals("present value", cl.getProperty(option, "present", null));
        assertTrue(cl.getProperties(option).contains("present"));
    }

    public void testAddPropertyDefault() {
        final WriteableCommandLine cl = commandLine();

        assertNull(cl.getProperty("present"));
        cl.addProperty("present", "present value");
        assertEquals("present value", cl.getProperty("present"));
        assertTrue(cl.getProperties().contains("present"));
    }

    public void testAddPropertyReplacesExistingValue() {
        final WriteableCommandLine cl = commandLine();

        cl.addProperty("present", "first");
        cl.addProperty("present", "second");

        assertEquals("second", cl.getProperty("present"));
    }

    public void testGetCurrentOptionDefaultsToRootOption() {
        final Option root = plainOption("root");
        final WriteableCommandLine cl = new WriteableCommandLineImpl(root, new ArrayList());

        assertEquals(root, cl.getCurrentOption());
    }

    public void testSetCurrentOption() {
        final Option root = plainOption("root");
        final WriteableCommandLine cl = new WriteableCommandLineImpl(root, new ArrayList());
        final Option other = plainOption("other");

        cl.setCurrentOption(other);
        assertEquals(other, cl.getCurrentOption());

        cl.setCurrentOption(null);
        assertNull(cl.getCurrentOption());
    }

    public void testLooksLikeOptionTrueForKnownTrigger() {
        final List options = new ArrayList();
        options.add(new DefaultOptionBuilder().withShortName("h").withLongName("help").create());

        final Group root = new GroupImpl(options, "root", "desc", 0, Integer.MAX_VALUE, false);
        final WriteableCommandLine cl = new WriteableCommandLineImpl(root, new ArrayList());

        assertTrue(cl.looksLikeOption("--help"));
    }

    public void testLooksLikeOptionFalseForUnknownTrigger() {
        final List options = new ArrayList();
        options.add(new DefaultOptionBuilder().withShortName("h").withLongName("help").create());

        final Group root = new GroupImpl(options, "root", "desc", 0, Integer.MAX_VALUE, false);
        final WriteableCommandLine cl = new WriteableCommandLineImpl(root, new ArrayList());

        assertFalse(cl.looksLikeOption("--unknown"));
    }

    public void testLooksLikeOptionFalseWhenNoPrefixMatches() {
        final WriteableCommandLine cl = commandLine();

        assertFalse(cl.looksLikeOption("plainvalue"));
    }
}
