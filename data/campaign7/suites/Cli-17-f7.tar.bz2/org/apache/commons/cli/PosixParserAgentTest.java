/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.cli;

import java.util.Arrays;

import junit.framework.TestCase;

/**
 * Self-contained tests for {@link PosixParser}, exercising both the
 * package-visible {@link PosixParser#flatten(Options, String[], boolean)}
 * algorithm directly and the public {@link Parser#parse} entry points.
 */
public class PosixParserAgentTest extends TestCase
{
    private Options options;
    private PosixParser parser;

    public void setUp()
    {
        options = new Options()
            .addOption("a", "enable-a", false, "turn [a] on or off")
            .addOption("b", "bfile", true, "set the value of [b]")
            .addOption("c", "copt", false, "turn [c] on or off");

        parser = new PosixParser();
    }

    public void testSimpleShort() throws Exception
    {
        String[] args = new String[] { "-a", "-b", "toast", "foo", "bar" };

        CommandLine cl = parser.parse(options, args);

        assertTrue("Confirm -a is set", cl.hasOption("a"));
        assertTrue("Confirm -b is set", cl.hasOption("b"));
        assertEquals("Confirm arg of -b", "toast", cl.getOptionValue("b"));
        assertEquals("Confirm size of extra args", 2, cl.getArgList().size());
    }

    public void testEmptyArguments() throws Exception
    {
        String[] flattened = parser.flatten(options, new String[0], false);

        assertEquals("flatten of empty array returns empty array", 0, flattened.length);

        CommandLine cl = parser.parse(options, new String[0]);

        assertFalse(cl.hasOption("a"));
        assertEquals(0, cl.getArgList().size());
    }

    public void testFlattenDoubleDashAlone()
    {
        String[] flattened = parser.flatten(options, new String[] { "--" }, false);

        assertEquals(1, flattened.length);
        assertEquals("--", flattened[0]);
    }

    public void testFlattenSingleHyphenAlone()
    {
        String[] flattened = parser.flatten(options, new String[] { "-" }, false);

        assertEquals(1, flattened.length);
        assertEquals("-", flattened[0]);
    }

    public void testFlattenLongOptionWithEquals()
    {
        String[] flattened = parser.flatten(options, new String[] { "--bfile=toast" }, false);

        assertEquals(Arrays.asList(new String[] { "--bfile", "toast" }), Arrays.asList(flattened));
    }

    public void testLongOptionWithEqualsViaParse() throws Exception
    {
        CommandLine cl = parser.parse(options, new String[] { "--bfile=toast" });

        assertTrue(cl.hasOption("b"));
        assertEquals("toast", cl.getOptionValue("b"));
    }

    public void testFlattenRecognizedTwoCharOption()
    {
        String[] flattened = parser.flatten(options, new String[] { "-a" }, false);

        assertEquals(1, flattened.length);
        assertEquals("-a", flattened[0]);
    }

    /**
     * Per the documented rule: an unrecognized two-character option is
     * simply ignored when stopAtNonOption is false.
     */
    public void testFlattenUnrecognizedTwoCharOptionIgnoredWhenNotStopping()
    {
        String[] flattened = parser.flatten(options, new String[] { "-z", "foo" }, false);

        assertEquals(Arrays.asList(new String[] { "foo" }), Arrays.asList(flattened));
    }

    /**
     * Per the documented rule: when an unrecognized two-character option is
     * found and stopAtNonOption is true, the remaining entries are copied
     * verbatim to the processed tokens.
     */
    public void testFlattenUnrecognizedTwoCharOptionStopsAndCopiesRemainder()
    {
        String[] flattened = parser.flatten(options,
                                            new String[] { "-z", "foo", "bar" }, true);

        assertEquals(Arrays.asList(new String[] { "foo", "bar" }), Arrays.asList(flattened));
    }

    /**
     * A bare unrecognized short option silently disappears (it is not
     * copied to the token list), so parsing with PosixParser does not
     * raise UnrecognizedOptionException the way GnuParser does.
     */
    public void testUnrecognizedOptionIsSilentlyDropped() throws Exception
    {
        String[] args = new String[] { "-a", "-d", "-b", "toast", "foo", "bar" };

        CommandLine cl = parser.parse(options, args);

        assertTrue("Confirm -a is set", cl.hasOption("a"));
        assertFalse("Confirm -d was never recognized", cl.hasOption("d"));
        assertTrue("Confirm -b is set", cl.hasOption("b"));
        assertEquals("toast", cl.getOptionValue("b"));
        assertEquals(2, cl.getArgList().size());
    }

    public void testMissingArg() throws Exception
    {
        String[] args = new String[] { "-b" };

        try
        {
            parser.parse(options, args);
            fail("MissingArgumentException wasn't thrown");
        }
        catch (MissingArgumentException e)
        {
            assertEquals("b", e.getOption().getOpt());
        }
    }

    public void testStop() throws Exception
    {
        String[] args = new String[] { "-c", "foober", "-b", "toast" };

        CommandLine cl = parser.parse(options, args, true);

        assertTrue("Confirm -c is set", cl.hasOption("c"));
        assertFalse("Confirm -b is not set", cl.hasOption("b"));
        assertEquals("Confirm 3 extra args", 3, cl.getArgList().size());
    }

    public void testMultiple() throws Exception
    {
        String[] args = new String[] { "-c", "foobar", "-b", "toast" };

        CommandLine cl = parser.parse(options, args, true);
        assertTrue("Confirm -c is set", cl.hasOption("c"));
        assertEquals(3, cl.getArgList().size());

        cl = parser.parse(options, cl.getArgs());

        assertFalse("Confirm -c is not set", cl.hasOption("c"));
        assertTrue("Confirm -b is set", cl.hasOption("b"));
        assertEquals("toast", cl.getOptionValue("b"));
        assertEquals(1, cl.getArgList().size());
        assertEquals("foobar", cl.getArgList().get(0));
    }

    public void testDoubleDash() throws Exception
    {
        String[] args = new String[] { "-c", "--", "-b", "toast" };

        CommandLine cl = parser.parse(options, args);

        assertTrue("Confirm -c is set", cl.hasOption("c"));
        assertFalse("Confirm -b is not set", cl.hasOption("b"));
        assertEquals("Confirm 2 extra args", 2, cl.getArgList().size());
    }

    public void testSingleDash() throws Exception
    {
        String[] args = new String[] { "-c", "-b", "-", "-a", "-" };

        CommandLine cl = parser.parse(options, args);

        assertTrue("Confirm -a is set", cl.hasOption("a"));
        assertTrue("Confirm -b is set", cl.hasOption("b"));
        assertEquals("-", cl.getOptionValue("b"));
        assertEquals(1, cl.getArgList().size());
        assertEquals("-", cl.getArgList().get(0));
    }

    public void testBurstTokenSeparateFlags()
    {
        String[] flattened = parser.flatten(options, new String[] { "-ac" }, false);

        assertEquals(Arrays.asList(new String[] { "-a", "-c" }), Arrays.asList(flattened));
    }

    public void testBurstTokenOptionWithAttachedArgument()
    {
        String[] flattened = parser.flatten(options, new String[] { "-abtoast" }, false);

        assertEquals(Arrays.asList(new String[] { "-a", "-b", "toast" }),
                      Arrays.asList(flattened));
    }

    public void testBurstTokenOptionWithAttachedArgumentViaParse() throws Exception
    {
        CommandLine cl = parser.parse(options, new String[] { "-abtoast" });

        assertTrue(cl.hasOption("a"));
        assertTrue(cl.hasOption("b"));
        assertEquals("toast", cl.getOptionValue("b"));
    }

    /**
     * A directly registered multi-character option id bypasses bursting
     * entirely: the whole token is recognized as one option.
     */
    public void testMultiCharacterOptionRegisteredDirectlyIsNotBurst()
    {
        Options multiCharOptions = new Options().addOption("ab", false, "two char option");

        String[] flattened = parser.flatten(multiCharOptions, new String[] { "-ab" }, false);

        assertEquals(1, flattened.length);
        assertEquals("-ab", flattened[0]);
    }

    /**
     * Per the documented bursting algorithm, when a character has no
     * matching Option and stopAtNonOption is false, only that single
     * character (prefixed with "-") should be appended to the processed
     * tokens -- the already-recognized leading option(s) in the same
     * token must not be duplicated or discarded.
     */
    public void testBurstTokenUnknownCharacterAppendsOnlyThatCharacter()
    {
        String[] flattened = parser.flatten(options, new String[] { "-ax" }, false);

        assertEquals(Arrays.asList(new String[] { "-a", "-x" }), Arrays.asList(flattened));
    }

    public void testBurstTokenUnknownCharacterWithStopAtNonOption()
    {
        String[] flattened = parser.flatten(options, new String[] { "-ax", "foo" }, true);

        assertEquals(Arrays.asList(new String[] { "-a", "--", "x", "foo" }),
                      Arrays.asList(flattened));
    }

    public void testLongOptionAfterDashIsNotSplitTwice()
    {
        String[] flattened = parser.flatten(options, new String[] { "--enable-a=value" }, false);

        assertEquals(Arrays.asList(new String[] { "--enable-a", "value" }),
                      Arrays.asList(flattened));
    }
}
