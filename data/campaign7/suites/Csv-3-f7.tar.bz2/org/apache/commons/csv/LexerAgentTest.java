/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.csv;

import static org.apache.commons.csv.Constants.BACKSPACE;
import static org.apache.commons.csv.Constants.CR;
import static org.apache.commons.csv.Constants.END_OF_STREAM;
import static org.apache.commons.csv.Constants.FF;
import static org.apache.commons.csv.Constants.LF;
import static org.apache.commons.csv.Constants.TAB;
import static org.apache.commons.csv.Constants.UNDEFINED;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.io.StringReader;

import org.junit.Test;

/**
 * Tests for {@link Lexer}, exercised through the concrete {@link CSVLexer}
 * subclass since Lexer itself is abstract. All the methods under test are
 * package-private members declared directly on Lexer.
 */
public class LexerAgentTest {

    private static Lexer lexerFor(final CSVFormat format, final String input) {
        return new CSVLexer(format, new ExtendedBufferedReader(new StringReader(input)));
    }

    // ---- constructor / field initialization ----

    @Test
    public void testConstructorStoresFormatAndStream() {
        final CSVFormat format = CSVFormat.newBuilder(',').withIgnoreSurroundingSpaces(true)
                .withIgnoreEmptyLines(true).build();
        final ExtendedBufferedReader reader = new ExtendedBufferedReader(new StringReader("a"));
        final Lexer lexer = new CSVLexer(format, reader);

        assertSame(format, lexer.format);
        assertSame(reader, lexer.in);
        assertTrue(lexer.ignoreSurroundingSpaces);
        assertTrue(lexer.ignoreEmptyLines);
    }

    @Test
    public void testConstructorFalseFlags() {
        final CSVFormat format = CSVFormat.newBuilder(',').withIgnoreSurroundingSpaces(false)
                .withIgnoreEmptyLines(false).build();
        final Lexer lexer = lexerFor(format, "a");

        assertFalse(lexer.ignoreSurroundingSpaces);
        assertFalse(lexer.ignoreEmptyLines);
    }

    // ---- getLineNumber ----

    @Test
    public void testGetLineNumberDelegatesToStream() throws IOException {
        final CSVFormat format = CSVFormat.newBuilder(',').build();
        final Lexer lexer = lexerFor(format, "a\nb\nc");

        assertEquals(0, lexer.getLineNumber());
        lexer.in.read(); // 'a'
        assertEquals(0, lexer.getLineNumber());
        lexer.in.read(); // '\n'
        assertEquals(1, lexer.getLineNumber());
        lexer.in.read(); // 'b'
        lexer.in.read(); // '\n'
        assertEquals(2, lexer.getLineNumber());
        assertEquals(lexer.in.getLineNumber(), lexer.getLineNumber());
    }

    // ---- readEscape ----

    @Test
    public void testReadEscapeNamedControlCharacters() throws IOException {
        final CSVFormat format = CSVFormat.newBuilder(',').withEscape('\\').build();

        assertEquals(CR, lexerFor(format, "r").readEscape());
        assertEquals(LF, lexerFor(format, "n").readEscape());
        assertEquals(TAB, lexerFor(format, "t").readEscape());
        assertEquals(BACKSPACE, lexerFor(format, "b").readEscape());
        assertEquals(FF, lexerFor(format, "f").readEscape());
    }

    @Test
    public void testReadEscapeLiteralControlCharactersPassThrough() throws IOException {
        final CSVFormat format = CSVFormat.newBuilder(',').withEscape('\\').build();

        assertEquals(CR, lexerFor(format, "\r").readEscape());
        assertEquals(LF, lexerFor(format, "\n").readEscape());
        assertEquals(FF, lexerFor(format, "\f").readEscape());
        assertEquals(TAB, lexerFor(format, "\t").readEscape());
        assertEquals(BACKSPACE, lexerFor(format, "\b").readEscape());
    }

    @Test
    public void testReadEscapeMetaCharacterIsReturnedAsIs() throws IOException {
        final CSVFormat format = CSVFormat.newBuilder(',').withEscape('\\').build();

        assertEquals(',', lexerFor(format, ",").readEscape());
        assertEquals('"', lexerFor(format, "\"").readEscape());
        assertEquals('\\', lexerFor(format, "\\").readEscape());
        assertEquals('x', lexerFor(format, "x").readEscape());
    }

    @Test(expected = IOException.class)
    public void testReadEscapeAtEndOfStreamThrows() throws IOException {
        final CSVFormat format = CSVFormat.newBuilder(',').withEscape('\\').build();
        lexerFor(format, "").readEscape();
    }

    @Test
    public void testReadEscapeLeavesLastCharAvailable() throws IOException {
        final CSVFormat format = CSVFormat.newBuilder(',').withEscape('\\').build();
        final Lexer lexer = lexerFor(format, "nrest");

        assertEquals(LF, lexer.readEscape());
        assertEquals('n', lexer.in.getLastChar());
        // stream position should be right after the escaped char
        assertEquals('r', lexer.in.read());
    }

    // ---- trimTrailingSpaces ----

    @Test
    public void testTrimTrailingSpacesRemovesOnlyTrailingWhitespace() {
        final Lexer lexer = lexerFor(CSVFormat.newBuilder(',').build(), "");
        final StringBuilder sb = new StringBuilder("  hello world  \t\n");

        lexer.trimTrailingSpaces(sb);

        assertEquals("  hello world", sb.toString());
    }

    @Test
    public void testTrimTrailingSpacesNoTrailingWhitespaceUnchanged() {
        final Lexer lexer = lexerFor(CSVFormat.newBuilder(',').build(), "");
        final StringBuilder sb = new StringBuilder("hello");

        lexer.trimTrailingSpaces(sb);

        assertEquals("hello", sb.toString());
    }

    @Test
    public void testTrimTrailingSpacesAllWhitespaceBecomesEmpty() {
        final Lexer lexer = lexerFor(CSVFormat.newBuilder(',').build(), "");
        final StringBuilder sb = new StringBuilder("   \t  ");

        lexer.trimTrailingSpaces(sb);

        assertEquals(0, sb.length());
    }

    @Test
    public void testTrimTrailingSpacesEmptyBufferUnchanged() {
        final Lexer lexer = lexerFor(CSVFormat.newBuilder(',').build(), "");
        final StringBuilder sb = new StringBuilder("");

        lexer.trimTrailingSpaces(sb);

        assertEquals(0, sb.length());
    }

    // ---- readEndOfLine ----

    @Test
    public void testReadEndOfLineConsumesLfAfterCr() throws IOException {
        final Lexer lexer = lexerFor(CSVFormat.newBuilder(',').build(), "\r\n2");
        final int c = lexer.in.read();

        assertEquals(CR, c);
        assertTrue(lexer.readEndOfLine(c));
        // the LF following CR must have been silently consumed
        assertEquals('2', lexer.in.read());
    }

    @Test
    public void testReadEndOfLineLfAlone() throws IOException {
        final Lexer lexer = lexerFor(CSVFormat.newBuilder(',').build(), "\n2");
        final int c = lexer.in.read();

        assertEquals(LF, c);
        assertTrue(lexer.readEndOfLine(c));
        assertEquals('2', lexer.in.read());
    }

    @Test
    public void testReadEndOfLineCrWithoutLf() throws IOException {
        final Lexer lexer = lexerFor(CSVFormat.newBuilder(',').build(), "\ra");
        final int c = lexer.in.read();

        assertEquals(CR, c);
        assertTrue(lexer.readEndOfLine(c));
        assertEquals('a', lexer.in.read());
    }

    @Test
    public void testReadEndOfLineNonEolCharacter() throws IOException {
        final Lexer lexer = lexerFor(CSVFormat.newBuilder(',').build(), "ab");
        final int c = lexer.in.read();

        assertEquals('a', c);
        assertFalse(lexer.readEndOfLine(c));
        assertEquals('b', lexer.in.read());
    }

    // ---- isWhitespace ----

    @Test
    public void testIsWhitespaceForOrdinaryWhitespace() {
        final Lexer lexer = lexerFor(CSVFormat.newBuilder(',').build(), "");

        assertTrue(lexer.isWhitespace(' '));
        assertTrue(lexer.isWhitespace('\t'));
        assertFalse(lexer.isWhitespace('a'));
    }

    @Test
    public void testIsWhitespaceDelimiterNeverCountsAsWhitespace() {
        // delimiter is itself a whitespace character
        final CSVFormat format = CSVFormat.newBuilder(' ').build();
        final Lexer lexer = lexerFor(format, "");

        assertFalse(lexer.isWhitespace(' '));
        // other whitespace characters are unaffected
        assertTrue(lexer.isWhitespace('\t'));
    }

    // ---- isStartOfLine ----

    @Test
    public void testIsStartOfLine() {
        final Lexer lexer = lexerFor(CSVFormat.newBuilder(',').build(), "");

        assertTrue(lexer.isStartOfLine(LF));
        assertTrue(lexer.isStartOfLine(CR));
        assertTrue(lexer.isStartOfLine(UNDEFINED));
        assertFalse(lexer.isStartOfLine('a'));
        assertFalse(lexer.isStartOfLine(END_OF_STREAM));
    }

    // ---- isEndOfFile ----

    @Test
    public void testIsEndOfFile() {
        final Lexer lexer = lexerFor(CSVFormat.newBuilder(',').build(), "");

        assertTrue(lexer.isEndOfFile(END_OF_STREAM));
        assertFalse(lexer.isEndOfFile(UNDEFINED));
        assertFalse(lexer.isEndOfFile('a'));
        assertFalse(lexer.isEndOfFile(0));
    }

    // ---- isDelimiter / isEscape / isQuoteChar / isCommentStart ----

    @Test
    public void testIsDelimiter() {
        final CSVFormat format = CSVFormat.newBuilder(';').build();
        final Lexer lexer = lexerFor(format, "");

        assertTrue(lexer.isDelimiter(';'));
        assertFalse(lexer.isDelimiter(','));
    }

    @Test
    public void testIsEscapeWhenConfigured() {
        final CSVFormat format = CSVFormat.newBuilder(',').withEscape('\\').build();
        final Lexer lexer = lexerFor(format, "");

        assertTrue(lexer.isEscape('\\'));
        assertFalse(lexer.isEscape('/'));
    }

    @Test
    public void testIsEscapeWhenDisabledNeverMatchesOrdinaryCharacters() {
        final CSVFormat format = CSVFormat.newBuilder(',').build(); // no escape configured
        final Lexer lexer = lexerFor(format, "");

        assertFalse(lexer.isEscape('\\'));
        assertFalse(lexer.isEscape(END_OF_STREAM));
        assertFalse(lexer.isEscape('a'));
    }

    @Test
    public void testIsQuoteCharWhenConfigured() {
        final CSVFormat format = CSVFormat.newBuilder(',').withQuoteChar('\'').build();
        final Lexer lexer = lexerFor(format, "");

        assertTrue(lexer.isQuoteChar('\''));
        assertFalse(lexer.isQuoteChar('"'));
    }

    @Test
    public void testIsCommentStartWhenConfigured() {
        final CSVFormat format = CSVFormat.newBuilder(',').withCommentStart('#').build();
        final Lexer lexer = lexerFor(format, "");

        assertTrue(lexer.isCommentStart('#'));
        assertFalse(lexer.isCommentStart('!'));
    }

    @Test
    public void testIsCommentStartWhenDisabled() {
        final CSVFormat format = CSVFormat.newBuilder(',').build(); // no comment marker configured
        final Lexer lexer = lexerFor(format, "");

        assertFalse(lexer.isCommentStart('#'));
    }

    /**
     * Boundary case: when a feature (escape/quote/comment) is disabled, Lexer
     * represents that internally with the sentinel character '￾' (see
     * Lexer.DISABLED). If that exact character ever appears as real input,
     * the disabled feature should still not be considered "active" for it -
     * a disabled feature must never match any character coming from the data.
     */
    @Test
    public void testDisabledEscapeDoesNotMatchSentinelCharacter() {
        final CSVFormat format = CSVFormat.newBuilder(',').build(); // escape disabled
        final Lexer lexer = lexerFor(format, "");

        assertFalse("a disabled escape must not match any input character, "
                + "including the internal sentinel value", lexer.isEscape('￾'));
    }

    @Test
    public void testDisabledQuoteCharDoesNotMatchSentinelCharacter() {
        final CSVFormat format = CSVFormat.newBuilder(',').withQuoteChar(null).build(); // quote disabled
        final Lexer lexer = lexerFor(format, "");

        assertFalse("a disabled quote char must not match any input character, "
                + "including the internal sentinel value", lexer.isQuoteChar('￾'));
    }

    @Test
    public void testDisabledCommentStartDoesNotMatchSentinelCharacter() {
        final CSVFormat format = CSVFormat.newBuilder(',').build(); // comment disabled
        final Lexer lexer = lexerFor(format, "");

        assertFalse("a disabled comment marker must not match any input character, "
                + "including the internal sentinel value", lexer.isCommentStart('￾'));
    }
}
