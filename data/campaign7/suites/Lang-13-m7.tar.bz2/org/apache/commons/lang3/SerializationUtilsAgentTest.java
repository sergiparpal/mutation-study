/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;

/**
 * Self-contained unit tests for {@link org.apache.commons.lang3.SerializationUtils}.
 */
public class SerializationUtilsAgentTest {

    /**
     * Simple serializable fixture with an equals/hashCode implementation
     * so that cloned/deserialized instances can be compared by value.
     */
    static class SerializableFixture implements Serializable {
        private static final long serialVersionUID = 1L;
        private final String name;
        private final int value;

        SerializableFixture(String name, int value) {
            this.name = name;
            this.value = value;
        }

        String getName() {
            return name;
        }

        int getValue() {
            return value;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof SerializableFixture)) {
                return false;
            }
            SerializableFixture other = (SerializableFixture) obj;
            return value == other.value
                    && (name == null ? other.name == null : name.equals(other.name));
        }

        @Override
        public int hashCode() {
            return (name == null ? 0 : name.hashCode()) * 31 + value;
        }
    }

    /** Non-serializable fixture used to trigger serialization failures. */
    static class NotSerializableFixture {
        @SuppressWarnings("unused")
        private int x = 1;
    }

    /** Serializable fixture holding a non-serializable field. */
    static class BadlySerializableFixture implements Serializable {
        private static final long serialVersionUID = 1L;
        @SuppressWarnings("unused")
        private final NotSerializableFixture bad = new NotSerializableFixture();
    }

    private OutputStream brokenOutputStream() {
        return new OutputStream() {
            @Override
            public void write(int b) throws IOException {
                throw new IOException("broken stream");
            }
        };
    }

    // clone(T)
    //-----------------------------------------------------------------------

    @Test
    public void testCloneNull() {
        assertNull(SerializationUtils.clone(null));
    }

    @Test
    public void testCloneSimpleObject() {
        SerializableFixture original = new SerializableFixture("foo", 42);
        SerializableFixture cloned = SerializationUtils.clone(original);
        assertNotNull(cloned);
        assertNotSame(original, cloned);
        assertEquals(original, cloned);
        assertEquals("foo", cloned.getName());
        assertEquals(42, cloned.getValue());
    }

    @Test
    public void testCloneString() {
        String original = "hello world";
        String cloned = SerializationUtils.clone(original);
        assertEquals(original, cloned);
    }

    @Test
    public void testCloneHashMap() {
        HashMap<String, Integer> map = new HashMap<String, Integer>();
        map.put("a", 1);
        map.put("b", 2);
        HashMap<String, Integer> cloned = SerializationUtils.clone(map);
        assertNotSame(map, cloned);
        assertEquals(map, cloned);
        assertEquals(Integer.valueOf(1), cloned.get("a"));
        assertEquals(Integer.valueOf(2), cloned.get("b"));
    }

    @Test
    public void testCloneUnserializableThrows() {
        try {
            SerializationUtils.clone(new BadlySerializableFixture());
            fail("Expected SerializationException");
        } catch (SerializationException expected) {
            // expected
        }
    }

    // serialize(Serializable)
    //-----------------------------------------------------------------------

    @Test
    public void testSerializeToByteArrayAndBack() {
        SerializableFixture original = new SerializableFixture("bar", 7);
        byte[] bytes = SerializationUtils.serialize(original);
        assertNotNull(bytes);
        assertTrue(bytes.length > 0);
        Object result = SerializationUtils.deserialize(bytes);
        assertEquals(original, result);
    }

    @Test
    public void testSerializeNullObject() {
        byte[] bytes = SerializationUtils.serialize(null);
        assertNotNull(bytes);
        Object result = SerializationUtils.deserialize(bytes);
        assertNull(result);
    }

    @Test
    public void testSerializeUnserializableThrowsSerializationException() {
        try {
            SerializationUtils.serialize(new BadlySerializableFixture());
            fail("Expected SerializationException");
        } catch (SerializationException expected) {
            // expected
        }
    }

    // serialize(Serializable, OutputStream)
    //-----------------------------------------------------------------------

    @Test
    public void testSerializeToStreamNullStreamThrowsIllegalArgument() {
        try {
            SerializationUtils.serialize(new SerializableFixture("x", 1), null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    public void testSerializeToStreamIOExceptionWrapped() {
        try {
            SerializationUtils.serialize(new SerializableFixture("x", 1), brokenOutputStream());
            fail("Expected SerializationException");
        } catch (SerializationException expected) {
            assertTrue(expected.getCause() instanceof IOException);
        }
    }

    @Test
    public void testSerializeToStreamMatchesByteArrayForm() throws IOException {
        SerializableFixture original = new SerializableFixture("baz", 99);
        byte[] viaByteArray = SerializationUtils.serialize(original);

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        SerializationUtils.serialize(original, baos);
        byte[] viaStream = baos.toByteArray();

        assertArrayEquals(viaByteArray, viaStream);
    }

    // deserialize(InputStream)
    //-----------------------------------------------------------------------

    @Test
    public void testDeserializeNullInputStreamThrowsIllegalArgument() {
        try {
            SerializationUtils.deserialize((java.io.InputStream) null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    public void testDeserializeGarbageStreamThrowsSerializationException() {
        byte[] garbage = new byte[] { 1, 2, 3, 4, 5 };
        try {
            SerializationUtils.deserialize(new ByteArrayInputStream(garbage));
            fail("Expected SerializationException");
        } catch (SerializationException expected) {
            // expected
        }
    }

    @Test
    public void testDeserializeEmptyStreamThrowsSerializationException() {
        try {
            SerializationUtils.deserialize(new ByteArrayInputStream(new byte[0]));
            fail("Expected SerializationException");
        } catch (SerializationException expected) {
            // expected
        }
    }

    // deserialize(byte[])
    //-----------------------------------------------------------------------

    @Test
    public void testDeserializeNullByteArrayThrowsIllegalArgument() {
        try {
            SerializationUtils.deserialize((byte[]) null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    public void testDeserializeComplexObjectGraph() {
        List<SerializableFixture> list = new ArrayList<SerializableFixture>();
        list.add(new SerializableFixture("one", 1));
        list.add(new SerializableFixture("two", 2));

        byte[] bytes = SerializationUtils.serialize((Serializable) list);
        Object result = SerializationUtils.deserialize(bytes);

        assertTrue(result instanceof List);
        @SuppressWarnings("unchecked")
        List<SerializableFixture> resultList = (List<SerializableFixture>) result;
        assertEquals(2, resultList.size());
        assertEquals(list, resultList);
        assertFalse(resultList.get(0) == list.get(0));
    }

    @Test
    public void testDeserializeUnknownClassThrowsSerializationException() {
        byte[] bytes = buildSerializedFormOfUnresolvableClass();
        try {
            SerializationUtils.deserialize(bytes);
            fail("Expected SerializationException");
        } catch (SerializationException expected) {
            assertTrue(expected.getCause() instanceof ClassNotFoundException);
        }
    }

    /**
     * Builds valid serialized bytes for a class that cannot possibly be
     * resolved on the classpath, by patching the class name embedded in a
     * real serialized stream.
     */
    private byte[] buildSerializedFormOfUnresolvableClass() {
        byte[] bytes = SerializationUtils.serialize(new SerializableFixture("marker", 0));
        String marker = SerializableFixture.class.getName();
        String bogus = marker + "x";
        byte[] markerBytes = marker.getBytes();
        int index = -1;
        for (int i = 0; i <= bytes.length - markerBytes.length; i++) {
            boolean match = true;
            for (int j = 0; j < markerBytes.length; j++) {
                if (bytes[i + j] != markerBytes[j]) {
                    match = false;
                    break;
                }
            }
            if (match) {
                index = i;
                break;
            }
        }
        if (index < 0) {
            throw new IllegalStateException("marker class name not found in stream");
        }
        // The two bytes preceding the UTF class name encode its length
        // (big-endian short); growing the name by one char means growing
        // that length by one too, so the stream stays well-formed.
        byte[] patched = new byte[bytes.length + 1];
        System.arraycopy(bytes, 0, patched, 0, index);
        patched[index - 1] = (byte) (bytes[index - 1] + 1);
        byte[] bogusBytes = bogus.getBytes();
        System.arraycopy(bogusBytes, 0, patched, index, bogusBytes.length);
        System.arraycopy(bytes, index + markerBytes.length, patched,
                index + bogusBytes.length, bytes.length - (index + markerBytes.length));
        return patched;
    }

    // Round trip sanity
    //-----------------------------------------------------------------------

    @Test
    public void testCloneRoundTripPreservesEqualsButNotIdentity() {
        Map<String, String> original = new HashMap<String, String>();
        original.put("key", "value");
        Map<String, String> cloned = SerializationUtils.clone((HashMap<String, String>) original);
        assertEquals(original, cloned);
        assertTrue(original != cloned);
    }

    @Test
    public void testConstructorIsPublic() {
        // SerializationUtils instances should not normally be constructed,
        // but the no-arg constructor is public for JavaBean-style tools.
        SerializationUtils instance = new SerializationUtils();
        assertNotNull(instance);
    }
}
