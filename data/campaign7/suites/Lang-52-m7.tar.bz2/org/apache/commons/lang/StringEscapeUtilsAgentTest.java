/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

/**
 * Unit tests {@link org.apache.commons.lang.StringEscapeUtils}.
 */
public class StringEscapeUtilsAgentTest extends TestCase {

    public StringEscapeUtilsAgentTest(String name) {
        super(name);
    }

    public static void main(String[] args) {
        TestRunner.run(suite());
    }

    public static Test suite() {
        TestSuite suite = new TestSuite(StringEscapeUtilsAgentTest.class);
        suite.setName("StringEscapeUtils Tests");
        return suite;
    }

    //-----------------------------------------------------------------------
    public void testConstructor() {
        assertNotNull(new StringEscapeUtils());
    }

    //-----------------------------------------------------------------------
    // escapeJava / escapeJavaScript
    //-----------------------------------------------------------------------
    public void testEscapeJavaNull() {
        assertNull(StringEscapeUtils.escapeJava(null));
    }

    public void testEscapeJavaEmpty() {
        assertEquals("", StringEscapeUtils.escapeJava(""));
    }

    public void testEscapeJavaBasic() {
        assertEquals("He didn't say, \\\"Stop!\\\"",
                StringEscapeUtils.escapeJava("He didn't say, \"Stop!\""));
    }

    public void testEscapeJavaControlChars() {
        assertEquals("\\t\\n\\f\\r\\b", StringEscapeUtils.escapeJava("\t\n\f\r\b"));
    }

    public void testEscapeJavaBackslashAndSlash() {
        assertEquals("\\\\", StringEscapeUtils.escapeJava("\\"));
        assertEquals("\\/", StringEscapeUtils.escapeJava("/"));
    }

    public void testEscapeJavaSingleQuoteNotEscaped() {
        // Java strings do not need single quotes escaped, unlike JavaScript
        assertEquals("'", StringEscapeUtils.escapeJava("'"));
    }

    public void testEscapeJavaUnicode() {
        assertEquals("\\u1234", StringEscapeUtils.escapeJava("ሴ"));
    }

    public void testEscapeJavaScriptSingleQuoteEscaped() {
        assertEquals("\\'", StringEscapeUtils.escapeJavaScript("'"));
    }

    public void testEscapeJavaScriptNull() {
        assertNull(StringEscapeUtils.escapeJavaScript(null));
    }

    public void testEscapeJavaWriterNullWriter() throws IOException {
        try {
            StringEscapeUtils.escapeJava(null, "foo");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    public void testEscapeJavaWriterNullString() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.escapeJava(writer, null);
        assertEquals("", writer.toString());
    }

    public void testEscapeJavaWriterMatchesStringForm() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.escapeJava(writer, "a\tb'\"c\\d");
        assertEquals(StringEscapeUtils.escapeJava("a\tb'\"c\\d"), writer.toString());
    }

    public void testEscapeJavaScriptWriterNullWriter() {
        try {
            StringEscapeUtils.escapeJavaScript(null, "foo");
            fail("Expected IllegalArgumentException");
        } catch (IOException ioe) {
            fail("Expected IllegalArgumentException, got IOException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    //-----------------------------------------------------------------------
    // unescapeJava / unescapeJavaScript
    //-----------------------------------------------------------------------
    public void testUnescapeJavaNull() {
        assertNull(StringEscapeUtils.unescapeJava(null));
    }

    public void testUnescapeJavaEmpty() {
        assertEquals("", StringEscapeUtils.unescapeJava(""));
    }

    public void testUnescapeJavaBasic() {
        assertEquals("He didn't say, \"Stop!\"",
                StringEscapeUtils.unescapeJava("He didn't say, \\\"Stop!\\\""));
    }

    public void testUnescapeJavaControlChars() {
        assertEquals("\t\n\f\r\b", StringEscapeUtils.unescapeJava("\\t\\n\\f\\r\\b"));
    }

    public void testUnescapeJavaUnicode() {
        assertEquals("ሴ", StringEscapeUtils.unescapeJava("\\u1234"));
    }

    public void testUnescapeJavaInvalidUnicode() {
        try {
            StringEscapeUtils.unescapeJava("\\uZZZZ");
            fail("Expected NestableRuntimeException");
        } catch (RuntimeException ex) {
            // expected - unable to parse hex digits
        }
    }

    public void testUnescapeJavaTrailingBackslash() {
        // a backslash at the very end is emitted verbatim
        assertEquals("abc\\", StringEscapeUtils.unescapeJava("abc\\"));
    }

    public void testUnescapeJavaUnknownEscapeIsLiteral() {
        // an escape for a character with no special meaning is passed through as-is
        assertEquals("z", StringEscapeUtils.unescapeJava("\\z"));
    }

    public void testUnescapeJavaRoundTrip() {
        String original = "Tab:\t Quote:\" Back:\\ Unicode:☃";
        String escaped = StringEscapeUtils.escapeJava(original);
        assertEquals(original, StringEscapeUtils.unescapeJava(escaped));
    }

    public void testUnescapeJavaWriterNullWriter() {
        try {
            StringEscapeUtils.unescapeJava(null, "foo");
            fail("Expected IllegalArgumentException");
        } catch (IOException ioe) {
            fail("Expected IllegalArgumentException, got IOException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    public void testUnescapeJavaWriterNullString() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.unescapeJava(writer, null);
        assertEquals("", writer.toString());
    }

    public void testUnescapeJavaScript() {
        assertEquals("He didn't say, \"Stop!\"",
                StringEscapeUtils.unescapeJavaScript("He didn\\'t say, \\\"Stop!\\\""));
    }

    public void testUnescapeJavaScriptNull() {
        assertNull(StringEscapeUtils.unescapeJavaScript(null));
    }

    public void testUnescapeJavaScriptWriter() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.unescapeJavaScript(writer, "\\'foo\\'");
        assertEquals("'foo'", writer.toString());
    }

    //-----------------------------------------------------------------------
    // escapeHtml / unescapeHtml
    //-----------------------------------------------------------------------
    public void testEscapeHtmlNull() {
        assertNull(StringEscapeUtils.escapeHtml(null));
    }

    public void testEscapeHtmlEmpty() {
        assertEquals("", StringEscapeUtils.escapeHtml(""));
    }

    public void testEscapeHtmlBasic() {
        assertEquals("&quot;bread&quot; &amp; &quot;butter&quot;",
                StringEscapeUtils.escapeHtml("\"bread\" & \"butter\""));
    }

    public void testEscapeHtmlNoSpecialChars() {
        assertEquals("plain text 123", StringEscapeUtils.escapeHtml("plain text 123"));
    }

    public void testEscapeHtmlApostropheNotEscaped() {
        // &apos; is not a legal HTML 4.0 entity, so it is not used
        assertEquals("McHale's Navy", StringEscapeUtils.escapeHtml("McHale's Navy"));
    }

    public void testEscapeHtmlWriterNullWriter() {
        try {
            StringEscapeUtils.escapeHtml(null, "foo");
            fail("Expected IllegalArgumentException");
        } catch (IOException ioe) {
            fail("Expected IllegalArgumentException, got IOException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    public void testEscapeHtmlWriterNullString() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.escapeHtml(writer, null);
        assertEquals("", writer.toString());
    }

    public void testUnescapeHtmlNull() {
        assertNull(StringEscapeUtils.unescapeHtml(null));
    }

    public void testUnescapeHtmlEmpty() {
        assertEquals("", StringEscapeUtils.unescapeHtml(""));
    }

    public void testUnescapeHtmlBasic() {
        assertEquals("<Français>", StringEscapeUtils.unescapeHtml("&lt;Fran&ccedil;ais&gt;"));
    }

    public void testUnescapeHtmlUnknownEntityLeftAlone() {
        assertEquals(">&zzzz;x", StringEscapeUtils.unescapeHtml("&gt;&zzzz;x"));
    }

    public void testUnescapeHtmlNumericEntity() {
        assertEquals("A", StringEscapeUtils.unescapeHtml("&#65;"));
    }

    public void testUnescapeHtmlWriterNullWriter() {
        try {
            StringEscapeUtils.unescapeHtml(null, "foo");
            fail("Expected IllegalArgumentException");
        } catch (IOException ioe) {
            fail("Expected IllegalArgumentException, got IOException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    public void testUnescapeHtmlWriterNullString() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.unescapeHtml(writer, null);
        assertEquals("", writer.toString());
    }

    public void testEscapeUnescapeHtmlRoundTrip() {
        String original = "<a href=\"test\">\"quote\" & 'apos'</a>";
        String escaped = StringEscapeUtils.escapeHtml(original);
        assertEquals(original, StringEscapeUtils.unescapeHtml(escaped));
    }

    //-----------------------------------------------------------------------
    // escapeXml / unescapeXml
    //-----------------------------------------------------------------------
    public void testEscapeXmlNull() {
        assertNull(StringEscapeUtils.escapeXml(null));
    }

    public void testEscapeXmlEmpty() {
        assertEquals("", StringEscapeUtils.escapeXml(""));
    }

    public void testEscapeXmlBasic() {
        assertEquals("&quot;bread&quot; &amp; &quot;butter&quot;",
                StringEscapeUtils.escapeXml("\"bread\" & \"butter\""));
    }

    public void testEscapeXmlApostrophe() {
        // XML supports &apos; unlike HTML
        assertEquals("McHale&apos;s Navy", StringEscapeUtils.escapeXml("McHale's Navy"));
    }

    public void testEscapeXmlLtGt() {
        assertEquals("&lt;tag&gt;", StringEscapeUtils.escapeXml("<tag>"));
    }

    public void testEscapeXmlWriterNullWriter() {
        try {
            StringEscapeUtils.escapeXml(null, "foo");
            fail("Expected IllegalArgumentException");
        } catch (IOException ioe) {
            fail("Expected IllegalArgumentException, got IOException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    public void testEscapeXmlWriterNullString() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.escapeXml(writer, null);
        assertEquals("", writer.toString());
    }

    public void testUnescapeXmlNull() {
        assertNull(StringEscapeUtils.unescapeXml(null));
    }

    public void testUnescapeXmlEmpty() {
        assertEquals("", StringEscapeUtils.unescapeXml(""));
    }

    public void testUnescapeXmlBasic() {
        assertEquals("<Français>", StringEscapeUtils.unescapeXml("&lt;Fran&#231;ais&gt;"));
    }

    public void testUnescapeXmlApostrophe() {
        assertEquals("'", StringEscapeUtils.unescapeXml("&apos;"));
    }

    public void testUnescapeXmlWriterNullWriter() {
        try {
            StringEscapeUtils.unescapeXml(null, "foo");
            fail("Expected IllegalArgumentException");
        } catch (IOException ioe) {
            fail("Expected IllegalArgumentException, got IOException");
        } catch (IllegalArgumentException ex) {
            // expected
        }
    }

    public void testUnescapeXmlWriterNullString() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.unescapeXml(writer, null);
        assertEquals("", writer.toString());
    }

    public void testEscapeUnescapeXmlRoundTrip() {
        String original = "<tag attr=\"val\">Français's \"quote\" & more</tag>";
        String escaped = StringEscapeUtils.escapeXml(original);
        assertEquals(original, StringEscapeUtils.unescapeXml(escaped));
    }

    //-----------------------------------------------------------------------
    // escapeSql
    //-----------------------------------------------------------------------
    public void testEscapeSqlNull() {
        assertNull(StringEscapeUtils.escapeSql(null));
    }

    public void testEscapeSqlEmpty() {
        assertEquals("", StringEscapeUtils.escapeSql(""));
    }

    public void testEscapeSqlNoQuotes() {
        assertEquals("plain", StringEscapeUtils.escapeSql("plain"));
    }

    public void testEscapeSqlSingleQuote() {
        assertEquals("McHale''s Navy", StringEscapeUtils.escapeSql("McHale's Navy"));
    }

    public void testEscapeSqlMultipleQuotes() {
        assertEquals("''''", StringEscapeUtils.escapeSql("''"));
    }
}
