/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.cli;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Comparator;

import junit.framework.TestCase;

/**
 * Self-contained tests for {@link HelpFormatter}.
 */
public class HelpFormatterAgentTest extends TestCase
{
    private final String eol = System.getProperty("line.separator");

    private String render(HelpFormatter hf, int width, int tabStop, String text)
    {
        StringBuffer sb = new StringBuffer();
        hf.renderWrappedText(sb, width, tabStop, text);
        return sb.toString();
    }

    // ---------------------------------------------------------- defaults

    public void testConstants()
    {
        assertEquals(74, HelpFormatter.DEFAULT_WIDTH);
        assertEquals(1, HelpFormatter.DEFAULT_LEFT_PAD);
        assertEquals(3, HelpFormatter.DEFAULT_DESC_PAD);
        assertEquals("usage: ", HelpFormatter.DEFAULT_SYNTAX_PREFIX);
        assertEquals("-", HelpFormatter.DEFAULT_OPT_PREFIX);
        assertEquals("--", HelpFormatter.DEFAULT_LONG_OPT_PREFIX);
        assertEquals(" ", HelpFormatter.DEFAULT_LONG_OPT_SEPARATOR);
        assertEquals("arg", HelpFormatter.DEFAULT_ARG_NAME);
    }

    public void testDefaultGetters()
    {
        HelpFormatter hf = new HelpFormatter();
        assertEquals(HelpFormatter.DEFAULT_WIDTH, hf.getWidth());
        assertEquals(HelpFormatter.DEFAULT_LEFT_PAD, hf.getLeftPadding());
        assertEquals(HelpFormatter.DEFAULT_DESC_PAD, hf.getDescPadding());
        assertEquals(HelpFormatter.DEFAULT_SYNTAX_PREFIX, hf.getSyntaxPrefix());
        assertEquals(HelpFormatter.DEFAULT_OPT_PREFIX, hf.getOptPrefix());
        assertEquals(HelpFormatter.DEFAULT_LONG_OPT_PREFIX, hf.getLongOptPrefix());
        assertEquals(HelpFormatter.DEFAULT_LONG_OPT_SEPARATOR, hf.getLongOptSeparator());
        assertEquals(HelpFormatter.DEFAULT_ARG_NAME, hf.getArgName());
        assertEquals(System.getProperty("line.separator"), hf.getNewLine());
        assertNotNull(hf.getOptionComparator());
    }

    // ---------------------------------------------------------- setters/getters

    public void testSetWidth()
    {
        HelpFormatter hf = new HelpFormatter();
        hf.setWidth(40);
        assertEquals(40, hf.getWidth());
    }

    public void testSetLeftPadding()
    {
        HelpFormatter hf = new HelpFormatter();
        hf.setLeftPadding(5);
        assertEquals(5, hf.getLeftPadding());
    }

    public void testSetDescPadding()
    {
        HelpFormatter hf = new HelpFormatter();
        hf.setDescPadding(7);
        assertEquals(7, hf.getDescPadding());
    }

    public void testSetSyntaxPrefix()
    {
        HelpFormatter hf = new HelpFormatter();
        hf.setSyntaxPrefix("call: ");
        assertEquals("call: ", hf.getSyntaxPrefix());
    }

    public void testSetNewLine()
    {
        HelpFormatter hf = new HelpFormatter();
        hf.setNewLine("\n");
        assertEquals("\n", hf.getNewLine());
    }

    public void testSetOptPrefix()
    {
        HelpFormatter hf = new HelpFormatter();
        hf.setOptPrefix("+");
        assertEquals("+", hf.getOptPrefix());
    }

    public void testSetLongOptPrefix()
    {
        HelpFormatter hf = new HelpFormatter();
        hf.setLongOptPrefix("++");
        assertEquals("++", hf.getLongOptPrefix());
    }

    public void testSetLongOptSeparator()
    {
        HelpFormatter hf = new HelpFormatter();
        hf.setLongOptSeparator("=");
        assertEquals("=", hf.getLongOptSeparator());
    }

    public void testSetArgName()
    {
        HelpFormatter hf = new HelpFormatter();
        hf.setArgName("value");
        assertEquals("value", hf.getArgName());
    }

    public void testSetOptionComparatorCustom()
    {
        HelpFormatter hf = new HelpFormatter();
        Comparator reverse = new Comparator()
        {
            public int compare(Object o1, Object o2)
            {
                Option opt1 = (Option) o1;
                Option opt2 = (Option) o2;
                return opt2.getKey().compareToIgnoreCase(opt1.getKey());
            }
        };
        hf.setOptionComparator(reverse);
        assertSame(reverse, hf.getOptionComparator());
    }

    public void testSetOptionComparatorNullResetsToDefault()
    {
        HelpFormatter hf = new HelpFormatter();
        Comparator original = hf.getOptionComparator();

        hf.setOptionComparator(new Comparator()
        {
            public int compare(Object o1, Object o2)
            {
                return 0;
            }
        });
        hf.setOptionComparator(null);

        Comparator afterReset = hf.getOptionComparator();
        assertNotNull(afterReset);
        assertFalse(afterReset == original);

        // default comparator sorts by key, case-insensitively
        Option a = new Option("a", "aaa");
        Option b = new Option("B", "bbb");
        assertTrue(afterReset.compare(a, b) < 0);
    }

    public void testDefaultOptionComparatorIsCaseInsensitive() throws Exception
    {
        HelpFormatter hf = new HelpFormatter();
        Comparator cmp = hf.getOptionComparator();

        Option lower = new Option("a", "desc a");
        Option upper = new Option("B", "desc b");

        assertTrue(cmp.compare(lower, upper) < 0);
        assertTrue(cmp.compare(upper, lower) > 0);
        assertEquals(0, cmp.compare(lower, new Option("a", "other description")));
    }

    // ---------------------------------------------------------- createPadding

    public void testCreatePaddingZero()
    {
        HelpFormatter hf = new HelpFormatter();
        assertEquals("", hf.createPadding(0));
    }

    public void testCreatePaddingPositive()
    {
        HelpFormatter hf = new HelpFormatter();
        assertEquals("     ", hf.createPadding(5));
        assertEquals(5, hf.createPadding(5).length());
        assertEquals(" ", hf.createPadding(1));
    }

    public void testCreatePaddingNegativeThrows()
    {
        HelpFormatter hf = new HelpFormatter();
        try
        {
            hf.createPadding(-1);
            fail("expected an exception for a negative padding length");
        }
        catch (NegativeArraySizeException e)
        {
            // expected: a negative length cannot be used to build the padding
        }
    }

    // ---------------------------------------------------------- rtrim

    public void testRtrimNull()
    {
        HelpFormatter hf = new HelpFormatter();
        assertNull(hf.rtrim(null));
    }

    public void testRtrimEmpty()
    {
        HelpFormatter hf = new HelpFormatter();
        assertEquals("", hf.rtrim(""));
    }

    public void testRtrimTrailingWhitespace()
    {
        HelpFormatter hf = new HelpFormatter();
        assertEquals("abc", hf.rtrim("abc   "));
        assertEquals("abc", hf.rtrim("abc\t\t"));
    }

    public void testRtrimNoTrailingWhitespace()
    {
        HelpFormatter hf = new HelpFormatter();
        assertEquals("abc", hf.rtrim("abc"));
    }

    public void testRtrimAllWhitespace()
    {
        HelpFormatter hf = new HelpFormatter();
        assertEquals("", hf.rtrim("   "));
    }

    public void testRtrimLeadingWhitespacePreserved()
    {
        HelpFormatter hf = new HelpFormatter();
        assertEquals("  abc", hf.rtrim("  abc  "));
    }

    // ---------------------------------------------------------- findWrapPos

    public void testFindWrapPosTextShorterThanWidthReturnsMinusOne()
    {
        HelpFormatter hf = new HelpFormatter();
        assertEquals(-1, hf.findWrapPos("hello", 10, 0));
    }

    public void testFindWrapPosTextExactlyWidthReturnsMinusOne()
    {
        HelpFormatter hf = new HelpFormatter();
        assertEquals(-1, hf.findWrapPos("hello", 5, 0));
    }

    public void testFindWrapPosFindsLastWhitespaceBeforeLimit()
    {
        HelpFormatter hf = new HelpFormatter();
        // "hello world" indices: 0-4 "hello", 5 ' ', 6-10 "world"
        // startPos + width = 0 + 8 = 8 -> scanning back from index 8 ('r')
        // the last whitespace at or before index 8 is index 5
        assertEquals(5, hf.findWrapPos("hello world", 8, 0));
    }

    public void testFindWrapPosRespectsNewline()
    {
        HelpFormatter hf = new HelpFormatter();
        // a newline before the width limit forces a wrap right after it
        int pos = hf.findWrapPos("ab\ncdefghij", 20, 0);
        assertEquals(3, pos);
    }

    public void testFindWrapPosRespectsTab()
    {
        HelpFormatter hf = new HelpFormatter();
        int pos = hf.findWrapPos("ab\tcdefghij", 20, 0);
        assertEquals(3, pos);
    }

    public void testFindWrapPosNoWhitespaceAnywhereInText()
    {
        HelpFormatter hf = new HelpFormatter();
        // "abcdefghij" has no whitespace at all; findWrapPos must not throw
        // and, per its contract, must not read past the end of the string.
        int pos = hf.findWrapPos("abcdefghij", 4, 0);
        assertTrue("wrap position must be a valid index into the text or -1, but was " + pos,
                   pos == -1 || (pos >= 0 && pos <= 10));
    }

    // ---------------------------------------------------------- renderWrappedText

    public void testRenderWrappedTextShortTextUnchanged()
    {
        HelpFormatter hf = new HelpFormatter();
        String result = render(hf, 74, 0, "short text");
        assertEquals("short text", result);
    }

    public void testRenderWrappedTextWrapsLongLines()
    {
        HelpFormatter hf = new HelpFormatter();
        String text = "aaaaa bbbbb ccccc ddddd eeeee fffff ggggg hhhhh iiiii jjjjj";
        String result = render(hf, 20, 0, text);

        String[] lines = result.split(eol);
        for (int i = 0; i < lines.length; i++)
        {
            assertTrue("line too long: [" + lines[i] + "]", lines[i].length() <= 20);
        }
        // re-joining the words from every line must reproduce the original text
        assertEquals(text, result.replaceAll(eol, " ").replaceAll(" +", " ").trim());
    }

    public void testRenderWrappedTextAppliesNextLineTabStop()
    {
        HelpFormatter hf = new HelpFormatter();
        String text = "aaaaa bbbbb ccccc ddddd eeeee";
        String result = render(hf, 15, 4, text);
        String[] lines = result.split(eol);
        assertTrue(lines.length > 1);
        // every continuation line must start with the tab-stop padding
        for (int i = 1; i < lines.length; i++)
        {
            assertTrue("line [" + lines[i] + "] should start with 4 spaces of padding",
                       lines[i].startsWith("    "));
        }
    }

    // ---------------------------------------------------------- printWrapped

    public void testPrintWrapped()
    {
        HelpFormatter hf = new HelpFormatter();
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);

        hf.printWrapped(pw, 74, "simple text");
        pw.flush();

        assertEquals("simple text" + eol, sw.toString());
    }

    // ---------------------------------------------------------- printUsage

    public void testPrintUsageSimple() throws Exception
    {
        HelpFormatter hf = new HelpFormatter();
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);

        hf.printUsage(pw, 74, "myapp");
        pw.flush();

        assertEquals("usage: myapp" + eol, sw.toString());
    }

    public void testPrintUsageWithOptions() throws Exception
    {
        HelpFormatter hf = new HelpFormatter();
        Options options = new Options();
        options.addOption("a", false, "toggle a");
        options.addOption("b", true, "value of b");

        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        hf.printUsage(pw, 74, "myapp", options);
        pw.flush();

        String result = sw.toString();
        assertTrue(result.startsWith("usage: myapp "));
        assertTrue(result.indexOf("[-a]") >= 0);
        assertTrue(result.indexOf("[-b <arg>]") >= 0);
    }

    public void testPrintUsageRequiredOptionHasNoBrackets() throws Exception
    {
        HelpFormatter hf = new HelpFormatter();
        Options options = new Options();
        Option required = new Option("r", false, "required option");
        required.setRequired(true);
        options.addOption(required);

        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        hf.printUsage(pw, 74, "myapp", options);
        pw.flush();

        String result = sw.toString();
        assertTrue(result.indexOf("-r") >= 0);
        assertFalse(result.indexOf("[-r]") >= 0);
    }

    public void testPrintUsageOptionGroupRequired() throws Exception
    {
        HelpFormatter hf = new HelpFormatter();
        OptionGroup group = new OptionGroup();
        group.addOption(new Option("x", false, "option x"));
        group.addOption(new Option("y", false, "option y"));
        group.setRequired(true);

        Options options = new Options();
        options.addOptionGroup(group);

        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        hf.printUsage(pw, 74, "myapp", options);
        pw.flush();

        String result = sw.toString();
        assertTrue(result.indexOf("-x") >= 0);
        assertTrue(result.indexOf("-y") >= 0);
        assertTrue(result.indexOf(" | ") >= 0);
        // the group as a whole is required, so it must not be wrapped in brackets
        assertFalse(result.indexOf("[") >= 0);
    }

    public void testPrintUsageOptionGroupOptional() throws Exception
    {
        HelpFormatter hf = new HelpFormatter();
        OptionGroup group = new OptionGroup();
        group.addOption(new Option("x", false, "option x"));
        group.addOption(new Option("y", false, "option y"));
        group.setRequired(false);

        Options options = new Options();
        options.addOptionGroup(group);

        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        hf.printUsage(pw, 74, "myapp", options);
        pw.flush();

        String result = sw.toString();
        assertTrue(result.indexOf("[-x | -y]") >= 0);
    }

    // ---------------------------------------------------------- printOptions / renderOptions

    public void testPrintOptionsContainsDescriptions() throws Exception
    {
        HelpFormatter hf = new HelpFormatter();
        Options options = new Options();
        options.addOption("a", false, "toggle a");
        options.addOption("b", true, "the value of b");

        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        hf.printOptions(pw, 74, options, 1, 3);
        pw.flush();

        String result = sw.toString();
        assertTrue(result.indexOf("-a") >= 0);
        assertTrue(result.indexOf("toggle a") >= 0);
        assertTrue(result.indexOf("-b") >= 0);
        assertTrue(result.indexOf("the value of b") >= 0);
    }

    public void testRenderOptionsOrdersByComparator() throws Exception
    {
        HelpFormatter hf = new HelpFormatter();
        Options options = new Options();
        options.addOption("z", false, "zzz option");
        options.addOption("a", false, "aaa option");

        StringBuffer sb = new StringBuffer();
        hf.renderOptions(sb, 74, options, 1, 3);
        String result = sb.toString();

        assertTrue("-a should be rendered before -z", result.indexOf("-a") < result.indexOf("-z"));
    }

    public void testRenderOptionsLeftPadding() throws Exception
    {
        HelpFormatter hf = new HelpFormatter();
        Options options = new Options();
        options.addOption("a", false, "desc");

        StringBuffer sb = new StringBuffer();
        hf.renderOptions(sb, 74, options, 4, 3);
        String result = sb.toString();

        assertTrue(result.startsWith("    -a"));
    }

    public void testRenderOptionsWithLongOpt() throws Exception
    {
        HelpFormatter hf = new HelpFormatter();
        Options options = new Options();
        options.addOption("a", "aaa", true, "desc for aaa");

        StringBuffer sb = new StringBuffer();
        hf.renderOptions(sb, 74, options, 1, 3);
        String result = sb.toString();

        assertTrue(result.indexOf("-a,--aaa") >= 0);
        assertTrue(result.indexOf("<arg>") >= 0);
        assertTrue(result.indexOf("desc for aaa") >= 0);
    }

    public void testRenderOptionsCustomArgName() throws Exception
    {
        HelpFormatter hf = new HelpFormatter();
        Options options = new Options();
        Option opt = new Option("f", true, "input file");
        opt.setArgName("file");
        options.addOption(opt);

        StringBuffer sb = new StringBuffer();
        hf.renderOptions(sb, 74, options, 1, 3);
        String result = sb.toString();

        assertTrue(result.indexOf("<file>") >= 0);
    }

    // ---------------------------------------------------------- printHelp

    public void testPrintHelpThrowsOnNullSyntax()
    {
        HelpFormatter hf = new HelpFormatter();
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        Options options = new Options();

        try
        {
            hf.printHelp(pw, 74, null, null, options, 1, 3, null, false);
            fail("expected IllegalArgumentException for a null cmdLineSyntax");
        }
        catch (IllegalArgumentException e)
        {
            // expected
        }
    }

    public void testPrintHelpThrowsOnEmptySyntax()
    {
        HelpFormatter hf = new HelpFormatter();
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        Options options = new Options();

        try
        {
            hf.printHelp(pw, 74, "", null, options, 1, 3, null, false);
            fail("expected IllegalArgumentException for an empty cmdLineSyntax");
        }
        catch (IllegalArgumentException e)
        {
            // expected
        }
    }

    public void testPrintHelpFullOutput() throws Exception
    {
        HelpFormatter hf = new HelpFormatter();
        Options options = new Options();
        options.addOption("a", false, "toggle a");

        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);

        hf.printHelp(pw, 74, "myapp", "a header", options, 1, 3, "a footer", false);
        pw.flush();

        String result = sw.toString();
        assertTrue(result.indexOf("usage: myapp") >= 0);
        assertTrue(result.indexOf("a header") >= 0);
        assertTrue(result.indexOf("-a") >= 0);
        assertTrue(result.indexOf("toggle a") >= 0);
        assertTrue(result.indexOf("a footer") >= 0);
    }

    public void testPrintHelpSkipsBlankHeaderAndFooter() throws Exception
    {
        HelpFormatter hf = new HelpFormatter();
        Options options = new Options();
        options.addOption("a", false, "toggle a");

        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);

        hf.printHelp(pw, 74, "myapp", "   ", options, 1, 3, "   ", false);
        pw.flush();

        String result = sw.toString();
        // only the usage line and the options should be present
        String[] lines = result.split(eol);
        assertEquals(2, lines.length);
    }

    public void testPrintHelpAutoUsageAppendsOptionSyntax() throws Exception
    {
        HelpFormatter hf = new HelpFormatter();
        Options options = new Options();
        options.addOption("a", false, "toggle a");

        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);

        hf.printHelp(pw, 74, "myapp", null, options, 1, 3, null, true);
        pw.flush();

        String result = sw.toString();
        assertTrue(result.indexOf("[-a]") >= 0);
    }

    public void testPrintHelpNoAutoUsageOmitsOptionSyntax() throws Exception
    {
        HelpFormatter hf = new HelpFormatter();
        Options options = new Options();
        options.addOption("a", false, "toggle a");

        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);

        hf.printHelp(pw, 74, "myapp", null, options, 1, 3, null, false);
        pw.flush();

        String result = sw.toString();
        String[] lines = result.split(eol);
        // the first (usage) line must not contain the option syntax
        assertFalse(lines[0].indexOf("[-a]") >= 0);
    }
}
