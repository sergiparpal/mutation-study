package org.apache.commons.lang;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Self-contained tests for {@link org.apache.commons.lang.StringEscapeUtils}.
 */
public class StringEscapeUtilsAgentTest extends TestCase {

    public StringEscapeUtilsAgentTest(String name) {
        super(name);
    }

    public static Test suite() {
        return new TestSuite(StringEscapeUtilsAgentTest.class);
    }

    //----------------------------------------------------------------------
    // escapeJava / escapeJava(Writer, String)
    //----------------------------------------------------------------------

    public void testEscapeJavaNull() {
        assertNull(StringEscapeUtils.escapeJava(null));
    }

    public void testEscapeJavaEmpty() {
        assertEquals("", StringEscapeUtils.escapeJava(""));
    }

    public void testEscapeJavaBasic() {
        assertEquals("He didn't say, \\\"Stop!\\\"",
                StringEscapeUtils.escapeJava("He didn't say, \"Stop!\""));
    }

    public void testEscapeJavaControlChars() {
        assertEquals("\\t", StringEscapeUtils.escapeJava("\t"));
        assertEquals("\\n", StringEscapeUtils.escapeJava("\n"));
        assertEquals("\\r", StringEscapeUtils.escapeJava("\r"));
        assertEquals("\\f", StringEscapeUtils.escapeJava("\f"));
        assertEquals("\\b", StringEscapeUtils.escapeJava("\b"));
        assertEquals("\\\\", StringEscapeUtils.escapeJava("\\"));
    }

    public void testEscapeJavaDoesNotEscapeSingleQuote() {
        // Java strings do not need single quotes escaped, unlike JavaScript.
        assertEquals("it's", StringEscapeUtils.escapeJava("it's"));
    }

    public void testEscapeJavaUnicode() {
        // character above 0xff should become a full \\u escape, upper-case hex.
        assertEquals("\\u2026", StringEscapeUtils.escapeJava("…"));
    }

    public void testEscapeJavaWriterNullWriterThrows() {
        try {
            StringEscapeUtils.escapeJava((Writer) null, "abc");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        } catch (IOException e) {
            fail("Expected IllegalArgumentException, got IOException: " + e);
        }
    }

    public void testEscapeJavaWriterNullStringIsNoOp() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.escapeJava(writer, null);
        assertEquals("", writer.toString());
    }

    //----------------------------------------------------------------------
    // escapeJavaScript
    //----------------------------------------------------------------------

    public void testEscapeJavaScriptNull() {
        assertNull(StringEscapeUtils.escapeJavaScript(null));
    }

    public void testEscapeJavaScriptEscapesSingleQuote() {
        // Unlike escapeJava, JavaScript needs the single quote escaped too.
        assertEquals("He didn\\'t say, \\\"Stop!\\\"",
                StringEscapeUtils.escapeJavaScript("He didn't say, \"Stop!\""));
    }

    public void testEscapeJavaScriptWriterNullWriterThrows() {
        try {
            StringEscapeUtils.escapeJavaScript((Writer) null, "abc");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        } catch (IOException e) {
            fail("Expected IllegalArgumentException, got IOException: " + e);
        }
    }

    //----------------------------------------------------------------------
    // unescapeJava / unescapeJava(Writer, String)
    //----------------------------------------------------------------------

    public void testUnescapeJavaNull() {
        assertNull(StringEscapeUtils.unescapeJava(null));
    }

    public void testUnescapeJavaEmpty() {
        assertEquals("", StringEscapeUtils.unescapeJava(""));
    }

    public void testUnescapeJavaBasic() {
        assertEquals("\t", StringEscapeUtils.unescapeJava("\\t"));
        assertEquals("\n", StringEscapeUtils.unescapeJava("\\n"));
        assertEquals("\r", StringEscapeUtils.unescapeJava("\\r"));
        assertEquals("\f", StringEscapeUtils.unescapeJava("\\f"));
        assertEquals("\b", StringEscapeUtils.unescapeJava("\\b"));
        assertEquals("'", StringEscapeUtils.unescapeJava("\\'"));
        assertEquals("\"", StringEscapeUtils.unescapeJava("\\\""));
        assertEquals("\\", StringEscapeUtils.unescapeJava("\\\\"));
    }

    public void testUnescapeJavaRoundTrip() {
        String original = "He didn't say, \"Stop!\"\t\n";
        String escaped = StringEscapeUtils.escapeJava(original);
        assertEquals(original, StringEscapeUtils.unescapeJava(escaped));
    }

    public void testUnescapeJavaUnicode() {
        assertEquals("…", StringEscapeUtils.unescapeJava("\\u2026"));
        assertEquals("A", StringEscapeUtils.unescapeJava("\\u0041"));
    }

    public void testUnescapeJavaTrailingBackslashIsKept() {
        // a lone backslash at the end of the string is output as-is per the javadoc.
        assertEquals("abc\\", StringEscapeUtils.unescapeJava("abc\\"));
    }

    public void testUnescapeJavaUnknownEscapePassesCharThrough() {
        // an escape sequence the method does not recognise is written out verbatim.
        assertEquals("z", StringEscapeUtils.unescapeJava("\\z"));
    }

    public void testUnescapeJavaInvalidUnicodeThrows() {
        try {
            StringEscapeUtils.unescapeJava("\\uZZZZ");
            fail("Expected an exception for invalid unicode digits");
        } catch (RuntimeException expected) {
            // NestableRuntimeException wraps the NumberFormatException; expected.
        }
    }

    public void testUnescapeJavaWriterNullWriterThrows() {
        try {
            StringEscapeUtils.unescapeJava((Writer) null, "abc");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        } catch (IOException e) {
            fail("Expected IllegalArgumentException, got IOException: " + e);
        }
    }

    public void testUnescapeJavaWriterNullStringIsNoOp() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.unescapeJava(writer, null);
        assertEquals("", writer.toString());
    }

    //----------------------------------------------------------------------
    // unescapeJavaScript
    //----------------------------------------------------------------------

    public void testUnescapeJavaScriptDelegatesToUnescapeJava() {
        assertEquals(StringEscapeUtils.unescapeJava("\\t\\n"),
                StringEscapeUtils.unescapeJavaScript("\\t\\n"));
        assertNull(StringEscapeUtils.unescapeJavaScript(null));
    }

    //----------------------------------------------------------------------
    // escapeHtml / escapeHtml(Writer, String)
    //----------------------------------------------------------------------

    public void testEscapeHtmlNull() {
        assertNull(StringEscapeUtils.escapeHtml(null));
    }

    public void testEscapeHtmlEmpty() {
        assertEquals("", StringEscapeUtils.escapeHtml(""));
    }

    public void testEscapeHtmlBasic() {
        assertEquals("&quot;bread&quot; &amp; &quot;butter&quot;",
                StringEscapeUtils.escapeHtml("\"bread\" & \"butter\""));
    }

    public void testEscapeHtmlLtGt() {
        assertEquals("&lt;foo&gt;", StringEscapeUtils.escapeHtml("<foo>"));
    }

    public void testEscapeHtmlApostropheIsNotEscaped() {
        // The javadoc explicitly says &apos; is not a legal HTML entity and so
        // apostrophes are left untouched.
        assertEquals("it's", StringEscapeUtils.escapeHtml("it's"));
    }

    public void testEscapeHtmlWriterNullWriterThrows() {
        try {
            StringEscapeUtils.escapeHtml((Writer) null, "abc");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        } catch (IOException e) {
            fail("Expected IllegalArgumentException, got IOException: " + e);
        }
    }

    public void testEscapeHtmlWriterNullStringIsNoOp() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.escapeHtml(writer, null);
        assertEquals("", writer.toString());
    }

    //----------------------------------------------------------------------
    // unescapeHtml / unescapeHtml(Writer, String)
    //----------------------------------------------------------------------

    public void testUnescapeHtmlNull() {
        assertNull(StringEscapeUtils.unescapeHtml(null));
    }

    public void testUnescapeHtmlBasic() {
        assertEquals("<Français>", StringEscapeUtils.unescapeHtml("&lt;Fran&ccedil;ais&gt;"));
    }

    public void testUnescapeHtmlUnrecognizedEntityPassesThrough() {
        assertEquals(">&zzzz;x", StringEscapeUtils.unescapeHtml("&gt;&zzzz;x"));
    }

    public void testUnescapeHtmlNumericEntity() {
        assertEquals("A", StringEscapeUtils.unescapeHtml("&#65;"));
    }

    public void testUnescapeHtmlWriterNullWriterThrows() {
        try {
            StringEscapeUtils.unescapeHtml((Writer) null, "abc");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        } catch (IOException e) {
            fail("Expected IllegalArgumentException, got IOException: " + e);
        }
    }

    public void testUnescapeHtmlWriterNullStringIsNoOp() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.unescapeHtml(writer, null);
        assertEquals("", writer.toString());
    }

    //----------------------------------------------------------------------
    // escapeXml / unescapeXml
    //----------------------------------------------------------------------

    public void testEscapeXmlNull() {
        assertNull(StringEscapeUtils.escapeXml(null));
    }

    public void testEscapeXmlBasic() {
        assertEquals("&quot;bread&quot; &amp; &quot;butter&quot;",
                StringEscapeUtils.escapeXml("\"bread\" & \"butter\""));
    }

    public void testEscapeXmlApostropheIsEscaped() {
        // Unlike HTML, XML does support &apos; as a legal entity.
        assertEquals("it&apos;s", StringEscapeUtils.escapeXml("it's"));
    }

    public void testEscapeXmlLtGt() {
        assertEquals("&lt;a&gt;", StringEscapeUtils.escapeXml("<a>"));
    }

    public void testEscapeXmlWriterNullWriterThrows() {
        try {
            StringEscapeUtils.escapeXml((Writer) null, "abc");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        } catch (IOException e) {
            fail("Expected IllegalArgumentException, got IOException: " + e);
        }
    }

    public void testEscapeXmlWriterNullStringIsNoOp() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.escapeXml(writer, null);
        assertEquals("", writer.toString());
    }

    public void testUnescapeXmlNull() {
        assertNull(StringEscapeUtils.unescapeXml(null));
    }

    public void testUnescapeXmlRoundTrip() {
        String original = "\"bread\" & <butter's>";
        String escaped = StringEscapeUtils.escapeXml(original);
        assertEquals(original, StringEscapeUtils.unescapeXml(escaped));
    }

    public void testUnescapeXmlWriterNullWriterThrows() {
        try {
            StringEscapeUtils.unescapeXml((Writer) null, "abc");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            // expected
        } catch (IOException e) {
            fail("Expected IllegalArgumentException, got IOException: " + e);
        }
    }

    public void testUnescapeXmlWriterNullStringIsNoOp() throws IOException {
        StringWriter writer = new StringWriter();
        StringEscapeUtils.unescapeXml(writer, null);
        assertEquals("", writer.toString());
    }

    //----------------------------------------------------------------------
    // escapeSql
    //----------------------------------------------------------------------

    public void testEscapeSqlNull() {
        assertNull(StringEscapeUtils.escapeSql(null));
    }

    public void testEscapeSqlEmpty() {
        assertEquals("", StringEscapeUtils.escapeSql(""));
    }

    public void testEscapeSqlNoQuotes() {
        assertEquals("SELECT * FROM t", StringEscapeUtils.escapeSql("SELECT * FROM t"));
    }

    public void testEscapeSqlSingleQuoteDoubled() {
        assertEquals("McHale''s Navy", StringEscapeUtils.escapeSql("McHale's Navy"));
    }

    public void testEscapeSqlMultipleQuotes() {
        assertEquals("''''", StringEscapeUtils.escapeSql("''"));
    }

    public void testEscapeSqlDoesNotTouchPercentOrUnderscore() {
        // the javadoc explicitly says LIKE-clause wildcards are not handled.
        assertEquals("100%_done", StringEscapeUtils.escapeSql("100%_done"));
    }
}
